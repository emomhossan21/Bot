<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Breadcrumbs Cocon-Aware
 *
 * KILLER FEATURE: Breadcrumbs = cocon structure, NOT WordPress categories.
 * Home > Cluster > Pillar > Article (instead of Home > Category > Article)
 *
 * Features:
 * - Cocon-aware trail builder using get_cocon_data()
 * - JSON-LD BreadcrumbList auto-inject in wp_head
 * - HTML renderer: shortcode [hts_breadcrumbs] + PHP function hts_breadcrumbs()
 * - Gutenberg Block (server-side)
 * - Fallback to WordPress category if page not in a cocon
 * - Dual mode: HTML+JSON or JSON-only (for themes with existing visual breadcrumbs)
 * - Customization: separator, max chars, show home, wrapper class
 *
 * @since 3.0.0
 */

class HTS_Breadcrumbs {

    const OPTION_KEY = 'hts_breadcrumbs_settings';

    /* Default settings */
    private static $defaults = array(
        'enabled'        => '1',
        'mode'           => 'both',       // 'both' | 'json_only' | 'html_only'
        'separator'      => ' › ',        // › / > / → / »
        'show_home'      => '1',
        'home_label'     => 'Accueil',
        'max_title_chars'=> 50,
        'show_current'   => '1',          // Show current page (non-linked) at end
        'wrapper_class'  => 'hts-breadcrumbs',
        'auto_inject'    => '1',          // Auto-inject before content
        'inject_position'=> 'before',     // 'before' | 'after' content
    );

    /* ══════════════════════════════════════════════
     *  INIT
     * ══════════════════════════════════════════════ */

    public function init() {
        // ── Cockpit guard: if module is OFF, no breadcrumbs ──
        if ( get_option( 'hts_module_breadcrumbs', '0' ) !== '1' ) return;

        $settings = self::get_settings();
        if ( $settings['enabled'] !== '1' ) return;

        // JSON-LD in wp_head (always if mode includes json)
        if ( in_array( $settings['mode'], array( 'both', 'json_only' ), true ) ) {
            add_action( 'wp_head', array( $this, 'inject_jsonld' ), 90 );
        }

        // Auto-inject HTML before/after content
        if ( $settings['auto_inject'] === '1' && in_array( $settings['mode'], array( 'both', 'html_only' ), true ) ) {
            add_filter( 'the_content', array( $this, 'auto_inject_html' ), 5 );
        }

        // Shortcode
        add_shortcode( 'hts_breadcrumbs', array( $this, 'shortcode_handler' ) );

        // Gutenberg block (server-side rendered)
        add_action( 'init', array( $this, 'register_block' ) );

        // AJAX settings
        add_action( 'wp_ajax_hts_breadcrumbs_save', array( $this, 'ajax_save_settings' ) );
    }

    /* ══════════════════════════════════════════════
     *  SETTINGS
     * ══════════════════════════════════════════════ */

    public static function get_settings() {
        $saved = get_option( self::OPTION_KEY, array() );
        return wp_parse_args( $saved, self::$defaults );
    }

    public function ajax_save_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        $settings = array(
            'enabled'         => sanitize_text_field( $_POST['enabled'] ?? '1' ),
            'mode'            => sanitize_text_field( $_POST['mode'] ?? 'both' ),
            'separator'       => sanitize_text_field( $_POST['separator'] ?? ' › ' ),
            'show_home'       => sanitize_text_field( $_POST['show_home'] ?? '1' ),
            'home_label'      => sanitize_text_field( $_POST['home_label'] ?? 'Accueil' ),
            'max_title_chars' => max( 10, (int) ( $_POST['max_title_chars'] ?? 50 ) ),
            'show_current'    => sanitize_text_field( $_POST['show_current'] ?? '1' ),
            'wrapper_class'   => sanitize_html_class( $_POST['wrapper_class'] ?? 'hts-breadcrumbs' ),
            'auto_inject'     => sanitize_text_field( $_POST['auto_inject'] ?? '1' ),
            'inject_position' => sanitize_text_field( $_POST['inject_position'] ?? 'before' ),
        );

        update_option( self::OPTION_KEY, $settings );
        hts_add_log( 'Breadcrumbs : paramètres mis à jour', 'success', 'breadcrumbs' );
        wp_send_json_success();
    }

    /* ══════════════════════════════════════════════
     *  BUILD TRAIL — Core Logic
     *
     *  Priority:
     *  1. Cocon: Home > Cluster Name > Pillar > Current
     *  2. WP Category fallback: Home > Category > Current
     *  3. Simple: Home > Current
     * ══════════════════════════════════════════════ */

    /**
     * Build the breadcrumb trail for a given post.
     * Returns array of [ 'label' => string, 'url' => string|null ]
     * Last item has url = null (current page).
     */
    public static function build_trail( $post_id = null ) {
        if ( ! $post_id ) $post_id = get_the_ID();
        if ( ! $post_id ) return array();

        $post = get_post( $post_id );
        if ( ! $post ) return array();

        $settings = self::get_settings();
        $trail = array();

        // ── Home ──
        if ( $settings['show_home'] === '1' ) {
            $trail[] = array(
                'label' => $settings['home_label'],
                'url'   => home_url( '/' ),
            );
        }

        // ── Try Cocon path ──
        $cocon_trail = self::get_cocon_trail( $post_id );

        if ( ! empty( $cocon_trail ) ) {
            $trail = array_merge( $trail, $cocon_trail );
        } else {
            // ── Fallback: WordPress category ──
            $cat_trail = self::get_category_trail( $post_id );
            if ( ! empty( $cat_trail ) ) {
                $trail = array_merge( $trail, $cat_trail );
            }
        }

        // ── Current page ──
        if ( $settings['show_current'] === '1' ) {
            $trail[] = array(
                'label' => self::truncate( $post->post_title, $settings['max_title_chars'] ),
                'url'   => null, // No link for current page
            );
        }

        return $trail;
    }

    /**
     * Get cocon-based trail: Cluster Name > Pillar > (current is added by caller)
     */
    private static function get_cocon_trail( $post_id ) {
        if ( ! class_exists( 'HTS_Cocon' ) ) return array();

        $cocon = new HTS_Cocon();
        $data  = $cocon->get_cocon_data();

        if ( empty( $data['clusters'] ) || empty( $data['nodes'] ) ) return array();

        $settings = self::get_settings();

        // Find which cluster this post belongs to
        foreach ( $data['clusters'] as $cluster_name => $cl ) {
            // Skip navigation/utility clusters
            if ( strtolower( $cluster_name ) === 'navigation' ) continue;
            if ( strtolower( $cluster_name ) === 'non classé' ) continue;

            $pages = $cl['pages'] ?? array();
            if ( ! in_array( $post_id, $pages, true ) && ! in_array( (int) $post_id, array_map( 'intval', $pages ), true ) ) {
                continue;
            }

            // Found the cluster!
            $trail = array();
            $pillar_id = (int) ( $cl['pillar_id'] ?? 0 );

            // Add cluster name as a crumb (links to pillar if available)
            $cluster_url = $pillar_id ? get_permalink( $pillar_id ) : null;
            $trail[] = array(
                'label' => self::truncate( $cluster_name, $settings['max_title_chars'] ),
                'url'   => $cluster_url,
            );

            // If current page IS the pillar, don't add pillar separately
            if ( $pillar_id && $pillar_id !== (int) $post_id ) {
                $pillar_title = get_the_title( $pillar_id );
                if ( $pillar_title ) {
                    $trail[] = array(
                        'label' => self::truncate( $pillar_title, $settings['max_title_chars'] ),
                        'url'   => get_permalink( $pillar_id ),
                    );
                }
            }

            return $trail;
        }

        return array();
    }

    /**
     * Fallback: WordPress category hierarchy.
     */
    private static function get_category_trail( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== 'post' ) return array();

        $settings = self::get_settings();
        $categories = get_the_category( $post_id );
        if ( empty( $categories ) ) return array();

        // Pick the "deepest" category (most ancestors)
        $best_cat = $categories[0];
        $best_depth = 0;
        foreach ( $categories as $cat ) {
            $depth = count( get_ancestors( $cat->term_id, 'category' ) );
            if ( $depth > $best_depth ) {
                $best_depth = $depth;
                $best_cat = $cat;
            }
        }

        // Build ancestor chain
        $chain = array();
        $ancestors = array_reverse( get_ancestors( $best_cat->term_id, 'category' ) );
        foreach ( $ancestors as $anc_id ) {
            $anc = get_term( $anc_id, 'category' );
            if ( $anc && ! is_wp_error( $anc ) ) {
                $chain[] = array(
                    'label' => self::truncate( $anc->name, $settings['max_title_chars'] ),
                    'url'   => get_term_link( $anc ),
                );
            }
        }

        // Add the category itself
        $chain[] = array(
            'label' => self::truncate( $best_cat->name, $settings['max_title_chars'] ),
            'url'   => get_term_link( $best_cat ),
        );

        return $chain;
    }

    /* ══════════════════════════════════════════════
     *  HTML RENDERING
     * ══════════════════════════════════════════════ */

    /**
     * Render breadcrumbs as HTML nav element.
     */
    public static function render_html( $post_id = null ) {
        $trail = self::build_trail( $post_id );
        if ( empty( $trail ) ) return '';

        $settings = self::get_settings();
        $sep = esc_html( $settings['separator'] );
        $class = esc_attr( $settings['wrapper_class'] );

        $html = '<nav class="' . $class . '" aria-label="Fil d\'Ariane">';
        $html .= '<ol itemscope itemtype="https://schema.org/BreadcrumbList" style="display:flex;flex-wrap:wrap;list-style:none;margin:0;padding:0;font-size:13px;gap:2px;">';

        foreach ( $trail as $i => $crumb ) {
            $pos = $i + 1;
            $is_last = ( $crumb['url'] === null );

            $html .= '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" style="display:flex;align-items:center;gap:2px;">';

            if ( $i > 0 ) {
                $html .= '<span class="' . $class . '-sep" style="color:#94a3b8;margin:0 2px;">' . $sep . '</span>';
            }

            if ( $crumb['url'] && ! $is_last ) {
                $html .= '<a itemprop="item" href="' . esc_url( $crumb['url'] ) . '" style="color:#3b82f6;text-decoration:none;">';
                $html .= '<span itemprop="name">' . esc_html( $crumb['label'] ) . '</span>';
                $html .= '</a>';
            } else {
                $html .= '<span itemprop="name" class="hts-text-secondary">' . esc_html( $crumb['label'] ) . '</span>';
            }

            $html .= '<meta itemprop="position" content="' . $pos . '">';
            $html .= '</li>';
        }

        $html .= '</ol></nav>';

        return $html;
    }

    /**
     * Auto-inject HTML before/after the_content.
     */
    public function auto_inject_html( $content ) {
        if ( ! is_singular() || is_admin() ) return $content;

        // Don't inject on homepage
        if ( is_front_page() || is_home() ) return $content;

        $html = self::render_html();
        if ( ! $html ) return $content;

        $settings = self::get_settings();
        $wrapper = '<div class="hts-breadcrumbs-auto hts-mb-4">' . $html . '</div>';

        if ( $settings['inject_position'] === 'after' ) {
            return $content . $wrapper;
        }
        return $wrapper . $content;
    }

    /* ══════════════════════════════════════════════
     *  JSON-LD BreadcrumbList
     * ══════════════════════════════════════════════ */

    public function inject_jsonld() {
        if ( ! is_singular() || is_front_page() || is_home() ) return;

        $trail = self::build_trail();
        if ( empty( $trail ) ) return;

        $items = array();
        foreach ( $trail as $i => $crumb ) {
            $item = array(
                '@type'    => 'ListItem',
                'position' => $i + 1,
                'name'     => $crumb['label'],
            );
            if ( $crumb['url'] ) {
                $item['item'] = $crumb['url'];
            }
            $items[] = $item;
        }

        $jsonld = array(
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $items,
        );

        echo '<script type="application/ld+json">' . wp_json_encode( $jsonld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }

    /* ══════════════════════════════════════════════
     *  SHORTCODE [hts_breadcrumbs]
     * ══════════════════════════════════════════════ */

    public function shortcode_handler( $atts ) {
        $atts = shortcode_atts( array(
            'post_id' => null,
        ), $atts );

        return self::render_html( $atts['post_id'] ? (int) $atts['post_id'] : null );
    }

    /* ══════════════════════════════════════════════
     *  GUTENBERG BLOCK (Server-Side Rendered)
     * ══════════════════════════════════════════════ */

    public function register_block() {
        if ( ! function_exists( 'register_block_type' ) ) return;

        register_block_type( 'hts/breadcrumbs', array(
            'render_callback' => array( $this, 'render_block' ),
            'attributes'      => array(),
        ) );
    }

    public function render_block( $attributes ) {
        return self::render_html();
    }

    /* ══════════════════════════════════════════════
     *  UTILITY
     * ══════════════════════════════════════════════ */

    private static function truncate( $text, $max = 50 ) {
        if ( mb_strlen( $text ) <= $max ) return $text;
        return mb_substr( $text, 0, $max - 1 ) . '…';
    }
}

/* ══════════════════════════════════════════════
 *  GLOBAL HELPER FUNCTION
 *  Usage in themes: <?php hts_breadcrumbs(); ?>
 * ══════════════════════════════════════════════ */

if ( ! function_exists( 'hts_breadcrumbs' ) ) {
    function hts_breadcrumbs( $post_id = null ) {
        echo HTS_Breadcrumbs::render_html( $post_id );
    }
}
