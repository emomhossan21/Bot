<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Auto-Updater
 *
 * @package Hack_The_SEO_Light
 * @since   1.2.0
 */


class HTS_Updater {

    const SLUG      = 'hack-the-seo-light';
    const CACHE_KEY = 'hts_update_check';
    const CACHE_TTL = 12 * HOUR_IN_SECONDS;

    private $basename;

    public function init() {
        $this->basename = defined( 'HTS__PLUGIN_BASENAME' )
            ? HTS__PLUGIN_BASENAME
            : 'hack-the-seo-light/hack-the-seo-light.php';

        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_for_update' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_info' ], 20, 3 );
        add_action( 'upgrader_process_complete', [ $this, 'clear_cache' ], 10, 2 );
        add_action( 'wp_ajax_hts_check_update_now', [ $this, 'ajax_check_update' ] );
    }

    public function check_for_update( $transient ) {
        if ( empty( $transient->checked ) ) return $transient;

        $remote = $this->get_remote_version();

        if ( $remote && ! empty( $remote['version'] ) && version_compare( $remote['version'], HTS__VERSION, '>' ) ) {
            $transient->response[ $this->basename ] = (object) [
                'slug'         => self::SLUG,
                'plugin'       => $this->basename,
                'new_version'  => $remote['version'],
                'url'          => $remote['homepage'] ?? 'https://hacktheseo.com/',
                'package'      => $this->get_download_url( $remote ),
                'tested'       => $remote['tested'] ?? '',
                'requires'     => $remote['requires'] ?? '6.0',
                'requires_php' => $remote['requires_php'] ?? '7.4',
                'icons'        => $remote['icons'] ?? [],
                'banners'      => $remote['banners'] ?? [],
            ];
        } else {
            $transient->no_update[ $this->basename ] = (object) [
                'slug'        => self::SLUG,
                'plugin'      => $this->basename,
                'new_version' => HTS__VERSION,
                'url'         => 'https://hacktheseo.com/',
            ];
        }

        return $transient;
    }

    public function plugin_info( $result, $action, $args ) {
        if ( $action !== 'plugin_information' ) return $result;
        if ( ! isset( $args->slug ) || $args->slug !== self::SLUG ) return $result;

        $remote = $this->get_remote_version();
        if ( ! $remote ) return $result;

        $info = new \stdClass();
        $info->name          = 'Hack The SEO Light';
        $info->slug          = self::SLUG;
        $info->version       = $remote['version'] ?? HTS__VERSION;
        $info->author        = '<a href="https://hacktheseo.com/">Hack The SEO</a>';
        $info->homepage      = $remote['homepage'] ?? 'https://hacktheseo.com/';
        $info->requires      = $remote['requires'] ?? '6.0';
        $info->requires_php  = $remote['requires_php'] ?? '7.4';
        $info->tested        = $remote['tested'] ?? '';
        $info->last_updated  = $remote['last_updated'] ?? '';
        $info->download_link = $this->get_download_url( $remote );
        $info->sections      = [
            'description' => $remote['description'] ?? 'SEO complet pour WordPress.',
            'changelog'   => $remote['changelog'] ?? '<p>Aucun changelog.</p>',
        ];
        if ( ! empty( $remote['banners'] ) ) $info->banners = $remote['banners'];

        return $info;
    }

    private function get_remote_version( $force = false ) {
        if ( ! $force ) {
            $cached = get_transient( self::CACHE_KEY );
            if ( $cached !== false ) return $cached;
        }

        $api_key  = hts_get_api_key();
        $base_url = rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' );

        $url = add_query_arg( [
            'slug'            => self::SLUG,
            'current_version' => HTS__VERSION,
            'domain'          => wp_parse_url( home_url(), PHP_URL_HOST ),
        ], $base_url . '/api/plugin/version' );

        $headers = [ 'Accept' => 'application/json' ];
        if ( ! empty( $api_key ) ) $headers['x-api-key'] = $api_key;

        $response = wp_remote_get( $url, [ 'timeout' => 15, 'headers' => $headers ] );

        if ( is_wp_error( $response ) ) return false;

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 || empty( $body['version'] ) ) return false;

        set_transient( self::CACHE_KEY, $body, self::CACHE_TTL );
        return $body;
    }

    private function get_download_url( $remote ) {
        if ( ! HTS_Subscription::is_active() ) return '';
        if ( ! empty( $remote['download_url'] ) ) return $remote['download_url'];

        $base_url = rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' );
        return add_query_arg( [
            'slug'    => self::SLUG,
            'api_key' => hts_get_api_key(),
            'domain'  => wp_parse_url( home_url(), PHP_URL_HOST ),
        ], $base_url . '/api/plugin/download' );
    }

    public function clear_cache( $upgrader, $options ) {
        if ( isset( $options['action'], $options['type'] ) && $options['action'] === 'update' && $options['type'] === 'plugin' ) {
            delete_transient( self::CACHE_KEY );
        }
    }

    public function ajax_check_update() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [ 'message' => 'Permissions insuffisantes.' ] );

        delete_transient( self::CACHE_KEY );
        $remote = $this->get_remote_version( true );
        if ( ! $remote ) wp_send_json_error( [ 'message' => 'Serveur de MAJ injoignable.' ] );

        $has_update = version_compare( $remote['version'], HTS__VERSION, '>' );
        wp_send_json_success( [
            'current'    => HTS__VERSION,
            'latest'     => $remote['version'],
            'has_update' => $has_update,
            'message'    => $has_update
                ? sprintf( 'Nouvelle version %s disponible !', $remote['version'] )
                : sprintf( 'Vous êtes à jour (v%s).', HTS__VERSION ),
        ] );
    }
}
