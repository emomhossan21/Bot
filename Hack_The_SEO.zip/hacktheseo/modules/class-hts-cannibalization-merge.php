<?php
defined( 'ABSPATH' ) || exit;
/**
 * Cannibalization Merge — Merge IA + Check pré-écriture
 *
 * Étend le module Cannibalization existant :
 * - Merge IA via API HTS (concat → API → merge intelligent)
 * - Apply merge : backup + audit trail + rollback possible
 * - Post-merge : trash loser + _hts_merged_into + 301 + invalidate embeddings
 * - Check pré-écriture : vérifier cannibalisation AVANT d'écrire
 * - Connecte au Workflow Engine (propose merge/redirect/differentiate)
 *
 * @since 1.33.0
 * @package HackTheSEO
 */

class HTS_Cannibalization_Merge {

    public function init() {
        add_action( 'wp_ajax_hts_cannib_merge_request', array( $this, 'ajax_merge_request' ) );
        add_action( 'wp_ajax_hts_cannib_merge_apply',   array( $this, 'ajax_merge_apply' ) );
        add_action( 'wp_ajax_hts_cannib_pre_check',     array( $this, 'ajax_pre_check' ) );

        // Hook Workflow dispatch
        add_filter( 'hts_workflow_dispatch', array( $this, 'handle_workflow_dispatch' ), 10, 5 );

        // Hook pré-écriture Commander
        add_filter( 'hts_commander_pre_write_check', array( $this, 'commander_pre_write_check' ), 10, 3 );

        // Hook import topical map
        add_filter( 'hts_cocon_import_filter', array( $this, 'filter_topical_map_import' ), 10, 2 );
    }

    /* ═══════════════════════════════════════════════
     *  4.1 — MERGE IA VIA API HTS
     * ═══════════════════════════════════════════════ */

    /**
     * Envoyer deux articles à l'API HTS pour merge intelligent.
     *
     * @param int $winner_id  Post à garder
     * @param int $loser_id   Post à fusionner dedans
     * @return array { merged_content, merged_title } ou { error }
     */
    public function request_merge( $winner_id, $loser_id ) {
        $winner = get_post( $winner_id );
        $loser  = get_post( $loser_id );

        if ( ! $winner || ! $loser ) {
            return array( 'error' => 'Un des deux articles est introuvable.' );
        }

        $api_key  = get_option( 'hts_api_key', '' );
        $base_url = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );

        if ( empty( $api_key ) ) {
            return array( 'error' => 'Clé API Hack The SEO non configurée.' );
        }

        // Concaténer les contenus pour l'API
        $body = array(
            'site_url' => site_url(),
            'merge'    => array(
                'winner' => array(
                    'title'   => $winner->post_title,
                    'content' => $winner->post_content,
                    'keyword' => get_post_meta( $winner_id, '_hts_api_keyword', true ) ?: $winner->post_title,
                    'url'     => get_permalink( $winner_id ),
                ),
                'loser' => array(
                    'title'   => $loser->post_title,
                    'content' => $loser->post_content,
                    'keyword' => get_post_meta( $loser_id, '_hts_api_keyword', true ) ?: $loser->post_title,
                    'url'     => get_permalink( $loser_id ),
                ),
            ),
            'language' => get_option( 'hts_language', 'fr' ),
        );

        $url = rtrim( $base_url, '/' ) . '/api/v1/content/merge';

        $response = wp_remote_post( $url, array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'X-API-KEY'    => $api_key,
            ),
            'body' => wp_json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) {
            $err = $response->get_error_message();
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Merge ERROR : ' . $err, 'error', 'cannibalization' );
            }
            return array( 'error' => 'Connexion API échouée : ' . $err );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 || empty( $data['content'] ) ) {
            $msg = $data['message'] ?? $data['error'] ?? 'Réponse API invalide (code ' . $code . ')';
            return array( 'error' => $msg );
        }

        return array(
            'merged_content' => $data['content'],
            'merged_title'   => $data['title'] ?? $winner->post_title,
            'winner_id'      => $winner_id,
            'loser_id'       => $loser_id,
        );
    }

    /* ═══════════════════════════════════════════════
     *  4.2 — APPLY MERGE (Content Writer + Audit Trail + Rollback)
     * ═══════════════════════════════════════════════ */

    /**
     * Appliquer un merge : mettre à jour le winner, trash le loser.
     *
     * @param int    $winner_id
     * @param int    $loser_id
     * @param string $merged_content  HTML du contenu fusionné
     * @param string $merged_title    Titre optionnel
     * @return array { success, winner_id, loser_id } ou { error }
     */
    public function apply_merge( $winner_id, $loser_id, $merged_content, $merged_title = '' ) {
        $winner = get_post( $winner_id );
        $loser  = get_post( $loser_id );

        if ( ! $winner || ! $loser ) {
            return array( 'error' => 'Article introuvable.' );
        }

        // ── Backup winner (pour rollback) ──
        update_post_meta( $winner_id, '_hts_merge_backup_content', $winner->post_content );
        update_post_meta( $winner_id, '_hts_merge_backup_title', $winner->post_title );
        update_post_meta( $winner_id, '_hts_merge_backup_date', current_time( 'mysql' ) );

        // ── Audit Trail ──
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log( 'cannib_merge', array(
                'post_id'         => $winner_id,
                'target_id'       => $loser_id,
                'snapshot_before' => mb_substr( $winner->post_content, 0, 500 ),
                'extra'           => wp_json_encode( array(
                    'loser_title' => $loser->post_title,
                    'loser_url'   => get_permalink( $loser_id ),
                ) ),
            ) );
        }

        // ── Update winner ──
        $update = array(
            'ID'           => $winner_id,
            'post_content' => wp_kses_post( $merged_content ),
        );
        if ( ! empty( $merged_title ) ) {
            $update['post_title'] = sanitize_text_field( $merged_title );
        }

        $result = wp_update_post( $update );
        if ( is_wp_error( $result ) ) {
            return array( 'error' => 'Échec mise à jour du winner : ' . $result->get_error_message() );
        }

        // ── 4.3 Post-merge ──
        $this->post_merge_cleanup( $winner_id, $loser_id );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( 'Merge appliqué : #%d ← #%d (%s)', $winner_id, $loser_id, $loser->post_title ),
                'success', 'cannibalization'
            );
        }

        return array(
            'success'   => true,
            'winner_id' => $winner_id,
            'loser_id'  => $loser_id,
        );
    }

    /* ═══════════════════════════════════════════════
     *  4.3 — POST-MERGE CLEANUP
     * ═══════════════════════════════════════════════ */

    /**
     * Après merge :
     * - Trash le loser (poubelle WP, PAS force delete)
     * - Marquer _hts_merged_into
     * - Créer 301 redirect
     * - Invalider embeddings du loser
     */
    private function post_merge_cleanup( $winner_id, $loser_id ) {

        // ── Marquer le loser ──
        update_post_meta( $loser_id, '_hts_merged_into', $winner_id );
        update_post_meta( $loser_id, '_hts_merged_at', current_time( 'mysql' ) );

        // ── Trash (PAS delete force — reste récupérable) ──
        wp_trash_post( $loser_id );

        // ── 301 redirect via module Redirects ──
        if ( class_exists( 'HTS_Redirects' ) ) {
            $from = wp_make_link_relative( get_permalink( $loser_id ) );
            $to   = get_permalink( $winner_id );
            $redirects = new HTS_Redirects();
            if ( method_exists( $redirects, 'add_redirect_rule' ) ) {
                $redirects->add_redirect_rule( $from, $to, 301, 'cannib_merge', 'Auto-merge #' . $loser_id . ' → #' . $winner_id );
            }
        }

        // ── Invalider embeddings du loser ──
        $this->invalidate_embeddings( $loser_id );

        // ── Recalculer GEO Score du winner ──
        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $geo = new HTS_Geo_Score();
            $geo->calculate( $winner_id, true );
        }
    }

    /**
     * Supprimer les embeddings d'un post.
     */
    private function invalidate_embeddings( $post_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_embeddings';

        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( ! $exists ) return;

        $wpdb->delete( $table, array( 'post_id' => $post_id ) );
    }

    /* ═══════════════════════════════════════════════
     *  4.4 — CHECK PRÉ-ÉCRITURE
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifier si un keyword/titre risque de cannibaler un article existant.
     *
     * @param string $keyword
     * @param string $title
     * @param int    $exclude_post_id  Post à exclure (pour les rewrites)
     * @return array|null  null = pas de cannibalisation, sinon { post_id, title, score, action }
     */
    public static function pre_check( $keyword, $title = '', $exclude_post_id = 0 ) {
        if ( empty( $keyword ) && empty( $title ) ) return null;

        global $wpdb;
        $search_term = ! empty( $keyword ) ? $keyword : $title;

        // Chercher par keyword exact dans les metas
        $existing = $wpdb->get_results( $wpdb->prepare( "
            SELECT p.ID, p.post_title, m.meta_value AS keyword
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} m ON p.ID = m.post_id
            WHERE p.post_type = 'post'
              AND p.post_status = 'publish'
              AND p.ID != %d
              AND m.meta_key IN ('_hts_api_keyword', '_hts_focus_keyword', '_yoast_wpseo_focuskw', 'rank_math_focus_keyword')
              AND LOWER(m.meta_value) = LOWER(%s)
            LIMIT 5
        ", $exclude_post_id, $search_term ), ARRAY_A );

        if ( ! empty( $existing ) ) {
            $match = $existing[0];
            return array(
                'post_id'  => (int) $match['ID'],
                'title'    => $match['post_title'],
                'keyword'  => $match['keyword'],
                'score'    => 100,
                'match'    => 'keyword_exact',
                'action'   => 'block',
                'message'  => sprintf(
                    'Le keyword "%s" est déjà ciblé par l\'article "%s" (#%d). Risque de cannibalisation élevé.',
                    esc_html( $search_term ), esc_html( $match['post_title'] ), $match['ID']
                ),
            );
        }

        // Chercher par titre similaire (Jaccard > 0.5)
        if ( ! empty( $title ) ) {
            $title_words = self::extract_words( $title );
            $similar = $wpdb->get_results( $wpdb->prepare( "
                SELECT ID, post_title FROM {$wpdb->posts}
                WHERE post_type = 'post' AND post_status = 'publish' AND ID != %d
                LIMIT 200
            ", $exclude_post_id ), ARRAY_A );

            foreach ( $similar as $s ) {
                $s_words = self::extract_words( $s['post_title'] );
                $jaccard = self::jaccard( $title_words, $s_words );
                if ( $jaccard >= 0.5 ) {
                    return array(
                        'post_id'  => (int) $s['ID'],
                        'title'    => $s['post_title'],
                        'keyword'  => '',
                        'score'    => (int) round( $jaccard * 100 ),
                        'match'    => 'title_similar',
                        'action'   => $jaccard >= 0.7 ? 'block' : 'warn',
                        'message'  => sprintf(
                            'L\'article "%s" (#%d) a un titre très similaire (similarité %d%%). Risque de cannibalisation.',
                            esc_html( $s['post_title'] ), $s['ID'], round( $jaccard * 100 )
                        ),
                    );
                }
            }
        }

        return null;
    }

    /**
     * Hook Commander : vérifier cannibalisation avant écriture.
     *
     * @param bool|null $result  null = OK, false = bloquer
     * @param string    $keyword
     * @param string    $title
     * @return bool|null
     */
    public function commander_pre_write_check( $result, $keyword, $title ) {
        $check = self::pre_check( $keyword, $title );

        if ( ! $check ) return $result; // Pas de cannibalisation

        if ( $check['action'] === 'block' ) {
            // ── 4.5 Proposer dans Inbox au lieu d'écrire ──
            if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                HTS_Workflow_Engine::propose(
                    'cannibalization',
                    'cannib_detected_pre_write',
                    $check['post_id'],
                    array(
                        'message'        => $check['message'],
                        'new_keyword'    => $keyword,
                        'new_title'      => $title,
                        'existing_id'    => $check['post_id'],
                        'existing_title' => $check['title'],
                        'match_type'     => $check['match'],
                        'similarity'     => $check['score'],
                    ),
                    'high'
                );
            }
            return false; // Bloquer l\'écriture
        }

        return $result; // Warn = laisser passer mais log
    }

    /**
     * 4.6 — Filtrer les sujets du topical map import.
     */
    public function filter_topical_map_import( $articles, $cocon_id ) {
        if ( ! is_array( $articles ) ) return $articles;

        $filtered = array();
        foreach ( $articles as $article ) {
            $kw = $article['keyword'] ?? '';
            $title = $article['title'] ?? '';
            $check = self::pre_check( $kw, $title );

            if ( $check && $check['action'] === 'block' ) {
                // Proposer dans l'Inbox au lieu d'importer
                if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                    HTS_Workflow_Engine::propose(
                        'cannibalization',
                        'cannib_detected_import',
                        $check['post_id'],
                        array(
                            'message'     => $check['message'],
                            'new_keyword' => $kw,
                            'cocon_id'    => $cocon_id,
                        ),
                        'medium'
                    );
                }
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Import filtré : "' . $kw . '" cannibale avec #' . $check['post_id'], 'warn', 'cannibalization' );
                }
                continue; // Ne pas importer ce sujet
            }

            $filtered[] = $article;
        }

        return $filtered;
    }

    /* ═══════════════════════════════════════════════
     *  4.7 — WORKFLOW ENGINE CONNECTION
     * ═══════════════════════════════════════════════ */

    /**
     * Proposer les paires cannibalisation dans le Workflow Engine.
     */
    public static function propose_pairs_to_inbox() {
        if ( ! class_exists( 'HTS_Cannibalization' ) || ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;

        $cannib = new HTS_Cannibalization();
        $data = $cannib->get_pairs();
        $pairs = $data['pairs'] ?? array();

        $count = 0;
        foreach ( $pairs as $pair ) {
            if ( ( $pair['status'] ?? '' ) === 'dismissed' ) continue;

            $rec = $pair['recommendation'] ?? array();
            $action = $rec['action'] ?? 'keep';
            if ( $action === 'keep' ) continue;

            $type = 'cannib_' . $action; // cannib_merge, cannib_redirect, cannib_differentiate
            $post_id = $rec['winner'] ?? $pair['post_a'] ?? 0;

            HTS_Workflow_Engine::propose(
                'cannibalization',
                $type,
                $post_id,
                array(
                    'post_a'  => $pair['post_a'] ?? 0,
                    'post_b'  => $pair['post_b'] ?? 0,
                    'score'   => $pair['score'] ?? 0,
                    'reason'  => $rec['reason'] ?? '',
                    'winner'  => $rec['winner'] ?? 0,
                    'loser'   => $rec['loser'] ?? 0,
                ),
                ( $pair['score'] ?? 0 ) >= 80 ? 'high' : 'medium'
            );
            $count++;
        }

        return $count;
    }

    /**
     * Handler Workflow dispatch pour merge/redirect.
     */
    public function handle_workflow_dispatch( $result, $agent, $type, $post_id, $data ) {
        if ( $agent !== 'cannibalization' ) return $result;

        if ( $type === 'cannib_merge' ) {
            $winner = (int) ( $data['winner'] ?? 0 );
            $loser  = (int) ( $data['loser'] ?? 0 );
            if ( ! $winner || ! $loser ) return false;

            $merge_result = $this->request_merge( $winner, $loser );
            if ( isset( $merge_result['error'] ) ) return false;

            $apply = $this->apply_merge( $winner, $loser, $merge_result['merged_content'], $merge_result['merged_title'] ?? '' );
            return ! isset( $apply['error'] );
        }

        if ( $type === 'cannib_redirect' ) {
            $winner = (int) ( $data['winner'] ?? 0 );
            $loser  = (int) ( $data['loser'] ?? 0 );
            if ( ! $winner || ! $loser ) return false;

            // Créer la 301
            if ( class_exists( 'HTS_Redirects' ) ) {
                $from = wp_make_link_relative( get_permalink( $loser ) );
                $to   = get_permalink( $winner );
                $redirects = new HTS_Redirects();
                if ( method_exists( $redirects, 'add_redirect_rule' ) ) {
                    $redirects->add_redirect_rule( $from, $to, 301, 'cannib_redirect', 'Cannibalisation : #' . $loser . ' → #' . $winner );
                }
            }
            return true;
        }

        return $result;
    }

    /* ═══════════════════════════════════════════════
     *  AJAX HANDLERS
     * ═══════════════════════════════════════════════ */

    public function ajax_merge_request() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $winner_id = absint( $_POST['winner_id'] ?? 0 );
        $loser_id  = absint( $_POST['loser_id'] ?? 0 );
        if ( ! $winner_id || ! $loser_id ) wp_send_json_error( 'IDs manquants' );

        $result = $this->request_merge( $winner_id, $loser_id );
        if ( isset( $result['error'] ) ) {
            wp_send_json_error( array( 'message' => $result['error'] ) );
        }

        wp_send_json_success( $result );
    }

    public function ajax_merge_apply() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $winner_id = absint( $_POST['winner_id'] ?? 0 );
        $loser_id  = absint( $_POST['loser_id'] ?? 0 );
        $content   = wp_kses_post( $_POST['content'] ?? '' );
        $title     = sanitize_text_field( $_POST['title'] ?? '' );

        if ( ! $winner_id || ! $loser_id || empty( $content ) ) {
            wp_send_json_error( 'Paramètres manquants' );
        }

        $result = $this->apply_merge( $winner_id, $loser_id, $content, $title );
        if ( isset( $result['error'] ) ) {
            wp_send_json_error( array( 'message' => $result['error'] ) );
        }

        wp_send_json_success( $result );
    }

    public function ajax_pre_check() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
        $title   = sanitize_text_field( $_POST['title'] ?? '' );
        $exclude = absint( $_POST['exclude_post_id'] ?? 0 );

        $check = self::pre_check( $keyword, $title, $exclude );

        if ( $check ) {
            wp_send_json_success( array( 'cannibalization' => true, 'details' => $check ) );
        } else {
            wp_send_json_success( array( 'cannibalization' => false ) );
        }
    }

    /* ═══════════════════════════════════════════════
     *  HELPERS
     * ═══════════════════════════════════════════════ */

    private static function extract_words( $text ) {
        $text = mb_strtolower( $text );
        $text = preg_replace( '/[^\p{L}\p{N}\s]/u', '', $text );
        $words = preg_split( '/\s+/', $text );
        $stop = function_exists( 'hts_get_stopwords' ) ? hts_get_stopwords() : array();
        return array_values( array_diff( $words, $stop ) );
    }

    private static function jaccard( array $a, array $b ) {
        if ( empty( $a ) && empty( $b ) ) return 0;
        $inter = count( array_intersect( $a, $b ) );
        $union = count( array_unique( array_merge( $a, $b ) ) );
        return $union > 0 ? $inter / $union : 0;
    }
}
