<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Meta Tags — Full SEO Meta Takeover
 *
 * Gère TOUS les meta tags SEO :
 *   - <title>           → document_title_parts filter
 *   - meta description  → wp_head injection
 *   - Open Graph        → og:title, og:description, og:url, og:type, og:image, og:locale, og:site_name
 *   - Twitter Cards     → twitter:card, twitter:title, twitter:description, twitter:image
 *   - Alt text          → Auto-fill missing alt from filename/title/focus keyword
 *
 * Cascade de lecture :
 *   1. HTS meta (_hts_meta_title, _hts_meta_description)
 *   2. Competitor meta (rank_math_title, _yoast_wpseo_title, etc.)
 *   3. Auto-generated from post title + excerpt
 *
 * Variable resolution:
 *   %title%, %sep%, %sitename%, %page%, %excerpt%, %category%, %tag%, %date%
 *   %%title%%, %%sep%%, %%sitename%% (Yoast format)
 *
 * @since 3.3.0
 */

class HTS_Meta_Tags {

    /** @var string Separator for title */
    private $sep = '—';

    public function init() {
        if ( get_option( 'hts_module_meta_tags', '1' ) !== '1' ) return;

        // ── Title ──
        add_filter( 'pre_get_document_title', array( $this, 'filter_title' ), 999 );
        add_filter( 'document_title_parts',   array( $this, 'filter_title_parts' ), 999 );
        add_filter( 'document_title_separator', array( $this, 'filter_separator' ), 999 );

        // ── Meta description + OG + Twitter → wp_head ──
        add_action( 'wp_head', array( $this, 'inject_meta_tags' ), 1 );

        // ── Rel prev/next (pagination) → wp_head ──
        add_action( 'wp_head', array( $this, 'inject_rel_prev_next' ), 2 );

        // ── Hreflang (multilingual) → wp_head ──
        add_action( 'wp_head', array( $this, 'inject_hreflang' ), 2 );

        // ── Remove competitor OG/meta output ──
        add_action( 'wp_head', array( $this, 'remove_competitor_meta' ), 0 );

        // ── Alt text auto-fill on save ──
        add_action( 'save_post', array( $this, 'auto_fill_image_alts' ), 20, 2 );

        // ── Admin: meta box in post editor ──
        add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
        add_action( 'save_post',      array( $this, 'save_meta_box' ), 10, 2 );

        // ── AJAX: preview ──
        add_action( 'wp_ajax_hts_meta_preview', array( $this, 'ajax_preview' ) );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SEPARATOR
     * ═══════════════════════════════════════════════════════════════ */

    public function filter_separator( $sep ) {
        $custom = get_option( 'hts_title_separator', '' );
        return $custom ?: $this->sep;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  TITLE — pre_get_document_title (highest priority)
     * ═══════════════════════════════════════════════════════════════ */

    public function filter_title( $title ) {
        // Only override if we have a custom title for this page
        if ( is_singular() ) {
            $post_id = get_queried_object_id();
            $custom  = $this->get_meta_title( $post_id );
            if ( $custom ) return $custom;
        }

        // Homepage safety net
        if ( ( is_front_page() || is_home() ) && empty( $title ) ) {
            $home_title = get_option( 'hts_home_title', '' );
            if ( $home_title ) return $this->resolve_variables( $home_title );
            return get_bloginfo( 'name' );
        }

        return $title; // Let document_title_parts handle the rest
    }

    public function filter_title_parts( $parts ) {
        if ( is_singular() ) {
            $post_id = get_queried_object_id();
            $custom  = $this->get_meta_title( $post_id );
            if ( $custom ) {
                // If custom title contains a separator, it's self-contained
                if ( preg_match( '/\s[-|–—]\s/', $custom ) ) {
                    return array( 'title' => $custom );
                }
                // Otherwise let WordPress append the site name
                $parts['title'] = $custom;
                return $parts;
            }
        }

        // Home page
        if ( is_front_page() || is_home() ) {
            $home_title = get_option( 'hts_home_title', '' );
            if ( $home_title ) {
                return array( 'title' => $this->resolve_variables( $home_title ) );
            }
            if ( empty( $parts['title'] ) ) {
                $parts['title'] = get_bloginfo( 'name' );
            }
        }

        // Archives
        if ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();
            if ( $term ) {
                $parts['title'] = $term->name;
            }
        }

        return $parts;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  GET META TITLE — Cascade HTS → Competitor → Auto
     * ═══════════════════════════════════════════════════════════════ */

    public function get_meta_title( $post_id ) {
        // 1. HTS custom
        $title = get_post_meta( $post_id, '_hts_meta_title', true );
        if ( ! empty( $title ) ) {
            $resolved = $this->resolve_variables( $title, $post_id );
            if ( ! empty( trim( $resolved ) ) ) return $resolved;
        }

        // 2. Competitor meta — resolve first, skip if result is empty
        $competitor_keys = array(
            'rank_math_title',
            '_yoast_wpseo_title',
            '_seopress_titles_title',
            '_aioseo_title',
        );
        foreach ( $competitor_keys as $key ) {
            $val = get_post_meta( $post_id, $key, true );
            if ( ! empty( $val ) ) {
                $resolved = $this->resolve_variables( $val, $post_id );
                if ( ! empty( trim( $resolved ) ) ) return $resolved;
            }
        }

        // 3. Auto: "Post Title — Site Name"
        return '';
    }

    /* ═══════════════════════════════════════════════════════════════
     *  GET META DESCRIPTION — Cascade HTS → Competitor → Auto
     * ═══════════════════════════════════════════════════════════════ */

    public function get_meta_description( $post_id ) {
        // 1. HTS custom
        $desc = get_post_meta( $post_id, '_hts_meta_description', true );
        if ( ! empty( $desc ) ) {
            $resolved = $this->resolve_variables( $desc, $post_id );
            if ( ! empty( trim( $resolved ) ) ) return $resolved;
        }

        // 2. Competitor meta — resolve first, skip if result is empty (e.g. %excerpt% with no excerpt)
        $competitor_keys = array(
            'rank_math_description',
            '_yoast_wpseo_metadesc',
            '_seopress_titles_desc',
            '_aioseo_description',
        );
        foreach ( $competitor_keys as $key ) {
            $val = get_post_meta( $post_id, $key, true );
            if ( ! empty( $val ) ) {
                $resolved = $this->resolve_variables( $val, $post_id );
                if ( ! empty( trim( $resolved ) ) ) return $resolved;
            }
        }

        // 3. Auto from excerpt → stripped content
        $post = get_post( $post_id );
        if ( ! $post ) return '';

        $desc = $post->post_excerpt;
        if ( ! empty( $desc ) ) {
            $desc = wp_strip_all_tags( $desc );
        }
        if ( empty( $desc ) ) {
            // Use Content Extractor (handles Elementor, Divi, etc.) if available
            if ( class_exists( 'HTS_Content_Extractor' ) ) {
                $desc = HTS_Content_Extractor::get_content( $post_id );
            } else {
                $desc = $post->post_content;
            }
            // Strip shortcodes BEFORE stripping tags (prevents [contact-form-7 ...] in SERP)
            $desc = strip_shortcodes( $desc );
            $desc = wp_strip_all_tags( $desc );
        }
        // Normalize whitespace
        $desc = preg_replace( '/\s+/', ' ', trim( $desc ) );
        // Character-based truncation (155 chars max for Google SERP 2026)
        if ( mb_strlen( $desc ) > 155 ) {
            $desc = mb_substr( $desc, 0, 152 ) . '…';
        }

        return $desc;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  VARIABLE RESOLUTION
     *  Supports both %var% (RM/HTS) and %%var%% (Yoast) formats
     * ═══════════════════════════════════════════════════════════════ */

    public function resolve_variables( $template, $post_id = 0 ) {
        if ( empty( $template ) ) return '';

        $post = $post_id ? get_post( $post_id ) : null;

        $replacements = array(
            'sitename'     => get_bloginfo( 'name' ),
            'site_title'   => get_bloginfo( 'name' ),
            'sitedesc'     => get_bloginfo( 'description' ),
            'sep'          => $this->filter_separator( $this->sep ),
            'separator'    => $this->filter_separator( $this->sep ),
        );

        if ( $post ) {
            $replacements['title']        = $post->post_title;
            $replacements['post_title']   = $post->post_title;
            $replacements['excerpt']      = $post->post_excerpt ?: wp_trim_words( wp_strip_all_tags( $post->post_content ), 20, '…' );
            $replacements['excerpt_only'] = $post->post_excerpt;
            $replacements['date']         = get_the_date( '', $post );
            $replacements['modified']     = get_the_modified_date( '', $post );
            $replacements['id']           = $post->ID;
            $replacements['name']         = $post->post_name;
            $replacements['author']       = get_the_author_meta( 'display_name', $post->post_author );
            $replacements['user']         = get_the_author_meta( 'display_name', $post->post_author );

            // Category
            $cats = get_the_category( $post->ID );
            $replacements['category']     = ! empty( $cats ) ? $cats[0]->name : '';
            $replacements['category_title'] = $replacements['category'];
            $replacements['primary_category'] = $replacements['category'];

            // Tags
            $tags = get_the_tags( $post->ID );
            $replacements['tag']          = ! empty( $tags ) ? $tags[0]->name : '';
            $replacements['tags']         = ! empty( $tags ) ? implode( ', ', wp_list_pluck( $tags, 'name' ) ) : '';

            // Focus keyword
            $kw = get_post_meta( $post->ID, '_hts_focus_keyword', true );
            if ( ! $kw ) $kw = get_post_meta( $post->ID, 'rank_math_focus_keyword', true );
            if ( ! $kw ) $kw = get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true );
            $replacements['focuskw']      = $kw ?: '';
            $replacements['keyword']      = $kw ?: '';

            // Page number
            $replacements['page']         = max( 1, get_query_var( 'paged', 1 ) );
            $replacements['pagenumber']   = $replacements['page'];
        }

        // Term (archives)
        if ( ! $post && ( is_category() || is_tag() || is_tax() ) ) {
            $term = get_queried_object();
            if ( $term ) {
                $replacements['term_title']       = $term->name;
                $replacements['term_description'] = $term->description;
                $replacements['category']         = $term->name;
                $replacements['tag']              = $term->name;
            }
        }

        // Replace %%var%% (Yoast format) first, then %var% (RM/HTS format)
        foreach ( $replacements as $var => $value ) {
            $template = str_replace( '%%' . $var . '%%', $value, $template );
            $template = str_replace( '%' . $var . '%', $value, $template );
        }

        // Clean up unreplaced variables
        $template = preg_replace( '/%%?[a-z_]+%%?/', '', $template );
        $template = preg_replace( '/\s{2,}/', ' ', trim( $template ) );

        return $template;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  INJECT — Meta Description + Open Graph + Twitter Cards
     * ═══════════════════════════════════════════════════════════════ */

    public static function is_wc_system_page( $post_id = 0 ) {
        if ( ! function_exists( 'wc_get_page_id' ) ) return false;
        if ( ! $post_id ) $post_id = get_queried_object_id();
        if ( ! $post_id ) return false;
        $wc_pages = array(
            wc_get_page_id( 'cart' ),
            wc_get_page_id( 'checkout' ),
            wc_get_page_id( 'myaccount' ),
            wc_get_page_id( 'terms' ),
        );
        if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url() ) return true;
        return in_array( $post_id, $wc_pages, true );
    }

    public function inject_meta_tags() {
        if ( is_admin() ) return;

        // WC system pages: noindex + canonical only
        if ( is_singular() && self::is_wc_system_page() ) {
            echo '<meta name="robots" content="noindex, follow" />' . "\n";
            echo '<link rel="canonical" href="' . esc_url( get_permalink() ) . '" />' . "\n";
            return;
        }

        $post_id = 0;
        $title   = '';
        $desc    = '';
        $url     = '';
        $type    = 'website';
        $image   = '';
        $img_w   = '';
        $img_h   = '';

        if ( is_singular() ) {
            $post_id = get_queried_object_id();
            $post    = get_post( $post_id );
            $title   = $this->get_meta_title( $post_id ) ?: get_the_title( $post_id );
            $desc    = $this->get_meta_description( $post_id );
            $url     = get_permalink( $post_id );
            $type    = 'website';
            if ( get_post_type( $post_id ) === 'post' ) {
                $type = 'article';
            } elseif ( in_array( get_post_type( $post_id ), array( 'page' ), true ) ) {
                $type = 'website';
            } else {
                // CPTs: use 'article' by default, filterable
                // WooCommerce products → og:type = product (og:type = og:product is standard)
                if ( get_post_type( $post_id ) === 'product' && function_exists( 'wc_get_product' ) ) {
                    $type = 'product';
                } else {
                    /**
                     * Filter: Open Graph type for posts/CPTs.
                     *
                     * @since 1.0.0
                     * @param string $type      OG type (default 'article').
                     * @param string $post_type Post type slug.
                     * @param int    $post_id   Post ID.
                     */
                    $type = apply_filters( 'hts_og_type', 'article', get_post_type( $post_id ), $post_id );
                }
            }

            // Image — Priority: 1) Custom OG image from SEO Panel, 2) Featured image
            $custom_og = get_post_meta( $post_id, '_hts_og_image', true );
            if ( $custom_og ) {
                $image = $custom_og;
                // Try to get dimensions from attachment
                $custom_og_id = attachment_url_to_postid( $custom_og );
                if ( $custom_og_id ) {
                    $og_meta = wp_get_attachment_metadata( $custom_og_id );
                    if ( $og_meta && isset( $og_meta['width'], $og_meta['height'] ) ) {
                        $img_w = (int) $og_meta['width'];
                        $img_h = (int) $og_meta['height'];
                    }
                }
            } elseif ( has_post_thumbnail( $post_id ) ) {
                $img_id  = get_post_thumbnail_id( $post_id );
                $image   = wp_get_attachment_image_url( $img_id, 'full' );
                $img_meta = wp_get_attachment_metadata( $img_id );
                if ( $img_meta && isset( $img_meta['width'], $img_meta['height'] ) ) {
                    $img_w = (int) $img_meta['width'];
                    $img_h = (int) $img_meta['height'];
                }
            }
        } elseif ( is_front_page() || is_home() ) {
            $title = get_option( 'hts_home_title', '' ) ?: get_bloginfo( 'name' );
            $title = $this->resolve_variables( $title );
            $desc  = get_option( 'hts_home_description', '' ) ?: get_bloginfo( 'description' );
            $desc  = $this->resolve_variables( $desc );
            $url   = home_url( '/' );
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term  = get_queried_object();
            $title = $term ? $term->name : '';
            if ( $term && $term->description ) {
                $raw = str_replace(
                    array( '</p>', '</div>', '</li>', '</h1>', '</h2>', '</h3>', '<br>', '<br/>', '<br />' ),
                    ' ', $term->description
                );
                $desc = wp_trim_words( wp_strip_all_tags( $raw ), 25, '...' );
            } else {
                $desc = '';
            }
            $url   = $term ? get_term_link( $term ) : '';

            // WC category thumbnail
            if ( $term && function_exists( 'wc_get_page_id' ) ) {
                $thumb_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
                if ( $thumb_id ) {
                    $image = wp_get_attachment_image_url( $thumb_id, 'full' );
                }
            }
        } else {
            // Other archives
            $title = wp_get_document_title();
            $url   = home_url( $_SERVER['REQUEST_URI'] ?? '/' );
        }

        // Fallback image: HTS default OG image
        if ( empty( $image ) ) {
            $og_default = get_option( 'hts_og_default_image', '' );
            if ( $og_default ) {
                $image = $og_default;
                $img_w = 1200;
                $img_h = 630;
            }
        }

        // Fallback image: site logo
        if ( empty( $image ) ) {
            $logo_id = get_theme_mod( 'custom_logo' );
            if ( $logo_id ) {
                $image = wp_get_attachment_image_url( $logo_id, 'full' );
                $lm = wp_get_attachment_metadata( $logo_id );
                if ( $lm && isset( $lm['width'], $lm['height'] ) ) {
                    $img_w = (int) $lm['width'];
                    $img_h = (int) $lm['height'];
                }
            }
        }

        // Fallback image: site icon
        if ( empty( $image ) ) {
            $site_icon_id = get_option( 'site_icon' );
            if ( $site_icon_id ) {
                $image = wp_get_attachment_image_url( $site_icon_id, 'full' );
            }
        }

        $locale   = get_locale();
        $sitename = get_bloginfo( 'name' );

        echo "\n<!-- Hack The SEO v" . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ) . " — HackTheSEO.com -->\n";

        // ── Meta Description ──
        if ( $desc ) {
            echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
        }

        // ── Open Graph ──
        echo '<meta property="og:locale" content="' . esc_attr( $locale ) . '" />' . "\n";
        echo '<meta property="og:type" content="' . esc_attr( $type ) . '" />' . "\n";
        if ( $title ) echo '<meta property="og:title" content="' . esc_attr( $title ) . '" />' . "\n";
        if ( $desc )  echo '<meta property="og:description" content="' . esc_attr( $desc ) . '" />' . "\n";
        if ( $url )   echo '<meta property="og:url" content="' . esc_url( $url ) . '" />' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr( $sitename ) . '" />' . "\n";

        if ( $image ) {
            echo '<meta property="og:image" content="' . esc_url( $image ) . '" />' . "\n";
            if ( $img_w && $img_h ) {
                echo '<meta property="og:image:width" content="' . esc_attr( $img_w ) . '" />' . "\n";
                echo '<meta property="og:image:height" content="' . esc_attr( $img_h ) . '" />' . "\n";
            }
            // Detect actual MIME type from URL extension
            $img_ext  = strtolower( pathinfo( wp_parse_url( $image, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );
            $mime_map = array( 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp', 'svg' => 'image/svg+xml', 'avif' => 'image/avif' );
            $img_mime = $mime_map[ $img_ext ] ?? 'image/jpeg';
            echo '<meta property="og:image:type" content="' . esc_attr( $img_mime ) . '" />' . "\n";
        }

        // Article specific OG
        if ( $type === 'article' && $post_id ) {
            echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c', $post_id ) ) . '" />' . "\n";
            echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'c', $post_id ) ) . '" />' . "\n";
            $author = get_userdata( get_post_field( 'post_author', $post_id ) );
            if ( $author ) {
                echo '<meta property="article:author" content="' . esc_attr( $author->display_name ) . '" />' . "\n";
            }
            $cats = get_the_category( $post_id );
            if ( ! empty( $cats ) ) {
                echo '<meta property="article:section" content="' . esc_attr( $cats[0]->name ) . '" />' . "\n";
            }
            $tags = get_the_tags( $post_id );
            if ( ! empty( $tags ) ) {
                foreach ( array_slice( $tags, 0, 5 ) as $tag ) {
                    echo '<meta property="article:tag" content="' . esc_attr( $tag->name ) . '" />' . "\n";
                }
            }
        }

        // Product specific OG (WooCommerce)
        if ( $type === 'product' && $post_id && function_exists( 'wc_get_product' ) ) {
            $wc_product = wc_get_product( $post_id );
            if ( $wc_product ) {
                $price = $wc_product->get_price();
                if ( $price !== '' && $price !== null ) {
                    $currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'EUR';
                    echo '<meta property="product:price:amount" content="' . esc_attr( $price ) . '" />' . "\n";
                    echo '<meta property="product:price:currency" content="' . esc_attr( $currency ) . '" />' . "\n";
                }
                $stock = $wc_product->get_stock_status();
                $avail = ( $stock === 'instock' ) ? 'instock' : ( ( $stock === 'onbackorder' ) ? 'pending' : 'oos' );
                echo '<meta property="product:availability" content="' . esc_attr( $avail ) . '" />' . "\n";
                // Brand
                $brands = wp_get_post_terms( $post_id, 'product_brand', array( 'fields' => 'names' ) );
                if ( is_wp_error( $brands ) || empty( $brands ) ) {
                    $brands = wp_get_post_terms( $post_id, 'pa_marque', array( 'fields' => 'names' ) );
                }
                if ( ! is_wp_error( $brands ) && ! empty( $brands ) ) {
                    echo '<meta property="product:brand" content="' . esc_attr( $brands[0] ) . '" />' . "\n";
                }
            }
        }

        // ── Twitter Cards ──
        $twitter_card = $image ? 'summary_large_image' : 'summary';
        echo '<meta name="twitter:card" content="' . esc_attr( $twitter_card ) . '" />' . "\n";
        if ( $title ) echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '" />' . "\n";
        if ( $desc )  echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '" />' . "\n";
        if ( $image ) echo '<meta name="twitter:image" content="' . esc_url( $image ) . '" />' . "\n";

        // Twitter site handle
        $twitter = $this->get_twitter_handle();
        if ( $twitter ) echo '<meta name="twitter:site" content="' . esc_attr( $twitter ) . '" />' . "\n";

        echo "<!-- /Hack The SEO -->\n";
    }

    /**
     * Get Twitter handle from various sources
     */
    private function get_twitter_handle() {
        $h = get_option( 'hts_twitter_handle', '' );
        if ( $h ) return $h;
        // Fallback: Rank Math
        $rm = get_option( 'rank-math-options-titles', array() );
        if ( ! empty( $rm['twitter_author_names'] ) ) return $rm['twitter_author_names'];
        // Fallback: Yoast
        $ys = get_option( 'wpseo_social', array() );
        if ( ! empty( $ys['twitter_site'] ) ) return '@' . ltrim( $ys['twitter_site'], '@' );
        return '';
    }

    /* ═══════════════════════════════════════════════════════════════
     *  REMOVE COMPETITOR META OUTPUT
     * ═══════════════════════════════════════════════════════════════ */

    public function remove_competitor_meta() {
        // ══════════════════════════════════════════════════════════
        //  RANK MATH — Full neutralization
        // ══════════════════════════════════════════════════════════
        if ( class_exists( 'RankMath' ) ) {
            // 1. Remove main head output (title, meta desc, canonical, robots, OG)
            $head = \RankMath\Frontend\Head::class ?? null;
            if ( $head && method_exists( $head, 'get' ) ) {
                remove_action( 'wp_head', array( \RankMath\Frontend\Head::get(), 'head' ), 1 );
            }
            // 2. Backup filters in case Head::head() removal fails
            add_filter( 'rank_math/frontend/title', '__return_empty_string', 999 );
            add_filter( 'rank_math/frontend/description', '__return_empty_string', 999 );
            add_filter( 'rank_math/opengraph/facebook', '__return_false', 999 );
            add_filter( 'rank_math/opengraph/twitter', '__return_false', 999 );
            // 3. Schema JSON-LD — RM uses separate JsonLD class in wp_footer
            add_filter( 'rank_math/json_ld', '__return_empty_array', 999 );
            if ( class_exists( 'RankMath\\Schema\\JsonLD' ) ) {
                remove_all_actions( 'rank_math/json_ld' );
            }
            // 4. Canonical — backup in case Head removal fails
            add_filter( 'rank_math/frontend/canonical', '__return_empty_string', 999 );
            // 5. Robots — backup
            add_filter( 'rank_math/frontend/robots', '__return_empty_array', 999 );
        }

        // ══════════════════════════════════════════════════════════
        //  YOAST — Full neutralization (supports Yoast 20+)
        // ══════════════════════════════════════════════════════════
        if ( defined( 'WPSEO_VERSION' ) ) {
            // 1. Legacy: WPSEO_Frontend (Yoast < 20)
            add_filter( 'wpseo_title', '__return_empty_string', 999 );
            add_filter( 'wpseo_metadesc', '__return_empty_string', 999 );
            add_filter( 'wpseo_opengraph_url', '__return_empty_string', 999 );
            if ( class_exists( 'WPSEO_Frontend' ) && method_exists( 'WPSEO_Frontend', 'get_instance' ) ) {
                $front = WPSEO_Frontend::get_instance();
                remove_action( 'wpseo_head', array( $front, 'head' ), 1 );
            }
            // 2. Yoast 20+: presenters + social metadata
            add_filter( 'wpseo_output_social_metadata', '__return_false', 999 );
            // 3. Schema JSON-LD — Yoast uses wpseo_json_ld_output filter
            add_filter( 'wpseo_json_ld_output', '__return_empty_array', 999 );
            add_filter( 'wpseo_schema_graph', '__return_empty_array', 999 );
            // 4. Canonical
            add_filter( 'wpseo_canonical', '__return_empty_string', 999 );
            // 5. Robots
            add_filter( 'wpseo_robots', '__return_empty_string', 999 );
            add_filter( 'wpseo_robots_array', '__return_empty_array', 999 );
            // 6. Nuclear: disable entire wpseo_head output
            add_filter( 'wpseo_head', '__return_empty_string', 999 );
        }

        // ══════════════════════════════════════════════════════════
        //  AIOSEO
        // ══════════════════════════════════════════════════════════
        if ( function_exists( 'aioseo' ) ) {
            add_filter( 'aioseo_disable', '__return_true' );
            add_filter( 'aioseo_schema_output', '__return_empty_array', 999 );
        }

        // ══════════════════════════════════════════════════════════
        //  SEOPRESS
        // ══════════════════════════════════════════════════════════
        if ( defined( 'SEOPRESS_VERSION' ) ) {
            remove_action( 'wp_head', 'seopress_social_og_metatags' );
            remove_action( 'wp_head', 'seopress_social_twitter_metatags' );
            add_filter( 'seopress_schemas_auto_output', '__return_false', 999 );
            add_filter( 'seopress_jsonld_output', '__return_empty_array', 999 );
        }

        // ══════════════════════════════════════════════════════════
        //  THEMES & COMMON PLUGINS
        // ══════════════════════════════════════════════════════════

        // Jetpack (Open Graph module)
        if ( class_exists( 'Jetpack' ) ) {
            add_filter( 'jetpack_enable_open_graph', '__return_false', 999 );
            remove_action( 'wp_head', 'jetpack_og_tags' );
        }

        // WooCommerce
        remove_action( 'wp_head', 'wc_page_meta_tags' );

        // Genesis framework
        remove_action( 'wp_head', 'genesis_open_graph_meta' );
        remove_action( 'genesis_meta', 'genesis_open_graph_meta' );

        // Theme OG via wp_head
        remove_action( 'wp_head', 'flavor_open_graph', 99 );
        remove_action( 'wp_head', 'developer_og_tags' );

        // The7 theme — injects OG tags via presscore_meta_open_graph()
        remove_action( 'wp_head', 'presscore_meta_open_graph' );
        remove_action( 'wp_head', 'dt_meta_open_graph' );
        // The7 also uses these filters
        add_filter( 'presscore_og_tags', '__return_empty_array', 999 );

        // Elementor — can inject OG in some configurations
        if ( defined( 'ELEMENTOR_VERSION' ) ) {
            add_filter( 'elementor/frontend/open_graph', '__return_false', 999 );
        }

        // ══════════════════════════════════════════════════════════
        //  NUCLEAR: Output buffer cleanup for any remaining OG/meta
        //  ONLY activate when a competitor SEO plugin is present
        //  (buffer wraps entire wp_head — costly on sites with Elementor)
        // ══════════════════════════════════════════════════════════
        $has_competitor = class_exists( 'RankMath' )
            || defined( 'WPSEO_VERSION' )
            || function_exists( 'aioseo' )
            || defined( 'SEOPRESS_VERSION' )
            || class_exists( 'Jetpack' );

        if ( $has_competitor ) {
            add_action( 'wp_head', array( $this, 'start_og_cleanup_buffer' ), 0 );
            add_action( 'wp_head', array( $this, 'end_og_cleanup_buffer' ), 9999 );
        }
    }

    /**
     * Start output buffering to strip duplicate OG tags from themes/plugins.
     * Only buffers wp_head output.
     */
    public function start_og_cleanup_buffer() {
        ob_start();
    }

    /**
     * End output buffer and strip any OG/Twitter meta tags not inside our marker block.
     * Only processes wp_head output.
     */
    public function end_og_cleanup_buffer() {
        $html = ob_get_clean();
        if ( empty( $html ) ) {
            return;
        }

        // Find our block markers
        $start_marker = '<!-- Hack The SEO v';
        $end_marker   = '<!-- /Hack The SEO -->';
        $start_pos    = strpos( $html, $start_marker );
        $end_pos      = strpos( $html, $end_marker );

        if ( $start_pos === false || $end_pos === false ) {
            // Our block not found — don't touch anything
            echo $html;
            return;
        }

        $end_pos += strlen( $end_marker );

        // Split HTML into: before our block | our block | after our block
        $before = substr( $html, 0, $start_pos );
        $ours   = substr( $html, $start_pos, $end_pos - $start_pos );
        $after  = substr( $html, $end_pos );

        // Pattern to match OG and Twitter meta tags
        $og_pattern = '/<meta[^>]+(?:property=["\']og:|name=["\']twitter:)[^>]*>\s*\n?/i';

        // Strip from before and after our block only
        $before_clean = preg_replace( $og_pattern, '', $before );
        $after_clean  = preg_replace( $og_pattern, '', $after );

        // Also strip duplicate meta descriptions (not inside our block)
        $desc_pattern = '/<meta[^>]+name=["\']description["\'][^>]*>\s*\n?/i';
        $before_clean = preg_replace( $desc_pattern, '', $before_clean );
        $after_clean  = preg_replace( $desc_pattern, '', $after_clean );

        // Also strip competitor SEO JSON-LD from wp_head (Yoast, Rank Math, AIOSEO, SEOPress)
        // IMPORTANT: Only strip schemas from known SEO plugins. Preserve schemas from
        // MEC, WooCommerce, The Events Calendar, and any other non-SEO plugins.
        $jsonld_pattern = '/(?:<!--[^>]*-->\\s*)?<script[^>]*type=["\']application\/ld\+json["\'][^>]*>.*?<\/script>\\s*/si';

        // Signatures of known SEO competitor JSON-LD (safe to strip)
        $competitor_signatures = array(
            'yoast-schema-graph',   // Yoast
            'rank-math',            // Rank Math
            'rank_math',            // Rank Math variant
            'aioseo',               // AIOSEO
            'seopress',             // SEOPress
            'schema-graph-piece',   // Yoast internals
        );

        $strip_competitor_jsonld = function( $m ) use ( $competitor_signatures ) {
            $block = $m[0];
            // Always keep HTS blocks
            if ( strpos( $block, 'HackTheSEO' ) !== false || strpos( $block, 'Hack The SEO' ) !== false || strpos( $block, 'HTS Light' ) !== false ) return $block;
            // Only strip if it matches a known SEO competitor
            foreach ( $competitor_signatures as $sig ) {
                if ( stripos( $block, $sig ) !== false ) return '';
            }
            // Preserve everything else (MEC, WooCommerce, theme, other plugins)
            return $block;
        };

        $before_clean = preg_replace_callback( $jsonld_pattern, $strip_competitor_jsonld, $before_clean );
        $after_clean  = preg_replace_callback( $jsonld_pattern, $strip_competitor_jsonld, $after_clean );

        echo $before_clean . $ours . $after_clean;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  ALT TEXT AUTO-FILL
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * On post save: find images in content missing alt text,
     * auto-generate from filename, post title, or focus keyword.
     */
    public function auto_fill_image_alts( $post_id, $post ) {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;
        if ( $post->post_status !== 'publish' ) return;

        $content = $post->post_content;
        $updated = false;

        // Find images in content
        if ( ! preg_match_all( '/<img[^>]+>/si', $content, $imgs ) ) return;

        $focus_kw = get_post_meta( $post_id, '_hts_focus_keyword', true );
        if ( ! $focus_kw ) $focus_kw = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        if ( ! $focus_kw ) $focus_kw = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );

        foreach ( $imgs[0] as $img_tag ) {
            // Skip if already has non-empty alt
            if ( preg_match( '/alt=["\']([^"\']+)["\']/i', $img_tag, $alt_match ) ) {
                if ( ! empty( trim( $alt_match[1] ) ) ) continue;
            }

            // Extract src to find attachment
            if ( ! preg_match( '/src=["\']([^"\']+)["\']/i', $img_tag, $src_match ) ) continue;
            $src = $src_match[1];

            // Generate alt text
            $alt = $this->generate_alt_text( $src, $post->post_title, $focus_kw );
            if ( empty( $alt ) ) continue;

            // Update in content
            $new_tag = $img_tag;
            if ( strpos( $img_tag, 'alt=' ) !== false ) {
                // Replace empty alt
                $new_tag = preg_replace( '/alt=["\'][^"\']*["\']/i', 'alt="' . esc_attr( $alt ) . '"', $img_tag );
            } else {
                // Add alt attribute
                $new_tag = str_replace( '<img', '<img alt="' . esc_attr( $alt ) . '"', $img_tag );
            }

            if ( $new_tag !== $img_tag ) {
                $content = str_replace( $img_tag, $new_tag, $content );
                $updated = true;
            }

            // Also update the attachment meta
            $attach_id = $this->get_attachment_id_from_url( $src );
            if ( $attach_id ) {
                $existing_alt = get_post_meta( $attach_id, '_wp_attachment_image_alt', true );
                if ( empty( $existing_alt ) ) {
                    update_post_meta( $attach_id, '_wp_attachment_image_alt', $alt );
                }
            }
        }

        // Also update featured image alt
        if ( has_post_thumbnail( $post_id ) ) {
            $thumb_id  = get_post_thumbnail_id( $post_id );
            $thumb_alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
            if ( empty( $thumb_alt ) ) {
                $alt = $this->generate_alt_text( '', $post->post_title, $focus_kw, true );
                if ( $alt ) update_post_meta( $thumb_id, '_wp_attachment_image_alt', $alt );
            }
        }

        // Save updated content
        if ( $updated ) {
            remove_action( 'save_post', array( $this, 'auto_fill_image_alts' ), 20 );
            $upd = wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );
            add_action( 'save_post', array( $this, 'auto_fill_image_alts' ), 20, 2 );
            if ( is_wp_error( $upd ) || 0 === $upd ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Meta Tags: échec sauvegarde alts post #' . $post_id, 'warning', 'meta-tags' );
                }
            }
        }
    }

    /**
     * Generate meaningful alt text
     */
    private function generate_alt_text( $src, $post_title, $focus_kw, $is_featured = false ) {
        // Priority 1: focus keyword + context
        if ( $focus_kw ) {
            if ( $is_featured ) {
                return $focus_kw . ' — ' . $post_title;
            }
            return $focus_kw;
        }

        // Priority 2: filename cleanup
        if ( $src ) {
            $filename = pathinfo( wp_parse_url( $src, PHP_URL_PATH ), PATHINFO_FILENAME );
            // Clean: remove dimensions, hashes, common prefixes
            $filename = preg_replace( '/-\d+x\d+$/', '', $filename );
            $filename = preg_replace( '/-[a-f0-9]{8,}$/', '', $filename );
            $filename = str_replace( array( '-', '_' ), ' ', $filename );
            $filename = ucfirst( trim( $filename ) );
            if ( mb_strlen( $filename ) > 5 ) return $filename;
        }

        // Priority 3: post title
        if ( $post_title ) return $post_title;

        return '';
    }

    /**
     * Get attachment ID from URL
     */
    private function get_attachment_id_from_url( $url ) {
        global $wpdb;
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( ! $path ) return 0;
        // Remove size suffix
        $path = preg_replace( '/-\d+x\d+\./', '.', $path );
        $id = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE guid LIKE %s AND post_type = 'attachment' LIMIT 1",
            '%' . $wpdb->esc_like( $path )
        ) );
        return (int) $id;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  META BOX — Post editor
     * ═══════════════════════════════════════════════════════════════ */

    public function add_meta_box() {
        add_meta_box(
            'hts-meta-tags',
 'HTS — Meta SEO',
            array( $this, 'render_meta_box' ),
            array( 'post', 'page' ),
            'normal',
            'high'
        );
    }

    public function render_meta_box( $post ) {
        wp_nonce_field( 'hts_meta_tags_save', '_hts_meta_tags_nonce' );

        $title = get_post_meta( $post->ID, '_hts_meta_title', true );
        $desc  = get_post_meta( $post->ID, '_hts_meta_description', true );

        // Show current source
        $title_source = 'auto';
        $desc_source  = 'auto';
        if ( ! empty( $title ) ) $title_source = 'hts';
        elseif ( $this->get_competitor_meta( $post->ID, 'title' ) ) $title_source = 'concurrent';
        if ( ! empty( $desc ) ) $desc_source = 'hts';
        elseif ( $this->get_competitor_meta( $post->ID, 'desc' ) ) $desc_source = 'concurrent';

        $preview_title = $this->get_meta_title( $post->ID ) ?: $post->post_title . ' ' . $this->sep . ' ' . get_bloginfo( 'name' );
        $preview_desc  = $this->get_meta_description( $post->ID );
        ?>
        <style>
            .hts-meta-field { margin-bottom:16px; }
            .hts-meta-field label { display:block; font-weight:600; margin-bottom:4px; font-size:13px; }
            .hts-meta-field input, .hts-meta-field textarea { width:100%; padding:8px 12px; border:1px solid #ddd; border-radius:6px; font-size:14px; }
            .hts-meta-field textarea { height:60px; resize:vertical; }
            .hts-meta-counter { font-size:11px; color:#888; margin-top:4px; }
            .hts-meta-counter.warn { color:#e67e22; }
            .hts-meta-counter.danger { color:#e74c3c; }
            .hts-meta-source { display:inline-block; font-size:11px; padding:2px 8px; border-radius:10px; margin-left:8px; }
            .hts-meta-source.hts { background:#d4f5d0; color:#2d7d2a; }
            .hts-meta-source.concurrent { background:#ffeaa7; color:#856404; }
            .hts-meta-source.auto { background:#e8e8e8; color:#666; }
            .hts-meta-preview { background:#fff; border:1px solid #e0e0e0; border-radius:8px; padding:16px; margin-top:16px; }
            .hts-meta-preview .serp-title { color:#1a0dab; font-size:18px; text-decoration:underline; cursor:pointer; }
            .hts-meta-preview .serp-url { color:#006621; font-size:14px; margin:2px 0; }
            .hts-meta-preview .serp-desc { color:#545454; font-size:13px; }
        </style>
        <div class="hts-meta-field">
            <label>
                Meta Title
                <span class="hts-meta-source <?php echo esc_attr( $title_source ); ?>">
                    <?php echo $title_source === 'hts' ? 'Personnalisé' : ( $title_source === 'concurrent' ? 'Importé' : 'Auto' ); ?>
                </span>
            </label>
            <input type="text" name="hts_meta_title" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php echo esc_attr( $preview_title ); ?>" oninput="htsMetaCount(this, 60, '.hts-title-count')">
            <div class="hts-meta-counter hts-title-count"><?php echo mb_strlen( $preview_title ); ?>/60 caractères</div>
            <small style="color:#999;">Variables : %title%, %sep%, %sitename%, %category%, %focuskw%</small>
        </div>
        <div class="hts-meta-field">
            <label>
                Meta Description
                <span class="hts-meta-source <?php echo esc_attr( $desc_source ); ?>">
                    <?php echo $desc_source === 'hts' ? 'Personnalisé' : ( $desc_source === 'concurrent' ? 'Importé' : 'Auto' ); ?>
                </span>
            </label>
            <textarea name="hts_meta_description" placeholder="<?php echo esc_attr( $preview_desc ); ?>" oninput="htsMetaCount(this, 155, '.hts-desc-count')"><?php echo esc_textarea( $desc ); ?></textarea>
            <div class="hts-meta-counter hts-desc-count"><?php echo mb_strlen( $preview_desc ); ?>/155 caractères</div>
        </div>
        <div class="hts-meta-preview">
            <div style="font-size:11px;color:#999;margin-bottom:8px;">Aperçu Google SERP :</div>
            <div class="serp-title"><?php echo esc_html( $preview_title ); ?></div>
            <div class="serp-url"><?php echo esc_url( get_permalink( $post->ID ) ); ?></div>
            <div class="serp-desc"><?php echo esc_html( $preview_desc ); ?></div>
        </div>
        <script>
        function htsMetaCount(el, max, target) {
            var len = el.value.length || el.placeholder.length;
            var counter = document.querySelector(target);
            if (!counter) return;
            counter.textContent = len + '/' + max + ' caractères';
            counter.className = 'hts-meta-counter' + (len > max ? ' danger' : (len > max * 0.9 ? ' warn' : ''));
        }
        </script>
        <?php
    }

    private function get_competitor_meta( $post_id, $type ) {
        $keys = $type === 'title'
            ? array( 'rank_math_title', '_yoast_wpseo_title', '_seopress_titles_title' )
            : array( 'rank_math_description', '_yoast_wpseo_metadesc', '_seopress_titles_desc' );
        foreach ( $keys as $k ) {
            $v = get_post_meta( $post_id, $k, true );
            if ( ! empty( $v ) ) return $v;
        }
        return '';
    }

    public function save_meta_box( $post_id, $post ) {
        if ( ! isset( $_POST['_hts_meta_tags_nonce'] ) || ! wp_verify_nonce( $_POST['_hts_meta_tags_nonce'], 'hts_meta_tags_save' ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;

        $title = sanitize_text_field( $_POST['hts_meta_title'] ?? '' );
        $desc  = sanitize_textarea_field( $_POST['hts_meta_description'] ?? '' );

        // P2 #26: Truncate meta title/desc to SEO-safe lengths
        if ( $title && mb_strlen( $title ) > 65 ) {
            $title = mb_substr( $title, 0, 62 ) . '...';
        }
        if ( $desc && mb_strlen( $desc ) > 160 ) {
            $desc = mb_substr( $desc, 0, 157 ) . '...';
        }

        if ( $title ) update_post_meta( $post_id, '_hts_meta_title', $title );
        else delete_post_meta( $post_id, '_hts_meta_title' );

        if ( $desc ) update_post_meta( $post_id, '_hts_meta_description', $desc );
        else delete_post_meta( $post_id, '_hts_meta_description' );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  AJAX — Preview
     * ═══════════════════════════════════════════════════════════════ */

    public function ajax_preview() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error();

        wp_send_json_success( array(
            'title'       => $this->get_meta_title( $post_id ) ?: get_the_title( $post_id ) . ' ' . $this->sep . ' ' . get_bloginfo( 'name' ),
            'description' => $this->get_meta_description( $post_id ),
            'url'         => get_permalink( $post_id ),
        ) );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  PUBLIC API
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Scan all published posts for missing meta descriptions
     */
    public function get_missing_meta_stats() {
        global $wpdb;
        $total = (int) wp_count_posts()->publish;
        $with_desc = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta}
             WHERE meta_key IN ('_hts_meta_description','rank_math_description','_yoast_wpseo_metadesc','_seopress_titles_desc')
             AND meta_value != ''"
        );
        $with_title = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta}
             WHERE meta_key IN ('_hts_meta_title','rank_math_title','_yoast_wpseo_title','_seopress_titles_title')
             AND meta_value != ''"
        );
        return array(
            'total'          => $total,
            'with_title'     => $with_title,
            'missing_title'  => $total - $with_title,
            'with_desc'      => $with_desc,
            'missing_desc'   => $total - $with_desc,
        );
    }

    /* =========================================================================
     * REL PREV / NEXT — Pagination hints for search engines
     * WordPress removed these in 5.3+. Google says they're a "hint",
     * still useful for crawl budget and page discovery.
     * ====================================================================== */

    /**
     * Inject <link rel="prev"> and <link rel="next"> for paginated content.
     * Covers: archive pages, paginated single posts (<!--nextpage-->).
     */
    public function inject_rel_prev_next() {
        if ( is_admin() ) return;
        if ( get_option( 'hts_rel_prev_next', '1' ) !== '1' ) return;

        if ( is_singular() ) {
            // Paginated single posts (<!--nextpage-->)
            global $page, $numpages, $post;
            if ( ! $post || $numpages <= 1 ) return;

            $base = get_permalink( $post->ID );

            if ( $page > 1 ) {
                $prev_page = $page - 1;
                $prev_url = ( $prev_page === 1 )
                    ? $base
                    : trailingslashit( $base ) . user_trailingslashit( $prev_page, 'single_paged' );
                echo '<link rel="prev" href="' . esc_url( $prev_url ) . '" />' . "\n";
            }

            if ( $page < $numpages ) {
                $next_url = trailingslashit( $base ) . user_trailingslashit( $page + 1, 'single_paged' );
                echo '<link rel="next" href="' . esc_url( $next_url ) . '" />' . "\n";
            }
        } elseif ( is_archive() || is_home() || is_search() ) {
            // Archive / blog / search pagination
            global $wp_query;
            $paged     = max( 1, get_query_var( 'paged', 1 ) );
            $max_pages = (int) $wp_query->max_num_pages;

            if ( $max_pages <= 1 ) return;

            if ( $paged > 1 ) {
                echo '<link rel="prev" href="' . esc_url( get_pagenum_link( $paged - 1 ) ) . '" />' . "\n";
            }

            if ( $paged < $max_pages ) {
                echo '<link rel="next" href="' . esc_url( get_pagenum_link( $paged + 1 ) ) . '" />' . "\n";
            }
        }
    }

    /* =========================================================================
     * HREFLANG — Multilingual alternate links
     * Auto-detects WPML, Polylang, TranslatePress.
     * Also supports manual hreflang via a filter.
     * ====================================================================== */

    /**
     * Inject hreflang link tags for multilingual sites.
     */
    public function inject_hreflang() {
        if ( is_admin() ) return;
        if ( get_option( 'hts_hreflang', '1' ) !== '1' ) return;

        // S18 FIX: Polylang & WPML inject their own hreflang natively — skip to avoid duplicates
        if ( function_exists( 'pll_the_languages' ) || defined( 'ICL_SITEPRESS_VERSION' ) ) {
            return;
        }

        $hreflangs = array();

        // ── WPML ──
        if ( defined( 'ICL_SITEPRESS_VERSION' ) && function_exists( 'icl_get_languages' ) ) {
            $langs = icl_get_languages( 'skip_missing=0&orderby=code' );
            if ( is_array( $langs ) ) {
                foreach ( $langs as $lang ) {
                    if ( ! empty( $lang['url'] ) && ! empty( $lang['language_code'] ) ) {
                        $hreflangs[ $lang['language_code'] ] = $lang['url'];
                    }
                }
            }
        }

        // ── Polylang ──
        elseif ( function_exists( 'pll_the_languages' ) ) {
            $pll_langs = pll_the_languages( array( 'raw' => 1 ) );
            if ( is_array( $pll_langs ) ) {
                foreach ( $pll_langs as $lang ) {
                    if ( ! empty( $lang['url'] ) && ! empty( $lang['slug'] ) ) {
                        $hreflangs[ $lang['slug'] ] = $lang['url'];
                    }
                }
            }
        }

        // ── TranslatePress ──
        elseif ( class_exists( 'TRP_Translate_Press' ) ) {
            $trp      = \TRP_Translate_Press::get_trp_instance();
            $settings = $trp->get_component( 'settings' );
            if ( $settings ) {
                $trp_settings = $settings->get_settings();
                $url_conv     = $trp->get_component( 'url_converter' );
                if ( $url_conv && ! empty( $trp_settings['publish-languages'] ) ) {
                    $current_url = home_url( add_query_arg( null, null ) );
                    foreach ( $trp_settings['publish-languages'] as $lang_code ) {
                        $translated_url = $url_conv->get_url_for_language( $lang_code, $current_url, '' );
                        if ( $translated_url ) {
                            $hreflangs[ $lang_code ] = $translated_url;
                        }
                    }
                }
            }
        }

        /**
         * Filter: hreflang link pairs (lang_code => URL).
         *
         * @since 1.4.0
         * @param array $hreflangs Associative array of lang_code => URL.
         */
        $hreflangs = apply_filters( 'hts_hreflang_links', $hreflangs );

        if ( empty( $hreflangs ) || count( $hreflangs ) < 2 ) return;

        foreach ( $hreflangs as $lang => $url ) {
            echo '<link rel="alternate" hreflang="' . esc_attr( $lang ) . '" href="' . esc_url( $url ) . '" />' . "\n";
        }

        // x-default = site default language (same logic as sitemap)
        $default_url = null;
        if ( class_exists( 'HTS_Language' ) ) {
            $default_lang = HTS_Language::get_site_default_lang();
            if ( $default_lang && isset( $hreflangs[ $default_lang ] ) ) {
                $default_url = $hreflangs[ $default_lang ];
            }
        }
        if ( ! $default_url ) {
            $default_url = reset( $hreflangs ); // fallback to first
        }
        echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $default_url ) . '" />' . "\n";
    }

    /* ═══════════════════════════════════════════════
     *  COACH INTEGRATION STUBS — Sprint 5.1
     * ═══════════════════════════════════════════════ */

    /**
     * Optimize meta title and/or description for a post.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_id: int, meta_title?: string, meta_desc?: string }
     * @return bool
     */
    public static function optimize_from_coach( $params ) {
        $post_id     = isset( $params['post_id'] ) ? (int) $params['post_id'] : 0;
        $action_type = $params['_action_type'] ?? 'optimize_meta_both';
        if ( $post_id <= 0 || ! get_post( $post_id ) ) return false;

        // Sprint 5.2: Déterminer quel(s) champ(s) optimiser selon le type d'action
        $do_title = in_array( $action_type, array( 'optimize_meta_both', 'optimize_meta_title' ), true );
        $do_desc  = in_array( $action_type, array( 'optimize_meta_both', 'optimize_meta_desc' ), true );

        // If explicit values provided, use them directly
        if ( $do_title && ! empty( $params['meta_title'] ) ) {
            $mt = sanitize_text_field( $params['meta_title'] );
            // P2 #26: Truncate meta title to SEO-safe length
            if ( mb_strlen( $mt ) > 65 ) {
                $mt = mb_substr( $mt, 0, 62 ) . '...';
            }
            update_post_meta( $post_id, '_hts_meta_title', $mt );
        }
        if ( $do_desc && ! empty( $params['meta_desc'] ) ) {
            $md = sanitize_textarea_field( $params['meta_desc'] );
            // P2 #26: Truncate meta description to SEO-safe length
            if ( mb_strlen( $md ) > 160 ) {
                $md = mb_substr( $md, 0, 157 ) . '...';
            }
            update_post_meta( $post_id, '_hts_meta_description', $md );
        }

        // If no explicit values, delegate to Meta Score for AI generation
        if ( ( $do_title && empty( $params['meta_title'] ) ) || ( $do_desc && empty( $params['meta_desc'] ) ) ) {
            if ( class_exists( 'HTS_Meta_Score' ) && method_exists( 'HTS_Meta_Score', 'generate_variants' ) ) {
                $meta_score = new \HTS_Meta_Score();
                $result = $meta_score->generate_variants( $post_id );
                if ( ! empty( $result['variants'][0] ) ) {
                    $best = $result['variants'][0];
                    if ( $do_title && ! empty( $best['title'] ) ) {
                        $ai_title = sanitize_text_field( $best['title'] );
                        // P2 #26: Truncate AI-generated title to SEO-safe length
                        if ( mb_strlen( $ai_title ) > 65 ) {
                            $ai_title = mb_substr( $ai_title, 0, 62 ) . '...';
                        }
                        update_post_meta( $post_id, '_hts_meta_title', $ai_title );
                    }
                    if ( $do_desc && ! empty( $best['description'] ) ) {
                        $ai_desc = sanitize_textarea_field( $best['description'] );
                        // P2 #26: Truncate AI-generated description to SEO-safe length
                        if ( mb_strlen( $ai_desc ) > 160 ) {
                            $ai_desc = mb_substr( $ai_desc, 0, 157 ) . '...';
                        }
                        update_post_meta( $post_id, '_hts_meta_description', $ai_desc );
                    }
                    return true;
                }
            }
            return false;
        }

        return true;
    }

    /**
     * Bulk optimize metas for multiple posts.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_ids: int[], scope?: string }
     * @return bool
     */
    public static function bulk_optimize_from_coach( $params ) {
        $post_ids = isset( $params['post_ids'] ) ? array_map( 'intval', (array) $params['post_ids'] ) : array();
        if ( empty( $post_ids ) ) return false;

        $count = 0;
        foreach ( $post_ids as $pid ) {
            if ( $pid > 0 && get_post( $pid ) ) {
                $ok = self::optimize_from_coach( array( 'post_id' => $pid ) );
                if ( $ok ) $count++;
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach: bulk_optimize_from_coach traité {$count}/" . count( $post_ids ) . " pages", 'info', 'coach' );
        }

        return $count > 0;
    }
}
