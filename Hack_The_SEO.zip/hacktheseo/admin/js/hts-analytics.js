/**
 * HTS Analytics — Period switcher, Export CSV, Chart rendering.
 * S8 update: full AJAX refresh for S1-S8 sections on period change.
 * Adapted for DS v5.7 JSX-style layout (S5 v4).
 *
 * Depends on htsAnalytics.ajaxUrl / htsAnalytics.nonce (wp_localize_script).
 *
 * @since 2.6.0
 */
(function($) {
    'use strict';

    var currentDays = 30;
    var loading = false;
    var cachedData = {};

    /* ── AI brand constants — full SVG paths (mirrors PHP $ai_brands from JSX A08) ── */
    var SRC_COLORS = {
        chatgpt: '#10A37F', claude: '#D97757', perplexity: '#20B8CD',
        meta_ai: '#0866FF', meta: '#0866FF', gemini: '#4285F4', copilot: '#7C3AED',
        you: '#F97316', phind: '#16A34A'
    };
    var SRC_BG = {
        chatgpt: '#ECFDF5', claude: '#FEF3EE', perplexity: '#ECFEFF',
        meta_ai: '#EBF5FF', meta: '#EBF5FF', gemini: '#EBF5FF', copilot: '#F3E8FF',
        you: '#FFF7ED', phind: '#ECFDF5'
    };
    var SRC_VB = {
        chatgpt: 16, claude: 16, perplexity: 16, meta_ai: 16, meta: 16
    };
    var SRC_PATH = {
        chatgpt: 'M14.949 6.547a3.94 3.94 0 0 0-.348-3.273 4.11 4.11 0 0 0-4.4-1.934A4.1 4.1 0 0 0 8.423.2 4.15 4.15 0 0 0 6.305.086a4.1 4.1 0 0 0-1.891.948 4.04 4.04 0 0 0-1.158 1.753 4.1 4.1 0 0 0-1.563.679A4 4 0 0 0 .554 4.72a3.99 3.99 0 0 0 .502 4.731 3.94 3.94 0 0 0 .346 3.274 4.11 4.11 0 0 0 4.402 1.933c.382.425.852.764 1.377.995.526.231 1.095.35 1.67.346 1.78.002 3.358-1.132 3.901-2.804a4.1 4.1 0 0 0 1.563-.68 4 4 0 0 0 1.14-1.253 3.99 3.99 0 0 0-.506-4.716',
        claude: 'm3.127 10.604 3.135-1.76.053-.153-.053-.085H6.11l-.525-.032-1.791-.048-1.554-.065-1.505-.08-.38-.081L0 7.832l.036-.234.32-.214.455.04 1.009.069 1.513.105 1.097.064 1.626.17h.259l.036-.105-.089-.065-.068-.064-1.566-1.062-1.695-1.121-.887-.646-.48-.327-.243-.306-.104-.67.435-.48.585.04.15.04.593.456 1.267.981 1.654 1.218.242.202.097-.068.012-.049-.109-.181-.9-1.626-.96-1.655-.428-.686-.113-.411a2 2 0 0 1-.068-.484l.496-.674L4.446 0l.662.089.279.242.411.94.666 1.48 1.033 2.014.302.597.162.553.06.17h.105v-.097l.085-1.134.157-1.392.154-1.792.052-.504.25-.605.497-.327.387.186.319.456-.045.294-.19 1.23-.37 1.93-.243 1.29h.142l.161-.16.654-.868 1.097-1.372.484-.545.565-.601.363-.287h.686l.505.751-.226.775-.707.895-.585.759-.839 1.13-.524.904.048.072.125-.012 1.897-.403 1.024-.186 1.223-.21.553.258.06.263-.218.536-1.307.323-1.533.307-2.284.54-.028.02.032.04 1.029.098.44.024h1.077l2.005.15.525.346.315.424-.053.323-.807.411-3.631-.863-.872-.218h-.12v.073l.726.71 1.331 1.202 1.667 1.55.084.383-.214.302-.226-.032-1.464-1.101-.565-.497-1.28-1.077h-.084v.113l.295.432 1.557 2.34.08.718-.112.234-.404.141-.444-.08-.911-1.28-.94-1.44-.759-1.291-.093.053-.448 4.821-.21.246-.484.186-.403-.307-.214-.496.214-.98.258-1.28.21-1.016.19-1.263.112-.42-.008-.028-.092.012-.953 1.307-1.448 1.957-1.146 1.227-.274.109-.477-.247.045-.44.266-.39 1.586-2.018.956-1.25.617-.723-.004-.105h-.036l-4.212 2.736-.75.096-.324-.302.04-.496.154-.162 1.267-.871z',
        perplexity: 'M8 .188a.5.5 0 0 1 .503.5V4.03l3.022-2.92.059-.048a.51.51 0 0 1 .49-.054.5.5 0 0 1 .306.46v3.247h1.117l.1.01a.5.5 0 0 1 .403.49v5.558a.5.5 0 0 1-.503.5H12.38v3.258a.5.5 0 0 1-.312.462.51.51 0 0 1-.55-.11l-3.016-3.018v3.448c0 .275-.225.5-.503.5a.5.5 0 0 1-.503-.5v-3.448l-3.018 3.019a.51.51 0 0 1-.548.11.5.5 0 0 1-.312-.463v-3.258H2.503a.5.5 0 0 1-.503-.5V5.215l.01-.1c.047-.229.25-.4.493-.4H3.62V1.469l.006-.074a.5.5 0 0 1 .302-.387.51.51 0 0 1 .547.102l3.023 2.92V.687c0-.276.225-.5.503-.5',
        meta_ai: 'M8.217 5.243C9.145 3.988 10.171 3 11.483 3 13.96 3 16 6.153 16.001 9.907c0 2.29-.986 3.725-2.757 3.725-1.543 0-2.395-.866-3.924-3.424l-.667-1.123-.118-.197a55 55 0 0 0-.53-.877l-1.178 2.08c-1.673 2.925-2.615 3.541-3.923 3.541C1.086 13.632 0 12.217 0 9.973 0 6.388 1.995 3 4.598 3q.477-.001.924.122c.31.086.611.22.913.407.577.359 1.154.915 1.782 1.714',
        meta: 'M8.217 5.243C9.145 3.988 10.171 3 11.483 3 13.96 3 16 6.153 16.001 9.907c0 2.29-.986 3.725-2.757 3.725-1.543 0-2.395-.866-3.924-3.424l-.667-1.123-.118-.197a55 55 0 0 0-.53-.877l-1.178 2.08c-1.673 2.925-2.615 3.541-3.923 3.541C1.086 13.632 0 12.217 0 9.973 0 6.388 1.995 3 4.598 3q.477-.001.924.122c.31.086.611.22.913.407.577.359 1.154.915 1.782 1.714',
    };

    /* Google G inline SVG */
    function googleG(s) {
        s = s || 16;
        return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" style="flex-shrink:0"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>';
    }

    /* AI logo — real SVG path if available, colored dot fallback */
    function aiLogo(slug, size) {
        size = size || 18;
        var bg = SRC_BG[slug] || '#f3f4f6';
        var color = SRC_COLORS[slug] || '#6366F1';
        var path = SRC_PATH[slug];
        var vb = SRC_VB[slug] || 16;
        var inner = Math.round(size * 0.6);
        var r = size > 24 ? '8px' : '50%';
        if (path) {
            return '<div style="width:' + size + 'px;height:' + size + 'px;border-radius:' + r + ';background:' + bg + ';display:inline-flex;align-items:center;justify-content:center;flex-shrink:0">' +
                '<svg width="' + inner + '" height="' + inner + '" viewBox="0 0 ' + vb + ' ' + vb + '"><path d="' + path + '" fill="' + color + '"/></svg></div>';
        }
        /* Fallback: colored dot */
        return '<div style="width:' + size + 'px;height:' + size + 'px;border-radius:' + r + ';background:' + bg + ';display:inline-flex;align-items:center;justify-content:center;flex-shrink:0">' +
            '<div style="width:' + Math.round(size * 0.5) + 'px;height:' + Math.round(size * 0.5) + 'px;border-radius:50%;background:' + color + '"></div></div>';
    }

    /* ── Chart data normalization — pad to correct bar count per period ── */
    function normalizeChartData(daily, days) {
        var PERIOD_BARS = { 7: 7, 30: 30, 90: 30, 365: 12 };
        var barCount = PERIOD_BARS[days] || 30;
        var now = new Date();
        var bars = [];
        var i, d, key;

        if (days === 365) {
            /* 12m → 12 monthly bars */
            var mLabels = ['J','F','M','A','M','J','J','A','S','O','N','D'];
            var monthMap = {};
            for (i = 11; i >= 0; i--) {
                d = new Date(now.getFullYear(), now.getMonth() - i, 1);
                key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
                bars.push({ key: key, label: mLabels[d.getMonth()], total: 0, ai: 0, gsc_clicks: 0 });
                monthMap[key] = bars.length - 1;
            }
            (daily || []).forEach(function(dd) {
                var mk = dd.day.substring(0, 7);
                if (monthMap[mk] !== undefined) {
                    bars[monthMap[mk]].total += dd.total;
                    bars[monthMap[mk]].ai += dd.ai;
                    bars[monthMap[mk]].gsc_clicks += dd.gsc_clicks || 0;
                }
            });
            return bars;
        }

        if (days === 90) {
            /* 90j → 30 bars (3-day buckets) */
            for (i = 0; i < 30; i++) {
                bars.push({ label: String(i * 3 + 1), total: 0, ai: 0, gsc_clicks: 0 });
            }
            (daily || []).forEach(function(dd) {
                var dayDate = new Date(dd.day + 'T00:00:00');
                var daysAgo = Math.floor((now - dayDate) / 864e5);
                var idx = 29 - Math.floor(daysAgo / 3);
                if (idx >= 0 && idx < 30) {
                    bars[idx].total += dd.total;
                    bars[idx].ai += dd.ai;
                    bars[idx].gsc_clicks += dd.gsc_clicks || 0;
                }
            });
            return bars;
        }

        if (days === 7) {
            /* 7j → 7 bars with day-of-week labels — always show 7 bars even with sparse data */
            var dayNames = ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'];
            var dayMap = {};
            for (i = 6; i >= 0; i--) {
                d = new Date(now);
                d.setDate(d.getDate() - i);
                key = d.toISOString().substring(0, 10);
                bars.push({ day: key, label: dayNames[d.getDay()], total: 0, ai: 0, gsc_clicks: 0 });
                dayMap[key] = bars.length - 1;
            }
            (daily || []).forEach(function(dd) {
                if (dayMap[dd.day] !== undefined) {
                    bars[dayMap[dd.day]].total = dd.total;
                    bars[dayMap[dd.day]].ai = dd.ai;
                    bars[dayMap[dd.day]].gsc_clicks = dd.gsc_clicks || 0;
                }
            });
            return bars; /* Always returns 7 bars, even if all zeros */
        }

        /* 30j default — pad to exact days count */
        var dayMap30 = {};
        for (i = days - 1; i >= 0; i--) {
            d = new Date(now);
            d.setDate(d.getDate() - i);
            key = d.toISOString().substring(0, 10);
            bars.push({ day: key, label: String(d.getDate()), total: 0, ai: 0, gsc_clicks: 0 });
            dayMap30[key] = bars.length - 1;
        }
        (daily || []).forEach(function(dd) {
            if (dayMap30[dd.day] !== undefined) {
                bars[dayMap30[dd.day]].total = dd.total;
                bars[dayMap30[dd.day]].ai = dd.ai;
                bars[dayMap30[dd.day]].gsc_clicks = dd.gsc_clicks || 0;
            }
        });
        return bars;
    }

    /* Seed initial 30-day cache immediately (not in ready — avoids async timing) */
    if (window.htsAnalyticsInitial) {
        cachedData[30] = window.htsAnalyticsInitial;
    }

    $(document).ready(function() {
        bindPeriodButtons();
        bindExportCSV();
        initChartTooltips();
    });

    /* ══════════════════════════════════════════════════════════════
     *  PERIOD SWITCHER
     * ══════════════════════════════════════════════════════════════ */

    function bindPeriodButtons() {
        $(document).on('click', '.hts-ana-period-btn', function(e) {
            e.preventDefault();
            if (loading) return;

            var days = parseInt($(this).data('days'), 10);
            if (days === currentDays) return;

            // Update button states (pill style)
            $('.hts-ana-period-btn').each(function() {
                this.style.background = 'transparent';
                this.style.boxShadow = 'none';
                this.style.color = 'rgba(60,60,67,.4)';
                this.style.fontWeight = '500';
            });
            this.style.background = 'var(--hts-pill-bg)';
            this.style.boxShadow = 'var(--hts-pill-shadow)';
            this.style.color = 'var(--hts-text)';
            this.style.fontWeight = '600';

            currentDays = days;

            if (cachedData[days]) {
                renderAll(cachedData[days]);
                return;
            }

            fetchData(days);
        });
    }

    function fetchData(days) {
        loading = true;
        showLoading(true);

        $.post(htsAnalytics.ajaxUrl, {
            action: 'hts_analytics_data',
            nonce: htsAnalytics.nonce,
            days: days
        }, function(response) {
            loading = false;
            showLoading(false);

            if (response.success && response.data) {
                cachedData[days] = response.data;
                renderAll(response.data);
            } else {
                // AJAX succeeded but returned error — keep previous view, show toast
                if (typeof window._htsToast === 'function') {
                    window._htsToast('Erreur de chargement des données', 'error');
                }
                // Revert to previous period button state
                revertPeriodButton();
            }
        }).fail(function() {
            loading = false;
            showLoading(false);
            if (typeof window._htsToast === 'function') {
                window._htsToast('Erreur réseau — réessayez', 'error');
            }
            revertPeriodButton();
        });
    }

    function revertPeriodButton() {
        // Revert button visual to the last working period
        $('.hts-ana-period-btn').each(function() {
            var d = parseInt($(this).data('days'), 10);
            var isActive = (d === currentDays && cachedData[d]);
            this.style.background = isActive ? 'var(--hts-pill-bg)' : 'transparent';
            this.style.boxShadow = isActive ? 'var(--hts-pill-shadow)' : 'none';
            this.style.color = isActive ? 'var(--hts-text)' : 'rgba(60,60,67,.4)';
            this.style.fontWeight = isActive ? '600' : '500';
        });
    }

    function showLoading(on) {
        var $overlay = $('#hts-ana-loading');
        if (on) $overlay.addClass('visible');
        else $overlay.removeClass('visible');
    }

    /* ══════════════════════════════════════════════════════════════
     *  RENDER ALL SECTIONS
     * ══════════════════════════════════════════════════════════════ */

    function renderAll(data) {
        mergeGscDaily(data); // S14: merge GSC daily clicks into daily array (mirrors analytics.php L46-63)
        renderHeroKPIs(data);
        renderChart(data);
        updatePeriodLabel(data);
        renderS4(data);
        /* S5 (Insights) — crawl_insights not in AJAX response, period-independent */
        renderS6(data);
        renderS7(data);
        renderS8(data);
    }

    /**
     * S14: Merge GSC daily clicks into the daily array.
     * The PHP SSR does this server-side (analytics.php L46-63), but the AJAX endpoint
     * returns gsc.daily separately. This function merges them so renderChart() can use gsc_clicks.
     */
    function mergeGscDaily(data) {
        if (!data) return;
        if (!data.daily) data.daily = [];

        var gscMap = {};
        if (data.gsc && data.gsc.daily && data.gsc.daily.length) {
            data.gsc.daily.forEach(function(gd) {
                var dateKey = gd.fetch_date || gd.date || '';
                if (dateKey) gscMap[dateKey] = parseInt(gd.clicks, 10) || 0;
            });
        }
        var hasGsc = Object.keys(gscMap).length > 0;

        // Build a map of existing daily entries
        var dailyMap = {};
        data.daily.forEach(function(dd) { dailyMap[dd.day] = dd; });

        // Merge GSC clicks into existing entries + create missing ones from GSC
        if (hasGsc) {
            Object.keys(gscMap).forEach(function(dateKey) {
                if (dailyMap[dateKey]) {
                    // Entry exists from tracker — add gsc_clicks
                    if (dailyMap[dateKey].gsc_clicks === undefined) {
                        dailyMap[dateKey].gsc_clicks = gscMap[dateKey];
                    }
                } else {
                    // No tracker visit for this date — create entry from GSC data
                    var entry = { day: dateKey, total: 0, ai: 0, gsc_clicks: gscMap[dateKey] };
                    data.daily.push(entry);
                    dailyMap[dateKey] = entry;
                }
            });
            // Re-sort by date
            data.daily.sort(function(a, b) { return a.day < b.day ? -1 : a.day > b.day ? 1 : 0; });
        }

        // Ensure all entries have gsc_clicks field
        data.daily.forEach(function(dd) {
            if (dd.gsc_clicks === undefined) dd.gsc_clicks = 0;
        });
    }

    /* ─── S1 Hero KPIs (dark gradient cards) ─── */
    function renderHeroKPIs(d) {
        var gsc = d.gsc || {};
        /* Target the value spans inside each hero card via class */
        var heroCards = document.querySelectorAll('.hts-ana-hero-kpi');
        if (heroCards && heroCards.length >= 4) {
            var kpis = [
                { v: formatNumber(gsc.clicks || 0), t: gsc.clicks_trend ? (gsc.clicks_trend > 0 ? '+' : '') + Math.round(gsc.clicks_trend) + '%' : '' },
                { v: formatNumber(d.ai_total || 0), t: d.ai_trend > 0 ? '+' + Math.round(d.ai_trend) + '%' : '' },
                { v: gsc.avg_position > 0 ? Number(gsc.avg_position).toFixed(1) : '\u2014', t: (gsc.position_trend && gsc.position_trend !== 0) ? (gsc.position_trend > 0 ? '+' : '') + Number(gsc.position_trend).toFixed(1) : '' },
                { v: (d.wf_rate !== undefined ? d.wf_rate + '%' : '0%'), t: d.wf_positive > 0 ? '+' + d.wf_positive : '' }
            ];
            heroCards.forEach(function(card, i) {
                if (!kpis[i]) return;
                var valEl = card.querySelector('.hts-ana-hero-val');
                var trendEl = card.querySelector('.hts-ana-hero-trend');
                if (valEl) valEl.textContent = kpis[i].v;
                if (trendEl) {
                    trendEl.textContent = kpis[i].t;
                    trendEl.style.display = kpis[i].t ? '' : 'none';
                }
            });
            return;
        }
        /* Legacy fallback: individual IDs */
        var $gscV = $('#hts-ana-hero-visites-google');
        if ($gscV.length) $gscV.text(formatNumber(gsc.clicks || 0));
        var $aiV = $('#hts-ana-hero-visites-ia');
        if ($aiV.length) $aiV.text(formatNumber(d.ai_total || 0));
        var $posV = $('#hts-ana-hero-position-moyenne');
        if ($posV.length) $posV.text(gsc.avg_position > 0 ? Number(gsc.avg_position).toFixed(1) : '\u2014');
        var $engV = $('#hts-ana-hero-engagement');
        if ($engV.length) $engV.text(d.engagement ? fmtTime(d.engagement.avg_time) : '\u2014');
    }

    /* ─── S3 Chart (bars) — normalized per period ─── */
    function renderChart(d) {
        var $box = $('#hts-ana-chart-bars');
        if (!$box.length) return;

        var days = d.days || currentDays;
        var bars = normalizeChartData(d.daily, days);

        if (!bars || !bars.length) {
            $box.html('<div style="text-align:center;width:100%;padding:40px 0;font-size:12px;color:var(--hts-text-3)">Pas de donn\u00e9es sur cette p\u00e9riode</div>');
            return;
        }

        // Check if ALL bars are empty (no visits tracked yet for this period)
        var hasAnyData = bars.some(function(r) { return r.total > 0 || (r.gsc_clicks || 0) > 0; });
        if (!hasAnyData) {
            // Show the bar structure but with a subtle empty state message
            var emptyHtml = '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:11px;color:var(--hts-text-3);text-align:center;z-index:1;pointer-events:none">Pas encore de visites sur cette p\u00e9riode</div>';
            bars.forEach(function(dd) {
                emptyHtml += '<div style="flex:1;position:relative"><div style="position:absolute;bottom:16px;left:0;right:0;height:3px;background:var(--hts-border-sub);border-radius:3px;opacity:.4"></div>';
                emptyHtml += '<div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:' + (bars.length > 12 ? 7 : 10) + 'px;color:var(--hts-faint);line-height:1">' + esc(dd.label) + '</div></div>';
            });
            $box.html(emptyHtml);
            return;
        }

        // S14: use gsc_clicks for Google bars when available, fallback to total-ai
        var hasGscClicks = bars.some(function(r) { return (r.gsc_clicks || 0) > 0; });
        var maxDay = Math.max.apply(null, bars.map(function(r) {
            var googleVal = hasGscClicks ? (r.gsc_clicks || 0) : Math.max(0, r.total - r.ai);
            return googleVal + r.ai;
        }));
        maxDay = Math.max(maxDay, 1);
        var barCount = bars.length;
        var gap = barCount > 12 ? 2 : 6;

        /* Update container gap */
        $box[0].style.gap = gap + 'px';

        var html = '';
        bars.forEach(function(dd) {
            var googleVal = hasGscClicks ? (dd.gsc_clicks || 0) : Math.max(0, dd.total - dd.ai);
            var googleH = Math.max(2, Math.round(googleVal / maxDay * 114));
            var aiH = Math.max(1, Math.round(dd.ai / maxDay * 114));
            html += '<div class="hts-ana-bar" style="flex:1;position:relative;cursor:pointer" ' +
                'data-day="' + esc(dd.day || dd.label) + '" data-total="' + dd.total + '" data-ai="' + dd.ai + '" data-google="' + googleVal + '">' +
                '<div class="hts-bar-google" style="position:absolute;bottom:16px;left:0;right:0;height:' + (googleH + aiH) + 'px;background:var(--hts-accent);opacity:.18;border-radius:3px 3px 0 0"></div>' +
                '<div class="hts-bar-ia" style="position:absolute;bottom:16px;left:0;right:0;height:' + aiH + 'px;background:var(--hts-geo);opacity:.75;border-radius:0"></div>' +
                '<div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:' + (barCount > 12 ? 7 : 10) + 'px;color:var(--hts-faint);line-height:1">' + esc(dd.label) + '</div>' +
                '</div>';
        });

        $box.html(html);
        initChartTooltips();
        /* Re-apply Google/IA visibility toggle state after bar re-render */
        if (typeof window._htsBarToggleUpdate === 'function') {
            window._htsBarToggleUpdate();
        }
    }

    /* ─── Period label ─── */
    function updatePeriodLabel(d) {
        var days = d.days || currentDays;
        var labels = { 7: '7j', 30: '30j', 90: '90j', 365: '12m' };
        var label = labels[days] || days + 'j';
        $('#hts-chart-period-label').text(label);
    }

    /* ══════════════════════════════════════════════════════════════
     *  S4 — SEO + GEO (Google card + Visibilité IA card)
     * ══════════════════════════════════════════════════════════════ */

    function renderS4(d) {
        var $s4 = $('#hts-ana-s4');
        if (!$s4.length) return;

        var gsc = d.gsc || { clicks: 0, impressions: 0, avg_position: 0, avg_ctr: 0 };
        var gscConnected = d.gsc !== null && d.gsc !== undefined;

        // S14: use gsc_clicks for Google sparkline when available
        var hasGscData = d.daily && d.daily.some(function(r) { return (r.gsc_clicks || 0) > 0; });
        var gscSpark = d.daily ? d.daily.map(function(r) { return hasGscData ? (r.gsc_clicks || 0) : r.total; }) : [];
        var aiSpark = d.daily ? d.daily.map(function(r) { return r.ai; }) : [];

        var html = '';

        /* ── Card Google ── */
        html += '<div class="hts-ds-card" style="padding:22px 24px 0;display:flex;flex-direction:column;overflow:hidden">';
        html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">';
        html += googleG(20);
        html += '<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Google</span>';
        if (gscConnected) {
            html += '<span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:6px;background:var(--hts-success-bg);color:var(--hts-success)">GSC connect\u00e9</span>';
        }
        html += '</div>';
        html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">';
        var gscKpis = [
            { l: 'Clics', v: formatNumber(gsc.clicks || 0), c: 'var(--hts-accent)' },
            { l: 'Impressions', v: formatNumber(gsc.impressions || 0), c: 'var(--hts-text)' },
            { l: 'Position moy.', v: gsc.avg_position > 0 ? Number(gsc.avg_position).toFixed(1) : '\u2014', c: 'var(--hts-success)' },
            { l: 'CTR moyen', v: (gsc.avg_ctr || 0) + '%', c: 'var(--hts-text)' }
        ];
        gscKpis.forEach(function(m) {
            html += '<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:var(--hts-surface)">';
            html += '<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">' + esc(m.l) + '</div>';
            html += '<div style="font-size:20px;font-weight:800;color:' + m.c + ';letter-spacing:-.03em">' + m.v + '</div>';
            html += '</div>';
        });
        html += '</div><div style="flex:1"></div>';
        html += bleedSpark(gscSpark, 'var(--hts-accent)', 50);
        html += '</div>';

        /* ── Card Visibilité IA ── */
        html += '<div class="hts-ds-card" style="padding:22px 24px 0;background:linear-gradient(180deg,var(--hts-geo-soft),var(--hts-bg));border:1px solid var(--hts-geo-border);display:flex;flex-direction:column;overflow:hidden">';
        html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">';
        html += '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" style="flex-shrink:0"><rect x="3" y="4" width="18" height="14" rx="3" stroke="var(--hts-geo)" stroke-width="1.7" fill="none"/><circle cx="9" cy="11" r="1.5" fill="var(--hts-geo)"/><circle cx="15" cy="11" r="1.5" fill="var(--hts-geo)"/><line x1="12" y1="1" x2="12" y2="4" stroke="var(--hts-geo)" stroke-width="1.7"/></svg>';
        html += '<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Visibilit\u00e9 IA</span>';
        if (d.ai_trend > 0) {
            html += '<span style="font-size:12px;font-weight:700;color:var(--hts-success)">+' + Math.round(d.ai_trend) + '%</span>';
        }
        html += '</div>';
        html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">';
        html += '<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:rgba(255,255,255,.7)">';
        html += '<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">Visites IA</div>';
        html += '<div style="font-size:20px;font-weight:800;color:var(--hts-geo);letter-spacing:-.03em">' + formatNumber(d.ai_total || 0) + '</div>';
        html += '</div>';
        html += '<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:rgba(255,255,255,.7)">';
        html += '<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">Articles cit\u00e9s</div>';
        html += '<div style="font-size:20px;font-weight:800;color:var(--hts-success);letter-spacing:-.03em">' + (d.top_articles ? d.top_articles.length : 0) + '</div>';
        html += '</div></div>';

        /* AI sources bars */
        if (d.ai_sources && d.ai_sources.length) {
            var maxSrc = d.ai_sources[0].count || 1;
            d.ai_sources.forEach(function(sr, si) {
                var slug = sr.source;
                var color = SRC_COLORS[slug] || 'var(--hts-geo)';
                var pct = Math.round(sr.count / maxSrc * 100);
                html += '<div style="display:flex;align-items:center;gap:8px;padding:7px 0;' + (si > 0 ? 'border-top:1px solid var(--hts-geo-border)' : '') + '">';
                html += aiLogo(slug, 18);
                html += '<div style="flex:1;height:5px;border-radius:3px;background:rgba(255,255,255,.5);overflow:hidden"><div style="width:' + pct + '%;height:100%;border-radius:3px;background:' + color + '"></div></div>';
                html += '<span style="font-size:11px;font-weight:700;color:var(--hts-text);min-width:30px;text-align:right">' + sr.count + '</span>';
                html += '</div>';
            });
        }
        html += '<div style="flex:1"></div>';
        html += bleedSpark(aiSpark, 'var(--hts-geo)', 50);
        html += '</div>';

        $s4.html(html);
    }

    /* ══════════════════════════════════════════════════════════════
     *  S6 — TOP PAGES (Google + IA)
     * ══════════════════════════════════════════════════════════════ */

    function renderS6(d) {
        var $s6 = $('#hts-ana-s6');
        if (!$s6.length) return;

        var gsc = d.gsc || {};
        var gscConnected = d.gsc !== null && d.gsc !== undefined;
        var html = '';

        /* ── Top pages Google ── */
        html += '<div class="hts-ds-card" style="padding:22px 24px">';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">';
        html += '<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Top pages Google</span>';
        html += '<button class="hts-tout-voir-btn" data-section="top-google" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>';
        html += '</div>';

        if (gsc.top_pages && gsc.top_pages.length) {
            gsc.top_pages.slice(0, 5).forEach(function(gp, i) {
                var gpEditUrl = gp.post_id ? 'post.php?post=' + gp.post_id + '&action=edit' : '';
                html += '<div style="display:flex;align-items:center;gap:10px;height:44px;' + (i > 0 ? 'border-top:1px solid var(--hts-border-sub)' : '') + '">';
                html += '<span style="width:20px;height:20px;border-radius:6px;background:var(--hts-accent-bg);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:var(--hts-accent);flex-shrink:0">' + (i + 1) + '</span>';
                var title = gp.title || gp.url || '';
                if (gpEditUrl) {
                    html += '<a href="' + esc(gpEditUrl) + '" style="flex:1;font-size:12px;font-weight:500;color:var(--hts-text);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(truncate(title, 45)) + '</a>';
                } else {
                    html += '<span style="flex:1;font-size:12px;font-weight:500;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(truncate(title, 45)) + '</span>';
                }
                html += '<span style="font-size:11px;font-weight:700;color:var(--hts-accent);min-width:30px;text-align:right">' + (gp.clicks || 0) + '</span>';
                html += '<span style="font-size:10px;color:var(--hts-text-3);min-width:50px;text-align:right">pos ' + esc(String(gp.position || '')) + '</span>';
                html += '</div>';
            });
        } else {
            if (!gscConnected) {
                html += '<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)"><span style="color:var(--hts-accent);font-weight:600">Connecter Search Console</span></div>';
            } else {
                html += '<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)">Pas encore assez de donn\u00e9es</div>';
            }
        }
        html += '</div>';

        /* ── Top pages IA ── */
        html += '<div class="hts-ds-card" style="padding:22px 24px;background:linear-gradient(180deg,var(--hts-geo-soft),var(--hts-bg));border:1px solid var(--hts-geo-border)">';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">';
        html += '<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Top pages cit\u00e9es par les IA</span>';
        html += '<button class="hts-tout-voir-btn" data-section="top-ia" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>';
        html += '</div>';

        if (d.top_articles && d.top_articles.length) {
            d.top_articles.slice(0, 5).forEach(function(art, i) {
                var editUrl = art.post_id ? 'post.php?post=' + art.post_id + '&action=edit' : '';
                html += '<div style="display:flex;align-items:center;gap:10px;height:44px;' + (i > 0 ? 'border-top:1px solid var(--hts-geo-border)' : '') + '">';
                html += '<span style="width:20px;height:20px;border-radius:6px;background:rgba(99,102,241,.15);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:var(--hts-geo);flex-shrink:0">' + (i + 1) + '</span>';
                html += '<div style="flex:1;min-width:0">';
                if (editUrl) {
                    html += '<a href="' + esc(editUrl) + '" style="font-size:12px;font-weight:500;color:var(--hts-text);text-decoration:none;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(truncate(art.title || '', 40)) + '</a>';
                } else {
                    html += '<span style="font-size:12px;font-weight:500;color:var(--hts-text);display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(truncate(art.title || '', 40)) + '</span>';
                }
                if (art.sources) {
                    html += '<div style="font-size:9px;color:var(--hts-text-3)">' + esc(art.sources) + '</div>';
                }
                html += '</div>';
                html += '<span style="font-size:11px;font-weight:700;color:var(--hts-geo);min-width:30px;text-align:right">' + (art.ai_visits || 0) + '</span>';
                html += '</div>';
            });
        } else {
            html += '<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)">Aucune citation IA d\u00e9tect\u00e9e</div>';
        }
        html += '</div>';

        $s6.html(html);
    }

    /* ══════════════════════════════════════════════════════════════
     *  S7 — ROBOTS + FRESHNESS
     * ══════════════════════════════════════════════════════════════ */

    function renderS7(d) {
        var $s7 = $('#hts-ana-s7');
        if (!$s7.length) return;

        var crawl = d.crawl || {};
        var catAI = (crawl.cat_totals && crawl.cat_totals.ai) || 0;
        var catSEO = (crawl.cat_totals && crawl.cat_totals.seo) || 0;
        var catTotal = catAI + catSEO;
        var botSources = crawl.bot_sources || {};
        var maxBot = 1;
        var aiBots = [];
        var seoBots = [];
        var allCount = 0;

        for (var slug in botSources) {
            if (!botSources.hasOwnProperty(slug)) continue;
            var info = botSources[slug];
            var cat = info.category || 'ai';
            var entry = { slug: slug, count: info.count || 0, label: info.label || slug, color: info.color || 'var(--hts-geo)' };
            allCount++;
            if (entry.count > maxBot) maxBot = entry.count;
            if (cat === 'seo') seoBots.push(entry);
            else aiBots.push(entry);
        }

        var html = '';

        /* ── Activité robots ── */
        html += '<div class="hts-ds-card" style="padding:22px 24px">';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">';
        html += '<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Activit\u00e9 robots</span>';
        if (catTotal > 0) {
            html += '<span style="font-size:11px;font-weight:700;color:var(--hts-accent)">' + formatNumber(catTotal) + ' scans</span>';
        }
        html += '</div>';

        if (catTotal > 0) {
            html += '<div style="display:flex;justify-content:space-between;font-size:11px;font-weight:600;margin-bottom:6px">';
            html += '<span style="color:var(--hts-geo)">Robots IA : ' + formatNumber(catAI) + '</span>';
            html += '<span style="color:var(--hts-danger)">Moteurs : ' + formatNumber(catSEO) + '</span>';
            html += '</div>';
            var aiPct = Math.round(catAI / catTotal * 100);
            html += '<div style="height:8px;border-radius:4px;overflow:hidden;display:flex;margin-bottom:12px">';
            html += '<div style="width:' + aiPct + '%;height:100%;background:linear-gradient(90deg,var(--hts-geo),#A78BFA)"></div>';
            html += '<div style="width:' + (100 - aiPct) + '%;height:100%;background:linear-gradient(90deg,#EA4335,#F87171)"></div>';
            html += '</div>';
        }

        /* Top 3 bots (AI priority, fill with SEO if < 3 AI) */
        var top3 = aiBots.slice(0, 3);
        if (top3.length < 3) {
            top3 = top3.concat(seoBots.slice(0, 3 - top3.length));
        }
        top3.forEach(function(bot, i) {
            var pct = Math.round(bot.count / maxBot * 100);
            var isAI = aiBots.indexOf(bot) !== -1;
            html += '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;' + (i > 0 ? 'border-top:1px solid var(--hts-border-sub)' : '') + '">';
            if (isAI) {
                html += aiLogo(bot.slug, 16);
            } else {
                html += '<div style="width:16px;height:16px;border-radius:50%;background:' + bot.color + '20;display:flex;align-items:center;justify-content:center"><div style="width:8px;height:8px;border-radius:50%;background:' + bot.color + '"></div></div>';
            }
            html += '<span style="font-size:11px;font-weight:600;color:var(--hts-text);flex:1">' + esc(bot.label) + '</span>';
            html += '<div style="width:60px;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:' + pct + '%;height:100%;border-radius:2px;background:' + bot.color + '"></div></div>';
            html += '<span style="font-size:11px;font-weight:700;color:var(--hts-text);min-width:30px;text-align:right">' + bot.count + '</span>';
            html += '</div>';
        });

        /* Toggle all robots */
        var top3Slugs = top3.map(function(b) { return b.slug; });
        html += '<button class="hts-robots-toggle-js" style="display:flex;align-items:center;gap:4px;margin-top:10px;padding:6px 12px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);width:100%;justify-content:center">Voir les ' + allCount + ' robots</button>';
        html += '<div class="hts-robots-detail-js" style="display:none;margin-top:12px">';
        /* Only show bots NOT in top 3 (complement) */
        var aiRemaining = aiBots.filter(function(b) { return top3Slugs.indexOf(b.slug) === -1; });
        var seoRemaining = seoBots.filter(function(b) { return top3Slugs.indexOf(b.slug) === -1; });
        if (aiRemaining.length) {
            html += '<div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">Robots IA</div>';
            aiRemaining.forEach(function(bot) {
                var pct = Math.round(bot.count / maxBot * 100);
                html += botRow(bot, pct, true);
            });
        }
        if (seoRemaining.length) {
            html += '<div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">Moteurs de recherche</div>';
            seoRemaining.forEach(function(bot) {
                var pct = Math.round(bot.count / maxBot * 100);
                html += botRow(bot, pct, false);
            });
        }
        html += '</div></div>';

        /* ── Contenu à rafraîchir ── */
        html += '<div class="hts-ds-card" style="padding:22px 24px">';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">';
        html += '<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Contenu \u00e0 rafra\u00eechir</span>';
        if (d.stale_posts && d.stale_posts.length) {
            html += '<button class="hts-tout-voir-btn" data-section="freshness" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>';
        }
        html += '</div>';

        if (d.stale_posts && d.stale_posts.length) {
            d.stale_posts.forEach(function(sp, i) {
                var extra = i >= 4 ? ' hts-fresh-extra' : '';
                var disp = i >= 4 ? 'none' : 'flex';
                html += '<div class="' + extra.trim() + '" style="display:' + disp + ';align-items:center;gap:10px;padding:8px 0;' + (i > 0 ? 'border-top:1px solid var(--hts-border-sub)' : '') + '">';
                html += '<span style="font-size:9px;font-weight:700;padding:3px 8px;border-radius:6px;background:var(--hts-danger-bg);color:var(--hts-danger);flex-shrink:0">' + (sp.months_ago || 0) + ' mois</span>';
                html += '<span style="flex:1;font-size:12px;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(truncate(sp.title || '', 45)) + '</span>';
                if (sp.edit_url) {
                    html += '<a href="' + esc(sp.edit_url) + '" style="font-size:11px;font-weight:600;color:var(--hts-accent);text-decoration:none;flex-shrink:0">Mettre \u00e0 jour</a>';
                }
                html += '</div>';
            });
        } else {
            html += '<div style="text-align:center;padding:30px 0">';
            html += '<div style="font-size:13px;font-weight:600;color:var(--hts-success)">Tous vos articles sont \u00e0 jour</div>';
            html += '</div>';
        }
        html += '</div>';

        $s7.html(html);

        /* Re-bind toggle */
        $s7.find('.hts-robots-toggle-js').on('click', function() {
            var $detail = $s7.find('.hts-robots-detail-js');
            var isOpen = $detail.is(':visible');
            $detail.toggle(!isOpen);
            $(this).text(isOpen ? 'Voir les ' + allCount + ' robots' : 'Masquer');
            /* Sync freshness extra rows */
            $s7.find('.hts-fresh-extra').each(function() {
                this.style.display = isOpen ? 'none' : 'flex';
            });
        });
    }

    function botRow(bot, pct, isAI) {
        var h = '<div style="display:flex;align-items:center;gap:8px;padding:5px 0">';
        if (isAI) {
            h += aiLogo(bot.slug, 14);
        } else {
            h += '<div style="width:14px;height:14px;border-radius:50%;background:' + bot.color + '20;display:flex;align-items:center;justify-content:center"><div style="width:6px;height:6px;border-radius:50%;background:' + bot.color + '"></div></div>';
        }
        h += '<span style="font-size:11px;font-weight:600;color:var(--hts-text);min-width:70px">' + esc(bot.label) + '</span>';
        h += '<div style="flex:1;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:' + pct + '%;height:100%;border-radius:2px;background:' + bot.color + '"></div></div>';
        h += '<span style="font-size:10px;font-weight:700;color:var(--hts-text-2);min-width:36px;text-align:right">' + bot.count + '</span>';
        h += '</div>';
        return h;
    }

    /* ══════════════════════════════════════════════════════════════
     *  S8 — ENGAGEMENT TABLE
     * ══════════════════════════════════════════════════════════════ */

    function renderS8(d) {
        var $s8 = $('#hts-ana-s8');
        if (!$s8.length) return;

        var html = '';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">';
        html += '<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Top articles par engagement</span>';
        html += '<button class="hts-tout-voir-btn" data-section="engagement" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>';
        html += '</div>';

        if (d.top_engaged && d.top_engaged.length) {
            html += '<table style="width:100%;border-collapse:collapse;font-size:12px">';
            html += '<thead><tr style="border-bottom:2px solid var(--hts-border)">';
            ['Article', 'Visites', 'IA', 'Temps', 'Scroll'].forEach(function(th) {
                var align = th === 'Article' ? 'left' : 'center';
                html += '<th style="text-align:' + align + ';padding:8px 10px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">' + th + '</th>';
            });
            html += '</tr></thead><tbody>';

            d.top_engaged.slice(0, 5).forEach(function(row) {
                var sc = row.avg_scroll >= 70 ? 'var(--hts-success)' : (row.avg_scroll >= 40 ? 'var(--hts-caution)' : 'var(--hts-danger)');
                var editUrl = row.post_id ? 'post.php?post=' + row.post_id + '&action=edit' : '';
                html += '<tr style="border-bottom:1px solid var(--hts-border-sub)">';
                if (editUrl) {
                    html += '<td style="padding:10px"><a href="' + esc(editUrl) + '" style="color:var(--hts-text);text-decoration:none;font-weight:500">' + esc(truncate(row.title || '', 40)) + '</a></td>';
                } else {
                    html += '<td style="padding:10px"><span style="color:var(--hts-text);font-weight:500">' + esc(truncate(row.title || '', 40)) + '</span></td>';
                }
                html += '<td style="text-align:center;padding:10px;font-weight:600">' + (row.visits || 0) + '</td>';
                html += '<td style="text-align:center;padding:10px">';
                if (row.ai_visits > 0) {
                    html += '<span style="background:var(--hts-geo-soft);color:var(--hts-geo);padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700">' + row.ai_visits + '</span>';
                } else {
                    html += '<span style="color:var(--hts-text-3)">\u2014</span>';
                }
                html += '</td>';
                html += '<td style="text-align:center;padding:10px;font-weight:600;color:var(--hts-success)">' + fmtTime(row.avg_time) + '</td>';
                html += '<td style="text-align:center;padding:10px">';
                html += '<div style="display:flex;align-items:center;gap:4px;justify-content:center">';
                html += '<div style="width:40px;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:' + (row.avg_scroll || 0) + '%;height:100%;border-radius:2px;background:' + sc + '"></div></div>';
                html += '<span style="font-size:10px;font-weight:600;color:' + sc + '">' + (row.avg_scroll || 0) + '%</span>';
                html += '</div></td></tr>';
            });

            html += '</tbody></table>';
        } else {
            html += '<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)">Pas encore assez de donn\u00e9es</div>';
        }

        $s8.html(html);
    }

    /* ══════════════════════════════════════════════════════════════
     *  TOUT VOIR MODAL — content rendering, filter, pagination
     * ══════════════════════════════════════════════════════════════ */

    var modal = { section: null, page: 1, perPage: 25, filter: '', rows: [] };

    function openModal(section) {
        modal.section = section;
        modal.page = 1;
        modal.filter = '';
        modal.rows = getModalRows(section);

        var $overlay = $('#hts-modal-overlay');
        var $title = $('#hts-modal-title');
        var $filter = $('#hts-modal-filter');
        if (!$overlay.length) return;

        var titles = {
            'top-google': 'Top pages Google',
            'top-ia': 'Top pages cit\u00e9es par les IA',
            'freshness': 'Contenu \u00e0 rafra\u00eechir',
            'engagement': 'Top articles par engagement'
        };
        $title.text(titles[section] || section);
        $filter.val('');
        $overlay.css('display', 'flex');
        renderModalBody();
    }

    function getModalRows(section) {
        var d = cachedData[currentDays];
        /* Fallback: if cache miss, try initial seed */
        if (!d && window.htsAnalyticsInitial) {
            d = window.htsAnalyticsInitial;
        }
        d = d || {};
        var gsc = d.gsc || {};

        if (section === 'top-google') {
            return (gsc.top_pages || []).map(function(p) {
                return {
                    title: p.title || p.url || '',
                    clicks: p.clicks || 0,
                    impressions: p.impressions || 0,
                    position: p.position || 0,
                    ctr: p.ctr || 0,
                    post_id: p.post_id || 0
                };
            });
        }
        if (section === 'top-ia') {
            return (d.top_articles || []).map(function(a) {
                return {
                    title: a.title || '',
                    ai_visits: a.ai_visits || 0,
                    sources: a.sources || '',
                    post_id: a.post_id || 0
                };
            });
        }
        if (section === 'freshness') {
            return (d.stale_posts || []).map(function(s) {
                return {
                    title: s.title || '',
                    months_ago: s.months_ago || 0,
                    edit_url: s.edit_url || ''
                };
            });
        }
        if (section === 'engagement') {
            return (d.top_engaged || []).map(function(r) {
                return {
                    title: r.title || '',
                    visits: r.visits || 0,
                    ai_visits: r.ai_visits || 0,
                    avg_time: r.avg_time || 0,
                    avg_scroll: r.avg_scroll || 0,
                    post_id: r.post_id || 0
                };
            });
        }
        return [];
    }

    function getFilteredRows() {
        if (!modal.filter) return modal.rows;
        var q = modal.filter.toLowerCase();
        return modal.rows.filter(function(r) {
            return (r.title || '').toLowerCase().indexOf(q) !== -1;
        });
    }

    function renderModalBody() {
        var $body = $('#hts-modal-body');
        var $info = $('#hts-modal-page-info');
        if (!$body.length) return;

        var filtered = getFilteredRows();
        var total = filtered.length;
        var pages = Math.max(1, Math.ceil(total / modal.perPage));
        if (modal.page > pages) modal.page = pages;
        var start = (modal.page - 1) * modal.perPage;
        var slice = filtered.slice(start, start + modal.perPage);

        var html = '';

        if (total === 0) {
            html = '<div style="text-align:center;padding:40px 0;font-size:13px;color:var(--hts-text-3)">Aucun r\u00e9sultat</div>';
            $body.html(html);
            $info.text('');
            updateModalPagination(0, 0);
            return;
        }

        /* Header info (result count) */
        var countHtml = '<div style="font-size:12px;color:var(--hts-text-3);padding:12px 0 8px">' + total + ' r\u00e9sultat' + (total > 1 ? 's' : '');
        if (modal.filter) countHtml += ' pour \u00ab ' + esc(modal.filter) + ' \u00bb';
        countHtml += '</div>';

        html += countHtml;
        html += '<table style="width:100%;border-collapse:collapse;font-size:12px">';
        html += '<thead><tr style="border-bottom:2px solid var(--hts-border);position:sticky;top:0;background:var(--hts-bg)">';

        var cols = getModalCols(modal.section);
        cols.forEach(function(col) {
            html += '<th style="text-align:' + (col.align || 'left') + ';padding:10px 8px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">' + col.label + '</th>';
        });
        html += '</tr></thead><tbody>';

        slice.forEach(function(row) {
            html += '<tr style="border-bottom:1px solid var(--hts-border-sub)">';
            html += renderModalRow(modal.section, row);
            html += '</tr>';
        });

        html += '</tbody></table>';
        $body.html(html);
        updateModalPagination(modal.page, pages);
    }

    function getModalCols(section) {
        if (section === 'top-google') {
            return [
                { label: 'Page', align: 'left' },
                { label: 'Clics', align: 'center' },
                { label: 'Impressions', align: 'center' },
                { label: 'CTR', align: 'center' },
                { label: 'Position', align: 'center' }
            ];
        }
        if (section === 'top-ia') {
            return [
                { label: 'Article', align: 'left' },
                { label: 'Visites IA', align: 'center' },
                { label: 'Sources', align: 'left' }
            ];
        }
        if (section === 'freshness') {
            return [
                { label: 'Article', align: 'left' },
                { label: 'Anciennet\u00e9', align: 'center' },
                { label: 'Action', align: 'center' }
            ];
        }
        if (section === 'engagement') {
            return [
                { label: 'Article', align: 'left' },
                { label: 'Visites', align: 'center' },
                { label: 'IA', align: 'center' },
                { label: 'Temps', align: 'center' },
                { label: 'Scroll', align: 'center' }
            ];
        }
        return [];
    }

    function renderModalRow(section, r) {
        var h = '';
        if (section === 'top-google') {
            var url = r.post_id ? 'post.php?post=' + r.post_id + '&action=edit' : '';
            if (url) {
                h += '<td style="padding:10px 8px"><a href="' + esc(url) + '" style="color:var(--hts-text);text-decoration:none;font-weight:500">' + esc(truncate(r.title, 60)) + '</a></td>';
            } else {
                h += '<td style="padding:10px 8px;font-weight:500;color:var(--hts-text)">' + esc(truncate(r.title, 60)) + '</td>';
            }
            h += '<td style="text-align:center;padding:10px 8px;font-weight:700;color:var(--hts-accent)">' + r.clicks + '</td>';
            h += '<td style="text-align:center;padding:10px 8px">' + formatNumber(r.impressions) + '</td>';
            h += '<td style="text-align:center;padding:10px 8px">' + r.ctr + '%</td>';
            h += '<td style="text-align:center;padding:10px 8px">' + r.position + '</td>';
        }
        else if (section === 'top-ia') {
            var url2 = r.post_id ? 'post.php?post=' + r.post_id + '&action=edit' : '';
            if (url2) {
                h += '<td style="padding:10px 8px"><a href="' + esc(url2) + '" style="color:var(--hts-text);text-decoration:none;font-weight:500">' + esc(truncate(r.title, 50)) + '</a></td>';
            } else {
                h += '<td style="padding:10px 8px;font-weight:500;color:var(--hts-text)">' + esc(truncate(r.title, 50)) + '</td>';
            }
            h += '<td style="text-align:center;padding:10px 8px"><span style="background:var(--hts-geo-soft);color:var(--hts-geo);padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700">' + r.ai_visits + '</span></td>';
            h += '<td style="padding:10px 8px;font-size:11px;color:var(--hts-text-3)">' + esc(r.sources) + '</td>';
        }
        else if (section === 'freshness') {
            h += '<td style="padding:10px 8px;font-weight:500;color:var(--hts-text)">' + esc(truncate(r.title, 55)) + '</td>';
            h += '<td style="text-align:center;padding:10px 8px"><span style="font-size:9px;font-weight:700;padding:3px 8px;border-radius:6px;background:var(--hts-danger-bg);color:var(--hts-danger)">' + r.months_ago + ' mois</span></td>';
            if (r.edit_url) {
                h += '<td style="text-align:center;padding:10px 8px"><a href="' + esc(r.edit_url) + '" style="font-size:11px;font-weight:600;color:var(--hts-accent);text-decoration:none">Mettre \u00e0 jour</a></td>';
            } else {
                h += '<td style="text-align:center;padding:10px 8px;color:var(--hts-text-3)">\u2014</td>';
            }
        }
        else if (section === 'engagement') {
            var sc = r.avg_scroll >= 70 ? 'var(--hts-success)' : (r.avg_scroll >= 40 ? 'var(--hts-caution)' : 'var(--hts-danger)');
            var url3 = r.post_id ? 'post.php?post=' + r.post_id + '&action=edit' : '';
            if (url3) {
                h += '<td style="padding:10px 8px"><a href="' + esc(url3) + '" style="color:var(--hts-text);text-decoration:none;font-weight:500">' + esc(truncate(r.title, 45)) + '</a></td>';
            } else {
                h += '<td style="padding:10px 8px;font-weight:500;color:var(--hts-text)">' + esc(truncate(r.title, 45)) + '</td>';
            }
            h += '<td style="text-align:center;padding:10px 8px;font-weight:600">' + r.visits + '</td>';
            h += '<td style="text-align:center;padding:10px 8px">';
            if (r.ai_visits > 0) {
                h += '<span style="background:var(--hts-geo-soft);color:var(--hts-geo);padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700">' + r.ai_visits + '</span>';
            } else {
                h += '<span style="color:var(--hts-text-3)">\u2014</span>';
            }
            h += '</td>';
            h += '<td style="text-align:center;padding:10px 8px;font-weight:600;color:var(--hts-success)">' + fmtTime(r.avg_time) + '</td>';
            h += '<td style="text-align:center;padding:10px 8px"><div style="display:flex;align-items:center;gap:4px;justify-content:center">';
            h += '<div style="width:40px;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:' + r.avg_scroll + '%;height:100%;border-radius:2px;background:' + sc + '"></div></div>';
            h += '<span style="font-size:10px;font-weight:600;color:' + sc + '">' + r.avg_scroll + '%</span>';
            h += '</div></td>';
        }
        return h;
    }

    function updateModalPagination(current, total) {
        var $prev = $('#hts-modal-prev');
        var $next = $('#hts-modal-next');
        var $perWrap = $('#hts-modal-perpage-wrap');
        var $nav = $('#hts-modal-nav');
        var $info = $('#hts-modal-page-info');
        var filtered = getFilteredRows();
        var count = filtered.length;

        /* Hide perPage selector + pagination when everything fits on one page */
        if (total <= 1) {
            $perWrap.css('visibility', 'hidden');
            $nav.css('visibility', 'hidden');
            $info.text(count + ' r\u00e9sultat' + (count > 1 ? 's' : ''));
        } else {
            $perWrap.css('visibility', 'visible');
            $nav.css('visibility', 'visible');
            $info.text('Page ' + current + ' sur ' + total);
        }

        if ($prev.length) {
            $prev.prop('disabled', current <= 1);
            $prev.css('opacity', current <= 1 ? '.4' : '1');
        }
        if ($next.length) {
            $next.prop('disabled', current >= total);
            $next.css('opacity', current >= total ? '.4' : '1');
        }
    }

    /* Expose openModal for the inline delegated handler */
    window._htsOpenModal = openModal;

    /* Modal interactions: filter, pagination, perPage, Export CSV */
    $(document).ready(function() {
        /* Filter input — debounced */
        var filterTimer = null;
        $(document).on('input', '#hts-modal-filter', function() {
            var val = $(this).val();
            clearTimeout(filterTimer);
            filterTimer = setTimeout(function() {
                modal.filter = val;
                modal.page = 1;
                renderModalBody();
            }, 200);
        });

        /* Pagination buttons */
        $(document).on('click', '#hts-modal-prev', function() {
            if (modal.page > 1) {
                modal.page--;
                renderModalBody();
            }
        });
        $(document).on('click', '#hts-modal-next', function() {
            var filtered = getFilteredRows();
            var pages = Math.max(1, Math.ceil(filtered.length / modal.perPage));
            if (modal.page < pages) {
                modal.page++;
                renderModalBody();
            }
        });

        /* Per page select */
        $(document).on('change', '#hts-modal-perpage', function() {
            modal.perPage = parseInt($(this).val(), 10) || 25;
            modal.page = 1;
            renderModalBody();
        });

        /* Export CSV from modal */
        $(document).on('click', '#hts-modal-export-csv', function() {
            var rows = getFilteredRows();
            if (!rows.length) { alert('Aucune donn\u00e9e \u00e0 exporter.'); return; }
            var cols = getModalCols(modal.section);
            var csvRows = [cols.map(function(c) { return c.label; })];
            rows.forEach(function(r) {
                var line = [];
                if (modal.section === 'top-google') {
                    line = [r.title, r.clicks, r.impressions, r.ctr + '%', r.position];
                } else if (modal.section === 'top-ia') {
                    line = [r.title, r.ai_visits, r.sources];
                } else if (modal.section === 'freshness') {
                    line = [r.title, r.months_ago + ' mois', ''];
                } else if (modal.section === 'engagement') {
                    line = [r.title, r.visits, r.ai_visits, fmtTime(r.avg_time), r.avg_scroll + '%'];
                }
                csvRows.push(line);
            });
            var csv = csvRows.map(function(row) {
                return row.map(function(c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(';');
            }).join('\n');
            var blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'hts-' + modal.section + '-' + new Date().toISOString().slice(0, 10) + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    });

    /* ══════════════════════════════════════════════════════════════
     *  CHART TOOLTIPS (delegated — works after re-render)
     * ══════════════════════════════════════════════════════════════ */

    function initChartTooltips() {
        var $tooltip = $('#hts-ana-chart-tooltip');
        if (!$tooltip.length) {
            $('body').append('<div id="hts-ana-chart-tooltip" style="position:fixed;z-index:999999;background:#1E293B;color:#fff;padding:8px 12px;border-radius:8px;font-size:11px;pointer-events:none;opacity:0;transition:opacity .15s;white-space:nowrap;box-shadow:0 4px 12px rgba(0,0,0,.2)"></div>');
            $tooltip = $('#hts-ana-chart-tooltip');
        }

        $(document).off('mouseenter.htsChart mouseleave.htsChart mousemove.htsChart')
            .on('mouseenter.htsChart', '.hts-ana-bar', function(e) {
                var day = $(this).data('day');
                var ai = $(this).data('ai');
                var google = $(this).data('google');
                var dateStr = formatDate(day);
                $tooltip.html(
                    '<div style="font-weight:700;margin-bottom:4px">' + dateStr + '</div>' +
                    '<div style="color:#93C5FD;display:flex;align-items:center;gap:4px">Google : ' + google + '</div>' +
                    '<div style="color:#A78BFA;margin-top:2px">IA : ' + ai + '</div>'
                );
                $tooltip.css({ opacity: 1, left: e.clientX + 12, top: e.clientY - 50 });
            })
            .on('mouseleave.htsChart', '.hts-ana-bar', function() {
                $tooltip.css('opacity', 0);
            })
            .on('mousemove.htsChart', '.hts-ana-bar', function(e) {
                $tooltip.css({ left: e.clientX + 12, top: e.clientY - 50 });
            });
    }

    /* ══════════════════════════════════════════════════════════════
     *  EXPORT CSV
     * ══════════════════════════════════════════════════════════════ */

    function bindExportCSV() {
        $(document).on('click', '#hts-ana-export-csv', function(e) {
            e.preventDefault();

            var data = cachedData[currentDays];
            if (!data || !data.daily || !data.daily.length) {
                alert('Aucune donn\u00e9e \u00e0 exporter pour cette p\u00e9riode.');
                return;
            }

            var rows = [['Date', 'Visites totales', 'Visites IA']];
            data.daily.forEach(function(dd) {
                rows.push([dd.day, dd.total, dd.ai]);
            });

            rows.push([]);
            rows.push(['R\u00e9sum\u00e9']);
            rows.push(['P\u00e9riode', currentDays + ' jours']);
            rows.push(['Total visites', data.engagement ? data.engagement.total : 0]);
            rows.push(['Total visites IA', data.ai_total || 0]);
            if (data.engagement) {
                rows.push(['Temps actif moyen', data.engagement.avg_time + 's']);
                rows.push(['Scroll moyen', data.engagement.avg_scroll + '%']);
                rows.push(['Taux de rebond', data.engagement.bounce_rate + '%']);
            }
            if (data.crawl) {
                rows.push(['Scans robots', data.crawl.total]);
            }

            var csv = rows.map(function(r) {
                return r.map(function(c) {
                    return '"' + String(c).replace(/"/g, '""') + '"';
                }).join(';');
            }).join('\n');

            var blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'hack-the-seo-analytics-' + currentDays + 'j-' + new Date().toISOString().slice(0, 10) + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }

    /* ══════════════════════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════════════════════ */

    function fmtTime(s) {
        s = parseInt(s, 10) || 0;
        if (s < 60) return s + 's';
        var m = Math.floor(s / 60);
        var sec = s % 60;
        return m + 'min' + (sec > 0 ? ' ' + sec + 's' : '');
    }

    function formatNumber(n) {
        return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }

    function esc(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str || ''));
        return div.innerHTML;
    }

    function truncate(str, len) {
        if (!str) return '';
        /* Decode HTML entities from backend titles (&#8211; → –) */
        if (str.indexOf('&') !== -1) {
            var ta = document.createElement('textarea');
            ta.innerHTML = str;
            str = ta.value;
        }
        return str.length > len ? str.substring(0, len) + '\u2026' : str;
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr + 'T00:00:00');
        var months = ['jan.', 'f\u00e9v.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'ao\u00fbt', 'sept.', 'oct.', 'nov.', 'd\u00e9c.'];
        return d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
    }

    /**
     * BleedSpark — JS equivalent of PHP hts_bleed_spark()
     * Full-width sparkline SVG that bleeds to card edges
     */
    function bleedSpark(data, color, h) {
        if (!data || data.length < 2) return '';
        h = h || 50;
        color = color || 'var(--hts-accent)';
        var W = 400;
        var pad = 6;
        var max = Math.max.apply(null, data);
        var min = Math.min.apply(null, data);
        var range = max - min || 1;
        var points = [];
        var count = data.length;
        data.forEach(function(v, i) {
            var x = (i / Math.max(count - 1, 1) * W).toFixed(1);
            var y = (pad + (1 - (v - min) / range) * (h - pad * 2)).toFixed(1);
            points.push(x + ',' + y);
        });
        var line = points.join(' ');
        var area = '0,' + h + ' ' + points.join(' ') + ' ' + W + ',' + h;
        var gid = 'bsjs-' + Math.random().toString(36).substr(2, 8);

        var out = '<div style="margin:0 -24px;overflow:hidden;border-radius:0 0 13px 13px;line-height:0">';
        out += '<svg width="100%" height="' + h + '" viewBox="0 0 ' + W + ' ' + h + '" preserveAspectRatio="none" style="display:block">';
        out += '<defs><linearGradient id="' + gid + '" x1="0" x2="0" y1="0" y2="' + h + '" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="' + color + '" stop-opacity=".2"/><stop offset="100%" stop-color="' + color + '" stop-opacity=".02"/></linearGradient></defs>';
        out += '<polygon points="' + area + '" fill="url(#' + gid + ')"/>';
        out += '<polyline points="' + line + '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
        out += '</svg></div>';
        return out;
    }

})(jQuery);
