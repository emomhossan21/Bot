<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Cocon Commander — Phase 6a
 *
 * Reçoit un cocon plan depuis app.hacktheseo, compare avec l'existant,
 * et commande les articles manquants.
 *
 * @package    Hack_The_SEO
 * @since      1.23.0
 */

if ( ! defined( 'WPINC' ) ) die;

class HTS_Cocon_Commander {

    /** Option key for stored cocon plans */
    const PLANS_OPTION = 'hts_cocon_plans';

    /** Statuses */
    const STATUS_TO_GENERATE = 'to_generate';
    const STATUS_PENDING_QUEUE = 'pending_queue';
    const STATUS_QUEUED      = 'queued';
    const STATUS_GENERATING  = 'generating';
    const STATUS_READY       = 'ready';
    const STATUS_RECEIVED    = 'received';
    const STATUS_DUPLICATE   = 'duplicate_warning';
    const STATUS_SIMILAR     = 'similar';
    const STATUS_SCHEDULED   = 'scheduled';
    const STATUS_PUBLISHED   = 'published';
    const STATUS_ERROR       = 'error';

    /* =========================================================================
     * CONSTANTS
     * ====================================================================== */

    const LOGS_OPTION = 'hts_cocon_logs';
    const LOGS_MAX    = 200;

    const CROSS_COCON_MIN_SIMILARITY = 0.35;
    const CROSS_COCON_MAX_OUT        = 2;
    const CROSS_COCON_MAX_IN         = 1;

    public function init() {
        // Phase 6a — Plan management
        add_action( 'wp_ajax_hts_cocon_plans',          array( $this, 'ajax_get_plans' ) );
        add_action( 'wp_ajax_hts_cocon_plan_detail',    array( $this, 'ajax_plan_detail' ) );
        add_action( 'wp_ajax_hts_cocon_order_article',  array( $this, 'ajax_order_article' ) );
        add_action( 'wp_ajax_hts_cocon_order_all',      array( $this, 'ajax_order_all' ) );
        add_action( 'wp_ajax_hts_cocon_check_status',   array( $this, 'ajax_check_status' ) );
        add_action( 'wp_ajax_hts_cocon_dismiss_article', array( $this, 'ajax_dismiss_article' ) );
        add_action( 'wp_ajax_hts_cocon_queue_articles',  array( $this, 'ajax_queue_articles' ) );
        add_action( 'wp_ajax_hts_cocon_reset_article',   array( $this, 'ajax_reset_article' ) );

        // Phase 6a+ — SaaS API flow (generate plan → poll → generate articles → create draft)
        add_action( 'wp_ajax_hts_cocon_generate_plan',   array( $this, 'ajax_generate_plan' ) );
        add_action( 'wp_ajax_hts_cocon_gen_plan',        array( $this, 'ajax_generate_plan' ) ); // JS alias
        add_action( 'wp_ajax_hts_cocon_poll_plan',       array( $this, 'ajax_poll_plan' ) );
        add_action( 'wp_ajax_hts_cocon_generate_article', array( $this, 'ajax_generate_article' ) );
        add_action( 'wp_ajax_hts_cocon_gen_article',     array( $this, 'ajax_generate_article' ) ); // JS alias
        add_action( 'wp_ajax_hts_cocon_poll_article',    array( $this, 'ajax_poll_article' ) );
        add_action( 'wp_ajax_hts_cocon_create_draft',    array( $this, 'ajax_create_draft' ) );
        add_action( 'wp_ajax_hts_cocon_delete_plan',     array( $this, 'ajax_delete_plan' ) );
        add_action( 'wp_ajax_hts_cocon_get_logs',        array( $this, 'ajax_cocon_get_logs' ) );
        add_action( 'wp_ajax_hts_cocon_save_linking_settings', array( $this, 'ajax_save_linking_settings' ) );

        // Session P — Batch cannibal recheck + plan summary
        add_action( 'wp_ajax_hts_cocon_batch_cannibal',  array( $this, 'ajax_batch_cannibal_check' ) );
        add_action( 'wp_ajax_hts_cocon_check_pillar',   array( $this, 'ajax_check_pillar_health' ) );
        add_action( 'wp_ajax_hts_cocon_plan_summary',    array( $this, 'ajax_plan_summary' ) );

        // Phase 6b — Auto-linking frères on publish
        add_action( 'transition_post_status', array( $this, 'on_post_publish' ), 20, 3 );
        // M3: Hook deferred pour maillage frères (évite timeout synchrone)
        add_action( 'hts_deferred_sibling_links', array( $this, 'auto_link_siblings' ), 10, 2 );

        // Phase 6b — Calendar AJAX
        add_action( 'wp_ajax_hts_calendar_articles',     array( $this, 'ajax_calendar_articles' ) );
        add_action( 'wp_ajax_hts_calendar_schedule',     array( $this, 'ajax_calendar_schedule' ) );

        // Phase 6d — Cross-Cocon Smart Linking (proposals only, client validates)
        add_action( 'wp_ajax_hts_cocon_cross_proposals',   array( $this, 'ajax_cross_cocon_proposals' ) );
        add_action( 'wp_ajax_hts_cocon_apply_cross_link',  array( $this, 'ajax_apply_cross_link' ) );
        add_action( 'wp_ajax_hts_cocon_rollback_cross_link', array( $this, 'ajax_rollback_cross_link' ) );
        add_action( 'wp_ajax_hts_cocon_dismiss_cross_link', array( $this, 'ajax_dismiss_cross_link' ) );

        // Phase 6d — Option toggle + manual scan
        add_action( 'wp_ajax_hts_save_option',               array( $this, 'ajax_save_option' ) );
        add_action( 'wp_ajax_hts_cocon_scan_cross_cocon',    array( $this, 'ajax_scan_cross_cocon' ) );

        // Bloc 2 — Embed pending + auto-analyze
        add_action( 'wp_ajax_hts_cocon_embed_pending', array( $this, 'ajax_embed_pending' ) );

        // Bloc 2 — Rescan maillage (re-run auto_link_siblings on all published articles of a cocon)
        add_action( 'wp_ajax_hts_cocon_rescan_maillage', array( $this, 'ajax_rescan_maillage' ) );

        // Sprint 6.2d — Auto-link siblings when _hts_cocon_id is assigned to an already-published post
        add_action( 'updated_post_meta', array( $this, 'on_cocon_id_changed' ), 10, 4 );
        add_action( 'added_post_meta',   array( $this, 'on_cocon_id_changed' ), 10, 4 );

        // Bloc 4 — Image settings
        add_action( 'wp_ajax_hts_cocon_get_image_settings', array( $this, 'ajax_get_image_settings' ) );

        // Image generation for a specific post
        add_action( 'wp_ajax_hts_cocon_generate_post_images', array( $this, 'ajax_generate_post_images' ) );
        add_action( 'wp_ajax_hts_cocon_check_images_status', array( $this, 'ajax_check_images_status' ) );
        add_action( 'wp_ajax_hts_cocon_get_recommended_links', array( $this, 'ajax_get_recommended_links' ) );

        // Sprint 6.2a — Money page cocons historiques
        add_action( 'wp_ajax_hts_build_money_cocon',    array( $this, 'ajax_build_money_cocon' ) );
        add_action( 'wp_ajax_hts_confirm_money_cocon',  array( $this, 'ajax_confirm_money_cocon' ) );
        add_action( 'wp_ajax_hts_apply_money_maillage', array( $this, 'ajax_apply_money_maillage' ) );
        add_action( 'wp_ajax_hts_auto_money_cocons',    array( $this, 'ajax_auto_money_cocons' ) );
        add_action( 'wp_ajax_hts_auto_cocons_init',     array( $this, 'ajax_auto_cocons_init' ) );
        add_action( 'wp_ajax_hts_auto_cocons_step',     array( $this, 'ajax_auto_cocons_step' ) );
        add_action( 'wp_ajax_hts_cocon_rescan_init',    array( $this, 'ajax_cocon_rescan_init' ) );
        add_action( 'wp_ajax_hts_cocon_rescan_step',    array( $this, 'ajax_cocon_rescan_step' ) );
        add_action( 'wp_ajax_hts_cocon_link_cluster', array( $this, 'ajax_link_single_cluster' ) );
        add_action( 'wp_ajax_hts_discover_money_pages', array( $this, 'ajax_discover_money_pages' ) );
        add_action( 'wp_ajax_hts_discover_money_init', array( $this, 'ajax_discover_money_init' ) );
        add_action( 'wp_ajax_hts_discover_money_step', array( $this, 'ajax_discover_money_step' ) );
        add_action( 'wp_ajax_hts_dismiss_money_page',   array( $this, 'ajax_dismiss_money_page' ) );
        add_action( 'wp_ajax_hts_dismiss_suggestion',  array( $this, 'ajax_dismiss_suggestion' ) );
        add_action( 'wp_ajax_hts_cocon_accept_suggestion', array( $this, 'ajax_accept_suggestion' ) );
        add_action( 'wp_ajax_hts_restore_money_page',   array( $this, 'ajax_restore_money_page' ) );
        add_action( 'wp_ajax_hts_search_pages_for_money', array( $this, 'ajax_search_pages_for_money' ) );
        add_action( 'wp_ajax_hts_add_manual_money_page',  array( $this, 'ajax_add_manual_money_page' ) );
        add_action( 'wp_ajax_hts_reset_cocon_data',        array( $this, 'ajax_reset_cocon_data' ) );

        // ── Recovery cron: rescue abandoned article jobs (client closed browser mid-generation) ──
        add_action( 'hts_cocon_recover_abandoned_jobs', array( $this, 'cron_recover_abandoned_jobs' ) );
        if ( ! wp_next_scheduled( 'hts_cocon_recover_abandoned_jobs' ) ) {
            wp_schedule_event( time() + 300, 'hts_15min', 'hts_cocon_recover_abandoned_jobs' );
        }
        add_filter( 'cron_schedules', function( $s ) {
            $s['hts_15min'] = array( 'interval' => 900, 'display' => 'Every 15 minutes (HTS)' );
            return $s;
        } );
    }

    /* =========================================================================
     * HELPER — Load cocon NLP data (multilingual-aware)
     * ====================================================================== */

    /**
     * Load hts_cocon_data from the correct option key, handling multilingual sites.
     * Uses HTS_Cocon::get_cached_cocon_data() if available, otherwise handles manually.
     *
     * @return array  Cocon data with 'clusters', 'nodes', 'stats', etc.
     */
    private static function load_cocon_data() {
        // Best path: use HTS_Cocon's method which handles caching + multilingual + exclusions
        if ( class_exists( 'HTS_Cocon' ) && method_exists( 'HTS_Cocon', 'get_cached_cocon_data' ) ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            // fix7: in AJAX context Polylang may return 'all' — normalize to ''
            if ( $lang === 'all' ) $lang = '';
            $data = \HTS_Cocon::get_cached_cocon_data( $lang );
            if ( ! empty( $data['clusters'] ) ) return self::sanitize_cluster_pillars( $data );
            // fix7: if language-specific data has no clusters, try without language
            if ( $lang && empty( $data['clusters'] ) ) {
                $data = \HTS_Cocon::get_cached_cocon_data( '' );
                if ( ! empty( $data['clusters'] ) ) return self::sanitize_cluster_pillars( $data );
            }
        }

        // Fallback: try multilingual option key
        if ( class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
            if ( $lang && $lang !== 'all' ) {
                $data = get_option( 'hts_cocon_data_' . $lang, array() );
                if ( ! empty( $data['clusters'] ) ) return self::sanitize_cluster_pillars( $data );
            }
        }

        // Final fallback: default key
        $data = get_option( 'hts_cocon_data', array() );

        // Sprint 6.2d: enforce 1 pillar max per cluster
        return self::sanitize_cluster_pillars( $data );
    }

    /**
     * Ensure each cluster has at most 1 pillar.
     * If multiple pages are flagged as pillar, keep the one with most inbound links.
     *
     * @since 2.5.0
     * @param array $data Cocon data with 'clusters' key
     * @return array Sanitized cocon data
     */
    private static function sanitize_cluster_pillars( $data ) {
        if ( empty( $data['clusters'] ) || ! is_array( $data['clusters'] ) ) return $data;

        // Sprint 6.2d fix: cache sanitized result per request to avoid log spam
        // and repeated get_post_meta calls on every load_cocon_data()
        static $cache = array( 'hash' => '', 'data' => null );
        $current_hash = md5( wp_json_encode( array_map( function( $cl ) {
            return array( 'pages' => $cl['pages'] ?? array(), 'pillar_id' => $cl['pillar_id'] ?? 0 );
        }, $data['clusters'] ) ) );
        if ( $cache['hash'] === $current_hash && $cache['data'] !== null ) {
            return $cache['data'];
        }

        foreach ( $data['clusters'] as $cname => &$cl ) {
            $pages = array_map( 'intval', $cl['pages'] ?? array() );
            if ( empty( $pages ) ) continue;

            // Find all pages flagged as pillar in this cluster
            $pillar_candidates = array();
            foreach ( $pages as $pid ) {
                $is_pillar = false;
                // Check node role
                if ( ! empty( $data['nodes'][ $pid ]['role'] ) && $data['nodes'][ $pid ]['role'] === 'pilier' ) {
                    $is_pillar = true;
                }
                if ( ! empty( $data['nodes'][ $pid ]['is_pillar'] ) ) {
                    $is_pillar = true;
                }
                if ( $is_pillar ) {
                    $pillar_candidates[] = $pid;
                }
            }

            // Also consider existing pillar_id
            $current_pillar = (int) ( $cl['pillar_id'] ?? 0 );
            if ( $current_pillar > 0 && ! in_array( $current_pillar, $pillar_candidates, true ) ) {
                $pillar_candidates[] = $current_pillar;
            }

            if ( count( $pillar_candidates ) > 1 ) {
                // Keep the one with most inbound links
                usort( $pillar_candidates, function( $a, $b ) {
                    $a_in = (int) get_post_meta( $a, '_hts_internal_links_in', true );
                    $b_in = (int) get_post_meta( $b, '_hts_internal_links_in', true );
                    return $b_in - $a_in;
                });
                $cl['pillar_id'] = $pillar_candidates[0];

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Cluster « %s » avait %d piliers — gardé #%d (plus de liens entrants)',
                            mb_substr( $cname, 0, 40 ), count( $pillar_candidates ), $pillar_candidates[0] ),
                        'warn', 'cocon-commander'
                    );
                }

                // Demote others in nodes
                for ( $i = 1; $i < count( $pillar_candidates ); $i++ ) {
                    $demoted = $pillar_candidates[ $i ];
                    if ( isset( $data['nodes'][ $demoted ]['role'] ) ) {
                        $data['nodes'][ $demoted ]['role'] = 'enfant';
                    }
                    if ( isset( $data['nodes'][ $demoted ]['is_pillar'] ) ) {
                        $data['nodes'][ $demoted ]['is_pillar'] = false;
                    }
                }
            }
        }
        unset( $cl );

        // Store in static cache
        $cache['hash'] = $current_hash;
        $cache['data'] = $data;

        return $data;
    }

    /* =========================================================================
     * API HELPER — Calls app.hacktheseo.com/api/v1/cocon/*
     * ====================================================================== */

    /**
     * Call the Hack The SEO SaaS cocon API.
     *
     * @param string $method  GET or POST
     * @param string $endpoint  e.g. 'generate-plan', 'plan-status/123'
     * @param array  $body  Payload for POST requests
     * @return array { success, status, data, error }
     */
    private function cocon_api_call( $method, $endpoint, $body = array() ) {
        $api_key = get_option( 'hts_api_key', '' );
        $base    = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ) . '/api/v1/cocon';
        $url     = $base . '/' . ltrim( $endpoint, '/' );

        // ── DIAG: log every API call ──
        hts_add_log( sprintf( 'API CALL %s /%s → %s (key=%s...)', $method, $endpoint, $url, substr( $api_key, 0, 10 ) ), 'info', 'cocon-api' );
        self::cocon_log( 'api_call', $method . ' /' . $endpoint, array( 'url' => $url, 'key_prefix' => substr( $api_key, 0, 10 ), 'base' => $base ) );

        $args = array(
            'timeout' => 120,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'X-API-KEY'    => $api_key,
            ),
        );

        if ( $method === 'POST' ) {
            $args['method'] = 'POST';
            $args['body']   = wp_json_encode( $body );
            $response = wp_remote_post( $url, $args );
        } else {
            $response = wp_remote_get( $url, $args );
        }

        if ( is_wp_error( $response ) ) {
            $err = $response->get_error_message();
            hts_add_log( 'API ERROR /' . $endpoint . ' → WP_Error: ' . $err, 'error', 'cocon-api' );
            self::cocon_log( 'api_error_raw', 'WP_Error: ' . $err, array( 'url' => $url, 'endpoint' => $endpoint ) );
            return array( 'success' => false, 'error' => $err, 'status' => 0, 'data' => null );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        // ── DIAG: log response ──
        hts_add_log( sprintf( 'API RESP /%s → HTTP %d (%d chars)', $endpoint, $code, strlen( $raw ) ), $code >= 400 ? 'error' : 'info', 'cocon-api' );
        self::cocon_log( $code >= 400 ? 'api_error_raw' : 'api_response', $method . ' /' . $endpoint . ' → HTTP ' . $code, array(
            'url'       => $url,
            'http'      => $code,
            'raw_first' => mb_substr( $raw, 0, 300 ),
            'data_keys' => is_array( $data ) ? array_keys( $data ) : 'not_json',
        ) );

        return array(
            'success' => $code >= 200 && $code < 300,
            'status'  => $code,
            'data'    => $data,
            'error'   => $code >= 400 ? ( $data['message'] ?? $data['error'] ?? 'HTTP ' . $code ) : null,
        );
    }

    /**
     * Public wrapper pour cocon_api_call — utilisé par Auto-Write (Phase 5).
     *
     * @since 1.34.0
     * @param string $method   'GET' or 'POST'
     * @param string $endpoint API endpoint
     * @param array  $body     Request body
     * @return array { success, status, data, error }
     */
    public function cocon_api_call_public( $method, $endpoint, $body = array() ) {
        return $this->cocon_api_call( $method, $endpoint, $body );
    }

    /* =========================================================================
     * PLAN STORAGE
     * ====================================================================== */

    /**
     * Get all stored cocon plans.
     *
     * @return array [ cocon_id => plan_data ]
     */
    public function get_plans() {
        return get_option( self::PLANS_OPTION, array() );
    }

    /**
     * Get a single plan by cocon_id.
     *
     * @param string $cocon_id
     * @return array|null
     */
    public function get_plan( $cocon_id ) {
        $plans = $this->get_plans();
        return $plans[ $cocon_id ] ?? null;
    }

    /**
     * Save/update a cocon plan received from SaaS.
     *
     * Merges articles: existing articles keep their status,
     * new articles are added as to_generate.
     *
     * @param array $data Payload from SaaS
     * @return array Saved plan
     */
    public function save_plan( array $data ) {
        $cocon_id     = sanitize_text_field( $data['cocon_id'] ?? '' );
        $pillar_url   = esc_url_raw( $data['pillar_url'] ?? '' );
        $pillar_title = sanitize_text_field( $data['pillar_title'] ?? '' );
        $articles_raw = $data['articles'] ?? array();

        if ( empty( $cocon_id ) ) {
            throw new \Exception( 'cocon_id manquant dans le plan.' );
        }

        $plans = $this->get_plans();
        $existing_plan = $plans[ $cocon_id ] ?? null;

        // Build article list with pre-check
        $articles = array();
        foreach ( $articles_raw as $art ) {
            $keyword = sanitize_text_field( $art['keyword'] ?? '' );
            if ( empty( $keyword ) ) continue;

            $article_key = md5( $keyword );

            // Keep existing status if already tracked
            $existing_status = null;
            if ( $existing_plan && isset( $existing_plan['articles'][ $article_key ] ) ) {
                $existing_status = $existing_plan['articles'][ $article_key ]['status'];
            }

            $precheck = $this->precheck_article( $keyword, $pillar_url, true );

            $articles[ $article_key ] = array(
                'keyword'    => $keyword,
                'topic'      => sanitize_text_field( $art['topic'] ?? '' ),
                'intent'     => sanitize_text_field( $art['intent'] ?? 'info' ),
                'category'   => sanitize_text_field( $art['category'] ?? '' ),
                'status'     => $existing_status ?? ( $precheck['result'] === 'original' ? self::STATUS_TO_GENERATE : $precheck['result'] ),
                'precheck'   => $precheck,
                'post_id'    => $existing_plan['articles'][ $article_key ]['post_id'] ?? null,
                'ordered_at' => $existing_plan['articles'][ $article_key ]['ordered_at'] ?? null,
            );
        }

        // ── Atomic write lock (Sprint Robustesse: wp_options-based, reliable with any object cache) ──
        if ( ! hts_acquire_lock( 'plans_write', 5, 10, 150 ) ) {
            throw new \Exception( 'Plans write lock timeout — opération abandonnée. Réessayez.' );
        }

        $plan = array(
            'cocon_id'      => $cocon_id,
            'pillar_url'    => $pillar_url,
            'pillar_title'  => $pillar_title,
            'articles'      => $articles,
            'received_at'   => current_time( 'Y-m-d H:i:s' ),
            'updated_at'    => current_time( 'Y-m-d H:i:s' ),
            'article_count' => count( $articles ),
        );

        // Preserve fields from the existing plan stub (set by ajax_generate_plan)
        if ( $existing_plan ) {
            $preserve_keys = array( 'keyword', 'language', 'articles_gen', 'status' );
            foreach ( $preserve_keys as $pk ) {
                if ( isset( $existing_plan[ $pk ] ) && ! isset( $plan[ $pk ] ) ) {
                    $plan[ $pk ] = $existing_plan[ $pk ];
                }
            }
        }
        // Also accept keyword/language from SaaS payload if present
        if ( ! empty( $data['keyword'] ) && empty( $plan['keyword'] ) ) {
            $plan['keyword'] = sanitize_text_field( $data['keyword'] );
        }
        if ( ! empty( $data['language'] ) && empty( $plan['language'] ) ) {
            $plan['language'] = sanitize_text_field( $data['language'] );
        }

        $plans[ $cocon_id ] = $plan;
        update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );

        hts_release_lock( 'plans_write' );

        hts_add_log(
            sprintf( '📋 Plan cocon reçu : %s — %d articles (%s)', $pillar_title ?: $cocon_id, count( $articles ), $cocon_id ),
            'success', 'cocon-commander'
        );

        return $plan;
    }

    /**
     * Update a single article status in a plan.
     *
     * @param string $cocon_id
     * @param string $article_key md5(keyword)
     * @param string $new_status
     * @param array  $extra_data Optional extra fields to merge
     */
    public function update_article_status( $cocon_id, $article_key, $new_status, $extra_data = array() ) {
        // ── Atomic write lock (Sprint Robustesse: wp_options-based) ──
        if ( ! hts_acquire_lock( 'plans_write', 5, 10, 150 ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Write lock timeout pour update_article_status ' . $cocon_id . '/' . $article_key, 'warning', 'cocon-commander' );
            }
            return false;
        }

        $plans = $this->get_plans();
        if ( ! isset( $plans[ $cocon_id ]['articles'][ $article_key ] ) ) {
            hts_release_lock( 'plans_write' );
            return false;
        }

        $plans[ $cocon_id ]['articles'][ $article_key ]['status'] = $new_status;
        foreach ( $extra_data as $k => $v ) {
            $plans[ $cocon_id ]['articles'][ $article_key ][ $k ] = $v;
        }
        $plans[ $cocon_id ]['updated_at'] = current_time( 'Y-m-d H:i:s' );
        update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );

        hts_release_lock( 'plans_write' );
        return true;
    }

    /* =========================================================================
     * PRE-CHECK DOUBLONS — Phase 6a.2
     *
     * Compare planned article keyword against existing site content.
     * 3 levels: titre exact, keyword Jaccard, embeddings cosine.
     * ====================================================================== */

    /**
     * Pre-check an article keyword against existing content.
     *
     * @param string $keyword
     * @param string $pillar_url (excluded from duplicate check)
     * @param bool   $quick_mode Skip embeddings check (for bulk operations)
     * @return array { result: original|duplicate_warning|similar, matches: [...] }
     */
    public function precheck_article( $keyword, $pillar_url = '', $quick_mode = false ) {
        $matches = array();

        // ── 1. Exact title match ──
        $exact = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => array( 'publish', 'draft', 'future' ),
            'title'          => $keyword,
            'posts_per_page' => 5,
        ) );
        foreach ( $exact as $p ) {
            if ( $pillar_url && untrailingslashit( get_permalink( $p->ID ) ) === untrailingslashit( $pillar_url ) ) continue;
            $matches[] = array(
                'post_id'    => $p->ID,
                'title'      => $p->post_title,
                'url'        => get_permalink( $p->ID ),
                'method'     => 'title_exact',
                'similarity' => 1.0,
            );
        }

        // ── 2. Keyword similarity (Jaccard on keywords + title words) ──
        if ( class_exists( 'HTS_Cocon' ) ) {
            $kw_words = explode( ' ', mb_strtolower( trim( $keyword ) ) );
            $search_posts = get_posts( array(
                'post_type'      => array( 'post', 'page' ),
                'post_status'    => array( 'publish', 'draft', 'future' ),
                's'              => $keyword,
                'posts_per_page' => 30,
            ) );

            foreach ( $search_posts as $p ) {
                if ( $pillar_url && untrailingslashit( get_permalink( $p->ID ) ) === untrailingslashit( $pillar_url ) ) continue;
                $already = false;
                foreach ( $matches as $m ) { if ( $m['post_id'] === $p->ID ) { $already = true; break; } }
                if ( $already ) continue;

                // Compare new keyword vs existing title
                $title_words = explode( ' ', mb_strtolower( $p->post_title ) );
                $sim_title = $this->jaccard_similarity( $kw_words, $title_words );

                // Compare new keyword vs existing keyword (meta)
                $existing_kw = get_post_meta( $p->ID, '_hts_focus_keyword', true );
                if ( empty( $existing_kw ) ) $existing_kw = get_post_meta( $p->ID, '_hts_api_keyword', true );
                $sim_kw = 0;
                if ( ! empty( $existing_kw ) ) {
                    $existing_kw_words = explode( ' ', mb_strtolower( trim( $existing_kw ) ) );
                    $sim_kw = $this->jaccard_similarity( $kw_words, $existing_kw_words );
                }

                // Take the best match
                $best_sim = max( $sim_title, $sim_kw );
                $best_method = $sim_kw >= $sim_title ? 'keyword_vs_keyword' : 'keyword_vs_title';

                if ( $best_sim >= 0.50 ) {
                    $matches[] = array(
                        'post_id'    => $p->ID,
                        'title'      => $p->post_title,
                        'url'        => get_permalink( $p->ID ),
                        'method'     => $best_method,
                        'similarity' => round( $best_sim, 3 ),
                    );
                }
            }
        }

        // ── 3. Embeddings cosine similarity (skip in quick_mode or if already found exact match) ──
        if ( ! $quick_mode && empty( $matches ) && class_exists( 'HTS_Embeddings' ) ) {
            $emb = new HTS_Embeddings();
            $vectors = $emb->load_all_vectors( true );

            if ( ! empty( $vectors ) ) {
                // Generate a temporary embedding for the keyword
                $kw_vector = $emb->get_embedding( $keyword );

                if ( $kw_vector ) {
                    foreach ( $vectors as $pid => $vec ) {
                        if ( $pillar_url ) {
                            $purl = get_permalink( $pid );
                            if ( untrailingslashit( $purl ) === untrailingslashit( $pillar_url ) ) continue;
                        }
                        // Skip if already matched
                        $already = false;
                        foreach ( $matches as $m ) { if ( $m['post_id'] === $pid ) { $already = true; break; } }
                        if ( $already ) continue;

                        $sim = HTS_Embeddings::cosine_similarity( $kw_vector, $vec );
                        if ( $sim >= 0.50 && $sim < 0.80 ) {
                            $matches[] = array(
                                'post_id'    => $pid,
                                'title'      => get_the_title( $pid ),
                                'url'        => get_permalink( $pid ),
                                'method'     => 'embeddings_cosine',
                                'similarity' => round( $sim, 3 ),
                            );
                        } elseif ( $sim >= 0.80 ) {
                            $matches[] = array(
                                'post_id'    => $pid,
                                'title'      => get_the_title( $pid ),
                                'url'        => get_permalink( $pid ),
                                'method'     => 'embeddings_cosine',
                                'similarity' => round( $sim, 3 ),
                            );
                        }
                    }
                }
            }
        }

        // ── Determine result ──
        $has_exact = false;
        $has_high  = false;
        $has_similar = false;

        foreach ( $matches as $m ) {
            if ( $m['method'] === 'title_exact' || $m['similarity'] >= 0.80 ) {
                $has_exact = true;
            } elseif ( $m['similarity'] >= 0.50 ) {
                $has_similar = true;
            }
        }

        if ( $has_exact ) {
            $result = self::STATUS_DUPLICATE;
        } elseif ( $has_similar ) {
            $result = self::STATUS_SIMILAR;
        } else {
            $result = 'original';
        }

        return array(
            'result'  => $result,
            'matches' => $matches,
        );
    }

    /**
     * Jaccard similarity between two word arrays.
     */
    private function jaccard_similarity( array $a, array $b ) {
        $sa = array_flip( $a );
        $sb = array_flip( $b );
        $inter = count( array_intersect_key( $sa, $sb ) );
        $union = count( $sa ) + count( $sb ) - $inter;
        return $union > 0 ? $inter / $union : 0;
    }

    /* =========================================================================
     * COMMANDER — Phase 6a.3
     *
     * Send article generation orders to app.hacktheseo.
     * ====================================================================== */

    /**
     * Send a single article order to the SaaS.
     *
     * @param string $cocon_id
     * @param string $article_key
     * @return array|WP_Error
     */
    public function send_order( $cocon_id, $article_key ) {
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) return new \WP_Error( 'no_plan', 'Plan cocon introuvable.' );

        $article = $plan['articles'][ $article_key ] ?? null;
        if ( ! $article ) return new \WP_Error( 'no_article', 'Article introuvable dans le plan.' );

        if ( ! in_array( $article['status'], array( self::STATUS_TO_GENERATE, self::STATUS_SIMILAR ), true ) ) {
            return new \WP_Error( 'wrong_status', 'Cet article n\'est pas en attente de génération (statut: ' . $article['status'] . ').' );
        }

        // Build context: existing siblings for better article generation
        $siblings = $this->get_existing_siblings( $cocon_id );

        $base_url = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
        $api_key  = get_option( 'hts_api_key', '' );

        if ( empty( $api_key ) ) {
            return new \WP_Error( 'no_api_key', 'Clé API non configurée.' );
        }

        $payload = array(
            'keyword'           => $article['keyword'],
            'topic'             => $article['topic'],
            'intent'            => $article['intent'],
            'category'          => $article['category'],
            'cocon_id'          => $cocon_id,
            'pillar_url'        => $plan['pillar_url'],
            'pillar_title'      => $plan['pillar_title'],
            'siblings'          => $siblings,
            'recommended_links' => $this->get_recommended_links( $cocon_id ),
            'site_url'          => home_url(),
            'lang'              => class_exists( 'HTS_Language' ) ? HTS_Language::get_site_default_lang() : 'fr',
        );

        $response = wp_remote_post( $base_url . '/api/v1/cocon/generate-article', array(
            'headers'  => array(
                'Content-Type' => 'application/json',
                'x-api-key'   => $api_key,
                'Accept'       => 'application/json',
            ),
            'body'     => wp_json_encode( $payload ),
            'timeout'  => 120,
        ) );

        if ( is_wp_error( $response ) ) {
            hts_add_log( 'Commande article échouée: ' . $response->get_error_message(), 'error', 'cocon-commander' );
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            $msg = 'Réponse API invalide (JSON: ' . json_last_error_msg() . ')';
            hts_add_log( '' . $msg, 'error', 'cocon-commander' );
            return new \WP_Error( 'json_error', $msg );
        }

        if ( $code >= 400 ) {
            $msg = $body['message'] ?? 'Erreur serveur (code ' . $code . ')';
            hts_add_log( 'Commande article refusée: ' . $msg, 'error', 'cocon-commander' );
            return new \WP_Error( 'api_error', $msg );
        }

        // Update status to queued
        $this->update_article_status( $cocon_id, $article_key, self::STATUS_QUEUED, array(
            'ordered_at'   => current_time( 'Y-m-d H:i:s' ),
            'saas_task_id' => $body['task_id'] ?? null,
        ) );

        hts_add_log(
            sprintf( '📤 Article commandé : "%s" (cocon: %s)', $article['keyword'], $cocon_id ),
            'success', 'cocon-commander'
        );

        return array(
            'status'  => 'queued',
            'keyword' => $article['keyword'],
            'task_id' => $body['task_id'] ?? null,
        );
    }

    /**
     * Send orders for all to_generate articles in a plan.
     *
     * @param string $cocon_id
     * @return array Results per article
     */
    public function send_all_orders( $cocon_id ) {
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) return array( 'error' => 'Plan introuvable' );

        $results = array();
        foreach ( $plan['articles'] as $key => $art ) {
            if ( $art['status'] === self::STATUS_TO_GENERATE ) {
                $res = $this->send_order( $cocon_id, $key );
                $results[ $key ] = is_wp_error( $res )
                    ? array( 'error' => $res->get_error_message() )
                    : $res;

                // Small delay between requests to avoid rate limiting
                usleep( 200000 ); // 200ms
            }
        }

        return $results;
    }

    /**
     * Check article generation status from SaaS.
     *
     * @param string $cocon_id
     * @param string $article_key
     * @return array|WP_Error
     */
    public function check_article_status( $cocon_id, $article_key ) {
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) return new \WP_Error( 'no_plan', 'Plan introuvable.' );

        $article = $plan['articles'][ $article_key ] ?? null;
        if ( ! $article ) return new \WP_Error( 'no_article', 'Article introuvable.' );

        $task_id = $article['saas_task_id'] ?? null;
        if ( ! $task_id ) {
            return array( 'status' => $article['status'] );
        }

        $base_url = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
        $api_key  = get_option( 'hts_api_key', '' );

        $response = wp_remote_get( $base_url . '/api/v1/cocon/article-status/' . $task_id, array(
            'headers' => array(
                'x-api-key' => $api_key,
                'Accept'    => 'application/json',
            ),
            'timeout' => 15,
        ) );

        if ( is_wp_error( $response ) ) return $response;

        $http_code = wp_remote_retrieve_response_code( $response );
        if ( $http_code < 200 || $http_code >= 300 ) {
            return new \WP_Error( 'http_error', 'Poll article: HTTP ' . $http_code );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new \WP_Error( 'json_error', 'Réponse poll JSON invalide: ' . json_last_error_msg() );
        }
        $new_status = $body['status'] ?? $article['status'];

        // Map SaaS status to local
        $status_map = array(
            'pending'    => self::STATUS_QUEUED,
            'processing' => self::STATUS_GENERATING,
            'completed'  => self::STATUS_READY,
            'failed'     => self::STATUS_TO_GENERATE, // Allow retry
        );
        $local_status = $status_map[ $new_status ] ?? $article['status'];

        if ( $local_status !== $article['status'] ) {
            $this->update_article_status( $cocon_id, $article_key, $local_status );
        }

        return array(
            'status'    => $local_status,
            'saas_status' => $new_status,
            'keyword'   => $article['keyword'],
        );
    }

    /**
     * Get existing siblings for a cocon (for generation context).
     *
     * @param string $cocon_id
     * @return array
     */
    public function get_existing_siblings( $cocon_id ) {
        $siblings = array();
        // Only published posts: the API uses these URLs for internal links.
        // Linking to drafts produces dead links on the public site.
        $posts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'meta_key'       => '_hts_cocon_id',
            'meta_value'     => $cocon_id,
            'posts_per_page' => 50,
        ) );

        foreach ( $posts as $p ) {
            $siblings[] = array(
                'post_id' => $p->ID,
                'title'   => $p->post_title,
                'url'     => get_permalink( $p->ID ),
                'keyword' => get_post_meta( $p->ID, '_hts_focus_keyword', true ),
            );
        }

        return $siblings;
    }

    /**
     * Get recommended internal links for an article being generated.
     *
     * Pulls pending/lost link suggestions from the Cocon analysis
     * so the SaaS can weave them into the generated article content.
     *
     * Returns outbound links: pages the new article should link TO.
     *
     * @param string $cocon_id
     * @return array [ { url, title, keyword, anchor_text } ]
     */
    public function get_recommended_links( $cocon_id ) {
        if ( ! class_exists( 'HTS_Cocon' ) ) return array();

        $cocon = new \HTS_Cocon();

        // Find cluster for this cocon
        $plan = $this->get_plan( $cocon_id );
        $pillar_url     = $plan['pillar_url'] ?? '';
        $pillar_post_id = $pillar_url ? hts_url_to_postid( $pillar_url ) : 0;

        $cocon_data   = $cocon->get_cocon_data();
        $cluster_name = '';

        if ( $pillar_post_id && ! empty( $cocon_data['nodes'][ $pillar_post_id ] ) ) {
            $cluster_name = $cocon_data['nodes'][ $pillar_post_id ]['cluster'] ?? '';
        }

        // Fallback: find cluster from any sibling
        if ( empty( $cluster_name ) ) {
            $sib = get_posts( array(
                'post_type'      => array( 'post', 'page' ),
                'post_status'    => 'publish',
                'meta_key'       => '_hts_cocon_id',
                'meta_value'     => $cocon_id,
                'posts_per_page' => 1,
            ) );
            if ( ! empty( $sib ) && ! empty( $cocon_data['nodes'][ $sib[0]->ID ] ) ) {
                $cluster_name = $cocon_data['nodes'][ $sib[0]->ID ]['cluster'] ?? '';
            }
        }

        if ( empty( $cluster_name ) ) return array();

        // Get suggestions for this cluster
        $sug_data    = $cocon->suggest_cluster_links( $cluster_name );
        $suggestions = $sug_data['suggestions'] ?? array();
        if ( empty( $suggestions ) ) return array();

        // Collect cocon sibling IDs
        $sibling_ids = array();
        $posts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'meta_key'       => '_hts_cocon_id',
            'meta_value'     => $cocon_id,
            'posts_per_page' => 50,
        ) );
        foreach ( $posts as $p ) {
            $sibling_ids[] = $p->ID;
        }
        if ( $pillar_post_id ) $sibling_ids[] = $pillar_post_id;
        $sibling_set = array_flip( array_unique( $sibling_ids ) );

        // Keep pending/lost suggestions targeting sibling pages
        $nodes       = $cocon_data['nodes'] ?? array();
        $recommended = array();
        $seen_urls   = array();

        foreach ( $suggestions as $sug ) {
            if ( ! in_array( $sug['state'] ?? '', array( 'pending', 'lost' ), true ) ) continue;

            $target_id = (int) ( $sug['target_id'] ?? 0 );
            if ( ! isset( $sibling_set[ $target_id ] ) ) continue;

            $url = get_permalink( $target_id );
            if ( isset( $seen_urls[ $url ] ) ) continue;
            $seen_urls[ $url ] = true;

            $recommended[] = array(
                'url'         => $url,
                'title'       => $nodes[ $target_id ]['title'] ?? get_the_title( $target_id ),
                'keyword'     => get_post_meta( $target_id, '_hts_focus_keyword', true ),
                'anchor_text' => $sug['anchor_text'] ?? '',
            );
        }

        // Sort by score and limit to 10
        return array_slice( $recommended, 0, 10 );
    }

    /**
     * Mark an article as received (called when API Receiver gets an article with matching cocon_id).
     *
     * @param string $cocon_id
     * @param string $keyword
     * @param int    $post_id
     */
    public function mark_received( $cocon_id, $keyword, $post_id ) {
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) return;

        $article_key = md5( $keyword );
        if ( ! isset( $plan['articles'][ $article_key ] ) ) {
            // Try fuzzy match on keyword
            foreach ( $plan['articles'] as $key => $art ) {
                if ( mb_strtolower( trim( $art['keyword'] ) ) === mb_strtolower( trim( $keyword ) ) ) {
                    $article_key = $key;
                    break;
                }
            }
        }

        if ( isset( $plan['articles'][ $article_key ] ) ) {
            $this->update_article_status( $cocon_id, $article_key, self::STATUS_RECEIVED, array(
                'post_id'     => $post_id,
                'received_at' => current_time( 'Y-m-d H:i:s' ),
            ) );

            hts_add_log(
                sprintf( 'Article reçu et associé au plan : "%s" → post #%d', $keyword, $post_id ),
                'success', 'cocon-commander'
            );
        }
    }

    /**
     * Get plan summary stats.
     *
     * @param string $cocon_id
     * @return array
     */
    public function get_plan_stats( $cocon_id, $plan_data = null ) {
        $plan = $plan_data ?? $this->get_plan( $cocon_id );
        if ( ! $plan ) return array();

        $stats = array(
            'total'         => 0,
            'to_generate'   => 0,
            'pending_queue' => 0,
            'queued'        => 0,
            'generating'    => 0,
            'ready'         => 0,
            'received'      => 0,
            'scheduled'     => 0,
            'published'     => 0,
            'duplicate'     => 0,
            'similar'       => 0,
            'error'         => 0,
        );

        foreach ( $plan['articles'] as $art ) {
            $stats['total']++;
            switch ( $art['status'] ) {
                case self::STATUS_TO_GENERATE:   $stats['to_generate']++; break;
                case self::STATUS_PENDING_QUEUE:  $stats['pending_queue']++; break;
                case self::STATUS_QUEUED:         $stats['queued']++; break;
                case self::STATUS_GENERATING:     $stats['generating']++; break;
                case self::STATUS_READY:          $stats['ready']++; break;
                case self::STATUS_RECEIVED:       $stats['received']++; break;
                case self::STATUS_SCHEDULED:      $stats['scheduled']++; break;
                case self::STATUS_PUBLISHED:      $stats['published']++; break;
                case self::STATUS_DUPLICATE:      $stats['duplicate']++; break;
                case self::STATUS_SIMILAR:        $stats['similar']++; break;
                case self::STATUS_ERROR:          $stats['error']++; break;
            }
        }

        return $stats;
    }

    /* =========================================================================
     * AJAX HANDLERS
     * ====================================================================== */

    public function ajax_get_plans() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(1);
        $plans = $this->get_plans();
        $summary = array();
        foreach ( $plans as $id => $plan ) {
            $summary[ $id ] = array(
                'cocon_id'      => $id,
                'pillar_title'  => $plan['pillar_title'],
                'pillar_url'    => $plan['pillar_url'],
                'article_count' => $plan['article_count'] ?? count( $plan['articles'] ),
                'received_at'   => $plan['received_at'],
                'stats'         => $this->get_plan_stats( $id, $plan ),
            );
        }
        wp_send_json_success( $summary );
    }

    public function ajax_plan_detail() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(1);
        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) wp_send_json_error( 'Plan introuvable.' );

        $plan['stats'] = $this->get_plan_stats( $cocon_id );
        wp_send_json_success( $plan );
    }

    public function ajax_order_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);
        $cocon_id    = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $article_key = sanitize_text_field( $_POST['article_key'] ?? '' );

        $result = $this->send_order( $cocon_id, $article_key );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }
        wp_send_json_success( $result );
    }

    public function ajax_order_all() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);
        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );

        $results = $this->send_all_orders( $cocon_id );
        wp_send_json_success( $results );
    }

    public function ajax_check_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(1);
        $cocon_id    = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $article_key = sanitize_text_field( $_POST['article_key'] ?? '' );

        $result = $this->check_article_status( $cocon_id, $article_key );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }
        wp_send_json_success( $result );
    }

    public function ajax_dismiss_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);
        $cocon_id    = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $article_key = sanitize_text_field( $_POST['article_key'] ?? '' );
        $action      = sanitize_text_field( $_POST['dismiss_action'] ?? 'keep_both' );

        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan || ! isset( $plan['articles'][ $article_key ] ) ) {
            wp_send_json_error( 'Article introuvable.' );
        }

        // Client decides: keep_both (generate anyway) | skip (remove from plan) | merge_later (Phase 6c)
        switch ( $action ) {
            case 'generate_anyway':
                $this->update_article_status( $cocon_id, $article_key, self::STATUS_TO_GENERATE );
                break;
            case 'skip':
                $this->update_article_status( $cocon_id, $article_key, 'skipped' );
                break;
            case 'merge_later':
                $this->update_article_status( $cocon_id, $article_key, 'merge_pending' );
                break;
        }

        wp_send_json_success( array( 'status' => $action ) );
    }

    /**
     * AJAX: Queue selected articles for background generation.
     * Sends them to the API immediately, stores job_id. The 15-min cron will
     * pick up completed jobs, create drafts and generate images.
     */
    public function ajax_queue_articles() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        $cocon_id     = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $article_keys = isset( $_POST['article_keys'] ) ? array_map( 'sanitize_text_field', (array) $_POST['article_keys'] ) : array();

        if ( empty( $cocon_id ) || empty( $article_keys ) ) {
            wp_send_json_error( 'cocon_id et article_keys requis.' );
        }

        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) wp_send_json_error( 'Plan introuvable.' );

        $queued = 0;

        // ── File d'attente LOCALE : pas d'appel API maintenant ──
        // Le cron 15min enverra les articles à l'API un par un.
        foreach ( $article_keys as $idx => $akey ) {
            if ( ! isset( $plan['articles'][ $akey ] ) ) continue;
            $art = $plan['articles'][ $akey ];

            // Skip already generated/queued/pending articles
            if ( in_array( $art['status'] ?? '', array( 'received', 'ready', 'queued', self::STATUS_PENDING_QUEUE ), true ) ) continue;

            $this->update_article_status( $cocon_id, $akey, self::STATUS_PENDING_QUEUE, array(
                'queued_at'   => current_time( 'Y-m-d H:i:s' ),
                'queue_order' => $idx,
            ) );
            $queued++;
        }

        self::cocon_log( 'batch_queued', sprintf( '📋 %d article(s) mis en file d\'attente locale', $queued ), array(
            'cocon_id' => $cocon_id,
        ) );

        wp_send_json_success( array(
            'queued'  => $queued,
            'message' => sprintf(
                '%d article(s) en file d\'attente. Ils seront envoyés à l\'API un par un (toutes les ~2 min). Vous pouvez fermer la page.',
                $queued
            ),
        ) );
    }

    /**
     * AJAX: Reset an article status back to to_generate.
     * Used to cancel stuck queued/pending_queue articles or retry errors.
     */
    public function ajax_reset_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $cocon_id    = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $article_key = sanitize_text_field( $_POST['article_key'] ?? '' );

        if ( empty( $cocon_id ) || empty( $article_key ) ) {
            wp_send_json_error( 'cocon_id et article_key requis.' );
        }

        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan || ! isset( $plan['articles'][ $article_key ] ) ) {
            wp_send_json_error( 'Article introuvable.' );
        }

        $old_status = $plan['articles'][ $article_key ]['status'] ?? '';
        $title      = $plan['articles'][ $article_key ]['title'] ?? $plan['articles'][ $article_key ]['keyword'] ?? '?';

        // Reset to to_generate, clear job_id and error
        $this->update_article_status( $cocon_id, $article_key, self::STATUS_TO_GENERATE, array(
            'job_id'       => '',
            'error_reason' => '',
            'queued_at'    => '',
            'ordered_at'   => '',
        ) );

        // Release dispatch lock if this was the active job
        delete_transient( 'hts_dispatch_lock' );

        self::cocon_log( 'article_reset', sprintf(
            '🔄 « %s » remis à rédiger (était : %s)',
            mb_substr( $title, 0, 50 ), $old_status
        ), array( 'cocon_id' => $cocon_id, 'old_status' => $old_status ) );

        wp_send_json_success( array( 'message' => 'Article remis à rédiger.' ) );
    }

    /* =========================================================================
     * SAAS WORKFLOW — Generate Plan → Poll → Generate Articles → Draft
     *
     * Mirrors the Full plugin flow (app.hacktheseo.com/api/v1/cocon/*)
     * ====================================================================== */

    /**
     * AJAX: Generate a cocon plan via SaaS API.
     * User provides pillar URL + main keyword → SaaS returns cocon_id.
     */
    public function ajax_generate_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier(1);

        $pillar_url   = esc_url_raw( $_POST['pillar_url'] ?? '' );
        $main_keyword = sanitize_text_field( $_POST['main_keyword'] ?? '' );
        $language     = sanitize_text_field( $_POST['language'] ?? 'fr-FR' );
        $max_articles = max( 1, min( 50, (int) ( $_POST['max_articles'] ?? 15 ) ) );

        // Guard: if Polylang sends 'all' as language, override with fr-FR
        if ( empty( $language ) || $language === 'all' ) {
            $language = 'fr-FR';
        }

        if ( empty( $pillar_url ) || empty( $main_keyword ) ) {
            wp_send_json_error( 'URL pilier et mot-clé requis.' );
        }

        $result = $this->cocon_api_call( 'POST', 'generate-plan', array(
            'site_url'     => site_url(),
            'pillar_url'   => $pillar_url,
            'main_keyword' => $main_keyword,
            'language'     => $language,
            'max_articles' => $max_articles,
        ) );

        if ( ! $result['success'] ) {
            $msg = $result['error'] ?? 'Erreur API';
            self::cocon_log( 'plan_error', 'generate-plan échoué', array(
                'http'     => $result['status'] ?? 0,
                'error'    => $msg,
                'raw_data' => $result['data'],
            ) );
            wp_send_json_error( array( 'message' => $msg, 'http' => $result['status'] ?? 0 ) );
        }

        // ── Debug: trace full API response to find cocon_id ──
        self::cocon_log( 'plan_api_response', 'Réponse generate-plan brute', array(
            'http'      => $result['status'] ?? 0,
            'data_keys' => is_array( $result['data'] ) ? array_keys( $result['data'] ) : 'not_array',
            'data_dump' => is_array( $result['data'] ) ? json_encode( array_map( function( $v ) {
                return is_array( $v ) ? '(array:' . count( $v ) . ')' : $v;
            }, $result['data'] ) ) : wp_json_encode( $result['data'] ),
        ) );

        // ── Robust cocon_id extraction: check ALL possible locations ──
        $cocon_id = null;
        $d = $result['data'];
        if ( is_array( $d ) ) {
            // Direct: {cocon_id: 123}
            if ( ! empty( $d['cocon_id'] ) ) $cocon_id = $d['cocon_id'];
            // Nested: {data: {cocon_id: 123}}
            elseif ( ! empty( $d['data']['cocon_id'] ) ) $cocon_id = $d['data']['cocon_id'];
            // Alt: {id: 123}
            elseif ( ! empty( $d['id'] ) ) $cocon_id = $d['id'];
            // Alt nested: {data: {id: 123}}
            elseif ( ! empty( $d['data']['id'] ) ) $cocon_id = $d['data']['id'];
            // Alt: {cocon: {id: 123}}
            elseif ( ! empty( $d['cocon']['id'] ) ) $cocon_id = $d['cocon']['id'];
        }

        // SAFETY NET: si cocon_id est vide/0, générer un ID temporaire local
        // Le poll_plan() migrera vers le vrai ID quand l'API le retournera
        if ( empty( $cocon_id ) || $cocon_id === 0 || $cocon_id === '0' ) {
            $cocon_id = 'tmp_' . wp_generate_password( 8, false );
            self::cocon_log( 'plan_warning', 'cocon_id absent dans la réponse API — ID temporaire: ' . $cocon_id, array(
                'full_data' => wp_json_encode( $result['data'] ),
            ) );
        }

        // Store plan stub locally
        $plans   = $this->get_plans();
        $plans[ $cocon_id ] = array(
            'cocon_id'      => $cocon_id,
            'pillar_url'    => $pillar_url,
            'pillar_title'  => '',
            'keyword'       => $main_keyword,
            'language'      => $language,
            'status'        => 'queued',
            'articles'      => array(),
            'article_count' => 0,
            'received_at'   => current_time( 'Y-m-d H:i:s' ),
            'updated_at'    => current_time( 'Y-m-d H:i:s' ),
            'articles_gen'  => array(),
        );
        update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );

        hts_add_log(
            sprintf( '📋 Plan cocon lancé : « %s » (cocon #%s)', $main_keyword, $cocon_id ),
            'success', 'cocon-commander'
        );

        self::cocon_log( 'plan_queued', '📋 Plan lancé', array(
            'cocon_id' => $cocon_id,
            'keyword'  => $main_keyword,
            'pillar'   => $pillar_url,
            'language' => $language,
            'max'      => $max_articles,
        ) );

        wp_send_json_success( array(
            'cocon_id' => $cocon_id,
            'message'  => $result['data']['message'] ?? 'Plan en cours de génération',
        ) );
    }

    /**
     * AJAX: Poll plan status from SaaS.
     * When status=success, saves the plan articles locally.
     */
    public function ajax_poll_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(1);

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        if ( empty( $cocon_id ) ) wp_send_json_error( 'cocon_id requis.' );

        // Si l'ID est temporaire (tmp_xxx), on ne peut pas poll l'API — chercher le vrai ID dans le plan local
        if ( strpos( $cocon_id, 'tmp_' ) === 0 ) {
            $plan = $this->get_plan( $cocon_id );
            if ( $plan && ! empty( $plan['real_cocon_id'] ) ) {
                $cocon_id = $plan['real_cocon_id'];
            } else {
                // Pas encore de vrai ID — retourner "en attente"
                wp_send_json_success( array(
                    'status'   => 'processing',
                    'cocon_id' => $cocon_id,
                    'message'  => 'Plan en cours de création...',
                ) );
            }
        }

        $result = $this->cocon_api_call( 'GET', 'plan-status/' . $cocon_id );

        if ( ! $result['success'] ) {
            wp_send_json_error( array( 'message' => $result['error'] ?? 'Erreur polling', 'cocon_id' => $cocon_id ) );
        }

        $status = $result['data']['status'] ?? 'unknown';

        // ── Debug: log plan-status response to verify cocon_id ──
        $api_cocon_id = 'ABSENT';
        $pd = $result['data'];
        if ( is_array( $pd ) ) {
            if ( ! empty( $pd['cocon_id'] ) ) $api_cocon_id = $pd['cocon_id'];
            elseif ( ! empty( $pd['data']['cocon_id'] ) ) $api_cocon_id = $pd['data']['cocon_id'];
            elseif ( ! empty( $pd['id'] ) ) $api_cocon_id = $pd['id'];
            elseif ( ! empty( $pd['data']['id'] ) ) $api_cocon_id = $pd['data']['id'];
            elseif ( ! empty( $pd['cocon']['id'] ) ) $api_cocon_id = $pd['cocon']['id'];
        }
        self::cocon_log( 'plan_poll_response', 'Réponse plan-status', array(
            'polled_cocon_id' => $cocon_id,
            'api_cocon_id'    => $api_cocon_id,
            'status'          => $status,
            'data_keys'       => is_array( $result['data'] ) ? array_keys( $result['data'] ) : 'not_array',
            'has_plan'        => ! empty( $result['data']['plan'] ),
        ) );

        // ── If API returned a different/real cocon_id, migrate the plan ──
        if ( $api_cocon_id !== 'ABSENT' && $api_cocon_id != $cocon_id && ! empty( $api_cocon_id ) ) {
            $plans = $this->get_plans();
            if ( isset( $plans[ $cocon_id ] ) ) {
                $plans[ $api_cocon_id ] = $plans[ $cocon_id ];
                $plans[ $api_cocon_id ]['cocon_id'] = $api_cocon_id;
                unset( $plans[ $cocon_id ] );
                update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );
                self::cocon_log( 'plan_migrate', '🔄 Plan migré de cocon #' . $cocon_id . ' → #' . $api_cocon_id, array() );
                $cocon_id = $api_cocon_id; // use real ID going forward
            }
        }

        // If plan is ready, save articles locally
        if ( $status === 'success' && ! empty( $result['data']['plan'] ) ) {
            $plans = $this->get_plans();

            // Parse the SaaS plan format: categories[] → articles[]
            $articles = array();
            $saas_plan = $result['data']['plan'];

            // Session P — Batch anti-cannibalisation : load all vectors once
            $all_vectors = array();
            $emb_available = class_exists( 'HTS_Embeddings' );
            if ( $emb_available ) {
                $emb = new \HTS_Embeddings();
                $all_vectors = $emb->load_all_vectors( true );
            }
            $cannib_count = 0;
            $ready_count  = 0;

            foreach ( $saas_plan as $cat ) {
                $category_name = $cat['category'] ?? '';
                foreach ( $cat['articles'] ?? array() as $art ) {
                    $keyword = sanitize_text_field( $art['keyword'] ?? $art['title'] ?? '' );
                    if ( empty( $keyword ) ) continue;

                    $article_key = md5( $keyword );
                    $precheck    = $this->precheck_article( $keyword, $plans[ $cocon_id ]['pillar_url'] ?? '', true );

                    // Session P — Batch embedding cannibal check
                    $cannibal_conflicts = array();
                    if ( $emb_available && ! empty( $all_vectors ) && $precheck['result'] === 'original' ) {
                        $title_text = sanitize_text_field( $art['title'] ?? $keyword );
                        $check_text = trim( $title_text . ' ' . $keyword );
                        $proposed_vector = $emb->get_embedding( $check_text );
                        if ( ! empty( $proposed_vector ) ) {
                            $pillar_pid = hts_url_to_postid( $plans[ $cocon_id ]['pillar_url'] ?? '' );
                            foreach ( $all_vectors as $pid => $vec ) {
                                if ( $pillar_pid && $pid === $pillar_pid ) continue;
                                $sim = \HTS_Embeddings::cosine_similarity( $proposed_vector, $vec );
                                if ( $sim >= 0.82 ) {
                                    $cannibal_conflicts[] = array(
                                        'post_id'    => $pid,
                                        'title'      => get_the_title( $pid ),
                                        'similarity' => round( $sim * 100 ),
                                    );
                                }
                            }
                        }
                    }

                    $final_status = $precheck['result'] === 'original' ? self::STATUS_TO_GENERATE : $precheck['result'];
                    if ( ! empty( $cannibal_conflicts ) ) {
                        $final_status = self::STATUS_SIMILAR; // Flag as risky
                        $cannib_count++;
                    } else {
                        $ready_count++;
                    }

                    $articles[ $article_key ] = array(
                        'keyword'    => $keyword,
                        'title'      => sanitize_text_field( $art['title'] ?? $keyword ),
                        'topic'      => sanitize_text_field( $art['topic'] ?? '' ),
                        'topic_id'   => (int) ( $art['topic_id'] ?? 0 ),
                        'intent'     => sanitize_text_field( $art['intent'] ?? 'info' ),
                        'category'   => sanitize_text_field( $category_name ),
                        'status'     => $final_status,
                        'precheck'   => $precheck,
                        'cannibal_conflicts' => $cannibal_conflicts,
                        'post_id'    => null,
                        'ordered_at' => null,
                    );
                    // Auto-classify intent if SaaS returned default 'info'
                    if ( $articles[ $article_key ]['intent'] === 'info' || empty( $articles[ $article_key ]['intent'] ) ) {
                        $articles[ $article_key ]['intent'] = self::classify_intent(
                            $articles[ $article_key ]['title'] . ' ' . $articles[ $article_key ]['keyword']
                        );
                    }
                }
            }

            if ( isset( $plans[ $cocon_id ] ) ) {
                $plans[ $cocon_id ]['status']        = 'success';
                $plans[ $cocon_id ]['articles']       = $articles;
                $plans[ $cocon_id ]['article_count']  = count( $articles );
                $plans[ $cocon_id ]['plan_raw']       = $saas_plan;
                $plans[ $cocon_id ]['updated_at']     = current_time( 'Y-m-d H:i:s' );
                // Session P — Store batch cannibal summary
                $plans[ $cocon_id ]['batch_summary']  = array(
                    'total'    => count( $articles ),
                    'ready'    => $ready_count,
                    'cannibal' => $cannib_count,
                    'duplicate' => count( $articles ) - $ready_count - $cannib_count,
                );
            }
            update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );

            hts_add_log(
                sprintf( 'Plan cocon prêt : %d articles (%d prêts, %d risques cannibalisation) — cocon #%s',
                    count( $articles ), $ready_count, $cannib_count, $cocon_id ),
                'success', 'cocon-commander'
            );

            self::cocon_log( 'plan_ready', 'Plan prêt', array(
                'cocon_id'   => $cocon_id,
                'categories' => count( $saas_plan ),
                'articles'   => count( $articles ),
                'ready'      => $ready_count,
                'cannibal'   => $cannib_count,
            ) );
        }

        // ── DIAG: log non-success poll status ──
        if ( $status !== 'success' ) {
            self::cocon_log( 'plan_poll_waiting', 'Poll #' . $cocon_id . ' → status=' . $status, array(
                'status'     => $status,
                'cocon_id'   => $cocon_id,
                'has_plan'   => ! empty( $result['data']['plan'] ),
                'error_msg'  => $result['data']['error'] ?? $result['data']['message'] ?? '',
                'raw_first'  => mb_substr( wp_json_encode( $result['data'] ), 0, 200 ),
            ) );
        }

        wp_send_json_success( array(
            'status'   => $status,
            'cocon_id' => $cocon_id,
            'plan'     => $result['data']['plan'] ?? array(),
        ) );
    }

    /**
     * AJAX: Generate a single article via SaaS.
     * Sends cocon_id + topic_id → SaaS returns job_id.
     */
    public function ajax_generate_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);
        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 180 );

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $topic_id = (int) ( $_POST['topic_id'] ?? 0 );
        $article_key = sanitize_text_field( $_POST['article_key'] ?? '' );
        $skip_cannibal_check = (bool) ( $_POST['skip_cannibal_check'] ?? false );

        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) wp_send_json_error( array( 'message' => 'Plan introuvable.' ) );

        // ── Guard: emergency stop active ──
        if ( get_transient( 'hts_generation_emergency_stop' ) ) {
            wp_send_json_error( array(
                'message' => 'Arrêt d\'urgence actif — génération bloquée. Désactivez l\'arrêt d\'urgence pour continuer.',
            ) );
        }

        // ── Guard: prevent re-generating already processed articles ──
        if ( ! empty( $article_key ) && isset( $plan['articles'][ $article_key ] ) ) {
            $current_status = $plan['articles'][ $article_key ]['status'] ?? '';
            $blocked_statuses = array( 'queued', 'received', 'ready', 'published' );
            if ( in_array( $current_status, $blocked_statuses, true ) ) {
                wp_send_json_error( array(
                    'message' => sprintf(
                        'Cet article est déjà en cours de traitement (statut : %s). Décochez-le.',
                        $current_status
                    ),
                ) );
            }
        }

        // ── Anti-cannibalization pre-check ──
        // Before generating, verify the proposed topic doesn't duplicate existing content
        if ( ! $skip_cannibal_check && class_exists( 'HTS_Embeddings' ) ) {
            $article_title = '';
            $article_keyword = '';
            if ( ! empty( $article_key ) && isset( $plan['articles'][ $article_key ] ) ) {
                $art = $plan['articles'][ $article_key ];
                $article_title = $art['title'] ?? $art['topic'] ?? '';
                $article_keyword = $art['keyword'] ?? $art['focus_keyword'] ?? '';
            }
            $check_text = trim( $article_title . ' ' . $article_keyword );

            if ( ! empty( $check_text ) ) {
                $emb = new \HTS_Embeddings();
                // Generate embedding for the proposed title
                $proposed_vector = $emb->get_embedding( $check_text );
                if ( ! empty( $proposed_vector ) ) {
                    $vectors = $emb->load_all_vectors( true );
                    $conflicts = array();
                    foreach ( $vectors as $pid => $vec ) {
                        $sim = HTS_Embeddings::cosine_similarity( $proposed_vector, $vec );
                        if ( $sim >= 0.82 ) {
                            $conflicts[] = array(
                                'post_id'    => $pid,
                                'title'      => get_the_title( $pid ),
                                'url'        => get_permalink( $pid ),
                                'similarity' => round( $sim * 100 ),
                            );
                        }
                    }
                    if ( ! empty( $conflicts ) ) {
                        // Sort by highest similarity first
                        usort( $conflicts, function( $a, $b ) { return $b['similarity'] - $a['similarity']; } );
                        wp_send_json_error( array(
                            'cannibal_warning' => true,
                            'message' => sprintf(
                                'Risque de cannibalisation : « %s » est trop similaire à %d article(s) existant(s).',
                                mb_substr( $article_title, 0, 50 ),
                                count( $conflicts )
                            ),
                            'conflicts' => array_slice( $conflicts, 0, 5 ),
                            'article_key' => $article_key,
                        ) );
                    }
                }
            }
        }

        // Plan already loaded above (line 1308) — reuse it
        $siblings      = $this->get_existing_siblings( $cocon_id );
        $pillar_post_id = hts_url_to_postid( $plan['pillar_url'] ?? '' );
        $pillar_title   = $pillar_post_id ? get_the_title( $pillar_post_id ) : '';

        // Résoudre le vrai cocon_id SaaS (pas le tmp_ local ni le "0")
        $api_cocon_id = $cocon_id;
        if ( strpos( $cocon_id, 'tmp_' ) === 0 || $cocon_id === '0' || $cocon_id === 0 ) {
            // Chercher le real_cocon_id dans le plan
            $real = $plan['real_cocon_id'] ?? $plan['cocon_id'] ?? '';
            if ( ! empty( $real ) && $real !== '0' && strpos( $real, 'tmp_' ) !== 0 ) {
                $api_cocon_id = $real;
            } else {
                wp_send_json_error( array(
                    'message' => 'Le plan n\'a pas encore de cocon_id valide. Relancez la génération du plan.',
                    'cocon_id' => $cocon_id,
                ) );
            }
        }

        $api_body = array(
            'cocon_id'          => $api_cocon_id,
            'topic_id'          => $topic_id,
            'site_url'          => site_url(),
            'pillar_url'        => $plan['pillar_url'] ?? '',
            'pillar_title'      => $pillar_title,
            'siblings'          => $siblings,
            'recommended_links' => $this->get_recommended_links( $cocon_id ),
            'language'          => $plan['language'] ?? 'fr-FR',
            'auto_validate'     => true,
        );

        // ── Debug: log exactly what we send to the API ──
        self::cocon_log( 'article_api_request', '📤 Requête generate-article', array(
            'cocon_id'    => $cocon_id,
            'cocon_type'  => gettype( $cocon_id ),
            'topic_id'    => $topic_id,
            'pillar_url'  => $plan['pillar_url'] ?? '',
            'nb_siblings' => count( $siblings ),
        ) );

        $result = $this->cocon_api_call( 'POST', 'generate-article', $api_body );

        if ( ! $result['success'] ) {
            $msg = $result['error'] ?? 'Erreur API';
            self::cocon_log( 'article_error', '' . $msg, array(
                'cocon_id'  => $cocon_id,
                'topic_id'  => $topic_id,
                'http'      => $result['status'] ?? 0,
                'api_data'  => wp_json_encode( $result['data'] ),
            ) );
            // ── User-friendly message if cocon not found ──
            if ( stripos( $msg, 'non trouvé' ) !== false || stripos( $msg, 'not found' ) !== false ) {
                $msg = sprintf(
                    'Le cocon #%s n\'existe pas côté serveur. Supprimez ce plan et relancez la génération du plan avant de générer les articles.',
                    $cocon_id
                );
            }
            wp_send_json_error( array( 'message' => $msg ) );
        }

        // Update article status
        if ( ! empty( $article_key ) && isset( $plan['articles'][ $article_key ] ) ) {
            $this->update_article_status( $cocon_id, $article_key, self::STATUS_QUEUED, array(
                'ordered_at' => current_time( 'Y-m-d H:i:s' ),
                'job_id'     => $result['data']['job_id'] ?? '',
                'topic_id'   => $topic_id,
            ) );
        }

        hts_add_log(
            sprintf( '✍️ Article lancé (cocon #%s, topic #%d)', $cocon_id, $topic_id ),
            'success', 'cocon-commander'
        );

        self::cocon_log( 'article_queued', '✍️ Article lancé', array(
            'cocon_id' => $cocon_id,
            'topic_id' => $topic_id,
            'job_id'   => $result['data']['job_id'] ?? '',
        ) );

        wp_send_json_success( array(
            'job_id'   => $result['data']['job_id'] ?? '',
            'status'   => $result['data']['status'] ?? 'queued',
            'message'  => $result['data']['message'] ?? 'Génération en cours',
            'topic_id' => $topic_id,
        ) );
    }

    /**
     * AJAX: Poll article generation status.
     */
    public function ajax_poll_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_id   = sanitize_text_field( $_POST['job_id'] ?? '' );
        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        if ( empty( $job_id ) ) wp_send_json_error( 'job_id requis.' );

        $result = $this->cocon_api_call( 'GET', 'article-status/' . $job_id );

        if ( ! $result['success'] ) {
            self::cocon_log( 'poll_article', 'Erreur HTTP', array( 'job_id' => $job_id ) );
            wp_send_json_error( array( 'message' => $result['error'] ?? 'Erreur polling' ) );
        }

        $status = $result['data']['status'] ?? 'unknown';

        // Log phase changes (smart: skips duplicates)
        self::cocon_log( 'poll_article', $status, array(
            'job_id' => $job_id,
            'phase'  => $result['data']['phase'] ?? '',
        ) );

        // If completed, store article in a transient (avoid JS encoding issues)
        if ( $status === 'completed' && ! empty( $result['data']['article'] ) ) {
            $transient_key = 'hts_article_' . $job_id;
            set_transient( $transient_key, $result['data']['article'], 3600 );

            self::cocon_log( 'article_ready', 'Article prêt', array(
                'job_id'   => $job_id,
                'title'    => $result['data']['article']['title'] ?? '',
                'words'    => $result['data']['article']['word_count'] ?? 0,
            ) );

            hts_add_log(
                sprintf( 'Article prêt (job %s)', $job_id ),
                'success', 'cocon-commander'
            );
        }

        wp_send_json_success( array(
            'status'        => $status,
            'phase'         => $result['data']['phase'] ?? '',
            'job_id'        => $job_id,
            'article_ready' => ( $status === 'completed' ),
            'article_title' => ( $status === 'completed' && ! empty( $result['data']['article'] ) )
                ? ( $result['data']['article']['title'] ?? '' ) : '',
        ) );
    }

    /**
     * AJAX: Create WordPress draft from completed article.
     * Enhanced v1.27.0 — ported from Full v4.0:
     * - Meta extraction from HTML head
     * - Short SEO slug from keyword
     * - HTML cleanup: strip body/h1/title/STOP/comments, fix markdown links, clean AI spam
     * - Safety net: fallback if content empty after cleanup
     * - SEO metas applied to all detected plugins (HTS, Yoast, RankMath, AIOSEO)
     * - Hard truncate safety net on meta fields
     * - Detailed cocon_log() at every step
     */
    /**
     * Crée un brouillon complet à partir d'un article généré par l'API.
     * Méthode programmatique utilisable depuis AJAX ET depuis le cron auto-write.
     *
     * @since 2.3.1
     * @param string $cocon_id     ID du cocon
     * @param string $article_key  Clé de l'article dans le plan
     * @param string $job_id       ID du job API
     * @param array  $options      Options supplémentaires {
     *     @type bool $auto_generated  Marqueur auto-write (default false)
     * }
     * @return array|false { post_id, title, slug, words, edit_url, images, cross_links, schemas } ou false
     */
    public function create_draft_from_article( $cocon_id, $article_key, $job_id, $options = array() ) {
        $auto_generated = ! empty( $options['auto_generated'] );

        // ── 0. Atomic lock: prevent race condition between JS poll and auto-write cron ──
        // Both can detect a completed article at the same time and try to create a draft.
        // The first one to set the transient lock wins; the other returns gracefully.
        $lock_key = 'hts_draft_lock_' . $job_id;
        $existing_lock = get_transient( $lock_key );
        if ( $existing_lock ) {
            // Another process is already creating this draft — check if it succeeded
            $existing_post_id = (int) $existing_lock;
            if ( $existing_post_id > 0 && get_post( $existing_post_id ) ) {
                self::cocon_log( 'draft_skip', '⏭️ Brouillon déjà créé par un autre processus → #' . $existing_post_id, array(
                    'job_id'   => $job_id,
                    'post_id'  => $existing_post_id,
                ) );
                return array(
                    'post_id'     => $existing_post_id,
                    'title'       => get_the_title( $existing_post_id ),
                    'slug'        => get_post_field( 'post_name', $existing_post_id ),
                    'words'       => hts_word_count( wp_strip_all_tags( get_post_field( 'post_content', $existing_post_id ) ) ),
                    'edit_url'    => get_edit_post_link( $existing_post_id, 'raw' ),
                    'images'      => 0,
                    'cross_links' => 0,
                    'schemas'     => array(),
                );
            }
            // Lock exists but no valid post — stale lock, proceed
        }
        // Set lock immediately (value = 'creating', will be updated with post_id after insert)
        set_transient( $lock_key, 'creating', 300 ); // 5 min TTL

        // ── 0b. Emergency stop guard: if stop was triggered, don't create draft ──
        if ( get_transient( 'hts_generation_emergency_stop' ) ) {
            delete_transient( $lock_key );
            self::cocon_log( 'draft_blocked', '🛑 Arrêt d\'urgence actif — brouillon annulé', array(
                'job_id'   => $job_id,
                'cocon_id' => $cocon_id,
            ) );
            return false;
        }

        // ── 1. Retrieve article from transient ──
        $transient_key = 'hts_article_' . $job_id;
        $article = get_transient( $transient_key );

        if ( ! $article || empty( $article['content_html'] ) ) {
            // Check if draft was already created by another process (race condition)
            $plans = $this->get_plans();
            $art_data = $plans[ $cocon_id ]['articles'][ $article_key ] ?? array();
            if ( ( $art_data['status'] ?? '' ) === self::STATUS_RECEIVED && ! empty( $art_data['post_id'] ) ) {
                $pid = (int) $art_data['post_id'];
                set_transient( $lock_key, $pid, 300 );
                self::cocon_log( 'draft_skip', '⏭️ Transient expiré mais brouillon déjà reçu → #' . $pid, array(
                    'job_id'   => $job_id,
                    'cocon_id' => $cocon_id,
                ) );
                return array(
                    'post_id'     => $pid,
                    'title'       => get_the_title( $pid ),
                    'slug'        => get_post_field( 'post_name', $pid ),
                    'words'       => hts_word_count( wp_strip_all_tags( get_post_field( 'post_content', $pid ) ) ),
                    'edit_url'    => get_edit_post_link( $pid, 'raw' ),
                    'images'      => 0,
                    'cross_links' => 0,
                    'schemas'     => array(),
                );
            }
            delete_transient( $lock_key );
            self::cocon_log( 'draft_error', 'Article introuvable dans transient', array(
                'job_id'   => $job_id,
                'cocon_id' => $cocon_id,
            ) );
            return false;
        }

        $content_html = $article['content_html'];
        $keyword      = $article['keyword'] ?? '';

        // ── Retrieve pillar info from plan (needed for cluster assignment) ──
        $plan = $this->get_plan( $cocon_id );
        $pillar_post_id = 0;
        if ( $plan && ! empty( $plan['pillar_url'] ) ) {
            $pillar_post_id = hts_url_to_postid( $plan['pillar_url'] );
        }

        self::cocon_log( 'content_cleaned', 'Début nettoyage HTML', array(
            'job_id'    => $job_id,
            'raw_bytes' => mb_strlen( $content_html ),
        ) );

        // ── 2. Extract raw metas from HTML head ──
        $extracted = self::extract_metas_from_html( $content_html );

        // ── 3. Strip <html>, <head>, <body> wrappers ──
        if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $content_html, $body_match ) ) {
            $content_html = $body_match[1];
        }

        // ── 4. Extract H1 for title ──
        $wp_title = '';
        if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/si', $content_html, $h1m ) ) {
            $wp_title = wp_strip_all_tags( $h1m[1] );
        }
        if ( empty( $wp_title ) ) {
            $wp_title = wp_strip_all_tags( $article['title'] ?? 'Article sans titre' );
        }

        // ── 5. Collect metas (API > HTML extraction) ──
        $raw_meta_title = $article['meta_title'] ?? '';
        if ( empty( $raw_meta_title ) ) $raw_meta_title = $extracted['meta_title'];
        if ( empty( $raw_meta_title ) ) $raw_meta_title = $wp_title;

        $raw_meta_desc = $article['meta_description'] ?? '';
        if ( empty( $raw_meta_desc ) ) $raw_meta_desc = $extracted['meta_description'];

        // ── 6. Generate short SEO slug ──
        $wp_slug = self::generate_short_slug( $keyword, $article['slug'] ?? '' );

        // ── 7. Hard safety net: truncate metas ──
        $meta_title = self::truncate_meta( $raw_meta_title, 60 );
        $meta_desc  = self::truncate_meta( $raw_meta_desc, 155 );

        // Fix 1: S'assurer que le keyword apparaît dans la meta description
        if ( ! empty( $keyword ) && ! empty( $meta_desc ) && mb_stripos( $meta_desc, $keyword ) === false ) {
            // Essayer d'injecter le keyword naturellement en début
            $kw_lower = mb_strtolower( $keyword );
            $desc_lower = mb_strtolower( $meta_desc );
            // Vérifier si un mot significatif du keyword est déjà présent
            $kw_words = array_filter( preg_split( '/[\s,\-]+/', $kw_lower ), function( $w ) { return mb_strlen( $w ) >= 4; } );
            $has_partial = false;
            foreach ( $kw_words as $kw ) {
                if ( mb_strpos( $desc_lower, $kw ) !== false ) { $has_partial = true; break; }
            }
            if ( ! $has_partial ) {
                // Aucun mot du keyword présent — injecter en début
                $meta_desc = ucfirst( $keyword ) . ' : ' . lcfirst( $meta_desc );
                $meta_desc = self::truncate_meta( $meta_desc, 155 );
            }
        }

        self::cocon_log( 'ai_metas', '🤖 Metas préparées', array(
            'meta_title' => $meta_title,
            'meta_desc'  => mb_substr( $meta_desc, 0, 60 ) . '...',
            'slug'       => $wp_slug,
            'keyword'    => $keyword,
        ) );

        // ── 8. Clean HTML content ──
        // On nettoie les wrappers structurels et on fixe les liens internes.
        // Les liens EXTERNES (PubMed, ScienceDirect, etc.) sont TOUJOURS préservés —
        // fix_ugly_permalinks ne touche que les liens ?p=XXX (internes WordPress).
        $wp_content = $content_html;
        $wp_content = preg_replace( '/<meta[^>]*>/i', '', $wp_content )         ?? $wp_content;
        $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content ) ?? $wp_content;
        $wp_content = preg_replace( '/<title>.*?<\/title>/si', '', $wp_content ) ?? $wp_content;
        $wp_content = preg_replace( '/\s*(?:<p>)?\s*STOP\s*(?:<\/p>)?\s*(?:<!--.*?-->)?\s*$/s', '', $wp_content ) ?? $wp_content;
        $wp_content = preg_replace( '/<!--.*?-->/s', '', $wp_content )           ?? $wp_content;

        // 8b. Fix markdown-style links [text](url) → <a> (cas rare, fallback AI)
        $wp_content = self::fix_markdown_links( $wp_content );

        // 8c. Clean AI spam: keyword stuffing blocks, semantic notes, keyword lists
        $wp_content = self::clean_ai_spam( $wp_content );

        // 8d. Convert ugly ?p=XXX links to proper pretty permalinks
        $wp_content = self::fix_ugly_permalinks( $wp_content );

        $wp_content = trim( $wp_content );

        // ── 8e. Safety net: if content empty after cleanup ──
        if ( empty( $wp_content ) ) {
            self::cocon_log( 'content_cleaned', 'Contenu vide après nettoyage — fallback sur brut', array(
                'job_id'     => $job_id,
                'raw_len'    => mb_strlen( $content_html ),
                'preg_error' => preg_last_error(),
            ) );
            $wp_content = $content_html;
            if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $wp_content, $fb ) ) {
                $wp_content = $fb[1];
            }
            $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content ) ?? $wp_content;
            $wp_content = trim( $wp_content );
        }

        // ── 9. Create WordPress draft ──
        // Sprint 6.2d: clean internal link attributes BEFORE save
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) && method_exists( 'HTS_Synchronise_Articles_Admin', 'fix_internal_link_attrs' ) ) {
            $wp_content = \HTS_Synchronise_Articles_Admin::fix_internal_link_attrs( $wp_content );
        }
        $default_author = (int) get_option( 'hts_default_author', 0 );
        $meta_input = array(
            '_hts_api_generated'  => 1,
            '_hts_api_keyword'    => $keyword,
            '_hts_cocon_id'       => $cocon_id,
            '_hts_cocon_job_id'   => $job_id,
            '_hts_article_key'    => $article_key,
            '_hts_cocon_keyword'  => $plan['keyword'] ?? $plan['main_keyword'] ?? $keyword,
        );
        if ( $auto_generated ) {
            $meta_input['_hts_auto_write'] = '1';
        }

        $post_args = array(
            'post_title'   => $wp_title,
            'post_name'    => self::ensure_unique_slug( sanitize_title( $wp_slug ), $wp_title ),
            'post_content' => $wp_content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'meta_input'   => $meta_input,
        );
        if ( $default_author > 0 ) {
            $post_args['post_author'] = $default_author;
        } else {
            // En contexte cron, get_current_user_id() = 0 → fallback intelligent
            $current = get_current_user_id();
            if ( $current > 0 ) {
                $post_args['post_author'] = $current;
            } else {
                // D3: $default_author est déjà 0 ici (testé au-dessus), passer direct au fallback admin
                $admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'order' => 'ASC', 'fields' => 'ID' ) );
                $fallback_author = ! empty( $admins ) ? (int) $admins[0] : 1;
                $post_args['post_author'] = $fallback_author;
            }
        }

        $post_id = wp_insert_post( $post_args );

        if ( is_wp_error( $post_id ) || ! $post_id ) {
            delete_transient( $lock_key );
            self::cocon_log( 'draft_error', 'wp_insert_post échoué', array(
                'job_id' => $job_id,
                'error'  => is_wp_error( $post_id ) ? $post_id->get_error_message() : 'empty post_id',
            ) );
            return false;
        }

        // Update lock with actual post_id (so concurrent processes can find it)
        set_transient( $lock_key, $post_id, 300 );

        // ── 9a-bis. Assign Polylang language (fix: articles created in EN instead of FR) ──
        if ( function_exists( 'pll_set_post_language' ) ) {
            // Priority: 1) plan language  2) pillar language  3) current admin lang  4) site default
            $post_lang = '';
            if ( ! empty( $plan['lang'] ) ) {
                $post_lang = $plan['lang'];
            } elseif ( $pillar_post_id && function_exists( 'pll_get_post_language' ) ) {
                $post_lang = pll_get_post_language( $pillar_post_id, 'slug' );
            }
            if ( ! $post_lang && function_exists( 'pll_current_language' ) ) {
                $post_lang = pll_current_language( 'slug' );
            }
            if ( ! $post_lang ) {
                $post_lang = substr( get_locale(), 0, 2 );
            }
            pll_set_post_language( $post_id, $post_lang );

            // Link to pillar as translation if same language
            if ( $pillar_post_id && function_exists( 'pll_save_post_translations' ) ) {
                $pillar_lang = pll_get_post_language( $pillar_post_id, 'slug' );
                if ( $pillar_lang === $post_lang ) {
                    // Don't link as translation — they're in the same language
                    // Polylang translations are for DIFFERENT languages of the same content
                }
            }
        }
        // Also store language in meta for modules that don't use Polylang API
        update_post_meta( $post_id, '_hts_content_lang', substr( get_locale(), 0, 2 ) );

        // ── 9b. Auto-assign WordPress category from plan ──
        // Strategy: ONE category per cocon (using cocon keyword), not per article group.
        // Only create a new WP category if no fuzzy match exists.
        $cat_id = 0;

        // Priority 1: inherit pillar's category (already set by user)
        if ( $pillar_post_id ) {
            $pillar_cats = wp_get_post_categories( $pillar_post_id );
            // Filter out "Uncategorized" (term_id = 1)
            $pillar_cats = array_filter( $pillar_cats, function( $c ) { return (int) $c !== 1; } );
            if ( ! empty( $pillar_cats ) ) {
                $cat_id = (int) array_values( $pillar_cats )[0];
            }
        }

        // Priority 2: match plan category name against existing WP categories (fuzzy)
        if ( ! $cat_id && $plan && ! empty( $plan['articles'][ $article_key ]['category'] ) ) {
            $plan_cat_name = $plan['articles'][ $article_key ]['category'];
            if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) && method_exists( 'HTS_Synchronise_Articles_Admin', 'cocon_ensure_category' ) ) {
                $cat_id = \HTS_Synchronise_Articles_Admin::cocon_ensure_category( $plan_cat_name );
            } else {
                $cat_id = get_cat_ID( $plan_cat_name );
            }
        }

        // Priority 3: if still no match, create ONE category per cocon (using cocon keyword, not article group name)
        if ( ! $cat_id && $plan ) {
            $cocon_keyword = $plan['keyword'] ?? $plan['pillar_keyword'] ?? '';
            if ( $cocon_keyword ) {
                // Check if it already exists first
                $cat_id = get_cat_ID( $cocon_keyword );
                if ( ! $cat_id ) {
                    $slug_check = get_term_by( 'slug', sanitize_title( $cocon_keyword ), 'category' );
                    if ( $slug_check ) {
                        $cat_id = (int) $slug_check->term_id;
                    }
                }
                if ( ! $cat_id ) {
                    // Create category under pillar's parent (if any)
                    $parent_cat = 0;
                    if ( $pillar_post_id ) {
                        $pc = wp_get_post_categories( $pillar_post_id );
                        $parent_cat = ! empty( $pc ) ? (int) $pc[0] : 0;
                        if ( $parent_cat === 1 ) $parent_cat = 0; // Don't use "Uncategorized" as parent
                    }
                    $cat_id = wp_create_category( $cocon_keyword, $parent_cat );
                    if ( $cat_id && ! is_wp_error( $cat_id ) ) {
                        self::cocon_log( 'category_created', '📂 Catégorie créée pour le cocon : « ' . $cocon_keyword . ' » → #' . $cat_id, array( 'cocon_id' => $cocon_id ) );
                    }
                }
            }
        }

        if ( $cat_id && ! is_wp_error( $cat_id ) ) {
            wp_set_post_categories( $post_id, array( (int) $cat_id ) );
            self::cocon_log( 'category_assigned', '📂 Catégorie assignée : « ' . ( get_cat_name( $cat_id ) ?: $cat_id ) . ' »', array(
                'post_id' => $post_id,
                'cat_id'  => $cat_id,
            ) );
        }

        // ── 10. Apply SEO metas to all detected plugins ──
        self::apply_seo_metas_multi_plugin( $post_id, $meta_title, $meta_desc, $keyword );

        self::cocon_log( 'seo_metas', '📋 Metas SEO appliquées', array(
            'post_id'    => $post_id,
            'hts'        => true,
            'yoast'      => defined( 'WPSEO_VERSION' ),
            'rankmath'   => class_exists( 'RankMath' ),
            'aioseo'     => class_exists( 'AIOSEO\\Plugin\\AIOSEO' ) || defined( 'AIOSEO_VERSION' ),
        ) );

        // ── 10b. Auto-assign to NLP cluster BEFORE pipeline (so cross_interlink uses real cluster) ──
        $pillar_cluster = '';
        if ( $pillar_post_id && class_exists( 'HTS_Cocon' ) ) {
            $cocon_data = self::load_cocon_data();
            $pillar_cluster = $cocon_data['nodes'][ $pillar_post_id ]['cluster'] ?? '';
            if ( ! empty( $pillar_cluster ) ) {
                // Add to NLP cluster data
                if ( ! empty( $cocon_data['clusters'][ $pillar_cluster ]['pages'] ) ) {
                    if ( ! in_array( $post_id, $cocon_data['clusters'][ $pillar_cluster ]['pages'] ) ) {
                        $cocon_data['clusters'][ $pillar_cluster ]['pages'][] = $post_id;
                    }
                }
                // Add node entry
                $cocon_data['nodes'][ $post_id ] = array(
                    'id'           => $post_id,
                    'title'        => $wp_title,
                    'url'          => get_permalink( $post_id ),
                    'edit_url'     => get_edit_post_link( $post_id, 'raw' ),
                    'type'         => get_post_type( $post_id ),
                    'cluster'      => $pillar_cluster,
                    'role'         => 'page',
                    'is_pillar'    => false,
                    'is_orphan'    => true,
                    'is_dead_end'  => true,
                    'incoming'     => array(),
                    'outgoing'     => array(),
                    'in_count'     => 0,
                    'out_count'    => 0,
                    'in_links'     => 0,
                    'out_links'    => 0,
                    'keywords'     => array( $keyword ),
                    'categories'   => wp_list_pluck( wp_get_post_categories( $post_id, array( 'fields' => 'all' ) ), 'name' ),
                    'tags'         => wp_list_pluck( wp_get_post_tags( $post_id, array( 'fields' => 'all' ) ), 'name' ),
                    'word_count'   => 0,
                    'h2_count'     => 0,
                    'date'         => current_time( 'Y-m-d H:i:s' ),
                    'pillar_score' => 0,
                    'click_depth'  => PHP_INT_MAX,
                );
                // Save with language suffix for multilingual sites
                $_cc_lang = '';
                if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
                    $_cc_lang = HTS_Language::get_post_language( $post_id );
                    if ( empty( $_cc_lang ) ) $_cc_lang = HTS_Language::get_current_lang();
                }
                $_cc_opt_key = ( $_cc_lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
                    ? 'hts_cocon_data_' . $_cc_lang
                    : 'hts_cocon_data';
                update_option( $_cc_opt_key, $cocon_data, false );
                wp_cache_delete( $_cc_opt_key, 'options' );
                // Also sync unsuffixed key for default language
                $_cc_default = function_exists( 'pll_default_language' ) ? pll_default_language( 'slug' ) : '';
                if ( $_cc_lang && $_cc_lang === $_cc_default && $_cc_opt_key !== 'hts_cocon_data' ) {
                    update_option( 'hts_cocon_data', $cocon_data, false );
                    wp_cache_delete( 'hts_cocon_data', 'options' );
                }

                // Store NLP cluster in separate meta — DO NOT overwrite _hts_cocon_id (plan ID)
                update_post_meta( $post_id, '_hts_nlp_cluster', $pillar_cluster );

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( '📌 Article « %s » auto-assigné au cluster « %s »', mb_substr( $wp_title, 0, 40 ), $pillar_cluster ),
                        'info', 'cocon-commander'
                    );
                }

                self::cocon_log( 'cluster_assigned', '📌 Cluster assigné AVANT maillage', array(
                    'post_id' => $post_id,
                    'cluster' => $pillar_cluster,
                    'pillar'  => $pillar_post_id,
                ) );
            }
        }

        // ── 10c. Article Pipeline — enrichissement complet (schemas, cross-links, stuffing) ──
        $pipeline_result = array( 'images_count' => 0, 'cross_links' => 0, 'schemas' => array(), 'stuffing' => false );
        if ( class_exists( 'HTS_Article_Pipeline' ) ) {
            $pipeline_result = HTS_Article_Pipeline::enrich_draft( $post_id, $wp_title, $keyword, $wp_content );
        }

        // ── 11. Update plan: mark article as received ──
        if ( ! empty( $article_key ) ) {
            // update_article_status uses the plans write lock internally
            $this->update_article_status( $cocon_id, $article_key, self::STATUS_RECEIVED, array(
                'post_id'        => $post_id,
                'received_at'    => current_time( 'Y-m-d H:i:s' ),
                'auto_generated' => $auto_generated,
            ) );

            // Also track topic_id → post_id mapping (use same lock pattern)
            if ( hts_acquire_lock( 'plans_write', 5, 10, 150 ) ) {

            $plans = $this->get_plans();
            if ( isset( $plans[ $cocon_id ] ) ) {
                $topic_id = $plans[ $cocon_id ]['articles'][ $article_key ]['topic_id'] ?? 0;
                $plans[ $cocon_id ]['articles_gen'][ $topic_id ] = array( 'post_id' => $post_id );

                // Cleanup standalone plan if article is done
                if ( ! empty( $plans[ $cocon_id ]['standalone'] ) ) {
                    $all_done = true;
                    foreach ( $plans[ $cocon_id ]['articles'] as $a ) {
                        if ( ! in_array( $a['status'] ?? '', array( self::STATUS_RECEIVED, self::STATUS_PUBLISHED, self::STATUS_ERROR ), true ) ) {
                            $all_done = false;
                            break;
                        }
                    }
                    if ( $all_done ) {
                        $plans[ $cocon_id ]['status'] = 'completed';
                    }
                }

                update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );
            }

            hts_release_lock( 'plans_write' );
            } else {
                self::cocon_log( 'lock_timeout', 'Write lock timeout — topic_id mapping ignoré', array(
                    'cocon_id' => $cocon_id,
                    'post_id'  => $post_id,
                ) );
            } // end lock acquired
        }

        // ── 12. Clean up transient ──
        delete_transient( $transient_key );

        // ── 12b. Workflow proposals enfant↔pilier ──
        if ( ! empty( $pillar_cluster ) && $pillar_post_id && class_exists( 'HTS_Workflow_Engine' ) ) {
            HTS_Workflow_Engine::propose(
                'linking',
                'add_internal_links',
                $post_id,
                array(
                    'reason'       => sprintf( 'Nouvel article du cocon « %s » : lien vers le pilier manquant', mb_substr( $pillar_cluster, 0, 40 ) ),
                    'source_cocon' => true,
                    'cluster'      => $pillar_cluster,
                    'target_id'    => $pillar_post_id,
                    'target_title' => get_the_title( $pillar_post_id ),
                    'anchor_text'  => $keyword,
                    'link_type'    => 'child_to_pillar',
                    'suggestion'   => 'Ajouter un lien vers le pilier « ' . mb_substr( get_the_title( $pillar_post_id ), 0, 50 ) . ' »',
                ),
                'high'
            );

            HTS_Workflow_Engine::propose(
                'linking',
                'add_internal_links',
                $pillar_post_id,
                array(
                    'reason'       => sprintf( 'Nouvel enfant « %s » ajouté au cocon : lien depuis le pilier manquant', mb_substr( $wp_title, 0, 40 ) ),
                    'source_cocon' => true,
                    'cluster'      => $pillar_cluster,
                    'target_id'    => $post_id,
                    'target_title' => $wp_title,
                    'anchor_text'  => $keyword,
                    'link_type'    => 'pillar_to_child',
                    'suggestion'   => 'Ajouter un lien vers « ' . mb_substr( $wp_title, 0, 50 ) . ' »',
                ),
                'high'
            );

            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( '🔗 Auto-maillage : 2 propositions créées (enfant↔pilier) pour « %s »', mb_substr( $wp_title, 0, 40 ) ),
                    'info', 'cocon-commander'
                );
            }
        }

        // ── 13. Final success log ──
        $word_count = $article['word_count'] ?? hts_word_count( wp_strip_all_tags( $wp_content ) );
        self::cocon_log( 'draft_created', 'Brouillon #' . $post_id, array(
            'job_id'    => $job_id,
            'cocon_id'  => $cocon_id,
            'title'     => $wp_title,
            'slug'      => $wp_slug,
            'words'     => $word_count,
            'has_metas' => ( ! empty( $meta_title ) && ! empty( $meta_desc ) ) ? 'yes' : 'partial',
            'keyword'   => $keyword,
            'auto'      => $auto_generated,
        ) );

        return array(
            'post_id'      => $post_id,
            'title'        => $wp_title,
            'slug'         => $wp_slug,
            'words'        => $word_count,
            'edit_url'     => get_edit_post_link( $post_id, 'raw' ),
            'images'       => $pipeline_result['images_count'],
            'cross_links'  => $pipeline_result['cross_links'],
            'schemas'      => $pipeline_result['schemas'],
        );
    }

    /**
     * AJAX: Create a WordPress draft from a generated article.
     * Thin wrapper around create_draft_from_article().
     */
    public function ajax_create_draft() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        $cocon_id    = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $article_key = sanitize_text_field( $_POST['article_key'] ?? '' );
        $job_id      = sanitize_text_field( $_POST['job_id'] ?? '' );

        $result = $this->create_draft_from_article( $cocon_id, $article_key, $job_id );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => 'Création du brouillon échouée — vérifiez les logs.' ) );
        }

        wp_send_json_success( $result );
    }

    /**
     * AJAX: Delete a cocon plan.
     */
    public function ajax_delete_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(1);

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $plans    = $this->get_plans();

        if ( isset( $plans[ $cocon_id ] ) ) {
            // Delete on SaaS (best-effort, ignore errors)
            if ( strpos( $cocon_id, 'tmp_' ) !== 0 ) {
                $this->cocon_api_call( 'POST', 'delete-plan', array( 'cocon_id' => $cocon_id ) );
            }
            unset( $plans[ $cocon_id ] );
            update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );
            hts_add_log( sprintf( 'Plan cocon supprimé (#%s)', $cocon_id ), 'info', 'cocon-commander' );
            self::cocon_log( 'plan_deleted', 'Plan supprimé', array( 'cocon_id' => $cocon_id ) );
        }

        wp_send_json_success();
    }

    /**
     * Session P: AJAX — Batch cannibalisation re-check for all articles in a plan.
     * Re-runs embedding-based similarity check against current site content.
     *
     * @since 2.4.8
     */
    public function ajax_batch_cannibal_check() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier(1);

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) wp_send_json_error( 'Plan introuvable.' );

        if ( ! class_exists( 'HTS_Embeddings' ) ) {
            wp_send_json_error( 'Module embeddings non disponible.' );
        }

        $emb = new \HTS_Embeddings();
        $all_vectors = $emb->load_all_vectors( true );
        $pillar_pid = hts_url_to_postid( $plan['pillar_url'] ?? '' );

        $plans = $this->get_plans();
        $ready = 0;
        $cannibal = 0;
        $duplicate = 0;
        $results = array();

        foreach ( $plan['articles'] as $key => $art ) {
            // Skip already received articles
            if ( ( $art['status'] ?? '' ) === self::STATUS_RECEIVED ) continue;

            $conflicts = array();
            $check_text = trim( ( $art['title'] ?? '' ) . ' ' . ( $art['keyword'] ?? '' ) );

            if ( ! empty( $all_vectors ) && ! empty( $check_text ) ) {
                $proposed_vector = $emb->get_embedding( $check_text );
                if ( ! empty( $proposed_vector ) ) {
                    foreach ( $all_vectors as $pid => $vec ) {
                        if ( $pillar_pid && $pid === $pillar_pid ) continue;
                        $sim = \HTS_Embeddings::cosine_similarity( $proposed_vector, $vec );
                        if ( $sim >= 0.82 ) {
                            $conflicts[] = array(
                                'post_id'    => $pid,
                                'title'      => get_the_title( $pid ),
                                'similarity' => round( $sim * 100 ),
                            );
                        }
                    }
                }
            }

            // Also run quick precheck
            $precheck = $this->precheck_article( $art['keyword'] ?? '', $plan['pillar_url'] ?? '', true );

            if ( $precheck['result'] === self::STATUS_DUPLICATE ) {
                $new_status = self::STATUS_DUPLICATE;
                $duplicate++;
            } elseif ( ! empty( $conflicts ) ) {
                $new_status = self::STATUS_SIMILAR;
                $cannibal++;
            } else {
                $new_status = self::STATUS_TO_GENERATE;
                $ready++;
            }

            // Update plan
            if ( isset( $plans[ $cocon_id ]['articles'][ $key ] ) ) {
                $plans[ $cocon_id ]['articles'][ $key ]['status'] = $new_status;
                $plans[ $cocon_id ]['articles'][ $key ]['cannibal_conflicts'] = $conflicts;
            }

            $results[ $key ] = array(
                'keyword'   => $art['keyword'] ?? '',
                'status'    => $new_status,
                'conflicts' => count( $conflicts ),
            );
        }

        // Update summary
        $plans[ $cocon_id ]['batch_summary'] = array(
            'total'    => count( $plan['articles'] ),
            'ready'    => $ready,
            'cannibal' => $cannibal,
            'duplicate' => $duplicate,
        );
        $plans[ $cocon_id ]['updated_at'] = current_time( 'Y-m-d H:i:s' );
        update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );

        wp_send_json_success( array(
            'summary' => $plans[ $cocon_id ]['batch_summary'],
            'results' => $results,
        ) );
    }

    /**
     * Session P: AJAX — Get plan summary with batch cannibal info.
     *
     * @since 2.4.8
     */
    public function ajax_plan_summary() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) wp_send_json_error( 'Plan introuvable.' );

        $summary = $plan['batch_summary'] ?? array();
        $articles_list = array();

        foreach ( $plan['articles'] as $key => $art ) {
            $articles_list[] = array(
                'key'       => $key,
                'keyword'   => $art['keyword'] ?? '',
                'title'     => $art['title'] ?? '',
                'status'    => $art['status'] ?? '',
                'conflicts' => count( $art['cannibal_conflicts'] ?? array() ),
                'conflict_titles' => array_map( function( $c ) {
                    return $c['title'] . ' (' . $c['similarity'] . '%)';
                }, array_slice( $art['cannibal_conflicts'] ?? array(), 0, 3 ) ),
            );
        }

        wp_send_json_success( array(
            'summary'  => $summary,
            'articles' => $articles_list,
        ) );
    }

    /* =========================================================================
     * PHASE 6b — PUBLISH PRIORITY
     *
     * Calculates a priority score for each article in a plan.
     * Used for sorting in Commander + Calendar.
     * ====================================================================== */

    /**
     * Calculate publish priority for an article.
     *
     * Priority factors:
     * - Keyword volume hint (from SaaS payload)
     * - Position in plan (first articles = higher priority)
     * - Intent: info > transactional > navigational
     * - Duplicate status penalty
     *
     * @param array  $article Article data from plan
     * @param int    $position 0-based index in plan
     * @param int    $total    Total articles in plan
     * @return int Priority score (0-100, higher = publish first)
     */
    public function calculate_priority( array $article, $position = 0, $total = 1 ) {
        $score = 50; // Base

        // Position bonus: earlier articles get higher priority
        if ( $total > 1 ) {
            $position_bonus = (int) round( 20 * ( 1 - $position / ( $total - 1 ) ) );
            $score += $position_bonus;
        }

        // Intent bonus
        $intent_scores = array(
            'info'           => 15,
            'informational'  => 15,
            'transactional'  => 10,
            'commercial'     => 10,
            'navigational'   => 5,
        );
        $score += $intent_scores[ $article['intent'] ?? 'info' ] ?? 10;

        // Volume hint (if SaaS sends it)
        $volume = (int) ( $article['volume'] ?? 0 );
        if ( $volume > 1000 ) {
            $score += 15;
        } elseif ( $volume > 100 ) {
            $score += 8;
        } elseif ( $volume > 0 ) {
            $score += 3;
        }

        // Penalty for duplicates/similar
        if ( ( $article['status'] ?? '' ) === self::STATUS_DUPLICATE ) {
            $score -= 30;
        } elseif ( ( $article['status'] ?? '' ) === self::STATUS_SIMILAR ) {
            $score -= 15;
        }

        return max( 0, min( 100, $score ) );
    }

    /**
     * Calculate and store priorities for all articles in a plan.
     *
     * @param string $cocon_id
     * @return array Updated plan
     */
    public function update_plan_priorities( $cocon_id ) {
        $plans = $this->get_plans();
        if ( ! isset( $plans[ $cocon_id ] ) ) return null;

        $plan  = $plans[ $cocon_id ];
        $total = count( $plan['articles'] );
        $pos   = 0;

        foreach ( $plan['articles'] as $key => &$article ) {
            $priority = $this->calculate_priority( $article, $pos, $total );
            $article['publish_priority'] = $priority;
            $pos++;
        }
        unset( $article );

        $plans[ $cocon_id ] = $plan;
        update_option( self::PLANS_OPTION, $plans, false ); delete_transient( 'hts_cocon_plans_cache' );

        return $plan;
    }

    /**
     * Apply priority meta to a received article post.
     *
     * @param int    $post_id
     * @param string $cocon_id
     * @param string $article_key
     */
    private function apply_priority_meta( $post_id, $cocon_id, $article_key ) {
        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan || ! isset( $plan['articles'][ $article_key ] ) ) return;

        $article  = $plan['articles'][ $article_key ];
        $priority = $article['publish_priority'] ?? $this->calculate_priority( $article );

        update_post_meta( $post_id, '_hts_cocon_publish_priority', $priority );
        update_post_meta( $post_id, '_hts_cocon_id', $cocon_id );
    }

    /* =========================================================================
     * PHASE 6b — AUTO-LINKING FRÈRES
     *
     * When a cocon article is published, automatically add internal links
     * to/from sibling articles in the same cocon.
     *
     * RULES:
     * - Pillar link is SACRÉ — never touched by auto-linking
     * - Only links to published siblings
     * - Preserves existing HTS links (from hacktheseo.com SaaS)
     * - Max 3 sibling links per article to keep it natural
     * ====================================================================== */

    /**
     * Hook: transition_post_status — triggered when any post changes status.
     *
     * @param string   $new_status
     * @param string   $old_status
     * @param \WP_Post $post
     */
    public function on_post_publish( $new_status, $old_status, $post ) {
        // Only act when going TO publish
        if ( $new_status !== 'publish' || $old_status === 'publish' ) return;
        if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) return;

        $cocon_id = get_post_meta( $post->ID, '_hts_cocon_id', true );

        // ── Commander cocon: sibling links (existing behavior) ──
        if ( ! empty( $cocon_id ) ) {
            if ( ! wp_next_scheduled( 'hts_deferred_sibling_links', array( $post->ID, $cocon_id ) ) ) {
                wp_schedule_single_event( time() + 15, 'hts_deferred_sibling_links', array( $post->ID, $cocon_id ) );
            }
            if ( get_option( 'hts_cross_cocon_enabled', false ) ) {
                $this->propose_cross_cocon_links( $post->ID, $cocon_id );
            }
        }

        // ── Sprint 6.2c: Auto-inject money page link into newly published article ──
        $money_target = get_post_meta( $post->ID, '_hts_money_target', true );

        // Debug log for tracing
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( '[6.2c] on_post_publish #%d « %s » cocon_id=%s money_target_meta=%s',
                $post->ID, mb_substr( $post->post_title, 0, 30 ), $cocon_id ?: '(vide)', $money_target ?: '(vide)' ),
                'info', 'cocon-commander'
            );
        }

        if ( ! $money_target && ! empty( $cocon_id ) ) {
            // Fallback 1: look for money page in the cocon plan
            $plan = $this->get_plan( $cocon_id );
            if ( $plan && ! empty( $plan['money_page_id'] ) ) {
                $money_target = (int) $plan['money_page_id'];
            }
        }
        if ( ! $money_target ) {
            // Fallback 2: find money page via NLP cluster membership or cocon_id
            $cocon_data_mp = self::load_cocon_data();
            $clusters_mp   = $cocon_data_mp['clusters'] ?? array();
            foreach ( $clusters_mp as $cname_mp => $cl_mp ) {
                $cl_pages_mp = array_map( 'intval', $cl_mp['pages'] ?? array() );
                // Match by page membership OR by cocon_id matching cluster name
                $in_cluster = in_array( $post->ID, $cl_pages_mp, true );
                if ( ! $in_cluster && ! empty( $cocon_id ) ) {
                    // Check if any page in this cluster shares the same cocon_id
                    foreach ( $cl_pages_mp as $check_pid ) {
                        if ( get_post_meta( $check_pid, '_hts_cocon_id', true ) === $cocon_id ) {
                            $in_cluster = true;
                            break;
                        }
                    }
                }
                if ( ! $in_cluster ) continue;

                // Found article's cluster — look for money pages in this cluster
                foreach ( $cl_pages_mp as $cpid ) {
                    if ( $cpid === $post->ID ) continue;
                    if ( get_post_meta( $cpid, '_hts_money_page', true ) ) {
                        $money_target = $cpid;
                        break 2;
                    }
                }
                // Also check pillar as money target
                $pil_id = (int) ( $cl_mp['pillar_id'] ?? 0 );
                if ( $pil_id > 0 && $pil_id !== $post->ID && get_post_meta( $pil_id, '_hts_money_page', true ) ) {
                    $money_target = $pil_id;
                }
                break;
            }
        }
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( '[6.2c] money_target résolu = %s pour post #%d', $money_target ?: '(aucun)', $post->ID ), 'info', 'cocon-commander' );
        }
        if ( $money_target ) {
            $money_target = (int) $money_target;
            $money_post_obj = get_post( $money_target );
            if ( $money_post_obj && $money_target !== $post->ID ) {
                // Sprint Robustesse: skip cross-language money links
                if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
                    $post_lang  = HTS_Language::get_post_language( $post->ID ) ?: '';
                    $money_lang = HTS_Language::get_post_language( $money_target ) ?: '';
                    if ( $post_lang && $money_lang && $post_lang !== $money_lang ) {
                        $money_post_obj = null; // Skip — different language
                    }
                }
            }
            if ( $money_post_obj && $money_target !== $post->ID ) {
                $money_url     = get_permalink( $money_target );
                $money_rel_url = wp_make_link_relative( $money_url );
                $content       = $post->post_content;

                // Check if money link already exists
                $has_money_link = false;
                if ( $money_url && strpos( $content, $money_url ) !== false ) $has_money_link = true;
                if ( ! $has_money_link && $money_rel_url && strpos( $content, $money_rel_url ) !== false ) $has_money_link = true;

                if ( ! $has_money_link ) {
                    $money_keyword = get_post_meta( $money_target, '_hts_focus_keyword', true ) ?: $money_post_obj->post_title;
                    $anchor        = $this->find_contextual_anchor( $content, $money_keyword, $money_post_obj->post_title );
                    $anchor_text   = $anchor ?: $money_keyword;
                    $link_html     = '<a href="' . esc_url( $money_url ) . '" data-hts="money" title="' . esc_attr( $money_post_obj->post_title ) . '">' . esc_html( $anchor_text ) . '</a>';

                    $new_content = $this->insert_contextual_link( $content, $link_html, $anchor_text, $money_keyword, $post->ID );

                    if ( $new_content && $new_content !== $content ) {
                        $money_update = wp_update_post( array( 'ID' => $post->ID, 'post_content' => $new_content ) );
                        if ( is_wp_error( $money_update ) || 0 === $money_update ) {
                            hts_debug_log( sprintf( '[6.2c] wp_update_post failed for money link on #%d: %s',
                                $post->ID, is_wp_error( $money_update ) ? $money_update->get_error_message() : 'returned 0' ), 'cocon-commander' );
                        } else {
                        if ( function_exists( 'hts_add_log' ) ) {
                            hts_add_log(
                                sprintf( '💰 Lien money auto-injecté dans « %s » → « %s »', mb_substr( $post->post_title, 0, 40 ), mb_substr( $money_post_obj->post_title, 0, 40 ) ),
                                'success', 'cocon-commander'
                            );
                        }
                        if ( class_exists( 'HTS_Audit_Trail' ) ) {
                            \HTS_Audit_Trail::log_link( $post->ID, $money_target, $anchor_text, 'link_to_money', $content, $new_content, \HTS_Audit_Trail::get_gsc_snapshot( $post->ID ) );
                        }
                        // Sprint 6.2d: sync outbound link counter
                        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                            \HTS_Workflow_Engine::recount_internal_links( $post->ID );
                        }
                        }
                    }
                }
            }
        }

        // ── NLP cluster: auto-propose link to cluster pillar (new behavior) ──
        $cocon_data = self::load_cocon_data();
        $clusters   = $cocon_data['clusters'] ?? array();
        if ( ! empty( $clusters ) && class_exists( 'HTS_Workflow_Engine' ) ) {
            foreach ( $clusters as $cl ) {
                $cl_pages  = array_map( 'intval', $cl['pages'] ?? array() );
                $pillar_id = (int) ( $cl['pillar_id'] ?? 0 );
                if ( ! in_array( $post->ID, $cl_pages, true ) ) continue;
                if ( $post->ID === $pillar_id ) break; // Don't link pillar to itself

                // Find the target for this cluster (money page or pillar)
                $target_id = 0;
                if ( $pillar_id > 0 ) {
                    $target_id = $pillar_id;
                }
                // Check if there's a money page override in this cluster
                $mp_target = get_post_meta( $post->ID, '_hts_money_target', true );
                if ( $mp_target ) {
                    $target_id = (int) $mp_target;
                }

                if ( $target_id > 0 && $target_id !== $post->ID ) {
                    $this->propose_cluster_maillage( $target_id, $cl['name'] ?? '', array( $post->ID ) );
                }
                break; // Found the cluster, stop looking
            }
        }
    }

    /**
     * Sprint 6.2d: When _hts_cocon_id is assigned/changed on a published post,
     * schedule sibling linking to fix orphans.
     *
     * @param int    $meta_id
     * @param int    $post_id
     * @param string $meta_key
     * @param mixed  $meta_value
     */
    public function on_cocon_id_changed( $meta_id, $post_id, $meta_key, $meta_value = '' ) {
        if ( $meta_key !== '_hts_cocon_id' ) return;
        if ( empty( $meta_value ) ) return;
        if ( get_post_status( $post_id ) !== 'publish' ) return;
        if ( ! in_array( get_post_type( $post_id ), array( 'post', 'page' ), true ) ) return;

        // Don't double-schedule if on_post_publish already did it
        if ( wp_next_scheduled( 'hts_deferred_sibling_links', array( $post_id, $meta_value ) ) ) return;

        wp_schedule_single_event( time() + 20, 'hts_deferred_sibling_links', array( $post_id, $meta_value ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( '🔗 Cocon assigné : post #%d → cocon « %s » — maillage frères programmé', $post_id, mb_substr( $meta_value, 0, 40 ) ),
                'info', 'cocon-commander'
            );
        }
    }

    /**
     * Auto-link a newly published article with its cocon siblings.
     *
     * @param int    $post_id   The newly published post
     * @param string $cocon_id  The cocon this article belongs to
     * @return array Results summary
     */
    public function auto_link_siblings( $post_id, $cocon_id ) {
        // Sprint Robustesse: if another heavy job is running (e.g. article generation),
        // reschedule this job for later instead of competing for resources
        $busy = get_transient( 'hts_heavy_job_running' );
        if ( $busy && $busy !== 'sibling_links' ) {
            // Reschedule 60s later
            if ( ! wp_next_scheduled( 'hts_deferred_sibling_links', array( $post_id, $cocon_id ) ) ) {
                wp_schedule_single_event( time() + 60, 'hts_deferred_sibling_links', array( $post_id, $cocon_id ) );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( '⏳ Maillage reporté pour #' . $post_id . ' — job en cours : ' . $busy, 'info', 'cocon-commander' );
            }
            return array( 'deferred' => true );
        }
        set_transient( 'hts_heavy_job_running', 'sibling_links', 120 );

        $plan = $this->get_plan( $cocon_id );
        if ( ! $plan ) { delete_transient( 'hts_heavy_job_running' ); return array( 'error' => 'Plan introuvable' ); }

        $post = get_post( $post_id );
        if ( ! $post ) { delete_transient( 'hts_heavy_job_running' ); return array( 'error' => 'Article introuvable' ); }

        $pillar_url = $plan['pillar_url'] ?? '';
        $results    = array( 'links_added' => 0, 'links_from_siblings' => 0 );

        // Get all published siblings in this cocon (excluding pillar and self)
        $siblings = $this->get_published_siblings( $cocon_id, $post_id, $pillar_url );

        if ( empty( $siblings ) ) {
            delete_transient( 'hts_heavy_job_running' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( 'Maillage #%d : premier article du cocon — les liens internes seront ajoutés automatiquement à la publication des prochains articles.', $post_id ),
                    'info', 'cocon-commander'
                );
            }
            $results['message'] = 'Les liens internes seront ajoutés automatiquement à la publication des prochains articles.';
            return $results;
        }

        // ── A. Add links FROM this article TO siblings ──
        $added_out = $this->insert_sibling_links( $post_id, $siblings, $pillar_url );
        $results['links_added'] = $added_out;

        // ── B. Add link FROM siblings TO this article ──
        $post_url     = get_permalink( $post_id );
        $post_keyword = get_post_meta( $post_id, '_hts_focus_keyword', true ) ?: $post->post_title;

        foreach ( $siblings as $sibling ) {
            $sib_added = $this->insert_single_link_to_post(
                $sibling['post_id'],
                $post_url,
                $post_keyword,
                $pillar_url
            );
            if ( $sib_added ) $results['links_from_siblings']++;
        }

        // Fix 1: Recount links pour le post ET chaque frère modifié
        if ( class_exists( 'HTS_Workflow_Engine' ) && method_exists( 'HTS_Workflow_Engine', 'recount_internal_links' ) ) {
            \HTS_Workflow_Engine::recount_internal_links( $post_id );
            foreach ( $siblings as $sibling ) {
                \HTS_Workflow_Engine::recount_internal_links( (int) $sibling['post_id'] );
            }
        }

        // Fix A: Ajouter le post au cluster dans hts_cocon_data pour que le graph se mette à jour
        $lang = class_exists( 'HTS_Language' ) ? \HTS_Language::get_current_lang() : '';
        $cocon_option_key = ( $lang && class_exists( 'HTS_Language' ) && \HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang
            : 'hts_cocon_data';
        $cocon_data_live = get_option( $cocon_option_key, array() );
        $clusters_live = $cocon_data_live['clusters'] ?? array();
        $post_added = false;

        foreach ( $clusters_live as $cname => &$cl ) {
            $cl_pages = array_map( 'intval', $cl['pages'] ?? array() );
            foreach ( $siblings as $sib ) {
                if ( in_array( (int) $sib['post_id'], $cl_pages, true ) ) {
                    if ( ! in_array( $post_id, $cl_pages, true ) ) {
                        $cl['pages'][] = $post_id;
                        $post_added = true;
                    }
                    break 2;
                }
            }
        }
        unset( $cl );

        if ( $post_added ) {
            $cocon_data_live['clusters'] = $clusters_live;
            update_option( $cocon_option_key, $cocon_data_live, false );
            if ( class_exists( 'HTS_Cocon' ) && property_exists( 'HTS_Cocon', 'cocon_data_cache' ) ) {
                \HTS_Cocon::$cocon_data_cache = array();
            }
        }

        // Invalider les caches transient linking
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient%hts\_cluster\_links\_%'" );

        hts_add_log(
            sprintf(
                'Auto-linking cocon : %s → %d liens sortants, %d liens entrants depuis frères',
                $post->post_title, $results['links_added'], $results['links_from_siblings']
            ),
            'success', 'cocon-commander'
        );

        delete_transient( 'hts_heavy_job_running' );
        return $results;
    }

    /**
     * Get published siblings for a cocon, excluding pillar and a given post.
     *
     * @param string $cocon_id
     * @param int    $exclude_post_id
     * @param string $pillar_url
     * @return array [ [ post_id, title, url, keyword ] ]
     */
    private function get_published_siblings( $cocon_id, $exclude_post_id = 0, $pillar_url = '' ) {
        $siblings = array();
        $posts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'meta_key'       => '_hts_cocon_id',
            'meta_value'     => $cocon_id,
            'posts_per_page' => 50,
            'exclude'        => $exclude_post_id ? array( $exclude_post_id ) : array(),
        ) );

        // Sprint Robustesse: filter by language — only link same-language siblings
        $source_lang = '';
        if ( $exclude_post_id > 0 && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $source_lang = HTS_Language::get_post_language( $exclude_post_id ) ?: '';
        }

        foreach ( $posts as $p ) {
            $url = get_permalink( $p->ID );
            // Skip pillar — lien pilier SACRÉ, jamais touché
            if ( $this->is_pillar_url( $url, $pillar_url ) ) continue;

            // Skip cross-language siblings
            if ( $source_lang && class_exists( 'HTS_Language' ) ) {
                $sib_lang = HTS_Language::get_post_language( $p->ID ) ?: '';
                if ( $sib_lang && $sib_lang !== $source_lang ) continue;
            }

            $siblings[] = array(
                'post_id' => $p->ID,
                'title'   => $p->post_title,
                'url'     => $url,
                'keyword' => get_post_meta( $p->ID, '_hts_focus_keyword', true ) ?: $p->post_title,
            );
        }

        return $siblings;
    }

    /**
     * AJAX: Rescan maillage for a cocon — re-run auto_link_siblings on all published articles.
     *
     * Useful for:
     *  - Articles published before the plugin was installed
     *  - After content edits that changed internal links
     *  - Manual re-linking when automatic linking missed articles
     *
     * If cocon_id is 'all', rescans all cocons.
     * Will be converted to cron in a future sprint.
     */
    public function ajax_rescan_maillage() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );

        // Sprint Robustesse: block if articles are generating
        $busy = get_transient( 'hts_heavy_job_running' );
        if ( $busy && $busy === 'article_generation' ) {
            wp_send_json_error( 'Des articles sont en cours de génération. Relancez le maillage dans quelques minutes.' );
        }

        // Auto-detect limited server
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time <= 60 && class_exists( 'HTS_Job_Runner' ) ) {
            wp_send_json_error( array( 'message' => 'use_batch', 'batch_init' => 'hts_cocon_rescan_init', 'batch_step' => 'hts_cocon_rescan_step' ) );
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 120 );

        $cocon_id = isset( $_POST['cocon_id'] ) ? sanitize_text_field( $_POST['cocon_id'] ) : '';
        if ( empty( $cocon_id ) ) wp_send_json_error( 'cocon_id manquant.' );

        $plans = get_option( 'hts_cocon_plans', array() );
        $target_cocons = array();

        if ( $cocon_id === 'all' ) {
            $target_cocons = array_keys( $plans );
        } elseif ( isset( $plans[ $cocon_id ] ) ) {
            $target_cocons = array( $cocon_id );
        } else {
            wp_send_json_error( 'Cocon introuvable.' );
        }

        $total_links_added     = 0;
        $total_links_from_sibs = 0;
        $total_articles        = 0;
        $cocons_processed      = 0;
        $cross_proposals       = 0;
        $cross_cocon_enabled   = (bool) get_option( 'hts_cross_cocon_enabled', false );

        foreach ( $target_cocons as $cid ) {
            $plan = $plans[ $cid ] ?? null;
            if ( ! $plan ) continue;

            // Get all published articles in this cocon
            $articles = get_posts( array(
                'post_type'      => array( 'post', 'page' ),
                'post_status'    => 'publish',
                'meta_key'       => '_hts_cocon_id',
                'meta_value'     => $cid,
                'posts_per_page' => 100,
                'fields'         => 'ids',
            ) );

            if ( empty( $articles ) ) continue;

            $cocons_processed++;

            foreach ( $articles as $pid ) {
                $result = $this->auto_link_siblings( $pid, $cid );
                $total_links_added     += (int) ( $result['links_added'] ?? 0 );
                $total_links_from_sibs += (int) ( $result['links_from_siblings'] ?? 0 );
                $total_articles++;

                // Also regenerate cross-cocon proposals if enabled
                if ( $cross_cocon_enabled ) {
                    $proposals = $this->propose_cross_cocon_links( $pid, $cid );
                    $cross_proposals += is_array( $proposals ) ? count( $proposals ) : 0;
                }
            }
        }

        $message = sprintf(
            '%d article(s) traité(s) sur %d cocon(s) — %d liens sortants ajoutés, %d liens entrants depuis frères',
            $total_articles, $cocons_processed, $total_links_added, $total_links_from_sibs
        );
        if ( $cross_proposals > 0 ) {
            $message .= sprintf( ', %d proposition(s) cross-cocon', $cross_proposals );
        }

        hts_add_log( '🔗 Rescan maillage : ' . $message, 'success', 'cocon-commander' );

        wp_send_json_success( array(
            'message'          => $message,
            'articles'         => $total_articles,
            'cocons'           => $cocons_processed,
            'links_added'      => $total_links_added,
            'links_from_sibs'  => $total_links_from_sibs,
            'cross_proposals'  => $cross_proposals,
        ) );
    }

    /**
     * Check if a URL is the pillar URL (sacré — skip_pillar).
     *
     * @param string $url
     * @param string $pillar_url
     * @return bool
     */
    private function is_pillar_url( $url, $pillar_url ) {
        if ( empty( $pillar_url ) ) return false;

        $normalized_url    = untrailingslashit( strtolower( $url ) );
        $normalized_pillar = untrailingslashit( strtolower( $pillar_url ) );

        // Compare as-is and with home_url prefix
        if ( $normalized_url === $normalized_pillar ) return true;
        if ( $normalized_url === untrailingslashit( strtolower( $pillar_url ) ) ) return true;

        return false;
    }

    /**
     * Insert links from a post to sibling articles.
     * Preserves existing HTS links (from hacktheseo.com).
     * Max 3 sibling links to keep content natural.
     *
     * @param int    $post_id
     * @param array  $siblings
     * @param string $pillar_url
     * @return int Number of links inserted
     */
    private function insert_sibling_links( $post_id, array $siblings, $pillar_url = '' ) {
        $post = get_post( $post_id );
        if ( ! $post ) return 0;

        // ── REINFORCEMENT LEARNING: Check if sibling linking works for this profile ──
        if ( class_exists( 'HTS_Strategy_Engine' ) ) {
            $pattern = \HTS_Strategy_Engine::get_pattern_for_post( 'link_sibling', $post_id );
            if ( $pattern && $pattern['status'] === 'inefficace' && $pattern['sample_size'] >= 5 ) {
                // Pattern shows sibling links hurt this article profile — skip with log
                self::cocon_log( 'sibling_skip_pattern', '🧠 Liens frères ignorés (pattern inefficace)', array(
                    'post_id'    => $post_id,
                    'confidence' => $pattern['confidence'],
                    'sample'     => $pattern['sample_size'],
                    'profile'    => $pattern['profile'],
                ) );
                return 0;
            }
        }

        $content_before = $post->post_content; // Snapshot for Audit Trail
        $content = $content_before;
        $added   = 0;

        // M5: Limite globale à 3 liens HTS (existants + nouveaux)
        $existing_hts_links = $this->count_hts_links( $content );
        $max_links = max( 0, 3 - $existing_hts_links );
        if ( $max_links <= 0 ) return 0;

        // Sort siblings by priority (if available, via post meta)
        usort( $siblings, function( $a, $b ) {
            $pa = (int) get_post_meta( $a['post_id'], '_hts_cocon_publish_priority', true );
            $pb = (int) get_post_meta( $b['post_id'], '_hts_cocon_publish_priority', true );
            return $pb - $pa; // Higher priority first
        } );

        $inserted_siblings = array(); // Track for audit trail

        foreach ( $siblings as $sib ) {
            if ( $added >= $max_links ) break;

            // Skip if link already exists
            if ( strpos( $content, $sib['url'] ) !== false ) continue;
            // Also check relative URL
            $rel_url = wp_make_link_relative( $sib['url'] );
            if ( $rel_url && strpos( $content, $rel_url ) !== false ) continue;

            // Find a good insertion point (paragraph containing related terms)
            // Try contextual anchor first (anchor diversity), fallback to keyword
            $contextual_anchor = $this->find_contextual_anchor( $content, $sib['keyword'], $sib['title'] );
            $anchor_text = $contextual_anchor ?: $sib['keyword'];
            $link_html   = '<a href="' . esc_url( $sib['url'] ) . '" title="' . esc_attr( $sib['title'] ) . '">' . esc_html( $anchor_text ) . '</a>';

            $new_content = $this->insert_contextual_link( $content, $link_html, $anchor_text, $sib['keyword'], $post_id );

            if ( $new_content && $new_content !== $content ) {
                $content = $new_content;
                $added++;
                $inserted_siblings[] = $sib;
            }
        }

        if ( $added > 0 ) {
            // Use Content Writer for builder-aware save (Elementor, Beaver, Bricks, etc.)
            $update_result = wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );
            if ( is_wp_error( $update_result ) || 0 === $update_result ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Cross-link injection: wp_update_post failed for post #{$post_id}: " . ( is_wp_error( $update_result ) ? $update_result->get_error_message() : 'returned 0' ), 'error', 'cocon' );
                }
            } else {
                if ( class_exists( 'HTS_Content_Writer' ) ) {
                    $builder = \HTS_Content_Writer::detect_builder( $post_id );
                    if ( in_array( $builder, array( 'elementor', 'beaver', 'bricks' ), true ) ) {
                        \HTS_Content_Extractor::invalidate_cache( $post_id );
                    }
                }
                // Sprint 6.2d: sync outbound link counter after insertion
                if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                    \HTS_Workflow_Engine::recount_internal_links( $post_id );
                }
            }

            // ── Audit Trail: log each sibling link for GSC feedback monitoring ──
            if ( class_exists( 'HTS_Audit_Trail' ) ) {
                $gsc_snapshot = \HTS_Audit_Trail::get_gsc_snapshot( $post_id );
                foreach ( $inserted_siblings as $sib ) {
                    \HTS_Audit_Trail::log_link(
                        $post_id,
                        absint( $sib['post_id'] ),
                        $sib['keyword'],
                        'link_sibling',
                        $content_before,
                        $content,
                        $gsc_snapshot
                    );
                }
            }
        }

        return $added;
    }

    /**
     * Insert a single link to a target post into a source post.
     * Used for reverse-linking (sibling → newly published article).
     *
     * @param int    $source_post_id
     * @param string $target_url
     * @param string $target_keyword
     * @param string $pillar_url
     * @return bool
     */
    private function insert_single_link_to_post( $source_post_id, $target_url, $target_keyword, $pillar_url = '' ) {
        $post = get_post( $source_post_id );
        if ( ! $post ) return false;

        $content_before = $post->post_content;

        // Don't add if link already exists
        if ( strpos( $content_before, $target_url ) !== false ) return false;
        $rel_url = wp_make_link_relative( $target_url );
        if ( $rel_url && strpos( $content_before, $rel_url ) !== false ) return false;

        $link_html = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( $target_keyword ) . '">' . esc_html( $target_keyword ) . '</a>';

        $new_content = $this->insert_contextual_link( $content_before, $link_html, $target_keyword, $target_keyword, $source_post_id );

        if ( $new_content && $new_content !== $content_before ) {
            $src_result = wp_update_post( array(
                'ID'           => $source_post_id,
                'post_content' => $new_content,
            ) );
            if ( is_wp_error( $src_result ) || 0 === $src_result ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Cross-link source update failed for post #{$source_post_id}: " . ( is_wp_error( $src_result ) ? $src_result->get_error_message() : 'returned 0' ), 'error', 'cocon' );
                }
            } else {
                // M4: Invalider le cache APRÈS le save réussi (pas avant)
                if ( class_exists( 'HTS_Content_Writer' ) ) {
                    \HTS_Content_Extractor::invalidate_cache( $source_post_id );
                }
                // Sprint 6.2d: sync outbound link counter
                if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                    \HTS_Workflow_Engine::recount_internal_links( $source_post_id );
                }
            }

            // ── Audit Trail: log for GSC feedback monitoring ──
            if ( class_exists( 'HTS_Audit_Trail' ) ) {
                $target_id = hts_url_to_postid( $target_url );
                \HTS_Audit_Trail::log_link(
                    $source_post_id,
                    $target_id ?: 0,
                    $target_keyword,
                    'link_sibling',
                    $content_before,
                    $new_content,
                    \HTS_Audit_Trail::get_gsc_snapshot( $source_post_id )
                );
            }

            return true;
        }

        return false;
    }

    /**
     * Insert a link in a contextually appropriate paragraph.
     *
     * Multi-format strategy (inspired by Full v4):
     * 1. Standard <p> tags (classic HTML, Divi, WPBakery, etc.)
     * 2. Gutenberg paragraph blocks (<!-- wp:paragraph -->)
     * 3. Generic text containers (div.text, div.content, etc.)
     * 4. Any block-level element with 20+ words of visible text
     * 5. Append dedicated paragraph at end of content (always works)
     *
     * Each strategy prefers placement after first H2 (intro zone reserved),
     * scores by keyword relevance, and falls back gracefully.
     *
     * @param string $content     Post content (any builder format)
     * @param string $link_html   Complete <a> tag
     * @param string $anchor_text Text of the anchor
     * @param string $keyword     Keyword to match in paragraphs
     * @param int    $post_id     Post ID (enables builder-aware append via Content Writer)
     * @return string Modified content (never null thanks to append fallback)
     */
    private function insert_contextual_link( $content, $link_html, $anchor_text, $keyword, $post_id = 0 ) {
        // Build the connector phrase in the site's language
        $locale = get_locale();
        $lang = strtolower( substr( $locale, 0, 2 ) );

        $phrases_by_lang = array(
            'fr' => array(
                'Découvrez également notre article sur %s.',
                'Pour aller plus loin, consultez %s.',
                'Retrouvez aussi %s sur notre site.',
            ),
            'en' => array(
                'Discover more in our article on %s.',
                'For further reading, check out %s.',
                'See also %s on our site.',
            ),
            'es' => array(
                'Descubra también nuestro artículo sobre %s.',
                'Para ir más lejos, consulte %s.',
                'Encuentre también %s en nuestro sitio.',
            ),
            'de' => array(
                'Entdecken Sie auch unseren Artikel über %s.',
                'Für mehr Informationen lesen Sie %s.',
                'Sehen Sie auch %s auf unserer Website.',
            ),
            'it' => array(
                'Scoprite anche il nostro articolo su %s.',
                'Per approfondire, consultate %s.',
                'Trovate anche %s sul nostro sito.',
            ),
            'pt' => array(
                'Descubra também nosso artigo sobre %s.',
                'Para ir mais longe, consulte %s.',
                'Confira também %s em nosso site.',
            ),
            'nl' => array(
                'Ontdek ook ons artikel over %s.',
                'Lees verder in %s.',
                'Bekijk ook %s op onze website.',
            ),
            'ja' => array(
                '%s についてもご覧ください。',
                '詳しくは %s をお読みください。',
                'こちらもおすすめ: %s。',
            ),
            'zh' => array(
                '另请参阅 %s。',
                '了解更多: %s。',
                '推荐阅读: %s。',
            ),
            'ar' => array(
                'اطلع أيضًا على %s.',
                'لمزيد من المعلومات، راجع %s.',
                'اقرأ أيضًا %s.',
            ),
            'ru' => array(
                'Ознакомьтесь также с %s.',
                'Подробнее читайте в %s.',
                'Смотрите также %s.',
            ),
            'ko' => array(
                '%s도 함께 확인해 보세요.',
                '자세한 내용은 %s를 참조하세요.',
                '추천 글: %s.',
            ),
            'pl' => array(
                'Sprawdź również nasz artykuł o %s.',
                'Dowiedz się więcej: %s.',
                'Zobacz także %s na naszej stronie.',
            ),
            'sv' => array(
                'Läs även vår artikel om %s.',
                'Läs mer i %s.',
                'Se även %s på vår webbplats.',
            ),
            'tr' => array(
                '%s hakkındaki makalemizi de keşfedin.',
                'Daha fazla bilgi için %s adresine bakın.',
                'Ayrıca sitemizde %s konusuna göz atın.',
            ),
        );

        $phrases = $phrases_by_lang[ $lang ] ?? $phrases_by_lang['en'];
        // M2: Phrase déterministe (basée sur post_id + anchor) pour éviter doublons en re-run
        $phrase_idx = abs( crc32( $post_id . '|' . $anchor_text ) ) % count( $phrases );
        $phrase = sprintf( $phrases[ $phrase_idx ], $link_html );

        // ══════════════════════════════════════════════════════════
        // SPRINT ROBUSTESSE: For visual builders (Elementor/Beaver/Bricks),
        // modifying post_content directly works for SEO (Google reads it) BUT
        // the link gets overwritten when the user edits in the builder (builder
        // re-renders from its own JSON, ignoring post_content changes).
        // → Use Content_Writer::append_paragraph() which syncs BOTH builder
        //   JSON and post_content atomically.
        // ══════════════════════════════════════════════════════════
        if ( $post_id > 0 && class_exists( 'HTS_Content_Writer' ) ) {
            $builder = \HTS_Content_Writer::detect_builder( $post_id );
            if ( in_array( $builder, array( 'elementor', 'beaver', 'bricks' ), true ) ) {
                $append_result = \HTS_Content_Writer::append_paragraph( $post_id, $phrase );
                if ( $append_result['success'] ) {
                    clean_post_cache( $post_id );
                    $refreshed = get_post( $post_id );
                    return $refreshed ? $refreshed->post_content : $this->append_link_paragraph( $content, $phrase );
                }
                // Builder append failed → fall through to HTML strategies as last resort
            }
        }

        // ══════════════════════════════════════════════════════════
        // PHASE A: Try to insert link phrase into existing paragraph
        // Works on post_content for standard, Gutenberg, Divi, WPBakery
        // (all store HTML in post_content as the canonical source).
        // ══════════════════════════════════════════════════════════

        // Strategy 1: Standard <p> tags (classic HTML, Divi, WPBakery, etc.)
        $result = $this->insert_link_in_paragraphs( $content, $phrase, $keyword, '/<p[^>]*>(.*?)<\/p>/si' );
        if ( $result ) return $result;

        // Strategy 2: Gutenberg paragraph blocks
        $result = $this->insert_link_in_gutenberg_blocks( $content, $phrase, $keyword );
        if ( $result ) return $result;

        // Strategy 3: Generic block-level elements (div.text, div.content, etc.)
        $result = $this->insert_link_in_paragraphs( $content, $phrase, $keyword, '/<div[^>]*class=["\'][^"\']*(?:text|content|paragraph|entry)[^"\']*["\'][^>]*>(.*?)<\/div>/si' );
        if ( $result ) return $result;

        // Strategy 4: Any block-level text container with enough words
        $result = $this->insert_link_in_text_blocks( $content, $phrase, $keyword );
        if ( $result ) return $result;

        // ══════════════════════════════════════════════════════════
        // PHASE B: No suitable paragraph found → APPEND
        // Use Content Writer::append_paragraph() for builder-aware
        // append (Elementor JSON, Beaver meta, Bricks meta, etc.)
        // ══════════════════════════════════════════════════════════
        if ( $post_id > 0 && class_exists( 'HTS_Content_Writer' ) ) {
            $append_result = \HTS_Content_Writer::append_paragraph( $post_id, $phrase );
            if ( $append_result['success'] ) {
                // Return the refreshed post_content
                clean_post_cache( $post_id );
                $refreshed = get_post( $post_id );
                return $refreshed ? $refreshed->post_content : $this->append_link_paragraph( $content, $phrase );
            }
        }

        // Ultimate fallback: simple append to content string
        return $this->append_link_paragraph( $content, $phrase );
    }

    /**
     * Strategy 1 & 3: Extract paragraphs via regex, score by keyword relevance,
     * prefer placement after first H2.
     *
     * @param string $content  Full post content
     * @param string $phrase   Pre-built connector sentence with link
     * @param string $keyword  Keyword for relevance scoring
     * @param string $pattern  Regex to match paragraph-like elements
     * @return string|null Modified content or null
     */
    private function insert_link_in_paragraphs( $content, $phrase, $keyword, $pattern ) {
        if ( ! preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
            return null;
        }

        // Need at least 2 paragraphs for meaningful placement
        if ( count( $matches ) < 2 ) return null;

        $first_h2_pos = $this->get_first_h2_position( $content );
        $keyword_words = $this->extract_keyword_words( $keyword );

        $best_match    = null;
        $best_score    = -1;
        $fallback_match = null; // Before-H2 fallback (like Full v4)

        foreach ( $matches as $match ) {
            $full_tag   = $match[0][0]; // Full <p>...</p>
            $inner_html = $match[1][0]; // Inner content
            $offset     = $match[0][1]; // Byte offset in content

            // Skip headings embedded in containers
            if ( preg_match( '/<h[1-6]/i', $full_tag ) ) continue;

            // Skip if already has too many links (>2)
            if ( substr_count( mb_strtolower( $full_tag ), '<a ' ) > 2 ) continue;

            // Skip very short paragraphs (less than 15 chars of visible text)
            $visible = wp_strip_all_tags( $inner_html );
            if ( mb_strlen( trim( $visible ) ) < 15 ) continue;

            // Score: keyword relevance
            $p_lower = mb_strtolower( $visible );
            $match_score = 0;
            foreach ( $keyword_words as $w ) {
                if ( mb_strpos( $p_lower, $w ) !== false ) $match_score++;
            }

            // Prefer after H2 (intro zone reserved for pillar link)
            $is_before_h2 = ( $first_h2_pos !== false && $offset < $first_h2_pos );

            if ( $is_before_h2 ) {
                // Save as fallback only
                if ( ! $fallback_match || $match_score > $fallback_match['score'] ) {
                    $fallback_match = array( 'match' => $match, 'score' => $match_score );
                }
                continue;
            }

            if ( $match_score > $best_score ) {
                $best_score = $match_score;
                $best_match = $match;
            }
        }

        // No match after H2 → try 3rd-to-last paragraph after H2
        if ( ! $best_match ) {
            $after_h2_paras = array();
            foreach ( $matches as $m ) {
                $off = $m[0][1];
                if ( $first_h2_pos === false || $off >= $first_h2_pos ) {
                    // Skip headings and short
                    if ( preg_match( '/<h[1-6]/i', $m[0][0] ) ) continue;
                    if ( mb_strlen( trim( wp_strip_all_tags( $m[1][0] ) ) ) < 15 ) continue;
                    $after_h2_paras[] = $m;
                }
            }
            $count = count( $after_h2_paras );
            if ( $count >= 3 ) {
                $best_match = $after_h2_paras[ $count - 3 ];
            } elseif ( $count >= 1 ) {
                $best_match = $after_h2_paras[ $count - 1 ];
            }
        }

        // Still nothing after H2 → use before-H2 fallback
        if ( ! $best_match && $fallback_match ) {
            $best_match = $fallback_match['match'];
        }

        if ( ! $best_match ) return null;

        // Insert phrase before closing tag
        $full_tag  = $best_match[0][0];
        $offset    = $best_match[0][1]; // M1: Byte offset exact du match (PREG_OFFSET_CAPTURE)
        $close_tag = '</p>';
        // Detect actual closing tag from the pattern
        if ( preg_match( '/(<\/\w+>)\s*$/i', $full_tag, $cm ) ) {
            $close_tag = $cm[1];
        }

        $insert_pos = mb_strrpos( $full_tag, $close_tag );
        if ( $insert_pos === false ) return null;

        $new_tag = mb_substr( $full_tag, 0, $insert_pos ) . ' ' . $phrase . mb_substr( $full_tag, $insert_pos );

        // M1: Replace at exact byte offset (not strpos which matches the FIRST occurrence)
        return substr_replace( $content, $new_tag, $offset, strlen( $full_tag ) );
    }

    /**
     * Strategy 2: Handle Gutenberg block format specifically.
     * <!-- wp:paragraph {"attr":"val"} -->\n<p>text</p>\n<!-- /wp:paragraph -->
     *
     * @param string $content
     * @param string $phrase
     * @param string $keyword
     * @return string|null
     */
    private function insert_link_in_gutenberg_blocks( $content, $phrase, $keyword ) {
        // Check if content uses Gutenberg blocks at all
        if ( strpos( $content, '<!-- wp:' ) === false ) return null;

        // Match Gutenberg paragraph blocks
        $pattern = '/<!-- wp:paragraph[^>]*-->\s*<p[^>]*>(.*?)<\/p>\s*<!-- \/wp:paragraph -->/si';

        if ( ! preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
            return null;
        }

        if ( count( $matches ) < 2 ) return null;

        $first_h2_pos  = $this->get_first_h2_position( $content );
        $keyword_words = $this->extract_keyword_words( $keyword );

        $best_match   = null;
        $best_score   = -1;
        $fallback     = null;

        foreach ( $matches as $match ) {
            $full_block = $match[0][0];
            $inner_text = $match[1][0];
            $offset     = $match[0][1];

            $visible = wp_strip_all_tags( $inner_text );
            if ( mb_strlen( trim( $visible ) ) < 15 ) continue;
            if ( substr_count( mb_strtolower( $full_block ), '<a ' ) > 2 ) continue;

            $p_lower = mb_strtolower( $visible );
            $score = 0;
            foreach ( $keyword_words as $w ) {
                if ( mb_strpos( $p_lower, $w ) !== false ) $score++;
            }

            $is_before_h2 = ( $first_h2_pos !== false && $offset < $first_h2_pos );
            if ( $is_before_h2 ) {
                if ( ! $fallback || $score > $fallback['score'] ) {
                    $fallback = array( 'match' => $match, 'score' => $score );
                }
                continue;
            }

            if ( $score > $best_score ) {
                $best_score = $score;
                $best_match = $match;
            }
        }

        // Fallback to positional choice
        if ( ! $best_match ) {
            $after_h2 = array();
            foreach ( $matches as $m ) {
                if ( $first_h2_pos === false || $m[0][1] >= $first_h2_pos ) {
                    if ( mb_strlen( trim( wp_strip_all_tags( $m[1][0] ) ) ) >= 15 ) {
                        $after_h2[] = $m;
                    }
                }
            }
            $count = count( $after_h2 );
            if ( $count >= 3 ) {
                $best_match = $after_h2[ $count - 3 ];
            } elseif ( $count >= 1 ) {
                $best_match = $after_h2[ $count - 1 ];
            }
        }

        if ( ! $best_match && $fallback ) {
            $best_match = $fallback['match'];
        }

        if ( ! $best_match ) return null;

        // Insert before </p> inside the Gutenberg block
        $full_block = $best_match[0][0];
        $new_block  = preg_replace( '/(<\/p>)\s*(<!-- \/wp:paragraph -->)/si', ' ' . $phrase . '$1' . "\n" . '$2', $full_block, 1 );

        if ( $new_block === $full_block ) return null;

        $pos = strpos( $content, $full_block );
        if ( $pos === false ) return null;

        return substr_replace( $content, $new_block, $pos, strlen( $full_block ) );
    }

    /**
     * Strategy 4: Find any block-level element with enough visible text.
     * Works with arbitrary HTML from page builders (Oxygen, custom themes, etc.)
     *
     * @param string $content
     * @param string $phrase
     * @param string $keyword
     * @return string|null
     */
    private function insert_link_in_text_blocks( $content, $phrase, $keyword ) {
        // Match common block-level elements that might contain text
        $pattern = '/<(div|section|article|td|li|blockquote)([^>]*)>((?:(?!<\1[\s>]).)*?)<\/\1>/si';

        if ( ! preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
            return null;
        }

        $first_h2_pos  = $this->get_first_h2_position( $content );
        $keyword_words = $this->extract_keyword_words( $keyword );

        $best = null;
        $best_score = -1;

        foreach ( $matches as $match ) {
            $full_tag = $match[0][0];
            $tag_name = $match[1][0];
            $inner    = $match[3][0];
            $offset   = $match[0][1];

            // Must have substantial text (20+ words)
            $visible = wp_strip_all_tags( $inner );
            if ( hts_word_count( $visible ) < 20 ) continue;

            // Skip if contains nested block elements (we want leaf nodes)
            if ( preg_match( '/<(?:div|section|article|table|ul|ol)\s/i', $inner ) ) continue;

            // Skip headings
            if ( preg_match( '/<h[1-6]/i', $full_tag ) ) continue;

            // Skip if too many links
            if ( substr_count( mb_strtolower( $full_tag ), '<a ' ) > 2 ) continue;

            // Prefer after H2
            $is_before_h2 = ( $first_h2_pos !== false && $offset < $first_h2_pos );
            $base_score = $is_before_h2 ? 0 : 100;

            // Keyword score
            $p_lower = mb_strtolower( $visible );
            foreach ( $keyword_words as $w ) {
                if ( mb_strpos( $p_lower, $w ) !== false ) $base_score += 10;
            }

            if ( $base_score > $best_score ) {
                $best_score = $base_score;
                $best = $match;
            }
        }

        if ( ! $best ) return null;

        $full_tag = $best[0][0];
        $tag_name = strtolower( $best[1][0] );
        $close    = '</' . $tag_name . '>';

        $insert_pos = strrpos( $full_tag, $close );
        if ( $insert_pos === false ) return null;

        // Wrap phrase in <p> for proper block-level insertion
        $wrapped_phrase = '<p>' . $phrase . '</p>';
        $new_tag = substr( $full_tag, 0, $insert_pos ) . ' ' . $wrapped_phrase . substr( $full_tag, $insert_pos );

        $pos = strpos( $content, $full_tag );
        if ( $pos === false ) return null;

        return substr_replace( $content, $new_tag, $pos, strlen( $full_tag ) );
    }

    /**
     * Strategy 5: Append a dedicated paragraph at end of content.
     * Ultimate fallback — always works.
     *
     * @param string $content
     * @param string $phrase
     * @return string
     */
    private function append_link_paragraph( $content, $phrase ) {
        $content = rtrim( $content );

        // For Gutenberg content, add a proper paragraph block
        if ( strpos( $content, '<!-- wp:' ) !== false ) {
            return $content . "\n\n" . '<!-- wp:paragraph -->' . "\n" . '<p>' . $phrase . '</p>' . "\n" . '<!-- /wp:paragraph -->';
        }

        // For standard HTML content
        return $content . "\n" . '<p>' . $phrase . '</p>';
    }

    /**
     * Get position of first H2 in content.
     *
     * @param string $content
     * @return int|false
     */
    private function get_first_h2_position( $content ) {
        return stripos( $content, '<h2' );
    }

    /**
     * Extract significant keyword words (>3 chars) for relevance scoring.
     *
     * @param string $keyword
     * @return array
     */
    private function extract_keyword_words( $keyword ) {
        return array_filter( explode( ' ', mb_strtolower( $keyword ) ), function( $w ) {
            return mb_strlen( $w ) > 3;
        } );
    }

    /* ══════════════════════════════════════════════
     *  ANCHOR DIVERSITY — Contextual anchor extraction
     *  Ported from Full v4 fuzzy_find_anchor + find_alternative_anchors
     *  100% local (no API call), finds real text segments from source content
     * ══════════════════════════════════════════════ */

    /**
     * Find the best contextual anchor in source content for a target article.
     * Extracts a real 2-6 word segment from the source that relates to the target keyword/title.
     *
     * @param string $source_content  HTML content of the source article
     * @param string $target_keyword  Focus keyword of the target
     * @param string $target_title    Title of the target article
     * @return string|null Best anchor found, or null if nothing good enough
     */
    private function find_contextual_anchor( $source_content, $target_keyword, $target_title = '' ) {
        // French stop words
        $stop = array_flip( explode( ',', 'le,la,les,un,une,des,du,de,d,l,en,et,ou,à,a,au,aux,pour,par,sur,dans,avec,sans,ce,ces,son,sa,ses,est,qui,que,quoi,comment,pourquoi,être,avoir,fait,plus,très,bien,tout,cette,aussi,mais,pas,nous,vous,ils' ) );

        // Combine words from keyword + title for broader matching
        $combined = mb_strtolower( html_entity_decode( $target_keyword . ' ' . $target_title, ENT_QUOTES, 'UTF-8' ) );
        $all_words = preg_split( '/[\s,\-:\']+/', $combined );
        $search_words = array_values( array_unique( array_filter( $all_words, function( $w ) use ( $stop ) {
            return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] );
        } ) ) );

        if ( empty( $search_words ) ) return null;

        // Extract visible text from content
        $text = wp_strip_all_tags( $source_content );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        // Split into sentences
        $sentences = preg_split( '/(?<=[.!?;:"])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );

        $candidates = array();

        foreach ( $sentences as $sentence ) {
            $sent_lower = mb_strtolower( $sentence );

            // Count keyword matches in sentence
            $sent_matches = 0;
            foreach ( $search_words as $sw ) {
                if ( mb_strpos( $sent_lower, $sw ) !== false ) $sent_matches++;
            }
            if ( $sent_matches === 0 ) continue;

            $words = preg_split( '/\s+/', trim( $sentence ) );
            if ( count( $words ) < 2 ) continue;

            // Sliding window: 2-6 word segments
            for ( $len = 2; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $start = 0; $start <= count( $words ) - $len; $start++ ) {
                    $segment = implode( ' ', array_slice( $words, $start, $len ) );
                    $segment = trim( preg_replace( '/[.,;:!?]+$/', '', $segment ) );
                    if ( mb_strlen( $segment ) < 8 || mb_strlen( $segment ) > 60 ) continue;

                    $seg_lower = mb_strtolower( $segment );

                    // Count keyword words found in this segment
                    $seg_matches = 0;
                    foreach ( $search_words as $sw ) {
                        if ( mb_strpos( $seg_lower, $sw ) !== false ) $seg_matches++;
                    }
                    if ( $seg_matches === 0 ) continue;

                    // Verify segment exists in HTML content and is not already linked
                    $seg_escaped = preg_quote( $segment, '/' );
                    if ( mb_strpos( $source_content, $segment ) === false ) continue;
                    if ( preg_match( '/<a[^>]*>[^<]*' . $seg_escaped . '/si', $source_content ) ) continue;

                    // Score: keyword matches × length bonus × sentence relevance
                    $score = $seg_matches * 20;
                    $score += ( $len >= 3 && $len <= 5 ) ? 15 : 0; // sweet spot 3-5 words
                    $score += $sent_matches * 5; // sentence-level relevance bonus

                    // Penalize if too similar to target title (we want diversity)
                    $title_sim = similar_text( $seg_lower, mb_strtolower( $target_title ), $pct );
                    if ( $pct > 80 ) $score -= 30; // too close to title = not diverse

                    $candidates[ $segment ] = max( $candidates[ $segment ] ?? 0, $score );
                }
            }
        }

        if ( empty( $candidates ) ) return null;

        // Return the best candidate
        arsort( $candidates );
        return array_keys( $candidates )[0];
    }

    /**
     * Find multiple contextual anchor alternatives for a target.
     * Returns up to 3 diverse anchors, sorted by relevance.
     *
     * @param string $source_content
     * @param string $target_keyword
     * @param string $target_title
     * @return array Up to 3 anchor strings
     */
    private function find_anchor_alternatives( $source_content, $target_keyword, $target_title = '' ) {
        $stop = array_flip( explode( ',', 'le,la,les,un,une,des,du,de,d,l,en,et,ou,à,a,au,aux,pour,par,sur,dans,avec,sans,ce,ces,son,sa,ses,est,qui,que,quoi,comment,pourquoi' ) );

        $combined = mb_strtolower( html_entity_decode( $target_keyword . ' ' . $target_title, ENT_QUOTES, 'UTF-8' ) );
        $all_words = preg_split( '/[\s,\-:\']+/', $combined );
        $search_words = array_values( array_unique( array_filter( $all_words, function( $w ) use ( $stop ) {
            return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] );
        } ) ) );

        if ( empty( $search_words ) ) return array();

        $text = wp_strip_all_tags( $source_content );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $sentences = preg_split( '/(?<=[.!?;:"])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );

        $candidates = array();
        foreach ( $sentences as $sentence ) {
            $sent_lower = mb_strtolower( $sentence );
            $matches = 0;
            foreach ( $search_words as $sw ) {
                if ( mb_strpos( $sent_lower, $sw ) !== false ) $matches++;
            }
            if ( $matches === 0 ) continue;

            $words = preg_split( '/\s+/', trim( $sentence ) );
            for ( $len = 2; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $start = 0; $start <= count( $words ) - $len; $start++ ) {
                    $phrase = implode( ' ', array_slice( $words, $start, $len ) );
                    $phrase = trim( preg_replace( '/[.,;:!?]+$/', '', $phrase ) );
                    if ( mb_strlen( $phrase ) < 8 || mb_strlen( $phrase ) > 60 ) continue;

                    $phrase_lower = mb_strtolower( $phrase );
                    $seg_matches = 0;
                    foreach ( $search_words as $sw ) {
                        if ( mb_strpos( $phrase_lower, $sw ) !== false ) $seg_matches++;
                    }
                    if ( $seg_matches === 0 ) continue;

                    $seg_escaped = preg_quote( $phrase, '/' );
                    if ( mb_strpos( $source_content, $phrase ) === false ) continue;
                    if ( preg_match( '/<a[^>]*>[^<]*' . $seg_escaped . '/si', $source_content ) ) continue;

                    $score = $seg_matches * 20 + ( $len >= 3 ? 10 : 0 ) + $matches;
                    $candidates[ $phrase ] = max( $candidates[ $phrase ] ?? 0, $score );
                }
            }
        }

        arsort( $candidates );
        return array_slice( array_keys( $candidates ), 0, 3 );
    }

    /**
     * Diagnose anchor diversity across internal links.
     * Alerts when the same target URL is linked 3+ times with the same anchor text.
     *
     * @param int $post_id  If provided, check only this post. 0 = all published posts.
     * @return array  Array of alerts with 'target_url', 'anchor', 'count', 'source_ids'.
     */
    public function diagnose_anchor_diversity( $post_id = 0 ) {
        $same_anchor_threshold = 3;

        $args = array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $post_id ? 1 : 200,
            'fields'         => 'ids',
        );
        if ( $post_id ) {
            $args['post__in'] = array( $post_id );
        }
        $ids = get_posts( $args );

        // Collect all internal links: target_url => array( anchor => array( source_ids ) )
        $link_map = array();
        $home     = home_url();

        foreach ( $ids as $pid ) {
            $content = get_post_field( 'post_content', $pid );
            if ( empty( $content ) ) continue;

            if ( ! preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/si', $content, $m, PREG_SET_ORDER ) ) {
                continue;
            }

            foreach ( $m as $match ) {
                $href   = $match[1];
                $anchor = mb_strtolower( trim( wp_strip_all_tags( $match[2] ) ) );

                // Only internal links
                if ( strpos( $href, $home ) === false && strpos( $href, '/' ) !== 0 ) {
                    continue;
                }
                if ( empty( $anchor ) || mb_strlen( $anchor ) < 2 ) continue;

                // Normalize URL
                $url = trailingslashit( str_replace( $home, '', $href ) );

                if ( ! isset( $link_map[ $url ] ) ) {
                    $link_map[ $url ] = array();
                }
                if ( ! isset( $link_map[ $url ][ $anchor ] ) ) {
                    $link_map[ $url ][ $anchor ] = array();
                }
                if ( ! in_array( $pid, $link_map[ $url ][ $anchor ], true ) ) {
                    $link_map[ $url ][ $anchor ][] = $pid;
                }
            }
        }

        // Find over-optimized anchors
        $alerts = array();
        foreach ( $link_map as $target_url => $anchors ) {
            foreach ( $anchors as $anchor => $source_ids ) {
                if ( count( $source_ids ) >= $same_anchor_threshold ) {
                    $alerts[] = array(
                        'target_url'          => $target_url,
                        'anchor'              => $anchor,
                        'count'               => count( $source_ids ),
                        'source_ids'          => $source_ids,
                        'anchor_over_optimized' => true,
                        'recommendation'      => sprintf(
                            'Cette URL est liée %d fois avec la même ancre "%s". Variez les ancres pour un profil de liens naturel.',
                            count( $source_ids ),
                            $anchor
                        ),
                    );
                }
            }
        }

        // Sort by count desc
        usort( $alerts, function( $a, $b ) { return $b['count'] - $a['count']; } );

        return $alerts;
    }

    /**
     * Count existing HTS-generated links (preserve_hts_links).
     * Links from hacktheseo.com or with data-hts attribute are preserved.
     *
     * @param string $content
     * @return int
     */
    private function count_hts_links( $content ) {
        $count = 0;
        if ( preg_match_all( '/<a[^>]+(hacktheseo|data-hts)[^>]*>/i', $content, $matches ) ) {
            $count = count( $matches[0] );
        }
        return $count;
    }

    /* =========================================================================
     * PHASE 6b — CALENDAR AJAX HANDLERS
     * ====================================================================== */

    /**
     * AJAX: Get articles for calendar view.
     * Returns all cocon articles with scheduling info.
     */
    public function ajax_calendar_articles() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        $articles = array();
        $plans    = $this->get_plans();

        foreach ( $plans as $cocon_id => $plan ) {
            // Ensure priorities are calculated
            if ( ! isset( reset( $plan['articles'] )['publish_priority'] ) ) {
                $plan = $this->update_plan_priorities( $cocon_id );
            }

            foreach ( $plan['articles'] as $key => $art ) {
                if ( ! in_array( $art['status'], array( self::STATUS_RECEIVED, 'ready', 'scheduled' ), true ) ) continue;

                $post_id       = $art['post_id'] ?? null;
                $scheduled_date = null;
                $post_status    = 'draft';

                if ( $post_id ) {
                    $p = get_post( $post_id );
                    if ( $p ) {
                        $post_status = $p->post_status;
                        if ( $post_status === 'future' ) {
                            $scheduled_date = $p->post_date;
                        } elseif ( $post_status === 'publish' ) {
                            $scheduled_date = $p->post_date;
                        }
                    }
                }

                $articles[] = array(
                    'article_key'    => $key,
                    'cocon_id'       => $cocon_id,
                    'pillar_title'   => $plan['pillar_title'],
                    'keyword'        => $art['keyword'],
                    'status'         => $art['status'],
                    'post_id'        => $post_id,
                    'post_status'    => $post_status,
                    'priority'       => $art['publish_priority'] ?? 50,
                    'scheduled_date' => $scheduled_date,
                    'intent'         => $art['intent'] ?? 'info',
                );
            }
        }

        // Sort by priority descending
        usort( $articles, function( $a, $b ) {
            return $b['priority'] - $a['priority'];
        } );

        wp_send_json_success( $articles );
    }

    /**
     * AJAX: Schedule/reschedule an article.
     * Sets the post to 'future' status with the given date.
     *
     * Sprint 6.3: Added diagnostic logging + safeguard against WP auto-publish.
     * WordPress internally calls wp_publish_post() if it considers post_date_gmt
     * to be in the past (can happen if a plugin overrides date_default_timezone_set
     * or filters wp_insert_post_data). The safeguard forces future via $wpdb if needed.
     */
    public function ajax_calendar_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        $post_id  = (int) ( $_POST['post_id'] ?? 0 );
        $raw_date = sanitize_text_field( $_POST['date'] ?? '' );
        $raw_time = sanitize_text_field( $_POST['time'] ?? '09:00:00' );

        // ── Défensif P6: si date contient déjà l'heure (modale qui concatène date+time) ──
        if ( preg_match( '/^(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}(:\d{2})?)/', $raw_date, $dt_m ) ) {
            $date = $dt_m[1];
            $time = $dt_m[2];
        } else {
            $date = $raw_date;
            $time = $raw_time;
        }
        // Normaliser HH:MM → HH:MM:SS
        if ( preg_match( '/^\d{2}:\d{2}$/', $time ) ) {
            $time .= ':00';
        }

        if ( ! $post_id || ! $date ) {
            wp_send_json_error( 'Paramètres manquants (post_id=' . $post_id . ', date=' . $date . ').' );
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            wp_send_json_error( 'Article #' . $post_id . ' introuvable.' );
        }

        // ── P5: Valider que le post est planifiable ──
        $allowed_statuses = array( 'draft', 'pending', 'future' );
        if ( ! in_array( $post->post_status, $allowed_statuses, true ) ) {
            wp_send_json_error( sprintf(
                'L\'article #%d est en statut « %s ». Seuls les brouillons et articles en attente peuvent être planifiés.',
                $post_id, $post->post_status
            ) );
        }

        // Build datetime
        $datetime = $date . ' ' . $time;
        if ( ! strtotime( $datetime ) ) {
            wp_send_json_error( 'Date invalide : ' . $datetime );
        }

        $tz          = wp_timezone();
        $future_time = ( new \DateTimeImmutable( $datetime, $tz ) )->getTimestamp();
        $now         = time();

        // If the selected datetime is in the past or within next 5 min, bump to now+5min
        if ( $future_time <= $now + 300 ) {
            $bumped  = new \DateTimeImmutable( 'now +5 minutes', $tz );
            $datetime = $bumped->format( 'Y-m-d H:i:s' );
            $future_time = $bumped->getTimestamp();
        }

        // ── Diagnostic Sprint 6.3: log all values before wp_update_post ──
        $gmt_date      = get_gmt_from_date( $datetime );
        $php_tz_before = date_default_timezone_get();
        $debug_info    = array(
            'post_id'         => $post_id,
            'old_status'      => $post->post_status,
            'local_date'      => $datetime,
            'gmt_date'        => $gmt_date,
            'future_ts'       => $future_time,
            'now_ts'          => $now,
            'delta_seconds'   => $future_time - $now,
            'wp_timezone'     => $tz->getName(),
            'php_timezone'    => $php_tz_before,
        );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( '[6.3 Schedule] PRE: ' . wp_json_encode( $debug_info ), 'info', 'cocon-commander' );
        }

        // ── Safeguard: force PHP timezone to UTC before wp_update_post ──
        // WordPress expects UTC internally; some plugins break this assumption.
        $restore_tz = false;
        if ( $php_tz_before !== 'UTC' ) {
            date_default_timezone_set( 'UTC' );
            $restore_tz = true;
        }

        // ALWAYS set to 'future' — this is a calendar scheduling action
        $sched_result = wp_update_post( array(
            'ID'            => $post_id,
            'post_status'   => 'future',
            'post_date'     => $datetime,
            'post_date_gmt' => $gmt_date,
        ), true ); // true = return WP_Error on failure

        // Restore PHP timezone immediately
        if ( $restore_tz ) {
            date_default_timezone_set( $php_tz_before );
        }

        if ( is_wp_error( $sched_result ) ) {
            wp_send_json_error( 'Échec planification : ' . $sched_result->get_error_message() );
        }
        if ( 0 === $sched_result ) {
            wp_send_json_error( 'wp_update_post a retourné 0 pour #' . $post_id );
        }

        // Force cache clear — critical for immediate visibility
        clean_post_cache( $post_id );

        // ── Safeguard Sprint 6.3: if WP auto-published, force back to future ──
        $status_after = get_post_status( $post_id );
        $was_forced   = false;

        if ( $status_after !== 'future' ) {
            global $wpdb;

            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf(
                    '[6.3 Schedule] SAFEGUARD: WP changed #%d to « %s » instead of « future ». Forcing via $wpdb. php_tz_was=%s gmt_date=%s',
                    $post_id, $status_after, $php_tz_before, $gmt_date
                ), 'warning', 'cocon-commander' );
            }

            // Direct DB update — bypasses all hooks that may interfere
            $wpdb->update(
                $wpdb->posts,
                array(
                    'post_status'   => 'future',
                    'post_date'     => $datetime,
                    'post_date_gmt' => $gmt_date,
                ),
                array( 'ID' => $post_id ),
                array( '%s', '%s', '%s' ),
                array( '%d' )
            );
            clean_post_cache( $post_id );

            // Schedule the WP cron event manually so WordPress publishes at the right time
            $gmt_ts = strtotime( $gmt_date . ' +0000' );
            wp_clear_scheduled_hook( 'publish_future_post', array( $post_id ) );
            if ( $gmt_ts > time() ) {
                wp_schedule_single_event( $gmt_ts, 'publish_future_post', array( $post_id ) );
            }

            $status_after = get_post_status( $post_id );
            $was_forced   = true;
        }

        // Track meta for traceability
        update_post_meta( $post_id, '_hts_calendar_scheduled', current_time( 'mysql' ) );
        update_post_meta( $post_id, '_hts_calendar_date', $datetime );

        // Update Commander plan if this is a cocon article
        $cocon_id    = get_post_meta( $post_id, '_hts_cocon_id', true );
        $article_key = get_post_meta( $post_id, '_hts_article_key', true );
        if ( $cocon_id && $article_key ) {
            $this->update_article_status( $cocon_id, $article_key, self::STATUS_SCHEDULED, array(
                'scheduled_date'    => $datetime,
                'calendar_scheduled' => true,
            ) );
        }

        // Log
        self::cocon_log( 'calendar_scheduled', sprintf(
            '📅 Planifié : « %s » → %s%s',
            mb_substr( $post->post_title, 0, 50 ), $datetime,
            $was_forced ? ' (forcé via $wpdb)' : ''
        ), array( 'post_id' => $post_id ) );

        wp_send_json_success( array(
            'post_id'    => $post_id,
            'date'       => $datetime,
            'gmt_date'   => $gmt_date,
            'status'     => $status_after,
            'verified'   => ( $status_after === 'future' ),
            'was_forced' => $was_forced,
            'debug'      => $debug_info,
        ) );
    }

    /* =========================================================================
     * PHASE 6d — CROSS-COCON SMART LINKING (v1.28.0)
     *
     * Principle: PROPOSE only, NEVER auto-apply.
     * The client sees proposals in the Commander UI and validates each link.
     * Every applied link is logged in Audit Trail for rollback.
     *
     * Best practices SEO 2026:
     *   - Similarity threshold 0.35 (strict for cross-cocon)
     *   - Max 2 outbound cross-cocon links per article
     *   - Max 1 inbound cross-cocon link per existing article
     *   - Pillar URLs are SACRED — never linked cross-cocon
     *   - Bidirectional: FROM new→old + FROM old→new
     *   - Audit Trail snapshot for every link applied
     * ====================================================================== */

    /**
     * Generate cross-cocon link proposals for a newly published article.
     * Stores proposals in post_meta — NEVER inserts links automatically.
     *
     * @param int    $post_id   The newly published post
     * @param string $cocon_id  The cocon this article belongs to
     * @return array  Proposals generated
     */
    public function propose_cross_cocon_links( $post_id, $cocon_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array();

        $plan = $this->get_plan( $cocon_id );
        $pillar_url = $plan['pillar_url'] ?? '';

        // Get candidates from OTHER cocons (exclude same cocon)
        $candidates = $this->get_cross_cocon_candidates( $post_id, $cocon_id );
        if ( empty( $candidates ) ) return array();

        $proposals  = array();
        $out_count  = 0;
        $in_count   = array(); // Track per-target to enforce max 1 inbound

        // Sprint Robustesse: determine source language for cross-language filtering
        $source_lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $source_lang = HTS_Language::get_post_language( $post_id ) ?: '';
        }

        foreach ( $candidates as $candidate ) {
            // Sprint Robustesse: skip cross-language candidates
            if ( $source_lang ) {
                $cand_lang = HTS_Language::get_post_language( $candidate['id'] ) ?: '';
                if ( $cand_lang && $cand_lang !== $source_lang ) continue;
            }

            // ── A. Proposal: FROM this article → candidate (cross_out) ──
            if ( $out_count < self::CROSS_COCON_MAX_OUT ) {
                // Skip if link already exists in content
                $content = $post->post_content;
                if ( strpos( $content, $candidate['url'] ) === false ) {
                    // Find contextual anchor from source content (anchor diversity)
                    $contextual_anchor = $this->find_contextual_anchor(
                        $content,
                        $candidate['keyword'],
                        $candidate['title']
                    );
                    $anchor = $contextual_anchor ?: $candidate['keyword'];

                    // Get alternatives for UI display
                    $alternatives = $this->find_anchor_alternatives( $content, $candidate['keyword'], $candidate['title'] );

                    $proposals[] = array(
                        'direction'    => 'cross_out',
                        'source_id'    => $post_id,
                        'source_title' => $post->post_title,
                        'target_id'    => $candidate['id'],
                        'target_title' => $candidate['title'],
                        'target_url'   => $candidate['url'],
                        'anchor'       => $anchor,
                        'anchor_alternatives' => $alternatives,
                        'anchor_source' => $contextual_anchor ? 'contextual' : 'keyword',
                        'similarity'   => $candidate['similarity'],
                        'cocon_id'     => $candidate['cocon_id'] ?? '',
                        'status'       => 'pending', // pending | applied | dismissed
                        'audit_id'     => null,
                    );
                    $out_count++;
                }
            }

            // ── B. Proposal: FROM candidate → this article (cross_in) ──
            $cid = $candidate['id'];
            if ( ! isset( $in_count[ $cid ] ) ) $in_count[ $cid ] = 0;
            if ( $in_count[ $cid ] < self::CROSS_COCON_MAX_IN ) {
                $cand_post = get_post( $cid );
                if ( $cand_post && strpos( $cand_post->post_content, get_permalink( $post_id ) ) === false ) {
                    $post_keyword = get_post_meta( $post_id, '_hts_focus_keyword', true ) ?: $post->post_title;

                    // Find contextual anchor from candidate's content
                    $contextual_anchor = $this->find_contextual_anchor(
                        $cand_post->post_content,
                        $post_keyword,
                        $post->post_title
                    );
                    $anchor = $contextual_anchor ?: $post_keyword;
                    $alternatives = $this->find_anchor_alternatives( $cand_post->post_content, $post_keyword, $post->post_title );

                    $proposals[] = array(
                        'direction'    => 'cross_in',
                        'source_id'    => $cid,
                        'source_title' => $candidate['title'],
                        'target_id'    => $post_id,
                        'target_title' => $post->post_title,
                        'target_url'   => get_permalink( $post_id ),
                        'anchor'       => $anchor,
                        'anchor_alternatives' => $alternatives,
                        'anchor_source' => $contextual_anchor ? 'contextual' : 'keyword',
                        'similarity'   => $candidate['similarity'],
                        'cocon_id'     => $cocon_id,
                        'status'       => 'pending',
                        'audit_id'     => null,
                    );
                    $in_count[ $cid ]++;
                }
            }
        }

        if ( ! empty( $proposals ) ) {
            // ── REINFORCEMENT LEARNING: Enrich with Strategy Engine patterns ──
            if ( class_exists( 'HTS_Strategy_Engine' ) ) {
                foreach ( $proposals as &$prop ) {
                    $source_id   = $prop['source_id'];
                    $action_type = 'link_' . $prop['direction']; // link_cross_out or link_cross_in

                    $pattern = \HTS_Strategy_Engine::get_pattern_for_post( $action_type, $source_id );
                    if ( $pattern ) {
                        $prop['strategy_confidence'] = $pattern['confidence'];
                        $prop['strategy_status']     = $pattern['status'];
                        $prop['strategy_sample']     = $pattern['sample_size'];
                        $prop['strategy_profile']    = $pattern['profile'] ?? '';

                        // UX non-expert: explain why confidence is high/low
                        if ( $pattern['status'] === 'fiable' ) {
                            $prop['strategy_note'] = sprintf(
                                'Ce type de lien a amélioré le SEO %s%% du temps sur des articles similaires (%d cas analysés).',
                                round( $pattern['confidence'] ),
                                $pattern['sample_size']
                            );
                        } elseif ( $pattern['status'] === 'inefficace' ) {
                            $prop['strategy_note'] = sprintf(
                                'Attention : ce type de lien a rarement fonctionné sur des articles similaires (%s%% de réussite sur %d cas).',
                                round( $pattern['confidence'] ),
                                $pattern['sample_size']
                            );
                        } elseif ( $pattern['status'] === 'mitige' ) {
                            $prop['strategy_note'] = sprintf(
                                'Résultats mitigés pour ce type de lien (%s%% de réussite sur %d cas). À valider.',
                                round( $pattern['confidence'] ),
                                $pattern['sample_size']
                            );
                        }
                        // observation = not enough data, no note
                    }
                }
                unset( $prop );
            }

            // Store proposals — merge with existing, deduplicate by source+target pair (CC2)
            $existing = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
            if ( ! is_array( $existing ) ) $existing = array();
            $existing_pairs = array();
            foreach ( $existing as $e ) {
                $existing_pairs[] = $e['source_id'] . '-' . $e['target_id'];
            }
            foreach ( $proposals as $p ) {
                $pair = $p['source_id'] . '-' . $p['target_id'];
                if ( ! in_array( $pair, $existing_pairs, true ) ) {
                    $existing[] = $p;
                    $existing_pairs[] = $pair;
                }
            }
            update_post_meta( $post_id, '_hts_cross_cocon_proposals', $existing );

            self::cocon_log( 'cross_link_proposed', '🔗 ' . count( $proposals ) . ' proposition(s) cross-cocon', array(
                'post_id'   => $post_id,
                'cocon_id'  => $cocon_id,
                'count_out' => $out_count,
                'count_in'  => array_sum( $in_count ),
            ) );

            hts_add_log(
                sprintf( '🔗 %d proposition(s) de liens cross-cocon pour « %s »', count( $proposals ), $post->post_title ),
                'info', 'cocon-commander'
            );
        }

        return $proposals;
    }

    /**
     * Get cross-cocon candidates: articles from OTHER cocons or without cocon,
     * that are semantically similar (above threshold).
     *
     * Uses HTS_Embeddings::get_scored_candidates for semantic scoring,
     * then filters out same-cocon articles and pillar URLs.
     *
     * @param int    $post_id   Source post
     * @param string $cocon_id  Source cocon (to exclude)
     * @return array  Candidates with similarity, url, keyword, cocon_id
     */
    public function get_cross_cocon_candidates( $post_id, $cocon_id ) {
        if ( ! class_exists( 'HTS_Embeddings' ) ) return array();

        $emb = new \HTS_Embeddings();
        $all_candidates = $emb->get_scored_candidates( $post_id, 50 );
        if ( empty( $all_candidates ) ) return array();

        // Get all plans to identify pillar URLs — skip_pillar protection
        $plans    = $this->get_plans();
        $pillars  = array();
        if ( is_array( $plans ) ) {
            foreach ( $plans as $p ) {
                if ( ! empty( $p['pillar_url'] ) ) {
                    $pillars[] = untrailingslashit( strtolower( $p['pillar_url'] ) );
                }
            }
        }

        $cross_candidates = array();

        foreach ( $all_candidates as $c ) {
            // Filter: minimum similarity for cross-cocon (stricter)
            if ( ( $c['similarity'] ?? 0 ) < self::CROSS_COCON_MIN_SIMILARITY ) continue;

            $cand_cocon = get_post_meta( $c['id'], '_hts_cocon_id', true );

            // Also check NLP cluster assignment
            if ( empty( $cand_cocon ) ) {
                $cocon_data = self::load_cocon_data();
                if ( ! empty( $cocon_data['nodes'][ $c['id'] ]['cluster'] ) ) {
                    $cand_cocon = $cocon_data['nodes'][ $c['id'] ]['cluster'];
                }
            }

            // Exclude same-cocon articles (already handled by auto_link_siblings)
            if ( ! empty( $cand_cocon ) && $cand_cocon === $cocon_id ) continue;

            // Exclude pillar URLs — pillar is SACRED, never cross-linked
            $cand_url = strtolower( untrailingslashit( $c['url'] ?? get_permalink( $c['id'] ) ) );
            $is_pillar = false;
            foreach ( $pillars as $purl ) {
                if ( $cand_url === $purl || $cand_url === untrailingslashit( strtolower( home_url( $purl ) ) ) ) {
                    $is_pillar = true;
                    break;
                }
            }
            if ( $is_pillar ) continue;

            $c['cocon_id'] = $cand_cocon;
            $c['keyword']  = get_post_meta( $c['id'], '_hts_focus_keyword', true )
                             ?: ( $c['title'] ?? get_the_title( $c['id'] ) );
            $c['url']      = $c['url'] ?? get_permalink( $c['id'] );

            $cross_candidates[] = $c;
        }

        // Limit to reasonable number (top candidates by score)
        return array_slice( $cross_candidates, 0, self::CROSS_COCON_MAX_OUT * 3 );
    }

    /**
     * AJAX: Get cross-cocon proposals for a post.
     */
    public function ajax_cross_cocon_proposals() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        $post_id = absint( $_POST['post_id'] ?? 0 );

        if ( ! $post_id ) {
            wp_send_json_error( 'ID article manquant.' );
        }

        $proposals = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
        if ( ! is_array( $proposals ) ) $proposals = array();

        // Enrich with current status info
        foreach ( $proposals as &$p ) {
            if ( $p['status'] === 'applied' && ! empty( $p['audit_id'] ) ) {
                $p['can_rollback'] = true;
            } else {
                $p['can_rollback'] = false;
            }
        }

        wp_send_json_success( array(
            'proposals' => $proposals,
            'enabled'   => (bool) get_option( 'hts_cross_cocon_enabled', false ),
            'post_id'   => $post_id,
        ) );
    }

    /**
     * AJAX: Apply a single cross-cocon link (client validated).
     *
     * Security layers:
     *  1. Nonce verification
     *  2. opt-in check (hts_cross_cocon_enabled)
     *  3. Content snapshot BEFORE (for rollback)
     *  4. Audit Trail log with full before/after
     *  5. cocon_log event
     */
    public function ajax_apply_cross_link() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        if ( ! get_option( 'hts_cross_cocon_enabled', false ) ) {
            wp_send_json_error( 'Le maillage cross-cocon n\'est pas activé. Activez-le dans les réglages.' );
        }

        $post_id    = absint( $_POST['post_id'] ?? 0 );
        $prop_index = absint( $_POST['proposal_index'] ?? -1 );

        if ( ! $post_id ) wp_send_json_error( 'ID article manquant.' );

        $proposals = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
        if ( ! is_array( $proposals ) || ! isset( $proposals[ $prop_index ] ) ) {
            wp_send_json_error( 'Proposition introuvable.' );
        }

        $prop = $proposals[ $prop_index ];
        if ( $prop['status'] !== 'pending' ) {
            wp_send_json_error( 'Cette proposition a déjà été traitée (' . $prop['status'] . ').' );
        }

        // Determine which post gets the link inserted
        $source_id  = absint( $prop['source_id'] );
        $target_url = $prop['target_url'];
        $anchor     = $prop['anchor'];
        $direction  = $prop['direction']; // cross_out or cross_in

        $source_post = get_post( $source_id );
        if ( ! $source_post ) {
            wp_send_json_error( 'Article source #' . $source_id . ' introuvable.' );
        }

        // ── Snapshot BEFORE ──
        $content_before = $source_post->post_content;

        // ── Insert the link ──
        $link_html = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( $prop['target_title'] ) . '">'
                   . esc_html( $anchor ) . '</a>';

        $new_content = $this->insert_contextual_link( $content_before, $link_html, $anchor, $anchor, $source_id );

        if ( ! $new_content || $new_content === $content_before ) {
            wp_send_json_error( 'Impossible d\'insérer le lien contextuellement. Essayez un autre emplacement.' );
        }

        // ── Save content (builder-aware) ──
        if ( class_exists( 'HTS_Content_Writer' ) ) {
            \HTS_Content_Extractor::invalidate_cache( $source_id );
        }
        $save_result = wp_update_post( array(
            'ID'           => $source_id,
            'post_content' => $new_content,
        ) );
        if ( is_wp_error( $save_result ) || 0 === $save_result ) {
            wp_send_json_error( 'Échec de la sauvegarde du contenu.' );
        }

        // ── Audit Trail ──
        $audit_id = 0;
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            $audit_id = \HTS_Audit_Trail::log_link(
                $source_id,
                absint( $prop['target_id'] ),
                $anchor,
                $direction,
                $content_before,
                $new_content,
                \HTS_Audit_Trail::get_gsc_snapshot( $source_id )
            );
        }

        // ── Update proposal status ──
        $proposals[ $prop_index ]['status']   = 'applied';
        $proposals[ $prop_index ]['audit_id'] = $audit_id;
        $proposals[ $prop_index ]['applied_at'] = current_time( 'mysql' );
        $proposals[ $prop_index ]['applied_by'] = get_current_user_id();
        update_post_meta( $post_id, '_hts_cross_cocon_proposals', $proposals );

        // ── cocon_log ──
        self::cocon_log( 'cross_link_applied', 'Lien cross-cocon appliqué', array(
            'source_id'  => $source_id,
            'target_id'  => absint( $prop['target_id'] ),
            'direction'  => $direction,
            'anchor'     => $anchor,
            'similarity' => $prop['similarity'],
            'audit_id'   => $audit_id,
        ) );

        hts_add_log(
            sprintf( '🔗 Lien cross-cocon appliqué : %s → %s (ancre: %s)',
                $source_post->post_title,
                $prop['target_title'],
                $anchor
            ),
            'success', 'cocon-commander'
        );

        wp_send_json_success( array(
            'message'  => 'Lien cross-cocon inséré avec succès.',
            'audit_id' => $audit_id,
            'source_id' => $source_id,
            'direction' => $direction,
        ) );
    }

    /**
     * AJAX: Rollback a cross-cocon link via Audit Trail.
     * Restores content to snapshot_before.
     */
    public function ajax_rollback_cross_link() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        $post_id    = absint( $_POST['post_id'] ?? 0 );
        $prop_index = absint( $_POST['proposal_index'] ?? -1 );

        if ( ! $post_id ) wp_send_json_error( 'ID article manquant.' );

        $proposals = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
        if ( ! is_array( $proposals ) || ! isset( $proposals[ $prop_index ] ) ) {
            wp_send_json_error( 'Proposition introuvable.' );
        }

        $prop = $proposals[ $prop_index ];
        if ( $prop['status'] !== 'applied' || empty( $prop['audit_id'] ) ) {
            wp_send_json_error( 'Ce lien n\'a pas été appliqué ou n\'a pas d\'ID Audit Trail.' );
        }

        // Delegate to Audit Trail rollback
        if ( ! class_exists( 'HTS_Audit_Trail' ) ) {
            wp_send_json_error( 'Module Audit Trail non disponible.' );
        }

        $result = \HTS_Audit_Trail::rollback( absint( $prop['audit_id'] ) );

        if ( ! $result['success'] ) {
            wp_send_json_error( $result['message'] );
        }

        // Update proposal status back to pending
        $proposals[ $prop_index ]['status']      = 'rolled_back';
        $proposals[ $prop_index ]['rolledback_at'] = current_time( 'mysql' );
        update_post_meta( $post_id, '_hts_cross_cocon_proposals', $proposals );

        self::cocon_log( 'cross_link_rollback', '↩️ Rollback lien cross-cocon', array(
            'source_id' => $prop['source_id'],
            'target_id' => $prop['target_id'],
            'direction' => $prop['direction'],
            'audit_id'  => $prop['audit_id'],
        ) );

        wp_send_json_success( array( 'message' => 'Lien cross-cocon annulé (contenu restauré).' ) );
    }

    /**
     * AJAX: Dismiss a cross-cocon link proposal.
     */
    public function ajax_dismiss_cross_link() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        $post_id    = absint( $_POST['post_id'] ?? 0 );
        $prop_index = absint( $_POST['proposal_index'] ?? -1 );

        if ( ! $post_id ) wp_send_json_error( 'ID article manquant.' );

        $proposals = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
        if ( ! is_array( $proposals ) || ! isset( $proposals[ $prop_index ] ) ) {
            wp_send_json_error( 'Proposition introuvable.' );
        }

        $proposals[ $prop_index ]['status']       = 'dismissed';
        $proposals[ $prop_index ]['dismissed_at']  = current_time( 'mysql' );
        $proposals[ $prop_index ]['dismissed_by']  = get_current_user_id();
        update_post_meta( $post_id, '_hts_cross_cocon_proposals', $proposals );

        self::cocon_log( 'cross_link_dismissed', '🚫 Proposition cross-cocon rejetée', array(
            'source_id' => $proposals[ $prop_index ]['source_id'],
            'target_id' => $proposals[ $prop_index ]['target_id'],
            'direction' => $proposals[ $prop_index ]['direction'],
        ) );

        wp_send_json_success( array( 'message' => 'Proposition rejetée.' ) );
    }

    /**
     * AJAX: Save a WP option (used by cross-cocon toggle).
     * Whitelist of allowed options for security.
     */
    public function ajax_save_option() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permissions insuffisantes.' );
        }

        $allowed = array( 'hts_cross_cocon_enabled' );
        $key     = sanitize_text_field( $_POST['option_key'] ?? '' );
        $value   = sanitize_text_field( $_POST['option_value'] ?? '' );

        if ( ! in_array( $key, $allowed, true ) ) {
            wp_send_json_error( 'Option non autorisée.' );
        }

        update_option( $key, $value, false );

        $label = $value ? 'activé' : 'désactivé';
        hts_add_log( "🔗 Maillage cross-cocon $label", 'info', 'cocon' );

        wp_send_json_success( array( 'message' => "Option $key mise à jour.", 'value' => $value ) );
    }

    /**
     * AJAX: Manually scan an existing post for cross-cocon link proposals.
     * Allows testing cross-cocon on articles that are already published.
     */
    public function ajax_scan_cross_cocon() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( 'Permissions insuffisantes.' );
        }

        if ( ! get_option( 'hts_cross_cocon_enabled', false ) ) {
            wp_send_json_error( 'Le maillage cross-cocon est désactivé. Activez-le d\'abord.' );
        }

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) {
            wp_send_json_error( 'ID article manquant.' );
        }

        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) {
            wp_send_json_error( 'Article introuvable ou non publié.' );
        }

        $cocon_id = get_post_meta( $post_id, '_hts_cocon_id', true );

        // Also check NLP cluster assignment (articles analyzed by cocon NLP but not created by Commander)
        if ( empty( $cocon_id ) ) {
            $cocon_data = self::load_cocon_data();
            if ( ! empty( $cocon_data['nodes'][ $post_id ]['cluster'] ) ) {
                $cocon_id = $cocon_data['nodes'][ $post_id ]['cluster'];
            }
        }

        if ( empty( $cocon_id ) ) {
            wp_send_json_error( 'Cet article n\'appartient à aucun cocon. Assignez-le d\'abord à un cocon sémantique.' );
        }

        // Clear existing pending proposals (keep applied/dismissed/rolled_back)
        $existing = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
        if ( is_array( $existing ) ) {
            $existing = array_values( array_filter( $existing, function( $p ) {
                return ( $p['status'] ?? '' ) !== 'pending';
            } ) );
            update_post_meta( $post_id, '_hts_cross_cocon_proposals', $existing );
        }

        // Generate fresh proposals
        $proposals = $this->propose_cross_cocon_links( $post_id, $cocon_id );

        // Count new proposals
        $all = get_post_meta( $post_id, '_hts_cross_cocon_proposals', true );
        $pending = 0;
        if ( is_array( $all ) ) {
            foreach ( $all as $p ) {
                if ( ( $p['status'] ?? '' ) === 'pending' ) $pending++;
            }
        }

        if ( $pending > 0 ) {
            wp_send_json_success( array(
                'message' => sprintf( '%d proposition(s) trouvée(s). Vérifiez le tableau ci-dessous.', $pending ),
                'count'   => $pending,
            ) );
        } else {
            wp_send_json_success( array(
                'message' => 'Aucune proposition trouvée. Causes possibles : pas assez d\'articles dans d\'autres cocons, similarité trop faible, ou liens déjà en place.',
                'count'   => 0,
            ) );
        }
    }

    /* =========================================================================
     * COCON LOGGING SYSTEM (ported from Full v4.0)
     *
     * Structured logging with smart dedup for poll phases.
     * Feeds important events to the dashboard activity log.
     * ====================================================================== */

    /**
     * Log a cocon-related event.
     *
     * Smart: skips duplicate poll_article entries if phase didn't change.
     * Feeds important events to hts_add_log() for dashboard visibility.
     *
     * @param string $type    Event type (plan_queued, article_ready, draft_created, etc.)
     * @param string $message Human-readable message
     * @param array  $data    Structured data (cocon_id, keyword, job_id, title, etc.)
     */
    public static function cocon_log( $type, $message, $data = array() ) {
        $logs = get_option( self::LOGS_OPTION, array() );

        // For poll_article: only log if phase CHANGED from last entry
        if ( $type === 'poll_article' ) {
            $last = end( $logs );
            if ( $last && $last['type'] === 'poll_article'
                && isset( $last['data']['job_id'] ) && $last['data']['job_id'] === ( $data['job_id'] ?? '' )
                && isset( $last['data']['phase'] ) && $last['data']['phase'] === ( $data['phase'] ?? '' )
            ) {
                return; // Same phase, skip duplicate
            }
        }

        $logs[] = array(
            'time'    => current_time( 'mysql' ),
            'type'    => $type,
            'message' => $message,
            'data'    => $data,
        );

        // Keep last 500 entries
        if ( count( $logs ) > 500 ) {
            $logs = array_slice( $logs, -500 );
        }
        update_option( self::LOGS_OPTION, $logs, false );

        // Feed important events to the dashboard activity log
        $dashboard_types = array(
            'plan_queued'          => 'success',
            'plan_ready'           => 'success',
            'plan_deleted'         => 'info',
            'article_queued'       => 'success',
            'article_ready'        => 'success',
            'article_error'        => 'error',
            'draft_created'        => 'success',
            'draft_error'          => 'error',
            'ai_metas'             => 'info',
            'ai_metas_error'       => 'error',
            'seo_metas'            => 'info',
            'content_cleaned'      => 'info',
            'cross_links'          => 'info',
            'cross_link_proposed'  => 'info',
            'cross_link_applied'   => 'success',
            'cross_link_rollback'  => 'warning',
            'cross_link_dismissed' => 'info',
            'auto_sched_config'    => 'info',
            'auto_sched_trigger'   => 'info',
            'auto_sched_article'   => 'success',
            'auto_sched_published' => 'success',
            'auto_sched_skipped'   => 'warning',
            'auto_sched_cron'      => 'info',
        );
        if ( isset( $dashboard_types[ $type ] ) && function_exists( 'hts_add_log' ) ) {
            $dash_msg = 'Cocon: ' . $message;
            if ( ! empty( $data['title'] ) )   $dash_msg .= ' — "' . $data['title'] . '"';
            if ( ! empty( $data['keyword'] ) ) $dash_msg .= ' [' . $data['keyword'] . ']';
            hts_add_log( $dash_msg, $dashboard_types[ $type ], 'cocon' );
        }
    }

    /**
     * Get cocon logs.
     *
     * @return array
     */
    public static function get_cocon_logs() {
        return get_option( self::LOGS_OPTION, array() );
    }

    /**
     * AJAX: Get cocon logs for the UI panel.
     */
    public function ajax_cocon_get_logs() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(1);
        wp_send_json_success( array( 'logs' => self::get_cocon_logs() ) );
    }

    /* =========================================================================
     * SEO HELPERS — Create Draft enhancements (ported from Full v4.0)
     * ====================================================================== */

    /**
     * Extract meta_title and meta_description from full HTML (including <head>).
     */
    private static function extract_metas_from_html( $html ) {
        $meta_title = '';
        $meta_desc  = '';

        if ( preg_match( '/<title>(.*?)<\/title>/si', $html, $tm ) ) {
            $meta_title = trim( wp_strip_all_tags( $tm[1] ) );
        }
        if ( preg_match( '/<meta\s+name=["\']description["\']\s+content=["\'](.*?)["\']/si', $html, $dm ) ) {
            $meta_desc = trim( $dm[1] );
        }

        return array(
            'meta_title'       => $meta_title,
            'meta_description' => $meta_desc,
        );
    }

    /**
     * Generate short SEO-friendly slug from keyword.
     * Priority: keyword-based slug (short, < 60 chars) > API slug.
     */
    private static function generate_short_slug( $keyword, $api_slug = '' ) {
        if ( ! empty( $keyword ) ) {
            $slug = sanitize_title( $keyword );
            if ( strlen( $slug ) <= 60 ) return $slug;
        }
        if ( ! empty( $api_slug ) ) {
            $slug = sanitize_title( $api_slug );
            if ( strlen( $slug ) > 60 ) {
                $slug = substr( $slug, 0, 60 );
                $slug = preg_replace( '/-[^-]*$/', '', $slug );
            }
            return $slug;
        }
        return sanitize_title( $keyword ?: 'article' );
    }

    /**
     * Ensure a post slug is unique BEFORE wp_insert_post.
     * Prevents WordPress from silently appending -2, -3, etc.
     * Instead, appends a meaningful differentiator from the title.
     *
     * @param string $slug  The desired slug
     * @param string $title The post title (used as differentiator source)
     * @return string Unique slug
     */
    private static function ensure_unique_slug( $slug, $title = '' ) {
        global $wpdb;

        // Check if slug already exists (published, draft, future, pending)
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_status IN ('publish','draft','future','pending') LIMIT 1",
            $slug
        ) );

        if ( ! $exists ) return $slug;

        // Slug collision — generate a meaningful variant instead of -2
        // Strategy: append distinctive words from title that aren't in slug
        $slug_words  = explode( '-', $slug );
        $title_words = explode( '-', sanitize_title( $title ) );
        $diff_words  = array_diff( $title_words, $slug_words );
        $diff_words  = array_filter( $diff_words, function( $w ) { return mb_strlen( $w ) > 2; } );

        if ( ! empty( $diff_words ) ) {
            // Take up to 2 distinctive words from title
            $suffix = implode( '-', array_slice( array_values( $diff_words ), 0, 2 ) );
            $candidate = substr( $slug . '-' . $suffix, 0, 70 );
            $candidate = preg_replace( '/-[^-]*$/', '', substr( $candidate, 0, 70 ) ); // clean cut

            $still_exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_status IN ('publish','draft','future','pending') LIMIT 1",
                $candidate
            ) );
            if ( ! $still_exists ) return $candidate;
        }

        // Fallback: use wp_unique_post_slug (will add -2 but at least we tried)
        return wp_unique_post_slug( $slug, 0, 'draft', 'post', 0 );
    }

    /**
     * Truncate a meta field to max length, breaking at word boundary.
     */
    private static function truncate_meta( $text, $max ) {
        if ( mb_strlen( $text ) <= $max ) return $text;
        $text = mb_substr( $text, 0, $max );
        $pos  = mb_strrpos( $text, ' ' );
        if ( $pos > $max * 0.6 ) {
            $text = mb_substr( $text, 0, $pos );
        }
        return rtrim( $text, ' .,;:' );
    }

    /**
     * Fix markdown-style citation links from AI → proper HTML <a> tags.
     * Pattern: [text](url) → <a href="url">text</a>
     */
    private static function fix_markdown_links( $content ) {
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
        $result = preg_replace_callback(
            '/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/',
            function( $m ) use ( $site_host ) {
                $text = $m[1];
                $url  = $m[2];
                $link_host = wp_parse_url( $url, PHP_URL_HOST );
                // Internal links: no target="_blank" (SEO + UX)
                if ( $link_host && ( $link_host === $site_host || str_ends_with( $link_host, '.' . $site_host ) ) ) {
                    return '<a href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>';
                }
                // External links: target="_blank" + noopener
                return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $text ) . '</a>';
            },
            $content
        );
        return ( $result !== null && $result !== '' ) ? $result : $content;
    }

    /**
     * Remove AI-generated spam blocks (keyword stuffing, semantic notes).
     */
    private static function clean_ai_spam( $content ) {
        // Remove "Note sémantique" blocks
        $cleaned = preg_replace(
            '/\s*(?:<p>)?\s*(?:Note\s+s[ée]mantique|S[ée]mantique\s*[:\(]|Keywords?\s*[:\(])[^<]*(?:<\/p>)?\s*/si',
            '',
            $content
        );
        $content = ( $cleaned !== null ) ? $cleaned : $content;

        // Remove paragraphs with 10+ comma-separated single words (keyword lists)
        $cleaned = preg_replace(
            '/<p>[^<]{20,}(?:(?:,\s*\w+){10,})[^<]*<\/p>/si',
            '',
            $content
        );
        return ( $cleaned !== null ) ? $cleaned : $content;
    }

    /**
     * Fix ugly permalinks (?p=XXX) → real pretty permalinks.
     *
     * The SaaS API generates internal links using WordPress default
     * permalinks (?p=XXX) because target articles are often still drafts
     * at generation time and get_permalink() returns ?p=XXX for drafts.
     *
     * This method:
     *  1. Finds all <a href="...?p=XXX"> links in the content
     *  2. Resolves ?p=XXX to the real post
     *  3. If the post is published → replaces with the real permalink
     *  4. If the post is draft/future → builds the permalink from the slug
     *  5. If the post doesn't exist → removes the <a> tag (keeps text)
     *  6. Also strips links pointing to the homepage
     */
    public static function fix_ugly_permalinks( $content ) {
        $home_url = trailingslashit( home_url() );
        $original = $content;

        $content = preg_replace_callback(
            '/<a\s([^>]*href=["\'])([^"\']*\?p=(\d+))(["\'][^>]*)>(.*?)<\/a>/is',
            function( $m ) use ( $home_url ) {
                $post_id     = (int) $m[3];
                $anchor_text = $m[5];
                $attrs       = $m[1];
                $after       = $m[4];

                $post = get_post( $post_id );

                // Post doesn't exist → remove link, keep text
                if ( ! $post ) {
                    return $anchor_text;
                }

                // Only link to published posts — drafts/future = dead links on public site
                if ( $post->post_status !== 'publish' ) {
                    return $anchor_text;
                }

                $real_url = get_permalink( $post_id );

                // Don't link to homepage
                if ( trailingslashit( $real_url ) === $home_url ) {
                    return $anchor_text;
                }

                return '<a ' . $attrs . esc_url( $real_url ) . $after . '>' . $anchor_text . '</a>';
            },
            $content
        );

        return ( $content !== null ) ? $content : $original;
    }

    /**
     * Apply SEO metas to all detected SEO plugins (HTS, Yoast, RankMath, AIOSEO).
     */
    public static function apply_seo_metas_multi_plugin( $post_id, $meta_title, $meta_desc, $keyword ) {
        // HTS native
        update_post_meta( $post_id, '_hts_meta_title', $meta_title );
        update_post_meta( $post_id, '_hts_meta_description', $meta_desc );
        update_post_meta( $post_id, '_hts_focus_keyword', $keyword );

        // Yoast SEO
        if ( defined( 'WPSEO_VERSION' ) ) {
            update_post_meta( $post_id, '_yoast_wpseo_title', $meta_title );
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_desc );
            update_post_meta( $post_id, '_yoast_wpseo_focuskw', $keyword );
        }

        // RankMath
        if ( class_exists( 'RankMath' ) ) {
            update_post_meta( $post_id, 'rank_math_title', $meta_title );
            update_post_meta( $post_id, 'rank_math_description', $meta_desc );
            update_post_meta( $post_id, 'rank_math_focus_keyword', $keyword );
        }

        // All In One SEO
        if ( class_exists( 'AIOSEO\\Plugin\\AIOSEO' ) || defined( 'AIOSEO_VERSION' ) ) {
            update_post_meta( $post_id, '_aioseo_title', $meta_title );
            update_post_meta( $post_id, '_aioseo_description', $meta_desc );
            update_post_meta( $post_id, '_aioseo_keywords', $keyword );
        }
    }

    /* ═══════════════════════════════════════════════════════════
     *  LINKING SETTINGS — Per-cocon configuration
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Best-practice defaults for cross-interlinking.
     *
     * These values are derived from SEO consensus (2024-2026):
     *   - 3-5 internal links per 1000 words (Zyppy, Rush Analytics, Yoast)
     *   - 1 link every 250-300 words (First Page NZ, inblog)
     *   - 5-10 links for a 2000-word article (LinkStorm, Bulldog)
     *
     * The SaaS already delivers ~1 pillar link + ~2-3 external links,
     * so the plugin's cross-interlink budget is the REMAINDER.
     */
    public static function get_linking_defaults() {
        return array(
            // Outbound: max sister links added by cross-interlink
            'max_outbound'       => 0,     // 0 = auto (word-count-based)
            // Inbound: max links FROM existing articles TO the new one
            'max_inbound'        => 5,
            // Depth: how many hierarchy levels to link across
            //   1 = same cluster only (pillar ↔ enfants)
            //   2 = same cluster + sibling clusters in same cocon
            //   3 = all clusters + historical articles (whole site)
            'depth'              => 2,
            // Count SaaS-delivered links toward the total budget?
            'count_saas_links'   => true,
            // Target total internal links per article (including SaaS-delivered)
            'target_total'       => 0,     // 0 = auto (word-count-based)
            // Min relevance score (0-100) for GPT suggestions to be applied
            'min_relevance'      => 50,
        );
    }

    /**
     * Get linking config for a specific cocon.
     * Falls back to defaults for any missing key.
     *
     * @param string $cocon_id  The cocon identifier
     * @return array  Complete config with all keys guaranteed
     */
    public static function get_linking_config( $cocon_id ) {
        $defaults = self::get_linking_defaults();
        if ( empty( $cocon_id ) ) return $defaults;

        $saved = get_option( 'hts_cocon_linking_' . sanitize_key( $cocon_id ), array() );
        if ( ! is_array( $saved ) ) return $defaults;

        return array_merge( $defaults, $saved );
    }

    /**
     * Calculate effective max outbound links based on word count + config.
     *
     * Best practice: ~1 link per 300 words, minus what the SaaS already delivers.
     * SaaS typically delivers: 1 pillar link + 1-2 sibling links = ~2-3 internal links.
     *
     * @param array $config       Linking config from get_linking_config()
     * @param int   $word_count   Article word count
     * @param int   $existing_internal_links  Links already in the article HTML
     * @return int  Number of outbound links to add
     */
    public static function calc_max_outbound( $config, $word_count, $existing_internal_links = 0 ) {
        // If user set a manual max, use it
        if ( ( $config['max_outbound'] ?? 0 ) > 0 ) {
            return max( 0, (int) $config['max_outbound'] - ( $config['count_saas_links'] ? $existing_internal_links : 0 ) );
        }

        // Auto mode: ~1 link per 300 words, target 7-10 total
        $target = ( $config['target_total'] ?? 0 ) > 0
            ? (int) $config['target_total']
            : max( 4, min( 12, (int) floor( $word_count / 300 ) ) );

        $budget = $target - $existing_internal_links;
        return max( 1, min( 10, $budget ) );
    }

    /**
     * AJAX: Save linking settings for a cocon.
     */
    public function ajax_save_linking_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        if ( empty( $cocon_id ) ) wp_send_json_error( 'cocon_id manquant' );

        $defaults = self::get_linking_defaults();

        $settings = array(
            'max_outbound'     => max( 0, min( 15, (int) ( $_POST['max_outbound'] ?? 0 ) ) ),
            'max_inbound'      => max( 1, min( 15, (int) ( $_POST['max_inbound'] ?? $defaults['max_inbound'] ) ) ),
            'depth'            => max( 1, min( 3, (int) ( $_POST['depth'] ?? $defaults['depth'] ) ) ),
            'count_saas_links' => ( $_POST['count_saas_links'] ?? '1' ) === '1',
            'target_total'     => max( 0, min( 20, (int) ( $_POST['target_total'] ?? 0 ) ) ),
            'min_relevance'    => max( 30, min( 90, (int) ( $_POST['min_relevance'] ?? $defaults['min_relevance'] ) ) ),
        );

        update_option( 'hts_cocon_linking_' . sanitize_key( $cocon_id ), $settings, false );
        wp_send_json_success( array( 'settings' => $settings ) );
    }

    /* ═══════════════════════════════════════
     * PILLAR HEALTH CHECK
     * Validates if a page is suitable as a money/pillar page
     * Returns: score 0-100, warnings[], type (money|info|weak)
     * ═══════════════════════════════════════ */

    /**
     * Check pillar page health for cocon quality.
     *
     * @param int|string $post_id_or_url Post ID or URL
     * @return array { score, type, warnings[], strengths[], word_count, has_cta, is_page }
     */
    public static function check_pillar_health( $post_id_or_url ) {
        $post_id = is_numeric( $post_id_or_url ) ? (int) $post_id_or_url : hts_url_to_postid( $post_id_or_url );
        $result  = array(
            'score'      => 0,
            'type'       => 'unknown',
            'warnings'   => array(),
            'strengths'  => array(),
            'word_count' => 0,
            'is_page'    => false,
            'has_h2'     => false,
            'is_published' => false,
        );

        if ( ! $post_id ) {
            $result['warnings'][] = 'Page introuvable sur le site';
            return $result;
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            $result['warnings'][] = 'Page introuvable';
            return $result;
        }

        $result['is_published'] = ( $post->post_status === 'publish' );
        $result['is_page']      = ( $post->post_type === 'page' );
        $content                = wp_strip_all_tags( $post->post_content );
        $result['word_count']   = hts_word_count( $content );
        $result['has_h2']       = (bool) preg_match( '/<h2[\s>]/i', $post->post_content );

        $score = 0;

        // Published?
        if ( $result['is_published'] ) {
            $score += 10;
        } else {
            $result['warnings'][] = 'Page non publiée (brouillon)';
        }

        // Word count (money pages need substance)
        if ( $result['word_count'] >= 2000 ) {
            $score += 25;
            $result['strengths'][] = $result['word_count'] . ' mots — contenu dense';
        } elseif ( $result['word_count'] >= 1000 ) {
            $score += 15;
        } elseif ( $result['word_count'] >= 500 ) {
            $score += 8;
            $result['warnings'][] = 'Contenu court (' . $result['word_count'] . ' mots) — les piliers performants font 1500+ mots';
        } else {
            $result['warnings'][] = 'Page très courte (' . $result['word_count'] . ' mots) — risque de pilier faible';
        }

        // Is a "page" (not post) = more likely a service/money page
        if ( $result['is_page'] ) {
            $score += 10;
            $result['strengths'][] = 'Page statique — bon format pour un pilier';
        }

        // Has H2 structure
        $h2_count = preg_match_all( '/<h2[\s>]/i', $post->post_content );
        if ( $h2_count >= 3 ) {
            $score += 15;
            $result['strengths'][] = $h2_count . ' sections (H2) — bien structuré';
        } elseif ( $h2_count >= 1 ) {
            $score += 8;
        } else {
            $result['warnings'][] = 'Pas de sous-titres (H2) — structure plate';
        }

        // Internal links pointing IN (if NLP data available)
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon_obj  = new \HTS_Cocon();
            $cocon_data = $cocon_obj->get_cocon_data();
            if ( ! empty( $cocon_data['nodes'][ $post_id ] ) ) {
                $node = $cocon_data['nodes'][ $post_id ];
                $in   = (int) ( $node['in_links'] ?? $node['in_count_semantic'] ?? 0 );
                if ( $in >= 5 ) {
                    $score += 20;
                    $result['strengths'][] = $in . ' liens entrants — page autoritaire';
                } elseif ( $in >= 2 ) {
                    $score += 10;
                } else {
                    $result['warnings'][] = 'Peu de liens entrants (' . $in . ') — le cocon va renforcer cette page';
                }
            }
        }

        // Has CTA-like elements (forms, buttons, links with commercial anchors)
        $has_cta = (bool) preg_match( '/<(form|button)|class=".*(?:cta|btn|button|contact).*"|type="submit"/i', $post->post_content );
        if ( $has_cta ) {
            $score += 10;
            $result['strengths'][] = 'Contient un appel à l\'action — orientation business';
        }

        // Has schema markup
        $has_schema = (bool) preg_match( '/application\/ld\+json/i', $post->post_content );
        if ( $has_schema ) {
            $score += 5;
        }

        // Focus keyword set?
        $focus_kw = get_post_meta( $post_id, '_hts_focus_keyword', true );
        if ( ! empty( $focus_kw ) ) {
            $score += 5;
            $result['strengths'][] = 'Mot-clé focus défini : ' . $focus_kw;
        }

        // ── GSC Performance Data ──
        $gsc_clicks      = (int) get_post_meta( $post_id, '_hts_gsc_clicks', true );
        $gsc_impressions  = (int) get_post_meta( $post_id, '_hts_gsc_impressions', true );
        $gsc_position     = round( (float) get_post_meta( $post_id, '_hts_gsc_position', true ), 1 );
        $gsc_ctr          = round( (float) get_post_meta( $post_id, '_hts_gsc_ctr', true ), 2 );
        $result['gsc'] = array(
            'clicks'      => $gsc_clicks,
            'impressions' => $gsc_impressions,
            'position'    => $gsc_position,
            'ctr'         => $gsc_ctr,
        );

        $has_gsc = ( $gsc_clicks > 0 || $gsc_impressions > 0 );
        if ( $has_gsc ) {
            // Clicks: strong indicator of page value
            if ( $gsc_clicks >= 100 ) {
                $score += 15;
                $result['strengths'][] = $gsc_clicks . ' clics/mois — page à fort trafic';
            } elseif ( $gsc_clicks >= 20 ) {
                $score += 10;
                $result['strengths'][] = $gsc_clicks . ' clics/mois — bon trafic organique';
            } elseif ( $gsc_clicks >= 5 ) {
                $score += 5;
            }

            // Position: opportunity vs already strong
            if ( $gsc_position > 0 && $gsc_position <= 3 ) {
                $score += 10;
                $result['strengths'][] = 'Position ' . $gsc_position . ' — déjà en top 3 Google';
            } elseif ( $gsc_position >= 4 && $gsc_position <= 10 ) {
                $score += 5;
                $result['strengths'][] = 'Position ' . $gsc_position . ' — le cocon va pousser vers le top 3';
            } elseif ( $gsc_position >= 11 && $gsc_position <= 20 ) {
                $result['strengths'][] = 'Position ' . $gsc_position . ' + impressions — fort potentiel si renforcé par le cocon';
            }

            // Impressions without clicks = opportunity
            if ( $gsc_impressions >= 500 && $gsc_clicks < 20 ) {
                $result['warnings'][] = $gsc_impressions . ' impressions mais ' . $gsc_clicks . ' clics — la page est vue mais pas cliquée, optimisez le title/meta';
            }
        } else {
            // No GSC data at all
            $result['warnings'][] = 'Pas de données Search Console — importez vos données GSC pour un diagnostic complet';
        }

        $result['score'] = min( 100, $score );

        // Type classification
        if ( $result['score'] >= 60 ) {
            $result['type'] = 'strong';
        } elseif ( $result['score'] >= 35 ) {
            $result['type'] = 'moderate';
        } else {
            $result['type'] = 'weak';
        }

        return $result;
    }

    /* ═══════════════════════════════════════
     * INTENT CLASSIFICATION
     * Classifies article intent from keyword/title
     * ═══════════════════════════════════════ */

    /**
     * Classify search intent from keyword/title text.
     *
     * @param string $text Keyword or title
     * @return string 'info' | 'commercial' | 'transactional' | 'navigational'
     */
    public static function classify_intent( $text ) {
        $text = mb_strtolower( trim( $text ) );

        // Transactional signals
        $transactional = array(
            'acheter', 'achat', 'prix', 'tarif', 'devis', 'commander', 'commande',
            'abonnement', 'offre', 'promo', 'promotion', 'soldes', 'réduction',
            'buy', 'price', 'pricing', 'order', 'purchase', 'deal', 'discount', 'coupon',
            'subscribe', 'signup', 'sign up', 'download', 'télécharger', 'essai gratuit',
            'free trial', 'get started', 'demo', 'démo',
        );

        // Commercial / investigation
        $commercial = array(
            'meilleur', 'meilleure', 'meilleurs', 'meilleures', 'top',
            'comparatif', 'comparaison', 'versus', ' vs ', 'alternative',
            'avis', 'review', 'test', 'classement', 'ranking',
            'quel', 'quelle', 'lequel', 'laquelle', 'choisir', 'choix',
            'best', 'comparison', 'compare', 'which', 'recommend',
            'pour', 'idéal', 'parfait', 'adapté',
        );

        // Navigational
        $navigational = array(
            'login', 'connexion', 'mon compte', 'dashboard', 'espace client',
            'support', 'contact', 'aide',
        );

        foreach ( $transactional as $t ) {
            if ( mb_strpos( $text, $t ) !== false ) return 'transactional';
        }
        foreach ( $commercial as $c ) {
            if ( mb_strpos( $text, $c ) !== false ) return 'commercial';
        }
        foreach ( $navigational as $n ) {
            if ( mb_strpos( $text, $n ) !== false ) return 'navigational';
        }

        return 'info';
    }

    /**
     * Get intent distribution for a plan.
     *
     * @param array $articles Plan articles array
     * @return array { info: N, commercial: N, transactional: N, navigational: N, total: N }
     */
    public static function get_plan_intent_distribution( $articles ) {
        $dist = array( 'info' => 0, 'commercial' => 0, 'transactional' => 0, 'navigational' => 0, 'total' => 0 );
        foreach ( $articles as $art ) {
            $intent = $art['intent'] ?? '';
            // Re-classify if default 'info' or empty
            if ( empty( $intent ) || $intent === 'info' ) {
                $intent = self::classify_intent( ( $art['title'] ?? '' ) . ' ' . ( $art['keyword'] ?? '' ) );
            }
            if ( isset( $dist[ $intent ] ) ) {
                $dist[ $intent ]++;
            } else {
                $dist['info']++;
            }
            $dist['total']++;
        }
        return $dist;
    }

    /**
     * Compute cluster health score.
     *
     * @param array $cluster Cluster data from NLP
     * @param array $nodes   Nodes in this cluster
     * @return array { score: 0-100, grade: A/B/C/D, issues[], recommendations[] }
     */
    public static function compute_cluster_health( $cluster, $nodes ) {
        $result = array(
            'score'           => 0,
            'grade'           => 'D',
            'issues'          => array(),
            'recommendations' => array(),
            'strengths'       => array(),
            'gsc'             => array( 'total_clicks' => 0, 'avg_position' => 0, 'has_data' => false ),
        );

        $page_count = count( $nodes );
        $density    = (int) ( $cluster['density'] ?? 0 );
        $orphans    = 0;
        $has_pillar = false;
        $total_wc   = 0;
        $total_in   = 0;
        $total_out  = 0;

        // GSC aggregation
        $gsc_clicks_sum = 0;
        $gsc_positions  = array();
        $gsc_impressions_sum = 0;

        foreach ( $nodes as $n ) {
            if ( ! empty( $n['is_orphan'] ) || ( $n['role'] ?? '' ) === 'orpheline' ) $orphans++;
            if ( ! empty( $n['is_pillar'] ) || ( $n['role'] ?? '' ) === 'pilier' ) $has_pillar = true;
            $total_wc  += (int) ( $n['word_count'] ?? 0 );
            $total_in  += (int) ( $n['in_links'] ?? $n['in_count_semantic'] ?? 0 );
            $total_out += (int) ( $n['out_links'] ?? $n['out_count_semantic'] ?? 0 );

            // Collect GSC data per node
            $pid = (int) ( $n['id'] ?? 0 );
            if ( $pid > 0 ) {
                $c = (int) get_post_meta( $pid, '_hts_gsc_clicks', true );
                $i = (int) get_post_meta( $pid, '_hts_gsc_impressions', true );
                $p = (float) get_post_meta( $pid, '_hts_gsc_position', true );
                $gsc_clicks_sum += $c;
                $gsc_impressions_sum += $i;
                if ( $p > 0 ) $gsc_positions[] = $p;
            }
        }

        $has_gsc = ( $gsc_clicks_sum > 0 || ! empty( $gsc_positions ) );
        $avg_pos = ! empty( $gsc_positions ) ? round( array_sum( $gsc_positions ) / count( $gsc_positions ), 1 ) : 0;
        $result['gsc'] = array(
            'total_clicks'  => $gsc_clicks_sum,
            'impressions'   => $gsc_impressions_sum,
            'avg_position'  => $avg_pos,
            'has_data'      => $has_gsc,
        );

        $score = 0;

        // Size: 5-7 minimum for authority
        if ( $page_count >= 8 ) {
            $score += 25;
        } elseif ( $page_count >= 5 ) {
            $score += 15;
        } elseif ( $page_count >= 3 ) {
            $score += 8;
            $result['recommendations'][] = 'Ajoutez ' . ( 5 - $page_count ) . '+ articles pour renforcer l\'autorité thématique';
        } else {
            $result['issues'][] = 'Cluster trop fin (' . $page_count . ' pages) — minimum 5 recommandé';
            $result['recommendations'][] = 'Utilisez « Compléter ce cocon » pour ajouter des articles';
        }

        // Has pillar
        if ( $has_pillar ) {
            $score += 20;
        } else {
            $result['issues'][] = 'Pas de page pilier identifiée';
            $result['recommendations'][] = 'Créez une page de synthèse forte pour ce thème';
        }

        // Density (internal linking)
        if ( $density >= 50 ) {
            $score += 25;
        } elseif ( $density >= 30 ) {
            $score += 15;
            $result['recommendations'][] = 'Densité de maillage moyenne — lancez un scan maillage';
        } elseif ( $density >= 10 ) {
            $score += 5;
            $result['issues'][] = 'Maillage faible (' . $density . '%) — les articles ne se lient pas assez';
        } else {
            $result['issues'][] = 'Maillage quasi inexistant';
            $result['recommendations'][] = 'Lancez « Mailler ce cluster » pour créer des liens internes';
        }

        // Orphans ratio
        if ( $page_count > 0 ) {
            $orphan_pct = ( $orphans / $page_count ) * 100;
            if ( $orphan_pct <= 10 ) {
                $score += 15;
            } elseif ( $orphan_pct <= 30 ) {
                $score += 8;
            } else {
                $result['issues'][] = round( $orphan_pct ) . '% de pages orphelines — elles ne reçoivent aucun lien';
            }
        }

        // Content depth (average word count)
        if ( $page_count > 0 ) {
            $avg_wc = $total_wc / $page_count;
            if ( $avg_wc >= 1500 ) {
                $score += 15;
            } elseif ( $avg_wc >= 800 ) {
                $score += 8;
            } else {
                $result['recommendations'][] = 'Contenu moyen de ' . round( $avg_wc ) . ' mots — visez 1000+ pour la profondeur';
            }
        }

        // ── GSC Performance ──
        if ( $has_gsc ) {
            // Cluster gets traffic = validated by Google
            if ( $gsc_clicks_sum >= 50 ) {
                $score += 15;
                $result['strengths'][] = $gsc_clicks_sum . ' clics/mois — cluster actif dans Google';
            } elseif ( $gsc_clicks_sum >= 10 ) {
                $score += 8;
            } elseif ( $gsc_clicks_sum > 0 ) {
                $score += 3;
            }

            // Average position: opportunity signal
            if ( $avg_pos > 0 && $avg_pos <= 5 ) {
                $score += 10;
            } elseif ( $avg_pos > 0 && $avg_pos <= 10 ) {
                $score += 5;
                $result['recommendations'][] = 'Position moyenne ' . $avg_pos . ' — le maillage peut pousser vers le top 3';
            } elseif ( $avg_pos > 10 && $avg_pos <= 20 ) {
                $result['recommendations'][] = 'Position ' . $avg_pos . ' avec ' . $gsc_impressions_sum . ' impressions — fort potentiel, renforcez le maillage interne';
            }

            // High impressions but low clicks = CTR opportunity
            if ( $gsc_impressions_sum >= 1000 && $gsc_clicks_sum < 50 ) {
                $result['recommendations'][] = $gsc_impressions_sum . ' impressions mais peu de clics — optimisez les titles et meta descriptions';
            }
        }

        $result['score'] = min( 100, $score );

        if ( $result['score'] >= 75 )      $result['grade'] = 'A';
        elseif ( $result['score'] >= 55 )   $result['grade'] = 'B';
        elseif ( $result['score'] >= 35 )   $result['grade'] = 'C';
        else                                $result['grade'] = 'D';

        return $result;
    }

    /* ═══════════════════════════════════════
     * AJAX: Pillar health check
     * ═══════════════════════════════════════ */
    public function ajax_check_pillar_health() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(1);

        $url = esc_url_raw( $_POST['pillar_url'] ?? '' );
        if ( empty( $url ) ) wp_send_json_error( 'URL manquante' );

        $health = self::check_pillar_health( $url );
        wp_send_json_success( $health );
    }

    /* ═══════════════════════════════════════
     * BLOC 2 — Embed pending + auto-analyze
     * ═══════════════════════════════════════ */

    /**
     * AJAX: Embed pending posts in batches of 10.
     * Called in a loop from JS until remaining === 0,
     * then JS auto-triggers NLP analysis.
     */
    public function ajax_embed_pending() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        if ( ! class_exists( 'HTS_Embeddings' ) ) {
            wp_send_json_error( 'Module Embeddings indisponible.' );
        }

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 60 );
        }

        $emb     = new HTS_Embeddings();
        $pending = $emb->get_pending_posts( 1 );

        if ( empty( $pending ) ) {
            wp_send_json_success( array(
                'indexed'   => 0,
                'remaining' => 0,
                'done'      => true,
                'skipped'   => 0,
            ) );
        }

        $p   = $pending[0];
        $pid = (int) $p['ID'];

        // Check if should_skip_post creates a permanent-pending loop
        if ( HTS_Embeddings::should_skip_post( $pid, $p['post_name'] ?? '' ) ) {
            update_post_meta( $pid, '_hts_embed_skip', '1' );
            $remaining = count( $emb->get_pending_posts( 50 ) );
            wp_send_json_success( array(
                'indexed'   => 0,
                'remaining' => $remaining,
                'done'      => $remaining === 0,
                'skipped'   => 1,
            ) );
        }

        $ok = $emb->index_post( $pid );
        $remaining = count( $emb->get_pending_posts( 50 ) );

        if ( $ok && function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( '🔄 Embed : %s indexé (%d restant)', get_the_title( $pid ), $remaining ), 'info', 'cocon' );
        }

        wp_send_json_success( array(
            'indexed'   => $ok ? 1 : 0,
            'remaining' => $remaining,
            'done'      => $remaining === 0,
            'skipped'   => $ok ? 0 : 1,
            'debug'     => $ok ? '' : 'Échec embedding post #' . $pid . ' — vérifiez clé OpenAI',
        ) );
    }

    /* ═══════════════════════════════════════
     * BLOC 4 — Image settings getter
     * ═══════════════════════════════════════ */

    /**
     * AJAX: Get current image settings for the UI panel.
     */
    /**
     * AJAX: Generate DALL-E images for a specific post (featured + in-content).
     * Used after manual draft creation so the user doesn't have to wait for cron.
     */
    public function ajax_generate_post_images() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( $post_id <= 0 ) wp_send_json_error( 'post_id requis.' );

        $post = get_post( $post_id );
        if ( ! $post ) wp_send_json_error( 'Article introuvable.' );

        $title   = $post->post_title;
        $keyword = get_post_meta( $post_id, '_hts_api_keyword', true ) ?: $title;
        $content = $post->post_content;

        if ( ! class_exists( 'Hts_Synchronise_Articles_Admin' ) || ! method_exists( 'Hts_Synchronise_Articles_Admin', 'cocon_generate_article_images' ) ) {
            wp_send_json_error( 'Module images non disponible.' );
        }

        $result = Hts_Synchronise_Articles_Admin::cocon_generate_article_images( $post_id, $title, $keyword, $content );

        self::cocon_log( 'images_generated', '🎨 Images générées', array(
            'post_id' => $post_id,
            'title'   => $title,
            'result'  => is_array( $result ) ? count( $result ) . ' image(s)' : 'OK',
        ) );

        wp_send_json_success( array(
            'post_id' => $post_id,
            'message' => 'Images générées',
        ) );
    }

    /**
     * AJAX: Check image generation status for a post.
     * Used by the JS to poll after "images programmées" until completion.
     */
    public function ajax_check_images_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( array( 'message' => 'post_id manquant' ) );

        $pending       = (bool) get_post_meta( $post_id, '_hts_images_pending', true );
        $pending_since = (int) get_post_meta( $post_id, '_hts_images_pending_since', true );
        $done_at       = get_post_meta( $post_id, '_hts_deferred_images_done', true );
        $thumbnail_id  = (int) get_post_meta( $post_id, '_thumbnail_id', true );
        $thumb_url     = $thumbnail_id ? wp_get_attachment_image_url( $thumbnail_id, 'thumbnail' ) : '';
        $img_count     = (int) get_post_meta( $post_id, '_hts_image_count', true );
        $cross_out     = (int) get_post_meta( $post_id, '_hts_cross_links_out', true );
        $cross_in      = (int) get_post_meta( $post_id, '_hts_cross_links_in', true );

        if ( $pending ) {
            // Check for stale: if pending for > 10 min, the cron probably crashed
            if ( $pending_since > 0 && ( time() - $pending_since ) > 600 ) {
                $status = 'done'; // Treat as done — cron crashed but article exists
                // Clean up stale flags
                delete_post_meta( $post_id, '_hts_images_pending' );
                delete_post_meta( $post_id, '_hts_images_pending_since' );
                update_post_meta( $post_id, '_hts_deferred_images_done', current_time( 'Y-m-d H:i:s' ) . ' (stale recovery)' );
            } else {
                $status = 'pending';
            }
        } elseif ( $done_at ) {
            $status = 'done';
        } else {
            // No pending flag and no done flag — images may not have been scheduled, treat as done
            $status = 'done';
        }

        wp_send_json_success( array(
            'status'      => $status,
            'done_at'     => $done_at ?: '',
            'thumb_url'   => $thumb_url,
            'img_count'   => $img_count,
            'cross_links' => $cross_out + $cross_in,
            'edit_url'    => get_edit_post_link( $post_id, 'raw' ),
        ) );
    }

    public function ajax_get_image_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        if ( class_exists( 'Hts_Synchronise_Articles_Admin' ) && method_exists( 'Hts_Synchronise_Articles_Admin', 'get_image_settings' ) ) {
            wp_send_json_success( Hts_Synchronise_Articles_Admin::get_image_settings() );
        } else {
            wp_send_json_success( wp_parse_args( get_option( 'hts_image_settings', array() ), array(
                'featured_enabled'      => true,
                'featured_style'        => 'illustration',
                'featured_quality'      => 'standard',
                'featured_text_overlay' => 'none',
                'incontent_enabled'     => true,
                'incontent_count'       => 2,
                'incontent_types'       => array( 'illustration', 'infographic' ),
                'extra_instructions'    => '',
            ) ) );
        }
    }

    /**
     * AJAX: Get recommended links for a cocon (lazy-loaded after page render).
     */
    public function ajax_get_recommended_links() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        if ( empty( $cocon_id ) ) wp_send_json_error( 'cocon_id requis' );

        $links = $this->get_recommended_links( $cocon_id );
        wp_send_json_success( array( 'links' => $links ) );
    }

    /* ═══════════════════════════════════════════════
     *  COACH INTEGRATION STUB — Sprint 5.1
     * ═══════════════════════════════════════════════ */

    /**
     * Generate satellite articles for a cocon/cluster.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { cluster_id: int, count?: int, keywords?: array }
     * @return bool
     */
    public static function generate_satellites_from_coach( $params ) {
        $cluster_id = isset( $params['cluster_id'] ) ? (int) $params['cluster_id'] : 0;
        if ( $cluster_id <= 0 ) return false;

        // Flag the cocon for satellite generation
        update_option( '_hts_cocon_coach_gen_' . $cluster_id, array(
            'requested_at' => current_time( 'mysql' ),
            'count'        => (int) ( $params['count'] ?? 3 ),
            'keywords'     => $params['keywords'] ?? array(),
        ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach: generate_satellites_from_coach pour cluster #{$cluster_id}", 'info', 'coach' );
        }

        return true;
    }

    /**
     * Cron: Recover abandoned article generation jobs.
     *
     * When a user starts article generation and then closes the browser/refreshes,
     * the JS polling stops and the completed article is never turned into a draft.
     * This cron runs every 15 min and checks for articles stuck in 'queued' status
     * for more than 10 minutes. If the API job is completed, it creates the draft.
     *
     * @since 2.5.0
     */
    public function cron_recover_abandoned_jobs() {
        $plans = $this->get_plans();
        if ( empty( $plans ) ) return;

        $recovered = 0;
        $failed    = 0;
        $now       = time();

        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) ) continue;

            foreach ( $plan['articles'] as $akey => $art ) {
                $status = $art['status'] ?? '';
                $job_id = $art['job_id'] ?? '';

                // Only look at queued articles with a job_id
                if ( $status !== self::STATUS_QUEUED || empty( $job_id ) ) continue;

                // Only recover if queued for > 10 minutes
                $ordered_at = strtotime( $art['ordered_at'] ?? '' );
                if ( ! $ordered_at || ( $now - $ordered_at ) < 600 ) continue;

                // Don't recover if older than 2 hours (transient expired)
                if ( ( $now - $ordered_at ) > 7200 ) {
                    // Mark as error — too old to recover
                    $this->update_article_status( $cocon_id, $akey, self::STATUS_ERROR, array(
                        'error_message' => 'Job abandonné (> 2h sans réponse). Relancez la génération.',
                    ) );
                    $failed++;
                    self::cocon_log( 'article_error', '⏰ Job abandonné > 2h', array(
                        'cocon_id' => $cocon_id,
                        'job_id'   => $job_id,
                        'akey'     => $akey,
                    ) );
                    continue;
                }

                // Poll the API to check if the article is ready
                $result = $this->cocon_api_call( 'GET', 'article-status/' . $job_id );

                if ( ! $result['success'] ) continue; // API unreachable, try again next cycle

                $api_status = $result['data']['status'] ?? '';

                if ( $api_status === 'completed' && ! empty( $result['data']['article'] ) ) {
                    // Article is ready! Store in transient and create draft
                    $transient_key = 'hts_article_' . $job_id;
                    set_transient( $transient_key, $result['data']['article'], 3600 );

                    $draft = $this->create_draft_from_article( $cocon_id, $akey, $job_id );
                    if ( $draft ) {
                        $recovered++;
                        self::cocon_log( 'draft_created', '🔄 Brouillon récupéré (cron) #' . $draft['post_id'], array(
                            'cocon_id' => $cocon_id,
                            'job_id'   => $job_id,
                            'title'    => $draft['title'] ?? '',
                        ) );
                    }
                } elseif ( $api_status === 'failed' || $api_status === 'error' ) {
                    $this->update_article_status( $cocon_id, $akey, self::STATUS_ERROR, array(
                        'error_message' => 'Génération échouée côté API: ' . ( $result['data']['message'] ?? $api_status ),
                    ) );
                    $failed++;
                    self::cocon_log( 'article_error', 'Job échoué côté API (cron recovery)', array(
                        'cocon_id' => $cocon_id,
                        'job_id'   => $job_id,
                        'status'   => $api_status,
                    ) );
                }
                // Status 'processing' → still running, will check again in 15 min
            }
        }

        if ( $recovered > 0 || $failed > 0 ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( '🔄 Recovery cron: %d récupéré(s), %d échoué(s)', $recovered, $failed ),
                    'info', 'cocon-commander'
                );
            }
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     * SPRINT 6.2a — COCONS HISTORIQUES MONEY PAGES
     *
     * Flux:
     *   1. Client déclare ses money pages (_hts_money_page, déjà fait)
     *   2. build_cocon_from_money_page() → trouve articles liés
     *   3. Client confirme → _hts_money_target écrit
     *   4. apply_money_cocon_maillage() → insère les liens
     *
     * Budget de liens respecté:
     *   - count_all_internal_links() compte TOUS les <a> internes
     *   - calc_max_outbound() donne le target (4-12 selon mots)
     *   - Hard cap: max 3 liens HTS par article (M5)
     *   - Si budget = 0 → article skippé
     *
     * Maillage intent journey:
     *   info → support → money (entonnoir)
     *   money → 2-3 support (autorité topique)
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Count ALL internal outbound links in post content.
     */
    private function count_all_internal_links( $content, $post_id = 0 ) {
        if ( empty( $content ) ) return 0;
        $host  = wp_parse_url( home_url(), PHP_URL_HOST );
        $count = 0;

        // Pre-compute self-URL variants to skip self-links without hts_url_to_postid()
        $self_urls = array();
        if ( $post_id > 0 ) {
            $self_permalink = get_permalink( $post_id );
            if ( $self_permalink ) {
                $self_urls[] = $self_permalink;
                $self_urls[] = untrailingslashit( $self_permalink );
                $self_urls[] = trailingslashit( $self_permalink );
                $self_rel = wp_make_link_relative( $self_permalink );
                if ( $self_rel ) {
                    $self_urls[] = $self_rel;
                    $self_urls[] = untrailingslashit( $self_rel );
                    $self_urls[] = trailingslashit( $self_rel );
                }
            }
        }

        if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\'#]+)["\'][^>]*>/i', $content, $m ) ) {
            foreach ( $m[1] as $href ) {
                $is_internal = ( strpos( $href, $host ) !== false )
                            || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 );
                if ( ! $is_internal ) continue;

                // Skip self-links (links pointing back to same page)
                if ( ! empty( $self_urls ) ) {
                    $href_clean = untrailingslashit( $href );
                    $is_self = false;
                    foreach ( $self_urls as $su ) {
                        if ( $href_clean === untrailingslashit( $su ) ) { $is_self = true; break; }
                    }
                    if ( $is_self ) continue;
                }

                $count++;
            }
        }
        return $count;
    }

    /**
     * Public static accessor for link budget — used by HTS_Workflow_Engine.
     * Sprint 6.2d: unified budget check.
     *
     * @since 2.5.0
     * @param int $post_id
     * @return array { budget, existing, hts_count, target, word_count }
     */
    public static function get_link_budget_for_post( $post_id ) {
        // Reuse same instance (init() is NOT called by constructor, so no hook duplication)
        static $instance = null;
        if ( $instance === null ) {
            $instance = new self();
        }
        return $instance->get_link_budget( $post_id );
    }

    /**
     * Calculate remaining link budget for a post.
     */
    private function get_link_budget( $post_id, $content_override = null ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'budget' => 0, 'existing' => 0, 'target' => 0, 'word_count' => 0, 'hts_count' => 0 );

        $content    = $content_override !== null ? $content_override : $post->post_content;
        $word_count = hts_word_count( wp_strip_all_tags( $content ) );
        $existing   = $this->count_all_internal_links( $content, $post_id );

        $config = self::get_linking_defaults();

        // Compute ideal target (no existing links subtracted)
        $target = self::calc_max_outbound( $config, $word_count, 0 );

        // Raw budget: if existing >= target, article is saturated → budget 0
        // Note: calc_max_outbound() returns max(1,...) which masks saturation,
        // so we compute the raw difference ourselves for the money cocon budget.
        $raw_budget = $target - $existing;
        if ( $raw_budget <= 0 ) {
            return array(
                'budget'     => 0,
                'existing'   => $existing,
                'hts_count'  => $this->count_hts_links( $content ),
                'target'     => $target,
                'word_count' => $word_count,
            );
        }

        // Cap HTS proportionnel au word count (M5 v2)
        if ( $word_count < 800 ) {
            $hts_max = 2;
        } elseif ( $word_count < 1500 ) {
            $hts_max = 3;
        } elseif ( $word_count < 3000 ) {
            $hts_max = 4;
        } else {
            $hts_max = 5;
        }
        $hts_existing = $this->count_hts_links( $content );
        $hts_budget   = max( 0, $hts_max - $hts_existing );
        $budget       = min( $raw_budget, $hts_budget );

        return array(
            'budget'     => max( 0, $budget ),
            'existing'   => $existing,
            'hts_count'  => $hts_existing,
            'target'     => $target,
            'word_count' => $word_count,
        );
    }

    /**
     * Build a historical cocon around a money page.
     *
     * @param int $money_page_id
     * @return array|false
     */
    public function build_cocon_from_money_page( $money_page_id ) {
        $post = get_post( $money_page_id );
        if ( ! $post || $post->post_status !== 'publish' ) return false;

        $money_url     = get_permalink( $money_page_id );
        $money_keyword = get_post_meta( $money_page_id, '_hts_focus_keyword', true ) ?: $post->post_title;
        $money_rel_url = wp_make_link_relative( $money_url );

        $cocon_data = self::load_cocon_data();
        $clusters   = $cocon_data['clusters'] ?? array();

        // A. Find money page cluster
        $money_cluster_name = '';
        $money_cluster      = null;
        foreach ( $clusters as $cname => $cl ) {
            if ( in_array( $money_page_id, $cl['pages'] ?? array() ) ) {
                $money_cluster      = $cl;
                $money_cluster_name = $cname;
                break;
            }
        }

        // B. Cluster pages = cocon base
        $cocon_pages    = array();
        $seen_ids       = array( $money_page_id );
        $cluster_count  = 0;
        $already_linked = 0;

        if ( $money_cluster ) {
            foreach ( $money_cluster['pages'] as $pid ) {
                if ( in_array( $pid, $seen_ids ) ) continue;
                $p = get_post( $pid );
                if ( ! $p || $p->post_status !== 'publish' ) continue;
                if ( ! in_array( $p->post_type, array( 'post', 'page' ), true ) ) continue;

                $seen_ids[] = $pid;
                $cluster_count++;

                $has_link = ( strpos( $p->post_content, $money_url ) !== false );
                if ( ! $has_link && $money_rel_url ) $has_link = ( strpos( $p->post_content, $money_rel_url ) !== false );
                if ( $has_link ) $already_linked++;

                $intent = self::classify_intent( ( get_post_meta( $pid, '_hts_focus_keyword', true ) ?: $p->post_title ) . ' ' . $p->post_title );
                $budget = $this->get_link_budget( $pid );

                $cocon_pages[] = array(
                    'id'             => $pid,
                    'title'          => $p->post_title,
                    'url'            => get_permalink( $pid ),
                    'similarity'     => 1.0,
                    'source'         => 'cluster',
                    'cluster'        => $money_cluster_name,
                    'intent'         => $intent,
                    'has_link'       => $has_link,
                    'word_count'     => $budget['word_count'],
                    'link_budget'    => $budget['budget'],
                    'links_existing' => $budget['existing'],
                    'links_target'   => $budget['target'],
                    'budget_full'    => $budget['budget'] <= 0,
                );
            }
        }

        // C. Enrich via embeddings
        $orphan_candidates = array();
        $semantic_count    = 0;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            try {
                $emb     = new \HTS_Embeddings();
                $similar = $emb->find_similar( $money_page_id, 50, 0.25 );
            } catch ( \Exception $e ) {
                $similar = array();
                hts_add_log( 'Embeddings error: ' . $e->getMessage(), 'warning', 'cocon-commander' );
            } catch ( \Error $e ) {
                $similar = array();
                hts_add_log( 'Embeddings fatal: ' . $e->getMessage(), 'error', 'cocon-commander' );
            }

            foreach ( $similar as $s ) {
                $pid = $s['post_id'];
                if ( in_array( $pid, $seen_ids ) ) continue;
                $p = get_post( $pid );
                if ( ! $p || $p->post_status !== 'publish' ) continue;
                if ( ! in_array( $p->post_type, array( 'post', 'page' ), true ) ) continue;

                $seen_ids[] = $pid;

                $other_cluster = '';
                foreach ( $clusters as $cname => $cl ) {
                    if ( in_array( $pid, $cl['pages'] ?? array() ) ) { $other_cluster = $cname; break; }
                }

                $has_link = ( strpos( $p->post_content, $money_url ) !== false );
                if ( ! $has_link && $money_rel_url ) $has_link = ( strpos( $p->post_content, $money_rel_url ) !== false );
                if ( $has_link ) $already_linked++;

                $intent = self::classify_intent( ( get_post_meta( $pid, '_hts_focus_keyword', true ) ?: $p->post_title ) . ' ' . $p->post_title );
                $budget = $this->get_link_budget( $pid );

                $item = array(
                    'id'             => $pid,
                    'title'          => $p->post_title,
                    'url'            => get_permalink( $pid ),
                    'similarity'     => $s['similarity'],
                    'source'         => empty( $other_cluster ) ? 'semantic' : 'other_cluster',
                    'cluster'        => $other_cluster,
                    'intent'         => $intent,
                    'has_link'       => $has_link,
                    'word_count'     => $budget['word_count'],
                    'link_budget'    => $budget['budget'],
                    'links_existing' => $budget['existing'],
                    'links_target'   => $budget['target'],
                    'budget_full'    => $budget['budget'] <= 0,
                );

                if ( $s['similarity'] >= 0.35 ) {
                    $cocon_pages[] = $item;
                    $semantic_count++;
                } else {
                    $item['source'] = 'orphan';
                    $orphan_candidates[] = $item;
                }
            }
        }

        // D. Sort by intent journey
        $intent_order = array( 'transactional' => 0, 'commercial' => 1, 'navigational' => 2, 'info' => 3 );
        usort( $cocon_pages, function( $a, $b ) use ( $intent_order ) {
            $ia = $intent_order[ $a['intent'] ] ?? 3;
            $ib = $intent_order[ $b['intent'] ] ?? 3;
            return $ia !== $ib ? $ia - $ib : $b['similarity'] <=> $a['similarity'];
        } );
        usort( $orphan_candidates, function( $a, $b ) { return $b['similarity'] <=> $a['similarity']; } );

        $budget_full_count = 0;
        foreach ( $cocon_pages as $cp ) { if ( $cp['budget_full'] ) $budget_full_count++; }

        return array(
            'money_page'         => array( 'id' => $money_page_id, 'title' => $post->post_title, 'url' => $money_url, 'keyword' => $money_keyword ),
            'cluster_name'       => $money_cluster_name,
            'cocon_pages'        => $cocon_pages,
            'orphan_candidates'  => array_slice( $orphan_candidates, 0, 10 ),
            'stats'              => array(
                'cluster_count'  => $cluster_count,
                'semantic_count' => $semantic_count,
                'orphan_count'   => count( $orphan_candidates ),
                'already_linked' => $already_linked,
                'total_proposed' => count( $cocon_pages ),
                'budget_full'    => $budget_full_count,
            ),
        );
    }

    /**
     * Apply pyramidal maillage (intent journey) for a money cocon.
     * Respects link budget: count_all_internal_links + calc_max_outbound.
     *
     * @param int   $money_page_id
     * @param array $options { dry_run: bool }
     * @return array
     */
    public function apply_money_cocon_maillage( $money_page_id, $options = array() ) {
        $dry_run    = ! empty( $options['dry_run'] );
        $money_post = get_post( $money_page_id );
        if ( ! $money_post ) return array( 'error' => 'Money page introuvable' );

        $money_url     = get_permalink( $money_page_id );
        $money_keyword = get_post_meta( $money_page_id, '_hts_focus_keyword', true ) ?: $money_post->post_title;
        $money_rel_url = wp_make_link_relative( $money_url );

        $cocon_page_ids = get_posts( array(
            'post_type' => array( 'post', 'page' ), 'post_status' => 'publish',
            'meta_key' => '_hts_money_target', 'meta_value' => (string) $money_page_id,
            'posts_per_page' => 100, 'fields' => 'ids',
        ) );
        if ( empty( $cocon_page_ids ) ) return array( 'error' => 'Aucune page dans ce cocon.' );

        $results = array(
            'links_added' => 0, 'pages_processed' => count( $cocon_page_ids ),
            'already_linked' => 0, 'budget_full' => 0, 'money_outlinks' => 0,
            'info_to_support' => 0, 'details' => array(),
        );

        // Identify support pages
        $support_pages = array();
        foreach ( $cocon_page_ids as $pid ) {
            $role = get_post_meta( $pid, '_hts_page_role', true ) ?: 'info';
            if ( in_array( $role, array( 'support', 'commercial' ), true ) ) {
                $support_pages[] = array(
                    'id' => $pid, 'title' => get_the_title( $pid ), 'url' => get_permalink( $pid ),
                    'keyword' => get_post_meta( $pid, '_hts_focus_keyword', true ) ?: get_the_title( $pid ),
                );
            }
        }

        // PHASE A: Each cocon page → money page
        foreach ( $cocon_page_ids as $page_id ) {
            $post = get_post( $page_id );
            if ( ! $post ) continue;
            $content = $post->post_content;

            // Already linked?
            if ( strpos( $content, $money_url ) !== false ) {
                $results['already_linked']++;
                $results['details'][] = array( 'id' => $page_id, 'action' => 'already_linked', 'title' => $post->post_title );
                continue;
            }
            if ( $money_rel_url && strpos( $content, $money_rel_url ) !== false ) {
                $results['already_linked']++;
                $results['details'][] = array( 'id' => $page_id, 'action' => 'already_linked', 'title' => $post->post_title );
                continue;
            }

            // Budget check
            $budget = $this->get_link_budget( $page_id );
            if ( $budget['budget'] <= 0 ) {
                $results['budget_full']++;
                $results['details'][] = array( 'id' => $page_id, 'action' => 'budget_full', 'title' => $post->post_title, 'existing' => $budget['existing'], 'target' => $budget['target'] );
                continue;
            }

            if ( $dry_run ) {
                $results['links_added']++;
                $results['details'][] = array( 'id' => $page_id, 'action' => 'will_add', 'title' => $post->post_title );
                continue;
            }

            $anchor      = $this->find_contextual_anchor( $content, $money_keyword, $money_post->post_title );
            $anchor_text = $anchor ?: $money_keyword;
            $link_html   = '<a href="' . esc_url( $money_url ) . '" data-hts="money" title="' . esc_attr( $money_post->post_title ) . '">' . esc_html( $anchor_text ) . '</a>';

            $new_content = $this->insert_contextual_link( $content, $link_html, $anchor_text, $money_keyword, $page_id );

            if ( $new_content && $new_content !== $content ) {
                $final_content = $new_content; // May be updated by Phase B below

                if ( class_exists( 'HTS_Audit_Trail' ) ) {
                    \HTS_Audit_Trail::log_link( $page_id, $money_page_id, $anchor_text, 'link_to_money', $content, $new_content, \HTS_Audit_Trail::get_gsc_snapshot( $page_id ) );
                }

                $results['links_added']++;
                $results['details'][] = array( 'id' => $page_id, 'action' => 'added_money_link', 'anchor' => $anchor_text, 'title' => $post->post_title );

                // PHASE B: If info page and still has budget, add 1 support link
                // Use round-robin to distribute across support pages (not always the first)
                $role = get_post_meta( $page_id, '_hts_page_role', true ) ?: 'info';
                // Re-count links in already-modified content (not from DB)
                $budget_after = $this->get_link_budget( $page_id, $final_content );
                if ( $role === 'info' && $budget_after['budget'] >= 1 && ! empty( $support_pages ) ) {
                    $sp_offset = $results['info_to_support'] % count( $support_pages );
                    for ( $sp_i = 0; $sp_i < count( $support_pages ); $sp_i++ ) {
                        $sp = $support_pages[ ( $sp_offset + $sp_i ) % count( $support_pages ) ];
                        if ( strpos( $final_content, $sp['url'] ) !== false ) continue;
                        $sp_rel = wp_make_link_relative( $sp['url'] );
                        if ( $sp_rel && strpos( $final_content, $sp_rel ) !== false ) continue;

                        $sp_anc  = $this->find_contextual_anchor( $final_content, $sp['keyword'], $sp['title'] );
                        $sp_text = $sp_anc ?: $sp['keyword'];
                        $sp_html = '<a href="' . esc_url( $sp['url'] ) . '" data-hts="support" title="' . esc_attr( $sp['title'] ) . '">' . esc_html( $sp_text ) . '</a>';
                        $sp_new  = $this->insert_contextual_link( $final_content, $sp_html, $sp_text, $sp['keyword'], $page_id );

                        if ( $sp_new && $sp_new !== $final_content ) {
                            $final_content = $sp_new;
                            $results['info_to_support']++;
                            if ( class_exists( 'HTS_Audit_Trail' ) ) {
                                \HTS_Audit_Trail::log_link( $page_id, $sp['id'], $sp_text, 'info_to_support', $new_content, $sp_new, \HTS_Audit_Trail::get_gsc_snapshot( $page_id ) );
                            }
                        }
                        break;
                    }
                }

                // Single wp_update_post for both Phase A + B (avoids double hooks/revisions)
                $maillage_update = wp_update_post( array( 'ID' => $page_id, 'post_content' => $final_content ) );
                if ( is_wp_error( $maillage_update ) || 0 === $maillage_update ) {
                    hts_debug_log( sprintf( '[maillage] wp_update_post failed for #%d: %s',
                        $page_id, is_wp_error( $maillage_update ) ? $maillage_update->get_error_message() : 'returned 0' ), 'cocon-commander' );
                } elseif ( class_exists( 'HTS_Content_Extractor' ) ) {
                    \HTS_Content_Extractor::invalidate_cache( $page_id );
                }
            }
        }

        // PHASE C: Money page → 2-3 support pages (topical authority)
        if ( ! empty( $support_pages ) && ! $dry_run ) {
            // Refresh money page from DB (avoid stale WP object cache)
            clean_post_cache( $money_page_id );
            $money_post_fresh = get_post( $money_page_id );
            $mb      = $this->get_link_budget( $money_page_id );
            $mc      = $money_post_fresh ? $money_post_fresh->post_content : $money_post->post_content;
            $mc_orig = $mc;
            $mm      = min( 3, count( $support_pages ), $mb['budget'] );
            $ma      = 0;
            foreach ( $support_pages as $sp ) {
                if ( $ma >= $mm ) break;
                if ( strpos( $mc, $sp['url'] ) !== false ) continue;
                $rel = wp_make_link_relative( $sp['url'] );
                if ( $rel && strpos( $mc, $rel ) !== false ) continue;

                $anc  = $this->find_contextual_anchor( $mc, $sp['keyword'], $sp['title'] );
                $atxt = $anc ?: $sp['keyword'];
                $lh   = '<a href="' . esc_url( $sp['url'] ) . '" data-hts="authority" title="' . esc_attr( $sp['title'] ) . '">' . esc_html( $atxt ) . '</a>';
                $nc   = $this->insert_contextual_link( $mc, $lh, $atxt, $sp['keyword'], $money_page_id );
                if ( $nc && $nc !== $mc ) { $mc = $nc; $ma++; }
            }
            if ( $ma > 0 ) {
                $mp_update = wp_update_post( array( 'ID' => $money_page_id, 'post_content' => $mc ) );
                if ( is_wp_error( $mp_update ) || 0 === $mp_update ) {
                    hts_debug_log( sprintf( '[maillage] wp_update_post failed for money page #%d: %s',
                        $money_page_id, is_wp_error( $mp_update ) ? $mp_update->get_error_message() : 'returned 0' ), 'cocon-commander' );
                } else {
                $results['money_outlinks'] = $ma;
                if ( class_exists( 'HTS_Audit_Trail' ) ) {
                    \HTS_Audit_Trail::log_link( $money_page_id, 0, $ma . ' support links', 'money_to_support', $mc_orig, $mc, \HTS_Audit_Trail::get_gsc_snapshot( $money_page_id ) );
                }
                if ( class_exists( 'HTS_Content_Extractor' ) ) \HTS_Content_Extractor::invalidate_cache( $money_page_id );
                }
            }
        }

        hts_add_log( sprintf( 'Maillage cocon : « %s » — %d ajoutés, %d déjà liés, %d saturés, %d info→support, money→%d',
            mb_substr( $money_post->post_title, 0, 40 ), $results['links_added'], $results['already_linked'],
            $results['budget_full'], $results['info_to_support'], $results['money_outlinks']
        ), 'success', 'cocon-commander' );

        return $results;
    }

    /**
     * Create inbox proposals for maillage within a cluster.
     * Each article → pillar/money page link becomes a workflow proposal.
     * The client approves in the Inbox, then the link is applied.
     *
     * @param int    $target_id   Pillar or money page to link TO
     * @param string $cluster     Cluster name (for logging/display)
     * @param array  $page_ids    Array of post IDs to link FROM
     * @return array { proposed, already_linked, budget_full, skipped }
     */
    public function propose_cluster_maillage( $target_id, $cluster, array $page_ids ) {
        $target_post = get_post( $target_id );
        if ( ! $target_post ) {
            hts_debug_log( '[fix7] propose_cluster_maillage: target post ' . $target_id . ' not found' );
            return array( 'proposed' => 0, 'already_linked' => 0, 'budget_full' => 0, 'skipped' => 0 );
        }

        $target_url     = get_permalink( $target_id );
        $target_keyword = get_post_meta( $target_id, '_hts_focus_keyword', true ) ?: $target_post->post_title;
        $target_rel_url = wp_make_link_relative( $target_url );

        hts_debug_log( sprintf( '[fix7] propose_cluster_maillage: cluster="%s" target=%d "%s" url=%s pages=%d',
            $cluster, $target_id, mb_substr( $target_post->post_title, 0, 40 ), $target_url, count( $page_ids )
        ) );

        // fix8: detect target language for hreflang compatibility
        $target_lang = '';
        if ( class_exists( 'HTS_Language' ) && method_exists( 'HTS_Language', 'get_post_language' ) ) {
            $target_lang = HTS_Language::get_post_language( $target_id ) ?: '';
        }

        $stats = array( 'proposed' => 0, 'already_linked' => 0, 'budget_full' => 0, 'skipped' => 0 );

        foreach ( $page_ids as $page_id ) {
            $page_id = (int) $page_id;
            if ( $page_id === $target_id ) continue;

            $post = get_post( $page_id );
            if ( ! $post || $post->post_status !== 'publish' ) { $stats['skipped']++; continue; }

            // fix8: hreflang check — only link pages in the same language
            if ( $target_lang && class_exists( 'HTS_Language' ) ) {
                $source_lang = HTS_Language::get_post_language( $page_id ) ?: '';
                if ( $source_lang && $source_lang !== $target_lang ) {
                    $stats['skipped']++;
                    continue;
                }
            }

            $content = $post->post_content;

            // Already linked? — fix7: only check inside <a> href attributes, not raw content
            $has_link = false;
            if ( preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>/i', $content, $href_matches ) ) {
                foreach ( $href_matches[1] as $href ) {
                    if ( $target_url && strpos( $href, $target_url ) !== false ) { $has_link = true; break; }
                    if ( $target_rel_url && strpos( $href, $target_rel_url ) !== false ) { $has_link = true; break; }
                    // fix7: also check untrailingslashit variants
                    if ( $target_url && untrailingslashit( $href ) === untrailingslashit( $target_url ) ) { $has_link = true; break; }
                }
            }
            if ( $has_link ) {
                $stats['already_linked']++;
                continue;
            }

            // Budget check — fix9: for Inbox proposals, NEVER block.
            // The budget will be re-checked at execution time (dispatch_internal_links).
            // The user sees the proposal in Inbox and decides; blocking here hides useful info.
            $budget = $this->get_link_budget( $page_id );
            $budget_warning = ( $budget['budget'] <= 0 );
            if ( $budget_warning ) {
                hts_debug_log( sprintf( '[fix9] propose_cluster_maillage: page %d budget=0 (hts=%d existing=%d target=%d) — PROPOSING ANYWAY (budget checked at execution)',
                    $page_id, $budget['hts_count'], $budget['existing'], $budget['target'] ) );
            }

            // Find best anchor text
            $anchor = $this->find_contextual_anchor( $content, $target_keyword, $target_post->post_title );
            if ( ! $anchor ) $anchor = $target_keyword;

            // Create inbox proposal via Workflow Engine
            if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                $proposal_data = array(
                    'target_id'    => $target_id,
                    'target_url'   => $target_url,
                    'target_title' => $target_post->post_title,
                    'anchor_text'  => $anchor,
                    'source_cocon' => true,
                    'cluster'      => $cluster,
                    'link_type'    => 'cluster',
                    'suggestion'   => sprintf( 'Ajouter un lien vers « %s »', mb_substr( $target_post->post_title, 0, 50 ) ),
                    'reason'       => sprintf( 'Cluster « %s » → %s', mb_substr( $cluster, 0, 30 ), mb_substr( $target_post->post_title, 0, 40 ) ),
                );
                // fix9: add budget warning so Inbox can display it
                if ( $budget_warning ) {
                    $proposal_data['budget_warning'] = true;
                    $proposal_data['budget_info'] = sprintf( '%d liens existants / %d max (%d HTS)', $budget['existing'], $budget['target'], $budget['hts_count'] );
                }
                $proposed_id = \HTS_Workflow_Engine::propose( 'linking', 'add_internal_links', $page_id, $proposal_data, $budget_warning ? 'low' : 'medium' );

                if ( $proposed_id ) {
                    $stats['proposed']++;
                    hts_debug_log( sprintf( '[fix7] propose OK: action_id=%d page=%d → target=%d anchor="%s"',
                        $proposed_id, $page_id, $target_id, mb_substr( $anchor, 0, 30 ) ) );
                } else {
                    $stats['skipped']++;
                    hts_debug_log( sprintf( '[fix7] propose FAILED: page=%d → target=%d (WE returned false)',
                        $page_id, $target_id ) );
                }
            } else {
                $stats['skipped']++;
                hts_debug_log( '[fix7] propose_cluster_maillage: HTS_Workflow_Engine class not found!' );
            }
        }

        if ( $stats['proposed'] > 0 ) {
            hts_add_log( sprintf( '📥 Cluster « %s » : %d proposition(s) envoyées à l\'inbox → %s',
                mb_substr( $cluster, 0, 30 ), $stats['proposed'], mb_substr( $target_post->post_title, 0, 40 )
            ), 'info', 'cocon-commander' );
        }

        return $stats;
    }

    /**
     * Auto-build all money cocons (1-click mode).
     *
     * Works PER CLUSTER:
     * 1. Load clusters (multilingual-aware)
     * 2. For each cluster: find money page inside OR use NLP pillar as target
     * 3. Assign ONLY same-cluster pages (strict silo, no cross-cluster)
     * 4. Apply maillage per cluster
     */
    public function auto_build_all_money_cocons() {
        $cocon_data = self::load_cocon_data();
        $clusters   = $cocon_data['clusters'] ?? array();

        $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
        hts_debug_log( sprintf( '[linking-unified] auto_build: lang=%s clusters=%d', $lang ?: '(none)', count( $clusters ) ) );

        if ( empty( $clusters ) ) {
            return array( 'error' => 'Aucun cluster détecté. Lancez « Recréer les clusters » d\'abord.' );
        }

        if ( ! class_exists( 'HTS_Cocon' ) || ! class_exists( 'HTS_Workflow_Engine' ) ) {
            return array( 'error' => 'Modules requis non disponibles.' );
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 );

        // A3: Compter les propositions pending existantes
        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';
        $existing_pending = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE agent = 'linking' AND type = 'add_internal_links' AND status = 'pending'"
        );

        $cocon = new \HTS_Cocon();

        // Get dismissed targets to skip
        $dismissed = array();
        if ( method_exists( 'HTS_Workflow_Engine', 'get_dismissed_targets' ) ) {
            $dismissed = \HTS_Workflow_Engine::get_dismissed_targets();
        }

        $global = array(
            'money_pages_processed' => 0,
            'total_cocon_pages'     => 0,
            'total_links_added'     => 0,
            'total_already_done'    => 0,
            'total_skipped'         => 0,
            'details'               => array(),
        );

        // Diversité des ancres — tracker les ancres par source
        $anchors_by_source = array();

        foreach ( $clusters as $cname => $cl ) {
            if ( in_array( $cname, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;
            if ( empty( $cl['pages'] ) ) continue;

            // Reset anchors tracker par cluster
            $anchors_by_source = array();

            // Use the V3 pipeline: Graph → Score → Anchor → Triple-check
            $result = $cocon->suggest_cluster_links( $cname, $lang );
            if ( ! empty( $result['error'] ) || empty( $result['suggestions'] ) ) {
                hts_debug_log( sprintf( '[linking-unified] cluster "%s": skip (%s)', $cname, $result['error'] ?? '0 suggestions' ) );
                continue;
            }

            $pillar_id = (int) ( $result['pillar_id'] ?? 0 );
            $proposed  = 0;
            $done      = 0;
            $skipped   = 0;

            foreach ( $result['suggestions'] as $sug ) {
                $state = $sug['state'] ?? 'pending';

                // Only propose pending or lost links
                if ( $state === 'done' ) { $done++; continue; }

                $source_id = (int) $sug['source_id'];
                $target_id = (int) $sug['target_id'];

                // Check dismissed blacklist
                $pair_key = $source_id . '_' . $target_id;
                if ( isset( $dismissed[ $pair_key ] ) ) { $skipped++; continue; }

                // Check pause linking (30j après 3 dismiss)
                $paused_until = (int) get_post_meta( $source_id, '_hts_linking_paused', true );
                if ( $paused_until > 0 && time() < $paused_until ) {
                    $skipped++;
                    continue; // Article en pause linking
                }

                // 1A. Budget check — ne pas proposer si source saturée
                if ( method_exists( $this, 'get_link_budget' ) ) {
                    $budget_info = $this->get_link_budget( $source_id );
                    if ( $budget_info['budget'] <= 0 ) {
                        hts_debug_log( '[linking-unified] Skip saturé #' . $source_id . ' (' . $budget_info['existing'] . '/' . $budget_info['target'] . ')' );
                        $skipped++;
                        continue;
                    }
                }

                // 1B. Vérifier que l'ancre existe dans le contenu source (pour les extract)
                $anchor_type = $sug['anchor_type'] ?? 'extract';
                if ( $anchor_type === 'extract' && ! empty( $sug['anchor_text'] ) ) {
                    $src_post = get_post( $source_id );
                    if ( $src_post ) {
                        $decoded = html_entity_decode( wp_strip_all_tags( $src_post->post_content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                        $anchor_found = ( mb_stripos( $decoded, $sug['anchor_text'] ) !== false );
                        // Fallback Elementor
                        if ( ! $anchor_found ) {
                            $el_data = get_post_meta( $source_id, '_elementor_data', true );
                            if ( is_string( $el_data ) && ! empty( $el_data ) ) {
                                $el_text = html_entity_decode( wp_strip_all_tags( $el_data ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                                $anchor_found = ( mb_stripos( $el_text, $sug['anchor_text'] ) !== false );
                            }
                        }
                        if ( ! $anchor_found ) {
                            hts_debug_log( '[linking-unified] Skip ancre introuvable "' . mb_substr( $sug['anchor_text'], 0, 40 ) . '" dans #' . $source_id );
                            $skipped++;
                            continue;
                        }
                    }
                }

                // 1C. Vérifier que la cible est publiée
                if ( ! get_post( $target_id ) || get_post_status( $target_id ) !== 'publish' ) {
                    $skipped++;
                    continue;
                }

                $proposal_data = array(
                    'target_id'     => $target_id,
                    'target_url'    => get_permalink( $target_id ),
                    'target_title'  => $sug['target_title'] ?? get_the_title( $target_id ),
                    'anchor_text'   => $sug['anchor_text'] ?? '',
                    'anchor_method' => $sug['anchor_method'] ?? 'php',
                    'bridge'        => $sug['anchor_bridge'] ?? '',
                    'source_cocon'  => true,
                    'cluster'       => $cname,
                    'link_type'     => $sug['link_type'] ?? 'cluster',
                    'suggestion'    => sprintf( 'Lien %s vers « %s »', $sug['link_type'] ?? 'cluster', mb_substr( $sug['target_title'] ?? '', 0, 50 ) ),
                    'reason'        => $sug['reason'] ?? sprintf( 'Cluster « %s »', mb_substr( $cname, 0, 30 ) ),
                );

                // 1D. Stocker le budget pour la modale
                if ( method_exists( $this, 'get_link_budget' ) ) {
                    $budget_info = $this->get_link_budget( $source_id );
                    $proposal_data['_budget'] = array(
                        'existing' => $budget_info['existing'],
                        'target'   => $budget_info['target'],
                        'budget'   => $budget_info['budget'],
                    );
                }

                if ( ! empty( $sug['orphan_rescue'] ) ) {
                    $proposal_data['priority'] = 'high';
                    $proposal_data['orphan_rescue'] = true;
                }

                // Diversité ancres — skip si trop similaire à une ancre déjà proposée
                $anchor_lower = mb_strtolower( $sug['anchor_text'] ?? '' );
                if ( isset( $anchors_by_source[ $source_id ] ) ) {
                    $too_similar = false;
                    foreach ( $anchors_by_source[ $source_id ] as $existing_anchor ) {
                        $words_a = array_unique( preg_split( '/\s+/', $anchor_lower ) );
                        $words_b = array_unique( preg_split( '/\s+/', $existing_anchor ) );
                        $inter   = count( array_intersect( $words_a, $words_b ) );
                        $union   = count( array_unique( array_merge( $words_a, $words_b ) ) );
                        if ( $union > 0 && ( $inter / $union ) > 0.5 ) {
                            $too_similar = true;
                            break;
                        }
                    }
                    if ( $too_similar ) {
                        $skipped++;
                        continue;
                    }
                }

                $priority = ! empty( $sug['orphan_rescue'] ) ? 'high' : ( $sug['priority'] ?? 'medium' );
                $proposed_id = \HTS_Workflow_Engine::propose( 'linking', 'add_internal_links', $source_id, $proposal_data, $priority );

                if ( $proposed_id ) {
                    $proposed++;
                    $anchors_by_source[ $source_id ][] = $anchor_lower;
                } else {
                    $skipped++;
                }
            }

            $global['money_pages_processed']++;
            $global['total_cocon_pages']    += count( $cl['pages'] );
            $global['total_links_added']    += $proposed;
            $global['total_already_done']   += $done;
            $global['total_skipped']        += $skipped;
            $global['details'][] = array(
                'cluster'        => $cname,
                'pillar_id'      => $pillar_id,
                'pillar_title'   => $result['pillar_title'] ?? '',
                'cocon_pages'    => count( $cl['pages'] ),
                'links_proposed' => $proposed,
                'already_done'   => $done,
                'skipped'        => $skipped,
            );

            hts_debug_log( sprintf( '[linking-unified] cluster "%s": proposed=%d done=%d skipped=%d', $cname, $proposed, $done, $skipped ) );
        }

        hts_add_log( sprintf( 'Maillage unifié : %d clusters, %d articles, %d propositions envoyées à l\'inbox (%d déjà liés)',
            $global['money_pages_processed'], $global['total_cocon_pages'],
            $global['total_links_added'], $global['total_already_done']
        ), 'success', 'cocon-commander' );

        delete_option( 'hts_cocon_awaiting_maillage' );
        $global['existing_pending'] = $existing_pending;
        return $global;
    }

    /* ═══ MONEY PAGE DISCOVERY — Smart multi-signal scoring ═══════════════
     *
     * Signals (max ~100pts):
     *   URL commerciale      +20   (devis, tarif, services, produit…)
     *   WooCommerce           +25   (product post_type or shortcode)
     *   CTA / Formulaire     +10-15 (form, tel:, booking widget, CTA button)
     *   GSC trafic            +5-20  (position + clics)
     *   Contenu commercial   +8-15  (densité mots commerciaux)
     *   Hub sémantique       +8-15  (nb articles proches via embeddings)
     *   Schema markup         +10   (Product, Service, Offer, LocalBusiness)
     *   Page niveau 1         +5    (page sans parent)
     *   Cluster actif         +5    (appartient à un cluster NLP)
     *
     * Blacklist auto-exclue : contact, équipe, mentions légales, CGV, panier,
     *   mon-compte, test, 404, plan-du-site, etc.
     *
     * Seuil recommandé : 30pts
     * ═══════════════════════════════════════════════════════════════════ */

    /**
     * Multi-byte aware word count that works for French.
     * hts_word_count() is locale-dependent and fails on accented chars.
     *
     * @param string $text Plain text (already stripped of HTML)
     * @return int
     */
    private static function mb_word_count( $text ) {
        if ( empty( $text ) ) return 0;
        // Split on whitespace, filter empty
        return count( array_filter( preg_split( '/\s+/u', trim( $text ) ), 'strlen' ) );
    }

    private static function get_money_blacklist_patterns() {
        return array(
            'contact', 'contactez', 'mentions-legales', 'mention-legale', 'cgv', 'cgu',
            'politique-de-confidentialite', 'politique-confidentialite', 'privacy', 'privacy-policy',
            'conditions-generales', 'conditions-utilisation', 'rgpd', 'gdpr', 'legal', 'disclaimer',
            'equipe', 'notre-equipe', 'team', 'our-team', 'about', 'a-propos', 'qui-sommes-nous',
            'notre-histoire', 'about-us', 'qui-suis-je',
            'plan-du-site', 'sitemap', 'panier', 'cart', 'checkout', 'paiement',
            'mon-compte', 'my-account', 'login', 'connexion', 'inscription', 'register',
            '404', 'merci', 'thank', 'confirmation', 'newsletter', 'unsubscribe',
            'test-page', 'page-test', 'exemple', 'sample', 'brouillon', 'draft', 'temp',
            'wp-admin', 'wp-login', 'feed', 'author',
            'partenaires', 'recrutement', 'carriere', 'careers', 'presse', 'press',
        );
    }

    private static function get_commercial_url_slugs() {
        return array(
            'devis', 'tarif', 'tarifs', 'prix', 'pricing', 'cout', 'budget',
            'services', 'service', 'prestations', 'prestation', 'nos-services',
            'produit', 'produits', 'product', 'products', 'shop', 'boutique', 'catalogue',
            'offre', 'offres', 'offer', 'offers', 'pack', 'packs', 'formule', 'formules',
            'formation', 'formations', 'training', 'cours', 'programme',
            'accompagnement', 'coaching', 'consulting', 'conseil', 'audit',
            'solution', 'solutions', 'agence', 'agency',
            'reservation', 'booking', 'rendez-vous', 'appointment', 'rdv',
            'demo', 'essai', 'trial', 'get-started', 'commencer',
            'location', 'locations', 'achat', 'vente',
            // SEO 2026: Buying guides & comparison hubs (near-conversion content)
            'guide', 'comparatif', 'comparateur', 'comment-choisir', 'choisir',
            'meilleur', 'meilleurs', 'meilleures', 'top', 'selection',
            'avis', 'test', // Note: 'test' in URL = buying guide context, distinct from blacklist 'test' pages
            'promo', 'promotion', 'soldes', 'destockage',
        );
    }

    private static function get_commercial_content_keywords() {
        return array(
            'devis', 'tarif', 'prix', 'gratuit', 'offre', 'acheter', 'commander',
            'réserver', 'essai', 'abonnement', 'formule', 'forfait',
            'à partir de', 'sur mesure', 'personnalisé', 'clé en main',
            'résultat', 'garanti', 'satisfaction', 'expert', 'professionnel',
            'solution', 'prestation', 'service', 'accompagnement',
            'bénéficiez', 'profitez', 'découvrez notre', 'demandez',
            'livraison', 'retour', 'remboursement', 'paiement',
            // SEO 2026: Buying guide & comparison keywords
            'comparatif', 'meilleur', 'guide d\'achat', 'comment choisir',
            'notre sélection', 'top', 'classement', 'versus', ' vs ',
            'avantages', 'inconvénients', 'avis', 'recommandation',
        );
    }

    /**
     * Detect CTA signals in post content.
     *
     * @param string $content Raw post_content
     * @return array { signals: array[], score: int }
     */
    private function detect_cta_signals( $content ) {
        $signals = array();
        $score   = 0;

        // ── Forms (HTML + shortcodes CF7, Gravity, WPForms, Forminator, Ninja) ──
        $form_count = 0;
        $form_count += preg_match_all( '/<form[^>]*>/i', $content, $m );
        $form_count += preg_match_all( '/\[(contact-form|gravityform|wpforms|forminator|ninja_form|caldera_form|fluentform)[^\]]*\]/i', $content, $m );
        if ( $form_count > 0 ) {
            $signals[] = array( 'key' => 'cta_form', 'label' => '📋 Formulaire', 'detail' => $form_count . ' formulaire(s)', 'points' => 15 );
            $score += 15;
        }

        // ── Phone link ──
        if ( preg_match( '/href=["\']tel:/i', $content ) ) {
            $signals[] = array( 'key' => 'cta_phone', 'label' => '📞 Téléphone', 'detail' => 'Lien tel: détecté', 'points' => 10 );
            $score += 10;
        }

        // ── Booking widgets ──
        $booking = array( 'calendly', 'acuity', 'bookly', 'amelia', 'data-cal-link', 'doctolib', 'reservio', 'simplybook' );
        foreach ( $booking as $bp ) {
            if ( stripos( $content, $bp ) !== false ) {
                $signals[] = array( 'key' => 'cta_booking', 'label' => '📅 Réservation', 'detail' => 'Widget réservation', 'points' => 15 );
                $score += 15;
                break;
            }
        }

        // ── WooCommerce shortcodes / elements (not just the word in prose) ──
        $woo_active = preg_match( '/\[(product|products|add_to_cart|shop_messages|woocommerce_cart|woocommerce_checkout|woocommerce_my_account|product_page|product_category)[^\]]*\]/i', $content )
            || preg_match( '/class=["\'][^"\']*woocommerce[^"\']*["\']/i', $content )
            || strpos( $content, 'add_to_cart_button' ) !== false
            || strpos( $content, 'data-product_id' ) !== false;
        if ( $woo_active ) {
            $signals[] = array( 'key' => 'woocommerce', 'label' => '🛒 E-commerce', 'detail' => 'Élément WooCommerce', 'points' => 25 );
            $score += 25;
        }

        // ── CTA buttons with commercial text ──
        if ( preg_match_all( '/<(?:a|button)[^>]*class=["\'][^"\']*(?:btn|button|cta|wp-block-button)[^"\']*["\'][^>]*>([^<]{3,50})<\//i', $content, $btns ) ) {
            $btn_kw = array( 'devis', 'rdv', 'réserver', 'acheter', 'commander', 'essai', 'demo', 'commencer', 'souscrire', 'inscription', 'demander', 'obtenir' );
            foreach ( $btns[1] as $btn_text ) {
                foreach ( $btn_kw as $bk ) {
                    if ( mb_stripos( $btn_text, $bk ) !== false ) {
                        $signals[] = array( 'key' => 'cta_button', 'label' => '🔘 Bouton CTA', 'detail' => '« ' . mb_substr( trim( $btn_text ), 0, 25 ) . ' »', 'points' => 10 );
                        $score += 10;
                        break 2;
                    }
                }
            }
        }

        return array( 'signals' => $signals, 'score' => $score );
    }

    /**
     * Score a single page as a money page candidate.
     *
     * @param int              $post_id
     * @param \WP_Post|null    $post
     * @param array            $clusters  From hts_cocon_data
     * @param \HTS_Embeddings|null $emb
     * @return array|null  { id, title, url, slug, score, reasons[], gsc_*, similar_count, manual, dismissed }
     */
    public function score_money_page_candidate( $post_id, $post = null, $clusters = array(), $emb = null, $menu_page_ids = array() ) {
        if ( ! $post ) $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return null;

        $slug       = $post->post_name;
        $content    = $post->post_content;
        $url        = get_permalink( $post_id );
        $signals    = array();
        $score      = 0;
        $in_menu    = isset( $menu_page_ids[ $post_id ] );
        $word_count = self::mb_word_count( wp_strip_all_tags( $content ) );

        // ── Menu signal — pages in WP nav menus are business pages ──
        if ( $in_menu ) {
            $menu_name = $menu_page_ids[ $post_id ];
            $signals[] = array( 'key' => 'in_menu', 'label' => 'Menu principal', 'detail' => 'Pr\u00e9sente dans le menu « ' . $menu_name . ' »', 'points' => 25 );
            $score += 25;
        }

        // ── BLACKLIST — auto-exclude (match full slug segments, not substrings) ──
        $blacklist  = self::get_money_blacklist_patterns();
        $slug_parts = explode( '-', $slug );
        foreach ( $blacklist as $bl ) {
            // Exact segment match: 'test' matches 'test-page' but NOT 'testimonials'
            // Multi-word patterns like 'qui-sommes-nous': check if slug starts with, ends with, or contains as segment sequence
            if ( strpos( $bl, '-' ) !== false ) {
                // Multi-segment pattern: direct strpos on slug is correct
                if ( $slug === $bl || strpos( $slug, $bl . '-' ) === 0 || strpos( $slug, '-' . $bl ) !== false ) {
                    return array( 'id' => $post_id, 'score' => -1, 'blacklisted' => true, 'bl_reason' => $bl );
                }
            } else {
                // Single-segment pattern: match exact segments
                if ( in_array( $bl, $slug_parts, true ) ) {
                    return array( 'id' => $post_id, 'score' => -1, 'blacklisted' => true, 'bl_reason' => $bl );
                }
            }
        }
        // Very short pages are utility, not money
        // WooCommerce products often have short descriptions (specs, images, etc.)
        $min_words = ( $post->post_type === 'product' ) ? 15 : 80;
        if ( $word_count < $min_words ) {
            return array( 'id' => $post_id, 'score' => -1, 'blacklisted' => true, 'bl_reason' => 'too_short' );
        }

        // ── WooCommerce product (post_type) ──
        $is_woo_product = ( $post->post_type === 'product' );
        if ( $is_woo_product ) {
            $signals[] = array( 'key' => 'woo_product', 'label' => '🛒 Produit', 'detail' => 'Page produit WooCommerce', 'points' => 25 );
            $score += 25;

            // WooCommerce: product attributes & variations = richer product page
            if ( function_exists( 'wc_get_product' ) ) {
                try {
                    $wc_product = wc_get_product( $post_id );
                    if ( $wc_product ) {
                        $attrs = $wc_product->get_attributes();
                        if ( count( $attrs ) >= 2 ) {
                            $signals[] = array( 'key' => 'woo_attributes', 'label' => '🏷️ Attributs produit', 'detail' => count( $attrs ) . ' attribut(s)', 'points' => 5 );
                            $score += 5;
                        }
                        if ( $wc_product->is_type( 'variable' ) ) {
                            $var_count = count( $wc_product->get_children() );
                            if ( $var_count >= 3 ) {
                                $signals[] = array( 'key' => 'woo_variations', 'label' => '🔀 Variations', 'detail' => $var_count . ' variante(s)', 'points' => 5 );
                                $score += 5;
                            }
                        }
                    }
                } catch ( \Exception $e ) { /* WooCommerce not fully loaded */ }
                catch ( \Error $e ) { /* skip */ }
            }
        }

        // ── URL commercial slug (segment-level match, not substring) ──
        $commercial_slugs = self::get_commercial_url_slugs();
        foreach ( $commercial_slugs as $cs ) {
            $matched = false;
            if ( strpos( $cs, '-' ) !== false ) {
                // Multi-segment: 'nos-services' → check as substring boundary
                $matched = ( $slug === $cs || strpos( $slug, $cs . '-' ) === 0 || strpos( $slug, '-' . $cs ) !== false );
            } else {
                $matched = in_array( $cs, $slug_parts, true );
            }
            if ( $matched ) {
                $signals[] = array( 'key' => 'url_commercial', 'label' => '🔗 URL commerciale', 'detail' => 'Contient /' . $cs . '/', 'points' => 20 );
                $score += 20;
                break;
            }
        }

        // ── CTA detection ──
        $cta = $this->detect_cta_signals( $content );
        // Avoid double-scoring WooCommerce: product post_type already gets +25
        if ( $is_woo_product ) {
            $cta['signals'] = array_values( array_filter( $cta['signals'], function ( $s ) {
                return $s['key'] !== 'woocommerce';
            } ) );
            $cta['score'] = array_sum( array_column( $cta['signals'], 'points' ) );
        }
        $signals = array_merge( $signals, $cta['signals'] );
        $score += $cta['score'];

        // ── Page vs Article : pages WP sont presque toujours des pages service/pilier ──
        if ( $post->post_type === 'page' ) {
            $signals[] = array( 'key' => 'is_page', 'label' => 'Page service', 'detail' => 'Type WordPress « Page » (pas un article blog)', 'points' => 15 );
            $score += 15;
        } elseif ( $post->post_type === 'post' && $word_count > 800 ) {
            $signals[] = array( 'key' => 'long_article', 'label' => 'Article long', 'detail' => $word_count . ' mots — probablement un contenu satellite', 'points' => -10 );
            $score -= 10;
        }

        // ── URL courte = page importante (closer to root) ──
        $url_depth = substr_count( trim( wp_parse_url( $url, PHP_URL_PATH ) ?: '', '/' ), '/' );
        if ( $url_depth <= 1 ) {
            $signals[] = array( 'key' => 'short_url', 'label' => 'URL racine', 'detail' => 'URL à 1 niveau — page stratégique', 'points' => 10 );
            $score += 10;
        } elseif ( $url_depth === 2 ) {
            $signals[] = array( 'key' => 'short_url', 'label' => 'URL courte', 'detail' => 'URL à 2 niveaux', 'points' => 5 );
            $score += 5;
        }

        // ── Page de conversion : formulaire de devis/contact ──
        $has_form = preg_match( '/\[contact-form|wpforms|gravity|elementor-form|forminator|devis|quote/i', $content );
        if ( $has_form ) {
            $signals[] = array( 'key' => 'has_form', 'label' => 'Formulaire', 'detail' => 'Contient un formulaire (devis/contact)', 'points' => 15 );
            $score += 15;
        }

        // ── GSC data ──
        $gsc_clicks      = (int) get_post_meta( $post_id, '_hts_gsc_clicks', true );
        $gsc_impressions  = (int) get_post_meta( $post_id, '_hts_gsc_impressions', true );
        $gsc_position     = (float) get_post_meta( $post_id, '_hts_gsc_position', true );

        if ( $gsc_clicks > 10 && $gsc_position > 0 && $gsc_position <= 10 ) {
            $pts = min( 20, 10 + (int) ( $gsc_clicks / 20 ) );
            $signals[] = array( 'key' => 'gsc_top10', 'label' => 'Top 10 Google', 'detail' => 'Pos. ' . round( $gsc_position, 1 ) . ' · ' . $gsc_clicks . ' clics', 'points' => $pts );
            $score += $pts;
        } elseif ( $gsc_clicks > 5 && $gsc_position > 0 && $gsc_position <= 20 ) {
            $pts = min( 15, 5 + (int) ( $gsc_clicks / 10 ) );
            $signals[] = array( 'key' => 'gsc_striking', 'label' => 'Visible sur Google', 'detail' => 'Pos. ' . round( $gsc_position, 1 ) . ' · ' . $gsc_clicks . ' clics', 'points' => $pts );
            $score += $pts;
        } elseif ( $gsc_impressions > 100 ) {
            $signals[] = array( 'key' => 'gsc_impressions', 'label' => '👁️ Impressions', 'detail' => $gsc_impressions . ' impressions/mois', 'points' => 5 );
            $score += 5;
        }

        // ── Commercial content density ──
        $text_lower     = mb_strtolower( wp_strip_all_tags( $content ) );
        $commercial_kws = self::get_commercial_content_keywords();
        $kw_count = 0;
        foreach ( $commercial_kws as $ckw ) {
            $kw_count += mb_substr_count( $text_lower, $ckw );
        }
        if ( $word_count > 0 ) {
            $density = ( $kw_count / $word_count ) * 100;
            if ( $density > 2.0 ) {
                $signals[] = array( 'key' => 'commercial_content', 'label' => '💰 Contenu commercial', 'detail' => round( $density, 1 ) . '% termes commerciaux', 'points' => 15 );
                $score += 15;
            } elseif ( $density > 1.0 ) {
                $signals[] = array( 'key' => 'commercial_content', 'label' => '💰 Semi-commercial', 'detail' => round( $density, 1 ) . '% termes commerciaux', 'points' => 8 );
                $score += 8;
            }
        }

        // ── Cluster membership ──
        $cluster_name = '';
        foreach ( $clusters as $cname => $cl ) {
            if ( in_array( $post_id, $cl['pages'] ?? array() ) ) {
                $cluster_name = $cname;
                $signals[] = array( 'key' => 'in_cluster', 'label' => '🗂️ Cluster NLP', 'detail' => mb_substr( $cname, 0, 30 ), 'points' => 5 );
                $score += 5;
                break;
            }
        }

        // ── Embeddings hub (expensive: only for high pre-score pages) ──
        $similar_count = 0;
        if ( $emb && $score >= 25 ) {
            try {
                $similar       = $emb->find_similar( $post_id, 50, 0.30 );
                $similar_count = count( $similar );
                if ( $similar_count >= 10 ) {
                    $signals[] = array( 'key' => 'cluster_hub', 'label' => '🧠 Hub thématique', 'detail' => $similar_count . ' articles proches', 'points' => 15 );
                    $score += 15;
                } elseif ( $similar_count >= 5 ) {
                    $signals[] = array( 'key' => 'cluster_hub', 'label' => '🧠 Cluster actif', 'detail' => $similar_count . ' articles proches', 'points' => 8 );
                    $score += 8;
                }
            } catch ( \Exception $e ) { /* skip */ }
            catch ( \Error $e ) { /* skip */ }
        }

        // ── Schema markup (multi-source detection) ──
        $schema_meta = get_post_meta( $post_id, '_hts_schema_type', true );
        $has_schema  = false;
        $schema_label = '';

        // 1. HTS own schema meta
        if ( in_array( $schema_meta, array( 'Product', 'Service', 'Offer', 'LocalBusiness', 'ProfessionalService' ), true ) ) {
            $has_schema  = true;
            $schema_label = $schema_meta;
        }
        // 2. WooCommerce products get Product schema automatically
        if ( ! $has_schema && $is_woo_product ) {
            $has_schema  = true;
            $schema_label = 'Product (WooCommerce)';
        }
        // 3. Rank Math schema type
        if ( ! $has_schema ) {
            $rm_schema = get_post_meta( $post_id, 'rank_math_rich_snippet', true );
            if ( in_array( $rm_schema, array( 'product', 'service', 'local_business', 'course' ), true ) ) {
                $has_schema  = true;
                $schema_label = ucfirst( str_replace( '_', ' ', $rm_schema ) );
            }
        }
        // 4. Yoast/AIOSEO schema detection (check in content for JSON-LD patterns)
        if ( ! $has_schema && preg_match( '/"@type"\s*:\s*"(Product|Service|Offer|LocalBusiness|ProfessionalService)"/i', $content ) ) {
            $has_schema  = true;
            $schema_label = 'Schema (inline)';
        }

        if ( $has_schema ) {
            $signals[] = array( 'key' => 'schema', 'label' => '🏷️ Schema ' . $schema_label, 'detail' => 'Données structurées', 'points' => 10 );
            $score += 10;
        }

        // ── FAQ / HowTo schema (AEO 2026 — AI Overviews compatibility) ──
        $has_faq = get_post_meta( $post_id, 'rank_math_rich_snippet', true ) === 'faq'
            || preg_match( '/\[(yoast-faq|rank-math-faq|schema-faq|aioseo-faq)[^\]]*\]/i', $content )
            || preg_match( '/"@type"\s*:\s*"(FAQPage|HowTo)"/i', $content )
            || preg_match( '/class=["\'][^"\']*schema-faq[^"\']*["\']/i', $content );
        if ( $has_faq ) {
            $signals[] = array( 'key' => 'faq_schema', 'label' => '❓ FAQ / HowTo', 'detail' => 'Compatible AI Overviews', 'points' => 8 );
            $score += 8;
        }

        // ── Top-level page ──
        if ( $post->post_type === 'page' && (int) $post->post_parent === 0 && $score > 0 ) {
            $signals[] = array( 'key' => 'top_level', 'label' => '📍 Page principale', 'detail' => 'Niveau 1 du site', 'points' => 5 );
            $score += 5;
        }

        // Sort signals by points desc
        usort( $signals, function ( $a, $b ) { return $b['points'] <=> $a['points']; } );

        // ── SEO 2026: Individual products are child pages, not pillar pages ──
        // Cap product score so categories always rank higher in discovery
        if ( $is_woo_product ) {
            $score = min( $score, 55 );
        }

        return array(
            'id'              => $post_id,
            'type'            => 'post', // Distinguishes from 'product_cat' in categories
            'title'           => $post->post_title,
            'url'             => $url,
            'slug'            => $slug,
            'score'           => $score,
            'reasons'         => $signals,
            'gsc_clicks'      => $gsc_clicks,
            'gsc_pos'         => round( $gsc_position, 1 ),
            'gsc_impressions' => $gsc_impressions,
            'word_count'      => $word_count,
            'similar_count'   => $similar_count,
            'cluster_name'    => $cluster_name,
            'manual'          => (bool) get_post_meta( $post_id, '_hts_money_page_manual', true ),
            'dismissed'       => (bool) get_post_meta( $post_id, '_hts_money_page_dismissed', true ),
            'in_menu'         => $in_menu,
        );
    }

    /**
     * Score a WooCommerce category as a money page candidate.
     * In e-commerce SEO 2026, category pages are THE pillar pages.
     *
     * Signals: product count, category description length, GSC data, depth,
     * schema markup, content density on category page.
     *
     * @param \WP_Term              $term
     * @param \HTS_Embeddings|null  $emb
     * @return array|null
     */
    public function score_woo_category_candidate( $term, $emb = null ) {
        if ( ! $term || ! is_a( $term, 'WP_Term' ) ) return null;

        // ── Blacklist: segment-level match, same logic as posts ──
        $blacklist  = self::get_money_blacklist_patterns();
        $slug_parts = explode( '-', $term->slug );
        foreach ( $blacklist as $bl ) {
            if ( strpos( $bl, '-' ) !== false ) {
                if ( $term->slug === $bl || strpos( $term->slug, $bl . '-' ) === 0 || strpos( $term->slug, '-' . $bl ) !== false ) {
                    return null;
                }
            } else {
                if ( in_array( $bl, $slug_parts, true ) ) return null;
            }
        }

        // Skip 'uncategorized' equivalent
        if ( in_array( $term->slug, array( 'uncategorized', 'non-classe', 'sans-categorie' ), true ) ) return null;

        $url = get_term_link( $term );
        if ( is_wp_error( $url ) ) return null;

        $signals    = array();
        $score      = 0;
        $product_ct = (int) $term->count;

        // ── Base: it's a commerce category ──
        $signals[] = array( 'key' => 'woo_category', 'label' => '🛒 Catégorie produits', 'detail' => $product_ct . ' produit(s)', 'points' => 25 );
        $score += 25;

        // ── Product count bonus ──
        if ( $product_ct >= 10 ) {
            $signals[] = array( 'key' => 'woo_depth', 'label' => '📦 Catalogue riche', 'detail' => $product_ct . ' produits', 'points' => 15 );
            $score += 15;
        } elseif ( $product_ct >= 3 ) {
            $signals[] = array( 'key' => 'woo_depth', 'label' => '📦 Gamme', 'detail' => $product_ct . ' produits', 'points' => 8 );
            $score += 8;
        }

        // ── Category description (content on category page = SEO best practice 2026) ──
        $desc       = $term->description ?? '';
        $desc_words = self::mb_word_count( wp_strip_all_tags( $desc ) );
        if ( $desc_words >= 200 ) {
            $signals[] = array( 'key' => 'cat_content', 'label' => 'Contenu riche', 'detail' => $desc_words . ' mots de description', 'points' => 15 );
            $score += 15;
        } elseif ( $desc_words >= 50 ) {
            $signals[] = array( 'key' => 'cat_content', 'label' => 'Description', 'detail' => $desc_words . ' mots', 'points' => 5 );
            $score += 5;
        }

        // ── Top-level category (depth 0) = pillar page ──
        if ( (int) $term->parent === 0 ) {
            $signals[] = array( 'key' => 'top_level_cat', 'label' => '📍 Catégorie principale', 'detail' => 'Niveau 1 (page pilier)', 'points' => 15 );
            $score += 15;
        }

        // ── Sub-categories = topical depth ──
        $children = get_terms( array(
            'taxonomy' => 'product_cat', 'parent' => $term->term_id,
            'hide_empty' => true, 'fields' => 'count',
        ) );
        if ( ! is_wp_error( $children ) && (int) $children > 0 ) {
            $signals[] = array( 'key' => 'has_subcats', 'label' => '🗂️ Sous-catégories', 'detail' => (int) $children . ' sous-catégorie(s)', 'points' => 10 );
            $score += 10;
        }

        // ── GSC data (stored on term meta if available) ──
        $term_meta_clicks = (int) get_term_meta( $term->term_id, '_hts_gsc_clicks', true );
        $term_meta_pos    = (float) get_term_meta( $term->term_id, '_hts_gsc_position', true );
        if ( $term_meta_clicks > 5 && $term_meta_pos > 0 && $term_meta_pos <= 20 ) {
            $pts = min( 20, 5 + (int) ( $term_meta_clicks / 10 ) );
            $signals[] = array( 'key' => 'gsc_category', 'label' => 'Visible sur Google', 'detail' => 'Pos. ' . round( $term_meta_pos, 1 ) . ' · ' . $term_meta_clicks . ' clics', 'points' => $pts );
            $score += $pts;
        }

        usort( $signals, function ( $a, $b ) { return $b['points'] <=> $a['points']; } );

        return array(
            'id'              => $term->term_id, // Positive! Type field distinguishes
            'type'            => 'product_cat',
            'term_id'         => $term->term_id,
            'title'           => $term->name,
            'url'             => $url,
            'slug'            => $term->slug,
            'score'           => $score,
            'reasons'         => $signals,
            'gsc_clicks'      => $term_meta_clicks,
            'gsc_pos'         => round( $term_meta_pos, 1 ),
            'gsc_impressions' => 0,
            'word_count'      => $desc_words,
            'similar_count'   => 0,
            'cluster_name'    => '',
            'product_count'   => $product_ct,
            'manual'          => false,
            'dismissed'       => (bool) get_term_meta( $term->term_id, '_hts_money_page_dismissed', true ),
            'cocon_count'     => 0,
        );
    }

    /**
     * Discover money pages: scan site, score, cache results.
     *
     * @param bool $force  Force re-scan even if cache is fresh
     * @return array { pages: array[], timestamp: int, total_scanned: int }
     */
    public function discover_money_pages( $force = false ) {
        // ── Check cache (24h TTL) — per-language for multilingual sites ──
        $mp_cache_lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $mp_cache_lang = HTS_Language::get_current_lang();
            if ( $mp_cache_lang === 'all' || empty( $mp_cache_lang ) ) {
                $mp_cache_lang = substr( get_locale(), 0, 2 );
            }
        }
        $mp_cache_key = $mp_cache_lang ? 'hts_money_pages_discovery_' . $mp_cache_lang : 'hts_money_pages_discovery';

        if ( ! $force ) {
            $cached = get_option( $mp_cache_key, array() );
            // Fallback: try unsuffixed key for migration
            if ( empty( $cached['pages'] ) && $mp_cache_lang ) {
                $cached = get_option( 'hts_money_pages_discovery', array() );
            }
            if ( ! empty( $cached['pages'] ) && isset( $cached['timestamp'] ) && ( time() - $cached['timestamp'] ) < 86400 ) {
                // Refresh dismiss/manual from live meta
                foreach ( $cached['pages'] as &$p ) {
                    $ptype = $p['type'] ?? 'post';
                    if ( $ptype === 'product_cat' ) {
                        $p['dismissed'] = (bool) get_term_meta( $p['id'], '_hts_money_page_dismissed', true );
                        $p['manual']    = false;
                    } else {
                        $p['dismissed'] = (bool) get_post_meta( $p['id'], '_hts_money_page_dismissed', true );
                        $p['manual']    = (bool) get_post_meta( $p['id'], '_hts_money_page_manual', true );
                    }
                }
                unset( $p );
                return $cached;
            }
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 );

        // ── Scan published content ──
        $post_types = array( 'page', 'post' );
        if ( post_type_exists( 'product' ) ) $post_types[] = 'product';

        // Language detection for filtering
        $mp_lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $mp_lang = HTS_Language::get_current_lang();
            if ( $mp_lang === 'all' || empty( $mp_lang ) ) {
                $mp_lang = substr( get_locale(), 0, 2 );
            }
        }

        $mp_args = array(
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => 2000,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'suppress_filters' => false, // Allow Polylang to filter by language
            'update_post_term_cache' => false,
        );

        // Add Polylang language filter
        if ( $mp_lang && class_exists( 'HTS_Language' ) ) {
            $mp_args = HTS_Language::filter_query_args( $mp_args, $mp_lang );
        }

        $candidates = get_posts( $mp_args );

        // Post-filter by language (safety net for AJAX context)
        if ( $mp_lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $candidates = array_values( array_map( function( $p ) { return is_object( $p ) ? $p->ID : (int) $p; },
                HTS_Language::filter_posts_by_lang(
                    array_map( function( $id ) { return get_post( $id ); }, $candidates ),
                    $mp_lang
                )
            ) );
        }

        // ── Performance: batch-preload meta cache for all candidates ──
        // This does 1 DB query instead of 2000×8 individual get_post_meta() calls
        if ( ! empty( $candidates ) ) {
            update_meta_cache( 'post', $candidates );
            // Also prime the post object cache to avoid N individual get_post() queries
            _prime_post_caches( $candidates, true, false );
        }

        $cocon_data = self::load_cocon_data();
        $clusters   = $cocon_data['clusters'] ?? array();

        // ── Scan WordPress navigation menus — pages in menus are business pages by definition ──
        $menu_page_ids = array();
        $nav_menus = wp_get_nav_menus();
        foreach ( $nav_menus as $menu ) {
            $items = wp_get_nav_menu_items( $menu->term_id );
            if ( ! $items ) continue;
            foreach ( $items as $item ) {
                if ( $item->type === 'post_type' && (int) $item->object_id > 0 ) {
                    $menu_page_ids[ (int) $item->object_id ] = $menu->name;
                }
            }
        }
        // Filter menu pages by language
        if ( $mp_lang && function_exists( 'pll_get_post_language' ) ) {
            foreach ( $menu_page_ids as $mpid => $mname ) {
                $pl = pll_get_post_language( $mpid, 'slug' );
                if ( $pl && $pl !== $mp_lang ) unset( $menu_page_ids[ $mpid ] );
            }
        }

        $emb = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            try { $emb = new \HTS_Embeddings(); } catch ( \Exception $e ) { $emb = null; } catch ( \Error $e ) { $emb = null; }
        }

        $scored = array();
        foreach ( $candidates as $pid ) {
            try {
                $result = $this->score_money_page_candidate( $pid, null, $clusters, $emb, $menu_page_ids );
            } catch ( \Exception $e ) { continue; } catch ( \Error $e ) { continue; }
            if ( ! $result || ( $result['score'] ?? 0 ) <= 0 ) continue;
            $scored[] = $result;
        }

        // ── WooCommerce: Score category pages (product_cat) as pillar candidates ──
        // In e-commerce SEO 2026, category pages ARE the money pages (pillar pages).
        // Products and blog posts link UP to categories for topical authority.
        $woo_cat_count = 0;
        if ( taxonomy_exists( 'product_cat' ) ) {
            $woo_cats = get_terms( array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => true,
                'number'     => 100,
            ) );
            if ( ! is_wp_error( $woo_cats ) ) {
                $woo_cat_count = count( $woo_cats );
                foreach ( $woo_cats as $term ) {
                    try {
                        $result = $this->score_woo_category_candidate( $term, $emb );
                    } catch ( \Exception $e ) { continue; } catch ( \Error $e ) { continue; }
                    if ( ! $result || ( $result['score'] ?? 0 ) <= 0 ) continue;
                    $scored[] = $result;
                }
            }
        }

        // ── Include manually flagged pages not already scored ──
        $manual_ids = get_posts( array(
            'post_type' => $post_types, 'post_status' => 'publish',
            'meta_key' => '_hts_money_page_manual', 'meta_value' => '1',
            'posts_per_page' => 50, 'fields' => 'ids',
        ) );
        // Only post-type IDs to avoid collision with category term IDs
        $scored_post_ids = array_column( array_filter( $scored, function ( $p ) {
            return ( $p['type'] ?? 'post' ) === 'post';
        } ), 'id' );
        foreach ( $manual_ids as $mid ) {
            if ( in_array( $mid, $scored_post_ids ) ) continue;
            try {
                $result = $this->score_money_page_candidate( $mid, null, $clusters, $emb );
            } catch ( \Exception $e ) { continue; } catch ( \Error $e ) { continue; }
            if ( $result && ( $result['score'] ?? 0 ) > -1 ) {
                $result['manual'] = true;
                $result['score']  = max( $result['score'], 30 ); // Manual = always above threshold
                $scored[] = $result;
            }
        }

        // ── Include menu pages not already in scored list (may have been blacklisted) ──
        $scored_post_ids_final = array_column( array_filter( $scored, function ( $p ) {
            return ( $p['type'] ?? 'post' ) === 'post';
        } ), 'id' );
        foreach ( $menu_page_ids as $mpid => $mname ) {
            if ( in_array( $mpid, $scored_post_ids_final ) ) continue;
            $mp_post = get_post( $mpid );
            if ( ! $mp_post || $mp_post->post_status !== 'publish' ) continue;
            $scored[] = array(
                'id'        => $mpid,
                'type'      => 'post',
                'title'     => $mp_post->post_title,
                'url'       => get_permalink( $mpid ),
                'slug'      => $mp_post->post_name,
                'score'     => 25,
                'reasons'   => array( array( 'key' => 'in_menu', 'label' => 'Menu principal', 'detail' => 'Menu « ' . $mname . ' »', 'points' => 25 ) ),
                'in_menu'   => true,
                'manual'    => false,
                'dismissed' => (bool) get_post_meta( $mpid, '_hts_money_page_dismissed', true ),
            );
        }

        // ── Filter out obvious non-money pages (utility/legal/navigation) ──
        $exclude_slugs = array(
            'faq', 'home', 'accueil', 'blog', 'articles', 'nos-articles',
            'code-de-conduite', 'mentions-legales', 'privacy-policy',
            'politique-de-confidentialite', 'cgv', 'cgu', 'contact',
            'a-propos', 'about', 'qui-sommes-nous', 'equipe', 'sitemap',
            'plan-du-site', 'cookie', 'rgpd', 'newsletter', 'login',
            'register', 'mon-compte', 'my-account', 'panier', 'cart',
            'checkout', 'commande',
        );
        $exclude_title_starts = array(
            'FAQ', 'Code de conduite', 'Mentions légales',
            'Politique de confidentialité', 'CGV', 'CGU',
        );
        $scored = array_values( array_filter( $scored, function( $p ) use ( $exclude_slugs, $exclude_title_starts ) {
            // Never filter manual pages
            if ( ! empty( $p['manual'] ) ) return true;
            $slug = $p['slug'] ?? '';
            if ( ! $slug && ! empty( $p['id'] ) && ( $p['type'] ?? 'post' ) !== 'product_cat' ) {
                $slug = get_post_field( 'post_name', $p['id'] );
            }
            if ( $slug && in_array( $slug, $exclude_slugs, true ) ) return false;
            $title = $p['title'] ?? '';
            foreach ( $exclude_title_starts as $prefix ) {
                if ( mb_stripos( $title, $prefix ) === 0 ) return false;
            }
            return true;
        } ) );

        usort( $scored, function ( $a, $b ) { return $b['score'] <=> $a['score']; } );

        // ── Merge with existing data: preserve manual adds + dismissed states ──
        // Re-detect must ADD new pages, not erase ones the client already configured
        $existing = get_option( $mp_cache_key, array() );
        if ( ! empty( $existing['pages'] ) ) {
            $new_ids = array_column( $scored, 'id' );
            foreach ( $existing['pages'] as $ep ) {
                $ep_id = (int) ( $ep['id'] ?? 0 );
                if ( ! $ep_id ) continue;
                // Preserve manual pages not in new scan
                if ( ! empty( $ep['manual'] ) && ! in_array( $ep_id, $new_ids ) ) {
                    $scored[] = $ep;
                    continue;
                }
                // Preserve dismissed state on re-detected pages
                if ( ! empty( $ep['dismissed'] ) && in_array( $ep_id, $new_ids ) ) {
                    foreach ( $scored as &$sp ) {
                        if ( (int) $sp['id'] === $ep_id ) {
                            $sp['dismissed'] = true;
                            break;
                        }
                    }
                    unset( $sp );
                }
            }
            // Re-sort after merge
            usort( $scored, function ( $a, $b ) { return ( $b['score'] ?? 0 ) <=> ( $a['score'] ?? 0 ); } );
        }

        $data = array(
            'pages'         => $scored,
            'timestamp'     => time(),
            'total_scanned' => count( $candidates ) + $woo_cat_count,
        );

        update_option( $mp_cache_key, $data, false );
        // Also save to unsuffixed key for backward compatibility
        if ( $mp_cache_key !== 'hts_money_pages_discovery' ) {
            update_option( 'hts_money_pages_discovery', $data, false );
        }

        // Sync _hts_money_page meta for qualifying pages (posts only, not terms)
        $threshold  = 30;
        $scored_post_ids = array_column( array_filter( $scored, function ( $p ) {
            return ( $p['type'] ?? 'post' ) === 'post';
        } ), 'id' );
        foreach ( $scored as $p ) {
            if ( ( $p['type'] ?? 'post' ) !== 'post' ) continue; // Skip taxonomy terms
            if ( $p['score'] >= $threshold && empty( $p['dismissed'] ) ) {
                update_post_meta( $p['id'], '_hts_money_page', '1' );
                $top_key = ! empty( $p['reasons'] ) ? $p['reasons'][0]['key'] : 'scored';
                update_post_meta( $p['id'], '_hts_money_page_reason', $top_key );
            } else {
                // Page dropped below threshold or is dismissed → remove flag
                // (unless manually flagged — manual pages keep their flag)
                if ( empty( $p['manual'] ) ) {
                    delete_post_meta( $p['id'], '_hts_money_page' );
                }
            }
        }

        // Also clean pages that used to have the flag but weren't even scored this round
        $old_flagged = get_posts( array(
            'post_type' => $post_types, 'post_status' => 'any',
            'meta_key' => '_hts_money_page', 'meta_value' => '1',
            'posts_per_page' => 200, 'fields' => 'ids',
        ) );
        foreach ( $old_flagged as $of_id ) {
            if ( ! in_array( $of_id, $scored_post_ids ) ) {
                $is_manual = (bool) get_post_meta( $of_id, '_hts_money_page_manual', true );
                if ( ! $is_manual ) {
                    delete_post_meta( $of_id, '_hts_money_page' );
                }
            }
        }

        $active = count( array_filter( $scored, function ( $p ) use ( $threshold ) {
            return $p['score'] >= $threshold && empty( $p['dismissed'] );
        } ) );

        hts_add_log( sprintf( 'Détection : %d pages business sur %d analysées (seuil %d)',
            $active, count( $candidates ) + $woo_cat_count, $threshold
        ), 'success', 'cocon-commander' );

        return $data;
    }

    /* ═══ AJAX HANDLERS — Discovery ═══ */

    public function ajax_discover_money_pages() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );

        // Auto-detect: if server has short timeout, suggest batch mode
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time <= 60 && class_exists( 'HTS_Job_Runner' ) ) {
            wp_send_json_error( array(
                'message'   => 'use_batch',
                'batch_init' => 'hts_discover_money_init',
                'batch_step' => 'hts_discover_money_step',
            ) );
        }

        // Legacy mode (server OK)
        $data  = $this->discover_money_pages( true );
        $count = count( array_filter( $data['pages'] ?? array(), function ( $p ) {
            return $p['score'] >= 30 && empty( $p['dismissed'] );
        } ) );
        wp_send_json_success( array( 'count' => $count, 'total_scanned' => $data['total_scanned'] ?? 0 ) );
    }

    /**
     * AJAX: Batch discover money pages — init.
     */
    public function ajax_discover_money_init() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_types = array( 'page', 'post' );
        if ( post_type_exists( 'product' ) ) $post_types[] = 'product';

        $candidates = get_posts( array(
            'post_type' => $post_types, 'post_status' => 'publish',
            'posts_per_page' => 2000, 'fields' => 'ids', 'no_found_rows' => true,
            'suppress_filters' => false,
        ) );

        if ( ! empty( $candidates ) ) {
            update_meta_cache( 'post', $candidates );
        }

        $job = HTS_Job_Runner::create( 'money_discover', array(
            'candidates' => $candidates,
        ), count( $candidates ) );

        wp_send_json_success( array( 'job_id' => $job['job_id'], 'total' => count( $candidates ) ) );
    }

    /**
     * AJAX: Batch discover money pages — step.
     */
    public function ajax_discover_money_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        $job = HTS_Job_Runner::load( $job_id );
        if ( ! $job ) wp_send_json_error( array( 'message' => 'Job introuvable ou expiré' ) );

        $start      = microtime( true );
        $candidates = $job['params']['candidates'] ?? array();
        $scored     = $job['result']['scored'] ?? array();
        $processed  = (int) $job['processed'];

        $cocon_data = self::load_cocon_data();
        $clusters   = $cocon_data['clusters'] ?? array();
        $emb        = class_exists( 'HTS_Embeddings' ) ? new \HTS_Embeddings() : null;
        $menu_ids   = array();

        // Process batch
        $batch_size = 30;
        $batch = array_slice( $candidates, $processed, $batch_size );

        foreach ( $batch as $pid ) {
            if ( ! HTS_Job_Runner::has_time( $start ) ) break;
            try {
                $result = $this->score_money_page_candidate( $pid, null, $clusters, $emb, $menu_ids );
            } catch ( \Exception $e ) { $processed++; continue; } catch ( \Error $e ) { $processed++; continue; }
            if ( $result && ( $result['score'] ?? 0 ) > 0 ) {
                $scored[] = $result;
            }
            $processed++;
        }

        $total = count( $candidates );
        $done  = ( $processed >= $total );

        HTS_Job_Runner::update( $job_id, array(
            'processed' => $processed,
            'step'      => $job['step'] + 1,
            'result'    => array( 'scored' => $scored ),
        ) );

        if ( $done ) {
            // Finalize: sort, merge, save
            usort( $scored, function( $a, $b ) { return $b['score'] <=> $a['score']; } );

            // Apply faux positifs filter
            $exclude_slugs = array( 'faq','home','accueil','blog','articles','nos-articles','code-de-conduite','mentions-legales','privacy-policy','politique-de-confidentialite','cgv','cgu','contact','a-propos','about','qui-sommes-nous','equipe','sitemap','plan-du-site','cookie','rgpd','newsletter','login','register','mon-compte','my-account','panier','cart','checkout','commande' );
            $exclude_titles = array( 'FAQ','Code de conduite','Mentions légales','Politique de confidentialité','CGV','CGU' );
            $scored = array_values( array_filter( $scored, function( $p ) use ( $exclude_slugs, $exclude_titles ) {
                if ( ! empty( $p['manual'] ) ) return true;
                $slug = $p['slug'] ?? get_post_field( 'post_name', $p['id'] );
                if ( $slug && in_array( $slug, $exclude_slugs, true ) ) return false;
                $title = $p['title'] ?? '';
                foreach ( $exclude_titles as $prefix ) {
                    if ( mb_stripos( $title, $prefix ) === 0 ) return false;
                }
                return true;
            } ) );

            // Save discovery cache
            $mp_cache_key = 'hts_money_pages_discovery';
            $discovery = array( 'pages' => $scored, 'timestamp' => time(), 'total_scanned' => $total );
            update_option( $mp_cache_key, $discovery, false );

            $active = count( array_filter( $scored, function( $p ) { return $p['score'] >= 30 && empty( $p['dismissed'] ); } ) );

            HTS_Job_Runner::complete( $job_id, array( 'count' => $active, 'total_scanned' => $total ) );
            wp_send_json_success( array(
                'status' => 'done', 'step' => $job['step'] + 1, 'total' => $total,
                'processed' => $processed, 'progress' => 100,
                'count' => $active, 'total_scanned' => $total,
            ) );
        }

        wp_send_json_success( array(
            'status'    => 'running',
            'step'      => $job['step'] + 1,
            'total'     => $total,
            'processed' => $processed,
            'progress'  => HTS_Job_Runner::progress_pct( $job ),
            'message'   => 'Analyse des pages... ' . $processed . '/' . $total,
        ) );
    }

    /**
     * AJAX: Reset all cocon data — clusters + money pages discovery.
     * Clears NLP clusters, money page detection, and related metas.
     * Does NOT touch generated articles, drafts, or cocon plans.
     */
    public function ajax_reset_cocon_data() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );

        try {
            // ── Delete plans on SaaS before local cleanup ──
            $plans = $this->get_plans();
            if ( ! empty( $plans ) ) {
                foreach ( $plans as $cid => $plan ) {
                    // Skip local-only plans (tmp_*)
                    if ( strpos( $cid, 'tmp_' ) === 0 ) continue;
                    // Best-effort: delete on SaaS (ignore errors — may 404 if already gone)
                    $this->cocon_api_call( 'POST', 'delete-plan', array( 'cocon_id' => $cid ) );
                }
                // Clear local plans
                delete_option( self::PLANS_OPTION );
                delete_transient( 'hts_cocon_plans_cache' );
                hts_add_log( 'Reset: ' . count( $plans ) . ' plans supprimés (local + SaaS)', 'info', 'cocon-commander' );
            }

            // ── Delete NLP cluster data ──
            delete_option( 'hts_cocon_data' );
            delete_option( 'hts_cocon_last_analysis' );
            delete_option( 'hts_cocon_missing_clusters' );
            delete_option( 'hts_cocon_page_decisions' );

            // Current language variant (always delete even if is_multilingual check fails)
            if ( class_exists( 'HTS_Language' ) ) {
                $cur = HTS_Language::get_current_lang();
                if ( $cur ) delete_option( 'hts_cocon_data_' . $cur );
            }

            // All multilingual variants
            if ( class_exists( 'HTS_Language' ) && method_exists( 'HTS_Language', 'is_multilingual' ) && HTS_Language::is_multilingual() ) {
                foreach ( array_keys( HTS_Language::get_available_languages() ) as $l ) {
                    delete_option( 'hts_cocon_data_' . $l );
                }
            }

            // ── Delete money pages discovery cache ──
            delete_option( 'hts_money_pages_discovery' );

            // ── Clean money page metas on posts ──
            global $wpdb;
            $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ('_hts_money_page','_hts_money_page_manual','_hts_money_page_dismissed','_hts_money_page_reason','_hts_money_target','_hts_page_role','_hts_cross_cocon_proposals')" );
            $wpdb->query( "DELETE FROM {$wpdb->termmeta} WHERE meta_key = '_hts_money_page_dismissed'" );

            // ── Purge Inbox: ALL linking/maillage actions (any status) ──
            $wf_table = $wpdb->prefix . 'hts_workflow_actions';
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wf_table ) ) === $wf_table ) {
                // Delete ALL linking agent actions (pending, done, failed, etc.)
                $del_linking = (int) $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$wf_table} WHERE agent = %s",
                    'linking'
                ) );
                // Also delete any cocon-sourced actions from other agents
                $del_cocon = (int) $wpdb->query(
                    "DELETE FROM {$wf_table} WHERE data LIKE '%\"source_cocon\"%'"
                );
                // Clean orphan backup/impact metas from deleted actions
                $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_hts_action_backup_%' OR meta_key LIKE '_hts_impact_%'" );
            }

            hts_add_log( 'Reset complet : clusters, pages business et metas supprimés', 'warning', 'cocon-commander' );

            // Flag: clusters should be hidden until next maillage
            update_option( 'hts_cocon_awaiting_maillage', '1', false );

            wp_send_json_success( array( 'reset' => true ) );
        } catch ( \Exception $e ) {
            wp_send_json_error( 'Erreur : ' . $e->getMessage() );
        } catch ( \Error $e ) {
            wp_send_json_error( 'Erreur fatale : ' . $e->getMessage() );
        }
    }

    public function ajax_dismiss_money_page() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        $id   = absint( $_POST['post_id'] ?? 0 );
        $type = sanitize_text_field( $_POST['mp_type'] ?? 'post' );
        if ( ! $id ) wp_send_json_error( 'ID requis.' );
        if ( $type === 'product_cat' ) {
            update_term_meta( $id, '_hts_money_page_dismissed', '1' );
            $title = '';
            $term  = get_term( $id, 'product_cat' );
            if ( $term && ! is_wp_error( $term ) ) $title = $term->name;
            hts_add_log( 'Catégorie business masquée : ' . $title, 'info', 'cocon-commander' );
        } else {
            update_post_meta( $id, '_hts_money_page_dismissed', '1' );
            delete_post_meta( $id, '_hts_money_page' );
            // Clean orphan _hts_money_target: articles assigned to this dismissed page
            // must be freed so they can be reassigned to other money pages
            global $wpdb;
            $orphans = $wpdb->get_col( $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_hts_money_target' AND meta_value = %s",
                (string) $id
            ) );
            foreach ( $orphans as $oid ) {
                delete_post_meta( (int) $oid, '_hts_money_target' );
                delete_post_meta( (int) $oid, '_hts_page_role' );
            }
            hts_add_log( 'Page business masquée : ' . get_the_title( $id ) . ( count( $orphans ) > 0 ? ' · ' . count( $orphans ) . ' article(s) libéré(s)' : '' ), 'info', 'cocon-commander' );
        }
        wp_send_json_success( array( 'dismissed' => $id ) );
    }

    public function ajax_dismiss_suggestion() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $name = sanitize_text_field( $_POST['cluster_name'] ?? '' );
        if ( empty( $name ) ) wp_send_json_error();
        $dismissed = get_option( 'hts_cocon_dismissed_suggestions', array() );
        $dismissed[ $name ] = time();
        update_option( 'hts_cocon_dismissed_suggestions', $dismissed, false );
        wp_send_json_success();
    }

    public function ajax_accept_suggestion() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $name = sanitize_text_field( $_POST['cluster_name'] ?? '' );
        if ( empty( $name ) ) wp_send_json_error();

        $lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $lang = HTS_Language::get_current_lang();
        }
        $opt_key = ( $lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang : 'hts_cocon_data';
        $data = get_option( $opt_key, array() );

        if ( isset( $data['clusters'][ $name ] ) ) {
            $data['clusters'][ $name ]['suggested'] = false;
            $pillar_id = $data['clusters'][ $name ]['pillar_id'] ?? 0;
            if ( $pillar_id ) {
                update_post_meta( $pillar_id, '_hts_money_page_manual', '1' );
            }
            update_option( $opt_key, $data, false );
            wp_cache_delete( $opt_key, 'options' );
            wp_send_json_success( array( 'message' => 'Groupe créé !' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Suggestion introuvable.' ) );
        }
    }

    public function ajax_restore_money_page() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        $id   = absint( $_POST['post_id'] ?? 0 );
        $type = sanitize_text_field( $_POST['mp_type'] ?? 'post' );
        if ( ! $id ) wp_send_json_error( 'ID requis.' );
        if ( $type === 'product_cat' ) {
            delete_term_meta( $id, '_hts_money_page_dismissed' );
            $title = '';
            $term  = get_term( $id, 'product_cat' );
            if ( $term && ! is_wp_error( $term ) ) $title = $term->name;
            hts_add_log( 'Catégorie business restaurée : ' . $title, 'info', 'cocon-commander' );
        } else {
            delete_post_meta( $id, '_hts_money_page_dismissed' );
            update_post_meta( $id, '_hts_money_page', '1' );
            hts_add_log( 'Page business restaurée : ' . get_the_title( $id ), 'info', 'cocon-commander' );
        }
        wp_send_json_success( array( 'restored' => $id ) );
    }

    /**
     * AJAX: Search published pages/posts for manual money page addition.
     * Returns up to 10 matches by title.
     */
    public function ajax_search_pages_for_money() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );

        $q = sanitize_text_field( $_POST['q'] ?? '' );
        if ( strlen( $q ) < 2 ) wp_send_json_error( 'Saisissez au moins 2 caractères.' );

        $post_types = array( 'page', 'post' );
        if ( post_type_exists( 'product' ) ) $post_types[] = 'product';

        // ── URL mode: resolve URL → post_id directly ──
        if ( preg_match( '#^https?://#i', $q ) ) {
            $url = esc_url_raw( trim( $q, " \t\n\r/" ) . '/' );
            $pid = hts_url_to_postid( $url );
            // Also try without trailing slash
            if ( ! $pid ) $pid = hts_url_to_postid( rtrim( $url, '/' ) );
            // Also try the raw input as-is
            if ( ! $pid ) $pid = hts_url_to_postid( trim( $q ) );

            if ( $pid ) {
                $p = get_post( $pid );
                if ( $p && $p->post_status === 'publish' && in_array( $p->post_type, $post_types, true ) ) {
                    $is_already = (bool) get_post_meta( $pid, '_hts_money_page', true );
                    wp_send_json_success( array( 'pages' => array( array(
                        'id'      => $pid,
                        'title'   => $p->post_title,
                        'type'    => $p->post_type,
                        'url'     => get_permalink( $pid ),
                        'slug'    => $p->post_name,
                        'already' => $is_already,
                    ) ) ) );
                }
            }
            // URL didn't resolve — fall through to title/slug search with the slug extracted from URL
            $path = wp_parse_url( $q, PHP_URL_PATH );
            if ( $path ) {
                $segments = array_filter( explode( '/', $path ) );
                $q = end( $segments ) ?: $q; // Use last URL segment as search term
            }
        }

        global $wpdb;
        $like = '%' . $wpdb->esc_like( $q ) . '%';

        // Build safe IN clause with individual placeholders
        $type_placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
        $query_args = $post_types;       // First: post_types for IN()
        $query_args[] = $like;           // Then: LIKE for post_title
        $query_args[] = $like;           // Then: LIKE for post_name

        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_type, post_name
             FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ($type_placeholders)
               AND ( post_title LIKE %s OR post_name LIKE %s )
             ORDER BY post_title ASC
             LIMIT 10",
            ...$query_args
        ) );

        // Check which pages are already in money list (all types, not just 'post')
        $existing_ids = array();
        $discovery = get_option( 'hts_money_pages_discovery', array() );
        if ( ! empty( $discovery['pages'] ) ) {
            foreach ( $discovery['pages'] as $mp ) {
                $existing_ids[] = (int) $mp['id'];
            }
        }

        $pages = array();
        foreach ( $results as $r ) {
            $pid = (int) $r->ID;
            $is_already = in_array( $pid, $existing_ids ) || (bool) get_post_meta( $pid, '_hts_money_page', true );
            $pages[] = array(
                'id'       => $pid,
                'title'    => $r->post_title,
                'type'     => $r->post_type,
                'url'      => get_permalink( $pid ),
                'slug'     => $r->post_name,
                'already'  => $is_already,
            );
        }

        wp_send_json_success( array( 'pages' => $pages ) );
    }

    /**
     * AJAX: Add a page as manual money page.
     * Sets _hts_money_page=1 and _hts_money_page_manual=1, then refreshes discovery cache.
     */
    public function ajax_add_manual_money_page() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );

        $id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID requis.' );

        $post = get_post( $id );
        if ( ! $post || $post->post_status !== 'publish' ) wp_send_json_error( 'Page introuvable ou non publiée.' );

        update_post_meta( $id, '_hts_money_page', '1' );
        update_post_meta( $id, '_hts_money_page_manual', '1' );
        delete_post_meta( $id, '_hts_money_page_dismissed' );

        // Inject into discovery cache (language-aware) so it shows immediately
        $_add_lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() && function_exists( 'pll_get_post_language' ) ) {
            $_add_lang = pll_get_post_language( $id, 'slug' );
        }
        $_add_key = $_add_lang ? 'hts_money_pages_discovery_' . $_add_lang : 'hts_money_pages_discovery';
        $discovery = get_option( $_add_key, array() );
        if ( empty( $discovery['pages'] ) ) {
            $discovery['pages'] = array();
            $discovery['timestamp'] = time();
        }

        // Check if already in cache
        $found = false;
        foreach ( $discovery['pages'] as &$mp ) {
            if ( (int) ( $mp['id'] ?? 0 ) === $id && ( $mp['type'] ?? 'post' ) === $post->post_type ) {
                $mp['manual']    = true;
                $mp['dismissed'] = false;
                $mp['score']     = max( $mp['score'] ?? 0, 30 );
                $found           = true;
                break;
            }
        }
        unset( $mp );
        if ( ! $found ) {
            $discovery['pages'][] = array(
                'id'       => $id,
                'title'    => $post->post_title,
                'url'      => get_permalink( $id ),
                'type'     => $post->post_type,
                'score'    => 30,
                'reasons'  => array( array( 'key' => 'manual', 'label' => 'Ajout manuel', 'detail' => 'Ajouté manuellement', 'points' => 30 ) ),
                'manual'   => true,
                'dismissed' => false,
            );
        }
        // Save on language-specific key + generic fallback
        update_option( $_add_key, $discovery, false );
        if ( $_add_key !== 'hts_money_pages_discovery' ) {
            update_option( 'hts_money_pages_discovery', $discovery, false );
        }

        hts_add_log( 'Page business ajoutée manuellement : ' . $post->post_title, 'success', 'cocon-commander' );
        wp_send_json_success( array(
            'id'    => $id,
            'title' => $post->post_title,
            'url'   => get_permalink( $id ),
        ) );
    }

    /* ═══ AJAX HANDLERS — Money Cocons ═══ */

    public function ajax_build_money_cocon() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        $id = absint( $_POST['money_page_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID requis.' );
        $r = $this->build_cocon_from_money_page( $id );
        $r ? wp_send_json_success( $r ) : wp_send_json_error( 'Page introuvable.' );
    }

    public function ajax_confirm_money_cocon() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        $mpid     = absint( $_POST['money_page_id'] ?? 0 );
        $page_ids = array_map( 'absint', (array) ( $_POST['page_ids'] ?? array() ) );
        $roles    = (array) ( $_POST['roles'] ?? array() );
        if ( ! $mpid ) wp_send_json_error( 'ID requis.' );
        if ( empty( $page_ids ) ) wp_send_json_error( 'Sélectionnez au moins une page.' );

        // Clean old assignments
        $old = get_posts( array( 'post_type' => array( 'post', 'page' ), 'meta_key' => '_hts_money_target', 'meta_value' => (string) $mpid, 'posts_per_page' => 200, 'fields' => 'ids' ) );
        foreach ( $old as $oid ) { if ( ! in_array( $oid, $page_ids ) ) { delete_post_meta( $oid, '_hts_money_target' ); delete_post_meta( $oid, '_hts_page_role' ); } }

        $confirmed = 0;
        foreach ( $page_ids as $pid ) {
            if ( $pid === $mpid ) continue;
            update_post_meta( $pid, '_hts_money_target', (string) $mpid );
            $role = sanitize_text_field( $roles[ $pid ] ?? '' );
            if ( ! in_array( $role, array( 'support', 'info' ), true ) ) {
                $role = in_array( self::classify_intent( get_the_title( $pid ) ), array( 'transactional', 'commercial' ), true ) ? 'support' : 'info';
            }
            update_post_meta( $pid, '_hts_page_role', $role );
            $confirmed++;
        }
        update_post_meta( $mpid, '_hts_page_role', 'money' );
        wp_send_json_success( array( 'confirmed' => $confirmed, 'money_page_id' => $mpid ) );
    }

    public function ajax_apply_money_maillage() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 120 );
        $id = absint( $_POST['money_page_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID requis.' );
        $r = $this->apply_money_cocon_maillage( $id, array( 'dry_run' => ! empty( $_POST['dry_run'] ) ) );
        if ( ! isset( $r['error'] ) ) delete_option( 'hts_cocon_awaiting_maillage' );
        isset( $r['error'] ) ? wp_send_json_error( $r['error'] ) : wp_send_json_success( $r );
    }

    public function ajax_auto_money_cocons() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );

        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time <= 60 && class_exists( 'HTS_Job_Runner' ) ) {
            wp_send_json_error( array( 'message' => 'use_batch', 'batch_init' => 'hts_auto_cocons_init', 'batch_step' => 'hts_auto_cocons_step' ) );
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 );

        hts_debug_log( '[fix7] ajax_auto_money_cocons: START' );
        $r = $this->auto_build_all_money_cocons();
        hts_debug_log( '[fix7] ajax_auto_money_cocons: RESULT = ' . wp_json_encode( array(
            'error' => $r['error'] ?? null,
            'money_pages_processed' => $r['money_pages_processed'] ?? 0,
            'total_cocon_pages' => $r['total_cocon_pages'] ?? 0,
            'total_links_added' => $r['total_links_added'] ?? 0,
            'total_budget_full' => $r['total_budget_full'] ?? 0,
            'total_already_linked' => $r['total_already_linked'] ?? 0,
        ) ) );

        isset( $r['error'] ) ? wp_send_json_error( $r['error'] ) : wp_send_json_success( $r );
    }

    /* ── Batch: auto cocons ── */

    public function ajax_auto_cocons_init() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $cocon_data = self::load_cocon_data();
        $clusters = $cocon_data['clusters'] ?? array();
        $ids = array();
        foreach ( $clusters as $cl ) {
            if ( ! empty( $cl['pillar_id'] ) && empty( $cl['suggested'] ) ) $ids[] = (int) $cl['pillar_id'];
        }
        if ( empty( $ids ) ) wp_send_json_error( array( 'message' => 'Aucun cluster actif' ) );
        $job = HTS_Job_Runner::create( 'auto_cocons', array( 'pillar_ids' => $ids ), count( $ids ) );
        wp_send_json_success( array( 'job_id' => $job['job_id'], 'total' => count( $ids ) ) );
    }

    public function ajax_auto_cocons_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        $job = HTS_Job_Runner::load( $job_id );
        if ( ! $job ) wp_send_json_error( array( 'message' => 'Job introuvable' ) );
        $start = microtime( true );
        $ids = $job['params']['pillar_ids'] ?? array();
        $processed = (int) $job['processed'];
        $results = $job['result']['built'] ?? array();
        if ( $processed < count( $ids ) && HTS_Job_Runner::has_time( $start ) ) {
            $pid = $ids[ $processed ];
            try {
                $r = $this->build_cocon_from_money_page( $pid );
                $results[] = array( 'id' => $pid, 'ok' => ! isset( $r['error'] ) );
            } catch ( \Throwable $e ) {
                $results[] = array( 'id' => $pid, 'ok' => false, 'error' => $e->getMessage() );
            }
            $processed++;
        }
        $done = ( $processed >= count( $ids ) );
        if ( $done ) { HTS_Job_Runner::complete( $job_id, array( 'built' => $results ) ); }
        else { HTS_Job_Runner::update( $job_id, array( 'processed' => $processed, 'step' => $job['step'] + 1, 'result' => array( 'built' => $results ) ) ); }
        wp_send_json_success( array( 'status' => $done ? 'done' : 'running', 'total' => count( $ids ), 'processed' => $processed, 'progress' => count( $ids ) > 0 ? round( $processed / count( $ids ) * 100 ) : 100, 'message' => $done ? 'Maillage terminé !' : 'Cocon ' . $processed . '/' . count( $ids ) . '...' ) );
    }

    /* ── Batch: cocon rescan ── */

    public function ajax_cocon_rescan_init() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        if ( empty( $cocon_id ) ) wp_send_json_error( array( 'message' => 'cocon_id manquant' ) );
        $plans = get_option( 'hts_cocon_plans', array() );
        $target_cocons = ( $cocon_id === 'all' ) ? array_keys( $plans ) : ( isset( $plans[ $cocon_id ] ) ? array( $cocon_id ) : array() );
        if ( empty( $target_cocons ) ) wp_send_json_error( array( 'message' => 'Cocon introuvable' ) );
        $article_ids = array();
        foreach ( $target_cocons as $cid ) {
            $arts = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'meta_key' => '_hts_cocon_id', 'meta_value' => $cid, 'posts_per_page' => 100, 'fields' => 'ids' ) );
            foreach ( $arts as $a ) $article_ids[] = array( 'pid' => (int) $a, 'cid' => $cid );
        }
        $job = HTS_Job_Runner::create( 'cocon_rescan', array( 'cocon_id' => $cocon_id, 'articles' => $article_ids ), count( $article_ids ) );
        wp_send_json_success( array( 'job_id' => $job['job_id'], 'total' => count( $article_ids ) ) );
    }

    public function ajax_cocon_rescan_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        $job = HTS_Job_Runner::load( $job_id );
        if ( ! $job ) wp_send_json_error( array( 'message' => 'Job introuvable' ) );
        $start = microtime( true );
        $articles = $job['params']['articles'] ?? array();
        $processed = (int) $job['processed'];
        $links_added = (int) ( $job['result']['links_added'] ?? 0 );
        $batch = array_slice( $articles, $processed, 10 );
        foreach ( $batch as $art ) {
            if ( ! HTS_Job_Runner::has_time( $start ) ) break;
            try {
                $r = $this->auto_link_siblings( (int) $art['pid'], $art['cid'] );
                $links_added += (int) ( $r['links_added'] ?? 0 );
            } catch ( \Throwable $e ) { /* skip */ }
            $processed++;
        }
        $done = ( $processed >= count( $articles ) );
        if ( $done ) { HTS_Job_Runner::complete( $job_id, array( 'links_added' => $links_added, 'articles' => $processed ) ); }
        else { HTS_Job_Runner::update( $job_id, array( 'processed' => $processed, 'step' => $job['step'] + 1, 'result' => array( 'links_added' => $links_added ) ) ); }
        wp_send_json_success( array( 'status' => $done ? 'done' : 'running', 'total' => count( $articles ), 'processed' => $processed, 'progress' => count( $articles ) > 0 ? round( $processed / count( $articles ) * 100 ) : 100, 'message' => $done ? $links_added . ' liens ajoutés !' : 'Scan... ' . $processed . '/' . count( $articles ) ) );
    }

    /**
     * AJAX handler: link a single cluster progressively.
     *
     * Called cluster-by-cluster from the front-end to avoid timeouts
     * on large sites with many clusters.
     *
     * @since 2.6.0
     */
    public function ajax_link_single_cluster() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 60 );

        $cluster_name = sanitize_text_field( $_POST['cluster'] ?? '' );
        $lang = sanitize_text_field( $_POST['lang'] ?? '' );

        if ( empty( $cluster_name ) ) {
            wp_send_json_error( 'Nom de cluster requis.' );
        }

        // check_only mode — retourne juste le count pending pour ce cluster
        $check_only = ! empty( $_POST['check_only'] );
        if ( $check_only ) {
            global $wpdb;
            $table = $wpdb->prefix . 'hts_workflow_actions';
            $pending = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE agent = 'linking' AND type = 'add_internal_links' AND status = 'pending' AND data LIKE %s",
                '%' . $wpdb->esc_like( '"cluster":"' . $cluster_name . '"' ) . '%'
            ) );
            // Check cache "well_linked" pour éviter le scan complet de 60s
            $wl_cache = get_transient( 'hts_wl_' . md5( $cluster_name ) );
            wp_send_json_success( array(
                'existing_pending' => $pending,
                'cluster'          => $cluster_name,
                'well_linked'      => ( $pending === 0 && $wl_cache ),
                'done'             => $wl_cache ? (int) $wl_cache : 0,
            ) );
        }

        if ( ! class_exists( 'HTS_Cocon' ) || ! class_exists( 'HTS_Workflow_Engine' ) ) {
            wp_send_json_error( 'Modules requis non disponibles.' );
        }

        $cocon = new \HTS_Cocon();
        $result = $cocon->suggest_cluster_links( $cluster_name, $lang );

        if ( ! empty( $result['error'] ) ) {
            wp_send_json_error( $result['error'] );
        }

        // Early return: si toutes les suggestions sont "done", pas besoin d'itérer les checks
        $suggestions = $result['suggestions'] ?? array();
        $total_done = 0;
        $total_pending = 0;
        foreach ( $suggestions as $sug ) {
            if ( ( $sug['state'] ?? '' ) === 'done' ) $total_done++;
            else $total_pending++;
        }
        if ( $total_pending === 0 ) {
            set_transient( 'hts_wl_' . md5( $cluster_name ), $total_done, HOUR_IN_SECONDS );
            wp_send_json_success( array(
                'cluster'  => $cluster_name,
                'proposed' => 0,
                'done'     => $total_done,
                'skipped'  => 0,
                'message'  => 'well_linked',
            ) );
        }

        $proposed = 0;
        $skipped  = 0;
        $done     = 0;

        foreach ( $suggestions as $sug ) {
            $state = $sug['state'] ?? 'pending';
            if ( $state === 'done' ) { $done++; continue; }
            if ( $state === 'lost' ) { $skipped++; continue; }

            $source_id = (int) $sug['source_id'];
            $target_id = (int) $sug['target_id'];

            // Checks légers seulement — les checks lourds (budget, ancre, publish)
            // sont déjà faits par suggest_cluster_links() et cachés
            $paused_until = (int) get_post_meta( $source_id, '_hts_linking_paused', true );
            if ( $paused_until > 0 && time() < $paused_until ) { $skipped++; continue; }

            $proposal_data = array(
                'target_id'     => $target_id,
                'target_url'    => get_permalink( $target_id ),
                'target_title'  => $sug['target_title'] ?? get_the_title( $target_id ),
                'anchor_text'   => $sug['anchor_text'] ?? '',
                'anchor_method' => $sug['anchor_method'] ?? 'php',
                'anchor_type'   => $sug['anchor_type'] ?? 'extract',
                'anchor_bridge' => $sug['anchor_bridge'] ?? '',
                'bridge'        => $sug['anchor_bridge'] ?? '',
                'source_cocon'  => true,
                'cluster'       => $cluster_name,
                'link_type'     => $sug['link_type'] ?? 'cluster',
                'suggestion'    => sprintf( 'Lien %s vers « %s »', $sug['link_type'] ?? 'cluster', mb_substr( $sug['target_title'] ?? '', 0, 50 ) ),
                'reason'        => $sug['reason'] ?? sprintf( 'Cluster « %s »', mb_substr( $cluster_name, 0, 30 ) ),
            );

            if ( method_exists( $this, 'get_link_budget' ) ) {
                $budget_info = $this->get_link_budget( $source_id );
                $proposal_data['_budget'] = array(
                    'existing' => $budget_info['existing'],
                    'target'   => $budget_info['target'],
                    'budget'   => $budget_info['budget'],
                );
            }

            $priority = ! empty( $sug['orphan_rescue'] ) ? 'high' : ( $sug['priority'] ?? 'medium' );
            $proposed_id = \HTS_Workflow_Engine::propose( 'linking', 'add_internal_links', $source_id, $proposal_data, $priority );
            if ( $proposed_id ) $proposed++;
            else $skipped++;
        }

        $response = array(
            'cluster'  => $cluster_name,
            'proposed' => $proposed,
            'done'     => $done,
            'skipped'  => $skipped,
        );
        if ( $proposed === 0 && $done > 0 ) {
            $response['message'] = 'well_linked';
            set_transient( 'hts_wl_' . md5( $cluster_name ), $done, HOUR_IN_SECONDS );
        }
        wp_send_json_success( $response );
    }

    /**
     * Sprint 6.2c — Score existing outbound links in a post for swap eligibility.
     *
     * Returns an array sorted by score ASC (most dispensable first).
     * Links with data-hts="money", data-hts-keep, data-hts="manual", or pointing
     * to the cluster pillar are excluded (never swappable).
     *
     * @since 2.5.0
     * @param int $post_id
     * @return array Scored link entries sorted ASC by score.
     */
    public static function score_existing_links( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) return array();

        $content  = $post->post_content;
        $site_url = trailingslashit( site_url() );

        // ── Collect all <a> tags with href ──
        if ( ! preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $content, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
            return array();
        }

        // ── Load cocon data for cluster awareness ──
        $cocon_data   = self::load_cocon_data();

        // Find source cluster & pillar
        $source_cluster = '';
        $source_pillar  = 0;
        if ( ! empty( $cocon_data['clusters'] ) ) {
            foreach ( $cocon_data['clusters'] as $cname => $cl ) {
                $cl_pages = array_map( 'intval', $cl['pages'] ?? array() );
                if ( in_array( $post_id, $cl_pages, true ) ) {
                    $source_cluster = $cname;
                    $source_pillar  = (int) ( $cl['pillar_id'] ?? 0 );
                    break;
                }
            }
        }

        // ── Generic anchors ──
        $generic_anchors = array(
            'cliquez ici', 'cliquer ici', 'en savoir plus', 'lire la suite',
            'ici', 'ce lien', 'cette page', 'voir plus', "plus d'infos",
            'découvrir', 'en savoir davantage', 'lien', 'article',
            'click here', 'read more', 'learn more', 'here', 'this link',
            'this page', 'find out more', 'see more', 'link', 'more info',
        );

        // PREG_OFFSET_CAPTURE returns byte offsets, use strlen for comparison
        $content_byte_length = strlen( $content );
        $scored = array();

        // Cache resolved post IDs to avoid repeated url_to_postid calls
        $resolved_ids = array();

        foreach ( $matches as $m ) {
            $full_tag  = $m[0][0]; // full <a>...</a>
            $offset    = $m[0][1]; // byte offset
            $href      = $m[1][0];
            $anchor    = wp_strip_all_tags( $m[2][0] );
            $anchor_lc = mb_strtolower( trim( $anchor ) );

            // ── Skip external links ──
            if ( strpos( $href, $site_url ) === false && strpos( $href, '/' ) !== 0 ) continue;

            // ── Never-swap guards ──
            if ( stripos( $full_tag, 'data-hts="money"' )  !== false ) continue;
            if ( stripos( $full_tag, 'data-hts-keep' )     !== false ) continue;
            if ( stripos( $full_tag, 'data-hts="manual"' ) !== false ) continue;
            if ( stripos( $full_tag, 'data-hts="support"' ) !== false ) continue;

            // Skip links inside shortcodes or Gutenberg special blocks (FAQ, table)
            $before_start = max( 0, $offset - 80 );
            $before_tag   = substr( $content, $before_start, $offset - $before_start );
            if ( preg_match( '/\[(faq|table|tabs|accordion)/i', $before_tag ) ) continue;
            if ( preg_match( '/wp:table|wp:faq|wp:yoast\/faq/i', $before_tag ) ) continue;

            // ── Resolve target post ID (cached) ──
            if ( ! isset( $resolved_ids[ $href ] ) ) {
                $resolved_ids[ $href ] = hts_url_to_postid( $href );
            }
            $target_id = $resolved_ids[ $href ];
            if ( ! $target_id ) continue; // skip unresolvable (anchor links, etc.)

            // Never swap link to source cluster pillar
            if ( $source_pillar > 0 && $target_id === $source_pillar ) continue;

            // ── Score calculation ──
            $score   = 0;
            $reasons = array();

            // +20 Anchor contains target's focus keyword
            $target_kw = mb_strtolower( (string) get_post_meta( $target_id, '_hts_focus_keyword', true ) );
            if ( $target_kw && mb_strpos( $anchor_lc, $target_kw ) !== false ) {
                $score += 20;
            }

            // +15 Same cluster as source
            $target_in_cluster = false;
            if ( $source_cluster && ! empty( $cocon_data['clusters'][ $source_cluster ]['pages'] ) ) {
                $cl_pages = array_map( 'intval', $cocon_data['clusters'][ $source_cluster ]['pages'] );
                if ( in_array( $target_id, $cl_pages, true ) ) {
                    $score += 15;
                    $target_in_cluster = true;
                }
            }

            // +10 Target has GSC traffic
            $target_clicks = (int) get_post_meta( $target_id, '_hts_gsc_clicks', true );
            if ( $target_clicks > 0 ) {
                $score += 10;
            }

            // +5 Long contextual anchor (>3 words)
            if ( hts_word_count( $anchor ) > 3 ) {
                $score += 5;
            }

            // +10 HTS-generated link
            if ( stripos( $full_tag, 'data-hts=' ) !== false ) {
                $score += 10;
            }

            // -10 Link to homepage
            $norm_href = trailingslashit( $href );
            if ( $norm_href === $site_url || $href === site_url() ) {
                $score -= 10;
                $reasons[] = 'lien accueil';
            }

            // -15 Generic anchor
            if ( in_array( $anchor_lc, $generic_anchors, true ) ) {
                $score -= 15;
                $reasons[] = 'ancre générique';
            }

            // -8 Thin content target (<300 words)
            $target_post = get_post( $target_id );
            if ( $target_post && hts_word_count( wp_strip_all_tags( $target_post->post_content ) ) < 300 ) {
                $score -= 8;
                $reasons[] = 'cible faible';
            }

            // -5 Target out of cluster
            if ( $source_cluster && ! $target_in_cluster ) {
                $score -= 5;
                $reasons[] = 'hors-cluster';
            }

            // -10 Footer/sidebar pattern (last 200 bytes of content)
            if ( $content_byte_length > 0 && ( $content_byte_length - $offset ) < 200 ) {
                $score -= 10;
                $reasons[] = 'zone footer';
            }

            // -5 Target orphan (0 inbound links)
            $target_in = (int) get_post_meta( $target_id, '_hts_internal_links_in', true );
            if ( $target_in <= 0 ) {
                $score -= 5;
                $reasons[] = 'cible orpheline';
            }

            $scored[] = array(
                'href'      => $href,
                'anchor'    => $anchor,
                'target_id' => $target_id,
                'score'     => $score,
                'reasons'   => $reasons,
                'offset'    => $offset,
                'full_tag'  => $full_tag,
            );
        }

        // Sort by score ASC (most dispensable first)
        usort( $scored, function( $a, $b ) { return $a['score'] - $b['score']; } );

        return $scored;
    }
}
