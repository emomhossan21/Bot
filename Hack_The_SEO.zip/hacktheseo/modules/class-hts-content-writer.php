<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Content Writer — Universal content WRITE for all major page builders (Light).
 *
 * Symmetric counterpart of HTS_Content_Extractor (read).
 * Handles builder-specific write operations:
 *  - update_image_alt()   → Change alt text on an image
 *  - insert_link()        → Insert <a> tag around anchor text
 *  - remove_link()        → Remove <a> tag but keep text
 *  - replace_text()       → Replace a text fragment
 *
 * Supported builders:
 *  - Standard / Gutenberg / Classic Editor  (wp_update_post)
 *  - Elementor  (_elementor_data JSON)
 *  - Divi       (shortcodes in post_content)
 *  - WPBakery   (shortcodes in post_content)
 *  - Beaver Builder (_fl_builder_data serialized)
 *  - Bricks     (_bricks_page_content_2 JSON)
 *  - WooCommerce (post_content + post_excerpt)
 *
 * Adapted from Full v3.5.2 → Light Phase 2.
 *
 * @package HackTheSEOLight
 * @since   1.14.0
 */

class HTS_Content_Writer {

    /**
     * Track suspended hook callbacks so we can restore them.
     * @var array
     */
    private static $suspended_hooks = array();

    /**
     * Suspend all HTS save_post hooks to prevent cascade recalculations
     * when Content Writer modifies post_content (e.g. adding a link).
     *
     * Without this, inserting a single <a> tag triggers: embeddings recalculation,
     * on-page score recalculation, meta score logging, sitemap cache clear, etc.
     * These are expensive and unnecessary for minor content edits.
     */
    private static function suspend_hts_hooks() {
        global $wp_filter;
        if ( ! isset( $wp_filter['save_post'] ) ) return;

        self::$suspended_hooks = array();
        $hts_classes = array(
            'HTS_Embeddings', 'HTS_On_Page_Score', 'HTS_Meta_Score',
            'HTS_Sitemap', 'HTS_Cocon', 'HTS_Cockpit', 'HTS_LLMs_Txt',
            'HTS_Content_Extractor', 'HTS_Canonical', 'HTS_Robots',
            'HTS_SEO_Panel', 'HTS_Schema_Markup', 'HTS_Meta_Tags',
        );

        foreach ( $wp_filter['save_post']->callbacks as $priority => $callbacks ) {
            foreach ( $callbacks as $id => $cb ) {
                $func = $cb['function'] ?? null;
                if ( ! is_array( $func ) ) continue;
                $obj = $func[0] ?? null;
                if ( ! is_object( $obj ) && ! is_string( $obj ) ) continue;
                $class = is_object( $obj ) ? get_class( $obj ) : $obj;
                if ( in_array( $class, $hts_classes, true ) ) {
                    self::$suspended_hooks[] = array(
                        'priority' => $priority,
                        'id'       => $id,
                        'callback' => $cb,
                    );
                    unset( $wp_filter['save_post']->callbacks[ $priority ][ $id ] );
                }
            }
        }
    }

    /**
     * Restore all previously suspended HTS save_post hooks.
     */
    private static function restore_hts_hooks() {
        global $wp_filter;
        if ( empty( self::$suspended_hooks ) ) return;

        foreach ( self::$suspended_hooks as $h ) {
            $wp_filter['save_post']->callbacks[ $h['priority'] ][ $h['id'] ] = $h['callback'];
        }
        self::$suspended_hooks = array();
    }

    /**
     * Acquire a post-level editing lock (transient).
     * Prevents concurrent modifications from maillage + content refresh.
     *
     * @param int $post_id
     * @param int $ttl     Lock duration in seconds (default 60)
     * @return bool True if lock acquired, false if already locked
     */
    public static function acquire_post_lock( $post_id, $ttl = 60 ) {
        $key = 'hts_content_edit_' . $post_id;
        if ( get_transient( $key ) ) {
            return false; // Another module is editing this post
        }
        set_transient( $key, time(), $ttl );
        return true;
    }

    /**
     * Release the post-level editing lock.
     *
     * @param int $post_id
     */
    public static function release_post_lock( $post_id ) {
        delete_transient( 'hts_content_edit_' . $post_id );
    }

    /**
     * Check if a post is currently being edited by another HTS module.
     *
     * @param int $post_id
     * @return bool
     */
    public static function is_post_locked( $post_id ) {
        return (bool) get_transient( 'hts_content_edit_' . $post_id );
    }

    /**
     * Wrapper around wp_update_post with error checking.
     * Suspends HTS save_post hooks to avoid cascade recalculations.
     *
     * @param array  $args    wp_update_post args
     * @param string $builder Builder name for error context
     * @return int|array       Post ID on success, or error array
     */
    private static function safe_update_post( $args, $builder = 'standard' ) {
        self::suspend_hts_hooks();
        $result = wp_update_post( $args );
        self::restore_hts_hooks();

        if ( is_wp_error( $result ) || 0 === $result ) {
            $msg = is_wp_error( $result ) ? $result->get_error_message() : 'wp_update_post returned 0';
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Content Writer: échec sauvegarde post #' . ( $args['ID'] ?? '?' ) . ' — ' . $msg, 'error', 'content-writer' );
            }
            return self::error( 'Échec de la sauvegarde du contenu.', $builder );
        }
        return $result;
    }

    /* ══════════════════════════════════════════════
     *  PUBLIC API
     * ══════════════════════════════════════════════ */

    /**
     * Update alt text for an image in the post content.
     *
     * @param int    $post_id
     * @param string $img_src   Full or partial src to match
     * @param string $new_alt   New alt text
     * @return array { success: bool, builder: string, message: string }
     */
    public static function update_image_alt( $post_id, $img_src, $new_alt ) {
        $builder = self::detect_builder( $post_id );

        switch ( $builder ) {
            case 'elementor':
                return self::elementor_update_image_alt( $post_id, $img_src, $new_alt );
            case 'beaver':
                return self::beaver_update_image_alt( $post_id, $img_src, $new_alt );
            case 'bricks':
                return self::bricks_update_image_alt( $post_id, $img_src, $new_alt );
            default:
                return self::standard_update_image_alt( $post_id, $img_src, $new_alt, $builder );
        }
    }

    /**
     * Insert a link (<a>) around matching anchor text in the post content.
     *
     * @param int    $post_id
     * @param string $anchor_text  Text to wrap with <a>
     * @param string $target_url   Link href
     * @param array  $attrs        Optional link attributes (title, rel, target)
     * @return array { success: bool, builder: string, message: string }
     */
    public static function insert_link( $post_id, $anchor_text, $target_url, $attrs = array() ) {
        $builder = self::detect_builder( $post_id );

        // Sprint 6.2d: auto-detect internal vs external for rel default
        $is_internal = false;
        $site_host   = wp_parse_url( home_url(), PHP_URL_HOST );
        $link_host   = wp_parse_url( $target_url, PHP_URL_HOST );
        if ( ! $link_host || ( $site_host && ( $link_host === $site_host || str_ends_with( $link_host, '.' . $site_host ) ) ) ) {
            $is_internal = true;
        }

        $rel    = $attrs['rel']    ?? ( $is_internal ? '' : 'noopener' );
        $target = $attrs['target'] ?? ( $is_internal ? '_self' : '_blank' );
        $title  = $attrs['title']  ?? '';

        $link_html = '<a href="' . esc_url( $target_url ) . '"';
        if ( $rel )    $link_html .= ' rel="' . esc_attr( $rel ) . '"';
        if ( $target && $target !== '_self' ) $link_html .= ' target="' . esc_attr( $target ) . '"';
        if ( $title )  $link_html .= ' title="' . esc_attr( $title ) . '"';
        $link_html .= '>' . esc_html( $anchor_text ) . '</a>';

        switch ( $builder ) {
            case 'elementor':
                return self::elementor_replace_text( $post_id, $anchor_text, $link_html );
            case 'beaver':
                return self::beaver_replace_text( $post_id, $anchor_text, $link_html );
            case 'bricks':
                return self::bricks_replace_text( $post_id, $anchor_text, $link_html );
            default:
                return self::standard_replace_in_content( $post_id, $anchor_text, $link_html, $builder );
        }
    }

    /**
     * Remove a link from the content, keeping the anchor text.
     *
     * @param int    $post_id
     * @param string $target_url  URL to find and unlink
     * @return array { success: bool, builder: string, message: string }
     */
    public static function remove_link( $post_id, $target_url ) {
        $builder = self::detect_builder( $post_id );

        $url_alt  = rtrim( $target_url, '/' );
        $url_alt2 = $url_alt . '/';
        $pattern  = '/<a[^>]+href=["\'](?:' . preg_quote( $url_alt, '/' ) . '|' . preg_quote( $url_alt2, '/' ) . ')["\'][^>]*>(.*?)<\/a>/si';

        switch ( $builder ) {
            case 'elementor':
                return self::elementor_regex_replace( $post_id, $pattern, '$1' );
            case 'beaver':
                return self::beaver_regex_replace( $post_id, $pattern, '$1' );
            case 'bricks':
                return self::bricks_regex_replace( $post_id, $pattern, '$1' );
            default:
                return self::standard_regex_replace( $post_id, $pattern, '$1', $builder );
        }
    }

    /**
     * Replace a text fragment in the post content.
     *
     * @param int    $post_id
     * @param string $search      Text to find
     * @param string $replace     Replacement (can contain HTML)
     * @return array { success: bool, builder: string, message: string }
     */
    public static function replace_text( $post_id, $search, $replace ) {
        $builder = self::detect_builder( $post_id );

        switch ( $builder ) {
            case 'elementor':
                return self::elementor_replace_text( $post_id, $search, $replace );
            case 'beaver':
                return self::beaver_replace_text( $post_id, $search, $replace );
            case 'bricks':
                return self::bricks_replace_text( $post_id, $search, $replace );
            default:
                return self::standard_replace_in_content( $post_id, $search, $replace, $builder );
        }
    }

    /**
     * Get the raw content for backup/rollback purposes.
     * Returns the builder-specific raw data that can be restored.
     *
     * @param int $post_id
     * @return array { builder: string, data: mixed, content: string }
     */
    public static function get_raw_backup( $post_id ) {
        $builder = self::detect_builder( $post_id );

        switch ( $builder ) {
            case 'elementor':
                return array(
                    'builder' => 'elementor',
                    'data'    => get_post_meta( $post_id, '_elementor_data', true ),
                    'content' => get_post( $post_id )->post_content ?? '',
                );
            case 'beaver':
                return array(
                    'builder' => 'beaver',
                    'data'    => get_post_meta( $post_id, '_fl_builder_data', true ),
                    'content' => get_post( $post_id )->post_content ?? '',
                );
            case 'bricks':
                return array(
                    'builder' => 'bricks',
                    'data'    => get_post_meta( $post_id, '_bricks_page_content_2', true ),
                    'content' => get_post( $post_id )->post_content ?? '',
                );
            default:
                return array(
                    'builder' => $builder,
                    'data'    => null,
                    'content' => get_post( $post_id )->post_content ?? '',
                );
        }
    }

    /**
     * Restore from a raw backup.
     *
     * @param int   $post_id
     * @param array $backup  From get_raw_backup()
     * @return bool
     */
    public static function restore_backup( $post_id, $backup ) {
        if ( ! is_array( $backup ) || empty( $backup['builder'] ) ) return false;

        // Restore post_content
        if ( isset( $backup['content'] ) ) {
            $upd = wp_update_post( array( 'ID' => $post_id, 'post_content' => $backup['content'] ) );
            if ( is_wp_error( $upd ) || 0 === $upd ) return false;
        }

        // Restore builder-specific meta
        if ( ! empty( $backup['data'] ) ) {
            switch ( $backup['builder'] ) {
                case 'elementor':
                    update_post_meta( $post_id, '_elementor_data', wp_slash( $backup['data'] ) );
                    break;
                case 'beaver':
                    update_post_meta( $post_id, '_fl_builder_data', $backup['data'] );
                    break;
                case 'bricks':
                    update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( $backup['data'] ) );
                    break;
            }
        }

        // Invalidate extraction cache
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            HTS_Content_Extractor::invalidate_cache( $post_id );
        }

        return true;
    }

    /* ══════════════════════════════════════════════
     *  BUILDER DETECTION
     * ══════════════════════════════════════════════ */

    /**
     * Detect which builder a post uses.
     *
     * @param int $post_id
     * @return string  elementor|divi|wpbakery|beaver|bricks|woo|gutenberg|standard
     */
    public static function detect_builder( $post_id ) {
        if ( ! class_exists( 'HTS_Content_Extractor' ) ) return 'standard';

        if ( HTS_Content_Extractor::is_elementor( $post_id ) ) return 'elementor';
        if ( HTS_Content_Extractor::is_beaver( $post_id ) )    return 'beaver';
        if ( HTS_Content_Extractor::is_bricks( $post_id ) )    return 'bricks';

        $post = get_post( $post_id );
        if ( ! $post ) return 'standard';

        $content = $post->post_content;
        if ( HTS_Content_Extractor::is_divi( $content ) )      return 'divi';
        if ( HTS_Content_Extractor::is_wpbakery( $content ) )  return 'wpbakery';
        if ( $post->post_type === 'product' )                   return 'woo';
        if ( preg_match( '/<!-- wp:/', $content ) )             return 'gutenberg';

        return 'standard';
    }

    /* ══════════════════════════════════════════════
     *  STANDARD / GUTENBERG / DIVI / WPBAKERY
     *  All store content in post_content (HTML or shortcodes)
     * ══════════════════════════════════════════════ */

    private static function standard_update_image_alt( $post_id, $img_src, $new_alt, $builder ) {
        $post = get_post( $post_id );
        if ( ! $post ) return self::error( 'Article introuvable.', $builder );

        $content = $post->post_content;
        $src_escaped = preg_quote( $img_src, '/' );

        $found = false;
        $new_content = preg_replace_callback(
            '/<img([^>]*(?:data-(?:lazy-)?src|data-original|src)\s*=\s*["\'](?:[^"\']*' . $src_escaped . ')["\'][^>]*)>/i',
            function( $m ) use ( $new_alt, &$found ) {
                $found = true;
                $attrs = $m[1];
                if ( preg_match( '/alt=["\'][^"\']*["\']/', $attrs ) ) {
                    $attrs = preg_replace( '/alt=["\'][^"\']*["\']/', 'alt="' . esc_attr( $new_alt ) . '"', $attrs );
                } else {
                    $attrs .= ' alt="' . esc_attr( $new_alt ) . '"';
                }
                return '<img' . $attrs . '>';
            },
            $content,
            1
        );

        if ( ! $found ) return self::error( 'Image non trouvée dans le contenu.', $builder );

        $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ), $builder );
        if ( is_array( $upd ) ) return $upd;
        self::after_write( $post_id );
        return self::success( 'Alt mis à jour.', $builder );
    }

    private static function standard_replace_in_content( $post_id, $search, $replace, $builder ) {
        $post = get_post( $post_id );
        if ( ! $post ) return self::error( 'Article introuvable.', $builder );

        $content = $post->post_content;

        // Sprint Robustesse: heading-aware replacement — skip occurrences inside <h1>-<h6>
        $new_content = self::replace_outside_headings( $content, $search, $replace );
        if ( $new_content === null ) {
            // Try with decoded entities
            $decoded = html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
            $new_content = self::replace_outside_headings( $decoded, $search, $replace );
        }
        if ( $new_content === null ) {
            return self::error( 'Texte non trouvé dans le contenu (hors titres).', $builder );
        }

        $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ), $builder );
        if ( is_array( $upd ) ) return $upd;
        self::after_write( $post_id );
        return self::success( 'Contenu modifié.', $builder );
    }

    /**
     * Replace the first occurrence of $search that is NOT inside an <h1>-<h6> tag.
     * Returns modified content or null if no safe occurrence found.
     */
    private static function replace_outside_headings( $content, $search, $replace, $skip_intro = true ) {
        $offset = 0;
        $search_len = mb_strlen( $search );

        // v2.5.12: Find first H2 position — skip intro zone (reserved for pillar link)
        $first_h2_pos = false;
        if ( $skip_intro && preg_match( '/<h2[\s>]/i', $content, $h2m, PREG_OFFSET_CAPTURE ) ) {
            $first_h2_pos = $h2m[0][1];
        }

        while ( ( $pos = mb_strpos( $content, $search, $offset ) ) !== false ) {
            // v2.5.12: Skip occurrences before first H2 (intro zone)
            if ( $first_h2_pos !== false && $pos < $first_h2_pos ) {
                $offset = $pos + $search_len;
                continue;
            }

            // Check if this position is inside a heading
            $before = mb_substr( $content, 0, $pos );
            $inside_heading = false;
            if ( preg_match_all( '/<(h[1-6])[\s>]/i', $before, $opens, PREG_OFFSET_CAPTURE ) ) {
                $last_open = end( $opens[0] );
                $tag_name  = end( $opens[1] )[0];
                $last_open_pos = $last_open[1];
                $between = substr( $content, $last_open_pos, $pos - $last_open_pos );
                if ( stripos( $between, '</' . $tag_name . '>' ) === false ) {
                    $inside_heading = true;
                }
            }
            // Also check if inside an existing <a> tag
            $inside_link = false;
            if ( preg_match_all( '/<a[\s>]/i', $before, $a_opens, PREG_OFFSET_CAPTURE ) ) {
                $last_a = end( $a_opens[0] );
                $last_a_pos = $last_a[1];
                $between_a = substr( $content, $last_a_pos, $pos - $last_a_pos );
                if ( stripos( $between_a, '</a>' ) === false ) {
                    $inside_link = true;
                }
            }

            if ( ! $inside_heading && ! $inside_link ) {
                // Safe to replace here
                return mb_substr( $content, 0, $pos ) . $replace . mb_substr( $content, $pos + $search_len );
            }
            $offset = $pos + $search_len;
        }
        return null; // No safe occurrence found
    }

    private static function standard_regex_replace( $post_id, $pattern, $replacement, $builder ) {
        $post = get_post( $post_id );
        if ( ! $post ) return self::error( 'Article introuvable.', $builder );

        $new_content = preg_replace( $pattern, $replacement, $post->post_content, 1 );

        if ( $new_content === $post->post_content ) {
            return self::error( 'Pattern non trouvé.', $builder );
        }

        $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ), $builder );
        if ( is_array( $upd ) ) return $upd;
        self::after_write( $post_id );
        return self::success( 'Contenu modifié.', $builder );
    }

    /* ══════════════════════════════════════════════
     *  ELEMENTOR
     *  Content stored in _elementor_data (JSON)
     * ══════════════════════════════════════════════ */

    private static function elementor_update_image_alt( $post_id, $img_src, $new_alt ) {
        $data = self::get_elementor_data( $post_id );
        if ( $data === null ) return self::error( 'Données Elementor introuvables.', 'elementor' );

        $found = false;
        self::walk_elementor_write( $data, function( &$el ) use ( $img_src, $new_alt, &$found ) {
            if ( $found ) return;
            $s = &$el['settings'];

            // Image widget
            if ( isset( $el['widgetType'] ) && $el['widgetType'] === 'image' ) {
                if ( ! empty( $s['image']['url'] ) && self::src_matches( $s['image']['url'], $img_src ) ) {
                    $s['image']['alt'] = $new_alt;
                    $found = true;
                    return;
                }
            }

            // Any widget with image settings (image-box, call-to-action, etc.)
            foreach ( array( 'image', 'background_image', 'image_overlay' ) as $key ) {
                if ( isset( $s[ $key ]['url'] ) && self::src_matches( $s[ $key ]['url'], $img_src ) ) {
                    $s[ $key ]['alt'] = $new_alt;
                    $found = true;
                    return;
                }
            }

            // Check for <img> in text-editor widgets
            if ( isset( $el['widgetType'] ) && $el['widgetType'] === 'text-editor' && ! empty( $s['editor'] ) ) {
                $src_escaped = preg_quote( $img_src, '/' );
                if ( preg_match( '/<img[^>]*src=["\'][^"\']*' . $src_escaped . '/i', $s['editor'] ) ) {
                    $s['editor'] = self::update_img_alt_in_html( $s['editor'], $img_src, $new_alt );
                    $found = true;
                    return;
                }
            }
        });

        if ( ! $found ) {
            $std = self::standard_update_image_alt( $post_id, $img_src, $new_alt, 'elementor' );
            if ( $std['success'] ) return $std;
            return self::error( 'Image non trouvée dans Elementor.', 'elementor' );
        }

        self::save_elementor_data( $post_id, $data );
        self::elementor_sync_post_content( $post_id, $data );
        self::after_write( $post_id );
        return self::success( 'Alt mis à jour (Elementor).', 'elementor' );
    }

    private static function elementor_replace_text( $post_id, $search, $replace ) {
        $data = self::get_elementor_data( $post_id );
        if ( $data === null ) return self::error( 'Données Elementor introuvables.', 'elementor' );

        $found = false;
        self::walk_elementor_write( $data, function( &$el ) use ( $search, $replace, &$found ) {
            if ( $found ) return;
            if ( ! isset( $el['widgetType'] ) ) return;

            // Sprint Robustesse: NEVER insert links in heading widgets
            if ( in_array( $el['widgetType'], array( 'heading', 'theme-post-title', 'theme-archive-title' ), true ) ) return;

            // For non-heading widgets, skip the 'title' field (only replace in content fields)
            $text_fields = array( 'editor', 'description_text', 'content' );
            $s = &$el['settings'];

            foreach ( $text_fields as $field ) {
                if ( ! empty( $s[ $field ] ) && is_string( $s[ $field ] ) ) {
                    $decoded = html_entity_decode( $s[ $field ], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                    if ( mb_strpos( $s[ $field ], $search ) !== false ) {
                        $s[ $field ] = self::mb_str_replace_first( $s[ $field ], $search, $replace );
                        $found = true;
                        return;
                    } elseif ( mb_strpos( $decoded, $search ) !== false ) {
                        $s[ $field ] = self::mb_str_replace_first( $decoded, $search, $replace );
                        $found = true;
                        return;
                    }
                }
            }

            // Accordion / toggle / tabs
            if ( isset( $s['tabs'] ) && is_array( $s['tabs'] ) ) {
                foreach ( $s['tabs'] as &$tab ) {
                    if ( ! empty( $tab['tab_content'] ) && mb_strpos( $tab['tab_content'], $search ) !== false ) {
                        $tab['tab_content'] = self::mb_str_replace_first( $tab['tab_content'], $search, $replace );
                        $found = true;
                        return;
                    }
                }
            }
        });

        if ( ! $found ) {
            // Sprint Robustesse: for Elementor, post_content is empty.
            // Don't fall back to standard_replace (will always fail).
            // Instead, return error — caller should use append_paragraph.
            return self::error( 'Texte non trouvé dans les widgets Elementor. Utilisez append_paragraph.', 'elementor' );
        }

        self::save_elementor_data( $post_id, $data );
        self::elementor_sync_post_content( $post_id, $data );
        // Sprint Robustesse: flush Elementor CSS cache
        delete_post_meta( $post_id, '_elementor_css' );
        if ( class_exists( '\\Elementor\\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
        self::after_write( $post_id );
        return self::success( 'Contenu modifié (Elementor).', 'elementor' );
    }

    private static function elementor_regex_replace( $post_id, $pattern, $replacement ) {
        $data = self::get_elementor_data( $post_id );
        if ( $data === null ) return self::error( 'Données Elementor introuvables.', 'elementor' );

        $found = false;
        self::walk_elementor_write( $data, function( &$el ) use ( $pattern, $replacement, &$found ) {
            if ( $found ) return;
            if ( ! isset( $el['widgetType'] ) ) return;

            $text_fields = array( 'editor', 'title', 'description_text', 'content' );
            $s = &$el['settings'];

            foreach ( $text_fields as $field ) {
                if ( ! empty( $s[ $field ] ) && is_string( $s[ $field ] ) && preg_match( $pattern, $s[ $field ] ) ) {
                    $s[ $field ] = preg_replace( $pattern, $replacement, $s[ $field ], 1 );
                    $found = true;
                    return;
                }
            }

            if ( isset( $s['tabs'] ) && is_array( $s['tabs'] ) ) {
                foreach ( $s['tabs'] as &$tab ) {
                    if ( ! empty( $tab['tab_content'] ) && preg_match( $pattern, $tab['tab_content'] ) ) {
                        $tab['tab_content'] = preg_replace( $pattern, $replacement, $tab['tab_content'], 1 );
                        $found = true;
                        return;
                    }
                }
            }
        });

        if ( ! $found ) {
            $std = self::standard_regex_replace( $post_id, $pattern, $replacement, 'elementor' );
            if ( $std['success'] ) return $std;
            return self::error( 'Pattern non trouvé dans Elementor.', 'elementor' );
        }

        self::save_elementor_data( $post_id, $data );
        self::elementor_sync_post_content( $post_id, $data );
        delete_post_meta( $post_id, '_elementor_css' );
        self::after_write( $post_id );
        return self::success( 'Contenu modifié (Elementor).', 'elementor' );
    }

    /* ── Elementor helpers ── */

    private static function get_elementor_data( $post_id ) {
        $data = get_post_meta( $post_id, '_elementor_data', true );
        if ( ! $data ) return null;
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        return is_array( $data ) ? $data : null;
    }

    private static function save_elementor_data( $post_id, $data ) {
        $json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
    }

    /**
     * Rebuild Elementor post_content from JSON data (SEO mirror).
     */
    private static function elementor_sync_post_content( $post_id, $data ) {
        $parts = array();
        self::walk_elementor_read( $data, function( $el ) use ( &$parts ) {
            if ( ! isset( $el['widgetType'] ) ) return;
            $s = $el['settings'] ?? array();
            switch ( $el['widgetType'] ) {
                case 'text-editor':
                    if ( ! empty( $s['editor'] ) ) $parts[] = $s['editor'];
                    break;
                case 'heading':
                    if ( ! empty( $s['title'] ) ) {
                        $tag = $s['header_size'] ?? 'h2';
                        $parts[] = '<' . $tag . '>' . $s['title'] . '</' . $tag . '>';
                    }
                    break;
                case 'image':
                    if ( ! empty( $s['image']['url'] ) ) {
                        $alt = $s['image']['alt'] ?? '';
                        $parts[] = '<img src="' . esc_url( $s['image']['url'] ) . '" alt="' . esc_attr( $alt ) . '" />';
                    }
                    break;
            }
        });

        if ( ! empty( $parts ) ) {
            $upd = wp_update_post( array( 'ID' => $post_id, 'post_content' => implode( "\n\n", $parts ) ) );
            if ( is_wp_error( $upd ) || 0 === $upd ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Content Writer: échec sauvegarde Elementor post #' . $post_id, 'error', 'content-writer' );
                }
            }
        }
    }

    private static function walk_elementor_write( &$elements, $callback ) {
        foreach ( $elements as &$el ) {
            $callback( $el );
            if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
                self::walk_elementor_write( $el['elements'], $callback );
            }
        }
    }

    private static function walk_elementor_read( $elements, $callback ) {
        foreach ( $elements as $el ) {
            $callback( $el );
            if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
                self::walk_elementor_read( $el['elements'], $callback );
            }
        }
    }

    /* ══════════════════════════════════════════════
     *  BEAVER BUILDER
     *  Content stored in _fl_builder_data (serialized)
     * ══════════════════════════════════════════════ */

    private static function beaver_update_image_alt( $post_id, $img_src, $new_alt ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) return self::error( 'Données Beaver introuvables.', 'beaver' );

        $found = false;
        foreach ( $data as &$node ) {
            if ( ! isset( $node->type ) || $node->type !== 'module' ) continue;
            $s = $node->settings;

            if ( isset( $s->photo_src ) && self::src_matches( $s->photo_src, $img_src ) ) {
                $s->alt = $new_alt;
                $found = true;
                break;
            }

            if ( isset( $s->text ) && preg_match( '/<img[^>]*' . preg_quote( $img_src, '/' ) . '/i', $s->text ) ) {
                $s->text = self::update_img_alt_in_html( $s->text, $img_src, $new_alt );
                $found = true;
                break;
            }
        }

        if ( ! $found ) {
            $std = self::standard_update_image_alt( $post_id, $img_src, $new_alt, 'beaver' );
            if ( $std['success'] ) return $std;
            return self::error( 'Image non trouvée dans Beaver.', 'beaver' );
        }

        update_post_meta( $post_id, '_fl_builder_data', $data );
        self::after_write( $post_id );
        return self::success( 'Alt mis à jour (Beaver Builder).', 'beaver' );
    }

    private static function beaver_replace_text( $post_id, $search, $replace ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) return self::error( 'Données Beaver introuvables.', 'beaver' );

        $found = false;
        foreach ( $data as &$node ) {
            if ( ! isset( $node->type ) || $node->type !== 'module' ) continue;
            // Sprint Robustesse: skip heading modules
            if ( isset( $node->settings->type ) && $node->settings->type === 'heading' ) continue;
            $s = $node->settings;

            // Only search in text/html content fields, NOT headings
            foreach ( array( 'text', 'html' ) as $field ) {
                if ( isset( $s->$field ) && is_string( $s->$field ) && mb_strpos( $s->$field, $search ) !== false ) {
                    $s->$field = self::mb_str_replace_first( $s->$field, $search, $replace );
                    $found = true;
                    break 2;
                }
            }
        }

        if ( ! $found ) {
            return self::error( 'Texte non trouvé dans les modules Beaver.', 'beaver' );
        }

        update_post_meta( $post_id, '_fl_builder_data', $data );
        self::after_write( $post_id );
        return self::success( 'Contenu modifié (Beaver Builder).', 'beaver' );
    }

    private static function beaver_regex_replace( $post_id, $pattern, $replacement ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) return self::error( 'Données Beaver introuvables.', 'beaver' );

        $found = false;
        foreach ( $data as &$node ) {
            if ( ! isset( $node->type ) || $node->type !== 'module' ) continue;
            $s = $node->settings;

            foreach ( array( 'text', 'html' ) as $field ) {
                if ( isset( $s->$field ) && is_string( $s->$field ) && preg_match( $pattern, $s->$field ) ) {
                    $s->$field = preg_replace( $pattern, $replacement, $s->$field, 1 );
                    $found = true;
                    break 2;
                }
            }
        }

        if ( ! $found ) {
            $std = self::standard_regex_replace( $post_id, $pattern, $replacement, 'beaver' );
            if ( $std['success'] ) return $std;
            return self::error( 'Pattern non trouvé dans Beaver.', 'beaver' );
        }

        update_post_meta( $post_id, '_fl_builder_data', $data );
        self::after_write( $post_id );
        return self::success( 'Contenu modifié (Beaver Builder).', 'beaver' );
    }

    /* ══════════════════════════════════════════════
     *  BRICKS BUILDER
     *  Content stored in _bricks_page_content_2 (JSON)
     * ══════════════════════════════════════════════ */

    private static function bricks_update_image_alt( $post_id, $img_src, $new_alt ) {
        $data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) return self::error( 'Données Bricks introuvables.', 'bricks' );

        $found = false;
        foreach ( $data as &$el ) {
            $name = $el['name'] ?? '';
            if ( $name === 'image' && ! empty( $el['settings']['image']['url'] ) ) {
                if ( self::src_matches( $el['settings']['image']['url'], $img_src ) ) {
                    $el['settings']['image']['alt'] = $new_alt;
                    $found = true;
                    break;
                }
            }
            if ( in_array( $name, array( 'text-basic', 'text', 'rich-text' ), true ) && ! empty( $el['settings']['text'] ) ) {
                if ( preg_match( '/<img[^>]*' . preg_quote( $img_src, '/' ) . '/i', $el['settings']['text'] ) ) {
                    $el['settings']['text'] = self::update_img_alt_in_html( $el['settings']['text'], $img_src, $new_alt );
                    $found = true;
                    break;
                }
            }
        }

        if ( ! $found ) {
            $std = self::standard_update_image_alt( $post_id, $img_src, $new_alt, 'bricks' );
            if ( $std['success'] ) return $std;
            return self::error( 'Image non trouvée dans Bricks.', 'bricks' );
        }

        update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
        self::after_write( $post_id );
        return self::success( 'Alt mis à jour (Bricks).', 'bricks' );
    }

    private static function bricks_replace_text( $post_id, $search, $replace ) {
        $data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) return self::error( 'Données Bricks introuvables.', 'bricks' );

        $found = false;
        foreach ( $data as &$el ) {
            $name = $el['name'] ?? '';
            // Sprint Robustesse: skip heading elements — never insert links in headings
            if ( in_array( $name, array( 'text-basic', 'text', 'rich-text' ), true ) && ! empty( $el['settings']['text'] ) ) {
                if ( mb_strpos( $el['settings']['text'], $search ) !== false ) {
                    $el['settings']['text'] = self::mb_str_replace_first( $el['settings']['text'], $search, $replace );
                    $found = true;
                    break;
                }
            }
        }

        if ( ! $found ) {
            return self::error( 'Texte non trouvé dans les éléments Bricks.', 'bricks' );
        }

        update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
        self::after_write( $post_id );
        return self::success( 'Contenu modifié (Bricks).', 'bricks' );
    }

    private static function bricks_regex_replace( $post_id, $pattern, $replacement ) {
        $data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) return self::error( 'Données Bricks introuvables.', 'bricks' );

        $found = false;
        foreach ( $data as &$el ) {
            $name = $el['name'] ?? '';
            if ( in_array( $name, array( 'text-basic', 'text', 'rich-text' ), true ) && ! empty( $el['settings']['text'] ) ) {
                if ( preg_match( $pattern, $el['settings']['text'] ) ) {
                    $el['settings']['text'] = preg_replace( $pattern, $replacement, $el['settings']['text'], 1 );
                    $found = true;
                    break;
                }
            }
        }

        if ( ! $found ) {
            $std = self::standard_regex_replace( $post_id, $pattern, $replacement, 'bricks' );
            if ( $std['success'] ) return $std;
            return self::error( 'Pattern non trouvé dans Bricks.', 'bricks' );
        }

        update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
        self::after_write( $post_id );
        return self::success( 'Contenu modifié (Bricks).', 'bricks' );
    }

    /* ══════════════════════════════════════════════
     *  UTILITY HELPERS
     * ══════════════════════════════════════════════ */

    private static function update_img_alt_in_html( $html, $img_src, $new_alt ) {
        $src_escaped = preg_quote( $img_src, '/' );
        return preg_replace_callback(
            '/<img([^>]*(?:data-(?:lazy-)?src|data-original|src)\s*=\s*["\'][^"\']*' . $src_escaped . '["\'][^>]*)>/i',
            function( $m ) use ( $new_alt ) {
                $attrs = $m[1];
                if ( preg_match( '/alt=["\'][^"\']*["\']/', $attrs ) ) {
                    $attrs = preg_replace( '/alt=["\'][^"\']*["\']/', 'alt="' . esc_attr( $new_alt ) . '"', $attrs );
                } else {
                    $attrs .= ' alt="' . esc_attr( $new_alt ) . '"';
                }
                return '<img' . $attrs . '>';
            },
            $html,
            1
        );
    }

    private static function src_matches( $url, $search ) {
        if ( $url === $search ) return true;
        if ( strpos( $url, $search ) !== false ) return true;
        $url_base    = preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', basename( $url ) );
        $search_base = preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', basename( $search ) );
        return strtolower( $url_base ) === strtolower( $search_base );
    }

    private static function mb_str_replace_first( $haystack, $needle, $replacement ) {
        $pos = mb_strpos( $haystack, $needle );
        if ( $pos === false ) return $haystack;
        return mb_substr( $haystack, 0, $pos ) . $replacement . mb_substr( $haystack, $pos + mb_strlen( $needle ) );
    }

    /* ══════════════════════════════════════════════
     *  APPEND PARAGRAPH (multi-builder)
     *  Adds a new paragraph with HTML content at the end of a post.
     *  Builder-aware: writes into Elementor JSON, Beaver meta, Bricks meta.
     * ══════════════════════════════════════════════ */

    /**
     * Append a paragraph containing HTML (e.g. a contextual link sentence)
     * at the end of the post content, using the correct builder format.
     *
     * @param int    $post_id
     * @param string $paragraph_html  HTML content to wrap in a paragraph (e.g. "Découvrez aussi <a href='...'>...")
     * @return array { success: bool, builder: string, message: string }
     */
    public static function append_paragraph( $post_id, $paragraph_html, $context = array() ) {
        $builder = self::detect_builder( $post_id );

        switch ( $builder ) {
            case 'elementor':
                return self::elementor_append_paragraph( $post_id, $paragraph_html, $context );
            case 'beaver':
                return self::beaver_append_paragraph( $post_id, $paragraph_html );
            case 'bricks':
                return self::bricks_append_paragraph( $post_id, $paragraph_html );
            default:
                return self::standard_append_paragraph( $post_id, $paragraph_html, $builder );
        }
    }

    /**
     * Standard/Gutenberg/Divi/WPBakery: append <p> to post_content.
     */
    private static function standard_append_paragraph( $post_id, $paragraph_html, $builder ) {
        $post = get_post( $post_id );
        if ( ! $post ) return self::error( 'Article introuvable.', $builder );

        $content = rtrim( $post->post_content );

        // Gutenberg: add a proper block
        if ( $builder === 'gutenberg' || strpos( $content, '<!-- wp:' ) !== false ) {
            $content .= "\n\n" . '<!-- wp:paragraph -->' . "\n" . '<p>' . $paragraph_html . '</p>' . "\n" . '<!-- /wp:paragraph -->';
        } else {
            $content .= "\n" . '<p>' . $paragraph_html . '</p>';
        }

        $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $content ), $builder );
        if ( is_array( $upd ) ) return $upd;
        self::after_write( $post_id );
        return self::success( 'Paragraphe ajouté en fin de contenu.', $builder );
    }

    /**
     * Elementor: add a text-editor widget at the end of the last section/column.
     */
    private static function elementor_append_paragraph( $post_id, $paragraph_html, $context = array() ) {
        $data = self::get_elementor_data( $post_id );
        if ( $data === null ) {
            return self::standard_append_paragraph( $post_id, $paragraph_html, 'elementor' );
        }

        // v2.5.12: Find the best text-editor widget by content length + thematic relevance.
        // Pass target_keywords from context so we can score thematic proximity.
        $target_keywords = ! empty( $context['target_keywords'] ) ? $context['target_keywords'] : array();
        $best_widget_path = null;
        $best_content_len = 0;
        $best_relevance   = 0;

        self::walk_elementor_find_best_text_widget( $data, array(), $best_widget_path, $best_content_len, false, $target_keywords, $best_relevance );

        if ( $best_widget_path !== null ) {
            // Navigate to the widget and append
            $ref = &$data;
            foreach ( $best_widget_path as $idx ) {
                if ( isset( $ref[ $idx ] ) ) {
                    $ref = &$ref[ $idx ];
                } elseif ( isset( $ref['elements'][ $idx ] ) ) {
                    $ref = &$ref['elements'][ $idx ];
                } else {
                    $best_widget_path = null;
                    break;
                }
            }

            if ( $best_widget_path !== null && isset( $ref['settings']['editor'] ) ) {
                $editor = &$ref['settings']['editor'];

                // v2.5.12: Find the best paragraph INSIDE this widget (by keyword overlap)
                // and append the phrase at the end of that paragraph (inline, not new <p>).
                $injected = self::inject_in_best_paragraph( $editor, $paragraph_html, $target_keywords );

                if ( ! $injected ) {
                    // Fallback: append after the last </p> as a new <p>
                    $last_p = strrpos( $editor, '</p>' );
                    if ( $last_p !== false ) {
                        $editor = substr( $editor, 0, $last_p + 4 ) . "\n<p>" . $paragraph_html . '</p>' . substr( $editor, $last_p + 4 );
                    } else {
                        $editor .= "\n<p>" . $paragraph_html . '</p>';
                    }
                }

                self::save_elementor_data( $post_id, $data );
                self::elementor_sync_post_content( $post_id, $data );
                // Flush Elementor CSS cache
                delete_post_meta( $post_id, '_elementor_css' );
                if ( class_exists( '\\Elementor\\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
                    \Elementor\Plugin::$instance->files_manager->clear_cache();
                }
                self::after_write( $post_id );
                return self::success( 'Lien injecté dans le contenu éditorial (Elementor).', 'elementor' );
            }
        }

        // Fallback: no suitable text widget found — create a new one in last content section
        $new_widget = array(
            'id'         => wp_generate_uuid4(),
            'elType'     => 'widget',
            'widgetType' => 'text-editor',
            'settings'   => array(
                'editor' => '<p>' . $paragraph_html . '</p>',
            ),
            'elements'   => array(),
        );

        // Find the last section that contains text-editor widgets AND is not a CTA section
        $appended = false;
        for ( $i = count( $data ) - 1; $i >= 0; $i-- ) {
            $el_type = $data[ $i ]['elType'] ?? '';
            if ( $el_type === 'section' || $el_type === 'container' ) {
                // Check if this section has any text-editor widgets
                $has_text = self::section_has_text_widget( $data[ $i ] );
                if ( ! $has_text ) continue; // Skip footer/CTA sections

                // v2.5.12: Also skip sections with CTA/button widgets (CTA zones)
                if ( self::section_has_cta_widget( $data[ $i ] ) ) continue;

                $section = &$data[ $i ];
                if ( ! empty( $section['elements'] ) ) {
                    $last_col_idx = count( $section['elements'] ) - 1;
                    $section['elements'][ $last_col_idx ]['elements'][] = $new_widget;
                    $appended = true;
                } else {
                    $section['elements'][] = $new_widget;
                    $appended = true;
                }
                break;
            }
        }

        if ( ! $appended ) {
            // Truly nothing — create a section
            $data[] = array(
                'id'       => wp_generate_uuid4(),
                'elType'   => 'section',
                'settings' => array(),
                'elements' => array(
                    array(
                        'id'       => wp_generate_uuid4(),
                        'elType'   => 'column',
                        'settings' => array( '_column_size' => 100 ),
                        'elements' => array( $new_widget ),
                    ),
                ),
            );
        }

        self::save_elementor_data( $post_id, $data );
        self::elementor_sync_post_content( $post_id, $data );
        delete_post_meta( $post_id, '_elementor_css' );
        if ( class_exists( '\\Elementor\\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
        self::after_write( $post_id );
        return self::success( 'Paragraphe ajouté (Elementor).', 'elementor' );
    }

    /**
     * Recursively find the LONGEST text-editor widget (= main editorial content).
     * Skips widgets inside CTA sections (sections containing button widgets).
     * When target_keywords are provided, uses a combined score: length + relevance.
     *
     * @since 2.5.12 — Changed from "last ≥100 chars" to "longest + most relevant, not in CTA".
     */
    private static function walk_elementor_find_best_text_widget( $elements, $path, &$best_path, &$best_len, $in_cta_section = false, $target_keywords = array(), &$best_relevance = 0 ) {
        foreach ( $elements as $idx => $el ) {
            $current_path = array_merge( $path, array( $idx ) );
            $el_type = $el['elType'] ?? '';

            // Detect CTA sections: top-level sections/containers that contain button widgets
            $child_in_cta = $in_cta_section;
            if ( ! $in_cta_section && ( $el_type === 'section' || $el_type === 'container' ) ) {
                $child_in_cta = self::section_has_cta_widget( $el );
            }

            if ( isset( $el['widgetType'] ) && $el['widgetType'] === 'text-editor' && ! empty( $el['settings']['editor'] ) ) {
                $editor_text = wp_strip_all_tags( $el['settings']['editor'] );
                $text_len = mb_strlen( $editor_text );

                // Skip if inside a CTA section, unless it's very long (>500 chars = real content)
                if ( $text_len < 100 || ( $child_in_cta && $text_len <= 500 ) ) {
                    // skip
                } else {
                    // v2.5.12: Combined score = length_score + relevance_score
                    $relevance = 0;
                    if ( ! empty( $target_keywords ) ) {
                        $text_lower = mb_strtolower( $editor_text );
                        foreach ( $target_keywords as $kw ) {
                            if ( mb_strpos( $text_lower, mb_strtolower( $kw ) ) !== false ) {
                                $relevance++;
                            }
                        }
                    }

                    // Prefer: relevance first, then length as tiebreaker
                    $is_better = false;
                    if ( $relevance > $best_relevance ) {
                        $is_better = true;
                    } elseif ( $relevance === $best_relevance && $text_len > $best_len ) {
                        $is_better = true;
                    }

                    if ( $is_better ) {
                        $best_path      = $current_path;
                        $best_len       = $text_len;
                        $best_relevance = $relevance;
                    }
                }
            }
            if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
                $child_path = array_merge( $current_path, array( 'elements' ) );
                self::walk_elementor_find_best_text_widget( $el['elements'], $child_path, $best_path, $best_len, $child_in_cta, $target_keywords, $best_relevance );
            }
        }
    }

    /**
     * Inject a phrase at the end of the most relevant existing <p> inside a widget editor HTML.
     * Instead of creating a new <p>, this appends the phrase as a sentence inside the best matching paragraph.
     *
     * @since 2.5.12
     * @param string &$editor_html  Reference to the widget editor HTML (modified in place).
     * @param string $phrase_html   The connector phrase with link HTML.
     * @param array  $keywords      Target keywords for paragraph scoring.
     * @return bool                 True if successfully injected, false if no suitable paragraph found.
     */
    private static function inject_in_best_paragraph( &$editor_html, $phrase_html, $keywords = array() ) {
        if ( ! preg_match_all( '/<p[^>]*>(.*?)<\/p>/si', $editor_html, $paras, PREG_SET_ORDER ) ) {
            return false;
        }

        // v2.5.12: Find first H2 position — skip paragraphs before it (intro zone reserved for pillar)
        $first_h2_pos = false;
        if ( preg_match( '/<h2[\s>]/i', $editor_html, $h2m, PREG_OFFSET_CAPTURE ) ) {
            $first_h2_pos = $h2m[0][1];
        }

        // v2.5.12: Detect connector phrase patterns (already injected by HTS)
        $connector_patterns = array(
            'Pour aller plus loin',
            'Retrouvez tous les détails',
            'Pour approfondir ce sujet',
            'Ce point est détaillé',
            'Nous abordons ce thème',
            'Learn more in our',
            'For a deeper dive',
            'We cover this topic',
            'Find out more about',
        );

        $best_score = -1;
        $best_para  = null;

        foreach ( $paras as $para ) {
            $p_text  = mb_strtolower( wp_strip_all_tags( html_entity_decode( $para[1], ENT_QUOTES, 'UTF-8' ) ) );
            $p_len   = mb_strlen( $p_text );

            // Skip very short paragraphs
            if ( $p_len < 50 ) continue;

            // v2.5.12: Skip paragraphs in intro zone (before first H2) — reserved for pillar link
            if ( $first_h2_pos !== false ) {
                $para_pos = strpos( $editor_html, $para[0] );
                if ( $para_pos !== false && $para_pos < $first_h2_pos ) continue;
            }

            // Skip paragraphs with 2+ existing links
            $link_count = preg_match_all( '/<a\s/i', $para[1] );
            if ( $link_count >= 2 ) continue;

            // v2.5.12: Skip paragraphs that already contain a connector phrase (= already has an HTS link)
            $has_connector = false;
            foreach ( $connector_patterns as $cp ) {
                if ( mb_stripos( $para[1], $cp ) !== false ) {
                    $has_connector = true;
                    break;
                }
            }
            if ( $has_connector ) continue;

            // Score by keyword overlap
            $score = 0;
            if ( ! empty( $keywords ) ) {
                foreach ( $keywords as $kw ) {
                    if ( mb_strpos( $p_text, mb_strtolower( $kw ) ) !== false ) {
                        $score++;
                    }
                }
            }

            // Bonus for longer paragraphs (more content = better context)
            $score += ( $p_len > 200 ) ? 0.5 : 0;

            // v2.5.12: Penalize paragraphs that already have a link (-1 score)
            if ( $link_count >= 1 ) {
                $score -= 1;
            }

            if ( $score > $best_score ) {
                $best_score = $score;
                $best_para  = $para;
            }
        }

        // Need at least some keyword match (or at least a decent paragraph if no keywords)
        if ( ! $best_para ) return false;
        if ( ! empty( $keywords ) && $best_score < 1 ) return false;

        // Inject the phrase at the end of the paragraph content (before </p>)
        $old_inner  = $best_para[1];
        $trimmed    = rtrim( $old_inner );

        // Ensure paragraph ends with punctuation before appending
        if ( ! preg_match( '/[.!?;](\s*(<\/[a-z]+>)?\s*)$/si', $trimmed ) ) {
            $trimmed .= '.';
        }

        $new_inner = $trimmed . ' ' . $phrase_html;
        $old_p     = $best_para[0];
        $new_p     = str_replace( $old_inner, $new_inner, $old_p );

        $result = str_replace( $old_p, $new_p, $editor_html );
        if ( $result === $editor_html ) return false;

        $editor_html = $result;
        return true;
    }

    /**
     * Check if an Elementor section/container contains button or CTA widgets.
     * Used to exclude CTA sections from link injection.
     *
     * @since 2.5.12
     */
    private static function section_has_cta_widget( $section ) {
        $cta_types = array( 'button', 'call-to-action', 'form', 'price-table', 'price-list' );
        if ( isset( $section['widgetType'] ) && in_array( $section['widgetType'], $cta_types, true ) ) return true;
        if ( ! empty( $section['elements'] ) && is_array( $section['elements'] ) ) {
            foreach ( $section['elements'] as $child ) {
                if ( self::section_has_cta_widget( $child ) ) return true;
            }
        }
        return false;
    }

    /**
     * Check if an Elementor section/container contains any text-editor widgets.
     */
    private static function section_has_text_widget( $section ) {
        if ( isset( $section['widgetType'] ) && $section['widgetType'] === 'text-editor' ) return true;
        if ( ! empty( $section['elements'] ) && is_array( $section['elements'] ) ) {
            foreach ( $section['elements'] as $child ) {
                if ( self::section_has_text_widget( $child ) ) return true;
            }
        }
        return false;
    }

    /**
     * Beaver Builder: add a rich-text module at the end.
     */
    private static function beaver_append_paragraph( $post_id, $paragraph_html ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) {
            return self::standard_append_paragraph( $post_id, $paragraph_html, 'beaver' );
        }

        // Find the last row → last column group → last column → add module
        $new_node_id = uniqid( 'hts_' );
        $parent_col  = null;

        // Walk backwards to find last column
        $reversed = array_reverse( $data, true );
        foreach ( $reversed as $node_id => $node ) {
            if ( isset( $node->type ) && $node->type === 'column' ) {
                $parent_col = $node_id;
                break;
            }
        }

        if ( $parent_col ) {
            $new_module = new \stdClass();
            $new_module->type     = 'module';
            $new_module->parent   = $parent_col;
            $new_module->position = 999;
            $new_module->settings = new \stdClass();
            $new_module->settings->type = 'rich-text';
            $new_module->settings->text = '<p>' . $paragraph_html . '</p>';

            $data[ $new_node_id ] = $new_module;
            update_post_meta( $post_id, '_fl_builder_data', $data );

            // Also update post_content for SEO
            $post = get_post( $post_id );
            if ( $post ) {
                $content = rtrim( $post->post_content ) . "\n" . '<p>' . $paragraph_html . '</p>';
                $upd = wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );
                if ( is_wp_error( $upd ) || 0 === $upd ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( 'Content Writer: échec sauvegarde Beaver post #' . $post_id, 'error', 'content-writer' );
                    }
                }
            }
        } else {
            // Fallback: just update post_content
            return self::standard_append_paragraph( $post_id, $paragraph_html, 'beaver' );
        }

        self::after_write( $post_id );
        return self::success( 'Paragraphe ajouté (Beaver Builder).', 'beaver' );
    }

    /**
     * Bricks: add a text-basic element at the end.
     */
    private static function bricks_append_paragraph( $post_id, $paragraph_html ) {
        $data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) {
            return self::standard_append_paragraph( $post_id, $paragraph_html, 'bricks' );
        }

        // Find the last container/section to use as parent
        $parent_id = null;
        for ( $i = count( $data ) - 1; $i >= 0; $i-- ) {
            $name = $data[ $i ]['name'] ?? '';
            if ( in_array( $name, array( 'section', 'container', 'block', 'div' ), true ) ) {
                $parent_id = $data[ $i ]['id'] ?? null;
                break;
            }
        }

        $new_element = array(
            'id'       => 'hts_' . uniqid(),
            'name'     => 'text-basic',
            'settings' => array(
                'text' => '<p>' . $paragraph_html . '</p>',
            ),
        );
        if ( $parent_id ) {
            $new_element['parent'] = $parent_id;
        }

        $data[] = $new_element;

        update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );

        // Also update post_content for SEO
        $post = get_post( $post_id );
        if ( $post ) {
            $content = rtrim( $post->post_content ) . "\n" . '<p>' . $paragraph_html . '</p>';
            $upd = wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );
            if ( is_wp_error( $upd ) || 0 === $upd ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Content Writer: échec sauvegarde Bricks post #' . $post_id, 'error', 'content-writer' );
                }
            }
        }

        self::after_write( $post_id );
        return self::success( 'Paragraphe ajouté (Bricks).', 'bricks' );
    }

    /**
     * Append a raw HTML block at the end of a post's content.
     * Unlike append_paragraph(), this does NOT wrap in <p> tags.
     * Use for multi-element blocks (FAQ sections, structured data, etc.)
     *
     * Builder support: Elementor, Beaver Builder, Bricks, Gutenberg, Classic, Divi, WPBakery.
     *
     * @since 2.5.6
     * @param int    $post_id   Post ID.
     * @param string $html      Raw HTML block to append (can contain h2, h3, p, ul, etc.)
     * @return array { success: bool, builder: string, message: string }
     */
    public static function append_html_block( $post_id, $html ) {
        $builder = self::detect_builder( $post_id );
        $post    = get_post( $post_id );
        if ( ! $post ) return self::error( 'Article introuvable.', $builder );

        switch ( $builder ) {
            case 'elementor':
                return self::elementor_append_html_block( $post_id, $html );
            case 'beaver':
                return self::beaver_append_html_block( $post_id, $html );
            case 'bricks':
                return self::bricks_append_html_block( $post_id, $html );
            case 'gutenberg':
                // Gutenberg: wrap in <!-- wp:html --> block (accepts raw HTML)
                $content = rtrim( $post->post_content ) . "\n\n<!-- wp:html -->\n" . $html . "\n<!-- /wp:html -->";
                $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $content ), $builder );
                if ( is_array( $upd ) ) return $upd;
                self::after_write( $post_id );
                return self::success( 'Bloc HTML ajouté (Gutenberg).', $builder );
            default:
                // Standard / Classic / Divi / WPBakery: raw append
                $content = rtrim( $post->post_content ) . "\n\n" . $html;
                $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $content ), $builder );
                if ( is_array( $upd ) ) return $upd;
                self::after_write( $post_id );
                return self::success( 'Bloc HTML ajouté.', $builder );
        }
    }

    /**
     * Elementor: append a text-editor widget with raw HTML (no <p> wrapping).
     */
    private static function elementor_append_html_block( $post_id, $html ) {
        $data = self::get_elementor_data( $post_id );
        if ( $data === null ) {
            // Fallback: standard append
            $post = get_post( $post_id );
            if ( ! $post ) return self::error( 'Article introuvable.', 'elementor' );
            $content = rtrim( $post->post_content ) . "\n\n" . $html;
            $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $content ), 'elementor' );
            if ( is_array( $upd ) ) return $upd;
            self::after_write( $post_id );
            return self::success( 'Bloc HTML ajouté (Elementor fallback post_content).', 'elementor' );
        }

        $new_widget = array(
            'id'         => wp_generate_uuid4(),
            'elType'     => 'widget',
            'widgetType' => 'text-editor',
            'settings'   => array( 'editor' => $html ),
            'elements'   => array(),
        );

        $appended = false;
        for ( $i = count( $data ) - 1; $i >= 0; $i-- ) {
            $el_type = $data[ $i ]['elType'] ?? '';
            if ( $el_type === 'section' || $el_type === 'container' ) {
                if ( ! empty( $data[ $i ]['elements'] ) ) {
                    $last_col_idx = count( $data[ $i ]['elements'] ) - 1;
                    $data[ $i ]['elements'][ $last_col_idx ]['elements'][] = $new_widget;
                } else {
                    $data[ $i ]['elements'][] = $new_widget;
                }
                $appended = true;
                break;
            }
        }

        if ( ! $appended ) {
            $data[] = array(
                'id'       => wp_generate_uuid4(),
                'elType'   => 'section',
                'settings' => array(),
                'elements' => array(
                    array(
                        'id'       => wp_generate_uuid4(),
                        'elType'   => 'column',
                        'settings' => array( '_column_size' => 100 ),
                        'elements' => array( $new_widget ),
                    ),
                ),
            );
        }

        self::save_elementor_data( $post_id, $data );
        self::elementor_sync_post_content( $post_id, $data );

        // Invalidate Elementor CSS cache so front-end renders fresh
        delete_post_meta( $post_id, '_elementor_css' );
        if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }

        self::after_write( $post_id );
        return self::success( 'Bloc HTML ajouté (Elementor).', 'elementor' );
    }

    /**
     * Beaver Builder: append a rich-text module with raw HTML (no <p> wrapping).
     */
    private static function beaver_append_html_block( $post_id, $html ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) {
            $post = get_post( $post_id );
            if ( ! $post ) return self::error( 'Article introuvable.', 'beaver' );
            $content = rtrim( $post->post_content ) . "\n\n" . $html;
            $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $content ), 'beaver' );
            if ( is_array( $upd ) ) return $upd;
            self::after_write( $post_id );
            return self::success( 'Bloc HTML ajouté (Beaver fallback).', 'beaver' );
        }

        $parent_col = null;
        $reversed = array_reverse( $data, true );
        foreach ( $reversed as $node_id => $node ) {
            if ( isset( $node->type ) && $node->type === 'column' ) {
                $parent_col = $node_id;
                break;
            }
        }

        if ( $parent_col ) {
            $new_node_id = uniqid( 'hts_' );
            $new_module = new \stdClass();
            $new_module->type     = 'module';
            $new_module->parent   = $parent_col;
            $new_module->position = 999;
            $new_module->settings = new \stdClass();
            $new_module->settings->type = 'rich-text';
            $new_module->settings->text = $html; // Raw HTML, no <p> wrap

            $data[ $new_node_id ] = $new_module;
            update_post_meta( $post_id, '_fl_builder_data', $data );

            // Sync post_content for SEO
            $post = get_post( $post_id );
            if ( $post ) {
                self::safe_update_post( array( 'ID' => $post_id, 'post_content' => rtrim( $post->post_content ) . "\n\n" . $html ), 'beaver' );
            }
        } else {
            $post = get_post( $post_id );
            if ( ! $post ) return self::error( 'Article introuvable.', 'beaver' );
            self::safe_update_post( array( 'ID' => $post_id, 'post_content' => rtrim( $post->post_content ) . "\n\n" . $html ), 'beaver' );
        }

        self::after_write( $post_id );
        return self::success( 'Bloc HTML ajouté (Beaver Builder).', 'beaver' );
    }

    /**
     * Bricks: append a text-basic element with raw HTML (no <p> wrapping).
     */
    private static function bricks_append_html_block( $post_id, $html ) {
        $data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) {
            $post = get_post( $post_id );
            if ( ! $post ) return self::error( 'Article introuvable.', 'bricks' );
            $content = rtrim( $post->post_content ) . "\n\n" . $html;
            $upd = self::safe_update_post( array( 'ID' => $post_id, 'post_content' => $content ), 'bricks' );
            if ( is_array( $upd ) ) return $upd;
            self::after_write( $post_id );
            return self::success( 'Bloc HTML ajouté (Bricks fallback).', 'bricks' );
        }

        $parent_id = null;
        for ( $i = count( $data ) - 1; $i >= 0; $i-- ) {
            $name = $data[ $i ]['name'] ?? '';
            if ( in_array( $name, array( 'section', 'container', 'block', 'div' ), true ) ) {
                $parent_id = $data[ $i ]['id'] ?? null;
                break;
            }
        }

        $new_element = array(
            'id'       => 'hts_' . uniqid(),
            'name'     => 'text-basic',
            'settings' => array( 'text' => $html ), // Raw HTML, no <p> wrap
        );
        if ( $parent_id ) {
            $new_element['parent'] = $parent_id;
        }
        $data[] = $new_element;

        update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );

        // Sync post_content for SEO
        $post = get_post( $post_id );
        if ( $post ) {
            self::safe_update_post( array( 'ID' => $post_id, 'post_content' => rtrim( $post->post_content ) . "\n\n" . $html ), 'bricks' );
        }

        self::after_write( $post_id );
        return self::success( 'Bloc HTML ajouté (Bricks).', 'bricks' );
    }

    private static function after_write( $post_id ) {
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            HTS_Content_Extractor::invalidate_cache( $post_id );
        }
    }

    private static function success( $message, $builder ) {
        return array( 'success' => true, 'builder' => $builder, 'message' => $message );
    }

    private static function error( $message, $builder ) {
        return array( 'success' => false, 'builder' => $builder, 'message' => $message );
    }
}
