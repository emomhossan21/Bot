<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Impact Tracker — AI Citation, Engagement & Crawl Tracking
 *
 * Tracks:
 *   - Visites IA: humans arriving from AI engines (referrer-based, JS beacon)
 *   - Scans IA:   AI bot crawls (User-Agent-based, server-side PHP)
 *   - Engagement:  active time + scroll depth (JS beacon)
 *
 * Lightweight: two custom tables, beacon + server-side, no external deps.
 *
 * @since 1.7.0
 */

class HTS_Impact_Tracker {

    const TABLE_VERSION = '1.2';
    const NONCE_ACTION  = 'hts_impact_track';

    /**
     * AI referrer patterns — domain substrings that identify AI-sourced human traffic.
     */
    private static $ai_sources = array(
        'chatgpt'   => array( 'chat.openai.com', 'chatgpt.com' ),
        'perplexity' => array( 'perplexity.ai' ),
        'claude'    => array( 'claude.ai', 'anthropic.com' ),
        'gemini'    => array( 'gemini.google.com', 'bard.google.com' ),
        'copilot'   => array( 'copilot.microsoft.com' ),
        'you'       => array( 'you.com' ),
        'phind'     => array( 'phind.com' ),
    );

    /**
     * AI bot User-Agent patterns — substring matches for known AI crawlers.
     * Each key is a slug (matches source_label), value is array of UA substrings.
     */
    private static $ai_bots = array(
        'chatgpt'    => array( 'GPTBot', 'ChatGPT-User' ),
        'perplexity' => array( 'PerplexityBot' ),
        'claude'     => array( 'ClaudeBot', 'Claude-Web', 'anthropic-ai' ),
        'gemini'     => array( 'Google-Extended', 'Gemini-Bot' ),
        'copilot'    => array( 'CopilotBot', 'BingBot/Copilot' ),
        'cohere'     => array( 'cohere-ai' ),
        'meta'       => array( 'Meta-ExternalAgent', 'FacebookBot' ),
        'apple'      => array( 'Applebot-Extended' ),
        'common'     => array( 'CCBot', 'Bytespider', 'Diffbot' ),
    );

    /**
     * Classic search engine bots — detected alongside AI bots for crawl analysis.
     * Separate from $ai_bots so we can distinguish IA vs SEO crawlers.
     */
    private static $seo_bots = array(
        'googlebot'  => array( 'Googlebot', 'Googlebot-Image', 'Googlebot-Video', 'Googlebot-News', 'Storebot-Google', 'Google-InspectionTool' ),
        'bingbot'    => array( 'bingbot', 'msnbot', 'BingPreview' ),
        'yandex'     => array( 'YandexBot', 'YandexImages', 'YandexMobileBot' ),
        'baidu'      => array( 'Baiduspider' ),
        'duckduckgo' => array( 'DuckDuckBot' ),
        'semrush'    => array( 'SemrushBot' ),
        'ahrefs'     => array( 'AhrefsBot' ),
        'moz'        => array( 'DotBot', 'rogerbot' ),
        'screaming'  => array( 'Screaming Frog' ),
    );

    /**
     * Bot category map.
     */
    const BOT_CAT_AI  = 'ai';
    const BOT_CAT_SEO = 'seo';

    /* ══════════════════════════════════════════════════════════════
     *  INIT
     * ══════════════════════════════════════════════════════════════ */

    public function init() {
        // Create / upgrade tables
        add_action( 'admin_init', array( $this, 'maybe_create_table' ) );

        // Front-end tracking script (JS beacon for human visits)
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_tracker' ) );

        // AJAX endpoints (public: nopriv for visitors, priv for logged-in)
        add_action( 'wp_ajax_hts_track_visit',        array( $this, 'ajax_track' ) );
        add_action( 'wp_ajax_nopriv_hts_track_visit',  array( $this, 'ajax_track' ) );

        // Server-side bot detection (runs on every front-end page load)
        add_action( 'template_redirect', array( $this, 'detect_ai_bot' ), 1 );

        // Admin AJAX: Impact data for SEO Panel
        add_action( 'wp_ajax_hts_impact_data', array( $this, 'ajax_impact_data' ) );

        // Cleanup old data (> 13 months) via weekly cron
        add_action( 'hts_impact_cleanup', array( $this, 'cleanup_old_data' ) );
        if ( ! wp_next_scheduled( 'hts_impact_cleanup' ) ) {
            wp_schedule_event( time() + 3600, 'weekly', 'hts_impact_cleanup' );
        }
    }

    /* ══════════════════════════════════════════════════════════════
     *  TABLE CREATION
     * ══════════════════════════════════════════════════════════════ */

    public function maybe_create_table() {
        $installed = get_option( 'hts_impact_table_version', '0' );
        if ( version_compare( $installed, self::TABLE_VERSION, '>=' ) ) return;

        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        // Visits table (human visits)
        $visits_table = $wpdb->prefix . 'hts_visits';
        $sql1 = "CREATE TABLE {$visits_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            visited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            referrer VARCHAR(500) DEFAULT '',
            ai_source VARCHAR(30) DEFAULT '',
            active_time INT UNSIGNED DEFAULT 0 COMMENT 'seconds',
            scroll_depth TINYINT UNSIGNED DEFAULT 0 COMMENT '0-100 percent',
            is_ai TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_post_date (post_id, visited_at),
            KEY idx_ai_date (is_ai, visited_at),
            KEY idx_post_ai (post_id, is_ai, visited_at)
        ) {$charset};";

        // Crawls table (AI + SEO bot scans)
        $crawls_table = $wpdb->prefix . 'hts_crawls';
        $sql2 = "CREATE TABLE {$crawls_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            crawled_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            bot_source VARCHAR(30) NOT NULL DEFAULT '',
            bot_category VARCHAR(10) NOT NULL DEFAULT 'ai' COMMENT 'ai or seo',
            status_code SMALLINT UNSIGNED NOT NULL DEFAULT 200,
            response_ms INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'server response time ms',
            user_agent VARCHAR(500) DEFAULT '',
            PRIMARY KEY (id),
            KEY idx_post_date (post_id, crawled_at),
            KEY idx_bot_date (bot_source, crawled_at),
            KEY idx_post_bot (post_id, bot_source, crawled_at),
            KEY idx_cat_date (bot_category, crawled_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql1 );
        dbDelta( $sql2 );

        update_option( 'hts_impact_table_version', self::TABLE_VERSION, false );
    }

    private function table() {
        global $wpdb;
        return $wpdb->prefix . 'hts_visits';
    }

    private function crawl_table() {
        global $wpdb;
        return $wpdb->prefix . 'hts_crawls';
    }

    /* ══════════════════════════════════════════════════════════════
     *  BOT DETECTION (server-side, template_redirect)
     * ══════════════════════════════════════════════════════════════ */

    /**
     * Detect AI + SEO bots via User-Agent on every singular page load.
     * Logs to hts_crawls table with bot_category, status_code, response_ms.
     * Rate-limited: max 1 crawl per bot+post per hour.
     */
    public function detect_ai_bot() {
        if ( is_admin() || ! is_singular() ) return;
        if ( get_option( 'hts_module_impact_tracker', '1' ) !== '1' ) return;

        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ( empty( $ua ) ) return;

        // Try AI bots first, then SEO bots
        $bot_source   = $this->match_ai_bot( $ua );
        $bot_category = self::BOT_CAT_AI;

        if ( ! $bot_source ) {
            $bot_source   = $this->match_seo_bot( $ua );
            $bot_category = self::BOT_CAT_SEO;
        }

        if ( ! $bot_source ) return;

        $post = get_queried_object();
        if ( ! $post || ! isset( $post->ID ) || $post->post_status !== 'publish' ) return;

        // Rate limit: max 1 crawl per bot+post per hour
        $rl_key = 'hts_cr_' . substr( md5( $bot_source . '|' . $post->ID ), 0, 12 );
        if ( get_transient( $rl_key ) ) return;
        set_transient( $rl_key, 1, 3600 );

        // Measure response time (time since PHP started)
        $response_ms = 0;
        if ( defined( 'HTS_REQUEST_START' ) ) {
            $response_ms = (int) round( ( microtime( true ) - HTS_REQUEST_START ) * 1000 );
        } elseif ( isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ) {
            $response_ms = (int) round( ( microtime( true ) - $_SERVER['REQUEST_TIME_FLOAT'] ) * 1000 );
        }

        // Status code: use what WP will send (at template_redirect, it's usually 200)
        $status_code = http_response_code();
        if ( ! $status_code ) $status_code = 200;

        global $wpdb;
        $wpdb->insert( $this->crawl_table(), array(
            'post_id'      => $post->ID,
            'crawled_at'   => current_time( 'mysql' ),
            'bot_source'   => $bot_source,
            'bot_category' => $bot_category,
            'status_code'  => $status_code,
            'response_ms'  => $response_ms,
            'user_agent'   => mb_substr( $ua, 0, 500 ),
        ), array( '%d', '%s', '%s', '%s', '%d', '%d', '%s' ) );
    }

    /**
     * Match User-Agent against known AI bot patterns.
     *
     * @param string $ua User-Agent string.
     * @return string|false Bot source slug or false.
     */
    public function match_ai_bot( $ua ) {
        foreach ( self::$ai_bots as $slug => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( stripos( $ua, $pattern ) !== false ) {
                    return $slug;
                }
            }
        }
        return false;
    }

    /**
     * Match User-Agent against known SEO/search engine bot patterns.
     *
     * @param string $ua User-Agent string.
     * @return string|false Bot source slug or false.
     */
    public function match_seo_bot( $ua ) {
        foreach ( self::$seo_bots as $slug => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( stripos( $ua, $pattern ) !== false ) {
                    return $slug;
                }
            }
        }
        return false;
    }

    /**
     * Get the category of a bot slug.
     *
     * @param string $slug Bot source slug.
     * @return string 'ai' or 'seo'.
     */
    public static function bot_category( $slug ) {
        if ( isset( self::$ai_bots[ $slug ] ) )  return self::BOT_CAT_AI;
        if ( isset( self::$seo_bots[ $slug ] ) ) return self::BOT_CAT_SEO;
        return self::BOT_CAT_AI; // default
    }

    /* ══════════════════════════════════════════════════════════════
     *  FRONT-END TRACKING SCRIPT (human visits)
     * ══════════════════════════════════════════════════════════════ */

    public function enqueue_tracker() {
        if ( ! is_singular() ) return;
        if ( is_admin() ) return;
        $post = get_queried_object();
        if ( ! $post || $post->post_status !== 'publish' ) return;
        if ( get_option( 'hts_module_impact_tracker', '1' ) !== '1' ) return;

        wp_enqueue_script(
            'hts-impact-tracker',
            HTS__PLUGIN_URL . 'public/js/hts-tracker' . HTS__MIN . '.js',
            array(),
            HTS__VERSION,
            true
        );

        wp_localize_script( 'hts-impact-tracker', 'htsTrack', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'postId'  => $post->ID,
            'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
        ) );
    }

    /* ══════════════════════════════════════════════════════════════
     *  AJAX: RECORD VISIT (human, beacon-based)
     * ══════════════════════════════════════════════════════════════ */

    public function ajax_track() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( 'nonce' );
        }

        $post_id      = isset( $_POST['post_id'] )      ? absint( $_POST['post_id'] )      : 0;
        $active_time   = isset( $_POST['active_time'] )   ? absint( $_POST['active_time'] )   : 0;
        $scroll_depth  = isset( $_POST['scroll_depth'] )  ? min( 100, absint( $_POST['scroll_depth'] ) ) : 0;
        $referrer      = isset( $_POST['referrer'] )      ? esc_url_raw( $_POST['referrer'] ) : '';

        if ( ! $post_id || ! get_post( $post_id ) ) {
            wp_send_json_error( 'invalid_post' );
        }

        // Rate limit: max 1 visit per IP+post per 30 minutes
        $ip_hash = md5( $this->get_visitor_ip() . '|' . $post_id );
        $transient_key = 'hts_vrl_' . substr( $ip_hash, 0, 16 );
        if ( get_transient( $transient_key ) ) {
            $this->update_engagement( $post_id, $referrer, $active_time, $scroll_depth );
            wp_send_json_success( 'updated' );
        }
        set_transient( $transient_key, 1, 1800 );

        $ai_source = $this->detect_ai_source( $referrer );
        $is_ai     = $ai_source !== '' ? 1 : 0;

        global $wpdb;
        $wpdb->insert( $this->table(), array(
            'post_id'      => $post_id,
            'visited_at'   => current_time( 'mysql' ),
            'referrer'     => mb_substr( $referrer, 0, 500 ),
            'ai_source'    => $ai_source,
            'active_time'  => $active_time,
            'scroll_depth' => $scroll_depth,
            'is_ai'        => $is_ai,
        ), array( '%d', '%s', '%s', '%s', '%d', '%d', '%d' ) );

        wp_send_json_success( 'tracked' );
    }

    private function update_engagement( $post_id, $referrer, $active_time, $scroll_depth ) {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$this->table()} SET active_time = GREATEST(active_time, %d), scroll_depth = GREATEST(scroll_depth, %d)
             WHERE post_id = %d AND referrer = %s AND visited_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
             ORDER BY id DESC LIMIT 1",
            $active_time, $scroll_depth, $post_id, mb_substr( $referrer, 0, 500 )
        ) );
    }

    public function detect_ai_source( $referrer ) {
        if ( empty( $referrer ) ) return '';
        $ref_lower = strtolower( $referrer );
        foreach ( self::$ai_sources as $slug => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( strpos( $ref_lower, $pattern ) !== false ) {
                    return $slug;
                }
            }
        }
        return '';
    }

    private function get_visitor_ip() {
        $headers = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' );
        foreach ( $headers as $h ) {
            if ( ! empty( $_SERVER[ $h ] ) ) {
                $ip = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ) );
                $clean = trim( $ip[0] );
                if ( filter_var( $clean, FILTER_VALIDATE_IP ) ) {
                    return $clean;
                }
            }
        }
        return '0.0.0.0';
    }

    /* ══════════════════════════════════════════════════════════════
     *  QUERY METHODS — VISITS (human)
     * ══════════════════════════════════════════════════════════════ */

    public function get_post_stats( $post_id ) {
        global $wpdb;
        $table = $this->table();

        $totals = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total_visits, SUM(is_ai) AS ai_visits,
                    AVG(active_time) AS avg_active_time, AVG(scroll_depth) AS avg_scroll_depth
            FROM {$table} WHERE post_id = %d", $post_id
        ) );

        $d30 = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total_30d, SUM(is_ai) AS ai_30d
             FROM {$table} WHERE post_id = %d AND visited_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $post_id
        ) );

        $sources = $wpdb->get_results( $wpdb->prepare(
            "SELECT ai_source, COUNT(*) AS cnt FROM {$table}
             WHERE post_id = %d AND is_ai = 1 AND visited_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY ai_source ORDER BY cnt DESC", $post_id
        ) );
        $ai_sources = array();
        foreach ( $sources as $s ) { $ai_sources[ $s->ai_source ] = (int) $s->cnt; }

        // Crawl stats for this post
        $crawl_stats = $this->get_post_crawl_stats( $post_id );

        return array(
            'total_visits'     => (int) ( $totals->total_visits ?? 0 ),
            'ai_visits'        => (int) ( $totals->ai_visits ?? 0 ),
            'avg_active_time'  => round( (float) ( $totals->avg_active_time ?? 0 ) ),
            'avg_scroll_depth' => round( (float) ( $totals->avg_scroll_depth ?? 0 ) ),
            'total_visits_30d' => (int) ( $d30->total_30d ?? 0 ),
            'ai_visits_30d'    => (int) ( $d30->ai_30d ?? 0 ),
            'ai_sources'       => $ai_sources,
            'crawls'           => $crawl_stats,
        );
    }

    public function get_site_stats() {
        // Request-level cache — called 2 times per cockpit load
        static $cached = null;
        if ( $cached !== null ) return $cached;

        global $wpdb;
        $table = $this->table();

        $this_month_start = gmdate( 'Y-m-01 00:00:00' );
        $last_month_start = gmdate( 'Y-m-01 00:00:00', strtotime( 'first day of last month' ) );
        $last_month_end   = gmdate( 'Y-m-t 23:59:59', strtotime( 'last month' ) );

        $tm = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total, SUM(is_ai) AS ai FROM {$table} WHERE visited_at >= %s",
            $this_month_start
        ) );
        $lm = $wpdb->get_row( $wpdb->prepare(
            "SELECT SUM(is_ai) AS ai FROM {$table} WHERE visited_at >= %s AND visited_at <= %s",
            $last_month_start, $last_month_end
        ) );

        $ai_this = (int) ( $tm->ai ?? 0 );
        $ai_last = (int) ( $lm->ai ?? 0 );
        $trend   = $ai_last > 0 ? round( ( $ai_this - $ai_last ) / $ai_last * 100, 1 ) : ( $ai_this > 0 ? 100 : 0 );

        $top_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, COUNT(*) AS ai_visits FROM {$table}
             WHERE is_ai = 1 AND visited_at >= %s GROUP BY post_id ORDER BY ai_visits DESC LIMIT 3",
            $this_month_start
        ) );
        $top_articles = array();
        foreach ( $top_rows as $r ) {
            $top_articles[] = array(
                'post_id'   => (int) $r->post_id,
                'title'     => get_the_title( $r->post_id ),
                'ai_visits' => (int) $r->ai_visits,
            );
        }

        // Site-wide crawl stats
        $crawl_site = $this->get_site_crawl_stats();

        $cached = array(
            'ai_this_month'    => $ai_this,
            'ai_last_month'    => $ai_last,
            'trend_pct'        => $trend,
            'total_this_month' => (int) ( $tm->total ?? 0 ),
            'top_articles'     => $top_articles,
            'crawls'           => $crawl_site,
        );
        return $cached;
    }

    /* ══════════════════════════════════════════════════════════════
     *  QUERY METHODS — CRAWLS (AI bots)
     * ══════════════════════════════════════════════════════════════ */

    /**
     * Crawl stats for a single post — enriched with categories + response time.
     */
    public function get_post_crawl_stats( $post_id ) {
        global $wpdb;
        $ct = $this->crawl_table();

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct} WHERE post_id = %d", $post_id
        ) );
        $d30 = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct} WHERE post_id = %d AND crawled_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $post_id
        ) );
        $last_crawl = $wpdb->get_var( $wpdb->prepare(
            "SELECT crawled_at FROM {$ct} WHERE post_id = %d ORDER BY crawled_at DESC LIMIT 1", $post_id
        ) );

        // Bot breakdown (30 days) with category
        $bots = $wpdb->get_results( $wpdb->prepare(
            "SELECT bot_source, bot_category, COUNT(*) AS cnt FROM {$ct}
             WHERE post_id = %d AND crawled_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY bot_source, bot_category ORDER BY cnt DESC", $post_id
        ) );
        $bot_sources = array();
        $cat_totals  = array( 'ai' => 0, 'seo' => 0 );
        foreach ( $bots as $b ) {
            $cat = $b->bot_category ?: self::bot_category( $b->bot_source );
            $bot_sources[ $b->bot_source ] = array(
                'count'    => (int) $b->cnt,
                'category' => $cat,
            );
            if ( isset( $cat_totals[ $cat ] ) ) {
                $cat_totals[ $cat ] += (int) $b->cnt;
            }
        }

        // Avg response time for this post
        $avg_ms = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT AVG(response_ms) FROM {$ct} WHERE post_id = %d AND response_ms > 0 AND crawled_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $post_id
        ) );

        return array(
            'total'        => $total,
            'last_30d'     => $d30,
            'last_crawl'   => $last_crawl,
            'bot_sources'  => $bot_sources,
            'cat_totals'   => $cat_totals,
            'avg_ms'       => $avg_ms,
        );
    }

    /**
     * Site-wide crawl stats — enriched with categories, response times, errors.
     */
    public function get_site_crawl_stats() {
        global $wpdb;
        $ct = $this->crawl_table();

        $this_month = gmdate( 'Y-m-01 00:00:00' );
        $last_month_start = gmdate( 'Y-m-01 00:00:00', strtotime( 'first day of last month' ) );
        $last_month_end   = gmdate( 'Y-m-t 23:59:59', strtotime( 'last month' ) );

        $tm = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct} WHERE crawled_at >= %s", $this_month
        ) );
        $lm = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct} WHERE crawled_at >= %s AND crawled_at <= %s",
            $last_month_start, $last_month_end
        ) );

        $trend = $lm > 0 ? round( ( $tm - $lm ) / $lm * 100, 1 ) : ( $tm > 0 ? 100 : 0 );

        // Bot breakdown this month (all bots)
        $bots = $wpdb->get_results( $wpdb->prepare(
            "SELECT bot_source, bot_category, COUNT(*) AS cnt FROM {$ct} WHERE crawled_at >= %s GROUP BY bot_source, bot_category ORDER BY cnt DESC",
            $this_month
        ) );
        $bot_sources = array();
        $cat_totals  = array( 'ai' => 0, 'seo' => 0 );
        foreach ( $bots as $b ) {
            $bot_sources[ $b->bot_source ] = array(
                'count'    => (int) $b->cnt,
                'category' => $b->bot_category ?: self::bot_category( $b->bot_source ),
            );
            $cat = $b->bot_category ?: self::bot_category( $b->bot_source );
            if ( isset( $cat_totals[ $cat ] ) ) {
                $cat_totals[ $cat ] += (int) $b->cnt;
            }
        }

        // Top scanned articles
        $top = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, COUNT(*) AS scans FROM {$ct} WHERE crawled_at >= %s
             GROUP BY post_id ORDER BY scans DESC LIMIT 5", $this_month
        ) );
        $top_scanned = array();
        foreach ( $top as $r ) {
            $top_scanned[] = array(
                'post_id' => (int) $r->post_id,
                'title'   => get_the_title( $r->post_id ),
                'scans'   => (int) $r->scans,
            );
        }

        // Response time stats (30 days, only rows with response_ms > 0)
        $d30_cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
        $perf = $wpdb->get_row( $wpdb->prepare(
            "SELECT AVG(response_ms) AS avg_ms, MAX(response_ms) AS max_ms, MIN(response_ms) AS min_ms
             FROM {$ct} WHERE crawled_at > %s AND response_ms > 0",
            $d30_cutoff
        ) );

        // HTTP status breakdown (30 days)
        $statuses = $wpdb->get_results( $wpdb->prepare(
            "SELECT status_code, COUNT(*) AS cnt FROM {$ct}
             WHERE crawled_at > %s
             GROUP BY status_code ORDER BY cnt DESC",
            $d30_cutoff
        ) );
        $status_breakdown = array();
        foreach ( $statuses as $s ) {
            $status_breakdown[ (int) $s->status_code ] = (int) $s->cnt;
        }

        // Crawl frequency: daily counts last 30 days by category
        $daily_crawls = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(crawled_at) AS day, bot_category, COUNT(*) AS cnt
             FROM {$ct} WHERE crawled_at > %s
             GROUP BY DATE(crawled_at), bot_category ORDER BY day ASC",
            $d30_cutoff
        ) );

        // Pages never crawled (published, with 0 crawls)
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $uncrawled_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
             AND p.ID NOT IN (SELECT DISTINCT post_id FROM {$ct})"
        );
        $total_published = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}"
        );

        return array(
            'this_month'       => $tm,
            'last_month'       => $lm,
            'trend_pct'        => $trend,
            'bot_sources'      => $bot_sources,
            'cat_totals'       => $cat_totals,
            'top_scanned'      => $top_scanned,
            'response_avg_ms'  => (int) round( (float) ( $perf->avg_ms ?? 0 ) ),
            'response_max_ms'  => (int) ( $perf->max_ms ?? 0 ),
            'status_breakdown' => $status_breakdown,
            'daily_crawls'     => $daily_crawls,
            'uncrawled_count'  => $uncrawled_count,
            'total_published'  => $total_published,
        );
    }

    /* ══════════════════════════════════════════════════════════════
     *  AJAX: IMPACT DATA FOR SEO PANEL
     * ══════════════════════════════════════════════════════════════ */

    public function ajax_impact_data() {
        check_ajax_referer( 'hts_panel_score', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        $post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
        if ( ! $post_id ) wp_send_json_error( 'missing_post_id' );
        $stats = $this->get_post_stats( $post_id );
        wp_send_json_success( $stats );
    }

    /* ══════════════════════════════════════════════════════════════
     *  ANALYTICS DATA — Centralized query for any period
     * ══════════════════════════════════════════════════════════════ */

    /**
     * Get all analytics data for a given period (in days).
     * Used by the Analytics page (server-side initial load + AJAX period switch).
     *
     * @param int $days Number of days to look back (7, 30, 90, 365).
     * @return array All analytics sections as associative array.
     */
    public function get_analytics_data( $days = 30 ) {
        // Request-level cache
        static $cache = array();
        if ( isset( $cache[ $days ] ) ) return $cache[ $days ];

        global $wpdb;
        $vt      = $this->table();
        $ct      = $this->crawl_table();
        $days    = max( 1, (int) $days );
        $cutoff  = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

        // ── 1. Engagement KPI ──
        $eng = $wpdb->get_row( $wpdb->prepare(
            "SELECT AVG(active_time) AS avg_time, AVG(scroll_depth) AS avg_scroll, COUNT(*) AS total
             FROM {$vt} WHERE visited_at > %s",
            $cutoff
        ) );
        $bounces = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$vt} WHERE visited_at > %s AND active_time < 15",
            $cutoff
        ) );
        $total_visits = (int) ( $eng->total ?? 0 );
        $engagement = array(
            'avg_time'    => round( (float) ( $eng->avg_time ?? 0 ) ),
            'avg_scroll'  => round( (float) ( $eng->avg_scroll ?? 0 ) ),
            'total'       => $total_visits,
            'bounce_rate' => $total_visits > 0 ? round( $bounces / $total_visits * 100 ) : 0,
        );

        // ── 2. AI visits for this period ──
        $ai_total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$vt} WHERE is_ai = 1 AND visited_at > %s",
            $cutoff
        ) );

        // Previous period of same length for trend
        $prev_cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-" . ( $days * 2 ) . " days" ) );
        $ai_prev = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$vt} WHERE is_ai = 1 AND visited_at > %s AND visited_at <= %s",
            $prev_cutoff, $cutoff
        ) );
        $ai_trend = $ai_prev > 0 ? round( ( $ai_total - $ai_prev ) / $ai_prev * 100, 1 ) : ( $ai_total > 0 ? 100 : 0 );

        // ── 3. AI source breakdown ──
        $src_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ai_source, COUNT(*) AS cnt FROM {$vt}
             WHERE is_ai = 1 AND visited_at > %s
             GROUP BY ai_source ORDER BY cnt DESC",
            $cutoff
        ) );

        // ── 4. Top articles by AI visits ──
        $top_ai = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, COUNT(*) AS ai_visits FROM {$vt}
             WHERE is_ai = 1 AND visited_at > %s
             GROUP BY post_id ORDER BY ai_visits DESC LIMIT 5",
            $cutoff
        ) );
        $top_articles = array();
        foreach ( $top_ai as $r ) {
            $top_articles[] = array(
                'post_id'   => (int) $r->post_id,
                'title'     => get_the_title( $r->post_id ),
                'ai_visits' => (int) $r->ai_visits,
            );
        }

        // ── 5. Top engaged articles (min 3 visits) ──
        $top_engaged = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, AVG(active_time) AS avg_time, AVG(scroll_depth) AS avg_scroll,
                    COUNT(*) AS visits, SUM(is_ai) AS ai_visits
             FROM {$vt}
             WHERE visited_at > %s
             GROUP BY post_id HAVING visits >= 3
             ORDER BY avg_time DESC LIMIT 10",
            $cutoff
        ) );
        $engaged_data = array();
        foreach ( $top_engaged as $row ) {
            $engaged_data[] = array(
                'post_id'    => (int) $row->post_id,
                'title'      => get_the_title( $row->post_id ),
                'visits'     => (int) $row->visits,
                'ai_visits'  => (int) $row->ai_visits,
                'avg_time'   => round( (float) $row->avg_time ),
                'avg_scroll' => round( (float) $row->avg_scroll ),
            );
        }

        // ── 6. Daily visits (for chart) ──
        $daily_data = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(visited_at) AS day, COUNT(*) AS total, SUM(is_ai) AS ai
             FROM {$vt}
             WHERE visited_at > %s
             GROUP BY DATE(visited_at) ORDER BY day ASC",
            $cutoff
        ) );
        $daily = array();
        foreach ( $daily_data as $dd ) {
            $daily[] = array(
                'day'   => $dd->day,
                'total' => (int) $dd->total,
                'ai'    => (int) ( $dd->ai ?? 0 ),
            );
        }

        // ── 7. Stale posts (> 12 months, period-independent) ──
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $stale_posts = $wpdb->get_results(
            "SELECT ID, post_title, post_modified
             FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type {$pt_in}
             AND post_modified < DATE_SUB(NOW(), INTERVAL 12 MONTH)
             ORDER BY post_modified ASC LIMIT 15"
        );
        $stale = array();
        foreach ( $stale_posts as $sp ) {
            $stale[] = array(
                'ID'         => (int) $sp->ID,
                'title'      => $sp->post_title,
                'months_ago' => (int) round( ( time() - strtotime( $sp->post_modified ) ) / ( 30 * DAY_IN_SECONDS ) ),
                'edit_url'   => get_edit_post_link( $sp->ID, 'raw' ),
            );
        }

        // ── 8. Crawl stats for this period ──
        $crawl_total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct} WHERE crawled_at > %s", $cutoff
        ) );
        $crawl_prev = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct} WHERE crawled_at > %s AND crawled_at <= %s",
            $prev_cutoff, $cutoff
        ) );
        $crawl_trend = $crawl_prev > 0 ? round( ( $crawl_total - $crawl_prev ) / $crawl_prev * 100, 1 ) : ( $crawl_total > 0 ? 100 : 0 );

        // Bot breakdown
        $bots = $wpdb->get_results( $wpdb->prepare(
            "SELECT bot_source, bot_category, COUNT(*) AS cnt FROM {$ct}
             WHERE crawled_at > %s GROUP BY bot_source, bot_category ORDER BY cnt DESC",
            $cutoff
        ) );
        $bot_sources = array();
        $cat_totals  = array( 'ai' => 0, 'seo' => 0 );
        foreach ( $bots as $b ) {
            $cat = $b->bot_category ?: self::bot_category( $b->bot_source );
            $bot_sources[ $b->bot_source ] = array(
                'count'    => (int) $b->cnt,
                'category' => $cat,
                'label'    => self::source_label( $b->bot_source ),
                'color'    => self::source_color( $b->bot_source ),
            );
            if ( isset( $cat_totals[ $cat ] ) ) {
                $cat_totals[ $cat ] += (int) $b->cnt;
            }
        }

        // Top scanned pages
        $top_scanned_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, COUNT(*) AS scans FROM {$ct}
             WHERE crawled_at > %s GROUP BY post_id ORDER BY scans DESC LIMIT 5",
            $cutoff
        ) );
        $top_scanned = array();
        foreach ( $top_scanned_rows as $r ) {
            $top_scanned[] = array(
                'post_id' => (int) $r->post_id,
                'title'   => get_the_title( $r->post_id ),
                'scans'   => (int) $r->scans,
            );
        }

        // Response time + status breakdown
        $perf = $wpdb->get_row( $wpdb->prepare(
            "SELECT AVG(response_ms) AS avg_ms, MAX(response_ms) AS max_ms
             FROM {$ct} WHERE crawled_at > %s AND response_ms > 0",
            $cutoff
        ) );
        $statuses = $wpdb->get_results( $wpdb->prepare(
            "SELECT status_code, COUNT(*) AS cnt FROM {$ct}
             WHERE crawled_at > %s GROUP BY status_code ORDER BY cnt DESC",
            $cutoff
        ) );
        $status_breakdown = array();
        foreach ( $statuses as $s ) {
            $status_breakdown[ (int) $s->status_code ] = (int) $s->cnt;
        }

        // Crawl coverage
        $uncrawled_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
             AND p.ID NOT IN (SELECT DISTINCT post_id FROM {$ct})"
        );
        $total_published = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}"
        );

        // ── 9. GSC data (if connected) ──
        $gsc_data = null;
        if ( class_exists( 'HTS_GSC_Connect' ) && get_option( 'hts_module_gsc', '1' ) === '1' ) {
            $gsc = new HTS_GSC_Connect();
            if ( $gsc->is_connected() && $gsc->has_data() ) {
                $gsc_data = $gsc->get_site_data( $days );
            }
        }

        $cache[ $days ] = array(
            'days'        => $days,
            'engagement'  => $engagement,
            'ai_total'    => $ai_total,
            'ai_trend'    => $ai_trend,
            'ai_sources'  => $src_rows ? array_map( function( $r ) {
                return array( 'source' => $r->ai_source, 'count' => (int) $r->cnt );
            }, $src_rows ) : array(),
            'top_articles'  => $top_articles,
            'top_engaged'   => $engaged_data,
            'daily'         => $daily,
            'stale_posts'   => $stale,
            'crawl'         => array(
                'total'            => $crawl_total,
                'trend'            => $crawl_trend,
                'cat_totals'       => $cat_totals,
                'bot_sources'      => $bot_sources,
                'top_scanned'      => $top_scanned,
                'response_avg_ms'  => (int) round( (float) ( $perf->avg_ms ?? 0 ) ),
                'response_max_ms'  => (int) ( $perf->max_ms ?? 0 ),
                'status_breakdown' => $status_breakdown,
                'uncrawled_count'  => $uncrawled_count,
                'total_published'  => $total_published,
            ),
            'gsc' => $gsc_data,
        );
        return $cache[ $days ];
    }

    /* ══════════════════════════════════════════════════════════════
     *  CLEANUP
     * ══════════════════════════════════════════════════════════════ */

    public function cleanup_old_data() {
        global $wpdb;
        $cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-13 months' ) );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$this->table()} WHERE visited_at < %s", $cutoff
        ) );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$this->crawl_table()} WHERE crawled_at < %s", $cutoff
        ) );
    }

    /* ══════════════════════════════════════════════════════════════
     *  HELPERS — LABELS
     * ══════════════════════════════════════════════════════════════ */

    public static function source_label( $slug ) {
        $labels = array(
            'chatgpt'    => 'ChatGPT',
            'perplexity' => 'Perplexity',
            'claude'     => 'Claude',
            'gemini'     => 'Gemini',
            'copilot'    => 'Copilot',
            'cohere'     => 'Cohere',
            'meta'       => 'Meta AI',
            'apple'      => 'Apple',
            'common'     => 'Autres IA',
            'you'        => 'You.com',
            'phind'      => 'Phind',
            'googlebot'  => 'Googlebot',
            'bingbot'    => 'Bingbot',
            'yandex'     => 'Yandex',
            'baidu'      => 'Baidu',
            'duckduckgo' => 'DuckDuckGo',
            'semrush'    => 'SEMrush',
            'ahrefs'     => 'Ahrefs',
            'moz'        => 'Moz',
            'screaming'  => 'Screaming Frog',
        );
        return $labels[ $slug ] ?? ucfirst( $slug );
    }

    /**
     * Color for a bot source (for charts).
     */
    public static function source_color( $slug ) {
        $colors = array(
            'chatgpt'    => '#10a37f',
            'perplexity' => '#20b8cd',
            'claude'     => '#d97706',
            'gemini'     => '#4285f4',
            'copilot'    => '#7c3aed',
            'cohere'     => '#ef4444',
            'meta'       => '#1877f2',
            'apple'      => '#333333',
            'common'     => '#9ca3af',
            'you'        => '#f97316',
            'phind'      => '#16a34a',
            'googlebot'  => '#ea4335',
            'bingbot'    => '#00809d',
            'yandex'     => '#fc0',
            'baidu'      => '#2932e1',
            'duckduckgo' => '#de5833',
            'semrush'    => '#ff642d',
            'ahrefs'     => '#1a56db',
            'moz'        => '#52a8e8',
            'screaming'  => '#55b849',
        );
        return $colors[ $slug ] ?? '#6366f1';
    }

    public static function ai_source_slugs() {
        return array_keys( self::$ai_sources );
    }

    public static function ai_bot_slugs() {
        return array_keys( self::$ai_bots );
    }

    public static function seo_bot_slugs() {
        return array_keys( self::$seo_bots );
    }

    public static function all_bot_slugs() {
        return array_merge( array_keys( self::$ai_bots ), array_keys( self::$seo_bots ) );
    }

    /**
     * Insights: cross-analysis of crawl data vs SEO scores.
     * Returns actionable insights for the dashboard.
     */
    public function get_crawl_insights() {
        global $wpdb;
        $ct = $this->crawl_table();
        $insights = array();

        // 1. Good SEO score but never crawled → maillage problem
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $uncrawled_good = $wpdb->get_results(
            "SELECT p.ID, p.post_title
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_seo_score'
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
             AND CAST(pm.meta_value AS UNSIGNED) >= 70
             AND p.ID NOT IN (SELECT DISTINCT post_id FROM {$ct})
             LIMIT 5"
        );
        if ( ! empty( $uncrawled_good ) ) {
            $titles = array();
            foreach ( $uncrawled_good as $p ) { $titles[] = $p->post_title; }
            $insights[] = array(
                'type'    => 'warning',
                'icon'    => 'alert-triangle',
                'title'   => 'Bon score mais jamais crawl&eacute;',
                'desc'    => count( $uncrawled_good ) . ' article(s) bien optimis&eacute;(s) n\'ont jamais &eacute;t&eacute; visit&eacute;(s) par les robots. V&eacute;rifiez le maillage interne.',
                'posts'   => $uncrawled_good,
            );
        }

        // 2. Crawled by AI bots but not cited → optimize GEO
        $vt = $this->table();
        $d30_cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
        $ai_crawled_not_cited = $wpdb->get_results( $wpdb->prepare(
            "SELECT c.post_id, COUNT(*) AS ai_crawls, COALESCE(v.ai_visits, 0) AS ai_visits
             FROM {$ct} c
             LEFT JOIN (
                SELECT post_id, COUNT(*) AS ai_visits FROM {$vt} WHERE is_ai = 1 GROUP BY post_id
             ) v ON c.post_id = v.post_id
             WHERE c.bot_category = 'ai' AND c.crawled_at > %s
             GROUP BY c.post_id
             HAVING ai_crawls >= 3 AND ai_visits = 0
             ORDER BY ai_crawls DESC LIMIT 5",
            $d30_cutoff
        ) );
        if ( ! empty( $ai_crawled_not_cited ) ) {
            $posts = array();
            foreach ( $ai_crawled_not_cited as $r ) {
                $posts[] = (object) array( 'ID' => $r->post_id, 'post_title' => get_the_title( $r->post_id ) );
            }
            $insights[] = array(
                'type'  => 'info',
                'icon'  => 'bot',
                'title' => 'Crawl&eacute; par les IA mais pas cit&eacute;',
                'desc'  => count( $ai_crawled_not_cited ) . ' article(s) sont crawl&eacute;(s) par les robots IA mais ne g&eacute;n&egrave;rent pas de trafic IA. Optimisez le score GEO.',
                'posts' => $posts,
            );
        }

        // 3. HTTP errors in crawls
        $errors = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ct}
             WHERE crawled_at > %s
             AND status_code >= 400",
            $d30_cutoff
        ) );
        if ( $errors > 0 ) {
            $error_pages = $wpdb->get_results( $wpdb->prepare(
                "SELECT post_id, status_code, COUNT(*) AS cnt FROM {$ct}
                 WHERE crawled_at > %s AND status_code >= 400
                 GROUP BY post_id, status_code ORDER BY cnt DESC LIMIT 5",
                $d30_cutoff
            ) );
            $insights[] = array(
                'type'  => 'error',
                'icon'  => 'x-circle',
                'title' => $errors . ' erreur(s) HTTP d&eacute;tect&eacute;e(s)',
                'desc'  => 'Des robots re&ccedil;oivent des erreurs (404, 500) sur certaines pages. V&eacute;rifiez les redirections.',
                'pages' => $error_pages,
            );
        }

        // 4. Slow response times
        $slow_pages = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, AVG(response_ms) AS avg_ms, COUNT(*) AS crawls FROM {$ct}
             WHERE crawled_at > %s AND response_ms > 0
             GROUP BY post_id HAVING avg_ms > 2000
             ORDER BY avg_ms DESC LIMIT 5",
            $d30_cutoff
        ) );
        if ( ! empty( $slow_pages ) ) {
            $insights[] = array(
                'type'  => 'warning',
                'icon'  => 'clock',
                'title' => 'Temps de r&eacute;ponse &eacute;lev&eacute;',
                'desc'  => count( $slow_pages ) . ' page(s) avec un temps de r&eacute;ponse moyen sup&eacute;rieur &agrave; 2 secondes pour les robots.',
                'pages' => $slow_pages,
            );
        }

        return $insights;
    }
}
