<?php
defined( 'ABSPATH' ) || exit;
/**
 * Module : Maillage interne intelligent
 *
 * Analyse les articles via IA (Anthropic prioritaire, fallback OpenAI) pour trouver des liens internes pertinents.
 * - Extrait les thèmes/mots-clés de chaque article
 * - Trouve les articles sémantiquement proches
 * - Suggère des liens internes à insérer
 * - Peut appliquer automatiquement les suggestions validées
 *
 * Utilise la cle API Anthropic (Coach) en priorite, fallback sur OpenAI.
 *
 * @since 1.14.5 (Light — ported from Full v2.2.0)
 */

class HTS_Internal_Linking {

    private $ai_key = '';
    private $ai_provider = 'none'; // 'anthropic', 'openai', or 'none'

    /**
     * Max liens internes par article (depuis agent settings 'linking').
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_max_links_per_post() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'linking' );
            if ( isset( $s['max_links_per_post'] ) ) {
                return max( 1, min( 30, (int) $s['max_links_per_post'] ) );
            }
        }
        return 5;
    }

    /**
     * Score sémantique minimum pour les suggestions (depuis agent settings 'linking').
     *
     * @since 2.4.3
     * @return float
     */
    public static function get_min_semantic_score() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'linking' );
            if ( isset( $s['min_semantic_score'] ) ) {
                return max( 0.10, min( 0.90, (float) $s['min_semantic_score'] ) );
            }
        }
        return 0.40; // Best practice 2026: only topically strong links help ranking
    }

    public function init() {
        if ( get_option( 'hts_module_linking', '1' ) !== '1' ) return;

        // Priorité : Anthropic (clé Coach), fallback OpenAI
        $anthropic_key = hts_get_anthropic_key();
        $openai_key    = hts_get_openai_key();

        if ( ! empty( $anthropic_key ) && strlen( $anthropic_key ) >= 20 ) {
            $this->ai_key      = $anthropic_key;
            $this->ai_provider = 'anthropic';
        } elseif ( ! empty( $openai_key ) ) {
            $this->ai_key      = $openai_key;
            $this->ai_provider = 'openai';
        }

        // AJAX endpoints
        add_action( 'wp_ajax_hts_analyze_linking', array( $this, 'ajax_analyze' ) );
        add_action( 'wp_ajax_hts_apply_link', array( $this, 'ajax_apply_link' ) );
        add_action( 'wp_ajax_hts_dismiss_link', array( $this, 'ajax_dismiss_link' ) );
        add_action( 'wp_ajax_hts_remove_link', array( $this, 'ajax_remove_link' ) );

        // Session K : Cron hebdo — proposer des liens internes dans l'Inbox
        add_action( 'hts_linking_weekly_scan', array( $this, 'cron_scan_linking' ) );
        if ( ! wp_next_scheduled( 'hts_linking_weekly_scan' ) ) {
            wp_schedule_event( time() + 5400, 'weekly', 'hts_linking_weekly_scan' );
        }
    }

    /**
     * Analyse un article et génère des suggestions de liens internes
     */
    public function ajax_analyze() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ) );
        }
        HTS_Subscription::require_tier(2);

        if ( $this->ai_provider === 'none' ) {
            wp_send_json_error( array( 'message' => 'Aucune cle API IA configuree (Anthropic ou OpenAI).' ) );
        }

        $post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
        $mode    = isset( $_POST['mode'] ) ? sanitize_text_field( $_POST['mode'] ) : 'single';

        try {
            if ( $mode === 'bulk' ) {
                $results = $this->analyze_bulk();
            } else {
                $results = $this->analyze_single( $post_id );
            }

            wp_send_json_success( $results );
        } catch ( Exception $e ) {
            wp_send_json_error( array( 'message' => $e->getMessage() ) );
        }
    }

    /**
     * Public: analyze a single post for internal linking.
     * Used by Content Refresh after rewriting an article.
     */
    public function analyze_for_post( $post_id ) {
        try {
            return $this->analyze_single( $post_id );
        } catch ( \Exception $e ) {
            return array( 'error' => $e->getMessage() );
        }
    }

    /**
     * Détermine si le contenu a changé de manière significative (justifie un re-appel IA).
     *
     * Critères : le word count a changé de > 10% OU les 3000 premiers caractères
     * (ce que l'IA reçoit) ont changé. Une correction de typo en fin d'article
     * ne déclenche PAS de re-analyse.
     *
     * @param int    $post_id
     * @param string $content_stripped  Contenu brut sans HTML
     * @return bool  true = changement significatif, false = cache valide
     */
    private function has_significant_change( $post_id, $content_stripped ) {
        // Hash des 3000 premiers caractères (ce que l'IA reçoit réellement)
        $content_for_ia = mb_substr( $content_stripped, 0, 3000 );
        $current_hash = md5( $content_for_ia );
        $stored_hash  = get_post_meta( $post_id, '_hts_link_content_hash', true );

        // Word count actuel vs stocké
        $current_wc = str_word_count( $content_stripped );
        $stored_wc  = (int) get_post_meta( $post_id, '_hts_link_word_count', true );

        // Pas de données stockées → première analyse → changement significatif
        if ( empty( $stored_hash ) || $stored_wc === 0 ) {
            return true;
        }

        // Les 3000 premiers chars ont changé → l'IA recevra un contenu différent
        if ( $stored_hash !== $current_hash ) {
            return true;
        }

        // Le word count a changé de plus de 10% → nouveau contenu ajouté/supprimé
        if ( $stored_wc > 0 ) {
            $change_pct = abs( $current_wc - $stored_wc ) / $stored_wc;
            if ( $change_pct > 0.10 ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Stocke les métriques de contenu pour le cache de maillage.
     *
     * @param int    $post_id
     * @param string $content_stripped
     */
    private function store_content_metrics( $post_id, $content_stripped ) {
        $content_for_ia = mb_substr( $content_stripped, 0, 3000 );
        update_post_meta( $post_id, '_hts_link_content_hash', md5( $content_for_ia ) );
        update_post_meta( $post_id, '_hts_link_word_count', str_word_count( $content_stripped ) );
    }

    /**
     * Analyse un seul article
     */
    private function analyze_single( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) throw new Exception( 'Article introuvable.' );

        // ── OPTIM 1 : Cache intelligent — skip IA si contenu pas significativement changé ──
        $content_stripped = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content_stripped = wp_strip_all_tags( HTS_Content_Extractor::get_content( $post_id ) );
        } else {
            $content_stripped = wp_strip_all_tags( $post->post_content );
        }

        $last_analyzed = get_post_meta( $post_id, '_hts_link_analyzed', true );
        $has_change = $this->has_significant_change( $post_id, $content_stripped );

        if ( ! $has_change && $last_analyzed && ( time() - (int) $last_analyzed ) < 90 * DAY_IN_SECONDS ) {
            $existing = get_post_meta( $post_id, '_hts_link_suggestions', true );
            if ( ! empty( $existing ) ) {
                hts_debug_log( '[Linking] analyze_single cache hit (no significant change) for post #' . $post_id );
                $ch_key = 'hts_linking_cache_hits_' . wp_date( 'Y-m' );
                update_option( $ch_key, (int) get_option( $ch_key, 0 ) + 1, false );
                return array(
                    'suggestions' => $existing,
                    'post_title'  => $post->post_title,
                    'message'     => count( $existing ) . ' suggestion(s) (cache — contenu inchangé).',
                );
            }
        }

        // Récupérer tous les autres articles publiés
        $candidates = $this->get_candidate_posts( $post_id );
        if ( empty( $candidates ) ) {
            return array( 'suggestions' => array(), 'message' => 'Pas assez d\'articles pour le maillage.' );
        }

        // Appel IA
        $suggestions = $this->get_ai_suggestions( $post, $candidates );

        // Stocker les suggestions + métriques contenu
        $this->store_suggestions( $post_id, $suggestions );
        $this->store_content_metrics( $post_id, $content_stripped );

        return array(
            'suggestions' => $suggestions,
            'post_title'  => $post->post_title,
            'message'     => count( $suggestions ) . ' suggestion(s) trouvée(s).',
        );
    }

    /**
     * Analyse en masse (top 20 articles les plus vus ou récents)
     */
    private function analyze_bulk() {
        // ── OPTIM 1.3 : Guard anti-boucle — max 1 run bulk par 24h ──
        $last_bulk_run = (int) get_option( 'hts_last_bulk_linking_run', 0 );
        if ( time() - $last_bulk_run < DAY_IN_SECONDS ) {
            $hours_ago = round( ( time() - $last_bulk_run ) / 3600, 1 );
            hts_debug_log( '[Linking] Analyse bulk ignorée — dernier run il y a ' . $hours_ago . 'h (guard 24h)' );
            return array(
                'skipped'  => true,
                'message'  => 'Analyse déjà lancée il y a ' . $hours_ago . 'h. Prochaine disponible dans ' . round( 24 - $hours_ago, 1 ) . 'h.',
            );
        }

        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        );
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }
        $posts = get_posts( $args );
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() && HTS_Language::detect_method() === 'url' ) {
            $posts = array_values( HTS_Language::filter_posts_by_lang( $posts ) );
        }

        $candidates = $this->get_candidate_posts( 0 );
        $all_suggestions = array();
        $analyzed = 0;

        foreach ( $posts as $post ) {
            // ── OPTIM 1 : Cache intelligent — skip IA si pas de changement significatif ──
            $existing = get_post_meta( $post->ID, '_hts_link_suggestions', true );
            $last_analyzed = get_post_meta( $post->ID, '_hts_link_analyzed', true );
            $content_stripped = '';
            if ( class_exists( 'HTS_Content_Extractor' ) ) {
                $content_stripped = wp_strip_all_tags( HTS_Content_Extractor::get_content( $post->ID ) );
            } else {
                $content_stripped = wp_strip_all_tags( $post->post_content );
            }
            $has_change = $this->has_significant_change( $post->ID, $content_stripped );

            if ( ! $has_change && $last_analyzed && ( time() - (int) $last_analyzed ) < 90 * DAY_IN_SECONDS ) {
                if ( ! empty( $existing ) ) {
                    $ch_key = 'hts_linking_cache_hits_' . wp_date( 'Y-m' );
                    update_option( $ch_key, (int) get_option( $ch_key, 0 ) + 1, false );
                    $all_suggestions[ $post->ID ] = array(
                        'title'       => $post->post_title,
                        'suggestions' => $existing,
                        'cached'      => true,
                    );
                }
                continue;
            }

            $post_candidates = array_filter( $candidates, function( $c ) use ( $post ) {
                return $c['id'] !== $post->ID;
            } );

            try {
                $suggestions = $this->get_ai_suggestions( $post, $post_candidates );
                $this->store_suggestions( $post->ID, $suggestions );
                $this->store_content_metrics( $post->ID, $content_stripped );

                if ( ! empty( $suggestions ) ) {
                    $all_suggestions[ $post->ID ] = array(
                        'title'       => $post->post_title,
                        'suggestions' => $suggestions,
                        'cached'      => false,
                    );
                }
                $analyzed++;
            } catch ( Exception $e ) {
                hts_add_log( 'Maillage erreur pour "' . $post->post_title . '": ' . $e->getMessage(), 'error', 'system' );
            }

            // Rate limiting : pause entre les appels
            if ( $analyzed > 0 && $analyzed % 5 === 0 ) {
                sleep( 1 );
            }
        }

        // ── OPTIM 1.3 : Marquer le run bulk comme effectué ──
        update_option( 'hts_last_bulk_linking_run', time(), false );

        return array(
            'posts'    => $all_suggestions,
            'analyzed' => $analyzed,
            'message'  => $analyzed . ' article(s) analysé(s), ' . count( $all_suggestions ) . ' avec suggestions.',
        );
    }

    /**
     * Récupère les articles candidats pour le maillage.
     *
     * Strategy:
     *  1. If embeddings are available → use semantic similarity (top 25 most relevant)
     *  2. Fallback → 100 most recent posts (legacy behavior)
     *
     * Candidates include: similarity score, GSC data, money page flag.
     */
    private function get_candidate_posts( $exclude_id ) {

        // ═══ STRATEGY 1: EMBEDDINGS (semantic pre-filtering) ═══
        if ( $exclude_id && class_exists( 'HTS_Embeddings' ) ) {
            $emb = new HTS_Embeddings();
            $scored = $emb->get_scored_candidates( $exclude_id, 30 );

            if ( ! empty( $scored ) ) {
                hts_add_log(
                    '🧠 Maillage sémantique : ' . count( $scored ) . ' candidats par embeddings pour post #' . $exclude_id
                    . ' | top sim=' . ( $scored[0]['similarity'] ?? '?' ),
                    'info', 'linking'
                );
                return $scored;
            }
            // Embeddings vides (pas encore indexé) → fallback
        }

        // ═══ STRATEGY 2: FALLBACK (100 most recent) ═══
        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'exclude'        => $exclude_id ? array( $exclude_id ) : array(),
            'fields'         => 'all',
        );
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }
        $posts = get_posts( $args );
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() && HTS_Language::detect_method() === 'url' ) {
            $posts = array_values( HTS_Language::filter_posts_by_lang( $posts ) );
        }

        $money_pages = class_exists( 'HTS_Embeddings' ) ? HTS_Embeddings::get_money_pages() : array();

        $candidates = array();
        foreach ( $posts as $p ) {
            $excerpt = wp_strip_all_tags( HTS_Content_Extractor::get_content( $p->ID ) );
            $excerpt = mb_substr( $excerpt, 0, 300 );

            $categories = wp_get_post_categories( $p->ID, array( 'fields' => 'names' ) );

            $candidates[] = array(
                'id'               => $p->ID,
                'title'            => $p->post_title,
                'url'              => get_permalink( $p ),
                'excerpt'          => $excerpt,
                'categories'       => $categories,
                'gsc_clicks'       => (int) get_post_meta( $p->ID, '_hts_gsc_clicks', true ),
                'gsc_impressions'  => (int) get_post_meta( $p->ID, '_hts_gsc_impressions', true ),
                'gsc_position'     => (float) get_post_meta( $p->ID, '_hts_gsc_position', true ),
                'similarity'       => 0,
                'is_money_page'    => in_array( $p->ID, $money_pages, true ),
                'final_score'      => 0,
            );
        }

        return $candidates;
    }

    /**
     * Appel IA pour obtenir des suggestions de liens (Anthropic prioritaire, fallback OpenAI)
     * Envoie le contenu reel + les phrases candidates pour forcer des ancres exactes
     */
    private function get_ai_suggestions( $post, $candidates ) {
        $extracted = HTS_Content_Extractor::get_content( $post->ID );
        $content_raw = wp_strip_all_tags( $extracted );
        // Décoder les entités HTML (è → è, etc.) — critique pour la correspondance d'ancres
        $content_raw = html_entity_decode( $content_raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $content = mb_substr( $content_raw, 0, 3000 );

        // Extraire les phrases du contenu (pour forcer des ancres exactes)
        $sentences = preg_split( '/(?<=[.!?])\s+/', $content, -1, PREG_SPLIT_NO_EMPTY );
        $sentences = array_filter( $sentences, function( $s ) { return mb_strlen( trim( $s ) ) > 20; } );
        $sentences = array_values( array_slice( $sentences, 0, 60 ) );

        $sentences_text = '';
        foreach ( $sentences as $i => $s ) {
            $sentences_text .= "[" . ( $i + 1 ) . "] " . trim( $s ) . "\n";
        }

        // Détecter les liens internes déjà présents (dans le contenu extrait pour compatibilité builders)
        $site_url = home_url();
        preg_match_all( '/<a[^>]+href=["\']([^"\']*' . preg_quote( parse_url( $site_url, PHP_URL_HOST ), '/' ) . '[^"\']*)["\'][^>]*>/i', $extracted, $existing_links );
        $existing_urls = array_map( 'trailingslashit', $existing_links[1] ?? array() );

        // Formater les candidats (exclure ceux déjà liés) — avec données GSC + similarité + money page
        $candidates_text = '';
        $count = 0;
        $has_embeddings = false;
        foreach ( $candidates as $c ) {
            if ( in_array( trailingslashit( $c['url'] ), $existing_urls, true ) ) continue;
            if ( $count >= 25 ) break;
            $cats = implode( ', ', $c['categories'] );

            $tags = array();

            // Similarity tag
            $sim = $c['similarity'] ?? 0;
            if ( $sim > 0 ) {
                $has_embeddings = true;
                $sim_pct = round( $sim * 100 );
                $tags[] = '🧠 ' . $sim_pct . '%';
            }

            // GSC tag
            if ( ( $c['gsc_clicks'] ?? 0 ) > 0 || ( $c['gsc_impressions'] ?? 0 ) > 0 ) {
                $gsc_parts = array();
                if ( $c['gsc_clicks'] > 0 ) $gsc_parts[] = $c['gsc_clicks'] . ' clics';
                if ( $c['gsc_impressions'] > 0 ) $gsc_parts[] = $c['gsc_impressions'] . ' impr';
                if ( $c['gsc_position'] > 0 ) $gsc_parts[] = 'pos ' . $c['gsc_position'];
                $tags[] = '' . implode( ', ', $gsc_parts );
            }

            // Money page tag
            if ( ! empty( $c['is_money_page'] ) ) {
                $tags[] = '💰 MONEY PAGE';
            }

            // Composite score tag
            $final = $c['final_score'] ?? 0;
            if ( $final > 0 ) {
                $tags[] = 'score=' . round( $final * 100 );
            }

            $tag_str = ! empty( $tags ) ? ' | ' . implode( ' | ', $tags ) : '';
            $candidates_text .= "- ID:{$c['id']} | \"{$c['title']}\" | Cat: {$cats}{$tag_str}\n";
            $count++;
        }

        if ( empty( $candidates_text ) ) return array();

        // ── Verifier la limite de credits IA ──
        $monthly_limit = (int) get_option( 'hts_ai_monthly_limit', 500000 );
        $usage = get_option( 'hts_ai_usage', array() );
        $month_key = wp_date( 'Y-m' );
        $current_usage = (int) ( $usage[ $month_key ] ?? 0 );
        if ( $monthly_limit > 0 && $current_usage >= $monthly_limit ) {
            hts_debug_log( '[Linking] Quota IA atteint (' . number_format( $current_usage ) . '/' . number_format( $monthly_limit ) . ' tokens) — skip IA' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Quota IA mensuel atteint (' . number_format( $current_usage ) . ' tokens). Les suggestions de maillage reprendront le mois prochain.', 'warning', 'linking' );
            }
            return array();
        }

        // Build context-aware rules based on available data
        $rules_similarity = $has_embeddings
            ? "5. SIMILARITE : Les candidats sont tries par pertinence semantique (embeddings IA). Un score eleve = forte proximite thematique. Favorise les candidats a haute similarite.\n"
            : "5. PERTINENCE : Choisis les articles les plus proches thematiquement.\n";

        $max_links = self::get_max_links_per_post();
        $ai_max_links = min( $max_links, 3 ); // OPTIM 2 : Limiter les suggestions IA à 3 pour réduire les tokens output
        $prompt = "Tu es un consultant SEO senior specialise en maillage interne. Ta mission : trouver les meilleurs liens internes a ajouter dans cet article.

ARTICLE SOURCE
Titre : \"{$post->post_title}\"

PHRASES DE L'ARTICLE (numerotees)
{$sentences_text}

ARTICLES CIBLES DISPONIBLES
(Tries par pertinence — les meilleurs candidats sont en haut)
{$candidates_text}

REGLES STRICTES
1. ANCRE EXACTE : L'ancre doit etre un EXTRAIT EXACT copie mot pour mot depuis une phrase ci-dessus (2 a 6 mots consecutifs). Pas de reformulation.
2. PERTINENCE : Le lien doit apporter de la valeur au lecteur — l'article cible doit approfondir un sujet mentionne.
3. NATUREL : L'ancre ne doit PAS etre le titre exact de l'article cible. Elle doit s'integrer naturellement dans la phrase.
4. DIVERSITE : Repartir les liens dans differentes parties de l'article (pas tout au meme endroit).
{$rules_similarity}6. MONEY PAGES : Les articles marques MONEY PAGE sont des pages de conversion. A pertinence egale, elles sont TOUJOURS prioritaires.
7. STRIKING DISTANCE : Les articles avec position 4-20 et beaucoup d'impressions sont des opportunites. Un lien interne peut les faire monter en Top 3.
8. MAX {$ai_max_links} liens. Mieux vaut 2 liens pertinents que {$ai_max_links} mediocres.
9. N'inclure QUE des liens a forte valeur ajoutee thematique.
10. ANCRES UNIQUES : Chaque ancre doit etre DIFFERENTE des autres. Ne jamais proposer deux ancres qui partagent les memes mots-cles principaux. Chaque lien doit venir d'un passage DIFFERENT de l'article.

FORMAT DE REPONSE (JSON strict)
[
  {
    \"target_id\": 123,
    \"target_title\": \"Titre de l'article cible\",
    \"anchor_text\": \"extrait exact du contenu source\",
    \"sentence_num\": 5,
    \"reason\": \"Explication courte de la pertinence thematique\",
    \"relevance_score\": 85
  }
]

Si aucun lien pertinent, retourne []";

        $system_msg = 'Tu reponds UNIQUEMENT en JSON valide, sans markdown, sans backticks, sans commentaire.';

        if ( $this->ai_provider === 'anthropic' ) {
            // ── Anthropic API (Claude Haiku 4.5) ──
            $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
                'timeout' => 45,
                'headers' => array(
                    'x-api-key'         => $this->ai_key,
                    'anthropic-version'  => '2023-06-01',
                    'Content-Type'       => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'      => 'claude-haiku-4-5-20251001',
                    'max_tokens' => 1200,
                    'system'     => $system_msg,
                    'messages'   => array(
                        array( 'role' => 'user', 'content' => $prompt ),
                    ),
                ) ),
            ) );

            if ( is_wp_error( $response ) ) {
                throw new \Exception( 'Erreur API Anthropic : ' . $response->get_error_message() );
            }

            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                throw new \Exception( 'Anthropic réponse JSON invalide : ' . json_last_error_msg() );
            }

            if ( $code !== 200 ) {
                $err = isset( $data['error']['message'] ) ? $data['error']['message'] : 'HTTP ' . $code;
                throw new \Exception( 'Anthropic erreur : ' . $err );
            }

            $text = $data['content'][0]['text'] ?? '';
            $tokens_used = (int) ( ( $data['usage']['input_tokens'] ?? 0 ) + ( $data['usage']['output_tokens'] ?? 0 ) );

        } else {
            // ── Fallback OpenAI (GPT-4o-mini) ──
            $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
                'timeout' => 45,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->ai_key,
                    'Content-Type'  => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'       => 'gpt-4o-mini',
                    'messages'    => array(
                        array( 'role' => 'system', 'content' => $system_msg ),
                        array( 'role' => 'user', 'content' => $prompt ),
                    ),
                    'temperature' => 0.2,
                    'max_tokens'  => 1200,
                ) ),
            ) );

            if ( is_wp_error( $response ) ) {
                throw new \Exception( 'Erreur API OpenAI : ' . $response->get_error_message() );
            }

            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                throw new \Exception( 'OpenAI réponse JSON invalide : ' . json_last_error_msg() );
            }

            if ( $code !== 200 ) {
                $err = isset( $data['error']['message'] ) ? $data['error']['message'] : 'HTTP ' . $code;
                throw new \Exception( 'OpenAI erreur : ' . $err );
            }

            $text = isset( $data['choices'][0]['message']['content'] ) ? $data['choices'][0]['message']['content'] : '';
            $tokens_used = (int) ( $data['usage']['total_tokens'] ?? 0 );
        }

        $text = trim( $text );
        $text = preg_replace( '/^```json\s*/', '', $text );
        $text = preg_replace( '/\s*```$/', '', $text );

        // ── Comptabiliser les tokens utilises ──
        if ( $tokens_used > 0 ) {
            $usage = get_option( 'hts_ai_usage', array() );
            $month_key = wp_date( 'Y-m' );
            $usage[ $month_key ] = ( (int) ( $usage[ $month_key ] ?? 0 ) ) + $tokens_used;
            // Nettoyer les mois anciens (garder 3 mois)
            $keep = array( $month_key, wp_date( 'Y-m', strtotime( '-1 month' ) ), wp_date( 'Y-m', strtotime( '-2 months' ) ) );
            $usage = array_intersect_key( $usage, array_flip( $keep ) );
            update_option( 'hts_ai_usage', $usage, false );

            // ── Sprint 2 : Compteurs granulaires pour page de coûts ──
            $calls_key  = 'hts_linking_calls_' . $month_key;
            $tokens_key = 'hts_linking_tokens_' . $month_key;
            update_option( $calls_key, (int) get_option( $calls_key, 0 ) + 1, false );
            update_option( $tokens_key, (int) get_option( $tokens_key, 0 ) + $tokens_used, false );

            // Ventilation par provider
            $prov_key = 'hts_linking_tokens_' . $this->ai_provider . '_' . $month_key;
            update_option( $prov_key, (int) get_option( $prov_key, 0 ) + $tokens_used, false );
        }

        $suggestions = json_decode( $text, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Internal linking: JSON decode failed for AI response: ' . json_last_error_msg(), 'warning', 'linking' );
            }
            return array();
        }
        if ( ! is_array( $suggestions ) ) return array();

        // ── Filtrer par min_semantic_score (Session F) ──
        $min_score = self::get_min_semantic_score();
        $min_score_100 = $min_score * 100; // IA retourne 0-100, seuil est 0.0-1.0

        // v2.5.12: Get dismissed target_ids for this source post — never re-propose
        $dismissed_targets = self::get_dismissed_targets( $post->ID );

        // v2.5.12: Compute connector phrase budget for this post
        // Proposals where anchor is NOT in the raw content will need a connector phrase.
        // We must limit these to what the connector budget allows.
        $elementor_raw = get_post_meta( $post->ID, '_elementor_data', true );
        $full_html = $post->post_content . ( is_string( $elementor_raw ) ? $elementor_raw : '' );

        $connector_sigs = array( 'Pour aller plus loin,', 'Retrouvez tous les détails', 'Pour approfondir ce sujet,', 'Ce point est détaillé', 'Nous abordons ce thème', 'Learn more in our', 'For a deeper dive', 'We cover this topic', 'Find out more about' );
        $existing_connectors = 0;
        foreach ( $connector_sigs as $sig ) { $existing_connectors += substr_count( $full_html, $sig ); }

        $is_page_type = ( $post->post_type === 'page' ) || (bool) get_post_meta( $post->ID, '_hts_money_page', true );
        if ( $is_page_type ) {
            $word_count_scan = str_word_count( wp_strip_all_tags( $full_html ) );
            $max_connectors = max( 1, min( 3, (int) floor( $word_count_scan / 500 ) ) );
        } else {
            $h2_count = preg_match_all( '/<h2[\s>]/i', $full_html );
            $max_connectors = max( 1, (int) $h2_count );
        }
        $connector_budget = max( 0, $max_connectors - $existing_connectors );

        // POST-VALIDATION : vérifier que chaque ancre existe VRAIMENT dans le contenu
        $validated = array();
        $used_anchor_words = array(); // v2.5.12: track significant words to dedup similar anchors
        foreach ( $suggestions as $s ) {
            $anchor = $s['anchor_text'] ?? '';
            $target_id = absint( $s['target_id'] ?? 0 );

            if ( empty( $anchor ) || ! $target_id ) continue;

            // v2.5.12: Skip if this source→target pair was previously dismissed
            if ( in_array( $target_id, $dismissed_targets, true ) ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Suggestion filtrée (cible déjà ignorée) : "' . $anchor . '" → post #' . $target_id, 'info', 'linking' );
                }
                continue;
            }

            // Filtrer les suggestions dont le relevance_score est inférieur au seuil
            $relevance = isset( $s['relevance_score'] ) ? (float) $s['relevance_score'] : 0;
            if ( $relevance < $min_score_100 ) {
                if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                    hts_debug_log( '[Linking] Suggestion filtrée (score ' . $relevance . ' < seuil ' . $min_score_100 . ') : ' . $anchor . ' → post #' . $target_id );
                }
                continue;
            }

            // v2.5.12: ANCHOR DEDUP — skip if anchor is too similar to an already-accepted one
            $anchor_sig_words = self::extract_significant_words( $anchor );
            if ( ! empty( $anchor_sig_words ) && ! empty( $used_anchor_words ) ) {
                $dominated = false;
                foreach ( $used_anchor_words as $prev_words ) {
                    // Count overlap
                    $overlap = count( array_intersect( $anchor_sig_words, $prev_words ) );
                    $min_len = min( count( $anchor_sig_words ), count( $prev_words ) );
                    // If 60%+ of significant words overlap → too similar
                    if ( $min_len > 0 && ( $overlap / $min_len ) >= 0.6 ) {
                        $dominated = true;
                        if ( function_exists( 'hts_add_log' ) ) {
                            hts_add_log( 'Suggestion filtrée (ancre similaire déjà proposée) : "' . $anchor . '" → post #' . $target_id, 'info', 'linking' );
                        }
                        break;
                    }
                }
                if ( $dominated ) continue;
            }

            // Recherche insensible à la casse dans le contenu brut
            $anchor_found_in_content = false;
            if ( mb_stripos( $content_raw, $anchor ) !== false ) {
                $anchor_found_in_content = true;
            } else {
                // Essayer une version sans accents
                $anchor_clean = remove_accents( $anchor );
                $content_clean = remove_accents( $content_raw );
                if ( mb_stripos( $content_clean, $anchor_clean ) !== false ) {
                    $anchor_found_in_content = true;
                }
            }

            if ( ! $anchor_found_in_content ) {
                // Anchor not in content → will need a connector phrase
                if ( $connector_budget <= 0 ) {
                    // No connector budget left → skip this suggestion entirely
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( 'Suggestion filtrée (ancre absente + budget connector épuisé) : "' . $anchor . '" → post #' . $target_id, 'info', 'linking' );
                    }
                    continue;
                }
                // Has budget → accept but decrement
                $connector_budget--;
                $s['needs_connector'] = true;
            }

            // Vérifier que l'ancre n'est pas déjà dans un lien
            $anchor_pattern = preg_quote( $anchor, '/' );
            if ( preg_match( '/<a[^>]*>.*?' . $anchor_pattern . '.*?<\/a>/si', $post->post_content ) ) {
                continue; // Déjà lié
            }

            $s['target_url'] = get_permalink( $target_id );
            $s['validated']  = true;
            $validated[] = $s;

            // v2.5.12: Track significant words for anchor dedup
            if ( ! empty( $anchor_sig_words ) ) {
                $used_anchor_words[] = $anchor_sig_words;
            }
        }

        return $validated;
    }

    /**
     * Stocke les suggestions en post_meta
     */
    private function store_suggestions( $post_id, $suggestions ) {
        update_post_meta( $post_id, '_hts_link_suggestions', $suggestions );
        update_post_meta( $post_id, '_hts_link_analyzed', time() );
    }

    /**
     * Applique un lien interne dans le contenu du post
     */
    public function ajax_apply_link() {
        // Buffer any PHP warnings/notices so they don't corrupt JSON output
        ob_start();

        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            ob_end_clean();
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ) );
        }
        HTS_Subscription::require_tier(2);

        $post_id     = absint( $_POST['post_id'] ?? 0 );
        $target_id   = absint( $_POST['target_id'] ?? 0 );
        $anchor_text = sanitize_text_field( $_POST['anchor_text'] ?? '' );

        if ( ! $post_id || ! $target_id || ! $anchor_text ) {
            ob_end_clean();
            wp_send_json_error( array( 'message' => 'Paramètres manquants (post_id=' . $post_id . ', target_id=' . $target_id . ', anchor=' . $anchor_text . ').' ) );
        }

        try {
            $this->do_apply_link( $post_id, $target_id, $anchor_text );
        } catch ( \Exception $e ) {
            $warnings = ob_get_clean();
            wp_send_json_error( array( 'message' => 'Erreur PHP : ' . $e->getMessage(), 'warnings' => $warnings, 'alternatives' => array() ) );
        } catch ( \Error $e ) {
            $warnings = ob_get_clean();
            wp_send_json_error( array( 'message' => 'Erreur fatale : ' . $e->getMessage() . ' L.' . $e->getLine() . ' ' . basename( $e->getFile() ), 'warnings' => $warnings, 'alternatives' => array() ) );
        }

        // Clean buffer if still open
        if ( ob_get_level() ) ob_end_clean();
    }

    /**
     * Logique d'application de lien — isolée pour try/catch propre
     */
    /**
     * Normalise un texte pour la comparaison d'ancres.
     * Gère : entités HTML, espaces insécables, guillemets typographiques, tirets longs.
     */
    private function normalize_for_match( $text ) {
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $text = str_replace( array( "\xC2\xA0", "\xA0" ), ' ', $text );
        $text = str_replace( '&nbsp;', ' ', $text );
        $text = preg_replace( '/\s+/', ' ', $text );
        $text = str_replace( array( "\xE2\x80\x98", "\xE2\x80\x99", "\xE2\x80\x9A", "\xE2\x80\x9B", "\xE2\x80\xB2" ), "'", $text );
        $text = str_replace( array( "\xE2\x80\x9C", "\xE2\x80\x9D", "\xE2\x80\x9E", "\xE2\x80\x9F", "\xE2\x80\xB3" ), '"', $text );
        $text = str_replace( array( "\xE2\x80\x91", "\xE2\x80\x93", "\xE2\x80\x94" ), '-', $text ); // U+2011 non-breaking hyphen + U+2013 en-dash + U+2014 em-dash
        return trim( $text );
    }

    public function do_apply_link( $post_id, $target_id, $anchor_text, $return_mode = false, $options = array() ) {

        $post = get_post( $post_id );
        if ( ! $post ) {
            if ( $return_mode ) return array( 'success' => false, 'message' => 'Article introuvable.' );
            if(ob_get_level())ob_end_clean();wp_send_json_error( array( 'message' => 'Article introuvable.' ) );
        }

        // ── Post-level lock: prevent concurrent modifications (maillage vs content refresh) ──
        if ( class_exists( 'HTS_Content_Writer' ) && ! HTS_Content_Writer::acquire_post_lock( $post_id, 30 ) ) {
            $msg = 'Article #' . $post_id . ' en cours de modification par un autre module — réessai plus tard.';
            if ( function_exists( 'hts_add_log' ) ) hts_add_log( $msg, 'info', 'linking' );
            if ( $return_mode ) return array( 'success' => false, 'message' => $msg );
            if(ob_get_level())ob_end_clean();wp_send_json_error( array( 'message' => $msg ) );
        }
        // Auto-release lock on script exit (handles wp_send_json_* which calls die())
        register_shutdown_function( function() use ( $post_id ) {
            if ( class_exists( 'HTS_Content_Writer' ) ) {
                HTS_Content_Writer::release_post_lock( $post_id );
            }
        } );

        // ── Content Writer backup for builder-aware rollback ──
        $writer_backup = HTS_Content_Writer::get_raw_backup( $post_id );

        $target_url = get_permalink( $target_id );
        $content    = $post->post_content;

        // Sprint Robustesse: for builder pages (Elementor, Divi, etc.), post_content
        // may be empty or contain only shortcodes. Use Content Extractor to get real HTML.
        $builder_detected = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $extracted_html = HTS_Content_Extractor::get_content( $post_id );
            $builder_detected = HTS_Content_Extractor::get_detected_builder();
            if ( $builder_detected !== 'standard' && ! empty( $extracted_html ) ) {
                // Builder page: use extracted content for matching
                $content = $extracted_html;
            }
        }

        // Décoder + normaliser les entités HTML, guillemets, espaces insécables
        $content_decoded = $this->normalize_for_match( $content );
        $anchor_decoded  = $this->normalize_for_match( $anchor_text );

        // ── STRATÉGIE DE MATCHING (du plus strict au plus souple) ──

        $matched_content = null;
        $matched_anchor  = $anchor_decoded;
        $strategy_used   = '';
        $intro_blocked   = false; // v2.5.13: track intro blocking for contextual error message

        // 1. Match exact
        $pattern = $this->build_anchor_pattern( $anchor_decoded );
        if ( preg_match( $pattern, $content ) ) {
            $matched_content = $content;
            $strategy_used   = 'exact';
        } elseif ( preg_match( $pattern, $content_decoded ) ) {
            $matched_content = $content_decoded;
            $strategy_used   = 'exact';
        }

        // 1b. Tag-tolerant exact: same words in same order, but allows inline HTML tags between them
        // Handles cases where source has <strong>transformer</strong> la recherche but anchor is "transformer la recherche"
        if ( ! $matched_content ) {
            $tag_pattern = $this->build_tag_tolerant_pattern( $anchor_decoded );
            if ( $tag_pattern ) {
                if ( preg_match( $tag_pattern, $content_decoded, $tag_m ) ) {
                    $matched_content = $content_decoded;
                    $matched_anchor  = $tag_m[1]; // includes HTML tags — valid inside <a>
                    $pattern = $tag_pattern;
                    $strategy_used = 'tag_tolerant';
                } elseif ( preg_match( $tag_pattern, $content, $tag_m ) ) {
                    $matched_content = $content;
                    $matched_anchor  = $tag_m[1];
                    $pattern = $tag_pattern;
                    $strategy_used = 'tag_tolerant';
                }
            }
        }

        // 2. Match sans accents
        if ( ! $matched_content ) {
            $anchor_no_accents = $this->remove_accents_light( $anchor_decoded );
            $pattern2 = $this->build_anchor_pattern( $anchor_no_accents );
            if ( preg_match( $pattern2, $this->remove_accents_light( $content_decoded ), $m2 ) ) {
                // Retrouver la vraie ancre dans le contenu original à la même position
                $pos = mb_strpos( $this->remove_accents_light( $content_decoded ), $m2[1] );
                if ( $pos !== false ) {
                    $real_anchor = mb_substr( $content_decoded, $pos, mb_strlen( $m2[1] ) );
                    $test_pattern = $this->build_anchor_pattern( $real_anchor );
                    if ( preg_match( $test_pattern, $content_decoded ) ) {
                        $matched_content = $content_decoded;
                        $matched_anchor  = $real_anchor;
                        $pattern = $test_pattern;
                        $strategy_used = 'sans_accents';
                    }
                }
            }
        }

        // 3. Match souple : mots significatifs de l'ancre dans un segment de 2-8 mots
        if ( ! $matched_content ) {
            $result = $this->fuzzy_find_anchor( $content_decoded, $anchor_decoded );
            if ( $result ) {
                $test_pattern = $this->build_anchor_pattern( $result );
                if ( preg_match( $test_pattern, $content_decoded ) ) {
                    $matched_content = $content_decoded;
                    $matched_anchor  = $result;
                    $pattern = $test_pattern;
                    $strategy_used = 'fuzzy';
                } elseif ( preg_match( $test_pattern, $content ) ) {
                    $matched_content = $content;
                    $matched_anchor  = $result;
                    $pattern = $test_pattern;
                    $strategy_used = 'fuzzy';
                }
            }
        }

        // ── STRATEGIES 1-3: REGEX REPLACEMENT ──
        if ( $matched_content !== null ) {
            $link = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( get_the_title( $target_id ) ) . '">' . $matched_anchor . '</a>';
            $new_content = preg_replace( $pattern, $link, $matched_content, 1 );

            // VERIFY: content actually changed AND the link tag is present in visible text
            $link_check = 'href="' . esc_url( $target_url ) . '"';
            if ( $new_content === $matched_content || $new_content === null || strpos( $new_content, $link_check ) === false ) {
                // Replacement was a false positive — reset and try fallback strategies
                $matched_content = null;
                $new_content     = null;
            }

            // VERIFY: link is NOT inside a heading (H1-H6)
            if ( $new_content !== null ) {
                $link_pos_check = strpos( $new_content, $link_check );
                if ( $link_pos_check !== false && $this->is_inside_heading( $new_content, $link_pos_check ) ) {
                    // Link landed in a heading — try to find a match outside headings
                    // Remove the bad replacement and retry with offset
                    $matched_content = null;
                    $new_content     = null;
                }
            }

            // VERIFY: link is NOT in intro zone (before first H2)
            // v2.5.12: NEVER inject in intro zone via automatic maillage
            $in_intro = false;
            if ( $new_content !== null ) {
                $link_pos_in_new = strpos( $new_content, $link_check );
                $h2_first = $this->get_first_h2_pos( $new_content );

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Intro check: link_pos=' . ( $link_pos_in_new !== false ? $link_pos_in_new : 'false' ) . ' h2_pos=' . ( $h2_first !== false ? $h2_first : 'false' ) . ' is_before=' . ( ( $link_pos_in_new !== false && $h2_first !== false && $link_pos_in_new < $h2_first ) ? 'YES' : 'NO' ) . ' post=' . $post_id, 'debug', 'linking' );
                }

                if ( $link_pos_in_new !== false && $h2_first !== false && $link_pos_in_new < $h2_first ) {

                    // Try to find a match AFTER the first H2 instead
                    $h2_pos = $this->get_first_h2_pos( $matched_content );
                    if ( $h2_pos !== false ) {
                        $after_h2 = substr( $matched_content, $h2_pos );
                        $new_after = preg_replace( $pattern, $link, $after_h2, 1 );
                        $found_after = ( $new_after !== $after_h2 && $new_after !== null && strpos( $new_after, $link_check ) !== false );

                        if ( function_exists( 'hts_add_log' ) ) {
                            hts_add_log( 'Intro retry: found_after_h2=' . ( $found_after ? 'YES' : 'NO' ) . ' after_h2_len=' . mb_strlen( $after_h2 ) . ' post=' . $post_id, 'debug', 'linking' );
                        }

                        if ( $found_after ) {
                            // Found after H2 — use this instead
                            $new_content = substr( $matched_content, 0, $h2_pos ) . $new_after;
                        } else {
                            // Anchor only exists in intro — BLOCK
                            $matched_content = null;
                            $new_content     = null;
                            $intro_blocked   = true;
                            hts_add_log(
                                'Lien bloqué (zone intro réservée au pilier) : ancre="' . $anchor_decoded . '" post=' . $post_id . ' — l\'ancre n\'existe que dans l\'introduction',
                                'info', 'linking'
                            );
                        }
                    } else {
                        // No H2 at all — block intro injection
                        $matched_content = null;
                        $new_content     = null;
                        hts_add_log( 'Lien bloqué (pas de H2 dans le contenu) : ancre="' . $anchor_decoded . '" post=' . $post_id, 'info', 'linking' );
                    }
                }
            }
        } // end if ( $matched_content !== null ) — strategies 1-3

        // ── STRATEGY 4: PARAGRAPH-LEVEL INJECTION ──
        if ( $matched_content === null ) {
            $target_title_for_link = get_the_title( $target_id );
            $injected = $this->paragraph_inject_link( $content, $anchor_decoded, $target_url, $target_title_for_link );
            if ( ! $injected ) {
                $injected = $this->paragraph_inject_link( $content_decoded, $anchor_decoded, $target_url, $target_title_for_link );
            }
            if ( ! $injected && isset( $result ) && $result ) {
                $injected = $this->paragraph_inject_link( $content, $result, $target_url, $target_title_for_link );
                if ( ! $injected ) {
                    $injected = $this->paragraph_inject_link( $content_decoded, $result, $target_url, $target_title_for_link );
                }
                if ( $injected ) $matched_anchor = $result;
            }

            if ( $injected ) {
                $new_content = $injected;
                $matched_content = 'injected'; // flag
                $strategy_used = 'paragraph';
            }
        }

        // ── STRATEGY 5: TOLERANT TEXT-NODE INJECTION ──
        if ( $matched_content === null ) {
            $target_title_str = get_the_title( $target_id );
            $tolerant = $this->tolerant_inject_link( $content, $anchor_decoded, $target_url, $target_title_str );
            if ( ! $tolerant ) {
                $tolerant = $this->tolerant_inject_link( $content_decoded, $anchor_decoded, $target_url, $target_title_str );
            }
            if ( ! $tolerant && isset( $result ) && $result ) {
                $tolerant = $this->tolerant_inject_link( $content, $result, $target_url, $target_title_str );
                if ( ! $tolerant ) {
                    $tolerant = $this->tolerant_inject_link( $content_decoded, $result, $target_url, $target_title_str );
                }
                if ( $tolerant ) $matched_anchor = $result;
            }

            if ( $tolerant ) {
                $new_content = $tolerant;
                $matched_content = 'tolerant'; // flag
                $strategy_used = 'tolerant';
            }
        }

        // ── STRATEGY 6: CONTEXTUAL PARAGRAPH APPEND (for AI-generated anchors) ──
        // When the anchor text doesn't exist in the content (AI generated it),
        // find the most relevant paragraph and append the link naturally.
        // v2.4.20: If a 'bridge' sentence is available (from v3 AI pipeline),
        // use it instead of appending a bare link.
        // Sprint Robustesse: now runs for ALL anchor types when direct matching fails,
        // not just generated anchors. This prevents "introuvable" errors.
        $is_generated_anchor = ( ! empty( $options['anchor_type'] ) && $options['anchor_type'] === 'generated' );
        $bridge_sentence     = ! empty( $options['anchor_bridge'] ) ? $options['anchor_bridge'] : '';
        if ( $matched_content === null ) {
            $appended = $this->contextual_append_link( $content, $anchor_decoded, $target_url, get_the_title( $target_id ), $target_id, $bridge_sentence );
            if ( ! $appended ) {
                $appended = $this->contextual_append_link( $content_decoded, $anchor_decoded, $target_url, get_the_title( $target_id ), $target_id, $bridge_sentence );
            }
            if ( $appended ) {
                $new_content = $appended;
                $matched_content = 'contextual_append';
                $matched_anchor  = $anchor_decoded;
                $strategy_used = 'contextual_append';
            }
        }

        // ── CONFIRMATION: if anchor changed, ask user before applying ──
        $is_confirmed    = ! empty( $_POST['confirmed'] );
        // Strip tags for comparison — tag_tolerant strategy includes HTML tags in matched_anchor
        $matched_anchor_clean = wp_strip_all_tags( $matched_anchor );
        $anchor_changed  = ( mb_strtolower( $matched_anchor_clean ) !== mb_strtolower( $anchor_decoded ) );

        // Auto-confirm when called from workflow engine (any execution context)
        // The anchor_changed confirmation is only needed for manual AJAX apply_link button.
        // When executing from workflow (approve, batch, cron), always auto-confirm.
        $is_workflow_context = ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX )
                             || ( ! empty( $_POST['action'] ) && in_array( $_POST['action'], array(
                                    'hts_inbox_approve', 'hts_inbox_batch', 'hts_inbox_execute'
                                ), true ) );

        // v2.4.17: return_mode (from Workflow Engine) is also workflow context
        if ( $return_mode ) {
            $is_workflow_context = true;
        }

        if ( $is_workflow_context && $anchor_changed ) {
            // v2.4.17: STRATEGY GATE — fuzzy and tolerant matches are too unreliable
            // for automated application. Only exact, sans_accents, paragraph are safe.
            // v2.4.19: Exception — allow fuzzy for AI-generated anchors (the anchor was 
            // invented by AI and won't exist verbatim, so fuzzy is expected and safe)
            $is_generated_anchor = ( ! empty( $options['anchor_type'] ) && $options['anchor_type'] === 'generated' );
            $blocked_strategies = $is_generated_anchor
                ? array( 'tolerant' ) // generated: allow fuzzy, still block tolerant
                : array( 'fuzzy', 'tolerant' ); // extract: block both as before

            if ( in_array( $strategy_used, $blocked_strategies, true ) ) {
                hts_add_log(
                    'Lien : stratégie ' . $strategy_used . ' non fiable → fallback phrase connective : demandé="' . mb_substr( $anchor_decoded, 0, 40 )
                    . '" trouvé="' . mb_substr( $matched_anchor, 0, 40 ) . '" post=' . $post_id,
                    'info', 'linking'
                );

                // Sprint Robustesse: instead of returning error, reset and let Strategy 6 (connector phrase) handle it
                $matched_content = null;
                $new_content     = null;
                $strategy_used   = '';
            }

            // SIMILARITY GATE — don't auto-confirm if anchor is too different
            // Strip HTML tags for comparison (tag_tolerant strategy includes tags in matched_anchor)
            $matched_for_sim = wp_strip_all_tags( $matched_anchor );
            $sim_score = 0;
            similar_text( mb_strtolower( $matched_for_sim ), mb_strtolower( $anchor_decoded ), $sim_score );

            if ( $sim_score < 55 ) {
                hts_add_log(
                    'Lien : ancre trop différente (sim=' . round( $sim_score, 1 ) . '%) → fallback phrase connective : demandé="' . mb_substr( $anchor_decoded, 0, 40 )
                    . '" trouvé="' . mb_substr( $matched_anchor, 0, 40 ) . '" post=' . $post_id,
                    'info', 'linking'
                );

                // Sprint Robustesse: reset and let Strategy 6 handle it
                $matched_content = null;
                $new_content     = null;
                $strategy_used   = '';
            } else {
                $is_confirmed = true;
            }
        }

        // ── Sprint Robustesse: RETRY Strategy 6 after gates reset ──
        // If strategy/similarity gates above reset matched_content to null,
        // we need a second chance at contextual_append (which already ran before the gates
        // but was skipped because matched_content was not null at that point).
        if ( $matched_content === null && $new_content === null ) {
            $bridge_sentence_retry = ! empty( $options['anchor_bridge'] ) ? $options['anchor_bridge'] : '';
            $appended_retry = $this->contextual_append_link( $content, $anchor_decoded, $target_url, get_the_title( $target_id ), $target_id, $bridge_sentence_retry );
            if ( ! $appended_retry ) {
                $appended_retry = $this->contextual_append_link( $content_decoded, $anchor_decoded, $target_url, get_the_title( $target_id ), $target_id, $bridge_sentence_retry );
            }
            if ( $appended_retry ) {
                $new_content     = $appended_retry;
                $matched_content = 'contextual_append';
                $matched_anchor  = $anchor_decoded;
                $strategy_used   = 'contextual_append';
                $is_confirmed    = true;
            }
        }

        // v2.4.17: DEDUP CHECK — block if target URL already linked in content
        // Bug C fix: normalize trailing slashes to avoid /page vs /page/ duplication
        if ( $matched_content !== null ) {
            $check_target_href = esc_url( $target_url );
            $check_target_no_slash = untrailingslashit( $check_target_href );
            $check_target_slash    = trailingslashit( $check_target_href );
            $original_content  = $post->post_content;
            if ( strpos( $original_content, $check_target_no_slash ) !== false || strpos( $original_content, $check_target_slash ) !== false ) {
                hts_add_log(
                    'Lien bloqué (cible déjà liée) : href="' . $check_target_href . '" post=' . $post_id . ' ancre="' . mb_substr( $anchor_decoded, 0, 40 ) . '"',
                    'info', 'linking'
                );

                $dedup_data = array(
                    'message' => 'Un lien vers cette page existe déjà dans le contenu. Lien non ajouté.',
                );

                if ( $return_mode ) return array( 'success' => false, 'data' => $dedup_data );
                if ( ob_get_level() ) ob_end_clean();
                wp_send_json_error( $dedup_data );
                return;
            }
        }

        // v2.5.12: Final intro zone check — block ANY link that ended up before first H2
        // Intro is reserved for pillar links only (manual or cocon maillage)
        if ( ! isset( $in_intro ) ) $in_intro = false;
        if ( $matched_content !== null && ! empty( $new_content ) && ! $in_intro ) {
            $link_check_intro = 'href="' . esc_url( $target_url ) . '"';
            $lp = strpos( $new_content, $link_check_intro );
            if ( $lp !== false && $this->is_before_first_h2( $new_content, $lp ) ) {
                $matched_content = null;
                $new_content     = null;
                $intro_blocked   = true;
                hts_add_log(
                    'Lien bloqué (zone intro réservée au pilier, strat ' . $strategy_used . ') : ancre="' . $anchor_decoded . '" post=' . $post_id,
                    'info', 'linking'
                );
            }
        }

        if ( $matched_content !== null && $anchor_changed && ! $is_confirmed ) {
            // Don't save — return proposed anchor for user confirmation
            $preview_context = $this->extract_plain_context( $new_content ?? '', $target_url, $matched_anchor );

            $confirm_data = array(
                'needs_confirm'   => true,
                'message'         => 'L\'ancre exacte n\'existe pas dans le contenu.',
                'proposed_anchor' => $matched_anchor,
                'original_anchor' => $anchor_text,
                'strategy'        => $strategy_used,
                'context'         => $preview_context,
                'source_title'    => get_the_title( $post_id ),
                'source_url'      => get_permalink( $post_id ),
                'in_intro'        => $in_intro,
            );

            if ( $return_mode ) return array( 'success' => true, 'data' => $confirm_data );
            if ( ob_get_level() ) ob_end_clean();
            wp_send_json_success( $confirm_data );
            return;
        }

        $connector_limit_reached = false; // v2.5.12: track if connector limit blocked injection

        // ── v2.5.12: HARD INTRO GUARD — catches ALL strategies before save ──
        // No matter which strategy succeeded, if the link ended up before the first H2, BLOCK IT.
        // Intro is reserved for the pillar page link only.
        if ( $matched_content !== null && ! empty( $new_content ) && is_string( $new_content ) ) {
            $guard_target_href = esc_url( $target_url );
            $guard_link_pos = strpos( $new_content, $guard_target_href );
            $guard_h2_pos   = false;
            if ( preg_match( '/<h2[\s>]/i', $new_content, $gm, PREG_OFFSET_CAPTURE ) ) {
                $guard_h2_pos = $gm[0][1];
            }

            if ( $guard_link_pos !== false && $guard_h2_pos !== false && $guard_link_pos < $guard_h2_pos ) {
                // Link is in intro — try to relocate after H2
                // Strip the link from new_content first (keep anchor text)
                $original_for_retry = $post->post_content;
                $retry_h2_pos = false;
                if ( preg_match( '/<h2[\s>]/i', $original_for_retry, $rh2m, PREG_OFFSET_CAPTURE ) ) {
                    $retry_h2_pos = $rh2m[0][1];
                }

                if ( $retry_h2_pos !== false ) {
                    $after_h2_content = substr( $original_for_retry, $retry_h2_pos );
                    // Build pattern for the anchor
                    $retry_escaped = preg_quote( $anchor_decoded, '/' );
                    $retry_escaped = preg_replace( '/\\\\ /', '\\s+', $retry_escaped );
                    $retry_pattern = '/(?<!["\'])(' . $retry_escaped . ')(?![^<]*<\/a>)(?![^<]*<\/h[1-6]>)/iu';
                    $retry_link = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( get_the_title( $target_id ) ) . '">' . $matched_anchor . '</a>';

                    $retry_result = preg_replace( $retry_pattern, $retry_link, $after_h2_content, 1 );

                    if ( $retry_result !== $after_h2_content && $retry_result !== null && strpos( $retry_result, $guard_target_href ) !== false ) {
                        // Anchor found after H2 — rebuild content with clean intro + linked body
                        $new_content = substr( $original_for_retry, 0, $retry_h2_pos ) . $retry_result;
                        hts_add_log( 'Intro guard: lien relocalisé après H2 (ancre="' . mb_substr( $anchor_decoded, 0, 40 ) . '" post=' . $post_id . ')', 'info', 'linking' );
                    } else {
                        // Anchor ONLY in intro — block entirely
                        $matched_content = null;
                        $new_content     = null;
                        $intro_blocked   = true;
                        hts_add_log( 'Intro guard: lien BLOQUÉ (ancre uniquement en intro, réservée au pilier) : "' . mb_substr( $anchor_decoded, 0, 40 ) . '" post=' . $post_id, 'info', 'linking' );
                    }
                } else {
                    // No H2 in content — allow (no intro zone concept)
                }
            }
        }

        // ── SAVE IF ANY STRATEGY SUCCEEDED — via Content Writer (multi-builder) ──
        if ( $matched_content !== null && ! empty( $matched_anchor ) ) {

            $writer_result = null;

            // Strategy 6 (contextual_append): anchor doesn't exist in original content,
            // so Content Writer::insert_link (search→replace) will fail.
            // Use append_paragraph instead, which adds a new text widget in Elementor
            // or appends a <p> in standard/Gutenberg.
            if ( $strategy_used === 'contextual_append' && class_exists( 'HTS_Content_Writer' ) ) {

                // v2.5.12: Connector phrase limit — prevent spammy "go see this article" phrases
                // Pages (pillar/money): max 1 connector total — commercial pages must stay clean
                // Articles (posts): max 1 connector per H2 section — editorial content can have more
                $current_post = get_post( $post_id );
                $current_content = $current_post->post_content ?? '';
                $elementor_data_raw = get_post_meta( $post_id, '_elementor_data', true );
                $check_text = $current_content . ( is_string( $elementor_data_raw ) ? $elementor_data_raw : '' );

                $connector_signatures = array(
                    'Pour aller plus loin,', 'Retrouvez tous les détails',
                    'Pour approfondir ce sujet,', 'Ce point est détaillé',
                    'Nous abordons ce thème',
                    'Learn more in our', 'For a deeper dive',
                    'We cover this topic', 'Find out more about',
                );
                $existing_connectors = 0;
                foreach ( $connector_signatures as $sig ) {
                    $existing_connectors += substr_count( $check_text, $sig );
                }

                // Determine max connectors based on page type and word count
                $is_page_type = ( $current_post->post_type === 'page' );
                $is_money     = (bool) get_post_meta( $post_id, '_hts_money_page', true );

                if ( $is_page_type || $is_money ) {
                    // Pillar/money pages: 1 per 500 words, min 1, max 3
                    $word_count = str_word_count( wp_strip_all_tags( $check_text ) );
                    $max_connectors = max( 1, min( 3, (int) floor( $word_count / 500 ) ) );
                } else {
                    // Articles: count H2 sections → max 1 per section
                    $h2_count = preg_match_all( '/<h2[\s>]/i', $check_text );
                    $max_connectors = max( 1, (int) $h2_count );
                }

                if ( $existing_connectors >= $max_connectors ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( 'Connector phrase bloquée (max ' . $max_connectors . ' atteint, ' . $existing_connectors . ' existant(s)) : post #' . $post_id, 'info', 'linking' );
                    }
                    $writer_result = null; // Fall through to insert_link (search-replace)
                    $connector_limit_reached = true; // v2.5.12: track for better error message
                } else {

                // v2.5.12: Always strip tags from anchor to prevent double-encoding
                $clean_anchor = wp_strip_all_tags( $matched_anchor );
                $link_html_for_append = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( get_the_title( $target_id ) ) . '">' . esc_html( $clean_anchor ) . '</a>';
                $bridge_for_append = ! empty( $options['anchor_bridge'] ) ? $options['anchor_bridge'] : '';
                if ( ! empty( $bridge_for_append ) && mb_stripos( $bridge_for_append, $anchor_decoded ) !== false ) {
                    $phrase_for_append = preg_replace( '/' . preg_quote( $anchor_decoded, '/' ) . '/iu', $link_html_for_append, $bridge_for_append, 1 );
                    if ( ! preg_match( '/[.!?]$/', $phrase_for_append ) ) $phrase_for_append .= '.';
                } else {
                    // v2.5.12: Varied connector phrases (random selection for natural diversity)
                    $connectors_pool = array(
                        'fr' => array(
                            'Pour aller plus loin, consultez notre guide sur %s.',
                            'Retrouvez tous les détails dans notre article dédié au %s.',
                            'Pour approfondir ce sujet, consultez %s.',
                            'Ce point est détaillé dans notre page sur %s.',
                            'Nous abordons ce thème en profondeur dans %s.',
                        ),
                        'en' => array(
                            'Learn more in our detailed guide on %s.',
                            'For a deeper dive, check out our article on %s.',
                            'We cover this topic in detail in %s.',
                            'Find out more about this in %s.',
                        ),
                    );
                    $lang = strtolower( substr( get_locale(), 0, 2 ) );
                    $pool = $connectors_pool[ $lang ] ?? $connectors_pool['en'];
                    $tpl = $pool[ array_rand( $pool ) ];
                    $phrase_for_append = sprintf( $tpl, $link_html_for_append );
                }
                $writer_result = HTS_Content_Writer::append_paragraph( $post_id, $phrase_for_append, array(
                    'target_keywords' => self::extract_significant_words( get_the_title( $target_id ) ),
                ) );

                } // end else (connector limit check)
            }

            // For all other strategies: search→replace (anchor exists in content)
            if ( $writer_result === null ) {
                $writer_result = HTS_Content_Writer::insert_link(
                    $post_id,
                    $matched_anchor,
                    $target_url,
                    array( 'title' => get_the_title( $target_id ) )
                );
            }

            if ( ! $writer_result['success'] ) {
                // Content Writer couldn't find the anchor
                // Sprint Robustesse: for builder pages, try append_paragraph as fallback
                if ( $builder_detected && $builder_detected !== 'standard' && class_exists( 'HTS_Content_Writer' ) ) {

                    // v2.5.12: Check connector phrase limit before fallback too
                    if ( ! isset( $existing_connectors ) || ! isset( $max_connectors ) ) {
                        $cur_p = get_post( $post_id );
                        $cur = $cur_p->post_content ?? '';
                        $el_raw = get_post_meta( $post_id, '_elementor_data', true );
                        $chk = $cur . ( is_string( $el_raw ) ? $el_raw : '' );
                        $connector_sigs = array( 'Pour aller plus loin,', 'Retrouvez tous les détails', 'Pour approfondir ce sujet,', 'Ce point est détaillé', 'Nous abordons ce thème', 'Learn more in our', 'For a deeper dive', 'We cover this topic', 'Find out more about' );
                        $existing_connectors = 0;
                        foreach ( $connector_sigs as $sig ) { $existing_connectors += substr_count( $chk, $sig ); }
                        $is_pg = ( $cur_p->post_type === 'page' ) || (bool) get_post_meta( $post_id, '_hts_money_page', true );
                        if ( $is_pg ) {
                            $wc_fb = str_word_count( wp_strip_all_tags( $chk ) );
                            $max_connectors = max( 1, min( 3, (int) floor( $wc_fb / 500 ) ) );
                        } else {
                            $max_connectors = max( 1, (int) preg_match_all( '/<h2[\s>]/i', $chk ) );
                        }
                    }

                    if ( $existing_connectors >= $max_connectors ) {
                        if ( function_exists( 'hts_add_log' ) ) {
                            hts_add_log( 'Fallback connector bloqué (max ' . $max_connectors . ' atteint) : ancre="' . mb_substr( $anchor_decoded, 0, 40 ) . '" post #' . $post_id, 'info', 'linking' );
                        }
                        $connector_limit_reached = true; // v2.5.12: track for better error message
                        // Don't try append_paragraph — let it fail gracefully
                    } else {

                    HTS_Content_Writer::restore_backup( $post_id, $writer_backup );
                    // v2.5.12: Use anchor_decoded (clean original anchor) not matched_anchor
                    // which may contain HTML fragments from tag_tolerant strategy
                    $clean_anchor_fb = wp_strip_all_tags( $anchor_decoded );
                    $link_html_fb = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( get_the_title( $target_id ) ) . '">' . esc_html( $clean_anchor_fb ) . '</a>';
                    $bridge_fb = ! empty( $options['anchor_bridge'] ) ? $options['anchor_bridge'] : '';
                    if ( ! empty( $bridge_fb ) && mb_stripos( $bridge_fb, $clean_anchor_fb ) !== false ) {
                        $phrase_fb = preg_replace( '/' . preg_quote( $clean_anchor_fb, '/' ) . '/iu', $link_html_fb, $bridge_fb, 1 );
                        if ( ! preg_match( '/[.!?]$/', $phrase_fb ) ) $phrase_fb .= '.';
                    } else {
                        $connectors_pool_fb = array(
                            'fr' => array(
                                'Pour aller plus loin, consultez notre guide sur %s.',
                                'Retrouvez tous les détails dans notre article dédié au %s.',
                                'Pour approfondir ce sujet, consultez %s.',
                                'Ce point est détaillé dans notre page sur %s.',
                            ),
                            'en' => array(
                                'Learn more in our detailed guide on %s.',
                                'For a deeper dive, check out our article on %s.',
                            ),
                        );
                        $lang_fb = strtolower( substr( get_locale(), 0, 2 ) );
                        $pool_fb = $connectors_pool_fb[ $lang_fb ] ?? $connectors_pool_fb['en'];
                        $phrase_fb = sprintf( $pool_fb[ array_rand( $pool_fb ) ], $link_html_fb );
                    }
                    $writer_result = HTS_Content_Writer::append_paragraph( $post_id, $phrase_fb, array(
                        'target_keywords' => self::extract_significant_words( get_the_title( $target_id ) ),
                    ) );
                    if ( $writer_result['success'] ) {
                        $strategy_used = 'builder_append_fallback';
                        hts_add_log( 'Lien ajouté via append_paragraph (fallback builder ' . $builder_detected . ') : "' . mb_substr( $matched_anchor, 0, 40 ) . '"', 'info', 'linking' );
                    }

                    } // end else (fallback connector limit)
                }

                if ( ! $writer_result['success'] ) {
                    // Truly failed — restore and fall through
                    HTS_Content_Writer::restore_backup( $post_id, $writer_backup );
                    $matched_content = null;
                }
            }

            // ── POST-SAVE VERIFICATION (only if write succeeded) ──
            if ( $matched_content !== null && $writer_result && $writer_result['success'] ) {
                clean_post_cache( $post_id );
                HTS_Content_Extractor::invalidate_cache( $post_id );
                $link_href_check = esc_url( $target_url );

                // Check both post_content AND builder-extracted content
                $saved_post    = get_post( $post_id );
                $extracted     = HTS_Content_Extractor::get_content( $post_id );
                // get_content() returns a string (HTML), not an array
                $verify_html   = is_string( $extracted ) ? $extracted : ( $saved_post->post_content ?? '' );

                if ( strpos( $verify_html, $link_href_check ) === false && strpos( $saved_post->post_content ?? '', $link_href_check ) === false ) {
                    // Bug F fix: also check _elementor_data directly (race condition — Elementor may save after post_content)
                    $elementor_raw = get_post_meta( $post_id, '_elementor_data', true );
                    $found_in_elementor = is_string( $elementor_raw ) && strpos( $elementor_raw, $link_href_check ) !== false;

                    if ( ! $found_in_elementor ) {
                        // Link was NOT saved — restore backup
                        HTS_Content_Writer::restore_backup( $post_id, $writer_backup );

                        hts_add_log(
                            'Lien échoué post-save (' . ( $writer_result['builder'] ?? '?' ) . '): ancre="' . $matched_anchor . '" href="' . $link_href_check . '"',
                            'warning', 'linking'
                        );

                        $matched_content = null;
                    } else {
                        // Found in Elementor data — link is saved, post_content may lag behind
                        hts_add_log(
                            'Lien confirmé dans _elementor_data (post_content pas encore synchronisé): "' . $matched_anchor . '"',
                            'info', 'linking'
                        );
                    }
                } else {
                    // SUCCESS — link confirmed
                    if ( class_exists( 'HTS_Audit_Trail' ) ) {
                        HTS_Audit_Trail::log_link(
                            $post_id,
                            $target_id,
                            $matched_anchor,
                            'manual',
                            $writer_backup['content'] ?? '',
                            $saved_post->post_content,
                            HTS_Audit_Trail::get_gsc_snapshot( $post_id )
                        );
                    }

                    $suggestions = get_post_meta( $post_id, '_hts_link_suggestions', true );
                    if ( is_array( $suggestions ) ) {
                        $suggestions = array_filter( $suggestions, function( $s ) use ( $target_id ) {
                            return absint( $s['target_id'] ?? 0 ) !== $target_id;
                        } );
                        update_post_meta( $post_id, '_hts_link_suggestions', array_values( $suggestions ) );
                    }

                    hts_add_log( 'Lien interne ajouté (' . ( $writer_result['builder'] ?? 'standard' ) . '): "' . $matched_anchor . '" → ' . get_the_title( $target_id ) . ' (stratégie: ' . $strategy_used . ')', 'success', 'system' );

                    // Sprint 6.2d: sync outbound link counter
                    if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                        \HTS_Workflow_Engine::recount_internal_links( $post_id );
                    }

                    $context_snippet = $this->extract_plain_context( $verify_html, $target_url, $matched_anchor );

                    // Did the anchor change vs what was requested?
                    $anchor_changed = ( mb_strtolower( $matched_anchor ) !== mb_strtolower( $anchor_text ) );

                    $success_data = array(
                        'message'        => 'Lien ajouté avec succès.',
                        'matched_anchor' => $matched_anchor,
                        'original_anchor'=> $anchor_text,
                        'anchor_changed' => $anchor_changed,
                        'strategy'       => $strategy_used,
                        'context'        => $context_snippet,
                        'target_title'   => get_the_title( $target_id ),
                        'target_url'     => $target_url,
                        'source_title'   => get_the_title( $post_id ),
                        'source_url'     => get_permalink( $post_id ),
                        'source_edit_url'=> get_edit_post_link( $post_id, 'raw' ),
                        'edit_url'       => get_edit_post_link( $post_id, 'raw' ),
                        'in_intro'       => $in_intro,
                    );

                    if ( $return_mode ) return array( 'success' => true, 'data' => $success_data );
                    if ( ob_get_level() ) ob_end_clean();
                    wp_send_json_success( $success_data );
                    return;
                } // end else SUCCESS (verify passed)
            } // end else (writer succeeded)
        } // end if matched_content

        // ── FALLBACK: ALL STRATEGIES FAILED ──
        {
            // Ancre introuvable → suggérer des alternatives depuis le contenu
            // Chercher avec les mots de l'ancre ET du titre cible
            $alt_anchors = $this->find_alternative_anchors( $content_decoded, $target_id, $anchor_decoded );

            // Debug : log pour comprendre les échecs
            $text_plain = wp_strip_all_tags( $content_decoded );
            $text_sample = mb_substr( $text_plain, 0, 200 );
            hts_add_log(
                'Lien échoué : ancre="' . $anchor_decoded . '" post=' . $post_id .
                ' target=' . $target_id .
                ' alts=' . count( $alt_anchors ) .
                ' content_len=' . mb_strlen( $text_plain ) .
                ' sample="' . $text_sample . '"',
                'warning', 'linking'
            );

            // v2.5.12: Contextual error messages — explain WHY, not just what failed
            $connector_was_blocked = ! empty( $connector_limit_reached );

            if ( ! empty( $intro_blocked ) ) {
                // v2.5.13: Anchor exists only in intro zone — explain clearly
                $error_msg = 'Lien non ajouté. L\'expression "' . $anchor_text . '" n\'apparaît que dans l\'introduction de la page. '
                           . 'La zone intro est réservée au lien pilier. '
                           . 'Hack The SEO ne peut insérer un lien que dans le corps de l\'article (après le premier H2).';
            } elseif ( $connector_was_blocked ) {
                // The real reason: connector limit reached + anchor not in existing text
                $is_pg = ( get_post_type( $post_id ) === 'page' ) || (bool) get_post_meta( $post_id, '_hts_money_page', true );
                $ec = isset( $existing_connectors ) ? $existing_connectors : '?';
                $mc = isset( $max_connectors ) ? $max_connectors : '?';
                if ( $is_pg ) {
                    $error_msg = 'Lien non ajouté. Cette page contient déjà ' . $ec . ' lien(s) éditorial(s) ajouté(s) par Hack The SEO '
                               . '(maximum ' . $mc . ' pour cette page). '
                               . "L'expression \"" . $anchor_text . "\" n'apparait pas dans le texte existant pour un lien direct.";
                } else {
                    $error_msg = 'Lien non ajouté. Cette section contient déjà un lien éditorial. '
                               . "L'expression \"" . $anchor_text . "\" n'apparait pas dans le texte existant pour un lien direct.";
                }
            } else {
                $error_msg = "L'expression \"" . $anchor_text . "\" n'a pas été trouvée dans le contenu de cette page. "
                           . "Le lien ne peut être ajouté que si le texte d'ancre existe déjà dans un paragraphe.";
                if ( empty( $alt_anchors ) ) {
                    $error_msg .= " Aucune expression alternative n'a été détectée dans le contenu.";
                }
            }

            $error_data = array(
                'message'      => $error_msg,
                'alternatives' => $alt_anchors,
            );

            if ( $return_mode ) return array( 'success' => false, 'data' => $error_data );
            if ( ob_get_level() ) ob_end_clean();
            wp_send_json_error( $error_data );
        }
    }

    /**
     * Construit un pattern regex pour une ancre.
     * Exclut : intérieur de liens <a>, intérieur de headings <h1>-<h6>, attributs HTML.
     */
    private function build_anchor_pattern( $anchor ) {
        $escaped = preg_quote( $anchor, '/' );
        // Permettre des espaces flexibles
        $escaped = preg_replace( '/\\\\ /', '\\s+', $escaped );
        // Negative lookahead: not inside </a> AND not inside </h1>-</h6>
        return '/(?<!["\'])(' . $escaped . ')(?![^<]*<\/a>)(?![^<]*<\/h[1-6]>)/iu';
    }

    /**
     * Build a regex pattern that matches the anchor text even when inline HTML tags
     * (like <strong>, <em>, <span>) appear between or around the words.
     *
     * Example: anchor "transformer la recherche" will match:
     *   "<strong>transformer</strong> la recherche"
     *   "transformer <em>la recherche</em>"
     *
     * @since 2.4.18
     */
    private function build_tag_tolerant_pattern( $anchor ) {
        $words = preg_split( '/\s+/u', trim( $anchor ) );
        if ( count( $words ) < 2 ) return null; // single word — regular pattern handles it

        $tag = '(?:<[^>]*>)*'; // zero or more HTML tags
        $parts = array();
        foreach ( $words as $w ) {
            $parts[] = preg_quote( $w, '/' );
        }

        // Between words: optional close/open tags + whitespace + optional tags
        $inner = $tag . implode( $tag . '\\s+' . $tag, $parts ) . $tag;

        return '/(?<!["\'])(' . $inner . ')(?![^<]*<\/a>)(?![^<]*<\/h[1-6]>)/iu';
    }

    /**
     * Checks if a byte position falls inside an H1-H6 tag.
     */
    private function is_inside_heading( $content, $position ) {
        // Find the last opening tag before this position
        $before = substr( $content, 0, $position );
        // Check if the last <hN> is not closed yet
        if ( preg_match_all( '/<(h[1-6])[\s>]/i', $before, $opens, PREG_OFFSET_CAPTURE ) ) {
            $last_open = end( $opens[0] );
            $tag_name  = end( $opens[1] )[0];
            $last_open_pos = $last_open[1];
            // Check if there's a closing tag for this heading between the open and our position
            $between = substr( $content, $last_open_pos, $position - $last_open_pos );
            if ( stripos( $between, '</' . $tag_name . '>' ) === false ) {
                return true; // Still inside the heading
            }
        }
        return false;
    }

    /**
     * Returns the byte position of the first <h2 in the content, or false if none.
     * Used to protect the intro zone (before first H2) from link injection.
     */
    private function get_first_h2_pos( $content ) {
        // Match <h2 with any attributes or just <h2>
        if ( preg_match( '/<h2[\s>]/i', $content, $m, PREG_OFFSET_CAPTURE ) ) {
            return $m[0][1];
        }
        return false;
    }

    /**
     * Checks if a given position in the content is BEFORE the first H2 tag.
     * If no H2 exists, returns false (allow linking anywhere).
     */
    private function is_before_first_h2( $content, $position ) {
        $h2_pos = $this->get_first_h2_pos( $content );
        if ( $h2_pos === false ) return false; // no H2, allow anywhere
        return $position < $h2_pos;
    }

    /**
     * Count internal links already present in the intro zone (before first H2).
     * Only counts <a> tags pointing to the same site (internal links).
     * Returns 0 if no H2 exists (no intro zone concept).
     *
     * @since 2.4.12
     */
    private function count_intro_links( $content ) {
        $h2_pos = $this->get_first_h2_pos( $content );
        if ( $h2_pos === false ) return 0; // no H2 → no intro zone constraint

        $intro = substr( $content, 0, $h2_pos );
        $site_url = home_url();
        $count = 0;

        if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $intro, $matches ) ) {
            foreach ( $matches[1] as $href ) {
                // Count only internal links (same domain) — skip external, anchors, etc.
                if ( strpos( $href, $site_url ) === 0 || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                    $count++;
                }
            }
        }

        return $count;
    }

    /**
     * Check if the intro zone is saturated (already has max allowed internal links).
     * Best practice: max 1 internal link before first H2 (typically the pillar link).
     *
     * @since 2.4.12
     */
    private function is_intro_saturated( $content, $max_intro_links = 1 ) {
        return $this->count_intro_links( $content ) >= $max_intro_links;
    }

    /**
     * Extract a plain-text context snippet around an inserted link.
     * Returns: "…texte avant [ancre liée] texte après…"
     */
    private function extract_plain_context( $html_content, $target_url, $anchor_text ) {
        if ( empty( $html_content ) ) return '';

        $href = esc_url( $target_url );
        $needle = 'href="' . $href . '"';
        $pos = strpos( $html_content, $needle );
        if ( $pos === false ) return '';

        // Find the full <a>...</a> block
        $a_start = strrpos( substr( $html_content, 0, $pos ), '<a' );
        $a_end   = strpos( $html_content, '</a>', $pos );
        if ( $a_start === false || $a_end === false ) return '';
        $a_end += 4; // include </a>

        // Get the content around this link
        $before_start = max( 0, $a_start - 80 );
        $after_end    = min( strlen( $html_content ), $a_end + 80 );
        $raw = substr( $html_content, $before_start, $after_end - $before_start );

        // Strip ALL HTML tags to get plain text, but mark the anchor
        // Replace our <a>...</a> with a marker
        $raw = preg_replace( '/<a\s[^>]*' . preg_quote( $href, '/' ) . '[^>]*>(.*?)<\/a>/si', '⟦$1⟧', $raw );
        // Strip remaining HTML
        $raw = wp_strip_all_tags( $raw );
        // Clean up whitespace
        $raw = preg_replace( '/\s+/', ' ', trim( $raw ) );

        $prefix = ( $before_start > 0 ) ? '…' : '';
        $suffix = ( $after_end < strlen( $html_content ) ) ? '…' : '';

        return $prefix . $raw . $suffix;
    }

    /**
     * Strategy 4: Paragraph-level matching.
     * Prefers paragraphs after the first H2 (intro zone reserved for pillar link).
     * Falls back to before-H2 paragraphs ONLY if intro is not saturated (< 1 internal link).
     */
    private function paragraph_inject_link( $content, $anchor, $target_url, $target_title ) {
        if ( ! preg_match_all( '/(<(?:p|li|td|blockquote)[^>]*>)(.*?)(<\/(?:p|li|td|blockquote)>)/si', $content, $paras, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
            return null;
        }

        $first_h2_pos = $this->get_first_h2_pos( $content );
        $anchor_lower = mb_strtolower( $anchor );
        $before_h2_result = null; // fallback
        $intro_saturated = $this->is_intro_saturated( $content );

        foreach ( $paras as $para ) {
            $para_pos   = $para[0][1]; // byte offset of this <p> in content
            $open_tag   = $para[1][0];
            $inner_html = $para[2][0];
            $close_tag  = $para[3][0];
            $full_match = $para[0][0];

            $is_before_h2 = ( $first_h2_pos !== false && $para_pos < $first_h2_pos );
            $inner_text = $this->normalize_for_match( wp_strip_all_tags( $inner_html ) );
            $inner_text_lower = mb_strtolower( $inner_text );

            if ( mb_strpos( $inner_text_lower, $anchor_lower ) === false ) continue;

            $esc = preg_quote( $anchor, '/' );
            if ( preg_match( '/<a[^>]*>[^<]*' . $esc . '/si', $inner_html ) ) continue;

            $link = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( $target_title ) . '">' . $anchor . '</a>';

            $pattern = '/' . preg_quote( $anchor, '/' ) . '/iu';
            if ( preg_match( $pattern, $inner_html ) ) {
                $new_inner = preg_replace( $pattern, $link, $inner_html, 1 );
                $result = str_replace( $inner_html, $new_inner, $content );
                if ( $is_before_h2 ) {
                    // Only save as fallback if intro is NOT saturated
                    if ( ! $intro_saturated && ! $before_h2_result ) $before_h2_result = $result;
                    continue;
                }
                return $result;
            }

            $parts = preg_split( '/(<[^>]+>)/', $inner_html, -1, PREG_SPLIT_DELIM_CAPTURE );
            foreach ( $parts as &$part ) {
                if ( strpos( $part, '<' ) === 0 ) continue;
                $part_lower = mb_strtolower( html_entity_decode( $part, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
                if ( mb_strpos( $part_lower, $anchor_lower ) !== false ) {
                    $part = preg_replace( $pattern, $link, $part, 1 );
                    $new_inner = implode( '', $parts );
                    $result = str_replace( $inner_html, $new_inner, $content );
                    if ( $is_before_h2 ) {
                        if ( ! $intro_saturated && ! $before_h2_result ) $before_h2_result = $result;
                        continue 2;
                    }
                    return $result;
                }
            }
        }

        // Fallback: return before-H2 match only if intro was not saturated
        return $before_h2_result;
    }

    /**
     * Strategy 5: Simple paragraph text-node replacement — bulletproof.
     * Only matches in visible text inside <p> tags, never in attributes or tags.
     * Prefers paragraphs after the first H2. Falls back to before-H2 only if intro not saturated.
     */
    private function tolerant_inject_link( $content, $anchor, $target_url, $target_title ) {
        if ( mb_strlen( $anchor ) < 3 ) return null;

        // Only work with paragraphs — safe context
        if ( ! preg_match_all( '/<(?:p|li|td|blockquote)[^>]*>(.*?)<\/(?:p|li|td|blockquote)>/si', $content, $paras, PREG_SET_ORDER, 0 ) ) {
            return null;
        }

        $first_h2_pos = $this->get_first_h2_pos( $content );
        $anchor_lower = mb_strtolower( $anchor );
        $link = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( $target_title ) . '">';
        $before_h2_result = null;
        $intro_saturated = $this->is_intro_saturated( $content );

        foreach ( $paras as $para ) {
            // Find this paragraph's position in the content
            $para_pos = strpos( $content, $para[0] );
            $is_before_h2 = ( $first_h2_pos !== false && $para_pos !== false && $para_pos < $first_h2_pos );

            $p_html = $para[1];

            // Check not already linked in this paragraph
            if ( preg_match( '/<a\s/i', $p_html ) ) {
                $esc_a = preg_quote( $anchor, '/' );
                if ( preg_match( '/<a[^>]*>.*?' . $esc_a . '.*?<\/a>/si', $p_html ) ) continue;
            }

            // Split paragraph into text nodes and HTML tags
            $parts = preg_split( '/(<[^>]+>)/', $p_html, -1, PREG_SPLIT_DELIM_CAPTURE );
            $replaced = false;

            foreach ( $parts as $i => &$part ) {
                // Skip HTML tags
                if ( isset( $part[0] ) && $part[0] === '<' ) continue;
                if ( empty( trim( $part ) ) ) continue;

                // Decode entities for comparison
                $part_decoded = html_entity_decode( $part, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                $part_lower   = mb_strtolower( $part_decoded );

                $pos = mb_strpos( $part_lower, $anchor_lower );
                if ( $pos === false ) continue;

                // Found in this text node! Extract the actual cased text
                $actual = mb_substr( $part_decoded, $pos, mb_strlen( $anchor ) );

                // Replace in the original (non-decoded) part
                // Use the decoded version for precise replacement
                $before_part = mb_substr( $part_decoded, 0, $pos );
                $after_part  = mb_substr( $part_decoded, $pos + mb_strlen( $anchor ) );

                $part = $before_part . $link . $actual . '</a>' . $after_part;
                $replaced = true;
                break;
            }

            if ( $replaced ) {
                $new_p_html = implode( '', $parts );
                // Replace only this paragraph in the full content
                $new_content = str_replace( $para[1], $new_p_html, $content );

                // CRITICAL: verify the content actually changed
                if ( $new_content !== $content ) {
                    if ( $is_before_h2 ) {
                        // Only save as fallback if intro is NOT saturated
                        if ( ! $intro_saturated && ! $before_h2_result ) $before_h2_result = $new_content;
                        continue;
                    }
                    return $new_content;
                }
            }
        }

        // Fallback: return before-H2 match only if intro was not saturated
        return $before_h2_result;
    }

    /**
     * Retire les accents légers pour matching souple
     */
    private function remove_accents_light( $str ) {
        $map = array(
            'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
            'à'=>'a','â'=>'a','ä'=>'a',
            'ù'=>'u','û'=>'u','ü'=>'u',
            'î'=>'i','ï'=>'i',
            'ô'=>'o','ö'=>'o',
            'ç'=>'c',
            'É'=>'E','È'=>'E','Ê'=>'E','Ë'=>'E',
            'À'=>'A','Â'=>'A','Ä'=>'A',
            'Ù'=>'U','Û'=>'U','Ü'=>'U',
            'Î'=>'I','Ï'=>'I',
            'Ô'=>'O','Ö'=>'O',
            'Ç'=>'C',
        );
        return strtr( $str, $map );
    }

    /**
     * Extract significant keywords from a title (removes stopwords and short words).
     * Used by append_paragraph context for thematic widget/paragraph targeting.
     *
     * @since 2.5.12
     * @param string $title
     * @return array
     */
    private static function extract_significant_words( $title ) {
        $sw = array_flip( function_exists( 'hts_get_stopwords' )
            ? array_merge( hts_get_stopwords(), array( 'd','l','comment','pourquoi','quand','guide','complet','faut','savoir','comprendre','découvrir' ) )
            : array() );
        $words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $title ) );
        return array_values( array_filter( $words, function( $w ) use ( $sw ) {
            return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
        } ) );
    }

    /**
     * Get target post IDs that were dismissed for a given source post.
     * Used to prevent re-proposing the same source→target pair after dismiss.
     *
     * @since 2.5.12
     * @param int $source_post_id
     * @return int[]
     */
    private static function get_dismissed_targets( $source_post_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';

        // Check table exists
        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            return array();
        }

        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT data FROM {$table} WHERE post_id = %d AND agent = 'linking' AND status = 'dismissed'",
            $source_post_id
        ) );

        $targets = array();
        foreach ( $rows as $json ) {
            $d = json_decode( $json, true );
            if ( ! empty( $d['target_id'] ) ) {
                $targets[] = (int) $d['target_id'];
            }
        }

        return array_unique( $targets );
    }

    /**
     * Strategy 6: Contextual paragraph append — for AI-generated anchors.
     * Finds the most relevant paragraph (by keyword overlap with target title)
     * and appends the link at the end of that paragraph.
     * 
     * SEO-safe: the link appears at the end of a thematically relevant paragraph,
     * which is a natural editorial pattern for internal linking.
     *
     * @since 2.4.19
     * @param string $content       Post content HTML.
     * @param string $anchor        The AI-generated anchor text.
     * @param string $target_url    URL to link to.
     * @param string $target_title  Target page title (for title attr + keyword extraction).
     * @param int    $target_id     Target post ID.
     * @return string|null          Modified content or null if failed.
     */
    private function contextual_append_link( $content, $anchor, $target_url, $target_title, $target_id = 0, $bridge = '' ) {
        if ( ! preg_match_all( '/<(?:p|li|td|blockquote)[^>]*>(.*?)<\/(?:p|li|td|blockquote)>/si', $content, $paras, PREG_SET_ORDER, 0 ) ) {
            return null;
        }

        $first_h2_pos = $this->get_first_h2_pos( $content );
        $intro_saturated = $this->is_intro_saturated( $content );

        // Extract significant keywords from target title for relevance scoring
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','comment','pourquoi','quand','guide','complet','faut','savoir','comprendre','découvrir' ) ) : array() );
        $target_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $target_title ) );
        $target_words = array_values( array_filter( $target_words, function( $w ) use ( $sw ) {
            return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
        } ) );
        if ( empty( $target_words ) ) return null;

        // Check target URL not already in content
        if ( strpos( $content, esc_url( $target_url ) ) !== false ) return null;

        // Score each paragraph by keyword overlap with target
        $best_score = 0;
        $best_para  = null;
        $best_idx   = -1;

        foreach ( $paras as $idx => $para ) {
            $para_pos = strpos( $content, $para[0] );
            $is_before_h2 = ( $first_h2_pos !== false && $para_pos !== false && $para_pos < $first_h2_pos );

            // Skip intro paragraphs
            if ( $is_before_h2 ) continue;

            $p_text = mb_strtolower( wp_strip_all_tags( html_entity_decode( $para[1], ENT_QUOTES, 'UTF-8' ) ) );

            // Skip very short paragraphs (< 50 chars)
            if ( mb_strlen( $p_text ) < 50 ) continue;

            // Skip paragraphs with 2+ existing links
            if ( preg_match_all( '/<a\s/i', $para[1] ) >= 2 ) continue;

            // Score by keyword overlap
            $score = 0;
            foreach ( $target_words as $tw ) {
                if ( mb_strpos( $p_text, $tw ) !== false ) $score++;
            }

            if ( $score > $best_score ) {
                $best_score = $score;
                $best_para  = $para;
                $best_idx   = $idx;
            }
        }

        // Need at least 1 keyword match
        if ( $best_score < 1 || ! $best_para ) return null;

        // Build the link HTML
        $link_html = '<a href="' . esc_url( $target_url ) . '" title="' . esc_attr( $target_title ) . '">' . esc_html( $anchor ) . '</a>';

        // ── v2.4.20: Use bridge sentence if available ──
        // Bridge is a complete sentence from AI that already contains the anchor text.
        // We replace the anchor text inside the bridge with the link HTML.
        $insert_text = '';
        if ( ! empty( $bridge ) && mb_stripos( $bridge, $anchor ) !== false ) {
            // Replace anchor text in bridge with link
            $bridge_with_link = preg_replace(
                '/' . preg_quote( $anchor, '/' ) . '/iu',
                $link_html,
                $bridge,
                1
            );
            // Ensure bridge starts with space and ends properly
            $bridge_with_link = trim( $bridge_with_link );
            if ( ! preg_match( '/[.!?]$/', $bridge_with_link ) ) {
                $bridge_with_link .= '.';
            }
            $insert_text = ' ' . $bridge_with_link;

            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    'Contextual append (bridge) : "' . mb_substr( $anchor, 0, 40 ) . '" dans §' . ( $best_idx + 1 )
                    . ' — bridge: "' . mb_substr( $bridge, 0, 60 ) . '"',
                    'info', 'linking'
                );
            }
        } else {
            // Fallback: append bare link (legacy behavior)
            $insert_text = ' ' . $link_html . '.';

            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    'Contextual append (bare) : "' . mb_substr( $anchor, 0, 40 ) . '" ajouté en fin de §' . ( $best_idx + 1 )
                    . ' (score=' . $best_score . '/' . count( $target_words ) . ')',
                    'info', 'linking'
                );
            }
        }

        // Insert at the end of the best paragraph (before </p>)
        $inner_html = $best_para[1];
        $trimmed = rtrim( $inner_html );

        // Ensure paragraph ends with punctuation before appending
        $ends_with_punct = preg_match( '/[.!?;](\s*(<\/[a-z]+>)?\s*)$/si', $trimmed );
        if ( ! $ends_with_punct ) {
            $trimmed .= '.';
        }

        $new_inner = $trimmed . $insert_text;

        // Replace the paragraph content
        $old_p = $best_para[0];
        $new_p = str_replace( $inner_html, $new_inner, $old_p );
        $result = str_replace( $old_p, $new_p, $content );

        if ( $result === $content ) return null;

        return $result;
    }

    /**
     * Fuzzy matching : trouve un segment du contenu qui contient les mots significatifs de l'ancre
     */
    private function fuzzy_find_anchor( $content, $anchor ) {
        $stop = array_flip( explode( ',', 'le,la,les,un,une,des,du,de,d,l,en,et,ou,à,a,au,aux,pour,par,sur,dans,avec,sans,ce,ces,son,sa,ses' ) );

        $anchor_words = preg_split( '/[\s,\-:\']+/', mb_strtolower( $anchor ) );
        $anchor_words = array_values( array_filter( $anchor_words, function( $w ) use ( $stop ) {
            return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] );
        } ) );

        if ( count( $anchor_words ) < 1 ) return null;

        // Extraire le texte visible (sans HTML)
        $text = wp_strip_all_tags( $content );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        // Découper en phrases
        $sentences = preg_split( '/(?<=[.!?;:])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );

        $best_match  = null;
        $best_score  = 0;

        foreach ( $sentences as $sentence ) {
            $sent_lower = mb_strtolower( $sentence );
            $words = preg_split( '/\s+/', trim( $sentence ) );
            if ( count( $words ) < 2 ) continue;

            // Fenêtre glissante de 2 à 7 mots
            for ( $len = 2; $len <= min( 7, count( $words ) ); $len++ ) {
                for ( $start = 0; $start <= count( $words ) - $len; $start++ ) {
                    $segment = implode( ' ', array_slice( $words, $start, $len ) );
                    $segment_clean = trim( preg_replace( '/[.,;:!?]+$/', '', $segment ) );
                    if ( mb_strlen( $segment_clean ) < 8 || mb_strlen( $segment_clean ) > 80 ) continue;

                    $seg_lower = mb_strtolower( $segment_clean );

                    // Compter les mots significatifs de l'ancre trouvés dans le segment
                    $found = 0;
                    foreach ( $anchor_words as $aw ) {
                        if ( mb_strpos( $seg_lower, $aw ) !== false ) $found++;
                    }

                    if ( $found < 1 ) continue;

                    // Score: mots matchés / total, bonus si longueur proche de l'ancre
                    $score = ( $found / count( $anchor_words ) ) * 100;
                    $len_diff = abs( mb_strlen( $segment_clean ) - mb_strlen( $anchor ) );
                    $score -= $len_diff * 0.5; // pénalité longueur
                    $score += $found * 10; // bonus mots trouvés

                    if ( $score > $best_score ) {
                        // Vérifier que ce segment existe bien dans le HTML et n'est pas déjà linké
                        $test = $this->build_anchor_pattern( $segment_clean );
                        if ( preg_match( $test, $content ) ) {
                            $esc_seg = preg_quote( $segment_clean, '/' );
                            if ( ! preg_match( '/<a[^>]*>[^<]*' . $esc_seg . '/si', $content ) ) {
                                $best_match = $segment_clean;
                                $best_score = $score;
                            }
                        }
                    }
                }
            }
        }

        return $best_match;
    }

    /**
     * Trouve des ancres alternatives dans le contenu, liées au sujet de la page cible
     */
    /**
     * Trouve des ancres alternatives dans le contenu, liées au sujet de la page cible.
     * Utilise les mots du titre cible ET de l'ancre originale pour maximiser les résultats.
     */
    private function find_alternative_anchors( $content, $target_id, $original_anchor = '' ) {
        $target_title = get_the_title( $target_id );

        $stop = array_flip( explode( ',', 'le,la,les,un,une,des,du,de,d,l,en,et,ou,à,a,au,aux,pour,par,sur,dans,avec,sans,ce,ces,son,sa,ses,est,qui,que,quoi,comment,pourquoi,être,avoir,fait,plus,très,bien,tout' ) );

        // Combiner mots du titre + mots de l'ancre originale
        $combined = mb_strtolower( html_entity_decode( $target_title . ' ' . $original_anchor, ENT_QUOTES, 'UTF-8' ) );
        $all_words = preg_split( '/[\s,\-:\']+/', $combined );
        $search_words = array_values( array_unique( array_filter( $all_words, function( $w ) use ( $stop ) {
            return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] );
        } ) ) );

        if ( empty( $search_words ) ) return array();

        $content_decoded = html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $text = wp_strip_all_tags( $content_decoded );

        // Découper en phrases
        $sentences = preg_split( '/(?<=[.!?;:])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );

        $candidates = array();
        foreach ( $sentences as $sentence ) {
            $sent_lower = mb_strtolower( $sentence );

            // Compter les mots-clés trouvés dans cette phrase
            $matches = 0;
            foreach ( $search_words as $sw ) {
                if ( mb_strpos( $sent_lower, $sw ) !== false ) $matches++;
            }
            if ( $matches === 0 ) continue;

            $words = preg_split( '/\s+/', trim( $sentence ) );

            // Fenêtre glissante de 2 à 6 mots
            for ( $len = 2; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $start = 0; $start <= count( $words ) - $len; $start++ ) {
                    $phrase = implode( ' ', array_slice( $words, $start, $len ) );
                    $phrase = trim( preg_replace( '/[.,;:!?]+$/', '', $phrase ) );
                    if ( mb_strlen( $phrase ) < 8 || mb_strlen( $phrase ) > 60 ) continue;

                    $phrase_lower = mb_strtolower( $phrase );

                    // Le segment doit contenir au moins un mot-clé
                    $seg_matches = 0;
                    foreach ( $search_words as $sw ) {
                        if ( mb_strpos( $phrase_lower, $sw ) !== false ) $seg_matches++;
                    }
                    if ( $seg_matches === 0 ) continue;

                    // Vérifier que le segment existe dans le HTML et n'est pas déjà linké
                    $test_pattern = $this->build_anchor_pattern( $phrase );
                    if ( preg_match( $test_pattern, $content ) || preg_match( $test_pattern, $content_decoded ) ) {
                        $esc = preg_quote( $phrase, '/' );
                        if ( ! preg_match( '/<a[^>]*>[^<]*' . $esc . '/si', $content_decoded ) ) {
                            $score = $seg_matches * 20 + ( $len >= 3 ? 10 : 0 ) + $matches;
                            $candidates[ $phrase ] = max( $candidates[ $phrase ] ?? 0, $score );
                        }
                    }
                }
            }
        }

        arsort( $candidates );
        return array_slice( array_keys( $candidates ), 0, 5 );
    }

    /**
     * Ignore une suggestion
     */
    public function ajax_dismiss_link() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ) );
        }
        HTS_Subscription::require_tier(2);

        $post_id   = absint( $_POST['post_id'] ?? 0 );
        $target_id = absint( $_POST['target_id'] ?? 0 );

        $suggestions = get_post_meta( $post_id, '_hts_link_suggestions', true );
        if ( is_array( $suggestions ) ) {
            $old_count = count( $suggestions );
            $suggestions = array_filter( $suggestions, function( $s ) use ( $target_id ) {
                return absint( $s['target_id'] ?? 0 ) !== $target_id;
            } );
            update_post_meta( $post_id, '_hts_link_suggestions', array_values( $suggestions ) );
            if ( function_exists('hts_add_log') ) {
                hts_add_log( sprintf('🚫 Maillage suggestion ignoree : "%s" → "%s"', get_the_title($post_id), get_the_title($target_id)), 'info', 'linking' );
            }
        }

        // v2.5.13: Persist dismiss in workflow_actions so get_dismissed_targets() survives re-scan
        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            // Avoid duplicate: check if already dismissed for this source→target pair
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE post_id = %d AND agent = 'linking' AND status = 'dismissed' AND data LIKE %s LIMIT 1",
                $post_id,
                '%"target_id":' . $target_id . '%'
            ) );
            if ( ! $exists ) {
                $wpdb->insert( $table, array(
                    'agent'       => 'linking',
                    'type'        => 'add_link',
                    'post_id'     => $post_id,
                    'data'        => wp_json_encode( array(
                        'target_id'    => $target_id,
                        'target_title' => get_the_title( $target_id ),
                    ) ),
                    'priority'    => 'medium',
                    'status'      => 'dismissed',
                    'created_at'  => current_time( 'mysql' ),
                    'resolved_at' => current_time( 'mysql' ),
                    'resolved_by' => get_current_user_id(),
                ), array( '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d' ) );
            }
        }

        wp_send_json_success();
    }

    /**
     * Supprime un lien interne déjà appliqué (garde le texte, retire le <a>)
     */
    public function ajax_remove_link() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ) );
        }
        HTS_Subscription::require_tier(2);

        $post_id    = absint( $_POST['post_id'] ?? 0 );
        $target_url = esc_url_raw( $_POST['target_url'] ?? '' );

        if ( ! $post_id || ! $target_url ) {
            wp_send_json_error( array( 'message' => 'Paramètres manquants.' ) );
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            wp_send_json_error( array( 'message' => 'Article introuvable.' ) );
        }

        $content_before = $post->post_content;

        // Use Content Writer for builder-aware link removal
        $writer_result = HTS_Content_Writer::remove_link( $post_id, $target_url );

        if ( $writer_result['success'] ) {
            if ( class_exists( 'HTS_Audit_Trail' ) ) {
                $after_content = get_post( $post_id )->post_content ?? '';
                HTS_Audit_Trail::log_link_removed( $post_id, $target_url, $content_before, $after_content );
            }

            hts_add_log( 'Lien interne supprimé (' . ( $writer_result['builder'] ?? 'standard' ) . ') dans #' . $post_id . ' → ' . $target_url, 'info', 'system' );
            wp_send_json_success( array( 'message' => 'Lien supprimé.' ) );
        } else {
            wp_send_json_error( array( 'message' => $writer_result['message'] ?? 'Lien introuvable dans le contenu.' ) );
        }
    }

    /**
     * Récupère toutes les suggestions en attente (pour le dashboard)
     */
    public function get_all_pending_suggestions() {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta}
             WHERE meta_key = '_hts_link_suggestions'
             AND meta_value != '' AND meta_value != 'a:0:{}'
             ORDER BY post_id DESC
             LIMIT 50",
            ARRAY_A
        );

        $pending = array();
        foreach ( $results as $row ) {
            $suggestions = maybe_unserialize( $row['meta_value'] );
            if ( ! empty( $suggestions ) && is_array( $suggestions ) ) {
                $pending[] = array(
                    'post_id'     => (int) $row['post_id'],
                    'post_title'  => get_the_title( $row['post_id'] ),
                    'edit_url'    => get_edit_post_link( $row['post_id'], 'raw' ),
                    'suggestions' => $suggestions,
                );
            }
        }

        return $pending;
    }

    /* ═══════════════════════════════════════════════════
     *  SESSION K — PROPOSITIONS INBOX
     * ═══════════════════════════════════════════════════ */

    /**
     * Cron : scanner les articles pour des opportunités de maillage interne.
     *
     * @since 2.4.7
     */
    /**
     * Phase 5.4: Sync _hts_internal_links_out for published pages that don't have it.
     * Runs once per cron scan cycle, max 50 posts per batch to avoid timeout.
     */
    private function sync_missing_link_counts() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return;
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $post_ids = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_internal_links_out'
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND pm.meta_id IS NULL
             LIMIT 50"
        );
        if ( empty( $post_ids ) ) return;
        foreach ( $post_ids as $pid ) {
            HTS_Workflow_Engine::recount_internal_links( (int) $pid );
        }
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'Sync link counts: %d pages mises à jour', count( $post_ids ) ), 'info', 'linking' );
        }
    }

    public function cron_scan_linking() {
        if ( class_exists( 'HTS_Subscription' ) && HTS_Subscription::get_plan_tier() < 2 ) return;
        try {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return;
        if ( ! HTS_Workflow_Engine::is_agent_enabled( 'linking' ) ) return;

        // ── OPTIM 1.3 : Guard anti-boucle — max 1 scan par 7j ──
        $last_scan = (int) get_option( 'hts_last_cron_linking_scan', 0 );
        if ( time() - $last_scan < 7 * DAY_IN_SECONDS ) {
            hts_debug_log( '[Linking] Cron scan ignoré — dernier scan il y a ' . round( ( time() - $last_scan ) / 3600, 1 ) . 'h (guard 7j)' );
            return;
        }
        update_option( 'hts_last_cron_linking_scan', time(), false );

        // Auto-purge propositions obsolètes (ancres qui n'existent plus dans le contenu)
        global $wpdb;
        $wa_table = $wpdb->prefix . 'hts_workflow_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wa_table ) ) ) {
            $stale_actions = $wpdb->get_results(
                "SELECT id, post_id, data FROM {$wa_table} WHERE type = 'add_internal_links' AND status = 'pending' AND created_at < DATE_SUB(NOW(), INTERVAL 3 DAY)"
            );
            $cc = array();
            $purged = 0;
            foreach ( $stale_actions as $sa ) {
                $meta = json_decode( $sa->data, true );
                if ( ! is_array( $meta ) ) continue;
                $anc = $meta['anchor_text'] ?? '';
                $at  = $meta['anchor_type'] ?? 'extract';
                if ( $at !== 'extract' || empty( $anc ) ) continue;
                if ( ! isset( $cc[ $sa->post_id ] ) ) {
                    $raw = get_post_field( 'post_content', $sa->post_id );
                    $cc[ $sa->post_id ] = mb_strtolower( wp_strip_all_tags( html_entity_decode( $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
                }
                if ( mb_strpos( $cc[ $sa->post_id ], mb_strtolower( $anc ) ) === false ) {
                    $wpdb->delete( $wa_table, array( 'id' => $sa->id ) );
                    $purged++;
                }
            }
            if ( $purged > 0 && function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf( 'Weekly scan : %d proposition(s) de maillage obsolète(s) supprimée(s).', $purged ), 'info', 'workflow' );
            }
        }

        // Phase 5.4: Sync _hts_internal_links_out for pages missing this counter
        $this->sync_missing_link_counts();

        $count = 0;

        // S18 FIX: Iterate over all available languages in cron context
        $cron_languages = array( '' ); // Default: no specific language
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $cron_languages = array_keys( HTS_Language::get_available_languages() );
        }

        foreach ( $cron_languages as $cron_lang ) {

        // ── Session N : Source primaire = données cocon (clusters + paires pilier/enfant) ──
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new \HTS_Cocon();
            $cocon_data = $cocon->get_cocon_data( $cron_lang ? $cron_lang : '' );

            if ( ! empty( $cocon_data['clusters'] ) ) {
                $nodes = $cocon_data['nodes'] ?? array();

                foreach ( $cocon_data['clusters'] as $cluster_name => $cluster ) {
                    if ( in_array( $cluster_name, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;

                    // Récupérer les suggestions du cocon pour ce cluster
                    $result = $cocon->suggest_cluster_links( $cluster_name );
                    if ( empty( $result['suggestions'] ) ) continue;

                    foreach ( $result['suggestions'] as $sug ) {
                        $source_id = (int) $sug['source_id'];
                        $target_id = (int) $sug['target_id'];

                        // Budget check
                        if ( class_exists( 'HTS_Cocon_Commander' ) && method_exists( 'HTS_Cocon_Commander', 'get_link_budget_for_post' ) ) {
                            $budget_info = \HTS_Cocon_Commander::get_link_budget_for_post( $source_id );
                            if ( $budget_info['budget'] <= 0 ) {
                                hts_debug_log( '[Linking cron] Skip saturé #' . $source_id );
                                continue;
                            }
                        }

                        // Check pause linking (30j après 3 dismiss)
                        $paused_until = (int) get_post_meta( $source_id, '_hts_linking_paused', true );
                        if ( $paused_until > 0 && time() < $paused_until ) {
                            continue; // Article en pause linking
                        }

                        // Ancre check (html_entity_decode + Elementor fallback)
                        $anchor_type = $sug['anchor_type'] ?? 'extract';
                        if ( $anchor_type === 'extract' && ! empty( $sug['anchor_text'] ) ) {
                            $src_post = get_post( $source_id );
                            if ( $src_post ) {
                                $decoded_cron = html_entity_decode( wp_strip_all_tags( $src_post->post_content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                                $af_cron = ( mb_stripos( $decoded_cron, $sug['anchor_text'] ) !== false );
                                if ( ! $af_cron ) {
                                    $el_cron = get_post_meta( $source_id, '_elementor_data', true );
                                    if ( is_string( $el_cron ) && ! empty( $el_cron ) ) {
                                        $af_cron = ( mb_stripos( html_entity_decode( wp_strip_all_tags( $el_cron ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ), $sug['anchor_text'] ) !== false );
                                    }
                                }
                                if ( ! $af_cron ) {
                                    hts_debug_log( '[Linking cron] Skip ancre introuvable dans #' . $source_id );
                                    continue;
                                }
                            }
                        }

                        // Cible publiée
                        if ( ! get_post( $target_id ) || get_post_status( $target_id ) !== 'publish' ) {
                            continue;
                        }

                        // Vérifier si le lien existe déjà dans le contenu
                        if ( method_exists( $cocon, 'link_exists_in_content' ) ) {
                            // La méthode est private, on vérifie autrement
                        }
                        $source_post = get_post( $source_id );
                        if ( ! $source_post ) continue;

                        $target_url = get_permalink( $target_id );
                        if ( $target_url && stripos( $source_post->post_content, $target_url ) !== false ) continue;
                        // Vérifier aussi avec le path relatif
                        $target_path = wp_parse_url( $target_url, PHP_URL_PATH );
                        if ( $target_path && stripos( $source_post->post_content, $target_path ) !== false ) continue;

                        // Proposer l'action
                        $link_type = $sug['link_type'] ?? 'cluster';
                        $priority  = $sug['priority'] ?? 'medium';

                        $why = sprintf(
                            'Lien manquant dans le cocon "%s" : %s → %s (%s)',
                            $cluster_name,
                            mb_substr( $sug['source_title'] ?? '', 0, 40 ),
                            mb_substr( $sug['target_title'] ?? '', 0, 40 ),
                            $link_type === 'child_to_pillar' ? 'enfant vers pilier' :
                                ( $link_type === 'pillar_to_child' ? 'pilier vers enfant' : 'lien sémantique' )
                        );

                        // Enrichir le reason avec GSC si disponible
                        $gsc_tag = ! empty( $sug['gsc']['tag'] ) ? $sug['gsc']['tag'] : '';
                        if ( $gsc_tag && strpos( $why, '📊' ) === false ) {
                            $why .= ' · ' . $gsc_tag;
                        }

                        $action_id = HTS_Workflow_Engine::propose(
                            'linking',
                            'add_internal_links',
                            $source_id,
                            array(
                                'reason'        => $why,
                                'source_cocon'  => true,
                                'cluster'       => $cluster_name,
                                'target_id'     => $target_id,
                                'target_title'  => $sug['target_title'] ?? '',
                                'anchor_text'   => $sug['anchor_text'] ?? '',
                                'anchor_method' => $sug['anchor_method'] ?? '',
                                'anchor_type'   => $sug['anchor_type'] ?? 'extract',
                                'anchor_bridge' => $sug['anchor_bridge'] ?? '',
                                'link_type'     => $link_type,
                                'suggestion'    => 'Ajouter un lien vers "' . mb_substr( $sug['target_title'] ?? '', 0, 50 ) . '"',
                                'gsc'           => $sug['gsc'] ?? array(),
                            ),
                            $priority
                        );

                        if ( $action_id ) $count++;
                        if ( $count >= 200 ) break 2; // Session P : limite relevée, toutes les propositions visibles dans Inbox
                    }
                }

                if ( $count > 0 && function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Linking cron (cocon) : {$count} proposition(s) créée(s)", 'info', 'linking' );
                }
                return;
            }
        }

        // ── Fallback : scan classique pour les sites sans cocon analysé ──
        global $wpdb;
        $max_links = self::get_max_links_per_post();

        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title,
                    COALESCE( lm.meta_value, 0 ) + 0 AS links_out
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} lm ON p.ID = lm.post_id AND lm.meta_key = '_hts_internal_links_out'
             WHERE p.post_type = 'post'
               AND p.post_status = 'publish'
               AND ( COALESCE( lm.meta_value, 0 ) + 0 < %d )
             ORDER BY COALESCE( lm.meta_value, 0 ) + 0 ASC, p.post_modified DESC
             LIMIT 50",
            max( 2, (int) ( $max_links * 0.5 ) )
        ), ARRAY_A );

        foreach ( $posts as $row ) {
            $proposed = $this->propose_inbox_actions( (int) $row['ID'], (int) $row['links_out'] );
            $count += $proposed;
            if ( $count >= 20 ) break;
        }

        if ( $count > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Internal Linking cron (fallback) : {$count} proposition(s) créée(s)", 'info', 'linking' );
        }
        } // end foreach $cron_languages (S18 FIX)
        } catch ( \Throwable $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Linking cron CRASH: ' . $e->getMessage() . ' L' . $e->getLine(), 'error', 'linking' );
            }
        }
    }

    /**
     * Proposer des actions de maillage interne dans l'Inbox.
     *
     * Vérifie les liens sortants existants, identifie les pages orphelines
     * ou sous-liées, et crée des actions avec un "pourquoi" non-expert.
     *
     * @since 2.4.7
     * @param int $post_id
     * @param int $links_out Nombre actuel de liens sortants (optionnel)
     * @return int Nombre de propositions créées
     */
    public function propose_inbox_actions( $post_id, $links_out = -1 ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;

        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return 0;

        // Compter les liens sortants actuels
        if ( $links_out < 0 ) {
            $links_out = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );
        }

        // Compter les liens entrants
        $links_in = (int) get_post_meta( $post_id, '_hts_internal_links_in', true );

        // Vérifier les suggestions existantes
        $existing_suggestions = get_post_meta( $post_id, '_hts_link_suggestions', true );
        $has_suggestions = ! empty( $existing_suggestions );

        // Identifier le cluster/cocon si disponible
        $cluster = '';
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon_id = get_post_meta( $post_id, '_hts_cocon_id', true );
            if ( $cocon_id ) {
                $cluster = get_post_meta( $post_id, '_hts_cocon_name', true ) ?: 'Cluster #' . $cocon_id;
            }
        }

        // Construire le "pourquoi" avec données chiffrées
        $why_parts = array();
        $priority  = 'medium';

        if ( $links_out === 0 && $links_in === 0 ) {
            $why_parts[] = 'Page orpheline : aucun lien interne (ni entrant, ni sortant)';
            $priority    = 'high';
        } elseif ( $links_out === 0 ) {
            $why_parts[] = 'Aucun lien interne sortant — cette page ne distribue pas de "jus SEO" vers vos autres articles';
            $priority    = 'high';
        } elseif ( $links_in === 0 ) {
            $why_parts[] = 'Aucun lien entrant vers cette page — Google aura du mal à la découvrir et la positionner';
            $priority    = 'high';
        } else {
            $max = self::get_max_links_per_post();
            $why_parts[] = $links_out . ' lien(s) sortant(s) sur ' . $max . ' recommandé(s)';
        }

        if ( $cluster ) {
            $why_parts[] = 'Fait partie du cluster "' . $cluster . '"';
        }

        $why = implode( '. ', $why_parts ) . '.';

        $action_id = HTS_Workflow_Engine::propose(
            'linking',
            'add_internal_links',
            $post_id,
            array(
                'reason'       => $why,
                'links_out'    => $links_out,
                'links_in'     => $links_in,
                'cluster'      => $cluster,
                'suggestion'   => 'Hack The SEO va analyser les meilleures opportunités de maillage',
                'has_existing' => $has_suggestions,
            ),
            $priority
        );

        return $action_id ? 1 : 0;
    }

    /* ═══════════════════════════════════════════════
     *  COACH INTEGRATION STUBS — Sprint 5.1
     * ═══════════════════════════════════════════════ */

    /**
     * Fix orphan pages by analyzing and proposing internal links.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_ids: int[] }
     * @return bool
     */
    public static function fix_orphans_from_coach( $params ) {
        $post_ids = isset( $params['post_ids'] ) ? array_map( 'intval', (array) $params['post_ids'] ) : array();
        if ( empty( $post_ids ) ) return false;

        $instance = new self();
        $count = 0;
        foreach ( $post_ids as $pid ) {
            if ( $pid > 0 && get_post( $pid ) ) {
                $instance->analyze_for_post( $pid );
                $count++;
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach: fix_orphans_from_coach analysé {$count} page(s)", 'info', 'coach' );
        }

        return $count > 0;
    }

    /**
     * Suggest internal links for a specific post.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_id: int, max_links: int, target_ids: int[] }
     * @return bool
     */
    public static function suggest_from_coach( $params ) {
        $post_id = isset( $params['post_id'] ) ? (int) $params['post_id'] : 0;
        if ( $post_id <= 0 || ! get_post( $post_id ) ) return false;

        $instance = new self();
        $instance->analyze_for_post( $post_id );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach: suggest_from_coach pour post #{$post_id}", 'info', 'coach' );
        }

        return true;
    }

    /**
     * Sprint 6.2c — Remove a link tag from content, preserving anchor text.
     *
     * Replaces "<a href="...">texte</a>" with just "texte".
     * Uses exact str_replace to avoid regex false positives.
     *
     * @since 2.5.0
     * @param string $content   The post_content.
     * @param string $full_tag  The complete <a>...</a> tag to remove.
     * @return string Modified content with link removed but text preserved.
     */
    public function remove_link_from_content( $content, $full_tag ) {
        // Extract href and anchor text from the full tag
        if ( preg_match( '/<a\s[^>]*>(.*?)<\/a>/is', $full_tag, $m ) ) {
            $anchor_text = $m[1];
        } else {
            $anchor_text = wp_strip_all_tags( $full_tag );
        }

        // Strategy 1: exact str_replace (fastest, works when HTML is byte-identical)
        $new_content = str_replace( $full_tag, $anchor_text, $content );

        // Strategy 2: regex match by href + anchor (tolerant to attribute reordering)
        if ( $new_content === $content ) {
            if ( preg_match( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $full_tag, $href_m ) ) {
                $target_href = preg_quote( $href_m[1], '/' );
                $anchor_escaped = preg_quote( $anchor_text, '/' );
                // Match any <a> with this exact href and anchor, regardless of other attributes
                $pattern = '/<a\s[^>]*href=["\']' . $target_href . '["\'][^>]*>' . $anchor_escaped . '<\/a>/is';
                $result = preg_replace( $pattern, $anchor_text, $content, 1 );
                if ( $result !== null && $result !== $content ) {
                    $new_content = $result;
                }
            }
        }

        // Strategy 3: match by href only (if anchor has special chars that break regex)
        if ( $new_content === $content ) {
            if ( preg_match( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $full_tag, $href_m ) ) {
                $target_href = preg_quote( $href_m[1], '/' );
                $pattern = '/<a\s[^>]*href=["\']' . $target_href . '["\'][^>]*>(.*?)<\/a>/is';
                $result = preg_replace( $pattern, '$1', $content, 1 );
                if ( $result !== null && $result !== $content ) {
                    $new_content = $result;
                }
            }
        }

        if ( $new_content !== $content && function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( '🔄 Lien supprimé (swap) : « %s »', mb_substr( wp_strip_all_tags( $anchor_text ), 0, 50 ) ),
                'info', 'internal-linking'
            );
        }

        return $new_content;
    }
}
