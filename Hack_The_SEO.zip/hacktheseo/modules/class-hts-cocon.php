<?php
defined( 'ABSPATH' ) || exit;
/**
 * Module : Cocon Sémantique v2 — Clustering NLP + Intelligence IA
 *
 * - Clustering par analyse sémantique IA (pas les catégories WP)
 * - Extraction TF-IDF des mots-clés principaux
 * - Détection automatique des pages piliers (score multi-critères)
 * - Rôle par page : pilier, fille, satellite, orpheline
 * - Suggestion de clusters manquants
 * - Hiérarchie pilier → filles
 *
 * @since 1.14.5 (Light — ported from Full v2.4.1)
 */
class HTS_Cocon {

    private $openai_key;
    private $analysis_lang = 'fr';
    private $cached_vectors = array();
    private $cached_site_corpus = array();
    private $cached_diverse_pages = array();
    private $used_anchors_by_source = array();
    private $source_content_cache = array();
    private $used_anchors_by_target = array();

    /** @var array Runtime cache for hts_cocon_data to avoid repeated DB reads */
    private static $cocon_data_cache = array();

    /**
     * Get cocon data with runtime cache.
     *
     * @param string $lang Language code (empty for default).
     * @return array
     */
    public static function get_cached_cocon_data( $lang = '' ) {
        // Fix Polylang: "Afficher toutes les langues" → $lang is 'all' or empty
        // Use site locale as primary (pll_default_language may differ from site locale)
        if ( ( empty( $lang ) || $lang === 'all' ) && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $lang = substr( get_locale(), 0, 2 );
            if ( empty( $lang ) && function_exists( 'pll_default_language' ) ) {
                $lang = pll_default_language( 'slug' );
            }
        }
        // Sanitize: 'all' should never reach DB lookup
        if ( $lang === 'all' ) $lang = '';

        $key = $lang ?: '__default__';
        if ( isset( self::$cocon_data_cache[ $key ] ) ) {
            return self::$cocon_data_cache[ $key ];
        }
        $data = null;
        if ( $lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $data = get_option( 'hts_cocon_data_' . $lang, array() );
        }
        if ( empty( $data ) ) {
            $data = get_option( 'hts_cocon_data', array() );
        }
        self::$cocon_data_cache[ $key ] = $data;
        return $data;
    }

    public function init() {
        $this->openai_key = hts_get_openai_key();
        add_action( 'wp_ajax_hts_cocon_analyze',       array( $this, 'ajax_analyze' ) );
        add_action( 'wp_ajax_hts_cocon_analyze_step', array( $this, 'ajax_analyze_step' ) );
        add_action( 'wp_ajax_hts_cocon_restore',       array( $this, 'ajax_restore_backup' ) );
        add_action( 'wp_ajax_hts_cocon_export',        array( $this, 'ajax_export_data' ) );
        add_action( 'wp_ajax_hts_cocon_import',        array( $this, 'ajax_import_data' ) );
        add_action( 'wp_ajax_hts_cocon_purge',         array( $this, 'ajax_purge_data' ) );
        add_action( 'wp_ajax_hts_cocon_refresh_links',  array( $this, 'ajax_refresh_links' ) );
        add_action( 'wp_ajax_hts_cocon_graph_data',     array( $this, 'ajax_graph_data' ) );
        add_action( 'wp_ajax_hts_cocon_suggest',        array( $this, 'ajax_suggest_links' ) );
        add_action( 'wp_ajax_hts_cocon_bulk_apply',     array( $this, 'ajax_bulk_apply' ) );
        add_action( 'wp_ajax_hts_cocon_detail',         array( $this, 'ajax_cluster_detail' ) );
        add_action( 'wp_ajax_hts_cocon_monitoring',      array( $this, 'ajax_monitoring' ) );
        add_action( 'wp_ajax_hts_cocon_debug_page',     array( $this, 'ajax_debug_page' ) );
        add_action( 'wp_ajax_hts_cocon_page_decision',  array( $this, 'ajax_page_decision' ) );

        // Invalidate page summary cache when post is updated (v2.4.13)
        add_action( 'save_post', array( __CLASS__, 'invalidate_summary_cache' ), 10, 1 );
    }

    /* ── TF-IDF KEYWORDS ── */

    private function extract_keywords( $text, $max = 10 ) {
        $text = mb_strtolower( html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) );
        $text = preg_replace( '/[^a-zàâäéèêëïîôùûüÿçœæ\s\'-]/u', ' ', $text );
        $stop = array_flip( explode( ',', 'le,la,les,un,une,des,du,de,d,l,au,aux,en,et,ou,mais,donc,car,ni,que,qui,quoi,dont,où,ce,ces,cette,cet,se,son,sa,ses,leur,leurs,mon,ma,mes,ton,ta,tes,nous,vous,ils,elles,je,tu,il,elle,on,ne,pas,plus,très,aussi,bien,pour,par,sur,dans,avec,sans,sous,entre,vers,chez,est,sont,être,avoir,faire,fait,dit,peut,tout,tous,toute,toutes,comme,même,autre,autres,quand,comment,pourquoi,si,alors,donc,puis,après,avant,depuis,encore,déjà,peu,beaucoup,trop,assez,ici,là,there,article,page' ) );
        $words = preg_split( '/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $words = array_filter( $words, function( $w ) use ( $stop ) { return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] ); } );

        $freq = array_count_values( $words );
        arsort( $freq );

        $bigrams = array();
        $prev = '';
        foreach ( $words as $w ) {
            if ( $prev && ! isset( $stop[ $prev ] ) && ! isset( $stop[ $w ] ) ) {
                $bg = $prev . ' ' . $w;
                $bigrams[ $bg ] = ( $bigrams[ $bg ] ?? 0 ) + 1;
            }
            $prev = $w;
        }
        arsort( $bigrams );

        $scores = array();
        foreach ( array_slice( $bigrams, 0, 15 ) as $bg => $c ) {
            if ( $c >= 2 ) $scores[ $bg ] = $c * 2.5;
        }
        foreach ( array_slice( $freq, 0, 30 ) as $w => $c ) {
            if ( $c >= 2 ) $scores[ $w ] = ( $scores[ $w ] ?? 0 ) + $c;
        }
        arsort( $scores );
        return array_slice( array_keys( $scores ), 0, $max );
    }

    private function keyword_similarity( $kw1, $kw2 ) {
        if ( empty( $kw1 ) || empty( $kw2 ) ) return 0;
        $s1 = array_flip( $kw1 );
        $s2 = array_flip( $kw2 );
        $inter = count( array_intersect_key( $s1, $s2 ) );
        $union = count( $s1 ) + count( $s2 ) - $inter;
        return $union > 0 ? $inter / $union : 0;
    }

    /* ══════════════════════════════════════════════════════════
       ANALYSE COMPLÈTE
    ══════════════════════════════════════════════════════════ */

    public function analyze_site( $lang = '' ) {
        // o3 reasoning can take 60-120s — extend PHP timeout to 600s
        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 600 );
        // ── Language detection — CRITICAL for Polylang/WPML sites ──
        // In AJAX context, pll_current_language() returns nothing.
        // We MUST resolve to a specific language, never analyze all languages mixed.
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }

        // Safety: if Polylang is active but $lang is still empty, detect dominant language
        // Mixing FR + EN articles in the same cocon analysis breaks clustering completely.
        if ( empty( $lang ) && function_exists( 'pll_languages_list' ) ) {
            // Try default language first
            if ( function_exists( 'pll_default_language' ) ) {
                $lang = pll_default_language( 'slug' );
            }
            // If still empty, count posts per language and pick the one with most content
            if ( empty( $lang ) ) {
                $langs = pll_languages_list( array( 'fields' => 'slug' ) );
                $best_lang = '';
                $best_count = 0;
                foreach ( $langs as $l ) {
                    $ct = (int) wp_count_posts( 'post' )->publish; // rough count
                    if ( function_exists( 'pll_count_posts' ) ) {
                        $ct = (int) pll_count_posts( $l, array( 'post_type' => 'post' ) );
                    }
                    if ( $ct > $best_count ) { $best_count = $ct; $best_lang = $l; }
                }
                if ( $best_lang ) $lang = $best_lang;
            }
            if ( ! empty( $lang ) && function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Cocon: langue auto-détectée → ' . $lang . ' (Polylang actif, aucune langue explicite)', 'info', 'cocon' );
            }
        }

        // Store language for clustering prompts (cluster names must match content language)
        $this->analysis_lang = $lang ?: substr( get_locale(), 0, 2 ) ?: 'fr';

        $args = array(
            'post_type'              => array( 'post', 'page' ),
            'post_status'            => 'publish',
            'posts_per_page'         => 500,
            'orderby'                => 'date',
            'order'                  => 'DESC',
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
            'suppress_filters'       => false, // CRITICAL: allow Polylang/WPML to filter by language
        );

        // Filter query for Polylang/WPML
        if ( $lang && class_exists( 'HTS_Language' ) ) {
            $args = HTS_Language::filter_query_args( $args, $lang );
        }

        $posts = get_posts( $args );

        // ALWAYS post-filter by language when multilingual is active
        // The query-level filter may fail in AJAX context (Polylang hooks not initialized)
        if ( $lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $before_count = count( $posts );
            $posts = array_values( HTS_Language::filter_posts_by_lang( $posts, $lang ) );
            $after_count = count( $posts );
            if ( $before_count !== $after_count && function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf(
                    'Cocon: post-filtre langue %s → %d/%d articles retenus (query renvoyait %d)',
                    $lang, $after_count, $before_count, $before_count
                ), 'info', 'cocon' );
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'Cocon analyze_site(%s): %d posts charges apres filtre langue', $lang, count( $posts ) ), 'info', 'cocon' );
        }

        if ( empty( $posts ) ) return array( 'nodes' => array(), 'links' => array(), 'clusters' => array(), 'stats' => array(), 'lang' => $lang );

        // ── Pre-filter: Remove utility pages from analysis entirely ──
        $site_url_for_filter = home_url();
        $utility_slugs = array(
            'contact', 'contact-2', 'formulaire', 'form', 'candidature',
            'politique-de-confidentialite', 'privacy-policy', 'privacy',
            'mentions-legales', 'legal-notice', 'mentions',
            'cgv', 'cgu', 'conditions-generales', 'terms',
            'mon-compte', 'my-account', 'account', 'login', 'register',
            'panier', 'cart', 'checkout', 'commande',
            'plan-du-site', 'sitemap', 'cookie', 'cookies', 'rgpd', 'gdpr',
            'test', 'test-page', 'brouillon', 'draft', 'sample-page', 'hello-world',
            // Navigation / About / Team / Legal pages (no SEO value for cocon)
            'qui-sommes-nous', 'a-propos', 'about', 'about-us',
            'equipe', 'lequipe', 'l-equipe', 'team', 'notre-equipe',
            'code-de-conduite', 'code-conduite', 'code-of-conduct',
            'home', 'accueil', 'homepage',
            'nos-articles', 'blog', 'articles', 'actualites', 'news',
            'faq', 'aide', 'help', 'support',
            'partenaires', 'partners', 'temoignages', 'testimonials',
            'legislation', 'ressources', 'resources',
        );
        $utility_frags = array( 'contact', 'formulaire', 'candidat', 'confidentialite', 'privacy', 'mentions-legale', 'cgv', 'cgu',
            'qui-sommes', 'a-propos', 'about-us', 'notre-equipe', 'code-de-conduit', 'code-conduit',
        );
        $utility_titles = array( 'politique de confidentialité', 'mentions légales', 'conditions générales', 'formulaire de', 'politique de cookies',
            // Hub/navigation page patterns (contains match)
            'nos articles', 'tous les articles', 'tous nos articles', 'notre blog',
            'nos services', 'nos prestations', 'nos offres',
        );
        // Titles that indicate non-content pages (EXACT match)
        $junk_titles_exact = array( 'test', 'test page', 'brouillon', 'draft', 'hello world', 'sample page', 'exemple', 'accueil',
            'home', 'qui sommes-nous', 'qui sommes nous', 'l\'équipe', 'notre équipe',
            'code de conduite', 'faq', 'aide',
            // Single-word category/hub pages (no real content value for cocon)
            'législation', 'legislation', 'blog', 'articles', 'actualités', 'actualites', 'ressources',
        );

        $filtered_posts = array();
        $excluded_count = 0;

        // Pre-cache menu page IDs to protect business pages from exclusion
        $_hts_menu_ids_cache = array();
        foreach ( wp_get_nav_menus() as $_m ) {
            $_items = wp_get_nav_menu_items( $_m->term_id );
            if ( $_items ) {
                foreach ( $_items as $_it ) {
                    if ( $_it->type === 'post_type' ) $_hts_menu_ids_cache[ (int) $_it->object_id ] = true;
                }
            }
        }

        foreach ( $posts as $p ) {
            $slug = $p->post_name;
            $title_lower = mb_strtolower( $p->post_title );
            $skip = false;
            $is_menu_page = isset( $_hts_menu_ids_cache[ $p->ID ] );

            // NEVER exclude pages that are in a WP navigation menu — they are business pages
            if ( $is_menu_page ) {
                $filtered_posts[] = $p;
                continue;
            }

            // Exact slug match
            if ( in_array( $slug, $utility_slugs ) ) $skip = true;

            // Partial slug match
            if ( ! $skip ) {
                foreach ( $utility_frags as $frag ) {
                    if ( strpos( $slug, $frag ) !== false ) { $skip = true; break; }
                }
            }

            // Title match (contains pattern)
            if ( ! $skip ) {
                foreach ( $utility_titles as $pat ) {
                    if ( strpos( $title_lower, $pat ) !== false ) { $skip = true; break; }
                }
            }

            // Exact junk title match
            if ( ! $skip && in_array( trim( $title_lower ), $junk_titles_exact ) ) $skip = true;

            // Title ends with " - ancien" / " - old" / " - copie" / " (copie)"
            if ( ! $skip && preg_match( '/[\s\-–—]+(ancien|old|copie|copy|draft|brouillon|test)\s*$/i', $p->post_title ) ) $skip = true;

            // Password protected
            if ( ! $skip && ! empty( $p->post_password ) ) $skip = true;

            // Near-empty content (< 100 words)
            if ( ! $skip ) {
                $plain = wp_strip_all_tags( $p->post_content );
                if ( hts_word_count( $plain ) < 100 ) $skip = true;
            }

            if ( $skip ) {
                $excluded_count++;
            } else {
                $filtered_posts[] = $p;
            }
        }

        if ( $excluded_count > 0 ) {
            hts_add_log( 'Cocon : ' . $excluded_count . ' page(s) utilitaire(s)/vide(s) exclue(s) de l\'analyse', 'info', 'cocon' );
        }
        if ( ! empty( $_hts_menu_ids_cache ) ) {
            $menu_protected = 0;
            foreach ( $_hts_menu_ids_cache as $_mid => $_v ) {
                foreach ( $filtered_posts as $_fp ) {
                    if ( $_fp->ID === $_mid ) { $menu_protected++; break; }
                }
            }
            hts_add_log( sprintf( 'Cocon : %d pages du menu WP protégées contre l\'exclusion', $menu_protected ), 'info', 'cocon' );
        }

        // ── Deduplicate: if multiple posts have the same title, keep the longest ──
        $title_map = array();
        foreach ( $filtered_posts as $p ) {
            $norm_title = mb_strtolower( trim( $p->post_title ) );
            if ( ! isset( $title_map[ $norm_title ] ) ) {
                $title_map[ $norm_title ] = $p;
            } else {
                // Keep the one with more content
                $existing_len = mb_strlen( wp_strip_all_tags( $title_map[ $norm_title ]->post_content ) );
                $new_len = mb_strlen( wp_strip_all_tags( $p->post_content ) );
                if ( $new_len > $existing_len ) {
                    $title_map[ $norm_title ] = $p;
                }
            }
        }
        $dedup_count = count( $filtered_posts ) - count( $title_map );
        if ( $dedup_count > 0 ) {
            hts_add_log( 'Cocon : ' . $dedup_count . ' doublon(s) de titre supprimé(s)', 'info', 'cocon' );
        }
        $posts = array_values( $title_map );
        if ( empty( $posts ) ) return array( 'nodes' => array(), 'links' => array(), 'clusters' => array(), 'stats' => array(), 'lang' => $lang );

        $site_url = home_url();
        $host = parse_url( $site_url, PHP_URL_HOST );

        // ── Phase 1 : Build nodes ──
        $nodes = array();
        $links = array();

        foreach ( $posts as $p ) {
            $content = $p->post_content;
            $cd = html_entity_decode( wp_strip_all_tags( $content ), ENT_QUOTES, 'UTF-8' );

            $outgoing = array();
            if ( preg_match_all( '/<a[^>]+href=["\']([^"\'#]+)["\'][^>]*>/i', $content, $lm ) ) {
                foreach ( $lm[1] as $href ) {
                    if ( strpos( $href, $host ) !== false || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                        $tid = hts_url_to_postid( $this->resolve_url( $href, $site_url ) );
                        if ( $tid && $tid !== $p->ID ) $outgoing[] = $tid;
                    }
                }
            }
            $outgoing = array_unique( $outgoing );

            $kw_text = $p->post_title . ' ' . $p->post_title . ' ' . mb_substr( $cd, 0, 2000 );
            $keywords = $this->extract_keywords( $kw_text, 12 );

            $cats = wp_get_post_categories( $p->ID, array( 'fields' => 'all' ) );
            $tags = wp_get_post_tags( $p->ID, array( 'fields' => 'all' ) );
            preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $content, $h2m );

            $nodes[ $p->ID ] = array(
                'id'           => $p->ID,
                'title'        => $p->post_title,
                'url'          => get_permalink( $p->ID ),
                'edit_url'     => get_edit_post_link( $p->ID, 'raw' ),
                'type'         => $p->post_type,
                'categories'   => wp_list_pluck( $cats, 'name' ),
                'tags'         => wp_list_pluck( $tags, 'name' ),
                'keywords'     => $keywords,
                'outgoing'     => $outgoing,
                'incoming'     => array(),
                'word_count'   => hts_word_count( $cd ),
                'h2_count'     => count( $h2m[0] ),
                'date'         => $p->post_date,
                'cluster'      => '',
                'role'         => '',
                'pillar_score' => 0,
            );
        }

        // ── Phase 2 : Incoming links ──
        // Load embeddings for semantic link quality scoring
        $link_vectors = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb_loader = new HTS_Embeddings();
            $link_vectors = $emb_loader->load_all_vectors();
        }
        $toxic_links = array(); // Links between unrelated pages

        foreach ( $nodes as $id => &$node ) {
            foreach ( $node['outgoing'] as $tid ) {
                if ( isset( $nodes[ $tid ] ) ) {
                    $nodes[ $tid ]['incoming'][] = $id;

                    // Score link quality by semantic similarity
                    $link_sim = 1.0; // Default: good
                    if ( $link_vectors && isset( $link_vectors[ $id ] ) && isset( $link_vectors[ $tid ] ) ) {
                        $link_sim = HTS_Embeddings::cosine_similarity( $link_vectors[ $id ], $link_vectors[ $tid ] );
                    }
                    $is_toxic = ( $link_vectors && isset( $link_vectors[ $id ] ) && isset( $link_vectors[ $tid ] ) && $link_sim < 0.30 );

                    $links[] = array( 'source' => $id, 'target' => $tid, 'similarity' => round( $link_sim, 3 ), 'toxic' => $is_toxic );

                    if ( $is_toxic ) {
                        $toxic_links[] = array(
                            'source_id'    => $id,
                            'target_id'    => $tid,
                            'source_title' => $nodes[ $id ]['title'],
                            'target_title' => $nodes[ $tid ]['title'],
                            'similarity'   => round( $link_sim, 3 ),
                        );
                    }
                }
            }
        }
        unset( $node );

        // Build semantic-aware incoming/outgoing (only count good links)
        foreach ( $nodes as &$node ) {
            $node['incoming']    = array_unique( $node['incoming'] );
            $node['out_count']   = count( $node['outgoing'] );
            $node['in_count']    = count( $node['incoming'] );

            // Semantic counts: only links with similarity >= 0.30
            $node['in_count_semantic']  = 0;
            $node['out_count_semantic'] = 0;
            if ( $link_vectors ) {
                foreach ( $node['incoming'] as $src ) {
                    if ( isset( $link_vectors[ $src ] ) && isset( $link_vectors[ $node['id'] ] ) ) {
                        $sim = HTS_Embeddings::cosine_similarity( $link_vectors[ $src ], $link_vectors[ $node['id'] ] );
                        if ( $sim >= 0.30 ) $node['in_count_semantic']++;
                    } else {
                        $node['in_count_semantic']++; // No embedding = assume good
                    }
                }
                foreach ( $node['outgoing'] as $tgt ) {
                    if ( isset( $link_vectors[ $node['id'] ] ) && isset( $link_vectors[ $tgt ] ) ) {
                        $sim = HTS_Embeddings::cosine_similarity( $link_vectors[ $node['id'] ], $link_vectors[ $tgt ] );
                        if ( $sim >= 0.30 ) $node['out_count_semantic']++;
                    } else {
                        $node['out_count_semantic']++;
                    }
                }
            } else {
                $node['in_count_semantic']  = $node['in_count'];
                $node['out_count_semantic'] = $node['out_count'];
            }

            // Orphan = no GOOD incoming links (toxic links don't count!)
            $node['is_orphan']   = $node['in_count_semantic'] === 0;
            $node['is_dead_end'] = $node['out_count'] === 0;
        }
        unset( $node );

        // ── Phase 2b : Click depth — BFS from homepage (Phase 6a.4) ──
        $home_id = (int) get_option( 'page_on_front', 0 );
        // Initialize all click depths to "unreachable"
        foreach ( $nodes as &$node ) {
            $node['click_depth'] = PHP_INT_MAX;
        }
        unset( $node );

        // BFS: find homepage (or best candidate) as root
        $bfs_root = null;
        if ( $home_id && isset( $nodes[ $home_id ] ) ) {
            $bfs_root = $home_id;
        } else {
            // If no homepage in nodes, use the node with most incoming links
            $max_in = -1;
            foreach ( $nodes as $id => $n ) {
                if ( $n['in_count'] > $max_in ) { $max_in = $n['in_count']; $bfs_root = $id; }
            }
        }

        if ( $bfs_root !== null ) {
            $nodes[ $bfs_root ]['click_depth'] = 0;
            $queue = array( $bfs_root );
            $visited = array( $bfs_root => true );

            while ( ! empty( $queue ) ) {
                $current = array_shift( $queue );
                $depth = $nodes[ $current ]['click_depth'];

                foreach ( $nodes[ $current ]['outgoing'] as $tid ) {
                    if ( isset( $nodes[ $tid ] ) && ! isset( $visited[ $tid ] ) ) {
                        $visited[ $tid ] = true;
                        $nodes[ $tid ]['click_depth'] = $depth + 1;
                        $queue[] = $tid;
                    }
                }
            }
        }

        // ── Phase 3 : Pillar score (uses SEMANTIC link counts + GSC performance) ──
        // S14 fix: benchmark-based scoring instead of ratio-to-max.
        // Old method: score = (value / site_max) × weight → "winner takes all" (most pages score 5-15).
        // New method: score = min(1, value / benchmark) × weight → reasonable benchmarks so a decent
        // article scores 50-65 and a strong pillar scores 80-95.
        // Benchmarks: 1500 words=full, 4 in-links=full, 5 H2s=full, 20 clicks=full.
        foreach ( $nodes as $pid => &$node ) {
            $s  = min( 1, $node['word_count'] / 1500 ) * 20;                   // /20: 1500+ words = full
            $s += min( 1, $node['in_count_semantic'] / 4 ) * 25;               // /25: 4+ semantic in-links = full
            $s += ( min( $node['out_count_semantic'], 10 ) / 10 ) * 10;        // /10: 10 out-links = full (unchanged)
            $s += min( 1, $node['h2_count'] / 5 ) * 10;                        // /10: 5+ H2 = full
            $s += min( count( $node['keywords'] ), 5 ) * 1.5;                  // max 7.5 (cap at 5 keywords)
            if ( $node['type'] === 'page' ) $s += 10;                          // +10 pages (unchanged)
            // GSC boost (up to 20 points)
            $gsc_clicks = (int) get_post_meta( (int) $pid, '_hts_gsc_clicks', true );
            $gsc_pos    = (float) get_post_meta( (int) $pid, '_hts_gsc_position', true );
            if ( $gsc_clicks > 0 ) {
                $s += min( 1, $gsc_clicks / 20 ) * 12;                         // /12: 20+ clicks = full
            }
            if ( $gsc_pos > 0 && $gsc_pos <= 10 ) {
                $s += max( 0, ( 10 - $gsc_pos ) / 10 ) * 8;                   // /8: position (unchanged)
            }
            $node['pillar_score'] = round( min( 100, $s ), 1 );                // Cap at 100
        }
        unset( $node );

        // ── Phase 4 : Clustering ──
        // Priority: Embeddings Seeded > Embeddings > AI > TF-IDF
        $has_embeddings = class_exists( 'HTS_Embeddings' );
        $emb_stats = $has_embeddings ? HTS_Embeddings::get_stats() : array( 'coverage' => 0 );

        // Load pillar IDs from unified source (v2.7.2 — discovery + manual + nav menus)
        $analyze_pillar_ids = $this->get_all_pillar_ids( $nodes, $this->analysis_lang );

        if ( $has_embeddings && ( $emb_stats['coverage'] ?? 0 ) >= 50 && ! empty( $analyze_pillar_ids ) ) {
            $clusters = $this->cluster_with_embeddings_seeded( $nodes, $analyze_pillar_ids );
        } elseif ( $has_embeddings && ( $emb_stats['coverage'] ?? 0 ) >= 50 ) {
            $clusters = $this->cluster_with_embeddings( $nodes );
        } elseif ( ! empty( $this->openai_key ) && count( $nodes ) >= 3 ) {
            $clusters = $this->cluster_with_ai( $nodes );
        } else {
            $clusters = $this->cluster_with_tfidf( $nodes );
        }

        // ── Phase 4b : Safety net — if clustering failed, fallback to WP categories ──
        // If "Non classé" has > 40% of pages, the clustering method produced junk.
        // WordPress categories are a much better fallback than one giant "Non classé".
        $total_node_count = count( $nodes );
        $nc_count = 0;
        foreach ( $clusters as $cn => $cl ) {
            if ( mb_strtolower( $cn ) === 'non classé' || mb_strtolower( $cn ) === 'non classe' ) {
                $nc_count = count( $cl['pages'] ?? array() );
            }
        }
        if ( $total_node_count > 10 && $nc_count > $total_node_count * 0.4 ) {
            hts_add_log( sprintf(
                'Clustering échoué (%d/%d dans "Non classé") — fallback catégories WordPress',
                $nc_count, $total_node_count
            ), 'warn', 'cocon' );
            $clusters = $this->cluster_with_wp_categories( $nodes );
        }

        // ── Phase 5 : Assign roles (semantic pillar selection) ──
        // Compute max pillar_score for normalization
        $max_pillar_score = 1;
        foreach ( $nodes as $n ) {
            if ( $n['pillar_score'] > $max_pillar_score ) $max_pillar_score = $n['pillar_score'];
        }

        foreach ( $clusters as $cname => &$cl ) {

            // RESPECT o3's pillar choice if set and valid
            if ( ! empty( $cl['pillar_id'] ) && isset( $nodes[ $cl['pillar_id'] ] ) && in_array( $cl['pillar_id'], $cl['pages'] ) ) {
                $pid_best = $cl['pillar_id'];
            } else {
            $best_combined = -1;
            $pid_best = 0;

            // Try semantic pillar selection if we have cached vectors
            $has_vectors = ! empty( $this->cached_vectors ) && class_exists( 'HTS_Embeddings' );
            $cluster_vectors = array();

            if ( $has_vectors ) {
                // Collect vectors for pages in this cluster
                foreach ( $cl['pages'] as $pid ) {
                    if ( isset( $this->cached_vectors[ $pid ] ) ) {
                        $cluster_vectors[ $pid ] = $this->cached_vectors[ $pid ];
                    }
                }
            }

            if ( count( $cluster_vectors ) >= 2 ) {
                // Compute centroid (average of all vectors in cluster)
                $dim = count( reset( $cluster_vectors ) );
                $centroid = array_fill( 0, $dim, 0.0 );
                foreach ( $cluster_vectors as $vec ) {
                    for ( $d = 0; $d < $dim; $d++ ) {
                        $centroid[ $d ] += $vec[ $d ];
                    }
                }
                $cnt = count( $cluster_vectors );
                for ( $d = 0; $d < $dim; $d++ ) {
                    $centroid[ $d ] /= $cnt;
                }

                // Score each page: 40% pillar_score + 60% semantic closeness to centroid
                foreach ( $cl['pages'] as $pid ) {
                    if ( ! isset( $nodes[ $pid ] ) ) continue;
                    $ps_norm = $nodes[ $pid ]['pillar_score'] / $max_pillar_score; // 0-1
                    $sem_score = 0;
                    if ( isset( $cluster_vectors[ $pid ] ) ) {
                        $sem_score = HTS_Embeddings::cosine_similarity( $cluster_vectors[ $pid ], $centroid );
                    }
                    $combined = $ps_norm * 0.4 + $sem_score * 0.6;
                    if ( $combined > $best_combined ) {
                        $best_combined = $combined;
                        $pid_best = $pid;
                    }
                }
            } else {
                // Fallback: pure pillar_score (no embeddings available)
                foreach ( $cl['pages'] as $pid ) {
                    if ( isset( $nodes[ $pid ] ) && $nodes[ $pid ]['pillar_score'] > $best_combined ) {
                        $best_combined = $nodes[ $pid ]['pillar_score'];
                        $pid_best = $pid;
                    }
                }
            }
            } // end auto-calculate fallback

            $cl['pillar_id'] = $pid_best;

            foreach ( $cl['pages'] as $pid ) {
                if ( ! isset( $nodes[ $pid ] ) ) continue;
                $nodes[ $pid ]['cluster'] = $cname;
                if ( $pid === $pid_best ) {
                    $nodes[ $pid ]['role'] = 'pilier';
                } elseif ( $nodes[ $pid ]['is_orphan'] && $nodes[ $pid ]['is_dead_end'] ) {
                    $nodes[ $pid ]['role'] = 'orpheline';
                } elseif ( $pid_best && ( in_array( $pid_best, $nodes[ $pid ]['outgoing'] ) || in_array( $pid, $nodes[ $pid_best ]['outgoing'] ?? array() ) ) ) {
                    $nodes[ $pid ]['role'] = 'fille';
                } else {
                    $nodes[ $pid ]['role'] = 'satellite';
                }
            }
        }
        unset( $cl );

        foreach ( $nodes as &$node ) {
            if ( empty( $node['cluster'] ) ) {
                $node['cluster'] = 'Non classé';
                $node['role'] = $node['is_orphan'] ? 'orpheline' : 'satellite';
            }
        }
        unset( $node );

        // ── Phase 6 : Cluster metrics (semantic-aware) ──
        // Build a lookup of toxic links for O(1) access
        $toxic_lookup = array();
        foreach ( $toxic_links as $tl ) {
            $toxic_lookup[ $tl['source_id'] . ':' . $tl['target_id'] ] = true;
        }

        foreach ( $clusters as &$cl ) {
            $n = count( $cl['pages'] );
            $internal = 0; $internal_semantic = 0; $internal_toxic = 0;
            $orphans = 0; $dead = 0;
            $cl_toxic_links = array();

            foreach ( $cl['pages'] as $pid ) {
                if ( ! isset( $nodes[ $pid ] ) ) continue;
                if ( $nodes[ $pid ]['is_orphan'] ) $orphans++;
                if ( $nodes[ $pid ]['is_dead_end'] ) $dead++;
                foreach ( $nodes[ $pid ]['outgoing'] as $tid ) {
                    if ( in_array( $tid, $cl['pages'] ) ) {
                        $internal++;
                        $link_key = $pid . ':' . $tid;
                        if ( isset( $toxic_lookup[ $link_key ] ) ) {
                            $internal_toxic++;
                            // Find the toxic link detail
                            foreach ( $toxic_links as $tl ) {
                                if ( $tl['source_id'] === $pid && $tl['target_id'] === $tid ) {
                                    $cl_toxic_links[] = $tl;
                                    break;
                                }
                            }
                        } else {
                            $internal_semantic++;
                        }
                    }
                }
            }
            $max_p = $n * ( $n - 1 );
            $cl['total_links']      = $internal;
            $cl['semantic_links']   = $internal_semantic;
            $cl['toxic_links']      = $internal_toxic;
            $cl['toxic_link_list']  = $cl_toxic_links;
            // Density based on SEMANTIC links only (toxic links don't count!)
            $cl['density']          = $max_p > 0 ? round( $internal_semantic / $max_p * 100, 1 ) : 0;
            $cl['page_count']       = $n;
            $cl['orphans']          = $orphans;
            $cl['dead_ends']        = $dead;

            $connected = 0;
            if ( $cl['pillar_id'] && isset( $nodes[ $cl['pillar_id'] ] ) ) {
                foreach ( $cl['pages'] as $pid ) {
                    if ( $pid === $cl['pillar_id'] || ! isset( $nodes[ $pid ] ) ) continue;
                    if ( in_array( $cl['pillar_id'], $nodes[ $pid ]['outgoing'] ) || in_array( $pid, $nodes[ $cl['pillar_id'] ]['outgoing'] ) ) {
                        $connected++;
                    }
                }
            }
            $cl['connected_to_pillar'] = $connected;
            $cl['pillar_coverage'] = $n > 1 ? round( $connected / ( $n - 1 ) * 100 ) : 100;

            // ── Sibling density — Phase 6a.5 ──
            // % of sibling pairs (non-pillar) that are linked to each other
            $siblings = array_filter( $cl['pages'], function( $pid ) use ( $cl ) {
                return $pid !== ( $cl['pillar_id'] ?? 0 );
            } );
            $siblings = array_values( $siblings );
            $sib_count = count( $siblings );
            $sib_linked = 0;
            $sib_total_pairs = 0;

            if ( $sib_count >= 2 ) {
                for ( $i = 0; $i < $sib_count; $i++ ) {
                    for ( $j = $i + 1; $j < $sib_count; $j++ ) {
                        $sib_total_pairs++;
                        $a_id = $siblings[ $i ];
                        $b_id = $siblings[ $j ];
                        if ( isset( $nodes[ $a_id ] ) && isset( $nodes[ $b_id ] ) ) {
                            // Link in either direction counts
                            if ( in_array( $b_id, $nodes[ $a_id ]['outgoing'] ) || in_array( $a_id, $nodes[ $b_id ]['outgoing'] ) ) {
                                $sib_linked++;
                            }
                        }
                    }
                }
            }
            $cl['sibling_density'] = $sib_total_pairs > 0 ? round( $sib_linked / $sib_total_pairs * 100, 1 ) : 100;
        }
        unset( $cl );

        uasort( $clusters, function( $a, $b ) { return $b['page_count'] - $a['page_count']; } );

        $total_orphans = count( array_filter( $nodes, function( $n ) { return $n['is_orphan']; } ) );
        $total_dead    = count( array_filter( $nodes, function( $n ) { return $n['is_dead_end']; } ) );
        $total_pillars = count( array_filter( $nodes, function( $n ) { return $n['role'] === 'pilier'; } ) );

        // Compute overall quality metrics
        $content_clusters = array_filter( $clusters, function( $cl ) { return ( $cl['name'] ?? '' ) !== 'Non classé'; } );
        $avg_sil = 0;
        $sil_cnt = 0;
        $border_total = 0;
        foreach ( $content_clusters as $cl ) {
            if ( isset( $cl['silhouette'] ) ) {
                $avg_sil += $cl['silhouette'];
                $sil_cnt++;
            }
            $border_total += count( $cl['border_pages'] ?? array() );
        }

        // Build flagged pages list with client decision status
        $decisions = get_option( 'hts_cocon_page_decisions', array() );
        $flagged_pages = array();
        foreach ( $this->cached_diverse_pages as $pid => $info ) {
            $flagged_pages[ $pid ] = array(
                'page_id'       => $pid,
                'title'         => $info['title'],
                'foreign_ratio' => $info['foreign_ratio'],
                'decision'      => $decisions[ $pid ]['decision'] ?? 'pending',
                'decided_at'    => $decisions[ $pid ]['decided_at'] ?? null,
            );
        }

        $result = array(
            'nodes'    => $nodes,
            'links'    => $links,
            'clusters' => $clusters,
            'lang'     => $lang,
            'toxic_links' => $toxic_links,
            'flagged_pages' => $flagged_pages,
            'stats'    => array(
                'total_pages'         => count( $nodes ),
                'total_links'         => count( $links ),
                'total_toxic_links'   => count( $toxic_links ),
                'total_flagged_pages' => count( $flagged_pages ),
                'total_pending_review' => count( array_filter( $flagged_pages, function( $f ) { return $f['decision'] === 'pending'; } ) ),
                'total_orphans'       => $total_orphans,
                'total_dead_ends'     => $total_dead,
                'total_clusters'      => count( $clusters ),
                'total_pillars'       => $total_pillars,
                'avg_links_per_page'  => count( $nodes ) > 0 ? round( count( $links ) / count( $nodes ), 1 ) : 0,
                'avg_silhouette'      => $sil_cnt > 0 ? round( $avg_sil / $sil_cnt, 3 ) : null,
                'total_border_pages'  => $border_total,
                'clustering_quality'  => $sil_cnt > 0 ? ( ( $avg_sil / $sil_cnt ) >= 0.3 ? 'bon' : ( ( $avg_sil / $sil_cnt ) >= 0.15 ? 'moyen' : 'faible' ) ) : 'inconnu',
                'deep_pages'          => count( array_filter( $nodes, function( $n ) { return ( $n['click_depth'] ?? 0 ) > 3 && ( $n['click_depth'] ?? 0 ) < PHP_INT_MAX; } ) ),
                'avg_click_depth'     => $this->avg_click_depth( $nodes ),
                'avg_sibling_density' => $this->avg_sibling_density( $clusters ),
            ),
        );

        // Log toxic links if any
        if ( ! empty( $toxic_links ) ) {
            hts_add_log(
                '' . count( $toxic_links ) . ' lien(s) toxique(s) détecté(s) (similarité < 0.30) — ces liens n\'apportent pas de valeur SEO',
                'warning', 'cocon'
            );
        }

        // Invalider le cache des suggestions de linking quand les clusters changent
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_cocon_sug_%' OR option_name LIKE '_transient_timeout_hts_cocon_sug_%'" );

        // Store per language if multilingual
        $opt_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang
            : 'hts_cocon_data';
        update_option( $opt_key, $result, false );
        update_option( 'hts_cocon_last_analysis', time(), false );

        // Invalidate runtime cache after save
        self::$cocon_data_cache = array();

        // Sync unsuffixed key with default language — prevents stale/broken data
        // when "Afficher toutes les langues" loads hts_cocon_data
        $default_lang = function_exists( 'pll_default_language' ) ? pll_default_language( 'slug' ) : '';
        if ( $lang && $lang === $default_lang && $opt_key !== 'hts_cocon_data' ) {
            update_option( 'hts_cocon_data', $result, false );
        }

        // Invalidate suggestion caches for all clusters
        if ( ! empty( $result['clusters'] ) ) {
            foreach ( array_keys( $result['clusters'] ) as $cn ) {
                delete_option( 'hts_cocon_ai_' . md5( $cn . $lang ) );
                delete_option( 'hts_cocon_ai_' . md5( $cn ) );
            }
        }

        return $result;
    }

    /* ══════════════════════════════════════════════
     *  LLM-GUIDED CLUSTERING (state-of-the-art)
     *
     * Approach inspired by:
     * - QualIT (Amazon, 2024): LLM extracts topics BEFORE clustering
     * - ClusterLLM (EMNLP 2023): LLM guides clustering with constraints
     * - BERTopic: Embeddings + c-TF-IDF for topic validation
     *
     * Flow:
     *  1. GPT reads ALL page titles + excerpts → assigns topic groups (1 API call)
     *  2. Embeddings validate: compute silhouette to check GPT's grouping
     *  3. Misplaced pages (negative silhouette) → reassigned by embedding distance
     *  4. Orphan pages → assigned to nearest cluster by embedding similarity
     *
     * Why this is better than pure embeddings:
     * On mono-thematic sites (e.g. psilocybin), all embeddings are very close.
     * GPT can distinguish "effects on depression" vs "legal status" vs "retreat tips"
     * because it UNDERSTANDS language, not just measures vector distance.
     * ══════════════════════════════════════════════ */

    /* ══════════════════════════════════════════════
     *  PILLAR IDS — Single source of truth (v2.7.2)
     *
     *  Combines: discovery cache + manual pages + nav menu fallback.
     *  Used by BOTH seeded clustering AND LLM-guided clustering.
     * ══════════════════════════════════════════════ */

    private function get_all_pillar_ids( $nodes, $lang = '' ) {
        $pillar_ids = array();
        $mp_threshold = 30;

        // Source 1: Discovery cache
        $mp_disc = $lang ? get_option( 'hts_money_pages_discovery_' . $lang, array() ) : array();
        if ( empty( $mp_disc['pages'] ) ) $mp_disc = get_option( 'hts_money_pages_discovery', array() );

        if ( ! empty( $mp_disc['pages'] ) ) {
            foreach ( $mp_disc['pages'] as $mp ) {
                $mp_id = (int) ( $mp['id'] ?? 0 );
                if ( ! $mp_id || ! isset( $nodes[ $mp_id ] ) ) continue;
                $is_manual = (bool) get_post_meta( $mp_id, '_hts_money_page_manual', true );
                if ( ! $is_manual && ( (int) ( $mp['score'] ?? 0 ) ) < $mp_threshold ) continue;
                $mp_type = $mp['type'] ?? 'post';
                $is_dismissed = $mp_type === 'product_cat'
                    ? (bool) get_term_meta( $mp_id, '_hts_money_page_dismissed', true )
                    : (bool) get_post_meta( $mp_id, '_hts_money_page_dismissed', true );
                if ( ! $is_dismissed ) $pillar_ids[] = $mp_id;
            }
        }

        // Source 2: Manual money pages NOT in discovery cache
        $manual_money = get_posts( array(
            'post_type' => array( 'post', 'page', 'product' ), 'post_status' => 'publish',
            'meta_key' => '_hts_money_page_manual', 'meta_value' => '1',
            'posts_per_page' => 50, 'fields' => 'ids', 'suppress_filters' => false,
        ) );
        foreach ( $manual_money as $mm_id ) {
            if ( isset( $nodes[ $mm_id ] ) && ! in_array( $mm_id, $pillar_ids, true ) ) {
                $is_dismissed = (bool) get_post_meta( $mm_id, '_hts_money_page_dismissed', true );
                if ( ! $is_dismissed ) $pillar_ids[] = $mm_id;
            }
        }

        // Source 3: Nav menu pages (fallback if no money pages at all)
        if ( empty( $pillar_ids ) ) {
            $nav_menus = wp_get_nav_menus();
            foreach ( $nav_menus as $menu ) {
                $items = wp_get_nav_menu_items( $menu->term_id );
                if ( ! $items ) continue;
                foreach ( $items as $item ) {
                    if ( $item->type === 'post_type' && (int) $item->object_id > 0 ) {
                        $mpid = (int) $item->object_id;
                        if ( isset( $nodes[ $mpid ] ) ) {
                            $is_dismissed = (bool) get_post_meta( $mpid, '_hts_money_page_dismissed', true );
                            if ( ! $is_dismissed ) $pillar_ids[] = $mpid;
                        }
                    }
                }
            }
        }

        $pillar_ids = array_unique( $pillar_ids );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'Pillar IDs (source unifiée): %d pages. IDs: %s',
                count( $pillar_ids ), implode( ', ', $pillar_ids )
            ), 'info', 'cocon' );
        }

        return $pillar_ids;
    }

    /* ══════════════════════════════════════════════
     *  EMBEDDINGS SEEDED CLUSTERING (v2.6.3)
     *
     *  Money pages cochées = seeds.
     *  Chaque page est rattachée au seed le plus proche par cosine similarity.
     *  Zéro LLM, zéro timeout, déterministe, scale à 10K+ pages.
     * ══════════════════════════════════════════════ */

    private function cluster_with_embeddings_seeded( $nodes, $seed_ids, $respect_seeds = false ) {
        // 1. Load vectors
        $emb = new \HTS_Embeddings();
        $vectors = $emb->load_all_vectors();
        $this->cached_vectors = $vectors; // cache for Phase 5 (finalize)

        // 2. Validate seeds — split into seeds-with-vectors and seeds-without-vectors
        $valid_seeds = array();
        $seeds_no_vector = array();
        $invalid_seeds = array();
        foreach ( $seed_ids as $sid ) {
            if ( ! isset( $nodes[ $sid ] ) ) {
                $invalid_seeds[] = (int) $sid;
                continue;
            }
            if ( isset( $vectors[ $sid ] ) ) {
                $valid_seeds[] = (int) $sid;
            } else {
                $seeds_no_vector[] = (int) $sid;
            }
        }

        if ( ! empty( $invalid_seeds ) ) {
            hts_add_log( sprintf(
                'Seeded clustering: %d seeds invalides (pas dans nodes): %s',
                count( $invalid_seeds ), implode( ',', $invalid_seeds )
            ), 'warn', 'cocon' );
        }

        if ( ! empty( $seeds_no_vector ) ) {
            hts_add_log( sprintf(
                'Seeded clustering: %d seeds sans vecteur (embedding manquant) — clusters créés en mode catégorie: %s',
                count( $seeds_no_vector ), implode( ',', $seeds_no_vector )
            ), 'warn', 'cocon' );
        }

        // Fallback if no valid seeds AT ALL (neither with nor without vectors)
        if ( empty( $valid_seeds ) && empty( $seeds_no_vector ) ) {
            hts_add_log( 'Seeded clustering: aucun seed valide — fallback embeddings k-medoids', 'warn', 'cocon' );
            $coverage = count( $vectors ) > 0 && count( $nodes ) > 0
                ? ( count( array_intersect_key( $vectors, $nodes ) ) / count( $nodes ) ) * 100
                : 0;
            if ( $coverage >= 30 ) {
                return $this->cluster_with_embeddings( $nodes );
            }
            return $this->cluster_with_tfidf( $nodes );
        }

        // 3. Assign each non-seed page to nearest seed
        $assignments = array(); // seed_id => array of page_ids
        $orphans = array();

        foreach ( $valid_seeds as $sid ) {
            $assignments[ $sid ] = array();
        }

        foreach ( $nodes as $pid => $n ) {
            $pid = (int) $pid; // Ensure int for comparisons (transient keys can be string)
            // Seeds go in their own cluster (both with and without vectors)
            if ( in_array( $pid, $valid_seeds, true ) || in_array( $pid, $seeds_no_vector, true ) ) continue;

            // Skip pages without vector
            if ( ! isset( $vectors[ $pid ] ) ) {
                $orphans[] = $pid;
                continue;
            }

            // Find nearest seed
            $best_seed = null;
            $best_sim  = -1.0;

            foreach ( $valid_seeds as $sid ) {
                $sim = \HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $sid ] );

                // Boost: existing link between page and seed (+0.05)
                $page_out = $n['outgoing'] ?? array();
                $seed_out = $nodes[ $sid ]['outgoing'] ?? array();
                if ( in_array( $sid, $page_out ) || in_array( $pid, $seed_out ) ) {
                    $sim += 0.05;
                }

                // Boost: shared WP categories (+0.03 per)
                $shared_cats = count( array_intersect(
                    $n['categories'] ?? array(),
                    $nodes[ $sid ]['categories'] ?? array()
                ) );
                $sim += 0.03 * $shared_cats;

                // Boost: shared tags (+0.02 per)
                $shared_tags = count( array_intersect(
                    $n['tags'] ?? array(),
                    $nodes[ $sid ]['tags'] ?? array()
                ) );
                $sim += 0.02 * $shared_tags;

                $sim = min( 1.0, $sim ); // cap

                if ( $sim > $best_sim ) {
                    $best_sim  = $sim;
                    $best_seed = $sid;
                }
            }

            $sim_threshold = $respect_seeds ? 0.45 : 0.30;
            if ( $best_seed !== null && $best_sim >= $sim_threshold ) {
                $assignments[ $best_seed ][] = $pid;
            } else {
                $orphans[] = $pid;
            }
        }

        // 4. Build clusters
        $clusters = array();
        foreach ( $valid_seeds as $sid ) {
            $name  = $nodes[ $sid ]['title'] ?? ( 'Cluster ' . $sid );
            // Deduplicate names
            if ( isset( $clusters[ $name ] ) ) {
                $name .= ' (' . $sid . ')';
            }
            $pages = array_merge( array( $sid ), $assignments[ $sid ] );
            $clusters[ $name ] = array(
                'name'      => $name,
                'pages'     => $pages,
                'pillar_id' => $sid, // ALWAYS the seed = the pillar
                'theme'     => '',
            );
        }

        // 4b. Build clusters for seeds WITHOUT vectors (assigned by WP category)
        foreach ( $seeds_no_vector as $sid ) {
            $name = $nodes[ $sid ]['title'] ?? ( 'Cluster ' . $sid );
            if ( isset( $clusters[ $name ] ) ) {
                $name .= ' (' . $sid . ')';
            }
            $seed_cats = $nodes[ $sid ]['categories'] ?? array();
            $cat_pages = array();
            if ( ! empty( $seed_cats ) ) {
                foreach ( $nodes as $pid => $n ) {
                    $pid = (int) $pid;
                    if ( in_array( $pid, $valid_seeds, true ) || in_array( $pid, $seeds_no_vector, true ) ) continue;
                    $already_assigned = false;
                    foreach ( $assignments as $assigned_pages ) {
                        if ( in_array( $pid, $assigned_pages, true ) ) { $already_assigned = true; break; }
                    }
                    if ( $already_assigned || in_array( $pid, $orphans, true ) ) continue;
                    $shared = count( array_intersect( $n['categories'] ?? array(), $seed_cats ) );
                    if ( $shared > 0 ) $cat_pages[] = $pid;
                }
            }
            $pages = array_merge( array( $sid ), $cat_pages );
            $clusters[ $name ] = array(
                'name'      => $name,
                'pages'     => $pages,
                'pillar_id' => $sid,
                'theme'     => '',
            );
        }

        // 4c. Cap cluster size at 20 when seeds are explicit (overflow → orphans)
        if ( $respect_seeds ) {
            $max_per_cluster = 20;
            foreach ( $clusters as $cname => &$cl ) {
                $seed = $cl['pillar_id'];
                $members = array_diff( $cl['pages'], array( $seed ) );
                if ( count( $members ) <= $max_per_cluster ) continue;

                // Rank members by similarity to seed, keep top 20
                $scored = array();
                foreach ( $members as $mpid ) {
                    $sim = ( isset( $vectors[ $mpid ] ) && isset( $vectors[ $seed ] ) )
                        ? \HTS_Embeddings::cosine_similarity( $vectors[ $mpid ], $vectors[ $seed ] )
                        : 0.0;
                    $scored[ $mpid ] = $sim;
                }
                arsort( $scored );
                $keep = array_slice( array_keys( $scored ), 0, $max_per_cluster, true );
                $overflow = array_slice( array_keys( $scored ), $max_per_cluster );

                $cl['pages'] = array_merge( array( $seed ), array_values( $keep ) );
                $orphans = array_merge( $orphans, $overflow );
            }
            unset( $cl );
        }

        // 5. Handle orphans — try category match before "Non classé"
        $remaining_orphans = array();
        $all_seeds = array_merge( $valid_seeds, $seeds_no_vector );
        foreach ( $orphans as $opid ) {
            $n = $nodes[ $opid ] ?? null;
            if ( ! $n ) { $remaining_orphans[] = $opid; continue; }

            $best_cat_seed = null;
            $best_cat_overlap = 0;
            foreach ( $all_seeds as $sid ) {
                $shared = count( array_intersect( $n['categories'] ?? array(), $nodes[ $sid ]['categories'] ?? array() ) );
                if ( $shared > $best_cat_overlap ) {
                    $best_cat_overlap = $shared;
                    $best_cat_seed = $sid;
                }
            }

            if ( $best_cat_seed !== null && $best_cat_overlap >= 1 ) {
                // Find the cluster with this seed and add the orphan
                foreach ( $clusters as &$cl ) {
                    if ( ( $cl['pillar_id'] ?? 0 ) === $best_cat_seed ) {
                        $cl['pages'][] = $opid;
                        break;
                    }
                }
                unset( $cl );
                continue;
            }

            $remaining_orphans[] = $opid;
        }

        if ( ! empty( $remaining_orphans ) ) {
            // Try to sub-cluster orphans into suggestions (mini k-medoids)
            $orphans_with_vec = array_values( array_filter( $remaining_orphans, function( $p ) use ( $vectors ) {
                return isset( $vectors[ $p ] );
            } ) );

            $suggested_clusters = array();
            if ( count( $orphans_with_vec ) >= 6 ) {
                $k = max( 2, min( 6, (int) round( count( $orphans_with_vec ) / 10 ) ) );

                // Pick k most distant pages as medoids
                $medoids = array( $orphans_with_vec[0] );
                for ( $m = 1; $m < $k; $m++ ) {
                    $best_id = null;
                    $best_min_dist = -1;
                    foreach ( $orphans_with_vec as $cand ) {
                        if ( in_array( $cand, $medoids, true ) ) continue;
                        $min_d = PHP_FLOAT_MAX;
                        foreach ( $medoids as $med ) {
                            if ( ! isset( $vectors[ $cand ] ) || ! isset( $vectors[ $med ] ) ) continue;
                            $d = 1.0 - \HTS_Embeddings::cosine_similarity( $vectors[ $cand ], $vectors[ $med ] );
                            if ( $d < $min_d ) $min_d = $d;
                        }
                        if ( $min_d > $best_min_dist ) { $best_min_dist = $min_d; $best_id = $cand; }
                    }
                    if ( $best_id !== null ) $medoids[] = $best_id;
                }

                // Assign orphans to nearest medoid
                $sub_groups = array();
                foreach ( $medoids as $med ) $sub_groups[ $med ] = array();
                foreach ( $orphans_with_vec as $opid ) {
                    $best_med = $medoids[0];
                    $best_d = PHP_FLOAT_MAX;
                    foreach ( $medoids as $med ) {
                        if ( ! isset( $vectors[ $med ] ) ) continue;
                        $d = 1.0 - \HTS_Embeddings::cosine_similarity( $vectors[ $opid ], $vectors[ $med ] );
                        if ( $d < $best_d ) { $best_d = $d; $best_med = $med; }
                    }
                    $sub_groups[ $best_med ][] = $opid;
                }

                foreach ( $sub_groups as $med => $pages ) {
                    if ( count( $pages ) < 2 ) continue;
                    $all_pages = array_merge( array( $med ), array_diff( $pages, array( $med ) ) );
                    $sug_name = ( $nodes[ $med ]['title'] ?? 'Suggestion ' . $med );
                    if ( isset( $clusters[ $sug_name ] ) ) $sug_name .= ' (' . $med . ')';
                    $suggested_clusters[ $sug_name ] = array(
                        'name'       => $sug_name,
                        'pages'      => $all_pages,
                        'pillar_id'  => $med,
                        'theme'      => '',
                        'suggested'  => true,
                    );
                }
            }

            // Pages not in any suggestion → "Non classé"
            $all_suggested_pids = array();
            foreach ( $suggested_clusters as $sc ) {
                $all_suggested_pids = array_merge( $all_suggested_pids, $sc['pages'] );
            }
            $truly_orphan = array_values( array_diff( $remaining_orphans, $all_suggested_pids ) );

            foreach ( $suggested_clusters as $sn => $sc ) {
                $clusters[ $sn ] = $sc;
            }

            if ( ! empty( $truly_orphan ) ) {
                $nc_label = 'Non classé';
                $best_score = -1;
                $best_pid = 0;
                foreach ( $truly_orphan as $opid ) {
                    $ps = $nodes[ $opid ]['pillar_score'] ?? 0;
                    if ( $ps > $best_score ) { $best_score = $ps; $best_pid = $opid; }
                }
                $clusters[ $nc_label ] = array(
                    'name'      => $nc_label,
                    'pages'     => $truly_orphan,
                    'pillar_id' => $best_pid,
                    'theme'     => '',
                    'suggested' => false,
                );
            }
        }

        // 6. Mega-cluster split (>40% of pages in one cluster on mono-thematic sites)
        //    SKIP when user explicitly chose seeds — respect their pillar selection
        if ( $respect_seeds ) {
            hts_add_log( 'Mega-cluster split skipped — seeds explicites, respect du choix utilisateur.', 'info', 'cocon' );
            return $clusters;
        }
        $total = count( $nodes );
        $mega_threshold = 0.4;
        foreach ( $clusters as $cname => $cl ) {
            if ( count( $cl['pages'] ) <= $total * $mega_threshold || $cname === 'Non classé' ) continue;

            $seed_id = $cl['pillar_id'];
            $member_pids = array_filter( $cl['pages'], function( $p ) use ( $seed_id ) { return $p !== $seed_id; } );
            $member_pids = array_values( $member_pids );

            // Need at least 6 members (seed + 5) and vectors to split
            if ( count( $member_pids ) < 5 ) continue;

            // k-medoids split using embeddings
            $sub_k = max( 2, min( 5, (int) round( count( $member_pids ) / 10 ) ) );
            $members_with_vec = array_filter( $member_pids, function( $p ) use ( $vectors ) { return isset( $vectors[ $p ] ); } );
            if ( count( $members_with_vec ) < $sub_k * 2 ) continue;

            hts_add_log( sprintf( 'Mega-cluster "%s" (%d pages, %.0f%%) → splitting into %d sub-groups',
                $cname, count( $cl['pages'] ), count( $cl['pages'] ) / $total * 100, $sub_k ), 'warn', 'cocon' );

            // K-medoids++ init: pick most distant pages as medoids
            $members_arr = array_values( $members_with_vec );
            $medoids = array( $members_arr[0] );
            for ( $m = 1; $m < $sub_k; $m++ ) {
                $best_id = null; $best_min_dist = -1;
                foreach ( $members_arr as $cand ) {
                    if ( in_array( $cand, $medoids ) ) continue;
                    $min_d = PHP_FLOAT_MAX;
                    foreach ( $medoids as $med ) {
                        $d = 1.0 - \HTS_Embeddings::cosine_similarity( $vectors[ $cand ], $vectors[ $med ] );
                        if ( $d < $min_d ) $min_d = $d;
                    }
                    if ( $min_d > $best_min_dist ) { $best_min_dist = $min_d; $best_id = $cand; }
                }
                if ( $best_id !== null ) $medoids[] = $best_id;
            }

            // Assign members to nearest medoid (5 iterations)
            $sub_assign = array();
            for ( $iter = 0; $iter < 5; $iter++ ) {
                $new_assign = array();
                foreach ( $members_arr as $pid ) {
                    $best_med = $medoids[0]; $best_d = 1.0 - \HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $medoids[0] ] );
                    for ( $mi = 1; $mi < count( $medoids ); $mi++ ) {
                        $d = 1.0 - \HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $medoids[ $mi ] ] );
                        if ( $d < $best_d ) { $best_d = $d; $best_med = $medoids[ $mi ]; }
                    }
                    $new_assign[ $pid ] = $best_med;
                }
                if ( $new_assign === $sub_assign ) break;
                $sub_assign = $new_assign;
            }

            // Build sub-groups
            $sub_groups = array();
            foreach ( $sub_assign as $pid => $med ) {
                $sub_groups[ $med ][] = $pid;
            }
            // Add members without vectors to the first sub-group
            $no_vec = array_diff( $member_pids, $members_with_vec );
            if ( ! empty( $no_vec ) && ! empty( $sub_groups ) ) {
                $first_med = array_key_first( $sub_groups );
                foreach ( $no_vec as $nv ) $sub_groups[ $first_med ][] = $nv;
            }

            // Replace mega-cluster with sub-clusters
            unset( $clusters[ $cname ] );
            $sub_i = 0;
            foreach ( $sub_groups as $med_id => $sub_pids ) {
                $sub_i++;
                if ( $sub_i === 1 ) {
                    // First sub-group keeps the original seed as pillar
                    $sub_name = $cname;
                    array_unshift( $sub_pids, $seed_id );
                    $sub_pillar = $seed_id;
                } else {
                    // Other sub-groups: pillar = page with best pillar_score
                    $best_ps = -1; $sub_pillar = $sub_pids[0] ?? 0;
                    foreach ( $sub_pids as $sp ) {
                        if ( ( $nodes[ $sp ]['pillar_score'] ?? 0 ) > $best_ps ) {
                            $best_ps = $nodes[ $sp ]['pillar_score'] ?? 0;
                            $sub_pillar = $sp;
                        }
                    }
                    $sub_name = $nodes[ $sub_pillar ]['title'] ?? ( $cname . ' #' . $sub_i );
                }
                $clusters[ $sub_name ] = array(
                    'name'      => $sub_name,
                    'pages'     => array_unique( $sub_pids ),
                    'pillar_id' => $sub_pillar,
                    'theme'     => '',
                );
            }
        }

        // 6b. Merge micro-clusters (< 3 pages) into nearest larger cluster
        // Only merge if we have >= 3 big clusters (otherwise we'd collapse everything)
        $min_cluster_size = 3;
        $merged_any = true;
        while ( $merged_any ) {
            $merged_any = false;
            $micro = array();
            $big   = array();
            foreach ( $clusters as $cn => $cl ) {
                if ( $cn === 'Non classé' ) continue;
                if ( count( $cl['pages'] ) < $min_cluster_size ) $micro[ $cn ] = $cl;
                else $big[ $cn ] = $cl;
            }
            if ( empty( $micro ) || count( $big ) < 3 ) break;

            foreach ( $micro as $mcn => $mcl ) {
                $best_target = null;
                $best_avg_sim = -1;
                foreach ( $big as $bcn => $bcl ) {
                    $total_sim = 0;
                    $cnt = 0;
                    foreach ( $mcl['pages'] as $mp ) {
                        if ( ! isset( $vectors[ $mp ] ) ) continue;
                        foreach ( $bcl['pages'] as $bp ) {
                            if ( ! isset( $vectors[ $bp ] ) ) continue;
                            $total_sim += \HTS_Embeddings::cosine_similarity( $vectors[ $mp ], $vectors[ $bp ] );
                            $cnt++;
                        }
                    }
                    $avg = $cnt > 0 ? $total_sim / $cnt : 0;
                    if ( $avg > $best_avg_sim ) {
                        $best_avg_sim = $avg;
                        $best_target  = $bcn;
                    }
                }
                if ( $best_target !== null ) {
                    $clusters[ $best_target ]['pages'] = array_unique( array_merge( $clusters[ $best_target ]['pages'], $mcl['pages'] ) );
                    unset( $clusters[ $mcn ] );
                    $merged_any = true;
                    hts_add_log( sprintf( 'Micro-cluster "%s" (%dp) fusionné dans "%s"', $mcn, count( $mcl['pages'] ), $best_target ), 'info', 'cocon' );
                    break; // restart while loop
                }
            }
        }

        // 7. Diagnostic log
        $seed_summary = sprintf( '%d seeds, %d pages, %d orphelins, %d clusters', count( $valid_seeds ), count( $nodes ), count( $orphans ), count( $clusters ) );
        hts_add_log( 'Seeded clustering: ' . $seed_summary, 'info', 'cocon' );
        if ( class_exists( 'HTS_Cocon_Commander' ) ) {
            \HTS_Cocon_Commander::cocon_log( 'debug_step', 'Clustering terminé: ' . $seed_summary . '. Clusters: ' . implode( ', ', array_map( function( $name, $cl ) {
                return '"' . mb_substr( $name, 0, 30 ) . '" (' . count( $cl['pages'] ) . 'p, pillar=' . ( $cl['pillar_id'] ?? '?' ) . ')';
            }, array_keys( $clusters ), $clusters ) ) );
        }

        return $clusters;
    }

    private function cluster_with_llm_guided( $nodes, $explicit_pillar_ids = array() ) {
        $emb = new HTS_Embeddings();
        $vectors = $emb->load_all_vectors();
        $this->cached_vectors = $vectors;

        // ══════════════════════════════════════════════════════════════════
        // Phase A0: Thematic diversity detection (SOFT FLAG, NOT EXCLUSION)
        // ══════════════════════════════════════════════════════════════════
        // BUSINESS REALITY: An e-commerce selling shoes adds a "Handbags"
        // page = diversification, NOT off-topic. We must NEVER auto-exclude.
        //
        // What we DO: flag pages with new/different vocabulary so GPT knows
        // to create a SEPARATE cluster for them (not mix with existing ones).
        // What we DON'T: remove pages from analysis or auto-exclude pages.
        // ══════════════════════════════════════════════════════════════════
        $off_topic_pids = array(); // Kept empty — we no longer auto-exclude

        // Build site corpus for TFTD (used later in link suggestion gates)
        $site_corpus_a0 = array();
        foreach ( $nodes as $pid => $n ) {
            $post = get_post( $pid );
            $text = mb_strtolower( $n['title'] );
            if ( $post ) {
                $text .= ' ' . mb_strtolower( html_entity_decode( wp_strip_all_tags( mb_substr( $post->post_content, 0, 500 ) ), ENT_QUOTES, 'UTF-8' ) );
            }
            $site_corpus_a0[ $pid ] = $text;
        }
        $this->cached_site_corpus = $site_corpus_a0; // Cache for link gates

        // Detect pages with unique vocabulary (informational flag for GPT prompt)
        $diverse_pages = array();
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir' ) ) : array() );

        foreach ( $nodes as $pid => $n ) {
            $title_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $n['title'] ) );
            $title_words = array_unique( array_values( array_filter( $title_words, function( $w ) use ( $sw ) {
                return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
            } ) ) );
            if ( count( $title_words ) < 2 ) continue;

            $foreign_count = 0;
            foreach ( $title_words as $tw ) {
                $found = false;
                foreach ( $site_corpus_a0 as $other_pid => $corpus ) {
                    if ( $other_pid === $pid ) continue;
                    if ( mb_strpos( $corpus, $tw ) !== false ) { $found = true; break; }
                }
                if ( ! $found ) $foreign_count++;
            }

            $foreign_ratio = $foreign_count / count( $title_words );
            if ( $foreign_ratio > 0.50 && $foreign_count >= 2 ) {
                $diverse_pages[ $pid ] = array(
                    'title' => $n['title'],
                    'foreign_ratio' => round( $foreign_ratio, 2 ),
                );
                hts_add_log(
                    '🆕 Vocabulaire unique : "' . mb_substr( $n['title'], 0, 50 )
                    . '" — ' . $foreign_count . '/' . count( $title_words )
                    . ' termes nouveaux (diversification probable)',
                    'info', 'cocon'
                );
            }
        }
        $this->cached_diverse_pages = $diverse_pages; // Used in GPT prompt

        // ALL pages go to GPT — no automatic exclusion
        $nodes_for_gpt = $nodes;

        // ── Identify pillar pages from money pages discovery (same source as the panel) ──
        // PRIORITY: If explicit IDs are passed from the UI (user's checkboxes), use those.
        // This is the source of truth — not the DB, not the cache.
        $menu_pillar_ids = array();
        $mp_threshold = 30;

        if ( ! empty( $explicit_pillar_ids ) ) {
            // Use EXACTLY the IDs the user checked in the UI
            foreach ( $explicit_pillar_ids as $epid ) {
                if ( isset( $nodes_for_gpt[ $epid ] ) ) {
                    $menu_pillar_ids[ $epid ] = true;
                }
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf(
                    'Clustering: %d pillar IDs EXPLICITES depuis UI (source de vérité). IDs: %s',
                    count( $menu_pillar_ids ), implode( ', ', array_keys( $menu_pillar_ids ) )
                ), 'info', 'cocon' );
            }
        } else {
            // Fallback: unified source (v2.7.2 — discovery + manual + nav menus)
            $unified_ids = $this->get_all_pillar_ids( $nodes_for_gpt, $this->analysis_lang );
            foreach ( $unified_ids as $uid ) {
                $menu_pillar_ids[ $uid ] = true;
            }
        } // end else (fallback to unified source)

        // ── Phase A: Build page catalog for GPT ──
        $page_catalog = '';
        $page_ids = array();
        $idx = 0;
        foreach ( $nodes_for_gpt as $pid => $n ) {
            $post = get_post( $pid );
            $excerpt = $post ? html_entity_decode( wp_strip_all_tags( mb_substr( $post->post_content, 0, 250 ) ), ENT_QUOTES, 'UTF-8' ) : '';
            $excerpt = preg_replace( '/\s+/', ' ', trim( $excerpt ) );
            $kw = implode( ', ', array_slice( $n['keywords'], 0, 5 ) );
            $cats = implode( ', ', $n['categories'] ?? array() );
            $wc = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;
            $type_hint = 'ARTICLE';
            if ( isset( $menu_pillar_ids[ $pid ] ) ) {
                $type_hint = 'PILLAR';
            } elseif ( $wc < 100 ) {
                $type_hint = 'NAV';
            } elseif ( $wc < 200 ) {
                $type_hint = 'THIN';
            }
            // Detect utility pages by title/slug pattern — but NEVER override PILLAR
            if ( $type_hint !== 'PILLAR' ) {
                $util_check = mb_strtolower( $n['title'] . ' ' . ( $post ? $post->post_name : '' ) );
                $util_pats = array( 'contact', 'mentions', 'cgv', 'cgu', 'confidential', 'cookies', 'panier', 'cart', 'checkout', 'compte', 'account', 'login', 'inscription', 'plan du site', 'sitemap', 'merci', 'thank', 'remerciement', 'confirmation', '404', 'erreur', 'desinscription', 'unsubscribe' );
                foreach ( $util_pats as $up_check ) {
                    if ( mb_strpos( $util_check, $up_check ) !== false ) { $type_hint = 'UTIL'; break; }
                }
            }
            $page_catalog .= "ID:{$pid} | [{$type_hint} {$wc}mots] \"{$n['title']}\" | Cat: {$cats} | KW: {$kw} | Extrait: {$excerpt}\n";
            $page_ids[] = $pid;
            $idx++;
        }

        $n_pages = count( $page_ids );
        $n_pillars = count( $menu_pillar_ids );
        // target_k = number of pillar pages if we have them, otherwise sqrt formula
        if ( $n_pillars >= 2 ) {
            $target_k = $n_pillars;
            if ( function_exists( 'hts_add_log' ) ) {
                $pillar_titles = array();
                foreach ( $menu_pillar_ids as $_ppid => $_v ) {
                    $pillar_titles[] = '"' . ( $nodes_for_gpt[ $_ppid ]['title'] ?? '?' ) . '" (ID:' . $_ppid . ')';
                }
                hts_add_log( sprintf(
                    'Cocon PILLAR: %d pages detectees → target %d clusters. Pages: %s',
                    $n_pillars, $target_k, implode( ', ', $pillar_titles )
                ), 'info', 'cocon' );
            }
        } else {
            $target_k = max( 3, min( 10, (int) round( sqrt( $n_pages / 1.8 ) ) ) );
        }

        // ── Phase B: o3 classifies all pages (1 API call) ──
        // Language-aware prompts: cluster names MUST be in the content language
        $is_fr = ( $this->analysis_lang === 'fr' );
        $hors_theme_label = $is_fr ? 'Hors-thème' : 'Off-topic';

        // ══════════════════════════════════════════════════════════════════
        //  HYBRID SEO/GEO CLUSTERING
        //
        //  Strategy: o3 builds DEEP clusters (8-15 pages) for topical authority.
        //  Money pages are commercial anchors — some may share a cluster if
        //  they target similar keywords (e.g. "Audit SEO gratuit" + "Audit
        //  technique SEO" = same cluster, one is pillar, other is page forte).
        //
        //  This maximizes:
        //  - Topical authority (deep clusters > thin clusters)
        //  - Commercial coverage (every cluster has a money page)
        //  - GEO visibility (AI models cite experts with depth)
        // ══════════════════════════════════════════════════════════════════

        if ( $n_pillars >= 2 ) {
            // ── HYBRID MODE: money pages guide clustering, o3 decides depth ──

            // Build categorized page lists
            $money_catalog = '';
            $article_catalog = '';
            $money_count = 0;
            $article_count = 0;

            foreach ( $nodes_for_gpt as $pid => $n ) {
                $post = get_post( $pid );
                $excerpt = $post ? html_entity_decode( wp_strip_all_tags( mb_substr( $post->post_content, 0, 250 ) ), ENT_QUOTES, 'UTF-8' ) : '';
                $excerpt = preg_replace( '/\s+/', ' ', trim( $excerpt ) );
                $kw = implode( ', ', array_slice( $n['keywords'], 0, 5 ) );
                $wc = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;
                $gsc_clicks = (int) get_post_meta( $pid, '_hts_gsc_clicks', true );
                $gsc_pos = round( (float) get_post_meta( $pid, '_hts_gsc_position', true ), 1 );
                $gsc_info = $gsc_clicks > 0 ? " | GSC: {$gsc_clicks} clics, pos {$gsc_pos}" : '';

                if ( isset( $menu_pillar_ids[ $pid ] ) ) {
                    $money_count++;
                    // Enrich with SEO authority signals for pillar selection
                    $in_links = $n['in_count'] ?? 0;
                    $out_links = $n['out_count'] ?? 0;
                    $is_page = $n['type'] === 'page' ? 'PAGE' : 'POST';
                    $in_menu = in_array( $pid, array_keys( $menu_pillar_ids ) ) ? 'Menu' : '';
                    $pillar_score = $n['pillar_score'] ?? 0;
                    $money_catalog .= "ID:{$pid} [{$is_page} {$wc}mots] \"{$n['title']}\" | Score:{$pillar_score} | Liens entrants:{$in_links} Sortants:{$out_links}{$gsc_info} | KW: {$kw} | Extrait: {$excerpt}\n";
                } else {
                    // Skip NAV/UTIL pages
                    if ( $wc < 100 ) continue;
                    $util_check = mb_strtolower( $n['title'] . ' ' . ( $post ? $post->post_name : '' ) );
                    $is_util = false;
                    foreach ( array( 'contact', 'mentions', 'cgv', 'cgu', 'confidential', 'cookies', 'panier', 'cart', 'checkout', 'compte', 'account', 'login', 'inscription', 'plan du site', 'sitemap', 'merci', 'thank', 'remerciement', 'confirmation', '404', 'erreur', 'desinscription', 'unsubscribe' ) as $up_check ) {
                        if ( mb_strpos( $util_check, $up_check ) !== false ) { $is_util = true; break; }
                    }
                    if ( $is_util ) continue;
                    $article_count++;
                    $article_catalog .= "ID:{$pid} [{$wc}mots] \"{$n['title']}\" | KW: {$kw}{$gsc_info} | Extrait: {$excerpt}\n";
                }
            }

            // Calculate ideal cluster range for SEO depth
            // SEO/GEO sweet spot: 8-12 pages per cluster for topical authority
            // Each cluster must have at least 1 money page → min = ceil(money/3) so max 3 PP per cluster
            // Each cluster should have at least 5 pages → max = total/5
            $total_content = $money_count + $article_count;
            $min_clusters = max( 4, (int) ceil( $money_count / 3 ) );   // Max 3 money pages per cluster
            $max_clusters = min( $money_count, (int) ceil( $total_content / 5 ) );  // Min 5 pages per cluster
            $ideal_clusters = (int) round( $total_content / 10 );       // ~10 pages per cluster = ideal
            if ( $max_clusters < $min_clusters ) $max_clusters = $min_clusters + 2;
            // Clamp ideal into range
            $ideal_clusters = max( $min_clusters, min( $max_clusters, $ideal_clusters ) );

            $system_msg = $is_fr
                ? 'Tu es un expert SEO/GEO (Generative Engine Optimization) de niveau mondial. Réponds UNIQUEMENT en JSON valide. Pas de markdown.'
                : 'You are a world-class SEO/GEO (Generative Engine Optimization) expert. Respond ONLY in valid JSON. No markdown.';

            $prompt = $is_fr
                ? "CONTEXTE : Un site web a {$money_count} pages business et {$article_count} articles de blog. Le client a sélectionné ces {$money_count} pages comme pages commerciales importantes.

PAGES BUSINESS (pages commerciales du client) :
{$money_catalog}
ARTICLES DE BLOG :
{$article_catalog}
MISSION : Construis des COCONS SÉMANTIQUES profonds pour maximiser l'autorité thématique sur Google ET la visibilité dans les réponses des IA (ChatGPT, Perplexity, Google AI Overview).

STRATÉGIE SEO/GEO :
- Un cocon profond (8-15 pages) = signal FORT d'expertise → Google te positionne → les IA te citent
- Un cocon maigre (1-3 pages) = AUCUNE autorité → ni Google ni les IA ne te remarquent
- Des pages business SIMILAIRES doivent être dans le MÊME cocon (ex: 'Audit SEO gratuit' et 'Audit technique SEO' = même cocon 'Audits SEO')

RÈGLES :
1. Crée entre {$min_clusters} et {$max_clusters} cocons (idéalement ~{$ideal_clusters}). Chaque cocon DOIT avoir au minimum 4 pages.
2. Chaque cocon DOIT contenir au moins 1 page business. C'est la page PILIER du cocon.
3. Si 2+ pages business sont thématiquement proches → MÊME cocon. Désigne la plus forte comme pilier, les autres comme 'pages_fortes'.
4. CHOIX DU PILIER — la page business la plus forte d'un cocon est celle qui cumule le plus de ces signaux :
   - Score élevé (indiqué dans les données)
   - Plus de liens entrants = plus d'autorité
   - Plus de clics GSC = validé par Google
   - Meilleure position GSC = déjà bien classé
   - Plus de mots = contenu plus complet
   - Type PAGE plutôt que POST
5. Chaque article de blog → assigne-le au cocon le plus pertinent thématiquement.
6. Aucun article oublié. Si un article ne correspond à rien → cocon « {$hors_theme_label} ».
7. Nomme chaque cocon EN FRANÇAIS en 3-5 mots décrivant le thème.
8. Pour chaque page business NON-pilier, explique en 1 phrase pourquoi elle est dans ce cocon plutôt que pilier de son propre cocon.

JSON STRICT :
{
  \"clusters\": [
    {
      \"name\": \"Nom du cocon\",
      \"pillar_id\": 123,
      \"pages_fortes\": [
        { \"id\": 456, \"raison\": \"Thème proche du pilier — renforce l'autorité du cocon\" }
      ],
      \"article_ids\": [789, 101, 102],
      \"theme\": \"Description en 1 phrase du cocon\"
    }
  ],
  \"missing_topics\": [
    { \"name\": \"Sujet manquant\", \"reason\": \"Pourquoi c'est important pour le GEO\", \"suggested_title\": \"Titre suggéré\" }
  ]
}"
                : "CONTEXT: A website has {$money_count} business pages and {$article_count} blog articles. The client selected these {$money_count} pages as important commercial pages.

BUSINESS PAGES (client's commercial pages):
{$money_catalog}
BLOG ARTICLES:
{$article_catalog}
MISSION: Build DEEP content silos to maximize topical authority on Google AND visibility in AI responses (ChatGPT, Perplexity, Google AI Overview).

SEO/GEO STRATEGY:
- A deep silo (8-15 pages) = STRONG expertise signal → Google ranks you → AIs cite you
- A thin silo (1-3 pages) = NO authority → neither Google nor AIs notice you
- SIMILAR business pages should be in the SAME silo (e.g. 'Free SEO Audit' and 'Technical SEO Audit' = same 'SEO Audits' silo)

RULES:
1. Create between {$min_clusters} and {$max_clusters} silos (ideally ~{$ideal_clusters}). Each silo MUST have at least 4 pages.
2. Each silo MUST contain at least 1 business page. This is the silo's PILLAR page.
3. If 2+ business pages are thematically close → SAME silo. Designate the strongest as pillar, others as 'strong_pages'.
4. PILLAR SELECTION — the strongest business page in a silo is the one with the most of these signals:
   - High Score (shown in data)
   - More incoming links = more authority
   - More GSC clicks = validated by Google
   - Better GSC position = already ranking well
   - More words = more comprehensive content
   - Type PAGE rather than POST
5. Each blog article → assign to the most relevant silo.
6. No article left out. If an article doesn't fit → silo \"{$hors_theme_label}\".
7. Name each silo IN ENGLISH with 3-5 words.
8. For each non-pillar business page, explain in 1 sentence why it's in this silo instead of being its own pillar.

STRICT JSON:
{
  \"clusters\": [
    {
      \"name\": \"Silo name\",
      \"pillar_id\": 123,
      \"strong_pages\": [
        { \"id\": 456, \"reason\": \"Close theme to pillar — reinforces silo authority\" }
      ],
      \"article_ids\": [789, 101, 102],
      \"theme\": \"One-sentence description\"
    }
  ],
  \"missing_topics\": [
    { \"name\": \"Missing topic\", \"reason\": \"Why it matters for GEO\", \"suggested_title\": \"Suggested title\" }
  ]
}";

            hts_add_log( sprintf(
                'Clustering HYBRIDE SEO/GEO: %d pages business, %d articles, cible %d-%d clusters. Pages business: %s',
                $money_count, $article_count, $min_clusters, $max_clusters, trim( $money_catalog )
            ), 'info', 'cocon' );

        } else {
            // ── FREE CLUSTERING (no money pages selected) ──
            $target_k = max( 3, min( 10, (int) round( sqrt( $n_pages / 1.8 ) ) ) );
            $prompt_lang_note = $is_fr
                ? 'Nomme chaque cluster EN FRANÇAIS en 3-5 mots SPÉCIFIQUES et UNIQUES'
                : 'Name each cluster IN ENGLISH with 3-5 SPECIFIC and UNIQUE words';
            $system_msg = $is_fr
                ? 'Réponds UNIQUEMENT en JSON valide. CHAQUE page [ARTICLE] et [THIN] DOIT apparaître dans exactement un cluster.'
                : 'Respond ONLY in valid JSON. EVERY [ARTICLE] and [THIN] page MUST appear in exactly one cluster.';

            $prompt = ( $is_fr
                ? "Tu es un expert SEO en cocons sémantiques. Voici {$n_pages} pages d'un même site web."
                : "You are an SEO expert in content clusters. Here are {$n_pages} pages from the same website." )
            . "\n\n" . ( $is_fr
                ? "MISSION : Regroupe-les en clusters thématiques cohérents. Vise environ {$target_k} à " . ( $target_k + 4 ) . " clusters."
                : "MISSION: Group them into coherent thematic clusters. Aim for roughly {$target_k} to " . ( $target_k + 4 ) . " clusters." )
            . "\n\n" . ( $is_fr
                ? "RÈGLES CRITIQUES :
1. Chaque cluster = un SOUS-THÈME PRÉCIS et HOMOGÈNE
2. Un cluster de plus de 12 pages est SUSPECT — découpez-le
3. Pages [NAV] et [UTIL] → NE LES INCLUS PAS
4. TOUTES les pages [ARTICLE] et [THIN] DOIVENT être dans un cluster
5. {$prompt_lang_note}
6. Pages hors-thème → cluster « {$hors_theme_label} »
7. VÉRIFIE que toutes les pages sont classées
8. Taille idéale = 5-10 pages par cluster"
                : "CRITICAL RULES:
1. Each cluster = a SPECIFIC and HOMOGENEOUS SUB-TOPIC
2. A cluster with more than 12 pages is SUSPICIOUS — split it
3. [NAV] and [UTIL] pages → DO NOT INCLUDE THEM
4. ALL [ARTICLE] and [THIN] pages MUST be in a cluster
5. {$prompt_lang_note}
6. Off-topic pages → cluster \"{$hors_theme_label}\"
7. VERIFY all pages are classified
8. Ideal size = 5-10 pages per cluster" )
            . "\n\nPAGES :\n{$page_catalog}\n";

            if ( ! empty( $diverse_pages ) ) {
                $div_list = '';
                foreach ( $diverse_pages as $dpid => $dinfo ) {
                    $div_list .= "- ID:{$dpid} \"{$dinfo['title']}\" ({$dinfo['foreign_ratio']}% " . ( $is_fr ? 'vocabulaire unique' : 'unique vocabulary' ) . ")\n";
                }
                $prompt .= "\n" . ( $is_fr ? "ATTENTION : vocabulaire très différent — cluster SÉPARÉ." : "WARNING: very different vocabulary — SEPARATE cluster." ) . "\n{$div_list}\n";
            }

            $missing_label = $is_fr ? "Identifie aussi 2-3 SUJETS MANQUANTS." : "Also identify 2-3 MISSING TOPICS.";
            $name_label = $is_fr ? 'Nom spécifique unique' : 'Unique specific name';
            $theme_label = $is_fr ? 'Description en 1 phrase' : 'One-sentence description';
            $missing_name = $is_fr ? 'Sujet manquant' : 'Missing topic';
            $missing_reason = $is_fr ? "Pourquoi c'est important" : 'Why it matters';
            $missing_title = $is_fr ? "Titre d'article suggéré" : 'Suggested article title';

            $prompt .= "{$missing_label}\n\nJSON STRICT :\n{\n  \"clusters\": [\n    { \"name\": \"{$name_label}\", \"page_ids\": [1, 2, 3], \"theme\": \"{$theme_label}\" }\n  ],\n  \"missing_topics\": [\n    { \"name\": \"{$missing_name}\", \"reason\": \"{$missing_reason}\", \"suggested_title\": \"{$missing_title}\" }\n  ]\n}";

            hts_add_log( sprintf( 'Clustering MODE LIBRE: %d pages, target %d clusters', $n_pages, $target_k ), 'info', 'cocon' );
        }

        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 120, // Must stay under Apache/OVH ~160s timeout
            'headers' => array( 'Authorization' => 'Bearer ' . $this->openai_key, 'Content-Type' => 'application/json' ),
            'body' => wp_json_encode( array(
                'model' => 'o3',
                'messages' => array(
                    array( 'role' => 'system', 'content' => $system_msg ),
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'max_completion_tokens' => 16000,
                'reasoning_effort' => 'medium',
            ) ),
        ) );

        // Track usage
        if ( ! is_wp_error( $resp ) ) {
            $body = json_decode( wp_remote_retrieve_body( $resp ), true );
            $tk = (int) ( $body['usage']['total_tokens'] ?? 0 );
            if ( $tk > 0 ) {
                $usage = get_option( 'hts_openai_usage', array() );
                $mk = wp_date( 'Y-m' );
                $usage[ $mk ] = ( (int) ( $usage[ $mk ] ?? 0 ) ) + $tk;
                update_option( 'hts_openai_usage', $usage, false );
            }
        }

        if ( is_wp_error( $resp ) ) {
            hts_add_log( 'LLM clustering: erreur WP — ' . $resp->get_error_message() . ' — fallback embeddings', 'warning', 'cocon' );
            return $this->cluster_with_embeddings( $nodes );
        }

        // Check HTTP status code (o3 can return 429 rate limit, 500, 503 etc.)
        $http_code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $http_code !== 200 ) {
            $err_body = wp_remote_retrieve_body( $resp );
            $err_msg = '';
            $err_json = json_decode( $err_body, true );
            if ( $err_json && isset( $err_json['error']['message'] ) ) {
                $err_msg = $err_json['error']['message'];
            }
            hts_add_log( sprintf( 'LLM clustering: HTTP %d — %s — fallback embeddings', $http_code, mb_substr( $err_msg ?: $err_body, 0, 200 ) ), 'error', 'cocon' );
            return $this->cluster_with_embeddings( $nodes );
        }

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $txt = $body['choices'][0]['message']['content'] ?? '';
        $txt = preg_replace( '/^```json\s*/', '', trim( $txt ) );
        $txt = preg_replace( '/\s*```$/', '', $txt );
        $res = json_decode( $txt, true );

        if ( ! $res || empty( $res['clusters'] ) ) {
            hts_add_log( 'LLM-Guided clustering: reponse invalide — fallback embeddings. Raw: ' . mb_substr( $txt, 0, 200 ), 'warning', 'cocon' );
            return $this->cluster_with_embeddings( $nodes );
        }

        // Diagnostic log
        $gpt_cluster_count = count( $res['clusters'] );
        $gpt_page_count = 0;
        foreach ( $res['clusters'] as $_gc ) {
            // Count from hybrid format
            if ( isset( $_gc['pillar_id'] ) ) {
                $gpt_page_count += 1; // pillar
                $gpt_page_count += count( $_gc['pages_fortes'] ?? $_gc['strong_pages'] ?? array() );
                $gpt_page_count += count( $_gc['article_ids'] ?? array() );
            }
            // Count from legacy format
            $gpt_page_count += count( $_gc['page_ids'] ?? array() );
        }
        hts_add_log( sprintf(
            'Cocon o3 result: %d clusters, %d pages assignees (sur %d envoyees, %d money pages). Clusters: %s',
            $gpt_cluster_count, $gpt_page_count, $n_pages, $n_pillars,
            implode( ', ', array_map( function( $c ) {
                $ct = count( $c['article_ids'] ?? $c['page_ids'] ?? array() );
                $pf = count( $c['pages_fortes'] ?? $c['strong_pages'] ?? array() );
                return '"' . ( $c['name'] ?? '?' ) . '" (' . ( $ct + $pf + 1 ) . 'p)';
            }, $res['clusters'] ) )
        ), 'info', 'cocon' );

        // Save missing topics
        if ( ! empty( $res['missing_topics'] ) ) {
            update_option( 'hts_cocon_missing_clusters', $res['missing_topics'], false );
        }

        // ── Phase C: Parse GPT clusters + validate page IDs ──
        $clusters = array();
        $assigned_pids = array();
        $valid_pids = array_keys( $nodes );

        // Count how many content pages (ARTICLE + THIN + PILLAR) GPT should have classified
        $content_page_count = 0;
        foreach ( $nodes_for_gpt as $pid => $n ) {
            // PILLAR pages always count
            if ( isset( $menu_pillar_ids[ $pid ] ) ) { $content_page_count++; continue; }
            $post = get_post( $pid );
            $wc = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;
            // Exclude NAV (<100 words) and UTIL pages from expected count
            if ( $wc < 100 ) continue;
            $util_check = mb_strtolower( $n['title'] . ' ' . ( $post ? $post->post_name : '' ) );
            $is_util = false;
            foreach ( array( 'contact', 'mentions', 'cgv', 'cgu', 'confidential', 'cookies', 'panier', 'cart', 'checkout', 'compte', 'account', 'login', 'inscription', 'plan du site', 'sitemap', 'merci', 'thank', 'remerciement', 'confirmation', '404', 'erreur', 'desinscription', 'unsubscribe' ) as $up ) {
                if ( mb_strpos( $util_check, $up ) !== false ) { $is_util = true; break; }
            }
            if ( ! $is_util ) $content_page_count++;
        }

        foreach ( $res['clusters'] as $gc ) {
            $name = trim( $gc['name'] ?? 'Groupe' );
            $theme = trim( $gc['theme'] ?? '' );

            // ── Support both formats: hybrid (pillar_id + pages_fortes + article_ids) and legacy (page_ids) ──
            $gpt_pids = array();
            $cluster_pillar_id = 0;

            if ( isset( $gc['pillar_id'] ) ) {
                // Hybrid format
                $cluster_pillar_id = (int) $gc['pillar_id'];
                $gpt_pids[] = $cluster_pillar_id;

                // pages_fortes / strong_pages
                $fortes = $gc['pages_fortes'] ?? $gc['strong_pages'] ?? array();
                foreach ( $fortes as $pf ) {
                    $pf_id = (int) ( is_array( $pf ) ? ( $pf['id'] ?? 0 ) : $pf );
                    if ( $pf_id ) $gpt_pids[] = $pf_id;
                }

                // article_ids
                foreach ( $gc['article_ids'] ?? array() as $aid ) {
                    $gpt_pids[] = (int) $aid;
                }
            }

            // Also support legacy page_ids format (free mode or fallback)
            if ( ! empty( $gc['page_ids'] ) ) {
                foreach ( $gc['page_ids'] as $pid ) {
                    $gpt_pids[] = (int) $pid;
                }
            }

            $gpt_pids = array_unique( array_filter( $gpt_pids ) );

            // Only keep valid page IDs that exist in our nodes
            $valid_group_pids = array();
            foreach ( $gpt_pids as $pid ) {
                if ( in_array( $pid, $valid_pids ) && ! in_array( $pid, $assigned_pids ) ) {
                    $valid_group_pids[] = $pid;
                    $assigned_pids[] = $pid;
                }
            }

            if ( empty( $valid_group_pids ) ) continue;

            // Validate pillar_id exists in the group
            if ( $cluster_pillar_id && ! in_array( $cluster_pillar_id, $valid_group_pids ) ) {
                $cluster_pillar_id = 0; // Will be auto-selected in Phase 5
            }

            // Deduplicate cluster names
            if ( isset( $clusters[ $name ] ) ) $name .= ' (' . count( $valid_group_pids ) . ')';

            $clusters[ $name ] = array(
                'name'      => $name,
                'pillar_id' => $cluster_pillar_id,
                'pages'     => $valid_group_pids,
                'theme'     => $theme,
            );
        }

        // ── Phase C2: Check completeness — retry if GPT missed too many pages ──
        $missing_pids = array_diff( $valid_pids, $assigned_pids );
        $missing_content = 0;
        foreach ( $missing_pids as $mpid ) {
            $mp = get_post( $mpid );
            $mwc = $mp ? hts_word_count( wp_strip_all_tags( $mp->post_content ) ) : 0;
            if ( $mwc >= 100 ) $missing_content++;
        }
        $missing_pct = $content_page_count > 0 ? ( $missing_content / $content_page_count ) * 100 : 0;

        if ( $missing_pct > 20 && $missing_content >= 5 && ! empty( $this->openai_key ) ) {
            hts_add_log(
                'GPT a oublié ' . $missing_content . ' pages contenu (' . round( $missing_pct ) . '%) — relance ciblée',
                'warning', 'cocon'
            );

            // Build list of missing pages + existing clusters for GPT
            $missing_catalog = '';
            foreach ( $missing_pids as $mpid ) {
                if ( ! isset( $nodes[ $mpid ] ) ) continue;
                $mp = get_post( $mpid );
                $mwc = $mp ? hts_word_count( wp_strip_all_tags( $mp->post_content ) ) : 0;
                if ( $mwc < 100 ) continue; // Skip NAV
                $mexc = $mp ? html_entity_decode( wp_strip_all_tags( mb_substr( $mp->post_content, 0, 300 ) ), ENT_QUOTES, 'UTF-8' ) : '';
                $mexc = preg_replace( '/\s+/', ' ', trim( $mexc ) );
                $missing_catalog .= "ID:{$mpid} | [{$mwc}mots] \"{$nodes[$mpid]['title']}\" | Extrait: {$mexc}\n";
            }

            $existing_clusters_desc = '';
            foreach ( $clusters as $cname => $cl ) {
                $existing_clusters_desc .= "- \"{$cname}\" (" . count( $cl['pages'] ) . " pages)\n";
            }

            $retry_prompt = "Tu es un expert SEO. Lors du premier clustering, ces {$missing_content} pages ont été oubliées. Classe-les dans les clusters existants OU crée de nouveaux clusters si nécessaire.

CLUSTERS EXISTANTS :
{$existing_clusters_desc}

PAGES OUBLIÉES À CLASSER :
{$missing_catalog}

RÈGLES :
- CHAQUE page ci-dessus DOIT être assignée à un cluster (existant ou nouveau)
- Si une page correspond à un cluster existant, utilise EXACTEMENT le même nom
- Si une page ne correspond à rien, crée un nouveau cluster

JSON STRICT :
{\"assignments\": [{\"page_id\": 123, \"cluster\": \"Nom du cluster\"}]}";

            $retry_resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
                'timeout' => 60,
                'headers' => array( 'Authorization' => 'Bearer ' . $this->openai_key, 'Content-Type' => 'application/json' ),
                'body' => wp_json_encode( array(
                    'model' => 'gpt-4.1',
                    'messages' => array(
                        array( 'role' => 'system', 'content' => 'Réponds UNIQUEMENT en JSON valide.' ),
                        array( 'role' => 'user', 'content' => $retry_prompt ),
                    ),
                    'temperature' => 0.1,
                    'max_tokens' => 4000,
                ) ),
            ) );

            if ( ! is_wp_error( $retry_resp ) ) {
                $retry_body = json_decode( wp_remote_retrieve_body( $retry_resp ), true );
                $retry_txt = $retry_body['choices'][0]['message']['content'] ?? '';
                $retry_txt = preg_replace( '/^```json\s*/', '', trim( $retry_txt ) );
                $retry_txt = preg_replace( '/\s*```$/', '', $retry_txt );
                $retry_res = json_decode( $retry_txt, true );

                if ( ! empty( $retry_res['assignments'] ) ) {
                    $retry_assigned = 0;
                    foreach ( $retry_res['assignments'] as $asgn ) {
                        $rpid = (int) ( $asgn['page_id'] ?? 0 );
                        $rcname = trim( $asgn['cluster'] ?? '' );
                        if ( ! $rpid || ! $rcname || ! in_array( $rpid, $valid_pids ) || in_array( $rpid, $assigned_pids ) ) continue;

                        // Create cluster if new
                        if ( ! isset( $clusters[ $rcname ] ) ) {
                            $clusters[ $rcname ] = array( 'name' => $rcname, 'pillar_id' => 0, 'pages' => array(), 'theme' => '' );
                        }
                        $clusters[ $rcname ]['pages'][] = $rpid;
                        $assigned_pids[] = $rpid;
                        $retry_assigned++;
                    }
                    hts_add_log(
                        'Retry GPT : ' . $retry_assigned . '/' . $missing_content . ' pages classées',
                        'success', 'cocon'
                    );
                }

                // Track usage
                $tk = (int) ( $retry_body['usage']['total_tokens'] ?? 0 );
                if ( $tk > 0 ) {
                    $usage = get_option( 'hts_openai_usage', array() );
                    $mk = wp_date( 'Y-m' );
                    $usage[ $mk ] = ( (int) ( $usage[ $mk ] ?? 0 ) ) + $tk;
                    update_option( 'hts_openai_usage', $usage, false );
                }
            }
        }

        // ── Phase D: Handle unassigned pages (GPT missed some) ──
        $unassigned = array_diff( $valid_pids, $assigned_pids );

        // Pre-detect utility pages among unassigned (these should NOT pollute clusters)
        $utility_patterns = array(
            'contact', 'mentions légales', 'mention légale', 'conditions générales',
            'cgv', 'cgu', 'politique de confidentialité', 'privacy', 'cookies',
            'panier', 'cart', 'checkout', 'mon compte', 'my account',
            'plan du site', 'sitemap', 'recherche', 'search', '404',
            'remerciement', 'thank you', 'merci', 'confirmation',
            'inscription', 'connexion', 'login', 'signup', 'register',
            'désabonnement', 'unsubscribe', 'partenaires', 'sponsors',
        );

        if ( ! empty( $unassigned ) && ! empty( $vectors ) && ! empty( $clusters ) ) {
            // Assign each unassigned page to the nearest cluster by embedding distance
            foreach ( $unassigned as $pid ) {
                // Check if page is a utility page (should go to Non classé regardless)
                $is_utility = false;
                $title_lower = mb_strtolower( $nodes[ $pid ]['title'] ?? get_the_title( $pid ) );
                foreach ( $utility_patterns as $up ) {
                    if ( mb_strpos( $title_lower, $up ) !== false ) { $is_utility = true; break; }
                }
                // Also flag pages with <200 words as utility
                $pid_wc = (int) ( $nodes[ $pid ]['word_count'] ?? 0 );
                if ( $pid_wc < 200 && $pid_wc > 0 ) $is_utility = true;

                if ( $is_utility || ! isset( $vectors[ $pid ] ) ) {
                    // Utility page or no embedding → "Non classé"
                    if ( ! isset( $clusters['Non classé'] ) ) {
                        $clusters['Non classé'] = array( 'name' => 'Non classé', 'pillar_id' => 0, 'pages' => array(), 'theme' => 'Pages utilitaires ou sans rapport thématique clair' );
                    }
                    $clusters['Non classé']['pages'][] = $pid;
                    continue;
                }

                $best_cluster = null;
                $best_sim = -1;
                foreach ( $clusters as $cname => $cl ) {
                    if ( $cname === 'Non classé' ) continue;
                    // Average similarity to cluster members
                    $total_sim = 0; $cnt = 0;
                    foreach ( $cl['pages'] as $cp ) {
                        if ( isset( $vectors[ $cp ] ) ) {
                            $total_sim += HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $cp ] );
                            $cnt++;
                        }
                    }
                    $avg_sim = $cnt > 0 ? $total_sim / $cnt : 0;
                    if ( $avg_sim > $best_sim ) {
                        $best_sim = $avg_sim;
                        $best_cluster = $cname;
                    }
                }

                if ( $best_cluster && $best_sim > 0.30 ) {
                    $clusters[ $best_cluster ]['pages'][] = $pid;
                    hts_add_log(
                        '🔄 Phase D : \"' . mb_substr( $nodes[ $pid ]['title'] ?? '', 0, 40 ) . '\" → \"' . $best_cluster . '\" (sim=' . round( $best_sim, 2 ) . ')',
                        'info', 'cocon'
                    );
                } else {
                    if ( ! isset( $clusters['Non classé'] ) ) {
                        $clusters['Non classé'] = array( 'name' => 'Non classé', 'pillar_id' => 0, 'pages' => array(), 'theme' => 'Pages utilitaires ou sans rapport thématique clair' );
                    }
                    $clusters['Non classé']['pages'][] = $pid;
                }
            }

            if ( count( $unassigned ) > 0 ) {
                hts_add_log(
                    '🧠 LLM-Guided : ' . count( $unassigned ) . ' page(s) non classée(s) par GPT → assignées par similarité',
                    'info', 'cocon'
                );
            }
        } elseif ( ! empty( $unassigned ) ) {
            if ( ! isset( $clusters['Non classé'] ) ) {
                $clusters['Non classé'] = array( 'name' => 'Non classé', 'pillar_id' => 0, 'pages' => array(), 'theme' => ( $this->analysis_lang === 'fr' ? 'Articles isolés' : 'Isolated articles' ) );
            }
            $clusters['Non classé']['pages'] = array_merge( $clusters['Non classé']['pages'] ?? array(), array_values( $unassigned ) );
        }

        // ── Phase D1.5: Mega-cluster split — auto-split clusters with 15+ pages ──
        if ( ! empty( $vectors ) ) {
            $to_split = array();
            foreach ( $clusters as $cname => $cl ) {
                if ( in_array( $cname, array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème', 'Hors-thème' ) ) ) continue;
                if ( count( $cl['pages'] ) >= 15 ) {
                    $to_split[ $cname ] = $cl;
                }
            }

            foreach ( $to_split as $cname => $cl ) {
                $pages = $cl['pages'];
                $n_sub = max( 2, min( 5, (int) round( count( $pages ) / 7 ) ) ); // Target 7 pages/sub-cluster

                // K-medoids split using embeddings
                $page_vectors = array();
                $no_vector = array();
                foreach ( $pages as $pid ) {
                    if ( isset( $vectors[ $pid ] ) ) {
                        $page_vectors[ $pid ] = $vectors[ $pid ];
                    } else {
                        $no_vector[] = $pid;
                    }
                }

                if ( count( $page_vectors ) < $n_sub * 2 ) continue; // Not enough vectors to split

                // Initialize medoids randomly
                $pids_with_vec = array_keys( $page_vectors );
                shuffle( $pids_with_vec );
                $medoids = array_slice( $pids_with_vec, 0, $n_sub );

                // K-medoids iterations
                for ( $iter = 0; $iter < 10; $iter++ ) {
                    // Assign pages to nearest medoid
                    $assignments = array_fill( 0, $n_sub, array() );
                    foreach ( $pids_with_vec as $pid ) {
                        $best_m = 0;
                        $best_sim = -1;
                        for ( $m = 0; $m < $n_sub; $m++ ) {
                            $sim = HTS_Embeddings::cosine_similarity( $page_vectors[ $pid ], $page_vectors[ $medoids[ $m ] ] );
                            if ( $sim > $best_sim ) { $best_sim = $sim; $best_m = $m; }
                        }
                        $assignments[ $best_m ][] = $pid;
                    }

                    // Update medoids to page with highest avg similarity to group
                    $changed = false;
                    for ( $m = 0; $m < $n_sub; $m++ ) {
                        if ( empty( $assignments[ $m ] ) ) continue;
                        $best_pid = $medoids[ $m ];
                        $best_avg = -1;
                        foreach ( $assignments[ $m ] as $cand ) {
                            $total = 0;
                            foreach ( $assignments[ $m ] as $other ) {
                                if ( $other === $cand ) continue;
                                $total += HTS_Embeddings::cosine_similarity( $page_vectors[ $cand ], $page_vectors[ $other ] );
                            }
                            $avg = count( $assignments[ $m ] ) > 1 ? $total / ( count( $assignments[ $m ] ) - 1 ) : 0;
                            if ( $avg > $best_avg ) { $best_avg = $avg; $best_pid = $cand; }
                        }
                        if ( $best_pid !== $medoids[ $m ] ) { $medoids[ $m ] = $best_pid; $changed = true; }
                    }
                    if ( ! $changed ) break;
                }

                // Use GPT to name the sub-clusters
                $sub_descriptions = array();
                for ( $m = 0; $m < $n_sub; $m++ ) {
                    $titles = array();
                    foreach ( $assignments[ $m ] as $pid ) {
                        $titles[] = $nodes[ $pid ]['title'] ?? get_the_title( $pid );
                    }
                    $sub_descriptions[ $m ] = implode( ', ', array_map( function( $t ) { return mb_substr( $t, 0, 40 ); }, array_slice( $titles, 0, 6 ) ) );
                }

                // Quick GPT call to name sub-clusters
                $is_fr_sub = ( $this->analysis_lang === 'fr' );
                $naming_prompt = $is_fr_sub
                    ? "Voici les sous-groupes d'un ancien cluster \"{$cname}\" que j'ai découpé. Donne un nom COURT (3-5 mots) et SPÉCIFIQUE pour chaque sous-groupe.\n\n"
                    : "Here are the sub-groups of a former cluster \"{$cname}\" that I split. Give a SHORT (3-5 words) and SPECIFIC name for each sub-group.\n\n";
                for ( $m = 0; $m < $n_sub; $m++ ) {
                    $g_label = $is_fr_sub ? 'Groupe' : 'Group';
                    $naming_prompt .= "{$g_label} " . ( $m + 1 ) . " (" . count( $assignments[ $m ] ) . " pages) : {$sub_descriptions[$m]}\n";
                }
                $naming_prompt .= $is_fr_sub
                    ? "\nJSON strict : {\"names\": [\"Nom groupe 1\", \"Nom groupe 2\", ...]}"
                    : "\nStrict JSON: {\"names\": [\"Group 1 name\", \"Group 2 name\", ...]}";

                $sub_names = array();
                if ( ! empty( $this->openai_key ) ) {
                    $name_resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
                        'timeout' => 30,
                        'headers' => array( 'Authorization' => 'Bearer ' . $this->openai_key, 'Content-Type' => 'application/json' ),
                        'body' => wp_json_encode( array(
                            'model' => 'gpt-4.1-mini',
                            'messages' => array(
                                array( 'role' => 'system', 'content' => 'JSON uniquement.' ),
                                array( 'role' => 'user', 'content' => $naming_prompt ),
                            ),
                            'temperature' => 0.1, 'max_tokens' => 500,
                        ) ),
                    ) );
                    if ( ! is_wp_error( $name_resp ) ) {
                        $nb = json_decode( wp_remote_retrieve_body( $name_resp ), true );
                        $nt = $nb['choices'][0]['message']['content'] ?? '';
                        $nt = preg_replace( '/^```json\s*/', '', trim( $nt ) );
                        $nt = preg_replace( '/\s*```$/', '', $nt );
                        $nr = json_decode( $nt, true );
                        if ( ! empty( $nr['names'] ) ) $sub_names = $nr['names'];
                    }
                }

                // Replace the mega-cluster with sub-clusters
                unset( $clusters[ $cname ] );
                for ( $m = 0; $m < $n_sub; $m++ ) {
                    if ( empty( $assignments[ $m ] ) ) continue;
                    $sub_name = $sub_names[ $m ] ?? $cname . ' — partie ' . ( $m + 1 );
                    // Avoid duplicate names
                    if ( isset( $clusters[ $sub_name ] ) ) $sub_name .= ' (' . count( $assignments[ $m ] ) . ')';
                    $sub_pages = $assignments[ $m ];
                    // Also assign no-vector pages to first sub-cluster
                    if ( $m === 0 && ! empty( $no_vector ) ) {
                        $sub_pages = array_merge( $sub_pages, $no_vector );
                        $no_vector = array();
                    }
                    $clusters[ $sub_name ] = array(
                        'name' => $sub_name, 'pillar_id' => 0, 'pages' => $sub_pages, 'theme' => '',
                    );
                }

                hts_add_log(
                    '✂️ Mega-cluster split : "' . $cname . '" (' . count( $pages ) . ' pages) → ' . $n_sub . ' sous-clusters',
                    'info', 'cocon'
                );
            }
        }

        // ── Phase D2: Navigation rescue — move content-rich pages out of Navigation ──
        // GPT sometimes puts articles with short/generic titles in Navigation.
        // A real nav page has little content. An article has substantial content.
        if ( isset( $clusters['Navigation'] ) && count( $clusters['Navigation']['pages'] ) > 0 && ! empty( $vectors ) ) {
            $nav_rescued = 0;
            $content_cluster_names = array_keys( array_filter( $clusters, function( $c ) {
                return ! in_array( $c['name'] ?? '', array( 'Navigation', 'Non classé', 'Thématiques émergentes' ) );
            } ) );

            $remaining_nav = array();
            foreach ( $clusters['Navigation']['pages'] as $pid ) {
                $post = get_post( $pid );
                $word_count = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;

                // If page has substantial content (>300 words), it's NOT navigation
                if ( $word_count > 300 && isset( $vectors[ $pid ] ) && ! empty( $content_cluster_names ) ) {
                    // Find best cluster by embedding similarity
                    $best_cluster = null;
                    $best_sim = 0;
                    foreach ( $content_cluster_names as $cname ) {
                        $total_sim = 0; $cnt = 0;
                        foreach ( $clusters[ $cname ]['pages'] as $cp ) {
                            if ( isset( $vectors[ $cp ] ) ) {
                                $total_sim += HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $cp ] );
                                $cnt++;
                            }
                        }
                        $avg = $cnt > 0 ? $total_sim / $cnt : 0;
                        if ( $avg > $best_sim ) { $best_sim = $avg; $best_cluster = $cname; }
                    }

                    if ( $best_cluster && $best_sim >= 0.25 ) {
                        $clusters[ $best_cluster ]['pages'][] = $pid;
                        $nav_rescued++;
                        hts_add_log(
                            '🚑 Rescue Navigation : "' . mb_substr( $nodes[ $pid ]['title'] ?? '', 0, 40 )
                            . '" (' . $word_count . ' mots) → "' . $best_cluster . '" (sim=' . round( $best_sim, 2 ) . ')',
                            'info', 'cocon'
                        );
                    } else {
                        $remaining_nav[] = $pid;
                    }
                } else {
                    $remaining_nav[] = $pid;
                }
            }
            $clusters['Navigation']['pages'] = $remaining_nav;
            if ( $nav_rescued > 0 ) {
                hts_add_log( '🚑 ' . $nav_rescued . ' page(s) riche(s) sauvée(s) du cluster Navigation', 'info', 'cocon' );
            }
        }

        // ── Phase E: Embedding validation — reassign misplaced pages ──
        // Use silhouette score to find pages that GPT put in the wrong cluster
        if ( count( $clusters ) >= 2 && ! empty( $vectors ) ) {
            $content_clusters = array_filter( $clusters, function( $cl ) { return ! in_array( $cl['name'] ?? '', array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème' ) ); } );
            if ( count( $content_clusters ) >= 2 ) {
                $get_dist = function( $a, $b ) use ( $vectors ) {
                    if ( ! isset( $vectors[ $a ] ) || ! isset( $vectors[ $b ] ) ) return 1.0;
                    return 1.0 - HTS_Embeddings::cosine_similarity( $vectors[ $a ], $vectors[ $b ] );
                };

                $moved = 0;
                $cluster_names = array_keys( $content_clusters );

                foreach ( $cluster_names as $cname ) {
                    $pages = $clusters[ $cname ]['pages'];
                    if ( count( $pages ) <= 3 ) continue; // Don't steal from small clusters

                    $to_move = array();
                    foreach ( $pages as $pid ) {
                        if ( ! isset( $vectors[ $pid ] ) ) continue;

                        // a(i) = avg distance within same cluster
                        $a_sum = 0; $a_cnt = 0;
                        foreach ( $pages as $other ) {
                            if ( $other === $pid ) continue;
                            $a_sum += $get_dist( $pid, $other );
                            $a_cnt++;
                        }
                        $a = $a_cnt > 0 ? $a_sum / $a_cnt : 0;

                        // b(i) = min avg distance to any other cluster
                        $b = PHP_FLOAT_MAX;
                        $nearest_cluster = null;
                        foreach ( $cluster_names as $other_cname ) {
                            if ( $other_cname === $cname ) continue;
                            $other_pages = $clusters[ $other_cname ]['pages'];
                            $b_sum = 0; $b_cnt = 0;
                            foreach ( $other_pages as $op ) {
                                $b_sum += $get_dist( $pid, $op );
                                $b_cnt++;
                            }
                            $avg_b = $b_cnt > 0 ? $b_sum / $b_cnt : PHP_FLOAT_MAX;
                            if ( $avg_b < $b ) {
                                $b = $avg_b;
                                $nearest_cluster = $other_cname;
                            }
                        }

                        // Silhouette: strongly negative = definitely in wrong cluster
                        $denom = max( $a, $b );
                        $sil = $denom > 0 ? ( $b - $a ) / $denom : 0;

                        if ( $sil < -0.15 && $nearest_cluster ) {
                            $to_move[] = array( 'pid' => $pid, 'target' => $nearest_cluster );
                        }
                    }

                    // Move pages (only if source cluster keeps >= 3 pages)
                    foreach ( $to_move as $mv ) {
                        if ( count( $clusters[ $cname ]['pages'] ) <= 3 ) break;
                        $clusters[ $cname ]['pages'] = array_values( array_diff( $clusters[ $cname ]['pages'], array( $mv['pid'] ) ) );
                        $clusters[ $mv['target'] ]['pages'][] = $mv['pid'];
                        $moved++;
                    }
                }

                if ( $moved > 0 ) {
                    hts_add_log(
                        '🔄 LLM-Guided : ' . $moved . ' page(s) réassignée(s) par validation embedding (silhouette négative)',
                        'info', 'cocon'
                    );
                }
            }
        }

        // ── Phase E2: Outlier detection — pages completely off-topic for their cluster ──
        // A page with avg similarity < 0.30 to ALL its cluster-mates is an outlier
        if ( ! empty( $vectors ) && count( $clusters ) >= 2 ) {
            $outliers = array();
            foreach ( $clusters as $cname => $cl ) {
                if ( in_array( $cl['name'] ?? '', array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème', 'Hors-thème' ) ) ) continue;
                if ( count( $cl['pages'] ) <= 2 ) continue;

                foreach ( $cl['pages'] as $pid ) {
                    if ( ! isset( $vectors[ $pid ] ) ) continue;
                    $total_sim = 0; $cnt = 0;
                    foreach ( $cl['pages'] as $other ) {
                        if ( $other === $pid || ! isset( $vectors[ $other ] ) ) continue;
                        $total_sim += HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $other ] );
                        $cnt++;
                    }
                    $avg_sim = $cnt > 0 ? $total_sim / $cnt : 0;
                    if ( $avg_sim < 0.30 ) {
                        $outliers[] = array( 'pid' => $pid, 'cluster' => $cname, 'avg_sim' => $avg_sim, 'title' => $nodes[ $pid ]['title'] ?? '' );
                    }
                }
            }

            if ( ! empty( $outliers ) ) {
                // Try to find a better cluster for each outlier
                $cluster_names = array_keys( array_filter( $clusters, function( $c ) { return ! in_array( $c['name'] ?? '', array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème' ) ); } ) );
                $off_topic = array();

                foreach ( $outliers as $out ) {
                    $best_cluster = null;
                    $best_sim = 0;
                    foreach ( $cluster_names as $cname ) {
                        if ( $cname === $out['cluster'] ) continue;
                        $total_sim = 0; $cnt = 0;
                        foreach ( $clusters[ $cname ]['pages'] as $cp ) {
                            if ( isset( $vectors[ $cp ] ) ) {
                                $total_sim += HTS_Embeddings::cosine_similarity( $vectors[ $out['pid'] ], $vectors[ $cp ] );
                                $cnt++;
                            }
                        }
                        $avg = $cnt > 0 ? $total_sim / $cnt : 0;
                        if ( $avg > $best_sim ) { $best_sim = $avg; $best_cluster = $cname; }
                    }

                    if ( $best_cluster && $best_sim >= 0.35 && count( $clusters[ $out['cluster'] ]['pages'] ) > 3 ) {
                        // Move to better cluster
                        $clusters[ $out['cluster'] ]['pages'] = array_values( array_diff( $clusters[ $out['cluster'] ]['pages'], array( $out['pid'] ) ) );
                        $clusters[ $best_cluster ]['pages'][] = $out['pid'];
                    } elseif ( $best_sim < 0.30 ) {
                        // Truly off-topic — isolate
                        $off_topic[] = $out;
                        if ( count( $clusters[ $out['cluster'] ]['pages'] ) > 3 ) {
                            $clusters[ $out['cluster'] ]['pages'] = array_values( array_diff( $clusters[ $out['cluster'] ]['pages'], array( $out['pid'] ) ) );
                        }
                    }
                }

                if ( ! empty( $off_topic ) ) {
                    if ( ! isset( $clusters['Thématiques émergentes'] ) ) {
                        $clusters['Thématiques émergentes'] = array( 'name' => 'Thématiques émergentes', 'pillar_id' => 0, 'pages' => array(), 'theme' => 'Pages sur des sujets nouveaux ou en cours de développement. Créez du contenu complémentaire pour renforcer ces thématiques.' );
                    }
                    foreach ( $off_topic as $ot ) {
                        if ( ! in_array( $ot['pid'], $clusters['Thématiques émergentes']['pages'] ) ) {
                            $clusters['Thématiques émergentes']['pages'][] = $ot['pid'];
                        }
                    }
                    hts_add_log(
                        '🆕 ' . count( $off_topic ) . ' page(s) en thématique émergente : ' . implode( ', ', array_map( function( $o ) { return '"' . mb_substr( $o['title'], 0, 35 ) . '"'; }, $off_topic ) ),
                        'info', 'cocon'
                    );
                }

                $reattached = count( $outliers ) - count( $off_topic );
                if ( $reattached > 0 ) {
                    hts_add_log( '🔄 ' . $reattached . ' outlier(s) déplacé(s) vers un cluster plus cohérent', 'info', 'cocon' );
                }
            }
        }

        // ── Phase E3: Non classé rescue — aggressively try to reclassify ──
        // Pages with embeddings should almost NEVER be in "Non classé" on a thematic site
        if ( isset( $clusters['Non classé'] ) && ! empty( $clusters['Non classé']['pages'] ) && ! empty( $vectors ) ) {
            $content_cluster_names = array_keys( array_filter( $clusters, function( $c ) {
                return ! in_array( $c['name'] ?? '', array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème' ) );
            } ) );

            if ( ! empty( $content_cluster_names ) ) {
                $rescued = 0;
                $remaining_nc = array();
                foreach ( $clusters['Non classé']['pages'] as $pid ) {
                    if ( ! isset( $vectors[ $pid ] ) ) {
                        // No embedding → can't classify → keep in Non classé
                        $remaining_nc[] = $pid;
                        continue;
                    }

                    // Block utility pages from rescue
                    $nc_title_lower = mb_strtolower( $nodes[ $pid ]['title'] ?? get_the_title( $pid ) );
                    $nc_is_utility = false;
                    $nc_util_pats = array( 'contact', 'mentions', 'cgv', 'cgu', 'confidential', 'cookies', 'panier', 'cart', 'checkout', 'compte', 'account', 'login', 'inscription', 'plan du site', 'sitemap', 'merci', 'thank', 'confirmation', '404', 'desinscription' );
                    foreach ( $nc_util_pats as $nup ) {
                        if ( mb_strpos( $nc_title_lower, $nup ) !== false ) { $nc_is_utility = true; break; }
                    }
                    if ( $nc_is_utility || ( (int) ( $nodes[ $pid ]['word_count'] ?? 0 ) < 200 && (int) ( $nodes[ $pid ]['word_count'] ?? 0 ) > 0 ) ) {
                        $remaining_nc[] = $pid;
                        continue;
                    }

                    // Find best matching cluster with a more permissive threshold
                    $best_cluster = null;
                    $best_sim = 0;
                    foreach ( $content_cluster_names as $cname ) {
                        $total_sim = 0; $cnt = 0;
                        foreach ( $clusters[ $cname ]['pages'] as $cp ) {
                            if ( isset( $vectors[ $cp ] ) ) {
                                $total_sim += HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $cp ] );
                                $cnt++;
                            }
                        }
                        $avg = $cnt > 0 ? $total_sim / $cnt : 0;
                        if ( $avg > $best_sim ) { $best_sim = $avg; $best_cluster = $cname; }
                    }

                    // Threshold = 0.30 (must have real thematic connection to escape Non classé)
                    if ( $best_cluster && $best_sim >= 0.30 ) {
                        $clusters[ $best_cluster ]['pages'][] = $pid;
                        $rescued++;
                        hts_add_log(
                            '🚑 Non classé rescue : "' . mb_substr( $nodes[ $pid ]['title'] ?? get_the_title( $pid ), 0, 40 )
                            . '" → "' . $best_cluster . '" (sim=' . round( $best_sim, 2 ) . ')',
                            'info', 'cocon'
                        );
                    } else {
                        $remaining_nc[] = $pid;
                    }
                }
                $clusters['Non classé']['pages'] = $remaining_nc;
                if ( $rescued > 0 ) {
                    hts_add_log( '🚑 ' . $rescued . ' page(s) sauvée(s) de Non classé', 'info', 'cocon' );
                }
            }
        }
        // ── Phase F: Compute quality metrics ──
        if ( count( $clusters ) >= 2 && ! empty( $vectors ) ) {
            $get_dist_fn = function( $a, $b ) use ( $vectors ) {
                if ( ! isset( $vectors[ $a ] ) || ! isset( $vectors[ $b ] ) ) return 1.0;
                return 1.0 - HTS_Embeddings::cosine_similarity( $vectors[ $a ], $vectors[ $b ] );
            };
            $content_clusters = array_filter( $clusters, function( $cl ) { return ! in_array( $cl['name'] ?? '', array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème' ) ); } );
            if ( count( $content_clusters ) >= 2 ) {
                $quality = $this->compute_cluster_quality( $content_clusters, $vectors, $get_dist_fn );
                foreach ( $quality['per_cluster'] as $cname => $metrics ) {
                    if ( isset( $clusters[ $cname ] ) ) {
                        $clusters[ $cname ]['silhouette']  = $metrics['silhouette'];
                        $clusters[ $cname ]['coherence']    = $metrics['coherence'];
                        $clusters[ $cname ]['border_pages'] = $metrics['border_pages'];
                    }
                }
                hts_add_log(
                    'LLM-Guided qualité : silhouette=' . round( $quality['avg_silhouette'], 3 )
                    . ' | ' . $quality['total_border_pages'] . ' frontière(s)'
                    . ( $quality['avg_silhouette'] >= 0.25 ? ' ✅' : ( $quality['avg_silhouette'] >= 0.1 ? ' ⚠️' : ' ❌' ) ),
                    'info', 'cocon'
                );
            }
        }

        // Remove empty clusters
        $clusters = array_filter( $clusters, function( $cl ) { return ! empty( $cl['pages'] ); } );

        hts_add_log(
            '🧠 LLM-Guided clustering : ' . count( $clusters ) . ' clusters créés par GPT + validation embeddings'
            . ' (' . count( $assigned_pids ) . '/' . $n_pages . ' pages classées directement par GPT)',
            'success', 'cocon'
        );

        return $clusters;
    }

    /* ── EMBEDDINGS CLUSTERING (fallback) ── */

    /**
     * Cluster pages using semantic embeddings + k-medoids.
     *
     * v2 improvements:
     * - Pre-filters utility pages (forms, privacy, CGV...)
     * - Normalizes distance matrix (min-max) for mono-thematic sites
     * - Detects and re-splits mega-clusters (>50% of pages)
     * - Better k selection for small/large sites
     */
    private function cluster_with_embeddings( $nodes ) {
        $emb = new HTS_Embeddings();
        $vectors = $emb->load_all_vectors();
        $this->cached_vectors = $vectors; // Cache for Phase 5 pillar assignment

        // Only cluster pages that have embeddings
        $embeddable_ids = array_values( array_intersect( array_keys( $nodes ), array_keys( $vectors ) ) );
        $non_embedded   = array_values( array_diff( array_keys( $nodes ), array_keys( $vectors ) ) );

        if ( count( $embeddable_ids ) < 6 ) {
            return ! empty( $this->openai_key ) ? $this->cluster_with_ai( $nodes ) : $this->cluster_with_tfidf( $nodes );
        }

        $n = count( $embeddable_ids );

        // ── Step 1: Compute full distance matrix (1 - cosine_similarity) ──
        $raw_dist = array();
        $all_distances = array(); // flat array for normalization
        for ( $i = 0; $i < $n; $i++ ) {
            for ( $j = $i + 1; $j < $n; $j++ ) {
                $a = $embeddable_ids[ $i ];
                $b = $embeddable_ids[ $j ];
                $cos = HTS_Embeddings::cosine_similarity( $vectors[ $a ], $vectors[ $b ] );

                // Boost: reduce distance if linked or same category
                if ( in_array( $b, $nodes[ $a ]['outgoing'] ) || in_array( $a, $nodes[ $b ]['outgoing'] ) ) {
                    $cos = min( 1.0, $cos + 0.05 );
                }
                $shared_cats = count( array_intersect( $nodes[ $a ]['categories'] ?? array(), $nodes[ $b ]['categories'] ?? array() ) );
                if ( $shared_cats > 0 ) $cos = min( 1.0, $cos + 0.03 * $shared_cats );

                // Boost: shared tags indicate topical affinity
                $shared_tags = count( array_intersect( $nodes[ $a ]['tags'] ?? array(), $nodes[ $b ]['tags'] ?? array() ) );
                if ( $shared_tags > 0 ) $cos = min( 1.0, $cos + 0.02 * $shared_tags );

                // Boost: shared TF-IDF keywords (strong topical signal)
                $shared_kw = count( array_intersect( $nodes[ $a ]['keywords'] ?? array(), $nodes[ $b ]['keywords'] ?? array() ) );
                if ( $shared_kw >= 3 ) $cos = min( 1.0, $cos + 0.02 * min( $shared_kw, 5 ) );

                $d = max( 0, 1.0 - $cos );
                $raw_dist[ "{$a}:{$b}" ] = $d;
                $raw_dist[ "{$b}:{$a}" ] = $d;
                $all_distances[] = $d;
            }
        }

        // ── Step 1b: Normalize distances (min-max) for mono-thematic sites ──
        // This makes small differences significant when all content is similar
        $d_min = ! empty( $all_distances ) ? min( $all_distances ) : 0;
        $d_max = ! empty( $all_distances ) ? max( $all_distances ) : 1;
        $d_range = $d_max - $d_min;
        $avg_dist = ! empty( $all_distances ) ? array_sum( $all_distances ) / count( $all_distances ) : 0.5;

        // Only normalize if the range is very compressed (mono-thematic site)
        $is_mono_thematic = ( $d_range < 0.3 && $avg_dist < 0.25 );

        $dist = array();
        foreach ( $raw_dist as $key => $d ) {
            if ( $is_mono_thematic && $d_range > 0.001 ) {
                // Normalize to 0-1 range so relative differences become significant
                $dist[ $key ] = ( $d - $d_min ) / $d_range;
            } else {
                $dist[ $key ] = $d;
            }
        }

        // Log diagnostic info
        hts_add_log(
            '🧠 Distances: min=' . round( $d_min, 4 ) . ' max=' . round( $d_max, 4 )
            . ' avg=' . round( $avg_dist, 4 ) . ' range=' . round( $d_range, 4 )
            . ( $is_mono_thematic ? ' → MONO-THÉMATIQUE (normalisation activée)' : '' ),
            'info', 'embeddings'
        );

        // Helper to get distance between two IDs
        $get_dist = function( $a, $b ) use ( $dist ) {
            if ( $a === $b ) return 0;
            return $dist[ "{$a}:{$b}" ] ?? 0.999;
        };

        // ── Step 2: Choose k ──
        // Mono-thematic sites need MORE clusters to find sub-topics
        if ( $is_mono_thematic ) {
            $k = max( 5, min( 10, (int) round( sqrt( $n / 1.5 ) ) ) );
        } else {
            $k = max( 4, min( 8, (int) round( sqrt( $n / 2.5 ) ) ) );
        }
        $k = min( $k, (int) floor( $n / 2 ) ); // At least 2 pages per cluster average

        // ── Step 3: K-medoids++ initialization ──
        // Pick first medoid = page with highest pillar_score
        $sorted_by_pillar = $embeddable_ids;
        usort( $sorted_by_pillar, function( $a, $b ) use ( $nodes ) {
            return ( $nodes[ $b ]['pillar_score'] ?? 0 ) <=> ( $nodes[ $a ]['pillar_score'] ?? 0 );
        } );
        $medoids = array( $sorted_by_pillar[0] );

        // Pick remaining medoids: maximize distance from existing medoids (k-means++ style)
        for ( $m = 1; $m < $k; $m++ ) {
            $best_id = null;
            $best_min_dist = -1;
            foreach ( $embeddable_ids as $cand ) {
                if ( in_array( $cand, $medoids ) ) continue;
                // Min distance to any existing medoid
                $min_d = PHP_FLOAT_MAX;
                foreach ( $medoids as $med ) {
                    $d = $get_dist( $cand, $med );
                    if ( $d < $min_d ) $min_d = $d;
                }
                if ( $min_d > $best_min_dist ) {
                    $best_min_dist = $min_d;
                    $best_id = $cand;
                }
            }
            if ( $best_id !== null ) $medoids[] = $best_id;
        }

        // ── Step 4: K-medoids iterations ──
        $max_iterations = 15;
        $assignments = array();

        for ( $iter = 0; $iter < $max_iterations; $iter++ ) {
            $changed = false;

            // Assign each page to nearest medoid
            $new_assignments = array();
            foreach ( $embeddable_ids as $pid ) {
                $best_med = $medoids[0];
                $best_d = $get_dist( $pid, $medoids[0] );
                for ( $m = 1; $m < count( $medoids ); $m++ ) {
                    $d = $get_dist( $pid, $medoids[ $m ] );
                    if ( $d < $best_d ) { $best_d = $d; $best_med = $medoids[ $m ]; }
                }
                $new_assignments[ $pid ] = $best_med;
            }

            if ( $new_assignments !== $assignments ) $changed = true;
            $assignments = $new_assignments;

            if ( ! $changed && $iter > 0 ) break;

            // Try swapping each medoid with each non-medoid in its cluster
            $improved = false;
            foreach ( $medoids as $mi => $current_med ) {
                // Get cluster members
                $members = array_keys( array_filter( $assignments, function( $med ) use ( $current_med ) { return $med === $current_med; } ) );
                if ( count( $members ) < 2 ) continue;

                // Current total distance for this cluster
                $current_total = 0;
                foreach ( $members as $pid ) $current_total += $get_dist( $pid, $current_med );

                // Try each member as new medoid
                foreach ( $members as $candidate ) {
                    if ( $candidate === $current_med ) continue;
                    $new_total = 0;
                    foreach ( $members as $pid ) $new_total += $get_dist( $pid, $candidate );
                    if ( $new_total < $current_total ) {
                        $medoids[ $mi ] = $candidate;
                        $current_med = $candidate;
                        $current_total = $new_total;
                        $improved = true;
                    }
                }
            }

            if ( ! $improved && ! $changed ) break;
        }

        // ── Step 5: Build groups from assignments ──
        $groups = array();
        foreach ( $assignments as $pid => $med ) {
            $groups[ $med ][] = $pid;
        }

        // Merge tiny clusters (1 page) into nearest larger cluster
        $real_groups = array();
        $tiny_pages  = array();
        foreach ( $groups as $med => $pids ) {
            if ( count( $pids ) >= 2 ) {
                $real_groups[ $med ] = $pids;
            } else {
                $tiny_pages = array_merge( $tiny_pages, $pids );
            }
        }

        // Assign tiny pages to nearest real cluster
        foreach ( $tiny_pages as $pid ) {
            $best_med = null;
            $best_d   = PHP_FLOAT_MAX;
            foreach ( array_keys( $real_groups ) as $med ) {
                $d = $get_dist( $pid, $med );
                if ( $d < $best_d ) { $best_d = $d; $best_med = $med; }
            }
            if ( $best_med !== null ) {
                $real_groups[ $best_med ][] = $pid;
            } else {
                $non_embedded[] = $pid;
            }
        }

        // ── Step 5b: Re-split mega-clusters ──
        // If any cluster has > 25% of pages or > 12 pages absolute, recursively split it
        $final_groups = array();
        foreach ( $real_groups as $med => $pids ) {
            if ( count( $pids ) > ( $n * 0.25 ) || count( $pids ) > 12 ) {
                // This cluster is too big — re-split with k-medoids on its members
                $sub_groups = $this->resplit_mega_cluster( $pids, $dist, $get_dist );
                foreach ( $sub_groups as $sg ) {
                    $final_groups[] = $sg;
                }
                hts_add_log(
                    '🧠 Mega-cluster (' . count( $pids ) . ' pages) re-splitté en ' . count( $sub_groups ) . ' sous-groupes',
                    'info', 'embeddings'
                );
            } else {
                $final_groups[] = $pids;
            }
        }

        // ── Step 5c: Merge micro-clusters (< 3 pages) into nearest cluster ──
        if ( count( $final_groups ) > 1 ) {
            $merged = true;
            while ( $merged ) {
                $merged = false;
                $big_groups   = array();
                $micro_groups = array();
                foreach ( $final_groups as $idx => $pids ) {
                    if ( count( $pids ) < 3 ) {
                        $micro_groups[ $idx ] = $pids;
                    } else {
                        $big_groups[ $idx ] = $pids;
                    }
                }
                if ( empty( $micro_groups ) || empty( $big_groups ) ) break;

                foreach ( $micro_groups as $mi => $micro_pids ) {
                    // Find nearest big group by average distance
                    $best_idx = null;
                    $best_avg = PHP_FLOAT_MAX;
                    foreach ( $big_groups as $bi => $big_pids ) {
                        $total_d = 0; $cnt = 0;
                        foreach ( $micro_pids as $mp ) {
                            foreach ( $big_pids as $bp ) {
                                $total_d += $get_dist( $mp, $bp );
                                $cnt++;
                            }
                        }
                        $avg_d = $cnt > 0 ? $total_d / $cnt : PHP_FLOAT_MAX;
                        if ( $avg_d < $best_avg ) {
                            $best_avg = $avg_d;
                            $best_idx = $bi;
                        }
                    }
                    if ( $best_idx !== null ) {
                        $final_groups[ $best_idx ] = array_merge( $final_groups[ $best_idx ], $micro_pids );
                        unset( $final_groups[ $mi ] );
                        $merged = true;
                        hts_add_log(
                            '🧠 Micro-cluster (' . count( $micro_pids ) . ' pages) fusionné dans groupe voisin',
                            'info', 'embeddings'
                        );
                    }
                }
                $final_groups = array_values( $final_groups );
            }
        }

        // ── Step 6: Name clusters with AI (or keywords fallback) ──
        $clusters = array();

        if ( ! empty( $this->openai_key ) && count( $final_groups ) >= 1 ) {
            $clusters = $this->name_clusters_with_ai( $final_groups, $nodes );
        }

        // Ensure ALL groups have a name (AI might miss some)
        if ( count( $clusters ) < count( $final_groups ) ) {
            $assigned_pids = array();
            foreach ( $clusters as $cl ) {
                foreach ( $cl['pages'] as $pid ) $assigned_pids[ $pid ] = true;
            }
            foreach ( $final_groups as $pids ) {
                // Check if this group is already covered
                $covered = false;
                foreach ( $pids as $pid ) {
                    if ( isset( $assigned_pids[ $pid ] ) ) { $covered = true; break; }
                }
                if ( $covered ) continue;

                // Name with keywords
                $akw = array();
                foreach ( $pids as $pid ) {
                    if ( ! isset( $nodes[ $pid ] ) ) continue;
                    foreach ( $nodes[ $pid ]['keywords'] as $kw ) {
                        $akw[ $kw ] = ( $akw[ $kw ] ?? 0 ) + 1;
                    }
                }
                arsort( $akw );
                $name = ucfirst( implode( ' + ', array_slice( array_keys( $akw ), 0, 3 ) ) );
                if ( isset( $clusters[ $name ] ) ) $name .= ' (' . count( $pids ) . ')';
                $clusters[ $name ] = array(
                    'name' => $name, 'pillar_id' => 0,
                    'pages' => $pids, 'theme' => 'Cluster par similarité sémantique',
                );
            }
        }

        // Non-embedded pages go to "Non classé"
        if ( ! empty( $non_embedded ) ) {
            if ( isset( $clusters['Non classé'] ) ) {
                $clusters['Non classé']['pages'] = array_merge( $clusters['Non classé']['pages'], $non_embedded );
            } else {
                $clusters['Non classé'] = array(
                    'name' => 'Non classé', 'pillar_id' => 0,
                    'pages' => array_values( array_unique( $non_embedded ) ),
                    'theme' => ( $this->analysis_lang === 'fr' ? 'Articles isolés' : 'Isolated articles' ),
                );
            }
        }

        hts_add_log(
            '🧠 Cocon : clustering sémantique (k-medoids, k=' . $k . ') — '
            . count( $final_groups ) . ' cluster(s) contenu, ' . count( $non_embedded ) . ' non classé(s)',
            'success', 'embeddings'
        );

        // ── Step 7: Compute cluster quality metrics ──
        $content_clusters = array_filter( $clusters, function( $cl ) { return ! in_array( $cl['name'] ?? '', array( 'Non classé', 'Thématiques émergentes', 'Navigation', 'Hors-thème' ) ); } );
        if ( count( $content_clusters ) >= 2 ) {
            $quality = $this->compute_cluster_quality( $content_clusters, $vectors, $get_dist );
            foreach ( $quality['per_cluster'] as $cname => $metrics ) {
                if ( isset( $clusters[ $cname ] ) ) {
                    $clusters[ $cname ]['silhouette']   = $metrics['silhouette'];
                    $clusters[ $cname ]['coherence']     = $metrics['coherence'];
                    $clusters[ $cname ]['border_pages']  = $metrics['border_pages'];
                }
            }
            hts_add_log(
                'Qualité clustering : silhouette=' . round( $quality['avg_silhouette'], 3 )
                . ' | ' . $quality['total_border_pages'] . ' page(s) frontière(s)'
                . ( $quality['avg_silhouette'] >= 0.3 ? ' bon' : ( $quality['avg_silhouette'] >= 0.15 ? ' moyen' : ' faible' ) ),
                'info', 'embeddings'
            );

            // ── Step 7b: Auto-reassign misplaced pages (negative silhouette) ──
            $moved = 0;
            foreach ( $quality['per_cluster'] as $cname => $metrics ) {
                if ( empty( $metrics['border_pages'] ) || ! isset( $clusters[ $cname ] ) ) continue;
                foreach ( $metrics['border_pages'] as $bp ) {
                    // Only move pages with negative silhouette (clearly wrong cluster)
                    if ( $bp['silhouette'] >= 0 ) continue;
                    $target_cluster = $bp['nearest'];
                    if ( ! isset( $clusters[ $target_cluster ] ) ) continue;

                    // Don't move if source cluster would become too small
                    if ( count( $clusters[ $cname ]['pages'] ) <= 3 ) continue;

                    // Move page
                    $clusters[ $cname ]['pages'] = array_values( array_diff( $clusters[ $cname ]['pages'], array( $bp['pid'] ) ) );
                    $clusters[ $target_cluster ]['pages'][] = $bp['pid'];
                    $moved++;
                }
            }
            if ( $moved > 0 ) {
                hts_add_log(
                    '🔄 ' . $moved . ' page(s) réassignée(s) au cluster le plus cohérent (silhouette négative)',
                    'info', 'embeddings'
                );
            }
        }

        return $clusters;
    }

    /**
     * Compute cluster quality metrics:
     * - Silhouette score per page (how well it fits its cluster vs nearest other)
     * - Coherence (avg intra-cluster similarity)
     * - Border pages (pages closer to another cluster's centroid)
     */
    private function compute_cluster_quality( $clusters, $vectors, $get_dist ) {
        $result = array( 'per_cluster' => array(), 'avg_silhouette' => 0, 'total_border_pages' => 0 );

        // Build cluster centroids (in embedding space)
        $centroids = array();
        $cluster_pages = array();
        foreach ( $clusters as $cname => $cl ) {
            $cluster_pages[ $cname ] = $cl['pages'];
            $vecs = array();
            foreach ( $cl['pages'] as $pid ) {
                if ( isset( $vectors[ $pid ] ) ) $vecs[] = $vectors[ $pid ];
            }
            if ( ! empty( $vecs ) ) {
                $dim = count( $vecs[0] );
                $centroid = array_fill( 0, $dim, 0.0 );
                foreach ( $vecs as $v ) {
                    for ( $d = 0; $d < $dim; $d++ ) $centroid[ $d ] += $v[ $d ];
                }
                $cnt = count( $vecs );
                for ( $d = 0; $d < $dim; $d++ ) $centroid[ $d ] /= $cnt;
                $centroids[ $cname ] = $centroid;
            }
        }

        $all_silhouettes = array();
        $cluster_names = array_keys( $clusters );

        foreach ( $clusters as $cname => $cl ) {
            $sil_scores = array();
            $intra_dists = array();
            $border_pages = array();
            $pages = $cl['pages'];

            foreach ( $pages as $pid ) {
                if ( ! isset( $vectors[ $pid ] ) ) continue;

                // a(i) = average distance to same cluster
                $a_sum = 0; $a_cnt = 0;
                foreach ( $pages as $other ) {
                    if ( $other === $pid ) continue;
                    $a_sum += $get_dist( $pid, $other );
                    $a_cnt++;
                }
                $a = $a_cnt > 0 ? $a_sum / $a_cnt : 0;
                $intra_dists[] = $a;

                // b(i) = minimum average distance to any OTHER cluster
                $b = PHP_FLOAT_MAX;
                $nearest_cluster = $cname;
                foreach ( $cluster_names as $other_cname ) {
                    if ( $other_cname === $cname ) continue;
                    $other_pages = $cluster_pages[ $other_cname ];
                    $b_sum = 0; $b_cnt = 0;
                    foreach ( $other_pages as $op ) {
                        $b_sum += $get_dist( $pid, $op );
                        $b_cnt++;
                    }
                    $avg_b = $b_cnt > 0 ? $b_sum / $b_cnt : PHP_FLOAT_MAX;
                    if ( $avg_b < $b ) {
                        $b = $avg_b;
                        $nearest_cluster = $other_cname;
                    }
                }

                // Silhouette: (b - a) / max(a, b)
                $denom = max( $a, $b );
                $sil = $denom > 0 ? ( $b - $a ) / $denom : 0;
                $sil_scores[] = $sil;
                $all_silhouettes[] = $sil;

                // Border page: silhouette < 0.1 = ambiguous
                if ( $sil < 0.1 && $nearest_cluster !== $cname ) {
                    $border_pages[] = array( 'pid' => $pid, 'silhouette' => round( $sil, 3 ), 'nearest' => $nearest_cluster );
                }
            }

            $avg_sil = ! empty( $sil_scores ) ? array_sum( $sil_scores ) / count( $sil_scores ) : 0;
            $avg_intra = ! empty( $intra_dists ) ? array_sum( $intra_dists ) / count( $intra_dists ) : 0;
            $coherence = max( 0, 1 - $avg_intra ); // 0-1 scale, 1 = perfectly coherent

            $result['per_cluster'][ $cname ] = array(
                'silhouette'   => round( $avg_sil, 3 ),
                'coherence'    => round( $coherence, 3 ),
                'border_pages' => $border_pages,
            );
            $result['total_border_pages'] += count( $border_pages );
        }

        $result['avg_silhouette'] = ! empty( $all_silhouettes ) ? array_sum( $all_silhouettes ) / count( $all_silhouettes ) : 0;
        return $result;
    }

    /**
     * Re-split a mega-cluster into sub-groups using k-medoids on its members.
     */
    private function resplit_mega_cluster( $pids, $dist, $get_dist ) {
        $n = count( $pids );
        // Target: sqrt(n/2) sub-clusters, min 3, max 8
        $sub_k = max( 3, min( 8, (int) round( sqrt( $n / 2 ) ) ) );
        $sub_k = min( $sub_k, (int) floor( $n / 3 ) );

        // K-medoids++ init: pick first = random (index 0), rest = max distance
        $medoids = array( $pids[0] );
        for ( $m = 1; $m < $sub_k; $m++ ) {
            $best_id = null;
            $best_min_dist = -1;
            foreach ( $pids as $cand ) {
                if ( in_array( $cand, $medoids ) ) continue;
                $min_d = PHP_FLOAT_MAX;
                foreach ( $medoids as $med ) {
                    $d = $get_dist( $cand, $med );
                    if ( $d < $min_d ) $min_d = $d;
                }
                if ( $min_d > $best_min_dist ) {
                    $best_min_dist = $min_d;
                    $best_id = $cand;
                }
            }
            if ( $best_id !== null ) $medoids[] = $best_id;
        }

        // Iterate
        $assignments = array();
        for ( $iter = 0; $iter < 10; $iter++ ) {
            $new_assignments = array();
            foreach ( $pids as $pid ) {
                $best_med = $medoids[0];
                $best_d = $get_dist( $pid, $medoids[0] );
                for ( $m = 1; $m < count( $medoids ); $m++ ) {
                    $d = $get_dist( $pid, $medoids[ $m ] );
                    if ( $d < $best_d ) { $best_d = $d; $best_med = $medoids[ $m ]; }
                }
                $new_assignments[ $pid ] = $best_med;
            }

            if ( $new_assignments === $assignments ) break;
            $assignments = $new_assignments;

            // Swap step
            $improved = false;
            foreach ( $medoids as $mi => $current_med ) {
                $members = array_keys( array_filter( $assignments, function( $med ) use ( $current_med ) { return $med === $current_med; } ) );
                if ( count( $members ) < 2 ) continue;
                $current_total = 0;
                foreach ( $members as $pid ) $current_total += $get_dist( $pid, $current_med );
                foreach ( $members as $candidate ) {
                    if ( $candidate === $current_med ) continue;
                    $new_total = 0;
                    foreach ( $members as $pid ) $new_total += $get_dist( $pid, $candidate );
                    if ( $new_total < $current_total ) {
                        $medoids[ $mi ] = $candidate;
                        $current_med = $candidate;
                        $current_total = $new_total;
                        $improved = true;
                    }
                }
            }
            if ( ! $improved ) break;
        }

        // Build sub-groups
        $sub_groups = array();
        foreach ( $assignments as $pid => $med ) {
            $sub_groups[ $med ][] = $pid;
        }

        // Merge singletons into nearest group
        $result = array();
        $orphans = array();
        foreach ( $sub_groups as $med => $spids ) {
            if ( count( $spids ) >= 2 ) {
                $result[] = $spids;
            } else {
                $orphans = array_merge( $orphans, $spids );
            }
        }
        foreach ( $orphans as $pid ) {
            $best_idx = 0;
            $best_d = PHP_FLOAT_MAX;
            foreach ( $result as $idx => $grp ) {
                foreach ( $grp as $gpid ) {
                    $d = $get_dist( $pid, $gpid );
                    if ( $d < $best_d ) { $best_d = $d; $best_idx = $idx; }
                }
            }
            if ( ! empty( $result ) ) $result[ $best_idx ][] = $pid;
        }

        return ! empty( $result ) ? $result : array( $pids );
    }

    /**
     * Use AI to name semantic clusters (post-embeddings grouping).
     * Ensures robust mapping: AI gets group_index, we verify all groups are covered.
     */
    private function name_clusters_with_ai( $groups, $nodes ) {
        $desc = '';
        foreach ( $groups as $idx => $pids ) {
            $desc .= "GROUPE " . $idx . " (" . count( $pids ) . " pages) :\n";
            foreach ( array_slice( $pids, 0, 12 ) as $pid ) {
                if ( ! isset( $nodes[ $pid ] ) ) continue;
                $kw = implode( ', ', array_slice( $nodes[ $pid ]['keywords'], 0, 5 ) );
                $desc .= "  ID:{$nodes[$pid]['id']} \"{$nodes[$pid]['title']}\" (kw: {$kw})\n";
            }
            if ( count( $pids ) > 12 ) $desc .= "  ... et " . ( count( $pids ) - 12 ) . " autres\n";
            $desc .= "\n";
        }

        $prompt = "Tu es un expert SEO spécialisé en cocons sémantiques.

Voici " . count( $groups ) . " groupes d'articles, déjà regroupés par proximité sémantique (embeddings vectoriels).
Ces groupes proviennent d'un même site — il est NORMAL qu'ils soient thématiquement proches.
Ta mission est de trouver le SOUS-THÈME SPÉCIFIQUE qui distingue chaque groupe des autres.

{$desc}

Pour CHAQUE groupe (il y en a " . count( $groups ) . "), donne :
1. Un NOM DE CLUSTER SEO court et SPÉCIFIQUE (3-5 mots).
   Chaque nom DOIT être UNIQUE et DIFFÉRENT des autres.
   Ne donne PAS un nom générique qui décrirait tout le site.
   Trouve l'ANGLE SPÉCIFIQUE de chaque groupe (ex: \"Dosage et protocoles\", \"Retraites et cérémonies\", \"Effets thérapeutiques\", \"Législation et risques\")
2. Le ID de la PAGE PILIER (la plus complète/générale du groupe)
3. Un thème en une phrase

Tu DOIS retourner exactement " . count( $groups ) . " clusters, un par groupe.

Identifie aussi 2-3 SUJETS MANQUANTS que le site devrait couvrir.

JSON STRICT :
{
  \"clusters\": [
    { \"group_index\": 0, \"name\": \"Nom SPÉCIFIQUE unique\", \"pillar_id\": 123, \"theme\": \"Description\" },
    { \"group_index\": 1, \"name\": \"...\", \"pillar_id\": 456, \"theme\": \"...\" }
  ],
  \"missing_clusters\": [
    { \"name\": \"Sujet manquant\", \"reason\": \"Pourquoi\", \"suggested_pillar_title\": \"Titre suggéré\" }
  ]
}";

        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 90,
            'headers' => array( 'Authorization' => 'Bearer ' . $this->openai_key, 'Content-Type' => 'application/json' ),
            'body' => wp_json_encode( array(
                'model' => 'gpt-4.1',
                'messages' => array(
                    array( 'role' => 'system', 'content' => 'Réponds UNIQUEMENT en JSON valide, sans markdown ni backticks. Tu DOIS fournir un cluster pour chaque group_index.' ),
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'temperature' => 0.2,
                'max_tokens' => 3500,
            ) ),
        ) );

        if ( is_wp_error( $resp ) ) return array();

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $tk = (int) ( $body['usage']['total_tokens'] ?? 0 );
        if ( $tk > 0 ) {
            $usage = get_option( 'hts_openai_usage', array() );
            $mk = wp_date( 'Y-m' );
            $usage[ $mk ] = ( (int) ( $usage[ $mk ] ?? 0 ) ) + $tk;
            update_option( 'hts_openai_usage', $usage, false );
        }

        $txt = $body['choices'][0]['message']['content'] ?? '';
        $txt = preg_replace( '/^```json\s*/', '', trim( $txt ) );
        $txt = preg_replace( '/\s*```$/', '', $txt );
        $res = json_decode( $txt, true );

        if ( ! $res || empty( $res['clusters'] ) ) return array();

        if ( ! empty( $res['missing_clusters'] ) ) {
            update_option( 'hts_cocon_missing_clusters', $res['missing_clusters'], false );
        }

        $clusters = array();
        foreach ( $res['clusters'] as $c ) {
            $gi = (int) ( $c['group_index'] ?? -1 );
            if ( ! isset( $groups[ $gi ] ) ) continue;
            $name = sanitize_text_field( $c['name'] ?? 'Cluster ' . ( $gi + 1 ) );
            $pids = $groups[ $gi ];
            $pil  = absint( $c['pillar_id'] ?? 0 );
            // Ensure unique cluster names
            if ( isset( $clusters[ $name ] ) ) $name .= ' ' . ( $gi + 1 );
            $clusters[ $name ] = array(
                'name' => $name,
                'pillar_id' => ( $pil && isset( $nodes[ $pil ] ) ) ? $pil : 0,
                'pages' => $pids,
                'theme' => sanitize_text_field( $c['theme'] ?? ( $this->analysis_lang === 'fr' ? 'Cluster sémantique' : 'Semantic cluster' ) ),
            );
        }

        return $clusters;
    }

    /* ── AI CLUSTERING ── */

    private function cluster_with_ai( $nodes ) {
        $monthly_limit = (int) get_option( 'hts_openai_monthly_limit', 1000000 );
        $usage = get_option( 'hts_openai_usage', array() );
        $mk = wp_date( 'Y-m' );
        $cu = (int) ( $usage[ $mk ] ?? 0 );
        if ( $monthly_limit > 0 && $cu >= $monthly_limit ) return $this->cluster_with_tfidf( $nodes );

        $batch = array_slice( $nodes, 0, 80, true );
        $is_fr_ai = ( $this->analysis_lang === 'fr' );
        $at = '';
        foreach ( $batch as $n ) {
            $kw = implode( ', ', array_slice( $n['keywords'], 0, 6 ) );
            $kw_label = $is_fr_ai ? 'Mots-clés' : 'Keywords';
            $at .= "ID:{$n['id']} | \"{$n['title']}\" | {$kw_label}: {$kw} | {$n['word_count']}w | {$n['in_count']} " . ( $is_fr_ai ? 'liens entrants' : 'inbound links' ) . "\n";
        }

        $nc_label_ai = $is_fr_ai ? 'Non classé' : 'Unclassified';
        if ( $is_fr_ai ) {
            $prompt = "Tu es un expert en architecture SEO et cocon sémantique.

═══ ARTICLES DU SITE (" . count( $batch ) . ") ═══
{$at}

═══ MISSION ═══
Regroupe ces articles en CLUSTERS SÉMANTIQUES basés sur leur THÈME RÉEL.

Règles :
1. NE PAS regrouper par catégorie WP. Analyse les sujets réels.
2. Chaque cluster = 2+ articles sur un même sous-thème
3. Nomme chaque cluster EN FRANÇAIS clairement (3-5 mots)
4. Identifie la page PILIER de chaque cluster (article le plus complet/général)
5. Articles sans cluster → \"{$nc_label_ai}\"
6. Identifie les SUJETS MANQUANTS que le site devrait couvrir

═══ FORMAT JSON STRICT ═══
{
  \"clusters\": [
    { \"name\": \"Nom cluster\", \"pillar_id\": 123, \"page_ids\": [123,456,789], \"theme\": \"Description courte\" }
  ],
  \"missing_clusters\": [
    { \"name\": \"Sujet manquant\", \"reason\": \"Pourquoi\", \"suggested_pillar_title\": \"Titre suggéré\" }
  ]
}";
        } else {
            $prompt = "You are an expert in SEO architecture and content silos.

═══ SITE ARTICLES (" . count( $batch ) . ") ═══
{$at}

═══ MISSION ═══
Group these articles into SEMANTIC CLUSTERS based on their ACTUAL TOPIC.

Rules:
1. DO NOT group by WP category. Analyze actual subjects.
2. Each cluster = 2+ articles on the same sub-topic
3. Name each cluster IN ENGLISH clearly (3-5 words)
4. Identify the PILLAR page of each cluster (most comprehensive/general article)
5. Articles without a cluster → \"{$nc_label_ai}\"
6. Identify MISSING TOPICS the site should cover

═══ STRICT JSON FORMAT ═══
{
  \"clusters\": [
    { \"name\": \"Cluster name\", \"pillar_id\": 123, \"page_ids\": [123,456,789], \"theme\": \"Short description\" }
  ],
  \"missing_clusters\": [
    { \"name\": \"Missing topic\", \"reason\": \"Why\", \"suggested_pillar_title\": \"Suggested title\" }
  ]
}";
        }

        $sys_ai = $is_fr_ai ? 'Réponds UNIQUEMENT en JSON valide, sans markdown.' : 'Respond ONLY in valid JSON, no markdown.';

        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 90,
            'headers' => array( 'Authorization' => 'Bearer ' . $this->openai_key, 'Content-Type' => 'application/json' ),
            'body' => wp_json_encode( array(
                'model' => 'gpt-4.1',
                'messages' => array(
                    array( 'role' => 'system', 'content' => $sys_ai ),
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'temperature' => 0.3,
                'max_tokens' => 3000,
            ) ),
        ) );

        if ( is_wp_error( $resp ) ) return $this->cluster_with_tfidf( $nodes );

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $tk = (int) ( $body['usage']['total_tokens'] ?? 0 );
        if ( $tk > 0 ) { $usage[ $mk ] = $cu + $tk; update_option( 'hts_openai_usage', $usage, false ); }

        $txt = $body['choices'][0]['message']['content'] ?? '';
        $txt = preg_replace( '/^```json\s*/', '', trim( $txt ) );
        $txt = preg_replace( '/\s*```$/', '', $txt );
        $res = json_decode( $txt, true );

        if ( ! $res || empty( $res['clusters'] ) ) return $this->cluster_with_tfidf( $nodes );

        if ( ! empty( $res['missing_clusters'] ) ) {
            update_option( 'hts_cocon_missing_clusters', $res['missing_clusters'], false );
        }

        $clusters = array();
        $assigned = array();
        foreach ( $res['clusters'] as $c ) {
            $name = sanitize_text_field( $c['name'] ?? 'Sans nom' );
            $pids = array_filter( array_map( 'absint', $c['page_ids'] ?? array() ), function( $id ) use ( $nodes ) { return isset( $nodes[ $id ] ); } );
            if ( count( $pids ) < 1 ) continue;
            $pil = absint( $c['pillar_id'] ?? 0 );
            $clusters[ $name ] = array(
                'name' => $name, 'pillar_id' => ( $pil && isset( $nodes[ $pil ] ) ) ? $pil : 0,
                'pages' => array_values( $pids ), 'theme' => sanitize_text_field( $c['theme'] ?? '' ),
            );
            foreach ( $pids as $id ) { $assigned[ $id ] = true; }
        }

        $unassigned = array_keys( array_diff_key( $nodes, $assigned ) );
        if ( ! empty( $unassigned ) ) {
            $clusters['Non classé'] = array( 'name' => 'Non classé', 'pillar_id' => 0, 'pages' => $unassigned, 'theme' => 'Articles non rattachés' );
        }
        return $clusters;
    }

    /* ── TF-IDF CLUSTERING (fallback) ── */

    private function cluster_with_tfidf( $nodes ) {
        if ( count( $nodes ) < 3 ) {
            $ids = array_keys( $nodes );
            return array( 'Tous les articles' => array( 'name' => 'Tous les articles', 'pillar_id' => $ids[0] ?? 0, 'pages' => $ids, 'theme' => '' ) );
        }

        $ids = array_keys( $nodes );
        $similarity = array();
        for ( $i = 0; $i < count( $ids ); $i++ ) {
            for ( $j = $i + 1; $j < count( $ids ); $j++ ) {
                $a = $ids[ $i ]; $b = $ids[ $j ];
                $sim = $this->keyword_similarity( $nodes[ $a ]['keywords'], $nodes[ $b ]['keywords'] );
                $sim += count( array_intersect( $nodes[ $a ]['categories'], $nodes[ $b ]['categories'] ) ) * 0.15;
                $sim += count( array_intersect( $nodes[ $a ]['tags'], $nodes[ $b ]['tags'] ) ) * 0.1;
                if ( in_array( $b, $nodes[ $a ]['outgoing'] ) || in_array( $a, $nodes[ $b ]['outgoing'] ) ) $sim += 0.2;
                $similarity[] = array( 'a' => $a, 'b' => $b, 'sim' => $sim );
            }
        }
        usort( $similarity, function( $x, $y ) { return $y['sim'] <=> $x['sim']; } );

        $cmap = array(); $cc = 0;
        foreach ( $similarity as $p ) {
            if ( $p['sim'] < 0.15 ) break;
            $ca = $cmap[ $p['a'] ] ?? null; $cb = $cmap[ $p['b'] ] ?? null;
            if ( $ca === null && $cb === null ) { $cmap[ $p['a'] ] = $cc; $cmap[ $p['b'] ] = $cc; $cc++; }
            elseif ( $ca !== null && $cb === null ) { $cmap[ $p['b'] ] = $ca; }
            elseif ( $ca === null && $cb !== null ) { $cmap[ $p['a'] ] = $cb; }
            elseif ( $ca !== $cb ) { $t = min( $ca, $cb ); $s = max( $ca, $cb ); foreach ( $cmap as &$v ) { if ( $v === $s ) $v = $t; } unset( $v ); }
        }

        $groups = array();
        foreach ( $ids as $id ) { $c = $cmap[ $id ] ?? 'o_' . $id; $groups[ $c ][] = $id; }

        $clusters = array(); $singles = array();
        foreach ( $groups as $pids ) {
            if ( count( $pids ) < 2 ) { $singles = array_merge( $singles, $pids ); continue; }
            $akw = array();
            foreach ( $pids as $pid ) { foreach ( $nodes[ $pid ]['keywords'] as $kw ) { $akw[ $kw ] = ( $akw[ $kw ] ?? 0 ) + 1; } }
            arsort( $akw );
            $name = ucfirst( implode( ' + ', array_slice( array_keys( $akw ), 0, 3 ) ) );
            $clusters[ $name ] = array( 'name' => $name, 'pillar_id' => 0, 'pages' => $pids, 'theme' => ( $this->analysis_lang === 'fr' ? 'Cluster par analyse lexicale' : 'Cluster by lexical analysis' ) );
        }
        if ( ! empty( $singles ) ) {
            $clusters['Non classé'] = array( 'name' => 'Non classé', 'pillar_id' => 0, 'pages' => $singles, 'theme' => ( $this->analysis_lang === 'fr' ? 'Articles isolés' : 'Isolated articles' ) );
        }
        return $clusters;
    }

    /**
     * Fallback clustering: group pages by their WordPress categories.
     *
     * Used when all other clustering methods fail (> 40% in "Non classé").
     * WP categories are manually curated and provide a reliable grouping.
     * Pages without a category (or only "Uncategorized") go to "Non classé".
     *
     * @param array $nodes Node data from analyze_site
     * @return array Clusters keyed by category name
     */
    private function cluster_with_wp_categories( $nodes ) {
        $clusters = array();
        $uncategorized = array();

        foreach ( $nodes as $pid => $node ) {
            $cats = $node['categories'] ?? array();
            // Filter out "Uncategorized" / "Non classé" (term_id 1 or name match)
            $real_cats = array();
            foreach ( $cats as $cat_name ) {
                $lower = mb_strtolower( $cat_name );
                if ( in_array( $lower, array( 'uncategorized', 'non classé', 'non classe' ), true ) ) continue;
                $real_cats[] = $cat_name;
            }

            if ( empty( $real_cats ) ) {
                $uncategorized[] = $pid;
                continue;
            }

            // Use the first real category as the cluster
            $cat = $real_cats[0];
            if ( ! isset( $clusters[ $cat ] ) ) {
                $clusters[ $cat ] = array(
                    'name'      => $cat,
                    'pillar_id' => 0,
                    'pages'     => array(),
                    'theme'     => 'Groupé par catégorie WordPress',
                );
            }
            $clusters[ $cat ]['pages'][] = $pid;
        }

        // Update page_count
        foreach ( $clusters as &$cl ) {
            $cl['page_count'] = count( $cl['pages'] );
        }
        unset( $cl );

        // Uncategorized pages
        if ( ! empty( $uncategorized ) ) {
            $clusters['Non classé'] = array(
                'name'       => 'Non classé',
                'pillar_id'  => 0,
                'pages'      => $uncategorized,
                'page_count' => count( $uncategorized ),
                'theme'      => 'Articles sans catégorie',
            );
        }

        hts_add_log( sprintf(
            'Fallback catégories WP : %d clusters créés, %d pages classées, %d non classées',
            count( $clusters ) - ( ! empty( $uncategorized ) ? 1 : 0 ),
            count( $nodes ) - count( $uncategorized ),
            count( $uncategorized )
        ), 'info', 'cocon' );

        return $clusters;
    }

    /* ── SUGGESTIONS ── */

    public function suggest_cluster_links( $cluster_name, $lang = '' ) {
        $data = $this->get_cocon_data( $lang );
        if ( empty( $data['clusters'][ $cluster_name ] ) ) return array( 'error' => 'Cluster introuvable.' );

        // Load client decisions for flagged pages
        $decisions = get_option( 'hts_cocon_page_decisions', array() );
        $excluded_pids = array();
        foreach ( $decisions as $pid => $d ) {
            if ( $d['decision'] === 'exclude' ) $excluded_pids[] = (int) $pid;
        }

        // No link suggestions for unclassified cluster
        if ( $cluster_name === 'Non classé' ) {
            return array(
                'pillar_id' => 0, 'pillar_title' => '',
                'cluster' => $cluster_name,
                'suggestions' => array(),
                'state_counts' => array( 'done' => 0, 'pending' => 0 ),
                'message' => 'Ces pages n\'ont pas pu être classées automatiquement. Réanalysez le site après avoir ajouté du contenu.',
            );
        }

        // Growth-oriented message for emerging themes
        if ( $cluster_name === 'Thématiques émergentes' ) {
            return array(
                'pillar_id' => 0, 'pillar_title' => '',
                'cluster' => $cluster_name,
                'suggestions' => array(),
                'state_counts' => array( 'done' => 0, 'pending' => 0 ),
                'message' => '💡 Ce groupe contient des pages sur des sujets en cours de développement. Pour créer un cocon sémantique efficace, publiez 3 à 5 articles complémentaires autour de ces thématiques, puis réanalysez.',
            );
        }

        $cluster = $data['clusters'][ $cluster_name ];
        $nodes = $data['nodes'];
        $pillar_id = (int) ( $cluster['pillar_id'] ?? 0 );

        // ══════════════════════════════════════════════════════════════════
        // FULL RESULT CACHE — skip le pipeline lourd si cache valide
        // Seul refresh_link_states() est appelé (< 2s)
        // ══════════════════════════════════════════════════════════════════
        $full_cache_key = 'hts_cluster_links_' . md5( $cluster_name . '_' . $lang );
        $full_cached = get_transient( $full_cache_key );
        if ( $full_cached !== false && is_array( $full_cached ) && ! empty( $full_cached['suggestions'] ) ) {
            $full_cached = $this->refresh_link_states( $full_cached );
            if ( method_exists( $this, 'anchor_log' ) ) {
                $this->anchor_log( 'Cluster links FULL cache HIT [' . $cluster_name . '] : ' . count( $full_cached['suggestions'] ) . ' suggestions' );
            }
            return $full_cached;
        }

        // ══════════════════════════════════════════════════════════════════
        // V3 PIPELINE — Graph → Score → Anchor (exécuté seulement si pas de cache)
        // @since 2.4.20
        // ══════════════════════════════════════════════════════════════════

        // Auto-detect pillar if not set
        if ( ! $pillar_id ) {
            $best = 0;
            foreach ( $cluster['pages'] as $pid ) {
                if ( isset( $nodes[ $pid ] ) && $nodes[ $pid ]['pillar_score'] > $best ) {
                    $best = $nodes[ $pid ]['pillar_score'];
                    $pillar_id = $pid;
                }
            }
        }

        // ── STEP 1 : GRAPH — link matrix ──
        $matrix = $this->build_link_matrix( $cluster['pages'], $nodes );

        $total_links = 0;
        $total_possible = 0;
        foreach ( $matrix as $targets ) {
            foreach ( $targets as $exists ) {
                $total_possible++;
                if ( $exists ) $total_links++;
            }
        }

        hts_add_log(
            'FUNNEL v3 graph ["' . $cluster_name . '"] : '
            . count( $cluster['pages'] ) . ' pages, '
            . $total_links . '/' . $total_possible . ' liens existants, '
            . ( $total_possible - $total_links ) . ' paires manquantes',
            'info', 'cocon'
        );

        // ── STEP 2 : SCORE — prioritize missing pairs ──
        $emb = class_exists( 'HTS_Embeddings' ) ? new HTS_Embeddings() : null;
        $vectors = $emb ? $emb->load_all_vectors() : null;

        $scored_pairs = $this->score_missing_pairs( $matrix, $cluster['pages'], $nodes, $pillar_id, $vectors );

        // ── STEP 3 : ANCHOR — AI contextual anchors ──
        // Reset PHP anchor caches for this cluster
        $this->used_anchors_by_source = array();
        $this->source_content_cache   = array();
        $this->used_anchors_by_target = array();

        // Cache des suggestions IA — ne pas refaire les appels si le cache est valide
        $cache_key = 'hts_cocon_sug_' . md5( $cluster_name . '_' . $lang );
        $cached = get_transient( $cache_key );
        if ( $cached !== false && is_array( $cached ) && ! empty( $cached ) ) {
            $this->anchor_log( 'V3 cache HIT [' . $cluster_name . '] : ' . count( $cached ) . ' suggestions en cache' );
            $all_sugs = $cached;
        } else {
            $all_sugs = $this->ai_contextual_anchors_v3( $scored_pairs, $nodes );
            if ( ! empty( $all_sugs ) ) {
                set_transient( $cache_key, $all_sugs, 7 * DAY_IN_SECONDS );
                $this->anchor_log( 'V3 cache SET [' . $cluster_name . '] : ' . count( $all_sugs ) . ' suggestions mises en cache (7j)' );
            }
        }

        // ── FALLBACK : old pipeline if AI returned nothing ──
        if ( empty( $all_sugs ) ) {
            hts_add_log( 'FUNNEL v3 fallback ["' . $cluster_name . '"] : IA indisponible, utilisation pipeline PHP classique', 'info', 'cocon' );
            $base = $this->suggest_without_ai( $cluster, $nodes, $pillar_id );
            $all_sugs = $base['suggestions'];
            $all_sugs = $this->enhance_anchors_with_ai( $all_sugs, $nodes );
        }

        $result = array(
            'pillar_id'    => $pillar_id,
            'pillar_title' => $nodes[ $pillar_id ]['title'] ?? '',
            'cluster'      => $cluster_name,
            'suggestions'  => $all_sugs,
        );

        // ── V3: No TFTD gate — cluster membership IS the validation ──
        // Only keep an extreme cosine floor (< 0.10) as safety net for
        // pages that may have slipped into the cluster by accident.
        $has_any_vectors = ( $vectors && count( $vectors ) >= 3 );
        if ( ! empty( $result['suggestions'] ) && $has_any_vectors ) {
            $cosine_blocked = 0;
            $filtered = array();
            foreach ( $result['suggestions'] as $sug ) {
                $sid = (int) $sug['source_id'];
                $tid = (int) $sug['target_id'];
                // Client exclusions
                if ( in_array( $sid, $excluded_pids ) || in_array( $tid, $excluded_pids ) ) continue;
                // Extreme cosine floor only
                if ( isset( $vectors[ $sid ] ) && isset( $vectors[ $tid ] ) ) {
                    $sim = HTS_Embeddings::cosine_similarity( $vectors[ $sid ], $vectors[ $tid ] );
                    if ( $sim < 0.10 ) { $cosine_blocked++; continue; }
                }
                $filtered[] = $sug;
            }
            $result['suggestions'] = $filtered;
            if ( $cosine_blocked > 0 ) {
                hts_add_log( 'FUNNEL v3 cosine safety ["' . $cluster_name . '"] : ' . $cosine_blocked . ' bloqué(s) (sim < 0.10)', 'info', 'cocon' );
            }
        }

        // ══════════════════════════════════════════════════════════════════
        // v2.4.16: TRIPLE-CHECK link state — regex + url_to_postid + audit trail memory
        // This catches: links in post_content (2 methods) AND links HTS applied
        // that were later lost (user saved in Gutenberg, revision overwrite, etc.)
        // ══════════════════════════════════════════════════════════════════
        if ( ! empty( $result['suggestions'] ) ) {
            $existing_targets_cache = array(); // url_to_postid cache
            $audit_cache = array();            // audit trail cache

            // Pre-compute orphan PIDs for diagnostic logging in triple-check
            $orphan_pids_for_log = array();
            foreach ( $cluster['pages'] as $pid ) {
                if ( isset( $nodes[ $pid ] ) && ( ! empty( $nodes[ $pid ]['is_orphan'] ) || ( $nodes[ $pid ]['role'] ?? '' ) === 'orpheline' ) ) {
                    $orphan_pids_for_log[] = (int) $pid;
                }
            }

            foreach ( $result['suggestions'] as &$sug ) {
                $sid = (int) $sug['source_id'];
                $tid = (int) $sug['target_id'];

                // ── Check 1: regex-based detection in post_content ──
                $found = $this->link_exists_in_content( $sid, $tid );

                // ── Check 2: url_to_postid fallback (catches URL variations) ──
                if ( $found === false ) {
                    if ( ! isset( $existing_targets_cache[ $sid ] ) ) {
                        $existing_targets_cache[ $sid ] = $this->get_existing_internal_targets( $sid );
                    }
                    if ( in_array( $tid, $existing_targets_cache[ $sid ], true ) ) {
                        $found = true;
                    }
                }

                if ( $found !== false ) {
                    // Link exists in post_content right now
                    $sug['state'] = 'done';
                    $sug['actual_anchor'] = is_string( $found ) ? $found : ( $sug['anchor_text'] ?? '' );

                    // Log when orphan targets get marked done — helps diagnose false positives
                    if ( in_array( $tid, $orphan_pids_for_log ?? array(), true ) ) {
                        $tc_msg = 'orphan-debug triple-check : orpheline ID=' . $tid . ' ciblée par ID=' . $sid
                            . ' → marquée DONE (ancre trouvée: "' . mb_substr( is_string( $found ) ? $found : '(bool)', 0, 40 ) . '")';
                        hts_debug_log( $tc_msg );
                        hts_add_log( $tc_msg, 'info', 'cocon' );
                    }
                } else {
                    // ── Check 3: audit trail memory — did HTS ever apply this link? ──
                    if ( class_exists( 'HTS_Audit_Trail' ) ) {
                        if ( ! isset( $audit_cache[ $sid ] ) ) {
                            $audit_cache[ $sid ] = HTS_Audit_Trail::get_applied_targets( $sid );
                        }
                        $was_applied = false;
                        $applied_anchor = '';
                        foreach ( $audit_cache[ $sid ] as $at ) {
                            if ( (int) $at['target_id'] === $tid ) {
                                $was_applied = true;
                                $applied_anchor = $at['anchor'];
                                break;
                            }
                        }
                        if ( $was_applied ) {
                            // HTS applied this link before, but it's no longer in post_content
                            $sug['state'] = 'lost';
                            $sug['actual_anchor'] = $applied_anchor;
                            $sug['lost_reason'] = 'Lien appliqué par Hack The SEO mais absent du contenu actuel (sauvegarde manuelle ?)';
                            continue;
                        }
                    }
                    $sug['state'] = 'pending';
                }
            }
            unset( $sug );

            // Sort: lost first (needs attention), then pending, then done
            usort( $result['suggestions'], function( $a, $b ) {
                $order = array( 'lost' => 0, 'pending' => 1, 'done' => 2 );
                return ( $order[ $a['state'] ] ?? 1 ) - ( $order[ $b['state'] ] ?? 1 );
            } );

            $result['state_counts'] = array(
                'done'    => count( array_filter( $result['suggestions'], function( $s ) { return $s['state'] === 'done'; } ) ),
                'pending' => count( array_filter( $result['suggestions'], function( $s ) { return $s['state'] === 'pending'; } ) ),
                'lost'    => count( array_filter( $result['suggestions'], function( $s ) { return $s['state'] === 'lost'; } ) ),
            );

            // ── FUNNEL LOG: triple-check states ──
            $method_by_state = array();
            foreach ( $result['suggestions'] as $s ) {
                $state  = $s['state'] ?? '?';
                $method = $s['anchor_method'] ?? '?';
                $key = $state . '/' . $method;
                $method_by_state[ $key ] = ( $method_by_state[ $key ] ?? 0 ) + 1;
            }
            hts_add_log(
                'FUNNEL triple-check ["' . $cluster_name . '"] : '
                . 'done=' . $result['state_counts']['done'] . ', '
                . 'pending=' . $result['state_counts']['pending'] . ', '
                . 'lost=' . ( $result['state_counts']['lost'] ?? 0 ) . ' — '
                . 'détail: ' . implode( ', ', array_map( function( $k, $v ) { return $k . '=' . $v; }, array_keys( $method_by_state ), $method_by_state ) ),
                'info', 'cocon'
            );

            // ══════════════════════════════════════════════════════════════════
            // ORPHAN SAFETY NET — post triple-check
            // If an orphan page has 0 "pending" incoming suggestions,
            // the triple-check marked all its pairs as "done" (nav links, 
            // sidebar, footer — not editorial links in content).
            // We FORCE the best AI suggestion for this orphan back to "pending"
            // so the user can add a REAL editorial link.
            // ══════════════════════════════════════════════════════════════════
            $orphan_pids = array();
            foreach ( $cluster['pages'] as $pid ) {
                if ( isset( $nodes[ $pid ] ) && ( ! empty( $nodes[ $pid ]['is_orphan'] ) || ( $nodes[ $pid ]['role'] ?? '' ) === 'orpheline' ) ) {
                    $orphan_pids[] = (int) $pid;
                }
            }

            // ── ALWAYS log orphan detection status ──
            $orphan_names = array();
            foreach ( $orphan_pids as $opid ) {
                $orphan_names[] = $opid . '="' . mb_substr( $nodes[ $opid ]['title'] ?? '?', 0, 30 ) . '"';
            }
            $detection_msg = 'orphan-debug DETECTION [' . $cluster_name . '] : '
                . count( $orphan_pids ) . ' orphelin(s) détecté(s)'
                . ( empty( $orphan_names ) ? ' (AUCUN!)' : ' → ' . implode( ', ', $orphan_names ) );
            hts_debug_log( $detection_msg );
            hts_add_log( $detection_msg,
                'info', 'cocon'
            );

            if ( ! empty( $orphan_pids ) ) {
                // Check which orphans already have pending incoming suggestions
                $orphans_with_pending = array();
                foreach ( $result['suggestions'] as $s ) {
                    if ( ( $s['state'] ?? '' ) === 'pending' && in_array( (int) $s['target_id'], $orphan_pids, true ) ) {
                        $orphans_with_pending[ (int) $s['target_id'] ] = true;
                    }
                }

                $rescued = 0;
                foreach ( $orphan_pids as $opid ) {
                    // Log pending status for EVERY orphan
                    $has_pending = isset( $orphans_with_pending[ $opid ] );
                    $targeting_states = array();
                    foreach ( $result['suggestions'] as $s ) {
                        if ( (int) $s['target_id'] === $opid ) {
                            $st = $s['state'] ?? '?';
                            $targeting_states[ $st ] = ( $targeting_states[ $st ] ?? 0 ) + 1;
                        }
                    }
                    $status_msg = 'orphan-debug STATUS : "' . mb_substr( $nodes[ $opid ]['title'] ?? '', 0, 35 ) . '" (ID=' . $opid . ')'
                        . ' → has_pending=' . ( $has_pending ? 'YES' : 'NO' )
                        . ' | targeting: ' . ( empty( $targeting_states ) ? 'NONE' : implode( ', ', array_map( function($k,$v){ return $k.'='.$v; }, array_keys($targeting_states), $targeting_states ) ) );
                    hts_debug_log( $status_msg );
                    hts_add_log( $status_msg, 'info', 'cocon' );

                    if ( $has_pending ) {
                        hts_add_log( 'orphan-debug : "' . mb_substr( $nodes[ $opid ]['title'] ?? '', 0, 40 ) . '" (ID=' . $opid . ') → déjà pending, skip', 'info', 'cocon' );
                        continue;
                    }

                    // Count ALL suggestions (any state) targeting this orphan
                    $all_targeting = 0;
                    $done_targeting = 0;
                    foreach ( $result['suggestions'] as $s ) {
                        if ( (int) $s['target_id'] === $opid ) {
                            $all_targeting++;
                            if ( ( $s['state'] ?? '' ) === 'done' ) $done_targeting++;
                        }
                    }
                    hts_add_log( 'orphan-debug : "' . mb_substr( $nodes[ $opid ]['title'] ?? '', 0, 40 ) . '" (ID=' . $opid . ') → ' . $all_targeting . ' suggestions totales, ' . $done_targeting . ' done', 'info', 'cocon' );

                    // This orphan has 0 pending incoming — find the best "done" suggestion targeting it
                    $best_idx   = -1;
                    $best_score = -1;
                    foreach ( $result['suggestions'] as $idx => $s ) {
                        if ( (int) $s['target_id'] !== $opid ) continue;
                        if ( ( $s['state'] ?? '' ) !== 'done' ) continue;
                        // Prefer AI anchors over PHP fallbacks
                        $priority = ( $s['anchor_method'] ?? '' ) === 'ai' ? 10 : 0;
                        $priority += ( $s['anchor_type'] ?? '' ) === 'extract' ? 5 : 0;
                        if ( $priority > $best_score ) {
                            $best_score = $priority;
                            $best_idx   = $idx;
                        }
                    }

                    if ( $best_idx >= 0 ) {
                        // Force this suggestion back to pending — the nav/sidebar link 
                        // is NOT an editorial link, so the user should add a real one
                        $result['suggestions'][ $best_idx ]['state'] = 'pending';
                        $result['suggestions'][ $best_idx ]['orphan_rescue'] = true;
                        $result['suggestions'][ $best_idx ]['reason'] = ( $result['suggestions'][ $best_idx ]['reason'] ?? '' )
                            . ' · page orpheline — lien éditorial nécessaire';
                        $rescued++;
                    } else {
                        // NO suggestion at all targets this orphan — create one from scratch
                        // Find the best source (pillar preferred, then most connected non-orphan)
                        $best_source = 0;
                        $best_out = -1;
                        foreach ( $cluster['pages'] as $sid ) {
                            if ( $sid === $opid ) continue;
                            if ( ! isset( $nodes[ $sid ] ) ) continue;
                            if ( ! empty( $nodes[ $sid ]['is_orphan'] ) ) continue;
                            $out = (int) ( $nodes[ $sid ]['out_count_semantic'] ?? $nodes[ $sid ]['out_count'] ?? 0 );
                            $boost = ! empty( $nodes[ $sid ]['is_pillar'] ) ? 100 : 0;
                            if ( ( $out + $boost ) > $best_out ) {
                                $best_out = $out + $boost;
                                $best_source = $sid;
                            }
                        }

                        if ( $best_source > 0 ) {
                            $orphan_title = $nodes[ $opid ]['title'] ?? '';
                            $clean_anchor = $this->build_orphan_anchor( $orphan_title );
                            $bridge = $this->build_orphan_bridge( $orphan_title, $clean_anchor );

                            $result['suggestions'][] = array(
                                'source_id'       => $best_source,
                                'target_id'       => $opid,
                                'source_title'    => $nodes[ $best_source ]['title'] ?? '',
                                'target_title'    => $orphan_title,
                                'anchor_text'     => $clean_anchor,
                                'anchor_method'   => 'ai',
                                'anchor_type'     => 'generated',
                                'anchor_sentence' => '',
                                'anchor_bridge'   => $bridge,
                                'link_type'       => ! empty( $nodes[ $best_source ]['is_pillar'] ) ? 'pillar_to_child' : 'sibling',
                                'reason'          => 'page orpheline — lien de dernier recours',
                                'priority'        => 'high',
                                'gsc'             => self::get_gsc_weight( $opid ),
                                'state'           => 'pending',
                                'orphan_rescue'   => true,
                            );
                            $rescued++;

                            hts_add_log(
                                'FUNNEL orphan-create ["' . $cluster_name . '"] : '
                                . '"' . mb_substr( $orphan_title, 0, 40 ) . '" n' . "\x27" . 'avait AUCUNE suggestion'
                                . ' → lien créé depuis "' . mb_substr( $nodes[ $best_source ]['title'] ?? '', 0, 40 ) . '"'
                                . ' avec ancre "' . $clean_anchor . '"',
                                'info', 'cocon'
                            );
                        }
                    }
                }

                if ( $rescued > 0 ) {
                    // Recount states
                    $result['state_counts'] = array(
                        'done'    => count( array_filter( $result['suggestions'], function( $s ) { return ( $s['state'] ?? '' ) === 'done'; } ) ),
                        'pending' => count( array_filter( $result['suggestions'], function( $s ) { return ( $s['state'] ?? '' ) === 'pending'; } ) ),
                        'lost'    => count( array_filter( $result['suggestions'], function( $s ) { return ( $s['state'] ?? '' ) === 'lost'; } ) ),
                    );

                    // Re-sort
                    usort( $result['suggestions'], function( $a, $b ) {
                        $order = array( 'lost' => 0, 'pending' => 1, 'done' => 2 );
                        return ( $order[ $a['state'] ] ?? 1 ) - ( $order[ $b['state'] ] ?? 1 );
                    } );

                    hts_add_log(
                        'FUNNEL orphan-rescue ["' . $cluster_name . '"] : '
                        . $rescued . ' orphelin(s) repêché(s) → pending forcé malgré triple-check done'
                        . ' (lien nav/sidebar détecté mais pas de lien éditorial)',
                        'info', 'cocon'
                    );
                }
            }

        } // end if ( ! empty( $result['suggestions'] ) )

        // Sauvegarder le résultat complet en cache (7j)
        set_transient( $full_cache_key, $result, 7 * DAY_IN_SECONDS );

        return $result;
    }

    /**
     * Refresh link states (done/pending/lost) from cached suggestions.
     * Fast: only checks if <a href> exists in post_content (< 2s for 40 suggestions).
     */
    private function refresh_link_states( $result ) {
        if ( empty( $result['suggestions'] ) ) return $result;

        foreach ( $result['suggestions'] as &$sug ) {
            $source_id = (int) ( $sug['source_id'] ?? 0 );
            $target_id = (int) ( $sug['target_id'] ?? 0 );
            if ( ! $source_id || ! $target_id ) continue;

            $post = get_post( $source_id );
            if ( ! $post || $post->post_status !== 'publish' ) {
                $sug['state'] = 'lost';
                continue;
            }

            $target_post = get_post( $target_id );
            if ( ! $target_post || $target_post->post_status !== 'publish' ) {
                $sug['state'] = 'lost';
                continue;
            }

            $target_url  = get_permalink( $target_id );
            $target_path = wp_parse_url( $target_url, PHP_URL_PATH );
            $content     = $post->post_content;

            $link_exists = false;
            if ( $target_url && stripos( $content, $target_url ) !== false ) $link_exists = true;
            if ( ! $link_exists && $target_path && stripos( $content, $target_path ) !== false ) $link_exists = true;

            if ( $link_exists ) {
                $sug['state'] = 'done';
            } elseif ( ( $sug['state'] ?? '' ) === 'done' ) {
                $sug['state'] = 'lost';
            }
        }
        unset( $sug );

        $result['state_counts'] = array(
            'done'    => count( array_filter( $result['suggestions'], function( $s ) { return ( $s['state'] ?? '' ) === 'done'; } ) ),
            'pending' => count( array_filter( $result['suggestions'], function( $s ) { return ( $s['state'] ?? '' ) === 'pending'; } ) ),
            'lost'    => count( array_filter( $result['suggestions'], function( $s ) { return ( $s['state'] ?? '' ) === 'lost'; } ) ),
        );

        return $result;
    }

    /**
     * Get all internal post IDs that are already linked from a source post.
     * Used to avoid suggesting duplicate links to the same target.
     * @since 2.4.15
     * @param int $source_id
     * @return array Array of post IDs (int) already linked from this source
     */
    private function get_existing_internal_targets( $source_id ) {
        $post = get_post( $source_id );
        if ( ! $post || empty( $post->post_content ) ) return array();

        $targets = array();
        $site_url = home_url();
        $site_host = parse_url( $site_url, PHP_URL_HOST );

        // Extract all href from <a> tags
        if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $post->post_content, $matches ) ) {
            foreach ( $matches[1] as $href ) {
                // Only internal links
                $href_host = parse_url( $href, PHP_URL_HOST );
                $is_internal = false;
                if ( empty( $href_host ) && strpos( $href, '/' ) === 0 ) {
                    $is_internal = true; // Relative URL
                    $href = $site_url . $href;
                } elseif ( $href_host === $site_host ) {
                    $is_internal = true;
                }

                if ( $is_internal ) {
                    $target_pid = hts_url_to_postid( $href );
                    if ( $target_pid > 0 ) {
                        $targets[] = $target_pid;
                    } else {
                        // v2.4.16: Log unresolved URLs for diagnostic
                        hts_add_log( 'Cocon dedup: url_to_postid failed for "' . $href . '" in post=' . $source_id, 'debug', 'cocon' );
                    }
                }
            }
        }

        return array_unique( $targets );
    }

    /**
     * Check if source post contains a link to target post (real-time).
     * Returns the anchor text if found, false otherwise.
     */
    private function link_exists_in_content( $source_id, $target_id ) {
        $post = get_post( $source_id );
        if ( ! $post ) return false;

        $target_url = get_permalink( $target_id );
        if ( ! $target_url ) return false;

        $content = $post->post_content;
        $target_path = parse_url( $target_url, PHP_URL_PATH );
        $target_path_clean = rtrim( $target_path, '/' );

        // Build patterns that tolerate trailing slash variations
        $url_patterns = array();

        // Full URL with optional trailing slash
        $url_patterns[] = preg_quote( rtrim( $target_url, '/' ), '/' ) . '\\/?';

        // Path only with optional trailing slash (if different from full URL)
        if ( $target_path_clean ) {
            $url_patterns[] = preg_quote( $target_path_clean, '/' ) . '\\/?';
        }

        // Only match real <a href="..."> tags — NO strpos fallback
        // strpos would false-positive on Gutenberg comments, data-* attrs, shortcodes, etc.
        foreach ( $url_patterns as $pat ) {
            if ( preg_match( '/<a\s[^>]*href=["\']' . $pat . '["\'][^>]*>(.*?)<\/a>/si', $content, $m ) ) {
                return wp_strip_all_tags( $m[1] ) ?: true;
            }
        }

        return false;
    }

    private function suggest_with_ai( $cluster, $nodes, $existing, $pillar_id ) {
        $at = '';
        foreach ( $cluster['pages'] as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $n = $nodes[ $pid ];
            $post = get_post( $pid );
            $ex = $post ? html_entity_decode( wp_strip_all_tags( mb_substr( $post->post_content, 0, 400 ) ), ENT_QUOTES, 'UTF-8' ) : '';
            $at .= "- ID:{$pid} | [{$n['role']}] \"{$n['title']}\" | {$n['word_count']}w | {$n['in_count']} in | Extrait: {$ex}\n";
        }

        $prompt = "Expert cocon sémantique SEO.

═══ CLUSTER : \"{$cluster['name']}\" — Pilier: ID:{$pillar_id} ═══

{$at}

═══ MISSION ═══
Génère le maillage cocon COMPLET idéal (tous les liens, même ceux déjà en place) :
1. Chaque fille DOIT pointer vers le pilier
2. Le pilier DOIT pointer vers chaque fille
3. Pages sœurs proches = liées entre elles
4. Ancre naturelle 2-5 mots par lien

FORMAT JSON : [{\"source_id\":X,\"target_id\":Y,\"anchor_text\":\"ancre\",\"link_type\":\"child_to_pillar|pillar_to_child|sibling\",\"reason\":\"...\",\"priority\":\"high|medium|low\"}]
Max 30 suggestions.";

        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 60,
            'headers' => array( 'Authorization' => 'Bearer ' . $this->openai_key, 'Content-Type' => 'application/json' ),
            'body' => wp_json_encode( array(
                'model' => 'gpt-4.1-mini',
                'messages' => array(
                    array( 'role' => 'system', 'content' => 'JSON valide uniquement.' ),
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'temperature' => 0.3, 'max_tokens' => 2500,
            ) ),
        ) );

        if ( is_wp_error( $resp ) ) return $this->suggest_without_ai( $cluster, $nodes, $pillar_id );

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $tk = (int) ( $body['usage']['total_tokens'] ?? 0 );
        if ( $tk > 0 ) {
            $us = get_option( 'hts_openai_usage', array() ); $mk = wp_date( 'Y-m' );
            $us[ $mk ] = ( (int) ( $us[ $mk ] ?? 0 ) ) + $tk;
            update_option( 'hts_openai_usage', $us, false );
        }

        $txt = $body['choices'][0]['message']['content'] ?? '';
        $txt = preg_replace( '/^```json\s*/', '', trim( $txt ) );
        $txt = preg_replace( '/\s*```$/', '', $txt );
        $sugs = json_decode( $txt, true );
        if ( ! is_array( $sugs ) ) return $this->suggest_without_ai( $cluster, $nodes, $pillar_id );

        // Filter out self-referencing links and invalid IDs
        $sugs = array_values( array_filter( $sugs, function( $s ) use ( $nodes ) {
            $src = (int) ( $s['source_id'] ?? 0 );
            $tgt = (int) ( $s['target_id'] ?? 0 );
            return $src !== $tgt && isset( $nodes[ $src ] ) && isset( $nodes[ $tgt ] );
        } ) );

        foreach ( $sugs as &$s ) {
            $s['source_title'] = $nodes[ $s['source_id'] ]['title'] ?? '';
            $s['target_title'] = $nodes[ $s['target_id'] ]['title'] ?? '';
            $s['source_role']  = $nodes[ $s['source_id'] ]['role'] ?? '';
            $s['target_role']  = $nodes[ $s['target_id'] ]['role'] ?? '';
        }
        unset( $s );

        return array( 'pillar_id' => $pillar_id, 'pillar_title' => $nodes[ $pillar_id ]['title'] ?? '', 'suggestions' => $sugs, 'cluster' => $cluster['name'] );
    }

    /**
     * Récupérer les métriques GSC d'un post pour pondérer les suggestions de liens.
     *
     * @param int $post_id
     * @return array { clicks, impressions, position, ctr, tag }
     */
    private static function get_gsc_weight( $post_id ) {
        static $cache = array();
        if ( isset( $cache[ $post_id ] ) ) return $cache[ $post_id ];

        $clicks      = (int) get_post_meta( $post_id, '_hts_gsc_clicks', true );
        $impressions = (int) get_post_meta( $post_id, '_hts_gsc_impressions', true );
        $position    = (float) get_post_meta( $post_id, '_hts_gsc_position', true );
        $ctr         = (float) get_post_meta( $post_id, '_hts_gsc_ctr', true );

        // Tag descriptif pour le reason
        $tag = '';
        $parts = array();
        if ( $impressions > 0 ) $parts[] = $impressions . ' impr.';
        if ( $clicks > 0 )      $parts[] = $clicks . ' clics';
        if ( $position > 0 )    $parts[] = 'pos ' . round( $position, 1 );
        if ( ! empty( $parts ) ) $tag = '' . implode( ', ', $parts );

        $cache[ $post_id ] = array(
            'clicks'      => $clicks,
            'impressions' => $impressions,
            'position'    => $position,
            'ctr'         => $ctr,
            'tag'         => $tag,
        );
        return $cache[ $post_id ];
    }

    /**
     * Calculer la priorité d'un lien en fonction des données GSC de la cible.
     *
     * Logique de pondération :
     * - critical : page en position 4-10 avec impressions (presque page 1, un lien interne peut faire basculer)
     * - high     : page en position 11-20 avec impressions (potentiel de gain réel)
     *              OU page orpheline avec impressions (Google la voit, un lien la booste)
     *              OU lien pilier↔enfant (toujours important structurellement)
     * - medium   : page avec impressions mais position > 20 (plus loin, gain incertain)
     *              OU sibling sans données GSC
     * - low      : page sans aucune impression (pas encore vue par Google)
     *
     * @param array  $gsc       Données GSC de la page cible
     * @param string $link_type child_to_pillar|pillar_to_child|sibling
     * @return string priority
     */
    private static function compute_link_priority( $gsc, $link_type = 'sibling' ) {
        $pos  = $gsc['position'] ?? 0;
        $impr = $gsc['impressions'] ?? 0;

        // Pilier↔enfant = toujours au minimum high (structurel)
        $is_structural = in_array( $link_type, array( 'child_to_pillar', 'pillar_to_child' ), true );

        // Position 4-10 avec visibilité → critical (presque page 1)
        if ( $pos >= 4 && $pos <= 10 && $impr >= 50 ) {
            return 'critical';
        }

        // Position 11-20 avec visibilité → high (opportunité page 1)
        if ( $pos > 10 && $pos <= 20 && $impr >= 20 ) {
            return 'high';
        }

        // Impressions sans clics → high (CTR à améliorer, un lien aide)
        if ( $impr >= 100 && ( $gsc['clicks'] ?? 0 ) <= 2 ) {
            return 'high';
        }

        // Structurel → high minimum
        if ( $is_structural ) {
            return 'high';
        }

        // Impressions présentes → medium
        if ( $impr > 0 ) {
            return 'medium';
        }

        // Pas de données GSC → low
        return 'low';
    }

    private function suggest_without_ai( $cluster, $nodes, $pillar_id ) {
        $sugs = array();
        // Reset diversité ancres et cache contenu pour ce cluster
        $this->used_anchors_by_source = array();
        $this->source_content_cache = array();
        $this->used_anchors_by_target = array();
        $pages = $cluster['pages'];
        if ( ! $pillar_id ) {
            $best = 0;
            foreach ( $pages as $pid ) {
                if ( isset( $nodes[ $pid ] ) && $nodes[ $pid ]['pillar_score'] > $best ) { $best = $nodes[ $pid ]['pillar_score']; $pillar_id = $pid; }
            }
        }

        // Load vectors for cosine floor check
        $vectors = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb = new HTS_Embeddings();
            $vectors = $emb->load_all_vectors();
        }
        $has_any_vectors = ( $vectors && count( $vectors ) >= 3 );

        // Stopwords for TFTD
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir' ) ) : array() );

        // Pre-load pillar content for TFTD
        $pillar_post = get_post( $pillar_id );
        $pillar_content = mb_strtolower(
            ( $nodes[ $pillar_id ]['title'] ?? '' ) . ' ' .
            ( $pillar_post ? html_entity_decode( wp_strip_all_tags( mb_substr( $pillar_post->post_content, 0, 1000 ) ), ENT_QUOTES, 'UTF-8' ) : '' )
        );
        $pillar_title_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $nodes[ $pillar_id ]['title'] ?? '' ) );
        $pillar_title_words = array_unique( array_values( array_filter( $pillar_title_words, function( $w ) use ( $sw ) {
            return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
        } ) ) );

        // Load client decisions
        $decisions = get_option( 'hts_cocon_page_decisions', array() );
        $excluded_pids = array();
        foreach ( $decisions as $dpid => $d ) {
            if ( $d['decision'] === 'exclude' ) $excluded_pids[] = (int) $dpid;
        }

        $diag_total_children = 0;
        $diag_tftd_blocked  = 0;
        $diag_cosine_blocked = 0;
        $diag_excluded       = 0;

        foreach ( $pages as $pid ) {
            if ( $pid === $pillar_id || ! isset( $nodes[ $pid ] ) ) continue;
            $diag_total_children++;

            // Client excluded this page → no links
            if ( in_array( $pid, $excluded_pids ) || in_array( $pillar_id, $excluded_pids ) ) { $diag_excluded++; continue; }

            // ── TFTD Gate: check lexical connection between page and pillar ──
            $page_post = get_post( $pid );
            $page_content = mb_strtolower(
                $nodes[ $pid ]['title'] . ' ' .
                ( $page_post ? html_entity_decode( wp_strip_all_tags( mb_substr( $page_post->post_content, 0, 1000 ) ), ENT_QUOTES, 'UTF-8' ) : '' )
            );
            $page_title_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $nodes[ $pid ]['title'] ) );
            $page_title_words = array_unique( array_values( array_filter( $page_title_words, function( $w ) use ( $sw ) {
                return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
            } ) ) );

            // Check bidirectional lexical connection
            $page_in_pillar = 0;
            foreach ( $page_title_words as $tw ) {
                if ( mb_strpos( $pillar_content, $tw ) !== false ) $page_in_pillar++;
            }
            $pillar_in_page = 0;
            foreach ( $pillar_title_words as $tw ) {
                if ( mb_strpos( $page_content, $tw ) !== false ) $pillar_in_page++;
            }

            // BLOCK if zero lexical connection in both directions
            if ( $page_in_pillar === 0 && $pillar_in_page === 0
                 && count( $page_title_words ) >= 2 && count( $pillar_title_words ) >= 2 ) {
                $diag_tftd_blocked++;
                hts_add_log(
                    '⛔ TFTD bloqué : "' . mb_substr( $nodes[ $pid ]['title'], 0, 35 )
                    . '" ↔ "' . mb_substr( $nodes[ $pillar_id ]['title'], 0, 35 )
                    . '" — 0 terme commun',
                    'info', 'cocon'
                );
                continue;
            }

            // Secondary: cosine floor
            if ( $has_any_vectors && isset( $vectors[ $pid ] ) && isset( $vectors[ $pillar_id ] ) ) {
                $sim = HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $pillar_id ] );
                if ( $sim < 0.20 ) {
                    $diag_cosine_blocked++;
                    hts_add_log(
                        '⛔ Cosine floor : "' . mb_substr( $nodes[ $pid ]['title'], 0, 40 ) . '" (sim=' . round( $sim, 3 ) . ')',
                        'info', 'cocon'
                    );
                    continue;
                }
            }

            // Child → pillar
            $child_gsc = self::get_gsc_weight( $pid );
            $child_prio = self::compute_link_priority( $child_gsc, 'child_to_pillar' );
            $child_reason = 'Enfant → pilier';
            if ( $child_gsc['tag'] ) $child_reason .= ' · ' . $child_gsc['tag'];
            $anchor_cp = $this->generate_varied_anchor( $nodes[ $pillar_id ]['title'] ?? '', $pid, 'child_to_pillar', $pillar_id );
            $sugs[] = array( 'source_id' => $pid, 'target_id' => $pillar_id, 'source_title' => $nodes[ $pid ]['title'], 'target_title' => $nodes[ $pillar_id ]['title'] ?? '', 'anchor_text' => $anchor_cp['anchor'], 'anchor_method' => $anchor_cp['method'], 'link_type' => 'child_to_pillar', 'reason' => $child_reason, 'priority' => $child_prio, 'gsc' => $child_gsc );
            // Pillar → child
            if ( isset( $nodes[ $pillar_id ] ) ) {
                $pillar_prio = self::compute_link_priority( $child_gsc, 'pillar_to_child' );
                $pillar_reason = 'Pilier → enfant';
                if ( $child_gsc['tag'] ) $pillar_reason .= ' · cible : ' . $child_gsc['tag'];
                $anchor_pc = $this->generate_varied_anchor( $nodes[ $pid ]['title'], $pillar_id, 'pillar_to_child', $pid );
                $sugs[] = array( 'source_id' => $pillar_id, 'target_id' => $pid, 'source_title' => $nodes[ $pillar_id ]['title'], 'target_title' => $nodes[ $pid ]['title'], 'anchor_text' => $anchor_pc['anchor'], 'anchor_method' => $anchor_pc['method'], 'link_type' => 'pillar_to_child', 'reason' => $pillar_reason, 'priority' => $pillar_prio, 'gsc' => $child_gsc );
            }
        }

        // ── Sibling links (entre enfants du même cluster) ──
        // Pour chaque paire d'enfants, vérifier la connexion lexicale et proposer un lien
        $children = array_filter( $pages, function( $pid ) use ( $pillar_id ) { return $pid !== $pillar_id; } );
        $children = array_values( $children );
        $child_contents = array();
        $child_title_words = array();

        foreach ( $children as $cid ) {
            if ( ! isset( $nodes[ $cid ] ) ) continue;
            if ( in_array( $cid, $excluded_pids ) ) continue;

            $cp = get_post( $cid );
            $child_contents[ $cid ] = mb_strtolower(
                $nodes[ $cid ]['title'] . ' ' .
                ( $cp ? html_entity_decode( wp_strip_all_tags( mb_substr( $cp->post_content, 0, 1500 ) ), ENT_QUOTES, 'UTF-8' ) : '' )
            );
            $words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $nodes[ $cid ]['title'] ) );
            $child_title_words[ $cid ] = array_unique( array_values( array_filter( $words, function( $w ) use ( $sw ) {
                return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
            } ) ) );
        }

        $sibling_count = 0;
        $max_siblings = 30; // Limiter pour ne pas exploser

        for ( $i = 0; $i < count( $children ); $i++ ) {
            for ( $j = $i + 1; $j < count( $children ); $j++ ) {
                if ( $sibling_count >= $max_siblings ) break 2;

                $a = $children[ $i ];
                $b = $children[ $j ];
                if ( ! isset( $child_contents[ $a ] ) || ! isset( $child_contents[ $b ] ) ) continue;

                // TFTD bidirectionnel entre les deux enfants
                $a_in_b = 0;
                foreach ( $child_title_words[ $a ] ?? array() as $tw ) {
                    if ( mb_strpos( $child_contents[ $b ], $tw ) !== false ) $a_in_b++;
                }
                $b_in_a = 0;
                foreach ( $child_title_words[ $b ] ?? array() as $tw ) {
                    if ( mb_strpos( $child_contents[ $a ], $tw ) !== false ) $b_in_a++;
                }

                // Au moins un terme commun dans une direction
                $a_ratio = count( $child_title_words[ $a ] ?? array() ) > 0 ? $a_in_b / count( $child_title_words[ $a ] ) : 0;
                $b_ratio = count( $child_title_words[ $b ] ?? array() ) > 0 ? $b_in_a / count( $child_title_words[ $b ] ) : 0;

                if ( $a_ratio === 0.0 && $b_ratio === 0.0 ) continue; // Pas de connexion lexicale

                // Cosine floor si embeddings disponibles
                if ( $has_any_vectors && isset( $vectors[ $a ] ) && isset( $vectors[ $b ] ) ) {
                    $sim = HTS_Embeddings::cosine_similarity( $vectors[ $a ], $vectors[ $b ] );
                    if ( $sim < 0.25 ) continue; // Seuil légèrement plus haut pour siblings
                }

                // Proposer A → B
                $gsc_b = self::get_gsc_weight( $b );
                $sib_prio_ab = self::compute_link_priority( $gsc_b, 'sibling' );
                $sib_reason_ab = 'Lien sémantique entre enfants du même cluster';
                if ( $gsc_b['tag'] ) $sib_reason_ab .= ' · cible : ' . $gsc_b['tag'];
                $anchor_ab = $this->generate_varied_anchor( $nodes[ $b ]['title'], $a, 'sibling', $b );
                $sugs[] = array(
                    'source_id'    => $a,
                    'target_id'    => $b,
                    'source_title' => $nodes[ $a ]['title'],
                    'target_title' => $nodes[ $b ]['title'],
                    'anchor_text'  => $anchor_ab['anchor'],
                    'anchor_method'=> $anchor_ab['method'],
                    'link_type'    => 'sibling',
                    'reason'       => $sib_reason_ab,
                    'priority'     => $sib_prio_ab,
                    'gsc'          => $gsc_b,
                );
                // Proposer B → A
                $gsc_a = self::get_gsc_weight( $a );
                $sib_prio_ba = self::compute_link_priority( $gsc_a, 'sibling' );
                $sib_reason_ba = 'Lien sémantique entre enfants du même cluster';
                if ( $gsc_a['tag'] ) $sib_reason_ba .= ' · cible : ' . $gsc_a['tag'];
                $anchor_ba = $this->generate_varied_anchor( $nodes[ $a ]['title'], $b, 'sibling', $a );
                $sugs[] = array(
                    'source_id'    => $b,
                    'target_id'    => $a,
                    'source_title' => $nodes[ $b ]['title'],
                    'target_title' => $nodes[ $a ]['title'],
                    'anchor_text'  => $anchor_ba['anchor'],
                    'anchor_method'=> $anchor_ba['method'],
                    'link_type'    => 'sibling',
                    'reason'       => $sib_reason_ba,
                    'priority'     => $sib_prio_ba,
                    'gsc'          => $gsc_a,
                );
                $sibling_count += 2;
            }
        }

        // ── AI Anchor Enhancement : appel batch Haiku pour améliorer les ancres ──
        $child_to_pillar_count = count( array_filter( $sugs, function( $s ) { return ( $s['link_type'] ?? '' ) === 'child_to_pillar'; } ) );
        $pillar_to_child_count = count( array_filter( $sugs, function( $s ) { return ( $s['link_type'] ?? '' ) === 'pillar_to_child'; } ) );
        $sibling_sugs_count    = count( array_filter( $sugs, function( $s ) { return ( $s['link_type'] ?? '' ) === 'sibling'; } ) );

        // ── FUNNEL DIAGNOSTIC LOG ──
        $cluster_diag_name = $cluster['name'] ?? '?';
        hts_add_log(
            'FUNNEL suggest_without_ai ["' . $cluster_diag_name . '"] : '
            . $diag_total_children . ' enfants totaux, '
            . $diag_excluded . ' exclus client, '
            . $diag_tftd_blocked . ' bloqués TFTD, '
            . $diag_cosine_blocked . ' bloqués cosine → '
            . $child_to_pillar_count . ' child→pillar + '
            . $pillar_to_child_count . ' pillar→child + '
            . $sibling_sugs_count . ' siblings = '
            . count( $sugs ) . ' paires totales avant IA',
            'info', 'cocon'
        );

        // Compter les anchor_method AVANT l'IA
        $method_counts_pre_ai = array();
        foreach ( $sugs as $s ) {
            $m = $s['anchor_method'] ?? 'unknown';
            $method_counts_pre_ai[ $m ] = ( $method_counts_pre_ai[ $m ] ?? 0 ) + 1;
        }
        hts_add_log(
            'FUNNEL anchor_methods AVANT IA ["' . $cluster_diag_name . '"] : '
            . implode( ', ', array_map( function( $k, $v ) { return $k . '=' . $v; }, array_keys( $method_counts_pre_ai ), $method_counts_pre_ai ) ),
            'info', 'cocon'
        );

        $sugs = $this->enhance_anchors_with_ai( $sugs, $nodes );

        // Compter les anchor_method APRÈS l'IA
        $method_counts_post_ai = array();
        foreach ( $sugs as $s ) {
            $m = $s['anchor_method'] ?? 'unknown';
            $method_counts_post_ai[ $m ] = ( $method_counts_post_ai[ $m ] ?? 0 ) + 1;
        }
        hts_add_log(
            'FUNNEL anchor_methods APRÈS IA ["' . ( $cluster['name'] ?? '?' ) . '"] : '
            . implode( ', ', array_map( function( $k, $v ) { return $k . '=' . $v; }, array_keys( $method_counts_post_ai ), $method_counts_post_ai ) ),
            'info', 'cocon'
        );

        return array( 'pillar_id' => $pillar_id, 'pillar_title' => $nodes[ $pillar_id ]['title'] ?? '', 'suggestions' => $sugs, 'cluster' => $cluster['name'] );
    }

    // ══════════════════════════════════════════════════════════════════
    //  V3 PIPELINE — Graph → Score → Anchor
    //  @since 2.4.20
    // ══════════════════════════════════════════════════════════════════

    /**
     * STEP 1 — GRAPH : build link matrix for cluster pages.
     * Returns $matrix[$source][$target] = true/false (link exists or not).
     * Pure PHP, 0 API calls.
     *
     * @since 2.4.20
     * @param array $pages   Array of post IDs in the cluster
     * @param array $nodes   Full cocon nodes (with outgoing links)
     * @return array         Matrix[source_id][target_id] = bool
     */
    private function build_link_matrix( $pages, $nodes ) {
        $matrix = array();
        foreach ( $pages as $pid ) {
            $matrix[ $pid ] = array();
            $existing_targets = $this->get_existing_internal_targets( $pid );
            foreach ( $pages as $tid ) {
                if ( $pid === $tid ) continue;
                $matrix[ $pid ][ $tid ] = in_array( $tid, $existing_targets, true );
            }
        }
        return $matrix;
    }

    /**
     * STEP 2 — SCORE : find & prioritize missing link pairs.
     * Each pair gets a score (0-100+) based on structural + semantic signals.
     * Pure PHP + embeddings, 0 API calls.
     *
     * @since 2.4.20
     * @param array    $matrix      Link matrix from build_link_matrix()
     * @param array    $pages       Cluster page IDs
     * @param array    $nodes       Cocon nodes
     * @param int      $pillar_id   Pillar page ID
     * @param array|null $vectors   Embedding vectors (if available)
     * @return array   Scored & sorted missing pairs
     */
    private function score_missing_pairs( $matrix, $pages, $nodes, $pillar_id, $vectors = null ) {
        $has_vectors = ( $vectors && count( $vectors ) >= 3 );

        // Load client decisions
        $decisions = get_option( 'hts_cocon_page_decisions', array() );
        $excluded_pids = array();
        foreach ( $decisions as $dpid => $d ) {
            if ( $d['decision'] === 'exclude' ) $excluded_pids[] = (int) $dpid;
        }

        // Pre-compute incoming counts for orphan detection
        $incoming_count = array();
        foreach ( $pages as $tid ) {
            $incoming_count[ $tid ] = 0;
            foreach ( $matrix as $sid => $targets ) {
                if ( ! empty( $targets[ $tid ] ) ) $incoming_count[ $tid ]++;
            }
        }

        // Pre-compute outgoing counts
        $outgoing_count = array();
        foreach ( $pages as $sid ) {
            $outgoing_count[ $sid ] = 0;
            if ( isset( $matrix[ $sid ] ) ) {
                foreach ( $matrix[ $sid ] as $exists ) {
                    if ( $exists ) $outgoing_count[ $sid ]++;
                }
            }
        }

        // ── DENSITY TARGET ──
        // For N pages: structural minimum = 2×(N-1) pillar↔child bidirectional
        // Target density: 35-45% for a healthy cocon
        // Ideal links per page: 3-5 outgoing, ≥2 incoming
        $n_pages        = count( $pages );
        $total_possible = $n_pages * ( $n_pages - 1 );
        $total_existing = 0;
        foreach ( $matrix as $targets ) {
            foreach ( $targets as $exists ) {
                if ( $exists ) $total_existing++;
            }
        }
        $current_density    = $total_possible > 0 ? $total_existing / $total_possible : 0;
        $target_density     = 0.40; // 40% is the sweet spot
        $target_total_links = (int) ceil( $total_possible * $target_density );
        $links_needed       = max( 0, $target_total_links - $total_existing );

        hts_add_log(
            'FUNNEL v3 density ["' . ( $nodes[ $pillar_id ]['title'] ?? '?' ) . '"] : '
            . 'actuel=' . round( $current_density * 100 ) . '% (' . $total_existing . ' liens), '
            . 'cible=40% (' . $target_total_links . ' liens), '
            . 'besoin=' . $links_needed . ' nouveaux liens',
            'info', 'cocon'
        );

        $scored = array();

        foreach ( $matrix as $sid => $targets ) {
            if ( ! isset( $nodes[ $sid ] ) ) continue;
            if ( in_array( $sid, $excluded_pids ) ) continue;

            foreach ( $targets as $tid => $exists ) {
                if ( $exists ) continue; // Link already present
                if ( ! isset( $nodes[ $tid ] ) ) continue;
                if ( in_array( $tid, $excluded_pids ) ) continue;

                $score   = 0;
                $reasons = array();

                // ── Signal 1 : Pillar connection (40 pts) ──
                if ( $sid === $pillar_id || $tid === $pillar_id ) {
                    $score += 40;
                    $link_type = ( $tid === $pillar_id ) ? 'child_to_pillar' : 'pillar_to_child';
                    $reasons[] = $link_type;
                } else {
                    $link_type = 'sibling';
                }

                // ── Signal 2 : Cosine similarity (0–30 pts) ──
                if ( $has_vectors && isset( $vectors[ $sid ], $vectors[ $tid ] ) ) {
                    $sim = HTS_Embeddings::cosine_similarity( $vectors[ $sid ], $vectors[ $tid ] );
                    $score += round( $sim * 30 );
                    $reasons[] = 'cos=' . round( $sim, 2 );
                    // Extreme floor — pages that slipped into the cluster by accident
                    if ( $sim < 0.10 ) continue;
                }

                // ── Signal 3 : Reciprocity — A→B exists but not B→A (15 pts) ──
                if ( ! empty( $matrix[ $tid ][ $sid ] ) ) {
                    $score += 15;
                    $reasons[] = 'reciprocal';
                }

                // ── Signal 4 : Orphan target — 0 incoming links in cluster (20 pts) ──
                if ( ( $incoming_count[ $tid ] ?? 0 ) === 0 ) {
                    $score += 20;
                    $reasons[] = 'orphan';
                }

                // ── Signal 5 : GSC data (10 pts) ──
                $gsc = self::get_gsc_weight( $tid );
                if ( ( $gsc['impressions'] ?? 0 ) > 100 ) {
                    $score += 10;
                    $reasons[] = 'gsc';
                }

                // ── Signal 6 : Complementarity (keyword Jaccard sweet spot 0.15–0.75) ──
                $jaccard = $this->title_keyword_jaccard( $sid, $tid, $nodes );
                if ( $jaccard >= 0.15 && $jaccard <= 0.75 ) {
                    $score += 10;
                    $reasons[] = 'compl=' . round( $jaccard, 2 );
                } elseif ( $jaccard > 0.75 ) {
                    $score -= 5;
                    $reasons[] = 'overlap=' . round( $jaccard, 2 );
                }

                // Signal 7 : Budget source (skip si saturé)
                if ( class_exists( 'HTS_Cocon_Commander' ) && method_exists( 'HTS_Cocon_Commander', 'get_link_budget_for_post' ) ) {
                    $src_budget = \HTS_Cocon_Commander::get_link_budget_for_post( $sid );
                    if ( $src_budget['budget'] <= 0 ) {
                        continue;
                    }
                }

                $scored[] = array(
                    'source_id'    => $sid,
                    'target_id'    => $tid,
                    'source_title' => $nodes[ $sid ]['title'] ?? '',
                    'target_title' => $nodes[ $tid ]['title'] ?? '',
                    'link_type'    => $link_type,
                    'score'        => $score,
                    'reasons'      => $reasons,
                    'gsc'          => $gsc,
                );
            }
        }

        // Sort by score descending
        usort( $scored, function( $a, $b ) { return $b['score'] - $a['score']; } );

        // ══════════════════════════════════════════════════════════════════
        // STRUCTURAL COVERAGE GUARANTEE
        // Before applying limits, ensure the cocon skeleton is complete.
        // These are non-negotiable links for a functioning cocon.
        // ══════════════════════════════════════════════════════════════════
        $scored = $this->ensure_structural_coverage(
            $scored, $matrix, $pages, $nodes, $pillar_id,
            $incoming_count, $outgoing_count, $excluded_pids
        );

        // Apply per-source limit and per-target limit
        // Structural pairs (forced) bypass the limit
        $scored = $this->apply_pair_limits( $scored, 5, 6 );

        // FUNNEL LOG
        $forced   = count( array_filter( $scored, function( $p ) { return ! empty( $p['forced'] ); } ) );
        $pillar_p = count( array_filter( $scored, function( $p ) { return $p['link_type'] !== 'sibling'; } ) );
        $sibling_p = count( $scored ) - $pillar_p;
        hts_add_log(
            'FUNNEL v3 score ["' . ( $nodes[ $pillar_id ]['title'] ?? '?' ) . '"] : '
            . count( $pages ) . ' pages, '
            . $pillar_p . ' pillar + ' . $sibling_p . ' sibling = '
            . count( $scored ) . ' paires ('
            . $forced . ' forcées structurelles)',
            'info', 'cocon'
        );

        return $scored;
    }

    /**
     * Ensure every page in the cluster has the structural minimum links.
     * Forces pairs that MUST exist for a healthy cocon:
     *  - Pillar → every child (bidirectional)
     *  - Every page gets ≥ 2 incoming links
     *  - Every page has ≥ 1 outgoing link
     *
     * Forced pairs are prepended with high score so they survive limits.
     *
     * @since 2.4.20
     */
    private function ensure_structural_coverage( $scored, $matrix, $pages, $nodes, $pillar_id, $incoming_count, $outgoing_count, $excluded_pids ) {
        // Build lookup of already-scored pairs
        $scored_lookup = array();
        foreach ( $scored as $pair ) {
            $scored_lookup[ $pair['source_id'] . ':' . $pair['target_id'] ] = true;
        }

        $forced = array();
        $children = array_filter( $pages, function( $pid ) use ( $pillar_id ) { return $pid !== $pillar_id; } );

        foreach ( $children as $cid ) {
            if ( in_array( $cid, $excluded_pids ) ) continue;
            if ( ! isset( $nodes[ $cid ] ) ) continue;

            // ── RULE 1: Pillar → child (if not already linked) ──
            if ( empty( $matrix[ $pillar_id ][ $cid ] ) ) {
                $key = $pillar_id . ':' . $cid;
                if ( ! isset( $scored_lookup[ $key ] ) ) {
                    $forced[] = array(
                        'source_id'    => $pillar_id,
                        'target_id'    => $cid,
                        'source_title' => $nodes[ $pillar_id ]['title'] ?? '',
                        'target_title' => $nodes[ $cid ]['title'] ?? '',
                        'link_type'    => 'pillar_to_child',
                        'score'        => 90, // Very high — structural requirement
                        'reasons'      => array( 'pillar_to_child', 'forced_structural' ),
                        'gsc'          => self::get_gsc_weight( $cid ),
                        'forced'       => true,
                    );
                    $scored_lookup[ $key ] = true;
                }
            }

            // ── RULE 2: Child → pillar (if not already linked) ──
            if ( empty( $matrix[ $cid ][ $pillar_id ] ) ) {
                $key = $cid . ':' . $pillar_id;
                if ( ! isset( $scored_lookup[ $key ] ) ) {
                    $forced[] = array(
                        'source_id'    => $cid,
                        'target_id'    => $pillar_id,
                        'source_title' => $nodes[ $cid ]['title'] ?? '',
                        'target_title' => $nodes[ $pillar_id ]['title'] ?? '',
                        'link_type'    => 'child_to_pillar',
                        'score'        => 85,
                        'reasons'      => array( 'child_to_pillar', 'forced_structural' ),
                        'gsc'          => self::get_gsc_weight( $pillar_id ),
                        'forced'       => true,
                    );
                    $scored_lookup[ $key ] = true;
                }
            }
        }

        // ── RULE 3: Every page ≥ 2 incoming links ──
        // Count what's already proposed + existing
        $proposed_incoming = array();
        foreach ( $pages as $pid ) $proposed_incoming[ $pid ] = $incoming_count[ $pid ] ?? 0;
        foreach ( $scored as $pair ) {
            $proposed_incoming[ $pair['target_id'] ] = ( $proposed_incoming[ $pair['target_id'] ] ?? 0 ) + 1;
        }
        foreach ( $forced as $pair ) {
            $proposed_incoming[ $pair['target_id'] ] = ( $proposed_incoming[ $pair['target_id'] ] ?? 0 ) + 1;
        }

        foreach ( $pages as $tid ) {
            if ( in_array( $tid, $excluded_pids ) ) continue;
            if ( ! isset( $nodes[ $tid ] ) ) continue;
            if ( ( $proposed_incoming[ $tid ] ?? 0 ) >= 2 ) continue;

            // Need more incoming links for this page
            $need = 2 - ( $proposed_incoming[ $tid ] ?? 0 );

            // Find best sources (prefer pillar, then highest-outgoing pages)
            $candidates = array();
            foreach ( $pages as $sid ) {
                if ( $sid === $tid ) continue;
                if ( in_array( $sid, $excluded_pids ) ) continue;
                if ( ! empty( $matrix[ $sid ][ $tid ] ) ) continue; // Already linked
                $key = $sid . ':' . $tid;
                if ( isset( $scored_lookup[ $key ] ) ) continue; // Already proposed
                // Score: prefer pillar, then pages with few outgoing proposals
                $cscore = ( $sid === $pillar_id ) ? 80 : 50;
                $candidates[] = array( 'sid' => $sid, 'score' => $cscore );
            }
            usort( $candidates, function( $a, $b ) { return $b['score'] - $a['score']; } );

            for ( $i = 0; $i < min( $need, count( $candidates ) ); $i++ ) {
                $sid = $candidates[ $i ]['sid'];
                $lt  = ( $sid === $pillar_id ) ? 'pillar_to_child' : ( ( $tid === $pillar_id ) ? 'child_to_pillar' : 'sibling' );
                $forced[] = array(
                    'source_id'    => $sid,
                    'target_id'    => $tid,
                    'source_title' => $nodes[ $sid ]['title'] ?? '',
                    'target_title' => $nodes[ $tid ]['title'] ?? '',
                    'link_type'    => $lt,
                    'score'        => 70,
                    'reasons'      => array( 'min_incoming', 'forced_structural' ),
                    'gsc'          => self::get_gsc_weight( $tid ),
                    'forced'       => true,
                );
                $scored_lookup[ $sid . ':' . $tid ] = true;
                $proposed_incoming[ $tid ] = ( $proposed_incoming[ $tid ] ?? 0 ) + 1;
            }
        }

        // ── RULE 4: Every page ≥ 1 outgoing link ──
        $proposed_outgoing = array();
        foreach ( $pages as $pid ) $proposed_outgoing[ $pid ] = $outgoing_count[ $pid ] ?? 0;
        foreach ( $scored as $pair ) {
            $proposed_outgoing[ $pair['source_id'] ] = ( $proposed_outgoing[ $pair['source_id'] ] ?? 0 ) + 1;
        }
        foreach ( $forced as $pair ) {
            $proposed_outgoing[ $pair['source_id'] ] = ( $proposed_outgoing[ $pair['source_id'] ] ?? 0 ) + 1;
        }

        foreach ( $pages as $sid ) {
            if ( in_array( $sid, $excluded_pids ) ) continue;
            if ( ! isset( $nodes[ $sid ] ) ) continue;
            if ( ( $proposed_outgoing[ $sid ] ?? 0 ) >= 1 ) continue;

            // This page has 0 outgoing — force at least one (prefer pillar)
            $best_tid = $pillar_id;
            if ( $sid === $pillar_id ) {
                // Pillar with no outgoing — find first child
                foreach ( $children as $c ) {
                    if ( ! in_array( $c, $excluded_pids ) && empty( $matrix[ $pillar_id ][ $c ] ) ) {
                        $best_tid = $c; break;
                    }
                }
            }
            if ( $best_tid === $sid ) continue;
            $key = $sid . ':' . $best_tid;
            if ( ! empty( $matrix[ $sid ][ $best_tid ] ) || isset( $scored_lookup[ $key ] ) ) continue;

            $lt = ( $best_tid === $pillar_id ) ? 'child_to_pillar' : ( ( $sid === $pillar_id ) ? 'pillar_to_child' : 'sibling' );
            $forced[] = array(
                'source_id'    => $sid,
                'target_id'    => $best_tid,
                'source_title' => $nodes[ $sid ]['title'] ?? '',
                'target_title' => $nodes[ $best_tid ]['title'] ?? '',
                'link_type'    => $lt,
                'score'        => 65,
                'reasons'      => array( 'min_outgoing', 'forced_structural' ),
                'gsc'          => self::get_gsc_weight( $best_tid ),
                'forced'       => true,
            );
            $scored_lookup[ $key ] = true;
        }

        if ( ! empty( $forced ) ) {
            hts_add_log(
                'FUNNEL v3 coverage : ' . count( $forced ) . ' paires structurelles forcées'
                . ' (pillar↔child + orphelins + min incoming/outgoing)',
                'info', 'cocon'
            );
        }

        // Prepend forced pairs (they have high scores so they survive limits)
        return array_merge( $forced, $scored );
    }

    /**
     * Keyword Jaccard similarity between two page titles.
     * @since 2.4.20
     */
    private function title_keyword_jaccard( $pid_a, $pid_b, $nodes ) {
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir' ) ) : array() );

        $extract = function( $title ) use ( $sw ) {
            $words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $title ) );
            return array_unique( array_values( array_filter( $words, function( $w ) use ( $sw ) {
                return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
            } ) ) );
        };

        $a = $extract( $nodes[ $pid_a ]['title'] ?? '' );
        $b = $extract( $nodes[ $pid_b ]['title'] ?? '' );

        if ( empty( $a ) || empty( $b ) ) return 0;

        $inter = count( array_intersect( $a, $b ) );
        $union = count( array_unique( array_merge( $a, $b ) ) );

        return $union > 0 ? $inter / $union : 0;
    }

    /**
     * Apply per-source and per-target limits on scored pairs.
     * @since 2.4.20
     */
    private function apply_pair_limits( $scored, $max_per_source = 5, $max_per_target = 6 ) {
        $src_counts = array();
        $tgt_counts = array();
        $result     = array();

        foreach ( $scored as $pair ) {
            $sid = $pair['source_id'];
            $tid = $pair['target_id'];

            if ( ! isset( $src_counts[ $sid ] ) ) $src_counts[ $sid ] = 0;
            if ( ! isset( $tgt_counts[ $tid ] ) ) $tgt_counts[ $tid ] = 0;

            // Forced structural pairs always pass
            if ( ! empty( $pair['forced'] ) ) {
                $src_counts[ $sid ]++;
                $tgt_counts[ $tid ]++;
                $result[] = $pair;
                continue;
            }

            if ( $src_counts[ $sid ] >= $max_per_source ) continue;
            if ( $tgt_counts[ $tid ] >= $max_per_target ) continue;

            $src_counts[ $sid ]++;
            $tgt_counts[ $tid ]++;
            $result[] = $pair;
        }

        return $result;
    }

    /**
     * Extract H2 sections from a post for AI anchor generation.
     * Returns array of ['heading' => '...', 'text' => '...'] per section.
     * Excludes intro (before first H2) and sub-heading text (H3-H6).
     *
     * @since 2.4.20
     * @param int $post_id
     * @return array
     */
    private function extract_h2_sections_for_ai( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) return array();

        $raw = $post->post_content;
        // Split by H2 (capture the full tag + content)
        $parts = preg_split( '/(<h2[^>]*>.*?<\/h2>)/si', $raw, -1, PREG_SPLIT_DELIM_CAPTURE );

        $sections = array();
        $current_heading = '';
        $current_text    = '';
        $in_section      = false;

        foreach ( $parts as $part ) {
            if ( preg_match( '/<h2[^>]*>(.*?)<\/h2>/si', $part, $m ) ) {
                // Save previous section
                if ( $in_section && mb_strlen( trim( $current_text ) ) >= 30 ) {
                    $sections[] = array(
                        'heading' => trim( wp_strip_all_tags( html_entity_decode( $current_heading, ENT_QUOTES, 'UTF-8' ) ) ),
                        'text'    => mb_substr( trim( $current_text ), 0, 1500 ),
                    );
                }
                $current_heading = $m[1];
                $current_text    = '';
                $in_section      = true;
            } elseif ( $in_section ) {
                // Remove sub-headings text (H3-H6) — should not become anchors
                $clean = preg_replace( '/<h[3-6][^>]*>.*?<\/h[3-6]>/si', ' ', $part );
                $text  = html_entity_decode( wp_strip_all_tags( $clean ), ENT_QUOTES, 'UTF-8' );
                $text  = preg_replace( '/\s+/', ' ', trim( $text ) );
                $current_text .= $text . ' ';
            }
        }
        // Last section
        if ( $in_section && mb_strlen( trim( $current_text ) ) >= 30 ) {
            $sections[] = array(
                'heading' => trim( wp_strip_all_tags( html_entity_decode( $current_heading, ENT_QUOTES, 'UTF-8' ) ) ),
                'text'    => mb_substr( trim( $current_text ), 0, 1500 ),
            );
        }

        return $sections;
    }

    /**
     * STEP 3 — ANCHOR : AI finds anchors + insertion context.
     * One API call per source page. Returns suggestions in the standard format
     * that the Inbox/Workflow engine expects.
     *
     * For EXTRACT anchors: the anchor text exists verbatim in the source article.
     *   → do_apply_link() injects via exact/tag_tolerant/fuzzy match.
     *
     * For GENERATED anchors: the AI also returns a 'bridge' sentence that
     *   integrates the link naturally at the end of the best paragraph.
     *   → do_apply_link() uses contextual_append with the bridge sentence.
     *
     * @since 2.4.20
     * @param array $scored_pairs   From score_missing_pairs()
     * @param array $nodes          Cocon nodes
     * @return array                Suggestions in standard format
     */
    private function ai_contextual_anchors_v3( $scored_pairs, $nodes ) {
        if ( empty( $scored_pairs ) ) return array();

        // Get API keys
        $anthropic_key = '';
        if ( class_exists( 'HTS_Coach' ) && method_exists( 'HTS_Coach', 'get_api_key' ) ) {
            $anthropic_key = \HTS_Coach::get_api_key();
        }
        $openai_key = $this->openai_key ?? '';

        if ( empty( $anthropic_key ) && empty( $openai_key ) ) {
            $this->anchor_log( 'V3 Anchor : pas de clé API → fallback PHP' );
            return array(); // Fallback to old pipeline
        }

        // Budget mensuel IA — max 50K tokens (~$5/mois avec Haiku 4.5)
        $month_key = wp_date( 'Y-m' );
        $usage = get_option( 'hts_cocon_anchor_ai_usage', array() );
        $used_tokens = (int) ( $usage[ $month_key ] ?? 0 );
        $monthly_limit = (int) apply_filters( 'hts_cocon_ai_monthly_token_limit', 50000 );
        if ( $used_tokens >= $monthly_limit ) {
            $this->anchor_log( 'V3 Anchor : budget mensuel atteint (' . $used_tokens . '/' . $monthly_limit . ' tokens) → fallback PHP' );
            return array();
        }

        // Group pairs by source page
        $by_source = array();
        foreach ( $scored_pairs as $pair ) {
            $sid = $pair['source_id'];
            if ( ! isset( $by_source[ $sid ] ) ) $by_source[ $sid ] = array();
            $by_source[ $sid ][] = $pair;
        }

        // Compute cluster-wide word frequency for distinctive keyword extraction
        $cluster_pages = array();
        foreach ( $scored_pairs as $pair ) {
            $cluster_pages[ $pair['source_id'] ] = true;
            $cluster_pages[ $pair['target_id'] ] = true;
        }
        $cluster_pages = array_keys( $cluster_pages );
        $cluster_word_freq = $this->compute_cluster_word_freq( $cluster_pages, $nodes );
        $cluster_size = count( $cluster_pages );

        $all_suggestions   = array();
        $global_anchors    = array(); // Cross-source dedup
        $total_ai_calls    = 0;
        $total_ai_results  = 0;

        foreach ( $by_source as $source_id => $targets ) {
            // Extract H2 sections
            $sections = $this->extract_h2_sections_for_ai( $source_id );
            if ( empty( $sections ) ) {
                // No H2 structure — use full content as single section
                $post = get_post( $source_id );
                if ( $post && ! empty( $post->post_content ) ) {
                    $text = html_entity_decode( wp_strip_all_tags( $post->post_content ), ENT_QUOTES, 'UTF-8' );
                    $text = preg_replace( '/\s+/', ' ', trim( $text ) );
                    $sections = array( array( 'heading' => '', 'text' => mb_substr( $text, 0, 3000 ) ) );
                } else {
                    continue;
                }
            }

            // Build target briefs
            $target_briefs = array();
            foreach ( $targets as $idx => $pair ) {
                $tid = $pair['target_id'];
                $target_briefs[] = array(
                    'idx'       => $idx,
                    'target_id' => $tid,
                    'title'     => $nodes[ $tid ]['title'] ?? '',
                    'summary'   => mb_substr( $this->get_page_summary( $tid ), 0, 200 ),
                    'link_type' => $pair['link_type'],
                    'reasons'   => $pair['reasons'],
                    'score'     => $pair['score'],
                    'gsc'       => $pair['gsc'] ?? array(),
                );
            }

            // Build prompt
            $prompt = $this->build_v3_prompt(
                $nodes[ $source_id ]['title'] ?? '',
                $sections,
                $target_briefs,
                $cluster_word_freq,
                $cluster_size
            );

            // Call AI (OpenAI first = cheaper for long context, fallback Anthropic)
            $ai_result = null;
            $total_ai_calls++;

            if ( ! empty( $openai_key ) ) {
                $ai_result = $this->call_anchor_ai_openai( $openai_key, $prompt['system'], $prompt['user'], 'gpt-4.1-mini' );
            }
            if ( ! $ai_result && ! empty( $anthropic_key ) ) {
                $ai_result = $this->call_anchor_ai_anthropic( $anthropic_key, $prompt['system'], $prompt['user'] );
            }

            if ( ! $ai_result || ! is_array( $ai_result ) ) {
                $this->anchor_log( 'V3 Anchor : pas de réponse IA pour source=' . $source_id . ' — fallback PHP pour ' . count( $targets ) . ' cibles' );
                // Fallback : PHP anchors for these pairs
                foreach ( $targets as $pair ) {
                    $php_anchor = $this->generate_varied_anchor( $pair['target_title'], $source_id, $pair['link_type'], $pair['target_id'] );
                    if ( $php_anchor['method'] === 'fallback' ) continue; // Skip raw title truncation
                    $all_suggestions[] = $this->build_v3_suggestion( $pair, $php_anchor['anchor'], $php_anchor['method'], 'extract', '' );
                }
                continue;
            }

            // Process AI results
            $this->anchor_log( 'V3 Anchor : source="' . mb_substr( $nodes[ $source_id ]['title'] ?? '', 0, 40 ) . '" → ' . count( $ai_result ) . ' résultats IA' );

            foreach ( $ai_result as $pair_id => $item ) {
                $pair_id = (int) $pair_id;
                if ( ! isset( $target_briefs[ $pair_id ] ) ) continue;

                $brief = $target_briefs[ $pair_id ];
                $pair  = $targets[ $brief['idx'] ];

                $anchor  = '';
                $ai_type = 'extract';
                $bridge  = '';
                if ( is_array( $item ) ) {
                    $anchor  = trim( $item['anchor'] ?? '' );
                    $ai_type = trim( $item['type'] ?? 'extract' );
                    $bridge  = trim( $item['bridge'] ?? '' );
                } elseif ( is_string( $item ) ) {
                    $anchor = trim( $item );
                }

                if ( ! in_array( $ai_type, array( 'extract', 'generated' ), true ) ) {
                    $ai_type = 'extract';
                }

                // ── AI confidence score ──
                $confidence = 'medium';
                if ( is_array( $item ) && ! empty( $item['confidence'] ) ) {
                    $confidence = trim( $item['confidence'] );
                }
                if ( ! in_array( $confidence, array( 'high', 'medium', 'low' ), true ) ) {
                    $confidence = 'medium';
                }

                // ── Validation — minimal, trust the AI ──
                if ( empty( $anchor ) ) continue;

                // Clean quotes and punctuation
                $anchor = str_replace( array( '"', "\xe2\x80\x9c", "\xe2\x80\x9d", "\xe2\x80\x9e", '«', '»', "\xC2\xAB", "\xC2\xBB" ), '', $anchor );
                $anchor = trim( $anchor, " \t.,;:!?-–—" );

                if ( mb_strlen( $anchor ) < 5 || mb_strlen( $anchor ) > 80 ) continue;

                // Dedup (cross-source)
                $anchor_lower = mb_strtolower( $anchor );
                if ( isset( $global_anchors[ $anchor_lower ] ) ) continue;

                // Anti-title-brut (>70% similarity = just the title, not useful)
                $target_title_lower = mb_strtolower( trim( $brief['title'] ) );
                if ( $target_title_lower && mb_strlen( $anchor_lower ) >= 5 ) {
                    $sim_ratio = similar_text( $anchor_lower, $target_title_lower ) / max( mb_strlen( $anchor_lower ), 1 );
                    if ( $sim_ratio > 0.70 ) continue;
                }

                // Anti-hallucination STRICT — l'ancre extract DOIT exister verbatim dans le contenu source
                if ( $ai_type === 'extract' ) {
                    $source_post = get_post( $source_id );
                    if ( $source_post && ! empty( $source_post->post_content ) ) {
                        $source_text_raw = html_entity_decode( wp_strip_all_tags( $source_post->post_content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                        $source_text = mb_strtolower( $source_text_raw );
                        if ( mb_strpos( $source_text, $anchor_lower ) === false ) {
                            // L'ancre n'existe PAS verbatim → REJETER (ne pas reclasser en generated)
                            $this->anchor_log( 'V3 REJET ancre halluccinée : "' . mb_substr( $anchor, 0, 50 ) . '" non trouvée dans #' . $source_id );
                            continue;
                        }
                        // Vérifier aussi dans le HTML original (pour l'application)
                        if ( mb_stripos( $source_post->post_content, $anchor ) === false ) {
                            // Existe en texte brut mais pas dans le HTML (entités, balises) → aussi rejeter
                            $this->anchor_log( 'V3 REJET ancre HTML mismatch : "' . mb_substr( $anchor, 0, 50 ) . '" trouvée en texte brut mais pas dans le HTML' );
                            continue;
                        }
                    }
                }


                // ── NO PHP keyword filter — the AI is the semantic filter ──
                // The old anchor_matches_target() checked literal keywords which:
                // - Rejected good anchors ("silos thématiques" for "Structure cocon")
                // - Accepted bad anchors ("outil de cocon" for "Définition")
                // The AI already understands semantic relevance. We trust its judgment
                // combined with its confidence score.

                // Skip low confidence (log for debug)
                if ( $confidence === 'low' ) {
                    $this->anchor_log(
                        'V3 skip low-confidence : "' . mb_substr( $anchor, 0, 40 )
                        . '" → cible "' . mb_substr( $brief['title'], 0, 40 ) . '"'
                    );
                    continue;
                }

                // Validate bridge for generated — anchor must appear in bridge text
                if ( $ai_type === 'generated' && ! empty( $bridge ) ) {
                    if ( mb_stripos( $bridge, $anchor ) === false ) {
                        $bridge = '';
                    }
                }

                $global_anchors[ $anchor_lower ] = true;
                $total_ai_results++;

                $all_suggestions[] = $this->build_v3_suggestion( $pair, $anchor, 'ai', $ai_type, $bridge );
            }

            // For targets that got no AI result, fallback to PHP anchor
            // ONLY keep contextual extracts — if the AI couldn't find an anchor,
            // title-based PHP methods (semantic_title, partial_title) produce noise
            $ai_covered_targets = array();
            foreach ( $all_suggestions as $s ) {
                if ( (int) $s['source_id'] === $source_id ) {
                    $ai_covered_targets[] = (int) $s['target_id'];
                }
            }
            foreach ( $targets as $pair ) {
                if ( in_array( (int) $pair['target_id'], $ai_covered_targets, true ) ) continue;
                $php_anchor = $this->generate_varied_anchor( $pair['target_title'], $source_id, $pair['link_type'], $pair['target_id'] );
                // Only contextual extracts — skip fallback AND title-based methods
                if ( ! in_array( $php_anchor['method'], array( 'contextual' ), true ) ) {
                    $this->anchor_log( 'V3 PHP skip non-contextual : method=' . $php_anchor['method'] . ' pour cible "' . mb_substr( $pair['target_title'], 0, 40 ) . '"' );
                    continue;
                }
                // Quality gate: reject list-like anchors (commas = keyword stuffing)
                $php_anchor_text = $php_anchor['anchor'];
                if ( substr_count( $php_anchor_text, ',' ) >= 2 ) {
                    $this->anchor_log( 'V3 PHP skip list-anchor : "' . mb_substr( $php_anchor_text, 0, 40 ) . '" (contains commas)' );
                    continue;
                }
                // Quality gate: reject anchors with slashes (SEO/SXO patterns)
                if ( strpos( $php_anchor_text, '/' ) !== false ) {
                    $this->anchor_log( 'V3 PHP skip slash-anchor : "' . mb_substr( $php_anchor_text, 0, 40 ) . '"' );
                    continue;
                }
                $anchor_lower = mb_strtolower( $php_anchor_text );
                if ( isset( $global_anchors[ $anchor_lower ] ) ) continue;
                $global_anchors[ $anchor_lower ] = true;
                $all_suggestions[] = $this->build_v3_suggestion( $pair, $php_anchor_text, $php_anchor['method'], 'extract', '' );
            }
        }

        // ══════════════════════════════════════════════════════════════════
        // GENERATED+BRIDGE FALLBACK — pour les paires sans aucune suggestion
        // Si ni l'IA ni le PHP extract n'ont trouvé d'ancre, créer un
        // "generated" avec bridge pour que le client ait au moins 1 proposition
        // ══════════════════════════════════════════════════════════════════
        $covered_pairs = array();
        foreach ( $all_suggestions as $s ) {
            $covered_pairs[ (int) $s['source_id'] . '_' . (int) $s['target_id'] ] = true;
        }
        foreach ( $scored_pairs as $pair ) {
            $pk = (int) $pair['source_id'] . '_' . (int) $pair['target_id'];
            if ( isset( $covered_pairs[ $pk ] ) ) continue;

            $target_title = $nodes[ $pair['target_id'] ]['title'] ?? '';
            $target_kw    = $target_title;
            $anchor_text  = mb_substr( $target_title, 0, 40 );
            $bridge       = $this->build_orphan_bridge( $target_title, $anchor_text );

            if ( ! empty( $bridge ) && ! empty( $anchor_text ) ) {
                $all_suggestions[] = $this->build_v3_suggestion( $pair, $anchor_text, 'php_fallback', 'generated', $bridge );
                $this->anchor_log( 'V3 generated fallback : source #' . $pair['source_id'] . ' → cible "' . mb_substr( $target_title, 0, 40 ) . '" avec bridge' );
            }
        }

        // ══════════════════════════════════════════════════════════════════
        // ORPHAN LAST RESORT — after ALL suggestions are built
        // If an orphan page has ZERO suggestions targeting it (neither AI
        // nor PHP found anything), generate a contextual bridge link.
        // This is the only place where "Pour approfondir" pattern is allowed,
        // and ONLY for orphans, max 1 per article.
        // ══════════════════════════════════════════════════════════════════
        $all_target_ids = array_unique( array_map( function( $s ) { return (int) $s['target_id']; }, $all_suggestions ) );

        // Identify orphan pages in cluster
        $cluster_pages = array();
        foreach ( $scored_pairs as $p ) {
            $cluster_pages[ $p['source_id'] ] = true;
            $cluster_pages[ $p['target_id'] ] = true;
        }
        $orphan_targets_missing = array();
        foreach ( array_keys( $cluster_pages ) as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            if ( empty( $nodes[ $pid ]['is_orphan'] ) && ( $nodes[ $pid ]['role'] ?? '' ) !== 'orpheline' ) continue;
            if ( in_array( $pid, $all_target_ids, true ) ) continue;
            $orphan_targets_missing[] = $pid;
        }

        if ( ! empty( $orphan_targets_missing ) ) {
            $this->anchor_log( 'V3 orphan-last-resort : ' . count( $orphan_targets_missing ) . ' orphelin(s) sans aucune suggestion → génération bridge' );

            foreach ( $orphan_targets_missing as $opid ) {
                $orphan_title   = $nodes[ $opid ]['title'] ?? '';
                $orphan_cluster = $nodes[ $opid ]['cluster'] ?? '';

                // Sprint 6.2d: cluster guard — only link from same-cluster sources
                // If orphan has no cluster, skip entirely (cross-topic link would be harmful)
                if ( empty( $orphan_cluster ) ) {
                    $this->anchor_log( 'V3 orphan-last-resort SKIP : "' . mb_substr( $orphan_title, 0, 40 ) . '" — pas de cluster assigné' );
                    continue;
                }

                // Build a clean descriptive anchor from the target title (3-5 significant words)
                $clean_anchor = $this->build_orphan_anchor( $orphan_title );
                // Build a natural bridge sentence
                $bridge = $this->build_orphan_bridge( $orphan_title, $clean_anchor );

                // Find the best source page IN THE SAME CLUSTER
                $best_source = 0;
                $best_out = -1;
                foreach ( array_keys( $cluster_pages ) as $sid ) {
                    if ( $sid === $opid ) continue;
                    if ( ! isset( $nodes[ $sid ] ) ) continue;
                    if ( ! empty( $nodes[ $sid ]['is_orphan'] ) ) continue;
                    // Sprint 6.2d: only same-cluster sources
                    $sid_cluster = $nodes[ $sid ]['cluster'] ?? '';
                    if ( $sid_cluster !== $orphan_cluster ) continue;

                    $out = (int) ( $nodes[ $sid ]['out_count_semantic'] ?? $nodes[ $sid ]['out_count'] ?? 0 );
                    $boost = ( ! empty( $nodes[ $sid ]['is_pillar'] ) ) ? 100 : 0;
                    if ( ( $out + $boost ) > $best_out ) {
                        $best_out = $out + $boost;
                        $best_source = $sid;
                    }
                }

                if ( $best_source <= 0 ) {
                    $this->anchor_log( 'V3 orphan-last-resort SKIP : "' . mb_substr( $orphan_title, 0, 40 ) . '" — aucune source dans le cluster "' . mb_substr( $orphan_cluster, 0, 30 ) . '"' );
                    continue;
                }

                if ( ! empty( $clean_anchor ) ) {
                    $all_suggestions[] = array(
                        'source_id'       => $best_source,
                        'target_id'       => $opid,
                        'source_title'    => $nodes[ $best_source ]['title'] ?? '',
                        'target_title'    => $orphan_title,
                        'anchor_text'     => $clean_anchor,
                        'anchor_method'   => 'ai',
                        'anchor_type'     => 'generated',
                        'anchor_sentence' => '',
                        'anchor_bridge'   => $bridge,
                        'link_type'       => ! empty( $nodes[ $best_source ]['is_pillar'] ) ? 'pillar_to_child' : 'sibling',
                        'reason'          => 'page orpheline — lien de dernier recours',
                        'priority'        => 'high',
                        'gsc'             => self::get_gsc_weight( $opid ),
                        'forced'          => true,
                        'orphan_rescue'   => true,
                    );

                    $this->anchor_log( 'V3 orphan-last-resort : "' . mb_substr( $orphan_title, 0, 40 ) . '" ← lien depuis "' . mb_substr( $nodes[ $best_source ]['title'] ?? '', 0, 40 ) . '" avec ancre "' . $clean_anchor . '"' );
                }
            }
        }

        $this->anchor_log( 'V3 Anchor total : ' . $total_ai_calls . ' appels IA, ' . $total_ai_results . ' ancres IA + ' . ( count( $all_suggestions ) - $total_ai_results ) . ' fallback PHP = ' . count( $all_suggestions ) . ' suggestions' );

        return $all_suggestions;
    }

    /**
     * Build a suggestion in the standard format expected by Inbox/Workflow.
     * @since 2.4.20
     */
    private function build_v3_suggestion( $pair, $anchor, $method, $type, $bridge ) {
        $priority = 'medium';
        if ( ( $pair['score'] ?? 0 ) > 60 ) $priority = 'high';
        elseif ( ( $pair['score'] ?? 0 ) < 25 ) $priority = 'low';

        $reason_parts = array();
        if ( $pair['link_type'] === 'child_to_pillar' ) $reason_parts[] = 'Enfant → pilier';
        elseif ( $pair['link_type'] === 'pillar_to_child' ) $reason_parts[] = 'Pilier → enfant';
        else $reason_parts[] = 'entre articles liés';
        if ( ! empty( $pair['reasons'] ) ) {
            $reason_parts[] = implode( ', ', $pair['reasons'] );
        }

        return array(
            'source_id'       => $pair['source_id'],
            'target_id'       => $pair['target_id'],
            'source_title'    => $pair['source_title'],
            'target_title'    => $pair['target_title'],
            'anchor_text'     => $anchor,
            'anchor_method'   => $method,
            'anchor_type'     => $type,
            'anchor_sentence' => '',
            'anchor_bridge'   => $bridge,
            'link_type'       => $pair['link_type'],
            'reason'          => implode( ' · ', $reason_parts ),
            'priority'        => $priority,
            'gsc'             => $pair['gsc'] ?? array(),
        );
    }

    /**
     * Build a clean, descriptive anchor from a page title for orphan last resort.
     * Extracts 3-5 significant words, removes stop words and meta-words.
     * @since 2.4.20
     */
    private function build_orphan_anchor( $title ) {
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir','meilleurs','meilleur','meilleures','méthode','terrain','secrets','seo','pas' ) ) : array() );

        // Clean title — remove everything after ':'
        $clean = preg_replace( '/\s*[:–—|].+$/u', '', $title );
        $words = preg_split( '/[\s\-\/]+/u', mb_strtolower( trim( $clean ) ) );
        $significant = array_values( array_filter( $words, function( $w ) use ( $sw ) {
            return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
        } ) );

        // Take 3-5 words max
        $significant = array_slice( $significant, 0, 5 );

        if ( empty( $significant ) ) {
            return mb_substr( $title, 0, 40 );
        }

        return implode( ' ', $significant );
    }

    /**
     * Build a natural bridge sentence for orphan last resort.
     * This is the ONLY place where a "pour approfondir" pattern is acceptable.
     * @since 2.4.20
     */
    private function build_orphan_bridge( $title, $anchor ) {
        // Varied bridge patterns to avoid repetition
        $patterns = array(
            'Nous avons détaillé %s dans un article dédié.',
            'Pour approfondir ce point, consultez notre article sur %s.',
            'Ce sujet est développé en détail dans notre guide sur %s.',
        );
        // Pick pattern based on title hash for consistency
        $idx = crc32( $title ) % count( $patterns );
        return sprintf( $patterns[ $idx ], $anchor );
    }

    /**
     * Build the v3 prompt for Haiku: contextual anchors per source page.
     * @since 2.4.20
     */
    private function build_v3_prompt( $source_title, $sections, $target_briefs, $cluster_word_freq = array(), $cluster_size = 1 ) {
        // Build sections text (cap total at ~4000 chars)
        $sections_text = '';
        $budget = 4000;
        foreach ( $sections as $i => $sec ) {
            $num = $i + 1;
            $heading = ! empty( $sec['heading'] ) ? $sec['heading'] : 'Section ' . $num;
            $text = mb_substr( $sec['text'], 0, min( 1200, (int) ( $budget / max( 1, count( $sections ) ) ) ) );
            $sections_text .= "[Section {$num} — {$heading}]\n{$text}\n\n";
            $budget -= mb_strlen( $text ) + 50;
            if ( $budget <= 0 ) break;
        }

        // Build targets list with DISTINCTIVE keywords
        $targets_text = '';
        foreach ( $target_briefs as $i => $t ) {
            $targets_text .= $i . '. "' . mb_substr( $t['title'], 0, 80 ) . '"';
            if ( ! empty( $t['summary'] ) ) {
                $targets_text .= "\n   Sujet : " . mb_substr( $t['summary'], 0, 200 );
            }
            // Show distinctive keywords as HINT (not hard rule — AI decides semantically)
            $kw = $this->extract_distinctive_keywords( $t['title'], $cluster_word_freq, $cluster_size );
            if ( ! empty( $kw ) ) {
                $targets_text .= "\n   Mots-clés distinctifs : " . implode( ', ', array_slice( $kw, 0, 4 ) );
            }
            $targets_text .= "\n";
        }

        $system = 'Tu es un expert SEO français spécialisé en maillage interne et cocons sémantiques.

MISSION : Pour CHAQUE page cible listée ci-dessous, tu DOIS proposer une ancre de lien à insérer dans la page source. Aucune cible ne peut rester sans proposition.

PRINCIPE CLÉ :
L' . "\x27" . 'ancre doit permettre au LECTEUR de comprendre CE QU' . "\x27" . 'IL VA TROUVER en cliquant.
L' . "\x27" . 'ancre doit être SÉMANTIQUEMENT liée au SUJET de la page cible.
Ce n' . "\x27" . 'est PAS un match de mots-clés — c' . "\x27" . 'est une compréhension du CONCEPT.

EXEMPLES DE COMPRÉHENSION SÉMANTIQUE :
Cible : "Structure cocon sémantique"
"architecture en silos thématiques" → parle de STRUCTURE (même sans le mot "structure")
"organiser vos pages en arborescence" → c' . "\x27" . 'est de la structure
"outil de cocon sémantique" → parle d' . "\x27" . 'outils, pas de structure

Cible : "Avantages d' . "\x27" . 'un cocon sémantique"
"les gains SEO d' . "\x27" . 'une architecture thématique" → parle d' . "\x27" . 'avantages/bénéfices
"améliorer votre positionnement grâce au cocon" → c' . "\x27" . 'est un avantage
"créer un cocon sémantique" → parle de création, pas des avantages

Cible : "Autorité thématique"
"renforcer votre expertise sur ce sujet" → concept d' . "\x27" . 'autorité
"devenir la référence thématique" → c' . "\x27" . 'est l' . "\x27" . 'autorité
"maillage interne cohérent" → parle de liens, pas d' . "\x27" . 'autorité

DEUX MODES :

MODE EXTRACT (préféré, type:"extract") :
- Trouve dans le CONTENU SOURCE un passage EXACT (2-6 mots) qui ÉVOQUE le sujet de la cible
- RÈGLE ABSOLUE : le passage DOIT être une CITATION EXACTE du texte source, copié MOT POUR MOT
- NE REFORMULE JAMAIS — copie-colle tel quel depuis le texte
- NE CHANGE JAMAIS singulier/pluriel, conjugaison, accord, majuscule
- VÉRIFIE que ta phrase existe EXACTEMENT dans le texte source avant de la proposer
- Si tu ne trouves aucun passage pertinent dans le texte, utilise le mode GENERATED
- La relation sémantique avec la cible peut être implicite (pas besoin de mots identiques)

MODE GENERATED (obligatoire si aucun extrait pertinent, type:"generated") :
- Crée une ancre de 3-6 mots qui DÉCRIT le sujet de la page cible
- Fournis OBLIGATOIREMENT un "bridge" : phrase complète de 12-25 mots qui :
  * S' . "\x27" . 'insère naturellement à la fin d' . "\x27" . 'un paragraphe existant
  * Contient l' . "\x27" . 'ancre intégrée dans la phrase (pas collée à la fin)
  * Apporte une transition logique vers le sujet de la cible
  Exemples de bridges :
  "Cette organisation en silos renforce considérablement les avantages SEO de votre cocon sémantique."
  "L' . "\x27" . 'autorité thématique de votre site dépend directement de cette architecture de contenus."

CONFIANCE :
Pour chaque ancre, indique ta confiance dans la pertinence sémantique ancre↔cible :
- "high" : l' . "\x27" . 'ancre décrit clairement le sujet de la cible
- "medium" : l' . "\x27" . 'ancre est liée mais indirectement
- "low" : doute sur la pertinence, ancre de secours

RÈGLES TECHNIQUES :
- 2 à 6 mots pour l' . "\x27" . 'ancre, français naturel, grammaticalement correct
- Chaque ancre UNIQUE dans le batch
- NE PAS recopier le titre brut de la page cible
- NE PAS utiliser "en savoir plus", "cliquez ici", "découvrez", "pour aller plus loin"
- NE JAMAIS retourner anchor:"" — tu DOIS proposer pour CHAQUE cible

JSON STRICT :
{"results":{"0":{"anchor":"texte","type":"extract","bridge":"","confidence":"high"},"1":{"anchor":"texte","type":"generated","bridge":"Phrase complète intégrant texte naturellement.","confidence":"medium"}}}';

        $user = 'PAGE SOURCE : "' . mb_substr( $source_title, 0, 80 ) . '"

CONTENU DE LA PAGE SOURCE :
' . $sections_text . '
PAGES CIBLES À LIER (tu DOIS proposer une ancre pour CHAQUE cible) :
' . $targets_text . '
Pour chaque cible, cherche d' . "\x27" . 'abord un extrait du contenu source qui ÉVOQUE le sujet de la cible (même indirectement). Si aucun passage pertinent, génère une ancre + bridge OBLIGATOIREMENT.';

        return array( 'system' => $system, 'user' => $user );
    }

    /**
     * Extract DISTINCTIVE keywords from a page title — words that distinguish
     * this page from other pages in the same cluster.
     *
     * In a cluster where all titles share "cocon sémantique", those words are NOT
     * distinctive. The distinctive word for "Structure cocon sémantique" is "structure".
     * For "Avantages d'un cocon sémantique" it's "avantages".
     *
     * @since 2.4.20
     * @param string $title              Target page title
     * @param array  $cluster_word_freq  Word → count of titles containing it (from compute_cluster_word_freq)
     * @param int    $cluster_size       Total number of pages in cluster
     * @return array                     Distinctive keywords (appear in ≤ 30% of cluster titles)
     */
    private function extract_distinctive_keywords( $title, $cluster_word_freq, $cluster_size ) {
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir','meilleurs','meilleur','meilleures','méthode','terrain','secrets' ) ) : array() );
        $words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $title ) );
        $all_kw = array_unique( array_values( array_filter( $words, function( $w ) use ( $sw ) {
            return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
        } ) ) );

        // A word is distinctive if it appears in ≤ 30% of cluster titles
        $threshold = max( 2, (int) ceil( $cluster_size * 0.30 ) );
        $distinctive = array();
        foreach ( $all_kw as $w ) {
            $freq = $cluster_word_freq[ $w ] ?? 0;
            if ( $freq <= $threshold ) {
                $distinctive[] = $w;
            }
        }

        // If ALL words are shared (extreme case), return the least common ones
        if ( empty( $distinctive ) && ! empty( $all_kw ) ) {
            usort( $all_kw, function( $a, $b ) use ( $cluster_word_freq ) {
                return ( $cluster_word_freq[ $a ] ?? 0 ) - ( $cluster_word_freq[ $b ] ?? 0 );
            } );
            $distinctive = array_slice( $all_kw, 0, 2 ); // Take 2 least common
        }

        return $distinctive;
    }

    /**
     * Compute word frequency across all cluster page titles.
     * Returns word → number of titles that contain this word.
     *
     * @since 2.4.20
     * @param array $pages  Page IDs in cluster
     * @param array $nodes  Cocon nodes
     * @return array        word => count
     */
    private function compute_cluster_word_freq( $pages, $nodes ) {
        $sw = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir','meilleurs','meilleur','meilleures','méthode','terrain','secrets' ) ) : array() );

        $freq = array();
        foreach ( $pages as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', mb_strtolower( $nodes[ $pid ]['title'] ?? '' ) );
            $unique_words = array_unique( array_values( array_filter( $words, function( $w ) use ( $sw ) {
                return mb_strlen( $w ) >= 3 && ! isset( $sw[ $w ] );
            } ) ) );
            foreach ( $unique_words as $w ) {
                $freq[ $w ] = ( $freq[ $w ] ?? 0 ) + 1;
            }
        }
        return $freq;
    }

    /**
     * Check if an anchor is relevant to a target page using distinctive keywords.
     * Uses SUBSTRING matching to handle French morphology:
     * "structurer" contains "structure", "maillage" contains "maill", etc.
     *
     * @since 2.4.20
     * @param string $anchor_lower       Lowercase anchor text
     * @param array  $distinctive_kw     Distinctive keywords of the target
     * @return bool                      True if anchor contains at least 1 distinctive keyword
     */
    private function anchor_matches_target( $anchor_lower, $distinctive_kw ) {
        foreach ( $distinctive_kw as $kw ) {
            // Direct: keyword found as substring in anchor
            if ( mb_strpos( $anchor_lower, $kw ) !== false ) return true;
            // Reverse: anchor word found as substring in keyword (handles "struct" in "structure")
            // Check each anchor word against keyword with min 4 chars shared root
            $anchor_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', $anchor_lower );
            foreach ( $anchor_words as $aw ) {
                if ( mb_strlen( $aw ) < 4 ) continue;
                // Shared root: first 4+ chars match
                $root_len = min( mb_strlen( $kw ), mb_strlen( $aw ), 6 );
                if ( $root_len >= 4 && mb_substr( $kw, 0, $root_len ) === mb_substr( $aw, 0, $root_len ) ) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Améliore les ancres d'un batch de suggestions via un appel IA unique (Haiku).
     *
     * Un seul appel pour tout le cluster. Si pas de clé API ou erreur → on garde
     * les ancres regex existantes comme fallback.
     *
     * Coût estimé : ~400 input tokens + ~300 output tokens = ~$0.0003 par cluster.
     *
     * @since 2.4.10
     * @param array $sugs     Suggestions avec anchor_text et anchor_method.
     * @param array $nodes    Nodes du cocon (pour les titres).
     * @return array          Suggestions avec ancres améliorées.
     */
    private function enhance_anchors_with_ai( $sugs, $nodes ) {
        if ( empty( $sugs ) ) return $sugs;

        try {
            return $this->do_enhance_anchors_with_ai( $sugs, $nodes );
        } catch ( \Throwable $e ) {
            $this->anchor_log( 'Anchor AI exception : ' . $e->getMessage() );
            return $sugs; // Erreur → fallback regex
        }
    }

    /**
     * Log pour le système Anchor AI — écrit dans hts_cocon_logs (Cocon Commander)
     * ET dans hts_activity_logs (Dashboard).
     */
    private function anchor_log( $message ) {
        // 1. Cocon Commander logs (visible dans onglets Tout/🔗)
        $logs = get_option( 'hts_cocon_logs', array() );
        $logs[] = array(
            'time'    => current_time( 'mysql' ),
            'type'    => 'anchor_ai',
            'message' => mb_substr( $message, 0, 500 ),
            'data'    => array(),
        );
        if ( count( $logs ) > 200 ) $logs = array_slice( $logs, -200 );
        update_option( 'hts_cocon_logs', $logs, false );

        // 2. Dashboard activity logs
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( $message, 'info', 'cocon' );
        }
    }

    /**
     * Get a short summary/description of a page for contextual anchor AI.
     * Priority: HTS meta description → Yoast/RankMath meta → WP excerpt → first 200 words after H1.
     * Cached in post_meta '_hts_page_summary_cache' to avoid regeneration.
     * @since 2.4.13
     * @param int $post_id
     * @return string Summary (150-250 chars) or empty string
     */
    private function get_page_summary( $post_id ) {
        // 1) Check cache first
        $cached = get_post_meta( $post_id, '_hts_page_summary_cache', true );
        if ( ! empty( $cached ) && is_array( $cached ) && ! empty( $cached['text'] ) ) {
            // Cache valid for 30 days
            if ( ( $cached['ts'] ?? 0 ) > ( time() - 30 * DAY_IN_SECONDS ) ) {
                return $cached['text'];
            }
        }

        $summary = '';

        // 2) HTS meta description
        $hts_desc = get_post_meta( $post_id, '_hts_meta_description', true );
        if ( ! empty( $hts_desc ) && mb_strlen( $hts_desc ) >= 30 ) {
            $summary = mb_substr( trim( $hts_desc ), 0, 300 );
        }

        // 3) Yoast meta description
        if ( empty( $summary ) ) {
            $yoast_desc = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );
            if ( ! empty( $yoast_desc ) && mb_strlen( $yoast_desc ) >= 30 ) {
                $summary = mb_substr( trim( $yoast_desc ), 0, 300 );
            }
        }

        // 4) Rank Math meta description
        if ( empty( $summary ) ) {
            $rm_desc = get_post_meta( $post_id, 'rank_math_description', true );
            if ( ! empty( $rm_desc ) && mb_strlen( $rm_desc ) >= 30 ) {
                $summary = mb_substr( trim( $rm_desc ), 0, 300 );
            }
        }

        // 5) SEOPress meta description
        if ( empty( $summary ) ) {
            $sp_desc = get_post_meta( $post_id, '_seopress_titles_desc', true );
            if ( ! empty( $sp_desc ) && mb_strlen( $sp_desc ) >= 30 ) {
                $summary = mb_substr( trim( $sp_desc ), 0, 300 );
            }
        }

        // 6) WP excerpt
        if ( empty( $summary ) ) {
            $post = get_post( $post_id );
            if ( $post && ! empty( $post->post_excerpt ) && mb_strlen( $post->post_excerpt ) >= 30 ) {
                $summary = mb_substr( trim( $post->post_excerpt ), 0, 300 );
            }
        }

        // 7) Fallback: first ~200 words of content (after H1, before or including first H2)
        if ( empty( $summary ) ) {
            $post = $post ?? get_post( $post_id );
            if ( $post && ! empty( $post->post_content ) ) {
                $content = $post->post_content;
                // Remove H1 if present
                $content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $content );
                // Strip HTML, decode entities
                $text = html_entity_decode( wp_strip_all_tags( $content ), ENT_QUOTES, 'UTF-8' );
                $text = preg_replace( '/\s+/', ' ', trim( $text ) );
                // Take first ~200 words
                $words = explode( ' ', $text );
                $summary = implode( ' ', array_slice( $words, 0, 200 ) );
                $summary = mb_substr( $summary, 0, 800 );
            }
        }

        // Cache the result
        if ( ! empty( $summary ) ) {
            update_post_meta( $post_id, '_hts_page_summary_cache', array(
                'text' => $summary,
                'ts'   => time(),
            ) );
        }

        return $summary;
    }

    /**
     * Invalidate page summary cache when post is updated.
     * Called via save_post hook.
     * @since 2.4.13
     */
    public static function invalidate_summary_cache( $post_id ) {
        delete_post_meta( $post_id, '_hts_page_summary_cache' );
    }

    private function do_enhance_anchors_with_ai( $sugs, $nodes ) {

        // Récupérer la clé API (Anthropic prioritaire, sinon OpenAI)
        $anthropic_key = '';
        if ( class_exists( 'HTS_Coach' ) && method_exists( 'HTS_Coach', 'get_api_key' ) ) {
            $anthropic_key = \HTS_Coach::get_api_key();
        }
        $openai_key = $this->openai_key ?? '';

        if ( empty( $anthropic_key ) && empty( $openai_key ) ) {
            return $sugs; // Pas de clé → ancres regex en fallback
        }

        // Pré-charger le contenu source par SECTIONS H2 pour chaque page
        // IMPORTANT (v2.4.12): on découpe le contenu en sections H2 pour distribuer
        // les ancres dans différentes parties de l'article (éviter la concentration)
        // L'intro (avant première H2) est exclue — best practice: max 1 lien avant H2
        $source_sections = array(); // $source_sections[$sid] = array of section texts
        $source_paragraphs = array(); // fallback: full text after H2
        foreach ( $sugs as $sug ) {
            $sid = (int) ( $sug['source_id'] ?? 0 );
            if ( $sid && ! isset( $source_sections[ $sid ] ) ) {
                $post = get_post( $sid );
                if ( $post && ! empty( $post->post_content ) ) {
                    $raw_content = $post->post_content;

                    // Split by H2 tags
                    $parts = preg_split( '/(<h2[\s>])/i', $raw_content, -1, PREG_SPLIT_DELIM_CAPTURE );

                    $sections = array();
                    $current_section = '';
                    $is_intro = true;

                    for ( $si = 0; $si < count( $parts ); $si++ ) {
                        if ( preg_match( '/^<h2[\s>]/i', $parts[ $si ] ) ) {
                            // Start of a new H2 section
                            if ( ! $is_intro && $current_section !== '' ) {
                                $sections[] = $current_section;
                            }
                            $is_intro = false;
                            $current_section = $parts[ $si ]; // start with <h2
                        } else {
                            if ( $is_intro ) {
                                // Skip intro content entirely
                                continue;
                            }
                            $current_section .= $parts[ $si ];
                        }
                    }
                    // Don't forget the last section
                    if ( ! $is_intro && $current_section !== '' ) {
                        $sections[] = $current_section;
                    }

                    // Clean each section: strip headings, then HTML, collapse whitespace
                    // CRITICAL: Remove H2/H3 TEXT from the content sent to AI
                    // Headings must never become link anchors (SEO best practice)
                    $clean_sections = array();
                    foreach ( $sections as $sec ) {
                        // Remove heading tags AND their content (H2, H3, H4)
                        $sec_no_headings = preg_replace( '/<h[2-4][^>]*>.*?<\/h[2-4]>/si', ' ', $sec );
                        $text = html_entity_decode( wp_strip_all_tags( $sec_no_headings ), ENT_QUOTES, 'UTF-8' );
                        $text = preg_replace( '/\s+/', ' ', trim( $text ) );
                        if ( mb_strlen( $text ) >= 30 ) { // Min 30 chars to be useful
                            $clean_sections[] = mb_substr( $text, 0, 800 );
                        }
                    }

                    $source_sections[ $sid ] = $clean_sections;

                    // Fallback: full text after H2 (joined sections)
                    $source_paragraphs[ $sid ] = mb_substr( implode( ' ', $clean_sections ), 0, 2000 );
                } else {
                    $source_sections[ $sid ] = array();
                    $source_paragraphs[ $sid ] = '';
                }
            }
        }

        // Construire la liste complète des paires avec distribution de sections
        // Pour chaque source_id, on distribue les paires sur différentes sections H2
        $all_pairs = array();
        $source_pair_counter = array(); // count pairs per source_id for round-robin
        $target_summaries = array(); // cache target summaries

        // v2.4.15: Pre-check existing links to avoid suggesting duplicates
        $existing_links_cache = array(); // $existing_links_cache[$sid] = array of target_ids already linked
        $skipped_existing = 0;

        foreach ( $sugs as $idx => $sug ) {
            $source_title = $sug['source_title'] ?? '';
            $target_title = $sug['target_title'] ?? '';
            if ( ! $source_title || ! $target_title ) continue;

            $sid = (int) ( $sug['source_id'] ?? 0 );
            $tid = (int) ( $sug['target_id'] ?? 0 );

            // v2.4.15: Skip if source already has a link to this target
            if ( $sid && $tid ) {
                if ( ! isset( $existing_links_cache[ $sid ] ) ) {
                    $existing_links_cache[ $sid ] = $this->get_existing_internal_targets( $sid );
                }
                if ( in_array( $tid, $existing_links_cache[ $sid ], true ) ) {
                    $skipped_existing++;
                    continue;
                }
            }

            if ( ! isset( $source_pair_counter[ $sid ] ) ) {
                $source_pair_counter[ $sid ] = 0;
            }

            // Round-robin: assign a different section to each pair from the same source
            $sections = $source_sections[ $sid ] ?? array();
            $context = '';
            if ( ! empty( $sections ) ) {
                // v2.4.18: Send ALL sections concatenated for maximum anchor options
                $all_sections_text = implode( "\n", $sections );
                $context = mb_substr( $all_sections_text, 0, 3500 );
            }
            if ( ! $context ) {
                $context = mb_substr( $source_paragraphs[ $sid ] ?? '', 0, 3500 );
            }

            // Load target page summary (cached per target_id)
            if ( $tid && ! isset( $target_summaries[ $tid ] ) ) {
                $target_summaries[ $tid ] = $this->get_page_summary( $tid );
            }
            $target_desc = $target_summaries[ $tid ] ?? '';

            $source_pair_counter[ $sid ]++;

            $all_pairs[] = array(
                'sug_idx'     => $idx,
                'source'      => mb_substr( $source_title, 0, 80 ),
                'target'      => mb_substr( $target_title, 0, 80 ),
                'type'        => $sug['link_type'] ?? 'sibling',
                'context'     => $context,
                'target_desc' => mb_substr( $target_desc, 0, 250 ),
            );
        }

        if ( empty( $all_pairs ) ) return $sugs;

        // v2.4.15: Log skipped duplicates
        if ( $skipped_existing > 0 ) {
            $this->anchor_log( 'Anchor AI : ' . $skipped_existing . ' paire(s) ignorée(s) — lien vers cible déjà existant dans le contenu source' );
        }

        // Traiter par batches de 5 (v2.4.18: réduit car on envoie le texte source complet)
        $batch_size    = 5;
        $total_applied = 0;
        $global_anchors_used = array(); // v2.4.15: cross-batch anchor dedup
        $batches       = array_chunk( $all_pairs, $batch_size );

        $with_desc = count( array_filter( $all_pairs, function( $p ) { return ! empty( $p['target_desc'] ); } ) );
        $this->anchor_log( 'Anchor AI : ' . count( $all_pairs ) . ' paires totales, ' . count( $batches ) . ' batch(es), ' . $with_desc . ' avec description cible' );

        foreach ( $batches as $batch_num => $batch ) {
            $pairs    = array();
            $pair_map = array();
            foreach ( $batch as $i => $item ) {
                $pairs[] = array(
                    'id'          => $i,
                    'source'      => $item['source'],
                    'target'      => $item['target'],
                    'type'        => $item['type'],
                    'context'     => $item['context'],
                    'target_desc' => $item['target_desc'] ?? '',
                );
                $pair_map[ $i ] = $item['sug_idx'];
            }

            // Construire le prompt batch avec contexte source + description cible
            $pairs_text = '';
            foreach ( $pairs as $p ) {
                $pairs_text .= $p['id'] . ". SOURCE: \"" . $p['source'] . "\"\n";
                $pairs_text .= "   CIBLE: \"" . $p['target'] . "\" (" . $p['type'] . ")\n";
                if ( ! empty( $p['target_desc'] ) ) {
                    $pairs_text .= "   DESCRIPTION CIBLE: " . mb_substr( $p['target_desc'], 0, 250 ) . "\n";
                }
                if ( ! empty( $p['context'] ) ) {
                    $pairs_text .= "   TEXTE SOURCE (cherche ton ancre ici): " . mb_substr( $p['context'], 0, 3500 ) . "\n";
                }
                $pairs_text .= "\n";
            }

            $system = 'Tu es un expert en maillage interne SEO. Tu choisis des textes d' . "\x27" . 'ancre pour des liens internes en français.

OBJECTIF : Pour chaque paire source/cible, trouve le MEILLEUR texte d' . "\x27" . 'ancre pour un lien interne.

DEUX MODES (du meilleur au acceptable) :

MODE 1 — EXTRAIT (préféré, type:"extract") :
Trouve dans le TEXTE SOURCE un passage EXACT de 2-6 mots lié à la page cible.
Copie-le mot pour mot. Retourne aussi la phrase source complète dans "sentence".

MODE 2 — GÉNÉRÉ (si pas d' . "\x27" . 'extrait pertinent, type:"generated") :
Crée une ancre naturelle de 2-5 mots qui DÉCRIT le contenu de la page cible.
L' . "\x27" . 'ancre doit être en français naturel, pas un titre copié.

PRIORITÉ :
1. ✅EXTRAIT contenant un mot-clé de la cible (ex: "structure de cocon" pour cible "Structure cocon sémantique")
2. EXTRAIT thématiquement lié même sans mot-clé exact (ex: "arborescence et architecture" pour cible "Structure cocon")
3. GÉNÉRÉ descriptif de la cible (ex: "structurer un cocon efficace" pour cible "Structure cocon sémantique")
4. NE RETOURNE JAMAIS anchor:"" — il y a TOUJOURS une ancre possible en mode généré

ANTI-PATTERNS :
- Titre brut de la page cible recopié (ni en extract ni en generated)
- Terme générique : "cette méthode", "ce concept", "en savoir plus"
- Passage purement stylistique sans valeur descriptive
- Même ancre pour deux paires différentes
- Ancre > 6 mots

Règles techniques :
- 2 à 6 mots, naturel et grammaticalement correct
- Chaque ancre UNIQUE dans le batch
- Pour extract : retourne la phrase source complète dans "sentence"
- Pour generated : "sentence" peut être vide

JSON STRICT — TOUJOURS retourner une ancre pour chaque paire :
{"results":{"0":{"anchor":"texte ancre","type":"extract","sentence":"phrase source"},"1":{"anchor":"texte ancre","type":"generated","sentence":""},...}}';

            $user_msg = "Pour chaque paire, trouve le meilleur texte d\x27ancre. PRIORITÉ : extrait exact du TEXTE SOURCE. Si aucun extrait pertinent, GÉNÈRE une ancre descriptive de 2-5 mots. Ne retourne JAMAIS anchor:\"\" :\n\n" . $pairs_text;

            // Appel API — priorité : OpenAI 4o-mini (moins cher pour contexte long), fallback Anthropic
            $ai_result = null;

            $this->anchor_log( 'Anchor AI batch ' . ( $batch_num + 1 ) . '/' . count( $batches ) . ' : envoi de ' . count( $pairs ) . ' paires avec contexte bidirectionnel' );

            if ( ! empty( $openai_key ) ) {
                $ai_result = $this->call_anchor_ai_openai( $openai_key, $system, $user_msg, 'gpt-4.1-mini' );
            }

            if ( ! $ai_result && ! empty( $anthropic_key ) ) {
                $ai_result = $this->call_anchor_ai_anthropic( $anthropic_key, $system, $user_msg );
            }

            if ( ! $ai_result || ! is_array( $ai_result ) ) {
                $this->anchor_log( 'Anchor AI batch ' . ( $batch_num + 1 ) . ' : pas de réponse, fallback regex' );
                continue;
            }

            $this->anchor_log( 'Anchor AI batch ' . ( $batch_num + 1 ) . ' : ' . count( $ai_result ) . ' résultats — clés: ' . implode( ',', array_keys( $ai_result ) ) );

            // Appliquer les ancres IA
            $applied = 0;
            $skipped_reasons = array();
            foreach ( $ai_result as $pair_id => $item ) {
                $pair_id = (int) $pair_id;
                if ( ! isset( $pair_map[ $pair_id ] ) ) {
                    $skipped_reasons[] = $pair_id . ':no_map';
                    continue;
                }
                $sug_idx = $pair_map[ $pair_id ];

                // v2.4.19: Parse anchor, type, and sentence from hybrid AI response
                $anchor   = '';
                $sentence = '';
                $ai_type  = 'extract'; // default to extract for backward compat
                if ( is_array( $item ) ) {
                    $anchor   = trim( $item['anchor'] ?? '' );
                    $sentence = trim( $item['sentence'] ?? '' );
                    $ai_type  = trim( $item['type'] ?? 'extract' );
                } elseif ( is_string( $item ) ) {
                    $anchor = trim( $item );
                }
                // Normalize type
                if ( ! in_array( $ai_type, array( 'extract', 'generated' ), true ) ) {
                    $ai_type = 'extract';
                }

                // v2.4.19: Skip empty anchors (should be rare with hybrid prompt)
                if ( empty( $anchor ) ) {
                    $skipped_reasons[] = $pair_id . ':no_anchor';
                    continue;
                }

                // Nettoyage : retirer guillemets, ponctuation résiduelle
                $anchor = str_replace( array( '"', "\xe2\x80\x9c", "\xe2\x80\x9d", "\xe2\x80\x9e", '«', '»', "\xC2\xAB", "\xC2\xBB" ), '', $anchor );
                $anchor = trim( $anchor, " \t.,;:!?-–—" );

                // Validation minimale : 5-80 chars, pas vide
                if ( mb_strlen( $anchor ) < 5 || mb_strlen( $anchor ) > 80 ) {
                    $skipped_reasons[] = $pair_id . ':len_' . mb_strlen( $anchor );
                    continue;
                }

                // v2.4.15: Dedup — skip if this exact anchor was already used in this or previous batch
                $anchor_lower = mb_strtolower( $anchor );
                if ( isset( $global_anchors_used[ $anchor_lower ] ) ) {
                    $skipped_reasons[] = $pair_id . ':dedup_anchor';
                    continue;
                }

                // v2.4.15: Anti-title-brut — reject if anchor is >70% of target title
                $target_title_for_check = mb_strtolower( trim( $sugs[ $sug_idx ]['target_title'] ?? '' ) );
                if ( $target_title_for_check && mb_strlen( $anchor_lower ) >= 5 ) {
                    $sim_ratio = similar_text( $anchor_lower, $target_title_for_check ) / max( mb_strlen( $anchor_lower ), 1 );
                    if ( $sim_ratio > 0.70 ) {
                        $skipped_reasons[] = $pair_id . ':title_brut';
                        continue;
                    }
                }

                // v2.4.19: ANTI-HALLUCINATION — behavior depends on type
                $source_id_check = (int) ( $sugs[ $sug_idx ]['source_id'] ?? 0 );
                if ( $ai_type === 'extract' && $source_id_check > 0 ) {
                    // EXTRACT: Relaxed check — verify 80%+ of anchor's significant words exist in source
                    // This handles "maillage interne cocon" when source has "maillage interne du cocon"
                    $source_post_check = get_post( $source_id_check );
                    if ( $source_post_check && ! empty( $source_post_check->post_content ) ) {
                        $source_text_clean = mb_strtolower( wp_strip_all_tags( $source_post_check->post_content ) );
                        // First try exact match (fastest, best)
                        if ( mb_stripos( $source_text_clean, $anchor ) !== false ) {
                            // Perfect — exact extract confirmed
                        } else {
                            // Relaxed check: split anchor into significant words, verify 80%+ exist in source
                            $anchor_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', $anchor_lower );
                            $anchor_words = array_values( array_filter( $anchor_words, function( $w ) {
                                return mb_strlen( $w ) >= 3;
                            } ) );
                            if ( count( $anchor_words ) > 0 ) {
                                $found_count = 0;
                                foreach ( $anchor_words as $aw ) {
                                    if ( mb_strpos( $source_text_clean, $aw ) !== false ) {
                                        $found_count++;
                                    }
                                }
                                // STRICT : l'ancre extract DOIT exister verbatim → REJETER sinon
                                $this->anchor_log( 'Anchor AI REJET (non verbatim) : "' . mb_substr( $anchor, 0, 40 ) . '" — ' . $found_count . '/' . count( $anchor_words ) . ' mots dans post ' . $source_id_check );
                                $skipped_reasons[] = $pair_id . ':not_verbatim(' . $found_count . '/' . count( $anchor_words ) . ')';
                                continue;
                            }
                        }
                    }
                } elseif ( $ai_type === 'generated' ) {
                    // GENERATED: No anti-hallucination (anchor is invented by design)
                    // But validate relevance: at least 1 significant word from target title should be in anchor
                    $target_words = preg_split( '/[\s\-\/:;,\.\!\?\(\)\'\"]+/u', $target_title_for_check );
                    $target_words = array_values( array_filter( $target_words, function( $w ) {
                        return mb_strlen( $w ) >= 4;
                    } ) );
                    $has_target_word = false;
                    foreach ( $target_words as $tw ) {
                        if ( mb_strpos( $anchor_lower, $tw ) !== false ) {
                            $has_target_word = true;
                            break;
                        }
                    }
                    if ( ! $has_target_word && count( $target_words ) > 0 ) {
                        $skipped_reasons[] = $pair_id . ':generated_irrelevant';
                        $this->anchor_log( 'Anchor AI skip (generated irrelevant) : "' . mb_substr( $anchor, 0, 40 ) . '" — aucun mot-clé de la cible "' . mb_substr( $target_title_for_check, 0, 40 ) . '"' );
                        continue;
                    }
                }

                $global_anchors_used[ $anchor_lower ] = true;

                $sugs[ $sug_idx ]['anchor_text']    = $anchor;
                $sugs[ $sug_idx ]['anchor_method']   = 'ai';
                $sugs[ $sug_idx ]['anchor_type']     = $ai_type;
                $sugs[ $sug_idx ]['anchor_sentence'] = $sentence;
                $applied++;
                $total_applied++;
            }

            $this->anchor_log( 'Anchor AI batch ' . ( $batch_num + 1 ) . ' : ' . $applied . '/' . count( $pairs ) . ' appliquées' . ( ! empty( $skipped_reasons ) ? ' — skip: ' . implode( ', ', $skipped_reasons ) : '' ) );

            // Log anchor results for this batch
            $empty_count = 0;
            $extract_count = 0;
            $generated_count = 0;
            foreach ( $ai_result as $pair_id => $item ) {
                $a = is_array( $item ) ? trim( $item['anchor'] ?? '' ) : trim( $item );
                $t = is_array( $item ) ? trim( $item['type'] ?? 'extract' ) : 'extract';
                if ( empty( $a ) ) $empty_count++;
                elseif ( $t === 'generated' ) $generated_count++;
                else $extract_count++;
            }
            $this->anchor_log( 'Anchor AI batch ' . ( $batch_num + 1 ) . ' types : extract=' . $extract_count . ' generated=' . $generated_count . ' empty=' . $empty_count );

        } // end foreach batches

        $this->anchor_log( 'Anchor AI total : ' . $total_applied . '/' . count( $all_pairs ) . ' ancres IA appliquées' );

        return $sugs;
    }

    /**
     * Appel Anthropic Haiku pour générer les ancres batch.
     * @since 2.4.10
     */
    private function call_anchor_ai_anthropic( $api_key, $system, $user_msg ) {
        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
            'timeout' => 20,
            'headers' => array(
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ),
            'body' => wp_json_encode( array(
                'model'       => 'claude-haiku-4-5-20251001',
                'max_tokens'  => 2000,
                'temperature' => 0.7,
                'system'      => $system,
                'messages'    => array( array( 'role' => 'user', 'content' => $user_msg ) ),
            ) ),
        ) );

        if ( is_wp_error( $response ) ) return null;
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            if ( function_exists( 'hts_add_log' ) ) {
                $this->anchor_log( 'Anchor AI Anthropic : HTTP ' . $code );
            }
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Anchor AI Anthropic : JSON invalide — ' . json_last_error_msg(), 'warning', 'cocon' );
            }
            return null;
        }
        $text = '';
        if ( isset( $body['content'] ) && is_array( $body['content'] ) ) {
            foreach ( $body['content'] as $block ) {
                if ( ( $block['type'] ?? '' ) === 'text' ) $text .= $block['text'];
            }
        }

        // Track usage
        if ( ! empty( $body['usage'] ) ) {
            $usage = get_option( 'hts_anthropic_anchor_usage', array() );
            $month = wp_date( 'Y-m' );
            if ( ! isset( $usage[ $month ] ) ) $usage[ $month ] = array( 'calls' => 0, 'input_tokens' => 0, 'output_tokens' => 0 );
            $usage[ $month ]['calls']++;
            $usage[ $month ]['input_tokens']  += (int) ( $body['usage']['input_tokens'] ?? 0 );
            $usage[ $month ]['output_tokens'] += (int) ( $body['usage']['output_tokens'] ?? 0 );
            update_option( 'hts_anthropic_anchor_usage', $usage, false );

            // Track token usage for monthly budget
            $tokens_used = (int) ( $body['usage']['input_tokens'] ?? 0 ) + (int) ( $body['usage']['output_tokens'] ?? 0 );
            if ( $tokens_used > 0 ) {
                $month_key = wp_date( 'Y-m' );
                $budget_usage = get_option( 'hts_cocon_anchor_ai_usage', array() );
                $budget_usage[ $month_key ] = ( $budget_usage[ $month_key ] ?? 0 ) + $tokens_used;
                update_option( 'hts_cocon_anchor_ai_usage', $budget_usage, false );
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            $stop = $body['stop_reason'] ?? 'unknown';
            $this->anchor_log( 'Anchor AI Anthropic raw : ' . mb_strlen( $text ) . ' chars, stop=' . $stop . ', out_tokens=' . ( $body['usage']['output_tokens'] ?? '?' ) . ', preview=' . mb_substr( $text, 0, 200 ) );
        }

        return $this->parse_anchor_json( $text );
    }

    /**
     * Appel OpenAI GPT-4o-mini pour générer les ancres batch (fallback).
     * @since 2.4.10
     */
    private function call_anchor_ai_openai( $openai_key, $system, $user_msg, $model = 'gpt-4.1-mini' ) {
        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 20,
            'headers' => array(
                'Authorization' => 'Bearer ' . $openai_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'model'       => $model,
                'max_tokens'  => 2000,
                'temperature' => 0.7,
                'messages'    => array(
                    array( 'role' => 'system', 'content' => $system ),
                    array( 'role' => 'user',   'content' => $user_msg ),
                ),
            ) ),
        ) );

        if ( is_wp_error( $response ) ) return null;
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            if ( function_exists( 'hts_add_log' ) ) {
                $this->anchor_log( 'Anchor AI OpenAI : HTTP ' . $code );
            }
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Anchor AI OpenAI : JSON invalide — ' . json_last_error_msg(), 'warning', 'cocon' );
            }
            return null;
        }
        $text = $body['choices'][0]['message']['content'] ?? '';

        // Track usage
        if ( ! empty( $body['usage'] ) ) {
            $usage = get_option( 'hts_openai_usage', array() );
            $month = wp_date( 'Y-m' );
            if ( ! isset( $usage[ $month ] ) ) $usage[ $month ] = array( 'prompt_tokens' => 0, 'completion_tokens' => 0 );
            $usage[ $month ]['prompt_tokens']     += (int) ( $body['usage']['prompt_tokens'] ?? 0 );
            $usage[ $month ]['completion_tokens'] += (int) ( $body['usage']['completion_tokens'] ?? 0 );
            update_option( 'hts_openai_usage', $usage, false );

            // Track token usage for monthly budget
            $tokens_used = (int) ( $body['usage']['prompt_tokens'] ?? 0 ) + (int) ( $body['usage']['completion_tokens'] ?? 0 );
            if ( $tokens_used > 0 ) {
                $month_key = wp_date( 'Y-m' );
                $budget_usage = get_option( 'hts_cocon_anchor_ai_usage', array() );
                $budget_usage[ $month_key ] = ( $budget_usage[ $month_key ] ?? 0 ) + $tokens_used;
                update_option( 'hts_cocon_anchor_ai_usage', $budget_usage, false );
            }
        }

        return $this->parse_anchor_json( $text );
    }

    /**
     * Parse la réponse JSON de l'IA pour extraire les ancres.
     * Accepte :
     *   {"anchors":{"0":"...","1":"..."}}
     *   {"results":{"0":{"anchor":"...","sentence":"..."},"1":{...}}}
     *   {"0":"...","1":"..."}
     *   {"0":{"anchor":"...","sentence":"..."},...}
     * @since 2.4.10
     */
    private function parse_anchor_json( $text ) {
        if ( empty( $text ) ) return null;

        // Retirer les backticks markdown si présents
        $text = preg_replace( '/^```(?:json)?\s*/s', '', $text );
        $text = preg_replace( '/\s*```\s*$/s', '', $text );
        $text = trim( $text );

        // Essai 1 : JSON direct
        $data = json_decode( $text, true );
        if ( ! is_array( $data ) ) {
            // Essai 2 : extraire le premier objet JSON complet (gestion des imbrications)
            $json_start = strpos( $text, '{' );
            if ( $json_start !== false ) {
                $depth = 0;
                $json_end = null;
                for ( $i = $json_start; $i < strlen( $text ); $i++ ) {
                    if ( $text[ $i ] === '{' ) $depth++;
                    if ( $text[ $i ] === '}' ) {
                        $depth--;
                        if ( $depth === 0 ) { $json_end = $i; break; }
                    }
                }
                if ( $json_end !== null ) {
                    $data = json_decode( substr( $text, $json_start, $json_end - $json_start + 1 ), true );
                }
            }
        }

        if ( ! is_array( $data ) ) return null;

        // Dépaqueter : {"results":{...}} ou {"anchors":{...}}
        if ( isset( $data['results'] ) && is_array( $data['results'] ) ) {
            return $data['results'];
        }
        if ( isset( $data['anchors'] ) && is_array( $data['anchors'] ) ) {
            return $data['anchors'];
        }

        return $data;
    }

    /**
     * Générer une ancre variée à partir du titre cible et du contenu source.
     *
     * Stratégie :
     *  1. Chercher un segment de 2-6 mots dans le contenu source qui contient
     *     des mots significatifs du titre cible → ancre contextuelle.
     *  2. Si rien trouvé, extraire un sous-segment sémantique du titre cible
     *     (pas le titre complet, juste la partie signifiante).
     *  3. Dernier recours : titre tronqué (ancien comportement).
     *
     * Répartition visée : ~10% exact match, ~90% partiel/sémantique.
     *
     * @since 2.4.9
     * @param string $target_title  Titre de la page cible.
     * @param int    $source_id     ID de la page source.
     * @param string $link_type     Type de lien (child_to_pillar, pillar_to_child, sibling).
     * @return array { 'anchor' => string, 'method' => string }
     */
    /**
     * Tracker interne pour diversifier les ancres par page source au sein d'un même build.
     * Réinitialisé dans build_cocon_links() avant chaque cluster.
     */

    private function generate_varied_anchor( $target_title, $source_id, $link_type = '', $target_id = 0 ) {
        $stop = array_flip( function_exists( 'hts_get_stopwords' ) ? array_merge( hts_get_stopwords(), array( 'd','l','quoi','dont','comment','pourquoi','quand','faire','fait','toute','toutes','bien','aussi','savoir','comprendre','guide','complet','faut','découvrir' ) ) : array() );

        // Mots interdits en début de segment (prépositions, articles, négations, démonstratifs)
        $bad_starts = function_exists( 'hts_get_bad_end_words' ) ? hts_get_bad_end_words() : array();
        // Add extra words that shouldn't start an anchor (conjunctions, adverbs)
        foreach ( array( 'mais','car','donc','si','il','elle','ils','elles','tout','toute','tous','très','bien','aussi','encore','aber','wenn','auch','noch','pero','sino','también','todavía' ) as $_w ) {
            $bad_starts[ $_w ] = true;
        }

        $target_decoded = html_entity_decode( $target_title, ENT_QUOTES, 'UTF-8' );

        // Extraire mots significatifs du titre cible
        $title_words = preg_split( '/[\s\-\/:;,\.!\?\(\)\'\"]+/u', mb_strtolower( $target_decoded ) );
        $title_words = array_values( array_filter( $title_words, function( $w ) use ( $stop ) {
            return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] );
        } ) );

        if ( count( $title_words ) < 1 ) {
            return array( 'anchor' => mb_substr( $target_title, 0, 40 ), 'method' => 'fallback' );
        }

        // Ancres déjà utilisées depuis cette source (pour diversité)
        $src_key = (int) $source_id;
        $tgt_key = (int) $target_id;
        if ( ! isset( $this->used_anchors_by_source[ $src_key ] ) ) {
            $this->used_anchors_by_source[ $src_key ] = array();
        }
        if ( $tgt_key && ! isset( $this->used_anchors_by_target[ $tgt_key ] ) ) {
            $this->used_anchors_by_target[ $tgt_key ] = array();
        }

        // Helper : vérifier si une ancre est un doublon (par source OU par cible)
        $is_anchor_used = function( $anchor_lower ) use ( $src_key, $tgt_key ) {
            foreach ( $this->used_anchors_by_source[ $src_key ] as $used ) {
                if ( $anchor_lower === $used ) return true;
            }
            if ( $tgt_key ) {
                foreach ( $this->used_anchors_by_target[ $tgt_key ] as $used ) {
                    if ( $anchor_lower === $used ) return true;
                }
            }
            return false;
        };

        // Helper : enregistrer une ancre utilisée
        $record_anchor = function( $anchor_lower ) use ( $src_key, $tgt_key ) {
            $this->used_anchors_by_source[ $src_key ][] = $anchor_lower;
            if ( $tgt_key ) {
                $this->used_anchors_by_target[ $tgt_key ][] = $anchor_lower;
            }
        };

        // ── STRATÉGIE 1 : segment contextuel dans le contenu source ──
        $contextual_result = $this->find_contextual_anchor( $source_id, $title_words, $bad_starts, $stop );
        if ( $contextual_result ) {
            $anchor_lower = mb_strtolower( $contextual_result );
            if ( ! $is_anchor_used( $anchor_lower ) ) {
                $record_anchor( $anchor_lower );
                return array( 'anchor' => $contextual_result, 'method' => 'contextual' );
            }
        }

        // ── STRATÉGIE 2 : sous-segment sémantique du titre ──
        $title_clean = $target_decoded;
        $title_clean = preg_replace( '/^(guide\s+(complet\s+)?:?\s*|comment\s+|pourquoi\s+|tout\s+savoir\s+sur\s+)/iu', '', $title_clean );
        $title_clean = preg_replace( '/\s*[:\-–—|]\s*(le\s+)?guide\s+(complet|ultime|pratique|définitif).*$/iu', '', $title_clean );
        $title_clean = preg_replace( '/\s*[:\-–—|]\s*(tout\s+savoir|comprendre|méthode).*$/iu', '', $title_clean );
        $title_clean = trim( $title_clean );

        if ( mb_strlen( $title_clean ) >= 10 && mb_strlen( $title_clean ) <= 50 && $title_clean !== $target_decoded ) {
            $anchor_lower = mb_strtolower( $title_clean );
            if ( ! $is_anchor_used( $anchor_lower ) ) {
                $record_anchor( $anchor_lower );
                return array( 'anchor' => $title_clean, 'method' => 'semantic_title' );
            }
            // Doublon par cible → passer à partial
        }

        // ── STRATÉGIE 3 : fragment naturel du titre ──
        $partial = $this->extract_partial_title( $target_decoded, $title_words, $stop );
        if ( $partial && mb_strlen( $partial ) >= 8 ) {
            $anchor_lower = mb_strtolower( $partial );
            if ( ! $is_anchor_used( $anchor_lower ) ) {
                $record_anchor( $anchor_lower );
                return array( 'anchor' => $partial, 'method' => 'partial_title' );
            }
        }

        // ── DERNIER RECOURS : titre tronqué proprement (sur une frontière de mot) ──
        $fallback = $this->clean_truncate_title( $target_decoded, 45 );
        $record_anchor( mb_strtolower( $fallback ) );
        return array( 'anchor' => $fallback, 'method' => 'fallback' );
    }

    /**
     * Cherche un segment contextuel de qualité dans le contenu source.
     * Retourne le meilleur segment (string) ou null si rien de bon.
     */
    private function find_contextual_anchor( $source_id, $title_words, $bad_starts, $stop ) {
        $src_key = (int) $source_id;

        // Cache : éviter de re-parser le même post pour chaque lien
        if ( ! isset( $this->source_content_cache[ $src_key ] ) ) {
            $source_post = get_post( $source_id );
            if ( ! $source_post || empty( $source_post->post_content ) ) {
                $this->source_content_cache[ $src_key ] = null;
                return null;
            }

            $raw_content = $source_post->post_content;
            $decoded_content = html_entity_decode( $raw_content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

            $text = wp_strip_all_tags( $decoded_content );
            // Ne pas chercher dans l'intro (avant premier H2)
            $h2_pos = mb_strpos( mb_strtolower( $raw_content ), '<h2' );
            if ( $h2_pos !== false ) {
                $after_h2_html = mb_substr( $raw_content, $h2_pos );
                $text = wp_strip_all_tags( html_entity_decode( $after_h2_html, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
            }

            // Limiter le texte parsé pour éviter les timeouts (max ~5000 chars ≈ 800 mots)
            if ( mb_strlen( $text ) > 5000 ) {
                $text = mb_substr( $text, 0, 5000 );
            }

            $sentences = preg_split( '/(?<=[.!?;])[\s]+/', $text, -1, PREG_SPLIT_NO_EMPTY );
            // Limiter à 60 phrases max
            if ( count( $sentences ) > 60 ) {
                $sentences = array_slice( $sentences, 0, 60 );
            }

            $this->source_content_cache[ $src_key ] = array(
                'sentences' => $sentences,
                'raw'       => $raw_content,
                'decoded'   => $decoded_content,
            );
        }

        $cache = $this->source_content_cache[ $src_key ];
        if ( ! $cache ) return null;

        $sentences       = $cache['sentences'];
        $raw_content     = $cache['raw'];
        $decoded_content = $cache['decoded'];
        $candidates      = array();

        foreach ( $sentences as $sentence ) {
            $words = preg_split( '/\s+/', trim( $sentence ) );
            if ( count( $words ) < 3 ) continue;

            for ( $len = 3; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $start = 0; $start <= count( $words ) - $len; $start++ ) {
                    $segment = implode( ' ', array_slice( $words, $start, $len ) );
                    // Nettoyage : retirer ponctuation en début et fin (UTF-8 safe)
                    $segment_clean = preg_replace( '/^[\s\p{P}\p{S}«»\x{AB}\x{BB}]+|[\s\p{P}\p{S}«»\x{AB}\x{BB}]+$/u', '', $segment );
                    // Retirer guillemets (droits + typographiques + chevrons) et parenthèses internes
                    $segment_clean = str_replace( array( '"', "\xe2\x80\x9c", "\xe2\x80\x9d", "\xe2\x80\x9e", "\xc2\xab", "\xc2\xbb", '«', '»', '(', ')', '[', ']' ), '', $segment_clean );
                    $segment_clean = preg_replace( '/^[\s.,;:!?\'\"\-–—]+|[\s.,;:!?\'\"\-–—]+$/u', '', $segment_clean );

                    // Si le nettoyage a changé le premier mot, revérifier
                    if ( empty( $segment_clean ) ) continue;

                    // ── Filtre longueur : min 15 chars pour contextuels ──
                    if ( mb_strlen( $segment_clean ) < 15 || mb_strlen( $segment_clean ) > 55 ) continue;

                    $seg_lower = mb_strtolower( $segment_clean );

                    // ── Filtre : rejeter si commence par un mot interdit ──
                    $first_word = mb_strtolower( explode( ' ', $segment_clean )[0] );
                    $first_word_clean = preg_replace( '/^(l|d|qu|n|s|j|m|c)[\x{0027}\x{2019}]/u', '', $first_word );
                    if ( isset( $bad_starts[ $first_word ] ) || isset( $bad_starts[ $first_word_clean ] ) ) continue;

                    // ── Filtre : rejeter si FINIT par un mot tronqué / préposition / article ──
                    $seg_words_tmp = explode( ' ', $segment_clean );
                    $last_word = mb_strtolower( preg_replace( '/[.,;:!?\'"()]+$/', '', end( $seg_words_tmp ) ) );
                    $bad_ends = function_exists( 'hts_get_bad_end_words' ) ? hts_get_bad_end_words() : array();
                    if ( isset( $bad_ends[ $last_word ] ) ) continue;

                    // ── Filtre LARGE négations : rejeter tout segment contenant "pas", "ne", "n'est", "n'a", "jamais", "rien", "plus" (sens négatif) ──
                    if ( preg_match( '/\b(pas|jamais|rien)\b/iu', $seg_lower ) ) continue;
                    if ( preg_match( '/\bne\s/iu', $seg_lower ) ) continue;
                    if ( preg_match( '/n[\x{0027}\x{2019}](est|a|ai|ont|en|y|était)/iu', $seg_lower ) ) continue;

                    // ── Filtre : rejeter segments contenant des chiffres/années isolées ──
                    if ( preg_match( '/\b(20\d{2}|19\d{2})\b/', $segment_clean ) ) continue;

                    // ── Filtre : rejeter si que des mots fonctionnels (pas de concept) ──
                    $seg_words = preg_split( '/\s+/', $seg_lower );
                    $meaningful_count = 0;
                    foreach ( $seg_words as $sw ) {
                        $sw_clean = preg_replace( '/^(l|d|qu|n|s|j|m|c)[\x{0027}\x{2019}]/u', '', $sw );
                        if ( mb_strlen( $sw_clean ) >= 3 && ! isset( $stop[ $sw_clean ] ) && ! isset( $bad_starts[ $sw_clean ] ) ) {
                            $meaningful_count++;
                        }
                    }
                    if ( $meaningful_count < 2 ) continue;

                    // Compter mots du titre cible présents dans le segment
                    $found = 0;
                    foreach ( $title_words as $tw ) {
                        if ( mb_strpos( $seg_lower, $tw ) !== false ) $found++;
                    }
                    if ( $found < max( 1, floor( count( $title_words ) * 0.3 ) ) ) continue;

                    // ── Scoring ──
                    $score = ( $found / count( $title_words ) ) * 100;
                    $score += $found * 15;

                    // Bonus : 3-5 mots = sweet spot
                    if ( $len >= 3 && $len <= 5 ) $score += 15;
                    // Bonus : commence par un mot significatif (nom/concept)
                    if ( $meaningful_count >= 2 ) $score += 10;
                    // Bonus : bonne longueur (20-40 chars)
                    $slen = mb_strlen( $segment_clean );
                    if ( $slen >= 20 && $slen <= 40 ) $score += 8;
                    // Malus : trop court (15-19 chars)
                    if ( $slen < 20 ) $score -= 5;

                    // Vérifier que le segment n'est pas déjà dans un lien
                    // Sprint 5.3: Guard UTF-8 — skip si bytes invalides
                    if ( ! mb_check_encoding( $segment_clean, 'UTF-8' ) ) continue;
                    $esc_seg = preg_quote( $segment_clean, '/' );
                    if ( preg_match( '/<a[^>]*>[^<]*' . $esc_seg . '/si', $raw_content ) ) continue;

                    // Vérifier que le segment existe en texte visible
                    $pat_test = '/(?<!["\'>])(' . $esc_seg . ')(?![^<]*<\/a>)/iu';
                    if ( ! preg_match( $pat_test, $raw_content ) && ! preg_match( $pat_test, $decoded_content ) ) continue;

                    $candidates[] = array( 'text' => $segment_clean, 'score' => $score );

                    // Limiter le nombre de candidats pour éviter les boucles trop longues
                    if ( count( $candidates ) >= 20 ) break 3;
                }
            }
        }

        if ( empty( $candidates ) ) return null;

        // Trier par score décroissant
        usort( $candidates, function( $a, $b ) { return $b['score'] - $a['score']; } );

        // Retourner le meilleur si score suffisant
        if ( $candidates[0]['score'] >= 35 ) {
            return $candidates[0]['text'];
        }

        return null;
    }

    /**
     * Extrait un fragment naturel du titre : prend les mots du début en gardant la structure
     * grammaticale jusqu'à avoir 2-4 mots significatifs. Inclut les mots de liaison entre eux.
     */
    private function extract_partial_title( $title, $title_words, $stop ) {
        // Retirer les suffixes génériques courants
        $clean = preg_replace( '/\s*[:\-–—|]\s*(le\s+)?guide\s+(complet|ultime|pratique|définitif).*$/iu', '', $title );
        $clean = preg_replace( '/\s*[:\-–—|]\s*(tout\s+savoir|comprendre|méthode).*$/iu', '', $clean );
        $clean = trim( $clean );

        $original_words = preg_split( '/\s+/', $clean );
        $significant_count = 0;
        $result_words = array();

        foreach ( $original_words as $ow ) {
            $ow_lower = mb_strtolower( trim( $ow, '.,;:!?-–—"\'' ) );
            $is_significant = ( mb_strlen( $ow_lower ) >= 3 && ! isset( $stop[ $ow_lower ] ) );

            // Toujours inclure le mot (préserve les mots de liaison)
            $result_words[] = trim( $ow, '.,;:!?' );

            if ( $is_significant ) {
                $significant_count++;
            }

            // Stop quand on a 3-4 mots significatifs ET le dernier mot ajouté est significatif
            // (pour ne pas finir par un article/préposition)
            if ( $significant_count >= 3 && $is_significant ) break;
            if ( $significant_count >= 4 ) break;

            // Sécurité : pas plus de 7 mots au total (sinon c'est trop long)
            if ( count( $result_words ) >= 7 ) break;
        }

        // Retirer les mots de liaison en fin (articles, prépositions)
        while ( count( $result_words ) > 0 ) {
            $last = mb_strtolower( end( $result_words ) );
            $filler = function_exists( 'hts_get_bad_end_words' ) ? hts_get_bad_end_words() : array();
            $filler[':'] = true; $filler['-'] = true; $filler['–'] = true;
            if ( isset( $filler[ $last ] ) || mb_strlen( $last ) < 2 ) {
                array_pop( $result_words );
            } else {
                break;
            }
        }

        if ( $significant_count >= 2 && count( $result_words ) >= 2 ) {
            $partial = implode( ' ', $result_words );
            if ( mb_strlen( $partial ) >= 10 && mb_strlen( $partial ) <= 50 ) {
                return $partial;
            }
        }
        return null;
    }

    /**
     * Tronque un titre proprement sur une frontière de mot.
     */
    private function clean_truncate_title( $title, $max_len = 45 ) {
        $title = trim( $title );
        if ( mb_strlen( $title ) <= $max_len ) return $title;

        $words = explode( ' ', $title );
        $result = '';
        foreach ( $words as $w ) {
            $test = $result ? $result . ' ' . $w : $w;
            if ( mb_strlen( $test ) > $max_len ) break;
            $result = $test;
        }
        return $result ?: mb_substr( $title, 0, $max_len );
    }

    /* ── APPLY LINK ── */

    public function apply_single_link( $source_id, $target_id, $anchor_text ) {
        $post = get_post( $source_id );
        if ( ! $post ) return false;

        $url = get_permalink( $target_id );
        $content_before = $post->post_content;
        $ad = html_entity_decode( $anchor_text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $cdd = html_entity_decode( $content_before, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        $ae = preg_quote( $ad, '/' );
        $pat = '/(?<!["\'>])(' . $ae . ')(?![^<]*<\/a>)/iu';

        $wc = $content_before;
        if ( preg_match( $pat, $content_before ) ) { $wc = $content_before; }
        elseif ( preg_match( $pat, $cdd ) ) { $wc = $cdd; }
        else {
            // Fallback : insert generated anchor as contextual link in best paragraph
            // v2.4.14: smarter insertion — find a paragraph AFTER first H2 that relates to the target
            $link_html = '<a href="' . esc_url( $url ) . '" title="' . esc_attr( get_the_title( $target_id ) ) . '">' . esc_html( $ad ) . '</a>';

            // Find first H2 position to avoid intro zone
            $h2_pos = false;
            if ( preg_match( '/<h2[\s>]/i', $wc, $h2m_fb, PREG_OFFSET_CAPTURE ) ) {
                $h2_pos = $h2m_fb[0][1];
            }

            // Get all paragraphs (after H2 if possible)
            $search_content = ( $h2_pos !== false ) ? substr( $wc, $h2_pos ) : $wc;
            $search_offset  = ( $h2_pos !== false ) ? $h2_pos : 0;

            if ( preg_match_all( '/<p[^>]*>(.*?)<\/p>/si', $search_content, $ps, PREG_OFFSET_CAPTURE ) ) {
                // Score paragraphs: prefer longer ones not already link-heavy
                $best_idx = -1;
                $best_score = -1;
                $target_title_lower = mb_strtolower( get_the_title( $target_id ) );
                $target_words = array_filter( explode( ' ', $target_title_lower ), function( $w ) {
                    return mb_strlen( $w ) >= 4;
                } );

                for ( $i = 0; $i < count( $ps[0] ); $i++ ) {
                    $p_text = wp_strip_all_tags( $ps[0][ $i ][0] );
                    $p_len  = mb_strlen( $p_text );
                    if ( $p_len < 60 ) continue; // Skip short paragraphs

                    // Check paragraph is not inside a heading
                    $p_abs_pos = $search_offset + $ps[0][ $i ][1];
                    $before_p = substr( $wc, max( 0, $p_abs_pos - 200 ), 200 );
                    if ( preg_match( '/<h[1-6][^>]*>[^<]*$/i', $before_p ) ) continue;

                    // Count existing links in this paragraph
                    $existing_links = substr_count( mb_strtolower( $ps[0][ $i ][0] ), '<a ' );
                    if ( $existing_links >= 2 ) continue; // Already link-heavy

                    // Score: prefer paragraphs with words related to target
                    $p_lower = mb_strtolower( $p_text );
                    $score = $p_len / 100; // Base score from length
                    foreach ( $target_words as $tw ) {
                        if ( mb_strpos( $p_lower, $tw ) !== false ) $score += 3;
                    }
                    $score -= $existing_links * 2; // Penalize existing links

                    if ( $score > $best_score ) {
                        $best_score = $score;
                        $best_idx   = $i;
                    }
                }

                if ( $best_idx >= 0 ) {
                    // v2.4.14: Insert generated anchor naturally
                    // The AI generates anchors like "comparer cocon et topical map"
                    // which work as standalone descriptive phrases
                    $insert_text = '. Pour aller plus loin : ' . $link_html;

                    $p_abs_pos = $search_offset + $ps[0][ $best_idx ][1];
                    $p_full    = $ps[0][ $best_idx ][0];
                    $p_end_pos = $p_abs_pos + strlen( $p_full );
                    // Insert before </p>
                    $close_p_pos = $p_end_pos - 4; // before </p>
                    $wc = substr( $wc, 0, $close_p_pos ) . $insert_text . substr( $wc, $close_p_pos );

                    $upd = wp_update_post( array( 'ID' => $source_id, 'post_content' => $wc ) );
                    if ( is_wp_error( $upd ) || 0 === $upd ) {
                        hts_add_log( 'Cocon: échec sauvegarde ancre post #' . $source_id, 'error', 'cocon' );
                        return false;
                    }
                    if ( class_exists( 'HTS_Audit_Trail' ) ) {
                        HTS_Audit_Trail::log_link(
                            $source_id, $target_id, $anchor_text, 'outbound',
                            $content_before, $wc,
                            HTS_Audit_Trail::get_gsc_snapshot( $source_id )
                        );
                    }
                    hts_add_log( 'Cocon: ancre générée insérée "' . $ad . '" dans §' . ( $best_idx + 1 ) . ' post=' . $source_id, 'success', 'cocon' );
                    return true;
                }
            }
            return false;
        }

        $link = '<a href="' . esc_url( $url ) . '" title="' . esc_attr( get_the_title( $target_id ) ) . '">' . $ad . '</a>';
        $nc = preg_replace( $pat, $link, $wc, 1 );

        // ── HEADING PROTECTION (v2.4.12) ──
        // Never inject a link inside H1-H6 tags (SEO best practice)
        $link_check = 'href="' . esc_url( $url ) . '"';
        $link_pos = strpos( $nc, $link_check );
        if ( $link_pos !== false ) {
            $before_link = substr( $nc, 0, $link_pos );
            if ( preg_match_all( '/<(h[1-6])[\s>]/i', $before_link, $hd_opens, PREG_OFFSET_CAPTURE ) ) {
                $last_open = end( $hd_opens[0] );
                $tag_name  = end( $hd_opens[1] )[0];
                $between   = substr( $nc, $last_open[1], $link_pos - $last_open[1] );
                if ( stripos( $between, '</' . $tag_name . '>' ) === false ) {
                    // Link is inside a heading — skip entirely
                    hts_add_log( 'Cocon bulk: lien bloqué (inside <' . $tag_name . '>) ancre="' . $ad . '" post=' . $source_id, 'info', 'system' );
                    return false;
                }
            }
        }

        // ── INTRO ZONE PROTECTION (v2.4.12) ──
        // Check if the injected link landed before the first H2
        // $link_check and $link_pos already set by heading protection above
        $link_pos = strpos( $nc, $link_check ); // re-check: heading protection may have changed $nc
        if ( $link_pos !== false ) {
            $h2_pos = false;
            if ( preg_match( '/<h2[\s>]/i', $nc, $h2m, PREG_OFFSET_CAPTURE ) ) {
                $h2_pos = $h2m[0][1];
            }
            if ( $h2_pos !== false && $link_pos < $h2_pos ) {
                // Link is in intro zone — count existing internal links there
                $intro_html = substr( $content_before, 0, $h2_pos );
                $site_url   = home_url();
                $intro_links = 0;
                if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $intro_html, $im ) ) {
                    foreach ( $im[1] as $href ) {
                        if ( strpos( $href, $site_url ) === 0 || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                            $intro_links++;
                        }
                    }
                }
                if ( $intro_links >= 1 ) {
                    // Try to find the anchor AFTER the first H2 instead
                    $after_h2 = substr( $wc, $h2_pos );
                    $nc_after = preg_replace( $pat, $link, $after_h2, 1 );
                    if ( $nc_after !== $after_h2 && $nc_after !== null && strpos( $nc_after, $link_check ) !== false ) {
                        $nc = substr( $wc, 0, $h2_pos ) . $nc_after;
                    } else {
                        // No match after H2 and intro saturated → skip this link
                        hts_add_log( 'Cocon bulk: lien bloqué (zone intro saturée) ancre="' . $ad . '" post=' . $source_id, 'info', 'system' );
                        return false;
                    }
                }
            }
        }

        $upd = wp_update_post( array( 'ID' => $source_id, 'post_content' => $nc ) );
        if ( is_wp_error( $upd ) || 0 === $upd ) {
            hts_add_log( 'Cocon: échec sauvegarde lien TF-IDF post #' . $source_id, 'error', 'cocon' );
            return false;
        }
        // ── Audit Trail ──
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log_link(
                $source_id, $target_id, $anchor_text, 'outbound',
                $content_before, $nc,
                HTS_Audit_Trail::get_gsc_snapshot( $source_id )
            );
        }
        return true;
    }

    /**
     * Average click depth across all reachable nodes.
     */
    private function avg_click_depth( $nodes ) {
        $depths = array();
        foreach ( $nodes as $n ) {
            if ( isset( $n['click_depth'] ) && $n['click_depth'] < PHP_INT_MAX ) {
                $depths[] = $n['click_depth'];
            }
        }
        return ! empty( $depths ) ? round( array_sum( $depths ) / count( $depths ), 1 ) : null;
    }

    /**
     * Average sibling density across non-trivial clusters.
     */
    private function avg_sibling_density( $clusters ) {
        $densities = array();
        foreach ( $clusters as $cl ) {
            if ( ( $cl['page_count'] ?? 0 ) >= 3 && isset( $cl['sibling_density'] ) ) {
                $densities[] = $cl['sibling_density'];
            }
        }
        return ! empty( $densities ) ? round( array_sum( $densities ) / count( $densities ), 1 ) : null;
    }

    private function resolve_url( $href, $base ) {
        if ( strpos( $href, 'http' ) === 0 ) return $href;
        if ( strpos( $href, '/' ) === 0 ) { $p = parse_url( $base ); return $p['scheme'] . '://' . $p['host'] . $href; }
        return trailingslashit( $base ) . $href;
    }

    /* ── AJAX ── */

    /**
     * AJAX: Refresh link metrics ONLY — does NOT recluster.
     * Re-reads HTML content of all cluster pages, recounts links,
     * recalculates density/orphans/dead_ends per cluster.
     * Clusters and page assignments stay exactly the same.
     *
     * @since 2.4.20
     */
    public function ajax_refresh_links() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier( 2 );

        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }
        $opt_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang
            : 'hts_cocon_data';

        $data = get_option( $opt_key, array() );
        if ( empty( $data['clusters'] ) || empty( $data['nodes'] ) ) {
            wp_send_json_error( 'Aucune analyse existante. Lancez d\'abord une analyse NLP.' );
        }

        $nodes    = &$data['nodes'];
        $clusters = &$data['clusters'];

        // ── Step 1: Re-read all outgoing/incoming links from actual HTML ──
        $all_page_ids = array();
        foreach ( $clusters as $cl ) {
            foreach ( $cl['pages'] ?? array() as $pid ) {
                $all_page_ids[] = (int) $pid;
            }
        }
        $all_page_ids = array_unique( $all_page_ids );

        // Reset link data for all nodes
        foreach ( $all_page_ids as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $nodes[ $pid ]['outgoing'] = array();
            $nodes[ $pid ]['incoming'] = array();
            $nodes[ $pid ]['out_count'] = 0;
            $nodes[ $pid ]['in_count']  = 0;
            $nodes[ $pid ]['out_count_semantic'] = 0;
            $nodes[ $pid ]['in_count_semantic']  = 0;
        }

        // Re-read links from HTML
        foreach ( $all_page_ids as $pid ) {
            $targets = $this->get_existing_internal_targets( $pid );
            // Only count links to pages within the cocon
            $internal_targets = array_intersect( $targets, $all_page_ids );
            if ( isset( $nodes[ $pid ] ) ) {
                $nodes[ $pid ]['outgoing']           = array_values( $internal_targets );
                $nodes[ $pid ]['out_count']           = count( $internal_targets );
                $nodes[ $pid ]['out_count_semantic']  = count( $internal_targets );
            }
        }

        // Rebuild incoming counts
        foreach ( $all_page_ids as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            foreach ( $nodes[ $pid ]['outgoing'] as $tid ) {
                if ( isset( $nodes[ $tid ] ) ) {
                    $nodes[ $tid ]['incoming'][] = $pid;
                    $nodes[ $tid ]['in_count']++;
                    $nodes[ $tid ]['in_count_semantic']++;
                }
            }
        }

        // Update orphan/dead_end status
        foreach ( $all_page_ids as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $nodes[ $pid ]['is_orphan']   = $nodes[ $pid ]['in_count_semantic'] === 0;
            $nodes[ $pid ]['is_dead_end'] = $nodes[ $pid ]['out_count'] === 0;
            // Update role label (keep pilier if already set)
            if ( ( $nodes[ $pid ]['role'] ?? '' ) !== 'pilier' ) {
                if ( $nodes[ $pid ]['is_orphan'] ) {
                    $nodes[ $pid ]['role'] = 'orpheline';
                } elseif ( ( $nodes[ $pid ]['role'] ?? '' ) === 'orpheline' ) {
                    // Was orphan, now has incoming links → promote to enfant
                    $nodes[ $pid ]['role'] = 'enfant';
                }
                // else: keep existing role (satellite, enfant, etc.)
            }
        }

        // ── Step 2: Recalculate cluster metrics ──
        $total_links_updated = 0;
        foreach ( $clusters as &$cl ) {
            $n = count( $cl['pages'] ?? array() );
            $internal = 0;
            $orphans  = 0;
            $dead     = 0;

            foreach ( $cl['pages'] as $pid ) {
                if ( ! isset( $nodes[ $pid ] ) ) continue;
                if ( $nodes[ $pid ]['is_orphan'] ) $orphans++;
                if ( $nodes[ $pid ]['is_dead_end'] ) $dead++;
                foreach ( $nodes[ $pid ]['outgoing'] as $tid ) {
                    if ( in_array( $tid, $cl['pages'] ) ) {
                        $internal++;
                    }
                }
            }

            $max_p = $n * ( $n - 1 );
            $cl['total_links']    = $internal;
            $cl['semantic_links'] = $internal;
            $cl['density']        = $max_p > 0 ? round( $internal / $max_p * 100, 1 ) : 0;
            $cl['page_count']     = $n;
            $cl['orphans']        = $orphans;
            $cl['dead_ends']      = $dead;
            $total_links_updated += $internal;

            // Pillar coverage
            $connected = 0;
            if ( ! empty( $cl['pillar_id'] ) && isset( $nodes[ $cl['pillar_id'] ] ) ) {
                foreach ( $cl['pages'] as $pid ) {
                    if ( $pid === $cl['pillar_id'] || ! isset( $nodes[ $pid ] ) ) continue;
                    if ( in_array( $cl['pillar_id'], $nodes[ $pid ]['outgoing'] ) || in_array( $pid, $nodes[ $cl['pillar_id'] ]['outgoing'] ) ) {
                        $connected++;
                    }
                }
            }
            $cl['connected_to_pillar'] = $connected;
            $cl['pillar_coverage']     = $n > 1 ? round( $connected / ( $n - 1 ) * 100 ) : 100;
        }
        unset( $cl );

        // ── Step 3: Update stats ──
        $total_orphans = 0;
        $total_dead    = 0;
        foreach ( $nodes as $n ) {
            if ( ! empty( $n['is_orphan'] ) ) $total_orphans++;
            if ( ! empty( $n['is_dead_end'] ) ) $total_dead++;
        }
        if ( isset( $data['stats'] ) ) {
            $data['stats']['total_links']   = $total_links_updated;
            $data['stats']['total_orphans'] = $total_orphans;
            $data['stats']['total_dead_ends'] = $total_dead;
        }

        // Save
        update_option( $opt_key, $data, false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                '🔄 Refresh liens : ' . count( $all_page_ids ) . ' pages scannées, '
                . $total_links_updated . ' liens internes, '
                . $total_orphans . ' orphelins',
                'info', 'cocon'
            );
        }

        wp_send_json_success( array(
            'message' => count( $all_page_ids ) . ' pages scannées — ' . $total_links_updated . ' liens détectés — ' . $total_orphans . ' orphelin(s).',
            'pages_scanned'  => count( $all_page_ids ),
            'total_links'    => $total_links_updated,
            'total_orphans'  => $total_orphans,
        ) );
    }

    public function ajax_analyze() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier( 1 );
        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        // Sanitize 'all' — must never analyze all languages mixed
        if ( $lang === 'all' ) $lang = '';
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
            if ( $lang === 'all' ) $lang = '';
        }
        // Safety: if Polylang is active but lang is still empty, force detection
        if ( empty( $lang ) && function_exists( 'pll_default_language' ) ) {
            $lang = pll_default_language( 'slug' );
        }
        if ( empty( $lang ) ) {
            $lang = substr( get_locale(), 0, 2 );
        }
        $force_recluster = ! empty( $_POST['force_recluster'] );

        // ── Load existing data BEFORE re-analysis ──
        $opt_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang
            : 'hts_cocon_data';
        $old_data = get_option( $opt_key, array() );

        // FIX POLYLANG: data may have been saved under a DIFFERENT key
        // (e.g. 'hts_cocon_data' without lang suffix, or with wrong lang)
        // Search all possible keys to find existing clusters
        if ( empty( $old_data['clusters'] ) ) {
            $fallback_keys = array( 'hts_cocon_data' );
            if ( $lang ) {
                $fallback_keys[] = 'hts_cocon_data_' . $lang;
            }
            // Also try common language codes
            foreach ( array( 'fr', 'en', 'es', 'de', 'it' ) as $try_lang ) {
                $fallback_keys[] = 'hts_cocon_data_' . $try_lang;
            }
            $fallback_keys = array_unique( $fallback_keys );

            foreach ( $fallback_keys as $fk ) {
                if ( $fk === $opt_key ) continue; // Already tried
                $try_data = get_option( $fk, array() );
                if ( ! empty( $try_data['clusters'] ) && ! empty( $try_data['nodes'] ) ) {
                    $old_data = $try_data;
                    // Migrate data to the correct key for this language
                    update_option( $opt_key, $old_data, false );
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf(
                            '🔄 Cocon données trouvées sous clé "%s" → migrées vers "%s" (%d clusters)',
                            $fk, $opt_key, count( $old_data['clusters'] )
                        ), 'info', 'cocon' );
                    }
                    break;
                }
            }
        }

        $had_clusters = ! empty( $old_data['clusters'] );

        // ══════════════════════════════════════════════════════════════
        //  FIX A: ALWAYS BACKUP before any re-analysis
        //  Stored in hts_cocon_data_backup (or _backup_{lang} for multilingual)
        //  Allows 1-click restore if analysis goes wrong
        // ══════════════════════════════════════════════════════════════
        if ( $had_clusters && ! empty( $old_data['nodes'] ) ) {
            $backup_key = $opt_key . '_backup';
            update_option( $backup_key, $old_data, false );
            update_option( $backup_key . '_ts', current_time( 'mysql' ), false );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf(
                    '💾 Cocon backup créé : %d clusters, %d nodes (clé: %s)',
                    count( $old_data['clusters'] ), count( $old_data['nodes'] ), $backup_key
                ), 'info', 'cocon' );
            }
        }

        // ── Run full analysis (rebuilds nodes, links, metrics — and clusters if force) ──
        if ( $force_recluster || ! $had_clusters ) {
            // Full recluster: run analyze_site normally (generates new clusters)
            $r = $this->analyze_site( $lang );

            // Purge money pages cache — force re-detection with new clusters
            if ( $force_recluster ) {
                delete_option( 'hts_money_pages_discovery' );
                delete_option( 'hts_money_pages_discovery_' . $lang );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Force recluster: cache pages business purgé — sera re-détecté au prochain chargement', 'info', 'cocon' );
                }
            }

            // ══════════════════════════════════════════════════════════
            //  FIX B: SAFETY NET — if "Non classé" has > 40% of pages,
            //  the clustering failed. Restore backup and abort.
            // ══════════════════════════════════════════════════════════
            $total_pages = count( $r['nodes'] ?? array() );
            $non_classe_count = 0;
            foreach ( $r['clusters'] ?? array() as $cname => $cl ) {
                if ( mb_strtolower( $cname ) === 'non classé' || mb_strtolower( $cname ) === 'non classe' ) {
                    $non_classe_count = (int) ( $cl['page_count'] ?? count( $cl['pages'] ?? array() ) );
                }
            }
            if ( $total_pages > 20 && $non_classe_count > $total_pages * 0.4 ) {
                // Clustering failed — restore backup
                if ( $had_clusters ) {
                    update_option( $opt_key, $old_data, false );
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf(
                            '🛑 Cocon : clustering échoué — %d/%d pages dans "Non classé" (> 40%%). Backup restauré automatiquement.',
                            $non_classe_count, $total_pages
                        ), 'error', 'cocon' );
                    }
                    wp_send_json_error( array(
                        'message' => sprintf(
                            'Analyse interrompue : le clustering a échoué (%d/%d pages non classées). Vos groupes précédents ont été conservés. Réessayez ou contactez le support.',
                            $non_classe_count, $total_pages
                        ),
                        'restored' => true,
                    ) );
                }
            }

            $protected_count = 0;
        } else {
            // PROTECTED MODE: re-analyze nodes + links + metrics but KEEP existing clusters
            $r = $this->analyze_site( $lang );

            // Restore old cluster assignments for all pages that still exist
            $old_clusters = $old_data['clusters'];
            $old_nodes    = $old_data['nodes'] ?? array();

            // Build a map: page_id → old cluster name
            $old_assignments = array();
            foreach ( $old_nodes as $pid => $node ) {
                if ( ! empty( $node['cluster'] ) ) {
                    $old_assignments[ $pid ] = $node['cluster'];
                }
            }

            // Restore cluster structures with only pages that still exist in new analysis
            $restored_clusters = array();
            foreach ( $old_clusters as $cname => $cl ) {
                $valid_pages = array_filter( $cl['pages'] ?? array(), function( $pid ) use ( $r ) {
                    return isset( $r['nodes'][ $pid ] );
                } );
                if ( empty( $valid_pages ) ) continue;

                $restored_clusters[ $cname ] = $cl;
                $restored_clusters[ $cname ]['pages']      = array_values( $valid_pages );
                $restored_clusters[ $cname ]['page_count'] = count( $valid_pages );
            }

            // Find NEW pages (in new analysis but not in any old cluster)
            $new_page_ids = array();
            foreach ( $r['nodes'] as $pid => $node ) {
                if ( ! isset( $old_assignments[ $pid ] ) ) {
                    $new_page_ids[] = $pid;
                }
            }

            // Assign new pages: use new analysis cluster assignment
            // (the new clustering already ran, so r['nodes'][$pid]['cluster'] has the new assignment)
            foreach ( $new_page_ids as $pid ) {
                $new_cluster = $r['nodes'][ $pid ]['cluster'] ?? '';
                if ( empty( $new_cluster ) ) $new_cluster = 'Non classé';

                // If the new cluster name exists in restored clusters, add the page there
                if ( isset( $restored_clusters[ $new_cluster ] ) ) {
                    $restored_clusters[ $new_cluster ]['pages'][] = $pid;
                    $restored_clusters[ $new_cluster ]['page_count']++;
                } else {
                    // New cluster name from NLP — check if it exists in new analysis
                    if ( isset( $r['clusters'][ $new_cluster ] ) ) {
                        // Only keep this new cluster for new pages
                        if ( ! isset( $restored_clusters[ $new_cluster ] ) ) {
                            $restored_clusters[ $new_cluster ] = $r['clusters'][ $new_cluster ];
                            $restored_clusters[ $new_cluster ]['pages'] = array();
                            $restored_clusters[ $new_cluster ]['page_count'] = 0;
                        }
                        $restored_clusters[ $new_cluster ]['pages'][] = $pid;
                        $restored_clusters[ $new_cluster ]['page_count']++;
                    } else {
                        // Fallback: put in "Non classé"
                        if ( ! isset( $restored_clusters['Non classé'] ) ) {
                            $restored_clusters['Non classé'] = array(
                                'name'       => 'Non classé',
                                'pages'      => array(),
                                'page_count' => 0,
                                'pillar_id'  => 0,
                            );
                        }
                        $restored_clusters['Non classé']['pages'][] = $pid;
                        $restored_clusters['Non classé']['page_count']++;
                    }
                }
            }

            // Fix node cluster assignments to match restored clusters
            foreach ( $r['nodes'] as $pid => &$node ) {
                if ( isset( $old_assignments[ $pid ] ) && isset( $restored_clusters[ $old_assignments[ $pid ] ] ) ) {
                    $node['cluster'] = $old_assignments[ $pid ];
                }
                // New pages keep their assignment from above
            }
            unset( $node );

            // Remove empty clusters
            $restored_clusters = array_filter( $restored_clusters, function( $cl ) {
                return ! empty( $cl['pages'] );
            } );

            $protected_count = count( $restored_clusters );
            $r['clusters'] = $restored_clusters;

            // Re-save with protected clusters
            update_option( $opt_key, $r, false );

            if ( count( $new_page_ids ) > 0 ) {
                hts_add_log(
                    sprintf( '🛡️ %d cluster(s) conservé(s) — %d nouvelle(s) page(s) assignée(s)', $protected_count, count( $new_page_ids ) ),
                    'info', 'cocon'
                );
            }
        }

        $missing = get_option( 'hts_cocon_missing_clusters', array() );
        wp_send_json_success( array(
            'stats' => $r['stats'],
            'clusters' => array_values( array_map( function( $c ) { return array( 'name' => $c['name'], 'page_count' => $c['page_count'], 'total_links' => $c['total_links'] ?? 0, 'density' => $c['density'] ?? 0, 'orphans' => $c['orphans'] ?? 0, 'dead_ends' => $c['dead_ends'] ?? 0, 'pillar_id' => $c['pillar_id'] ?? 0, 'pillar_coverage' => $c['pillar_coverage'] ?? 0, 'theme' => $c['theme'] ?? '' ); }, $r['clusters'] ) ),
            'missing_clusters' => $missing,
            'flagged_pages' => array_values( $r['flagged_pages'] ?? array() ),
            'message' => $r['stats']['total_pages'] . ' articles analysés.'
                . ( $protected_count > 0 ? ' Clusters conservés (' . $protected_count . ').' : '' )
                . ( ! empty( $new_page_ids ) ? ' ' . count( $new_page_ids ) . ' nouvelle(s) page(s) ajoutée(s).' : '' ),
            'protected_count' => $protected_count,
        ) );
    }

    /* ══════════════════════════════════════════════════════════════════
     *  CHUNKED ANALYSIS — avoids Apache/OVH timeout on shared hosting.
     *  Called by JS as sequential steps: init → scan (batched) → links → cluster → finalize
     *  Work-in-progress stored in transient 'hts_analyze_wip'.
     * ══════════════════════════════════════════════════════════════════ */
    public function ajax_analyze_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier( 1 );
        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 120 );

        $step   = sanitize_text_field( $_POST['step'] ?? '' );
        $lang   = sanitize_text_field( $_POST['lang'] ?? '' );
        $offset = (int) ( $_POST['offset'] ?? 0 );
        $force  = ! empty( $_POST['force_recluster'] );
        $wip_key = 'hts_analyze_wip';

        if ( empty( $lang ) ) {
            if ( class_exists( 'HTS_Language' ) ) $lang = HTS_Language::get_current_lang();
            if ( empty( $lang ) && function_exists( 'pll_default_language' ) ) $lang = pll_default_language( 'slug' );
            if ( empty( $lang ) ) $lang = substr( get_locale(), 0, 2 );
        }

        // ────────────────────────────────────────────────
        //  STEP: INIT — Load posts, dedup, store IDs
        // ────────────────────────────────────────────────
        if ( $step === 'init' ) {
            // Backup existing data
            $opt_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
                ? 'hts_cocon_data_' . $lang : 'hts_cocon_data';
            $old_data = get_option( $opt_key, array() );
            if ( ! empty( $old_data['clusters'] ) && ! empty( $old_data['nodes'] ) ) {
                update_option( $opt_key . '_backup', $old_data, false );
                update_option( $opt_key . '_backup_ts', current_time( 'mysql' ), false );
            }

            // Load posts
            $args = array(
                'post_type' => array( 'post', 'page' ), 'post_status' => 'publish',
                'posts_per_page' => 500, 'orderby' => 'date', 'order' => 'DESC',
                'no_found_rows' => true, 'update_post_meta_cache' => false,
                'update_post_term_cache' => false, 'suppress_filters' => false,
            );
            if ( $lang && class_exists( 'HTS_Language' ) ) {
                $args = HTS_Language::filter_query_args( $args, $lang );
            }
            $posts = get_posts( $args );
            if ( $lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
                $posts = array_values( HTS_Language::filter_posts_by_lang( $posts, $lang ) );
            }

            // Pre-filter utility pages
            $utility_slugs = array(
                'contact','contact-2','formulaire','form','candidature',
                'politique-de-confidentialite','privacy-policy','privacy',
                'mentions-legales','legal-notice','mentions','cgv','cgu',
                'conditions-generales','terms','mon-compte','my-account',
                'account','login','register','panier','cart','checkout',
                'commande','plan-du-site','sitemap','cookie','cookies',
                'rgpd','gdpr','qui-sommes-nous','a-propos','about',
                'about-us','equipe','lequipe','l-equipe','team',
                'notre-equipe','partenaires','partners','temoignages',
                'testimonials','faq','aide','help','support',
            );
            $site_url = home_url();
            $posts = array_filter( $posts, function( $p ) use ( $utility_slugs, $site_url ) {
                $slug = basename( rtrim( str_replace( $site_url, '', get_permalink( $p->ID ) ), '/' ) );
                return ! in_array( $slug, $utility_slugs, true );
            } );

            // Dedup by title
            $title_map = array();
            foreach ( $posts as $p ) {
                $norm = mb_strtolower( trim( $p->post_title ) );
                if ( empty( $norm ) ) continue;
                if ( ! isset( $title_map[ $norm ] ) ) {
                    $title_map[ $norm ] = $p;
                } else {
                    $old_len = mb_strlen( wp_strip_all_tags( $title_map[ $norm ]->post_content ) );
                    $new_len = mb_strlen( wp_strip_all_tags( $p->post_content ) );
                    if ( $new_len > $old_len ) $title_map[ $norm ] = $p;
                }
            }
            $post_ids = wp_list_pluck( array_values( $title_map ), 'ID' );

            if ( empty( $post_ids ) ) {
                delete_transient( $wip_key );
                wp_send_json_success( array( 'step' => 'done', 'message' => 'Aucun article trouvé.' ) );
            }

            $wip = array(
                'lang'           => $lang,
                'force'          => $force,
                'post_ids'       => array_values( $post_ids ),
                'nodes'          => array(),
                'links'          => array(),
                'site_url'       => $site_url,
                'host'           => parse_url( $site_url, PHP_URL_HOST ),
                'had_clusters'   => ! empty( $old_data['clusters'] ),
                'opt_key'        => $opt_key,
                'started_at'     => time(),
            );
            set_transient( $wip_key, $wip, 1800 );

            hts_add_log( sprintf( 'Analyse chunked init: %d posts, lang=%s', count( $post_ids ), $lang ), 'info', 'cocon' );
            wp_send_json_success( array(
                'step' => 'init', 'total' => count( $post_ids ), 'message' => count( $post_ids ) . ' articles à analyser',
            ) );
        }

        // ────────────────────────────────────────────────
        //  STEP: SCAN — Build nodes in batches of 20
        // ────────────────────────────────────────────────
        if ( $step === 'scan' ) {
            $wip = get_transient( $wip_key );
            if ( ! $wip ) wp_send_json_error( 'Session expirée. Relancez l\'analyse.' );

            $max_time = (int) ini_get( 'max_execution_time' );
            $batch_size = ( $max_time > 0 && $max_time <= 60 ) ? 10 : 20;
            $post_ids   = $wip['post_ids'];
            $total      = count( $post_ids );
            $batch      = array_slice( $post_ids, $offset, $batch_size );

            if ( empty( $batch ) ) {
                wp_send_json_success( array( 'step' => 'scan', 'done' => true, 'processed' => $total, 'total' => $total ) );
            }

            $site_url = $wip['site_url'];
            $host     = $wip['host'];
            $nodes    = $wip['nodes'];
            $_scan_start = microtime( true );
            $_scan_count = 0;

            foreach ( $batch as $pid ) {
                if ( class_exists( 'HTS_Job_Runner' ) && ! HTS_Job_Runner::has_time( $_scan_start ) ) break;
                $_scan_count++;
                $p = get_post( $pid );
                if ( ! $p ) continue;

                $content = $p->post_content;
                $cd = html_entity_decode( wp_strip_all_tags( $content ), ENT_QUOTES, 'UTF-8' );

                $outgoing = array();
                if ( preg_match_all( '/<a[^>]+href=["\']([^"\'#]+)["\'][^>]*>/i', $content, $lm ) ) {
                    foreach ( $lm[1] as $href ) {
                        if ( strpos( $href, $host ) !== false || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                            $tid = hts_url_to_postid( $this->resolve_url( $href, $site_url ) );
                            if ( $tid && $tid !== $p->ID ) $outgoing[] = $tid;
                        }
                    }
                }
                $outgoing = array_unique( $outgoing );

                $kw_text = $p->post_title . ' ' . $p->post_title . ' ' . mb_substr( $cd, 0, 2000 );
                $keywords = $this->extract_keywords( $kw_text, 12 );

                $cats = wp_get_post_categories( $p->ID, array( 'fields' => 'all' ) );
                $tags = wp_get_post_tags( $p->ID, array( 'fields' => 'all' ) );
                preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $content, $h2m );

                $nodes[ $p->ID ] = array(
                    'id'           => $p->ID,
                    'title'        => $p->post_title,
                    'url'          => get_permalink( $p->ID ),
                    'edit_url'     => get_edit_post_link( $p->ID, 'raw' ),
                    'type'         => $p->post_type,
                    'categories'   => wp_list_pluck( $cats, 'name' ),
                    'tags'         => wp_list_pluck( $tags, 'name' ),
                    'keywords'     => $keywords,
                    'outgoing'     => $outgoing,
                    'incoming'     => array(),
                    'word_count'   => hts_word_count( $cd ),
                    'h2_count'     => count( $h2m[0] ),
                    'date'         => $p->post_date,
                    'cluster'      => '',
                    'role'         => '',
                    'pillar_score' => 0,
                );
            }

            $wip['nodes'] = $nodes;
            set_transient( $wip_key, $wip, 1800 );

            $processed = min( $offset + $_scan_count, $total );
            wp_send_json_success( array(
                'step' => 'scan', 'done' => ( $processed >= $total ),
                'processed' => $processed, 'total' => $total,
            ) );
        }

        // ────────────────────────────────────────────────
        //  STEP: LINKS — Incoming links + pillar scores
        // ────────────────────────────────────────────────
        if ( $step === 'links' ) {
            $wip = get_transient( $wip_key );
            if ( ! $wip ) wp_send_json_error( 'Session expirée. Relancez l\'analyse.' );

            $nodes = &$wip['nodes'];
            $links = array();

            // Load embeddings
            $link_vectors = null;
            if ( class_exists( 'HTS_Embeddings' ) ) {
                $emb_loader = new \HTS_Embeddings();
                $link_vectors = $emb_loader->load_all_vectors();
            }
            $toxic_links = array();

            // Incoming links + semantic scoring
            foreach ( $nodes as $id => &$node ) {
                foreach ( $node['outgoing'] as $tid ) {
                    if ( isset( $nodes[ $tid ] ) ) {
                        $nodes[ $tid ]['incoming'][] = $id;
                        $link_sim = 1.0;
                        if ( $link_vectors && isset( $link_vectors[ $id ] ) && isset( $link_vectors[ $tid ] ) ) {
                            $link_sim = \HTS_Embeddings::cosine_similarity( $link_vectors[ $id ], $link_vectors[ $tid ] );
                        }
                        $is_toxic = ( $link_vectors && isset( $link_vectors[ $id ] ) && isset( $link_vectors[ $tid ] ) && $link_sim < 0.30 );
                        $links[] = array( 'source' => $id, 'target' => $tid, 'similarity' => round( $link_sim, 3 ), 'toxic' => $is_toxic );
                        if ( $is_toxic ) {
                            $toxic_links[] = array( 'source_id' => $id, 'target_id' => $tid,
                                'source_title' => $nodes[ $id ]['title'], 'target_title' => $nodes[ $tid ]['title'],
                                'similarity' => round( $link_sim, 3 ) );
                        }
                    }
                }
            }
            unset( $node );

            // Semantic counts
            foreach ( $nodes as &$node ) {
                $node['incoming'] = array_unique( $node['incoming'] );
                $node['out_count'] = count( $node['outgoing'] );
                $node['in_count']  = count( $node['incoming'] );
                $node['in_count_semantic'] = 0;
                $node['out_count_semantic'] = 0;
                if ( $link_vectors ) {
                    foreach ( $node['incoming'] as $src ) {
                        if ( isset( $link_vectors[ $src ] ) && isset( $link_vectors[ $node['id'] ] ) ) {
                            $sim = \HTS_Embeddings::cosine_similarity( $link_vectors[ $src ], $link_vectors[ $node['id'] ] );
                            if ( $sim >= 0.30 ) $node['in_count_semantic']++;
                        } else { $node['in_count_semantic']++; }
                    }
                    foreach ( $node['outgoing'] as $tgt ) {
                        if ( isset( $link_vectors[ $node['id'] ] ) && isset( $link_vectors[ $tgt ] ) ) {
                            $sim = \HTS_Embeddings::cosine_similarity( $link_vectors[ $node['id'] ], $link_vectors[ $tgt ] );
                            if ( $sim >= 0.30 ) $node['out_count_semantic']++;
                        } else { $node['out_count_semantic']++; }
                    }
                } else {
                    $node['in_count_semantic']  = $node['in_count'];
                    $node['out_count_semantic'] = $node['out_count'];
                }
                $node['is_orphan']   = $node['in_count_semantic'] === 0;
                $node['is_dead_end'] = $node['out_count'] === 0;
            }
            unset( $node );

            // BFS click depth
            $home_id = (int) get_option( 'page_on_front', 0 );
            foreach ( $nodes as &$node ) { $node['click_depth'] = PHP_INT_MAX; } unset( $node );
            $bfs_root = null;
            if ( $home_id && isset( $nodes[ $home_id ] ) ) { $bfs_root = $home_id; }
            else { $max_in = -1; foreach ( $nodes as $id => $n ) { if ( $n['in_count'] > $max_in ) { $max_in = $n['in_count']; $bfs_root = $id; } } }
            if ( $bfs_root !== null ) {
                $nodes[ $bfs_root ]['click_depth'] = 0;
                $queue = array( $bfs_root ); $visited = array( $bfs_root => true );
                while ( ! empty( $queue ) ) {
                    $current = array_shift( $queue );
                    $depth = $nodes[ $current ]['click_depth'];
                    foreach ( $nodes[ $current ]['outgoing'] as $tid ) {
                        if ( isset( $nodes[ $tid ] ) && ! isset( $visited[ $tid ] ) ) {
                            $visited[ $tid ] = true; $nodes[ $tid ]['click_depth'] = $depth + 1; $queue[] = $tid;
                        }
                    }
                }
            }

            // Pillar scores
            foreach ( $nodes as $pid => &$node ) {
                $s  = min( 1, $node['word_count'] / 1500 ) * 20;
                $s += min( 1, $node['in_count_semantic'] / 4 ) * 25;
                $s += ( min( $node['out_count_semantic'], 10 ) / 10 ) * 10;
                $s += min( 1, $node['h2_count'] / 5 ) * 10;
                $s += min( count( $node['keywords'] ), 5 ) * 1.5;
                if ( $node['type'] === 'page' ) $s += 10;
                $gsc_clicks = (int) get_post_meta( (int) $pid, '_hts_gsc_clicks', true );
                $gsc_pos    = (float) get_post_meta( (int) $pid, '_hts_gsc_position', true );
                if ( $gsc_clicks > 0 ) $s += min( 1, $gsc_clicks / 20 ) * 12;
                if ( $gsc_pos > 0 && $gsc_pos <= 10 ) $s += max( 0, ( 10 - $gsc_pos ) / 10 ) * 8;
                $node['pillar_score'] = round( min( 100, $s ), 1 );
            }
            unset( $node );

            $wip['nodes'] = $nodes;
            $wip['links'] = $links;
            $wip['toxic_links'] = $toxic_links;
            set_transient( $wip_key, $wip, 1800 );

            // ── Save partial data (nodes + links) — preserve existing clusters ──
            $opt_key = $wip['opt_key'];
            $_existing_data = get_option( $opt_key, array() );
            $_existing_clusters = $_existing_data['clusters'] ?? array();

            $partial_result = array(
                'nodes' => $nodes, 'links' => $links, 'clusters' => $_existing_clusters,
                'lang' => $wip['lang'], 'toxic_links' => $toxic_links, 'flagged_pages' => array(),
                'stats' => array(
                    'total_pages' => count( $nodes ), 'total_links' => count( $links ),
                    'total_toxic_links' => count( $toxic_links ),
                ),
            );
            update_option( $opt_key, $partial_result, false );
            update_option( 'hts_cocon_last_analysis', time(), false );
            self::$cocon_data_cache = array();
            $default_lang = function_exists( 'pll_default_language' ) ? pll_default_language( 'slug' ) : '';
            if ( $wip['lang'] && $wip['lang'] === $default_lang && $opt_key !== 'hts_cocon_data' ) {
                update_option( 'hts_cocon_data', $partial_result, false );
            }

            // ── Trigger money page discovery ──
            if ( class_exists( 'HTS_Cocon_Commander' ) ) {
                $cc = new \HTS_Cocon_Commander();
                if ( method_exists( $cc, 'discover_money_pages' ) ) {
                    $mp_data = $cc->discover_money_pages( true );
                    $mp_count = count( array_filter( $mp_data['pages'] ?? array(), function( $p ) {
                        return ( $p['score'] ?? 0 ) >= 30 && empty( $p['dismissed'] );
                    } ) );
                }
            }

            hts_add_log( sprintf( 'Analyse chunked links: %d liens, %d toxiques, %d pages business', count( $links ), count( $toxic_links ), $mp_count ?? 0 ), 'info', 'cocon' );
            wp_send_json_success( array(
                'step' => 'links', 'links' => count( $links ), 'toxic' => count( $toxic_links ),
                'money_pages' => $mp_count ?? 0,
            ) );
        }

        // ────────────────────────────────────────────────
        //  STEP: EMBED — Index missing embeddings for analysis pages
        // ────────────────────────────────────────────────
        if ( $step === 'embed' ) {
            $wip = get_transient( $wip_key );
            if ( ! $wip ) wp_send_json_error( 'Session expirée. Relancez l\'analyse.' );

            if ( ! class_exists( 'HTS_Embeddings' ) || ! function_exists( 'hts_get_openai_key' ) || empty( hts_get_openai_key() ) ) {
                wp_send_json_success( array( 'step' => 'embed', 'done' => true, 'skipped' => true, 'message' => 'Embeddings ignorés (pas de clé OpenAI).' ) );
            }

            $emb = new \HTS_Embeddings();
            $pending = $emb->get_pending_posts( 500 );

            // Filter to only pages in our analysis
            $our_ids = array_flip( $wip['post_ids'] );
            $pending = array_values( array_filter( $pending, function( $p ) use ( $our_ids ) {
                return isset( $our_ids[ $p['ID'] ] );
            } ) );
            $total = count( $pending );

            if ( $offset >= $total || $total === 0 ) {
                wp_send_json_success( array( 'step' => 'embed', 'done' => true, 'total' => $total, 'message' => $total === 0 ? 'Tous les embeddings sont à jour.' : $total . ' embeddings indexés.' ) );
            }

            $batch = array_slice( $pending, $offset, 10 );
            $indexed = 0;
            $_emb_start = microtime( true );
            foreach ( $batch as $p ) {
                if ( class_exists( 'HTS_Job_Runner' ) && ! HTS_Job_Runner::has_time( $_emb_start ) ) break;
                if ( $emb->index_post( (int) $p['ID'] ) ) $indexed++;
            }

            $processed = min( $offset + $indexed, $total );
            wp_send_json_success( array(
                'step' => 'embed', 'done' => ( $processed >= $total ),
                'processed' => $processed, 'total' => $total, 'indexed' => $indexed,
            ) );
        }

        // ────────────────────────────────────────────────
        //  STEP: CLUSTER — Run clustering algorithm
        // ────────────────────────────────────────────────
        if ( $step === 'cluster' ) {
            $wip = get_transient( $wip_key );
            if ( ! $wip ) wp_send_json_error( 'Session expirée. Relancez l\'analyse.' );

            $this->analysis_lang = $wip['lang'] ?: 'fr';
            $nodes = $wip['nodes'];

            // Read explicit pillar IDs from UI (sent by htsCreateGroups JS)
            $explicit_pillar_ids = array();
            if ( ! empty( $_POST['pillar_ids'] ) ) {
                $explicit_pillar_ids = array_filter( array_map( 'intval', explode( ',', sanitize_text_field( $_POST['pillar_ids'] ) ) ) );
                hts_add_log( sprintf( 'Cluster step: %d pillar IDs reçus depuis UI: %s', count( $explicit_pillar_ids ), implode( ', ', $explicit_pillar_ids ) ), 'info', 'cocon' );
            }

            // Clustering decision tree — v2.6.3: Embeddings Seeded > Embeddings > AI > TF-IDF
            $has_embeddings = class_exists( 'HTS_Embeddings' );
            $emb_stats = $has_embeddings ? \HTS_Embeddings::get_stats() : array( 'coverage' => 0 );
            $_cluster_max_time = (int) ini_get( 'max_execution_time' );
            $_cluster_limited  = ( $_cluster_max_time > 0 && $_cluster_max_time <= 60 );

            if ( $has_embeddings && ( $emb_stats['coverage'] ?? 0 ) >= 50 && ! empty( $explicit_pillar_ids ) ) {
                // BEST: embeddings seeded — déterministe, rapide, scale à 10K+ (NO LLM)
                $clusters = $this->cluster_with_embeddings_seeded( $nodes, $explicit_pillar_ids, true );
            } elseif ( $has_embeddings && ( $emb_stats['coverage'] ?? 0 ) >= 50 ) {
                // GOOD: embeddings k-medoids — NO LLM
                $clusters = $this->cluster_with_embeddings( $nodes );
            } elseif ( $_cluster_limited ) {
                // LIMITED SERVER: skip LLM, use TF-IDF (local, fast, no API call)
                hts_add_log( 'Clustering: serveur limité (' . $_cluster_max_time . 's) → TF-IDF local (pas d\'appel LLM)', 'info', 'cocon' );
                $clusters = $this->cluster_with_tfidf( $nodes );
            } elseif ( ! empty( $this->openai_key ) && count( $nodes ) >= 3 ) {
                // FALLBACK: AI sans embeddings (requires LLM API call)
                $clusters = $this->cluster_with_ai( $nodes );
            } else {
                // DERNIER RECOURS: TF-IDF
                $clusters = $this->cluster_with_tfidf( $nodes );
            }

            // Safety net: if Non classé > 40%, fallback to WP categories
            $total_node_count = count( $nodes );
            $nc_count = 0;
            foreach ( $clusters as $cn => $cl ) {
                if ( mb_strtolower( $cn ) === 'non classé' || mb_strtolower( $cn ) === 'non classe' ) {
                    $nc_count = count( $cl['pages'] ?? array() );
                }
            }
            if ( $total_node_count > 10 && $nc_count > $total_node_count * 0.4 ) {
                hts_add_log( sprintf( 'Clustering échoué (%d/%d "Non classé") → fallback catégories', $nc_count, $total_node_count ), 'warn', 'cocon' );
                $clusters = $this->cluster_with_wp_categories( $nodes );
            }

            $wip['clusters'] = $clusters;
            set_transient( $wip_key, $wip, 1800 );

            hts_add_log( sprintf( 'Analyse chunked cluster: %d clusters', count( $clusters ) ), 'info', 'cocon' );
            wp_send_json_success( array( 'step' => 'cluster', 'clusters' => count( $clusters ) ) );
        }

        // ────────────────────────────────────────────────
        //  STEP: FINALIZE — Roles, stats, save
        // ────────────────────────────────────────────────
        if ( $step === 'finalize' ) {
            $wip = get_transient( $wip_key );
            if ( ! $wip ) wp_send_json_error( 'Session expirée. Relancez l\'analyse.' );

            $nodes       = $wip['nodes'];
            $links       = $wip['links'];
            $clusters    = $wip['clusters'];
            $toxic_links = $wip['toxic_links'] ?? array();
            $lang        = $wip['lang'];
            $opt_key     = $wip['opt_key'];

            // Phase 5: Assign roles
            $max_pillar_score = 1;
            foreach ( $nodes as $n ) {
                if ( $n['pillar_score'] > $max_pillar_score ) $max_pillar_score = $n['pillar_score'];
            }

            // Load vectors for semantic pillar selection
            $has_vectors = class_exists( 'HTS_Embeddings' );
            $all_vectors = array();
            if ( $has_vectors ) {
                $emb_loader = new \HTS_Embeddings();
                $all_vectors = $emb_loader->load_all_vectors();
            }

            foreach ( $clusters as $cname => &$cl ) {
                // RESPECT seeded/o3 pillar choice if set and valid
                if ( ! empty( $cl['pillar_id'] ) && isset( $nodes[ $cl['pillar_id'] ] ) && in_array( $cl['pillar_id'], $cl['pages'] ) ) {
                    $pid_best = $cl['pillar_id'];
                } else {
                    // Auto-calculate pillar (fallback for free mode or invalid pillar)
                    $best_combined = -1; $pid_best = 0;
                    $cluster_vectors = array();
                    if ( $has_vectors && ! empty( $all_vectors ) ) {
                        foreach ( $cl['pages'] as $pid ) {
                            if ( isset( $all_vectors[ $pid ] ) ) $cluster_vectors[ $pid ] = $all_vectors[ $pid ];
                        }
                    }

                    if ( count( $cluster_vectors ) >= 2 ) {
                        $dim = count( reset( $cluster_vectors ) );
                        $centroid = array_fill( 0, $dim, 0.0 );
                        foreach ( $cluster_vectors as $vec ) { for ( $d = 0; $d < $dim; $d++ ) $centroid[ $d ] += $vec[ $d ]; }
                        $cnt = count( $cluster_vectors );
                        for ( $d = 0; $d < $dim; $d++ ) $centroid[ $d ] /= $cnt;
                        foreach ( $cl['pages'] as $pid ) {
                            if ( ! isset( $nodes[ $pid ] ) ) continue;
                            $ps_norm = $nodes[ $pid ]['pillar_score'] / $max_pillar_score;
                            $sem_score = isset( $cluster_vectors[ $pid ] ) ? \HTS_Embeddings::cosine_similarity( $cluster_vectors[ $pid ], $centroid ) : 0;
                            $combined = $ps_norm * 0.4 + $sem_score * 0.6;
                            if ( $combined > $best_combined ) { $best_combined = $combined; $pid_best = $pid; }
                        }
                    } else {
                        foreach ( $cl['pages'] as $pid ) {
                            if ( isset( $nodes[ $pid ] ) && $nodes[ $pid ]['pillar_score'] > $best_combined ) {
                                $best_combined = $nodes[ $pid ]['pillar_score']; $pid_best = $pid;
                            }
                        }
                    }
                }
                $cl['pillar_id'] = $pid_best;
                foreach ( $cl['pages'] as $pid ) {
                    if ( ! isset( $nodes[ $pid ] ) ) continue;
                    $nodes[ $pid ]['cluster'] = $cname;
                    if ( $pid === $pid_best ) { $nodes[ $pid ]['role'] = 'pilier'; }
                    elseif ( $nodes[ $pid ]['is_orphan'] && $nodes[ $pid ]['is_dead_end'] ) { $nodes[ $pid ]['role'] = 'orpheline'; }
                    elseif ( $pid_best && ( in_array( $pid_best, $nodes[ $pid ]['outgoing'] ) || in_array( $pid, $nodes[ $pid_best ]['outgoing'] ?? array() ) ) ) { $nodes[ $pid ]['role'] = 'fille'; }
                    else { $nodes[ $pid ]['role'] = 'satellite'; }
                }
            }
            unset( $cl );

            foreach ( $nodes as &$node ) {
                if ( empty( $node['cluster'] ) ) { $node['cluster'] = 'Non classé'; $node['role'] = $node['is_orphan'] ? 'orpheline' : 'satellite'; }
            }
            unset( $node );

            // Phase 6: Cluster metrics
            $toxic_lookup = array();
            foreach ( $toxic_links as $tl ) { $toxic_lookup[ $tl['source_id'] . ':' . $tl['target_id'] ] = true; }

            foreach ( $clusters as &$cl ) {
                $n = count( $cl['pages'] ); $internal = 0; $internal_semantic = 0; $internal_toxic = 0;
                $orphans = 0; $dead = 0; $cl_toxic_links = array();
                foreach ( $cl['pages'] as $pid ) {
                    if ( ! isset( $nodes[ $pid ] ) ) continue;
                    if ( $nodes[ $pid ]['is_orphan'] ) $orphans++;
                    if ( $nodes[ $pid ]['is_dead_end'] ) $dead++;
                    foreach ( $nodes[ $pid ]['outgoing'] as $tid ) {
                        if ( in_array( $tid, $cl['pages'] ) ) {
                            $internal++;
                            $link_key = $pid . ':' . $tid;
                            if ( isset( $toxic_lookup[ $link_key ] ) ) {
                                $internal_toxic++;
                                foreach ( $toxic_links as $tl ) { if ( $tl['source_id'] === $pid && $tl['target_id'] === $tid ) { $cl_toxic_links[] = $tl; break; } }
                            } else { $internal_semantic++; }
                        }
                    }
                }
                $max_p = $n * ( $n - 1 );
                $cl['total_links']     = $internal;
                $cl['semantic_links']  = $internal_semantic;
                $cl['toxic_links']     = $internal_toxic;
                $cl['toxic_link_list'] = $cl_toxic_links;
                $cl['density']         = $max_p > 0 ? round( $internal_semantic / $max_p * 100, 1 ) : 0;
                $cl['page_count']      = $n;
                $cl['orphans']         = $orphans;
                $cl['dead_ends']       = $dead;

                $connected = 0;
                if ( $cl['pillar_id'] && isset( $nodes[ $cl['pillar_id'] ] ) ) {
                    foreach ( $cl['pages'] as $pid ) {
                        if ( $pid === $cl['pillar_id'] || ! isset( $nodes[ $pid ] ) ) continue;
                        if ( in_array( $cl['pillar_id'], $nodes[ $pid ]['outgoing'] ) || in_array( $pid, $nodes[ $cl['pillar_id'] ]['outgoing'] ) ) $connected++;
                    }
                }
                $cl['connected_to_pillar'] = $connected;
                $cl['pillar_coverage'] = $n > 1 ? round( $connected / ( $n - 1 ) * 100 ) : 100;

                // Sibling density
                $siblings = array_values( array_filter( $cl['pages'], function( $pid ) use ( $cl ) { return $pid !== ( $cl['pillar_id'] ?? 0 ); } ) );
                $sib_count = count( $siblings ); $sib_linked = 0; $sib_total_pairs = 0;
                if ( $sib_count >= 2 ) {
                    for ( $i = 0; $i < $sib_count; $i++ ) {
                        for ( $j = $i + 1; $j < $sib_count; $j++ ) {
                            $sib_total_pairs++;
                            if ( isset( $nodes[ $siblings[ $i ] ] ) && isset( $nodes[ $siblings[ $j ] ] ) ) {
                                if ( in_array( $siblings[ $j ], $nodes[ $siblings[ $i ] ]['outgoing'] ) || in_array( $siblings[ $i ], $nodes[ $siblings[ $j ] ]['outgoing'] ) ) $sib_linked++;
                            }
                        }
                    }
                }
                $cl['sibling_density'] = $sib_total_pairs > 0 ? round( $sib_linked / $sib_total_pairs * 100, 1 ) : 100;
            }
            unset( $cl );

            uasort( $clusters, function( $a, $b ) { return $b['page_count'] - $a['page_count']; } );

            $total_orphans  = count( array_filter( $nodes, function( $n ) { return $n['is_orphan']; } ) );
            $total_dead     = count( array_filter( $nodes, function( $n ) { return $n['is_dead_end']; } ) );
            $total_pillars  = count( array_filter( $nodes, function( $n ) { return $n['role'] === 'pilier'; } ) );
            $content_clusters = array_filter( $clusters, function( $cl ) { return ( $cl['name'] ?? '' ) !== 'Non classé'; } );
            $avg_sil = 0; $sil_cnt = 0; $border_total = 0;
            foreach ( $content_clusters as $cl ) {
                if ( isset( $cl['silhouette'] ) ) { $avg_sil += $cl['silhouette']; $sil_cnt++; }
                $border_total += count( $cl['border_pages'] ?? array() );
            }

            $result = array(
                'nodes' => $nodes, 'links' => $links, 'clusters' => $clusters,
                'lang' => $lang, 'toxic_links' => $toxic_links, 'flagged_pages' => array(),
                'stats' => array(
                    'total_pages' => count( $nodes ), 'total_links' => count( $links ),
                    'total_toxic_links' => count( $toxic_links ), 'total_flagged_pages' => 0,
                    'total_pending_review' => 0, 'total_orphans' => $total_orphans,
                    'total_dead_ends' => $total_dead, 'total_clusters' => count( $clusters ),
                    'total_pillars' => $total_pillars,
                    'avg_links_per_page' => count( $nodes ) > 0 ? round( count( $links ) / count( $nodes ), 1 ) : 0,
                    'avg_silhouette' => $sil_cnt > 0 ? round( $avg_sil / $sil_cnt, 3 ) : null,
                    'total_border_pages' => $border_total,
                    'clustering_quality' => $sil_cnt > 0 ? ( ( $avg_sil / $sil_cnt ) >= 0.3 ? 'bon' : ( ( $avg_sil / $sil_cnt ) >= 0.15 ? 'moyen' : 'faible' ) ) : 'inconnu',
                    'deep_pages' => count( array_filter( $nodes, function( $n ) { return ( $n['click_depth'] ?? 0 ) > 3 && ( $n['click_depth'] ?? 0 ) < PHP_INT_MAX; } ) ),
                    'avg_click_depth' => $this->avg_click_depth( $nodes ),
                    'avg_sibling_density' => $this->avg_sibling_density( $clusters ),
                ),
            );

            // Save
            global $wpdb;
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_cocon_sug_%' OR option_name LIKE '_transient_timeout_hts_cocon_sug_%'" );
            update_option( $opt_key, $result, false );
            update_option( 'hts_cocon_last_analysis', time(), false );
            self::$cocon_data_cache = array();
            // Force WP object cache to drop stale cocon data
            wp_cache_delete( $opt_key, 'options' );
            wp_cache_delete( 'hts_cocon_data', 'options' );

            $default_lang = function_exists( 'pll_default_language' ) ? pll_default_language( 'slug' ) : '';
            if ( $lang && $lang === $default_lang && $opt_key !== 'hts_cocon_data' ) {
                update_option( 'hts_cocon_data', $result, false );
            }
            // ALSO save to fallback key if not multilingual, to cover all read paths
            if ( ! class_exists( 'HTS_Language' ) || ! \HTS_Language::is_multilingual() ) {
                if ( $opt_key !== 'hts_cocon_data' ) {
                    update_option( 'hts_cocon_data', $result, false );
                }
            }

            if ( class_exists( 'HTS_Cocon_Commander' ) ) {
                \HTS_Cocon_Commander::cocon_log( 'debug_step', 'FINALIZE SAVE opt_key=' . $opt_key . ' lang=' . $lang . ' clusters=' . count( $clusters ) . ' nodes=' . count( $nodes ) . ' default_lang=' . $default_lang );
            }

            // Clean WIP transient
            delete_transient( $wip_key );

            // Clear awaiting_maillage flag
            delete_option( 'hts_cocon_awaiting_maillage' );

            if ( $wip['force'] ) {
                delete_option( 'hts_money_pages_discovery' );
                delete_option( 'hts_money_pages_discovery_' . $lang );
            }

            $elapsed = time() - ( $wip['started_at'] ?? time() );
            hts_add_log( sprintf( 'Analyse chunked terminée: %d pages, %d clusters en %ds', count( $nodes ), count( $clusters ), $elapsed ), 'info', 'cocon' );

            wp_send_json_success( array(
                'step' => 'done',
                'message' => count( $nodes ) . ' articles analysés, ' . count( $clusters ) . ' groupes créés.',
                'stats' => $result['stats'],
            ) );
        }

        wp_send_json_error( 'Étape inconnue: ' . $step );
    }

    /**
    public function ajax_restore_backup() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier( 2 );

        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }

        $opt_key    = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang
            : 'hts_cocon_data';
        $backup_key = $opt_key . '_backup';
        $backup     = get_option( $backup_key, array() );
        $backup_ts  = get_option( $backup_key . '_ts', '' );

        if ( empty( $backup ) || empty( $backup['clusters'] ) ) {
            wp_send_json_error( array( 'message' => 'Aucun backup disponible. Le backup est créé automatiquement avant chaque analyse.' ) );
        }

        // Restore
        update_option( $opt_key, $backup, false );

        // Invalidate runtime cache after restore
        self::$cocon_data_cache = array();

        $cluster_count = count( $backup['clusters'] );
        $node_count    = count( $backup['nodes'] ?? array() );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                '🔄 Cocon RESTAURÉ depuis backup (%s) : %d clusters, %d nodes',
                $backup_ts, $cluster_count, $node_count
            ), 'success', 'cocon' );
        }

        wp_send_json_success( array(
            'message'    => sprintf( 'Données restaurées : %d groupes, %d pages (backup du %s).', $cluster_count, $node_count, $backup_ts ),
            'clusters'   => $cluster_count,
            'nodes'      => $node_count,
            'backup_ts'  => $backup_ts,
        ) );
    }

    /**
     * AJAX: Export cocon data as JSON (for transfer between environments).
     */
    public function ajax_export_data() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier( 1 );

        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }
        $opt_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang : 'hts_cocon_data';

        $data = get_option( $opt_key, array() );
        if ( empty( $data ) ) wp_send_json_error( 'Aucune donnée cocon.' );

        wp_send_json_success( array(
            'data'     => $data,
            'opt_key'  => $opt_key,
            'clusters' => count( $data['clusters'] ?? array() ),
            'nodes'    => count( $data['nodes'] ?? array() ),
            'exported' => current_time( 'mysql' ),
        ) );
    }

    /**
     * AJAX: Import cocon data from JSON (for transfer between environments).
     * Requires the full data structure as exported by ajax_export_data.
     */
    public function ajax_import_data() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier( 2 );

        $json = stripslashes( $_POST['cocon_data'] ?? '' );
        $data = json_decode( $json, true );

        if ( empty( $data ) || empty( $data['clusters'] ) || empty( $data['nodes'] ) ) {
            wp_send_json_error( 'Données invalides. Utilisez le JSON exporté par Hack The SEO.' );
        }

        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }
        $opt_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
            ? 'hts_cocon_data_' . $lang : 'hts_cocon_data';

        // Backup current data before import
        $old = get_option( $opt_key, array() );
        if ( ! empty( $old['clusters'] ) ) {
            update_option( $opt_key . '_backup', $old, false );
            update_option( $opt_key . '_backup_ts', current_time( 'mysql' ), false );
        }

        update_option( $opt_key, $data, false );

        // Invalidate runtime cache after import
        self::$cocon_data_cache = array();

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                '📥 Cocon importé : %d clusters, %d nodes',
                count( $data['clusters'] ), count( $data['nodes'] )
            ), 'success', 'cocon' );
        }

        wp_send_json_success( array(
            'message'  => sprintf( 'Import réussi : %d groupes, %d pages.', count( $data['clusters'] ), count( $data['nodes'] ) ),
            'clusters' => count( $data['clusters'] ),
            'nodes'    => count( $data['nodes'] ),
        ) );
    }

    /**
     * AJAX: Purge ALL cocon data for a specific language.
     * Deletes clusters, nodes, money pages cache, backup, and missing clusters.
     * Does NOT delete WordPress posts or meta — only HTS analysis data.
     */
    public function ajax_purge_data() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier( 2 );

        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( $lang === 'all' ) $lang = '';

        // Resolve language
        if ( empty( $lang ) ) {
            $lang = substr( get_locale(), 0, 2 );
        }

        $deleted = array();

        // Cocon data (clusters + nodes)
        $keys_to_delete = array(
            'hts_cocon_data_' . $lang,
            'hts_cocon_data_' . $lang . '_backup',
            'hts_cocon_data_' . $lang . '_backup_ts',
            'hts_money_pages_discovery_' . $lang,
        );

        // Also delete unsuffixed if this is the default language
        $default_lang = function_exists( 'pll_default_language' ) ? pll_default_language( 'slug' ) : substr( get_locale(), 0, 2 );
        if ( $lang === $default_lang || empty( $lang ) ) {
            $keys_to_delete[] = 'hts_cocon_data';
            $keys_to_delete[] = 'hts_cocon_data_backup';
            $keys_to_delete[] = 'hts_cocon_data_backup_ts';
            $keys_to_delete[] = 'hts_money_pages_discovery';
        }

        // Missing clusters suggestion cache
        $keys_to_delete[] = 'hts_cocon_missing_clusters';

        foreach ( $keys_to_delete as $k ) {
            if ( get_option( $k ) !== false ) {
                delete_option( $k );
                $deleted[] = $k;
            }
        }

        // Clear static cache
        self::$cocon_data_cache = array();

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'PURGE cocon (%s) : %d options supprimées — %s',
                strtoupper( $lang ), count( $deleted ), implode( ', ', $deleted )
            ), 'warn', 'cocon' );
        }

        wp_send_json_success( array(
            'message' => sprintf( 'Données %s purgées (%d options supprimées). Relancez l\'analyse pour recréer les groupes.', strtoupper( $lang ), count( $deleted ) ),
            'deleted' => $deleted,
        ) );
    }

    public function ajax_graph_data() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $filter = sanitize_text_field( $_POST['cluster'] ?? '' );
        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! $lang && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }
        $data = self::get_cached_cocon_data( $lang );
        if ( empty( $data['nodes'] ) ) $data = $this->analyze_site( $lang );

        // ── Injection des articles de cocon manquants dans les nodes ──
        if ( $filter ) {
            $plans = get_option( 'hts_cocon_plans', array() );
            $target_cids = array();
            foreach ( $plans as $pid => $plan ) {
                $pk = $plan['keyword'] ?? $plan['pillar_title'] ?? '';
                if ( $pk === $filter || (string) $pid === $filter ) $target_cids[] = (string) $pid;
            }
            if ( empty( $target_cids ) ) {
                $fl = mb_strtolower( $filter );
                foreach ( $plans as $pid => $plan ) {
                    $pkl = mb_strtolower( $plan['keyword'] ?? '' );
                    if ( $pkl && ( mb_strpos( $pkl, $fl ) !== false || mb_strpos( $fl, $pkl ) !== false ) ) $target_cids[] = (string) $pid;
                }
            }
            if ( ! empty( $target_cids ) ) {
                $cocon_posts = get_posts( array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => array( 'publish', 'draft' ),
                    'meta_query'     => array(
                        array(
                            'key'     => '_hts_cocon_id',
                            'value'   => $target_cids,
                            'compare' => 'IN',
                        ),
                    ),
                    'posts_per_page' => 100,
                ) );
                foreach ( $cocon_posts as $cp ) {
                    if ( isset( $data['nodes'][ $cp->ID ] ) ) continue;
                    $data['nodes'][ $cp->ID ] = array(
                        'id' => $cp->ID, 'title' => $cp->post_title, 'cluster' => $filter,
                        'role' => 'page', 'url' => get_permalink( $cp->ID ),
                        'edit_url' => get_edit_post_link( $cp->ID, 'raw' ) ?: '',
                        'in_count' => 0, 'out_count' => 0, 'is_orphan' => true, 'is_dead_end' => true,
                        'keywords' => array(), 'pillar_score' => 0, 'click_depth' => PHP_INT_MAX,
                        'is_draft' => ( $cp->post_status === 'draft' ),
                    );
                }
            }
        }

        $ns = array(); $ls = array(); $cids = array();
        $gsc_pos_sum = 0; $gsc_pos_ct = 0; $gsc_clicks_total = 0; $gsc_impr_total = 0;
        foreach ( $data['nodes'] as $n ) {
            if ( $filter && $n['cluster'] !== $filter ) continue;
            $cids[] = $n['id'];
            // S14: use _hts_combined_score (the score clients see in WP admin) for graph display
            $bo_score = (int) get_post_meta( (int) $n['id'], '_hts_combined_score', true );
            // S14: GSC data per node for sidebar display
            $node_clicks = (int) get_post_meta( (int) $n['id'], '_hts_gsc_clicks', true );
            $node_impr   = (int) get_post_meta( (int) $n['id'], '_hts_gsc_impressions', true );
            $node_pos    = (float) get_post_meta( (int) $n['id'], '_hts_gsc_position', true );
            $node_ctr    = (float) get_post_meta( (int) $n['id'], '_hts_gsc_ctr', true );
            // Accumulate for cluster averages
            $gsc_clicks_total += $node_clicks;
            $gsc_impr_total   += $node_impr;
            if ( $node_pos > 0 ) { $gsc_pos_sum += $node_pos; $gsc_pos_ct++; }
            $is_draft = ! empty( $n['is_draft'] ) || get_post_status( (int) $n['id'] ) === 'draft';
            $ns[] = array( 'id' => $n['id'], 'title' => mb_substr( $n['title'], 0, 50 ), 'cluster' => $n['cluster'], 'role' => $n['role'], 'in' => $n['in_count'], 'out' => $n['out_count'], 'orphan' => $n['is_orphan'], 'dead_end' => $n['is_dead_end'], 'url' => $n['url'], 'edit_url' => $n['edit_url'], 'score' => $bo_score > 0 ? $bo_score : $n['pillar_score'], 'pillar_score' => $n['pillar_score'], 'click_depth' => $n['click_depth'] ?? PHP_INT_MAX, 'gsc_clicks' => $node_clicks, 'gsc_impressions' => $node_impr, 'gsc_position' => round( $node_pos, 1 ), 'gsc_ctr' => round( $node_ctr, 2 ), 'is_draft' => $is_draft );
        }
        foreach ( $data['links'] as $l ) {
            if ( $filter && ( ! in_array( $l['source'], $cids ) || ! in_array( $l['target'], $cids ) ) ) continue;
            $ls[] = $l;
        }

        // Scan liens HTML réels pour les articles du graph (complète les liens NLP)
        $existing_pairs = array();
        foreach ( $ls as $el ) { $existing_pairs[ $el['source'] . '_' . $el['target'] ] = true; }
        foreach ( $cids as $cid_scan ) {
            $scan_content = get_post_field( 'post_content', $cid_scan );
            if ( empty( $scan_content ) ) continue;
            preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>/i', $scan_content, $href_matches );
            foreach ( $href_matches[1] as $href ) {
                $linked_id = hts_url_to_postid( $href );
                if ( $linked_id && $linked_id !== $cid_scan && in_array( $linked_id, $cids, true ) ) {
                    $pair = $cid_scan . '_' . $linked_id;
                    if ( ! isset( $existing_pairs[ $pair ] ) ) {
                        $ls[] = array( 'source' => $cid_scan, 'target' => $linked_id, 'type' => 'internal' );
                        $existing_pairs[ $pair ] = true;
                    }
                }
            }
        }

        // S14: cluster-level GSC aggregates
        $cluster_gsc = array(
            'avg_position'    => $gsc_pos_ct > 0 ? round( $gsc_pos_sum / $gsc_pos_ct, 1 ) : 0,
            'total_clicks'    => $gsc_clicks_total,
            'total_impressions' => $gsc_impr_total,
            'pages_with_gsc'  => $gsc_pos_ct,
        );
        wp_send_json_success( array( 'nodes' => array_values( $ns ), 'links' => $ls, 'clusters' => array_keys( $data['clusters'] ?? array() ), 'gsc' => $cluster_gsc ) );
    }

    public function ajax_suggest_links() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $cl = sanitize_text_field( $_POST['cluster'] ?? '' );
        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! $cl ) wp_send_json_error( array( 'message' => 'Cluster non spécifié.' ) );
        $r = $this->suggest_cluster_links( $cl, $lang );
        if ( isset( $r['error'] ) ) wp_send_json_error( array( 'message' => $r['error'] ) );
        wp_send_json_success( $r );
    }

    public function ajax_cluster_detail() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $cn = sanitize_text_field( $_POST['cluster'] ?? '' );
        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';

        $data = $this->get_cocon_data( $lang );
        if ( empty( $data['clusters'][ $cn ] ) ) wp_send_json_error( array( 'message' => 'Introuvable.' ) );

        $cl = $data['clusters'][ $cn ];
        $nodes = $data['nodes'];
        $gsc_pages = get_option( 'hts_gsc_pages', array() );
        $freshness = class_exists( 'HTS_Freshness' ) ? new \HTS_Freshness() : null;
        $pages = array();

        foreach ( $cl['pages'] as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $n = $nodes[ $pid ];

            // Content Doctor score
            $cd_score = (int) get_post_meta( $pid, '_hts_geo_score', true );

            // Freshness score
            $fresh_score = $freshness ? $freshness->get_freshness_score( $pid ) : 0;
            $modified_date = get_the_modified_date( 'Y-m-d', $pid );

            // GSC data (match by URL)
            $page_url = $n['url'] ?? get_permalink( $pid );
            $gsc = array( 'clicks' => 0, 'impressions' => 0, 'ctr' => 0, 'position' => 0 );
            if ( ! empty( $gsc_pages ) ) {
                foreach ( $gsc_pages as $gp ) {
                    $gsc_url = rtrim( $gp['url'] ?? '', '/' );
                    $match_url = rtrim( $page_url, '/' );
                    if ( $gsc_url === $match_url || strpos( $gsc_url, parse_url( $match_url, PHP_URL_PATH ) ) !== false ) {
                        $gsc = array(
                            'clicks'      => (int) ( $gp['clicks'] ?? 0 ),
                            'impressions' => (int) ( $gp['impressions'] ?? 0 ),
                            'ctr'         => round( (float) ( $gp['ctr'] ?? 0 ), 1 ),
                            'position'    => round( (float) ( $gp['position'] ?? 0 ), 1 ),
                        );
                        break;
                    }
                }
            }

            // S14: use _hts_combined_score (BO-visible) for display, keep pillar_score for internal
            $bo_score = (int) get_post_meta( (int) $pid, '_hts_combined_score', true );
            $pages[] = array(
                'id' => $pid, 'title' => $n['title'], 'role' => $n['role'],
                'in_count' => $n['in_count'], 'out_count' => $n['out_count'],
                'score' => $bo_score > 0 ? $bo_score : $n['pillar_score'], 'orphan' => $n['is_orphan'],
                'click_depth' => $n['click_depth'] ?? PHP_INT_MAX,
                'keywords' => array_slice( $n['keywords'], 0, 5 ),
                'url' => $n['url'], 'edit_url' => $n['edit_url'],
                'cd_score' => $cd_score, 'fresh_score' => $fresh_score,
                'modified_date' => $modified_date, 'gsc' => $gsc,
            );
        }
        usort( $pages, function( $a, $b ) { if ( $a['role'] === 'pilier' ) return -1; if ( $b['role'] === 'pilier' ) return 1; return $b['score'] - $a['score']; } );

        // ── Calcul du score d'autorité croisé ──
        $authority = $this->compute_authority_score( $pages, $cl );
        $recommendations = $this->generate_recommendations( $pages, $cl, $authority );

        // ── Engagement + AI aggregate ──
        $eng_total_time = 0; $eng_total_scroll = 0; $eng_total_views = 0; $eng_n = 0;
        foreach ( $cl['pages'] as $pid ) {
            $t = (float) get_post_meta( $pid, '_hts_eng_avg_time', true );
            $s = (float) get_post_meta( $pid, '_hts_eng_avg_scroll', true );
            $v = (int) get_post_meta( $pid, '_hts_eng_views', true );
            if ( $t > 0 || $v > 0 ) { $eng_total_time += $t; $eng_total_scroll += $s; $eng_total_views += $v; $eng_n++; }
        }
        $engagement = array(
            'avg_time'   => $eng_n ? round( $eng_total_time / $eng_n ) : 0,
            'avg_scroll' => $eng_n ? round( $eng_total_scroll / $eng_n ) : 0,
            'total_views' => $eng_total_views,
            'has_data'   => $eng_n > 0,
        );

        $ai_data_raw = get_option( 'hts_citation_data', array() );
        $ai_visits = 0; $cutoff_30d = wp_date( 'Y-m-d', strtotime( '-30 days' ) );
        foreach ( $ai_data_raw as $day => $dd ) {
            if ( $day < $cutoff_30d || empty( $dd['pages'] ) ) continue;
            foreach ( $dd['pages'] as $url => $info ) {
                foreach ( $cl['pages'] as $pid ) {
                    $pu = get_permalink( $pid );
                    $pp = parse_url( $pu, PHP_URL_PATH );
                    if ( $url === $pu || ( $pp && strpos( $url, $pp ) !== false ) ) { $ai_visits += (int) $info['count']; break; }
                }
            }
        }

        wp_send_json_success( array(
            'cluster'          => $cn,
            'theme'            => $cl['theme'] ?? '',
            'pillar_id'        => $cl['pillar_id'] ?? 0,
            'pillar_coverage'  => $cl['pillar_coverage'] ?? 0,
            'sibling_density'  => $cl['sibling_density'] ?? null,
            'density'          => $cl['density'] ?? 0,
            'silhouette'       => $cl['silhouette'] ?? null,
            'coherence'        => $cl['coherence'] ?? null,
            'border_pages'     => $cl['border_pages'] ?? array(),
            'toxic_links'      => $cl['toxic_link_list'] ?? array(),
            'toxic_count'      => $cl['toxic_links'] ?? 0,
            'semantic_links'   => $cl['semantic_links'] ?? 0,
            'pages'            => $pages,
            'authority'        => $authority,
            'recommendations'  => $recommendations,
            'engagement'       => $engagement,
            'ai_visits'        => $ai_visits,
        ) );
    }

    /**
     * Score d'autorité croisé : maillage + contenu + performance + fraîcheur
     */
    private function compute_authority_score( $pages, $cl ) {
        if ( empty( $pages ) ) return array( 'total' => 0, 'maillage' => 0, 'contenu' => 0, 'performance' => 0, 'fraicheur' => 0 );

        $count = count( $pages );

        // MAILLAGE (30%) — densité + couverture + ratio isolées
        $density    = min( 100, ( $cl['density'] ?? 0 ) * 2 ); // densité 50% = score 100
        $coverage   = $cl['pillar_coverage'] ?? 0;
        $orphan_pct = 0;
        $orphans = array_filter( $pages, function( $p ) { return $p['orphan']; } );
        $orphan_pct = $count > 0 ? ( 1 - count( $orphans ) / $count ) * 100 : 100;
        $maillage   = round( $density * 0.35 + $coverage * 0.4 + $orphan_pct * 0.25 );

        // CONTENU (30%) — moyenne score Content Doctor
        $cd_scores = array_filter( array_column( $pages, 'cd_score' ), function( $s ) { return $s > 0; } );
        $contenu = ! empty( $cd_scores ) ? round( array_sum( $cd_scores ) / count( $cd_scores ) ) : 0;
        // Pénalité si le pilier a un score faible
        $pillar = array_filter( $pages, function( $p ) { return $p['role'] === 'pilier'; } );
        $pillar = reset( $pillar );
        if ( $pillar && $pillar['cd_score'] > 0 && $pillar['cd_score'] < 50 ) {
            $contenu = round( $contenu * 0.8 ); // -20% si pilier faible
        }
        $has_cd = ! empty( $cd_scores );

        // PERFORMANCE (20%) — clics + CTR + position
        $total_clicks = array_sum( array_column( array_column( $pages, 'gsc' ), 'clicks' ) );
        $positions = array_filter( array_column( array_column( $pages, 'gsc' ), 'position' ), function( $p ) { return $p > 0; } );
        $avg_position = ! empty( $positions ) ? array_sum( $positions ) / count( $positions ) : 0;
        $ctrs = array_filter( array_column( array_column( $pages, 'gsc' ), 'ctr' ), function( $c ) { return $c > 0; } );
        $avg_ctr = ! empty( $ctrs ) ? array_sum( $ctrs ) / count( $ctrs ) : 0;

        $perf = 0;
        $has_gsc = $total_clicks > 0 || ! empty( $positions );
        if ( $has_gsc ) {
            $click_score = min( 100, $total_clicks / max( 1, $count ) * 5 ); // 20 clics/page = 100
            $pos_score   = $avg_position > 0 ? max( 0, 100 - ( $avg_position - 1 ) * 5 ) : 0; // pos 1=100, pos 21=0
            $ctr_score   = min( 100, $avg_ctr * 20 ); // CTR 5% = 100
            $perf = round( $click_score * 0.4 + $pos_score * 0.35 + $ctr_score * 0.25 );
        }

        // FRAÎCHEUR (20%) — moyenne score fraîcheur
        $fresh_scores = array_column( $pages, 'fresh_score' );
        $fraicheur = ! empty( $fresh_scores ) ? round( array_sum( $fresh_scores ) / count( $fresh_scores ) ) : 0;
        // Pénalité si pilier obsolète
        if ( $pillar && $pillar['fresh_score'] < 40 ) {
            $fraicheur = round( $fraicheur * 0.8 );
        }

        // Pondération adaptative : si pas de GSC ou Content Doctor, redistribuer
        if ( $has_cd && $has_gsc ) {
            $total = round( $maillage * 0.30 + $contenu * 0.30 + $perf * 0.20 + $fraicheur * 0.20 );
        } elseif ( $has_cd && ! $has_gsc ) {
            $total = round( $maillage * 0.35 + $contenu * 0.35 + $fraicheur * 0.30 );
        } elseif ( ! $has_cd && $has_gsc ) {
            $total = round( $maillage * 0.40 + $perf * 0.30 + $fraicheur * 0.30 );
        } else {
            $total = round( $maillage * 0.50 + $fraicheur * 0.50 );
        }

        return array(
            'total'       => min( 100, $total ),
            'maillage'    => $maillage,
            'contenu'     => $contenu,
            'performance' => $perf,
            'fraicheur'   => $fraicheur,
            'has_cd'      => $has_cd,
            'has_gsc'     => $has_gsc,
            'total_clicks' => $total_clicks,
            'avg_position' => round( $avg_position, 1 ),
            'avg_ctr'     => round( $avg_ctr, 1 ),
        );
    }

    /**
     * Recommandations intelligentes basées sur les données croisées
     */
    private function generate_recommendations( $pages, $cl, $auth ) {
        $recs = array();
        $count = count( $pages );
        if ( ! $count ) return $recs;

        $pillar = null;
        foreach ( $pages as $p ) { if ( $p['role'] === 'pilier' ) { $pillar = $p; break; } }

        // ── EMERGING THEMES: growth-oriented recommendation ──
        if ( ( $cl['name'] ?? '' ) === 'Thématiques émergentes' ) {
            $titles = array_slice( array_column( $pages, 'title' ), 0, 3 );
            $recs[] = array(
                'type'     => 'croissance',
                'priority' => 'medium',
                'icon'     => '🌱',
                'title'    => 'Thématique en développement — ' . $count . ' page(s)',
                'detail'   => 'Ces pages traitent de sujets nouveaux pour votre site : ' . implode( ', ', $titles ) . '. Pour que Google comprenne cette thématique, il faut un minimum de contenu complémentaire.',
                'action'   => 'Publiez 3 à 5 articles autour de ces sujets, puis réanalysez le site. Un cocon sémantique se formera automatiquement.',
            );
            // For emerging themes, also flag if the content seems truly unrelated (e.g. SEO article on psilocybin site)
            if ( $count <= 2 ) {
                $recs[] = array(
                    'type'     => 'croissance',
                    'priority' => 'low',
                    'icon'     => '🤔',
                    'title'    => 'Ces pages sont-elles stratégiques ?',
                    'detail'   => 'Si ce contenu ne fait pas partie de votre stratégie, il pourrait diluer la thématique principale de votre site aux yeux de Google.',
                    'action'   => 'Gardez-les si c\'est une diversification voulue. Sinon, envisagez de les passer en noindex ou de les supprimer.',
                );
            }
            return $recs; // No maillage recommendations for emerging themes
        }

        // ── MAILLAGE ──
        $orphans = array_filter( $pages, function( $p ) { return $p['orphan']; } );
        if ( count( $orphans ) > 0 ) {
            $titles = array_slice( array_column( $orphans, 'title' ), 0, 3 );
            $recs[] = array(
                'type'     => 'maillage',
                'priority' => 'high',
                'icon'     => '🔗',
                'title'    => count( $orphans ) . ' page(s) isolée(s) dans ce groupe',
                'detail'   => 'Google ne peut pas les découvrir : ' . implode( ', ', $titles ),
                'action'   => 'Cliquez "Tout appliquer" ci-dessous pour corriger automatiquement.',
            );
        }
        if ( ( $cl['pillar_coverage'] ?? 0 ) < 50 && $pillar ) {
            $recs[] = array(
                'type'     => 'maillage',
                'priority' => 'medium',
                'icon'     => '🔗',
                'title'    => 'Couverture faible (' . ( $cl['pillar_coverage'] ?? 0 ) . '%)',
                'detail'   => 'La page principale "' . $pillar['title'] . '" n\'est pas bien reliée aux autres pages du groupe.',
                'action'   => 'Ajoutez des liens depuis la page principale vers les pages filles.',
            );
        }

        // ── LIENS TOXIQUES ──
        $cl_toxic = $cl['toxic_link_list'] ?? array();
        if ( ! empty( $cl_toxic ) ) {
            $toxic_details = array();
            foreach ( array_slice( $cl_toxic, 0, 5 ) as $tl ) {
                $toxic_details[] = '"' . mb_substr( $tl['source_title'], 0, 30 ) . '" → "' . mb_substr( $tl['target_title'], 0, 30 ) . '" (sim=' . $tl['similarity'] . ')';
            }
            $recs[] = array(
                'type'     => 'maillage',
                'priority' => 'high',
                'icon'     => '🧹',
                'title'    => count( $cl_toxic ) . ' lien(s) toxique(s) détecté(s)',
                'detail'   => 'Ces liens internes relient des pages qui n\'ont rien en commun sémantiquement. Ils diluent le jus SEO du cocon et confondent Google sur la thématique du groupe.' . "\n" . implode( "\n", $toxic_details ),
                'action'   => 'Supprimez ces liens manuellement pour renforcer la cohérence thématique du cocon.',
            );
        }

        // ── CONTENU ──
        if ( $auth['has_cd'] ) {
            // Pilier faible
            if ( $pillar && $pillar['cd_score'] > 0 && $pillar['cd_score'] < 50 ) {
                $recs[] = array(
                    'type'     => 'contenu',
                    'priority' => 'high',
                    'icon'     => '📝',
                    'title'    => 'La page principale a un score contenu faible (' . $pillar['cd_score'] . '/100)',
                    'detail'   => 'C\'est la page la plus importante du groupe. Améliorez-la en priorité.',
                    'action'   => 'Utilisez le Content Doctor pour l\'optimiser.',
                    'edit_url' => $pillar['edit_url'] ?? '',
                );
            }
            // Pages faibles
            $weak = array_filter( $pages, function( $p ) { return $p['cd_score'] > 0 && $p['cd_score'] < 40; } );
            if ( count( $weak ) > 0 && ( ! $pillar || $pillar['cd_score'] >= 50 ) ) {
                $titles = array_slice( array_column( $weak, 'title' ), 0, 3 );
                $recs[] = array(
                    'type'     => 'contenu',
                    'priority' => 'medium',
                    'icon'     => '📝',
                    'title'    => count( $weak ) . ' page(s) avec un contenu à améliorer',
                    'detail'   => implode( ', ', $titles ),
                    'action'   => 'Lancez le Content Doctor sur ces pages.',
                );
            }
            // Pages sans score CD
            $no_cd = array_filter( $pages, function( $p ) { return $p['cd_score'] === 0; } );
            if ( count( $no_cd ) > 0 && count( $no_cd ) < $count ) {
                $recs[] = array(
                    'type'     => 'contenu',
                    'priority' => 'low',
                    'icon'     => '📝',
                    'title'    => count( $no_cd ) . ' page(s) non encore analysée(s)',
                    'detail'   => 'Lancez le Content Doctor pour évaluer leur qualité.',
                    'action'   => '',
                );
            }
        } else {
            $recs[] = array(
                'type'     => 'contenu',
                'priority' => 'low',
                'icon'     => '📝',
                'title'    => 'Aucune analyse de contenu disponible',
                'detail'   => 'Le Content Doctor n\'a pas encore évalué ces pages.',
                'action'   => 'Lancez le Content Doctor pour obtenir un score contenu.',
            );
        }

        // ── PERFORMANCE ──
        if ( $auth['has_gsc'] ) {
            // Pages sans clics
            $no_clicks = array_filter( $pages, function( $p ) { return ( $p['gsc']['clicks'] ?? 0 ) === 0 && ( $p['gsc']['impressions'] ?? 0 ) > 10; } );
            if ( count( $no_clicks ) > 0 ) {
                $titles = array_slice( array_column( $no_clicks, 'title' ), 0, 3 );
                $recs[] = array(
                    'type'     => 'performance',
                    'priority' => 'medium',
                    'icon'     => '📊',
                    'title'    => count( $no_clicks ) . ' page(s) visibles mais pas cliquées',
                    'detail'   => 'Google les montre (' . array_sum( array_column( array_column( $no_clicks, 'gsc' ), 'impressions' ) ) . ' impressions) mais personne ne clique.',
                    'action'   => 'Améliorez les titles et meta descriptions pour attirer les clics.',
                );
            }
            // Pilier mal positionné
            if ( $pillar && ( $pillar['gsc']['position'] ?? 0 ) > 20 ) {
                $recs[] = array(
                    'type'     => 'performance',
                    'priority' => 'high',
                    'icon'     => '📊',
                    'title'    => 'La page principale est en position ' . $pillar['gsc']['position'],
                    'detail'   => 'Elle devrait être en première page Google pour être citée par les IA.',
                    'action'   => 'Renforcez les liens vers cette page et améliorez son contenu.',
                );
            }
        } else {
            $recs[] = array(
                'type'     => 'performance',
                'priority' => 'low',
                'icon'     => '📊',
                'title'    => 'Aucune donnée Google Search Console',
                'detail'   => 'Importez vos données GSC pour voir les clics et positions.',
                'action'   => 'Allez dans l\'onglet Search Console pour importer un CSV.',
            );
        }

        // ── FRAÎCHEUR ──
        $stale = array_filter( $pages, function( $p ) { return $p['fresh_score'] < 40; } );
        if ( count( $stale ) > 0 ) {
            $titles = array_slice( array_column( $stale, 'title' ), 0, 3 );
            $prio = ( $pillar && $pillar['fresh_score'] < 40 ) ? 'high' : 'medium';
            $recs[] = array(
                'type'     => 'fraicheur',
                'priority' => $prio,
                'icon'     => '🕐',
                'title'    => count( $stale ) . ' page(s) obsolète(s)',
                'detail'   => ( $pillar && $pillar['fresh_score'] < 40 ? 'La page principale n\'a pas été mise à jour depuis longtemps ! ' : '' ) . implode( ', ', $titles ),
                'action'   => 'Les IA privilégient le contenu récent. Mettez à jour ces pages.',
            );
        }

        // ── ENGAGEMENT ──
        $low_engagement = array();
        $short_content = array();
        foreach ( $pages as $p ) {
            $eng_time = (float) get_post_meta( $p['id'], '_hts_eng_avg_time', true );
            $eng_scroll = (float) get_post_meta( $p['id'], '_hts_eng_avg_scroll', true );
            $word_count = (int) get_post_meta( $p['id'], '_hts_word_count', true );
            if ( ! $word_count ) {
                $post = get_post( $p['id'] );
                $word_count = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;
            }

            if ( $eng_time > 0 && $eng_time < 30 ) {
                $low_engagement[] = array( 'title' => $p['title'], 'time' => round( $eng_time ), 'scroll' => round( $eng_scroll ), 'edit_url' => $p['edit_url'] ?? '' );
            }
            if ( $word_count > 0 && $word_count < 500 ) {
                $short_content[] = array( 'title' => $p['title'], 'words' => $word_count, 'edit_url' => $p['edit_url'] ?? '' );
            }
        }

        if ( count( $low_engagement ) > 0 ) {
            $recs[] = array(
                'type'     => 'engagement',
                'priority' => count( $low_engagement ) >= 3 ? 'high' : 'medium',
                'icon'     => '👁️',
                'title'    => count( $low_engagement ) . ' page(s) avec un engagement très faible',
                'detail'   => 'Temps moyen < 30s : ' . implode( ', ', array_slice( array_column( $low_engagement, 'title' ), 0, 3 ) ),
                'action'   => 'Améliorez l\'introduction, ajoutez des visuels et structurez mieux le contenu.',
            );
        }
        if ( count( $short_content ) > 0 ) {
            $recs[] = array(
                'type'     => 'engagement',
                'priority' => 'medium',
                'icon'     => '👁️',
                'title'    => count( $short_content ) . ' page(s) avec un contenu trop court (< 500 mots)',
                'detail'   => implode( ', ', array_slice( array_column( $short_content, 'title' ), 0, 3 ) ),
                'action'   => 'Enrichissez ces articles pour qu\'ils soient cités par les IA.',
            );
        }

        // ── TRAFIC IA ──
        $ai_data = get_option( 'hts_citation_data', array() );
        $ai_total = 0;
        $cutoff = wp_date( 'Y-m-d', strtotime( '-30 days' ) );
        foreach ( $ai_data as $day => $dd ) {
            if ( $day >= $cutoff ) $ai_total += (int) ( $dd['total'] ?? 0 );
        }
        // Check if any page in cluster has AI traffic
        $ai_per_url = array();
        foreach ( $ai_data as $day => $dd ) {
            if ( $day < $cutoff || empty( $dd['pages'] ) ) continue;
            foreach ( $dd['pages'] as $url => $info ) {
                if ( ! isset( $ai_per_url[ $url ] ) ) $ai_per_url[ $url ] = 0;
                $ai_per_url[ $url ] += (int) $info['count'];
            }
        }
        $cluster_ai = 0;
        foreach ( $pages as $p ) {
            $url = $p['url'] ?? '';
            $path = parse_url( $url, PHP_URL_PATH );
            foreach ( $ai_per_url as $aurl => $acnt ) {
                if ( $aurl === $url || ( $path && strpos( $aurl, $path ) !== false ) ) {
                    $cluster_ai += $acnt;
                }
            }
        }

        if ( $cluster_ai === 0 ) {
            $recs[] = array(
                'type'     => 'ai',
                'priority' => 'medium',
                'icon'     => '🤖',
                'title'    => 'Aucun trafic IA détecté sur ce cocon',
                'detail'   => 'Ni ChatGPT, ni Perplexity n\'envoient de visiteurs vers ces pages.',
                'action'   => 'Ajoutez des FAQ structurées et optimisez pour le GEO (Generative Engine Optimization).',
            );
        } elseif ( $cluster_ai > 0 ) {
            $recs[] = array(
                'type'     => 'ai',
                'priority' => 'low',
                'icon'     => '🤖',
                'title'    => $cluster_ai . ' visite(s) IA ces 30 derniers jours',
                'detail'   => 'Ce cocon est cité par les IA. Continuez à enrichir le contenu structuré.',
                'action'   => '',
            );
        }

        // ── QUALITÉ CLUSTERING ──
        $sil = $cl['silhouette'] ?? null;
        if ( $sil !== null ) {
            if ( $sil < 0.1 ) {
                $recs[] = array(
                    'type'     => 'qualite',
                    'priority' => 'high',
                    'icon'     => '🎯',
                    'title'    => 'Cohérence faible (silhouette: ' . $sil . ')',
                    'detail'   => 'Ce cluster contient des pages peu liées thématiquement. Certaines sont peut-être mal classées.',
                    'action'   => 'Relancez l\'analyse ou réorganisez les catégories WordPress.',
                );
            } elseif ( $sil < 0.25 ) {
                $recs[] = array(
                    'type'     => 'qualite',
                    'priority' => 'low',
                    'icon'     => '🎯',
                    'title'    => 'Cohérence correcte (silhouette: ' . $sil . ')',
                    'detail'   => 'Le cluster est globalement cohérent mais quelques pages sont ambiguës.',
                    'action'   => '',
                );
            }
        }
        $border = $cl['border_pages'] ?? array();
        if ( count( $border ) > 0 ) {
            $bp_titles = array();
            foreach ( array_slice( $border, 0, 3 ) as $bp ) {
                $bp_post = get_post( $bp['pid'] );
                if ( $bp_post ) $bp_titles[] = '"' . mb_substr( $bp_post->post_title, 0, 40 ) . '"';
            }
            $recs[] = array(
                'type'     => 'qualite',
                'priority' => 'medium',
                'icon'     => '🎯',
                'title'    => count( $border ) . ' page(s) frontière(s)',
                'detail'   => 'Ces pages sont à la frontière entre ce cluster et un autre : ' . implode( ', ', $bp_titles ),
                'action'   => 'Spécialisez leur contenu ou déplacez-les dans le groupe le plus pertinent.',
            );
        }

        // ── CLICK DEPTH — Phase 6a.4 ──
        $deep_pages = array_filter( $pages, function( $p ) {
            return isset( $p['click_depth'] ) && $p['click_depth'] > 3 && $p['click_depth'] < PHP_INT_MAX;
        } );
        if ( count( $deep_pages ) > 0 ) {
            $titles = array_slice( array_column( $deep_pages, 'title' ), 0, 3 );
            $recs[] = array(
                'type'     => 'maillage',
                'priority' => 'medium',
                'icon'     => '📏',
                'title'    => count( $deep_pages ) . ' page(s) trop profonde(s)',
                'detail'   => 'Ces pages sont à plus de 3 clics de la page d\'accueil : ' . implode( ', ', $titles ) . '. Google les considère comme peu importantes.',
                'action'   => 'Ajoutez des liens depuis des pages de premier niveau pour les rapprocher de la surface.',
            );
        }

        // ── SIBLING DENSITY — Phase 6a.5 ──
        $sib_density = $cl['sibling_density'] ?? 100;
        if ( $sib_density < 20 && $count >= 3 ) {
            $recs[] = array(
                'type'     => 'maillage',
                'priority' => 'medium',
                'icon'     => '🔀',
                'title'    => 'Maillage entre articles faible (' . $sib_density . '%)',
                'detail'   => 'Les pages de ce cocon ne se lient pas assez entre elles. Seules ' . $sib_density . '% des paires frères/sœurs sont reliées.',
                'action'   => 'Utilisez les suggestions de liens pour relier les articles similaires entre eux.',
            );
        }

        // Trier par priorité
        $prio_map = array( 'high' => 0, 'medium' => 1, 'low' => 2 );
        usort( $recs, function( $a, $b ) use ( $prio_map ) {
            return ( $prio_map[ $a['priority'] ] ?? 2 ) - ( $prio_map[ $b['priority'] ] ?? 2 );
        } );

        return $recs;
    }

    public function ajax_bulk_apply() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier( 2 );
        $links = json_decode( stripslashes( $_POST['links'] ?? '[]' ), true );
        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        if ( ! is_array( $links ) || empty( $links ) ) wp_send_json_error( array( 'message' => 'Aucun lien.' ) );

        $ok = 0; $err = 0;
        foreach ( $links as $l ) {
            $s = absint( $l['source_id'] ?? 0 ); $t = absint( $l['target_id'] ?? 0 ); $a = sanitize_text_field( $l['anchor_text'] ?? '' );
            if ( ! $s || ! $t || ! $a ) { $err++; continue; }
            if ( $this->apply_single_link( $s, $t, $a ) ) { $ok++; hts_add_log( "Cocon: \"{$a}\" #{$s} → #{$t}", 'success', 'system' ); } else { $err++; }
        }
        $this->analyze_site( $lang );
        wp_send_json_success( array( 'applied' => $ok, 'errors' => $err, 'message' => $ok . ' lien(s) appliqué(s)' . ( $err ? ", {$err} erreur(s)" : '' ) ) );
    }

    /* ── LANGUAGE-AWARE DATA ACCESS ── */

    /**
     * Get cocon data for the specified language (or current).
     * Falls back to unscoped data if per-lang data doesn't exist.
     */
    public function get_cocon_data( $lang = '' ) {
        if ( ( ! $lang || $lang === 'all' ) && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }
        // 'all' must never reach DB — redirect to default language
        if ( $lang === 'all' ) {
            $lang = function_exists( 'pll_default_language' ) ? pll_default_language( 'slug' ) : substr( get_locale(), 0, 2 );
        }

        $data = self::get_cached_cocon_data( $lang );
        if ( empty( $data ) ) return array();

        // ── Strip excluded pages from EVERYTHING ──
        // When client clicks "Non", the page disappears from graph, stats, clusters, links.
        $decisions = get_option( 'hts_cocon_page_decisions', array() );
        $excluded = array();
        foreach ( $decisions as $pid => $d ) {
            if ( $d['decision'] === 'exclude' ) $excluded[] = (int) $pid;
        }

        if ( ! empty( $excluded ) && ! empty( $data['nodes'] ) ) {
            // Remove from nodes
            foreach ( $excluded as $pid ) {
                unset( $data['nodes'][ $pid ] );
            }

            // Remove from links (any link involving an excluded page)
            if ( ! empty( $data['links'] ) ) {
                $data['links'] = array_values( array_filter( $data['links'], function( $l ) use ( $excluded ) {
                    return ! in_array( (int) $l['source'], $excluded ) && ! in_array( (int) $l['target'], $excluded );
                } ) );
            }

            // Remove from clusters and recount
            if ( ! empty( $data['clusters'] ) ) {
                foreach ( $data['clusters'] as $cname => &$cl ) {
                    $cl['pages'] = array_values( array_diff( $cl['pages'] ?? array(), $excluded ) );
                    $cl['page_count'] = count( $cl['pages'] );
                    // Recount orphans in this cluster
                    $orph = 0;
                    foreach ( $cl['pages'] as $cpid ) {
                        if ( isset( $data['nodes'][ $cpid ] ) && ( $data['nodes'][ $cpid ]['is_orphan'] ?? false ) ) $orph++;
                    }
                    $cl['orphans'] = $orph;
                    // If pillar was excluded, reset
                    if ( in_array( (int) ( $cl['pillar_id'] ?? 0 ), $excluded ) ) {
                        $cl['pillar_id'] = 0;
                    }
                }
                unset( $cl );
                // Remove empty clusters
                $data['clusters'] = array_filter( $data['clusters'], function( $c ) { return ! empty( $c['pages'] ); } );
            }

            // Recount stats
            if ( ! empty( $data['stats'] ) ) {
                $data['stats']['total_pages'] = count( $data['nodes'] );
                $data['stats']['total_links'] = count( $data['links'] );
                $data['stats']['total_clusters'] = count( $data['clusters'] );
                $orph_total = 0;
                foreach ( $data['nodes'] as $n ) { if ( $n['is_orphan'] ?? false ) $orph_total++; }
                $data['stats']['total_orphans'] = $orph_total;
            }
        }

        return $data;
    }

    /* ── PUBLIC API ── */

    public function get_quick_stats( $lang = '' ) {
        $data = $this->get_cocon_data( $lang );
        $last = get_option( 'hts_cocon_last_analysis', 0 );
        $missing = get_option( 'hts_cocon_missing_clusters', array() );
        if ( empty( $data ) ) return array( 'analyzed' => false, 'last' => 0 );

        // Merge flagged pages with current decisions
        $decisions = get_option( 'hts_cocon_page_decisions', array() );
        $flagged = array();
        foreach ( $data['flagged_pages'] ?? array() as $pid => $fp ) {
            $fp['decision'] = $decisions[ $pid ]['decision'] ?? 'pending';
            $fp['decided_at'] = $decisions[ $pid ]['decided_at'] ?? null;
            $fp['cluster'] = $data['nodes'][ $pid ]['cluster'] ?? '';
            $flagged[ $pid ] = $fp;
        }

        return array(
            'analyzed' => true, 'last' => $last, 'stats' => $data['stats'] ?? array(),
            'lang' => $data['lang'] ?? '',
            'missing_clusters' => $missing,
            'flagged_pages' => $flagged,
            'clusters' => array_map( function( $c ) {
                return array( 'name' => $c['name'], 'page_count' => $c['page_count'] ?? count( $c['pages'] ?? array() ), 'density' => $c['density'] ?? 0, 'orphans' => $c['orphans'] ?? 0, 'dead_ends' => $c['dead_ends'] ?? 0, 'total_links' => $c['total_links'] ?? 0, 'pillar_id' => $c['pillar_id'] ?? 0, 'pillar_coverage' => $c['pillar_coverage'] ?? 0, 'theme' => $c['theme'] ?? '', 'orphan_count' => $c['orphans'] ?? 0 );
            }, $data['clusters'] ?? array() ),
        );
    }

    /* ── PERFORMANCE SCORING & SNAPSHOTS ── */

    const SNAP_OPT = 'hts_cocon_perf_snapshots';

    /**
     * Compute performance score (0-100) for a cluster.
     * Weights: Visibility 35%, Engagement 25%, Maillage 25%, AI Presence 15%
     */
    private function compute_cluster_score( $cluster, $nodes, $ai_per_url ) {
        $pages = $cluster['pages'];
        $pillar_id = (int) ( $cluster['pillar_id'] ?? 0 );
        $cnt = 0;
        $sum_clicks = 0; $sum_impr = 0; $sum_pos = 0; $pos_n = 0;
        $sum_time = 0; $sum_scroll = 0; $sum_views = 0;
        $sum_ai = 0;
        $links_done = 0; $links_total = 0;

        foreach ( $pages as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $cnt++;

            // GSC
            $sum_clicks += (int) get_post_meta( $pid, '_hts_gsc_clicks', true );
            $sum_impr   += (int) get_post_meta( $pid, '_hts_gsc_impressions', true );
            $p = (float) get_post_meta( $pid, '_hts_gsc_position', true );
            if ( $p > 0 ) { $sum_pos += $p; $pos_n++; }

            // Engagement
            $sum_views  += (int) get_post_meta( $pid, '_hts_eng_views', true );
            $sum_time   += (float) get_post_meta( $pid, '_hts_eng_avg_time', true );
            $sum_scroll += (float) get_post_meta( $pid, '_hts_eng_avg_scroll', true );

            // AI traffic
            $permalink = get_permalink( $pid );
            $path = parse_url( $permalink, PHP_URL_PATH );
            foreach ( $ai_per_url as $aurl => $acnt ) {
                if ( $aurl === $permalink || ( $path && strpos( $aurl, $path ) !== false ) ) {
                    $sum_ai += $acnt;
                }
            }

            // Maillage: child→pillar links
            if ( $pid !== $pillar_id && $pillar_id ) {
                $links_total++;
                if ( $this->link_exists_in_content( $pid, $pillar_id ) !== false ) $links_done++;
            }
            // pillar→child links
            if ( $pillar_id && $pid !== $pillar_id ) {
                $links_total++;
                if ( $this->link_exists_in_content( $pillar_id, $pid ) !== false ) $links_done++;
            }
        }

        if ( $cnt === 0 ) return array( 'score' => 0, 'components' => array(), 'metrics' => array() );

        // ── Sub-scores (each 0-100) ──

        // Visibility: position (closer to 1 = better) + has clicks
        $avg_pos = $pos_n ? ( $sum_pos / $pos_n ) : 100;
        $vis_pos = max( 0, min( 100, ( 1 - ( ( $avg_pos - 1 ) / 49 ) ) * 100 ) ); // pos 1=100, pos 50=0
        $vis_click = min( 100, ( $sum_clicks / max( 1, $cnt ) ) * 10 ); // 10 clicks/page = 100
        $visibility = round( $vis_pos * 0.6 + $vis_click * 0.4 );

        // Engagement: time on page + scroll depth
        $avg_time = $sum_time / $cnt;
        $avg_scroll = $sum_scroll / $cnt;
        $eng_time = min( 100, ( $avg_time / 180 ) * 100 ); // 3 min = 100
        $eng_scroll = min( 100, $avg_scroll ); // already 0-100
        $engagement = round( $eng_time * 0.5 + $eng_scroll * 0.5 );

        // Maillage: % of ideal links done
        $maillage = $links_total > 0 ? round( ( $links_done / $links_total ) * 100 ) : 0;

        // AI Presence: any AI traffic is good
        $ai_score = min( 100, $sum_ai * 20 ); // 5 visits = 100

        // ── Composite score ──
        $score = round( $visibility * 0.35 + $engagement * 0.25 + $maillage * 0.25 + $ai_score * 0.15 );

        return array(
            'score' => $score,
            'components' => array(
                'visibility' => $visibility,
                'engagement' => $engagement,
                'maillage'   => $maillage,
                'ai'         => $ai_score,
            ),
            'metrics' => array(
                'clicks'      => $sum_clicks,
                'impressions' => $sum_impr,
                'avg_position' => $pos_n ? round( $sum_pos / $pos_n, 1 ) : null,
                'views'       => $sum_views,
                'avg_time'    => round( $sum_time / $cnt ),
                'avg_scroll'  => round( $sum_scroll / $cnt ),
                'ai_visits'   => $sum_ai,
                'links_done'  => $links_done,
                'links_total' => $links_total,
            ),
        );
    }

    /**
     * Auto-diagnose: find the weakest component and return actionable insight.
     */
    private function diagnose_cluster( $score_data ) {
        $c = $score_data['components'];
        $m = $score_data['metrics'];
        if ( empty( $c ) ) return array( 'level' => 'neutral', 'text' => '' );

        // Find weakest component
        $weakest = 'visibility';
        $weakest_val = $c['visibility'];
        foreach ( $c as $k => $v ) {
            if ( $v < $weakest_val ) { $weakest = $k; $weakest_val = $v; }
        }

        $diags = array(
            'maillage' => array(
                'icon' => "\xF0\x9F\x94\x97", // 🔗
                'text' => 'Maillage incomplet (' . $m['links_done'] . '/' . $m['links_total'] . ' liens). Utilisez "Optimiser" pour compléter.',
                'level' => $weakest_val < 50 ? 'danger' : 'warning',
            ),
            'visibility' => array(
                'icon' => "\xF0\x9F\x94\x8D", // 🔍
                'text' => 'Visibilité Google faible' . ( $m['avg_position'] ? ' (pos. moy. ' . $m['avg_position'] . ')' : '' ) . '. Optimisez titres et méta.',
                'level' => $weakest_val < 30 ? 'danger' : 'warning',
            ),
            'engagement' => array(
                'icon' => "\xF0\x9F\x93\x89", // 📉
                'text' => 'Engagement faible (temps moy. ' . $m['avg_time'] . 's). Améliorez le contenu ou l\'UX.',
                'level' => $weakest_val < 30 ? 'danger' : 'warning',
            ),
            'ai' => array(
                'icon' => "\xF0\x9F\xA4\x96", // 🤖
                'text' => 'Pas de trafic IA détecté. Structurez le contenu pour les LLM.',
                'level' => 'info',
            ),
        );

        // Only show diagnostic if score < 70 AND weakest < 50
        if ( $score_data['score'] >= 70 && $weakest_val >= 50 ) {
            return array( 'level' => 'success', 'icon' => "\xE2\x9C\x85", 'text' => 'Ce cocon performe bien.' );
        }

        return $diags[ $weakest ] ?? array( 'level' => 'neutral', 'text' => '' );
    }

    /**
     * Save weekly snapshot of all cluster scores.
     */
    private function maybe_save_snapshot( $scores_by_cluster ) {
        $snapshots = get_option( self::SNAP_OPT, array() );
        $this_week = date( 'o-W' ); // ISO year-week e.g. 2026-07

        // Already snapped this week?
        if ( ! empty( $snapshots ) && end( $snapshots )['week'] === $this_week ) return;

        $snap = array( 'week' => $this_week, 'date' => wp_date( 'Y-m-d' ), 'clusters' => array() );
        foreach ( $scores_by_cluster as $name => $sd ) {
            $snap['clusters'][ $name ] = array(
                'score'      => $sd['score'],
                'components' => $sd['components'],
                'clicks'     => $sd['metrics']['clicks'] ?? 0,
                'impressions' => $sd['metrics']['impressions'] ?? 0,
            );
        }
        $snapshots[] = $snap;

        // Keep max 52 weeks (1 year)
        if ( count( $snapshots ) > 52 ) $snapshots = array_slice( $snapshots, -52 );

        update_option( self::SNAP_OPT, $snapshots, false );
    }

    /**
     * Get trend for a cluster: compare current score to previous snapshot.
     * Returns: 'up' | 'down' | 'stable' | 'new' and the delta.
     */
    private function get_trend( $cluster_name, $current_score ) {
        $snapshots = get_option( self::SNAP_OPT, array() );
        if ( count( $snapshots ) < 1 ) return array( 'trend' => 'new', 'delta' => 0 );

        // Get last snapshot (which is the most recent stored)
        $last = end( $snapshots );
        if ( ! isset( $last['clusters'][ $cluster_name ] ) ) return array( 'trend' => 'new', 'delta' => 0 );

        $prev_score = $last['clusters'][ $cluster_name ]['score'];
        $delta = $current_score - $prev_score;

        if ( $delta >= 5 ) return array( 'trend' => 'up', 'delta' => $delta );
        if ( $delta <= -5 ) return array( 'trend' => 'down', 'delta' => $delta );
        return array( 'trend' => 'stable', 'delta' => $delta );
    }

    /**
     * AJAX endpoint: returns scores for all clusters + saves snapshot.
     */
    public function ajax_monitoring() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $lang = isset( $_POST['lang'] ) ? sanitize_text_field( $_POST['lang'] ) : '';
        $data = $this->get_cocon_data( $lang );
        if ( empty( $data['clusters'] ) ) wp_send_json_error( array( 'message' => 'Aucune donnée.' ) );

        $nodes = $data['nodes'];

        // Aggregate AI traffic per URL (last 30 days)
        $ai_data = get_option( 'hts_citation_data', array() );
        $ai_per_url = array();
        $cutoff_30 = wp_date( 'Y-m-d', strtotime( '-30 days' ) );
        foreach ( $ai_data as $day => $dd ) {
            if ( $day < $cutoff_30 || empty( $dd['pages'] ) ) continue;
            foreach ( $dd['pages'] as $url => $info ) {
                if ( ! isset( $ai_per_url[ $url ] ) ) $ai_per_url[ $url ] = 0;
                $ai_per_url[ $url ] += (int) $info['count'];
            }
        }

        $scores_by_cluster = array();
        $results = array();

        foreach ( $data['clusters'] as $cname => $cl ) {
            if ( $cname === 'Non classé' ) continue;

            $sd = $this->compute_cluster_score( $cl, $nodes, $ai_per_url );
            $scores_by_cluster[ $cname ] = $sd;

            $trend = $this->get_trend( $cname, $sd['score'] );
            $diag  = $this->diagnose_cluster( $sd );

            $results[ $cname ] = array(
                'score'      => $sd['score'],
                'components' => $sd['components'],
                'metrics'    => $sd['metrics'],
                'trend'      => $trend['trend'],
                'delta'      => $trend['delta'],
                'diagnostic' => $diag,
            );
        }

        // Save weekly snapshot
        $this->maybe_save_snapshot( $scores_by_cluster );

        wp_send_json_success( array( 'clusters' => $results ) );
    }

    /**
     * Debug endpoint: shows WHY a page is in a cluster and similarity scores.
     * Call: wp-admin/admin-ajax.php?action=hts_cocon_debug_page&nonce=X&page_id=123
     */
    public function ajax_debug_page() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier( 1 );

        $pid = (int) ( $_GET['page_id'] ?? $_POST['page_id'] ?? 0 );
        if ( ! $pid ) wp_send_json_error( array( 'message' => 'page_id requis' ) );

        $lang = isset( $_GET['lang'] ) ? sanitize_text_field( $_GET['lang'] ) : '';
        $data = $this->get_cocon_data( $lang );
        if ( empty( $data['nodes'][ $pid ] ) ) wp_send_json_error( array( 'message' => 'Page non trouvée dans le cocon.' ) );

        $node = $data['nodes'][ $pid ];
        $debug = array(
            'page_id'    => $pid,
            'title'      => $node['title'],
            'cluster'    => $node['cluster'],
            'role'       => $node['role'],
            'keywords'   => $node['keywords'],
            'in_count'   => $node['in_count'],
            'in_count_semantic' => $node['in_count_semantic'] ?? 'N/A',
            'out_count'  => $node['out_count'],
            'is_orphan'  => $node['is_orphan'],
            'pillar_score' => $node['pillar_score'],
        );

        // Load embeddings
        $vectors = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb = new HTS_Embeddings();
            $vectors = $emb->load_all_vectors();
        }

        $debug['has_embedding'] = ( $vectors && isset( $vectors[ $pid ] ) );

        // Compute similarity to ALL other pages
        $similarities = array();
        if ( $vectors && isset( $vectors[ $pid ] ) ) {
            foreach ( $data['nodes'] as $other_pid => $other_node ) {
                if ( $other_pid === $pid || ! isset( $vectors[ $other_pid ] ) ) continue;
                $sim = HTS_Embeddings::cosine_similarity( $vectors[ $pid ], $vectors[ $other_pid ] );

                // Keyword overlap
                $kw_a = array_map( 'mb_strtolower', $node['keywords'] ?? array() );
                $kw_b = array_map( 'mb_strtolower', $other_node['keywords'] ?? array() );
                $kw_union = count( array_unique( array_merge( $kw_a, $kw_b ) ) );
                $kw_inter = count( array_intersect( $kw_a, $kw_b ) );
                $kw_jaccard = $kw_union > 0 ? round( $kw_inter / $kw_union, 3 ) : 0;

                $similarities[] = array(
                    'pid'        => $other_pid,
                    'title'      => mb_substr( $other_node['title'], 0, 50 ),
                    'cluster'    => $other_node['cluster'],
                    'cosine'     => round( $sim, 4 ),
                    'kw_jaccard' => $kw_jaccard,
                    'would_pass_gate' => ( $sim >= 0.35 || $kw_jaccard >= 0.10 ) && $sim >= 0.20 ? 'YES' : 'BLOCKED',
                    'block_reason'    => $sim < 0.20 ? 'cosine<0.20' : ( $sim < 0.35 && $kw_jaccard < 0.10 ? 'cosine<0.35+kw<0.10' : 'passes' ),
                );
            }
            usort( $similarities, function( $a, $b ) { return $b['cosine'] <=> $a['cosine']; } );
        }

        // Average similarity to whole site (Phase A0 check)
        $avg_sim_site = 0;
        if ( ! empty( $similarities ) ) {
            $avg_sim_site = round( array_sum( array_column( $similarities, 'cosine' ) ) / count( $similarities ), 4 );
        }
        $debug['avg_sim_to_site'] = $avg_sim_site;
        $debug['phase_a0_would_exclude'] = $avg_sim_site < 0.25;

        // Similarity to cluster mates
        $cluster_name = $node['cluster'];
        $cluster_sims = array_filter( $similarities, function( $s ) use ( $cluster_name ) { return $s['cluster'] === $cluster_name; } );
        $avg_sim_cluster = ! empty( $cluster_sims ) ? round( array_sum( array_column( $cluster_sims, 'cosine' ) ) / count( $cluster_sims ), 4 ) : 0;
        $debug['avg_sim_to_cluster'] = $avg_sim_cluster;
        $debug['phase_e2_would_exclude'] = $avg_sim_cluster < 0.30;

        // Show top 10 most similar and bottom 5 least similar
        $debug['top_10_similar'] = array_slice( $similarities, 0, 10 );
        $debug['bottom_5_similar'] = array_slice( $similarities, -5 );

        // Check AI suggestion cache
        $ai_cache_key = 'hts_cocon_ai_' . md5( $cluster_name . $lang );
        $ai_cached = get_option( $ai_cache_key, false );
        $debug['ai_cache_exists'] = ( $ai_cached !== false );
        if ( is_array( $ai_cached ) ) {
            $debug['ai_cache_count'] = count( $ai_cached );
            $debug['ai_cache_involves_page'] = count( array_filter( $ai_cached, function( $s ) use ( $pid ) {
                return (int) $s['source_id'] === $pid || (int) $s['target_id'] === $pid;
            } ) );
        }

        wp_send_json_success( $debug );
    }

    /**
     * Client decides: is a flagged page strategic diversification or truly off-topic?
     * POST: action=hts_cocon_page_decision, nonce, page_id, decision=keep|exclude
     */
    public function ajax_page_decision() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $pid = (int) ( $_POST['page_id'] ?? 0 );
        $decision = sanitize_text_field( $_POST['decision'] ?? '' );

        if ( ! $pid || ! in_array( $decision, array( 'keep', 'exclude', 'undo' ) ) ) {
            wp_send_json_error( array( 'message' => 'page_id et decision (keep|exclude|undo) requis.' ) );
        }

        $decisions = get_option( 'hts_cocon_page_decisions', array() );

        if ( $decision === 'undo' ) {
            unset( $decisions[ $pid ] );
            update_option( 'hts_cocon_page_decisions', $decisions, false );
            hts_add_log( '↩ Décision annulée pour "' . get_the_title( $pid ) . '"', 'info', 'cocon' );
            wp_send_json_success( array( 'page_id' => $pid, 'decision' => 'undo', 'message' => 'Décision annulée. La page est de nouveau en attente de validation.' ) );
            return;
        }
        $decisions[ $pid ] = array(
            'decision'   => $decision,
            'decided_at' => current_time( 'mysql' ),
            'title'      => get_the_title( $pid ),
        );
        update_option( 'hts_cocon_page_decisions', $decisions, false );

        $label = $decision === 'keep' ? 'diversification stratégique' : 'hors-sujet (exclu du maillage)';
        hts_add_log(
            '👤 Décision client : "' . get_the_title( $pid ) . '" → ' . $label,
            'info', 'cocon'
        );

        wp_send_json_success( array(
            'page_id'  => $pid,
            'decision' => $decision,
            'message'  => $decision === 'keep'
                ? 'Page conservée. Publiez du contenu complémentaire pour renforcer ce cocon.'
                : 'Page exclue du maillage. Elle ne recevra plus de suggestions de liens.',
        ) );
    }

    /**
     * Get all stored client decisions for flagged pages.
     */
    public static function get_page_decisions() {
        return get_option( 'hts_cocon_page_decisions', array() );
    }
}
