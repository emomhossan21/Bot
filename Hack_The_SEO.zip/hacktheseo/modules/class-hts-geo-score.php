<?php
defined( 'ABSPATH' ) || exit;
/**
 * GEO Score — Score d'optimisation pour la visibilité IA (0-100)
 *
 * 12 critères pondérés /113, normalisé /100.
 * Basé sur la recherche Princeton + consensus GEO 2026.
 * Propose des actions gap dans l'Inbox via le Workflow Engine.
 *
 * @since 1.32.0
 * @package HackTheSEO
 */

class HTS_Geo_Score {

    const META_SCORE   = '_hts_geo_score';
    const META_RESULT  = '_hts_geo_score_result';
    const META_DATE    = '_hts_geo_score_date';
    const CACHE_TTL    = DAY_IN_SECONDS; // 24h

    /**
     * Score minimum avant alerte Inbox (depuis agent settings 'geo_score').
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_min_score_alert() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'geo_score' );
            if ( isset( $s['min_score_alert'] ) ) {
                return max( 10, min( 90, (int) $s['min_score_alert'] ) );
            }
        }
        return 50;
    }

    public function init() {
        add_action( 'wp_ajax_hts_geo_score_analyze', array( $this, 'ajax_analyze' ) );
        add_action( 'wp_ajax_hts_geo_score_bulk',    array( $this, 'ajax_bulk' ) );

        // Cron bulk scan
        add_action( 'hts_geo_score_cron_scan', array( $this, 'cron_bulk_scan' ) );
        if ( ! wp_next_scheduled( 'hts_geo_score_cron_scan' ) ) {
            wp_schedule_event( time() + 3600, 'daily', 'hts_geo_score_cron_scan' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  CALCUL DU SCORE
     * ═══════════════════════════════════════════════ */

    /**
     * Calcule le GEO Score d'un article.
     *
     * @param int  $post_id
     * @param bool $force    Ignorer le cache
     * @return array|null    { geo_score, checks[], recommendations[], ... }
     */
    public function calculate( $post_id, $force = false ) {
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) return null;

        // Cache check
        if ( ! $force ) {
            $cached_date = (int) get_post_meta( $post_id, self::META_DATE, true );
            if ( $cached_date && ( time() - $cached_date ) < self::CACHE_TTL ) {
                $cached = get_post_meta( $post_id, self::META_RESULT, true );
                if ( is_array( $cached ) ) return $cached;
            }
        }

        $content  = $post->post_content;
        $text     = wp_strip_all_tags( $content );
        $site_url = home_url();

        // Récupérer le keyword
        $keyword = $this->find_keyword( $post_id, $post->post_title );

        $checks      = array();
        $total_score = 0;
        $max_score   = 0;

        // ── Critères extensibles ──
        $criteria = $this->get_criteria();

        foreach ( $criteria as $criterion ) {
            $result = call_user_func( $criterion['callback'], $post_id, $content, $text, $keyword, $site_url );
            $result['id']     = $criterion['id'];
            $result['label']  = $criterion['label'];
            $result['weight'] = $criterion['weight'];
            $result['max']    = $criterion['weight'];

            $checks[]     = $result;
            $total_score += $result['score'];
            $max_score   += $criterion['weight'];
        }

        // Score final normalisé /100
        $geo_score = $max_score > 0 ? (int) round( min( 100, ( $total_score / $max_score ) * 100 ) ) : 0;

        // Recommandations prioritaires (top 5 gaps)
        $recommendations = array();
        foreach ( $checks as $check ) {
            if ( ! empty( $check['fix'] ) ) {
                $gap = $check['weight'] - $check['score'];
                $recommendations[] = array(
                    'criterion' => $check['id'],
                    'label'     => $check['label'],
                    'fix'       => $check['fix'],
                    'why'       => $check['why'] ?? '',
                    'priority'  => $gap,
                    'impact'    => $check['weight'],
                );
            }
        }
        usort( $recommendations, function( $a, $b ) { return $b['priority'] <=> $a['priority']; } );
        $recommendations = array_slice( $recommendations, 0, 5 );

        $result = array(
            'post_id'         => $post_id,
            'title'           => $post->post_title,
            'geo_score'       => $geo_score,
            'total_raw'       => $total_score,
            'max_raw'         => $max_score,
            'checks'          => $checks,
            'recommendations' => $recommendations,
            'word_count'      => hts_word_count( $text ),
            'keyword'         => $keyword,
        );

        // Cache
        update_post_meta( $post_id, self::META_SCORE, $geo_score );
        update_post_meta( $post_id, self::META_RESULT, $result );
        update_post_meta( $post_id, self::META_DATE, time() );

        return $result;
    }

    /**
     * Retourne les 12 critères avec callbacks.
     * Extensible via apply_filters('hts_geo_score_criteria').
     */
    public function get_criteria() {
        $criteria = array(
            array( 'id' => 'faq_lists',       'label' => 'FAQ et listes structurées',     'weight' => 18, 'callback' => array( $this, 'check_faq_lists' ) ),
            array( 'id' => 'direct_intro',     'label' => 'Réponse directe en intro',      'weight' => 15, 'callback' => array( $this, 'check_direct_intro' ) ),
            array( 'id' => 'data_stats',       'label' => 'Données chiffrées et stats',    'weight' => 15, 'callback' => array( $this, 'check_data_stats' ) ),
            array( 'id' => 'sources_cited',    'label' => 'Sources citées',                'weight' => 10, 'callback' => array( $this, 'check_sources' ) ),
            array( 'id' => 'headings',         'label' => 'Structure H2/H3',               'weight' => 12, 'callback' => array( $this, 'check_headings' ) ),
            array( 'id' => 'content_length',   'label' => 'Longueur du contenu',           'weight' => 8,  'callback' => array( $this, 'check_length' ) ),
            array( 'id' => 'internal_links',   'label' => 'Maillage interne',              'weight' => 8,  'callback' => array( $this, 'check_internal_links' ) ),
            array( 'id' => 'images_alt',       'label' => 'Images et ALT SEO',             'weight' => 7,  'callback' => array( $this, 'check_images' ) ),
            array( 'id' => 'meta_seo',         'label' => 'Meta title et description',     'weight' => 5,  'callback' => array( $this, 'check_meta' ) ),
            array( 'id' => 'freshness',        'label' => 'Fraîcheur',                     'weight' => 5,  'callback' => array( $this, 'check_freshness' ) ),
            array( 'id' => 'schema_markup',    'label' => 'Schema Markup',                 'weight' => 5,  'callback' => array( $this, 'check_schema' ) ),
            array( 'id' => 'eeat_signals',     'label' => 'Signaux E-E-A-T',              'weight' => 5,  'callback' => array( $this, 'check_eeat' ) ),
        );

        /**
         * Filter: GEO score criteria list (id, label, weight, callback).
         *
         * @since 1.31.0
         * @param array $criteria Array of scoring criteria.
         */
        return apply_filters( 'hts_geo_score_criteria', $criteria );
    }

    /* ═══════════════════════════════════════════════
     *  12 CRITÈRES
     * ═══════════════════════════════════════════════ */

    /** #1 — FAQ / Listes structurées (18) */
    public function check_faq_lists( $post_id, $content, $text, $keyword, $site_url ) {
        $score = 0;
        $parts = array();

        $has_faq = preg_match( '/faq|questions?\s*(fréquentes|posées|courantes)|frequently\s*asked/i', $content );
        preg_match_all( '/<(ul|ol)[^>]*>.*?<\/\1>/si', $content, $lists );
        $list_count = count( $lists[0] );
        preg_match_all( '/<details[^>]*>.*?<\/details>/si', $content, $details );
        $details_count = count( $details[0] );

        if ( $has_faq || $details_count >= 2 ) { $score += 8; $parts[] = 'FAQ détectée'; }
        if ( $list_count >= 3 ) { $score += 6; $parts[] = $list_count . ' listes'; }
        elseif ( $list_count >= 1 ) { $score += 3; $parts[] = $list_count . ' liste(s)'; }
        if ( $details_count >= 3 ) { $score += 4; $parts[] = $details_count . ' blocs Q&A'; }

        $score = min( 18, $score );
        return array(
            'score'  => $score,
            'detail' => empty( $parts ) ? 'Aucune FAQ ni liste structurée' : implode( ', ', $parts ),
            'fix'    => $score < 12 ? 'Ajouter une section FAQ avec 3-5 questions fréquentes en fin d\'article.' : null,
            'why'    => 'Les IA extraient en priorité les contenus structurés en listes et FAQ pour leurs réponses.',
        );
    }

    /** #2 — Réponse directe en intro (15) */
    public function check_direct_intro( $post_id, $content, $text, $keyword, $site_url ) {
        $first_p = '';
        if ( preg_match( '/<p[^>]*>(.*?)<\/p>/si', $content, $fp ) ) {
            $first_p = wp_strip_all_tags( $fp[1] );
        }
        $fp_words = hts_word_count( $first_p );
        $kw_in_intro = ! empty( $keyword ) && mb_stripos( $first_p, $keyword ) !== false;

        if ( $fp_words >= 20 && $fp_words <= 80 && $kw_in_intro ) {
            $score = 15; $detail = 'Intro concise (' . $fp_words . ' mots) avec keyword';
        } elseif ( $fp_words >= 20 && $fp_words <= 80 ) {
            $score = 10; $detail = 'Intro concise mais keyword absent';
        } elseif ( $fp_words > 80 ) {
            $score = 5; $detail = 'Intro trop longue (' . $fp_words . ' mots)';
        } else {
            $score = 2; $detail = 'Intro trop courte (' . $fp_words . ' mots)';
        }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $score < 12 ? 'Reformuler l\'intro (30-60 mots) pour répondre directement à la question avec le keyword dans les premiers mots.' : null,
            'why'    => 'Les IA cherchent une réponse directe dans les premiers paragraphes pour la citer.',
        );
    }

    /** #3 — Données chiffrées / statistiques (15) */
    public function check_data_stats( $post_id, $content, $text, $keyword, $site_url ) {
        preg_match_all( '/\b\d{1,3}(?:[.,]\d{1,3})*\s*(?:%|€|\$|millions?|milliards?|ans?|jours?|heures?|kg|km|fois)\b/i', $text, $numbers );
        $has_source_words = preg_match( '/(selon|d\'après|étude|recherche|rapport|statistique|publié|source)/i', $text );
        $num_count = count( $numbers[0] );

        if ( $num_count >= 5 && $has_source_words ) {
            $score = 15; $detail = $num_count . ' données + sourcing';
        } elseif ( $num_count >= 5 ) {
            $score = 12; $detail = $num_count . ' données chiffrées';
        } elseif ( $num_count >= 2 ) {
            $score = 7; $detail = $num_count . ' données — enrichir';
        } else {
            $score = 2; $detail = $num_count . ' donnée(s) — critique';
        }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $score < 10 ? 'Enrichir avec des données factuelles, statistiques et pourcentages sourcés.' : null,
            'why'    => 'Les contenus avec des chiffres concrets sont plus crédibles et plus souvent cités par les IA.',
        );
    }

    /** #4 — Sources citées (10) */
    public function check_sources( $post_id, $content, $text, $keyword, $site_url ) {
        preg_match_all( '/<a[^>]+href\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $content, $links );
        $external = 0;
        $auth_domains = array( '.gouv.fr', '.gov', '.edu', 'wikipedia.org', 'statista.com', 'insee.fr', 'who.int', 'europa.eu' );

        foreach ( ( $links[1] ?? array() ) as $href ) {
            if ( strpos( $href, 'http' ) === 0 && strpos( $href, $site_url ) !== 0 ) {
                $external++;
            }
        }

        if ( $external >= 3 ) {
            $score = 10; $detail = $external . ' sources externes';
        } elseif ( $external >= 1 ) {
            $score = 5; $detail = $external . ' source(s) — en ajouter';
        } else {
            $score = 0; $detail = 'Aucune source externe';
        }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $score < 7 ? 'Ajouter 2-3 sources autoritaires (études, rapports officiels, .gouv, .edu).' : null,
            'why'    => 'Les IA vérifient la crédibilité via les sources citées. Des liens vers des domaines autoritaires augmentent la confiance.',
        );
    }

    /** #5 — Structure H2/H3 (12) */
    public function check_headings( $post_id, $content, $text, $keyword, $site_url ) {
        preg_match_all( '/<h2[^>]*>/i', $content, $h2 );
        preg_match_all( '/<h3[^>]*>/i', $content, $h3 );
        $h2c = count( $h2[0] ); $h3c = count( $h3[0] );

        if ( $h2c >= 3 && $h3c >= 2 ) {
            $score = 12; $detail = $h2c . ' H2, ' . $h3c . ' H3 — riche';
        } elseif ( $h2c >= 3 ) {
            $score = 9; $detail = $h2c . ' H2, ' . $h3c . ' H3 — ajoutez des H3';
        } elseif ( $h2c >= 2 ) {
            $score = 6; $detail = $h2c . ' H2 — ajoutez des sous-titres';
        } else {
            $score = max( 0, $h2c * 3 ); $detail = $h2c . ' H2 — structure insuffisante';
        }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $score < 9 ? 'Ajouter des sous-titres H2/H3 pour structurer le contenu (min. 3 H2 + 2 H3).' : null,
            'why'    => 'Une bonne structure de titres aide les IA à comprendre et segmenter le contenu.',
        );
    }

    /** #6 — Longueur contenu (8) */
    public function check_length( $post_id, $content, $text, $keyword, $site_url ) {
        $wc = hts_word_count( $text );

        if ( $wc >= 2500 ) { $score = 8; $detail = $wc . ' mots — excellent'; }
        elseif ( $wc >= 1500 ) { $score = 7; $detail = $wc . ' mots — bon'; }
        elseif ( $wc >= 600 ) { $score = 4; $detail = $wc . ' mots — suffisant'; }
        else { $score = 1; $detail = $wc . ' mots — trop court'; }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $wc < 1200 ? 'Article trop court (' . $wc . ' mots). Enrichir pour atteindre 1200-2000 mots.' : null,
            'why'    => 'Les articles longs et complets couvrent mieux le sujet et sont plus souvent référencés par les IA.',
        );
    }

    /** #7 — Maillage interne (8) */
    public function check_internal_links( $post_id, $content, $text, $keyword, $site_url ) {
        preg_match_all( '/<a[^>]+href\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $content, $links );
        $internal = 0;
        foreach ( ( $links[1] ?? array() ) as $href ) {
            if ( strpos( $href, $site_url ) === 0 || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                $internal++;
            }
        }

        if ( $internal >= 5 ) { $score = 8; $detail = $internal . ' liens internes'; }
        elseif ( $internal >= 3 ) { $score = 6; $detail = $internal . ' liens — bon'; }
        elseif ( $internal >= 1 ) { $score = 3; $detail = $internal . ' lien(s) — insuffisant'; }
        else { $score = 0; $detail = 'Aucun lien interne'; }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $internal < 3 ? 'Ajouter des liens vers des articles connexes (min. 3 liens internes).' : null,
            'why'    => 'Le maillage interne transmet l\'autorité et aide les IA à cartographier les sujets du site.',
        );
    }

    /** #8 — Images + ALT (7) */
    public function check_images( $post_id, $content, $text, $keyword, $site_url ) {
        preg_match_all( '/<img[^>]*>/i', $content, $imgs );
        $total = count( $imgs[0] );
        $with_alt = 0;
        $with_kw_alt = 0;
        foreach ( $imgs[0] as $img ) {
            if ( preg_match( '/alt\s*=\s*["\']([^"\']+)["\']/i', $img, $am ) ) {
                $with_alt++;
                if ( ! empty( $keyword ) && mb_stripos( $am[1], $keyword ) !== false ) $with_kw_alt++;
            }
        }

        if ( $total >= 2 && $with_alt === $total && $with_kw_alt >= 1 ) { $score = 7; $detail = $total . ' images, ALT+keyword'; }
        elseif ( $total >= 2 && $with_alt === $total ) { $score = 5; $detail = $total . ' images avec ALT'; }
        elseif ( $total >= 1 ) { $score = 3; $detail = $total . ' image(s), ' . $with_alt . ' avec ALT'; }
        else { $score = 0; $detail = 'Aucune image'; }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $score < 5 ? 'Ajouter au moins 2 images avec ALT descriptif contenant le keyword.' : null,
            'why'    => 'Les images avec ALT optimisé renforcent le SEO et la compréhension du contenu par les IA.',
        );
    }

    /** #9 — Meta title + description (5) */
    public function check_meta( $post_id, $content, $text, $keyword, $site_url ) {
        $mt = get_post_meta( $post_id, '_hts_meta_title', true )
            ?: get_post_meta( $post_id, '_yoast_wpseo_title', true )
            ?: get_post_meta( $post_id, 'rank_math_title', true )
            ?: '';
        $md = get_post_meta( $post_id, '_hts_meta_description', true )
            ?: get_post_meta( $post_id, '_yoast_wpseo_metadesc', true )
            ?: get_post_meta( $post_id, 'rank_math_description', true )
            ?: '';

        $score = 0;
        $parts = array();
        $mt_len = mb_strlen( $mt );
        $md_len = mb_strlen( $md );

        if ( $mt_len >= 30 && $mt_len <= 65 ) { $score += 3; $parts[] = 'Title OK (' . $mt_len . 'c)'; }
        elseif ( $mt_len > 0 ) { $score += 1; $parts[] = 'Title ' . $mt_len . 'c'; }
        else { $parts[] = 'Title manquant'; }

        if ( $md_len >= 120 && $md_len <= 160 ) { $score += 2; $parts[] = 'Desc OK (' . $md_len . 'c)'; }
        elseif ( $md_len > 0 ) { $score += 1; $parts[] = 'Desc ' . $md_len . 'c'; }
        else { $parts[] = 'Desc manquante'; }

        return array(
            'score'  => $score,
            'detail' => implode( ' | ', $parts ),
            'fix'    => $score < 4 ? 'Compléter le meta title (50-60 car.) et la meta description (130-155 car.).' : null,
            'why'    => 'Les meta bien optimisées améliorent le CTR dans les SERP et sont lues par les IA.',
        );
    }

    /** #10 — Fraîcheur (5) */
    public function check_freshness( $post_id, $content, $text, $keyword, $site_url ) {
        if ( class_exists( 'HTS_Freshness' ) ) {
            $freshness_score = HTS_Freshness::get_score( $post_id );
            $days = HTS_Freshness::get_days_since_modified( $post_id );
        } else {
            $modified = get_post_modified_time( 'U', false, $post_id );
            $days = $modified ? (int) round( ( time() - $modified ) / DAY_IN_SECONDS ) : 9999;
            $freshness_score = max( 0, min( 100, 100 - ( $days / 365 * 100 ) ) );
        }

        if ( $days < 90 ) { $score = 5; $detail = 'Modifié il y a ' . $days . 'j — frais'; }
        elseif ( $days < 180 ) { $score = 3; $detail = 'Modifié il y a ' . $days . 'j — à rafraîchir'; }
        else { $score = 1; $detail = 'Modifié il y a ' . $days . 'j — obsolète'; }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $days >= 180 ? 'Article non modifié depuis ' . $days . ' jours. Mettre à jour avec des infos récentes.' : null,
            'why'    => 'Les IA privilégient les contenus récents et à jour.',
        );
    }

    /** #11 — Schema Markup (5) */
    public function check_schema( $post_id, $content, $text, $keyword, $site_url ) {
        $detected = get_post_meta( $post_id, '_hts_schemas_predetected', true );
        $count = is_array( $detected ) ? count( $detected ) : 0;
        $has_jsonld = strpos( $content, 'application/ld+json' ) !== false;

        if ( $count >= 2 || $has_jsonld ) {
            $score = 5; $detail = $count . ' schema(s) détecté(s)' . ( $has_jsonld ? ' + JSON-LD inline' : '' );
        } elseif ( $count >= 1 ) {
            $score = 3; $detail = $count . ' schema — enrichir';
        } else {
            $score = 0; $detail = 'Aucun schema détecté';
        }

        return array(
            'score'  => $score,
            'detail' => $detail,
            'fix'    => $score < 4 ? 'Ajouter un schema FAQ ou HowTo pour améliorer la visibilité structurée.' : null,
            'why'    => 'Les schemas JSON-LD aident les IA à comprendre le type de contenu et ses entités.',
        );
    }

    /** #12 — E-E-A-T signaux (5) */
    public function check_eeat( $post_id, $content, $text, $keyword, $site_url ) {
        $post = get_post( $post_id );
        $score = 0;
        $parts = array();

        // Auteur != admin
        $author = get_the_author_meta( 'display_name', $post->post_author );
        if ( ! empty( $author ) && mb_strtolower( $author ) !== 'admin' && mb_strtolower( $author ) !== 'administrator' ) {
            $score += 2; $parts[] = 'Auteur : ' . $author;
        } else {
            $parts[] = 'Auteur = admin';
        }

        // Bio auteur
        $bio = get_the_author_meta( 'description', $post->post_author );
        if ( ! empty( $bio ) && mb_strlen( $bio ) >= 30 ) {
            $score += 2; $parts[] = 'Bio auteur présente';
        } else {
            $parts[] = 'Bio auteur absente';
        }

        // Date visible (post_date != empty)
        if ( ! empty( $post->post_date ) ) {
            $score += 1; $parts[] = 'Date publiée';
        }

        return array(
            'score'  => $score,
            'detail' => implode( ' | ', $parts ),
            'fix'    => $score < 4 ? 'Définir un auteur (pas "admin") avec une bio descriptive pour renforcer la crédibilité.' : null,
            'why'    => 'Les signaux E-E-A-T (Expertise, Experience, Authoritativeness, Trust) influencent le classement IA.',
        );
    }

    /* ═══════════════════════════════════════════════
     *  PROPOSITIONS GAP → WORKFLOW ENGINE
     * ═══════════════════════════════════════════════ */

    /**
     * Envoyer les gap proposals au Workflow Engine.
     */
    public function propose_gaps( $post_id, $result ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return;
        if ( empty( $result['recommendations'] ) ) return;

        // Seuil configurable depuis les agent settings
        $min_alert = self::get_min_score_alert();
        if ( ( $result['geo_score'] ?? 100 ) >= $min_alert ) return;

        $top_rec = $result['recommendations'][0];
        HTS_Workflow_Engine::propose(
            'geo_score',
            'geo_optimize',
            $post_id,
            array(
                'geo_score'  => $result['geo_score'],
                'top_fix'    => $top_rec['fix'],
                'top_why'    => $top_rec['why'] ?? '',
                'criterion'  => $top_rec['criterion'],
                'fixes_count'=> count( $result['recommendations'] ),
            ),
            $result['geo_score'] < 30 ? 'high' : 'medium'
        );
    }

    /* ═══════════════════════════════════════════════
     *  CRON + AJAX
     * ═══════════════════════════════════════════════ */

    /**
     * Cron : scan bulk de tous les posts publiés.
     */
    public function cron_bulk_scan() {
        $lock_key = 'hts_lock_geo_bulk_scan';
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, 120 );

        try {
            $batch_size = 50;

            $posts = get_posts( array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => $batch_size + 1,
                'fields'         => 'ids',
                'orderby'        => 'modified',
                'order'          => 'ASC',
                'meta_query'     => array(
                    'relation' => 'OR',
                    array( 'key' => self::META_DATE, 'compare' => 'NOT EXISTS' ),
                    array( 'key' => self::META_DATE, 'value' => time() - self::CACHE_TTL, 'compare' => '<', 'type' => 'NUMERIC' ),
                ),
            ) );

            $has_more = count( $posts ) > $batch_size;
            $posts    = array_slice( $posts, 0, $batch_size );

            $count = 0;
            foreach ( $posts as $pid ) {
                $result = $this->calculate( $pid, true );
                if ( $result ) {
                    $this->propose_gaps( $pid, $result );
                    $count++;
                }
            }

            if ( $count > 0 && function_exists( 'hts_add_log' ) ) {
                hts_add_log( "GEO Score cron : {$count} articles scannés", 'info', 'geo-score' );
            }

            // Reschedule soon if more posts remain
            if ( $has_more ) {
                wp_schedule_single_event( time() + 120, 'hts_geo_score_cron_scan' );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'GEO Score cron : more posts remain, rescheduled in 2 min', 'info', 'geo-score' );
                }
            }
            delete_transient( $lock_key );
        } catch ( \Throwable $e ) {
            delete_transient( $lock_key );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'cron', 'geo_score_cron_bulk_scan error: ' . $e->getMessage() );
            }
        }
    }

    public function ajax_analyze() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'Post ID manquant' );

        $result = $this->calculate( $post_id, true );
        if ( ! $result ) wp_send_json_error( 'Article introuvable' );

        wp_send_json_success( $result );
    }

    public function ajax_bulk() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $posts = get_posts( array(
            'post_type' => 'post', 'post_status' => 'publish',
            'posts_per_page' => 50, 'fields' => 'ids',
            'orderby' => 'modified', 'order' => 'ASC',
        ) );

        $results = array();
        foreach ( $posts as $pid ) {
            $r = $this->calculate( $pid, true );
            if ( $r ) {
                $results[] = array(
                    'post_id'   => $pid,
                    'title'     => $r['title'],
                    'geo_score' => $r['geo_score'],
                    'top_fix'   => ! empty( $r['recommendations'] ) ? $r['recommendations'][0]['fix'] : null,
                );
            }
        }

        usort( $results, function( $a, $b ) { return $a['geo_score'] <=> $b['geo_score']; } );

        $scores = array_column( $results, 'geo_score' );
        $avg = count( $scores ) > 0 ? round( array_sum( $scores ) / count( $scores ) ) : 0;

        wp_send_json_success( array( 'results' => $results, 'avg_score' => $avg, 'total' => count( $results ) ) );
    }

    /* ═══════════════════════════════════════════════
     *  HELPERS
     * ═══════════════════════════════════════════════ */

    private function find_keyword( $post_id, $title ) {
        $kw = get_post_meta( $post_id, '_hts_api_keyword', true );
        if ( $kw ) return $kw;
        $kw = get_post_meta( $post_id, '_hts_focus_keyword', true );
        if ( $kw ) return $kw;
        $kw = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
        if ( $kw ) return $kw;
        $kw = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        if ( $kw ) return $kw;
        return $title;
    }
}
