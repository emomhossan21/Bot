<?php
/**
 * Hack The SEO — Redirections & 404 (S9 — DS v5.7 pixel-perfect)
 * Standalone page, CEO-friendly
 *
 * AJAX endpoints used:
 *   hts_redirect_get_data    → Load all data (rules + 404s + patterns)
 *   hts_redirect_action      → add / edit / delete / toggle redirect
 *   hts_404_action            → ignore / redirect / accept_suggestion / clear / cleanup_false_positives
 *   hts_redirect_bulk         → accept_all_suggestions / ignore_404s
 *   hts_redirect_export_csv  → Export CSV
 *   hts_redirect_import_csv  → Import CSV
 *
 * @since 2.6.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! current_user_can( 'manage_options' ) ) return;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}
$nonce = wp_create_nonce( 'hts_admin_nonce' );
$ajax  = admin_url( 'admin-ajax.php' );
$gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
$_can_redirect_ai = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::can( 'redirect_ai' ) : true;
?>

<?php echo HTS_DS::page_open( true ); ?>

<?php // ── Hero (matches JSX: dark gradient + radial glow + right KPIs) ── ?>
<div class="hts-hero" style="position:relative;overflow:hidden;margin-bottom:20px">
	<div style="position:absolute;top:-30px;right:-30px;width:180px;height:180px;border-radius:50%;background:radial-gradient(circle,rgba(0,210,106,.08) 0%,transparent 70%);pointer-events:none"></div>
	<div style="display:flex;align-items:center;justify-content:space-between;position:relative;z-index:1">
		<div style="flex:1">
			<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
				<?php echo HTS_DS::dot( $gsc_connected ? 'ok' : 'fail', 8 ); ?>
				<span style="font-size:11px;font-weight:600;color:<?php echo $gsc_connected ? 'rgba(0,210,106,.8)' : 'rgba(239,68,68,.8)'; ?>;text-transform:uppercase;letter-spacing:.08em">
					<?php echo $gsc_connected ? 'Google Search Console connectée' : 'Search Console non connectée'; ?>
				</span>
			</div>
			<h1 class="hts-hero__title">Redirections & 404</h1>
			<p style="font-size:14px;color:rgba(255,255,255,.55);margin:6px 0 0;line-height:1.5" id="hero-sub">Chargement…</p>
		</div>
		<div style="display:flex;gap:14px;position:relative;z-index:1">
			<div style="text-align:center;padding:10px 18px;border-radius:12px;background:rgba(255,255,255,.06)">
				<div style="font-size:24px;font-weight:800;color:var(--hts-success)" id="hero-clics">—</div>
				<div style="font-size:9px;color:rgba(255,255,255,.35);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-top:2px">Clics préservés (90j)</div>
			</div>
			<div style="text-align:center;padding:10px 18px;border-radius:12px;background:rgba(239,68,68,.1)" id="hero-404-box">
				<div style="font-size:24px;font-weight:800;color:var(--hts-danger)" id="hero-404">—</div>
				<div style="font-size:9px;color:rgba(255,255,255,.35);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-top:2px">Erreurs 404</div>
				<div style="font-size:10px;color:var(--hts-danger);font-weight:700;margin-top:4px;display:none" id="hero-lost"></div>
			</div>
		</div>
	</div>
</div>

<?php // ── Tabs (3 tabs: Vue d'ensemble, Pages introuvables, Redirections) ── ?>
<?php echo HTS_DS::tab_bar( array(
	array( 'id' => 'home',  'label' => "Vue d'ensemble", 'icon' => '', 'badge' => 0 ),
	array( 'id' => '404s',  'label' => 'Pages introuvables', 'icon' => '', 'badge' => 0 ),
	array( 'id' => 'rules', 'label' => 'Redirections',       'icon' => '', 'badge' => 0 ),
), 'home' ); ?>

<div style="margin-top:24px"></div>

<div class="hts-rd">
	<div id="hts-ld" style="text-align:center;padding:30px;color:var(--hts-text-3);font-size:13px">Chargement…</div>

	<!-- ═══ HOME / VUE D'ENSEMBLE ═══ -->
	<div class="vw active" id="vw-home">

		<!-- AI Suggestions — purple gradient card (JSX exact) -->
		<div id="ai-card" style="display:none;padding:22px 24px;border-radius:18px;background:linear-gradient(135deg,#F5F3FF 0%,#EDE9FE 50%,#F5F3FF 100%);border:1px solid var(--hts-geo-border);margin-bottom:24px">
			<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
				<div style="display:flex;align-items:center;gap:8px">
					<?php echo HTS_DS::icon( 'zap', 16, 'var(--hts-geo)' ); ?>
					<span style="font-size:14px;font-weight:700;color:var(--hts-geo)" id="ai-title"></span>
					<span style="font-size:12px;color:var(--hts-text-3)" id="ai-count"></span>
				</div>
				<?php if ( $_can_redirect_ai ) : ?>
				<button id="ai-bulk" onclick="_bulkAI()" style="display:none;align-items:center;gap:4px;padding:6px 14px;border-radius:8px;border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);white-space:nowrap">
					<?php echo HTS_DS::icon( 'check', 12, '#fff' ); ?> Valider les <span id="ai-bulk-n">0</span> fiables
				</button>
				<?php else : ?>
				<a id="ai-bulk" href="<?php echo esc_url( rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' ) . '/user/pricing/plans' ); ?>" target="_blank" style="display:none;align-items:center;gap:4px;padding:6px 14px;border-radius:8px;border:none;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--hts-font);white-space:nowrap;text-decoration:none">
					<?php echo HTS_DS::icon( 'zap', 12, '#fff' ); ?> Suggestions IA <span id="ai-bulk-n" style="display:none">0</span>
				</a>
				<?php endif; ?>
			</div>
			<div id="ai-list"></div>
		</div>

		<!-- Health issues -->
		<div id="health-box"></div>

		<!-- Pattern alerts -->
		<div id="pat-box"></div>

		<!-- Section: Dernières erreurs 404 -->
		<div id="ov-404-section" style="display:none;margin-bottom:24px">
			<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
				<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Dernières erreurs 404</span>
				<button style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)" onclick="htsRN(document.querySelector('[data-tab=&quot;404s&quot;]'))">Tout voir</button>
			</div>
			<div id="ov-404-list"></div>
		</div>

		<!-- Section: Dernières redirections -->
		<div id="ov-rules-section" style="display:none;margin-top:24px">
			<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
				<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Dernières redirections</span>
				<button style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)" onclick="htsRN(document.querySelector('[data-tab=&quot;rules&quot;]'))">Tout voir</button>
			</div>
			<div id="ov-rules-list"></div>
		</div>
	</div>

	<!-- ═══ 404s ═══ -->
	<div class="vw" id="vw-404s">
		<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
			<div style="display:flex;align-items:center;gap:8px;flex:1;padding:8px 14px;border:1.5px solid var(--hts-border);border-radius:10px;background:var(--hts-bg)">
				<?php echo HTS_DS::icon( 'search', 14, 'var(--hts-text-3)' ); ?>
				<input id="f-search" type="text" placeholder="Rechercher une erreur 404..." style="flex:1;border:none;outline:none;font-size:13px;font-family:var(--hts-font);color:var(--hts-text);background:transparent">
			</div>
			<button id="btn-analyse" onclick="_runAnalysis(this)" style="display:flex;align-items:center;gap:6px;padding:8px 20px;border-radius:10px;border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);white-space:nowrap">
				<?php echo HTS_DS::icon( 'zap', 13, '#fff' ); ?> Lancer l'analyse
			</button>
			<button onclick="_purgeBots(this)" style="display:flex;align-items:center;gap:6px;padding:8px 16px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);color:var(--hts-text-2);font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);white-space:nowrap" title="Supprime les faux 404 générés par des bots et scanners de sécurité">
				<?php echo HTS_DS::icon( 'trash-2', 13, 'var(--hts-text-3)' ); ?> Purger les bots
			</button>

		</div>
		<!-- Progress bar (hidden by default) -->
		<div id="analysis-progress" style="display:none;margin-bottom:12px">
			<div style="display:flex;align-items:center;gap:16px;padding:14px 20px;background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:14px;box-shadow:var(--hts-shadow)">
				<div style="width:32px;height:32px;position:relative;flex-shrink:0">
					<div style="position:absolute;inset:2px;border-radius:50%;border:1px solid var(--hts-border-sub)"></div>
					<div style="position:absolute;inset:0;animation:htsSpin 1.8s linear infinite">
						<div style="width:6px;height:6px;border-radius:50%;background:var(--hts-geo);position:absolute;top:0;left:50%;margin-left:-3px"></div>
					</div>
					<div style="position:absolute;inset:5px;animation:htsSpin 2.8s linear infinite reverse">
						<div style="width:4px;height:4px;border-radius:50%;background:var(--hts-geo);opacity:.5;position:absolute;top:0;left:50%;margin-left:-2px"></div>
					</div>
					<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
						<div style="width:5px;height:5px;border-radius:50%;background:var(--hts-geo);opacity:.7;animation:htsPulse 2s ease-in-out infinite"></div>
					</div>
				</div>
				<div style="min-width:0;flex:1">
					<span id="analysis-label" style="font-size:13px;font-weight:600;color:var(--hts-text)">Préparation...</span>
					<div style="margin-top:8px;height:3px;border-radius:2px;background:var(--hts-surface);overflow:hidden">
						<div id="analysis-bar" style="height:100%;width:0%;border-radius:2px;background:var(--hts-geo);transition:width .4s ease"></div>
					</div>
				</div>
			</div>
		</div>
		<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
			<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--hts-text-3)">
				<input type="checkbox" id="f-show-bots" style="accent-color:var(--hts-accent)"> Inclure les bots spam (SEMrush, Ahrefs...)
			</label>
			<span id="f-count" style="font-size:12px;color:var(--hts-text-3)"></span>
		</div>
		<div id="f-list"></div>
		<div class="hts-hidden" id="f-empty" style="padding:30px 20px;text-align:center;color:var(--hts-text-3);font-size:13px">Aucune erreur 404 en attente</div>
	</div>

	<!-- ═══ RULES ═══ -->
	<div class="vw" id="vw-rules">
		<!-- Toolbar: Search + Add + Import + Export (JSX exact) -->
		<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
			<div style="display:flex;align-items:center;gap:8px;flex:1;padding:8px 14px;border:1.5px solid var(--hts-border);border-radius:10px;background:var(--hts-bg)">
				<?php echo HTS_DS::icon( 'search', 14, 'var(--hts-text-3)' ); ?>
				<input id="r-search" type="text" placeholder="Rechercher..." style="flex:1;border:none;outline:none;font-size:13px;font-family:var(--hts-font);color:var(--hts-text);background:transparent">
			</div>
			<button id="btn-add-toggle" style="display:flex;align-items:center;gap:5px;padding:8px 16px;border-radius:10px;border:none;background:var(--hts-accent);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font)">
				<?php echo HTS_DS::icon( 'plus', 13, '#fff' ); ?> Ajouter
			</button>
			<label style="cursor:pointer;margin:0;display:flex;align-items:center;gap:5px;padding:8px 14px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);font-family:var(--hts-font)">
				<?php echo HTS_DS::icon( 'upload', 13, 'var(--hts-text-3)' ); ?> Importer
				<input type="file" id="imp-file" accept=".csv,.tsv,.txt" style="display:none">
			</label>
			<button onclick="_export()" style="display:flex;align-items:center;gap:5px;padding:8px 14px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">
				<?php echo HTS_DS::icon( 'download', 13, 'var(--hts-text-3)' ); ?> Exporter
			</button>
		</div>
		<div id="imp-msg" style="font-size:11px;margin-bottom:8px;display:none"></div>

		<!-- Inline add form (JSX: collapsible) -->
		<div id="add-form" class="hts-ds-card" style="display:none;padding:16px 20px;margin-bottom:16px;border-radius:14px">
			<div style="display:flex;align-items:center;gap:10px">
				<input id="a-src" placeholder="/ancienne-url" style="flex:1;padding:9px 12px;border-radius:8px;border:1.5px solid var(--hts-border);font-size:13px;font-family:var(--hts-mono);color:var(--hts-text);background:var(--hts-bg)">
				<span style="color:var(--hts-faint);font-size:13px">→</span>
				<div class="ac-wrap" style="flex:2">
					<input id="a-tgt" class="hts-ac-input" placeholder="Chercher une page ou coller une URL" style="padding:9px 12px;border-radius:8px;border:1.5px solid var(--hts-border);font-size:13px;font-family:var(--hts-mono);color:var(--hts-text);background:var(--hts-bg)" autocomplete="off">
					<div class="ac-drop" id="acd-a-tgt"></div>
				</div>
				<select id="a-typ" style="padding:9px 10px;border-radius:8px;border:1.5px solid var(--hts-border);font-size:13px;font-family:var(--hts-font);color:var(--hts-text);background:var(--hts-bg);cursor:pointer">
					<option>301</option><option>302</option><option>307</option><option>410</option>
				</select>
				<label style="display:flex;align-items:center;gap:4px;font-size:12px;color:var(--hts-text-2);cursor:pointer;white-space:nowrap">
					<input type="checkbox" id="a-rgx" style="accent-color:var(--hts-accent)"> Regex
				</label>
				<button id="a-submit" onclick="_addRule()" style="padding:9px 20px;border-radius:8px;border:none;background:var(--hts-success);color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--hts-font)">Créer</button>
			</div>
			<span id="a-msg" style="font-size:11px;margin-top:6px;display:block"></span>
		</div>

		<div id="audit-result"></div>

		<div id="r-list"></div>
		<div class="hts-hidden" id="r-empty" style="padding:30px 20px;text-align:center;color:var(--hts-text-3);font-size:13px">Aucune redirection</div>
	</div>
</div>

<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>

<!-- ═══ DS-aligned styles (S9 pixel-perfect JSX) ═══ -->
<style>
.hts-rd .vw{display:none}
.hts-rd .vw.active{display:block}
.hts-rd code{font-family:var(--hts-mono);font-size:11px;background:none;padding:0;border:none;color:inherit;border-radius:0}

/* ── Card rows ── */
.hts-rd .cd-row{padding:10px 20px;border-bottom:1px solid var(--hts-border-sub);display:flex;align-items:center;gap:10px;transition:opacity .25s,max-height .3s,padding .3s}
.hts-rd .cd-row:hover{background:var(--hts-surface)}
.hts-rd .cd-row:last-child{border-bottom:none}

/* ── Dot ── */
.hts-rd .dot{width:8px;height:8px;border-radius:50%;display:inline-block;flex-shrink:0}
.hts-rd .dot-g{background:var(--hts-success)}.hts-rd .dot-o{background:var(--hts-caution)}.hts-rd .dot-r{background:var(--hts-danger)}.hts-rd .dot-x{background:var(--hts-gray-200)}

/* ── Buttons (inline) ── */
.hts-rd .bn{padding:6px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid var(--hts-border);background:var(--hts-bg);color:var(--hts-text);transition:all .15s;white-space:nowrap;display:inline-flex;align-items:center;gap:5px;font-family:var(--hts-font)}
.hts-rd .bn:hover{border-color:var(--hts-geo);color:var(--hts-geo)}
.hts-rd .bn-grn{background:var(--hts-success);color:#fff;border-color:var(--hts-success)}
.hts-rd .bn-grn:hover{background:#059669;border-color:#059669;color:#fff}
.hts-rd .bn-s{padding:5px 10px;font-size:11px;color:var(--hts-text-2)}
.hts-rd .bn-a{padding:5px 10px;border-radius:var(--hts-radius-xs);border:none;background:var(--hts-success-bg);cursor:pointer;font-size:11px;font-weight:600;color:var(--hts-success);font-family:var(--hts-font)}
.hts-rd .bn-i{width:26px;height:26px;border-radius:6px;border:1px solid var(--hts-border-sub);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0}
.hts-rd .bn-i:hover{border-color:var(--hts-border);background:var(--hts-surface)}
.hts-rd .bn-d{color:var(--hts-danger);border-color:var(--hts-danger-bg)}
.hts-rd .bn-d:hover{background:var(--hts-danger-bg)}

/* ── Origin badges (JSX exact) ── */
.hts-rd .ob{font-size:9px;font-weight:700;padding:2px 7px;border-radius:4px;flex-shrink:0}
.hts-rd .ob-ia{background:var(--hts-geo-soft);color:var(--hts-geo)}
.hts-rd .ob-co{background:var(--hts-caution-bg);color:var(--hts-caution)}
.hts-rd .ob-sl{background:var(--hts-accent-bg);color:var(--hts-accent)}
.hts-rd .ob-mn{background:var(--hts-surface);color:var(--hts-text-3)}
.hts-rd .tb{font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;background:var(--hts-accent-bg);color:var(--hts-accent);flex-shrink:0}

/* ── URL styles ── */
.hts-rd .ar{display:inline-block;color:var(--hts-faint);margin:0 2px;font-size:12px}

/* ── Pattern alerts ── */
.hts-rd .pat{background:var(--hts-caution-bg);border-radius:14px;border:1px solid var(--hts-caution);padding:12px 20px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px}

/* ── 404 individual cards (JSX exact) ── */
.hts-rd .f-card{background:var(--hts-bg);border-radius:14px;border:1px solid var(--hts-border);box-shadow:0 1px 2px rgba(0,0,0,.04),0 1px 3px rgba(0,0,0,.03);margin-bottom:8px;overflow:visible;position:relative}
.hts-rd .f-card--ai{background:linear-gradient(135deg,var(--hts-geo-soft),var(--hts-bg));border-color:var(--hts-geo-border)}
.hts-rd .f-card .f-main{display:flex;align-items:center;gap:12px;padding:14px 20px}
.hts-rd .f-card .f-url{flex:1;min-width:0}
.hts-rd .f-card .f-url a{display:block;text-decoration:none;padding:0;margin:0;background:none;border:none;box-shadow:none}
.hts-rd .f-card .f-url code{font-size:12px;color:var(--hts-accent);font-family:var(--hts-mono);display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-decoration:none}
.hts-rd .f-card .f-sugg{font-size:11px;margin-top:3px;display:flex;align-items:center;gap:4px}
.hts-rd .f-card .f-sugg a{padding:0;margin:0;background:none;border:none;box-shadow:none}
.hts-rd .f-card .f-hits{font-size:12px;font-weight:700;color:var(--hts-success);font-family:var(--hts-mono);width:40px;text-align:right;flex-shrink:0}
.hts-rd .f-card .f-ago{font-size:10px;color:var(--hts-text-3);width:70px;text-align:right;flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hts-rd .f-card .f-acts{display:flex;gap:4px;flex-shrink:0;min-width:180px;justify-content:flex-end}
.hts-rd .f-card .f-inline{padding:14px 20px;border-top:1px solid var(--hts-border-sub);background:var(--hts-surface);display:flex;align-items:center;gap:12px;border-radius:0 0 14px 14px}

/* ── Rule cards (JSX exact) ── */
.hts-rd .r-card{background:var(--hts-bg);border-radius:14px;border:1px solid var(--hts-border);box-shadow:0 1px 2px rgba(0,0,0,.04),0 1px 3px rgba(0,0,0,.03);padding:14px 20px;margin-bottom:8px}
.hts-rd .r-card .r-main{display:flex;align-items:center;gap:12px}
.hts-rd .r-card .r-src{font-size:12px;color:var(--hts-text-3);font-family:var(--hts-mono);text-decoration:line-through;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:280px;display:inline-block}
.hts-rd .r-card .r-tgt{font-size:12px;color:var(--hts-accent);font-weight:600;font-family:var(--hts-mono);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:400px;display:inline-block}
.hts-rd .r-card .r-meta{display:flex;align-items:center;gap:8px;margin-top:3px}
.hts-rd .r-card a{padding:0;margin:0;background:none;border:none;box-shadow:none;text-decoration:none}

/* ── AI suggestion rows inside purple card ── */
.hts-rd .ai-row{padding:14px 18px;border-radius:12px;background:var(--hts-bg);border:1px solid var(--hts-geo-border);margin-bottom:8px;display:flex;align-items:center;gap:14px}
.hts-rd .ai-row:last-child{margin-bottom:0}
.hts-rd .ai-row a{padding:0;margin:0;background:none;border:none;box-shadow:none;text-decoration:none}

/* ── Overview cards (compact) ── */
.hts-rd .ov-card{background:var(--hts-bg);border-radius:14px;border:1px solid var(--hts-border);box-shadow:0 1px 2px rgba(0,0,0,.04),0 1px 3px rgba(0,0,0,.03);padding:0;margin-bottom:8px;overflow:visible;position:relative}
.hts-rd .ov-card .ov-main{display:flex;align-items:center;gap:12px;padding:12px 20px}
.hts-rd .ov-card a{padding:0;margin:0;background:none;border:none;box-shadow:none;text-decoration:none}
.hts-rd .ov-card .ov-inline{padding:14px 20px;border-top:1px solid var(--hts-border-sub);background:var(--hts-surface);display:flex;align-items:center;gap:12px;border-radius:0 0 14px 14px}

/* ── Transitions ── */
.hts-rd .f-card,.hts-rd .r-card,.hts-rd .ov-card{transition:opacity .25s,max-height .3s}

/* ── Inline form action buttons (JSX exact) ── */
.hts-rd .bn-apply{padding:9px 18px;border-radius:8px;border:none;background:var(--hts-success);color:#fff;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--hts-font);flex-shrink:0;white-space:nowrap}
.hts-rd .bn-apply:hover{background:#059669}
.hts-rd .bn-cancel{padding:9px 14px;border-radius:8px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);flex-shrink:0;white-space:nowrap}
.hts-rd .bn-cancel:hover{border-color:var(--hts-text-3)}

/* ── Autocomplete dropdown (JSX exact) ── */
.hts-rd .ac-wrap{position:relative;flex:1}
.hts-rd .ac-wrap input{width:100%;box-sizing:border-box}
.hts-rd .ac-drop{position:absolute;top:100%;left:0;right:0;margin-top:4px;background:var(--hts-bg);border-radius:10px;border:1px solid var(--hts-border);box-shadow:0 8px 32px rgba(0,0,0,.12);z-index:50;max-height:320px;overflow-y:auto;display:none}
.hts-rd .ac-drop::-webkit-scrollbar{width:6px}
.hts-rd .ac-drop::-webkit-scrollbar-track{background:transparent}
.hts-rd .ac-drop::-webkit-scrollbar-thumb{background:var(--hts-border);border-radius:3px}
.hts-rd .ac-drop.open{display:block}
.hts-rd .ac-item{width:100%;padding:10px 14px;border:none;border-bottom:1px solid var(--hts-border-sub);background:var(--hts-bg);cursor:pointer;font-family:var(--hts-font);text-align:left;display:block}
.hts-rd .ac-item:last-child{border-bottom:none}
.hts-rd .ac-item:hover{background:var(--hts-surface)}
.hts-rd .ac-item .ac-title{font-size:13px;font-weight:600;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hts-rd .ac-item .ac-url{font-size:11px;color:var(--hts-text-3);font-family:var(--hts-mono);margin-top:1px}

.hts-hidden{display:none!important}
.hts-redir-toast{position:fixed;bottom:20px;right:20px;padding:12px 20px;background:var(--hts-text);color:#fff;border-radius:10px;font-size:13px;font-weight:600;z-index:99999;opacity:0;transform:translateY(10px);transition:all .3s;pointer-events:none;font-family:var(--hts-font);max-width:360px}
.hts-redir-toast.show{opacity:1;transform:translateY(0)}.hts-redir-toast.success{background:var(--hts-success)}.hts-redir-toast.error{background:var(--hts-danger)}
</style>

<script>
(function(){
var R = {
	nonce: '<?php echo esc_js( $nonce ); ?>',
	ajax: '<?php echo esc_js( $ajax ); ?>',
	data: null,
	offset: 0
};
var canRedirectAI = <?php echo $_can_redirect_ai ? 'true' : 'false'; ?>;
var upgradeUrl = '<?php echo esc_js( rtrim( get_option( "hts_api_base_url", "https://app.hacktheseo.com" ), "/" ) . "/user/pricing/plans" ); ?>';

/* ═══ Toast + Modal (Phase 6.29-6.30 — replaces native alert/confirm) ═══ */
function _toast(msg,type){var t=document.getElementById('hts-redir-toast');if(!t){t=document.createElement('div');t.id='hts-redir-toast';t.className='hts-redir-toast';document.body.appendChild(t)}t.className='hts-redir-toast'+(type?' '+type:'')+' show';t.textContent=msg;clearTimeout(t._tm);t._tm=setTimeout(function(){t.className='hts-redir-toast'},3000)}
function _confirm(title,msg,okLabel,cls){return new Promise(function(resolve){var ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99998;display:flex;align-items:center;justify-content:center';var m=document.createElement('div');m.style.cssText='background:var(--hts-bg,#fff);border-radius:14px;padding:28px 32px;max-width:420px;width:90%;box-shadow:0 8px 30px rgba(0,0,0,.15);font-family:var(--hts-font)';m.innerHTML='<div style="font-size:16px;font-weight:700;color:var(--hts-text,#1a1f36);margin-bottom:8px">'+esc(title)+'</div><div style="font-size:13px;color:var(--hts-text-2,#64748b);margin-bottom:20px;line-height:1.5">'+esc(msg)+'</div><div style="display:flex;gap:8px;justify-content:flex-end"><button class="hts-m-c" style="padding:8px 16px;border-radius:8px;border:1px solid var(--hts-border,#e5e7eb);background:var(--hts-bg,#fff);font-size:13px;font-weight:600;cursor:pointer;color:var(--hts-text-2)">Annuler</button><button class="hts-m-o" style="padding:8px 16px;border-radius:8px;border:none;background:'+(cls==='danger'?'var(--hts-danger)':'var(--hts-accent)')+';color:#fff;font-size:13px;font-weight:700;cursor:pointer">'+esc(okLabel||'Confirmer')+'</button></div>';ov.appendChild(m);document.body.appendChild(ov);function close(v){document.body.removeChild(ov);resolve(v)}ov.addEventListener('click',function(e){if(e.target===ov)close(false)});m.querySelector('.hts-m-c').addEventListener('click',function(){close(false)});m.querySelector('.hts-m-o').addEventListener('click',function(){close(true)})})}

/* ═══ SVG snippets ═══ */
var SVG_X = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--hts-faint)" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
var SVG_X_DANGER = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--hts-danger)" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
var SVG_EXT = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--hts-text-3)" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>';
var SVG_DEL = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--hts-danger)" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>';
var SVG_EDIT = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--hts-text-3)" stroke-width="1.7"><path d="M4 20h16M4 20V16L14.586 5.414a2 2 0 012.828 0L19.586 7.586a2 2 0 010 2.828L9 20"/></svg>';
var SVG_ZAP = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--hts-caution)" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';
var SVG_ZAP_GEO = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--hts-geo)" stroke-width="1.7"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';

/* ═══ NAV ═══ */
window.htsRN = function(btn) {
	var view = btn.getAttribute('data-tab') || btn.getAttribute('data-view');
	if (!view) return;
	document.querySelectorAll('.hts-ds-tabs__item').forEach(function(t){t.classList.remove('hts-ds-tabs__item--active')});
	document.querySelectorAll('.hts-rd .vw').forEach(function(v){v.classList.remove('active')});
	btn.classList.add('hts-ds-tabs__item--active');
	var el = document.getElementById('vw-' + view);
	if (el) el.classList.add('active');
	/* Update badge colors: active tab = accent, inactive = text3 */
	document.querySelectorAll('.hts-ds-tabs__item').forEach(function(t){
		var badge = t.querySelector('.hts-tab-badge-ds');
		if (badge) badge.style.background = t.classList.contains('hts-ds-tabs__item--active') ? 'var(--hts-accent)' : 'var(--hts-text-3)';
	});
};
document.querySelectorAll('.hts-ds-tabs__item').forEach(function(t) {
	t.addEventListener('click', function(e) {
		e.preventDefault();
		htsRN(this);
	});
});

/* ═══ Add form toggle ═══ */
document.getElementById('btn-add-toggle').addEventListener('click', function(){
	var f = document.getElementById('add-form');
	var isHidden = f.style.display === 'none';
	f.style.display = isHidden ? 'block' : 'none';
	if (isHidden) {
		window._editingRuleId = 0;
		document.getElementById('a-src').value = '';
		document.getElementById('a-tgt').value = '';
		document.getElementById('a-msg').textContent = '';
		var btn=document.getElementById('a-submit');if(btn)btn.textContent='Créer';
	}
});

/* ═══ LOAD ═══ */
var _initDone = false;
function load(append) {
	if (!append) R.offset = 0;
	var fd = new FormData();
	fd.append('action','hts_redirect_get_data');
	fd.append('nonce',R.nonce);
	fd.append('offset',R.offset||0);
	var showBots=document.getElementById('f-show-bots');
	fd.append('hide_bots',showBots&&showBots.checked?'0':'1');
	fetch(R.ajax,{method:'POST',body:fd})
	.then(function(r){return r.json()})
	.then(function(j){
		if (!j.success) return;
		var d = j.data;
		R.data = d;
		document.getElementById('hts-ld').style.display = 'none';

		/* ── Update hero ── */
		var stats = d.stats || {};
		var heroSub = document.getElementById('hero-sub');
		var heroClics = document.getElementById('hero-clics');
		var hero404 = document.getElementById('hero-404');
		var heroLost = document.getElementById('hero-lost');
		var activeCount = (d.rules||[]).filter(function(r){return r.enabled=='1'||r.active}).length;
		var aiCount = (d.top_404s||[]).filter(function(f){return f.suggested_target&&parseFloat(f.suggested_score)>=0.5}).length;
		if (heroSub) heroSub.textContent = activeCount + ' redirections actives · ' + (stats.total_pending||stats.total_404||d.total_404s||0) + ' erreurs 404 · ' + aiCount + ' suggestions IA';
		if (heroClics) heroClics.textContent = fmtN(stats.gsc_saved_clicks||d.total_clicks_saved||0);
		var t404 = stats.total_pending||stats.total_404||d.total_404s||0;
		if (hero404) hero404.textContent = t404;
		if (heroLost) {
			if (stats.gsc_lost_clicks > 0) {
				heroLost.style.display = 'block';
				heroLost.textContent = fmtN(stats.gsc_lost_clicks) + ' clic' + (stats.gsc_lost_clicks > 1 ? 's' : '') + ' perdu' + (stats.gsc_lost_clicks > 1 ? 's' : '');
			} else {
				heroLost.style.display = 'none';
			}
		}
		var hero404Box = document.getElementById('hero-404-box');
		if (hero404Box) hero404Box.style.background = t404 > 0 ? 'rgba(239,68,68,.1)' : 'rgba(255,255,255,.06)';

		/* ── Update tab badges ── */
		document.querySelectorAll('.hts-ds-tabs__item').forEach(function(t) {
			var tabId = t.getAttribute('data-tab');
			var existing = t.querySelector('.hts-tab-badge-ds');
			if (existing) existing.remove();
			if (tabId === '404s' && t404 > 0) {
				var badge = document.createElement('span');
				badge.className = 'hts-tab-badge-ds';
				badge.style.cssText = 'min-width:18px;height:18px;border-radius:9px;padding:0 5px;color:#fff;font-size:10px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;margin-left:4px';
				badge.style.background = t.classList.contains('hts-ds-tabs__item--active') ? 'var(--hts-accent)' : 'var(--hts-text-3)';
				badge.textContent = t404;
				t.appendChild(badge);
			}
			if (tabId === 'rules' && (d.rules||[]).length > 0) {
				var badge2 = document.createElement('span');
				badge2.className = 'hts-tab-badge-ds';
				badge2.style.cssText = 'min-width:18px;height:18px;border-radius:9px;padding:0 5px;color:#fff;font-size:10px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;margin-left:4px';
				badge2.style.background = t.classList.contains('hts-ds-tabs__item--active') ? 'var(--hts-accent)' : 'var(--hts-text-3)';
				badge2.textContent = (d.rules||[]).length;
				t.appendChild(badge2);
			}
		});

		renderHome(d);
		render404s(d);
		renderRules(d);
		_acBind(); /* Bind autocomplete on all inputs (static + dynamic) */
		if (!_initDone) {
			_initDone = true;
			document.getElementById('r-search').addEventListener('input', _filterRules);
			document.getElementById('f-search').addEventListener('input', _filter404s);
			var _showBots=document.getElementById('f-show-bots');
			if(_showBots)_showBots.addEventListener('change',function(){load()});
		}
	})
	.catch(function(e){
		document.getElementById('hts-ld').textContent = 'Erreur de chargement : ' + e.message;
		document.getElementById('hts-ld').style.color = 'var(--hts-danger)';
	});
}

/* ═══ RENDER HOME ═══ */
function renderHome(d) {
	var stats = d.stats || {};

	/* Health issues */
	var hb=document.getElementById('health-box');hb.innerHTML='';
	(d.health||[]).forEach(function(h){
		var sevColor=h.severity==='critical'||h.severity==='error'?'var(--hts-danger)':'var(--hts-caution)';
		var sevIcon=h.severity==='critical'||h.severity==='error'
			?'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="'+sevColor+'" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
			:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="'+sevColor+'" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>';
		var cardHtml='<div class="hts-ds-card" style="margin-bottom:14px;border-color:'+sevColor+'">'
			+'<div style="padding:14px 20px;display:flex;align-items:center;gap:10px;border-bottom:1px solid var(--hts-border-sub)">'+sevIcon
			+'<span style="font-size:13px;font-weight:700;color:'+sevColor+'">'+esc(h.label||h.desc)+'</span></div>'
			+'<div style="padding:0">';
		if((h.type==='chain'||h.type==='loop')&&h.items&&h.items.length){
			(h.items||[]).forEach(function(c){
				cardHtml+='<div class="cd-row" style="gap:8px">'
					+'<span class="dot dot-r"></span>'
					+'<code style="flex:1;font-size:11px;color:var(--hts-text)">'+esc(c.chain_start||c.chain||c.loop||'')+'</code>'
					+'<span class="ar">&rarr;</span><code style="font-size:11px;color:var(--hts-caution)">'+esc(c.chain_mid||'')+'</code>'
					+'<span class="ar">&rarr;</span><code style="font-size:11px;color:var(--hts-danger)">'+esc(c.chain_end||'')+'</code>'
					+'<button class="bn bn-s" onclick="_delRule('+(c.chain_start_id||c.id)+')">Corriger</button>'
					+'</div>';
			});
		}
		if((h.type==='broken'||h.type==='stale')&&h.items&&h.items.length){
			(h.items||[]).forEach(function(s){
				cardHtml+='<div class="cd-row" style="gap:8px">'
					+'<span class="dot dot-o"></span>'
					+'<div style="flex:1;min-width:0"><code style="font-size:11px;color:var(--hts-text-3);text-decoration:line-through">'+esc(s.source_url||s.source)+'</code><span class="ar">&rarr;</span><code style="font-size:11px;color:var(--hts-danger)">'+esc(s.target_url||s.target)+' ('+(s.status||'supprimé')+')</code></div>'
					+'<button class="bn bn-s bn-d" onclick="_delRule('+s.id+')">Supprimer</button>'
					+'</div>';
			});
		}
		if(h.type==='spike'){
			// Small inline notice, not a full card — too heavy at top
			cardHtml='<div style="padding:8px 16px;border-radius:8px;background:var(--hts-caution-bg);margin-bottom:10px;font-size:11px;color:var(--hts-caution);display:flex;align-items:center;gap:6px">'
				+sevIcon+'<span>'+esc(h.label)+'</span></div>';
			hb.innerHTML+=cardHtml;
			return; // skip the full card layout
		}
		cardHtml+='</div></div>';
		hb.innerHTML+=cardHtml;
	});

	/* AI suggestions (purple gradient card — JSX exact) */
	var ac=document.getElementById('ai-card'),al=document.getElementById('ai-list');
	var withS=(d.top_404s||[]).filter(function(f){return f.suggested_target&&parseFloat(f.suggested_score)>=0.5});
	if(withS.length){
		ac.style.display='block';
		document.getElementById('ai-title').textContent='Suggestions IA';
		document.getElementById('ai-count').textContent=withS.length+' redirections proposées';
		var fiable=withS.filter(function(f){return parseFloat(f.suggested_score)>=0.75}).length;
		var bulkBtn=document.getElementById('ai-bulk'),bulkN=document.getElementById('ai-bulk-n');
		if(fiable>0){bulkBtn.style.display='inline-flex';bulkN.textContent=fiable;}else bulkBtn.style.display='none';
		var h='';
		withS.forEach(function(f,idx){
			var sc=Math.round(parseFloat(f.suggested_score)*100);
			var scCol=sc>=75?'var(--hts-success)':sc>=50?'var(--hts-caution)':'var(--hts-danger)';
			var sugUrl=f.suggested_url||f.suggested_target;
			var sugLink=f.suggested_url||('/'+f.suggested_target+'/');
			var hidden=idx>=3?' style="display:none" class="ai-row ai-extra"':' class="ai-row"';
			h+='<div'+hidden+' id="sr-'+f.id+'">'
				+'<span class="dot dot-r"></span>'
				+'<div style="flex:1;min-width:0">'
				+'<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">'
				+'<a href="'+escA(f.url)+'" target="_blank" rel="noopener" style="text-decoration:none"><code style="font-size:12px;color:var(--hts-danger);font-family:var(--hts-mono)">'+esc(f.url)+'</code></a>'
				+'<span style="color:var(--hts-text-3);font-size:11px">→</span>'
				+'<a href="'+escA(sugLink)+'" target="_blank" rel="noopener" style="text-decoration:none"><code style="font-size:12px;color:var(--hts-success);font-weight:600;font-family:var(--hts-mono)">'+esc(f.suggested_title||sugUrl)+'</code></a>'
				+'</div>'
				+'<div style="display:flex;align-items:center;gap:8px;margin-top:4px">'
				+'<span style="font-size:11px;color:var(--hts-text-3)">'+fmtN(f.hit_count||f.hits||0)+' visites perdues</span>'
				+'<span style="font-size:11px;font-weight:700;color:'+scCol+'" title="Score de confiance IA">'+sc+'%</span>'
				+'</div></div>'
				+'<div style="display:flex;gap:6px;flex-shrink:0">'
				+(canRedirectAI?'<button style="padding:6px 14px;border-radius:10px;border:none;background:var(--hts-success);color:#fff;font-size:11px;font-weight:600;cursor:pointer;font-family:var(--hts-font)" onclick="f404(\'accept_suggestion\','+f.id+',{},function(){load()})">Valider</button>':'<a href="'+upgradeUrl+'" target="_blank" style="padding:6px 14px;border-radius:10px;border:none;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;font-size:11px;font-weight:700;text-decoration:none;display:inline-block">Pro</a>')
				+'<button style="padding:6px 14px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-3);cursor:pointer;font-family:var(--hts-font)" onclick="f404(\'ignore\','+f.id+',{},function(){load()})">Ignorer</button>'
				+'</div></div>';
		});
		if(withS.length>3){
			h+='<button id="ai-show-more" onclick="_toggleAIMore()" style="width:100%;padding:10px;border:none;background:none;color:var(--hts-geo);font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);text-align:center">Voir les '+(withS.length-3)+' autres suggestions</button>';
		}
		al.innerHTML=h;
	}else{ac.style.display='none';}

	/* Patterns — max 2 visible, skip if no samples or count < 3 */
	var pb=document.getElementById('pat-box');pb.innerHTML='';
	var patShown=0;
	(d.patterns||[]).forEach(function(p){
		var samples=(p.samples||[]).filter(function(u){return u&&u.length>1&&u.length<120});
		if(!samples.length||p.count<3)return;
		if(patShown>=2)return;
		patShown++;
		var html='<div class="pat">'
			+'<div style="flex:1">'
			+'<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">'+SVG_ZAP
			+'<span style="font-size:12px;font-weight:700;color:var(--hts-text)">'+esc(p.label||p.pattern)+'</span>'
			+'<span style="font-size:11px;color:var(--hts-text-3)">'+fmtN(p.count)+' URLs</span>'
			+'</div>'
			+'<div style="font-size:11px;color:var(--hts-text-3);margin-bottom:6px">'+esc(p.description||'Motif récurrent détecté')+'</div>'
			+'<details style="font-size:11px;color:var(--hts-text-3)"><summary style="cursor:pointer">Exemples</summary><div style="margin-top:4px">';
		samples.slice(0,3).forEach(function(url){
			html+='<code style="display:block;font-size:10px;padding:2px 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(url)+'</code>';
		});
		html+='</div></details></div>';
		if(p.target){
			html+='<button class="bn bn-grn bn-s" onclick="_applyPatSafe(\''+escA(p.pattern)+'\',\''+escA(p.target)+'\',\''+escA(p.label||p.pattern)+'\','+fmtN(p.count)+')">Appliquer le pattern</button>';
		}
		html+='</div>';
		pb.innerHTML+=html;
	});

	/* Recent 404s — Overview (JSX: top 3 with SectionLabel) */
	var ov404Sec=document.getElementById('ov-404-section'),ov404List=document.getElementById('ov-404-list');
	var all404=(d.top_404s||[]);
	if(all404.length){
		ov404Sec.style.display='block';
		var h2='';
		all404.slice(0,3).forEach(function(f,i){
			var sc=f.suggested_target?Math.round(parseFloat(f.suggested_score)*100):0;
			var scCol=sc>=75?'var(--hts-success)':sc>=50?'var(--hts-caution)':'var(--hts-danger)';
			var sugUrl=f.suggested_url||f.suggested_target;
			var sugLink=f.suggested_url||('/'+f.suggested_target+'/');
			h2+='<div class="ov-card" id="ovf-'+f.id+'" style="z-index:'+(window._ovRedirecting===i?50:1)+'">'
				+'<div class="ov-main">'
				+'<span class="dot '+(sc>=50?'dot-o':'dot-r')+'"></span>'
				+'<div style="flex:1;min-width:0">'
				+'<a href="'+escA(f.url)+'" target="_blank" rel="noopener" style="text-decoration:none" onclick="event.stopPropagation()"><code style="font-size:12px;color:var(--hts-accent);font-family:var(--hts-mono);display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(f.url)+'</code></a>';
			if(f.suggested_target){
				h2+='<div style="display:flex;align-items:center;gap:4px;margin-top:2px">'
					+'<span style="font-size:11px;color:'+(sc>=50?'var(--hts-success)':'var(--hts-caution)')+'">Page trouvée : <a href="'+escA(sugLink)+'" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline" onclick="event.stopPropagation()">'+esc(f.suggested_title||sugUrl)+'</a></span>'
					+'<span style="font-size:10px;font-weight:700;color:'+scCol+'" title="Score de confiance">'+sc+'%</span>'
					+'</div>';
			}
			h2+='</div>'
				+'<span style="font-size:12px;font-weight:700;color:var(--hts-success);font-family:var(--hts-mono);width:40px;text-align:right;flex-shrink:0">'+fmtN(f.hit_count||f.hits||0)+'</span>'
				+'<span style="font-size:10px;color:var(--hts-text-3);width:70px;text-align:right;flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+ago(f.last_hit)+'</span>'
				+'<div style="display:flex;gap:4px;flex-shrink:0;justify-content:flex-end">';
			if(sc>=50){if(canRedirectAI)h2+='<button class="bn-a" onclick="f404(\'accept_suggestion\','+f.id+',{},function(){load()})">Valider</button>';else h2+='<a href="'+upgradeUrl+'" target="_blank" class="bn-a" style="background:linear-gradient(135deg,#f59e0b,#f97316);border-color:#f59e0b;text-decoration:none">Pro</a>';}
			h2+='<button class="bn bn-s" onclick="_ovRedirect('+i+','+f.id+',\''+escA(f.url)+'\')">Rediriger</button>'
				+'<a href="'+escA(f.url)+'" target="_blank" rel="noopener" class="bn-i">'+SVG_EXT+'</a>'
				+'<button class="bn-i" onclick="f404(\'ignore\','+f.id+',{},function(){load()})">'+SVG_X+'</button>'
				+'</div></div>';
			/* Inline redirect form */
			h2+='<div class="ov-inline" id="ovi-'+i+'" style="display:none">'
				+'<span style="font-size:12px;font-weight:600;color:var(--hts-text-3);flex-shrink:0">Rediriger vers :</span>'
				+'<div class="ac-wrap">'
				+'<input id="ovt-'+f.id+'" class="hts-ac-input" placeholder="Chercher une page ou coller une URL" style="padding:9px 14px;border-radius:8px;border:1.5px solid var(--hts-accent);font-size:13px;font-family:var(--hts-font);color:var(--hts-text);background:var(--hts-bg);outline:none" autocomplete="off">'
				+'<div class="ac-drop" id="acd-ovt-'+f.id+'"></div>'
				+'</div>'
				+'<button class="bn-apply" onclick="_ovApply('+f.id+')">Appliquer</button>'
				+'<button class="bn-cancel" onclick="_ovCloseRedirect()">Annuler</button>'
				+'</div>';
			h2+='</div>';
		});
		ov404List.innerHTML=h2;
	}else{ov404Sec.style.display='none';}

	/* Recent redirections — Overview (JSX: top 3 with SectionLabel) */
	var ovRulesSec=document.getElementById('ov-rules-section'),ovRulesList=document.getElementById('ov-rules-list');
	var rules=d.rules||[];
	if(rules.length){
		ovRulesSec.style.display='block';
		var h3='';
		rules.slice(0,3).forEach(function(r){
			var obCls=r.origin==='ai_auto'||r.origin==='ai_suggested'?'ob-ia':r.origin==='slug_change'?'ob-sl':r.origin==='cocon'?'ob-co':'ob-mn';
			var obLbl=r.origin==='ai_auto'?'IA auto':r.origin==='ai_suggested'?'IA':r.origin==='slug_change'?'Slug':r.origin==='cocon'?'Cocon':'Manuel';
			var isActive=r.enabled=='1'||r.active;
			var isRegex=r.is_regex=='1'||r.is_regex===1;
			var srcD=r.source_url||r.source,tgtD=r.target_url||r.target;
			if(isRegex){
				srcD=srcD.replace(/\(\.\+\)/g,'*').replace(/^\//,'').replace(/\/$/,'');
				if(srcD)srcD='/'+srcD+'/';
				tgtD=tgtD.replace(/\/\$\d/g,'').replace(/^\//,'/')||'page correspondante';
				if(tgtD==='/')tgtD='page correspondante';
			}
			h3+='<div class="r-card" style="padding:12px 20px"><div class="r-main">'
				+'<span class="dot '+(isActive?'dot-g':'dot-o')+'"></span>'
				+'<div style="flex:1;min-width:0">'
				+'<div style="display:flex;align-items:center;gap:6px">'
				+'<span class="r-src" style="font-size:11px">'+esc(srcD)+'</span>'
				+'<span style="color:var(--hts-faint);font-size:11px">→</span>'
				+'<span class="r-tgt" style="font-size:11px">'+esc(tgtD)+'</span>'
				+'</div>'
				+'<div class="r-meta">'
				+'<span class="tb">'+(r.redirect_type||r.type)+'</span>'
				+(isRegex?'<span class="ob" style="background:var(--hts-caution-bg);color:var(--hts-caution)">Regex</span>':'')
				+'<span class="ob '+obCls+'">'+obLbl+'</span>'
				+'<span style="font-family:var(--hts-mono);font-size:10px;color:var(--hts-text-3)">'+fmtN(r.hit_count||r.hits||0)+' hits</span>'
				+'</div></div></div></div>';
		});
		ovRulesList.innerHTML=h3;
	}else{ovRulesSec.style.display='none';}
}

/* ═══ RENDER 404s ═══ */
function render404s(d) {
	var list=document.getElementById('f-list'),empty=document.getElementById('f-empty'),countEl=document.getElementById('f-count');
	var items=d.top_404s||[];
	if(countEl)countEl.textContent=items.length+' erreur'+(items.length!==1?'s':'');
	if(!items.length){list.innerHTML='';empty.classList.remove('hts-hidden');return;}
	empty.classList.add('hts-hidden');
	var h='';
	items.forEach(function(f,i){
		var sc=f.suggested_target?Math.round(parseFloat(f.suggested_score)*100):0;
		var scCol=sc>=75?'var(--hts-success)':sc>=50?'var(--hts-caution)':'var(--hts-danger)';
		var sugUrl=f.suggested_url||f.suggested_target;
		var isAI=sc>=50;
		var isGeo=!!f.is_geo_bot;
		h+='<div class="f-card'+(isAI?' f-card--ai':'')+(isGeo?' f-card--geo':'')+'" id="fr-'+f.id+'" style="z-index:'+(window._f404Redirecting===i?50:1)+(isGeo?';border-left:3px solid var(--hts-caution)':'')+'">'
			+'<div class="f-main">'
			+'<span class="dot '+(isGeo?'dot-o':isAI?'dot-o':'dot-r')+'"></span>'
			+'<div class="f-url">'
			+'<a href="'+escA(f.url)+'" target="_blank" rel="noopener" style="text-decoration:none" onclick="event.stopPropagation()"><code>'+esc(f.url)+'</code></a>';
		if(isGeo){
			h+='<div style="display:inline-flex;align-items:center;gap:4px;margin-left:8px;padding:2px 8px;border-radius:6px;background:rgba(245,158,11,.12);color:#d97706;font-size:10px;font-weight:700;vertical-align:middle" title="Cette URL est recherch\u00e9e par les IA (GPTbot, Perplexity...). Redirigez vers une page pertinente pour \u00eatre cit\u00e9.">'+SVG_ZAP_GEO+' Opportunit\u00e9 GEO</div>';
		}
		if(f.suggested_target){
			var sugLink=f.suggested_url||('/'+f.suggested_target+'/');
			h+='<div class="f-sugg" style="color:'+(sc>=50?'var(--hts-success)':'var(--hts-caution)')+'">';
			if(isAI) h+=SVG_ZAP_GEO+' ';
			h+='Page trouvée : <a href="'+escA(sugLink)+'" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline" onclick="event.stopPropagation()">'+esc(f.suggested_title||sugUrl)+'</a>'
				+' <span style="font-size:10px;font-weight:700;color:'+scCol+'" title="Score de confiance de l\u0027IA">'+sc+'%</span>'
				+'</div>';
		}
		h+='</div>'
			+'<div class="f-hits">'+fmtN(f.hit_count||f.hits||0)+'</div>'
			+'<div class="f-ago">'+ago(f.last_hit)+'</div>'
			+'<div class="f-acts">';
		if(isAI){if(canRedirectAI)h+='<button class="bn-a" onclick="f404(\'accept_suggestion\','+f.id+',{},function(){load()})">Valider</button>';else h+='<a href="'+upgradeUrl+'" target="_blank" class="bn-a" style="background:linear-gradient(135deg,#f59e0b,#f97316);border-color:#f59e0b;text-decoration:none">Pro</a>';}
		h+='<button class="bn bn-s" onclick="_f404Redirect('+i+','+f.id+',\''+escA(f.url)+'\')">Rediriger</button>'
			+'<a href="'+escA(f.url)+'" target="_blank" rel="noopener" class="bn-i">'+SVG_EXT+'</a>'
			+'<button class="bn-i" onclick="f404(\'ignore\','+f.id+',{},function(){load()})">'+SVG_X+'</button>'
			+'</div></div>';
		/* Inline redirect form (replaces prompt) */
		h+='<div class="f-inline" id="fi-'+i+'" style="display:none">'
			+'<span style="font-size:12px;font-weight:600;color:var(--hts-text-3);flex-shrink:0">Rediriger vers :</span>'
			+'<div class="ac-wrap">'
			+'<input id="ft-'+f.id+'" class="hts-ac-input" placeholder="Chercher une page ou coller une URL (ex: /fr/)" style="padding:9px 14px;border-radius:8px;border:1.5px solid var(--hts-accent);font-size:13px;font-family:var(--hts-font);color:var(--hts-text);background:var(--hts-bg);outline:none" autocomplete="off">'
			+'<div class="ac-drop" id="acd-ft-'+f.id+'"></div>'
			+'</div>'
			+'<button class="bn-apply" onclick="_f404Apply('+f.id+')">Appliquer</button>'
			+'<button class="bn-cancel" onclick="_f404CloseRedirect()">Annuler</button>'
			+'</div>';
		h+='</div>';
	});
	list.innerHTML=h;
	/* Pagination — show "Charger plus" if more 404s exist */
	var loadMore=document.getElementById('f-load-more');
	if(!loadMore){
		loadMore=document.createElement('div');
		loadMore.id='f-load-more';
		loadMore.style.cssText='text-align:center;padding:16px 0';
		list.parentNode.insertBefore(loadMore,list.nextSibling);
	}
	var total=R.data&&R.data.stats?R.data.stats.total_pending||0:0;
	var shown=items.length;
	if(total>shown){
		loadMore.innerHTML='<button onclick="_loadMore404s()" style="padding:8px 24px;border-radius:8px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Charger plus ('+shown+' / '+total+')</button>';
		loadMore.style.display='block';
	}else{
		loadMore.style.display='none';
	}
}

/* ═══ RENDER RULES ═══ */
function renderRules(d) {
	var list=document.getElementById('r-list'),empty=document.getElementById('r-empty');
	var rules=d.rules||[];
	if(!rules.length){list.innerHTML='';empty.classList.remove('hts-hidden');return;}
	empty.classList.add('hts-hidden');
	var h='';
	rules.forEach(function(r){
		var obCls=r.origin==='ai_auto'||r.origin==='ai_suggested'?'ob-ia':r.origin==='slug_change'?'ob-sl':r.origin==='cocon'?'ob-co':'ob-mn';
		var obLbl=r.origin==='ai_auto'?'IA auto':r.origin==='ai_suggested'?'IA':r.origin==='slug_change'?'Slug':r.origin==='cocon'?'Cocon':'Manuel';
		var isActive=r.enabled=='1'||r.active;
		var isRegex=r.is_regex=='1'||r.is_regex===1;
		var srcDisplay=r.source_url||r.source;
		var tgtDisplay=r.target_url||r.target;
		// Human-readable for regex patterns
		if(isRegex){
			srcDisplay=srcDisplay.replace(/\(\.\+\)/g,'*').replace(/\(\[^\/\]\+\)/g,'*').replace(/^\//,'').replace(/\/$/,'');
			if(srcDisplay)srcDisplay='URLs contenant /'+srcDisplay+'/';
			tgtDisplay=tgtDisplay.replace(/\/\$\d/g,'').replace(/^\//,'/')||'même chemin sans préfixe';
			if(tgtDisplay==='/')tgtDisplay='page correspondante';
		}
		var srcTag=isRegex?'<span class="r-src">'+esc(srcDisplay)+'</span>':'<a href="'+escA(r.source_url||r.source)+'" target="_blank" rel="noopener" class="r-src">'+esc(srcDisplay)+'</a>';
		var tgtTag=isRegex?'<span class="r-tgt">'+esc(tgtDisplay)+'</span>':'<a href="'+escA(r.target_url||r.target)+'" target="_blank" rel="noopener" class="r-tgt">'+esc(tgtDisplay)+'</a>';
		h+='<div class="r-card" style="opacity:'+(isActive?'1':'0.5')+'">'
			+'<div class="r-main">'
			+'<span class="dot '+(isActive?'dot-g':'dot-o')+'"></span>'
			+'<div style="flex:1;min-width:0">'
			+'<div style="display:flex;align-items:center;gap:6px">'
			+srcTag
			+'<span style="color:var(--hts-faint);font-size:11px">→</span>'
			+tgtTag
			+'</div>'
			+'<div class="r-meta">'
			+'<span class="tb">'+(r.redirect_type||r.type)+'</span>'
			+(isRegex?'<span class="ob" style="background:var(--hts-caution-bg);color:var(--hts-caution)">Regex</span>':'')
			+'<span class="ob '+obCls+'">'+obLbl+'</span>'
			+'<span style="font-family:var(--hts-mono);font-size:10px;color:var(--hts-text-3)">'+fmtN(r.hit_count||r.hits||0)+' hits</span>'
			+'</div></div>'
			+'<div style="display:flex;gap:4px;flex-shrink:0">'
			+'<button class="bn-i" style="width:28px;height:28px;border:1px solid var(--hts-border)" onclick="_editRule('+r.id+',\''+escA(r.source_url||r.source)+'\',\''+escA(r.target_url||r.target)+'\')" title="Modifier">'+SVG_EDIT+'</button>'
			+'<button class="bn-i" style="width:28px;height:28px;border:1px solid var(--hts-danger-bg)" onclick="_delRule('+r.id+')">'+SVG_X_DANGER+'</button>'
			+'</div></div></div>';
	});
	list.innerHTML=h;
}

/* ═══ 404 AJAX ═══ */
window.f404=function(sub,id,extra,cb){
	var fd=new FormData();fd.append('action','hts_404_action');fd.append('nonce',R.nonce);fd.append('sub_action',sub);if(id)fd.append('id',id);
	if(extra)Object.keys(extra).forEach(function(k){fd.append(k,extra[k])});
	fetch(R.ajax,{method:'POST',body:fd})
	.then(function(r){
		if(!r.ok)throw new Error('HTTP '+r.status);
		return r.text();
	})
	.then(function(txt){
		try{var j=JSON.parse(txt)}catch(e){throw new Error('Réponse invalide: '+txt.substring(0,100))}
		if(!j.success&&j.data){_toast(typeof j.data==='string'?j.data:'Erreur serveur','error');return}
		if(cb)cb(j);
	})
	.catch(function(e){_toast('Erreur : '+e.message,'error')});
};

/* ═══ Inline redirect forms (replace browser prompt) ═══ */
window._f404Redirecting = null;
window._f404Redirect = function(idx, id, url) {
	_f404CloseRedirect();
	window._f404Redirecting = idx;
	var el = document.getElementById('fi-'+idx);
	if (el) { el.style.display = 'flex'; el.parentNode.style.zIndex = 50; }
};
window._f404CloseRedirect = function() {
	document.querySelectorAll('.f-card .f-inline').forEach(function(el){ el.style.display = 'none'; el.parentNode.style.zIndex = 1; });
	window._f404Redirecting = null;
};
window._f404Apply = function(id) {
	var inp = document.getElementById('ft-'+id);
	if (!inp || !inp.value.trim()) return;
	f404('redirect', id, {target: inp.value.trim()}, function(){ _f404CloseRedirect(); load(); });
};

window._ovRedirecting = null;
window._ovRedirect = function(idx, id, url) {
	_ovCloseRedirect();
	window._ovRedirecting = idx;
	var el = document.getElementById('ovi-'+idx);
	if (el) { el.style.display = 'flex'; el.parentNode.style.zIndex = 50; }
};
window._ovCloseRedirect = function() {
	document.querySelectorAll('.ov-card .ov-inline').forEach(function(el){ el.style.display = 'none'; el.parentNode.style.zIndex = 1; });
	window._ovRedirecting = null;
};
window._ovApply = function(id) {
	var inp = document.getElementById('ovt-'+id);
	if (!inp || !inp.value.trim()) return;
	f404('redirect', id, {target: inp.value.trim()}, function(){ _ovCloseRedirect(); load(); });
};

/* ═══ 404 ANALYSIS — unified flow ═══ */
window._runAnalysis=function(btn){
	btn.disabled=true;
	var prog=document.getElementById('analysis-progress');
	var bar=document.getElementById('analysis-bar');
	var label=document.getElementById('analysis-label');
	prog.style.display='block';
	bar.style.width='0%';
	var results={clean:0,gsc:0,ai_scanned:0,ai_found:0};

	// Step 1/3: Clean false positives
	label.textContent='Nettoyage des faux positifs...';bar.style.width='10%';
	f404('cleanup_false_positives',0,{},function(j1){
		results.clean=j1.data&&j1.data.total||0;
		bar.style.width='33%';

		// Step 2/3: Import GSC (skip if not connected — won't error, backend returns error message)
		label.textContent='Import Google Search Console...';
		f404('import_gsc_404s',0,{},function(j2){
			if(j2.success)results.gsc=j2.data&&j2.data.imported||0;
			// GSC error = normal if not connected, continue silently
			bar.style.width='66%';

			// Step 3/3: AI scan
			label.textContent='Analyse IA des erreurs 404...';
			f404('bulk_rescan_ai',0,{},function(j3){
				results.ai_scanned=j3.data&&j3.data.scanned||0;
				results.ai_found=j3.data&&j3.data.found||0;
				bar.style.width='100%';
				label.textContent='Terminé !';

				// Summary
				setTimeout(function(){
					prog.style.display='none';
					btn.disabled=false;
					var msg='Analyse terminée :\n\n';
					if(results.clean>0)msg+='\u2022 '+results.clean+' faux positif(s) nettoyé(s)\n';
					if(results.gsc>0)msg+='\u2022 '+results.gsc+' nouvelle(s) 404 importée(s) depuis GSC\n';
					if(results.ai_found>0)msg+='\u2022 '+results.ai_found+' suggestion(s) IA trouvée(s) sur '+results.ai_scanned+' analysées\n';
					if(results.clean===0&&results.gsc===0&&results.ai_found===0)msg+='Aucun changement détecté. Tout est à jour.';
					_toast(msg,'success');
					load();
				},600);
			});
		});
	});
};
/* Keep individual functions for programmatic use */
window._importGSC=function(btn){if(btn)btn.disabled=true;f404('import_gsc_404s',0,{},function(j){if(btn)btn.disabled=false;if(j.success)load();});};
window._rescanAI=function(btn){if(btn)btn.disabled=true;f404('bulk_rescan_ai',0,{},function(j){if(btn)btn.disabled=false;if(j.success)load();});};
window._cleanFP=function(btn){if(btn)btn.disabled=true;f404('cleanup_false_positives',0,{},function(j){if(btn)btn.disabled=false;if(j.success)load();});};
window._purgeBots=function(btn){
	_confirm('Purger les 404 bots ?','Supprime les faux 404 créés par des bots (scanners de sécurité, crawlers SEO spam, URLs de probe type /phpmyadmin, /login, /.env...). Les vraies 404 de visiteurs et les opportunités GEO sont conservées.','Purger','danger').then(function(ok){
		if(!ok)return;
		if(btn)btn.disabled=true;
		f404('purge_bot_probes',0,{},function(j){
			if(btn)btn.disabled=false;
			if(j.success){
				var d=j.data||{};
				_toast(d.purged+' 404 bots supprimées ('+d.probes+' probes + '+d.spam_bots+' spam). '+d.remaining+' restantes.','ok');
				load();
			}
		});
	});
};
window._clearRes=function(){_confirm('Supprimer les 404 résolues ?','Les 404 déjà redirigées ou ignorées seront supprimées. Les redirections elles-mêmes ne sont pas affectées.','Supprimer','danger').then(function(ok){if(!ok)return;f404('clear_resolved',0,{},function(){load()})})};
window._loadMore404s=function(){
	R.offset=(R.offset||0)+50;
	var fd=new FormData();
	fd.append('action','hts_redirect_get_data');
	fd.append('nonce',R.nonce);
	fd.append('offset',R.offset);
	var _sb=document.getElementById('f-show-bots');
	fd.append('hide_bots',_sb&&_sb.checked?'0':'1');
	fetch(R.ajax,{method:'POST',body:fd})
	.then(function(r){return r.json()})
	.then(function(j){
		if(!j.success||!j.data)return;
		var newItems=j.data.top_404s||[];
		if(!newItems.length){
			var btn=document.getElementById('f-load-more');
			if(btn)btn.innerHTML='<span style="font-size:12px;color:var(--hts-text-3)">Toutes les 404 sont affichées</span>';
			return;
		}
		/* Append to existing data and re-render */
		R.data.top_404s=(R.data.top_404s||[]).concat(newItems);
		render404s(R.data);
		_acBind();
	})
	.catch(function(e){_toast('Erreur : '+e.message,'error')});
};
window._toggleAIMore=function(){
	var extras=document.querySelectorAll('.ai-extra');
	var btn=document.getElementById('ai-show-more');
	var visible=extras[0]&&extras[0].style.display!=='none';
	extras.forEach(function(el){el.style.display=visible?'none':'flex'});
	if(btn)btn.textContent=visible?'Voir les '+extras.length+' autres suggestions':'Masquer';
};
window._bulkAI=function(){
	var ids=[];
	(R.data.top_404s||[]).forEach(function(f){if(f.suggested_target&&parseFloat(f.suggested_score)>=0.75)ids.push(f.id)});
	if(!ids.length)return;
	var fd=new FormData();fd.append('action','hts_redirect_bulk');fd.append('nonce',R.nonce);fd.append('sub_action','accept_all_suggestions');
	ids.forEach(function(id){fd.append('ids[]',id)});
	fetch(R.ajax,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(){load()}).catch(function(e){_toast('Erreur réseau : '+e.message,'error')});
};
window._applyPatSafe=function(pat,tgt,label,count){
	var desc='Rediriger automatiquement '+(count||'ces')+' pages. Les anciennes URLs seront redirigées vers les nouvelles. Réversible depuis l\u0027onglet Redirections.';
	_confirm('Appliquer la redirection ?',desc,'Rediriger').then(function(ok){
	if(!ok)return;
	var fd=new FormData();fd.append('action','hts_redirect_action');fd.append('nonce',R.nonce);fd.append('sub_action','add');
	fd.append('source',pat);fd.append('target',tgt||'/');fd.append('type',tgt?'301':'410');fd.append('is_regex','1');
	fd.append('notes','Pattern auto-détecté');
	fetch(R.ajax,{method:'POST',body:fd})
	.then(function(r){return r.json()})
	.then(function(j){
		if(j.success){
			_toast('Redirection appliquée !','success');
			load();
		}else{
			_toast('Erreur : '+(j.data||'Impossible'),'error');
		}
	})
	.catch(function(e){_toast('Erreur réseau : '+e.message,'error')});
	}); // end _confirm .then
};

/* ═══ REDIRECT RULES AJAX ═══ */
function rAjax(sub,id,cb){
	var fd=new FormData();fd.append('action','hts_redirect_action');fd.append('nonce',R.nonce);fd.append('sub_action',sub);fd.append('id',id);
	fetch(R.ajax,{method:'POST',body:fd})
	.then(function(r){return r.json()})
	.then(function(j){if(cb)cb(j)})
	.catch(function(e){_toast('Erreur réseau : '+e.message,'error')});
}
window._toggle=function(id){rAjax('toggle',id,function(){load()})};
window._delRule=function(id){_confirm('Supprimer cette redirection ?','La règle sera supprimée. Les visiteurs ne seront plus redirigés.','Supprimer','danger').then(function(ok){if(!ok)return;rAjax('delete',id,function(){load()})})};
window._editRule=function(id,src,tgt){
	var form=document.getElementById('add-form');
	form.style.display='block';
	document.getElementById('a-src').value=src;
	document.getElementById('a-tgt').value=tgt;
	window._editingRuleId=id;
	var btn=document.getElementById('a-submit');
	if(btn)btn.textContent='Modifier';
	form.scrollIntoView({behavior:'smooth',block:'center'});
};
window._filterRules=function(){
	var q=document.getElementById('r-search').value.toLowerCase();
	document.querySelectorAll('#r-list .r-card').forEach(function(row){
		row.style.display=row.textContent.toLowerCase().indexOf(q)>=0?'':'none';
	});
};
window._filter404s=function(){
	var q=document.getElementById('f-search').value.toLowerCase();
	document.querySelectorAll('#f-list .f-card').forEach(function(row){
		row.style.display=row.textContent.toLowerCase().indexOf(q)>=0?'':'none';
	});
};
window._auditAI=function(btn){
	btn.disabled=true;btn.textContent='Audit en cours...';
	f404('audit_ai_redirects',0,{},function(j){
		btn.disabled=false;btn.innerHTML='<?php echo HTS_DS::icon("zap",12,"var(--hts-geo)"); ?> Auditer les redirections IA';
		var res=document.getElementById('audit-result');
		if(!j.success||!j.data){res.innerHTML='<div style="padding:12px;color:var(--hts-danger);font-size:12px">Erreur d\u0027audit</div>';return;}
		var d=j.data;
		var html='<div class="hts-ds-card" style="padding:16px 20px;margin-bottom:14px">';
		html+='<div style="font-size:13px;font-weight:700;margin-bottom:10px">Résultat de l\u0027audit IA</div>';
		if(d.broken_list&&d.broken_list.length){
			html+='<div style="font-size:12px;font-weight:600;color:var(--hts-danger);margin-bottom:6px">Redirections cassées ('+d.broken_list.length+')</div>';
			(d.broken_list||[]).forEach(function(b){
				html+='<div style="padding:6px 0;font-size:11px;display:flex;gap:8px;align-items:center;border-bottom:1px solid var(--hts-border-sub)">'
					+'<code style="color:var(--hts-text-3)">'+esc(b.source)+'</code><span class="ar">→</span><code style="color:var(--hts-danger)">'+esc(b.target)+' (cible cassée)</code>'
					+'<button class="bn bn-s bn-d" onclick="_delRule('+b.id+')">Supprimer</button></div>';
			});
		}
		if(d.high_traffic_list&&d.high_traffic_list.length){
			html+='<div style="font-size:12px;font-weight:600;color:var(--hts-caution);margin:12px 0 6px">Haut trafic à vérifier ('+d.high_traffic_list.length+')</div>';
			(d.high_traffic_list||[]).forEach(function(ht){
				html+='<div style="padding:6px 0;font-size:11px;display:flex;gap:8px;align-items:center;border-bottom:1px solid var(--hts-border-sub)">'
					+'<code style="color:var(--hts-text-3)">'+esc(ht.source)+'</code><span class="ar">→</span><code>'+esc(ht.target)+'</code>'
					+'<span style="font-weight:700;color:var(--hts-caution)">'+fmtN(ht.hits)+' hits</span></div>';
			});
		}
		if((!d.broken_list||!d.broken_list.length)&&(!d.high_traffic_list||!d.high_traffic_list.length)){
			html+='<div style="color:var(--hts-success);font-size:12px">Toutes les redirections IA sont fonctionnelles.</div>';
		}
		html+='</div>';
		res.innerHTML=html;
	});
};
window._addRule=function(){
	var src=document.getElementById('a-src').value.trim();
	var tgt=document.getElementById('a-tgt').value.trim();
	var typ=document.getElementById('a-typ').value;
	var rgx=document.getElementById('a-rgx').checked;
	var msg=document.getElementById('a-msg');
	if(!src){msg.textContent='Source requise';msg.style.color='var(--hts-danger)';return;}

	// If editing an existing rule, delete it first then re-add
	var editId=window._editingRuleId||0;
	var proceed=function(){
		var fd=new FormData();fd.append('action','hts_redirect_action');fd.append('nonce',R.nonce);fd.append('sub_action','add');
		fd.append('source',src);fd.append('target',tgt);fd.append('type',typ);fd.append('is_regex',rgx?'1':'0');
		fetch(R.ajax,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(j){
			if(j.success){
				msg.textContent=editId?'Redirection modifiée':'Redirection créée';
				msg.style.color='var(--hts-success)';
				document.getElementById('a-src').value='';document.getElementById('a-tgt').value='';
				window._editingRuleId=0;
				var btn=document.getElementById('a-submit');if(btn)btn.textContent='Créer';
				load();
				setTimeout(function(){msg.textContent='';document.getElementById('add-form').style.display='none'},2000);
			}
			else{msg.textContent=j.data||'Erreur';msg.style.color='var(--hts-danger)';}
		}).catch(function(e){msg.textContent='Erreur réseau';msg.style.color='var(--hts-danger)';});
	};
	if(editId){
		rAjax('delete',editId,function(){proceed()});
	}else{
		proceed();
	}
};

/* ═══ IMPORT/EXPORT ═══ */
document.getElementById('imp-file').addEventListener('change',function(){
	var file=this.files[0];
	var msg=document.getElementById('imp-msg');
	if(!file)return;
	msg.style.display='block';
	msg.textContent='Import en cours...';msg.style.color='var(--hts-geo)';
	var fd=new FormData();fd.append('action','hts_redirect_import_csv');fd.append('nonce',R.nonce);fd.append('csv_file',file);
	fetch(R.ajax,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(j){
		msg.textContent=j.success?(j.data.imported||0)+' importées'+(j.data.errors?' ('+j.data.errors+' erreurs)':''):'Erreur : '+(j.data||'');
		msg.style.color=j.success?'var(--hts-success)':'var(--hts-danger)';
		if(j.success)load();
		setTimeout(function(){msg.style.display='none'},5000);
	}).catch(function(e){msg.textContent='Erreur réseau';msg.style.color='var(--hts-danger)';});
});
window._export=function(){
	var fd=new FormData();fd.append('action','hts_redirect_export_csv');fd.append('nonce',R.nonce);
	fetch(R.ajax,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(j){
		if(!j.success||!j.data||!j.data.csv){_toast('Erreur export','error');return;}
		var blob=new Blob([j.data.csv],{type:'text/csv'});
		var url=URL.createObjectURL(blob);
		var a=document.createElement('a');a.href=url;a.download='hts-redirections-'+new Date().toISOString().slice(0,10)+'.csv';
		document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);
	}).catch(function(e){_toast('Erreur réseau : '+e.message,'error')});
};

/* ═══ AUTOCOMPLETE — Page search for redirect target ═══ */
var _acTimer=null;
function _acBind(){
	document.querySelectorAll('.hts-ac-input').forEach(function(inp){
		if(inp.dataset.acBound)return;
		inp.dataset.acBound='1';
		var dropId='acd-'+inp.id;
		inp.addEventListener('input',function(){
			var q=inp.value.trim();
			clearTimeout(_acTimer);
			var drop=document.getElementById(dropId);
			if(!drop)return;
			if(q.length<2){drop.classList.remove('open');drop.innerHTML='';return;}
			// If starts with / or http — user is typing a URL, no search
			if(q.charAt(0)==='/'||q.indexOf('http')===0){drop.classList.remove('open');return;}
			_acTimer=setTimeout(function(){
				var fd=new FormData();
				fd.append('action','hts_redirect_search_pages');
				fd.append('nonce',R.nonce);
				fd.append('q',q);
				fetch(R.ajax,{method:'POST',body:fd})
				.then(function(r){return r.json()})
				.then(function(j){
					if(!j.success||!j.data||!j.data.length){drop.classList.remove('open');drop.innerHTML='';return;}
					var html='';
					j.data.forEach(function(p){
						html+='<button class="ac-item" data-url="'+escA(p.url)+'" type="button">'
							+'<div class="ac-title">'+esc(p.title)+'</div>'
							+'<div class="ac-url">'+esc(p.url)+'</div>'
							+'</button>';
					});
					drop.innerHTML=html;
					drop.classList.add('open');
					// Bind click on items
					drop.querySelectorAll('.ac-item').forEach(function(item){
						item.addEventListener('click',function(e){
							e.preventDefault();
							e.stopPropagation();
							inp.value=item.dataset.url;
							drop.classList.remove('open');
							drop.innerHTML='';
						});
					});
				})
				.catch(function(){drop.classList.remove('open');});
			},250);
		});
		// Close dropdown on blur (with delay for click)
		inp.addEventListener('blur',function(){
			setTimeout(function(){
				var drop=document.getElementById(dropId);
				if(drop)drop.classList.remove('open');
			},200);
		});
	});
}

/* ═══ HELPERS ═══ */
function esc(s){if(!s)return '';var d=document.createElement('div');d.appendChild(document.createTextNode(s));return d.innerHTML}
function escA(s){return esc(s).replace(/'/g,'&#39;').replace(/"/g,'&quot;')}
function ago(d){if(!d)return '';var df=Math.max(0,Math.floor((Date.now()-new Date(d.replace(' ','T')).getTime())/1000));if(df<60)return 'maintenant';if(df<3600)return Math.floor(df/60)+' min';if(df<86400)return Math.floor(df/3600)+' h';return Math.floor(df/86400)+' j'}
function fmtN(n){if(typeof n!=='number')n=parseInt(n,10)||0;return n.toLocaleString('fr-FR')}

/* ═══ EXPOSE to global scope (onclick attributes run outside IIFE) ═══ */
window.load = load;

/* ═══ INIT ═══ */
load();
})();
</script>
