<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Hack The SEO — Pages en concurrence (S11b — DS v5.7)
 * CEO language: "Pages en concurrence" (not "cannibalisation")
 * Groups loaded via AJAX (POST) with pagination.
 * @since 2.6.0
 *
 * Changelog S11b:
 * - FIX race condition filtres: requestId anti-stale + container vidé synchrone
 * - Barre de progression scan avec étapes CEO-friendly + ralenti UX
 * - Bouton "Définir pilier" → radio inline dans la barre pilier (pas de popup)
 * - GSC check: badge connecté/non connecté dans le hero
 * - Tous les fix S11 maintenus (POST, display, tokens, etc.)
 */
if ( ! defined( 'WPINC' ) ) die;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}

$_can_merge = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::can( 'cannibal_merge' ) : true;
$cannibal    = new HTS_Cannibalization();
$pairs_data  = $cannibal->get_pairs();
$groups_data = $cannibal->get_groups();
$pairs     = $pairs_data['pairs'] ?? array();
$scanned   = $pairs_data['scanned_at'] ?? ( $groups_data['scanned_at'] ?? '' );
$groups    = $groups_data['groups'] ?? array();
$ajax_url  = admin_url( 'admin-ajax.php' );
$nonce     = wp_create_nonce( 'hts_admin_nonce' );
$total_groups    = count( $groups );
$total_pages     = $groups_data['total_pages'] ?? 0;
$critical_groups = count( array_filter( $groups, function( $g ) { return ( $g['severity'] ?? '' ) === 'critical'; } ) );
$warning_groups  = count( array_filter( $groups, function( $g ) { return ( $g['severity'] ?? '' ) === 'warning'; } ) );
$resolved_pairs  = count( array_filter( $pairs, function( $p ) { return in_array( $p['status'] ?? '', array( 'dismissed', 'redirected', 'merge_pending' ), true ); } ) );
$has_groups = ! empty( $groups );
$has_pairs  = ! empty( $pairs );

// ── Historique — commenté S11, à finaliser session dédiée ──
// $history = get_option( 'hts_cannibal_history', array() );
// if ( ! is_array( $history ) ) $history = array();
// $history = array_slice( $history, 0, 20 );

// ── GSC connection check ──
$gsc_connected = false;
if ( class_exists( 'HTS_GSC_Connect' ) ) {
	$gsc_connected = ( new HTS_GSC_Connect() )->is_connected();
}

// ── Hero KPIs ──
$hero_kpis = '<div style="position:absolute;top:28px;right:32px;display:flex;flex-wrap:wrap;gap:8px;max-width:60%">';
foreach ( array(
	array( 'l' => 'Groupes',   'v' => $total_groups,    'c' => 'rgba(255,255,255,.9)' ),
	array( 'l' => 'Pages',     'v' => $total_pages,     'c' => 'rgba(255,255,255,.9)' ),
	array( 'l' => 'Critiques', 'v' => $critical_groups, 'c' => 'var(--hts-danger)' ),
	array( 'l' => 'Attention', 'v' => $warning_groups,  'c' => 'var(--hts-caution)' ),
	array( 'l' => 'Résolus',   'v' => $resolved_pairs,  'c' => 'var(--hts-success)' ),
) as $k ) {
	$hero_kpis .= '<div style="text-align:center;padding:8px 14px;border-radius:8px;background:rgba(255,255,255,.04)">'
		. '<div style="font-size:18px;font-weight:800;color:' . $k['c'] . '">' . (int) $k['v'] . '</div>'
		. '<div style="font-size:9px;color:rgba(255,255,255,.35);font-weight:600;text-transform:uppercase;margin-top:2px">' . esc_html( $k['l'] ) . '</div>'
		. '</div>';
}
$hero_kpis .= '</div>';

// ── Hero extra: KPIs + scan date + GSC badge ──
$hero_extra = $hero_kpis;
$hero_bottom = '';
if ( $scanned ) {
	$hero_bottom .= '<div style="display:flex;align-items:center;gap:12px;margin-top:14px;font-size:11px;color:rgba(255,255,255,.35)">'
		. HTS_DS::dot( 'ok', 6 )
		. '<span>Dernier scan : ' . esc_html( $scanned ) . '</span>';
}
if ( $gsc_connected ) {
	$hero_bottom .= '<span style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:4px;background:rgba(52,211,153,.12);color:rgba(52,211,153,.9);font-weight:600;font-size:10px">'
		. HTS_DS::dot( 'ok', 5 ) . ' GSC</span>';
} else {
	$hero_bottom .= '<span style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:4px;background:rgba(255,255,255,.06);color:rgba(255,255,255,.3);font-weight:600;font-size:10px">'
		. 'GSC non connecté</span>';
}
if ( $scanned ) {
	$hero_bottom .= '</div>';
} else {
	$hero_bottom = '<div style="display:flex;align-items:center;gap:12px;margin-top:14px;font-size:11px;color:rgba(255,255,255,.35)">' . $hero_bottom . '</div>';
}
$hero_extra .= $hero_bottom;
?>

<?php echo HTS_DS::page_open( true ); ?>
<?php echo HTS_DS::hero(
	'Pages en concurrence',
	'Détectez les pages qui se battent pour les mêmes mots-clés sur Google',
	$hero_extra
); ?>
<style>.hts-hero{position:relative}</style>

<?php if ( $has_groups ) : ?>

<?php // ── Filter tabs + Scan button ── ?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px">
	<div class="hts-ds-tabs" id="hts-cb-tabs">
		<button class="hts-ds-tabs__item hts-ds-tabs__item--active" data-severity="all" onclick="htsCbFilterGroup('all',this)">
			Tous (<?php echo $total_groups; ?>)
		</button>
		<button class="hts-ds-tabs__item" data-severity="critical" onclick="htsCbFilterGroup('critical',this)">
			<?php echo HTS_DS::dot( 'fail', 6 ); ?> Critiques (<?php echo $critical_groups; ?>)
		</button>
		<button class="hts-ds-tabs__item" data-severity="warning" onclick="htsCbFilterGroup('warning',this)">
			<?php echo HTS_DS::dot( 'warn', 6 ); ?> Attention (<?php echo $warning_groups; ?>)
		</button>
	</div>
	<?php echo HTS_DS::button( 'Analyser avec l\'IA', 'geo', 'sm', array( 'type' => 'button', 'id' => 'hts-cb-scan', 'onclick' => 'htsCbScan()' ),
		HTS_DS::icon( 'zap', 13, 'rgba(255,255,255,.9)' ) ); ?>
</div>

<!-- Scan progress — Loader Orbit (DS v5.7 A14b-D) -->
<div id="hts-cb-scan-progress" style="display:none;margin-bottom:24px">
	<div style="display:flex;align-items:center;gap:16px;padding:14px 20px;background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:14px;box-shadow:var(--hts-shadow)">
		<div style="width:32px;height:32px;position:relative;flex-shrink:0">
			<div style="position:absolute;inset:2px;border-radius:50%;border:1px solid var(--hts-border-sub)"></div>
			<div style="position:absolute;inset:0;animation:htsSpin 1.8s linear infinite">
				<div style="width:6px;height:6px;border-radius:50%;background:var(--hts-geo);position:absolute;top:0;left:50%;margin-left:-3px"></div>
			</div>
			<div style="position:absolute;inset:5px;animation:htsSpin 2.8s linear infinite reverse">
				<div style="width:4px;height:4px;border-radius:50%;background:var(--hts-geo);opacity:.5;position:absolute;top:0;left:50%;margin-left:-2px"></div>
			</div>
			<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
				<div style="width:5px;height:5px;border-radius:50%;background:var(--hts-geo);opacity:.7;animation:htsPulse 2s ease-in-out infinite"></div>
			</div>
		</div>
		<div style="min-width:0;flex:1">
			<div id="hts-cb-scan-label" style="font-size:13px;font-weight:600;color:var(--hts-text)">Analyse en cours...</div>
			<div id="hts-cb-scan-detail" style="font-size:11px;color:var(--hts-text-3);margin-top:2px">Préparation de l'analyse...</div>
			<div style="margin-top:8px;width:100%;height:3px;border-radius:2px;background:var(--hts-surface);overflow:hidden">
				<div id="hts-cb-scan-bar" style="height:100%;width:0%;border-radius:2px;background:var(--hts-geo);transition:width .6s ease"></div>
			</div>
		</div>
	</div>
</div>

<!-- Groups container (AJAX loaded) -->
<div id="hts-cb-groups"></div>

<!-- Load more -->
<div id="hts-cb-load-more" style="display:none;text-align:center;margin:16px 0">
	<?php echo HTS_DS::button( 'Charger plus de groupes', 'default', 'md', array( 'type' => 'button', 'onclick' => 'htsCbLoadMore()' ) ); ?>
</div>

<!-- Initial loading -->
<div id="hts-cb-loading" style="text-align:center;padding:20px;color:var(--hts-text-3);font-size:12px">
	Chargement des groupes...
</div>

<?php elseif ( $has_pairs && ! $has_groups ) : ?>
	<?php echo HTS_DS::empty_state(
		'Mise à jour disponible',
		count( $pairs ) . ' paires détectées. Relancez le scan pour activer le regroupement intelligent.',
		'Lancer le scan',
		array( 'type' => 'button', 'onclick' => 'htsCbScan()' )
	); ?>
	<!-- Scan progress for empty state — Orbit -->
	<div id="hts-cb-scan-progress" style="display:none;margin:24px 0">
		<div style="display:flex;align-items:center;gap:16px;padding:14px 20px;background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:14px;box-shadow:var(--hts-shadow)">
			<div style="width:32px;height:32px;position:relative;flex-shrink:0">
				<div style="position:absolute;inset:2px;border-radius:50%;border:1px solid var(--hts-border-sub)"></div>
				<div style="position:absolute;inset:0;animation:htsSpin 1.8s linear infinite">
					<div style="width:6px;height:6px;border-radius:50%;background:var(--hts-geo);position:absolute;top:0;left:50%;margin-left:-3px"></div>
				</div>
				<div style="position:absolute;inset:5px;animation:htsSpin 2.8s linear infinite reverse">
					<div style="width:4px;height:4px;border-radius:50%;background:var(--hts-geo);opacity:.5;position:absolute;top:0;left:50%;margin-left:-2px"></div>
				</div>
				<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
					<div style="width:5px;height:5px;border-radius:50%;background:var(--hts-geo);opacity:.7;animation:htsPulse 2s ease-in-out infinite"></div>
				</div>
			</div>
			<div style="min-width:0;flex:1">
				<div id="hts-cb-scan-label" style="font-size:13px;font-weight:600;color:var(--hts-text)">Analyse en cours...</div>
				<div id="hts-cb-scan-detail" style="font-size:11px;color:var(--hts-text-3);margin-top:2px">Préparation de l'analyse...</div>
				<div style="margin-top:8px;width:100%;height:3px;border-radius:2px;background:var(--hts-surface);overflow:hidden">
					<div id="hts-cb-scan-bar" style="height:100%;width:0%;border-radius:2px;background:var(--hts-geo);transition:width .6s ease"></div>
				</div>
			</div>
		</div>
	</div>
<?php else : ?>
	<?php if ( ! empty( $scanned ) ) : ?>
		<?php echo HTS_DS::empty_state(
			'Aucune concurrence détectée',
			'Votre site est propre : aucune page ne se fait concurrence. Relancez un scan si vous avez publié de nouveaux contenus.'
		); ?>
	<?php else : ?>
		<?php echo HTS_DS::empty_state(
			'Aucun scan effectué',
			'Lancez un scan pour détecter les pages qui se font concurrence sur les mêmes mots-clés.',
			'Lancer le scan',
			array( 'type' => 'button', 'onclick' => 'htsCbScan()' )
		); ?>
	<?php endif; ?>
<?php endif; ?>

<?php /* ── HISTORIQUE DES ACTIONS — commenté S11, à finaliser session dédiée ──
<?php if ( ! empty( $history ) ) : ?>
<!-- Historique des actions -->
<div style="margin-top:32px">
	...
</div>
<?php endif; ?>
── FIN HISTORIQUE COMMENTÉ */ ?>

<div id="hts-cb-toast" style="position:fixed;bottom:30px;right:30px;background:var(--hts-success);color:rgba(255,255,255,.95);padding:12px 20px;border-radius:var(--hts-radius);font-size:13px;font-weight:600;z-index:99999;display:none;box-shadow:var(--hts-shadow-lg)"></div>

<!-- Confirmation Modal -->
<div class="hts-cb-modal-overlay" id="hts-cb-modal">
	<div class="hts-cb-modal">
		<div class="hts-cb-modal-header">
			<span class="modal-icon" id="hts-cb-modal-icon"><?php echo HTS_DS::icon( 'link', 20, 'var(--hts-geo)' ); ?></span>
			<h4 id="hts-cb-modal-title">Confirmer l'action</h4>
			<button type="button" class="modal-close" onclick="htsCbModalClose()">&times;</button>
		</div>
		<div class="hts-cb-modal-body" id="hts-cb-modal-body"></div>
		<div class="hts-cb-modal-footer">
			<?php echo HTS_DS::button( 'Annuler', 'default', 'md', array( 'type' => 'button', 'onclick' => 'htsCbModalClose()', 'class' => 'hts-ds-btn modal-cancel' ) ); ?>
			<button type="button" class="hts-ds-btn hts-ds-btn--geo modal-confirm" id="hts-cb-modal-confirm">Confirmer</button>
		</div>
	</div>
</div>

<!-- Agent not enabled modal (same pattern as Planning) -->
<div id="hts-cb-agent-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.4);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
	<div style="background:var(--hts-bg,#fff);border-radius:var(--hts-radius,12px);padding:32px;max-width:440px;width:90%;box-shadow:0 12px 40px rgba(0,0,0,.15);text-align:center">
		<div style="margin-bottom:16px"><?php echo HTS_DS::icon( 'shield', 48, 'var(--hts-caution)' ); ?></div>
		<div style="font-size:18px;font-weight:700;color:var(--hts-text);margin-bottom:8px">Action impossible</div>
		<div style="font-size:13px;color:var(--hts-text-2);line-height:1.6;max-width:340px;margin:0 auto 16px">
			L'action n'a pas pu être effectuée pour la raison suivante :
		</div>
		<div class="hts-cb-agent-body" style="text-align:left;max-width:360px;margin:0 auto 24px;background:var(--hts-surface,#f9fafb);border-radius:8px;padding:10px 14px;max-height:140px;overflow-y:auto"></div>
		<div style="display:flex;gap:8px;justify-content:center">
			<?php echo HTS_DS::button( 'Fermer', 'default', 'sm', array( 'onclick' => "document.getElementById('hts-cb-agent-modal').style.display='none'" ) ); ?>
			<a href="<?php echo admin_url( 'admin.php?page=hts-api-settings' ); ?>" style="text-decoration:none;display:inline-block"><?php echo HTS_DS::button( 'Ouvrir les réglages', 'geo', 'sm' ); ?></a>
		</div>
	</div>
</div>

<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>

<!-- ═══ DS-aligned styles ═══ -->
<style>
.hts-cb-group{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius-lg);margin-bottom:12px;overflow:hidden;box-shadow:var(--hts-shadow);transition:box-shadow var(--hts-dur-fast)}
.hts-cb-group:hover{box-shadow:var(--hts-shadow-lg)}
.hts-cb-group.critical{border-color:var(--hts-danger);box-shadow:var(--hts-shadow),0 0 0 1px var(--hts-danger-bg,rgba(239,68,68,.08))}
.hts-cb-group.warning{border-color:var(--hts-caution);box-shadow:var(--hts-shadow),0 0 0 1px var(--hts-caution-bg,rgba(234,179,8,.08))}
.hts-cb-group.ok{border-color:var(--hts-border)}
.hts-cb-group-head{display:flex;align-items:center;padding:16px 20px;cursor:pointer;gap:12px;transition:background var(--hts-dur-fast)}
.hts-cb-group-head:hover{background:var(--hts-surface)}
.hts-cb-group-score{font-size:22px;font-weight:800;min-width:45px;text-align:center}
.hts-cb-group-score.crit{color:var(--hts-danger)}.hts-cb-group-score.warn{color:var(--hts-caution)}.hts-cb-group-score.safe{color:var(--hts-success)}
.hts-cb-group-info{flex:1}
.hts-cb-group-kw{font-size:14px;font-weight:700;color:var(--hts-text)}
.hts-cb-group-kw .keyword{background:var(--hts-caution-bg);color:var(--hts-caution);padding:2px 8px;border-radius:4px;font-size:12px;font-weight:600;margin-left:6px}
.hts-cb-group-meta{font-size:11px;color:var(--hts-text-3);margin-top:3px;display:flex;gap:12px;flex-wrap:wrap}
.hts-cb-group-chevron{font-size:18px;color:var(--hts-text-3);transition:transform var(--hts-dur-normal)}
.hts-cb-group.open .hts-cb-group-chevron{transform:rotate(90deg)}
.hts-cb-group-body{display:none;border-top:1px solid var(--hts-border-sub);padding:16px 20px}
.hts-cb-group.open .hts-cb-group-body{display:block}
.hts-cb-pillar-bar{background:var(--hts-accent-bg);border:1px solid var(--hts-accent);border-radius:var(--hts-radius-sm);padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;gap:10px;font-size:12px;flex-wrap:wrap}
.hts-cb-pillar-bar .pillar-label{font-weight:700;color:var(--hts-accent)}
.hts-cb-pillar-bar .pillar-title{color:var(--hts-accent);text-decoration:none;padding:0;background:none;box-shadow:none;border:none}
.hts-cb-pillar-bar .pillar-title:hover{text-decoration:underline}
.hts-cb-pillar-bar .pillar-score-badge{font-size:11px;color:var(--hts-accent);font-weight:600;margin-left:6px}
.hts-cb-pillar-bar .pillar-change{font-size:10px;color:var(--hts-geo);cursor:pointer;margin-left:auto;text-decoration:underline;padding:0;background:none;box-shadow:none;border:none;font-family:var(--hts-font)}
.hts-cb-advice-bar{background:var(--hts-caution-bg);border:1px solid var(--hts-caution);border-radius:var(--hts-radius-sm);padding:10px 14px;margin-bottom:14px;font-size:12px;color:var(--hts-caution);line-height:1.5}
.hts-cb-pages-table{width:100%;border-collapse:collapse;font-size:12px}
.hts-cb-pages-table th{text-align:left;font-size:10px;color:var(--hts-text-3);text-transform:uppercase;font-weight:600;letter-spacing:.3px;padding:6px 8px;border-bottom:1px solid var(--hts-border-sub);white-space:nowrap}
.hts-cb-pages-table td{padding:8px;border-bottom:1px solid var(--hts-border-sub);vertical-align:top}
.hts-cb-pages-table tr:last-child td{border-bottom:none}
.hts-cb-pages-table .pillar-row{background:var(--hts-success-bg)}
.hts-cb-pages-table a{color:var(--hts-accent);text-decoration:none;font-weight:500;padding:0;background:none;box-shadow:none;border:none}
.hts-cb-pages-table a:hover{text-decoration:underline}
.hts-cb-pages-table .num-cell{text-align:right;font-family:var(--hts-mono);font-size:11px}
.hts-cb-pages-table input[type="checkbox"]{accent-color:var(--hts-accent)}
.hts-cb-pages-table code{background:none}
/* Pillar button — hidden by default, shown when "Changer le pilier" is clicked */
.hts-cb-pillar-btn{display:none;font-size:10px;padding:2px 8px;border-radius:4px;border:1px solid var(--hts-geo);background:none;color:var(--hts-geo);cursor:pointer;font-weight:600;margin-top:4px;font-family:var(--hts-font);transition:background var(--hts-dur-fast)}
.hts-cb-pillar-btn:hover{background:var(--hts-geo-soft)}
.hts-cb-group.changing-pillar .hts-cb-pillar-btn{display:inline-block}
/* Actions */
.hts-cb-group-actions{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}
.hts-cb-group-actions button{font-size:11px;padding:7px 14px;border-radius:var(--hts-radius-sm);cursor:pointer;font-weight:600;border:1px solid var(--hts-border);background:var(--hts-bg);color:var(--hts-text-2);font-family:var(--hts-font);display:flex;align-items:center;gap:5px;transition:background var(--hts-dur-fast),border-color var(--hts-dur-fast)}
.hts-cb-group-actions button:hover{background:var(--hts-surface)}
.hts-cb-group-actions button.primary{background:var(--hts-accent);color:rgba(255,255,255,.95);border:none}
.hts-cb-group-actions button.primary:hover{opacity:.9}
.hts-cb-group-actions button.danger{color:var(--hts-danger);border-color:var(--hts-danger)}
.hts-cb-group-actions button.danger:hover{background:var(--hts-danger-bg,rgba(239,68,68,.06))}
/* Modal */
.hts-cb-modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:100000;display:none;align-items:center;justify-content:center}
.hts-cb-modal-overlay.open{display:flex}
.hts-cb-modal{background:var(--hts-bg);border-radius:var(--hts-radius-lg);width:95%;max-width:540px;max-height:80vh;overflow:hidden;box-shadow:var(--hts-shadow-lg);display:flex;flex-direction:column}
.hts-cb-modal-header{padding:18px 22px;border-bottom:1px solid var(--hts-border-sub);display:flex;align-items:center;gap:10px}
.hts-cb-modal-header h4{margin:0;font-size:15px;font-weight:700;color:var(--hts-text);flex:1}
.hts-cb-modal-header .modal-close{background:none;border:none;font-size:18px;color:var(--hts-text-3);cursor:pointer;padding:4px 8px;border-radius:var(--hts-radius-xs)}
.hts-cb-modal-header .modal-close:hover{background:var(--hts-surface);color:var(--hts-text)}
.hts-cb-modal-body{padding:18px 22px;overflow-y:auto;flex:1}
.hts-cb-modal-body .modal-summary{font-size:13px;color:var(--hts-text-2);margin-bottom:14px;line-height:1.6}
.hts-cb-modal-body .modal-summary strong{color:var(--hts-text)}
.hts-cb-modal-body .modal-pages{font-size:11px;color:var(--hts-text-2);max-height:180px;overflow-y:auto;background:var(--hts-surface);border-radius:var(--hts-radius-sm);padding:10px 12px}
.hts-cb-modal-body .modal-pages div{padding:3px 0;border-bottom:1px solid var(--hts-border-sub)}
.hts-cb-modal-body .modal-pages div:last-child{border-bottom:none}
.hts-cb-modal-body .modal-warning{background:var(--hts-caution-bg);border:1px solid var(--hts-caution);border-radius:var(--hts-radius-sm);padding:10px 14px;margin-top:12px;font-size:12px;color:var(--hts-caution)}
.hts-cb-modal-body .modal-info{background:var(--hts-accent-bg);border:1px solid var(--hts-accent);border-radius:var(--hts-radius-sm);padding:10px 14px;margin-top:12px;font-size:12px;color:var(--hts-accent)}
.hts-cb-modal-footer{padding:14px 22px;border-top:1px solid var(--hts-border-sub);display:flex;gap:10px;justify-content:flex-end}
.hts-cb-modal-footer .modal-confirm.danger{background:var(--hts-danger)}
.hts-cb-modal-footer .modal-confirm.danger:hover{opacity:.9}
</style>

<script>
(function(){
	'use strict';
	var ajaxUrl  = '<?php echo esc_js( $ajax_url ); ?>';
	var nonce    = '<?php echo esc_js( $nonce ); ?>';
	var canMerge = <?php echo $_can_merge ? 'true' : 'false'; ?>;
	var upgradeUrl = '<?php echo esc_js( rtrim( get_option( "hts_api_base_url", "https://app.hacktheseo.com" ), "/" ) . "/user/pricing/plans" ); ?>';
	var PER_PAGE = 20;
	var currentOffset   = 0;
	var currentSeverity = 'all';
	var isLoading       = false;
	var requestId       = 0; /* anti-stale: ignore responses from old requests */

	function htsPost(action, data) {
		var fd = new FormData();
		fd.append('action', action);
		fd.append('nonce', nonce);
		for (var k in data) {
			if (Array.isArray(data[k])) { data[k].forEach(function(v) { fd.append(k + '[]', v); }); }
			else { fd.append(k, data[k]); }
		}
		return fetch(ajaxUrl, { method:'POST', body:fd }).then(function(r) { return r.json(); });
	}
	function toast(msg, duration) {
		var t = document.getElementById('hts-cb-toast');
		t.textContent = msg;
		t.style.background = (duration && duration > 3000) ? 'var(--hts-danger)' : 'var(--hts-success)';
		t.style.display = 'block';
		setTimeout(function() { t.style.display = 'none'; }, duration || 3000);
	}
	function esc(str) { var d = document.createElement('div'); d.textContent = str || ''; return d.innerHTML; }
	function trimStr(str, len) { str = str || ''; return str.length > len ? str.substring(0, len) + '...' : str; }
	function fmtNum(n) { return (n || 0).toLocaleString('fr-FR'); }
	function fmtDate(dateStr) { if (!dateStr) return '\u2014'; var d = new Date(dateStr); if (isNaN(d)) return '\u2014'; return ('0'+d.getDate()).slice(-2)+'/'+('0'+(d.getMonth()+1)).slice(-2)+'/'+d.getFullYear(); }
	function pillarScoreColor(score) { if (score >= 60) return 'var(--hts-success)'; if (score >= 30) return 'var(--hts-caution)'; return 'var(--hts-text-3)'; }

	/* ── Render group card ── */
	function renderGroup(g) {
		var severity=g.severity||'ok',maxScore=g.max_score||0,avgScore=g.avg_score||0,keyword=g.keyword||'',pages=g.pages||[],pageCount=g.page_count||pages.length,pairsCt=g.pairs_count||0,pillarId=g.pillar_id||0,groupId=g.id||'',pillarTitle=g.pillar_title||'';
		var scoreClass=maxScore>=80?'crit':(maxScore>=50?'warn':'safe');
		var pillarScore=0;
		for(var i=0;i<pages.length;i++){if(parseInt(pages[i].post_id,10)===parseInt(pillarId,10)){pillarScore=pages[i].pillar_score||0;break;}}
		var html='<div class="hts-cb-group '+esc(severity)+'" data-severity="'+esc(severity)+'" data-group-id="'+esc(groupId)+'">';
		html+='<div class="hts-cb-group-head" onclick="htsCbToggle(this.parentNode)">';
		html+='<div class="hts-cb-group-score '+scoreClass+'">'+maxScore+'</div>';
		html+='<div class="hts-cb-group-info"><div class="hts-cb-group-kw">'+pageCount+' pages en concurrence';
		if(keyword)html+=' <span class="keyword">'+esc(keyword)+'</span>';
		html+='</div><div class="hts-cb-group-meta"><span>Score max : '+maxScore+' | moy : '+avgScore+'</span><span>'+pairsCt+' paire(s)</span>';
		if(pillarId)html+='<span>Pilier : '+esc(trimStr(pillarTitle,40))+'</span>';
		html+='</div></div><div class="hts-cb-group-chevron">\u203A</div></div>';
		html+='<div class="hts-cb-group-body">';
		if(pillarId){
			html+='<div class="hts-cb-pillar-bar">';
			html+='<span class="pillar-icon"><?php echo HTS_DS::icon("star",16,"var(--hts-accent)"); ?></span>';
			html+='<span class="pillar-label">Page pilier :</span>';
			html+='<a href="/?p='+pillarId+'" target="_blank" class="pillar-title">'+esc(pillarTitle)+'</a>';
			html+='<span class="pillar-score-badge">(score '+pillarScore+'/100)</span>';
			html+='<button type="button" class="pillar-change" onclick="event.stopPropagation();htsCbChangePillar(\''+esc(groupId)+'\')">Changer le pilier</button>';
			html+='</div>';
		}
		var advice=g.advice||'';if(advice)html+='<div class="hts-cb-advice-bar">'+esc(advice)+'</div>';
		html+='<table class="hts-cb-pages-table"><thead><tr><th style="width:30px"><input type="checkbox" onchange="htsCbSelectAll(this,\''+esc(groupId)+'\')" checked></th><th>Page</th><th style="text-align:right">Score</th><th style="text-align:right">Clics 30j</th><th style="text-align:right">Impressions</th><th style="text-align:right">Pos. moy</th><th style="text-align:right">Liens</th><th style="text-align:right">Longueur</th><th style="text-align:right">Date</th></tr></thead><tbody>';
		for(var p=0;p<pages.length;p++){var pg=pages[p],isPillar=parseInt(pg.post_id,10)===parseInt(pillarId,10),ps=pg.pillar_score||0,psColor=pillarScoreColor(ps),pos=parseFloat(pg.avg_position)||0;
			html+='<tr class="'+(isPillar?'pillar-row':'')+'" data-pid="'+pg.post_id+'"><td><input type="checkbox" class="hts-cb-page-check" data-group="'+esc(groupId)+'" data-pid="'+pg.post_id+'"'+(isPillar?' disabled title="Page pilier (la meilleure)"':' checked')+'></td>';
			html+='<td><a href="'+esc(pg.url||'')+'" target="_blank">'+esc(trimStr(pg.title,60))+'</a>';
			if(!isPillar){
				html+='<br><button type="button" class="hts-cb-pillar-btn" data-gid="'+esc(groupId)+'" data-pid="'+pg.post_id+'" onclick="event.stopPropagation();htsCbPillarSelected(\''+esc(groupId)+'\','+pg.post_id+')">D\u00e9finir comme pilier</button>';
			}
			html+='</td>';
			html+='<td class="num-cell"><span style="font-weight:700;color:'+psColor+'">'+ps+'</span></td>';
			html+='<td class="num-cell">'+fmtNum(pg.clicks)+'</td><td class="num-cell">'+fmtNum(pg.impressions)+'</td>';
			html+='<td class="num-cell">'+(pos>0?pos:'\u2014')+'</td><td class="num-cell">'+(pg.in_links||0)+'</td>';
			html+='<td class="num-cell">'+fmtNum(Math.round((pg.content_length||0)/1000))+'k</td>';
			html+='<td class="num-cell" style="font-size:10px">'+fmtDate(pg.date)+'</td></tr>';
		}
		html+='</tbody></table>';
		html+='<div class="hts-cb-group-actions">';
		if(canMerge){
		html+='<button type="button" class="primary" onclick="htsCbGroupAction(\''+esc(groupId)+'\',\'redirect_all\','+pillarId+')"><?php echo HTS_DS::icon("link",12,"rgba(255,255,255,.9)"); ?> Rediriger vers le pilier</button>';
		html+='<button type="button" onclick="htsCbGroupAction(\''+esc(groupId)+'\',\'merge_all\','+pillarId+')">Marquer pour fusion</button>';
		}else{
		html+='<a href="'+upgradeUrl+'" target="_blank" style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:8px;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;font-size:11px;font-weight:700;text-decoration:none"><?php echo HTS_DS::icon("zap",12,"#fff"); ?> Rediriger \u2014 Pro</a>';
		html+='<a href="'+upgradeUrl+'" target="_blank" style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:8px;border:1px solid #f59e0b;color:#f59e0b;font-size:11px;font-weight:700;text-decoration:none;background:none"><?php echo HTS_DS::icon("zap",12,"#f59e0b"); ?> Fusionner \u2014 Pro</a>';
		}
		html+='<button type="button" class="danger" onclick="htsCbGroupAction(\''+esc(groupId)+'\',\'dismiss_group\',0)">Ignorer</button>';
		html+='</div></div></div>';
		return html;
	}

	/* ── Load groups via AJAX (POST) ── */
	function loadGroups(append) {
		var container = document.getElementById('hts-cb-groups');
		if (!container) return;
		requestId++;
		var thisRequest = requestId;
		isLoading = true;
		if (!append) { currentOffset = 0; container.innerHTML = ''; }
		var loadingEl = document.getElementById('hts-cb-loading');
		if (loadingEl) loadingEl.style.display = 'block';
		htsPost('hts_cannibal_get_groups', { offset: currentOffset, limit: PER_PAGE, severity: currentSeverity })
		.then(function(res) {
			if (thisRequest !== requestId) return; /* stale response — ignore */
			isLoading = false;
			if (loadingEl) loadingEl.style.display = 'none';
			if (!res.success || !res.data) return;
			var groups = res.data.groups || [];
			var html = '';
			groups.forEach(function(g) { html += renderGroup(g); });
			if (append) container.innerHTML += html;
			else container.innerHTML = html;
			currentOffset += groups.length;
			var loadMore = document.getElementById('hts-cb-load-more');
			if (loadMore) loadMore.style.display = (res.data.has_more ? 'block' : 'none');
		})
		.catch(function() {
			if (thisRequest !== requestId) return;
			isLoading = false;
			if (loadingEl) loadingEl.textContent = 'Erreur de chargement';
		});
	}

	window.htsCbLoadMore = function() { loadGroups(true); };

	/* ── Scan with progress bar (CEO-friendly) ── */
	var scanSteps = [
		{ pct: 8,  label: 'Lecture de vos pages',               detail: 'On r\u00e9cup\u00e8re la liste de tous vos contenus publi\u00e9s...' },
		{ pct: 20, label: 'Comparaison des mots-cl\u00e9s',     detail: 'On v\u00e9rifie si plusieurs pages ciblent les m\u00eames mots-cl\u00e9s...' },
		{ pct: 40, label: 'Analyse des titres',                  detail: 'On d\u00e9tecte les titres trop similaires entre eux...' },
		{ pct: 60, label: 'Analyse s\u00e9mantique',             detail: 'On compare le sens profond de chaque page (embeddings)...' },
		{ pct: 80, label: 'Regroupement des pages',              detail: 'On regroupe les pages qui se font concurrence...' },
		{ pct: 90, label: '\u00c9lection des piliers',           detail: 'On identifie la meilleure page de chaque groupe (clics, liens, anciennet\u00e9)...' }
	];
	window.htsCbScan = function() {
		var progress = document.getElementById('hts-cb-scan-progress');
		var bar = document.getElementById('hts-cb-scan-bar');
		var label = document.getElementById('hts-cb-scan-label');
		var detail = document.getElementById('hts-cb-scan-detail');
		var scanBtn = document.getElementById('hts-cb-scan');
		if (progress) progress.style.display = 'block';
		if (scanBtn) scanBtn.disabled = true;
		if (bar) bar.style.width = '0%';

		/* Animate steps with delays for perceived progress */
		var stepIdx = 0;
		var stepTimer = setInterval(function() {
			if (stepIdx >= scanSteps.length) { clearInterval(stepTimer); return; }
			var s = scanSteps[stepIdx];
			if (bar) bar.style.width = s.pct + '%';
			if (label) label.textContent = s.label;
			if (detail) detail.textContent = s.detail;
			stepIdx++;
		}, 1800);

		htsPost('hts_cannibal_scan', {}).then(function(res) {
			clearInterval(stepTimer);
			if (bar) bar.style.width = '100%';
			if (label) label.textContent = 'Termin\u00e9 !';
			if (scanBtn) scanBtn.disabled = false;
			if (res.success) {
				if (detail) detail.textContent = (res.data.total || 0) + ' paire(s) d\u00e9tect\u00e9e(s), dont ' + (res.data.critical || 0) + ' critique(s).';
				setTimeout(function() { location.reload(); }, 1500);
			} else {
				if (detail) detail.textContent = 'Erreur : ' + (res.data || '\u00c9chec');
				if (bar) bar.style.background = 'var(--hts-danger)';
			}
		}).catch(function() {
			clearInterval(stepTimer);
			if (bar) { bar.style.width = '100%'; bar.style.background = 'var(--hts-danger)'; }
			if (label) label.textContent = 'Erreur r\u00e9seau';
			if (detail) detail.textContent = 'V\u00e9rifiez votre connexion et r\u00e9essayez.';
			if (scanBtn) scanBtn.disabled = false;
		});
	};

	/* ── Toggle / Filter ── */
	window.htsCbToggle = function(groupEl) { groupEl.classList.toggle('open'); };
	window.htsCbFilterGroup = function(level, el) {
		document.querySelectorAll('#hts-cb-tabs .hts-ds-tabs__item').forEach(function(t) { t.classList.remove('hts-ds-tabs__item--active'); });
		el.classList.add('hts-ds-tabs__item--active');
		currentSeverity = level;
		isLoading = false; /* cancel any pending load so the new one fires */
		loadGroups(false);
	};

	/* ── Select all / Get selected ── */
	window.htsCbSelectAll = function(checkbox, groupId) {
		var checks = document.querySelectorAll('.hts-cb-page-check[data-group="' + groupId + '"]:not(:disabled)');
		checks.forEach(function(c) { c.checked = checkbox.checked; });
	};
	function getSelectedIds(groupId) {
		var ids = [];
		document.querySelectorAll('.hts-cb-page-check[data-group="' + groupId + '"]:checked:not(:disabled)').forEach(function(c) {
			ids.push(parseInt(c.dataset.pid,10));
		});
		return ids;
	}

	/* ── Modal ── */
	window.htsCbModalClose = function() {
		document.getElementById('hts-cb-modal').classList.remove('open');
	};
	function showModal(opts) {
		document.getElementById('hts-cb-modal-title').textContent = opts.title || 'Confirmer';
		document.getElementById('hts-cb-modal-body').innerHTML = opts.body || '';
		var confirmBtn = document.getElementById('hts-cb-modal-confirm');
		confirmBtn.textContent = opts.confirmText || 'Confirmer';
		confirmBtn.className = 'hts-ds-btn hts-ds-btn--geo modal-confirm' + (opts.danger ? ' danger' : '');
		confirmBtn.onclick = function() { htsCbModalClose(); if (opts.onConfirm) opts.onConfirm(); };
		document.getElementById('hts-cb-modal').classList.add('open');
	}

	function getSelectedPageInfo(groupId) {
		var info = [];
		document.querySelectorAll('.hts-cb-page-check[data-group="' + groupId + '"]:checked:not(:disabled)').forEach(function(c) {
			var row = c.closest('tr');
			var link = row ? row.querySelector('a') : null;
			info.push({ id: parseInt(c.dataset.pid,10), title: link ? link.textContent : '#' + c.dataset.pid });
		});
		return info;
	}
	function getPillarInfo(groupId) {
		var groupEl = document.querySelector('[data-group-id="' + groupId + '"]');
		if (!groupEl) return { id: 0, title: '?' };
		var pillarLink = groupEl.querySelector('.pillar-title');
		var pillarId = 0;
		var pillarCheck = groupEl.querySelector('.hts-cb-page-check:disabled');
		if (pillarCheck) pillarId = parseInt(pillarCheck.dataset.pid,10);
		return { id: pillarId, title: pillarLink ? pillarLink.textContent : '?' };
	}

	/* ── Group Actions ── */
	window.htsCbGroupAction = function(groupId, actionType, pillarId) {
		var selectedIds = getSelectedIds(groupId);
		var selectedInfo = getSelectedPageInfo(groupId);
		var pillarInfo = getPillarInfo(groupId);

		if (actionType === 'redirect_all') {
			if (!selectedIds.length) { toast('S\u00e9lectionnez au moins une page'); return; }
			var body = '<div class="modal-summary">Les <strong>' + selectedIds.length + ' pages</strong> s\u00e9lectionn\u00e9es seront redirig\u00e9es (301) vers le pilier <strong>' + esc(pillarInfo.title) + '</strong>.</div>';
			body += '<div class="modal-pages">';
			selectedInfo.forEach(function(p) { body += '<div>' + esc(p.title) + ' \u2192 pilier</div>'; });
			body += '</div>';
			body += '<div class="modal-warning">Une redirection 301 sera cr\u00e9\u00e9e de chaque page vers le pilier. Les pages resteront publi\u00e9es \u2014 vous pourrez les passer en brouillon manuellement.</div>';
			showModal({ title: 'Rediriger vers le pilier', body: body, confirmText: 'Rediriger ' + selectedIds.length + ' pages', onConfirm: function() { executeGroupAction(groupId, actionType, pillarId, selectedIds); } });
		} else if (actionType === 'merge_all') {
			if (!selectedIds.length) { toast('S\u00e9lectionnez au moins une page'); return; }
			var body2 = '<div class="modal-summary">Marquer <strong>' + selectedIds.length + ' pages</strong> pour fusion manuelle vers <strong>' + esc(pillarInfo.title) + '</strong>.</div>';
			body2 += '<div class="modal-pages">';
			selectedInfo.forEach(function(p) { body2 += '<div>' + esc(p.title) + '</div>'; });
			body2 += '</div>';
			body2 += '<div class="modal-info">Aucune modification automatique. Vous pourrez fusionner le contenu manuellement.</div>';
			showModal({ title: 'Marquer pour fusion', body: body2, confirmText: 'Marquer ' + selectedIds.length + ' pages', onConfirm: function() { executeGroupAction(groupId, actionType, pillarId, selectedIds); } });
		} else if (actionType === 'dismiss_group') {
			showModal({ title: 'Ignorer ce groupe', body: '<div class="modal-summary">Ce groupe sera marqu\u00e9 comme r\u00e9solu. Il r\u00e9appara\u00eetra lors du prochain scan si le probl\u00e8me persiste.</div>', confirmText: 'Ignorer', danger: true, onConfirm: function() { executeGroupAction(groupId, actionType, 0, []); } });
		}
	};

	function executeGroupAction(groupId, actionType, pillarId, selectedIds) {
		var groupEl = document.querySelector('[data-group-id="' + groupId + '"]');
		var btns = groupEl ? groupEl.querySelectorAll('.hts-cb-group-actions button') : [];
		btns.forEach(function(b) { b.disabled = true; });
		htsPost('hts_cannibal_group_action', {
			group_id: groupId, action_type: actionType,
			pillar_id: pillarId, selected_ids: selectedIds
		}).then(function(res) {
			if (res.success) {
				var d = res.data || {};
				var msg = (d.processed || 0) + ' page(s) trait\u00e9e(s)';
				if (d.mode === 'queued') msg += ' (en file d\u0027attente)';
				if (!d.processed && d.errors) {
					/* Erreur → ouvrir le modal avec les raisons */
					var reasons = d.error_reasons || [];
					var agentModal = document.getElementById('hts-cb-agent-modal');
					if (agentModal) {
						var bodyEl = agentModal.querySelector('.hts-cb-agent-body');
						if (bodyEl && reasons.length) {
							var html = '';
							reasons.forEach(function(r) { html += '<div style="padding:6px 0;border-bottom:1px solid var(--hts-border-sub,#eee);font-size:12px;color:var(--hts-text-2)">' + esc(r) + '</div>'; });
							bodyEl.innerHTML = html;
						}
						agentModal.style.display = 'flex';
					}
					btns.forEach(function(b) { b.disabled = false; });
					return;
				}
				if (d.errors) {
					var reasons = d.error_reasons || [];
					msg += ', ' + d.errors + ' erreur(s)';
					if (reasons.length) msg += ' : ' + reasons[0];
				}
				toast(msg, d.errors ? 5000 : 3000);
				if (groupEl) { groupEl.style.opacity = '0.3'; groupEl.style.pointerEvents = 'none'; }
				setTimeout(function() { location.reload(); }, 1500);
			} else {
				toast('Erreur : ' + (res.data || ''), 5000);
				btns.forEach(function(b) { b.disabled = false; });
			}
		}).catch(function() {
			toast('Erreur r\u00e9seau', 5000);
			btns.forEach(function(b) { b.disabled = false; });
		});
	}

	/* ── Rollback redirections ── */
	/* ── Rollback — commenté S11, à finaliser session dédiée ──
	window.htsCbRollback = function(historyIdx) { };
	*/

	/* ── Change pillar (inline radio UX) ── */
	window.htsCbChangePillar = function(groupId) {
		var groupEl = document.querySelector('[data-group-id="' + groupId + '"]');
		if (!groupEl) return;
		groupEl.classList.toggle('changing-pillar');
		var changeBtn = groupEl.querySelector('.pillar-change');
		if (groupEl.classList.contains('changing-pillar')) {
			if (changeBtn) changeBtn.textContent = 'Annuler';
		} else {
			if (changeBtn) changeBtn.textContent = 'Changer le pilier';
		}
	};
	window.htsCbPillarSelected = function(groupId, newPillarId) {
		htsPost('hts_cannibal_change_pillar', { group_id: groupId, new_pillar_id: newPillarId })
		.then(function(res) {
			if (res.success) {
				toast('Pilier modifi\u00e9');
				setTimeout(function() { location.reload(); }, 1000);
			} else {
				toast('Erreur : ' + (res.data || ''), 5000);
			}
		}).catch(function() {
			toast('Erreur r\u00e9seau', 5000);
		});
	};

	/* ── Init ── */
	document.addEventListener('DOMContentLoaded', function() { loadGroups(false); });
})();
</script>
