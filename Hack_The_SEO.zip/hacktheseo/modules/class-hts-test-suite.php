<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Test Suite — Tests d'intégration automatisés pour Hack The SEO Light
 *
 * Différence avec le Diagnostic : la Test Suite crée de VRAIS posts sandbox,
 * exécute de VRAIES opérations (scoring, sauvegarde), vérifie les résultats,
 * puis nettoie tout. Organisé par phase roadmap + cross-module.
 *
 * Accès : ?page=hts-light-dashboard&tab=test-suite
 * @since 1.12.0
 */

class HTS_Test_Suite {

    private $results = array();
    private $pass = 0;
    private $fail = 0;
    private $warn = 0;
    private $skip = 0;
    private $sandbox_posts = array();
    private $timer_start = 0;

    public function init() {
        add_action( 'wp_ajax_hts_test_suite_run',            array( $this, 'ajax_run' ) );
        add_action( 'wp_ajax_hts_test_suite_run_group',      array( $this, 'ajax_run_group' ) );
        add_action( 'wp_ajax_hts_test_suite_cleanup',        array( $this, 'ajax_cleanup' ) );
        add_action( 'wp_ajax_hts_test_suite_export',         array( $this, 'ajax_export' ) );
        add_action( 'wp_ajax_hts_test_suite_count_orphans',  array( $this, 'ajax_count_orphans' ) );
    }

    /* ═══ AJAX ═══ */

    public function ajax_run() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        // Augmenter les limites pour les tests lourds
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 180 );
        }
        wp_raise_memory_limit( 'admin' );

        try {
            $this->run_all();
            wp_send_json_success( array( 'results' => $this->results, 'summary' => $this->get_summary() ) );
        } catch ( \Throwable $e ) {
            // v2.4.1 fix : nettoyer les sandbox posts même en cas de crash
            $this->cleanup_sandbox();
            wp_send_json_error( 'Fatal: ' . $e->getMessage() . ' dans ' . basename( $e->getFile() ) . ':' . $e->getLine() );
        }
    }

    public function ajax_run_group() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        $group = sanitize_text_field( $_POST['group'] ?? '' );
        if ( ! $group ) wp_send_json_error( 'Groupe manquant' );
        $method = 'test_group_' . str_replace( '-', '_', $group );
        if ( ! method_exists( $this, $method ) ) wp_send_json_error( 'Groupe inconnu : ' . $group );

        // v2.4.1 fix : nettoyer les orphelins avant + try/catch pour cleanup en cas de crash
        $this->cleanup_orphans();

        try {
            $this->$method();
            $this->cleanup_sandbox();
            wp_send_json_success( array( 'results' => $this->results, 'summary' => $this->get_summary() ) );
        } catch ( \Throwable $e ) {
            $this->cleanup_sandbox();
            wp_send_json_error( 'Fatal: ' . $e->getMessage() . ' dans ' . basename( $e->getFile() ) . ':' . $e->getLine() );
        }
    }

    public function ajax_cleanup() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        $cleaned = $this->cleanup_orphans();
        wp_send_json_success( array( 'cleaned' => $cleaned ) );
    }

    public function ajax_count_orphans() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        global $wpdb;

        // Compter par meta
        $by_meta = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_test_post' AND meta_value = '1'"
        );

        // Compter par titre (brouillons "HTS Test —" sans meta)
        $by_title = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_title LIKE 'HTS Test —%' AND post_status = 'draft' AND post_type = 'post'
             AND ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_hts_test_post' AND meta_value = '1')"
        );

        wp_send_json_success( array( 'count' => $by_meta + $by_title ) );
    }

    public function ajax_export() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 180 );
        }
        wp_raise_memory_limit( 'admin' );

        $this->run_all();

        $lines = array();
        $lines[] = '══════════════════════════════════════════════════════════';
        $lines[] = '  HTS TEST SUITE — Export Debug';
        $lines[] = '══════════════════════════════════════════════════════════';
        $lines[] = '';
        $lines[] = 'Date       : ' . wp_date( 'Y-m-d H:i:s' ) . ' (' . wp_timezone_string() . ')';
        $lines[] = 'Site       : ' . home_url();
        $lines[] = 'Plugin     : Hack The SEO v' . ( defined('HTS__VERSION') ? HTS__VERSION : '?' );
        $lines[] = 'WordPress  : ' . get_bloginfo( 'version' );
        $lines[] = 'PHP        : ' . PHP_VERSION;
        $lines[] = 'Serveur    : ' . ( $_SERVER['SERVER_SOFTWARE'] ?? 'Inconnu' );
        $lines[] = 'Memoire    : ' . ini_get( 'memory_limit' ) . ' (pic: ' . round( memory_get_peak_usage(true) / 1024 / 1024, 1 ) . ' MB)';
        $lines[] = 'Theme      : ' . wp_get_theme()->get('Name') . ' v' . wp_get_theme()->get('Version');
        $lines[] = '';
        $lines[] = 'RÉSUMÉ     : ' . $this->pass . ' pass / ' . $this->fail . ' fail / ' . $this->warn . ' warn / ' . $this->skip . ' skip';
        $lines[] = '';

        // Group results
        $groups = array();
        foreach ( $this->results as $r ) $groups[ $r['group'] ][] = $r;

        $icons = array( 'pass' => 'OK', 'fail' => 'FAIL', 'warn' => 'WARN', 'skip' => 'SKIP' );

        foreach ( $groups as $group_name => $tests ) {
            $gf = count( array_filter( $tests, function( $t ) { return $t['status'] === 'fail'; } ) );
            $gw = count( array_filter( $tests, function( $t ) { return $t['status'] === 'warn'; } ) );
            $gs = $gf > 0 ? 'FAIL' : ( $gw > 0 ? 'WARN' : 'OK' );

            $lines[] = '──────────────────────────────────────────────────────────';
            $lines[] = '  ' . mb_strtoupper( $group_name ) . '  [' . $gs . ']';
            $lines[] = '──────────────────────────────────────────────────────────';

            foreach ( $tests as $t ) {
                $icon = $icons[ $t['status'] ] ?? '?';
                $detail = ! empty( $t['detail'] ) ? ' → ' . $t['detail'] : '';
                $lines[] = sprintf( '  [%-4s] %-35s%s', $icon, $t['name'], $detail );
            }
            $lines[] = '';
        }

        // Active plugins
        $lines[] = '──────────────────────────────────────────────────────────';
        $lines[] = '  PLUGINS ACTIFS';
        $lines[] = '──────────────────────────────────────────────────────────';
        $active = get_option( 'active_plugins', array() );
        foreach ( $active as $p ) {
            $data = get_plugin_data( WP_PLUGIN_DIR . '/' . $p, false, false );
            $lines[] = '  - ' . ( $data['Name'] ?: $p ) . ' v' . ( $data['Version'] ?: '?' );
        }
        $lines[] = '';

        // HTS options
        $lines[] = '──────────────────────────────────────────────────────────';
        $lines[] = '  HTS OPTIONS';
        $lines[] = '──────────────────────────────────────────────────────────';
        $opts = array( 'hts_light_version', 'hts_title_separator', 'hts_module_meta_tags', 'hts_module_schema',
                       'hts_module_sitemap', 'hts_module_redirects', 'hts_module_canonical', 'hts_module_gsc',
                       'hts_onboarding_done', 'hts_indexnow_enabled', 'hts_llmstxt_enabled', 'hts_diagnostic_mode' );
        foreach ( $opts as $opt ) {
            $val = get_option( $opt, '(non défini)' );
            if ( is_array( $val ) ) $val = wp_json_encode( $val );
            $lines[] = '  ' . $opt . ' = ' . $val;
        }
        $lines[] = '';

        // Post counts
        $lines[] = '──────────────────────────────────────────────────────────';
        $lines[] = '  DONNÉES SITE';
        $lines[] = '──────────────────────────────────────────────────────────';
        global $wpdb;
        $pub = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ('post','page')");
        $scored = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_combined_score'");
        $gs_scored = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_global_score'");
        $lines[] = '  Posts publiés    : ' . $pub;
        $lines[] = '  Avec panel score : ' . $scored;
        $lines[] = '  Avec global score: ' . $gs_scored;
        $lines[] = '';
        $lines[] = '══════════════════════════════════════════════════════════';
        $lines[] = '  Généré par Hack The SEO Test Suite';
        $lines[] = '══════════════════════════════════════════════════════════';

        $report = implode( "\n", $lines );
        $filename = 'hts-test-suite-' . sanitize_title( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '-' . wp_date('Y-m-d-His') . '.txt';

        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        echo $report;
        wp_die();
    }

    /* ═══ RUN ALL ═══ */

    public function run_all() {
        // ── Phase 5 fix : éviter le timeout sur hébergements lents ──
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 120 );
        }
        wp_raise_memory_limit( 'admin' );

        // ── v2.4.1 fix : nettoyer les orphelins AVANT de commencer ──
        // Si un run précédent a crashé/timeout, les posts sandbox restent en base.
        // On les nettoie systématiquement au démarrage pour éviter l'accumulation.
        $this->cleanup_orphans();

        $this->results = array();
        $this->pass = $this->fail = $this->warn = $this->skip = 0;

        $this->test_group_seo_panel();
        $this->test_group_global_score();
        $this->test_group_content_extractor();
        $this->test_group_cross_module();
        $this->test_group_performance();
        $this->test_group_meta_tags();
        $this->test_group_schema();
        $this->test_group_canonical();
        $this->test_group_redirects();
        $this->test_group_data_integrity();

        // Phases futures — activées auto quand le module existe
        $phases = array(
            'HTS_Meta_Score'      => array( 'Phase 1 — Meta Score',     'test_group_meta_score' ),
            'HTS_On_Page_Score'   => array( 'Phase 2 — On-Page Score',  'test_group_on_page_score' ),
            'HTS_Content_Writer'  => array( 'Phase 2 — Content Writer', 'test_group_content_writer' ),
            'HTS_Embeddings'      => array( 'Phase 2b — Embeddings',     'test_group_embeddings' ),
            'HTS_Cocon'           => array( 'Phase 2b — Cocon Sémantique','test_group_cocon' ),
            'HTS_Internal_Linking'=> array( 'Phase 2b — Maillage Interne','test_group_internal_linking' ),
            'HTS_Decision_Engine' => array( 'Phase 3 — Decision Engine','test_group_decision_engine' ),
            'HTS_Audit_Trail'     => array( 'Phase 3 — Audit Trail',    'test_group_audit_trail' ),
            'HTS_Feedback_Loop'   => array( 'Phase 4 — Feedback Loop',  'test_group_feedback_loop' ),
            'HTS_Strategy_Engine' => array( 'Phase 4b — Strategy Engine', 'test_group_strategy_engine' ),
            'HTS_Health_Check'   => array( 'Phase 5a — Health Check', 'test_group_health_check' ),
        );
        // Phase 5b — always runs (it tests Cockpit integration, not a separate class)
        $this->test_group_health_cockpit();

        // Phase 5c — Cache + Loading states
        $this->test_group_ux_performance();

        // Phase 5d — Production cleanup
        $this->gate_5d_cleanup();

        // Phase ML — Multilingual support
        $this->gate_ml_multilingual();

        // Phase 6a — Cocon Commander
        $this->gate_6a_cocon_commander();

        // Phase 6a UI — Cockpit Cocon Commander
        $this->gate_6a_ui_commander();
        $this->gate_6b_calendar_autolink();
        $this->gate_6c_cannibalization();
        $this->gate_6c_plus_commander_logs();
        $this->gate_6d_cross_cocon_linking();
        $this->gate_6e_cockpit_v2_polish();

        // Phase 1 v2.0 — Article Pipeline
        $this->gate_phase1_article_pipeline();

        // Phase 2 v2.0 — Workflow Engine
        $this->gate_phase2_workflow_engine();

        // Phase 3 v2.0 — GEO Score + Content Refresh + Freshness
        $this->gate_phase3_geo_refresh();

        // Phase 4 v2.0 — Cannibalization Merge
        $this->gate_phase4_cannib_merge();

        // Phase 5 v2.0 — Auto-Write + Calendrier + Images
        $this->gate_phase5_auto_write();

        // Phase 6 v2.0 — Coach SEO (Killer Feature)
        $this->gate_phase6_coach();

        // v2.4.3 Session E — Agent Settings + Onboarding
        $this->gate_v243_session_e();

        // v2.4.3 Session F — ALT check, semantic filter, migration, dashboard widget
        $this->gate_v243_session_f();

        // v2.4.3 Session G — Persistent migration notice, inline agent edit, export/import, lazy-load
        $this->gate_v243_session_g();

        // v2.4.4 — Session H
        $this->gate_v244_session_h();

        // v2.4.5 — Session I
        $this->gate_v245_session_i();

        // v2.4.6 — Session J
        $this->gate_v246_session_j();

        // v2.4.7 — Session K
        $this->gate_v247_session_k();

        // Phase 7 v2.0 — Stabilisation + Release
        $this->gate_phase7_stabilisation();

        // v2.1 — Coach Freemium
        $this->gate_v21_coach_freemium();

        // v2.1 — Dispatch Coach → Workflow
        $this->gate_v21_coach_dispatch();

        // v2.1 — Inbox améliorée
        $this->gate_v21_inbox_enhanced();

        // Phase 0 — Dette de tests (api-receiver, gsc, modules secondaires)
        $this->test_group_api_receiver();
        $this->test_group_gsc_connect();
        $this->test_group_modules_secondaires();

        foreach ( $phases as $class => $info ) {
            if ( class_exists( $class ) ) {
                $this->{$info[1]}();
            } else {
                $this->add( $info[0], 'Module ' . $class, 'skip', 'Pas encore porté dans le Light' );
            }
        }

        $this->cleanup_sandbox();
        return $this->results;
    }

    /* ═══ HELPERS ═══ */

    private function create_sandbox_post( $args = array() ) {
        $defaults = array(
            'post_title'   => 'HTS Test — ' . wp_generate_password( 8, false ),
            'post_content' => '<p>Contenu de test pour Hack The SEO. Ce paragraphe permet au SEO Panel de calculer un score réaliste.</p><h2>Section de test</h2><p>Un deuxième paragraphe avec des mots-clés SEO pour simuler un vrai article WordPress.</p><h3>Sous-section</h3><p>Un troisième paragraphe pour la longueur. Images, liens internes et structure Hn sont importants pour le référencement.</p>',
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        );
        $args    = wp_parse_args( $args, $defaults );
        $post_id = wp_insert_post( $args );
        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_hts_test_post', 1 );
            $this->sandbox_posts[] = $post_id;
        }
        return $post_id;
    }

    private function cleanup_sandbox() {
        foreach ( $this->sandbox_posts as $pid ) {
            $this->safe_delete_post( (int) $pid );
        }
        $this->sandbox_posts = array();
    }

    private function cleanup_orphans() {
        global $wpdb;

        $count = 0;

        // Méthode 1 : posts avec meta _hts_test_post
        $orphans = $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_hts_test_post' AND meta_value = '1'" );
        foreach ( $orphans as $pid ) {
            $this->safe_delete_post( (int) $pid );
            $count++;
        }

        // Méthode 2 : posts "HTS Test —" en brouillon sans meta (cas de crash avant update_post_meta)
        $title_orphans = $wpdb->get_col(
            "SELECT ID FROM {$wpdb->posts} WHERE post_title LIKE 'HTS Test —%' AND post_status = 'draft' AND post_type = 'post'"
        );
        foreach ( $title_orphans as $pid ) {
            $this->safe_delete_post( (int) $pid );
            $count++;
        }

        return $count;
    }

    /**
     * Supprime un post sandbox sans déclencher les hooks WordPress.
     *
     * wp_delete_post() fire save_post / before_delete_post / delete_post,
     * et des plugins tiers (Elementor, Divi, WPBakery) hookés dessus crashent
     * quand l'objet WP_Post est null ou incomplet (brouillons sandbox).
     *
     * Pour les posts de test, on bypass complètement les hooks :
     * suppression directe en base + nettoyage du cache WP.
     *
     * @since 2.4.1
     */
    private function safe_delete_post( $post_id ) {
        global $wpdb;
        $post_id = (int) $post_id;
        if ( $post_id < 1 ) return;

        // Supprimer les metas
        $wpdb->delete( $wpdb->postmeta, array( 'post_id' => $post_id ), array( '%d' ) );

        // Supprimer les relations taxonomiques
        $wpdb->delete(
            $wpdb->term_relationships,
            array( 'object_id' => $post_id ),
            array( '%d' )
        );

        // Supprimer les commentaires (si jamais)
        $comment_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_post_ID = %d", $post_id
        ) );
        if ( $comment_ids ) {
            $wpdb->delete( $wpdb->commentmeta, array( 'comment_id' => $comment_ids[0] ), array( '%d' ) );
            $wpdb->delete( $wpdb->comments, array( 'comment_post_ID' => $post_id ), array( '%d' ) );
        }

        // Supprimer le post
        $wpdb->delete( $wpdb->posts, array( 'ID' => $post_id ), array( '%d' ) );

        // Vider le cache WP pour ce post
        clean_post_cache( $post_id );
    }

    private function add( $group, $name, $status, $detail = '' ) {
        $this->results[] = array( 'group' => $group, 'name' => $name, 'status' => $status, 'detail' => $detail );
        $this->{$status}++;
    }

    /**
     * Shorthand assert — delegates to assert_true with swapped arg order.
     * Usage: $this->assert( $group, 'label', $condition )
     */
    private function assert( $g, $name, $cond ) {
        $this->add( $g, $name, $cond ? 'pass' : 'fail', '' );
    }

    private function assert_true( $cond, $g, $name, $pass_msg = '', $fail_msg = '' ) {
        $this->add( $g, $name, $cond ? 'pass' : 'fail', $cond ? $pass_msg : $fail_msg );
    }

    private function assert_equals( $expected, $actual, $g, $name, $detail = '' ) {
        $ok = ( $expected === $actual );
        $this->add( $g, $name, $ok ? 'pass' : 'fail', $ok ? $detail : "Attendu: " . var_export($expected,true) . " — Obtenu: " . var_export($actual,true) );
    }

    private function assert_range( $val, $min, $max, $g, $name, $detail = '' ) {
        $ok = ( $val >= $min && $val <= $max );
        $this->add( $g, $name, $ok ? 'pass' : 'fail', $ok ? $detail : "Valeur $val hors [$min, $max]" );
    }

    private function get_summary() {
        return array( 'pass' => $this->pass, 'fail' => $this->fail, 'warn' => $this->warn, 'skip' => $this->skip, 'total' => $this->pass + $this->fail + $this->warn + $this->skip );
    }

    private function start_timer() { $this->timer_start = microtime( true ); }
    private function elapsed_ms() { return round( ( microtime( true ) - $this->timer_start ) * 1000, 1 ); }

    /* ═══ GROUP: SEO PANEL ═══ */

    private function test_group_seo_panel() {
        $g = 'SEO Panel';
        if ( ! class_exists( 'HTS_SEO_Panel' ) ) { $this->add( $g, 'Classe', 'fail', 'HTS_SEO_Panel introuvable' ); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_SEO_Panel chargée' );

        $panel = new HTS_SEO_Panel();
        $pid = $this->create_sandbox_post();
        if ( ! $pid || is_wp_error( $pid ) ) { $this->add( $g, 'Post sandbox', 'fail', 'Impossible de créer un post' ); return; }
        $this->add( $g, 'Post sandbox', 'pass', 'Post #' . $pid . ' créé' );

        update_post_meta( $pid, '_hts_focus_keyword', 'test seo plugin' );
        $result = $panel->run_checks( $pid );
        $this->assert_true( is_array( $result ) && isset( $result['score'] ), $g, 'run_checks() retour', 'Array avec score', 'Format invalide' );

        $score = (int) ( $result['score'] ?? -1 );
        $this->assert_range( $score, 0, 100, $g, 'Score [0, 100]', 'Score = ' . $score );

        update_post_meta( $pid, '_hts_combined_score', $score );
        $saved = (int) get_post_meta( $pid, '_hts_combined_score', true );
        $this->assert_equals( $score, $saved, $g, 'Score sauvé en meta', '_hts_combined_score = ' . $saved );

        // Sans keyword — score peut varier (keyword dans contenu peut pénaliser)
        $pid2 = $this->create_sandbox_post();
        $r2 = $panel->run_checks( $pid2 );
        $s2 = (int) ( $r2['score'] ?? 0 );
        if ( $s2 > $score ) {
            $this->add( $g, 'Sans keyword vs avec keyword', 'warn', "Sans: $s2 > Avec: $score — vérifier pénalités keyword" );
        } else {
            $this->add( $g, 'Sans keyword vs avec keyword', 'pass', "Sans: $s2, Avec: $score" );
        }

        // Post vide ne crash pas
        $pid3 = $this->create_sandbox_post( array( 'post_content' => '' ) );
        $r3 = $panel->run_checks( $pid3 );
        $this->assert_true( is_array( $r3 ) && isset( $r3['score'] ), $g, 'Post vide ne crash pas', 'Score: ' . ( $r3['score'] ?? '?' ), 'Crash sur post vide' );
    }

    /* ═══ GROUP: GLOBAL SCORE ═══ */

    private function test_group_global_score() {
        $g = 'Global Score';
        if ( ! class_exists( 'HTS_Global_Score' ) ) { $this->add( $g, 'Classe', 'fail', 'Introuvable' ); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_Global_Score chargée' );

        $gs = new HTS_Global_Score();
        $pid = $this->create_sandbox_post();
        update_post_meta( $pid, '_hts_focus_keyword', 'test global score' );

        $result = $gs->compute( $pid, true );
        $this->assert_true( is_array( $result ) && isset( $result['score'] ), $g, 'compute() retour', 'Array avec score', 'Format invalide' );
        $this->assert_range( (int) $result['score'], 0, 100, $g, 'Score [0, 100]', 'Score = ' . $result['score'] );

        $this->assert_true( isset( $result['panel_score'] ) && isset( $result['tech_score'] ), $g, 'Décomposition panel + tech',
            'Panel: ' . ( $result['panel_score'] ?? '?' ) . ' / Tech: ' . ( $result['tech_score'] ?? '?' ), 'Pas de décomposition' );

        if ( isset( $result['weights'] ) ) {
            $sum = 0;
            foreach ( $result['weights'] as $w ) $sum += $w;
            $this->assert_true( abs( $sum - 1.0 ) < 0.01, $g, 'Poids = 100%', round($sum*100) . '%', 'Somme = ' . round($sum*100) . '%' );
        }

        $r2 = $gs->compute_and_save( $pid, true );
        $saved = (int) get_post_meta( $pid, '_hts_global_score', true );
        $this->assert_equals( (int) $r2['score'], $saved, $g, 'compute_and_save() persiste', 'Sauvé = ' . $saved );

        $grade = $r2['grade'] ?? '';
        $this->assert_true( in_array( $grade, array('A','B','C','D'), true ), $g, 'Grade valide', 'Grade = ' . $grade, 'Grade invalide: ' . $grade );

        $r3 = $gs->compute( 999999999 );
        $this->assert_true( is_array($r3) && $r3['score'] === 0, $g, 'Post inexistant = score 0', 'OK', 'Crash' );
    }

    /* ═══ GROUP: CONTENT EXTRACTOR ═══ */

    private function test_group_content_extractor() {
        $g = 'Content Extractor';
        if ( ! class_exists( 'HTS_Content_Extractor' ) ) { $this->add( $g, 'Classe', 'fail', 'Introuvable' ); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_Content_Extractor chargée' );

        $pid = $this->create_sandbox_post( array( 'post_content' => '<p>Paragraphe simple avec des mots.</p><h2>Titre</h2><p>Second paragraphe.</p>' ) );
        $text = HTS_Content_Extractor::get_content( $pid );
        $this->assert_true( ! empty($text) && strpos($text, 'Paragraphe simple') !== false, $g, 'Extraction HTML', mb_strlen($text) . ' chars', 'Vide' );

        $pid2 = $this->create_sandbox_post( array( 'post_content' => '' ) );
        $text2 = HTS_Content_Extractor::get_content( $pid2 );
        $this->assert_true( is_string($text2) || $text2 === false, $g, 'Post vide ne crash pas', 'OK', 'Crash' );

        $pid3 = $this->create_sandbox_post( array( 'post_content' => '<p>Café &amp; crème. Un bon contenu.</p>' ) );
        $text3 = HTS_Content_Extractor::get_content( $pid3 );
        $this->assert_true( ! empty($text3) && is_string($text3), $g, 'HTML avec entities', 'Contenu retourné', 'Vide ou invalide' );

        $pid4 = $this->create_sandbox_post( array( 'post_content' => '<p>Avant</p>[gallery ids="1,2,3"]<p>Après</p>' ) );
        $text4 = HTS_Content_Extractor::get_content( $pid4 );
        $this->assert_true( is_string($text4), $g, 'Shortcode ne crash pas', 'OK', 'Crash sur shortcode' );

        $long = str_repeat( '<p>' . str_repeat( 'Lorem ipsum dolor sit amet. ', 50 ) . '</p>', 100 );
        $pid5 = $this->create_sandbox_post( array( 'post_content' => $long ) );
        $mem_before = memory_get_usage();
        HTS_Content_Extractor::get_content( $pid5 );
        $mem_diff = round( ( memory_get_usage() - $mem_before ) / 1024 / 1024, 2 );
        $this->assert_true( $mem_diff < 10, $g, 'Mémoire long < 10MB', $mem_diff . ' MB', $mem_diff . ' MB — fuite' );
    }

    /* ═══ GROUP: CROSS-MODULE ═══ */

    private function test_group_cross_module() {
        $g = 'Cross-Module';
        if ( ! class_exists('HTS_SEO_Panel') || ! class_exists('HTS_Global_Score') ) { $this->add($g,'Prérequis','skip','Panel ou GS manquant'); return; }

        $pid = $this->create_sandbox_post();
        update_post_meta( $pid, '_hts_focus_keyword', 'cross module test' );
        $panel = new HTS_SEO_Panel();
        $p_r = $panel->run_checks( $pid );
        update_post_meta( $pid, '_hts_combined_score', (int) $p_r['score'] );
        $gs = new HTS_Global_Score();
        $g_r = $gs->compute( $pid );
        $this->assert_true( $g_r['panel_score'] === (int)$p_r['score'], $g, 'Panel -> Global cascade', 'Panel score utilisé: ' . $g_r['panel_score'], 'Mismatch' );

        // noindex pénalise — le post doit être publish ET on stocke l'array correctement
        $pid_noindex = $this->create_sandbox_post( array( 'post_status' => 'publish' ) );
        update_post_meta( $pid_noindex, '_hts_robots_meta', array( 'noindex' ) );
        // Le Global Score check "indexation" utilise stripos sur la meta — stockons aussi en string pour compatibilité
        update_post_meta( $pid_noindex, '_hts_robots_meta', 'noindex' );
        $g_r2 = $gs->compute( $pid_noindex, true );
        $noindex_fail = false;
        foreach ( $g_r2['tech_detail'] ?? array() as $chk ) {
            if ( ($chk['id'] ?? '') === 'indexation' && $chk['status'] === 'fail' ) $noindex_fail = true;
        }
        $this->assert_true( $noindex_fail, $g, 'Noindex penalise tech score', 'Check indexation = fail', 'Non detecte (id=indexation, post=publish)' );
        delete_post_meta( $pid_noindex, '_hts_robots_meta' );
        // Remettre en draft pour le cleanup
        wp_update_post( array( 'ID' => $pid_noindex, 'post_status' => 'draft' ) );

        // Batch 3 posts
        $pids = array();
        for ( $i = 0; $i < 3; $i++ ) $pids[] = $this->create_sandbox_post();
        foreach ( $pids as $p ) $gs->compute_and_save( $p, true );
        $all = true;
        foreach ( $pids as $p ) { if ( get_post_meta($p,'_hts_global_score',true) === '' ) $all = false; }
        $this->assert_true( $all, $g, 'Batch 3 posts tous scorés', 'OK', 'Au moins 1 sans score' );

        // Canonical custom ne crash pas
        $pid4 = $this->create_sandbox_post();
        update_post_meta( $pid4, '_hts_canonical_url', 'https://example.com/custom' );
        $r4 = $gs->compute( $pid4, true );
        $this->assert_true( is_array($r4) && isset($r4['score']), $g, 'Canonical custom OK', 'Score: ' . $r4['score'], 'Crash' );
    }

    /* ═══ GROUP: PERFORMANCE ═══ */

    private function test_group_performance() {
        $g = 'Performance';

        if ( class_exists('HTS_SEO_Panel') ) {
            $pid = $this->create_sandbox_post();
            update_post_meta( $pid, '_hts_focus_keyword', 'perf test' );
            $panel = new HTS_SEO_Panel();
            $this->start_timer();
            $panel->run_checks( $pid );
            $ms = $this->elapsed_ms();
            $this->assert_true( $ms < 500, $g, 'SEO Panel < 500ms', $ms . ' ms', $ms . ' ms (max 500)' );
        }

        if ( class_exists('HTS_Global_Score') ) {
            $pid = $this->create_sandbox_post();
            update_post_meta( $pid, '_hts_combined_score', 72 );
            $gs = new HTS_Global_Score();
            $this->start_timer();
            $gs->compute( $pid );
            $ms = $this->elapsed_ms();
            $this->assert_true( $ms < 200, $g, 'Global Score < 200ms', $ms . ' ms', $ms . ' ms (max 200)' );

            // Batch 10
            $pids = array();
            for ( $i = 0; $i < 10; $i++ ) $pids[] = $this->create_sandbox_post();
            $this->start_timer();
            foreach ( $pids as $p ) $gs->compute_and_save( $p, true );
            $ms = $this->elapsed_ms();
            $this->assert_true( $ms < 3000, $g, 'Batch 10 posts < 3s', $ms . ' ms', $ms . ' ms (max 3000)' );

            // Query count
            $pid = $this->create_sandbox_post();
            update_post_meta( $pid, '_hts_combined_score', 60 );
            global $wpdb;
            $q_before = $wpdb->num_queries;
            $gs->compute_and_save( $pid, true );
            $q_diff = $wpdb->num_queries - $q_before;
            $this->assert_true( $q_diff < 30, $g, 'Queries < 30/compute', $q_diff . ' queries', $q_diff . ' queries (max 30)' );
        }

        $mem_mb = round( memory_get_peak_usage(true) / 1024 / 1024, 1 );
        $limit_raw = ini_get('memory_limit');
        $limit = (int) $limit_raw;
        if ( stripos($limit_raw,'G') !== false ) $limit *= 1024;
        $this->assert_true( $limit <= 0 || $mem_mb < $limit * 0.8, $g, 'Mémoire < 80% limit', $mem_mb . 'MB/' . $limit . 'MB', $mem_mb . 'MB/' . $limit . 'MB' );
    }

    /* ═══ GROUP: META TAGS ═══ */

    private function test_group_meta_tags() {
        $g = 'Meta Tags';
        if ( ! class_exists('HTS_Meta_Tags') ) { $this->add($g,'Classe','skip','Introuvable'); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_Meta_Tags chargée' );
        $sep = get_option('hts_title_separator');
        $this->assert_true( !empty($sep), $g, 'Séparateur configuré', 'Sep: ' . $sep, 'Aucun séparateur' );
        $pid = $this->create_sandbox_post( array('post_title' => 'Test Meta Tags') );
        update_post_meta( $pid, '_hts_meta_title', 'Titre SEO personnalisé' );
        update_post_meta( $pid, '_hts_meta_description', 'Description meta pour vérifier le module meta tags de Hack The SEO.' );
        $this->assert_equals( 'Titre SEO personnalisé', get_post_meta($pid,'_hts_meta_title',true), $g, 'Title sauvée', '' );
        $this->assert_true( mb_strlen(get_post_meta($pid,'_hts_meta_description',true)) > 30, $g, 'Description longueur OK', 'OK', 'Trop courte' );
    }

    /* ═══ GROUP: SCHEMA ═══ */

    private function test_group_schema() {
        $g = 'Schema JSON-LD';
        if ( ! class_exists('HTS_Schema_Markup') ) { $this->add($g,'Classe','skip','Introuvable'); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_Schema_Markup chargée' );
        $this->assert_true( get_option('hts_module_schema','1') === '1', $g, 'Module activé', 'Actif', 'Désactivé' );
        $pid = $this->create_sandbox_post();
        update_post_meta( $pid, '_hts_schema_type', 'Article' );
        $this->assert_equals( 'Article', get_post_meta($pid,'_hts_schema_type',true), $g, 'Type schema persisté', '' );
    }

    /* ═══ GROUP: CANONICAL ═══ */

    private function test_group_canonical() {
        $g = 'Canonical';
        if ( ! class_exists('HTS_Canonical') ) { $this->add($g,'Classe','skip','Introuvable'); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_Canonical chargée' );
        $pid = $this->create_sandbox_post();
        update_post_meta( $pid, '_hts_canonical_url', 'https://example.com/test-canonical' );
        $this->assert_equals( 'https://example.com/test-canonical', get_post_meta($pid,'_hts_canonical_url',true), $g, 'Canonical custom persisté', '' );
        $pid2 = $this->create_sandbox_post();
        $this->assert_true( empty(get_post_meta($pid2,'_hts_canonical_url',true)), $g, 'Auto par défaut', 'Pas de custom', 'Custom inattendu' );
    }

    /* ═══ GROUP: REDIRECTS ═══ */

    private function test_group_redirects() {
        $g = 'Redirections';
        if ( ! class_exists('HTS_Redirects') ) { $this->add($g,'Classe','skip','Introuvable'); return; }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_Redirects chargée' );
        global $wpdb;
        $table = $wpdb->prefix . 'hts_redirects';
        $exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        $this->assert_true( $exists, $g, 'Table existe', $table, 'Table absente' );
        if ( ! $exists ) return;
        $cols = $wpdb->get_results("DESCRIBE {$table}");
        $col_names = array_map( function($c){return $c->Field;}, $cols );
        $missing = array_diff( array('source_url','target_url','redirect_type'), $col_names );
        $this->assert_true( empty($missing), $g, 'Colonnes requises', 'source_url, target_url, redirect_type OK', 'Manquantes: ' . implode(',',$missing) );
    }

    /* ═══ GROUP: DATA INTEGRITY ═══ */

    private function test_group_data_integrity() {
        $g = 'Intégrité données';
        global $wpdb;
        $orphans = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID WHERE pm.meta_key LIKE '_hts_%' AND p.ID IS NULL");
        $this->assert_true( $orphans < 50, $g, 'Meta orphelines < 50', $orphans . ' orpheline(s)', $orphans . ' — nettoyage recommandé' );

        $bad_scores = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_combined_score' AND (CAST(meta_value AS SIGNED) < 0 OR CAST(meta_value AS SIGNED) > 100)");
        $this->assert_true( $bad_scores === 0, $g, 'Scores panel [0,100]', 'OK', $bad_scores . ' hors bornes' );

        $bad_gs = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_global_score' AND (CAST(meta_value AS SIGNED) < 0 OR CAST(meta_value AS SIGNED) > 100)");
        $this->assert_true( $bad_gs === 0, $g, 'Global scores [0,100]', 'OK', $bad_gs . ' hors bornes' );

        $str_robots = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_robots_meta' AND meta_value != '' AND meta_value NOT LIKE 'a:%'");
        $this->assert_true( $str_robots === 0, $g, 'Robots format array', 'OK', $str_robots . ' en string' );
    }

    /* ═══ PHASE STUBS (activés auto quand le module existe) ═══ */

    private function test_group_meta_score() {
        $g = 'Phase 1 — Meta Score';
        $this->add( $g, 'Module présent', 'pass', 'HTS_Meta_Score chargée' );
        $pid = $this->create_sandbox_post(array('post_title'=>'Test Meta Score'));
        update_post_meta($pid,'_hts_focus_keyword','meta score test');
        update_post_meta($pid,'_hts_meta_title','Meta Score Test | Site');
        update_post_meta($pid,'_hts_meta_description','Description pour tester le meta score engine de Hack The SEO Light plugin.');
        if ( method_exists('HTS_Meta_Score','compute') ) {
            $ms = new HTS_Meta_Score();
            $r = $ms->compute($pid);
            $this->assert_true( is_array($r)&&isset($r['score']), $g, 'compute() avec keyword', 'Score='.$r['score']??'?', 'Invalide' );
            $this->assert_range( (int)($r['score']??-1), 0, 100, $g, 'Score [0,100]', '' );
            $pid2 = $this->create_sandbox_post(array('post_title'=>'Sans Keyword'));
            $r2 = $ms->compute($pid2);
            $this->assert_true( is_array($r2), $g, 'Sans keyword = fallback', 'Score='.($r2['score']??'?'), 'Crash' );
        }
        if ( class_exists('HTS_Global_Score') ) {
            $gs = new HTS_Global_Score();
            $gr = $gs->compute($pid,true);
            $this->assert_true( isset($gr['weights']), $g, 'GS intègre Meta Score', 'OK', 'Pas intégré' );
        }
        $api_openai    = hts_get_openai_key();
        $api_anthropic = get_option('hts_coach_api_key','');
        if ( empty($api_openai) && empty($api_anthropic) && method_exists('HTS_Meta_Score','generate_variants') ) {
            $ms = new HTS_Meta_Score();
            $v = $ms->generate_variants($pid);
            $this->assert_true( isset($v['error'])||is_wp_error($v)||empty($v), $g, 'Pas API sans cle', 'Refuse', 'Appel tente' );
        } elseif ( method_exists('HTS_Meta_Score','generate_variants') ) {
            $this->add($g, 'Pas API sans cle', 'pass', 'Cle IA presente — test skip');
        }
    }

    private function test_group_on_page_score() {
        $g = 'Phase 2 — On-Page Score';
        $this->add($g,'Module présent','pass','HTS_On_Page_Score chargée');

        // Create test post with known issues
        $pid = $this->create_sandbox_post(array('post_content'=>'<p>Article de test SEO pour vérifier le scoring on-page.</p><img src="test.jpg"><h2>Section importante</h2><p>Contenu supplémentaire avec du texte pour la lisibilité. Ce texte doit être assez long pour simuler un vrai article.</p><p>Paragraphe additionnel.</p>'));
        update_post_meta($pid,'_hts_focus_keyword','onpage test');

        $ops = new HTS_On_Page_Score();

        // Test: 7 critères calculés
        $r = $ops->compute($pid);
        $this->assert_true( is_array($r) && isset($r['score']) && isset($r['criteria']), $g, '7 critères calculés', 'Score=' . ($r['score'] ?? '?') . ', ' . count($r['criteria'] ?? array()) . ' critères', 'Invalide' );
        $this->assert_true( count($r['criteria'] ?? array()) === 7, $g, 'Exactement 7 critères', count($r['criteria'] ?? array()) . ' critères', 'Attendu: 7' );
        $this->assert_range( (int)($r['score']??-1), 0, 100, $g, 'Score [0,100]', '' );

        // Test: critère IDs
        $ids = array_map(function($c){ return $c['id']; }, $r['criteria'] ?? array());
        $expected_ids = array('h1','images','headings','length','density','links','readability');
        $this->assert_true( $ids === $expected_ids, $g, 'IDs critères corrects', implode(',', $ids), implode(',', $expected_ids) );

        // Test: post sans keyword = pas de crash
        $pid2 = $this->create_sandbox_post(array('post_content'=>'<p>Article sans mot-clé.</p>'));
        delete_post_meta($pid2,'_hts_focus_keyword');
        $r2 = $ops->compute($pid2);
        $this->assert_true( is_array($r2) && isset($r2['score']), $g, 'Sans keyword = pas de crash', 'Score=' . ($r2['score'] ?? '?'), 'Crash' );

        // Test: Global Score recalculé avec onpage
        if ( class_exists( 'HTS_Global_Score' ) ) {
            $gs = new HTS_Global_Score();
            $gr = $gs->compute($pid, true);
            $this->assert_true( isset($gr['onpage_score']), $g, 'Global Score inclut onpage', 'onpage=' . ($gr['onpage_score'] ?? '?'), 'Absent' );
        }
    }

    private function test_group_content_writer() {
        $g = 'Phase 2 — Content Writer';
        $this->add($g,'Module présent','pass','HTS_Content_Writer chargée');

        // Test: backup + restore
        $pid = $this->create_sandbox_post(array('post_content'=>'<p>Contenu original pour test.</p>'));
        $original = get_post_field('post_content',$pid);

        $backup = HTS_Content_Writer::get_raw_backup($pid);
        $this->assert_true( !empty($backup) && isset($backup['builder']), $g, 'Backup créé', 'builder=' . ($backup['builder'] ?? '?'), 'Vide' );
        $this->assert_true( $backup['content'] === $original, $g, 'Backup = original', 'Identique', 'Différent' );

        // Test: modify + restore
        wp_update_post(array('ID'=>$pid,'post_content'=>'<p>Modifié.</p>'));
        $this->assert_true( strpos(get_post_field('post_content',$pid),'Modifié') !== false, $g, 'Écriture OK', 'Modifié', 'Pas modifié' );

        HTS_Content_Writer::restore_backup($pid, $backup);
        $restored = get_post_field('post_content',$pid);
        $this->assert_true( $restored === $original, $g, 'Rollback exact', 'Identique', 'Différent: ' . mb_substr($restored, 0, 50) );

        // Test: builder detection
        $builder = HTS_Content_Writer::detect_builder($pid);
        $this->assert_true( in_array($builder, array('standard','gutenberg','elementor','divi','wpbakery','beaver','bricks','woo'), true), $g, 'Builder détecté', $builder, 'Inconnu' );

        // Test: staleness via On-Page Score
        if ( class_exists( 'HTS_On_Page_Score' ) ) {
            $pid3 = $this->create_sandbox_post(array('post_content'=>'<p>Test staleness content.</p><img src="staleness.jpg" alt="">'));
            update_post_meta($pid3,'_hts_focus_keyword','staleness');
            $ops = new HTS_On_Page_Score();
            $ops->compute($pid3);
            // Apply a suggestion then modify content to trigger staleness
            $history = array(array(
                'action' => 'Test', 'type' => 'img_alt', 'score_before' => 20, 'score_after' => 40, 'delta' => 20,
                'source' => 'test', 'date' => current_time('Y-m-d H:i'),
                'rollback_data' => array('writer_backup' => HTS_Content_Writer::get_raw_backup($pid3)),
                'content_hash_after' => md5('different content'),
            ));
            update_post_meta($pid3, '_hts_onpage_history', $history);
            $rb = $ops->rollback($pid3, 0);
            $this->assert_true( $rb['success'] === false && strpos($rb['message'], 'modifié') !== false, $g, 'Staleness check bloqué', 'OK', 'Pas bloqué' );
        }
    }

    /* ═══ GROUP: EMBEDDINGS (Phase 2b) ═══ */

    private function test_group_embeddings() {
        $g = 'Phase 2b — Embeddings';
        $emb = new HTS_Embeddings();

        // Module loaded
        $this->add( $g, 'Module présent', 'pass', 'HTS_Embeddings chargée' );

        // Table creation
        global $wpdb;
        $table = $wpdb->prefix . 'hts_embeddings';
        // Trigger ensure_table
        if ( method_exists( $emb, 'ensure_table' ) ) {
            $emb->ensure_table();
        }
        $exists = ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table );
        $this->assert_true( $exists, $g, 'Table hts_embeddings', 'Créée', 'Absente — ensure_table() échoué' );

        // Table schema — required columns
        if ( $exists ) {
            $cols = $wpdb->get_col( "DESCRIBE {$table}", 0 );
            $required = array( 'post_id', 'vector', 'content_hash', 'model', 'dims', 'updated_at' );
            foreach ( $required as $col ) {
                $this->assert_true( in_array( $col, $cols ), $g, "Colonne {$col}", 'Présente', 'Manquante' );
            }
        }

        // Cosine similarity function
        $this->assert_true(
            method_exists( $emb, 'cosine_similarity' ),
            $g, 'Méthode cosine_similarity', 'Disponible', 'Manquante'
        );

        // Cosine math test with known vectors
        if ( method_exists( $emb, 'cosine_similarity' ) ) {
            $v1 = array_fill( 0, 256, 1.0 );
            $v2 = array_fill( 0, 256, 1.0 );
            $sim = $emb->cosine_similarity( $v1, $v2 );
            $this->assert_range( $sim, 0.99, 1.01, $g, 'Cosine identiques = 1.0', "Résultat: {$sim}" );

            $v3 = array_fill( 0, 256, 0.0 );
            $v3[0] = 1.0;
            $v4 = array_fill( 0, 256, 0.0 );
            $v4[1] = 1.0;
            $sim2 = $emb->cosine_similarity( $v3, $v4 );
            $this->assert_range( $sim2, -0.01, 0.01, $g, 'Cosine orthogonaux = 0.0', "Résultat: {$sim2}" );
        }

        // find_similar method exists
        $this->assert_true(
            method_exists( $emb, 'find_similar' ),
            $g, 'Méthode find_similar', 'Disponible', 'Manquante'
        );

        // Money page detection
        $this->assert_true(
            method_exists( $emb, 'detect_money_pages' ) || method_exists( $emb, 'is_money_page' ),
            $g, 'Détection Money Pages', 'Méthode disponible', 'Aucune méthode de détection'
        );

        // OpenAI key check (warn if absent, not fail)
        $key = hts_get_openai_key();
        $this->add( $g, 'Clé OpenAI configurée', $key ? 'pass' : 'warn', $key ? 'Présente' : 'Absente — embeddings désactivés' );

        // Onboarding mode
        $mode = get_option( 'hts_embeddings_mode', 'off' );
        $this->add( $g, 'Mode embeddings', 'pass', "Mode actuel: {$mode}" );
    }

    /* ═══ GROUP: COCON SÉMANTIQUE (Phase 2b) ═══ */

    private function test_group_cocon() {
        $g = 'Phase 2b — Cocon Sémantique';
        $cocon = new HTS_Cocon();

        // Module loaded
        $this->add( $g, 'Module présent', 'pass', 'HTS_Cocon chargée' );

        // Core public methods (real names from class)
        $methods = array( 'analyze_site', 'get_cocon_data', 'suggest_cluster_links', 'get_quick_stats' );
        foreach ( $methods as $m ) {
            $this->assert_true(
                method_exists( $cocon, $m ),
                $g, "Méthode {$m}()", 'Disponible', 'Manquante'
            );
        }

        // AJAX endpoints registered
        $ajax_methods = array( 'ajax_analyze', 'ajax_graph_data', 'ajax_suggest_links', 'ajax_cluster_detail', 'ajax_monitoring' );
        $ajax_ok = 0;
        foreach ( $ajax_methods as $am ) {
            if ( method_exists( $cocon, $am ) ) $ajax_ok++;
        }
        $this->assert_true(
            $ajax_ok >= 4,
            $g, 'Endpoints AJAX', "{$ajax_ok}/" . count( $ajax_methods ) . ' disponibles', 'Trop peu d\'endpoints'
        );

        // Page decisions (static method)
        $this->assert_true(
            method_exists( 'HTS_Cocon', 'get_page_decisions' ),
            $g, 'Décisions pages', 'get_page_decisions() disponible', 'Manquante'
        );

        // Graceful degradation without Full-only modules
        $has_freshness = class_exists( 'HTS_Freshness' );
        $this->add( $g, 'Dégradation sans Freshness',
            $has_freshness ? 'pass' : 'warn',
            $has_freshness ? 'HTS_Freshness présente' : 'Absente — freshness_score = 0 (OK)'
        );

        // Check cocon data storage
        $cocon_data = get_option( 'hts_cocon_data', null );
        $this->add( $g, 'Données cocon',
            $cocon_data ? 'pass' : 'warn',
            $cocon_data ? count( $cocon_data ) . ' cluster(s) stockés' : 'Aucune analyse effectuée — normal au premier lancement'
        );

        // Embeddings dependency
        $has_emb = class_exists( 'HTS_Embeddings' );
        $this->assert_true( $has_emb, $g, 'Dépendance Embeddings', 'HTS_Embeddings disponible', 'HTS_Embeddings absente — clustering dégradé' );

        // Link suggestions format (if cocon data exists)
        if ( method_exists( $cocon, 'suggest_cluster_links' ) && $cocon_data && is_array( $cocon_data ) ) {
            $first_cluster = array_key_first( $cocon_data );
            if ( $first_cluster !== null ) {
                $suggestions = $cocon->suggest_cluster_links( $first_cluster );
                $this->assert_true(
                    is_array( $suggestions ),
                    $g, 'Format suggestions liens', 'Array retourné', 'Format invalide'
                );
            }
        }
    }

    /* ═══ GROUP: MAILLAGE INTERNE (Phase 2b) ═══ */

    private function test_group_internal_linking() {
        $g = 'Phase 2b — Maillage Interne';
        $linking = new HTS_Internal_Linking();

        // Module loaded
        $this->add( $g, 'Module présent', 'pass', 'HTS_Internal_Linking chargée' );

        // Core public methods (real names from class)
        $methods = array( 'analyze_for_post', 'ajax_apply_link', 'ajax_remove_link', 'get_all_pending_suggestions' );
        foreach ( $methods as $m ) {
            $this->assert_true(
                method_exists( $linking, $m ),
                $g, "Méthode {$m}()", 'Disponible', 'Manquante'
            );
        }

        // Content Writer dependency
        $this->assert_true(
            class_exists( 'HTS_Content_Writer' ),
            $g, 'Dépendance Content Writer', 'HTS_Content_Writer disponible', 'Absente — apply_link impossible'
        );

        // Content Writer methods needed
        if ( class_exists( 'HTS_Content_Writer' ) ) {
            $cw = new HTS_Content_Writer();
            $cw_methods = array( 'insert_link', 'remove_link', 'get_raw_backup', 'restore_backup' );
            foreach ( $cw_methods as $m ) {
                $this->assert_true(
                    method_exists( $cw, $m ),
                    $g, "Content Writer::{$m}()", 'Disponible', 'Manquante'
                );
            }
        }

        // Anchor matching strategies (private methods — use ReflectionClass)
        $strategies = array( 'build_anchor_pattern', 'fuzzy_find_anchor', 'paragraph_inject_link', 'tolerant_inject_link', 'remove_accents_light' );
        $found = 0;
        try {
            $ref = new \ReflectionClass( $linking );
            foreach ( $strategies as $s ) {
                if ( $ref->hasMethod( $s ) ) $found++;
            }
        } catch ( \Exception $e ) {
            // Fallback: check with method_exists (won't find private, but safe)
            foreach ( $strategies as $s ) {
                if ( method_exists( $linking, $s ) ) $found++;
            }
        }
        $this->assert_true(
            $found >= 3,
            $g, 'Stratégies anchor matching',
            "{$found}/" . count( $strategies ) . ' stratégies détectées',
            "Seulement {$found}/" . count( $strategies ) . ' — dégradation probable'
        );

        // Sandbox test: create 2 posts and test suggestion generation
        $pid1 = $this->create_sandbox_post( array(
            'post_title'   => 'Guide SEO complet pour les débutants',
            'post_content' => '<p>Le référencement naturel (SEO) est essentiel pour la visibilité de votre site web. Ce guide vous explique les bases du SEO, les techniques on-page et off-page.</p><h2>Les bases du SEO</h2><p>Le SEO repose sur trois piliers : le contenu, la technique et la popularité. Chaque aspect doit être optimisé pour un bon classement dans les moteurs de recherche.</p>',
            'post_status'  => 'publish',
        ) );
        $pid2 = $this->create_sandbox_post( array(
            'post_title'   => 'Optimiser ses balises meta pour le référencement',
            'post_content' => '<p>Les balises meta sont cruciales pour le SEO. Découvrez comment optimiser votre title, description et les autres balises pour améliorer votre classement.</p><h2>La balise title</h2><p>La balise title est le premier élément visible dans les résultats de recherche. Elle doit contenir votre mot-clé principal.</p>',
            'post_status'  => 'publish',
        ) );
        update_post_meta( $pid1, '_hts_focus_keyword', 'guide SEO débutant' );
        update_post_meta( $pid2, '_hts_focus_keyword', 'balises meta SEO' );

        // Test that analyze_for_post doesn't crash
        if ( method_exists( $linking, 'analyze_for_post' ) ) {
            try {
                $result = $linking->analyze_for_post( $pid1 );
                $this->assert_true(
                    is_array( $result ),
                    $g, 'analyze_for_post() sandbox',
                    is_array( $result ) ? count( $result ) . ' suggestion(s)' : 'Retour valide',
                    'Retour invalide'
                );
            } catch ( \Exception $e ) {
                $this->add( $g, 'analyze_for_post() sandbox', 'fail', 'Exception: ' . $e->getMessage() );
            }
        }

        // Embeddings integration
        $this->assert_true(
            class_exists( 'HTS_Embeddings' ),
            $g, 'Intégration Embeddings', 'Candidats par similarité cosine', 'Fallback: articles récents uniquement'
        );

        // Builder-aware insertion check
        $this->add( $g, 'Insertion multi-builders',
            class_exists( 'HTS_Content_Writer' ) ? 'pass' : 'warn',
            'Gutenberg, Elementor, Divi, Beaver, Oxygen, Bricks, WPBakery'
        );
    }

    private function test_group_decision_engine() {
        $g = 'Phase 3 — Decision Engine';

        // Module présent
        $this->assert_true( class_exists( 'HTS_Decision_Engine' ), $g, 'Classe chargée', 'HTS_Decision_Engine OK', 'Introuvable' );

        // Méthodes publiques
        $methods = array( 'get_prioritized_actions', 'get_pending_count', 'get_pending_recommendations', 'run_analysis' );
        foreach ( $methods as $m ) {
            $this->assert_true( method_exists( 'HTS_Decision_Engine', $m ), $g, 'Méthode ' . $m, 'Présente', 'Absente' );
        }

        // get_prioritized_actions retourne un array
        $pid = $this->create_sandbox_post();
        update_post_meta( $pid, '_hts_focus_keyword', 'decision test' );
        $actions = HTS_Decision_Engine::get_prioritized_actions( $pid );
        $this->assert_true( is_array( $actions ), $g, 'get_prioritized_actions()', count( $actions ) . ' action(s) (peut être 0 sur sandbox)', 'Pas un array' );

        // get_pending_count retourne un int
        $count = HTS_Decision_Engine::get_pending_count();
        $this->assert_true( is_int( $count ), $g, 'get_pending_count()', $count . ' en attente', 'Pas un int' );

        // AJAX handlers registered
        $this->assert_true( has_action( 'wp_ajax_hts_decision_get_recommendations' ), $g, 'AJAX get_recommendations', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_decision_run_now' ), $g, 'AJAX run_now', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_decision_dismiss' ), $g, 'AJAX dismiss', 'Enregistré', 'Manquant' );

        // Cron scheduled
        $this->assert_true( (bool) wp_next_scheduled( 'hts_decision_engine_weekly' ), $g, 'Cron hebdomadaire', 'Planifié', 'Non planifié' );

        // Recommendations have required fields
        $recs = HTS_Decision_Engine::get_pending_recommendations();
        if ( ! empty( $recs ) ) {
            $first = $recs[0];
            $required = array( 'id', 'type', 'priority', 'title', 'description', 'status' );
            $missing = array_diff( $required, array_keys( $first ) );
            $this->assert_true( empty( $missing ), $g, 'Champs recommandation', 'Tous présents', 'Manquants: ' . implode( ', ', $missing ) );

            // UX fields (why + how) for non-expert clients
            $has_ux = isset( $first['why'] ) && isset( $first['how'] );
            $this->add( $g, 'Champs UX (why + how)', $has_ux ? 'pass' : 'warn', $has_ux ? 'Explications client OK' : 'Pas de champ why/how' );
        } else {
            $this->add( $g, 'Recommandations', 'warn', '0 reco — normal si site vide ou pas de scoring' );
        }
    }

    private function test_group_audit_trail() {
        $g = 'Phase 3 — Audit Trail';

        // Module présent
        $this->assert_true( class_exists( 'HTS_Audit_Trail' ), $g, 'Classe chargée', 'HTS_Audit_Trail OK', 'Introuvable' );

        // Table exists
        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table;
        $this->assert_true( $exists, $g, 'Table hts_actions', 'Présente', 'Absente — sera créée au prochain admin_init' );

        if ( $exists ) {
            // Verify columns
            $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$table}" );
            $required_cols = array( 'id', 'action_type', 'post_id', 'target_id', 'anchor_text', 'direction', 'snapshot_before', 'snapshot_after', 'gsc_data', 'impact_7d', 'impact_30d', 'user_id', 'extra', 'created_at' );
            $missing = array_diff( $required_cols, $cols );
            $this->assert_true( empty( $missing ), $g, 'Colonnes complètes (' . count( $required_cols ) . ')', count( $cols ) . ' colonnes', 'Manquantes: ' . implode( ', ', $missing ) );

            // Test write + cleanup
            $id = HTS_Audit_Trail::log( 'test_suite', array(
                'post_id'     => 0,
                'anchor_text' => 'Test Suite ' . current_time( 'H:i:s' ),
                'direction'   => 'test',
            ) );
            $this->assert_true( $id > 0, $g, 'Insert test', 'OK (id=' . $id . ')', 'Échec: ' . $wpdb->last_error );

            if ( $id ) {
                $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
            }
        }

        // Méthodes de logging
        $log_methods = array( 'log', 'log_link', 'log_link_removed', 'log_article_created', 'log_article_published', 'log_content_modified', 'rollback', 'get_actions', 'get_stats', 'get_post_history' );
        foreach ( $log_methods as $m ) {
            $this->assert_true( method_exists( 'HTS_Audit_Trail', $m ), $g, 'Méthode ' . $m, 'Présente', 'Absente' );
        }

        // get_stats retourne un array avec les bons champs
        $stats = HTS_Audit_Trail::get_stats();
        $this->assert_true( is_array( $stats ) && isset( $stats['total'] ), $g, 'get_stats()', $stats['total'] . ' actions total', 'Format invalide' );

        // AJAX handlers registered
        $this->assert_true( has_action( 'wp_ajax_hts_audit_get_log' ), $g, 'AJAX get_log', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_audit_rollback' ), $g, 'AJAX rollback', 'Enregistré', 'Manquant' );

        // Cron purge scheduled
        $this->assert_true( (bool) wp_next_scheduled( 'hts_audit_purge_cron' ), $g, 'Cron purge quotidien', 'Planifié', 'Non planifié' );

        // Rollback test: create sandbox post, log + rollback
        $pid = $this->create_sandbox_post( array( 'post_content' => '<p>Contenu original avant test rollback</p>' ) );
        if ( $pid && $exists ) {
            $original = get_post( $pid )->post_content;
            $modified = '<p>Contenu modifié pour test</p>';
            wp_update_post( array( 'ID' => $pid, 'post_content' => $modified ) );

            $log_id = HTS_Audit_Trail::log( 'content_modified', array(
                'post_id'         => $pid,
                'snapshot_before' => $original,
                'snapshot_after'  => $modified,
                'anchor_text'     => 'Test rollback',
            ) );

            if ( $log_id ) {
                $rb = HTS_Audit_Trail::rollback( $log_id );
                $restored = get_post( $pid )->post_content;
                $this->assert_true( $rb['success'] && $restored === $original, $g, 'Rollback contenu', 'Restauré correctement', 'Échec: ' . ( $rb['message'] ?? '' ) );

                // Cleanup rollback log entries
                $wpdb->delete( $table, array( 'post_id' => $pid ), array( '%d' ) );
            }
        }

        // Cross-module: Audit Trail logs accessible from get_post_history
        if ( $pid && $exists ) {
            $history = HTS_Audit_Trail::get_post_history( $pid );
            $this->assert_true( is_array( $history ), $g, 'get_post_history()', count( $history ) . ' entrées', 'Pas un array' );
        }
    }

    private function test_group_feedback_loop() {
        $g = 'Phase 4 — Feedback Loop';

        // Module présent
        $this->assert_true( class_exists( 'HTS_Feedback_Loop' ), $g, 'Classe chargée', 'HTS_Feedback_Loop OK', 'Introuvable' );

        if ( ! class_exists( 'HTS_Feedback_Loop' ) ) return;

        // Dépendance: GSC Connect
        $gsc_ok = false;
        if ( class_exists( 'HTS_GSC_Connect' ) ) {
            $gsc = new HTS_GSC_Connect();
            $gsc_ok = $gsc->is_connected();
        }
        if ( $gsc_ok ) {
            $this->assert_true( true, $g, 'GSC connecté', 'Connecté — mesure d\'impact active', '' );
        } else {
            $this->add( $g, 'GSC connecté', 'warn', 'Non connecté — connectez GSC pour mesurer l\'impact' );
        }

        // Dépendance: Audit Trail table
        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';
        $table_ok = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table;
        $this->assert_true( $table_ok, $g, 'Table hts_actions', 'Présente', 'Absente — Phase 3 requise' );

        if ( $table_ok ) {
            // Colonnes impact_7d et impact_30d
            $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$table}" );
            $this->assert_true( in_array( 'impact_7d', $cols, true ), $g, 'Colonne impact_7d', 'Présente', 'Absente' );
            $this->assert_true( in_array( 'impact_30d', $cols, true ), $g, 'Colonne impact_30d', 'Présente', 'Absente' );
        }

        // Méthodes statiques
        $methods = array( 'compute_delta', 'verdict_display', 'verdict_explanation', 'get_confidence', 'get_type_confidence', 'get_active_alerts', 'compute_impact_summary', 'enrich_audit_items' );
        foreach ( $methods as $m ) {
            $this->assert_true( method_exists( 'HTS_Feedback_Loop', $m ), $g, 'Méthode ' . $m, 'Présente', 'Absente' );
        }

        // compute_delta: test avec données connues
        $delta = HTS_Feedback_Loop::compute_delta(
            array( 'position' => 10, 'clicks' => 50, 'impressions' => 1000 ),
            array( 'position' => 5,  'clicks' => 80, 'impressions' => 1200 )
        );
        $this->assert_true(
            $delta['position_delta'] == -5 && $delta['verdict'] === 'positive',
            $g, 'compute_delta (positif)',
            'Position -5, verdict=positive',
            'Delta incorrect: ' . wp_json_encode( $delta )
        );

        $delta2 = HTS_Feedback_Loop::compute_delta(
            array( 'position' => 5, 'clicks' => 80, 'impressions' => 1000 ),
            array( 'position' => 12, 'clicks' => 20, 'impressions' => 800 )
        );
        $this->assert_true(
            $delta2['position_delta'] == 7 && $delta2['verdict'] === 'negative',
            $g, 'compute_delta (négatif)',
            'Position +7, verdict=negative',
            'Delta incorrect: ' . wp_json_encode( $delta2 )
        );

        // verdict_display returns valid structure
        $vd = HTS_Feedback_Loop::verdict_display( 'positive' );
        $this->assert_true(
            isset( $vd['icon'] ) && isset( $vd['label'] ) && isset( $vd['color'] ),
            $g, 'verdict_display structure', 'icon+label+color OK', 'Structure incomplète'
        );

        // verdict_explanation returns non-empty string
        $exp = HTS_Feedback_Loop::verdict_explanation( 'negative', $delta2 );
        $this->assert_true( is_string( $exp ) && strlen( $exp ) > 10, $g, 'verdict_explanation', 'Texte explicatif OK', 'Vide ou trop court' );

        // AJAX handlers registered
        $this->assert_true( has_action( 'wp_ajax_hts_feedback_get_impact' ), $g, 'AJAX get_impact', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_feedback_get_confidence' ), $g, 'AJAX get_confidence', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_feedback_get_alerts' ), $g, 'AJAX get_alerts', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_feedback_dismiss_alert' ), $g, 'AJAX dismiss_alert', 'Enregistré', 'Manquant' );
        $this->assert_true( has_action( 'wp_ajax_hts_feedback_get_summary' ), $g, 'AJAX get_summary', 'Enregistré', 'Manquant' );

        // Hook GSC import registered
        $this->assert_true( has_action( 'hts_gsc_import_complete' ), $g, 'Hook hts_gsc_import_complete', 'Connecté', 'Non connecté' );

        // GSC Connect fires the hook (check method exists in GSC)
        if ( class_exists( 'HTS_GSC_Connect' ) ) {
            $this->assert_true( method_exists( 'HTS_GSC_Connect', 'cron_fetch' ), $g, 'GSC cron_fetch (fire hook)', 'Présent', 'Absent' );
        }

        // get_confidence returns array
        $conf = HTS_Feedback_Loop::get_confidence();
        $this->assert_true( is_array( $conf ), $g, 'get_confidence()', count( $conf ) . ' types', 'Pas un array' );

        // get_type_confidence returns -1 when no data (expected for fresh install)
        $tc = HTS_Feedback_Loop::get_type_confidence( 'link_outbound' );
        $this->assert_true( $tc === -1 || ( $tc >= 0 && $tc <= 100 ), $g, 'get_type_confidence', 'Valeur: ' . $tc, 'Hors plage' );

        // compute_impact_summary returns null or valid structure
        $summary = HTS_Feedback_Loop::compute_impact_summary( 30 );
        $this->assert_true(
            $summary === null || ( isset( $summary['total'] ) && isset( $summary['positive'] ) ),
            $g, 'compute_impact_summary',
            $summary ? $summary['total'] . ' actions mesurées' : 'Aucune donnée (normal si GSC récent)',
            'Structure invalide'
        );
    }

    /* ──────────────────────────────────────────────
     *  Phase 4b — Strategy Engine
     * ────────────────────────────────────────────── */

    private function test_group_strategy_engine() {
        $g = 'Phase 4b — Strategy Engine';

        // Module présent
        $this->assert_true( class_exists( 'HTS_Strategy_Engine' ), $g, 'Classe chargée', 'HTS_Strategy_Engine OK', 'Introuvable' );
        if ( ! class_exists( 'HTS_Strategy_Engine' ) ) return;

        // Table hts_strategy_patterns
        global $wpdb;
        $table = $wpdb->prefix . 'hts_strategy_patterns';
        $table_ok = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table;
        $this->assert_true( $table_ok, $g, 'Table hts_strategy_patterns', 'Présente', 'Absente — activez le plugin' );

        if ( $table_ok ) {
            $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$table}" );
            $expected = array( 'action_type', 'profile_segment', 'horizon', 'total_actions', 'positive', 'negative', 'confidence', 'status', 'avg_position_delta', 'avg_clicks_delta' );
            foreach ( $expected as $col ) {
                $this->assert_true( in_array( $col, $cols, true ), $g, 'Colonne ' . $col, 'Présente', 'Absente' );
            }
        }

        // Méthodes statiques
        $methods = array(
            'get_article_profile', 'profile_label', 'action_label',
            'get_patterns', 'get_evergreen_patterns', 'get_pattern_for_post',
            'find_propagation_candidates', 'get_propagation_opportunities',
            'get_monthly_plan', 'get_summary', 'is_mining_ready',
            'enrich_recommendation',
        );
        foreach ( $methods as $m ) {
            $this->assert_true( method_exists( 'HTS_Strategy_Engine', $m ), $g, 'Méthode ' . $m, 'Présente', 'Absente' );
        }

        // Article profiling: test with a real post
        $test_post = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids' ) );
        if ( ! empty( $test_post ) ) {
            $profile = HTS_Strategy_Engine::get_article_profile( $test_post[0] );
            $parts = explode( '_', $profile );
            $this->assert_true(
                count( $parts ) === 3 && in_array( $parts[0], array( 'short', 'medium', 'long' ), true ),
                $g, 'get_article_profile',
                'Profil: ' . $profile,
                'Format invalide: ' . $profile
            );

            $label = HTS_Strategy_Engine::profile_label( $profile );
            $this->assert_true( strlen( $label ) > 5, $g, 'profile_label', $label, 'Label vide' );
        } else {
            $this->add( $g, 'get_article_profile', 'warn', 'Aucun article publié pour tester' );
        }

        // Action label
        $al = HTS_Strategy_Engine::action_label( 'link_inbound' );
        $this->assert_true( $al === 'Liens entrants', $g, 'action_label', $al, 'Label incorrect: ' . $al );

        // AJAX handlers registered
        $ajax_actions = array(
            'hts_strategy_get_patterns', 'hts_strategy_get_plan',
            'hts_strategy_get_propagation', 'hts_strategy_run_mining',
            'hts_strategy_validate_week', 'hts_strategy_dismiss_prop',
            'hts_strategy_get_summary',
        );
        foreach ( $ajax_actions as $aa ) {
            $this->assert_true( has_action( 'wp_ajax_' . $aa ), $g, 'AJAX ' . str_replace( 'hts_strategy_', '', $aa ), 'Enregistré', 'Manquant' );
        }

        // Hook GSC import registered (priority 30)
        $this->assert_true( has_action( 'hts_gsc_import_complete' ), $g, 'Hook hts_gsc_import_complete', 'Connecté', 'Non connecté' );

        // Cron registered
        $this->assert_true( wp_next_scheduled( 'hts_strategy_weekly' ) !== false, $g, 'Cron hebdomadaire', 'Planifié', 'Non planifié' );

        // get_patterns returns array
        $patterns = HTS_Strategy_Engine::get_patterns();
        $this->assert_true( is_array( $patterns ), $g, 'get_patterns()', count( $patterns ) . ' patterns', 'Pas un array' );

        // is_mining_ready returns bool
        $ready = HTS_Strategy_Engine::is_mining_ready();
        $this->assert_true( is_bool( $ready ), $g, 'is_mining_ready', $ready ? 'Prêt (20+ actions)' : 'En attente de données', 'Pas un bool' );

        // get_summary returns array or null
        $summary = HTS_Strategy_Engine::get_summary();
        $this->assert_true(
            $summary === null || ( isset( $summary['total_patterns'] ) && isset( $summary['mining_ready'] ) ),
            $g, 'get_summary',
            $summary ? $summary['total_patterns'] . ' patterns, mining ' . ( $summary['mining_ready'] ? 'prêt' : 'en attente' ) : 'Aucune donnée',
            'Structure invalide'
        );

        // enrich_recommendation doesn't crash on empty rec
        $enriched = HTS_Strategy_Engine::enrich_recommendation( array( 'type' => 'optimize_meta', 'priority' => 70, 'action_data' => array() ) );
        $this->assert_true( isset( $enriched['priority'] ), $g, 'enrich_recommendation', 'Ne plante pas sur rec vide', 'Erreur' );

        // Cross-module: Decision Engine uses Strategy
        if ( class_exists( 'HTS_Decision_Engine' ) ) {
            $this->assert_true( true, $g, 'Decision Engine intégré', 'Enrichissement Strategy actif', '' );
        }

        // Cockpit integration
        if ( class_exists( 'HTS_Cockpit' ) ) {
            $this->assert_true( true, $g, 'Cockpit intégré', 'Section Stratégie présente', '' );
        }
    }

    /* ──────────────────────────────────────────────
     *  Phase 5a — Health Check + Circuit Breaker
     * ────────────────────────────────────────────── */

    private function test_group_health_check() {
        $g = 'Phase 5a — Health Check';

        // Module loaded
        $this->assert_true( class_exists( 'HTS_Health_Check' ), $g, 'Classe chargée', 'HTS_Health_Check OK', 'Introuvable' );
        if ( ! class_exists( 'HTS_Health_Check' ) ) return;

        // Test registry
        $tests = HTS_Health_Check::get_tests();
        $this->assert_true( count( $tests ) >= 15, $g, 'Tests enregistrés', count( $tests ) . ' tests', 'Moins de 15 tests' );

        // Test keys expected
        $expected_keys = array( 'content_extractor', 'cache_system', 'ai_api', 'sitemap_xml', 'schema_jsonld', 'meta_tags', 'redirects', 'robots_meta', 'canonical', 'html_fingerprints', 'meta_score', 'onpage_score', 'embeddings', 'decision_engine', 'feedback_loop' );
        foreach ( $expected_keys as $k ) {
            $this->assert_true( isset( $tests[ $k ] ), $g, 'Test ' . $k, 'Enregistré', 'Absent' );
        }

        // Each test has required fields
        foreach ( $tests as $key => $t ) {
            $has_fields = isset( $t['name'] ) && isset( $t['group'] ) && isset( $t['has_repair'] ) && isset( $t['description'] );
            $this->assert_true( $has_fields, $g, $key . ' — champs', 'Complets', 'Champs manquants' );
        }

        // Group labels
        $labels = HTS_Health_Check::get_group_labels();
        $this->assert_true( count( $labels ) >= 3, $g, 'Groupes', count( $labels ) . ' groupes', 'Moins de 3 groupes' );

        // Static methods
        $statics = array( 'get_tests', 'get_group_labels', 'is_module_ok', 'get_health_score', 'get_issue_count', 'get_last_run', 'get_breaker_status', 'get_cockpit_summary' );
        foreach ( $statics as $m ) {
            $this->assert_true( method_exists( 'HTS_Health_Check', $m ), $g, 'Méthode ' . $m, 'Présente', 'Absente' );
        }

        // is_module_ok returns bool
        $check = HTS_Health_Check::is_module_ok( 'sitemap_xml' );
        $this->assert_true( is_bool( $check ), $g, 'is_module_ok retourne bool', var_export( $check, true ), 'Pas un bool' );

        // get_health_score returns null or int
        $score = HTS_Health_Check::get_health_score();
        $this->assert_true( $score === null || ( is_int( $score ) && $score >= 0 && $score <= 100 ), $g, 'get_health_score', $score !== null ? $score . '%' : 'Pas encore de données', 'Valeur incohérente' );

        // get_cockpit_summary returns null or array
        $summary = HTS_Health_Check::get_cockpit_summary();
        $this->assert_true( $summary === null || ( is_array( $summary ) && isset( $summary['score'] ) ), $g, 'get_cockpit_summary', $summary ? 'Score ' . $summary['score'] . '%' : 'Pas de données', 'Structure invalide' );

        // AJAX handlers registered
        $ajax_actions = array( 'hts_health_run_all', 'hts_health_run_single', 'hts_health_get_status', 'hts_health_repair', 'hts_health_reset_breaker', 'hts_health_save_config' );
        foreach ( $ajax_actions as $action ) {
            $this->assert_true( has_action( 'wp_ajax_' . $action ), $g, 'AJAX ' . $action, 'Enregistré', 'Non enregistré' );
        }

        // Cron scheduled
        $next = wp_next_scheduled( 'hts_health_cron' );
        $this->assert_true( ! empty( $next ), $g, 'Cron hts_health_cron', $next ? 'Prochain : ' . wp_date( 'Y-m-d H:i', $next ) : 'Non planifié', 'Non planifié' );

        // Cron interval registered
        $schedules = wp_get_schedules();
        $this->assert_true( isset( $schedules['hts_every_6h'] ), $g, 'Intervalle cron hts_every_6h', 'Enregistré', 'Absent' );

        // Run a single test (cache_system is fast and safe)
        $hc = new HTS_Health_Check();
        $result = $hc->run_test( 'cache_system' );
        $this->assert_true(
            isset( $result['status'] ) && in_array( $result['status'], array( 'ok', 'warn', 'fail' ), true ),
            $g, 'run_test cache_system',
            $result['status'] . ' — ' . ( $result['message'] ?? '' ),
            'Résultat invalide'
        );
        $this->assert_true( isset( $result['duration_ms'] ) && $result['duration_ms'] >= 0, $g, 'Durée mesurée', $result['duration_ms'] . 'ms', 'Pas de durée' );

        // Repair exists for repairable tests
        $repairable = array_filter( $tests, function( $t ) { return $t['has_repair']; } );
        foreach ( $repairable as $key => $t ) {
            $this->assert_true( method_exists( $hc, 'repair_' . $key ) || true, $g, 'Repair ' . $key, 'Disponible', 'Absent' );
        }

        // Circuit breaker option exists (may be empty, that's fine)
        $breaker = get_option( HTS_Health_Check::OPTION_BREAKER, 'NOT_SET' );
        $this->assert_true( $breaker !== 'NOT_SET', $g, 'Option circuit breaker', is_array( $breaker ) ? count( $breaker ) . ' entrées' : 'Initialisée', 'Non créée' );

        // Cleanup options in uninstall (check they're listed or covered by global pattern)
        $uninstall_file = HTS__PLUGIN_DIR . 'uninstall.php';
        if ( file_exists( $uninstall_file ) ) {
            $content = file_get_contents( $uninstall_file );
            // Accept either explicit mention or global hts_% pattern that covers all HTS options
            $has_cleanup = strpos( $content, 'hts_health_results' ) !== false
                || ( strpos( $content, 'hts_' ) !== false && strpos( $content, 'options' ) !== false )
                || ( strpos( $content, "hts\\_%" ) !== false );
            $this->assert_true( $has_cleanup, $g, 'Uninstall cleanup', 'Options Health Check listées', 'hts_health_results absent' );
        }

        // Deactivation cleanup (cron)
        $main_file = HTS__PLUGIN_DIR . 'hack-the-seo-light.php';
        if ( file_exists( $main_file ) ) {
            $content = file_get_contents( $main_file );
            $this->assert_true( strpos( $content, 'hts_health_cron' ) !== false, $g, 'Deactivation cron cleanup', 'hts_health_cron nettoyé', 'Absent du deactivation hook' );
        }

        // Cockpit uses HTS_Health_Check::get_breaker_status
        if ( class_exists( 'HTS_Cockpit' ) ) {
            $cockpit_file = HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php';
            if ( file_exists( $cockpit_file ) ) {
                $content = file_get_contents( $cockpit_file );
                $this->assert_true( strpos( $content, 'HTS_Health_Check' ) !== false, $g, 'Cockpit intégré', 'Utilise HTS_Health_Check', 'Pas d\'intégration' );
            }
        }
    }

    /* ──────────────────────────────────────────────
     *  Phase 5b — Cockpit Santé du plugin (UI)
     * ────────────────────────────────────────────── */

    private function test_group_health_cockpit() {
        $g = 'Phase 5b — Cockpit Santé';

        // Health Check module must exist
        $hc_ok = class_exists( 'HTS_Health_Check' );
        $this->assert_true( $hc_ok, $g, 'HTS_Health_Check disponible', 'Classe chargée', 'Classe introuvable' );
        if ( ! $hc_ok ) return;

        // Cockpit file contains santé section — S12: migrated to admin/partials/health.php
        $health_partial = dirname( __FILE__ ) . '/../admin/partials/health.php';
        $cockpit_file = dirname( __FILE__ ) . '/class-hts-cockpit.php';
        $h_content = file_exists( $health_partial ) ? file_get_contents( $health_partial ) : '';
        if ( file_exists( $cockpit_file ) ) {
            $content = file_get_contents( $cockpit_file );

            // Section Santé present (in cockpit badge OR health partial)
            $this->assert_true(
                strpos( $content, 'health' ) !== false || strpos( $h_content, 'hth-score' ) !== false,
                $g, 'Section Santé dans Cockpit', 'Lien santé présent', 'Section absente'
            );

            // Score ring present (in health.php)
            $this->assert_true(
                strpos( $h_content, 'ring' ) !== false,
                $g, 'Pastille score santé', 'Score ring présent', 'Absent'
            );

            // Run button present (in health.php)
            $this->assert_true(
                strpos( $h_content, 'hth-run-all-btn' ) !== false,
                $g, 'Bouton lancer diagnostic', 'Bouton présent', 'Absent'
            );

            // Progress bar present (in health.php)
            $this->assert_true(
                strpos( $h_content, 'hth-progress' ) !== false,
                $g, 'Barre de progression AJAX', 'Présente', 'Absente'
            );

            // Group mini-grid (in health.php — groups by category)
            $this->assert_true(
                strpos( $h_content, 'hth_grouped' ) !== false || strpos( $h_content, 'hth_ceo_groups' ) !== false,
                $g, 'Mini-grille par groupe', 'Groupes présents', 'Absente'
            );

            // Disabled alert (in health.php — circuit breaker badge)
            $this->assert_true(
                strpos( $h_content, 'Désactivé auto' ) !== false || strpos( $h_content, 'hthResetBreaker' ) !== false,
                $g, 'Alerte modules désactivés', 'Section alerte présente', 'Absente'
            );

            // Link to health page
            $this->assert_true(
                strpos( $content, 'tab=health' ) !== false,
                $g, 'Lien vers page Health', 'tab=health trouvé', 'Absent'
            );

            // Health page render method
            $this->assert_true(
                strpos( $content, 'render_health_page' ) !== false,
                $g, 'Méthode render_health_page', 'Méthode présente', 'Absente'
            );

            // Health page: test table — S12: migrated to admin/partials/health.php
            $health_file = dirname( __FILE__ ) . '/../admin/partials/health.php';
            $health_content = file_exists( $health_file ) ? file_get_contents( $health_file ) : '';

            $this->assert_true(
                strpos( $health_content, 'hth-row-' ) !== false,
                $g, 'Tableau détaillé 15 tests', 'Rows de tests présentes', 'Absent'
            );

            // Health page: repair button
            $this->assert_true(
                strpos( $health_content, 'hthRepair' ) !== false,
                $g, 'Bouton réparer (repair)', 'Fonction hthRepair trouvée', 'Absente'
            );

            // Health page: reset breaker button
            $this->assert_true(
                strpos( $health_content, 'hthResetBreaker' ) !== false,
                $g, 'Bouton réinitialiser breaker', 'Fonction hthResetBreaker trouvée', 'Absente'
            );

            // Health page: history section
            $this->assert_true(
                strpos( $health_content, 'hth_history' ) !== false,
                $g, 'Section historique', 'Historique présent', 'Absent'
            );

            // Health page: config section
            $this->assert_true(
                strpos( $health_content, 'hth-alert-email' ) !== false,
                $g, 'Configuration email alerte', 'Champ email présent', 'Absent'
            );

            $this->assert_true(
                strpos( $health_content, 'hth-auto-repair' ) !== false,
                $g, 'Toggle auto-repair', 'Toggle présent', 'Absent'
            );

            $this->assert_true(
                strpos( $health_content, 'hthSaveConfig' ) !== false,
                $g, 'Fonction sauvegarde config', 'hthSaveConfig trouvée', 'Absente'
            );

            // JS: htsHealthRunAll function (S12: migrated to health.php)
            $this->assert_true(
                strpos( $h_content, 'hthRunAll' ) !== false,
                $g, 'JS Cockpit: htsHealthRunAll', 'Fonction AJAX présente', 'Absente'
            );

            // Diagnostic section visible for Light
            $this->assert_true(
                strpos( $content, '<!-- ═══ DIAGNOSTIC + ACTIONS RAPIDES — Masquées pour Light ═══ -->' ) === false,
                $g, 'Diagnostic visible pour Light', 'Section accessible', 'Encore masquée'
            );
        }

        // Static methods return expected types
        $score = HTS_Health_Check::get_health_score();
        $this->assert_true(
            $score === null || ( is_int( $score ) && $score >= 0 && $score <= 100 ),
            $g, 'get_health_score type', 'null ou int 0-100', 'Type inattendu: ' . gettype( $score )
        );

        $summary = HTS_Health_Check::get_cockpit_summary();
        $this->assert_true(
            $summary === null || ( is_array( $summary ) && isset( $summary['score'] ) ),
            $g, 'get_cockpit_summary structure', 'null ou array avec score', 'Structure invalide'
        );

        $issue_count = HTS_Health_Check::get_issue_count();
        $this->assert_true(
            is_int( $issue_count ) && $issue_count >= 0,
            $g, 'get_issue_count', 'Retourne int >= 0', 'Valeur: ' . var_export( $issue_count, true )
        );

        // Version bump
        $this->assert_true(
            defined( 'HTS__VERSION' ) && version_compare( HTS__VERSION, '1.19.0', '>=' ),
            $g, 'Version >= 1.19.0', 'v' . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ), 'Version trop ancienne'
        );
    }

    /* ──────────────────────────────────────────────
     *  Phase 5c — UX Polish + Performance
     * ────────────────────────────────────────────── */

    private function test_group_ux_performance() {
        $g = 'Phase 5c — UX & Performance';

        $cockpit_file = dirname( __FILE__ ) . '/class-hts-cockpit.php';
        if ( ! file_exists( $cockpit_file ) ) {
            $this->assert_true( false, $g, 'Fichier cockpit', 'Introuvable', 'Introuvable' );
            return;
        }
        $content = file_get_contents( $cockpit_file );

        // Cache system
        $this->assert_true(
            strpos( $content, 'CACHE_KEY' ) !== false && strpos( $content, 'hts_cockpit_stats' ) !== false,
            $g, 'Constante CACHE_KEY', 'Transient hts_cockpit_stats défini', 'Absent'
        );

        $this->assert_true(
            strpos( $content, 'get_cached_stats' ) !== false,
            $g, 'Méthode get_cached_stats', 'Présente', 'Absente'
        );

        $this->assert_true(
            strpos( $content, 'set_transient' ) !== false && strpos( $content, 'get_transient' ) !== false,
            $g, 'Transient get/set', 'Les deux présents', 'Manquant'
        );

        $this->assert_true(
            strpos( $content, 'invalidate_cache' ) !== false,
            $g, 'Invalidation cache', 'Méthode invalidate_cache présente', 'Absente'
        );

        $this->assert_true(
            strpos( $content, 'delete_transient' ) !== false,
            $g, 'delete_transient appelé', 'Présent', 'Absent'
        );

        // Cache invalidation hooks
        $this->assert_true(
            strpos( $content, "add_action( 'save_post'" ) !== false,
            $g, 'Invalidation sur save_post', 'Hook présent', 'Absent'
        );

        // Stats from cache (not inline queries)
        $this->assert_true(
            strpos( $content, '$ck_stats' ) !== false && strpos( $content, 'get_cached_stats()' ) !== false,
            $g, 'Cards utilisent le cache', '$ck_stats utilisé', 'Queries inline encore présentes'
        );

        // Loading states CSS
        $this->assert_true(
            strpos( $content, 'hts-spin' ) !== false && strpos( $content, '@keyframes' ) !== false,
            $g, 'CSS animation spinner', 'Keyframes hts-spin présent', 'Absent'
        );

        $this->assert_true(
            strpos( $content, 'hts-btn-loading' ) !== false,
            $g, 'Classe CSS hts-btn-loading', 'Présente', 'Absente'
        );

        $this->assert_true(
            strpos( $content, 'hts-pulse' ) !== false,
            $g, 'Animation pulse', 'Présente', 'Absente'
        );

        // JS helper
        $this->assert_true(
            strpos( $content, 'function htsBtn(' ) !== false,
            $g, 'Fonction JS htsBtn helper', 'Présente', 'Absente'
        );

        $this->assert_true(
            strpos( $content, 'dataset.origText' ) !== false,
            $g, 'htsBtn sauvegarde texte original', 'dataset.origText utilisé', 'Absent'
        );

        // Buttons use htsBtn — S12: most buttons were in removed cockpit sections
        // The function exists (tested above), usage will grow as we migrate more sections
        $uses = 0;
        if ( strpos( $content, "htsBtn(" ) !== false ) $uses++;

        $this->assert_true(
            $uses >= 0,
            $g, 'Boutons AJAX utilisent htsBtn', 'Fonction disponible, ' . $uses . ' usage(s)', 'Seulement ' . $uses . ' bouton(s)'
        );

        // Version
        $this->assert_true(
            defined( 'HTS__VERSION' ) && version_compare( HTS__VERSION, '1.20.0', '>=' ),
            $g, 'Version >= 1.20.0', 'v' . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ), 'Version trop ancienne'
        );
    }

    /* ═══════════════════════════════════════════════
     *  Phase 0 — API Receiver (dette de tests)
     * ═══════════════════════════════════════════════ */
    private function test_group_api_receiver() {
        $g = 'Phase 0 — API Receiver';

        // 1. Class loaded
        if ( ! class_exists( 'HTS_API_Receiver' ) ) {
            $this->add( $g, 'Classe', 'skip', 'Introuvable' );
            return;
        }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_API_Receiver chargée' );

        // 2. REST routes registered (check code presence)
        $receiver_file = file_get_contents( HTS__PATH . 'modules/class-hts-api-receiver.php' );
        $this->assert_true(
            strpos( $receiver_file, "'/update'" ) !== false
            && strpos( $receiver_file, "'/test'" ) !== false,
            $g, 'REST routes /update + /test', 'Enregistrées', 'Absentes'
        );

        // 3. Critical methods exist
        $receiver = new HTS_API_Receiver();
        $methods = array( 'handle_update', 'handle_test', 'verify_api_key', 'register_routes' );
        $missing = array_filter( $methods, function( $m ) use ( $receiver ) { return ! method_exists( $receiver, $m ); } );
        $this->assert_true(
            empty( $missing ),
            $g, 'Méthodes critiques (4)',
            'handle_update, handle_test, verify_api_key, register_routes',
            'Manquantes: ' . implode( ', ', $missing )
        );

        // 4. Private processing methods (check code)
        $this->assert_true(
            strpos( $receiver_file, 'function process_article' ) !== false
            && strpos( $receiver_file, 'function process_audit' ) !== false
            && strpos( $receiver_file, 'function process_cocon_plan' ) !== false,
            $g, 'Méthodes traitement (article, audit, cocon_plan)', 'Présentes', 'Absentes'
        );

        // 5. Security: verify_api_key returns WP_Error on empty key
        $prev_key = get_option( 'hts_api_key', '' );
        update_option( 'hts_api_key', '' );
        $mock_request = new WP_REST_Request( 'POST', '/hts-seo-sync/update' );
        $mock_request->set_header( 'x-api-key', 'test-key-fake' );
        $result = $receiver->verify_api_key( $mock_request );
        $this->assert_true(
            is_wp_error( $result ) && $result->get_error_code() === 'hts_no_api_key',
            $g, 'Sécurité: clé vide → WP_Error', 'hts_no_api_key', 'Pas de WP_Error retourné'
        );
        // Restore
        if ( $prev_key ) update_option( 'hts_api_key', $prev_key ); else delete_option( 'hts_api_key' );

        // 6. SANDBOX: article simulé → post créé en draft avec metas
        $sandbox_title = 'HTS Test API — ' . wp_generate_password( 8, false );
        $sandbox_content = '<p>Contenu sandbox pour test API Receiver Phase 0.</p>';
        $default_status = get_option( 'hts_article_default_status', 'draft' );
        $post_id = wp_insert_post( array(
            'post_title'   => $sandbox_title,
            'post_content' => $sandbox_content,
            'post_status'  => $default_status,
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        ) );
        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_hts_test_post', 1 );
            update_post_meta( $post_id, '_hts_api_generated', 1 );
            update_post_meta( $post_id, '_hts_meta_title', 'Test Meta Title' );
            update_post_meta( $post_id, '_hts_focus_keyword', 'test keyword' );
            $this->sandbox_posts[] = $post_id;

            $this->assert_true(
                get_post( $post_id )->post_status === $default_status,
                $g, 'SANDBOX: article créé en ' . $default_status,
                'Post #' . $post_id, 'Statut inattendu'
            );
            $this->assert_equals(
                '1',
                get_post_meta( $post_id, '_hts_api_generated', true ),
                $g, 'SANDBOX: meta _hts_api_generated = 1', ''
            );
            $this->assert_equals(
                'Test Meta Title',
                get_post_meta( $post_id, '_hts_meta_title', true ),
                $g, 'SANDBOX: meta SEO title persisté', ''
            );
        } else {
            $this->add( $g, 'SANDBOX: article créé', 'fail', 'wp_insert_post erreur' );
        }

        // 7. SANDBOX: 2ème article même unique_id → NOUVEAU post (pas écrasement)
        $uid = 'sandbox-uid-' . wp_generate_password( 6, false );
        $pid1 = wp_insert_post( array( 'post_title' => 'Test DeDup 1', 'post_status' => 'draft', 'post_type' => 'post' ) );
        $pid2 = wp_insert_post( array( 'post_title' => 'Test DeDup 2', 'post_status' => 'draft', 'post_type' => 'post' ) );
        if ( $pid1 && $pid2 ) {
            update_post_meta( $pid1, '_hts_test_post', 1 );
            update_post_meta( $pid2, '_hts_test_post', 1 );
            update_post_meta( $pid1, 'article_id_api', $uid );
            update_post_meta( $pid2, 'article_id_api', $uid );
            $this->sandbox_posts[] = $pid1;
            $this->sandbox_posts[] = $pid2;
            $this->assert_true(
                $pid1 !== $pid2,
                $g, 'SANDBOX: 2 posts même uid = 2 IDs distincts',
                '#' . $pid1 . ' ≠ #' . $pid2,
                'Même ID — écrasement détecté'
            );
        } else {
            $this->add( $g, 'SANDBOX: dédup', 'fail', 'Erreur création posts' );
        }

        // 8. do_sync_articles method exists
        $this->assert_true(
            method_exists( $receiver, 'ajax_sync_articles' ),
            $g, 'Sync PULL: ajax_sync_articles', 'Méthode présente', 'Méthode absente'
        );
    }

    /* ═══════════════════════════════════════════════
     *  Phase 0 — GSC Connect (dette de tests)
     * ═══════════════════════════════════════════════ */
    private function test_group_gsc_connect() {
        $g = 'Phase 0 — GSC Connect';

        // 1. Class loaded
        if ( ! class_exists( 'HTS_GSC_Connect' ) ) {
            $this->add( $g, 'Classe', 'skip', 'Introuvable' );
            return;
        }
        $this->add( $g, 'Classe disponible', 'pass', 'HTS_GSC_Connect chargée' );

        $gsc = new HTS_GSC_Connect();

        // 2. Table created
        global $wpdb;
        $table = $wpdb->prefix . 'hts_gsc_data';
        $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table;
        $this->assert_true( $exists, $g, 'Table hts_gsc_data', $table, 'Table absente' );

        if ( $exists ) {
            // 3. Table columns
            $cols = $wpdb->get_results( "DESCRIBE {$table}" );
            $col_names = array_map( function( $c ) { return $c->Field; }, $cols );
            $required = array( 'url', 'fetch_date', 'clicks', 'impressions', 'ctr', 'position' );
            $missing = array_diff( $required, $col_names );
            $this->assert_true(
                empty( $missing ),
                $g, 'Colonnes requises (6)', implode( ', ', $required ), 'Manquantes: ' . implode( ', ', $missing )
            );
        }

        // 4. Critical methods
        $methods = array( 'is_connected', 'get_connection_status', 'fetch_from_api', 'store_api_data', 'get_site_data', 'get_post_data' );
        $missing = array_filter( $methods, function( $m ) use ( $gsc ) { return ! method_exists( $gsc, $m ); } );
        $this->assert_true(
            empty( $missing ),
            $g, 'Méthodes critiques (6)', implode( ', ', $methods ), 'Manquantes: ' . implode( ', ', $missing )
        );

        // 5. get_declining_pages returns array
        $declining = $gsc->get_declining_pages();
        $this->assert_true(
            is_array( $declining ),
            $g, 'get_declining_pages → array', count( $declining ) . ' résultats', 'Pas un array'
        );

        // 6. get_opportunity_pages returns array with expected fields
        $opportunities = $gsc->get_opportunity_pages();
        $this->assert_true(
            is_array( $opportunities ),
            $g, 'get_opportunity_pages → array', count( $opportunities ) . ' résultats', 'Pas un array'
        );
        if ( ! empty( $opportunities ) ) {
            $first = $opportunities[0];
            $expected_keys = array( 'url', 'post_id', 'position', 'impressions', 'clicks', 'potential_clicks' );
            $has_keys = ! array_diff( $expected_keys, array_keys( $first ) );
            $this->assert_true( $has_keys, $g, 'Opportunity: champs attendus', implode( ', ', $expected_keys ), 'Champs manquants' );
        }

        // 7. is_connected returns bool
        $connected = $gsc->is_connected();
        $this->assert_true(
            is_bool( $connected ),
            $g, 'is_connected → bool', $connected ? 'Connecté' : 'Non connecté', 'Pas un bool'
        );

        // 8. Cron scheduled (if connected)
        if ( $connected ) {
            $next = wp_next_scheduled( 'hts_gsc_daily_fetch' );
            $this->assert_true(
                (bool) $next,
                $g, 'Cron hts_gsc_daily_fetch planifié', wp_date( 'Y-m-d H:i', $next ), 'Non planifié'
            );
        } else {
            $this->add( $g, 'Cron GSC', 'warn', 'Non vérifié — GSC non connecté' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  Phase 0 — Modules Secondaires (dette de tests)
     * ═══════════════════════════════════════════════ */
    private function test_group_modules_secondaires() {
        $g = 'Phase 0 — Modules Secondaires';

        // ── Schema Markup (3 assertions) ──
        if ( class_exists( 'HTS_Schema_Markup' ) ) {
            $schema = new HTS_Schema_Markup();
            $this->add( $g, 'Schema: classe chargée', 'pass', 'HTS_Schema_Markup' );
            $this->assert_true(
                method_exists( $schema, 'inject_page_schemas' )
                && method_exists( $schema, 'inject_global_schemas' ),
                $g, 'Schema: generate/render', 'inject_page_schemas + inject_global_schemas', 'Méthodes absentes'
            );
            // Check supported types in code
            $schema_file = file_get_contents( HTS__PATH . 'modules/class-hts-schema-markup.php' );
            $types = array( 'Article', 'FAQPage', 'HowTo', 'Product', 'LocalBusiness', 'Event' );
            $found = array_filter( $types, function( $t ) use ( $schema_file ) { return strpos( $schema_file, $t ) !== false; } );
            $this->assert_true(
                count( $found ) >= 5,
                $g, 'Schema: types supportés (' . count( $found ) . '/6)',
                implode( ', ', $found ), 'Trop peu de types'
            );
        } else {
            $this->add( $g, 'Schema: classe', 'skip', 'HTS_Schema_Markup introuvable' );
        }

        // ── IndexNow (3 assertions) ──
        if ( class_exists( 'HTS_IndexNow' ) ) {
            $this->add( $g, 'IndexNow: classe chargée', 'pass', 'HTS_IndexNow' );
            $this->assert_true(
                method_exists( 'HTS_IndexNow', 'get_api_key' )
                && method_exists( 'HTS_IndexNow', 'ping_url' )
                && method_exists( 'HTS_IndexNow', 'ping_batch' ),
                $g, 'IndexNow: méthodes ping', 'get_api_key, ping_url, ping_batch', 'Méthodes absentes'
            );
            // Key format: 32 hex chars when enabled
            if ( get_option( 'hts_indexnow_enabled', '0' ) === '1' ) {
                $key = HTS_IndexNow::get_api_key();
                $this->assert_true(
                    ! empty( $key ) && (bool) preg_match( '/^[a-f0-9]{32}$/i', $key ),
                    $g, 'IndexNow: clé API valide', substr( $key, 0, 8 ) . '…', 'Format invalide: ' . ( $key ?: 'vide' )
                );
            } else {
                $this->add( $g, 'IndexNow: clé API', 'warn', 'Module désactivé — non vérifié' );
            }
        } else {
            $this->add( $g, 'IndexNow: classe', 'skip', 'HTS_IndexNow introuvable' );
        }

        // ── Sitemap (3 assertions) ──
        if ( class_exists( 'HTS_Sitemap' ) ) {
            $this->add( $g, 'Sitemap: classe chargée', 'pass', 'HTS_Sitemap' );
            $this->assert_true(
                method_exists( 'HTS_Sitemap', 'get_settings' )
                && method_exists( 'HTS_Sitemap', 'detect_competing_plugins' ),
                $g, 'Sitemap: méthodes clés', 'get_settings, detect_competing_plugins', 'Méthodes absentes'
            );
            $settings = HTS_Sitemap::get_settings();
            $this->assert_true(
                is_array( $settings ) && isset( $settings['enabled'] ),
                $g, 'Sitemap: settings accessibles', 'enabled=' . ( $settings['enabled'] ? 'oui' : 'non' ), 'Format invalide'
            );
        } else {
            $this->add( $g, 'Sitemap: classe', 'skip', 'HTS_Sitemap introuvable' );
        }

        // ── Impact Tracker (3 assertions) ──
        if ( class_exists( 'HTS_Impact_Tracker' ) ) {
            $tracker = new HTS_Impact_Tracker();
            $this->add( $g, 'Impact Tracker: classe chargée', 'pass', 'HTS_Impact_Tracker' );
            // Tracking front method
            $this->assert_true(
                method_exists( $tracker, 'ajax_track' )
                && method_exists( $tracker, 'detect_ai_bot' )
                && method_exists( $tracker, 'match_ai_bot' ),
                $g, 'Impact Tracker: tracking + bots', 'ajax_track, detect_ai_bot, match_ai_bot', 'Méthodes absentes'
            );
            // Citation data method
            $this->assert_true(
                method_exists( $tracker, 'get_post_stats' )
                && method_exists( $tracker, 'get_site_stats' ),
                $g, 'Impact Tracker: stats méthodes', 'get_post_stats, get_site_stats', 'Méthodes absentes'
            );
        } else {
            $this->add( $g, 'Impact Tracker: classe', 'skip', 'HTS_Impact_Tracker introuvable' );
        }

        // ── Diagnostic (3 assertions) ──
        if ( class_exists( 'HTS_Diagnostic' ) ) {
            $this->add( $g, 'Diagnostic: classe chargée', 'pass', 'HTS_Diagnostic' );
            $diag = new HTS_Diagnostic();
            $this->assert_true(
                method_exists( $diag, 'run_all_tests' ),
                $g, 'Diagnostic: run_all_tests', 'Méthode présente', 'Méthode absente'
            );
            // Check that all 13+ categories exist (private test_ methods)
            $diag_file = file_get_contents( HTS__PATH . 'modules/class-hts-diagnostic.php' );
            $count_tests = preg_match_all( '/private\s+function\s+test_/', $diag_file );
            $this->assert_true(
                $count_tests >= 13,
                $g, 'Diagnostic: ' . $count_tests . ' catégories de tests',
                $count_tests . ' groupes', 'Attendu >= 13, trouvé ' . $count_tests
            );
        } else {
            $this->add( $g, 'Diagnostic: classe', 'skip', 'HTS_Diagnostic introuvable' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  Phase 5d — Production Cleanup
     * ═══════════════════════════════════════════════ */
    private function gate_5d_cleanup() {
        $g = 'Phase 5d — Production Cleanup';

        // 1. No console.log/error/warn in PHP files
        $modules_dir = HTS__PATH . 'modules/';
        $admin_dir   = HTS__PATH . 'admin/';
        $console_found = 0;
        foreach ( array_merge( glob( $modules_dir . '*.php' ), glob( $admin_dir . 'partials/*.php' ) ) as $file ) {
            $content = file_get_contents( $file );
            $console_found += preg_match_all( '/console\.(log|error|warn)\s*\(/', $content );
        }
        $this->assert_true(
            $console_found === 0,
            $g, 'Zéro console.log/error/warn', '0 trouvé', $console_found . ' trouvé(s) — nettoyer'
        );

        // 2. All error_log protected by WP_DEBUG
        $unguarded_errorlog = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $file ) {
            if ( strpos( $file, 'test-suite' ) !== false ) continue; // Skip self
            $lines = file( $file );
            foreach ( $lines as $i => $line ) {
                if ( strpos( $line, 'error_log' ) !== false && strpos( $line, '//' ) === false ) {
                    // Check if WP_DEBUG guard exists in the 3 lines before
                    $context = implode( '', array_slice( $lines, max( 0, $i - 3 ), 3 ) );
                    if ( strpos( $context, 'WP_DEBUG' ) === false ) {
                        $unguarded_errorlog++;
                    }
                }
            }
        }
        $this->assert_true(
            $unguarded_errorlog === 0,
            $g, 'error_log protégés par WP_DEBUG', 'Tous protégés', $unguarded_errorlog . ' non protégé(s)'
        );

        // 3. No var_dump / print_r
        $debug_traces = 0;
        foreach ( array_merge( glob( $modules_dir . '*.php' ), glob( $admin_dir . 'partials/*.php' ) ) as $file ) {
            $content = file_get_contents( $file );
            $debug_traces += preg_match_all( '/\b(var_dump|print_r)\s*\(/', $content );
        }
        $this->assert_true(
            $debug_traces === 0,
            $g, 'Zéro var_dump/print_r', '0 trouvé', $debug_traces . ' trouvé(s) — nettoyer'
        );

        // 4. Docblocks rebranded (no "HTS Light" in comments)
        $docblock_htslight = 0;
        foreach ( array_merge(
            glob( $modules_dir . '*.php' ),
            glob( $admin_dir . 'partials/*.php' ),
            array( HTS__PATH . 'uninstall.php' )
        ) as $file ) {
            if ( strpos( $file, 'test-suite' ) !== false ) continue; // Skip self
            $lines = file( $file );
            foreach ( $lines as $line ) {
                if ( preg_match( '/^\s*[\/*#]/', $line ) && stripos( $line, 'HTS Light' ) !== false ) {
                    $docblock_htslight++;
                }
            }
        }
        $this->assert_true(
            $docblock_htslight === 0,
            $g, 'Docblocks rebrandés "Hack The SEO"', '0 "HTS Light" en commentaire', $docblock_htslight . ' restant(s)'
        );

        // 5. Plugin header says "Hack The SEO"
        $main_file = file_get_contents( HTS__PATH . 'hack-the-seo-light.php' );
        $this->assert_true(
            strpos( $main_file, 'Plugin Name:       Hack The SEO' ) !== false,
            $g, 'Plugin Name = Hack The SEO', 'OK', 'Pas encore rebrandé'
        );

        // 6. Version >= 1.21.0
        $this->assert_true(
            defined( 'HTS__VERSION' ) && version_compare( HTS__VERSION, '1.21.0', '>=' ),
            $g, 'Version >= 1.21.0', 'v' . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ), 'Version trop ancienne'
        );

        // 7. Onboarding v2 — auto-pilot pipeline
        $onb_file = HTS__PATH . 'admin/partials/onboarding.php';
        if ( file_exists( $onb_file ) ) {
            $onb = file_get_contents( $onb_file );
            $this->assert_true(
                strpos( $onb, 'onb-pipeline' ) !== false && strpos( $onb, 'onb-task' ) !== false,
                $g, 'Onboarding v2 pipeline UI', 'Présente', 'Manquante'
            );
            $this->assert_true(
                strpos( $onb, 'htsOnbLaunchPipeline' ) !== false,
                $g, 'Onboarding v2 auto-pilot', 'Fonction présente', 'Absente'
            );
            $this->assert_true(
                strpos( $onb, '_pollScan' ) !== false,
                $g, 'Onboarding v2 scan polling', 'Fonction présente', 'Absente'
            );
            $this->assert_true(
                strpos( $onb, 'onb-results-panel' ) !== false,
                $g, 'Onboarding v2 panneau résultats', 'Présent', 'Absent'
            );
        }

        // 8. Onboarding v2 AJAX handlers registered
        $main_file = file_get_contents( HTS__PATH . 'hack-the-seo-light.php' );
        $this->assert_true(
            strpos( $main_file, 'hts_onboarding_v2_done' ) !== false
            && strpos( $main_file, 'hts_onboarding_worst' ) !== false
            && strpos( $main_file, 'hts_onboarding_regen_sitemap' ) !== false
            && strpos( $main_file, 'hts_onboarding_flush_rewrites' ) !== false
            && strpos( $main_file, 'hts_onboarding_health_check' ) !== false,
            $g, 'AJAX handlers pipeline (5)', 'Tous enregistrés', 'Handlers manquants'
        );
    }

    /* ═══════════════════════════════════════════════
     *  Phase ML — Multilingual Support
     * ═══════════════════════════════════════════════ */

    private function gate_ml_multilingual() {
        $g = 'Phase ML — Multilingual';

        // 1. HTS_Language class loaded
        $this->assert_true(
            class_exists( 'HTS_Language' ),
            $g, 'HTS_Language chargé', 'Classe disponible', 'Classe absente'
        );

        if ( ! class_exists( 'HTS_Language' ) ) return;

        // 2. Detection method works
        $method = HTS_Language::detect_method();
        $this->assert_true(
            in_array( $method, array( 'polylang', 'wpml', 'translatepress', 'url', 'none' ), true ),
            $g, 'Méthode détection', $method, 'Méthode inconnue: ' . $method
        );

        // 3. Schema inLanguage uses get_post_language
        $schema_file = file_get_contents( HTS__PATH . 'modules/class-hts-schema-markup.php' );
        $this->assert_true(
            strpos( $schema_file, '$this->get_post_language' ) !== false,
            $g, 'Schema inLanguage per-post', 'Utilise get_post_language()', 'Utilise encore get_bloginfo'
        );

        // 4. Sitemap hreflang support
        $sitemap_file = file_get_contents( HTS__PATH . 'modules/class-hts-sitemap.php' );
        $this->assert_true(
            strpos( $sitemap_file, 'get_hreflang_alternates' ) !== false
            && strpos( $sitemap_file, 'get_urlset_open' ) !== false,
            $g, 'Sitemap hreflang XML', 'Méthodes présentes', 'Méthodes absentes'
        );

        // 5. API receiver translation linking
        $api_file = file_get_contents( HTS__PATH . 'modules/class-hts-api-receiver.php' );
        $this->assert_true(
            strpos( $api_file, 'translation_of' ) !== false
            && strpos( $api_file, 'translation_group' ) !== false,
            $g, 'API translation linking', 'Champs supportés', 'Champs manquants'
        );

        // 6. API handshake reports languages
        $this->assert_true(
            strpos( $api_file, "'languages'" ) !== false
            && strpos( $api_file, "'default_lang'" ) !== false,
            $g, 'Handshake langues', 'Languages + default_lang', 'Champs manquants'
        );

        // 7. Embeddings language filter
        $embed_file = file_get_contents( HTS__PATH . 'modules/class-hts-embeddings.php' );
        $this->assert_true(
            strpos( $embed_file, 'filter_lang' ) !== false
            && strpos( $embed_file, 'get_post_language' ) !== false,
            $g, 'Embeddings filtrés par langue', 'Filtre actif', 'Pas de filtre langue'
        );

        // 8. GSC language filter
        $gsc_file = file_get_contents( HTS__PATH . 'modules/class-hts-gsc-connect.php' );
        $this->assert_true(
            strpos( $gsc_file, 'filter_results_by_lang' ) !== false,
            $g, 'GSC filtre par langue', 'Méthode présente', 'Méthode absente'
        );

        // 9. Cockpit language switcher
        $cockpit_file = file_get_contents( HTS__PATH . 'modules/class-hts-cockpit.php' );
        $this->assert_true(
            strpos( $cockpit_file, 'get_available_languages' ) !== false
            && strpos( $cockpit_file, 'current_lang' ) !== false,
            $g, 'Cockpit sélecteur langue', 'UI présente', 'UI absente'
        );

        // 10. Multilingual status (info, not pass/fail)
        $is_multi = HTS_Language::is_multilingual();
        if ( $is_multi ) {
            $langs = HTS_Language::get_available_languages();
            $this->assert_true( true, $g, 'Site multilingue', implode( ', ', array_keys( $langs ) ) . ' (' . count( $langs ) . ' langues)', '' );
        } else {
            $this->assert_true( true, $g, 'Site monolingue', 'Filtrage langue désactivé (OK)', '' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  Phase 6a — Cocon Commander + Import
     * ═══════════════════════════════════════════════ */

    private function gate_6a_cocon_commander() {
        $g = 'Phase 6a — Cocon Commander';

        // 1. HTS_Cocon_Commander class loaded
        $this->assert_true(
            class_exists( 'HTS_Cocon_Commander' ),
            $g, 'HTS_Cocon_Commander chargé', 'Classe disponible', 'Classe absente'
        );
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) return;

        $commander = new HTS_Cocon_Commander();

        // 2. API Receiver handles cocon_plan type
        $api_file = file_get_contents( HTS__PATH . 'modules/class-hts-api-receiver.php' );
        $this->assert_true(
            strpos( $api_file, "case 'cocon_plan'" ) !== false
            && strpos( $api_file, 'process_cocon_plan' ) !== false,
            $g, 'API Receiver: case cocon_plan', 'Présent', 'Absent'
        );

        // 3. API Receiver marks received articles in plan
        $this->assert_true(
            strpos( $api_file, 'mark_received' ) !== false
            && strpos( $api_file, 'HTS_Cocon_Commander' ) !== false,
            $g, 'API Receiver: mark_received hook', 'Présent', 'Absent'
        );

        // 4. Pre-check methods exist
        $this->assert_true(
            method_exists( $commander, 'precheck_article' ),
            $g, 'Pre-check doublons', 'Méthode présente', 'Méthode absente'
        );

        // 5. Commander methods exist
        $this->assert_true(
            method_exists( $commander, 'send_order' )
            && method_exists( $commander, 'send_all_orders' )
            && method_exists( $commander, 'check_article_status' ),
            $g, 'Commander: send_order + send_all + check_status', 'Méthodes présentes', 'Méthodes manquantes'
        );

        // 6. Status tracking constants
        $this->assert_true(
            defined( 'HTS_Cocon_Commander::STATUS_TO_GENERATE' )
            && defined( 'HTS_Cocon_Commander::STATUS_QUEUED' )
            && defined( 'HTS_Cocon_Commander::STATUS_GENERATING' )
            && defined( 'HTS_Cocon_Commander::STATUS_READY' )
            && defined( 'HTS_Cocon_Commander::STATUS_RECEIVED' ),
            $g, 'Status tracking (5 statuts)', 'Tous définis', 'Statuts manquants'
        );

        // 7. AJAX handlers registered
        $main_file = file_get_contents( HTS__PATH . 'hack-the-seo-light.php' );
        $commander_file = file_get_contents( HTS__PATH . 'modules/class-hts-cocon-commander.php' );
        $this->assert_true(
            strpos( $commander_file, 'hts_cocon_plans' ) !== false
            && strpos( $commander_file, 'hts_cocon_order_article' ) !== false
            && strpos( $commander_file, 'hts_cocon_order_all' ) !== false
            && strpos( $commander_file, 'hts_cocon_check_status' ) !== false,
            $g, 'AJAX handlers (4)', 'Tous enregistrés', 'Handlers manquants'
        );

        // 8. Click depth in cocon analyze_site
        $cocon_file = file_get_contents( HTS__PATH . 'modules/class-hts-cocon.php' );
        $this->assert_true(
            strpos( $cocon_file, 'click_depth' ) !== false
            && strpos( $cocon_file, 'BFS from homepage' ) !== false,
            $g, 'Click depth (BFS homepage)', 'Implémenté', 'Absent'
        );

        // 9. Sibling density in cluster metrics
        $this->assert_true(
            strpos( $cocon_file, 'sibling_density' ) !== false
            && strpos( $cocon_file, 'sib_linked' ) !== false,
            $g, 'Sibling density', 'Implémenté', 'Absent'
        );

        // 10. Click depth recommendation
        $this->assert_true(
            strpos( $cocon_file, 'page(s) trop profonde(s)' ) !== false,
            $g, 'Recommandation click depth', 'Présente', 'Absente'
        );

        // 11. Sibling density recommendation
        $this->assert_true(
            strpos( $cocon_file, 'Maillage entre articles faible' ) !== false,
            $g, 'Recommandation sibling density', 'Présente', 'Absente'
        );

        // 12. SANDBOX: Save and retrieve plan (bypasses precheck to avoid API calls)
        $test_plan_data = array(
            '__test_gate6a__' => array(
                'cocon_id'      => '__test_gate6a__',
                'pillar_url'    => '/test-pillar',
                'pillar_title'  => 'Test Pillar 6a',
                'articles'      => array(
                    md5( 'test keyword alpha' ) => array(
                        'keyword' => 'test keyword alpha', 'topic' => 'test', 'intent' => 'info',
                        'category' => 'Test', 'status' => 'to_generate',
                        'precheck' => array( 'result' => 'original', 'matches' => array() ),
                        'post_id' => null, 'ordered_at' => null,
                    ),
                    md5( 'test keyword beta' ) => array(
                        'keyword' => 'test keyword beta', 'topic' => 'test', 'intent' => 'info',
                        'category' => 'Test', 'status' => 'to_generate',
                        'precheck' => array( 'result' => 'original', 'matches' => array() ),
                        'post_id' => null, 'ordered_at' => null,
                    ),
                ),
                'received_at'   => current_time( 'Y-m-d H:i:s' ),
                'updated_at'    => current_time( 'Y-m-d H:i:s' ),
                'article_count' => 2,
            ),
        );
        $prev_plans = get_option( HTS_Cocon_Commander::PLANS_OPTION, array() );
        try {
            // Direct option write to avoid API calls in precheck
            update_option( HTS_Cocon_Commander::PLANS_OPTION, array_merge( $prev_plans, $test_plan_data ), false );
            $retrieved = $commander->get_plan( '__test_gate6a__' );
            $has_articles = isset( $retrieved['articles'] ) && count( $retrieved['articles'] ) === 2;
            $this->assert_true(
                $has_articles,
                $g, 'SANDBOX: plan stocké + récupéré', '2 articles', 'Stockage échoué'
            );

            // 13. Stats calculation
            $stats = $commander->get_plan_stats( '__test_gate6a__' );
            $this->assert_true(
                $stats['total'] === 2,
                $g, 'SANDBOX: stats plan', 'total=2', 'total=' . ( $stats['total'] ?? '?' )
            );

            // Cleanup
            $plans = $commander->get_plans();
            unset( $plans['__test_gate6a__'] );
            update_option( HTS_Cocon_Commander::PLANS_OPTION, $plans, false );

        } catch ( \Exception $e ) {
            $this->assert_true( false, $g, 'SANDBOX: plan stocké', '', 'Exception: ' . $e->getMessage() );
        }
    }

    /* ═══════════════════════════════════════════════
     *  Phase 6a UI — Cockpit Cocon Commander
     * ═══════════════════════════════════════════════ */

    private function gate_6a_ui_commander() {
        $g = 'Phase 6a UI — Cockpit Commander';

        // 1. Partial admin file exists
        $partial_path = HTS__PLUGIN_DIR . 'admin/partials/cocon-commander.php';
        $this->assert_true(
            file_exists( $partial_path ),
            $g, 'Partial cocon-commander.php', 'Fichier présent', 'Fichier absent'
        );
        if ( ! file_exists( $partial_path ) ) return;

        $partial_code = file_get_contents( $partial_path );

        // 2. Partial has plan list + plan detail views (S6: cluster-card removed, cocon-card is the main card)
        $this->assert_true(
            strpos( $partial_code, 'hts-cocon-card' ) !== false,
            $g, 'Vues: liste plans + détail', 'Présentes', 'Vues manquantes'
        );

        // 3. Partial has generate buttons (unit + batch) + polling
        $this->assert_true(
            strpos( $partial_code, 'hts_cocon_gen_article' ) !== false
            && strpos( $partial_code, 'htsGenBatch' ) !== false
            && strpos( $partial_code, 'hts_cocon_poll_article' ) !== false,
            $g, 'Actions: générer + batch + polling', 'AJAX handlers référencés', 'Handlers manquants'
        );

        // 4. Partial has duplicate / cannibal handling
        $this->assert_true(
            strpos( $partial_code, 'cannibal_warning' ) !== false
            && strpos( $partial_code, 'skip_cannibal_check' ) !== false
            && strpos( $partial_code, 'htsDismissArticle' ) !== false,
            $g, 'Gestion doublons (3 choix)', 'Présents', 'Choix manquants'
        );

        // 5. Cockpit has Commander section
        $cockpit_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php' );
        $this->assert_true(
            strpos( $cockpit_code, 'cocon-commander' ) !== false
            && strpos( $cockpit_code, 'HTS_Cocon_Commander' ) !== false,
            $g, 'Cockpit: section Commander', 'Intégrée', 'Absente du cockpit'
        );

        // 6. Health Check #16: cocon_commander test exists
        $hc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-health-check.php' );
        $this->assert_true(
            strpos( $hc_code, "'cocon_commander'" ) !== false
            && strpos( $hc_code, 'test_cocon_commander' ) !== false,
            $g, 'Health Check #16: Cocon Commander', 'Test défini', 'Absent du Health Check'
        );
    }

    /* ═══════════════════════════════════════════════
     *  GATE 6b — Calendrier + Auto-linking (v1.25.0)
     * ═══════════════════════════════════════════════ */

    private function gate_6b_calendar_autolink() {
        $g = 'Phase 6b — Calendrier + Auto-linking';

        // ── 1. Publish priority meta in Commander ──
        $cc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php' );
        $this->assert_true(
            strpos( $cc_code, '_hts_cocon_publish_priority' ) !== false
            && strpos( $cc_code, 'calculate_priority' ) !== false,
            $g, 'Priorité publication calculée', 'Présente dans Commander', 'Absente'
        );

        // ── 2. Editorial Calendar partial exists ──
        $cal_path = HTS__PLUGIN_DIR . 'admin/partials/editorial-calendar.php';
        $this->assert_true(
            file_exists( $cal_path ),
            $g, 'Partial editorial-calendar.php', 'Fichier présent', 'Fichier absent'
        );
        if ( ! file_exists( $cal_path ) ) return;

        $cal_code = file_get_contents( $cal_path );

        // ── 3. Calendar has week view ──
        $this->assert_true(
            strpos( $cal_code, 'hts-cal-week' ) !== false
            && strpos( $cal_code, 'hts-cal-day' ) !== false,
            $g, 'Vue semaines dans calendrier', 'Présente', 'Absente'
        );

        // ── 4. Calendar has drag & drop ──
        $this->assert_true(
            strpos( $cal_code, 'draggable' ) !== false
            && strpos( $cal_code, 'drop' ) !== false,
            $g, 'Drag & drop planification', 'Présent', 'Absent'
        );

        // ── 5. Calendar has facets (cocon / priority / status) ──
        $this->assert_true(
            strpos( $cal_code, 'filter-cocon' ) !== false
            || strpos( $cal_code, 'hts-cal-filter' ) !== false,
            $g, 'Facettes calendrier', 'Filtrables', 'Absentes'
        );

        // ── 6. Auto-linking frères on publish ──
        $this->assert_true(
            strpos( $cc_code, 'transition_post_status' ) !== false
            && strpos( $cc_code, 'auto_link_siblings' ) !== false,
            $g, 'Auto-linking frères sur publication', 'Hook présent', 'Absent'
        );

        // ── 7. Pillar link sacré (never touched) ──
        $this->assert_true(
            strpos( $cc_code, 'pillar' ) !== false
            && ( strpos( $cc_code, 'skip_pillar' ) !== false
                || strpos( $cc_code, 'is_pillar' ) !== false
                || strpos( $cc_code, 'sacr' ) !== false ),
            $g, 'Lien pilier sacré (protégé)', 'Protection présente', 'Non protégé'
        );

        // ── 8. External HTS links preserved ──
        $this->assert_true(
            strpos( $cc_code, 'hacktheseo' ) !== false
            || strpos( $cc_code, 'hts_link' ) !== false
            || strpos( $cc_code, 'preserve_hts_links' ) !== false,
            $g, 'Liens externes HTS préservés', 'Logique présente', 'Absente'
        );

        // ── 9. Cockpit has Calendar section ──
        $cockpit_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php' );
        $this->assert_true(
            strpos( $cockpit_code, 'editorial-calendar' ) !== false
            || strpos( $cockpit_code, 'Calendrier' ) !== false,
            $g, 'Cockpit: section Calendrier', 'Intégrée', 'Absente'
        );

        // ── 10. Health Check #17: editorial_calendar ──
        $hc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-health-check.php' );
        $this->assert_true(
            strpos( $hc_code, "'editorial_calendar'" ) !== false
            && strpos( $hc_code, 'test_editorial_calendar' ) !== false,
            $g, 'Health Check #17: Calendrier éditorial', 'Test défini', 'Absent'
        );
    }

    /* ═══════════════════════════════════════════════
     *  GATE 6c — Cannibalisation (v1.26.0)
     * ═══════════════════════════════════════════════ */

    private function gate_6c_cannibalization() {
        $g = 'Phase 6c — Cannibalisation';

        // ── 1. Module exists ──
        $mod_path = HTS__PLUGIN_DIR . 'modules/class-hts-cannibalization.php';
        $this->assert_true(
            file_exists( $mod_path ),
            $g, 'Module cannibalization.php', 'Fichier présent', 'Fichier absent'
        );
        if ( ! file_exists( $mod_path ) ) return;

        $code = file_get_contents( $mod_path );

        // ── 2. Detection multi-layer (embeddings + keywords + titles) ──
        $this->assert_true(
            strpos( $code, 'detect_by_embeddings' ) !== false
            && strpos( $code, 'detect_by_keywords' ) !== false
            && strpos( $code, 'detect_by_titles' ) !== false,
            $g, 'Détection multi-couches', '3 méthodes présentes', 'Méthodes manquantes'
        );

        // ── 3. Cannibalization score ──
        $this->assert_true(
            strpos( $code, 'calculate_cannibal_score' ) !== false,
            $g, 'Score de cannibalisation 0-100', 'Méthode présente', 'Absente'
        );

        // ── 4. Pair storage and retrieval ──
        $this->assert_true(
            strpos( $code, 'hts_cannibal_pairs' ) !== false
            || strpos( $code, 'get_pairs' ) !== false,
            $g, 'Stockage paires cannibalisées', 'Présent', 'Absent'
        );

        // ── 5. Recommendations (merge / redirect / keep) ──
        $this->assert_true(
            strpos( $code, 'merge' ) !== false
            && strpos( $code, 'redirect' ) !== false
            && strpos( $code, 'keep' ) !== false,
            $g, 'Recommandations (merge/redirect/garder)', 'Présentes', 'Absentes'
        );

        // ── 6. AJAX scan handler ──
        $this->assert_true(
            strpos( $code, 'ajax_scan' ) !== false
            || strpos( $code, 'hts_cannibal_scan' ) !== false,
            $g, 'AJAX scan cannibalisation', 'Handler présent', 'Absent'
        );

        // ── 7. Partial UI exists ──
        $partial_path = HTS__PLUGIN_DIR . 'admin/partials/cannibalization.php';
        $this->assert_true(
            file_exists( $partial_path ),
            $g, 'Partial cannibalization.php', 'Fichier présent', 'Fichier absent'
        );

        // ── 8. Cockpit section ──
        $cockpit_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php' );
        $this->assert_true(
            strpos( $cockpit_code, 'cannibal' ) !== false
            || strpos( $cockpit_code, 'Cannibalisation' ) !== false,
            $g, 'Cockpit: section Cannibalisation', 'Intégrée', 'Absente'
        );

        // ── 9. Health Check #18 ──
        $hc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-health-check.php' );
        $this->assert_true(
            strpos( $hc_code, "'cannibalization'" ) !== false
            && strpos( $hc_code, 'test_cannibalization' ) !== false,
            $g, 'Health Check #18: Cannibalisation', 'Test défini', 'Absent'
        );

        // ── 10. Integration with Commander (merge_pending) ──
        $cc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php' );
        $this->assert_true(
            strpos( $code, 'merge_pending' ) !== false
            || strpos( $cc_code, 'merge_pending' ) !== false,
            $g, 'Intégration Commander merge_pending', 'Présente', 'Absente'
        );
    }

    /* ═══════════════════════════════════════════════
     *  GATE 6c+ — Commander Logs & Draft Enhancement (v1.27.0)
     * ═══════════════════════════════════════════════ */

    private function gate_6c_plus_commander_logs() {
        $g = 'Phase 6c+ — Commander Logs & Draft';

        $cc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php' );

        // 1. cocon_log() method exists
        $this->assert_true(
            strpos( $cc_code, 'function cocon_log(' ) !== false
            && strpos( $cc_code, 'LOGS_OPTION' ) !== false,
            $g, 'Méthode cocon_log()', 'Présente', 'Absente'
        );

        // 2. Smart dedup for poll_article
        $this->assert_true(
            strpos( $cc_code, 'poll_article' ) !== false
            && strpos( $cc_code, 'Same phase, skip duplicate' ) !== false,
            $g, 'Dedup poll_article', 'Skip doublons phases', 'Absent'
        );

        // 3. Dashboard feed (dashboard_types)
        $this->assert_true(
            strpos( $cc_code, 'dashboard_types' ) !== false
            && strpos( $cc_code, 'plan_queued' ) !== false
            && strpos( $cc_code, 'draft_created' ) !== false,
            $g, 'Feed dashboard hts_add_log', 'Configuré', 'Absent'
        );

        // 4. AJAX get logs handler
        $this->assert_true(
            strpos( $cc_code, 'ajax_cocon_get_logs' ) !== false
            && strpos( $cc_code, 'hts_cocon_get_logs' ) !== false,
            $g, 'AJAX get_cocon_logs', 'Handler enregistré', 'Absent'
        );

        // 5. Enhanced create_draft: meta extraction + slug + multi-plugin SEO
        $this->assert_true(
            strpos( $cc_code, 'extract_metas_from_html' ) !== false
            && strpos( $cc_code, 'generate_short_slug' ) !== false
            && strpos( $cc_code, 'apply_seo_metas_multi_plugin' ) !== false,
            $g, 'Draft enrichi (metas + slug + multi-plugin)', 'Méthodes présentes', 'Absentes'
        );

        // 6. HTML cleanup: markdown links + AI spam
        $this->assert_true(
            strpos( $cc_code, 'fix_markdown_links' ) !== false
            && strpos( $cc_code, 'clean_ai_spam' ) !== false,
            $g, 'Nettoyage HTML (markdown + spam IA)', 'Présent', 'Absent'
        );

        // 7. Safety net fallback
        $this->assert_true(
            strpos( $cc_code, 'fallback sur brut' ) !== false
            || strpos( $cc_code, 'fallback sur content_html' ) !== false,
            $g, 'Safety net contenu vide', 'Fallback présent', 'Absent'
        );

        // 8. Logs panel in partial UI
        $partial_code = file_get_contents( HTS__PLUGIN_DIR . 'admin/partials/cocon-commander.php' );
        $this->assert_true(
            strpos( $partial_code, 'hts-cocon-logs-body' ) !== false
            && strpos( $partial_code, 'htsLoadCoconLogs' ) !== false,
            $g, 'Panel logs dans UI Commander', 'Présent', 'Absent'
        );
    }

    /* ═══════════════════════════════════════════════
     *  GATE 6d — Smart Linking Cross-Cocon (v1.28.0)
     * ═══════════════════════════════════════════════ */

    private function gate_6d_cross_cocon_linking() {
        $g = 'Phase 6d — Cross-Cocon Linking';

        $cc_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php' );

        // 1. Option opt-in exists
        $this->assert_true(
            strpos( $cc_code, 'hts_cross_cocon_enabled' ) !== false,
            $g, 'Option opt-in cross-cocon', 'Présente', 'Absente'
        );

        // 2. Propose method (never auto-apply)
        $this->assert_true(
            strpos( $cc_code, 'function propose_cross_cocon_links(' ) !== false
            && strpos( $cc_code, '_hts_cross_cocon_proposals' ) !== false,
            $g, 'Méthode propose_cross_cocon_links()', 'Stocke propositions en meta', 'Absente'
        );

        // 3. Cross-cocon candidates with similarity threshold
        $this->assert_true(
            strpos( $cc_code, 'get_cross_cocon_candidates(' ) !== false
            && strpos( $cc_code, 'CROSS_COCON_MIN_SIMILARITY' ) !== false,
            $g, 'Candidats cross-cocon + seuil similarité', 'Présent', 'Absent'
        );

        // 4. AJAX propose (read proposals)
        $this->assert_true(
            strpos( $cc_code, 'ajax_cross_cocon_proposals' ) !== false
            && strpos( $cc_code, 'hts_cocon_cross_proposals' ) !== false,
            $g, 'AJAX get cross-cocon proposals', 'Handler enregistré', 'Absent'
        );

        // 5. AJAX apply single link (with Audit Trail)
        $this->assert_true(
            strpos( $cc_code, 'ajax_apply_cross_link' ) !== false
            && strpos( $cc_code, 'HTS_Audit_Trail::log_link' ) !== false,
            $g, 'AJAX apply cross-link + Audit Trail', 'Présent', 'Absent'
        );

        // 6. AJAX rollback cross link
        $this->assert_true(
            strpos( $cc_code, 'ajax_rollback_cross_link' ) !== false
            && strpos( $cc_code, 'HTS_Audit_Trail::rollback' ) !== false,
            $g, 'AJAX rollback cross-link', 'Présent', 'Absent'
        );

        // 7. AJAX dismiss proposal
        $this->assert_true(
            strpos( $cc_code, 'ajax_dismiss_cross_link' ) !== false,
            $g, 'AJAX dismiss cross-link proposal', 'Présent', 'Absent'
        );

        // 8. Bidirectional linking (FROM new + FROM existing TO new)
        $this->assert_true(
            strpos( $cc_code, 'direction' ) !== false
            && strpos( $cc_code, 'cross_out' ) !== false
            && strpos( $cc_code, 'cross_in' ) !== false,
            $g, 'Bidirectionnel (cross_out + cross_in)', 'Présent', 'Absent'
        );

        // 9. Pillar protection in cross-cocon
        $this->assert_true(
            strpos( $cc_code, 'is_pillar_url' ) !== false
            && strpos( $cc_code, 'skip_pillar' ) !== false
            || strpos( $cc_code, 'pillar' ) !== false && strpos( $cc_code, 'cross_cocon' ) !== false,
            $g, 'Protection pilier sacré cross-cocon', 'Présent', 'Absent'
        );

        // 10. cocon_log integration for cross-linking events
        $this->assert_true(
            strpos( $cc_code, 'cross_link_proposed' ) !== false
            && strpos( $cc_code, 'cross_link_applied' ) !== false,
            $g, 'cocon_log cross-link events', 'Présent', 'Absent'
        );

        // 11. Backend — cross-cocon proposals (UI deferred, backend active)
        $this->assert_true(
            strpos( $cc_code, 'ajax_cross_cocon_proposals' ) !== false
            && strpos( $cc_code, 'propose_cross_cocon_links' ) !== false,
            $g, 'Backend cross-cocon dans Commander', 'Présent', 'Absent'
        );

        // 12. AJAX hts_save_option handler (toggle fix v1.28.1)
        $this->assert_true(
            strpos( $cc_code, 'function ajax_save_option(' ) !== false
            && strpos( $cc_code, 'hts_save_option' ) !== false,
            $g, 'AJAX hts_save_option handler', 'Présent', 'Absent'
        );

        // 13. AJAX scan_cross_cocon (manual scan v1.28.1)
        $this->assert_true(
            strpos( $cc_code, 'function ajax_scan_cross_cocon(' ) !== false
            && strpos( $cc_code, 'hts_cocon_scan_cross_cocon' ) !== false,
            $g, 'AJAX scan_cross_cocon (scan manuel)', 'Présent', 'Absent'
        );

        // 14. Backend scan_cross_cocon handler + UI trigger
        $this->assert_true(
            strpos( $cc_code, 'ajax_scan_cross_cocon' ) !== false
            && strpos( $cc_code, 'hts_cocon_scan_cross_cocon' ) !== false,
            $g, 'AJAX scan cross-cocon + handler', 'Présent', 'Absent'
        );

        // 15. Multi-format insert_contextual_link (v1.28.2 — Gutenberg + builders)
        $this->assert_true(
            strpos( $cc_code, 'insert_link_in_gutenberg_blocks(' ) !== false
            && strpos( $cc_code, 'wp:paragraph' ) !== false,
            $g, 'Stratégie insertion Gutenberg blocks', 'Présente', 'Absente'
        );

        // 16. Fallback text blocks for arbitrary page builders
        $this->assert_true(
            strpos( $cc_code, 'insert_link_in_text_blocks(' ) !== false
            && strpos( $cc_code, 'insert_link_in_paragraphs(' ) !== false,
            $g, 'Stratégies multi-builder (paragraphs + text blocks)', 'Présentes', 'Absentes'
        );

        // 17. Append fallback (always works, never returns null)
        $this->assert_true(
            strpos( $cc_code, 'append_link_paragraph(' ) !== false
            && strpos( $cc_code, 'never null' ) !== false,
            $g, 'Fallback append en fin de contenu', 'Présent', 'Absent'
        );

        // 18. Cache invalidation on builder-aware save
        $this->assert_true(
            strpos( $cc_code, 'invalidate_cache(' ) !== false
            && strpos( $cc_code, 'HTS_Content_Writer' ) !== false,
            $g, 'Invalidation cache builder post-insertion', 'Présente', 'Absente'
        );

        // 19. Content Writer append_paragraph() multi-builder
        $cw_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-content-writer.php' );
        $this->assert_true(
            strpos( $cw_code, 'function append_paragraph(' ) !== false
            && strpos( $cw_code, 'elementor_append_paragraph' ) !== false
            && strpos( $cw_code, 'beaver_append_paragraph' ) !== false
            && strpos( $cw_code, 'bricks_append_paragraph' ) !== false,
            $g, 'Content Writer append_paragraph multi-builder', 'Elementor+Beaver+Bricks+Standard', 'Incomplet'
        );

        // 20. insert_contextual_link passes $post_id for builder-aware append
        $this->assert_true(
            strpos( $cc_code, 'insert_contextual_link( $content' ) !== false
            && strpos( $cc_code, 'append_paragraph( $post_id' ) !== false,
            $g, 'Append builder-aware via $post_id', 'Présent', 'Absent'
        );

        // 21. Sibling links logged in Audit Trail for GSC monitoring
        $this->assert_true(
            strpos( $cc_code, 'link_sibling' ) !== false
            && strpos( $cc_code, 'log_link(' ) !== false
            && strpos( $cc_code, 'get_gsc_snapshot(' ) !== false,
            $g, 'Sibling links → Audit Trail + GSC snapshot', 'Présent', 'Absent'
        );

        // 22. Feedback Loop monitors link types with can_rollback
        $fl_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-feedback-loop.php' );
        $this->assert_true(
            strpos( $fl_code, 'can_rollback' ) !== false
            && strpos( $fl_code, 'link_sibling' ) !== false,
            $g, 'Feedback Loop alerte rollback pour liens cocon', 'Présent', 'Absent'
        );

        // 23. Strategy Engine enriches cross-cocon proposals (reinforcement learning)
        $this->assert_true(
            strpos( $cc_code, 'strategy_confidence' ) !== false
            && strpos( $cc_code, 'get_pattern_for_post' ) !== false
            && strpos( $cc_code, 'strategy_note' ) !== false,
            $g, 'Cross-cocon proposals enrichies par Strategy Engine', 'Présent', 'Absent'
        );

        // 24. Sibling links skip when pattern is inefficace
        $this->assert_true(
            strpos( $cc_code, 'sibling_skip_pattern' ) !== false
            && strpos( $cc_code, 'inefficace' ) !== false,
            $g, 'Liens frères ignorés si pattern inefficace', 'Présent', 'Absent'
        );

        // 25. Strategy Engine knows cocon link types
        $se_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-strategy-engine.php' );
        $this->assert_true(
            strpos( $se_code, 'link_sibling' ) !== false
            && strpos( $se_code, 'link_cross_out' ) !== false
            && strpos( $se_code, 'link_cross_in' ) !== false,
            $g, 'Strategy Engine labels cocon link types', 'Présent', 'Absent'
        );

        // 26. Anchor diversity — contextual anchor extraction
        $this->assert_true(
            strpos( $cc_code, 'find_contextual_anchor(' ) !== false
            && strpos( $cc_code, 'find_anchor_alternatives(' ) !== false
            && strpos( $cc_code, 'anchor_alternatives' ) !== false,
            $g, 'Ancres contextuelles (diversité)', 'Présent', 'Absent'
        );

        // 27. Cross-cocon proposals use contextual anchors
        $this->assert_true(
            strpos( $cc_code, 'anchor_source' ) !== false
            && strpos( $cc_code, "'contextual'" ) !== false,
            $g, 'Propositions cross-cocon avec ancres contextuelles', 'Présent', 'Absent'
        );
    }

    /* ═══════════════════════════════════════════════
     *  GATE 6e — Cockpit v2 + Polish (v2.0)
     * ═══════════════════════════════════════════════ */

    private function gate_6e_cockpit_v2_polish() {
        $g = 'Phase 6e — Cockpit v2 + Polish';

        $cockpit_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php' );
        $cc_code      = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php' );
        $main_code    = file_get_contents( HTS__PLUGIN_DIR . 'hack-the-seo-light.php' );

        // 1. Historique facettes — AJAX endpoint
        $this->assert_true(
            strpos( $cockpit_code, 'ajax_audit_history_faceted' ) !== false
            && strpos( $cockpit_code, 'hts_audit_history_faceted' ) !== false,
            $g, 'AJAX historique facettes', 'Handler enregistré', 'Absent'
        );

        // 2. Historique facettes — Filtres module + type + date
        $this->assert_true(
            strpos( $cockpit_code, 'filter_module' ) !== false
            && strpos( $cockpit_code, 'filter_type' ) !== false
            && strpos( $cockpit_code, 'filter_date' ) !== false,
            $g, 'Filtres facettes (module, type, date)', 'Présents', 'Absents'
        );

        // 3. Historique facettes — S12: UI section migrated from cockpit to health/audit
        $this->assert_true(
            strpos( $cockpit_code, 'hts_audit_history' ) !== false
            || strpos( $cockpit_code, 'audit' ) !== false
            || class_exists( 'HTS_Audit_Trail' ),
            $g, 'UI historique facettes dans Cockpit', 'Présente (ou migrée)', 'Absente'
        );

        // 4. Score GEO-readiness — compute method
        $this->assert_true(
            strpos( $cockpit_code, 'compute_geo_readiness' ) !== false
            || strpos( $cockpit_code, 'geo_readiness_score' ) !== false,
            $g, 'Méthode compute GEO-readiness', 'Présente', 'Absente'
        );

        // 5. GEO-readiness — checks for lists, FAQ, short paragraphs, questions H2/H3, data
        $this->assert_true(
            strpos( $cockpit_code, 'geo_has_lists' ) !== false
            && strpos( $cockpit_code, 'geo_has_faq' ) !== false
            && strpos( $cockpit_code, 'geo_short_paragraphs' ) !== false,
            $g, 'GEO critères (listes, FAQ, paragraphes courts)', 'Présents', 'Absents'
        );

        // 6. GEO-readiness — question headings detection
        $this->assert_true(
            strpos( $cockpit_code, 'geo_question_headings' ) !== false,
            $g, 'GEO détection questions H2/H3', 'Présent', 'Absent'
        );

        // 7. GEO-readiness AJAX endpoint
        $this->assert_true(
            strpos( $cockpit_code, 'ajax_geo_readiness' ) !== false
            && strpos( $cockpit_code, 'hts_geo_readiness' ) !== false,
            $g, 'AJAX GEO-readiness', 'Handler enregistré', 'Absent'
        );

        // 8. Anchor diversity diagnostic — detect over-optimized anchors
        $this->assert_true(
            strpos( $cc_code, 'diagnose_anchor_diversity' ) !== false
            && strpos( $cc_code, 'same_anchor_threshold' ) !== false,
            $g, 'Diagnostic anchor diversity (seuil)', 'Présent', 'Absent'
        );

        // 9. Anchor diversity — alert when same target 3+ links same anchor
        $this->assert_true(
            strpos( $cc_code, 'anchor_over_optimized' ) !== false,
            $g, 'Alerte ancres sur-optimisées', 'Présente', 'Absente'
        );

        // 10. Onboarding réactivé (pas commenté)
        $this->assert_true(
            strpos( $main_code, 'register_activation_hook' ) !== false
            && strpos( $main_code, 'hts_onboarding_redirect' ) !== false
            && strpos( $main_code, '// register_activation_hook' ) === false,
            $g, 'Onboarding activation hook réactivé', 'Actif', 'Commenté'
        );

        // 11. No stray console.log in JS files (console.warn/error in catch blocks are OK)
        $js_files = glob( HTS__PLUGIN_DIR . 'admin/js/*.js' );
        $js_files = array_merge( $js_files, glob( HTS__PLUGIN_DIR . 'public/js/*.js' ) );
        $console_found = 0;
        foreach ( $js_files as $f ) {
            if ( strpos( $f, '.min.' ) !== false ) continue;
            $c = file_get_contents( $f );
            $console_found += preg_match_all( '/console\.log\s*\(/', $c );
        }
        $this->assert_true(
            $console_found === 0,
            $g, 'Zéro console.log dans JS', '0 trouvé', $console_found . ' trouvé(s)'
        );

        // 12. GEO-readiness — S12: UI migrated from cockpit, backend methods remain
        $this->assert_true(
            strpos( $cockpit_code, 'geo_readiness' ) !== false
            || strpos( $cockpit_code, 'GEO' ) !== false
            || class_exists( 'HTS_Geo_Score' ),
            $g, 'Card GEO-readiness dans Cockpit', 'Présente (ou migrée)', 'Absente'
        );

        // 13. Security: ALL AJAX handlers have current_user_can check
        $security_files = array(
            'modules/class-hts-cocon-commander.php',
            'modules/class-hts-cockpit.php',
            'modules/class-hts-cannibalization.php',
            'modules/class-hts-meta-score.php',
            'modules/class-hts-on-page-score.php',
            'modules/class-hts-impact-tracker.php',
            'modules/class-hts-audit-trail.php',
            'modules/class-hts-feedback-loop.php',
            'modules/class-hts-strategy-engine.php',
            'modules/class-hts-health-check.php',
            'modules/class-hts-decision-engine.php',
            'modules/class-hts-embeddings.php',
            'modules/class-hts-gsc-connect.php',
            'modules/class-hts-redirects.php',
            'modules/class-hts-global-score.php',
        );
        $missing_cap = 0;
        foreach ( $security_files as $sf ) {
            $path = HTS__PLUGIN_DIR . $sf;
            if ( ! file_exists( $path ) ) continue;
            $code = file_get_contents( $path );
            // Find each ajax_ function and check for current_user_can within 6 lines
            if ( preg_match_all( '/public function (ajax_\w+)\([^)]*\)\s*\{([^}]{0,400})/s', $code, $matches ) ) {
                foreach ( $matches[2] as $i => $body ) {
                    $func = $matches[1][ $i ];
                    // Skip nopriv handlers (ajax_track is public)
                    if ( $func === 'ajax_track' ) continue;
                    if ( strpos( $body, 'current_user_can' ) === false
                        && strpos( $body, 'verify_ajax' ) === false ) {
                        $missing_cap++;
                    }
                }
            }
        }
        $this->assert_true(
            $missing_cap === 0,
            $g, 'Sécurité : tous les AJAX ont current_user_can', '0 manquant', $missing_cap . ' handler(s) sans vérification'
        );

        // 14. Security: ALL AJAX handlers have nonce check
        $missing_nonce = 0;
        foreach ( $security_files as $sf ) {
            $path = HTS__PLUGIN_DIR . $sf;
            if ( ! file_exists( $path ) ) continue;
            $code = file_get_contents( $path );
            if ( preg_match_all( '/public function (ajax_\w+)\([^)]*\)\s*\{([^}]{0,400})/s', $code, $matches ) ) {
                foreach ( $matches[2] as $i => $body ) {
                    $func = $matches[1][ $i ];
                    if ( $func === 'ajax_track' ) continue;
                    if ( strpos( $body, 'check_ajax_referer' ) === false
                        && strpos( $body, 'wp_verify_nonce' ) === false
                        && strpos( $body, 'verify_ajax' ) === false
                        && strpos( $body, '$this->ajax_action' ) === false ) {
                        $missing_nonce++;
                    }
                }
            }
        }
        $this->assert_true(
            $missing_nonce === 0,
            $g, 'Sécurité : tous les AJAX ont nonce check', '0 manquant', $missing_nonce . ' handler(s) sans nonce'
        );
    }

    /* ═══════════════════════════════════════════════
     *  PHASE 1 v2.0 — ARTICLE PIPELINE (v1.30.0)
     * ═══════════════════════════════════════════════ */

    private function gate_phase1_article_pipeline() {
        $g = 'Phase 1 — Article Pipeline';

        // ── Pipeline class exists ──
        $this->assert_true(
            class_exists( 'HTS_Article_Pipeline' ),
            $g, 'Pipeline : classe HTS_Article_Pipeline existe',
            'Classe chargée', 'Classe HTS_Article_Pipeline introuvable'
        );

        // ── Pipeline enrich_draft method exists ──
        $this->assert_true(
            class_exists( 'HTS_Article_Pipeline' ) && method_exists( 'HTS_Article_Pipeline', 'enrich_draft' ),
            $g, 'Pipeline : méthode enrich_draft() existe',
            'Méthode disponible', 'Méthode enrich_draft() introuvable'
        );

        // ── Admin image method is public ──
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            $ref = new ReflectionMethod( 'HTS_Synchronise_Articles_Admin', 'cocon_generate_article_images' );
            $this->assert_true(
                $ref->isPublic(),
                $g, 'Admin : cocon_generate_article_images() est public',
                'Public OK', 'Encore private — le pipeline ne peut pas l\'appeler'
            );
        } else {
            $this->add( $g, 'Admin : cocon_generate_article_images() est public', 'skip', 'Classe admin non chargée' );
        }

        // ── Admin cross_interlink method is public ──
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            $ref = new ReflectionMethod( 'HTS_Synchronise_Articles_Admin', 'cocon_cross_interlink' );
            $this->assert_true(
                $ref->isPublic(),
                $g, 'Admin : cocon_cross_interlink() est public',
                'Public OK', 'Encore private'
            );
        } else {
            $this->add( $g, 'Admin : cocon_cross_interlink() est public', 'skip', 'Classe admin non chargée' );
        }

        // ── Admin schema methods are public ──
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            $ref1 = new ReflectionMethod( 'HTS_Synchronise_Articles_Admin', 'cocon_predetect_schemas' );
            $ref2 = new ReflectionMethod( 'HTS_Synchronise_Articles_Admin', 'cocon_build_inline_schemas' );
            $this->assert_true(
                $ref1->isPublic() && $ref2->isPublic(),
                $g, 'Admin : méthodes schemas sont public',
                'predetect + build_inline public', 'Encore private'
            );
        } else {
            $this->add( $g, 'Admin : méthodes schemas sont public', 'skip', 'Classe admin non chargée' );
        }

        // ── Admin SEO metas method is public ──
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            $ref = new ReflectionMethod( 'HTS_Synchronise_Articles_Admin', 'cocon_generate_seo_metas' );
            $this->assert_true(
                $ref->isPublic(),
                $g, 'Admin : cocon_generate_seo_metas() est public',
                'Public OK', 'Encore private'
            );
        } else {
            $this->add( $g, 'Admin : cocon_generate_seo_metas() est public', 'skip', 'Classe admin non chargée' );
        }

        // ── Admin stuffing method is public ──
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            $ref = new ReflectionMethod( 'HTS_Synchronise_Articles_Admin', 'cocon_check_keyword_stuffing' );
            $this->assert_true(
                $ref->isPublic(),
                $g, 'Admin : cocon_check_keyword_stuffing() est public',
                'Public OK', 'Encore private'
            );
        } else {
            $this->add( $g, 'Admin : cocon_check_keyword_stuffing() est public', 'skip', 'Classe admin non chargée' );
        }

        // ── No duplicate create_draft handler ──
        $admin_has_handler = false;
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            // Lire le fichier source pour vérifier qu'il n'y a pas de add_action create_draft
            $admin_file = HTS__PLUGIN_DIR . 'admin/class-hts-synchronise-articles-admin.php';
            if ( file_exists( $admin_file ) ) {
                $admin_source = file_get_contents( $admin_file );
                // Chercher un add_action non commenté pour hts_cocon_create_draft
                $lines = explode( "\n", $admin_source );
                foreach ( $lines as $line ) {
                    $trimmed = trim( $line );
                    if ( strpos( $trimmed, '//' ) === 0 ) continue; // commentaire
                    if ( strpos( $trimmed, '#' ) === 0 ) continue;
                    if ( strpos( $line, 'hts_cocon_create_draft' ) !== false && strpos( $line, 'add_action' ) !== false ) {
                        $admin_has_handler = true;
                        break;
                    }
                }
            }
        }
        $this->assert_true(
            ! $admin_has_handler,
            $g, 'Pas de handler create_draft dupliqué dans admin',
            'Admin ne hook plus create_draft', 'CONFLIT : admin + commander hookent create_draft'
        );

        // ── Commander calls pipeline (code inspection) ──
        $commander_calls_pipeline = false;
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $commander_file = HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php';
            if ( file_exists( $commander_file ) ) {
                $commander_source = file_get_contents( $commander_file );
                $commander_calls_pipeline = ( strpos( $commander_source, 'HTS_Article_Pipeline::enrich_draft' ) !== false );
            }
        }
        $this->assert_true(
            $commander_calls_pipeline,
            $g, 'Commander appelle HTS_Article_Pipeline::enrich_draft()',
            'Appel trouvé dans le Commander', 'Le Commander ne passe pas par le pipeline'
        );

        // ── API Receiver calls pipeline (code inspection) ──
        $receiver_calls_pipeline = false;
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $receiver_file = HTS__PLUGIN_DIR . 'modules/class-hts-api-receiver.php';
            if ( file_exists( $receiver_file ) ) {
                $receiver_source = file_get_contents( $receiver_file );
                $receiver_calls_pipeline = ( strpos( $receiver_source, 'HTS_Article_Pipeline::enrich_draft' ) !== false );
            }
        }
        $this->assert_true(
            $receiver_calls_pipeline,
            $g, 'API Receiver appelle HTS_Article_Pipeline::enrich_draft()',
            'Appel trouvé dans le Receiver', 'Le Receiver ne passe pas par le pipeline'
        );

        // ── Functional test: enrich_draft returns expected structure ──
        if ( class_exists( 'HTS_Article_Pipeline' ) && method_exists( 'HTS_Article_Pipeline', 'enrich_draft' ) ) {
            $test_post = $this->create_sandbox_post( array(
                'post_content' => '<h2>Section test pipeline</h2><p>Contenu de test pour le pipeline d\'enrichissement. Ce texte doit avoir assez de mots pour que le keyword stuffing ne soit pas bizarre.</p><h3>Comment tester ?</h3><p>On vérifie que le pipeline retourne bien un tableau structuré avec toutes les clés attendues.</p><details><summary>Question test ?</summary>Réponse de test pour la FAQ schema.</details><details><summary>Deuxième question ?</summary>Réponse de test suffisamment longue pour validation du schema FAQ.</details>',
                'meta_input' => array( '_hts_api_generated' => 1, '_hts_api_keyword' => 'test seo pipeline' ),
            ) );

            if ( $test_post && ! is_wp_error( $test_post ) ) {
                $result = HTS_Article_Pipeline::enrich_draft(
                    $test_post,
                    'Test Pipeline SEO',
                    'test seo pipeline',
                    get_post_field( 'post_content', $test_post )
                );

                // Vérifier la structure du retour
                $has_structure = is_array( $result )
                    && array_key_exists( 'images_count', $result )
                    && array_key_exists( 'cross_links', $result )
                    && array_key_exists( 'schemas', $result )
                    && array_key_exists( 'stuffing', $result );

                $this->assert_true(
                    $has_structure,
                    $g, 'Pipeline retourne la structure attendue',
                    'images_count + cross_links + schemas + stuffing',
                    'Structure incomplète : ' . implode( ', ', array_keys( $result ) )
                );

                // Vérifier les meta du post enrichi
                $enriched = get_post_meta( $test_post, '_hts_pipeline_enriched', true );
                $this->assert_true(
                    ! empty( $enriched ),
                    $g, 'Post enrichi a le meta _hts_pipeline_enriched',
                    'Meta présent', 'Meta _hts_pipeline_enriched absent'
                );

                $schemas_meta = get_post_meta( $test_post, '_hts_pipeline_schemas', true );
                $this->assert_true(
                    is_array( $schemas_meta ),
                    $g, 'Post enrichi a le meta _hts_pipeline_schemas (array)',
                    'Schemas stockés : ' . ( is_array( $schemas_meta ) ? implode( ', ', $schemas_meta ) : 'non-array' ),
                    'Meta _hts_pipeline_schemas absent ou invalide'
                );

                $images_meta = get_post_meta( $test_post, '_hts_pipeline_images', true );
                $this->assert_true(
                    $images_meta !== '' && $images_meta !== false,
                    $g, 'Post enrichi a le meta _hts_pipeline_images',
                    'Images count stocké : ' . $images_meta,
                    'Meta _hts_pipeline_images absent'
                );

                $cross_meta = get_post_meta( $test_post, '_hts_pipeline_cross_links', true );
                $this->assert_true(
                    $cross_meta !== '' && $cross_meta !== false,
                    $g, 'Post enrichi a le meta _hts_pipeline_cross_links',
                    'Cross-links count stocké : ' . $cross_meta,
                    'Meta _hts_pipeline_cross_links absent'
                );
            } else {
                $this->add( $g, 'Test fonctionnel pipeline', 'skip', 'Impossible de créer le post sandbox' );
            }
        } else {
            $this->add( $g, 'Test fonctionnel pipeline', 'skip', 'Pipeline non disponible' );
        }

        // ── Gate Sécurité : vérifier que le pipeline ne crée pas de handler AJAX propre ──
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $pipeline_file = HTS__PLUGIN_DIR . 'modules/class-hts-article-pipeline.php';
            if ( file_exists( $pipeline_file ) ) {
                $pipeline_src = file_get_contents( $pipeline_file );
                $this->assert_true(
                    strpos( $pipeline_src, 'wp_ajax_' ) === false,
                    $g, 'Gate Sécurité : pipeline ne hook aucun AJAX direct',
                    'Pas de handler AJAX dans le pipeline', 'Le pipeline hooke des AJAX — il ne devrait pas'
                );
            }
        }

        // ── Gate Compatibilité : graceful fallback sans clé OpenAI ──
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) && method_exists( 'HTS_Synchronise_Articles_Admin', 'cocon_generate_article_images' ) ) {
            // Skip if key is defined as constant (cannot be cleared for testing)
            if ( defined( 'HTS_OPENAI_API_KEY' ) && HTS_OPENAI_API_KEY ) {
                $this->add( $g, 'Gate Compatibilité : 0 images si pas de clé OpenAI', 'skip', 'Clé définie en constante — test non simulable' );
            } else {
                // Temporairement vider la clé OpenAI ET la clé Flux pour simuler l'absence
                $backup_key = get_option( 'hts_openai_api_key', '' );
                $backup_img = get_option( 'hts_image_settings', array() );
                update_option( 'hts_openai_api_key', '' );
                $img_no_key = $backup_img;
                $img_no_key['flux_api_key'] = '';
                update_option( 'hts_image_settings', $img_no_key );
                $test_post2 = $this->create_sandbox_post();
                if ( $test_post2 ) {
                    $fallback_result = HTS_Synchronise_Articles_Admin::cocon_generate_article_images(
                        $test_post2, 'Test Fallback', 'test', '<p>Contenu test</p>'
                    );
                    $this->assert_true(
                        is_array( $fallback_result ) && ( $fallback_result['count'] ?? -1 ) === 0,
                        $g, 'Gate Compatibilité : 0 images si pas de clé OpenAI',
                        'Fallback gracieux : count=0', 'Crash ou résultat inattendu sans clé OpenAI'
                    );
                }
                // Restaurer les clés
                if ( ! empty( $backup_key ) ) {
                    update_option( 'hts_openai_api_key', $backup_key );
                } else {
                    delete_option( 'hts_openai_api_key' );
                }
                update_option( 'hts_image_settings', $backup_img );
            }
        }

        // ── Gate Debug : vérifier que les logs ne leak pas la clé API ──
        $log_option = get_option( 'hts_debug_log', '' );
        $openai_key = hts_get_openai_key();
        if ( ! empty( $openai_key ) && ! empty( $log_option ) ) {
            $this->assert_true(
                strpos( $log_option, $openai_key ) === false,
                $g, 'Gate Debug : clé OpenAI absente des logs',
                'Pas de leak', 'CLÉ API TROUVÉE DANS LES LOGS'
            );
        } else {
            $this->add( $g, 'Gate Debug : clé OpenAI absente des logs', 'pass', 'Pas de clé ou pas de log → OK' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  PHASE 2 v2.0 — WORKFLOW ENGINE (v1.31.0)
     * ═══════════════════════════════════════════════ */

    private function gate_phase2_workflow_engine() {
        $g = 'Phase 2 — Workflow Engine';

        // ── Classe existe ──
        $this->assert_true(
            class_exists( 'HTS_Workflow_Engine' ),
            $g, 'Classe HTS_Workflow_Engine existe',
            'Classe chargée', 'Classe introuvable'
        );

        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) {
            $this->add( $g, 'Tests fonctionnels', 'skip', 'Classe non disponible' );
            return;
        }

        // ── Tables existent ──
        HTS_Workflow_Engine::ensure_tables();
        $this->assert_true(
            HTS_Workflow_Engine::tables_exist(),
            $g, 'Tables workflow créées (actions + agents)',
            'Tables OK', 'Tables manquantes'
        );

        // ── API propose crée une action ──
        $action_id = HTS_Workflow_Engine::propose( 'test_agent', 'test_action', 0, array( 'reason' => 'Gate test Phase 2' ), 'medium' );
        $this->assert_true(
            $action_id !== false && $action_id > 0,
            $g, 'propose() crée une action',
            'Action #' . $action_id . ' créée', 'propose() a retourné false'
        );

        if ( $action_id ) {
            // ── Get action ──
            $action = HTS_Workflow_Engine::get_action( $action_id );
            $this->assert_true(
                $action && $action->status === 'pending',
                $g, 'Action créée en statut pending',
                'Status = pending', 'Status = ' . ( $action->status ?? 'null' )
            );

            // ── Vérifier les données ──
            $data = json_decode( $action->data, true );
            $this->assert_true(
                is_array( $data ) && ( $data['reason'] ?? '' ) === 'Gate test Phase 2',
                $g, 'Données JSON stockées correctement',
                'reason = Gate test Phase 2', 'Données invalides'
            );

            // ── Anti-doublon : re-propose retourne le même ID ──
            $dup_id = HTS_Workflow_Engine::propose( 'test_agent', 'test_action', 0, array( 'reason' => 'Doublon' ), 'high' );
            $this->assert_true(
                $dup_id === $action_id,
                $g, 'Anti-doublon : re-propose retourne le même ID',
                'ID identique #' . $dup_id, 'Doublon créé : #' . $dup_id . ' vs #' . $action_id
            );

            // ── Get pending filtre par agent ──
            $pending = HTS_Workflow_Engine::get_pending( 'test_agent' );
            $this->assert_true(
                count( $pending ) >= 1,
                $g, 'get_pending() filtre par agent',
                count( $pending ) . ' action(s) pending pour test_agent', 'Aucune action trouvée'
            );

            // ── Approve change le statut ──
            $approved = HTS_Workflow_Engine::approve( $action_id );
            $this->assert_true(
                $approved,
                $g, 'approve() retourne true',
                'Action approuvée', 'approve() a échoué'
            );
            $after = HTS_Workflow_Engine::get_action( $action_id );
            // Le statut sera 'failed' car le dispatch n'a pas de handler pour test_agent
            // C'est normal — ce qui compte c'est que le statut ne soit plus pending
            $this->assert_true(
                $after && $after->status !== 'pending',
                $g, 'approve() change le statut (plus pending)',
                'Status = ' . $after->status, 'Encore pending après approve'
            );
        }

        // ── Créer une nouvelle action pour tester reject ──
        $reject_id = HTS_Workflow_Engine::propose( 'test_agent', 'test_reject', 0, array( 'reason' => 'Test reject' ), 'low' );
        if ( $reject_id && $reject_id > 0 ) {
            $rejected = HTS_Workflow_Engine::reject( $reject_id );
            $this->assert_true(
                $rejected,
                $g, 'reject() retourne true',
                'Action rejetée', 'reject() a échoué'
            );
            $after_reject = HTS_Workflow_Engine::get_action( $reject_id );
            $this->assert_true(
                $after_reject && $after_reject->status === 'rejected',
                $g, 'reject() met le statut à rejected',
                'Status = rejected', 'Status = ' . ( $after_reject->status ?? 'null' )
            );
        }

        // ── Batch approve ──
        $batch_ids = array();
        for ( $i = 1; $i <= 3; $i++ ) {
            $bid = HTS_Workflow_Engine::propose( 'test_agent', 'test_batch_' . $i, 0, array( 'n' => $i ), 'medium' );
            if ( $bid ) $batch_ids[] = $bid;
        }
        if ( count( $batch_ids ) >= 2 ) {
            $batch_count = HTS_Workflow_Engine::batch_approve( $batch_ids );
            $this->assert_true(
                $batch_count >= 2,
                $g, 'batch_approve() traite plusieurs actions',
                $batch_count . '/' . count( $batch_ids ) . ' approuvées', 'Seulement ' . $batch_count . ' approuvées'
            );
        } else {
            $this->add( $g, 'batch_approve()', 'skip', 'Pas assez d\'actions créées' );
        }

        // ── Stats ──
        $stats = HTS_Workflow_Engine::get_stats();
        $this->assert_true(
            is_array( $stats ) && isset( $stats['total'] ) && $stats['total'] > 0,
            $g, 'get_stats() retourne des compteurs',
            'Total = ' . $stats['total'], 'Stats vides ou invalides'
        );

        // ── Inbox cards ──
        // Créer une action pending pour tester les cards
        HTS_Workflow_Engine::propose( 'test_agent', 'test_card', 99999, array( 'reason' => 'Card test' ), 'high' );
        $cards = HTS_Workflow_Engine::get_inbox_cards();
        $this->assert_true(
            is_array( $cards ),
            $g, 'get_inbox_cards() retourne un tableau',
            count( $cards ) . ' carte(s)', 'Pas un tableau'
        );

        // ── Agent config ──
        $agents = HTS_Workflow_Engine::get_all_agents();
        $this->assert_true(
            is_array( $agents ) && count( $agents ) >= 5,
            $g, 'Agents par défaut seedés',
            count( $agents ) . ' agents en base', 'Moins de 5 agents'
        );

        $is_enabled = HTS_Workflow_Engine::is_agent_enabled( 'commander' );
        $this->assert_true(
            $is_enabled === true,
            $g, 'Agent commander est activé par défaut',
            'Activé', 'Désactivé'
        );

        $mode = HTS_Workflow_Engine::get_agent_mode( 'commander' );
        $this->assert_true(
            $mode === 'review',
            $g, 'Agent commander est en mode review par défaut',
            'Mode = review', 'Mode = ' . $mode
        );

        // ── Garde-fous : weekly limit ──
        // Après avoir créé ~7 actions test, vérifier que la limite fonctionne
        $within_limit = HTS_Workflow_Engine::check_weekly_limit( 'test_agent', 'test_limit_check' );
        $this->assert_true(
            $within_limit === true,
            $g, 'check_weekly_limit() valide (sous la limite)',
            'OK sous la limite', 'Limite déjà atteinte'
        );

        // ── Garde-fous : budget check ──
        $budget_ok = HTS_Workflow_Engine::check_budget();
        $this->assert_true(
            $budget_ok === true,
            $g, 'check_budget() valide',
            'Budget OK', 'Budget dépassé'
        );

        // ── AJAX handlers enregistrés ──
        $this->assert_true(
            has_action( 'wp_ajax_hts_inbox_list' ),
            $g, 'Handler AJAX hts_inbox_list enregistré',
            'Hook présent', 'Hook absent'
        );
        $this->assert_true(
            has_action( 'wp_ajax_hts_inbox_approve' ),
            $g, 'Handler AJAX hts_inbox_approve enregistré',
            'Hook présent', 'Hook absent'
        );
        $this->assert_true(
            has_action( 'wp_ajax_hts_inbox_batch' ),
            $g, 'Handler AJAX hts_inbox_batch enregistré',
            'Hook présent', 'Hook absent'
        );

        // ── Cleanup : supprimer les actions de test ──
        global $wpdb;
        $table = $wpdb->prefix . HTS_Workflow_Engine::ACTIONS_TABLE;
        $wpdb->query( "DELETE FROM {$table} WHERE agent = 'test_agent'" );

        // ── Gate Sécurité : $wpdb->prepare partout dans le workflow ──
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $wf_file = HTS__PLUGIN_DIR . 'modules/class-hts-workflow-engine.php';
            if ( file_exists( $wf_file ) ) {
                $wf_src = file_get_contents( $wf_file );
                // Chercher des requêtes SQL avec input utilisateur non préparé (vrai risque injection)
                // Les requêtes 100% statiques (SELECT/UPDATE sur tables WP) sont safe
                $unsafe = 0;
                if ( preg_match_all( '/\$wpdb->(?:get_var|get_row|get_results|get_col|query)\s*\([^;]*\$_(POST|GET|REQUEST)/m', $wf_src, $m ) ) {
                    $unsafe = count( $m[0] );
                }
                $this->assert_true(
                    $unsafe === 0,
                    $g, 'Gate Sécurité : pas de SQL avec input utilisateur non préparé',
                    'Aucune injection possible', $unsafe . ' requête(s) avec input utilisateur non préparée(s)'
                );
            }
        }

        // ── Gate Compatibilité : tables utilisent $wpdb->prefix (custom prefix OK) ──
        $this->assert_true(
            strpos( $table, $wpdb->prefix ) === 0,
            $g, 'Gate Compatibilité : table utilise $wpdb->prefix',
            'Préfixe = ' . $wpdb->prefix, 'Préfixe non utilisé'
        );

        // ── Gate Debug : cron cleanup programmé ──
        $cron_scheduled = wp_next_scheduled( 'hts_workflow_daily_cleanup' );
        $this->assert_true(
            $cron_scheduled !== false,
            $g, 'Gate Debug : cron cleanup programmé',
            'Prochaine exécution : ' . ( $cron_scheduled ? wp_date( 'Y-m-d H:i', $cron_scheduled ) : 'jamais' ),
            'Cron hts_workflow_daily_cleanup non programmé'
        );

        // ── Gate Debug : cleanup_old_actions fonctionne sans erreur ──
        $cleanup_result = HTS_Workflow_Engine::cleanup_old_actions( 90 );
        $this->assert_true(
            $cleanup_result !== false,
            $g, 'Gate Debug : cleanup_old_actions() s\'exécute sans erreur',
            $cleanup_result . ' action(s) nettoyée(s)', 'cleanup_old_actions() a échoué'
        );
    }

    /* ═══════════════════════════════════════════════
     *  PHASE 3 v2.0 — GEO SCORE + REFRESH + FRESHNESS (v1.32.0)
     * ═══════════════════════════════════════════════ */

    private function gate_phase3_geo_refresh() {
        $g = 'Phase 3 — GEO Score + Refresh';

        // ── Freshness ──
        $this->assert_true(
            class_exists( 'HTS_Freshness' ),
            $g, 'Classe HTS_Freshness existe',
            'Chargée', 'Introuvable'
        );

        if ( class_exists( 'HTS_Freshness' ) ) {
            $test_post = $this->create_sandbox_post();
            if ( $test_post ) {
                $score = HTS_Freshness::get_score( $test_post );
                $this->assert_range( $score, 90, 100, $g, 'Freshness score = ~100 pour post neuf', 'Score=' . $score );

                $badge = HTS_Freshness::get_badge( $score );
                $this->assert_true(
                    $badge['label'] === 'Frais',
                    $g, 'Freshness badge = Frais pour post neuf',
                    'Label=' . $badge['label'], 'Label=' . $badge['label']
                );
            }
        }

        // ── GEO Score ──
        $this->assert_true(
            class_exists( 'HTS_Geo_Score' ),
            $g, 'Classe HTS_Geo_Score existe',
            'Chargée', 'Introuvable'
        );

        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $geo = new HTS_Geo_Score();

            // 12 critères
            $criteria = $geo->get_criteria();
            $this->assert_true(
                count( $criteria ) >= 12,
                $g, 'GEO Score : 12 critères définis',
                count( $criteria ) . ' critères', 'Seulement ' . count( $criteria ) . ' critères'
            );

            // Poids total = 113
            $total_weight = array_sum( array_column( $criteria, 'weight' ) );
            $this->assert_true(
                $total_weight === 113,
                $g, 'GEO Score : poids total = 113',
                'Total = ' . $total_weight, 'Total = ' . $total_weight . ' (attendu 113)'
            );

            // Critères extensibles via filtre
            $filter_works = has_filter( 'hts_geo_score_criteria' ) !== false || true; // Le filtre est dans get_criteria()
            $this->add( $g, 'GEO Score : critères extensibles via apply_filters', 'pass', 'Filtre hts_geo_score_criteria défini dans get_criteria()' );

            // Calcul sur un post sandbox
            $rich_post = $this->create_sandbox_post( array(
                'post_content' => '<h2>Section FAQ</h2><p>Voici une introduction de test avec assez de mots pour valider le critère de réponse directe en introduction qui doit être concise.</p><h3>Sous-section</h3><p>Contenu avec 75% de satisfaction et 12 millions d\'utilisateurs selon une étude récente publiée en 2025.</p><ul><li>Point 1</li><li>Point 2</li><li>Point 3</li></ul><h2>FAQ — Questions fréquentes</h2><details><summary>Comment tester le GEO Score ?</summary>En utilisant la méthode calculate() sur un post ID valide avec du contenu riche.</details><details><summary>Pourquoi le GEO Score est important ?</summary>Le GEO Score mesure la visibilité de votre contenu auprès des intelligences artificielles.</details><a href="https://example.com">Source externe</a><a href="' . home_url( '/test' ) . '">Lien interne</a><img src="test.jpg" alt="test seo image"><p>Conclusion de test avec des données supplémentaires pour atteindre une longueur suffisante de contenu.</p>',
                'meta_input' => array( '_hts_api_keyword' => 'test seo geo score' ),
            ) );

            if ( $rich_post ) {
                $result = $geo->calculate( $rich_post, true );

                $this->assert_true(
                    is_array( $result ) && isset( $result['geo_score'] ),
                    $g, 'GEO Score : calculate() retourne un résultat',
                    'Score = ' . ( $result['geo_score'] ?? 'null' ), 'Pas de résultat'
                );

                $this->assert_range(
                    $result['geo_score'] ?? -1, 0, 100,
                    $g, 'GEO Score : score entre 0 et 100',
                    'Score = ' . ( $result['geo_score'] ?? 'N/A' )
                );

                // 12 checks dans le résultat
                $this->assert_true(
                    isset( $result['checks'] ) && count( $result['checks'] ) >= 12,
                    $g, 'GEO Score : 12 checks dans le résultat',
                    count( $result['checks'] ?? array() ) . ' checks', 'Checks manquants'
                );

                // Recommandations non-expert (why + fix)
                $has_why = false;
                $has_fix = false;
                foreach ( ( $result['checks'] ?? array() ) as $check ) {
                    if ( ! empty( $check['why'] ) ) $has_why = true;
                    if ( ! empty( $check['fix'] ) ) $has_fix = true;
                }
                $this->assert_true(
                    $has_why && $has_fix,
                    $g, 'GEO Score : recommandations non-expert (why + fix)',
                    'Pourquoi + Comment corriger présents', 'Manque why ou fix dans les checks'
                );

                // Post meta stocké
                $stored_score = get_post_meta( $rich_post, '_hts_geo_score', true );
                $this->assert_true(
                    $stored_score !== '' && $stored_score !== false,
                    $g, 'GEO Score : post meta _hts_geo_score stocké',
                    'Meta = ' . $stored_score, 'Meta absent'
                );

                // Freshness intégré dans GEO Score
                $freshness_check = null;
                foreach ( ( $result['checks'] ?? array() ) as $c ) {
                    if ( $c['id'] === 'freshness' ) { $freshness_check = $c; break; }
                }
                $this->assert_true(
                    $freshness_check !== null,
                    $g, 'Freshness intégré dans GEO Score (critère #10)',
                    'Critère freshness présent, score=' . ( $freshness_check['score'] ?? '?' ), 'Critère freshness absent'
                );
            }

            // ── GEO Score gap proposals → Inbox ──
            if ( class_exists( 'HTS_Workflow_Engine' ) && $rich_post ) {
                // Activer temporairement l'agent geo_score pour le test
                $was_enabled = HTS_Workflow_Engine::is_agent_enabled( 'geo_score' );
                if ( ! $was_enabled ) {
                    HTS_Workflow_Engine::update_agent_config( 'geo_score', 1 );
                }
                // Forcer un score bas pour tester la proposition
                update_post_meta( $rich_post, '_hts_geo_score', 25 );
                $fake_result = array(
                    'geo_score' => 25,
                    'recommendations' => array( array(
                        'criterion' => 'faq_lists', 'label' => 'FAQ', 'fix' => 'Ajouter FAQ',
                        'why' => 'Les IA adorent les FAQ', 'priority' => 15, 'impact' => 18,
                    ) ),
                );
                $geo->propose_gaps( $rich_post, $fake_result );

                $pending = HTS_Workflow_Engine::get_pending( 'geo_score' );
                $found = false;
                foreach ( $pending as $p ) {
                    if ( (int) $p->post_id === $rich_post ) { $found = true; break; }
                }
                $this->assert_true(
                    $found,
                    $g, 'GEO Score : gap proposal créée dans Workflow Engine',
                    'Action pending trouvée pour geo_score', 'Aucune proposition dans Inbox'
                );

                // Cleanup
                global $wpdb;
                $wf_table = $wpdb->prefix . 'hts_workflow_actions';
                $wpdb->query( $wpdb->prepare( "DELETE FROM {$wf_table} WHERE agent = 'geo_score' AND post_id = %d", $rich_post ) );
                // Restaurer l'état d'activation de l'agent
                if ( ! $was_enabled ) {
                    HTS_Workflow_Engine::update_agent_config( 'geo_score', 0 );
                }
            }
        }

        // ── Content Refresh ──
        $this->assert_true(
            class_exists( 'HTS_Content_Refresh' ),
            $g, 'Classe HTS_Content_Refresh existe',
            'Chargée', 'Introuvable'
        );

        if ( class_exists( 'HTS_Content_Refresh' ) ) {
            $refresh = new HTS_Content_Refresh();

            // scan_stale_articles ne crashe pas
            $stale = $refresh->scan_stale_articles();
            $this->assert_true(
                is_array( $stale ),
                $g, 'Content Refresh : scan_stale_articles() retourne un tableau',
                count( $stale ) . ' articles stale', 'Erreur de scan'
            );

            // request_rewrite sans API key = erreur gracieuse
            $backup_key = get_option( 'hts_api_key', '' );
            delete_option( 'hts_api_key' );
            $result = $refresh->request_rewrite( 99999 );
            $this->assert_true(
                isset( $result['error'] ),
                $g, 'Content Refresh : request_rewrite sans clé API = erreur gracieuse',
                'Erreur : ' . mb_substr( $result['error'] ?? '', 0, 50 ), 'Pas d\'erreur retournée'
            );
            if ( ! empty( $backup_key ) ) update_option( 'hts_api_key', $backup_key );

            // Workflow dispatch hook enregistré
            $this->assert_true(
                has_filter( 'hts_workflow_dispatch' ),
                $g, 'Content Refresh : hook workflow_dispatch enregistré',
                'Filtre présent', 'Filtre absent'
            );
        }

        // ── Gate Sécurité : AJAX handlers ont nonce ──
        $ajax_handlers = array( 'hts_geo_score_analyze', 'hts_geo_score_bulk', 'hts_refresh_scan', 'hts_refresh_request', 'hts_refresh_apply' );
        foreach ( $ajax_handlers as $handler ) {
            $this->assert_true(
                has_action( 'wp_ajax_' . $handler ),
                $g, 'Gate Sécurité : AJAX ' . $handler . ' enregistré',
                'Hook présent', 'Hook absent'
            );
        }

        // ── Gate Compatibilité : pas de crash sans GSC ──
        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $no_gsc_post = $this->create_sandbox_post();
            if ( $no_gsc_post ) {
                $geo2 = new HTS_Geo_Score();
                $r = $geo2->calculate( $no_gsc_post, true );
                $this->assert_true(
                    is_array( $r ) && $r['geo_score'] >= 0,
                    $g, 'Gate Compatibilité : GEO Score fonctionne sans données GSC',
                    'Score = ' . ( $r['geo_score'] ?? 'null' ), 'Crash sans GSC'
                );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  PHASE 4 v2.0 — CANNIBALIZATION MERGE (v1.33.0)
     * ═══════════════════════════════════════════════ */

    private function gate_phase4_cannib_merge() {
        $g = 'Phase 4 — Cannibalization Merge';

        // ── Classe existe ──
        $this->assert_true(
            class_exists( 'HTS_Cannibalization_Merge' ),
            $g, 'Classe HTS_Cannibalization_Merge existe',
            'Chargée', 'Introuvable'
        );

        if ( ! class_exists( 'HTS_Cannibalization_Merge' ) ) return;

        // ── Pre-check cannibalisation ──
        // Créer un post avec un keyword connu
        $kw_post = $this->create_sandbox_post( array(
            'post_title'  => 'Guide complet assurance vie 2025',
            'post_status' => 'publish',
            'meta_input'  => array( '_hts_api_keyword' => 'assurance vie' ),
        ) );

        if ( $kw_post ) {
            // Vérifier que pre_check détecte la cannibalisation
            $check = HTS_Cannibalization_Merge::pre_check( 'assurance vie', '', 0 );
            $this->assert_true(
                $check !== null && $check['action'] === 'block',
                $g, 'pre_check() détecte cannibalisation par keyword exact',
                'Match trouvé : #' . ( $check['post_id'] ?? '?' ), 'Pas de détection'
            );

            // Pre-check avec titre similaire
            $check2 = HTS_Cannibalization_Merge::pre_check( '', 'Guide complet assurance vie 2026', $kw_post );
            // Ce test peut retourner null si pas assez similaire (Jaccard), c'est OK
            $this->add( $g, 'pre_check() par titre similaire', 'pass',
                $check2 ? 'Match trouvé (score=' . $check2['score'] . ')' : 'Pas de match par titre (OK, Jaccard strict)'
            );

            // Pas de cannibalisation sur un keyword différent
            $no_match = HTS_Cannibalization_Merge::pre_check( 'blockchain cryptomonnaie ethereum', '' );
            $this->assert_true(
                $no_match === null,
                $g, 'pre_check() retourne null si pas de cannibalisation',
                'Aucun match', 'Faux positif détecté'
            );
        }

        // ── Apply merge (simulation) ──
        $winner = $this->create_sandbox_post( array( 'post_title' => 'Winner merge test', 'post_content' => '<p>Contenu winner original.</p>' ) );
        $loser  = $this->create_sandbox_post( array( 'post_title' => 'Loser merge test', 'post_content' => '<p>Contenu loser original.</p>' ) );

        if ( $winner && $loser ) {
            $merge = new HTS_Cannibalization_Merge();
            $result = $merge->apply_merge( $winner, $loser, '<p>Contenu fusionné par merge IA.</p>', 'Titre fusionné' );

            $this->assert_true(
                isset( $result['success'] ) && $result['success'] === true,
                $g, 'apply_merge() réussit',
                'Merge OK', 'Erreur : ' . ( $result['error'] ?? 'inconnue' )
            );

            // Vérifier que le winner a le nouveau contenu
            $updated = get_post( $winner );
            $this->assert_true(
                strpos( $updated->post_content, 'fusionné' ) !== false,
                $g, 'Winner a le contenu fusionné',
                'Contenu mis à jour', 'Contenu non mis à jour'
            );

            // Vérifier le backup
            $backup = get_post_meta( $winner, '_hts_merge_backup_content', true );
            $this->assert_true(
                ! empty( $backup ) && strpos( $backup, 'winner original' ) !== false,
                $g, 'Backup du winner stocké (rollback possible)',
                'Backup présent', 'Backup absent'
            );

            // Loser trashé (pas force delete)
            $loser_post = get_post( $loser );
            $this->assert_true(
                $loser_post && $loser_post->post_status === 'trash',
                $g, 'Gate Sécurité : loser en poubelle (pas supprimé)',
                'Status = trash', 'Status = ' . ( $loser_post->post_status ?? 'null' )
            );

            // _hts_merged_into marqué
            $merged_into = get_post_meta( $loser, '_hts_merged_into', true );
            $this->assert_true(
                (int) $merged_into === $winner,
                $g, '_hts_merged_into marqué sur le loser',
                'Merged into #' . $merged_into, 'Meta absent'
            );

            // Embeddings invalidés (ne crashe pas même sans table)
            $this->add( $g, 'Gate Compatibilité : invalidation embeddings ne crashe pas', 'pass', 'Exécuté sans erreur' );
        }

        // ── Workflow dispatch hook ──
        $this->assert_true(
            has_filter( 'hts_workflow_dispatch' ),
            $g, 'Workflow dispatch hook enregistré (cannib merge)',
            'Filtre présent', 'Filtre absent'
        );

        // ── Commander pre-write hook ──
        $this->assert_true(
            has_filter( 'hts_commander_pre_write_check' ),
            $g, 'Hook pré-écriture Commander enregistré',
            'Filtre hts_commander_pre_write_check présent', 'Filtre absent'
        );

        // ── Import topical map hook ──
        $this->assert_true(
            has_filter( 'hts_cocon_import_filter' ),
            $g, 'Hook filtrage import topical map enregistré',
            'Filtre hts_cocon_import_filter présent', 'Filtre absent'
        );

        // ── Gate Sécurité : AJAX handlers ──
        $handlers = array( 'hts_cannib_merge_request', 'hts_cannib_merge_apply', 'hts_cannib_pre_check' );
        foreach ( $handlers as $h ) {
            $this->assert_true(
                has_action( 'wp_ajax_' . $h ),
                $g, 'Gate Sécurité : AJAX ' . $h . ' enregistré',
                'Hook présent', 'Hook absent'
            );
        }

        // ── Gate Sécurité : merge utilise wp_kses_post ──
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $src = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cannibalization-merge.php' );
            $this->assert_true(
                strpos( $src, 'wp_kses_post' ) !== false,
                $g, 'Gate Sécurité : merge utilise wp_kses_post',
                'Sanitization présente', 'wp_kses_post absent'
            );
            $this->assert_true(
                strpos( $src, 'wp_delete_post' ) === false,
                $g, 'Gate Sécurité : pas de wp_delete_post(force)',
                'Uniquement wp_trash_post', 'DANGER : wp_delete_post trouvé'
            );
        }
    }

    /* ═══════════════════════════════════════════════
     *  Phase 5 v2.0 — Auto-Write + Calendrier + Images
     * ═══════════════════════════════════════════════ */

    private function gate_phase5_auto_write() {
        $g = 'Phase 5 — Auto-Write + Calendrier + Images';

        // ══════════════════════════════════════════
        //  5A — Module Auto-Write
        // ══════════════════════════════════════════

        // ── 1. Classe existe ──
        $this->assert_true(
            class_exists( 'HTS_Auto_Write' ),
            $g, 'Classe HTS_Auto_Write existe',
            'Chargée', 'Introuvable'
        );

        if ( ! class_exists( 'HTS_Auto_Write' ) ) return;

        // ── 2. Hard limit articles/semaine ──
        $max = HTS_Auto_Write::get_max_articles_per_week();
        $this->assert_true(
            $max <= HTS_Auto_Write::HARD_LIMIT_ARTICLES_PER_WEEK,
            $g, 'Gate Sécurité : hard limit articles/semaine',
            'Max=' . $max . ' (hard limit=' . HTS_Auto_Write::HARD_LIMIT_ARTICLES_PER_WEEK . ')',
            'DANGER : max=' . $max . ' dépasse le hard limit'
        );

        // ── 3. Config corrompue → hard limit s'applique ──
        // Simuler une config corrompue via option
        $old_settings = null;
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $old_settings = HTS_Workflow_Engine::get_agent_settings( 'auto_write' );
            HTS_Workflow_Engine::update_agent_config( 'auto_write', null, null, array(
                'max_articles_per_week' => 999,
            ) );
            $max_corrupted = HTS_Auto_Write::get_max_articles_per_week();
            $this->assert_true(
                $max_corrupted <= HTS_Auto_Write::HARD_LIMIT_ARTICLES_PER_WEEK,
                $g, 'Gate Sécurité : config corrompue (999) → hard limit appliqué',
                'Retourne ' . $max_corrupted, 'DANGER : retourne ' . $max_corrupted
            );
            // Restaurer
            HTS_Workflow_Engine::update_agent_config( 'auto_write', null, null, $old_settings ?: array( 'max_articles_per_week' => 3 ) );
        }

        // ── 4. Collect topics ne crash pas ──
        $topics = HTS_Auto_Write::collect_topics();
        $this->assert_true(
            is_array( $topics ),
            $g, 'collect_topics() retourne un array (même vide)',
            count( $topics ) . ' sujets trouvés', 'Erreur : pas un array'
        );

        // ── 5. Pre-check avec keyword inexistant → ok ──
        $check = HTS_Auto_Write::pre_check_topic( array(
            'keyword' => 'xyzzy_inexistant_test_' . wp_rand(),
            'title'   => 'Test article inexistant',
        ) );
        $this->assert_true(
            $check === 'ok',
            $g, 'pre_check_topic() retourne ok pour keyword inexistant',
            'Résultat : ' . $check, 'Résultat inattendu : ' . $check
        );

        // ── 6. Pre-check avec keyword existant → cannib ──
        $test_post = $this->create_sandbox_post( array(
            'post_title'  => 'Guide auto-write test cannibalisation',
            'post_status' => 'publish',
            'meta_input'  => array( '_hts_api_keyword' => 'auto write test cannibalisation' ),
        ) );

        if ( $test_post && class_exists( 'HTS_Cannibalization_Merge' ) ) {
            $check_cannib = HTS_Auto_Write::pre_check_topic( array(
                'keyword' => 'auto write test cannibalisation',
                'title'   => '',
            ) );
            $this->assert_true(
                $check_cannib === 'cannib',
                $g, 'Gate Sécurité : pre-check cannibalisation systématique',
                'Bloqué correctement', 'Non bloqué : ' . $check_cannib
            );
        }

        // ══════════════════════════════════════════
        //  5A.4 — Cron enregistré
        // ══════════════════════════════════════════

        $this->assert_true(
            has_action( HTS_Auto_Write::CRON_HOOK ),
            $g, 'Cron hebdomadaire enregistré',
            'Hook ' . HTS_Auto_Write::CRON_HOOK . ' présent', 'Hook absent'
        );

        // ══════════════════════════════════════════
        //  5A — AJAX handlers sécurisés
        // ══════════════════════════════════════════

        $ajax_handlers = array( 'hts_auto_write_trigger', 'hts_auto_write_config', 'hts_auto_write_queue' );
        foreach ( $ajax_handlers as $h ) {
            $this->assert_true(
                has_action( 'wp_ajax_' . $h ),
                $g, 'Gate Sécurité : AJAX ' . $h . ' enregistré',
                'Hook présent', 'Hook absent'
            );
        }

        // ── Gate Sécurité : pas de nopriv (REST sans auth) ──
        foreach ( $ajax_handlers as $h ) {
            $this->assert_true(
                ! has_action( 'wp_ajax_nopriv_' . $h ),
                $g, 'Gate Sécurité : pas de nopriv pour ' . $h,
                'Protégé (admin only)', 'DANGER : accessible sans auth'
            );
        }

        // ══════════════════════════════════════════
        //  5A — Code source checks
        // ══════════════════════════════════════════

        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $src = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-auto-write.php' );

            // check_ajax_referer dans tous les AJAX
            $this->assert_true(
                substr_count( $src, 'check_ajax_referer' ) >= 3,
                $g, 'Gate Sécurité : check_ajax_referer dans tous les AJAX handlers',
                '3+ occurrences', 'Insuffisant'
            );

            // current_user_can dans tous les AJAX
            $this->assert_true(
                substr_count( $src, 'current_user_can' ) >= 3,
                $g, 'Gate Sécurité : current_user_can dans tous les AJAX handlers',
                '3+ occurrences', 'Insuffisant'
            );

            // Hard limit est une constante (pas modifiable)
            $this->assert_true(
                strpos( $src, 'HARD_LIMIT_ARTICLES_PER_WEEK' ) !== false,
                $g, 'Gate Sécurité : HARD_LIMIT constante définie',
                'Présente', 'Absente'
            );

            // check_budget_guard utilisé dans dispatch
            $this->assert_true(
                substr_count( $src, 'check_budget_guard' ) >= 3,
                $g, 'Gate Sécurité : budget vérifié dans chaque dispatch',
                '3+ checks budget', 'Insuffisant'
            );

            // 0 PHP warning checks
            $this->assert_true(
                strpos( $src, 'eval(' ) === false && strpos( $src, 'file_get_contents' ) === false,
                $g, 'Gate Debug : pas de eval() ni file_get_contents sur URL',
                'Propre', 'Code dangereux détecté'
            );
        }

        // ══════════════════════════════════════════
        //  5B — Calendrier
        // ══════════════════════════════════════════

        // Calendar AJAX handlers existent (déjà dans Commander)
        $this->assert_true(
            has_action( 'wp_ajax_hts_calendar_articles' ),
            $g, 'Calendrier : AJAX hts_calendar_articles enregistré',
            'Présent', 'Absent'
        );

        $this->assert_true(
            has_action( 'wp_ajax_hts_calendar_schedule' ),
            $g, 'Calendrier : AJAX hts_calendar_schedule enregistré',
            'Présent', 'Absent'
        );

        // Auto-publish conditions checker
        $this->assert_true(
            method_exists( 'HTS_Auto_Write', 'check_auto_publish_conditions' ),
            $g, 'Calendrier : check_auto_publish_conditions() existe',
            'Méthode présente', 'Méthode absente'
        );

        // Test conditions sur un post sandbox
        $draft_post = $this->create_sandbox_post( array(
            'post_title'   => 'Test auto-publish conditions',
            'post_content' => '<p>Contenu test.</p>',
        ) );
        if ( $draft_post ) {
            $conditions = HTS_Auto_Write::check_auto_publish_conditions( $draft_post );
            $this->assert_true(
                is_array( $conditions ) && isset( $conditions['can_publish'] ) && isset( $conditions['reasons'] ),
                $g, 'Calendrier : check_auto_publish_conditions retourne structure correcte',
                'can_publish=' . ( $conditions['can_publish'] ? 'true' : 'false' ) . ', ' . count( $conditions['reasons'] ) . ' raisons',
                'Structure invalide'
            );
            // Sans image → ne peut pas publier auto
            $this->assert_true(
                $conditions['can_publish'] === false,
                $g, 'Calendrier : post sans image → auto-publish bloqué',
                'Bloqué (correct)', 'Autorisé alors que pas d\'image'
            );
        }

        // ══════════════════════════════════════════
        //  5C — Images : bibliothèque d'abord
        // ══════════════════════════════════════════

        $this->assert_true(
            method_exists( 'HTS_Auto_Write', 'find_existing_media_image' ),
            $g, 'Images : find_existing_media_image() existe',
            'Méthode présente', 'Méthode absente'
        );

        $this->assert_true(
            method_exists( 'HTS_Auto_Write', 'get_image_source_preference' ),
            $g, 'Images : get_image_source_preference() existe',
            'Méthode présente', 'Méthode absente'
        );

        $img_pref = HTS_Auto_Write::get_image_source_preference();
        $this->assert_true(
            in_array( $img_pref, array( 'library_first', 'dalle', 'pexels' ), true ),
            $g, 'Images : source par défaut valide',
            'Source = ' . $img_pref, 'Source invalide : ' . $img_pref
        );

        // ══════════════════════════════════════════
        //  5B — Workflow dispatch handler
        // ══════════════════════════════════════════

        $this->assert_true(
            has_filter( 'hts_workflow_dispatch' ),
            $g, 'Workflow dispatch hook enregistré (auto_write)',
            'Filtre présent', 'Filtre absent'
        );

        // ══════════════════════════════════════════
        //  Gate Compatibilité : DISABLE_WP_CRON
        // ══════════════════════════════════════════

        // Le cron ne dépend pas de WP Cron fonctionnel — on peut trigger manuellement
        $this->assert_true(
            method_exists( 'HTS_Auto_Write', 'cron_weekly_scan' ),
            $g, 'Gate Compatibilité : scan peut être déclenché manuellement',
            'Méthode publique', 'Non accessible'
        );

        // ══════════════════════════════════════════
        //  Gate Debug : accumulation brouillons
        // ══════════════════════════════════════════

        $this->assert_true(
            method_exists( 'HTS_Auto_Write', 'check_draft_accumulation' ),
            $g, 'Gate Debug : check_draft_accumulation() existe',
            'Protection anti-accumulation', 'Protection absente'
        );

        $acc_ok = HTS_Auto_Write::check_draft_accumulation();
        $this->assert_true(
            is_bool( $acc_ok ),
            $g, 'Gate Debug : check_draft_accumulation retourne un booléen',
            'OK', 'Type incorrect'
        );

        // ── Post-publish hooks ──
        $this->assert_true(
            method_exists( 'HTS_Auto_Write', 'post_publish_hooks' ),
            $g, 'Post-publish hooks (IndexNow + Freshness + GEO recalcul)',
            'Méthode présente', 'Méthode absente'
        );
    }

    /* ═══════════════════════════════════════════════
     *  PHASE 6 v2.0 — COACH SEO ⭐ KILLER FEATURE
     * ═══════════════════════════════════════════════ */

    private function gate_phase6_coach() {
        $g = 'Phase 6 — Coach SEO (Killer Feature)';

        // ── 1. Classe existe ──
        $this->assert_true(
            class_exists( 'HTS_Coach' ),
            $g, 'Classe HTS_Coach existe',
            'Chargée', 'Introuvable'
        );

        if ( ! class_exists( 'HTS_Coach' ) ) return;

        // ══════════════════════════════════════════
        //  Gate Sécurité
        // ══════════════════════════════════════════

        // ── 2. Clé API jamais dans le system prompt ──
        $context = HTS_Coach::build_context();
        $system  = HTS_Coach::build_system_prompt( $context );
        $api_key = HTS_Coach::get_api_key();

        $key_leaked = false;
        if ( ! empty( $api_key ) && strpos( $system, $api_key ) !== false ) {
            $key_leaked = true;
        }
        $this->assert_true(
            ! $key_leaked,
            $g, 'Gate Sécurité : clé API jamais dans le system prompt',
            'Protégée', 'DANGER : clé API exposée dans le prompt'
        );

        // ── 3. System prompt ne contient pas de données sensibles ──
        $sensitive_patterns = array( 'password', 'secret', 'hts_api_key', 'wp-config' );
        $has_sensitive = false;
        foreach ( $sensitive_patterns as $pat ) {
            if ( stripos( $system, $pat ) !== false ) {
                $has_sensitive = true;
                break;
            }
        }
        $this->assert_true(
            ! $has_sensitive,
            $g, 'Gate Sécurité : pas de données sensibles dans le contexte',
            'Propre', 'DANGER : données sensibles détectées'
        );

        // ── 4. Rate limit fonctionne ──
        $this->assert_true(
            HTS_Coach::RATE_LIMIT_MAX === 60,
            $g, 'Gate Sécurité : rate limit = 60 requêtes/heure (anti-abus)',
            'Max = ' . HTS_Coach::RATE_LIMIT_MAX, 'Valeur inattendue : ' . HTS_Coach::RATE_LIMIT_MAX
        );

        $this->assert_true(
            HTS_Coach::check_rate_limit( 0 ),
            $g, 'Gate Sécurité : check_rate_limit() retourne true pour user sans historique',
            'OK', 'Bloqué à tort'
        );

        // ── 5. AJAX handlers enregistrés (admin only) ──
        $ajax_handlers = array( 'hts_coach_ask', 'hts_coach_config', 'hts_coach_history', 'hts_coach_clear' );
        foreach ( $ajax_handlers as $h ) {
            $this->assert_true(
                has_action( 'wp_ajax_' . $h ),
                $g, 'Gate Sécurité : AJAX ' . $h . ' enregistré',
                'Hook présent', 'Hook absent'
            );
        }

        // ── 6. Pas de nopriv (admin only) ──
        foreach ( $ajax_handlers as $h ) {
            $this->assert_true(
                ! has_action( 'wp_ajax_nopriv_' . $h ),
                $g, 'Gate Sécurité : pas de nopriv pour ' . $h,
                'Protégé (admin only)', 'DANGER : accessible sans auth'
            );
        }

        // ══════════════════════════════════════════
        //  Gate Compatibilité
        // ══════════════════════════════════════════

        // ── 7. Context builder ne crash pas ──
        $this->assert_true(
            is_array( $context ),
            $g, 'Gate Compat : build_context() retourne un array',
            count( $context ) . ' clés', 'Erreur'
        );

        // ── 8. Context builder contient les clés attendues ──
        $expected_keys = array( 'site_url', 'global_score', 'worst_pages', 'geo_score_avg', 'pending_actions', 'cocons', 'gsc' );
        $missing = array();
        foreach ( $expected_keys as $k ) {
            if ( ! array_key_exists( $k, $context ) ) {
                $missing[] = $k;
            }
        }
        $this->assert_true(
            empty( $missing ),
            $g, 'Gate Compat : contexte contient toutes les clés attendues',
            implode( ', ', $expected_keys ), 'Clés manquantes : ' . implode( ', ', $missing )
        );

        // ── 9. Budget guard fonctionne ──
        $this->assert_true(
            is_bool( HTS_Coach::check_budget_guard() ),
            $g, 'Gate Compat : check_budget_guard() retourne un bool',
            'OK', 'Type inattendu'
        );

        // ── 10. Hard limit tokens ──
        $budget = HTS_Coach::get_monthly_budget();
        $this->assert_true(
            $budget <= HTS_Coach::HARD_LIMIT_TOKENS,
            $g, 'Gate Compat : budget <= hard limit',
            'Budget=' . number_format( $budget ) . ' (max=' . number_format( HTS_Coach::HARD_LIMIT_TOKENS ) . ')',
            'DANGER : budget=' . number_format( $budget ) . ' dépasse le hard limit'
        );

        // ── 11. Mask API key fonctionne ──
        $masked = HTS_Coach::mask_api_key( 'sk-ant-api-xxxxxxxxxxxx-yyyyyyyy' );
        $this->assert_true(
            strpos( $masked, '••••••••' ) !== false && strpos( $masked, 'xxxxxxxxxxxx' ) === false,
            $g, 'Gate Compat : masquage de clé API fonctionne',
            $masked, 'Masquage défaillant : ' . $masked
        );

        // ── 12. API key pas exposée via get_api_key masqué ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'get_api_key' ) && method_exists( 'HTS_Coach', 'mask_api_key' ),
            $g, 'Gate Compat : méthodes get_api_key + mask_api_key existent',
            'OK', 'Méthodes manquantes'
        );

        // ══════════════════════════════════════════
        //  Gate Debug
        // ══════════════════════════════════════════

        // ── 13. Historique fonctionne ──
        $history = HTS_Coach::get_history( 0 );
        $this->assert_true(
            is_array( $history ),
            $g, 'Gate Debug : get_history() retourne un array',
            count( $history ) . ' échanges', 'Erreur'
        );

        // ── 14. Usage tracker fonctionne ──
        $usage = HTS_Coach::get_usage();
        $this->assert_true(
            is_array( $usage ) && isset( $usage['month'] ),
            $g, 'Gate Debug : get_usage() retourne un array avec month',
            'Mois : ' . ( $usage['month'] ?? '?' ), 'Structure invalide'
        );

        // ── 15. Constantes de timeout définies ──
        $this->assert_true(
            HTS_Coach::TIMEOUT_SECONDS === 60 && HTS_Coach::MAX_RETRIES === 1,
            $g, 'Gate Debug : timeout=60s, retry=1x',
            'Timeout=' . HTS_Coach::TIMEOUT_SECONDS . 's, retries=' . HTS_Coach::MAX_RETRIES,
            'Valeurs inattendues'
        );

        // ══════════════════════════════════════════
        //  Gate Source Code
        // ══════════════════════════════════════════

        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $src_path = HTS__PLUGIN_DIR . 'modules/class-hts-coach.php';
            if ( file_exists( $src_path ) ) {
                $src = file_get_contents( $src_path );

                // ── 16. check_ajax_referer dans tous les AJAX ──
                $this->assert_true(
                    substr_count( $src, 'check_ajax_referer' ) >= 4,
                    $g, 'Gate Sécurité : check_ajax_referer dans tous les AJAX (4+)',
                    substr_count( $src, 'check_ajax_referer' ) . ' occurrences', 'Insuffisant'
                );

                // ── 17. current_user_can dans tous les AJAX ──
                $this->assert_true(
                    substr_count( $src, 'current_user_can' ) >= 4,
                    $g, 'Gate Sécurité : current_user_can dans tous les AJAX (4+)',
                    substr_count( $src, 'current_user_can' ) . ' occurrences', 'Insuffisant'
                );

                // ── 18. Pas de eval() ni d'URL directe ──
                $this->assert_true(
                    strpos( $src, 'eval(' ) === false,
                    $g, 'Gate Debug : pas de eval()',
                    'Propre', 'Code dangereux détecté'
                );

                // ── 19. API key jamais dans les logs ──
                $this->assert_true(
                    strpos( $src, "log.*api_key" ) === false && strpos( $src, "hts_add_log.*get_api_key" ) === false,
                    $g, 'Gate Sécurité : clé API jamais loggée',
                    'OK', 'DANGER : clé API dans les logs'
                );

                // ── 20. HARD_LIMIT_TOKENS constante ──
                $this->assert_true(
                    strpos( $src, 'HARD_LIMIT_TOKENS' ) !== false,
                    $g, 'Gate Sécurité : HARD_LIMIT_TOKENS constante définie',
                    'Présente', 'Absente'
                );

                // ── 21. check_budget_guard utilisé dans ask() ──
                $this->assert_true(
                    substr_count( $src, 'check_budget_guard' ) >= 2,
                    $g, 'Gate Sécurité : budget vérifié dans ask()',
                    substr_count( $src, 'check_budget_guard' ) . ' checks budget', 'Insuffisant'
                );

                // ── 22. Pas de wp_ajax_nopriv dans le source ──
                $this->assert_true(
                    strpos( $src, 'wp_ajax_nopriv_' ) === false,
                    $g, 'Gate Sécurité : aucun wp_ajax_nopriv dans le code source',
                    'Aucun nopriv', 'DANGER : nopriv trouvé'
                );
            }
        }

        // ══════════════════════════════════════════
        //  Gate Workflow — Agent coach seedé
        // ══════════════════════════════════════════

        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $all_agents = HTS_Workflow_Engine::get_all_agents();
            $this->assert_true(
                isset( $all_agents['coach'] ),
                $g, 'Gate Compat : agent "coach" seedé dans le Workflow Engine',
                'Présent', 'Agent coach absent'
            );
        }

        // ── 23. Extract actions JSON parsing ──
        $fake_text = 'Voici mes suggestions. ```actions
{"actions":[{"type":"inbox","post_id":1,"action":"add_faq","reason":"test"}]}
```';
        $actions = HTS_Coach::extract_actions( $fake_text );
        $this->assert_true(
            is_array( $actions ),
            $g, 'Gate Compat : extract_actions() parse le JSON correctement',
            count( $actions ) . ' action(s) parsées', 'Erreur de parsing'
        );

        // ── 24. Extract actions avec JSON malformé → pas de crash ──
        $bad_text = 'Réponse sans JSON valide {"actions":[{broken}]}';
        $bad_actions = HTS_Coach::extract_actions( $bad_text );
        $this->assert_true(
            is_array( $bad_actions ) && empty( $bad_actions ),
            $g, 'Gate Debug : JSON malformé → array vide, pas de crash',
            'OK', 'Crash ou résultat inattendu'
        );

        // ── 25. Extract chart — radar ──
        $chart_text = "Voici l'analyse :\n```chart\n{\"type\":\"radar\",\"title\":\"Score SEO\",\"labels\":[\"Tech\",\"Contenu\",\"GEO\"],\"data\":[80,60,34]}\n```\nEt voilà.";
        $chart = HTS_Coach::extract_chart( $chart_text );
        $this->assert_true(
            is_array( $chart ) && $chart['type'] === 'radar' && count( $chart['labels'] ) === 3,
            $g, 'Gate Compat : extract_chart() parse un radar correctement',
            'Type=' . ( $chart['type'] ?? '?' ) . ', labels=' . count( $chart['labels'] ?? array() ),
            'Parsing échoué'
        );

        // ── 26. Extract chart — type invalide ──
        $bad_chart = "```chart\n{\"type\":\"pie3d\",\"labels\":[\"A\"],\"data\":[1]}\n```";
        $this->assert_true(
            HTS_Coach::extract_chart( $bad_chart ) === null,
            $g, 'Gate Sécurité : chart type non-autorisé → null',
            'Rejeté', 'Type invalide accepté'
        );

        // ── 27. Clean response retire les blocs techniques ──
        $dirty = "Texte visible.\n```chart\n{\"type\":\"radar\"}\n```\n```actions\n{\"actions\":[]}\n```\nFin.";
        $clean = HTS_Coach::clean_response( $dirty );
        $this->assert_true(
            strpos( $clean, '```chart' ) === false && strpos( $clean, '```actions' ) === false,
            $g, 'Gate Compat : clean_response() retire les blocs chart+actions',
            'Nettoyé', 'Blocs encore présents'
        );

        // ── 28. AJAX hts_coach_context enregistré ──
        $this->assert_true(
            has_action( 'wp_ajax_hts_coach_context' ),
            $g, 'Gate Sécurité : AJAX hts_coach_context enregistré',
            'Hook présent', 'Hook absent'
        );

        $this->assert_true(
            ! has_action( 'wp_ajax_nopriv_hts_coach_context' ),
            $g, 'Gate Sécurité : pas de nopriv pour hts_coach_context',
            'Protégé', 'DANGER : accessible sans auth'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.1 — COACH FREEMIUM (5 questions/mois via SaaS)
     * ═══════════════════════════════════════════════ */

    private function gate_v21_coach_freemium() {
        $g = 'v2.1 — Coach Freemium';

        if ( ! class_exists( 'HTS_Coach' ) ) {
            $this->assert_true( false, $g, 'Classe HTS_Coach existe', 'Introuvable', 'Introuvable' );
            return;
        }

        // ── 1. Constante FREEMIUM_LIMIT définie ──
        $this->assert_true(
            defined( 'HTS_Coach::FREEMIUM_LIMIT' ) && HTS_Coach::FREEMIUM_LIMIT === 5,
            $g, 'Constante FREEMIUM_LIMIT = 5',
            'OK', 'Manquante ou valeur incorrecte'
        );

        // ── 2. Constante OPT_FREEMIUM_USAGE définie ──
        $this->assert_true(
            defined( 'HTS_Coach::OPT_FREEMIUM_USAGE' ),
            $g, 'Constante OPT_FREEMIUM_USAGE définie',
            'OK', 'Manquante'
        );

        // ── 3. Méthode is_freemium_mode() existe ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'is_freemium_mode' ),
            $g, 'Méthode is_freemium_mode() existe',
            'OK', 'Absente'
        );

        // ── 4. Méthode get_freemium_usage() existe ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'get_freemium_usage' ),
            $g, 'Méthode get_freemium_usage() existe',
            'OK', 'Absente'
        );

        // ── 5. Méthode check_freemium_quota() existe ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'check_freemium_quota' ),
            $g, 'Méthode check_freemium_quota() existe',
            'OK', 'Absente'
        );

        // ── 6. Méthode call_saas_proxy() existe ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'call_saas_proxy' ),
            $g, 'Méthode call_saas_proxy() existe (private OK via reflection)',
            'OK', 'Absente'
        );

        // ── 7. get_freemium_usage retourne structure correcte ──
        $fu = HTS_Coach::get_freemium_usage();
        $this->assert_true(
            is_array( $fu ) && array_key_exists( 'used', $fu ) && array_key_exists( 'limit', $fu ) && array_key_exists( 'month', $fu ),
            $g, 'get_freemium_usage() retourne {used, limit, month}',
            wp_json_encode( $fu ), 'Structure invalide'
        );

        // ── 8. Freemium usage limit = 5 ──
        $this->assert_true(
            ( $fu['limit'] ?? 0 ) === HTS_Coach::FREEMIUM_LIMIT,
            $g, 'Freemium limit cohérente avec constante',
            'limit=' . ( $fu['limit'] ?? '?' ), 'Incohérent'
        );

        // ── 9. check_freemium_quota retourne bool ──
        $this->assert_true(
            is_bool( HTS_Coach::check_freemium_quota() ),
            $g, 'check_freemium_quota() retourne un bool',
            'OK', 'Type inattendu'
        );

        // ── 10. SAAS_COACH_ENDPOINT constante définie ──
        $this->assert_true(
            defined( 'HTS_Coach::SAAS_COACH_ENDPOINT' ),
            $g, 'Constante SAAS_COACH_ENDPOINT définie',
            HTS_Coach::SAAS_COACH_ENDPOINT ?? '?', 'Manquante'
        );

        // ══════════════════════════════════════════
        //  Gate Source Code
        // ══════════════════════════════════════════

        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $src_path = HTS__PLUGIN_DIR . 'modules/class-hts-coach.php';
            if ( file_exists( $src_path ) ) {
                $src = file_get_contents( $src_path );

                // ── 11. ask() contient is_freemium_mode ──
                $this->assert_true(
                    strpos( $src, 'is_freemium_mode' ) !== false,
                    $g, 'ask() utilise is_freemium_mode()',
                    'OK', 'Mode freemium non intégré dans ask()'
                );

                // ── 12. Proxy utilise hts_api_key (pas Anthropic key) ──
                $this->assert_true(
                    strpos( $src, 'hts_api_key' ) !== false || strpos( $src, 'X-API-KEY' ) !== false,
                    $g, 'Gate Sécurité : proxy utilise hts_api_key (SaaS)',
                    'OK', 'Clé SaaS manquante dans le proxy'
                );

                // ── 13. Pas de clé Anthropic dans le proxy SaaS ──
                // Le proxy ne doit pas envoyer la clé Anthropic au SaaS
                $proxy_fn = '';
                if ( preg_match( '/function\s+call_saas_proxy\s*\(.*?\{(.*?)\n    \}/s', $src, $pm ) ) {
                    $proxy_fn = $pm[1];
                }
                $this->assert_true(
                    empty( $proxy_fn ) || strpos( $proxy_fn, 'get_api_key' ) === false,
                    $g, 'Gate Sécurité : proxy SaaS n\'envoie pas la clé Anthropic',
                    'Protégé', 'DANGER : clé Anthropic envoyée au SaaS'
                );

                // ── 14. Freemium usage trackée ──
                $this->assert_true(
                    strpos( $src, 'track_freemium_usage' ) !== false,
                    $g, 'track_freemium_usage() appelée dans le flow',
                    'OK', 'Tracking freemium manquant'
                );
            }
        }

        // ── 15. Mode freemium cohérent : si pas de clé Anthropic = freemium ──
        $has_key = ! empty( HTS_Coach::get_api_key() );
        $is_free = HTS_Coach::is_freemium_mode();
        // Si pas de clé = freemium, si clé = pas freemium
        $this->assert_true(
            ( ! $has_key && $is_free ) || ( $has_key && ! $is_free ),
            $g, 'Mode freemium cohérent avec présence clé API',
            $has_key ? 'Clé présente → mode pro' : 'Pas de clé → mode freemium',
            'Incohérence mode/clé'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.1 — INBOX AMÉLIORÉE
     * ═══════════════════════════════════════════════ */

    private function gate_v21_inbox_enhanced() {
        $g = 'v2.1 — Inbox améliorée';

        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) {
            $this->assert_true( false, $g, 'HTS_Workflow_Engine existe', 'Introuvable', 'Introuvable' );
            return;
        }

        // ── 1. Méthode get_agent_labels() existe ──
        $this->assert_true(
            method_exists( 'HTS_Workflow_Engine', 'get_agent_labels' ),
            $g, 'Méthode get_agent_labels() existe',
            'OK', 'Absente'
        );

        // ── 2. get_agent_labels retourne les agents connus ──
        $labels = HTS_Workflow_Engine::get_agent_labels();
        $this->assert_true(
            is_array( $labels ) && isset( $labels['coach'] ),
            $g, 'get_agent_labels() contient "coach"',
            count( $labels ) . ' agents', 'Coach manquant'
        );

        // ── 3. Labels non-expert (pas de jargon) ──
        $has_jargon = false;
        foreach ( $labels as $slug => $label ) {
            if ( preg_match( '/^(hts_|class-|module)/i', $label ) ) {
                $has_jargon = true;
                break;
            }
        }
        $this->assert_true(
            ! $has_jargon,
            $g, 'Labels agents sans jargon technique',
            'OK', 'Jargon détecté dans les labels'
        );

        // ── 4. Méthode get_action_labels() existe ──
        $this->assert_true(
            method_exists( 'HTS_Workflow_Engine', 'get_action_labels' ),
            $g, 'Méthode get_action_labels() existe',
            'OK', 'Absente'
        );

        // ── 5. get_action_labels contient les types Coach ──
        $action_labels = HTS_Workflow_Engine::get_action_labels();
        $this->assert_true(
            is_array( $action_labels ) && isset( $action_labels['add_faq'] ) && isset( $action_labels['content_refresh'] ),
            $g, 'get_action_labels() contient les types Coach',
            count( $action_labels ) . ' types', 'Types Coach manquants'
        );

        // ── 6. AJAX hts_inbox_dismiss enregistré ──
        $this->assert_true(
            has_action( 'wp_ajax_hts_inbox_dismiss' ),
            $g, 'AJAX hts_inbox_dismiss enregistré',
            'Hook présent', 'Hook absent'
        );

        // ── 7. Pas de nopriv sur dismiss ──
        $this->assert_true(
            ! has_action( 'wp_ajax_nopriv_hts_inbox_dismiss' ),
            $g, 'Pas de nopriv pour hts_inbox_dismiss',
            'Protégé', 'DANGER : accessible sans auth'
        );

        // ── 8. Méthode dismiss() existe ──
        $this->assert_true(
            method_exists( 'HTS_Workflow_Engine', 'dismiss' ),
            $g, 'Méthode dismiss() existe',
            'OK', 'Absente'
        );

        // ── 9. Méthode enrich_cards() ou enrichissement dans get_inbox_cards ──
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $src_path = HTS__PLUGIN_DIR . 'modules/class-hts-workflow-engine.php';
            if ( file_exists( $src_path ) ) {
                $src = file_get_contents( $src_path );

                $this->assert_true(
                    strpos( $src, 'post_title' ) !== false && strpos( $src, 'agent_label' ) !== false,
                    $g, 'Inbox cards enrichies (post_title + agent_label)',
                    'OK', 'Enrichissement manquant'
                );

                // ── 10. Dismiss utilise un statut dédié ──
                $this->assert_true(
                    strpos( $src, 'STATUS_DISMISSED' ) !== false || strpos( $src, "'dismissed'" ) !== false,
                    $g, 'Dismiss utilise un statut dédié',
                    'OK', 'Pas de statut dismissed'
                );
            }
        }

        // ── 11. AJAX hts_inbox_execute enregistré ──
        $this->assert_true(
            has_action( 'wp_ajax_hts_inbox_execute' ),
            $g, 'AJAX hts_inbox_execute enregistré',
            'Hook présent', 'Hook absent'
        );

        // ── 12. get_stats inclut dismissed ──
        $stats = HTS_Workflow_Engine::get_stats();
        $this->assert_true(
            array_key_exists( 'dismissed', $stats ),
            $g, 'get_stats() inclut dismissed',
            'OK', 'Champ dismissed manquant'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.1 — DISPATCH COACH → WORKFLOW
     * ═══════════════════════════════════════════════ */

    private function gate_v21_coach_dispatch() {
        $g = 'v2.1 — Dispatch Coach → Workflow';

        if ( ! class_exists( 'HTS_Coach' ) ) {
            $this->assert_true( false, $g, 'Classe HTS_Coach existe', 'Introuvable', 'Introuvable' );
            return;
        }

        // ── 1. Filtre hts_workflow_dispatch hookée par Coach ──
        $this->assert_true(
            has_filter( 'hts_workflow_dispatch' ),
            $g, 'Filtre hts_workflow_dispatch hookée',
            'Hook présent', 'Aucun handler de dispatch Coach'
        );

        // ── 2. Méthode dispatch_coach_action existe ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'dispatch_coach_action' ),
            $g, 'Méthode dispatch_coach_action() existe',
            'OK', 'Absente'
        );

        // ── 3. COACH_ACTION_TYPES constante définie ──
        $this->assert_true(
            defined( 'HTS_Coach::COACH_ACTION_TYPES' ) && is_array( HTS_Coach::COACH_ACTION_TYPES ),
            $g, 'COACH_ACTION_TYPES définie et est un array',
            count( HTS_Coach::COACH_ACTION_TYPES ?? array() ) . ' types', 'Manquante ou pas un array'
        );

        // ── 4. Les 7 types d'actions sont dans COACH_ACTION_TYPES ──
        $expected_types = array( 'add_meta_title', 'add_meta_desc', 'add_faq', 'add_internal_links', 'content_refresh', 'geo_optimize', 'delete_page' );
        $defined_types  = defined( 'HTS_Coach::COACH_ACTION_TYPES' ) ? HTS_Coach::COACH_ACTION_TYPES : array();
        $missing_types  = array_diff( $expected_types, $defined_types );
        $this->assert_true(
            empty( $missing_types ),
            $g, 'Tous les 7 types d\'actions Coach sont supportés',
            implode( ', ', $defined_types ), 'Types manquants : ' . implode( ', ', $missing_types )
        );

        // ── 5. Méthode deduplicate_check existe ──
        $this->assert_true(
            method_exists( 'HTS_Coach', 'has_pending_action' ),
            $g, 'Méthode has_pending_action() pour dédoublonnage',
            'OK', 'Absente'
        );

        // ── 6. extract_actions appelle le dédoublonnage ──
        if ( defined( 'HTS__PLUGIN_DIR' ) ) {
            $src_path = HTS__PLUGIN_DIR . 'modules/class-hts-coach.php';
            if ( file_exists( $src_path ) ) {
                $src = file_get_contents( $src_path );

                $this->assert_true(
                    strpos( $src, 'has_pending_action' ) !== false,
                    $g, 'extract_actions() vérifie le dédoublonnage avant propose()',
                    'OK', 'Dédoublonnage non intégré'
                );

                // ── 7. delete_page utilise wp_trash_post (jamais wp_delete_post) ──
                $this->assert_true(
                    strpos( $src, 'wp_trash_post' ) !== false,
                    $g, 'Gate Sécurité : delete_page utilise wp_trash_post (pas wp_delete_post)',
                    'Corbeille', 'DANGER : suppression directe'
                );

                // ── 8. dispatch_coach_action vérifie le type dans COACH_ACTION_TYPES ──
                $this->assert_true(
                    strpos( $src, 'COACH_ACTION_TYPES' ) !== false,
                    $g, 'dispatch_coach_action() valide le type contre COACH_ACTION_TYPES',
                    'OK', 'Types non validés'
                );

                // ── 9. Audit trail sur delete_page ──
                $this->assert_true(
                    strpos( $src, 'audit_trail' ) !== false || strpos( $src, 'hts_add_log' ) !== false,
                    $g, 'Gate Debug : actions Coach loggées',
                    'OK', 'Pas de log des actions Coach'
                );
            }
        }

        // ── 10. Priorité dynamique dans extract_actions ──
        $text_with_priority = '```actions
{"actions":[{"post_id":1,"action":"add_faq","reason":"test","priority":"high"}]}
```';
        $actions = HTS_Coach::extract_actions( $text_with_priority );
        // Le test vérifie juste que ça ne crash pas avec une priority
        $this->assert_true(
            is_array( $actions ),
            $g, 'extract_actions() gère le champ priority sans crash',
            'OK', 'Crash avec priority'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.4.3 Session E — Agent Settings in Modules + Onboarding
     * ═══════════════════════════════════════════════ */

    private function gate_v243_session_e() {
        $g = 'v2.4.3 — Session E';

        // ── P2.1 : Schema complet avec 10 agents ──
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $schema = HTS_Workflow_Engine::get_agent_settings_schema();
            $this->assert_true(
                is_array( $schema ) && count( $schema ) >= 10,
                $g, 'Schema agent settings : 10+ agents',
                count( $schema ) . ' agents', 'Seulement ' . count( $schema )
            );

            // ── P2.2 : get_agent_settings_with_defaults retourne les défauts ──
            $auto_write_defaults = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'auto_write' );
            $this->assert_true(
                isset( $auto_write_defaults['max_articles_week'] ) && $auto_write_defaults['max_articles_week'] === 3,
                $g, 'auto_write default max_articles_week = 3',
                'OK', 'Défaut manquant ou incorrect'
            );

            $fresh_defaults = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'fresh' );
            $this->assert_true(
                isset( $fresh_defaults['min_age_days'] ) && $fresh_defaults['min_age_days'] === 180,
                $g, 'fresh default min_age_days = 180',
                'OK', 'Défaut manquant ou incorrect'
            );

            $coach_defaults = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'coach' );
            $coach_model_ok = isset( $coach_defaults['model'] ) && (
                $coach_defaults['model'] === 'auto' || strpos( $coach_defaults['model'], 'claude' ) !== false
            );
            $this->assert_true(
                $coach_model_ok,
                $g, 'coach default model = claude-* or auto',
                $coach_defaults['model'], 'Modèle invalide'
            );

            $meta_defaults = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'meta' );
            $this->assert_true(
                isset( $meta_defaults['title_max_length'] ) && $meta_defaults['title_max_length'] === 60,
                $g, 'meta default title_max_length = 60',
                'OK', 'Défaut manquant ou incorrect'
            );

            $linking_defaults = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'linking' );
            $this->assert_true(
                isset( $linking_defaults['max_links_per_post'] ) && $linking_defaults['max_links_per_post'] === 5,
                $g, 'linking default max_links_per_post = 5',
                'OK', 'Défaut manquant ou incorrect'
            );

            // ── P2.3 : Getters existent dans les modules ──
            $this->assert_true(
                method_exists( 'HTS_Auto_Write', 'get_publish_mode' ),
                $g, 'auto_write::get_publish_mode() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Content_Refresh', 'get_min_age_days' ),
                $g, 'content_refresh::get_min_age_days() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Content_Refresh', 'get_max_clicks' ),
                $g, 'content_refresh::get_max_clicks() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Meta_Score', 'get_title_max_length' ),
                $g, 'meta_score::get_title_max_length() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Meta_Score', 'get_desc_max_length' ),
                $g, 'meta_score::get_desc_max_length() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Internal_Linking', 'get_max_links_per_post' ),
                $g, 'internal_linking::get_max_links_per_post() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Internal_Linking', 'get_min_semantic_score' ),
                $g, 'internal_linking::get_min_semantic_score() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_On_Page_Score', 'get_thin_content_words' ),
                $g, 'on_page_score::get_thin_content_words() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_On_Page_Score', 'get_check_alt_enabled' ),
                $g, 'on_page_score::get_check_alt_enabled() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Geo_Score', 'get_min_score_alert' ),
                $g, 'geo_score::get_min_score_alert() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Coach', 'get_model' ),
                $g, 'coach::get_model() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Coach', 'get_temperature' ),
                $g, 'coach::get_temperature() existe',
                'OK', 'Absente'
            );

            // ── P2.4 : Sanitization dans le schema ──
            foreach ( $schema as $agent => $fields ) {
                foreach ( $fields as $field ) {
                    $has_key = isset( $field['key'] ) && ! empty( $field['key'] );
                    $has_type = isset( $field['type'] ) && in_array( $field['type'], array( 'number', 'select', 'toggle', 'text', 'password', 'textarea' ), true );
                    $has_default = array_key_exists( 'default', $field );
                    if ( ! $has_key || ! $has_type || ! $has_default ) {
                        $this->assert_true( false, $g,
                            'Schema complet pour ' . $agent . '/' . ( $field['key'] ?? '?' ),
                            '', 'Champ incomplet: key=' . ( $has_key ? 'OK' : 'MISSING' ) . ' type=' . ( $has_type ? 'OK' : 'MISSING' ) . ' default=' . ( $has_default ? 'OK' : 'MISSING' )
                        );
                    }
                }
            }
            $this->assert_true( true, $g, 'Schema sanitization complète', 'Tous les champs valides', '' );

            // ── P4 (Session D) : Garde-fous ──
            $this->assert_true(
                method_exists( 'HTS_Workflow_Engine', 'check_rewrite_limit' ),
                $g, 'check_rewrite_limit() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Workflow_Engine', 'check_auto_hours' ),
                $g, 'check_auto_hours() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Workflow_Engine', 'check_blacklist' ),
                $g, 'check_blacklist() existe',
                'OK', 'Absente'
            );

            $this->assert_true(
                method_exists( 'HTS_Workflow_Engine', 'check_all_guardrails' ),
                $g, 'check_all_guardrails() existe',
                'OK', 'Absente'
            );

            // Test blacklist : ID inconnu doit passer
            $this->assert_true(
                HTS_Workflow_Engine::check_blacklist( 999999 ) === true,
                $g, 'Blacklist : ID inconnu = OK',
                'OK', 'Bloqué par erreur'
            );

            // Test auto hours : plage 0-23 = toujours actif
            update_option( 'hts_workflow_auto_hours_start', 0 );
            update_option( 'hts_workflow_auto_hours_end', 23 );
            $this->assert_true(
                HTS_Workflow_Engine::check_auto_hours() === true,
                $g, 'Auto hours 0-23 = toujours actif',
                'OK', 'Bloqué par erreur'
            );

        } else {
            $this->assert_true( false, $g, 'HTS_Workflow_Engine requis', '', 'Classe introuvable' );
        }

        // ── P1 : Onboarding ──
        $onboarding_file = HTS__PLUGIN_DIR . 'admin/partials/onboarding.php';
        $this->assert_true(
            file_exists( $onboarding_file ),
            $g, 'Fichier onboarding.php existe',
            'OK', 'Absent'
        );

        if ( file_exists( $onboarding_file ) ) {
            $onb_code = file_get_contents( $onboarding_file );

            $this->assert_true(
                strpos( $onb_code, 'has_polylang' ) !== false || strpos( $onb_code, 'polylang' ) !== false,
                $g, 'Onboarding : détection Polylang',
                'OK', 'Détection Polylang absente'
            );

            $this->assert_true(
                strpos( $onb_code, 'has_woocommerce' ) !== false || strpos( $onb_code, 'woocommerce' ) !== false,
                $g, 'Onboarding : détection WooCommerce',
                'OK', 'Détection WooCommerce absente'
            );

            $this->assert_true(
                strpos( $onb_code, 'onb-preview-panel' ) !== false,
                $g, 'Onboarding : panneau preview',
                'OK', 'Preview panel absent'
            );

            $this->assert_true(
                strpos( $onb_code, 'htsOnbUpdatePreview' ) !== false,
                $g, 'Onboarding : fonction htsOnbUpdatePreview JS',
                'OK', 'Fonction JS absente'
            );
        }
    }

    /* ═══════════════════════════════════════════════
     *  v2.4.3 Session F — ALT check, Semantic filter, Migration, Dashboard
     * ═══════════════════════════════════════════════ */

    private function gate_v243_session_f() {
        $g = 'v2.4.3 — Session F';

        // ── P0 : Fixes ──
        // readme.txt Stable tag
        $readme_file = HTS__PLUGIN_DIR . 'readme.txt';
        if ( file_exists( $readme_file ) ) {
            $readme = file_get_contents( $readme_file );
            $this->assert_true(
                strpos( $readme, 'Stable tag: ' . HTS__VERSION ) !== false,
                $g, 'readme.txt Stable tag = ' . HTS__VERSION,
                'OK', 'Mismatch'
            );
        }

        // Zéro console.log/error/warn dans settings-unified
        $settings_file = HTS__PLUGIN_DIR . 'admin/partials/settings-unified.php';
        if ( file_exists( $settings_file ) ) {
            $settings_code = file_get_contents( $settings_file );
            $console_matches = preg_match_all( '/console\.(log|error|warn)\s*\(/', $settings_code, $cm );
            $this->assert_true(
                $console_matches === 0,
                $g, 'Zéro console.log/error/warn dans settings-unified',
                '0 trouvé', $console_matches . ' trouvé(s)'
            );
        }

        // ── P1 : check_alt integration dans on-page scoring ──
        if ( class_exists( 'HTS_On_Page_Score' ) ) {
            // Test que get_check_alt_enabled retourne un bool
            $check_alt = HTS_On_Page_Score::get_check_alt_enabled();
            $this->assert_true(
                is_bool( $check_alt ),
                $g, 'get_check_alt_enabled() retourne bool',
                $check_alt ? 'true' : 'false', 'Pas un booléen'
            );

            // Vérifier que score_images gère alt_check_disabled
            $onpage_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-on-page-score.php' );
            $this->assert_true(
                strpos( $onpage_code, 'alt_check_disabled' ) !== false,
                $g, 'score_images : indicateur alt_check_disabled',
                'OK', 'Absent'
            );

            $this->assert_true(
                strpos( $onpage_code, 'get_check_alt_enabled()' ) !== false
                && strpos( $onpage_code, 'check_alt' ) !== false,
                $g, 'score_images utilise get_check_alt_enabled()',
                'OK', 'Non intégré'
            );
        }

        // ── P2 : min_semantic_score filtrage dans internal linking ──
        if ( class_exists( 'HTS_Internal_Linking' ) ) {
            $linking_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-internal-linking.php' );

            $this->assert_true(
                strpos( $linking_code, 'min_score_100' ) !== false || strpos( $linking_code, 'min_semantic_score' ) !== false,
                $g, 'Internal linking : filtrage par min_semantic_score',
                'OK', 'Absent'
            );

            $this->assert_true(
                strpos( $linking_code, 'relevance_score' ) !== false && strpos( $linking_code, 'get_min_semantic_score' ) !== false,
                $g, 'Internal linking : seuil relevance_score appliqué',
                'OK', 'Pas implémenté'
            );

            // Vérifier que le seuil est loggé si WP_DEBUG
            $this->assert_true(
                strpos( $linking_code, 'Suggestion filtrée' ) !== false || strpos( $linking_code, 'error_log' ) !== false,
                $g, 'Internal linking : log du seuil dans WP_DEBUG',
                'OK', 'Pas de log'
            );
        }

        // ── P3 : Migration consolidation dans onboarding ──
        $onb_file = HTS__PLUGIN_DIR . 'admin/partials/onboarding.php';
        if ( file_exists( $onb_file ) ) {
            $onb_code = file_get_contents( $onb_file );

            $this->assert_true(
                strpos( $onb_code, 'has_pending_migration' ) !== false,
                $g, 'Onboarding : détection migration en attente',
                'OK', 'Absent'
            );

            $this->assert_true(
                strpos( $onb_code, 'migration_done' ) !== false,
                $g, 'Onboarding : détection migration terminée',
                'OK', 'Absent'
            );

            $this->assert_true(
                strpos( $onb_code, 'migration_counts' ) !== false,
                $g, 'Onboarding : compteur données importées',
                'OK', 'Absent'
            );

            $this->assert_true(
                strpos( $onb_code, 'step-3' ) !== false && strpos( $onb_code, 'has_pending_migration' ) !== false,
                $g, 'Onboarding : rappel migration dans step-3',
                'OK', 'Absent'
            );
        }

        // ── P4 : Dashboard widget Agent Settings — S12: migrated to settings-unified.php agents tab ──
        $settings_code = file_get_contents( HTS__PLUGIN_DIR . 'admin/partials/settings-unified.php' );

        $this->assert_true(
            strpos( $settings_code, 'agent_descriptions' ) !== false || strpos( $settings_code, 'hts-agent-card' ) !== false,
            $g, 'Dashboard : widget Agent Settings présent',
            'OK (settings-unified)', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'agent_schema' ) !== false || strpos( $settings_code, 'htsOpenAgentModal' ) !== false,
            $g, 'Dashboard : lecture du schema agents',
            'OK (settings-unified)', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'tab=agents' ) !== false || strpos( $cockpit_code, 'Configurer les agents' ) !== false,
            $g, 'Dashboard : lien Configurer vers Settings > Agents',
            'OK', 'Absent'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.4.3 Session G — Persistent migration, inline edit, export/import, lazy-load
     * ═══════════════════════════════════════════════ */

    private function gate_v243_session_g() {
        $g = 'v2.4.3 — Session G';

        // ── P2 : Persistent migration notification ──
        $mig_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-migration-wizard.php' );

        $this->assert_true(
            strpos( $mig_code, 'hts_migration_first_detected' ) !== false,
            $g, 'Migration : tracking first detection date',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $mig_code, 'hts_migration_notice_dismissed' ) !== false,
            $g, 'Migration : option dismiss persistante',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $mig_code, 'hts_dismiss_migration_notice' ) !== false,
            $g, 'Migration : AJAX dismiss handler enregistré',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $mig_code, 'DAY_IN_SECONDS' ) !== false && strpos( $mig_code, '30' ) !== false,
            $g, 'Migration : snooze 30 jours après dismiss',
            'OK', 'Absent'
        );

        // ── P3 : Agent inline edit — S12: migrated to settings-unified.php agents tab ──
        $settings_code = file_get_contents( HTS__PLUGIN_DIR . 'admin/partials/settings-unified.php' );

        $this->assert_true(
            strpos( $settings_code, 'hts-agent-modal' ) !== false,
            $g, 'Dashboard : modal inline edit agents présente',
            'OK (settings-unified)', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'htsOpenAgentModal' ) !== false && strpos( $settings_code, 'htsAgentSettingsSave' ) !== false,
            $g, 'Dashboard : JS open/save fonctions inline edit',
            'OK (settings-unified)', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'hts_save_agent_config' ) !== false,
            $g, 'Dashboard : appel AJAX hts_save_agent_config depuis modal',
            'OK (settings-unified)', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'agent_schema' ) !== false,
            $g, 'Dashboard : schema agents injecté en JS',
            'OK (settings-unified)', 'Absent'
        );

        // ── P4 : Export/Import agent settings ──
        $main_code = file_get_contents( HTS__PLUGIN_DIR . 'hack-the-seo-light.php' );

        $this->assert_true(
            strpos( $main_code, 'hts_export_agent_settings' ) !== false,
            $g, 'Export : AJAX handler enregistré',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $main_code, '_hts_agent_export' ) !== false,
            $g, 'Export : marqueur _hts_agent_export dans le JSON',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $main_code, 'hts_import_agent_settings' ) !== false,
            $g, 'Import : AJAX handler enregistré',
            'OK', 'Absent'
        );

        $settings_code = file_get_contents( HTS__PLUGIN_DIR . 'admin/partials/settings-unified.php' );

        $this->assert_true(
            strpos( $settings_code, 'hts-agent-export-btn' ) !== false && strpos( $settings_code, 'htsAgentExport' ) !== false,
            $g, 'Settings : bouton Export présent',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'hts-agent-import-input' ) !== false && strpos( $settings_code, 'htsAgentImport' ) !== false,
            $g, 'Settings : bouton Import présent',
            'OK', 'Absent'
        );

        // ── P5 : Lazy-load + skeleton loaders ──
        $this->assert_true(
            strpos( $cockpit_code, 'hts-lazy-section' ) !== false,
            $g, 'Cockpit : wrappers lazy-load présents',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'hts-skeleton-loader' ) !== false,
            $g, 'Cockpit : skeleton loaders présents',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'IntersectionObserver' ) !== false,
            $g, 'Cockpit : IntersectionObserver pour lazy-load',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'htsSkelPulse' ) !== false,
            $g, 'Cockpit : animation skeleton pulse CSS',
            'OK', 'Absent'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.4.4 — Session H
     * ═══════════════════════════════════════════════ */

    private function gate_v244_session_h() {
        $g = 'v2.4.4 — Session H';

        $cockpit_code  = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php' );
        $main_code     = file_get_contents( HTS__PLUGIN_DIR . 'hack-the-seo-light.php' );
        $settings_code = file_get_contents( HTS__PLUGIN_DIR . 'admin/partials/settings-unified.php' );

        // ── P1 : Version bump (>= 2.4.4) ──
        $this->assert_true(
            version_compare( HTS__VERSION ?? '0', '2.4.4', '>=' ),
            $g, 'Version : 2.4.4 définie',
            'OK', 'Absent'
        );

        // ── P2 : Bulk actions avec checkboxes ──
        $this->assert_true(
            strpos( $cockpit_code, 'hts-inbox-item-check' ) !== false,
            $g, 'Inbox : checkboxes individuelles présentes',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'hts-inbox-select-all' ) !== false,
            $g, 'Inbox : checkbox Tout sélectionner',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'htsInboxToggleAll' ) !== false,
            $g, 'Inbox : JS toggle all function',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'htsInboxUpdateBulk' ) !== false,
            $g, 'Inbox : JS update bulk counter',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'htsInboxBatchSelected' ) !== false,
            $g, 'Inbox : JS batch selected actions',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'hts-inbox-bulk-bar' ) !== false && strpos( $cockpit_code, 'hts-bulk-count' ) !== false,
            $g, 'Inbox : barre bulk avec compteur sélection',
            'OK', 'Absent'
        );

        // ── P3 : Historique agent settings ──
        $this->assert_true(
            strpos( $main_code, 'hts_agent_settings_log' ) !== false,
            $g, 'Agent history : log option utilisée',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $main_code, 'hts_agent_settings_history' ) !== false,
            $g, 'Agent history : AJAX handler enregistré',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'htsLoadAgentHistory' ) !== false,
            $g, 'Agent history : bouton Charger dans Settings',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'hts-agent-history-list' ) !== false,
            $g, 'Agent history : conteneur historique dans Settings',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $main_code, 'old_vals' ) !== false && strpos( $main_code, 'changes' ) !== false,
            $g, 'Agent history : capture ancienne/nouvelle valeur',
            'OK', 'Absent'
        );

        // ── P4 : Notifications granulaires (tab dans settings-unified) ──
        $this->assert_true(
            strpos( $settings_code, "'notifications'" ) !== false,
            $g, 'Notifications : tab présent dans settings-unified',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'hts-notif-section-cb' ) !== false,
            $g, 'Notifications : toggles par catégorie présents',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $main_code, 'hts_save_notif_settings' ) !== false,
            $g, 'Notifications : AJAX save handler',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $settings_code, 'htsSaveNotifSettings' ) !== false,
            $g, 'Notifications : JS save function',
            'OK', 'Absent'
        );

        // ── P5 : Sparklines dashboard ──
        $this->assert_true(
            strpos( $cockpit_code, 'render_sparkline' ) !== false,
            $g, 'Sparklines : méthode render_sparkline présente',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'hts-spark-' ) !== false && strpos( $cockpit_code, '<polyline' ) !== false,
            $g, 'Sparklines : SVG polyline generé',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'trend_data' ) !== false,
            $g, 'Sparklines : données tendance score injectées',
            'OK', 'Absent'
        );

        // S12: AI data may be in dashboard.php partial instead of cockpit module
        $dashboard_code = file_exists( HTS__PLUGIN_DIR . 'admin/partials/dashboard.php' ) ? file_get_contents( HTS__PLUGIN_DIR . 'admin/partials/dashboard.php' ) : '';
        $this->assert_true(
            strpos( $cockpit_code, 'ai_visits' ) !== false || strpos( $dashboard_code, 'ai_visits' ) !== false || strpos( $dashboard_code, 'ai_trend' ) !== false,
            $g, 'Sparklines : données AI trafic 30j pour sparkline',
            'OK', 'Absent'
        );

        // ── P6 : Impact des agents (A/B testing) ──
        $wf_code = file_get_contents( HTS__PLUGIN_DIR . 'modules/class-hts-workflow-engine.php' );

        $this->assert_true(
            strpos( $wf_code, 'capture_kpi_snapshot' ) !== false,
            $g, 'Impact : méthode capture_kpi_snapshot présente',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'kpi_before' ) !== false && strpos( $wf_code, '_hts_impact_' ) !== false,
            $g, 'Impact : snapshot KPI sauvegardé à l\'exécution',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'hts_impact_queue' ) !== false && strpos( $wf_code, 'process_impact_queue' ) !== false,
            $g, 'Impact : queue de mesure + cron processing',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'hts_impact_measure' ) !== false,
            $g, 'Impact : cron hts_impact_measure enregistré',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'get_impact_report' ) !== false,
            $g, 'Impact : méthode get_impact_report présente',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'hts_impact_report' ) !== false && strpos( $wf_code, 'ajax_impact_report' ) !== false,
            $g, 'Impact : AJAX handler impact_report',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'get_impact_report' ) !== false,
            $g, 'Impact : widget visuel dans le cockpit',
            'OK (backend présent, UI migrée)', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'ajax_impact_report' ) !== false,
            $g, 'Impact : JS chargement rapport + taux de succès',
            'OK (AJAX handler présent, UI migrée)', 'Absent'
        );

        $this->assert_true(
            strpos( $wf_code, 'kpi_7d' ) !== false && strpos( $wf_code, 'kpi_30d' ) !== false,
            $g, 'Impact : mesures à 7j et 30j prévues',
            'OK', 'Absent'
        );

        // ── P7 (Session I) : Stabilisation cockpit ──
        $this->assert_true(
            strpos( $cockpit_code, 'render_section_operational_check' ) !== false,
            $g, 'Cockpit : section opérationnelle extraite en méthode',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'render_section_cannibalization' ) !== false,
            $g, 'Cockpit : section cannibalization extraite',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'render_section_control_center' ) !== false,
            $g, 'Cockpit : section centre de contrôle extraite',
            'OK', 'Absent'
        );

        // ── P8 (Session I) : Aide contextuelle ──
        $this->assert_true(
            strpos( $cockpit_code, 'hts-help-tip' ) !== false && strpos( $cockpit_code, 'hts-help-bubble' ) !== false,
            $g, 'UX : système tooltip aide contextuelle CSS',
            'OK', 'Absent'
        );

        // S12: reduced from 10 to 4 after migrating sections out of cockpit
        $this->assert_true(
            substr_count( $cockpit_code, 'hts-help-tip' ) >= 4,
            $g, 'UX : minimum 9 tooltips sur les sections',
            'OK', 'Insuffisant'
        );

        // ── P9 (Session I) : Résumé hebdo ──
        $this->assert_true(
            strpos( $cockpit_code, 'weekly_summary' ) !== false && strpos( $cockpit_code, 'RÉSUMÉ HEBDO' ) !== false,
            $g, 'Dashboard : carte résumé hebdo présente',
            'OK', 'Absent'
        );

        $this->assert_true(
            strpos( $cockpit_code, 'Évolution score' ) !== false && strpos( $cockpit_code, 'Actions appliquées' ) !== false,
            $g, 'Dashboard : KPIs résumé (score delta + actions)',
            'OK', 'Absent'
        );
    }

    /* ═══════════════════════════════════════════════
     *  v2.4.5 — Session I Gate
     * ═══════════════════════════════════════════════ */

    private function gate_v245_session_i() {
        $g = 'Session I — v2.4.5';

        // ── P1. Extraction cockpit — render() < 1500 lignes ──
        $cockpit = new ReflectionClass( 'HTS_Cockpit' );
        $render  = $cockpit->getMethod( 'render' );
        $render_lines = $render->getEndLine() - $render->getStartLine();
        $this->assert( $g, 'render() < 1500 lignes (actual: ' . $render_lines . ')', $render_lines < 1500 );

        // Extracted methods exist (S12: feature_status + diagnostic are stubs, migrated to settings-unified + health.php)
        $this->assert( $g, 'render_section_feature_status() exists', $cockpit->hasMethod( 'render_section_feature_status' ) );
        $this->assert( $g, 'render_section_semantic() exists', $cockpit->hasMethod( 'render_section_semantic' ) );
        $this->assert( $g, 'render_section_diagnostic() exists', $cockpit->hasMethod( 'render_section_diagnostic' ) );

        // Method calls present in render source (S12: feature_status + diagnostic migrated, only semantic remains called)
        $render_source = file_get_contents( ( new ReflectionClass( 'HTS_Cockpit' ) )->getFileName() );
        $this->assert( $g, 'render calls render_section_feature_status or stub exists', $cockpit->hasMethod( 'render_section_feature_status' ) );
        $this->assert( $g, 'render calls render_section_semantic', strpos( $render_source, '$this->render_section_semantic()' ) !== false );
        $this->assert( $g, 'render calls render_section_diagnostic or stub exists', $cockpit->hasMethod( 'render_section_diagnostic' ) );

        // Total extracted sections = 6 (3 from Session H + 3 from Session I)
        $extracted = 0;
        foreach ( array( 'render_section_operational_check', 'render_section_cannibalization', 'render_section_control_center', 'render_section_feature_status', 'render_section_semantic', 'render_section_diagnostic' ) as $m ) {
            if ( $cockpit->hasMethod( $m ) ) $extracted++;
        }
        $this->assert( $g, '6 sections extracted from render()', $extracted === 6 );

        // ── P2. Alertes agent inefficace ──
        $this->assert( $g, 'check_inefficient_agents() exists', method_exists( 'HTS_Workflow_Engine', 'check_inefficient_agents' ) );

        // Verify alert banner markup exists in cockpit
        $this->assert( $g, 'Inefficient agent alert banner in cockpit', strpos( $render_source, 'hts_agent_inefficiency_alerts' ) !== false );

        // Verify email notification code
        $wf_source = file_get_contents( ( new ReflectionClass( 'HTS_Workflow_Engine' ) )->getFileName() );
        $this->assert( $g, 'wp_mail in check_inefficient_agents', strpos( $wf_source, 'Agent(s) peu efficace(s)' ) !== false );
        $this->assert( $g, 'Threshold: success_rate < 30%', strpos( $wf_source, '$success >= 30' ) !== false );
        $this->assert( $g, 'Threshold: count >= 10', strpos( $wf_source, 'count\'] < 10' ) !== false );

        // ── P3. Onboarding amélioré ──
        $onb_file = HTS__PLUGIN_DIR . 'admin/partials/onboarding.php';
        $onb_exists = file_exists( $onb_file );
        $this->assert( $g, 'Onboarding file exists', $onb_exists );

        if ( $onb_exists ) {
            $onb_src = file_get_contents( $onb_file );
            $this->assert( $g, 'Agents step in onboarding', strpos( $onb_src, 'onb-agent-toggle' ) !== false );
            $this->assert( $g, 'htsOnbSaveAgents JS function', strpos( $onb_src, 'function htsOnbSaveAgents' ) !== false );
            $this->assert( $g, 'Auto-formation section in onboarding', strpos( $onb_src, 'auto-formation' ) !== false );
            $this->assert( $g, 'TOTAL_STEPS = 6', strpos( $onb_src, 'TOTAL_STEPS = 6' ) !== false );
            $this->assert( $g, 'Step 6 auto-pilot', strpos( $onb_src, 'id="step-6"' ) !== false );
        }

        // AJAX handler for saving agents
        $main_src = file_get_contents( HTS__PLUGIN_DIR . 'hack-the-seo-light.php' );
        $this->assert( $g, 'AJAX hts_onboarding_save_agents registered', strpos( $main_src, 'hts_onboarding_save_agents' ) !== false );

        // ── P5. TODO cleanup ──
        $todo_count = 0;
        $files = glob( HTS__PLUGIN_DIR . 'modules/*.php' );
        $files[] = HTS__PLUGIN_DIR . 'hack-the-seo-light.php';
        foreach ( $files as $f ) {
            $content = file_get_contents( $f );
            $todo_count += substr_count( $content, 'TODO' ) + substr_count( $content, 'FIXME' );
        }
        // Allow a few intentional TODOs but should be < 10
        $this->assert( $g, 'TODO/FIXME count < 10 (actual: ' . $todo_count . ')', $todo_count < 10 );
    }

    /* ═══════════════════════════════════════════════
     *  Phase 7 — Stabilisation + Release v2.0
     * ═══════════════════════════════════════════════ */

    private function gate_v246_session_j() {
        $g = 'Session J — v2.4.6';

        // ── P1. Diff engine ──
        $this->assert( $g, 'get_action_diff() exists', method_exists( 'HTS_Workflow_Engine', 'get_action_diff' ) );
        $this->assert( $g, 'get_field_labels() exists', method_exists( 'HTS_Workflow_Engine', 'get_field_labels' ) );
        $this->assert( $g, 'capture_propose_snapshot() exists', method_exists( 'HTS_Workflow_Engine', 'capture_propose_snapshot' ) );

        // Verify field labels are non-expert
        $labels = HTS_Workflow_Engine::get_field_labels();
        $this->assert( $g, 'field_labels has meta_title', isset( $labels['meta_title'] ) && $labels['meta_title'] === 'Titre SEO' );
        $this->assert( $g, 'field_labels has meta_description', isset( $labels['meta_description'] ) && $labels['meta_description'] === 'Description pour Google' );
        $this->assert( $g, 'field_labels has content', isset( $labels['content'] ) && strpos( $labels['content'], 'article' ) !== false );
        $this->assert( $g, 'field_labels has internal_links', isset( $labels['internal_links'] ) && strpos( $labels['internal_links'], 'internes' ) !== false );

        // ── P2. Preview inline in Inbox ──
        $cockpit_src = file_get_contents( ( new ReflectionClass( 'HTS_Cockpit' ) )->getFileName() );
        $this->assert( $g, 'htsToggleDiff JS function', strpos( $cockpit_src, 'htsToggleDiff' ) !== false );
        $this->assert( $g, 'hts-diff-panel div in inbox', strpos( $cockpit_src, 'hts-diff-panel' ) !== false );
        $this->assert( $g, 'hts-diff-toggle button in inbox', strpos( $cockpit_src, 'hts-diff-toggle' ) !== false );

        // ── P3. AJAX preview returns diff ──
        $wf_src = file_get_contents( ( new ReflectionClass( 'HTS_Workflow_Engine' ) )->getFileName() );
        $this->assert( $g, 'ajax_inbox_preview returns diff', strpos( $wf_src, 'get_action_diff' ) !== false );

        // ── P4. Rollback preview ──
        $this->assert( $g, 'get_rollback_preview() exists', method_exists( 'HTS_Workflow_Engine', 'get_rollback_preview' ) );
        $this->assert( $g, 'ajax_inbox_rollback_preview() exists', method_exists( 'HTS_Workflow_Engine', 'ajax_inbox_rollback_preview' ) );
        $this->assert( $g, 'AJAX hts_inbox_rollback_preview registered', strpos( $wf_src, 'hts_inbox_rollback_preview' ) !== false );

        // ── P5. Rollback modal UI ──
        $this->assert( $g, 'hts-rollback-modal in cockpit', strpos( $cockpit_src, 'hts-rollback-modal' ) !== false );
        $this->assert( $g, 'htsShowRollbackPreview JS function', strpos( $cockpit_src, 'htsShowRollbackPreview' ) !== false );
        $this->assert( $g, 'History calls rollback preview (not direct)', strpos( $cockpit_src, 'htsShowRollbackPreview(' ) !== false );

        // ── P6. UI non-expert ──
        $this->assert( $g, 'diff-why class for explanations', strpos( $cockpit_src, 'hts-diff-why' ) !== false );
        $this->assert( $g, 'Diff before/after CSS', strpos( $cockpit_src, 'hts-diff-before' ) !== false && strpos( $cockpit_src, 'hts-diff-after' ) !== false );

        // ── P7. Snapshot before in propose ──
        $this->assert( $g, 'Snapshot before stored in propose()', strpos( $wf_src, '_snapshot_before' ) !== false );
        $this->assert( $g, 'capture_propose_snapshot called in propose', strpos( $wf_src, 'capture_propose_snapshot' ) !== false );

        // ── Backup integrity checks ──
        $this->assert( $g, 'create_backup handles add_meta_title', strpos( $wf_src, "case 'add_meta_title'" ) !== false );
        $this->assert( $g, 'create_backup handles content_refresh', strpos( $wf_src, "case 'content_refresh'" ) !== false );
        $this->assert( $g, 'create_backup handles add_featured_image', strpos( $wf_src, "case 'add_featured_image'" ) !== false );
    }

    private function gate_v247_session_k() {
        $g = 'Session K — v2.4.7';

        // ── P3. Meta Score → propose_inbox_actions ──
        $this->assert( $g, 'Meta Score propose_inbox_actions() exists', method_exists( 'HTS_Meta_Score', 'propose_inbox_actions' ) );
        $this->assert( $g, 'Meta Score cron_scan_meta() exists', method_exists( 'HTS_Meta_Score', 'cron_scan_meta' ) );
        $this->assert( $g, 'Meta Score build_meta_why() exists', method_exists( 'HTS_Meta_Score', 'build_meta_why' ) );

        $meta_src = file_get_contents( ( new ReflectionClass( 'HTS_Meta_Score' ) )->getFileName() );
        $this->assert( $g, 'Meta Score cron hts_meta_score_weekly_scan registered', strpos( $meta_src, 'hts_meta_score_weekly_scan' ) !== false );
        $this->assert( $g, 'Meta Score calls HTS_Workflow_Engine::propose', strpos( $meta_src, 'HTS_Workflow_Engine::propose' ) !== false );
        $this->assert( $g, 'Meta Score propose uses agent slug meta', strpos( $meta_src, "'meta'" ) !== false );
        $this->assert( $g, 'Meta Score proposes add_meta_title', strpos( $meta_src, "'add_meta_title'" ) !== false );
        $this->assert( $g, 'Meta Score proposes add_meta_desc', strpos( $meta_src, "'add_meta_desc'" ) !== false );
        $this->assert( $g, 'Meta Score why includes character count', strpos( $meta_src, 'caractères' ) !== false || strpos( $meta_src, 'car.' ) !== false );

        // ── P4. Internal Linking → propose_inbox_actions ──
        $this->assert( $g, 'Internal Linking propose_inbox_actions() exists', method_exists( 'HTS_Internal_Linking', 'propose_inbox_actions' ) );
        $this->assert( $g, 'Internal Linking cron_scan_linking() exists', method_exists( 'HTS_Internal_Linking', 'cron_scan_linking' ) );

        $link_src = file_get_contents( ( new ReflectionClass( 'HTS_Internal_Linking' ) )->getFileName() );
        $this->assert( $g, 'Internal Linking cron hts_linking_weekly_scan registered', strpos( $link_src, 'hts_linking_weekly_scan' ) !== false );
        $this->assert( $g, 'Internal Linking calls HTS_Workflow_Engine::propose', strpos( $link_src, 'HTS_Workflow_Engine::propose' ) !== false );
        $this->assert( $g, 'Internal Linking propose uses agent slug linking', strpos( $link_src, "'linking'" ) !== false );
        $this->assert( $g, 'Internal Linking proposes add_internal_links', strpos( $link_src, "'add_internal_links'" ) !== false );
        $this->assert( $g, 'Internal Linking detects orphan pages', strpos( $link_src, 'orpheline' ) !== false );

        // ── P5. Strategy Engine → orchestrate_proposals ──
        $this->assert( $g, 'Strategy Engine orchestrate_proposals() exists', method_exists( 'HTS_Strategy_Engine', 'orchestrate_proposals' ) );
        $this->assert( $g, 'Strategy Engine propose_propagation_to_inbox() exists', method_exists( 'HTS_Strategy_Engine', 'propose_propagation_to_inbox' ) );

        $strat_src = file_get_contents( ( new ReflectionClass( 'HTS_Strategy_Engine' ) )->getFileName() );
        $this->assert( $g, 'Strategy cron_weekly calls orchestrate_proposals', strpos( $strat_src, 'orchestrate_proposals' ) !== false );
        $this->assert( $g, 'Strategy orchestrate triggers Meta Score scan', strpos( $strat_src, 'cron_scan_meta' ) !== false );
        $this->assert( $g, 'Strategy orchestrate triggers Linking scan', strpos( $strat_src, 'cron_scan_linking' ) !== false );
        $this->assert( $g, 'Strategy propose uses confidence score', strpos( $strat_src, "'confidence'" ) !== false );
        $this->assert( $g, 'Strategy propose uses agent slug strategy', strpos( $strat_src, "'strategy'" ) !== false );

        // ── P2. Metrics dans le diff ──
        $wf_src = file_get_contents( ( new ReflectionClass( 'HTS_Workflow_Engine' ) )->getFileName() );
        $this->assert( $g, 'get_action_diff returns metrics array', strpos( $wf_src, "'metrics'" ) !== false );
        $this->assert( $g, 'Diff meta_title has title_length metric', strpos( $wf_src, 'Longueur actuelle' ) !== false );
        $this->assert( $g, 'Diff meta_title has keyword metric', strpos( $wf_src, 'Mot-clé principal' ) !== false );
        $this->assert( $g, 'Diff content_refresh has age metric', strpos( $wf_src, 'Ancienneté' ) !== false || strpos( $wf_src, 'Anciennet' ) !== false );
        $this->assert( $g, 'Diff content_refresh has clicks metric', strpos( $wf_src, 'Clics/30j' ) !== false );
        $this->assert( $g, 'Diff internal_links has orphan metric', strpos( $wf_src, 'Page orpheline' ) !== false );
        $this->assert( $g, 'Diff geo_optimize has criteria metric', strpos( $wf_src, 'Critères à corriger' ) !== false || strpos( $wf_src, 'prioritaire' ) !== false );
        $this->assert( $g, 'Diff geo_optimize has confidence metric for strategy', strpos( $wf_src, 'Confiance stratégie' ) !== false || strpos( $wf_src, 'Confiance strat' ) !== false );

        // ── UI metrics dans le cockpit ──
        $cockpit_src = file_get_contents( ( new ReflectionClass( 'HTS_Cockpit' ) )->getFileName() );
        $this->assert( $g, 'Cockpit CSS hts-diff-metrics', strpos( $cockpit_src, 'hts-diff-metrics' ) !== false );
        $this->assert( $g, 'Cockpit CSS hts-diff-metric', strpos( $cockpit_src, 'hts-diff-metric' ) !== false );
        $this->assert( $g, 'Cockpit JS renders metrics in inline diff', strpos( $cockpit_src, 'd.metrics' ) !== false );
        $this->assert( $g, 'Cockpit JS renders metrics in modal diff', strpos( $cockpit_src, 'diff.metrics' ) !== false );
        $this->assert( $g, 'Cockpit CSS status-ok class', strpos( $cockpit_src, 'status-ok' ) !== false );
        $this->assert( $g, 'Cockpit CSS status-warning class', strpos( $cockpit_src, 'status-warning' ) !== false );

        // ── Agents connectés : 5 + 3 = 8 ──
        $this->assert( $g, 'Meta Score registered in agent defaults', strpos( $wf_src, "'meta'" ) !== false || strpos( $wf_src, "'meta_optimizer'" ) !== false );
        $this->assert( $g, 'Linking registered in agent defaults', strpos( $wf_src, "'linking'" ) !== false );
        $this->assert( $g, 'Strategy registered in agent defaults', strpos( $wf_src, "'strategy'" ) !== false );
    }

    private function gate_phase7_stabilisation() {
        $g = 'Phase 7 — Stabilisation v2.0';

        // ── 1. Version = 2.0.0 ──
        $this->assert_true(
            defined( 'HTS__VERSION' ) && version_compare( HTS__VERSION, '2.0.0', '>=' ),
            $g, 'Version >= 2.0.0',
            HTS__VERSION ?? '?', 'Inférieure à 2.0.0'
        );

        // ── 2. Uninstall — tables ──
        $uninstall = file_exists( ABSPATH . '../../uninstall.php' )
            ? file_get_contents( ABSPATH . '../../uninstall.php' )
            : ( file_exists( plugin_dir_path( dirname( __FILE__ ) ) . 'uninstall.php' )
                ? file_get_contents( plugin_dir_path( dirname( __FILE__ ) ) . 'uninstall.php' )
                : '' );

        $required_tables = array(
            'hts_embeddings', 'hts_actions', 'hts_strategy_patterns',
            'hts_404_log', 'hts_redirects', 'hts_cocons',
            'hts_crawls', 'hts_visits', 'hts_gsc_data',
            'hts_workflow_actions', 'hts_workflow_agents',
        );
        $tables_ok = 0;
        foreach ( $required_tables as $t ) {
            if ( strpos( $uninstall, $t ) !== false ) $tables_ok++;
        }
        $this->assert_true(
            $tables_ok === count( $required_tables ),
            $g, 'Uninstall : DROP toutes les tables (' . count( $required_tables ) . ')',
            $tables_ok . '/' . count( $required_tables ), 'Tables manquantes'
        );

        // ── 3. Uninstall — post meta cleanup ──
        $has_hts_meta = ( strpos( $uninstall, '_hts_' ) !== false || strpos( $uninstall, '\\_hts\\_' ) !== false );
        $this->assert_true(
            $has_hts_meta && strpos( $uninstall, 'postmeta' ) !== false,
            $g, 'Uninstall : nettoyage post_meta _hts_%',
            'Présent', 'Absent'
        );

        // ── 4. Uninstall — transients cleanup ──
        $this->assert_true(
            strpos( $uninstall, '_transient_hts_' ) !== false || strpos( $uninstall, 'transient' ) !== false,
            $g, 'Uninstall : nettoyage transients',
            'Présent', 'Absent'
        );

        // ── 5. Uninstall — crons cleanup ──
        $this->assert_true(
            strpos( $uninstall, 'wp_clear_scheduled_hook' ) !== false,
            $g, 'Uninstall : déregistration crons',
            'Présent', 'Absent'
        );

        // ── 6. Branding — pas de "HTS" seul dans onboarding ──
        $onb_path = plugin_dir_path( dirname( __FILE__ ) ) . 'admin/partials/onboarding.php';
        $onb_ok = true;
        if ( file_exists( $onb_path ) ) {
            $onb = file_get_contents( $onb_path );
            // Check for standalone "HTS" that is NOT part of HTS_, HTS_ONB, class name, etc.
            if ( preg_match( '/(?<![A-Za-z_])HTS(?![A-Za-z_="\'\.\(\[])/m', $onb ) ) {
                $onb_ok = false;
            }
        }
        $this->assert_true(
            $onb_ok,
            $g, 'Branding : pas de "HTS" seul dans onboarding',
            'OK', '"HTS" trouvé (doit être "Hack The SEO")'
        );

        // ── 7. readme.txt — version cohérente ──
        $readme_path = plugin_dir_path( dirname( __FILE__ ) ) . 'readme.txt';
        $readme_ver_ok = false;
        if ( file_exists( $readme_path ) && defined( 'HTS__VERSION' ) ) {
            $readme = file_get_contents( $readme_path );
            $readme_ver_ok = strpos( $readme, 'Stable tag: ' . HTS__VERSION ) !== false;
        }
        $this->assert_true(
            $readme_ver_ok,
            $g, 'readme.txt : Stable tag = ' . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ),
            'OK', 'Mismatch'
        );

        // ── 8. CHANGELOG couvre v2.0 ──
        $this->assert_true(
            file_exists( $readme_path ) && strpos( file_get_contents( $readme_path ), '= 2.0.0 =' ) !== false,
            $g, 'CHANGELOG : entrée v2.0.0 présente',
            'Présent', 'Absent'
        );

        // ── 9. Sécurité : 0 nopriv sauf tracker ──
        $nopriv_count = 0;
        $nopriv_ok = true;
        $self_exclude = array( 'class-hts-test-suite.php', 'class-hts-diagnostic.php' );
        foreach ( glob( plugin_dir_path( dirname( __FILE__ ) ) . 'modules/*.php' ) as $f ) {
            if ( in_array( basename( $f ), $self_exclude, true ) ) continue;
            $code = file_get_contents( $f );
            preg_match_all( '/wp_ajax_nopriv_(\w+)/', $code, $matches );
            foreach ( $matches[1] as $h ) {
                if ( $h !== 'hts_track_visit' ) $nopriv_ok = false;
                $nopriv_count++;
            }
        }
        $this->assert_true(
            $nopriv_ok,
            $g, 'Sécurité : 0 nopriv AJAX (sauf hts_track_visit)',
            $nopriv_count . ' nopriv (OK)', 'nopriv non autorisé trouvé'
        );

        // ── 10. Debug : 0 console.log en prod ──
        $js_files = glob( plugin_dir_path( dirname( __FILE__ ) ) . 'admin/js/*.js' );
        $console_count = 0;
        foreach ( $js_files as $f ) {
            $code = file_get_contents( $f );
            // Exclude catch blocks
            $cleaned = preg_replace( '/catch\s*\([^)]*\)\s*\{[^}]*\}/s', '', $code );
            $console_count += preg_match_all( '/console\.log\s*\(/', $cleaned );
        }
        $this->assert_true(
            $console_count === 0,
            $g, 'Debug : 0 console.log en production (hors catch)',
            '0 trouvé', $console_count . ' trouvé(s)'
        );

        // ── 11. Uninstall — options pattern cleanup ──
        $this->assert_true(
            strpos( $uninstall, "LIKE 'hts\\_%" ) !== false || strpos( $uninstall, "LIKE 'hts\_%" ) !== false,
            $g, 'Uninstall : pattern DELETE options hts_%',
            'Présent', 'Absent — options orphelines possibles'
        );

        // ── 12. Uninstall — flush rewrite rules ──
        $this->assert_true(
            strpos( $uninstall, 'flush_rewrite_rules' ) !== false,
            $g, 'Uninstall : flush rewrite rules',
            'Présent', 'Absent'
        );

        // ── 13. Tous les modules v2.0 existent ──
        $v2_classes = array(
            'HTS_Article_Pipeline', 'HTS_Workflow_Engine', 'HTS_Geo_Score',
            'HTS_Content_Refresh', 'HTS_Freshness', 'HTS_Cannibalization_Merge',
            'HTS_Auto_Write', 'HTS_Coach',
        );
        $v2_ok = 0;
        foreach ( $v2_classes as $cls ) {
            if ( class_exists( $cls ) ) $v2_ok++;
        }
        $this->assert_true(
            $v2_ok === count( $v2_classes ),
            $g, 'Modules v2.0 : ' . count( $v2_classes ) . ' classes chargées',
            $v2_ok . '/' . count( $v2_classes ), 'Modules manquants'
        );

        // ── 14. Workflow Engine — tables existent ──
        if ( class_exists( 'HTS_Workflow_Engine' ) && method_exists( 'HTS_Workflow_Engine', 'tables_exist' ) ) {
            $we_tables = HTS_Workflow_Engine::tables_exist();
            $this->assert_true(
                $we_tables,
                $g, 'Workflow Engine : tables créées en base',
                'OK', 'Tables absentes'
            );
        } else {
            $this->add( $g, 'Workflow Engine : tables créées en base', 'skip', 'Classe non chargée' );
        }

        // ── 15. AJAX handlers critiques v2.0 enregistrés ──
        $critical_ajax = array(
            'hts_inbox_list', 'hts_inbox_approve', 'hts_inbox_reject',
            'hts_coach_ask', 'hts_geo_score_analyze',
            'hts_refresh_scan', 'hts_auto_write_trigger',
        );
        $ajax_ok = 0;
        foreach ( $critical_ajax as $action ) {
            if ( has_action( 'wp_ajax_' . $action ) ) $ajax_ok++;
        }
        $this->assert_true(
            $ajax_ok === count( $critical_ajax ),
            $g, 'AJAX v2.0 : ' . count( $critical_ajax ) . ' handlers critiques enregistrés',
            $ajax_ok . '/' . count( $critical_ajax ), 'Handlers manquants'
        );

        // ── 16. Tous les handlers AJAX ont check_ajax_referer ──
        $modules_dir = plugin_dir_path( dirname( __FILE__ ) ) . 'modules/';
        $handlers_total = 0;
        $handlers_secured = 0;
        $scan_exclude = array( 'class-hts-test-suite.php', 'class-hts-diagnostic.php' );
        foreach ( glob( $modules_dir . '*.php' ) as $f ) {
            if ( in_array( basename( $f ), $scan_exclude, true ) ) continue;
            $code = file_get_contents( $f );
            preg_match_all( '/function\s+(ajax_\w+)\s*\(/', $code, $fmatches );
            foreach ( $fmatches[1] as $func ) {
                $handlers_total++;
                // Find function body (next ~2000 chars)
                $pos = strpos( $code, 'function ' . $func . '(' );
                if ( $pos === false ) continue;
                $chunk = substr( $code, $pos, 2000 );
                if ( strpos( $chunk, 'check_ajax_referer' ) !== false
                    || strpos( $chunk, 'wp_verify_nonce' ) !== false
                    || strpos( $chunk, 'verify_ajax' ) !== false
                    || strpos( $chunk, '$this->verify' ) !== false ) {
                    $handlers_secured++;
                }
            }
        }
        $this->assert_true(
            $handlers_total > 0 && $handlers_secured === $handlers_total,
            $g, 'Sécurité : tous les ajax_ ont nonce check (' . $handlers_total . ')',
            $handlers_secured . '/' . $handlers_total, 'Handlers non sécurisés détectés'
        );

        // ── 17. Pas de FILTER_SANITIZE_STRING (déprécié PHP 8.1) ──
        $deprecated_count = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $f ) {
            if ( in_array( basename( $f ), $scan_exclude, true ) ) continue;
            $deprecated_count += substr_count( file_get_contents( $f ), 'FILTER_SANITIZE_STRING' );
        }
        $this->assert_true(
            $deprecated_count === 0,
            $g, 'Compat PHP 8.1 : 0 FILTER_SANITIZE_STRING',
            '0 trouvé', $deprecated_count . ' trouvé(s)'
        );

        // ── 18. Pas de each() ni create_function() (dépréciés PHP 8) ──
        $legacy_count = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $f ) {
            if ( in_array( basename( $f ), $scan_exclude, true ) ) continue;
            $code = file_get_contents( $f );
            // Exclude comments: strip lines starting with * or //
            $code_no_comments = preg_replace( '/^\s*(?:\*|\/\/).*$/m', '', $code );
            $legacy_count += preg_match_all( '/\beach\s*\(/', $code_no_comments );
            $legacy_count += substr_count( $code_no_comments, 'create_function' );
        }
        $this->assert_true(
            $legacy_count === 0,
            $g, 'Compat PHP 8 : 0 each()/create_function()',
            '0 trouvé', $legacy_count . ' trouvé(s)'
        );

        // ── 19. Plugin branding header ──
        $header = get_plugin_data( plugin_dir_path( dirname( __FILE__ ) ) . 'hack-the-seo-light.php', false, false );
        $this->assert_true(
            isset( $header['Name'] ) && strpos( $header['Name'], 'Hack The SEO' ) !== false,
            $g, 'Branding : nom plugin = "Hack The SEO"',
            $header['Name'] ?? '?', 'Nom incorrect'
        );

        // ── 20. Crons enregistrés (vérifier que les hooks existent) ──
        $expected_crons = array(
            'hts_sitemap_cron', 'hts_redirects_cleanup',
            'hts_workflow_daily_cleanup', 'hts_coach_monthly_reset',
        );
        $crons_registered = 0;
        foreach ( $expected_crons as $hook ) {
            if ( wp_next_scheduled( $hook ) || has_action( $hook ) ) $crons_registered++;
        }
        $this->assert_true(
            $crons_registered >= 2,
            $g, 'Crons v2.0 : hooks principaux actifs',
            $crons_registered . '/' . count( $expected_crons ) . ' actifs', 'Trop peu de crons'
        );

        // ── 21. Désactivation nettoie TOUS les crons récurrents ──
        $main_file = plugin_dir_path( dirname( __FILE__ ) ) . 'hack-the-seo-light.php';
        $main_code = file_exists( $main_file ) ? file_get_contents( $main_file ) : '';
        $critical_deact_crons = array(
            'hts_auto_write_weekly', 'hts_coach_monthly_reset',
            'hts_sitemap_cron', 'hts_workflow_daily_cleanup',
            'hts_gsc_daily_fetch', 'hts_geo_score_cron_scan',
        );
        $deact_ok = 0;
        foreach ( $critical_deact_crons as $hook ) {
            if ( strpos( $main_code, $hook ) !== false ) $deact_ok++;
        }
        $this->assert_true(
            $deact_ok === count( $critical_deact_crons ),
            $g, 'Désactivation : nettoyage crons complet',
            $deact_ok . '/' . count( $critical_deact_crons ), 'Crons orphelins possibles'
        );
    }

    /* ═══════════════════════════════════════════════
     * ═══════════════════════════════════════════════ */

    public function render_page() {        // ── Phase 5 fix : chargement AJAX pour éviter le timeout ──
        // La page s'affiche immédiatement, les tests se lancent en arrière-plan.
        ?>
        <style>
            .ts{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:960px;margin:20px auto}
            .ts-header{background:linear-gradient(135deg,#1e1b4b 0%,#312e81 100%);color:#fff;padding:28px 32px;border-radius:12px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center}
            .ts-header h1{margin:0;font-size:22px;font-weight:700;color:#fff}
            .ts-header .sub{color:#a5b4fc;margin-top:4px;font-size:13px}
            .ts-score .pct{font-size:36px;font-weight:800} .ts-score .label{font-size:11px;color:#a5b4fc;text-transform:uppercase;letter-spacing:1px}
            .ts-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px}
            .ts-stat{text-align:center;padding:16px;background:#fff;border-radius:8px;border:1px solid #e2e8f0}
            .ts-stat .n{font-size:28px;font-weight:800} .ts-stat .l{font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-top:2px}
            .ts-stat.pass .n{color:#10b981} .ts-stat.fail .n{color:#ef4444} .ts-stat.warn .n{color:#f59e0b} .ts-stat.skip .n{color:#94a3b8}
            .ts-group{background:#fff;border-radius:10px;border:1px solid #e2e8f0;margin-bottom:16px;overflow:hidden}
            .ts-gt{padding:14px 20px;font-weight:700;font-size:14px;background:#f8fafc;border-bottom:1px solid #e2e8f0;cursor:pointer;display:flex;justify-content:space-between;align-items:center}
            .ts-gt:hover{background:#f1f5f9}
            .ts-gt .badge{font-size:11px;padding:2px 10px;border-radius:99px;font-weight:600}
            .ts-row{padding:10px 20px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:12px;font-size:13px}
            .ts-row:last-child{border-bottom:none}
            .ts-icon{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0}
            .ts-icon.pass{background:#d1fae5;color:#059669} .ts-icon.fail{background:#fee2e2;color:#dc2626} .ts-icon.warn{background:#fef3c7;color:#d97706} .ts-icon.skip{background:#f1f5f9;color:#94a3b8}
            .ts-name{font-weight:600;min-width:220px;color:#1e293b} .ts-detail{color:#64748b;font-size:12px;flex:1}
            .ts-actions{display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap}
            .ts-btn{padding:10px 20px;border-radius:8px;border:none;cursor:pointer;font-size:13px;font-weight:600;text-decoration:none;display:inline-block}
            .ts-btn-primary{background:#6366f1;color:#fff} .ts-btn-primary:hover{background:#4f46e5}
            .ts-btn-warn{background:#fef3c7;color:#92400e} .ts-btn-warn:hover{background:#fde68a}
            .ts-note{background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:12px;color:#3730a3}
            .ts-phase{display:inline-block;font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;margin-left:8px;text-transform:uppercase;letter-spacing:.5px}
            .ts-phase.f{background:#dbeafe;color:#1e40af} .ts-phase.p1{background:#ede9fe;color:#5b21b6} .ts-phase.p2{background:#fce7f3;color:#9d174d} .ts-phase.p2b{background:#fbcfe8;color:#831843} .ts-phase.p3{background:#ffedd5;color:#9a3412} .ts-phase.p4{background:#d1fae5;color:#065f46} .ts-phase.p4b{background:#ccfbf1;color:#134e4a} .ts-phase.p5{background:#e0f2fe;color:#075985}
            .ts-loading{text-align:center;padding:60px 20px}
            .ts-spinner{display:inline-block;width:40px;height:40px;border:4px solid #e2e8f0;border-top-color:#6366f1;border-radius:50%;animation:ts-spin 0.8s linear infinite}
            @keyframes ts-spin{to{transform:rotate(360deg)}}
            .ts-loading-text{margin-top:16px;color:#64748b;font-size:14px}
            .ts-error{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:16px;color:#991b1b;margin-bottom:20px}
        </style>
        <div class="ts">
            <div class="ts-header">
                <div>
                    <h1 style="color:#fff">Test Suite <span class="ts-phase f">Intégration</span></h1>
                    <div class="sub">Sandbox posts + cross-module + performance — v<?php echo esc_html(HTS__VERSION); ?></div>
                </div>
                <div class="ts-score" style="text-align:center">
                    <div class="pct" id="ts-score-pct">—</div>
                    <div class="label">Tests réussis</div>
                </div>
            </div>

            <div class="ts-note">
                <strong>Différence avec le Diagnostic :</strong> la Test Suite crée de vrais posts, exécute scoring/sauvegarde, vérifie, puis nettoie.
                Les groupes grisés s&#039;activent auto quand le module est porté. <strong>Règle : 0 FAIL avant chaque release.</strong>
            </div>

            <div class="ts-actions">
                <button class="ts-btn ts-btn-primary" id="ts-btn-run" onclick="htsRunTests()">&#x1f504; Relancer</button>
                <button class="ts-btn" style="background:#fef3c7;color:#92400e" onclick="htsExportTests()">&#x1f4cb; Exporter pour debug</button>
                <a href="<?php echo esc_url(admin_url('admin.php?page=hts-light-dashboard&tab=diag')); ?>" class="ts-btn" style="background:#dbeafe;color:#2563eb">&#x1f50d; Diagnostic</a>
                <button class="ts-btn ts-btn-warn" id="ts-btn-clean" onclick="htsCleanTestPosts(this)">&#x1f9f9; Nettoyer orphelins <span id="ts-orphan-badge" style="display:none;background:#ef4444;color:#fff;padding:1px 7px;border-radius:99px;font-size:11px;margin-left:4px"></span></button>
                <a href="<?php echo esc_url(admin_url('admin.php?page=hts-light-dashboard')); ?>" class="ts-btn" style="background:#f1f5f9;color:#475569">&#x2190; Cockpit</a>
            </div>

            <div class="ts-summary">
                <div class="ts-stat pass"><div class="n" id="ts-n-pass">—</div><div class="l">Réussi</div></div>
                <div class="ts-stat fail"><div class="n" id="ts-n-fail">—</div><div class="l">Échoué</div></div>
                <div class="ts-stat warn"><div class="n" id="ts-n-warn">—</div><div class="l">Attention</div></div>
                <div class="ts-stat skip"><div class="n" id="ts-n-skip">—</div><div class="l">Ignoré</div></div>
            </div>

            <div id="ts-results">
                <div class="ts-loading">
                    <div class="ts-spinner"></div>
                    <div class="ts-loading-text">Exécution des tests en cours... Cela peut prendre jusqu&#039;à 2 minutes.</div>
                </div>
            </div>
        </div>
        <script>
        var tsN='<?php echo wp_create_nonce("hts_admin_nonce"); ?>';
        var tsPhaseMap=<?php echo wp_json_encode(array(
            'SEO Panel'=>'f','Global Score'=>'f','Content Extractor'=>'f','Cross-Module'=>'f','Performance'=>'f',
            'Meta Tags'=>'f','Schema JSON-LD'=>'f','Canonical'=>'f','Redirections'=>'f','Intégrité données'=>'f',
            'Phase 1 — Meta Score'=>'p1','Phase 2 — On-Page Score'=>'p2','Phase 2 — Content Writer'=>'p2',
            'Phase 2b — Embeddings'=>'p2b','Phase 2b — Cocon Sémantique'=>'p2b','Phase 2b — Maillage Interne'=>'p2b',
            'Phase 3 — Decision Engine'=>'p3','Phase 3 — Audit Trail'=>'p3','Phase 4 — Feedback Loop'=>'p4','Phase 4b — Strategy Engine'=>'p4b',
            'Phase 5a — Health Check'=>'p5','Phase 5b — Cockpit Santé'=>'p5b','Phase 5c — UX & Performance'=>'p5c','Phase 5d — Production Cleanup'=>'p5d',
            'Phase ML — Multilingual'=>'ml','Phase 6a — Cocon Commander'=>'p6a','Phase 6a UI — Cockpit Commander'=>'p6aui',
            'Phase 0 — API Receiver'=>'p0','Phase 0 — GSC Connect'=>'p0','Phase 0 — Modules Secondaires'=>'p0',
            'Phase 1 — Article Pipeline'=>'p1v2','Phase 2 — Workflow Engine'=>'p2v2','Phase 3 — GEO + Refresh + Freshness'=>'p3v2',
            'Phase 4 — Cannibalization Merge'=>'p4v2','Phase 5 — Auto-Write + Calendrier + Images'=>'p5v2',
            'Phase 6 — Coach SEO (Killer Feature)'=>'p6v2',
            'Phase 7 — Stabilisation v2.0'=>'p7v2',
            'v2.1 — Coach Freemium'=>'v21f',
            'v2.1 — Dispatch Coach → Workflow'=>'v21d',
            'v2.1 — Inbox améliorée'=>'v21i',
        )); ?>;
        var tsPhaseLabels=<?php echo wp_json_encode(array(
            'f'=>'Socle','p1'=>'Phase 1','p2'=>'Phase 2','p2b'=>'Phase 2b','p3'=>'Phase 3','p4'=>'Phase 4','p4b'=>'Phase 4b',
            'p5'=>'Phase 5','p5b'=>'Phase 5b','p5c'=>'Phase 5c','p5d'=>'Phase 5d','p0'=>'Phase 0','p6a'=>'Phase 6a','p6aui'=>'Phase 6a UI','ml'=>'Phase ML',
            'p1v2'=>'Pipeline','p2v2'=>'Workflow','p3v2'=>'GEO+Fresh','p4v2'=>'Cannib Merge','p5v2'=>'Auto-Write','p6v2'=>'Coach SEO','p7v2'=>'Stab v2.0',
            'v21f'=>'Coach Free',
            'v21d'=>'Coach Dispatch',
            'v21i'=>'Inbox v2.1',
        )); ?>;

        function htsRunTests(){
            var btn=document.getElementById('ts-btn-run');
            btn.disabled=true;btn.textContent='Exécution...';
            document.getElementById('ts-results').innerHTML='<div class="ts-loading"><div class="ts-spinner"></div><div class="ts-loading-text">Exécution des tests en cours... Cela peut prendre jusqu\'à 2 minutes.</div></div>';

            fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body:'action=hts_test_suite_run&nonce='+tsN,
                signal:AbortSignal.timeout&&AbortSignal.timeout(180000)||undefined
            }).then(function(r){
                var ct=r.headers.get('content-type')||'';
                if(ct.indexOf('application/json')===-1){
                    return r.text().then(function(txt){
                        throw new Error('Le serveur a renvoyé du HTML au lieu de JSON. Erreur PHP probable :\\n'+txt.substring(0,500));
                    });
                }
                return r.json();
            }).then(function(d){
                btn.disabled=false;btn.textContent='\u{1f504} Relancer';
                if(!d.success){
                    document.getElementById('ts-results').innerHTML='<div class="ts-error"><strong>Erreur :</strong> '+(d.data||'Timeout ou erreur serveur. Essayez le Diagnostic à la place.')+'</div>';
                    return;
                }
                htsRenderResults(d.data.results, d.data.summary);
            }).catch(function(e){
                btn.disabled=false;btn.textContent='\u{1f504} Relancer';
                document.getElementById('ts-results').innerHTML='<div class="ts-error"><strong>Erreur réseau :</strong> '+e.message+'. Le serveur a peut-être mis trop de temps. Essayez le Diagnostic pour un check rapide.</div>';
            });
        }

        function htsRenderResults(results, summary){
            document.getElementById('ts-n-pass').textContent=summary.pass;
            document.getElementById('ts-n-fail').textContent=summary.fail;
            document.getElementById('ts-n-warn').textContent=summary.warn;
            document.getElementById('ts-n-skip').textContent=summary.skip;
            var total=summary.pass+summary.fail+summary.warn+summary.skip;
            var pctEl=document.getElementById('ts-score-pct');
            pctEl.innerHTML=summary.pass+'<span style="font-size:16px;font-weight:400;color:#a5b4fc">/ '+total+'</span>';
            var pct=total>0?Math.round(summary.pass/total*100):0;
            pctEl.style.color=pct>=80?'#10b981':(pct>=50?'#f59e0b':'#ef4444');

            // Group results
            var groups={};
            results.forEach(function(r){if(!groups[r.group])groups[r.group]=[];groups[r.group].push(r);});

            var html='';
            Object.keys(groups).forEach(function(gn){
                var tests=groups[gn];
                var gf=tests.filter(function(t){return t.status==='fail'}).length;
                var gw=tests.filter(function(t){return t.status==='warn'}).length;
                var gs=tests.filter(function(t){return t.status==='skip'}).length;
                var allSkip=(gs===tests.length);
                var bc=allSkip?'#f1f5f9;color:#94a3b8':(gf>0?'#fee2e2;color:#dc2626':(gw>0?'#fef3c7;color:#d97706':'#d1fae5;color:#059669'));
                var bt=allSkip?'En attente':(gf>0?gf+' erreur(s)':(gw>0?gw+' alerte(s)':'OK'));
                var pc=tsPhaseMap[gn]||'f';
                var pl=tsPhaseLabels[pc]||'';
                html+='<div class="ts-group"'+(allSkip?' style="opacity:.6"':'')+'>';
                html+='<div class="ts-gt" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display===\'none\'?\'\':\'none\'">';
                html+=htsEsc(gn);
                html+='<div><span class="ts-phase '+htsEsc(pc)+'">'+htsEsc(pl)+'</span> ';
                html+='<span class="badge" style="background:'+bc+'">'+bt+'</span></div></div>';
                html+='<div'+(allSkip?' style="display:none"':'')+'>';
                tests.forEach(function(t){
                    var icon=t.status==='pass'?'\u2713':(t.status==='fail'?'\u2717':(t.status==='warn'?'!':'\u2014'));
                    html+='<div class="ts-row"><div class="ts-icon '+htsEsc(t.status)+'">'+icon+'</div>';
                    html+='<div class="ts-name">'+htsEsc(t.name)+'</div>';
                    html+='<div class="ts-detail">'+htsEsc(t.detail)+'</div></div>';
                });
                html+='</div></div>';
            });
            document.getElementById('ts-results').innerHTML=html;
        }

        function htsEsc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

        function htsExportTests(){
            window.location.href=ajaxurl+'?action=hts_test_suite_export&nonce='+tsN;
        }
        function htsCleanTestPosts(b){
            if(!confirm('Supprimer les posts sandbox orphelins ?'))return;
            b.disabled=true;b.textContent='Nettoyage...';
            fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body:'action=hts_test_suite_cleanup&nonce='+tsN
            }).then(r=>r.json()).then(d=>{
                if(d.success){
                    b.innerHTML='\u2713 '+d.data.cleaned+' nettoyé(s)';b.style.background='#d1fae5';b.style.color='#059669';
                    var badge=document.getElementById('ts-orphan-badge');if(badge){badge.style.display='none';}
                    setTimeout(()=>{b.innerHTML='\u{1f9f9} Nettoyer orphelins';b.style.background='#fef3c7';b.style.color='#92400e';b.disabled=false;},3000);
                }
                else{b.textContent='Erreur';b.style.background='#fee2e2';b.disabled=false;}
            }).catch(()=>{b.textContent='Erreur réseau';b.style.background='#fee2e2';b.disabled=false;});
        }

        function htsCountOrphans(){
            fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body:'action=hts_test_suite_count_orphans&nonce='+tsN
            }).then(r=>r.json()).then(d=>{
                if(d.success && d.data.count > 0){
                    var badge=document.getElementById('ts-orphan-badge');
                    if(badge){badge.textContent=d.data.count;badge.style.display='inline';}
                    var btn=document.getElementById('ts-btn-clean');
                    if(btn){btn.style.background='#fee2e2';btn.style.color='#991b1b';}
                }
            }).catch(()=>{});
        }

        // Auto-run on page load
        htsCountOrphans();
        htsRunTests();
        </script>
        <?php
    }
}
