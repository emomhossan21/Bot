<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Diagnostic — Page de tests automatisés pour tous les modules SEO
 *
 * Activation : define( 'HTS__DIAGNOSTIC', true ) dans wp-config.php
 *              OU via admin : Hack The SEO → Diagnostic (visible uniquement si activé)
 *
 * Objectif : vérifier que le plugin peut remplacer Yoast/RankMath sans perte SEO.
 *            Chaque test est autonome, idempotent, et ne modifie rien.
 *
 * @since 1.4.1
 */

class HTS_Diagnostic {

    /** @var array Test results: [ 'name', 'status' (pass|fail|warn|skip), 'detail', 'group' ] */
    private $results = array();

    /** @var int Counters */
    private $pass = 0;
    private $fail = 0;
    private $warn = 0;
    private $skip = 0;

    /**
     * Check if diagnostic mode is enabled.
     */
    public static function is_enabled() {
        // 1. Constant in wp-config.php
        if ( defined( 'HTS__DIAGNOSTIC' ) && HTS__DIAGNOSTIC ) return true;
        // 2. Option toggle (admin UI)
        if ( get_option( 'hts_diagnostic_mode', '0' ) === '1' ) return true;
        return false;
    }

    /**
     * Init — register admin page + AJAX toggle.
     */
    public function init() {
        // Always register AJAX handlers (diagnostic page accessible via cockpit tab)
        add_action( 'wp_ajax_hts_diagnostic_toggle', array( $this, 'ajax_toggle' ) );
        add_action( 'wp_ajax_hts_diagnostic_run', array( $this, 'ajax_run' ) );
        add_action( 'wp_ajax_hts_diagnostic_export', array( $this, 'ajax_export' ) );
        add_action( 'wp_ajax_hts_diagnostic_normalize_robots', array( $this, 'ajax_normalize_robots' ) );
        add_action( 'wp_ajax_hts_diagnostic_clean_orphans', array( $this, 'ajax_clean_orphans' ) );

        // Register admin page route
        add_action( 'admin_menu', array( $this, 'register_menu' ), 50 );
    }

    public function register_menu() {
        // No separate page — diagnostic renders inside the dashboard via ?page=hts-light-dashboard&tab=diag
        // This avoids WAF/security plugins blocking separate page slugs
    }

    public function ajax_toggle() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $current = get_option( 'hts_diagnostic_mode', '0' );
        $new = $current === '1' ? '0' : '1';
        update_option( 'hts_diagnostic_mode', $new );
        wp_send_json_success( array( 'enabled' => $new === '1' ) );
    }

    public function ajax_run() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $this->run_all_tests();
        wp_send_json_success( array(
            'results' => $this->results,
            'summary' => array(
                'pass' => $this->pass,
                'fail' => $this->fail,
                'warn' => $this->warn,
                'skip' => $this->skip,
            ),
        ) );
    }

    /**
     * AJAX: Export diagnostic report as downloadable text file.
     */
    public function ajax_export() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        $this->run_all_tests();
        $report = $this->generate_export_text();

        $filename = 'hts-diagnostic-' . sanitize_title( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '-' . wp_date( 'Y-m-d-His' ) . '.txt';

        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        echo esc_html( $report );
        wp_die();
    }

    /**
     * Generate plain-text export of diagnostic results.
     */
    private function generate_export_text() {
        $total = $this->pass + $this->fail + $this->warn + $this->skip;
        $pct   = $total > 0 ? round( $this->pass / $total * 100 ) : 0;

        $lines = array();
        $lines[] = '════════════════════════════════════════════════════════';
        $lines[] = '  HACK THE SEO — AUDIT SEO';
        $lines[] = '════════════════════════════════════════════════════════';
        $lines[] = '';
        $lines[] = 'Date       : ' . wp_date( 'Y-m-d H:i:s' ) . ' (' . wp_timezone_string() . ')';
        $lines[] = 'Site       : ' . home_url();
        $lines[] = 'Plugin     : Hack The SEO v' . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' );
        $lines[] = 'WordPress  : ' . get_bloginfo( 'version' );
        $lines[] = 'PHP        : ' . PHP_VERSION;
        $lines[] = 'Serveur    : ' . ( $_SERVER['SERVER_SOFTWARE'] ?? 'Inconnu' );
        $lines[] = 'Mémoire PHP: ' . ini_get( 'memory_limit' );
        $lines[] = 'Exec time  : ' . ini_get( 'max_execution_time' ) . 's';
        $lines[] = 'Thème      : ' . wp_get_theme()->get( 'Name' ) . ' v' . wp_get_theme()->get( 'Version' );
        $lines[] = 'Multisite  : ' . ( is_multisite() ? 'Oui' : 'Non' );
        $lines[] = '';
        $lines[] = 'Score      : ' . $pct . '% (' . $this->pass . ' OK / ' . $this->fail . ' erreurs / ' . $this->warn . ' alertes / ' . $this->skip . ' ignorés)';
        $lines[] = '';

        // Group results
        $groups = array();
        foreach ( $this->results as $r ) {
            $groups[ $r['group'] ][] = $r;
        }

        $status_icons = array( 'pass' => '✓', 'fail' => '✗', 'warn' => '!', 'skip' => '—' );
        $status_labels = array( 'pass' => 'OK', 'fail' => 'ERREUR', 'warn' => 'ALERTE', 'skip' => 'IGNORÉ' );

        foreach ( $groups as $group_name => $tests ) {
            $group_fails = count( array_filter( $tests, function( $t ) { return $t['status'] === 'fail'; } ) );
            $group_warns = count( array_filter( $tests, function( $t ) { return $t['status'] === 'warn'; } ) );
            $group_status = $group_fails > 0 ? '✗ ERREUR' : ( $group_warns > 0 ? '! ALERTE' : '✓ OK' );

            $lines[] = '────────────────────────────────────────────────────────';
            $lines[] = '  ' . mb_strtoupper( $group_name ) . '  [' . $group_status . ']';
            $lines[] = '────────────────────────────────────────────────────────';

            foreach ( $tests as $t ) {
                $icon   = $status_icons[ $t['status'] ] ?? '?';
                $label  = $status_labels[ $t['status'] ] ?? '?';
                $detail = ! empty( $t['detail'] ) ? '  →  ' . $t['detail'] : '';
                $lines[] = sprintf( '  [%s] %-7s %-30s%s', $icon, $label, $t['name'], $detail );
            }
            $lines[] = '';
        }

        // Active plugins list (useful for debugging compatibility)
        $lines[] = '────────────────────────────────────────────────────────';
        $lines[] = '  PLUGINS ACTIFS';
        $lines[] = '────────────────────────────────────────────────────────';
        $active_plugins = get_option( 'active_plugins', array() );
        foreach ( $active_plugins as $p ) {
            $data = get_plugin_data( WP_PLUGIN_DIR . '/' . $p, false, false );
            $lines[] = '  • ' . ( $data['Name'] ?: $p ) . ' v' . ( $data['Version'] ?: '?' );
        }
        $lines[] = '';

        $lines[] = '════════════════════════════════════════════════════════';
        $lines[] = '  Généré par Hack The SEO Diagnostic — hacktheseo.com';
        $lines[] = '════════════════════════════════════════════════════════';

        return implode( "\n", $lines );
    }

    /**
     * AJAX: Normalize all string-format _hts_robots_meta to array format.
     */
    public function ajax_normalize_robots() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''", '_hts_robots_meta' ) );

        $converted = 0;
        $already   = 0;

        foreach ( $rows as $row ) {
            $v = maybe_unserialize( $row->meta_value );

            if ( is_array( $v ) ) {
                $already++;
                continue;
            }

            // String format: "noindex,nofollow" or "noindex"
            if ( is_string( $row->meta_value ) ) {
                $arr = array_filter( array_map( 'trim', explode( ',', $row->meta_value ) ) );
                $valid = array_intersect( $arr, array( 'noindex', 'nofollow', 'noarchive', 'noimageindex', 'nosnippet' ) );
                if ( ! empty( $valid ) ) {
                    update_post_meta( (int) $row->post_id, '_hts_robots_meta', array_values( $valid ) );
                    $converted++;
                } else {
                    delete_post_meta( (int) $row->post_id, '_hts_robots_meta' );
                    $converted++;
                }
            }
        }

        wp_send_json_success( array(
            'converted' => $converted,
            'already'   => $already,
            'total'     => count( $rows ),
        ) );
    }

    /**
     * AJAX: Clean orphan HTS meta on deleted/trashed posts.
     */
    public function ajax_clean_orphans() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        global $wpdb;
        $deleted = (int) $wpdb->query( "
            DELETE pm FROM {$wpdb->postmeta} pm
            LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
            WHERE pm.meta_key LIKE '_hts_%'
            AND ( p.ID IS NULL OR p.post_status NOT IN ('publish','draft','pending','private','future') )
        " );

        wp_send_json_success( array( 'deleted' => $deleted ) );
    }

    /* ═══════════════════════════════════════════════
     *  TEST RUNNER — Execute all test groups
     * ═══════════════════════════════════════════════ */

    public function run_all_tests() {
        $this->results = array();
        $this->pass = $this->fail = $this->warn = $this->skip = 0;

        $this->test_environment();
        $this->test_meta_tags();
        $this->test_sitemap();
        $this->test_robots();
        $this->test_canonical();
        $this->test_schema();
        $this->test_indexnow();
        $this->test_llmstxt();
        $this->test_redirects();
        $this->test_breadcrumbs();
        $this->test_pagination_hreflang();
        $this->test_data_integrity();
        $this->test_competitor_compat();
        $this->test_http_endpoints();
        $this->test_frontend_compat();
        $this->test_onboarding_ux();
        $this->test_plugin_weight();
        $this->test_cron_health();
        $this->test_security_audit();

        return $this->results;
    }

    /* ═══════════════════════════════════════════════
     *  HELPER: Record a test result
     * ═══════════════════════════════════════════════ */

    private function add( $group, $name, $status, $detail = '' ) {
        $this->results[] = array(
            'group'  => $group,
            'name'   => $name,
            'status' => $status,
            'detail' => $detail,
        );
        $this->{$status}++;
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 1: ENVIRONMENT
     * ═══════════════════════════════════════════════ */

    private function test_environment() {
        $g = 'Environnement';

        // PHP version
        $phpv = PHP_VERSION;
        $this->add( $g, 'PHP ≥ 7.4', version_compare( $phpv, '7.4', '>=' ) ? 'pass' : 'fail', "Version: $phpv" );

        // WordPress version
        global $wp_version;
        $this->add( $g, 'WordPress ≥ 5.9', version_compare( $wp_version, '5.9', '>=' ) ? 'pass' : 'warn', "Version: $wp_version" );

        // Plugin version
        $this->add( $g, 'Version plugin', 'pass', HTS__VERSION );

        // Light mode
        $this->add( $g, 'Mode Light', defined( 'HTS__IS_LIGHT' ) && HTS__IS_LIGHT ? 'pass' : 'warn', defined( 'HTS__IS_LIGHT' ) ? 'HTS__IS_LIGHT = true' : 'Constante non définie' );

        // Permalinks (must be "pretty" for sitemaps)
        $structure = get_option( 'permalink_structure' );
        $this->add( $g, 'Permaliens actifs', ! empty( $structure ) ? 'pass' : 'fail', $structure ?: 'Permaliens simples (sitemaps KO)' );

        // SSL
        $this->add( $g, 'HTTPS actif', is_ssl() || strpos( home_url(), 'https' ) === 0 ? 'pass' : 'warn', home_url() );

        // Blog public (not discouraging indexing)
        $public = get_option( 'blog_public', '1' );
        $this->add( $g, 'Blog visible (non bloqué)', $public === '1' ? 'pass' : 'fail', $public !== '1' ? 'ATTENTION: "Demander aux moteurs de ne pas indexer" est coché !' : 'OK — visible' );

        // wp_cron
        $this->add( $g, 'WP-Cron actif', ! defined( 'DISABLE_WP_CRON' ) || ! DISABLE_WP_CRON ? 'pass' : 'warn', defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'DISABLE_WP_CRON = true → crons sitemap/IndexNow via système cron requis' : 'OK' );

        // ── PHP / Server checks ──

        // PHP memory_limit
        $mem_limit = ini_get( 'memory_limit' );
        $mem_bytes = wp_convert_hr_to_bytes( $mem_limit );
        $mem_ok    = $mem_bytes >= 128 * 1024 * 1024; // 128M minimum
        $this->add( $g, 'PHP memory_limit', $mem_ok ? 'pass' : 'warn', "$mem_limit" . ( ! $mem_ok ? ' — Recommandé: 128M minimum (256M pour gros sites)' : '' ) );

        // PHP max_execution_time
        $max_exec = (int) ini_get( 'max_execution_time' );
        $exec_ok  = $max_exec === 0 || $max_exec >= 30;
        $this->add( $g, 'PHP max_execution_time', $exec_ok ? 'pass' : 'warn', "{$max_exec}s" . ( ! $exec_ok ? ' — Trop court pour la régénération sitemap de gros sites' : '' ) );

        // PHP extensions requises
        $required_ext = array( 'json', 'mbstring', 'xml', 'curl', 'dom' );
        $missing_ext  = array();
        foreach ( $required_ext as $ext ) {
            if ( ! extension_loaded( $ext ) ) $missing_ext[] = $ext;
        }
        $this->add( $g, 'Extensions PHP', empty( $missing_ext ) ? 'pass' : 'fail',
            empty( $missing_ext )
                ? implode( ', ', $required_ext ) . ' ✓'
                : 'MANQUANTES: ' . implode( ', ', $missing_ext ) . ' — fonctionnalités SEO dégradées'
        );

        // Server software
        $server = $_SERVER['SERVER_SOFTWARE'] ?? '';
        $server_short = '';
        if ( stripos( $server, 'apache' ) !== false )     $server_short = 'Apache';
        elseif ( stripos( $server, 'nginx' ) !== false )   $server_short = 'Nginx';
        elseif ( stripos( $server, 'litespeed' ) !== false ) $server_short = 'LiteSpeed';
        elseif ( stripos( $server, 'iis' ) !== false )     $server_short = 'IIS';
        else $server_short = $server ?: 'Inconnu';

        $server_note = '';
        if ( $server_short === 'Nginx' ) {
            $server_note = ' — Vérifier que les rewrite rules sont dans la config nginx (pas de .htaccess)';
        }
        $this->add( $g, 'Serveur web', 'pass', $server_short . $server_note );

        // Object cache
        $has_object_cache = wp_using_ext_object_cache();
        if ( $has_object_cache ) {
            $this->add( $g, 'Object cache', 'pass', 'Cache objet externe actif (Redis/Memcached) — bonne performance' );
        }

        // Database charset
        global $wpdb;
        $charset = $wpdb->charset;
        $this->add( $g, 'Charset BDD', $charset === 'utf8mb4' ? 'pass' : 'warn',
            $charset . ( $charset !== 'utf8mb4' ? ' — utf8mb4 recommandé pour les emojis et caractères spéciaux' : '' )
        );

        // Multisite check
        if ( is_multisite() ) {
            $this->add( $g, 'Multisite', 'warn', 'WordPress Multisite détecté — vérifier la configuration sitemap par sous-site' );
        }

        // Theme
        $theme = wp_get_theme();
        $this->add( $g, 'Thème actif', 'pass', $theme->get( 'Name' ) . ' v' . $theme->get( 'Version' ) . ( $theme->parent() ? ' (enfant de ' . $theme->parent()->get( 'Name' ) . ')' : '' ) );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 2: META TAGS
     * ═══════════════════════════════════════════════ */

    private function test_meta_tags() {
        $g = 'Meta Tags';

        // Module enabled
        $enabled = get_option( 'hts_module_meta_tags', '1' ) === '1';
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'warn', $enabled ? '' : 'Module désactivé — Meta tags gérés par WordPress ou concurrent' );
        if ( ! $enabled ) return;

        // Home title configured
        $ht = get_option( 'hts_home_title', '' );
        $this->add( $g, 'Title accueil configuré', ! empty( $ht ) ? 'pass' : 'warn', $ht ?: 'Vide — WordPress par défaut' );

        // Home description
        $hd = get_option( 'hts_home_description', '' );
        $this->add( $g, 'Description accueil configurée', ! empty( $hd ) ? 'pass' : 'warn', $hd ? mb_substr( $hd, 0, 60 ) . '…' : 'Vide — aucune description OG' );

        // Check coverage: posts with custom title
        global $wpdb;
        $pt_in = hts_sql_post_types_in();
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in}" );
        $with_title = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_meta_title' AND meta_value != ''" );
        $with_desc  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_meta_description' AND meta_value != ''" );

        $pct_title = $total > 0 ? round( $with_title / $total * 100 ) : 0;
        $pct_desc  = $total > 0 ? round( $with_desc / $total * 100 ) : 0;

        $this->add( $g, 'Couverture Title', $pct_title >= 50 ? 'pass' : 'warn', "$with_title/$total pages ({$pct_title}%) — fallback auto: titre WordPress" );
        $this->add( $g, 'Couverture Description', $pct_desc >= 30 ? 'pass' : 'warn', "$with_desc/$total pages ({$pct_desc}%) — fallback auto: extrait" );

        // OG default image
        $og_img = get_option( 'hts_og_default_image', '' );
        $this->add( $g, 'Image OG par défaut', ! empty( $og_img ) ? 'pass' : 'warn', $og_img ? 'Configurée' : 'Vide — fallback: logo du site ou rien' );

        // Separator
        $sep = get_option( 'hts_title_separator', '—' );
        $this->add( $g, 'Séparateur de titre', 'pass', "\"$sep\"" );

        // Variable resolution — test resolve on dummy
        if ( class_exists( 'HTS_Meta_Tags' ) ) {
            $mt = new HTS_Meta_Tags();
            if ( method_exists( $mt, 'resolve_variables' ) ) {
                $resolved = $mt->resolve_variables( '%sitename% %sep% %title%' );
                $this->add( $g, 'Résolution de variables', ! empty( trim( $resolved ) ) ? 'pass' : 'fail', "Test: '%sitename% %sep% %title%' → '$resolved'" );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 3: SITEMAP
     * ═══════════════════════════════════════════════ */

    private function test_sitemap() {
        $g = 'Sitemap XML';

        $enabled = get_option( 'hts_module_sitemap', '1' ) === '1';
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'warn', '' );
        if ( ! $enabled ) return;

        $settings = HTS_Sitemap::get_settings();

        // Cocon sitemaps should be OFF in Light
        $this->add( $g, 'Cocon sitemaps désactivé (Light)', ! $settings['cocon_sitemaps'] ? 'pass' : 'fail', $settings['cocon_sitemaps'] ? 'ACTIF — pas de HTS_Cocon en Light → sous-sitemaps cocon vides' : 'Correctement désactivé' );

        // WP core sitemaps disabled
        $this->add( $g, 'WP core sitemaps désactivé', $settings['disable_wp_sitemaps'] ? 'pass' : 'warn', $settings['disable_wp_sitemaps'] ? 'Pas de doublon /wp-sitemap.xml' : '/wp-sitemap.xml toujours actif (doublon)' );

        // Post types configured
        $this->add( $g, 'Post types', 'pass', implode( ', ', $settings['post_types'] ) );

        // Noindex exclusion enabled
        $this->add( $g, 'Exclusion noindex', $settings['exclude_noindex'] ? 'pass' : 'fail', $settings['exclude_noindex'] ? 'Pages noindex exclues du sitemap' : 'DANGER : pages noindex dans le sitemap' );

        // Redirect exclusion
        $this->add( $g, 'Exclusion redirections', ! empty( $settings['exclude_redirected'] ) ? 'pass' : 'warn', '' );

        // Competing sitemaps disabled
        $competitors = HTS_Sitemap::detect_competing_plugins();
        if ( ! empty( $competitors ) ) {
            $names = array_column( $competitors, 'name' );
            $this->add( $g, 'Sitemaps concurrents neutralisés', $settings['disable_competing'] ? 'pass' : 'fail', implode( ', ', $names ) . ' détecté(s)' );
        } else {
            $this->add( $g, 'Aucun concurrent sitemap', 'pass', '' );
        }

        // Stats
        $stats = get_option( 'hts_sitemap_stats', array() );
        $total_urls = 0;
        foreach ( $stats as $k => $v ) {
            if ( is_array( $v ) && isset( $v['urls'] ) ) $total_urls += (int) $v['urls'];
        }
        $this->add( $g, 'URLs totales', $total_urls > 0 ? 'pass' : 'warn', "$total_urls URLs dans le sitemap" . ( $total_urls === 0 ? ' — régénération nécessaire' : '' ) );

        // Last cron run
        $last = $stats['cron_last_run'] ?? '';
        if ( $last ) {
            $ago = human_time_diff( strtotime( $last ) );
            $this->add( $g, 'Dernier cron', 'pass', "{$ago} ({$last})" );
        } else {
            $this->add( $g, 'Dernier cron', 'warn', 'Jamais exécuté — attendre 6h ou cliquer Régénérer' );
        }

        // Pagination check
        foreach ( $settings['post_types'] as $pt ) {
            $count = (int) wp_count_posts( $pt )->publish;
            $max = (int) $settings['max_urls_per_sitemap'];
            $pages = max( 1, ceil( $count / $max ) );
            if ( $pages > 1 ) {
                $this->add( $g, "Pagination $pt", 'pass', "$count posts → $pages sitemaps (max $max/sitemap)" );
            }
        }

        // Rewrite rules installed
        $flush_needed = get_option( 'hts_sitemap_flush_needed', false );
        $this->add( $g, 'Rewrite rules', ! $flush_needed ? 'pass' : 'warn', $flush_needed ? 'Flush en attente — prochain chargement' : 'Installées' );

        // robots.txt reference
        $custom_robots = get_option( 'hts_robotstxt_custom', '' );
        $has_sitemap_ref = strpos( $custom_robots, 'Sitemap:' ) !== false;
        $this->add( $g, 'Sitemap dans robots.txt', $has_sitemap_ref || empty( $custom_robots ) ? 'pass' : 'warn', $has_sitemap_ref ? 'Référencé' : 'Pas de robots.txt custom OU pas de directive Sitemap (le filtre auto l\'ajoute)' );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 4: ROBOTS META
     * ═══════════════════════════════════════════════ */

    private function test_robots() {
        $g = 'Robots Meta';

        $enabled = get_option( 'hts_module_robots', '1' ) === '1';
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'warn', '' );
        if ( ! $enabled ) return;

        // Physical robots.txt file (should NOT exist — override WP virtual)
        $this->add( $g, 'Pas de robots.txt physique', ! HTS_Robots::has_physical_file() ? 'pass' : 'warn', HTS_Robots::has_physical_file() ? 'Un fichier robots.txt physique existe → bloque le filtre WP (et HTS)' : 'OK — filtrage virtuel actif' );

        // Global noindex rules
        $global = get_option( 'hts_robots_global', array() );
        $noindex_pts = array();
        foreach ( $global as $pt => $dirs ) {
            if ( is_array( $dirs ) && in_array( 'noindex', $dirs, true ) ) {
                $noindex_pts[] = $pt;
            }
        }
        if ( ! empty( $noindex_pts ) ) {
            $this->add( $g, 'Noindex global', 'warn', 'Post types noindex : ' . implode( ', ', $noindex_pts ) );
        } else {
            $this->add( $g, 'Aucun noindex global', 'pass', '' );
        }

        // Protected pages can't be noindexed — verify
        $front = (int) get_option( 'page_on_front' );
        if ( $front ) {
            list( $prot, ) = HTS_Robots::is_protected( $front );
            $this->add( $g, 'Homepage protégée', $prot ? 'pass' : 'fail', $prot ? "Page $front protégée contre noindex" : "Homepage NON protégée — risque de noindex accidentel" );
        }

        // Count noindex pages
        global $wpdb;
        $noindex_count = 0;
        $rows = $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''", '_hts_robots_meta' ) );
        foreach ( $rows as $v ) {
            $a = maybe_unserialize( $v );
            if ( is_array( $a ) && in_array( 'noindex', $a, true ) ) { $noindex_count++; continue; }
            if ( is_string( $v ) && strpos( $v, 'noindex' ) !== false ) $noindex_count++;
        }
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type " . hts_sql_post_types_in() );
        $pct = $total > 0 ? round( $noindex_count / $total * 100 ) : 0;
        $status = $pct > 30 ? 'fail' : ( $pct > 15 ? 'warn' : 'pass' );
        $this->add( $g, 'Pages noindex', $status, "$noindex_count/$total ({$pct}%) — " . ( $pct > 30 ? 'TROP de noindex ! Vérifier' : 'OK' ) );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 5: CANONICAL
     * ═══════════════════════════════════════════════ */

    private function test_canonical() {
        $g = 'Canonical';

        $enabled = get_option( 'hts_module_canonical', '1' ) === '1';
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'warn', '' );
        if ( ! $enabled ) return;

        $settings = HTS_Canonical::get_settings();

        // Self-referencing
        $this->add( $g, 'Self-referencing', $settings['self_referencing'] === '1' ? 'pass' : 'warn', $settings['self_referencing'] === '1' ? 'Chaque page pointe vers elle-même' : 'Désactivé — pages sans canonical' );

        // WP canonical removed
        $this->add( $g, 'WP canonical supprimé', $settings['remove_wp_canonical'] === '1' ? 'pass' : 'fail', $settings['remove_wp_canonical'] === '1' ? 'Pas de doublon rel=canonical' : 'DOUBLE canonical possible !' );

        // Active conflicts
        $conflicts = get_option( 'hts_canonical_conflicts', array() );
        $unresolved = 0;
        $conflict_details = array();
        foreach ( $conflicts as $c ) {
            if ( ( $c['status'] ?? '' ) !== 'resolved' && ( $c['status'] ?? '' ) !== 'dismissed' ) {
                $unresolved++;
                $ta = $c['title_a'] ?? 'ID ' . ( $c['page_a'] ?? '?' );
                $tb = $c['title_b'] ?? 'ID ' . ( $c['page_b'] ?? '?' );
                $risk = $c['risk'] ?? 'medium';
                $layer = $c['layer_label'] ?? $c['layer'] ?? '';
                $sug = $c['suggestion']['action'] ?? 'review';
                $conflict_details[] = mb_strimwidth( $ta, 0, 35, '…' ) . ' ' . mb_strimwidth( $tb, 0, 35, '…' ) . " [$risk, $layer → $sug]";
            }
        }
        $detail_text = $unresolved > 0
            ? "$unresolved conflit(s) non résolu(s) — " . implode( ' | ', array_slice( $conflict_details, 0, 3 ) )
            : 'Aucun';
        $this->add( $g, 'Conflits cannibalisation', $unresolved === 0 ? 'pass' : 'warn', $detail_text );

        // Manual canonicals pointing elsewhere
        global $wpdb;
        $external_canonicals = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_canonical_url' AND meta_value != ''" );
        $this->add( $g, 'Canonicals manuels', 'pass', "$external_canonicals page(s) avec canonical personnalisé" );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 6: SCHEMA
     * ═══════════════════════════════════════════════ */

    private function test_schema() {
        $g = 'Schema JSON-LD';

        $mod = get_option( 'hts_module_schema', '1' );
        $enabled = $mod !== '0' && $mod !== 0 && $mod !== false;
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'warn', "Option: " . var_export( $mod, true ) );
        if ( ! $enabled ) return;

        // Organization name
        $name = get_bloginfo( 'name' );
        $this->add( $g, 'Nom organisation', ! empty( $name ) ? 'pass' : 'fail', $name ?: 'Vide — Schema Organization invalide' );

        // Logo
        $logo_id = get_theme_mod( 'custom_logo' );
        $this->add( $g, 'Logo défini', $logo_id ? 'pass' : 'warn', $logo_id ? 'Logo custom_logo trouvé' : 'Pas de logo — Schema Organization sans image' );

        // Social profiles
        $social = get_option( 'hts_social_profiles', array() );
        $has_social = false;
        if ( is_array( $social ) ) {
            foreach ( $social as $url ) {
                if ( ! empty( $url ) ) { $has_social = true; break; }
            }
        }
        $this->add( $g, 'Profils sociaux', $has_social ? 'pass' : 'warn', $has_social ? 'Au moins 1 profil configuré' : 'Aucun — fallback Yoast/RankMath ou vide' );

        // Schema Pro count
        global $wpdb;
        $pro_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_schema_type' AND meta_value != 'auto' AND meta_value != ''" );
        $this->add( $g, 'Schema Pro actifs', 'pass', "$pro_count page(s) avec schema manuel (Product, Event, etc.)" );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 7: INDEXNOW
     * ═══════════════════════════════════════════════ */

    private function test_indexnow() {
        $g = 'IndexNow';

        $enabled = get_option( 'hts_indexnow_enabled', '0' ) === '1';
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'skip', $enabled ? '' : 'Désactivé — ping Bing/Yandex inactif' );
        if ( ! $enabled ) return;

        // API key exists
        $key = HTS_IndexNow::get_api_key();
        $this->add( $g, 'Clé API', ! empty( $key ) && strlen( $key ) >= 8 ? 'pass' : 'fail', strlen( $key ) . ' caractères' );

        // Stats
        $stats = get_option( 'hts_indexnow_stats', array() );
        $total_pings = $stats['total_pings'] ?? 0;
        $this->add( $g, 'Historique pings', 'pass', "$total_pings pings envoyés" );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 8: LLMS.TXT
     * ═══════════════════════════════════════════════ */

    private function test_llmstxt() {
        $g = 'llms.txt';

        $enabled = get_option( 'hts_llmstxt_enabled', '1' ) === '1';
        $this->add( $g, 'Module activé', $enabled ? 'pass' : 'skip', '' );
        if ( ! $enabled ) return;

        // Functional test: generate content
        if ( class_exists( 'HTS_LLMs_Txt' ) ) {
            $llms = new HTS_LLMs_Txt();
            if ( method_exists( $llms, 'get_content' ) ) {
                $content = $llms->get_content();
                $len = strlen( $content );
                $this->add( $g, 'Contenu généré', $len > 50 ? 'pass' : 'warn', "$len caractères" );

                // Check structure
                $has_h1 = strpos( $content, '# ' ) !== false;
                $has_h2 = strpos( $content, '## ' ) !== false;
                $this->add( $g, 'Structure Markdown', $has_h1 && $has_h2 ? 'pass' : 'warn', ( $has_h1 ? '✓ H1' : '✗ H1' ) . ' ' . ( $has_h2 ? '✓ H2' : '✗ H2' ) );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 9: REDIRECTIONS
     * ═══════════════════════════════════════════════ */

    private function test_redirects() {
        $g = 'Redirections';

        if ( ! class_exists( 'HTS_Redirects' ) ) {
            $this->add( $g, 'Module', 'skip', 'Classe non chargée' );
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'hts_redirects';
        $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table;
        $this->add( $g, 'Table BDD', $table_exists ? 'pass' : 'warn', $table_exists ? $table : 'Table non créée — aucune redirection enregistrée' );

        if ( $table_exists ) {
            $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
            $active = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE enabled = 1" );
            $this->add( $g, 'Redirections actives', 'pass', "$active actives / $total totales" );

            // Redirect loops
            $loops = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} a JOIN {$table} b ON a.target_url = b.source_url AND b.target_url = a.source_url WHERE a.enabled = 1 AND b.enabled = 1" );
            $this->add( $g, 'Boucles de redirection', $loops === 0 ? 'pass' : 'fail', $loops > 0 ? "$loops boucle(s) détectée(s) !" : 'Aucune' );
        }

        // 404 monitoring
        $pending_404 = HTS_Redirects::get_pending_count();
        $this->add( $g, '404 en attente', $pending_404 < 20 ? 'pass' : 'warn', "$pending_404 URL(s) 404 non redirigées" );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 10: BREADCRUMBS
     * ═══════════════════════════════════════════════ */

    private function test_breadcrumbs() {
        $g = 'Breadcrumbs';
        $this->add( $g, 'Module chargé', class_exists( 'HTS_Breadcrumbs' ) ? 'pass' : 'skip', class_exists( 'HTS_Breadcrumbs' ) ? 'Schema BreadcrumbList généré automatiquement' : 'Non chargé' );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP: PAGINATION & HREFLANG
     * ═══════════════════════════════════════════════ */

    private function test_pagination_hreflang() {
        $g = 'Pagination & Multilingue';

        // Rel prev/next
        $rel = get_option( 'hts_rel_prev_next', '1' );
        $this->add( $g, 'rel prev/next', $rel === '1' ? 'pass' : 'warn',
            $rel === '1' ? 'Activé — balises de pagination injectées' : 'Désactivé — Google ne voit pas la structure paginée' );

        // Hreflang
        $hreflang = get_option( 'hts_hreflang', '1' );
        $has_wpml = defined( 'ICL_SITEPRESS_VERSION' );
        $has_pll  = function_exists( 'pll_the_languages' );
        $has_trp  = class_exists( 'TRP_Translate_Press' );
        $multilingual = $has_wpml || $has_pll || $has_trp;

        if ( $hreflang === '1' && $multilingual ) {
            $plugin = $has_wpml ? 'WPML' : ( $has_pll ? 'Polylang' : 'TranslatePress' );
            $this->add( $g, 'hreflang', 'pass', 'Activé — ' . $plugin . ' détecté, balises injectées' );
        } elseif ( $hreflang === '1' && ! $multilingual ) {
            $this->add( $g, 'hreflang', 'pass', 'Activé — aucun plugin multilingue détecté (pas de balises générées)' );
        } else {
            $this->add( $g, 'hreflang', 'warn', 'Désactivé' . ( $multilingual ? ' — un plugin multilingue est détecté, activez hreflang' : '' ) );
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 11: DATA INTEGRITY (le plus important !)
     * ═══════════════════════════════════════════════ */

    private function test_data_integrity() {
        $g = 'Intégrité données';

        global $wpdb;

        // Check for string-format robots meta (from Migration Wizard or SEO Panel)
        $all_robots = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''", '_hts_robots_meta' ) );

        $string_format = 0;
        $array_format = 0;
        $empty_format = 0;
        $corrupt = 0;

        foreach ( $all_robots as $row ) {
            $v = $row->meta_value;
            $unserialized = maybe_unserialize( $v );

            if ( is_array( $unserialized ) ) {
                $array_format++;
            } elseif ( is_string( $v ) && strpos( $v, ',' ) !== false ) {
                // String format like "noindex,nofollow" — from Migration Wizard
                $string_format++;
            } elseif ( is_string( $v ) && in_array( $v, array( 'noindex', 'nofollow', 'noarchive', 'noimageindex' ), true ) ) {
                // Single directive as string
                $string_format++;
            } elseif ( empty( $v ) ) {
                $empty_format++;
            } else {
                $corrupt++;
            }
        }

        $total_robots = count( $all_robots );
        $this->add( $g, 'Robots meta: format', $string_format === 0 && $corrupt === 0 ? 'pass' : ( $corrupt > 0 ? 'fail' : 'warn' ),
            "Total: $total_robots — Array: $array_format, String: $string_format, Corrupt: $corrupt" . ( $string_format > 0 ? ' — String format fonctionne via normalize_robots_meta()' : '' )
        );

        // Check canonical conflicts data
        $conflicts = get_option( 'hts_canonical_conflicts', array() );
        $this->add( $g, 'Conflits canonical', 'pass', count( $conflicts ) . ' enregistrés' );

        // Orphan meta: HTS meta on deleted/draft posts
        $orphan = (int) $wpdb->get_var( "
            SELECT COUNT(*) FROM {$wpdb->postmeta} pm 
            LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID 
            WHERE pm.meta_key LIKE '_hts_%' 
            AND (p.ID IS NULL OR p.post_status NOT IN ('publish','draft','pending','private','future'))
        " );
        $this->add( $g, 'Meta orphelines', $orphan === 0 ? 'pass' : 'warn', $orphan > 0 ? "$orphan meta(s) HTS sur posts supprimés — nettoyage possible" : 'Aucune' );

        // Sitemap settings stored correctly
        $sitemap_settings = get_option( 'hts_sitemap_settings', array() );
        if ( isset( $sitemap_settings['cocon_sitemaps'] ) && $sitemap_settings['cocon_sitemaps'] && ! class_exists( 'HTS_Cocon' ) ) {
            $this->add( $g, 'Sitemap: cocon en BDD', 'warn', 'cocon_sitemaps=true en base mais HTS_Cocon absent — runtime guard le bloque' );
        } else {
            $this->add( $g, 'Sitemap: config cohérente', 'pass', '' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 12: COMPETITOR COMPATIBILITY
     * ═══════════════════════════════════════════════ */

    private function test_competitor_compat() {
        $g = 'Compatibilité';

        // Detect active competitors
        $competitors = array();
        if ( class_exists( 'RankMath' ) || function_exists( 'rank_math' ) ) $competitors[] = 'Rank Math';
        if ( defined( 'WPSEO_VERSION' ) )                                   $competitors[] = 'Yoast SEO ' . WPSEO_VERSION;
        if ( function_exists( 'aioseo' ) )                                   $competitors[] = 'All in One SEO';
        if ( defined( 'SEOPRESS_VERSION' ) )                                 $competitors[] = 'SEOPress ' . SEOPRESS_VERSION;

        if ( empty( $competitors ) ) {
            $this->add( $g, 'Aucun plugin SEO concurrent', 'pass', 'HTS est le seul gestionnaire SEO' );
        } else {
            $this->add( $g, 'Concurrent(s) détecté(s)', 'warn', implode( ', ', $competitors ) . ' — HTS neutralise leur output' );
        }

        // Check Jetpack OG
        if ( class_exists( 'Jetpack' ) ) {
            $this->add( $g, 'Jetpack détecté', 'warn', 'Module Open Graph Jetpack neutralisé par HTS' );
        }

        // Check for Yoast/RM data available for fallback
        global $wpdb;
        $ym_data = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key IN ('_yoast_wpseo_title','rank_math_title') AND meta_value != ''" );
        if ( $ym_data > 0 ) {
            $this->add( $g, 'Données Yoast/RM disponibles', 'pass', "$ym_data meta(s) titre — utilisées en fallback cascade" );
        }

        // ── CPTs actifs ──
        $seo_pts = function_exists( 'hts_get_seo_post_types' ) ? hts_get_seo_post_types( false ) : array();
        $cpt_names = array();
        foreach ( $seo_pts as $slug => $obj ) {
            if ( in_array( $slug, array( 'post', 'page' ), true ) ) continue;
            $counts = wp_count_posts( $slug );
            $count = is_object( $counts ) && isset( $counts->publish ) ? (int) $counts->publish : 0;
            if ( $count > 0 ) {
                $cpt_names[] = $obj->label . " ($count)";
            }
        }
        if ( ! empty( $cpt_names ) ) {
            $this->add( $g, 'Custom Post Types détectés', 'pass', implode( ', ', $cpt_names ) . ' — couverts par le SEO panel + sitemap' );
        } else {
            $this->add( $g, 'Custom Post Types', 'skip', 'Aucun CPT public avec contenu détecté' );
        }

        // ── WooCommerce ──
        if ( class_exists( 'WooCommerce' ) ) {
            $wc_counts = wp_count_posts( 'product' );
            $product_count = is_object( $wc_counts ) && isset( $wc_counts->publish ) ? (int) $wc_counts->publish : 0;
            $this->add( $g, 'WooCommerce détecté', 'pass',
                $product_count . ' produit(s) publié(s) — Schema Product auto + OG enrichis actifs'
            );
            // Check if products are in sitemap
            $sm = class_exists( 'HTS_Sitemap' ) ? HTS_Sitemap::get_settings() : array();
            $in_sitemap = isset( $sm['post_types'] ) && in_array( 'product', (array) $sm['post_types'], true );
            $this->add( $g, 'Produits dans le sitemap', $in_sitemap ? 'pass' : 'warn',
                $in_sitemap ? 'Les produits sont inclus dans le sitemap XML' : 'Activez le type "Produits" dans Réglages → Sitemap → Post types'
            );
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 13: HTTP ENDPOINTS (live tests)
     * ═══════════════════════════════════════════════ */

    private function test_http_endpoints() {
        $g = 'Endpoints HTTP';

        // Sitemap
        $sitemap_url = home_url( '/sitemap.xml' );
        $resp = wp_remote_head( $sitemap_url, array( 'timeout' => 10, 'sslverify' => false ) );
        if ( is_wp_error( $resp ) ) {
            // Loopback blocked — note it but don't fail
            $this->add( $g, 'sitemap.xml', 'warn', 'Loopback HTTP bloqué : ' . $resp->get_error_message() . ' — Vérifiez manuellement : ' . $sitemap_url );
        } else {
            $code = wp_remote_retrieve_response_code( $resp );
            $ct = wp_remote_retrieve_header( $resp, 'content-type' );
            $is_xml = strpos( $ct, 'xml' ) !== false;
            $this->add( $g, 'sitemap.xml', $code === 200 && $is_xml ? 'pass' : 'fail', "HTTP $code — Content-Type: $ct" );
        }

        // robots.txt
        $robots_url = home_url( '/robots.txt' );
        $resp = wp_remote_get( $robots_url, array( 'timeout' => 10, 'sslverify' => false ) );
        if ( is_wp_error( $resp ) ) {
            $this->add( $g, 'robots.txt', 'warn', 'Loopback bloqué — vérifiez manuellement' );
        } else {
            $code = wp_remote_retrieve_response_code( $resp );
            $body = wp_remote_retrieve_body( $resp );
            $has_ua = strpos( $body, 'User-agent' ) !== false;
            $has_sitemap = stripos( $body, 'Sitemap:' ) !== false;
            $this->add( $g, 'robots.txt', $code === 200 && $has_ua ? 'pass' : 'fail', "HTTP $code — " . ( $has_ua ? 'User-agent ✓' : 'User-agent ✗' ) . ' — ' . ( $has_sitemap ? 'Sitemap ✓' : 'Sitemap ✗' ) );
        }

        // llms.txt
        if ( get_option( 'hts_llmstxt_enabled', '1' ) === '1' ) {
            $llms_url = home_url( '/llms.txt' );
            $resp = wp_remote_head( $llms_url, array( 'timeout' => 10, 'sslverify' => false ) );
            if ( is_wp_error( $resp ) ) {
                // Functional fallback
                if ( class_exists( 'HTS_LLMs_Txt' ) ) {
                    $llms = new HTS_LLMs_Txt();
                    $content = method_exists( $llms, 'get_content' ) ? $llms->get_content() : '';
                    $this->add( $g, 'llms.txt', strlen( $content ) > 50 ? 'pass' : 'warn', 'Loopback bloqué mais contenu généré (' . strlen( $content ) . ' car.) — vérifiez ' . $llms_url );
                } else {
                    $this->add( $g, 'llms.txt', 'warn', 'Loopback bloqué' );
                }
            } else {
                $code = wp_remote_retrieve_response_code( $resp );
                $this->add( $g, 'llms.txt', $code === 200 ? 'pass' : 'fail', "HTTP $code" );
            }
        }

        // IndexNow key file
        if ( get_option( 'hts_indexnow_enabled', '0' ) === '1' ) {
            $key = HTS_IndexNow::get_api_key();
            $key_url = home_url( '/' . $key . '.txt' );
            $resp = wp_remote_get( $key_url, array( 'timeout' => 10, 'sslverify' => false ) );
            if ( is_wp_error( $resp ) ) {
                $this->add( $g, 'IndexNow key file', 'warn', 'Loopback bloqué — vérifiez ' . $key_url );
            } else {
                $code = wp_remote_retrieve_response_code( $resp );
                $body = trim( wp_remote_retrieve_body( $resp ) );
                $this->add( $g, 'IndexNow key file', $code === 200 && $body === $key ? 'pass' : 'fail', "HTTP $code — " . ( $body === $key ? 'Key match ✓' : "Key mismatch: expected '$key', got '$body'" ) );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 14: FRONT-END COMPATIBILITY (HTML live)
     *  Fetches actual HTML output and checks for
     *  duplicate tags, conflicting plugins, cache issues
     * ═══════════════════════════════════════════════ */

    private function test_frontend_compat() {
        $g = 'Compatibilité Front-End';

        // Fetch homepage HTML
        $url  = home_url( '/' );
        $resp = wp_remote_get( $url, array( 'timeout' => 15, 'sslverify' => false, 'redirection' => 3 ) );

        if ( is_wp_error( $resp ) ) {
            $this->add( $g, 'Accès homepage', 'warn', 'Loopback HTTP bloqué : ' . $resp->get_error_message() . ' — Tests front-end impossibles' );
            return;
        }

        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code !== 200 ) {
            $this->add( $g, 'Accès homepage', 'fail', "HTTP $code — Attendu 200" );
            return;
        }

        $html = wp_remote_retrieve_body( $resp );
        $this->add( $g, 'Accès homepage', 'pass', "HTTP 200 — " . strlen( $html ) . ' octets' );

        // Only parse <head> section for performance
        $head = '';
        $head_start = stripos( $html, '<head' );
        $head_end   = stripos( $html, '</head>' );
        if ( $head_start !== false && $head_end !== false ) {
            $head = substr( $html, $head_start, $head_end - $head_start + 7 );
        } else {
            $this->add( $g, 'Parsing <head>', 'warn', 'Impossible d\'isoler la balise <head> — tests limités' );
            $head = $html; // fallback: parse whole page
        }

        $head_lower = strtolower( $head );

        // ── Double <title> ──
        $title_count = substr_count( $head_lower, '<title' );
        $this->add( $g, 'Double <title>', $title_count <= 1 ? 'pass' : 'fail',
            $title_count . ' balise(s) <title>' . ( $title_count > 1 ? ' — CONFLIT: thème ou plugin injecte un 2e title' : '' )
        );

        // ── Double meta description ──
        $desc_count = preg_match_all( '/<meta[^>]+name=["\']description["\']/i', $head, $m );
        $this->add( $g, 'Double meta description', $desc_count <= 1 ? 'pass' : 'fail',
            $desc_count . ' meta description(s)' . ( $desc_count > 1 ? ' — CONFLIT: plugin SEO concurrent ou thème' : '' )
        );

        // ── Double meta robots ──
        $robots_count = preg_match_all( '/<meta[^>]+name=["\']robots["\']/i', $head, $m );
        $this->add( $g, 'Double meta robots', $robots_count <= 1 ? 'pass' : 'fail',
            $robots_count . ' meta robots' . ( $robots_count > 1 ? ' — CONFLIT: wp_robots ou concurrent actif' : '' )
        );

        // ── Double rel canonical ──
        $canonical_count = preg_match_all( '/<link[^>]+rel=["\']canonical["\']/i', $head, $m );
        $this->add( $g, 'Double canonical', $canonical_count <= 1 ? 'pass' : 'fail',
            $canonical_count . ' rel=canonical' . ( $canonical_count > 1 ? ' — CONFLIT: WP core ou concurrent' : '' )
        );

        // ── Double OG tags ──
        $og_title_count = preg_match_all( '/<meta[^>]+property=["\']og:title["\']/i', $head, $m );
        $og_desc_count  = preg_match_all( '/<meta[^>]+property=["\']og:description["\']/i', $head, $m );
        $og_total = $og_title_count + $og_desc_count;
        $this->add( $g, 'Double OG tags', $og_title_count <= 1 && $og_desc_count <= 1 ? 'pass' : 'fail',
            "og:title × $og_title_count, og:description × $og_desc_count"
            . ( $og_title_count > 1 || $og_desc_count > 1 ? ' — CONFLIT: Jetpack, thème, ou plugin social' : '' )
        );

        // ── Double Schema JSON-LD ──
        $schema_count = substr_count( $head_lower, 'application/ld+json' );
        // Also check body for schema (some themes inject in footer)
        $body_schema  = substr_count( strtolower( $html ), 'application/ld+json' );
        $this->add( $g, 'Schema JSON-LD', 'pass',
            "$body_schema bloc(s) JSON-LD total" . ( $body_schema > 3 ? ' — Vérifier si thème injecte des schemas supplémentaires' : '' )
        );
        // Detect specific duplicate Organization/Website schemas
        if ( preg_match_all( '/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/si', $html, $ld_matches ) ) {
            $org_count = 0;
            $website_count = 0;
            foreach ( $ld_matches[1] as $ld_block ) {
                if ( stripos( $ld_block, '"Organization"' ) !== false ) $org_count++;
                if ( stripos( $ld_block, '"WebSite"' ) !== false )     $website_count++;
            }
            if ( $org_count > 1 ) {
                $this->add( $g, 'Double Schema Organization', 'fail', "$org_count blocs Organization — thème ou plugin injecte un doublon" );
            }
            if ( $website_count > 1 ) {
                $this->add( $g, 'Double Schema WebSite', 'fail', "$website_count blocs WebSite — doublon détecté" );
            }
        }

        // ── Detect competing plugin output markers ──
        $markers = array(
            'Yoast SEO'     => array( 'yoast seo plugin', 'yoast-schema' ),
            'Rank Math'     => array( 'rank math', 'rank-math' ),
            'All in One SEO' => array( 'all in one seo', 'aioseo' ),
            'SEOPress'      => array( 'seopress' ),
            'Jetpack OG'    => array( 'jetpack open graph', 'jetpack-open-graph' ),
        );
        $found_markers = array();
        foreach ( $markers as $name => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( stripos( $html, $pattern ) !== false ) {
                    $found_markers[] = $name;
                    break;
                }
            }
        }
        if ( ! empty( $found_markers ) ) {
            $this->add( $g, 'Output concurrent détecté', 'fail',
                implode( ', ', array_unique( $found_markers ) ) . ' injecte du HTML — neutralisation incomplète !'
            );
        } else {
            $this->add( $g, 'Output concurrent', 'pass', 'Aucun marqueur Yoast/RankMath/AIOSEO/SEOPress/Jetpack dans le HTML' );
        }

        // ── HTS own output present ──
        $hts_marker = stripos( $html, 'HTS Light' ) !== false || stripos( $html, 'Hack The SEO' ) !== false || stripos( $html, 'HackTheSEO' ) !== false;
        $this->add( $g, 'Marqueur Hack The SEO', $hts_marker ? 'pass' : 'fail', $hts_marker ? 'Commentaire Hack The SEO trouvé dans le <head>' : 'Aucun marqueur Hack The SEO — le module Meta Tags est-il activé ?' );

        // ── Test an internal post page too (if available) ──
        $sample_post = get_posts( array( 'numberposts' => 1, 'post_status' => 'publish', 'post_type' => 'post' ) );
        if ( ! empty( $sample_post ) ) {
            $post_url  = get_permalink( $sample_post[0]->ID );
            $post_resp = wp_remote_get( $post_url, array( 'timeout' => 15, 'sslverify' => false, 'redirection' => 3 ) );

            if ( ! is_wp_error( $post_resp ) && wp_remote_retrieve_response_code( $post_resp ) === 200 ) {
                $post_html  = wp_remote_retrieve_body( $post_resp );
                $post_lower = strtolower( $post_html );

                // Check title on article page
                $post_title_count = substr_count( $post_lower, '<title' );
                $post_desc_count  = preg_match_all( '/<meta[^>]+name=["\']description["\']/i', $post_html, $m );
                $post_canon_count = preg_match_all( '/<link[^>]+rel=["\']canonical["\']/i', $post_html, $m );

                $post_ok = $post_title_count <= 1 && $post_desc_count <= 1 && $post_canon_count <= 1;
                $this->add( $g, 'Page article test', $post_ok ? 'pass' : 'fail',
                    '"' . mb_substr( $sample_post[0]->post_title, 0, 40 ) . '…" — '
                    . "title×$post_title_count, desc×$post_desc_count, canonical×$post_canon_count"
                    . ( ! $post_ok ? ' — CONFLIT sur template single' : '' )
                );
            } else {
                $this->add( $g, 'Page article test', 'warn', 'Impossible de fetch ' . $post_url );
            }
        }

        // ── Cache detection ──
        $cache_headers = array();
        $resp_headers = wp_remote_retrieve_headers( $resp );
        foreach ( array( 'x-cache', 'x-litespeed-cache', 'x-varnish', 'cf-cache-status', 'x-proxy-cache', 'x-wp-super-cache' ) as $ch ) {
            $val = is_object( $resp_headers ) && isset( $resp_headers[ $ch ] ) ? $resp_headers[ $ch ] : '';
            if ( ! empty( $val ) ) $cache_headers[] = $ch . ': ' . $val;
        }
        if ( ! empty( $cache_headers ) ) {
            $this->add( $g, 'Cache détecté', 'warn', implode( ' | ', $cache_headers ) . ' — Purger après modification SEO' );
        } else {
            $this->add( $g, 'Cache', 'pass', 'Aucun header de cache détecté' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 15: ONBOARDING & UX
     * ═══════════════════════════════════════════════ */

    private function test_onboarding_ux() {
        $g = 'Onboarding & UX';

        // ── Sitemap first-run: cron scheduled ──
        $next = wp_next_scheduled( 'hts_sitemap_cron' );
        $this->add( $g, 'Cron sitemap planifié', $next ? 'pass' : 'fail',
            $next ? 'Prochain run : ' . wp_date( 'Y-m-d H:i:s', $next ) : 'Cron non planifié — aucune régénération auto'
        );

        // ── Sitemap stats: has URLs ──
        $stats = get_option( 'hts_sitemap_stats', array() );
        $last  = ! empty( $stats['last_generated'] ) ? $stats['last_generated'] : '';
        $cron_last = ! empty( $stats['cron_last_run'] ) ? $stats['cron_last_run'] : '';
        $this->add( $g, 'Sitemap déjà généré', ! empty( $last ) ? 'pass' : 'warn',
            ! empty( $last ) ? "Dernière génération : $last" : 'Jamais généré — en attente du premier cron'
        );

        // ── DISABLE_WP_CRON detection ──
        $cron_disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
        $this->add( $g, 'WP-Cron actif', ! $cron_disabled ? 'pass' : 'warn',
            $cron_disabled ? 'DISABLE_WP_CRON=true — Configurer un cron système' : 'WP-Cron natif actif'
        );

        // ── Settings mode saved ──
        $mode = get_option( 'hts_settings_mode', 'amateur' );
        $this->add( $g, 'Mode réglages', 'pass', 'Mode : ' . ucfirst( $mode ) );

        // ── CSS/JS assets loaded check ──
        $css_file = HTS__PLUGIN_DIR . 'admin/css/hts-synchronise-articles-admin.css';
        $js_file  = HTS__PLUGIN_DIR . 'admin/js/hts-seo-settings.js';
        $assets_ok = file_exists( $css_file ) && file_exists( $js_file );
        $this->add( $g, 'Assets admin', $assets_ok ? 'pass' : 'fail',
            $assets_ok ? 'CSS + JS présents' : 'Fichier(s) manquant(s) — réinstaller le plugin'
        );

        // ── First activation flag cleanup ──
        $first_run_pending = get_option( 'hts_sitemap_first_run', false );
        $this->add( $g, 'Flag first-run', ! $first_run_pending ? 'pass' : 'warn',
            ! $first_run_pending ? 'Nettoyé' : 'En attente — première génération sitemap pas encore exécutée'
        );

        // ── SEO Scores pre-computed ──
        global $wpdb;
        $total_published = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type " . hts_sql_post_types_in()
        );
        $with_score = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_combined_score'"
        );
        $score_pct = $total_published > 0 ? round( $with_score / $total_published * 100 ) : 0;
        $score_progress = get_option( 'hts_batch_score_progress', array() );
        $sp_status = $score_progress['status'] ?? '';
        if ( $sp_status === 'running' ) {
            $this->add( $g, 'Scores SEO pré-calculés', 'warn',
                "En cours : $with_score/$total_published ($score_pct%) — batch en arrière-plan"
            );
        } else {
            $this->add( $g, 'Scores SEO pré-calculés',
                $score_pct >= 90 ? 'pass' : ( $score_pct > 0 ? 'warn' : 'fail' ),
                "$with_score/$total_published ($score_pct%)"
                . ( $score_pct < 90 ? ' — Lancer "Calculer les scores SEO" dans le Cockpit' : '' )
            );
        }
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 17: PLUGIN WEIGHT — Impact on site performance
     * ═══════════════════════════════════════════════ */

    private function test_plugin_weight() {
        $g = 'Poids du plugin';

        // ── 1. Memory usage ──
        $mem_before = memory_get_usage( true );
        $mem_peak   = memory_get_peak_usage( true );
        $mem_limit  = $this->parse_size( ini_get( 'memory_limit' ) );
        $mem_pct    = $mem_limit > 0 ? round( $mem_peak / $mem_limit * 100 ) : 0;

        $this->add( $g, 'Pic mémoire PHP', $mem_pct < 50 ? 'pass' : ( $mem_pct < 75 ? 'warn' : 'fail' ),
            size_format( $mem_peak ) . ' / ' . size_format( $mem_limit ) . ' (' . $mem_pct . '%)'
        );

        // ── 2. Options autoload size ──
        global $wpdb;
        $autoload_size = (int) $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload = 'yes' AND option_name LIKE 'hts_%'"
        );
        $autoload_kb = round( $autoload_size / 1024, 1 );
        $this->add( $g, 'Options autoload Hack The SEO', $autoload_kb < 500 ? 'pass' : ( $autoload_kb < 2000 ? 'warn' : 'fail' ),
            $autoload_kb . ' Ko en autoload — ' . ( $autoload_kb < 500 ? 'Léger' : ( $autoload_kb < 2000 ? 'Modéré, surveiller' : 'Trop lourd, optimiser' ) )
        );

        // ── 3. Total autoload (all plugins + WP) ──
        $total_autoload = (int) $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload = 'yes'"
        );
        $total_kb = round( $total_autoload / 1024, 1 );
        $this->add( $g, 'Total autoload du site', $total_kb < 1000 ? 'pass' : ( $total_kb < 3000 ? 'warn' : 'fail' ),
            $total_kb . ' Ko total — ' . ( $total_kb < 1000 ? 'Bon' : 'Vérifier les options volumineuses' )
        );

        // ── 4. HTS-specific options count ──
        $hts_options_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE 'hts_%'"
        );
        $this->add( $g, 'Nombre d\'options Hack The SEO', $hts_options_count < 150 ? 'pass' : ( $hts_options_count < 300 ? 'warn' : 'fail' ),
            $hts_options_count . ' options en base'
        );

        // ── 5. Transients count (scaled to site size) ──
        $transient_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '%_transient_hts_%'"
        );
        // Threshold: ~3x published posts is normal (content cache + rate limits + misc)
        $published = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type " . hts_sql_post_types_in()
        );
        $transient_threshold_warn = max( 200, $published * 5 );
        $transient_threshold_fail = max( 500, $published * 15 );
        $this->add( $g, 'Transients Hack The SEO', $transient_count < $transient_threshold_warn ? 'pass' : ( $transient_count < $transient_threshold_fail ? 'warn' : 'fail' ),
            $transient_count . ' transient(s) actif(s) — seuil normal pour ' . $published . ' posts publiés'
        );

        // ── 6. Post meta footprint ──
        $meta_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE '_hts_%'"
        );
        $meta_size = (int) $wpdb->get_var(
            "SELECT SUM(LENGTH(meta_value)) FROM {$wpdb->postmeta} WHERE meta_key LIKE '_hts_%'"
        );
        $meta_mb = round( ( $meta_size ?: 0 ) / 1048576, 2 );
        $this->add( $g, 'Meta posts Hack The SEO', $meta_mb < 50 ? 'pass' : ( $meta_mb < 200 ? 'warn' : 'fail' ),
            $meta_count . ' entrées (' . $meta_mb . ' Mo) — ' . ( $meta_mb < 50 ? 'Léger' : 'Surveiller la croissance' )
        );

        // ── 7. Custom tables size ──
        $tables = array( 'hts_actions', 'hts_workflow_actions', 'hts_workflow_agents', 'hts_redirects', 'hts_404_log', 'hts_gsc_data', 'hts_embeddings', 'hts_strategy_patterns' );
        $total_table_mb = 0;
        $table_details = array();
        foreach ( $tables as $t ) {
            $full = $wpdb->prefix . $t;
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $full ) ) === $full ) {
                $row_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$full}" );
                $table_status = $wpdb->get_row( "SHOW TABLE STATUS LIKE '{$full}'" );
                $size_mb = $table_status ? round( ( $table_status->Data_length + $table_status->Index_length ) / 1048576, 2 ) : 0;
                $total_table_mb += $size_mb;
                if ( $size_mb > 1 || $row_count > 1000 ) {
                    $table_details[] = $t . ': ' . $row_count . ' lignes / ' . $size_mb . ' Mo';
                }
            }
        }
        $this->add( $g, 'Tables custom Hack The SEO', $total_table_mb < 100 ? 'pass' : ( $total_table_mb < 500 ? 'warn' : 'fail' ),
            round( $total_table_mb, 1 ) . ' Mo total' . ( ! empty( $table_details ) ? ' — ' . implode( ', ', $table_details ) : '' )
        );

        // ── 8. Front-end hooks count ──
        $front_hooks = 0;
        $front_hooks += count( array_filter( glob( HTS__PLUGIN_DIR . 'modules/*.php' ), function( $f ) {
            $c = file_get_contents( $f );
            return preg_match( "/add_action\s*\(\s*['\"]wp_head['\"]/", $c ) || preg_match( "/add_filter\s*\(\s*['\"]the_content['\"]/", $c );
        } ) );
        $this->add( $g, 'Modules avec hooks front-end', $front_hooks < 10 ? 'pass' : 'warn',
            $front_hooks . ' module(s) ajoutent du code sur chaque page visiteur'
        );

        // ── 9. PHP file count + total codebase ──
        $php_files = glob( HTS__PLUGIN_DIR . 'modules/*.php' );
        $total_lines = 0;
        foreach ( $php_files as $f ) {
            $total_lines += count( file( $f ) );
        }
        $this->add( $g, 'Taille codebase modules', 'pass',
            count( $php_files ) . ' fichiers, ~' . number_format( $total_lines ) . ' lignes PHP'
        );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 18: CRON HEALTH — Scheduled tasks audit
     * ═══════════════════════════════════════════════ */

    private function test_cron_health() {
        $g = 'Santé des tâches planifiées';

        // ── 1. Count HTS crons ──
        $crons = _get_cron_array();
        $hts_crons = array();
        $hts_overdue = array();
        $now = time();

        if ( is_array( $crons ) ) {
            foreach ( $crons as $timestamp => $hooks ) {
                foreach ( $hooks as $hook => $events ) {
                    if ( strpos( $hook, 'hts_' ) === 0 ) {
                        $hts_crons[ $hook ] = array(
                            'next'    => $timestamp,
                            'overdue' => $timestamp < $now,
                            'events'  => count( $events ),
                        );
                        if ( $timestamp < ( $now - 3600 ) ) {
                            $hts_overdue[] = $hook . ' (retard ' . human_time_diff( $timestamp ) . ')';
                        }
                    }
                }
            }
        }

        $cron_count = count( $hts_crons );
        $this->add( $g, 'Tâches planifiées Hack The SEO', $cron_count <= 12 ? 'pass' : ( $cron_count <= 20 ? 'warn' : 'fail' ),
            $cron_count . ' cron(s) actif(s)' . ( $cron_count > 12 ? ' — Beaucoup de crons, vérifier si tous nécessaires' : '' )
        );

        // ── 2. Overdue crons ──
        $this->add( $g, 'Crons en retard (> 1h)', empty( $hts_overdue ) ? 'pass' : 'warn',
            empty( $hts_overdue ) ? 'Aucun retard' : implode( ', ', array_slice( $hts_overdue, 0, 5 ) )
        );

        // ── 3. Duplicate crons (same hook scheduled multiple times) ──
        $duplicates = array();
        foreach ( $hts_crons as $hook => $info ) {
            if ( $info['events'] > 1 ) {
                $duplicates[] = $hook . ' (' . $info['events'] . 'x)';
            }
        }
        $this->add( $g, 'Crons dupliqués', empty( $duplicates ) ? 'pass' : 'warn',
            empty( $duplicates ) ? 'Aucun doublon' : 'Doublons : ' . implode( ', ', $duplicates ) . ' — Désactiver/réactiver le plugin'
        );

        // ── 4. WP-Cron active ──
        $cron_disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
        $this->add( $g, 'WP-Cron système', ! $cron_disabled ? 'pass' : 'warn',
            $cron_disabled
                ? 'DISABLE_WP_CRON=true — Configurer un vrai cron serveur (recommandé pour la performance)'
                : 'WP-Cron natif actif — fonctionne mais un cron serveur serait plus fiable'
        );

        // ── 5. Total site crons (not just HTS) ──
        $total_crons = 0;
        if ( is_array( $crons ) ) {
            foreach ( $crons as $hooks ) $total_crons += count( $hooks );
        }
        $this->add( $g, 'Total crons du site', $total_crons < 50 ? 'pass' : ( $total_crons < 100 ? 'warn' : 'fail' ),
            $total_crons . ' tâche(s) planifiée(s) globalement' . ( $total_crons >= 50 ? ' — ' . $cron_count . ' sont de Hack The SEO' : '' )
        );

        // ── 6. High-frequency crons ──
        $high_freq = array();
        $schedules = wp_get_schedules();
        if ( is_array( $crons ) ) {
            foreach ( $crons as $hooks ) {
                foreach ( $hooks as $hook => $events ) {
                    if ( strpos( $hook, 'hts_' ) !== 0 ) continue;
                    foreach ( $events as $ev ) {
                        $schedule = $ev['schedule'] ?? '';
                        $interval = isset( $schedules[ $schedule ] ) ? $schedules[ $schedule ]['interval'] : 0;
                        if ( $interval > 0 && $interval < 3600 ) {
                            $high_freq[] = $hook . ' (toutes les ' . round( $interval / 60 ) . ' min)';
                        }
                    }
                }
            }
        }
        $this->add( $g, 'Crons haute fréquence (< 1h)', empty( $high_freq ) ? 'pass' : 'warn',
            empty( $high_freq ) ? 'Aucun cron trop fréquent' : implode( ', ', $high_freq ) . ' — consomme des ressources'
        );

        // ── 7. List all HTS crons with next run ──
        $cron_list = array();
        foreach ( $hts_crons as $hook => $info ) {
            $cron_list[] = $hook . ' → ' . wp_date( 'Y-m-d H:i', $info['next'] );
        }
        $this->add( $g, 'Détail des crons', 'pass',
            empty( $cron_list ) ? 'Aucun cron' : implode( ' | ', array_slice( $cron_list, 0, 8 ) ) . ( count( $cron_list ) > 8 ? ' (+' . ( count( $cron_list ) - 8 ) . ')' : '' )
        );
    }

    /* ═══════════════════════════════════════════════
     *  GROUP 19: SECURITY AUDIT
     * ═══════════════════════════════════════════════ */

    private function test_security_audit() {
        $g = 'Audit sécurité';

        // ── 1. AJAX handlers — all have capability check ──
        $modules_dir = HTS__PLUGIN_DIR . 'modules/';
        $missing_cap = 0;
        $missing_nonce = 0;
        $checked_handlers = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $file ) {
            $code = file_get_contents( $file );
            if ( preg_match_all( '/public function (ajax_\w+)\([^)]*\)\s*\{(.{0,500})/s', $code, $matches ) ) {
                foreach ( $matches[2] as $i => $body ) {
                    $func = $matches[1][ $i ];
                    if ( $func === 'ajax_track' ) continue; // Public handler (nopriv)
                    $checked_handlers++;
                    if ( strpos( $body, 'current_user_can' ) === false && strpos( $body, 'verify_ajax' ) === false ) {
                        $missing_cap++;
                    }
                    if ( strpos( $body, 'check_ajax_referer' ) === false && strpos( $body, 'wp_verify_nonce' ) === false && strpos( $body, 'verify_ajax' ) === false ) {
                        $missing_nonce++;
                    }
                }
            }
        }
        $this->add( $g, 'AJAX : vérification permissions', $missing_cap === 0 ? 'pass' : 'fail',
            $checked_handlers . ' handlers vérifiés — ' . ( $missing_cap === 0 ? 'Tous protégés' : $missing_cap . ' SANS current_user_can !' )
        );
        $this->add( $g, 'AJAX : vérification nonce (anti-CSRF)', $missing_nonce === 0 ? 'pass' : 'fail',
            $missing_nonce === 0 ? 'Tous protégés' : $missing_nonce . ' SANS nonce !'
        );

        // ── 3. REST API routes exposure ──
        $rest_exposed = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $file ) {
            $code = file_get_contents( $file );
            $rest_exposed += preg_match_all( '/register_rest_route/', $code );
        }
        // Also check main plugin + admin
        $main_code = file_get_contents( HTS__PLUGIN_DIR . 'hack-the-seo-light.php' );
        $rest_exposed += preg_match_all( '/register_rest_route/', $main_code );

        $this->add( $g, 'Endpoints REST API exposés', $rest_exposed <= 5 ? 'pass' : 'warn',
            $rest_exposed . ' route(s) REST — ' . ( $rest_exposed <= 5 ? 'Normal' : 'Vérifier que toutes ont une permission_callback' )
        );

        // ── 4. REST routes with permission_callback ──
        $rest_no_perm = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $file ) {
            $code = file_get_contents( $file );
            if ( preg_match_all( '/register_rest_route\s*\([^;]+\)/s', $code, $routes ) ) {
                foreach ( $routes[0] as $route ) {
                    if ( strpos( $route, 'permission_callback' ) === false ) {
                        $rest_no_perm++;
                    }
                }
            }
        }
        $this->add( $g, 'REST : permission_callback', $rest_no_perm === 0 ? 'pass' : 'fail',
            $rest_no_perm === 0 ? 'Toutes les routes ont une permission_callback' : $rest_no_perm . ' route(s) SANS permission_callback !'
        );

        // ── 5. File permissions ──
        $plugin_dir = HTS__PLUGIN_DIR;
        $writable_issues = 0;
        $check_files = array( 'hack-the-seo-light.php', 'modules/class-hts-cockpit.php', 'modules/class-hts-cocon-commander.php' );
        foreach ( $check_files as $cf ) {
            $full = $plugin_dir . $cf;
            if ( file_exists( $full ) ) {
                $perms = fileperms( $full ) & 0777;
                if ( $perms & 0002 ) $writable_issues++; // World-writable
            }
        }
        $this->add( $g, 'Permissions fichiers', $writable_issues === 0 ? 'pass' : 'fail',
            $writable_issues === 0 ? 'Aucun fichier en écriture publique' : $writable_issues . ' fichier(s) en 777 — risque de sécurité'
        );

        // ── 6. nopriv AJAX handlers (public-facing) ──
        $nopriv_count = 0;
        $nopriv_hooks = array();
        foreach ( glob( $modules_dir . '*.php' ) as $file ) {
            $code = file_get_contents( $file );
            if ( preg_match_all( '/wp_ajax_nopriv_(\w+)/', $code, $np ) ) {
                $nopriv_count += count( $np[1] );
                $nopriv_hooks = array_merge( $nopriv_hooks, $np[1] );
            }
        }
        $this->add( $g, 'Endpoints publics (nopriv)', $nopriv_count <= 2 ? 'pass' : 'warn',
            $nopriv_count . ' handler(s) accessible(s) sans connexion' . ( ! empty( $nopriv_hooks ) ? ' : ' . implode( ', ', $nopriv_hooks ) : '' )
        );

        // ── 7. SQL injection check — direct $_POST/$_GET in queries ──
        $sql_issues = 0;
        foreach ( glob( $modules_dir . '*.php' ) as $file ) {
            $code = file_get_contents( $file );
            // Look for $wpdb->query/get_* with direct $_POST/$_GET (not inside prepare)
            if ( preg_match_all( '/\$wpdb->(query|get_var|get_col|get_results|get_row)\s*\(\s*["\'].*\$_(?:POST|GET|REQUEST)/', $code, $sq ) ) {
                $sql_issues += count( $sq[0] );
            }
        }
        $this->add( $g, 'Protection SQL injection', $sql_issues === 0 ? 'pass' : 'fail',
            $sql_issues === 0 ? 'Aucune injection directe détectée' : $sql_issues . ' requête(s) avec entrée utilisateur directe !'
        );

        // ── 8. API key exposure ──
        $api_key = get_option( 'hts_api_key', '' );
        $openai_key = hts_get_openai_key();
        $keys_in_html = false;
        // Check that keys are not directly output in JS/HTML
        $scan_dirs = array( $modules_dir, HTS__PLUGIN_DIR . 'admin/partials/' );
        foreach ( $scan_dirs as $dir ) {
            foreach ( glob( $dir . '*.php' ) as $file ) {
                $code = file_get_contents( $file );
                // Detect actual key value output (not just variable name checks like empty())
                if ( preg_match( '/(?:echo|print)\s+(?:\$hts_api_key|\$openai_key|get_option\s*\(\s*[\'"]hts_(?:api_key|openai_api_key)[\'"])(?!\s*\)?\s*\?\s)/', $code ) ) {
                    $keys_in_html = true;
                }
                // Detect wp_localize_script passing actual key values
                if ( preg_match( '/wp_localize_script.*[\'"]api_key[\'"]\s*=>\s*get_option\s*\(\s*[\'"]hts_(?:api_key|openai_api_key)/', $code ) ) {
                    $keys_in_html = true;
                }
            }
        }
        $this->add( $g, 'Clés API non exposées', ! $keys_in_html ? 'pass' : 'fail',
            ! $keys_in_html ? 'Les clés API restent côté serveur' : 'Clé API potentiellement exposée dans le HTML !'
        );
    }

    /**
     * Parse a PHP size string (128M, 512M, 1G) to bytes.
     */
    private function parse_size( $size_str ) {
        $size_str = trim( $size_str );
        $unit = strtolower( substr( $size_str, -1 ) );
        $val  = (int) $size_str;
        switch ( $unit ) {
            case 'g': return $val * 1073741824;
            case 'm': return $val * 1048576;
            case 'k': return $val * 1024;
            default:  return $val;
        }
    }

    /* ═══════════════════════════════════════════════
     *  RENDER — Admin page output
     * ═══════════════════════════════════════════════ */

    public function render_page() {
        $this->run_all_tests();

        // Group results
        $groups = array();
        foreach ( $this->results as $r ) {
            $groups[ $r['group'] ][] = $r;
        }

        $score = $this->pass + $this->fail + $this->warn + $this->skip;
        $pct = $score > 0 ? round( $this->pass / $score * 100 ) : 0;
        ?>
        <style>
            .hd { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 960px; margin: 20px auto; }
            .hd-header { background: linear-gradient(135deg, #1e293b 0%, #334155 100%); color: #fff; padding: 28px 32px; border-radius: 12px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }
            .hd-header h1 { margin: 0; font-size: 22px; font-weight: 700; color: #fff; }
            .hd-header .sub { color: #94a3b8; margin-top: 4px; font-size: 13px; }
            .hd-score { text-align: center; }
            .hd-score .pct { font-size: 36px; font-weight: 800; color: <?php echo esc_attr( $pct >= 80 ? '#10b981' : ( $pct >= 50 ? '#f59e0b' : '#ef4444' ) ); ?>; }
            .hd-score .label { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px; }
            .hd-summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
            .hd-stat { text-align: center; padding: 16px; background: #fff; border-radius: 8px; border: 1px solid #e2e8f0; }
            .hd-stat .n { font-size: 28px; font-weight: 800; }
            .hd-stat .l { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-top: 2px; }
            .hd-stat.pass .n { color: #10b981; }
            .hd-stat.fail .n { color: #ef4444; }
            .hd-stat.warn .n { color: #f59e0b; }
            .hd-stat.skip .n { color: #94a3b8; }
            .hd-group { background: #fff; border-radius: 10px; border: 1px solid #e2e8f0; margin-bottom: 16px; overflow: hidden; }
            .hd-group-title { padding: 14px 20px; font-weight: 700; font-size: 14px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; cursor: pointer; display: flex; justify-content: space-between; align-items: center; }
            .hd-group-title:hover { background: #f1f5f9; }
            .hd-group-title .badge { font-size: 11px; padding: 2px 10px; border-radius: 99px; font-weight: 600; }
            .hd-row { padding: 10px 20px; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; gap: 12px; font-size: 13px; }
            .hd-row:last-child { border-bottom: none; }
            .hd-icon { width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; flex-shrink: 0; }
            .hd-icon.pass { background: #d1fae5; color: #059669; }
            .hd-icon.fail { background: #fee2e2; color: #dc2626; }
            .hd-icon.warn { background: #fef3c7; color: #d97706; }
            .hd-icon.skip { background: #f1f5f9; color: #94a3b8; }
            .hd-name { font-weight: 600; min-width: 220px; color: #1e293b; }
            .hd-detail { color: #64748b; font-size: 12px; flex: 1; }
            .hd-actions { display: flex; gap: 10px; margin-bottom: 24px; }
            .hd-btn { padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer; font-size: 13px; font-weight: 600; }
            .hd-btn-primary { background: #3b82f6; color: #fff; }
            .hd-btn-primary:hover { background: #2563eb; }
            .hd-btn-danger { background: #fee2e2; color: #dc2626; }
            .hd-btn-danger:hover { background: #fecaca; }
            .hd-note { background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; font-size: 12px; color: #92400e; }
        </style>

        <div class="hd">
            <div class="hd-header">
                <div>
                    <h1 style="color:#fff;">Audit SEO</h1>
                    <div class="sub">Audit automatique — Hack The SEO v<?php echo esc_html( HTS__VERSION ); ?></div>
                </div>
                <div class="hd-score">
                    <div class="pct"><?php echo (int) $this->pass; ?><span style="font-size:16px;font-weight:400;color:#94a3b8;">/ <?php echo (int) $score; ?></span></div>
                    <div class="label">Tests réussis</div>
                </div>
            </div>

            <div class="hd-actions">
                <button class="hd-btn hd-btn-primary" onclick="location.reload()">🔄 Relancer les tests</button>
                <button class="hd-btn" style="background:#dbeafe;color:#2563eb;" onclick="htsExportDiag()">📋 Exporter le rapport</button>
            </div>

            <div class="hd-summary">
                <div class="hd-stat pass"><div class="n"><?php echo (int) $this->pass; ?></div><div class="l">Réussi</div></div>
                <div class="hd-stat fail"><div class="n"><?php echo (int) $this->fail; ?></div><div class="l">Échoué</div></div>
                <div class="hd-stat warn"><div class="n"><?php echo (int) $this->warn; ?></div><div class="l">Attention</div></div>
                <div class="hd-stat skip"><div class="n"><?php echo (int) $this->skip; ?></div><div class="l">Ignoré</div></div>
            </div>

            <?php foreach ( $groups as $group_name => $tests ) :
                $group_fails = count( array_filter( $tests, function( $t ) { return $t['status'] === 'fail'; } ) );
                $group_warns = count( array_filter( $tests, function( $t ) { return $t['status'] === 'warn'; } ) );
                $badge_color = $group_fails > 0 ? '#fee2e2; color: #dc2626' : ( $group_warns > 0 ? '#fef3c7; color: #d97706' : '#d1fae5; color: #059669' );
                $badge_text  = $group_fails > 0 ? $group_fails . ' erreur(s)' : ( $group_warns > 0 ? $group_warns . ' alerte(s)' : 'OK' );
            ?>
            <div class="hd-group">
                <div class="hd-group-title" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? '' : 'none'">
                    <?php echo esc_html( $group_name ); ?>
                    <span class="badge" style="background: <?php echo esc_attr( $badge_color ); ?>"><?php echo esc_html( $badge_text ); ?></span>
                </div>
                <div>
                    <?php foreach ( $tests as $t ) : ?>
                    <div class="hd-row">
                        <div class="hd-icon <?php echo esc_attr( $t['status'] ); ?>">
                            <?php echo $t['status'] === 'pass' ? '✓' : ( $t['status'] === 'fail' ? '✗' : ( $t['status'] === 'warn' ? '!' : '—' ) ); ?>
                        </div>
                        <div class="hd-name"><?php echo esc_html( $t['name'] ); ?></div>
                        <div class="hd-detail"><?php echo esc_html( $t['detail'] ); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <?php
            // Show cleanup actions if there are issues to fix
            $has_string_robots = false;
            $has_orphans = false;
            foreach ( $this->results as $r ) {
                if ( $r['name'] === 'Robots meta: format' && $r['status'] !== 'pass' ) $has_string_robots = true;
                if ( $r['name'] === 'Meta orphelines' && $r['status'] !== 'pass' ) $has_orphans = true;
            }
            if ( $has_string_robots || $has_orphans ) : ?>
            <div class="hd-group" style="border-color:#fde68a;">
                <div class="hd-group-title" style="background:#fffbeb;">
                    Actions de nettoyage
                    <span class="badge" style="background:#fef3c7;color:#d97706;">Disponible</span>
                </div>
                <div style="padding:16px 20px;">
                    <?php if ( $has_string_robots ) : ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                        <div>
                            <strong style="font-size:13px;">Normaliser robots meta</strong>
                            <div style="font-size:12px;color:#64748b;">Convertir les données string → array pour cohérence (fonctionne déjà via normalize, ceci nettoie la BDD)</div>
                        </div>
                        <button class="hd-btn" style="background:#dbeafe;color:#2563eb;white-space:nowrap;" onclick="htsNormalizeRobots(this)">Normaliser</button>
                    </div>
                    <?php endif; ?>
                    <?php if ( $has_orphans ) : ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;">
                        <div>
                            <strong style="font-size:13px;">Nettoyer meta orphelines</strong>
                            <div style="font-size:12px;color:#64748b;">Supprimer les meta HTS sur les posts supprimés</div>
                        </div>
                        <button class="hd-btn" style="background:#dbeafe;color:#2563eb;white-space:nowrap;" onclick="htsCleanOrphans(this)">Nettoyer</button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <script>
        var hdNonce = '<?php echo wp_create_nonce( "hts_admin_nonce" ); ?>';
        function htsExportDiag() {
            window.location.href = ajaxurl + '?action=hts_diagnostic_export&nonce=' + hdNonce;
        }
        function htsNormalizeRobots(btn) {
            if ( ! confirm( 'Normaliser toutes les robots meta string → array ?' ) ) return;
            btn.disabled = true; btn.textContent = '…';
            fetch( ajaxurl, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=hts_diagnostic_normalize_robots&nonce=' + hdNonce
            }).then(r => r.json()).then(d => {
                if (d.success) {
                    btn.textContent = '✓ ' + d.data.converted + ' converti(s)';
                    btn.style.background = '#d1fae5'; btn.style.color = '#059669';
                    setTimeout(() => location.reload(), 1500);
                } else { btn.textContent = 'Erreur'; btn.style.background = '#fee2e2'; btn.style.color = '#dc2626'; }
            });
        }
        function htsCleanOrphans(btn) {
            if ( ! confirm( 'Supprimer les meta HTS orphelines ? (irréversible)' ) ) return;
            btn.disabled = true; btn.textContent = '…';
            fetch( ajaxurl, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=hts_diagnostic_clean_orphans&nonce=' + hdNonce
            }).then(r => r.json()).then(d => {
                if (d.success) {
                    btn.textContent = '✓ ' + d.data.deleted + ' supprimée(s)';
                    btn.style.background = '#d1fae5'; btn.style.color = '#059669';
                    setTimeout(() => location.reload(), 1500);
                } else { btn.textContent = 'Erreur'; btn.style.background = '#fee2e2'; btn.style.color = '#dc2626'; }
            });
        }
        function htsToggleDiag() {
            // Kept for backward compatibility but no longer shown
        }
        </script>
        <?php
    }
}
