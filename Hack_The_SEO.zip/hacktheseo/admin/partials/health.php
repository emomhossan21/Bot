<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Hack The SEO — Santé du plugin (S12 — DS v5.7)
 * Tab dans les réglages unifiés.
 * Utilise HTS_Health_Check (module) pour les données + AJAX.
 * @since 2.6.0
 */
if ( ! class_exists( 'HTS_Health_Check' ) ) {
	echo '<div class="hts-ds-card" style="padding:40px;text-align:center"><p style="color:var(--hts-text-3)">Le module Santé n\'est pas disponible sur cette installation.</p></div>';
	return;
}

$hth_nonce      = wp_create_nonce( 'hts_admin_nonce' );
$hth_tests      = HTS_Health_Check::get_tests();
$hth_groups     = HTS_Health_Check::get_group_labels();
$hth_results    = get_option( 'hts_health_results', array() );
$hth_test_res   = isset( $hth_results['results'] ) ? $hth_results['results'] : array();
$hth_summary    = isset( $hth_results['summary'] ) ? $hth_results['summary'] : array();
$hth_history    = get_option( 'hts_health_history', array() );
$hth_breaker    = get_option( HTS_Health_Check::OPTION_BREAKER, array() );
$hth_config     = get_option( HTS_Health_Check::OPTION_CONFIG, array() );
$hth_score      = HTS_Health_Check::get_health_score();
$hth_last_run   = isset( $hth_results['timestamp'] ) ? $hth_results['timestamp'] : null;
$hth_next_cron  = wp_next_scheduled( 'hts_health_cron' );

// Score label
if ( $hth_score === null ) {
	$hth_status_label = 'Pas encore analysé';
	$hth_status_var   = 'var(--hts-text-3)';
} elseif ( $hth_score >= 80 ) {
	$hth_status_label = 'Votre site est en bonne santé';
	$hth_status_var   = 'var(--hts-success)';
} elseif ( $hth_score >= 50 ) {
	$hth_status_label = 'Quelques points à améliorer';
	$hth_status_var   = 'var(--hts-caution)';
} else {
	$hth_status_label = 'Des problèmes nécessitent votre attention';
	$hth_status_var   = 'var(--hts-danger)';
}

// Group tests
$hth_grouped = array();
foreach ( $hth_tests as $tkey => $tdef ) {
	$g = isset( $tdef['group'] ) ? $tdef['group'] : 'other';
	$hth_grouped[ $g ][ $tkey ] = $tdef;
}

// CEO group labels
$hth_ceo_groups = array(
	'infrastructure' => 'Fondations techniques',
	'seo_technique'  => 'Référencement',
	'intelligence'   => 'Agents et intelligence IA',
);
?>

<!-- Score header -->
<div class="hts-ds-card" style="margin-bottom:16px">
	<div style="display:flex;align-items:center;gap:24px;padding:24px">
		<?php echo HTS_DS::ring( $hth_score !== null ? (int) $hth_score : 0, 80, 5 ); ?>
		<div style="flex:1">
			<div style="font-size:18px;font-weight:700;color:var(--hts-text)"><?php echo esc_html( $hth_status_label ); ?></div>
			<div style="font-size:13px;color:var(--hts-text-3);margin-top:4px" id="hth-score-detail">
				<?php if ( ! empty( $hth_summary ) ) : ?>
					<?php echo (int) ( isset( $hth_summary['ok'] ) ? $hth_summary['ok'] : 0 ); ?> OK, <?php echo (int) ( isset( $hth_summary['warn'] ) ? $hth_summary['warn'] : 0 ); ?> avertissements, <?php echo (int) ( isset( $hth_summary['fail'] ) ? $hth_summary['fail'] : 0 ); ?> problèmes
				<?php else : ?>
					Lancez un premier diagnostic pour voir l'état de votre site.
				<?php endif; ?>
			</div>
			<div style="font-size:11px;color:var(--hts-text-3);margin-top:6px">
				<?php if ( $hth_last_run ) : ?>
					Dernier scan : <?php echo esc_html( wp_date( 'j M Y à H:i', (int) strtotime( $hth_last_run ) ) ); ?>
				<?php endif; ?>
				<?php if ( $hth_next_cron ) : ?>
					 — Prochain : <?php echo esc_html( wp_date( 'j M à H:i', (int) $hth_next_cron ) ); ?>
				<?php endif; ?>
			</div>
		</div>
		<div style="flex-shrink:0">
			<?php echo HTS_DS::button( 'Tout tester', 'primary', 'md', array( 'type' => 'button', 'id' => 'hth-run-all-btn', 'onclick' => 'hthRunAll()' ) ); ?>
			<button type="button" class="hts-ds-btn hts-ds-btn--sm" id="hth-send-report" onclick="hthSendReport()" style="margin-left:8px;background:var(--hts-geo);color:#fff;border:none;border-radius:var(--hts-radius-sm,6px);padding:8px 14px;font-size:13px;cursor:pointer;">
				Envoyer le rapport au support
			</button>
		</div>
	</div>
	<div id="hth-progress" style="display:none;padding:0 24px 16px">
		<div style="height:4px;background:var(--hts-border-sub);border-radius:2px">
			<div id="hth-progress-bar" style="height:100%;background:var(--hts-geo);border-radius:2px;width:0%;transition:width .4s"></div>
		</div>
		<div id="hth-progress-text" style="font-size:11px;color:var(--hts-text-3);margin-top:4px">Analyse en cours...</div>
	</div>
</div>

<!-- Tests by group -->
<?php foreach ( $hth_grouped as $gkey => $gtests ) :
	$glabel = isset( $hth_ceo_groups[ $gkey ] ) ? $hth_ceo_groups[ $gkey ] : ( isset( $hth_groups[ $gkey ] ) ? $hth_groups[ $gkey ] : ucfirst( str_replace( '_', ' ', $gkey ) ) );
?>
<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--hts-text-3);margin:20px 0 8px"><?php echo esc_html( $glabel ); ?></div>
<div class="hts-ds-card" style="margin-bottom:16px;overflow:hidden">
	<?php foreach ( $gtests as $tkey => $tdef ) :
		$tr      = isset( $hth_test_res[ $tkey ] ) ? $hth_test_res[ $tkey ] : array();
		$status  = isset( $tr['status'] ) ? $tr['status'] : 'unknown';
		$message = isset( $tr['message'] ) ? $tr['message'] : 'Pas encore testé';
		$bk      = isset( $hth_breaker[ $tkey ]['status'] ) ? $hth_breaker[ $tkey ]['status'] : 'ok';
	?>
	<div id="hth-row-<?php echo esc_attr( $tkey ); ?>" style="display:flex;align-items:center;gap:14px;padding:12px 20px;border-bottom:1px solid var(--hts-border-sub)">
		<span id="hth-badge-<?php echo esc_attr( $tkey ); ?>" style="font-size:11px;font-weight:600;padding:3px 10px;border-radius:10px;white-space:nowrap;<?php
			if ( $status === 'ok' ) echo 'background:var(--hts-success-bg);color:var(--hts-success)';
			elseif ( $status === 'warn' ) echo 'background:var(--hts-caution-bg);color:var(--hts-caution)';
			elseif ( $status === 'fail' ) echo 'background:var(--hts-danger-bg);color:var(--hts-danger)';
			else echo 'background:var(--hts-surface);color:var(--hts-text-3)';
		?>">
			<?php
			if ( $status === 'ok' ) echo 'OK';
			elseif ( $status === 'warn' ) echo 'Attention';
			elseif ( $status === 'fail' ) echo 'Problème';
			else echo 'Non testé';
			?>
		</span>
		<div style="flex:1;min-width:0">
			<div style="font-size:13px;font-weight:600;color:var(--hts-text)"><?php echo esc_html( $tdef['name'] ); ?></div>
			<div style="font-size:11px;color:var(--hts-text-3);margin-top:1px" id="hth-msg-<?php echo esc_attr( $tkey ); ?>"><?php echo esc_html( $message ); ?></div>
		</div>
		<?php if ( $bk === 'disabled' ) : ?>
		<span style="font-size:10px;font-weight:600;padding:3px 8px;border-radius:6px;background:var(--hts-caution-bg);color:var(--hts-caution)">Désactivé auto</span>
		<?php echo HTS_DS::button( 'Réactiver', 'default', 'sm', array( 'type' => 'button', 'onclick' => 'hthResetBreaker(\'' . esc_js( $tkey ) . '\',this)' ) ); ?>
		<?php endif; ?>
		<?php if ( ! empty( $tdef['has_repair'] ) ) : ?>
		<?php echo HTS_DS::button( 'Réparer', 'default', 'sm', array( 'type' => 'button', 'id' => 'hth-repair-' . esc_attr( $tkey ), 'onclick' => 'hthRepair(\'' . esc_js( $tkey ) . '\',this)', 'style' => $status === 'ok' ? 'display:none' : '' ) ); ?>
		<?php endif; ?>
		<?php echo HTS_DS::button( 'Tester', 'default', 'sm', array( 'type' => 'button', 'onclick' => 'hthRunSingle(\'' . esc_js( $tkey ) . '\',this)' ) ); ?>
	</div>
	<?php endforeach; ?>
</div>
<?php endforeach; ?>

<!-- History -->
<?php if ( ! empty( $hth_history ) ) : ?>
<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--hts-text-3);margin:20px 0 8px">Historique des diagnostics</div>
<div class="hts-ds-card" style="margin-bottom:16px;overflow:hidden">
	<?php foreach ( array_slice( array_reverse( $hth_history ), 0, 10 ) as $hentry ) :
		$hs = isset( $hentry['summary'] ) ? $hentry['summary'] : array();
		$htotal = isset( $hs['total'] ) ? (int) $hs['total'] : 0;
		$hok    = isset( $hs['ok'] ) ? (int) $hs['ok'] : 0;
		$hwarn  = isset( $hs['warn'] ) ? (int) $hs['warn'] : 0;
		$hfail  = isset( $hs['fail'] ) ? (int) $hs['fail'] : 0;
		$hscore = $htotal > 0 ? (int) round( ( ( $hok * 100 + $hwarn * 50 ) / ( $htotal * 100 ) ) * 100 ) : 0;
	?>
	<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 20px;border-bottom:1px solid var(--hts-border-sub);font-size:12px">
		<span style="color:var(--hts-text-3);font-family:var(--hts-mono);font-size:11px"><?php $ts = strtotime( isset( $hentry['timestamp'] ) ? $hentry['timestamp'] : '' ); echo $ts ? esc_html( wp_date( 'j M Y H:i', $ts ) ) : '—'; ?></span>
		<span>
			<strong style="color:<?php echo $hscore >= 80 ? 'var(--hts-success)' : ( $hscore >= 50 ? 'var(--hts-caution)' : 'var(--hts-danger)' ); ?>"><?php echo $hscore; ?>%</strong>
			 — <?php echo $hok; ?> OK, <?php echo $hwarn; ?> attention, <?php echo $hfail; ?> problème(s)
		</span>
		<span style="font-size:10px;color:var(--hts-text-3)"><?php echo esc_html( isset( $hentry['source'] ) ? $hentry['source'] : 'manuel' ); ?></span>
	</div>
	<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Configuration -->
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title( 'Configuration de la surveillance', 'Alertes email et réparation automatique' ); ?>
	<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-end">
		<div style="flex:1;min-width:220px">
			<label style="font-size:12px;font-weight:600;color:var(--hts-text);display:block;margin-bottom:4px">Email pour les alertes</label>
			<?php echo HTS_DS::input( array( 'type' => 'email', 'id' => 'hth-alert-email', 'value' => esc_attr( isset( $hth_config['alert_email'] ) ? $hth_config['alert_email'] : get_option( 'admin_email' ) ), 'style' => 'width:100%' ) ); ?>
			<div style="font-size:11px;color:var(--hts-text-3);margin-top:2px">Recevez un email si un module est automatiquement désactivé.</div>
		</div>
		<div>
			<label style="font-size:12px;font-weight:600;color:var(--hts-text);display:block;margin-bottom:8px">Réparation automatique</label>
			<label class="hts-onb-toggle"><input type="checkbox" id="hth-auto-repair" <?php checked( isset( $hth_config['auto_repair'] ) ? $hth_config['auto_repair'] : true ); ?>><span class="sl"></span></label>
		</div>
		<div>
			<?php echo HTS_DS::button( 'Enregistrer', 'primary', 'sm', array( 'type' => 'button', 'onclick' => 'hthSaveConfig()' ) ); ?>
		</div>
	</div>
	<div id="hth-config-msg" style="display:none;margin-top:8px;font-size:12px;font-weight:600"></div>
</div></div>

<!-- Diagnostic détaillé -->
<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--hts-text-3);margin:20px 0 8px">Diagnostic détaillé</div>
<div class="hts-ds-card" style="margin-bottom:16px;overflow:hidden">
<?php
// ── Gather operational data ──
global $wpdb;

// API keys
$diag_key_saas   = ! empty( get_option( 'hts_api_key', '' ) );
$diag_key_coach  = ! empty( get_option( 'hts_coach_api_key', '' ) );
$diag_key_openai = ! empty( get_option( 'hts_openai_api_key', '' ) );

// Crons
$diag_crons = array(
	'hts_embeddings_index'       => 'Embeddings',
	'hts_health_cron'            => 'Health Check',
	'hts_refresh_weekly_scan'    => 'Fraîcheur contenu',
	'hts_auto_write_weekly'      => 'Rédaction auto',
	'hts_decision_engine_weekly' => 'Decision Engine',
	'hts_weekly_digest'          => 'Digest email',
	'hts_inbox_weekly_scan'      => 'Inbox scan',
);
$diag_crons_ok = 0;
$diag_crons_missing = array();
foreach ( $diag_crons as $hook => $label ) {
	if ( wp_next_scheduled( $hook ) ) {
		$diag_crons_ok++;
	} else {
		$diag_crons_missing[] = $label;
	}
}

// Tables
$diag_tables = array(
	$wpdb->prefix . 'hts_workflow_actions' => 'Workflow',
	$wpdb->prefix . 'hts_workflow_agents'  => 'Agents',
	$wpdb->prefix . 'hts_actions'          => 'Audit Trail',
	$wpdb->prefix . 'hts_embeddings'       => 'Embeddings',
);
$diag_tables_ok = 0;
foreach ( $diag_tables as $tbl => $lbl ) {
	if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl ) ) === $tbl ) $diag_tables_ok++;
}

// Embeddings coverage
$diag_emb = class_exists( 'HTS_Embeddings' ) ? HTS_Embeddings::get_stats() : array( 'coverage' => 0, 'indexed' => 0, 'total_posts' => 0, 'pending' => 0 );

// Content coverage
$pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
$diag_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}" );

$meta_keys_title = "('_hts_meta_title','rank_math_title','_yoast_wpseo_title')";
$meta_keys_desc  = "('_hts_meta_description','rank_math_description','_yoast_wpseo_metadesc','_seopress_titles_desc')";
$diag_with_title = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN {$meta_keys_title} AND meta_value != ''" );
$diag_with_desc  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN {$meta_keys_desc} AND meta_value != ''" );
$diag_with_feat  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_thumbnail_id' AND pm.meta_value > 0 WHERE p.post_status = 'publish' AND p.post_type {$pt_in}" );

// Images ALT
$diag_img_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%'" );
$diag_img_alt   = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt' AND pm.meta_value != '' WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%'" );

// Thin content
$diag_thin = 0;
$thin_q = $wpdb->get_results( "SELECT post_content FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in} LIMIT 500" );
foreach ( $thin_q as $tq ) {
	if ( function_exists( 'hts_word_count' ) ) {
		if ( hts_word_count( wp_strip_all_tags( $tq->post_content ) ) < 300 ) $diag_thin++;
	} else {
		if ( str_word_count( wp_strip_all_tags( $tq->post_content ) ) < 300 ) $diag_thin++;
	}
}

// Workflow Engine
$diag_wf = class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist();
$diag_wf_stats = $diag_wf ? HTS_Workflow_Engine::get_stats() : array( 'pending' => 0, 'done' => 0, 'total' => 0 );

// Redirects
$diag_redirects = is_array( get_option( 'hts_redirects', array() ) ) ? count( get_option( 'hts_redirects', array() ) ) : 0;
$diag_404 = class_exists( 'HTS_Redirects' ) && method_exists( 'HTS_Redirects', 'get_pending_count' ) ? (int) HTS_Redirects::get_pending_count() : 0;

// GSC
$diag_gsc = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();

// Helper
$dpct = function( $n ) use ( $diag_total ) { return $diag_total > 0 ? round( $n / $diag_total * 100 ) : 0; };
$dcolor = function( $pct ) { return $pct >= 80 ? 'var(--hts-success)' : ( $pct >= 50 ? 'var(--hts-caution)' : 'var(--hts-danger)' ); };

$diag_rows = array(
	// Infrastructure
	array( 'g' => 'Infrastructure', 'n' => 'Clé API HTS', 'v' => $diag_key_saas ? 'Connectée' : 'MANQUANTE', 's' => $diag_key_saas ? 'ok' : 'fail' ),
	array( 'g' => '', 'n' => 'Clé OpenAI', 'v' => $diag_key_openai ? 'Active' : 'Absente', 's' => $diag_key_openai ? 'ok' : 'warn' ),
	array( 'g' => '', 'n' => 'Clé Coach (Anthropic)', 'v' => $diag_key_coach ? 'Active' : 'Absente (fallback OpenAI)', 's' => $diag_key_coach ? 'ok' : 'warn' ),
	array( 'g' => '', 'n' => 'Tables base de données', 'v' => $diag_tables_ok . '/' . count( $diag_tables ), 's' => $diag_tables_ok === count( $diag_tables ) ? 'ok' : 'fail' ),
	array( 'g' => '', 'n' => 'Tâches planifiées (crons)', 'v' => $diag_crons_ok . '/' . count( $diag_crons ) . ( ! empty( $diag_crons_missing ) ? ' — manquants : ' . implode( ', ', $diag_crons_missing ) : '' ), 's' => empty( $diag_crons_missing ) ? 'ok' : 'warn' ),
	array( 'g' => '', 'n' => 'Search Console', 'v' => $diag_gsc ? 'Connectée' : 'Non connectée', 's' => $diag_gsc ? 'ok' : 'warn' ),
	array( 'g' => '', 'n' => 'Workflow Engine', 'v' => $diag_wf ? (int) ( isset( $diag_wf_stats['pending'] ) ? $diag_wf_stats['pending'] : 0 ) . ' en attente, ' . (int) ( isset( $diag_wf_stats['done'] ) ? $diag_wf_stats['done'] : 0 ) . ' exécutées' : 'Non disponible', 's' => $diag_wf ? 'ok' : 'fail' ),

	// Couverture contenu
	array( 'g' => 'Couverture contenu (' . $diag_total . ' pages)', 'n' => 'Titre SEO', 'v' => $diag_with_title . '/' . $diag_total . ' (' . $dpct( $diag_with_title ) . '%)', 's' => $dpct( $diag_with_title ) >= 80 ? 'ok' : ( $dpct( $diag_with_title ) >= 50 ? 'warn' : 'fail' ) ),
	array( 'g' => '', 'n' => 'Meta description', 'v' => $diag_with_desc . '/' . $diag_total . ' (' . $dpct( $diag_with_desc ) . '%)', 's' => $dpct( $diag_with_desc ) >= 80 ? 'ok' : ( $dpct( $diag_with_desc ) >= 50 ? 'warn' : 'fail' ) ),
	array( 'g' => '', 'n' => 'Image mise en avant', 'v' => $diag_with_feat . '/' . $diag_total . ' (' . $dpct( $diag_with_feat ) . '%)', 's' => $dpct( $diag_with_feat ) >= 80 ? 'ok' : 'warn' ),
	array( 'g' => '', 'n' => 'ALT des images', 'v' => $diag_img_alt . '/' . $diag_img_total . ' (' . ( $diag_img_total > 0 ? round( $diag_img_alt / $diag_img_total * 100 ) : 100 ) . '%)', 's' => ( $diag_img_total > 0 && round( $diag_img_alt / $diag_img_total * 100 ) < 70 ) ? 'warn' : 'ok' ),
	array( 'g' => '', 'n' => 'Articles trop courts (< 300 mots)', 'v' => $diag_thin > 0 ? $diag_thin . ' article(s)' : 'Aucun', 's' => $diag_thin === 0 ? 'ok' : 'warn' ),
	array( 'g' => '', 'n' => 'Embeddings sémantiques', 'v' => (int) ( isset( $diag_emb['indexed'] ) ? $diag_emb['indexed'] : 0 ) . '/' . (int) ( isset( $diag_emb['total_posts'] ) ? $diag_emb['total_posts'] : 0 ) . ' (' . (int) ( isset( $diag_emb['coverage'] ) ? $diag_emb['coverage'] : 0 ) . '%)', 's' => (int) ( isset( $diag_emb['coverage'] ) ? $diag_emb['coverage'] : 0 ) >= 80 ? 'ok' : 'warn' ),

	// SEO technique
	array( 'g' => 'SEO technique', 'n' => 'Redirections actives', 'v' => $diag_redirects . ' redirection(s)', 's' => 'ok' ),
	array( 'g' => '', 'n' => 'Pages 404 en attente', 'v' => $diag_404 > 0 ? $diag_404 . ' page(s)' : 'Aucune', 's' => $diag_404 === 0 ? 'ok' : 'warn' ),
);

$last_group = '';
foreach ( $diag_rows as $row ) :
	if ( ! empty( $row['g'] ) && $row['g'] !== $last_group ) :
		$last_group = $row['g'];
?>
	<div style="padding:10px 20px;background:var(--hts-surface);border-bottom:1px solid var(--hts-border);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--hts-text-3)"><?php echo esc_html( $row['g'] ); ?></div>
<?php endif; ?>
	<div style="display:flex;align-items:center;gap:12px;padding:10px 20px;border-bottom:1px solid var(--hts-border-sub)">
		<span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;background:<?php echo $row['s'] === 'ok' ? 'var(--hts-success)' : ( $row['s'] === 'warn' ? 'var(--hts-caution)' : 'var(--hts-danger)' ); ?>"></span>
		<span style="flex:1;font-size:13px;font-weight:500;color:var(--hts-text)"><?php echo esc_html( $row['n'] ); ?></span>
		<span style="font-size:12px;color:var(--hts-text-2);font-family:var(--hts-mono);white-space:nowrap"><?php echo esc_html( $row['v'] ); ?></span>
	</div>
<?php endforeach; ?>
</div>

<!-- Debug (admin only) -->
<?php if ( current_user_can( 'manage_options' ) ) : ?>
<div style="margin-top:24px">
	<button type="button" onclick="var d=document.getElementById('hts-debug-tools');d.style.display=d.style.display==='none'?'block':'none'" style="border:none;background:none;cursor:pointer;font-size:12px;color:var(--hts-text-3);padding:0;font-family:var(--hts-font)">
		<?php echo HTS_DS::icon( 'gear', 13, 'var(--hts-text-3)' ); ?> Outils avancés
	</button>
	<div id="hts-debug-tools" style="display:none;margin-top:12px;padding:20px;border:1px dashed var(--hts-border);border-radius:var(--hts-radius-sm);background:var(--hts-surface)">
		<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=test-suite' ) ); ?>" class="hts-ds-btn hts-ds-btn--sm" style="text-decoration:none">
				<?php echo HTS_DS::icon( 'zap', 13, 'var(--hts-text-2)' ); ?> Test Suite
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=health' ) ); ?>" class="hts-ds-btn hts-ds-btn--sm" style="text-decoration:none">
				<?php echo HTS_DS::icon( 'shield', 13, 'var(--hts-text-2)' ); ?> Health Check
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=global-score' ) ); ?>" class="hts-ds-btn hts-ds-btn--sm" style="text-decoration:none">
				<?php echo HTS_DS::icon( 'chart', 13, 'var(--hts-text-2)' ); ?> Score Global
			</a>
		</div>
		<div style="padding-top:14px;border-top:1px solid var(--hts-border-sub);font-size:11px;color:var(--hts-text-3);font-family:var(--hts-mono);line-height:1.8">
			<?php
			$db_ver = $GLOBALS['wpdb']->db_version();
			$mem    = defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : '?';
			$max_ex = ini_get( 'max_execution_time' );
			?>
			HTS v<?php echo defined( 'HTS__VERSION' ) ? esc_html( HTS__VERSION ) : '?'; ?>
			 · WP <?php echo esc_html( get_bloginfo( 'version' ) ); ?>
			 · PHP <?php echo esc_html( phpversion() ); ?>
			 · MySQL <?php echo esc_html( $db_ver ); ?>
			 · Mémoire <?php echo esc_html( $mem ); ?>
			 · max_execution <?php echo esc_html( $max_ex ); ?>s
		</div>
	</div>
</div>
<?php endif; ?>

<!-- JS -->
<script>
(function(){
var nonce='<?php echo esc_js( $hth_nonce ); ?>',ajaxUrl='<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>';
function post(action,data){var fd=new FormData();fd.append('action',action);fd.append('nonce',nonce);for(var k in data)fd.append(k,data[k]);return fetch(ajaxUrl,{method:'POST',body:fd}).then(function(r){return r.json();});}
function updateBadge(key,t){var b=document.getElementById('hth-badge-'+key),m=document.getElementById('hth-msg-'+key),r=document.getElementById('hth-repair-'+key);if(b){b.textContent=t.status==='ok'?'OK':t.status==='warn'?'Attention':t.status==='fail'?'Problème':'Non testé';b.style.cssText='font-size:11px;font-weight:600;padding:3px 10px;border-radius:10px;white-space:nowrap;'+(t.status==='ok'?'background:var(--hts-success-bg);color:var(--hts-success)':t.status==='warn'?'background:var(--hts-caution-bg);color:var(--hts-caution)':t.status==='fail'?'background:var(--hts-danger-bg);color:var(--hts-danger)':'background:var(--hts-surface);color:var(--hts-text-3)');}if(m)m.textContent=t.message||'';if(r)r.style.display=t.status==='ok'?'none':'inline-flex';}
window.hthRunAll=function(){var btn=document.getElementById('hth-run-all-btn'),prog=document.getElementById('hth-progress'),pbar=document.getElementById('hth-progress-bar'),ptxt=document.getElementById('hth-progress-text');btn.disabled=true;btn.textContent='Analyse...';prog.style.display='block';pbar.style.width='30%';post('hts_health_run_all',{}).then(function(j){pbar.style.width='100%';if(j.success&&j.data&&j.data.results){var tests=j.data.results,sum=j.data.summary||{};for(var k in tests)updateBadge(k,tests[k]);var det=document.getElementById('hth-score-detail');if(det)det.textContent=(sum.ok||0)+' OK, '+(sum.warn||0)+' avertissements, '+(sum.fail||0)+' problèmes';ptxt.textContent='Diagnostic terminé !';}else{ptxt.textContent='Erreur lors du diagnostic.';}btn.disabled=false;btn.textContent='Tout tester';setTimeout(function(){prog.style.display='none';},2500);}).catch(function(){btn.disabled=false;btn.textContent='Tout tester';ptxt.textContent='Erreur réseau.';});};
window.hthRunSingle=function(key,btn){btn.disabled=true;var t=btn.textContent;btn.textContent='...';post('hts_health_run_single',{test_key:key}).then(function(j){if(j.success&&j.data)updateBadge(key,j.data);btn.disabled=false;btn.textContent=t;});};
window.hthRepair=function(key,btn){btn.disabled=true;btn.textContent='...';post('hts_health_repair',{test_key:key}).then(function(j){btn.textContent=j.success?'OK':'Erreur';btn.style.color=j.success?'var(--hts-success)':'var(--hts-danger)';if(j.success)setTimeout(function(){var row=document.getElementById('hth-row-'+key);if(row){var last=row.querySelector('.hts-ds-btn:last-child');if(last)hthRunSingle(key,last);}},500);setTimeout(function(){btn.disabled=false;btn.textContent='Réparer';btn.style.color='';},2000);});};
window.hthResetBreaker=function(key,btn){_htsConfirm('Réactiver le module ?','Le circuit breaker sera réinitialisé et le module redeviendra actif.','Réactiver').then(function(ok){if(!ok)return;btn.disabled=true;btn.textContent='...';post('hts_health_reset_breaker',{test_key:key}).then(function(j){if(j.success){btn.textContent='OK';btn.style.color='var(--hts-success)';}setTimeout(function(){btn.disabled=false;},1500);});});};
window.hthSaveConfig=function(){var em=document.getElementById('hth-alert-email').value,ar=document.getElementById('hth-auto-repair').checked?'1':'0',msg=document.getElementById('hth-config-msg');post('hts_health_save_config',{alert_email:em,auto_repair:ar}).then(function(j){msg.textContent=j.success?'Enregistré':'Erreur';msg.style.color=j.success?'var(--hts-success)':'var(--hts-danger)';msg.style.display='block';setTimeout(function(){msg.style.display='none';},3000);});};
window.hthSendReport=function(){var btn=document.getElementById('hth-send-report');btn.disabled=true;btn.textContent='Envoi en cours...';post('hts_health_send_report',{}).then(function(j){btn.disabled=false;if(j.success){btn.textContent='Rapport envoyé !';btn.style.background='var(--hts-success)';setTimeout(function(){btn.textContent='Envoyer le rapport au support';btn.style.background='var(--hts-geo)';},3000);}else{btn.textContent='Envoyer le rapport au support';alert(j.data&&j.data.message?j.data.message:'Erreur');}}).catch(function(){btn.disabled=false;btn.textContent='Envoyer le rapport au support';alert('Erreur réseau');});};
})();
</script>
