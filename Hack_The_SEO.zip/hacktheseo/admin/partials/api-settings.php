<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Admin partial — API & Connexion Settings
 *
 * Calqué sur le pattern du module Full (settings.php)
 * Un seul bouton "Enregistrer" = save + validate via /api/articles
 *
 * Variables from render_admin_page():
 *   $api_key, $push_history, $total_received, $articles_count, $last_sync
 *
 * @package Hack_The_SEO_Light
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$current_env = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
?>

<div class="hts-wrap">

    <!-- Header -->
    <div class="hts-header">
        <div class="hts-header-left">
            <?php if ( file_exists( HTS__PLUGIN_DIR . 'admin/assets/icons/icon-admin.svg' ) ) : ?>
            <div class="hts-header-logo">
                <img src="<?php echo esc_url( HTS__PLUGIN_URL . 'admin/assets/icons/icon-admin.svg' ); ?>" alt="Hack The SEO">
            </div>
            <?php endif; ?>
            <div>
                <h1>API & Connexion <span class="hts-version">v<?php echo esc_html( HTS__VERSION ); ?></span></h1>
                <p style="color:rgba(255,255,255,0.8);margin:4px 0 0;font-size:13px;">
                    Connectez votre site au SaaS Hack The SEO pour recevoir articles et audits
                </p>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px;">
        <div style="background:#fff;border:1px solid var(--hts-border);border-radius:var(--hts-radius);text-align:center;padding:20px;">
            <div style="font-size:12px;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;">Dernière sync</div>
            <div style="font-size:18px;font-weight:700;color:var(--hts-text);"><?php echo esc_html( $last_sync ? date_i18n( 'j M Y à H:i', strtotime( $last_sync ) ) : '—' ); ?></div>
        </div>
        <div style="background:#fff;border:1px solid var(--hts-border);border-radius:var(--hts-radius);text-align:center;padding:20px;">
            <div style="font-size:12px;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;">Articles reçus</div>
            <div style="font-size:24px;font-weight:700;color:var(--hts-accent);"><?php echo intval( $articles_count ); ?></div>
        </div>
        <div style="background:#fff;border:1px solid var(--hts-border);border-radius:var(--hts-radius);text-align:center;padding:20px;">
            <div style="font-size:12px;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;">Push API reçus</div>
            <div style="font-size:24px;font-weight:700;color:var(--hts-accent);"><?php echo intval( $total_received ); ?></div>
        </div>
    </div>

    <div class="hts-grid">

        <!-- API KEY — Pattern identique au Full (un seul bouton save+validate) -->
        <div class="hts-ds-card">
            <div class="hts-card-header">
 <h3 class="hts-card-title"> Clé API</h3>
            </div>
            <div class="hts-card-body">
                <?php if ( defined( 'HTS_API_KEY' ) && HTS_API_KEY ) : ?>
                    <div class="hts-connection-status hts-connection-status--connected">
                        <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Cle definie dans wp-config.php (prioritaire)
                    </div>
                    <p style="color:var(--hts-gray-500);font-size:13px;margin:12px 0 0;">
                        La cle est configuree via <code>define('HTS_API_KEY', '...')</code> dans votre wp-config.php.
                    </p>
                <?php else : ?>
                <p style="color:var(--hts-gray-500);font-size:14px;margin:0 0 20px;">
                    Votre cle API est disponible dans votre espace
                    <a href="<?php echo esc_url( $current_env ); ?>/" target="_blank" rel="noopener"><?php echo esc_html( str_replace( 'https://', '', $current_env ) ); ?></a>.
                    Elle permet de recevoir vos articles et audits SEO.
                </p>

                <div id="hts-api-alert"></div>

                <form id="hts-api-form" method="post">
                    <div class="hts-form-group">
                        <label class="hts-label" for="hts-api-key">Hack The SEO API Key</label>
                        <div class="hts-input--with-btn">
                            <input
                                type="password"
                                class="hts-input hts-input--mono"
                                id="hts-api-key"
                                name="api_key"
                                value="<?php echo esc_attr( $api_key ); ?>"
                                placeholder="sk-xxxxxxxxxxxxxxxxxxxx"
                                required
                                autocomplete="off"
                                spellcheck="false"
                            >
                            <button type="submit" class="hts-btn hts-btn--primary" id="hts-api-save">
                                <span class="hts-spinner"></span>
                                <span class="hts-btn-label">Enregistrer</span>
                            </button>
                            <?php if ( ! empty( $api_key ) ) : ?>
                            <button type="button" class="hts-btn" id="hts-verify-sub"
                                    style="background:var(--hts-gray-100);margin-left:4px;"
                                    title="Vérifier l'état de l'abonnement">
                                <span class="hts-spinner"></span>
 <span class="hts-btn-label"> Vérifier l'abonnement</span>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>

                <div id="hts-connection-status">
                    <?php if ( ! empty( $api_key ) ) : ?>
                        <div class="hts-connection-status hts-connection-status--connected">
 <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Clé API configurée
                        </div>
                    <?php else : ?>
                        <div class="hts-connection-status hts-connection-status--none">
                            <span>—</span> Aucune clé API configurée
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Subscription status (inline) -->
                <?php if ( ! empty( $api_key ) && class_exists( 'HTS_Subscription' ) ) :
                    $sub_status  = HTS_Subscription::get_status();
                    $sub_data    = HTS_Subscription::get_data();
                    $sub_checked = (int) get_option( HTS_Subscription::OPT_CHECKED_AT, 0 );
                ?>
                <div id="hts-sub-status" class="hts-mt-2">
                    <?php if ( $sub_status === 'active' ) : ?>
                        <div class="hts-connection-status hts-connection-status--connected" style="background:var(--hts-success-bg);">
 <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Abonnement actif
                            <?php if ( ! empty( $sub_data['plan'] ) ) echo ' — ' . esc_html( ucfirst( $sub_data['plan'] ) ); ?>
                            <?php if ( ! empty( $sub_data['expires_at'] ) ) : ?>
                                <span style="color:var(--hts-gray-400);margin-left:8px;font-size:12px;">
                                    exp. <?php echo esc_html( date_i18n( 'j M Y', strtotime( $sub_data['expires_at'] ) ) ); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php elseif ( $sub_status === 'expired' ) : ?>
                        <div class="hts-connection-status hts-connection-status--disconnected" style="border-left-color:var(--hts-warning);color:var(--hts-warning);">
 <?php echo HTS_DS::icon('alert-triangle',14,'var(--hts-caution)'); ?> Abonnement expiré — mises à jour désactivées
                            <a href="<?php echo esc_url( $current_env . '/billing' ); ?>" target="_blank" style="margin-left:8px;font-size:12px;">Renouveler →</a>
                        </div>
                    <?php elseif ( in_array( $sub_status, [ 'cancelled', 'inactive' ], true ) ) : ?>
                        <div class="hts-connection-status hts-connection-status--disconnected">
 <?php echo HTS_DS::icon('x',14,'var(--hts-danger)'); ?> Abonnement inactif
                        </div>
                    <?php else : ?>
                        <div class="hts-connection-status hts-connection-status--none">
                            <span>—</span> Abonnement non vérifié
                        </div>
                    <?php endif; ?>
                    <?php if ( $sub_checked ) : ?>
                        <span id="hts-sub-date" style="font-size:11px;color:var(--hts-gray-400);margin-top:4px;display:block;">
                            Vérifié le <?php echo esc_html( date_i18n( 'j M Y à H:i', $sub_checked ) ); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <?php if ( ! empty( $sub_data ) && is_array( $sub_data ) ) : ?>
                <div style="margin-top:12px;padding:12px 16px;background:#F8FAFC;border:1px solid #E5E7EB;border-radius:8px;font-size:12px;">
                    <div style="font-weight:700;margin-bottom:8px;color:#111827;">Quotas & Limites</div>
                    <?php
                    $q_limit = (int) get_option('hts_api_article_quota_saas', 0);
                    $q_used = (int) get_option('hts_api_articles_used_saas', 0);
                    if ($q_limit === 0) {
                        $q_limit = $sub_data['articles_limit'] ?? '?';
                        $q_used = $sub_data['articles_used'] ?? '?';
                    }
                    $q_remaining = is_numeric($q_limit) && is_numeric($q_used) ? max(0, $q_limit - $q_used) : '?';
                    ?>
                    <div>Articles : <strong><?php echo esc_html( $q_remaining ); ?></strong> restants (<?php echo esc_html( $q_used ); ?> / <?php echo esc_html( $q_limit ); ?>)</div>
                    <details style="margin-top:8px">
                        <summary style="cursor:pointer;color:#6366F1;font-size:11px;">Debug : données brutes</summary>
                        <pre style="font-size:10px;overflow-x:auto;margin-top:4px;max-height:200px;overflow-y:auto;background:#fff;padding:8px;border:1px solid #E5E7EB;border-radius:4px;"><?php echo esc_html( wp_json_encode( $sub_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); ?></pre>
                    </details>
                </div>
                <?php endif; ?>
                <span id="hts-sub-result" style="font-size:13px;color:var(--hts-gray-500);display:none;margin-top:6px;"></span>
                <?php endif; ?>
                <?php endif; /* HTS_API_KEY define check */ ?>
            </div>
        </div>

        <!-- CLÉ API COACH SEO (Anthropic) — hidden unless HTS_SHOW_API_KEYS defined -->
        <?php if ( defined( 'HTS_SHOW_API_KEYS' ) && HTS_SHOW_API_KEYS ) : ?>
        <div class="hts-ds-card">
            <div class="hts-card-header">
                <h3 class="hts-card-title">Coach SEO — Cle API Anthropic</h3>
            </div>
            <div class="hts-card-body">
                <?php if ( defined( 'HTS_ANTHROPIC_API_KEY' ) && HTS_ANTHROPIC_API_KEY ) : ?>
                    <div class="hts-connection-status hts-connection-status--connected">
                        <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Clé définie dans wp-config.php (prioritaire)
                    </div>
                    <p style="color:var(--hts-gray-500);font-size:13px;margin:12px 0 0;">
                        La clé est configurée via <code>define('HTS_ANTHROPIC_API_KEY', '...')</code> dans votre wp-config.php.
                        Pour la modifier, éditez ce fichier directement.
                    </p>
                <?php else :
                    $coach_key = get_option( 'hts_coach_api_key', '' );
                ?>
                    <p style="color:var(--hts-gray-500);font-size:14px;margin:0 0 16px;">
                        Le Coach SEO utilise l\'IA Claude pour analyser votre site et vous donner des conseils personnalisés.
                        Obtenez votre clé sur <a href="https://console.anthropic.com/" target="_blank" rel="noopener">console.anthropic.com</a>.
                    </p>

                    <div id="hts-coach-key-alert"></div>

                    <div class="hts-form-group">
                        <label class="hts-label" for="hts-coach-api-key">Clé API Anthropic</label>
                        <div class="hts-input--with-btn">
                            <input
                                type="password"
                                class="hts-input hts-input--mono"
                                id="hts-coach-api-key"
                                value="<?php echo esc_attr( $coach_key ); ?>"
                                placeholder="sk-ant-api03-..."
                                autocomplete="off"
                                spellcheck="false"
                            >
                            <button type="button" class="hts-btn hts-btn--primary" id="hts-coach-key-save" onclick="htsSaveCoachKey()">
                                <span class="hts-btn-label">Enregistrer</span>
                            </button>
                        </div>
                    </div>

                    <div id="hts-coach-key-status" style="margin-top:8px;">
                        <?php if ( ! empty( $coach_key ) ) : ?>
                            <div class="hts-connection-status hts-connection-status--connected">
                                <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Clé API Coach configurée
                            </div>
                        <?php else : ?>
                            <div class="hts-connection-status hts-connection-status--none">
                                <span>—</span> Aucune clé API Coach configurée
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ( class_exists( 'HTS_Coach' ) ) :
                        $coach_usage  = HTS_Coach::get_usage();
                        $coach_budget = HTS_Coach::get_monthly_budget();
                        $coach_total  = ( $coach_usage['tokens_in'] ?? 0 ) + ( $coach_usage['tokens_out'] ?? 0 );
                        $coach_pct    = $coach_budget > 0 ? min( 100, round( $coach_total / $coach_budget * 100 ) ) : 0;
                    ?>
                    <div style="margin-top:16px;padding:12px 14px;background:var(--hts-gray-50,#f9fafb);border:1px solid var(--hts-border,#e5e7eb);border-radius:8px;">
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                            <span style="font-size:12px;font-weight:600;color:var(--hts-text,#1a1f36);">Utilisation ce mois</span>
                            <span style="font-size:12px;color:var(--hts-gray-500,#64748b);">
                                <?php echo esc_html( number_format( $coach_total ) ); ?> / <?php echo esc_html( number_format( $coach_budget ) ); ?> tokens
                            </span>
                        </div>
                        <div style="height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden;">
                            <div style="height:100%;width:<?php echo $coach_pct; ?>%;background:<?php echo $coach_pct > 80 ? '#dc2626' : ( $coach_pct > 50 ? '#d97706' : '#6366f1' ); ?>;border-radius:3px;"></div>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-top:4px;">
                            <span style="font-size:10px;color:var(--hts-gray-400,#94a3b8);"><?php echo (int) ( $coach_usage['requests'] ?? 0 ); ?> requête(s)</span>
                            <span style="font-size:10px;color:var(--hts-gray-400,#94a3b8);"><?php echo $coach_pct; ?>% utilisé</span>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div style="margin-top:12px;">
                        <label class="hts-label" for="hts-coach-pricing">Tarifs Hack The SEO (affichés par le Coach)</label>
                        <textarea
                            class="hts-input"
                            id="hts-coach-pricing"
                            rows="3"
                            style="resize:vertical;font-size:12px;"
                            placeholder="Ex: Starter 49 euros/mois, Pro 149 euros/mois, Enterprise sur devis"
                        ><?php echo esc_textarea( get_option( 'hts_coach_pricing', '' ) ); ?></textarea>
                        <div style="display:flex;align-items:center;gap:6px;margin-top:6px;">
                            <button type="button" class="hts-btn" style="background:var(--hts-gray-100,#f3f4f6);" onclick="htsSaveCoachPricing()">
                                <span class="hts-btn-label">Enregistrer</span>
                            </button>
                            <span id="hts-pricing-status" style="font-size:11px;"></span>
                        </div>
                        <p style="font-size:11px;color:var(--hts-gray-400,#94a3b8);margin:4px 0 0;">
                            Le Coach citera ces tarifs quand un client pose une question sur les prix. Laissez vide pour rediriger vers le support.
                        </p>
                    </div>

                    <div style="margin-top:12px;">
                        <label class="hts-label" for="hts-coach-budget">Budget mensuel (tokens)</label>
                        <div class="hts-input--with-btn">
                            <input
                                type="number"
                                class="hts-input"
                                id="hts-coach-budget"
                                value="<?php echo esc_attr( class_exists('HTS_Coach') ? HTS_Coach::get_monthly_budget() : 100000 ); ?>"
                                min="1000"
                                max="500000"
                                step="10000"
                            >
                            <button type="button" class="hts-btn" style="background:var(--hts-gray-100,#f3f4f6);" onclick="htsSaveCoachBudget()">
                                <span class="hts-btn-label">Modifier</span>
                            </button>
                        </div>
                        <p style="font-size:11px;color:var(--hts-gray-400,#94a3b8);margin:4px 0 0;">
                            100K tokens ≈ 50 questions. Maximum : 500K tokens/mois.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <script>
        function htsSaveCoachKey() {
            var key = document.getElementById('hts-coach-api-key').value.trim();
            var btn = document.getElementById('hts-coach-key-save');
            var alert = document.getElementById('hts-coach-key-alert');
            btn.disabled = true;
            btn.querySelector('.hts-btn-label').textContent = 'Enregistrement...';

            var fd = new FormData();
            fd.append('action', 'hts_coach_config');
            fd.append('nonce', '<?php echo wp_create_nonce("hts_admin_nonce"); ?>');
            fd.append('save', '1');
            fd.append('api_key', key);

            fetch(ajaxurl, { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                btn.disabled = false;
                btn.querySelector('.hts-btn-label').textContent = 'Enregistrer';
                if (d.success) {
                    var st = document.getElementById('hts-coach-key-status');
                    if (st) st.innerHTML = '<div class="hts-connection-status hts-connection-status--connected">✅ Clé API Coach enregistrée</div>';
                    if (alert) alert.innerHTML = '<div style="padding:10px 14px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;color:#166534;font-size:13px;margin-bottom:12px;">✅ Clé enregistrée avec succès !</div>';
                } else {
                    if (alert) alert.innerHTML = '<div style="padding:10px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;color:#991b1b;font-size:13px;margin-bottom:12px;">❌ ' + (d.data && d.data.message ? d.data.message : 'Erreur') + '</div>';
                }
            });
        }

        function htsSaveCoachBudget() {
            var budget = document.getElementById('hts-coach-budget').value;
            var fd = new FormData();
            fd.append('action', 'hts_coach_config');
            fd.append('nonce', '<?php echo wp_create_nonce("hts_admin_nonce"); ?>');
            fd.append('save', '1');
            fd.append('budget', budget);

            fetch(ajaxurl, { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    var alert = document.getElementById('hts-coach-key-alert');
                    if (alert) alert.innerHTML = '<div style="padding:10px 14px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;color:#166534;font-size:13px;margin-bottom:12px;">Budget mis a jour !</div>';
                }
            });
        }

        function htsSaveCoachPricing() {
            var pricing = document.getElementById('hts-coach-pricing').value;
            var status = document.getElementById('hts-pricing-status');
            var fd = new FormData();
            fd.append('action', 'hts_coach_config');
            fd.append('nonce', '<?php echo wp_create_nonce("hts_admin_nonce"); ?>');
            fd.append('save', '1');
            fd.append('pricing', pricing);

            status.textContent = 'Enregistrement...';
            status.style.color = '#6366f1';

            fetch(ajaxurl, { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    status.textContent = 'Tarifs enregistres !';
                    status.style.color = '#16a34a';
                } else {
                    status.textContent = 'Erreur';
                    status.style.color = '#dc2626';
                }
                setTimeout(function(){ status.textContent = ''; }, 3000);
            });
        }
        </script>
        <?php endif; /* HTS_SHOW_API_KEYS — Anthropic section */ ?>

        <!-- CLÉ API OPENAI (Embeddings + fallback) -->
        <?php if ( defined( 'HTS_SHOW_API_KEYS' ) && HTS_SHOW_API_KEYS ) : ?>
        <div class="hts-ds-card">
            <div class="hts-card-header">
                <h3 class="hts-card-title">OpenAI — Embeddings et IA (fallback)</h3>
            </div>
            <div class="hts-card-body">
                <?php if ( defined( 'HTS_OPENAI_API_KEY' ) && HTS_OPENAI_API_KEY ) : ?>
                    <div class="hts-connection-status hts-connection-status--connected">
                        <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Cle definie dans wp-config.php (prioritaire)
                    </div>
                    <p style="color:var(--hts-gray-500);font-size:13px;margin:12px 0 0;">
                        La cle est configuree via <code>define('HTS_OPENAI_API_KEY', '...')</code> dans votre wp-config.php.
                    </p>
                <?php else : ?>
                    <?php $openai_key = function_exists('hts_get_openai_key') ? hts_get_openai_key() : get_option( 'hts_openai_api_key', '' ); ?>
                    <p style="color:var(--hts-gray-500);font-size:13px;margin:0 0 16px;">
                        La cle OpenAI est utilisee pour les <strong>embeddings semantiques</strong> (analyse de similarite entre articles, detection de cannibalisation, cocon semantique).
                        Obtenez votre cle sur <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">platform.openai.com</a>.
                    </p>

                    <div id="hts-openai-alert"></div>

                    <div class="hts-form-group">
                        <label class="hts-label" for="hts-openai-key">Cle API OpenAI</label>
                        <div class="hts-input--with-btn">
                            <input
                                type="password"
                                class="hts-input hts-input--mono"
                                id="hts-openai-key"
                                value="<?php echo esc_attr( $openai_key ); ?>"
                                placeholder="sk-proj-..."
                                autocomplete="off"
                                spellcheck="false"
                            >
                            <button type="button" class="hts-btn hts-btn--primary" id="hts-openai-key-save" onclick="htsSaveOpenAIKey()">
                                <span class="hts-btn-label">Enregistrer</span>
                            </button>
                        </div>
                    </div>

                    <div id="hts-openai-key-status" style="margin-top:8px;">
                        <?php if ( ! empty( $openai_key ) ) : ?>
                            <div class="hts-connection-status hts-connection-status--connected">
                                <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?> Cle API OpenAI configuree
                            </div>
                        <?php else : ?>
                            <div class="hts-connection-status">
                                <span>&mdash;</span> Aucune cle API OpenAI configuree &mdash; les embeddings sont desactives
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <script>
        function htsSaveOpenAIKey() {
            var key = document.getElementById('hts-openai-key').value.trim();
            var btn = document.getElementById('hts-openai-key-save');
            var alertEl = document.getElementById('hts-openai-alert');
            btn.disabled = true;
            btn.querySelector('.hts-btn-label').textContent = 'Enregistrement...';

            var fd = new FormData();
            fd.append('action', 'hts_save_openai_key');
            fd.append('nonce', '<?php echo wp_create_nonce("hts_admin_nonce"); ?>');
            fd.append('openai_key', key);

            fetch(ajaxurl, { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                btn.disabled = false;
                btn.querySelector('.hts-btn-label').textContent = 'Enregistrer';
                if (d.success) {
                    var st = document.getElementById('hts-openai-key-status');
                    if (st) st.innerHTML = '<div class="hts-connection-status hts-connection-status--connected">Cle API OpenAI enregistree</div>';
                    if (alertEl) alertEl.innerHTML = '<div style="padding:10px 14px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;color:#166534;font-size:13px;margin-bottom:12px;">Cle enregistree avec succes !</div>';
                } else {
                    if (alertEl) alertEl.innerHTML = '<div style="padding:10px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;color:#991b1b;font-size:13px;margin-bottom:12px;">' + (d.data && d.data.message ? d.data.message : 'Erreur') + '</div>';
                }
            });
        }
        </script>
        <?php endif; /* HTS_SHOW_API_KEYS — OpenAI section */ ?>


    </div>

    <!-- PUSH HISTORY -->
    <div class="hts-card hts-mt-5">
        <div class="hts-card-header">
 <h3 class="hts-card-title"> Historique des push reçus</h3>
            <?php if ( ! empty( $push_history ) ) : ?>
                <button type="button" id="hts-clear-history" class="hts-btn hts-btn--outline hts-btn--sm"
                    style="color:var(--hts-danger);border-color:var(--hts-danger);">
 Vider
                </button>
            <?php endif; ?>
        </div>
        <div class="hts-card-body">
            <?php if ( empty( $push_history ) ) : ?>
                <div style="text-align:center;padding:32px 20px;color:var(--hts-gray-400);">
 <div style="font-size:28px;margin-bottom:6px;"></div>
                    <p style="margin:0;font-size:14px;">Aucun push reçu pour le moment.</p>
                </div>
            <?php else : ?>
                <div style="overflow-x:auto;">
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead>
                            <tr style="border-bottom:2px solid var(--hts-gray-200);">
                                <th class="hts-table th">Date</th>
                                <th class="hts-table th">Type</th>
                                <th style="text-align:center;padding:8px 12px;color:var(--hts-gray-500);font-weight:600;">Statut</th>
                                <th class="hts-table th">Détail</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $push_history as $entry ) : ?>
                                <tr style="border-bottom:1px solid var(--hts-gray-100);">
                                    <td style="padding:10px 12px;white-space:nowrap;color:var(--hts-gray-600);">
                                        <?php echo esc_html( $entry['date'] ?? '—' ); ?>
                                    </td>
                                    <td style="padding:10px 12px;">
                                        <?php
                                        $type_label = $entry['type'] ?? 'unknown';
 $type_emoji = '';
                                        echo esc_html( $type_emoji . ' ' . ucfirst( $type_label ) );
                                        ?>
                                    </td>
                                    <td style="padding:10px 12px;text-align:center;">
                                        <?php if ( ( $entry['status'] ?? '' ) === 'success' ) : ?>
 <?php echo HTS_DS::icon('check',14,'var(--hts-success)'); ?>
                                        <?php else : ?>
 <?php echo HTS_DS::icon('x',14,'var(--hts-danger)'); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:10px 12px;color:var(--hts-gray-600);max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                                        <?php echo esc_html( $entry['detail'] ?? '—' ); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ═══ RESSOURCES — Documentation, Changelog, Feature request ═══ -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:20px;">
        <!-- Documentation -->
        <div style="background:#fff;border:1px solid var(--hts-border);border-radius:var(--hts-radius);text-align:center;padding:28px 20px;">
            <div style="margin-bottom:12px;"><?php echo HTS_DS::icon('book-open',28); ?></div>
            <h3 style="font-size:15px;font-weight:700;margin:0 0 8px;color:var(--hts-text);">Documentation</h3>
            <p style="font-size:13px;color:var(--hts-text-2);margin:0 0 16px;line-height:1.5;">
                Guides et tutoriels pour tirer le meilleur de Hack The SEO.
            </p>
            <a href="https://hacktheseo.com/documentation/" target="_blank" rel="noopener" class="hts-btn hts-btn--primary hts-btn--sm">
                Lire la doc
            </a>
        </div>
        <!-- Changelog -->
        <div style="background:#fff;border:1px solid var(--hts-border);border-radius:var(--hts-radius);text-align:center;padding:28px 20px;">
            <div style="margin-bottom:12px;"><?php echo HTS_DS::icon('list-ordered',28); ?></div>
            <h3 style="font-size:15px;font-weight:700;margin:0 0 8px;color:var(--hts-text);">Changelog</h3>
            <p style="font-size:13px;color:var(--hts-text-2);margin:0 0 16px;line-height:1.5;">
                Nouveautés, corrections et améliorations à chaque version.
            </p>
            <a href="https://hacktheseo.com/changelog/" target="_blank" rel="noopener" class="hts-btn hts-btn--primary hts-btn--sm">
                Voir les nouveautés
            </a>
        </div>
        <!-- Suggest a feature -->
        <div style="background:#fff;border:1px solid var(--hts-border);border-radius:var(--hts-radius);text-align:center;padding:28px 20px;">
            <div style="margin-bottom:12px;"><?php echo HTS_DS::icon('lightbulb',28); ?></div>
            <h3 style="font-size:15px;font-weight:700;margin:0 0 8px;color:var(--hts-text);">Suggérer une idée</h3>
            <p style="font-size:13px;color:var(--hts-text-2);margin:0 0 16px;line-height:1.5;">
                Hack The SEO évolue grâce à vos retours. Proposez vos idées.
            </p>
            <a href="https://hacktheseo.com/feedback/" target="_blank" rel="noopener" class="hts-btn hts-btn--primary hts-btn--sm">
                Proposer une idée
            </a>
        </div>
    </div>

    <!-- ═══ IMAGE & AUTHOR SETTINGS (migré depuis Cocon Commander v2.5.0 + Flux API Sprint 6.1) ═══ -->
    <?php
    $img_cfg = class_exists( 'Hts_Synchronise_Articles_Admin' ) && method_exists( 'Hts_Synchronise_Articles_Admin', 'get_image_settings' )
        ? Hts_Synchronise_Articles_Admin::get_image_settings()
        : wp_parse_args( get_option( 'hts_image_settings', array() ), array(
            'featured_enabled' => true, 'featured_source' => 'ai', 'featured_style' => 'illustration',
            'featured_quality' => 'medium', 'featured_text_overlay' => 'none',
            'incontent_enabled' => true, 'incontent_count' => 2,
            'incontent_types' => array( 'illustration', 'infographic' ), 'extra_instructions' => '',
            'pexels_api_key' => '', 'incontent_quality' => 'medium',
            'image_provider' => 'openai', 'openai_model' => 'gpt-image-1',
            'flux_api_key' => '', 'flux_model' => 'flux-2-pro',
        ) );
    $img_styles   = array( 'illustration' => 'Illustration', 'photo_realistic' => 'Photo réaliste', 'infographic' => 'Infographie', '3d_render' => 'Rendu 3D', 'watercolor' => 'Aquarelle', 'minimalist' => 'Minimaliste', 'isometric' => 'Isométrique' );
    $img_types    = array( 'illustration' => 'Illustration', 'infographic' => 'Infographie', 'schema_diagram' => 'Schéma/Diagramme', 'comparison' => 'Comparaison', 'process' => 'Processus', 'photo' => 'Photo' );
    $img_overlays = array( 'none' => 'Aucun', 'title' => 'Titre', 'keyword' => 'Mot-clé', 'brand' => 'Marque' );
    $img_sources  = array( 'ai' => '🤖 IA uniquement', 'pexels' => '📷 Pexels uniquement (photos)', 'both' => '🏆 Mix recommandé (Pexels featured + IA in-content)' );
    $current_provider = $img_cfg['image_provider'] ?? 'openai';
    $default_author = (int) get_option( 'hts_default_author', 0 );
    $wp_authors     = get_users( array( 'capability' => array( 'edit_posts' ), 'orderby' => 'display_name', 'fields' => array( 'ID', 'display_name' ) ) );
    ?>
    <div class="hts-ds-card" style="margin-top:20px;">
        <div class="hts-card-header">
            <h2>🎨 Agent Images — Réglages</h2>
        </div>
        <div class="hts-card-body" style="padding:20px;">

            <!-- Author selector -->
            <div style="padding:12px;background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;margin-bottom:16px;">
                <div style="font-size:12px;font-weight:700;color:#1a1f36;margin-bottom:8px;">✍️ Auteur par défaut des articles</div>
                <select id="hts-default-author" style="width:100%;max-width:300px;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;">
                    <option value="0" <?php selected( $default_author, 0 ); ?>>— Auteur WordPress par défaut —</option>
                    <?php foreach ( $wp_authors as $author ) : ?>
                    <option value="<?php echo (int) $author->ID; ?>" <?php selected( $default_author, (int) $author->ID ); ?>><?php echo esc_html( $author->display_name ); ?></option>
                    <?php endforeach; ?>
                </select>
                <div style="font-size:9px;color:#64748b;margin-top:4px;">Tous les articles générés seront signés par cet auteur.</div>
            </div>

            <!-- ═══ IMAGE PROVIDER SELECTOR ═══ -->
            <div style="padding:16px;background:linear-gradient(135deg,#faf5ff 0%,#f0f9ff 100%);border:1px solid #c4b5fd;border-radius:10px;margin-bottom:16px;">
                <div style="font-size:13px;font-weight:700;color:#1a1f36;margin-bottom:10px;">🧠 Fournisseur IA pour les images</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
                    <!-- OpenAI card -->
                    <label id="hts-provider-card-openai" style="cursor:pointer;padding:12px;border-radius:8px;border:2px solid <?php echo $current_provider === 'openai' ? '#6366f1' : '#e2e8f0'; ?>;background:<?php echo $current_provider === 'openai' ? '#eef2ff' : '#fff'; ?>;transition:all .2s;">
                        <input type="radio" name="hts-img-provider" value="openai" <?php checked( $current_provider, 'openai' ); ?> style="display:none;" onchange="htsToggleProvider()">
                        <div style="font-size:12px;font-weight:700;color:#1a1f36;">OpenAI GPT-image</div>
                        <div style="font-size:9px;color:#64748b;margin-top:3px;">Utilise votre clé API OpenAI existante. Synchrone, résultat immédiat.</div>
                        <div style="margin-top:6px;">
                            <select id="hts-openai-model" style="width:100%;padding:4px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:10px;">
                                <option value="gpt-image-1" <?php selected( $img_cfg['openai_model'] ?? 'gpt-image-1', 'gpt-image-1' ); ?>>gpt-image-1 (~$0.02-0.07/img)</option>
                                <option value="gpt-image-1-mini" <?php selected( $img_cfg['openai_model'] ?? '', 'gpt-image-1-mini' ); ?>>gpt-image-1-mini (~$0.005-0.01/img)</option>
                                <option value="gpt-image-1.5" <?php selected( $img_cfg['openai_model'] ?? '', 'gpt-image-1.5' ); ?>>gpt-image-1.5 (~$0.04/img, meilleur)</option>
                                <option value="dall-e-3" <?php selected( $img_cfg['openai_model'] ?? '', 'dall-e-3' ); ?>>DALL-E 3 (legacy ~$0.04-0.08/img)</option>
                            </select>
                        </div>
                    </label>
                    <!-- BFL Flux card -->
                    <label id="hts-provider-card-flux" style="cursor:pointer;padding:12px;border-radius:8px;border:2px solid <?php echo $current_provider === 'flux' ? '#6366f1' : '#e2e8f0'; ?>;background:<?php echo $current_provider === 'flux' ? '#eef2ff' : '#fff'; ?>;transition:all .2s;">
                        <input type="radio" name="hts-img-provider" value="flux" <?php checked( $current_provider, 'flux' ); ?> style="display:none;" onchange="htsToggleProvider()">
                        <div style="font-size:12px;font-weight:700;color:#1a1f36;">BFL Flux <span style="font-size:9px;padding:1px 5px;background:#dbeafe;color:#1e40af;border-radius:4px;font-weight:600;">NOUVEAU</span></div>
                        <div style="font-size:9px;color:#64748b;margin-top:3px;">Black Forest Labs. Meilleur rendu photo, texte dans l&#39;image, ~$0.03/img.</div>
                        <div style="margin-top:6px;">
                            <select id="hts-flux-model" style="width:100%;padding:4px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:10px;">
                                <option value="flux-2-pro" <?php selected( $img_cfg['flux_model'] ?? 'flux-2-pro', 'flux-2-pro' ); ?>>FLUX.2 [pro] — $0.03/img (recommandé)</option>
                                <option value="flux-2-max" <?php selected( $img_cfg['flux_model'] ?? '', 'flux-2-max' ); ?>>FLUX.2 [max] — $0.07/img (qualité max)</option>
                                <option value="flux-2-klein-9b" <?php selected( $img_cfg['flux_model'] ?? '', 'flux-2-klein-9b' ); ?>>FLUX.2 [klein 9B] — $0.015/img (rapide)</option>
                                <option value="flux-2-klein-4b" <?php selected( $img_cfg['flux_model'] ?? '', 'flux-2-klein-4b' ); ?>>FLUX.2 [klein 4B] — $0.014/img (ultra rapide)</option>
                                <option value="flux-2-flex" <?php selected( $img_cfg['flux_model'] ?? '', 'flux-2-flex' ); ?>>FLUX.2 [flex] — $0.05/img (typographie)</option>
                            </select>
                        </div>
                    </label>
                </div>
                <!-- BFL API Key (visible only when flux selected) -->
                <div id="hts-flux-key-row" style="<?php echo $current_provider === 'flux' ? '' : 'display:none;'; ?>padding:10px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;">
                    <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">🔑 Clé API BFL (Black Forest Labs)</label>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <input type="password" id="hts-flux-api-key" value="<?php echo esc_attr( $img_cfg['flux_api_key'] ?? '' ); ?>" placeholder="Créez un compte sur dashboard.bfl.ai" style="flex:1;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:11px;font-family:monospace;box-sizing:border-box;">
                        <button type="button" onclick="htsTestFluxKey(this)" style="padding:6px 12px;background:#6366f1;color:#fff;border:none;border-radius:6px;font-size:10px;font-weight:600;cursor:pointer;white-space:nowrap;">Tester</button>
                    </div>
                    <div id="hts-flux-key-status" style="font-size:9px;margin-top:4px;color:#64748b;">Pay-as-you-go, pas d&#39;abonnement. <a href="https://dashboard.bfl.ai/get-started" target="_blank" rel="noopener" style="color:#6366f1;">Créer une clé BFL →</a></div>
                </div>
            </div>

            <!-- Source selector -->
            <div style="padding:12px;background:#fefce8;border:1px solid #fde68a;border-radius:8px;margin-bottom:16px;">
                <div style="font-size:12px;font-weight:700;color:#1a1f36;margin-bottom:8px;">📸 Source des images</div>
                <?php foreach ( $img_sources as $src_val => $src_label ) : ?>
                <label style="font-size:11px;display:flex;align-items:center;gap:6px;cursor:pointer;margin-bottom:4px;">
                    <input type="radio" name="hts-img-source" value="<?php echo esc_attr( $src_val ); ?>" <?php checked( $img_cfg['featured_source'] ?? 'ai', $src_val ); ?>> <?php echo esc_html( $src_label ); ?>
                </label>
                <?php endforeach; ?>
                <div style="font-size:9px;color:#92400e;margin-top:6px;">💡 <strong>Mix recommandé :</strong> featured = photo Pexels · in-content = IA (<span id="hts-provider-label"><?php echo $current_provider === 'flux' ? 'Flux' : 'GPT-image'; ?></span>)</div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <!-- Featured image -->
                <div style="padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
                    <div style="font-size:12px;font-weight:700;color:#1a1f36;margin-bottom:8px;">Image mise en avant (IA)</div>
                    <label style="font-size:11px;display:flex;align-items:center;gap:4px;cursor:pointer;margin-bottom:6px;"><input type="checkbox" id="hts-img-feat-enabled" <?php checked( $img_cfg['featured_enabled'] ); ?>> Générer automatiquement</label>
                    <div style="margin-bottom:6px;"><label style="font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px;">Style IA</label>
                        <select id="hts-img-feat-style" style="width:100%;padding:4px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:11px;">
                            <?php foreach ( $img_styles as $sv => $sl ) : ?><option value="<?php echo esc_attr( $sv ); ?>" <?php selected( $img_cfg['featured_style'], $sv ); ?>><?php echo esc_html( $sl ); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div style="margin-bottom:6px;"><label style="font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px;">Qualité</label>
                        <label style="font-size:10px;cursor:pointer;margin-right:6px;"><input type="radio" name="hts-img-feat-q" value="low" <?php checked( $img_cfg['featured_quality'], 'low' ); ?>> Low</label>
                        <label style="font-size:10px;cursor:pointer;margin-right:6px;"><input type="radio" name="hts-img-feat-q" value="medium" <?php checked( in_array( $img_cfg['featured_quality'], array( 'medium', 'standard' ) ) ); ?>> Medium</label>
                        <label style="font-size:10px;cursor:pointer;"><input type="radio" name="hts-img-feat-q" value="high" <?php checked( in_array( $img_cfg['featured_quality'], array( 'high', 'hd' ) ) ); ?>> High</label>
                    </div>
                    <div><label style="font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px;">Texte sur l&#39;image</label>
                        <select id="hts-img-feat-overlay" style="width:100%;padding:4px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:11px;">
                            <?php foreach ( $img_overlays as $ov => $ol ) : ?><option value="<?php echo esc_attr( $ov ); ?>" <?php selected( $img_cfg['featured_text_overlay'], $ov ); ?>><?php echo esc_html( $ol ); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <!-- In-content images -->
                <div style="padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
                    <div style="font-size:12px;font-weight:700;color:#1a1f36;margin-bottom:8px;">Images dans l&#39;article (IA)</div>
                    <label style="font-size:11px;display:flex;align-items:center;gap:4px;cursor:pointer;margin-bottom:6px;"><input type="checkbox" id="hts-img-inc-enabled" <?php checked( $img_cfg['incontent_enabled'] ); ?>> Générer automatiquement</label>
                    <div style="margin-bottom:6px;"><label style="font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px;">Nombre (1-5)</label><input type="number" id="hts-img-inc-count" value="<?php echo (int) $img_cfg['incontent_count']; ?>" min="1" max="5" style="width:60px;padding:4px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:11px;"></div>
                    <div style="margin-bottom:6px;"><label style="font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px;">Qualité</label>
                        <label style="font-size:10px;cursor:pointer;margin-right:6px;"><input type="radio" name="hts-img-inc-q" value="low" <?php checked( $img_cfg['incontent_quality'], 'low' ); ?>> Low</label>
                        <label style="font-size:10px;cursor:pointer;margin-right:6px;"><input type="radio" name="hts-img-inc-q" value="medium" <?php checked( $img_cfg['incontent_quality'], 'medium' ); ?>> Medium</label>
                        <label style="font-size:10px;cursor:pointer;"><input type="radio" name="hts-img-inc-q" value="high" <?php checked( $img_cfg['incontent_quality'], 'high' ); ?>> High</label>
                    </div>
                    <div><label style="font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Types autorisés</label>
                        <?php $current_types = $img_cfg['incontent_types'] ?? array(); foreach ( $img_types as $tv => $tl ) : ?>
                        <label style="font-size:10px;display:flex;align-items:center;gap:4px;cursor:pointer;margin-bottom:2px;"><input type="checkbox" class="hts-img-type-cb" value="<?php echo esc_attr( $tv ); ?>" <?php checked( in_array( $tv, $current_types, true ) ); ?>> <?php echo esc_html( $tl ); ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Pexels API Key -->
            <div style="margin-top:12px;padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
                <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">🔑 Clé API Pexels</label>
                <input type="password" id="hts-img-pexels-key" value="<?php echo esc_attr( $img_cfg['pexels_api_key'] ?? '' ); ?>" placeholder="Gratuit — pexels.com/api" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:11px;font-family:monospace;box-sizing:border-box;">
                <div style="font-size:9px;color:#64748b;margin-top:3px;">Gratuit et illimité. <a href="https://www.pexels.com/api/new/" target="_blank" rel="noopener" style="color:#6366f1;">Créer une clé Pexels →</a></div>
            </div>

            <div style="margin-top:12px;">
                <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Instructions pour l&#39;agent (prompt libre)</label>
                <textarea id="hts-img-extra" rows="3" style="width:100%;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:12px;resize:vertical;box-sizing:border-box;" placeholder="Ex: Privilégier les schémas techniques. Style flat design, fond blanc."><?php echo esc_textarea( $img_cfg['extra_instructions'] ); ?></textarea>
            </div>

            <div style="margin-top:10px;display:flex;gap:8px;align-items:center;">
                <button type="button" onclick="htsSaveImageSettings(this)" style="padding:8px 16px;background:#6366f1;color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">💾 Enregistrer</button>
                <span id="hts-img-save-status" style="font-size:10px;"></span>
            </div>
        </div>
    </div>

    <!-- ═══ AUTO-SCHEDULE SETTINGS (migré depuis Cocon Commander v2.5.0) ═══ -->
    <?php
    $as_cfg     = class_exists( 'HTS_Auto_Write' ) ? HTS_Auto_Write::get_auto_schedule_config() : array( 'enabled' => false );
    $as_days    = $as_cfg['days'] ?? array( 1, 2, 3, 4, 5 );
    $day_labels = array( 1 => 'Lun', 2 => 'Mar', 3 => 'Mer', 4 => 'Jeu', 5 => 'Ven', 6 => 'Sam', 7 => 'Dim' );
    ?>
    <div class="hts-ds-card" style="margin-top:20px;">
        <div class="hts-card-header">
            <h2>📅 Publication automatique</h2>
        </div>
        <div class="hts-card-body" style="padding:20px;">
            <p style="font-size:11px;color:#64748b;margin:0 0 14px;">Quand activée, les articles prêts (brouillons avec image et score GEO suffisant) sont automatiquement planifiés. Aucune intervention nécessaire.</p>

            <label style="font-size:12px;display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:14px;font-weight:600;color:#1a1f36;">
                <input type="checkbox" id="hts-as-enabled" <?php checked( $as_cfg['enabled'] ); ?>> Activer la publication automatique
            </label>

            <div id="hts-as-fields" style="<?php echo $as_cfg['enabled'] ? '' : 'opacity:.5;pointer-events:none;'; ?>">
                <div style="margin-bottom:12px;">
                    <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:6px;">Jours de publication</label>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <?php foreach ( $day_labels as $dv => $dl ) : ?>
                        <label style="font-size:11px;display:flex;align-items:center;gap:3px;cursor:pointer;padding:4px 10px;background:<?php echo in_array( $dv, $as_days, false ) ? '#dbeafe' : '#f1f5f9'; ?>;border-radius:6px;border:1px solid <?php echo in_array( $dv, $as_days, false ) ? '#93c5fd' : '#e2e8f0'; ?>;">
                            <input type="checkbox" class="hts-as-day" value="<?php echo $dv; ?>" <?php checked( in_array( $dv, $as_days, false ) ); ?> style="margin:0;"> <?php echo esc_html( $dl ); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px;">
                    <div>
                        <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Heure</label>
                        <select id="hts-as-time" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:8px;font-size:12px;">
                            <?php for ( $h = 6; $h <= 22; $h++ ) : ?><?php for ( $m = 0; $m < 60; $m += 30 ) : ?><?php $tv = sprintf( '%02d:%02d', $h, $m ); ?>
                            <option value="<?php echo $tv; ?>" <?php selected( $as_cfg['time'] ?? '09:00', $tv ); ?>><?php echo $tv; ?></option>
                            <?php endfor; ?><?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Max par jour</label>
                        <select id="hts-as-max-day" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:8px;font-size:12px;">
                            <option value="1" <?php selected( $as_cfg['max_per_day'] ?? 1, 1 ); ?>>1</option>
                            <option value="2" <?php selected( $as_cfg['max_per_day'] ?? 1, 2 ); ?>>2</option>
                            <option value="3" <?php selected( $as_cfg['max_per_day'] ?? 1, 3 ); ?>>3</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-size:11px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Délai entre articles</label>
                        <select id="hts-as-gap" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:8px;font-size:12px;">
                            <option value="1" <?php selected( $as_cfg['min_gap_hours'] ?? 2, 1 ); ?>>1h</option>
                            <option value="2" <?php selected( $as_cfg['min_gap_hours'] ?? 2, 2 ); ?>>2h</option>
                            <option value="3" <?php selected( $as_cfg['min_gap_hours'] ?? 2, 3 ); ?>>3h</option>
                            <option value="4" <?php selected( $as_cfg['min_gap_hours'] ?? 2, 4 ); ?>>4h</option>
                        </select>
                    </div>
                </div>

                <?php if ( class_exists( 'HTS_Auto_Write' ) ) : ?>
                <div style="padding:8px 12px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;font-size:10px;color:#166534;margin-bottom:12px;">
                    💡 <strong>Garde-fous :</strong> Max <?php echo HTS_Auto_Write::HARD_LIMIT_ARTICLES_PER_WEEK; ?> articles/semaine, image obligatoire, score GEO minimum, anti-cannibalisation.
                </div>
                <?php endif; ?>
            </div>

            <div style="display:flex;gap:8px;align-items:center;margin-top:10px;">
                <button type="button" onclick="htsSaveAutoSchedule(this)" style="padding:8px 16px;background:#6366f1;color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">💾 Enregistrer</button>
                <button type="button" onclick="htsTriggerAutoSchedule(this)" style="padding:6px 12px;background:none;color:#6366f1;border:1px solid #e0e7ff;border-radius:8px;font-size:10px;font-weight:600;cursor:pointer;">▶ Planifier maintenant</button>
                <span id="hts-as-save-status" style="font-size:10px;"></span>
            </div>
        </div>
    </div>

    <!-- System info (compact) -->
    <div style="text-align:center;padding:16px;margin-top:16px;color:var(--hts-text-3);font-size:12px;">
        <strong>Hack The SEO</strong> v<?php echo esc_html( HTS__VERSION ); ?>
        · WordPress <?php echo esc_html( get_bloginfo( 'version' ) ); ?>
        · PHP <?php echo esc_html( PHP_VERSION ); ?>
        · <?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>
    </div>

</div>

<!-- JavaScript — Calqué sur hts-synchronise-articles-admin.js du Full -->
<script>
(function() {
    'use strict';

    var nonce   = (typeof htsAdmin !== 'undefined') ? htsAdmin.nonce : '';
    var ajaxUrl = (typeof htsAdmin !== 'undefined') ? htsAdmin.ajaxUrl : ajaxurl;

    // Helper: show WP-style alert
    function showAlert(container, type, message) {
        if (!container) return;
        var cls = (type === 'success') ? 'notice-success' : 'notice-error';
        container.innerHTML = '<div class="notice ' + cls + '" style="margin:0 0 16px;padding:10px 14px;border-left-width:4px;"><p>' + message + '</p></div>';
    }

    // Helper: refresh subscription status via AJAX
    function refreshSubscription(callback) {
        fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ action: 'hts_refresh_subscription', nonce: nonce })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (callback) callback(data);
        })
        .catch(function() {
            if (callback) callback(null);
        });
    }

    // ═══ API KEY FORM — Save + Validate + Auto-check subscription ═══
    var apiForm = document.getElementById('hts-api-form');
    if (apiForm) {
        apiForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var btn      = document.getElementById('hts-api-save');
            var input    = document.getElementById('hts-api-key');
            var alertBox = document.getElementById('hts-api-alert');
            var statusEl = document.getElementById('hts-connection-status');
            var apiKey   = input.value.trim();

            if (!apiKey) {
                showAlert(alertBox, 'danger', 'Veuillez saisir une clé API.');
                return;
            }

            btn.classList.add('hts-btn--loading');
            btn.disabled = true;
            alertBox.innerHTML = '';

            fetch(ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action:  'hts_save_and_validate_api_key',
                    nonce:   nonce,
                    api_key: apiKey
                })
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                btn.classList.remove('hts-btn--loading');
                btn.disabled = false;

                if (data.success) {
                    showAlert(alertBox, 'success', data.data.message + ' Vérification de l\'abonnement…');
                    if (statusEl) {
                        statusEl.innerHTML = '<div class="hts-connection-status hts-connection-status--connected"><span>\u2713</span> Clé API valide et connectée</div>';
                    }
                    // Auto-check subscription after key save
                    refreshSubscription(function() {
                        setTimeout(function() { location.reload(); }, 1200);
                    });
                } else {
                    var msg = (data.data && data.data.message) ? data.data.message : 'Erreur inconnue.';
                    showAlert(alertBox, 'danger', msg);
                    if (statusEl) {
                        statusEl.innerHTML = '<div class="hts-connection-status hts-connection-status--disconnected"><span>\u2717</span> Clé API invalide</div>';
                    }
                }
            })
            .catch(function(err) {
                btn.classList.remove('hts-btn--loading');
                btn.disabled = false;
                showAlert(alertBox, 'danger', 'Erreur réseau : ' + err.message);
            });
        });
    }

    // ═══ VERIFY SUBSCRIPTION BUTTON ═══
    var verifyBtn = document.getElementById('hts-verify-sub');
    if (verifyBtn) {
        verifyBtn.addEventListener('click', function() {
            var resultEl = document.getElementById('hts-sub-result');
            verifyBtn.classList.add('hts-btn--loading');
            if (resultEl) { resultEl.style.display = 'block'; resultEl.textContent = 'Vérification…'; }

            refreshSubscription(function(data) {
                verifyBtn.classList.remove('hts-btn--loading');
                if (data && data.data && data.data.message) {
                    if (resultEl) resultEl.textContent = (data.success ? '\u2705 ' : '\u274C ') + data.data.message;
                }
                setTimeout(function() { location.reload(); }, 1500);
            });
        });
    }

    // ═══ SAVE DEFAULT STATUS ═══
    var btnSaveStatus = document.getElementById('hts-save-status');
    if (btnSaveStatus) {
        btnSaveStatus.addEventListener('click', function(e) {
            e.preventDefault();
            var sel     = document.getElementById('hts-default-status');
            var saved   = document.getElementById('hts-status-saved');
            btnSaveStatus.classList.add('hts-btn--loading');

            fetch(ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'hts_save_article_default_status',
                    nonce:  nonce,
                    status: sel ? sel.value : 'draft'
                })
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                btnSaveStatus.classList.remove('hts-btn--loading');
                if (saved) {
                    saved.style.display = 'inline';
                    setTimeout(function() { saved.style.display = 'none'; }, 3000);
                }
            })
            .catch(function() {
                btnSaveStatus.classList.remove('hts-btn--loading');
            });
        });
    }


    // ═══ CLEAR HISTORY ═══
    var clearBtn = document.getElementById('hts-clear-history');
    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            _htsConfirm('Vider l\'historique ?','L\'historique des push IndexNow sera supprimé.','Vider','danger').then(function(ok){
            if (!ok) return;

            fetch(ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'hts_clear_push_history',
                    nonce:  nonce
                })
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res.success) location.reload();
            });
            });
        });
    }

    // ═══ IMAGE SETTINGS (migré depuis Cocon Commander + Flux API Sprint 6.1) ═══

    // Toggle provider UI
    window.htsToggleProvider=function(){
        var sel=document.querySelector('input[name="hts-img-provider"]:checked');
        if(!sel)return;
        var v=sel.value;
        // Card styling
        var cO=document.getElementById('hts-provider-card-openai');
        var cF=document.getElementById('hts-provider-card-flux');
        cO.style.border=v==='openai'?'2px solid #6366f1':'2px solid #e2e8f0';
        cO.style.background=v==='openai'?'#eef2ff':'#fff';
        cF.style.border=v==='flux'?'2px solid #6366f1':'2px solid #e2e8f0';
        cF.style.background=v==='flux'?'#eef2ff':'#fff';
        // BFL key row
        document.getElementById('hts-flux-key-row').style.display=v==='flux'?'':'none';
        // Label
        var lb=document.getElementById('hts-provider-label');
        if(lb)lb.textContent=v==='flux'?'Flux':'GPT-image';
    };

    // Test BFL API key
    window.htsTestFluxKey=function(b){
        var key=document.getElementById('hts-flux-api-key').value.trim();
        var st=document.getElementById('hts-flux-key-status');
        if(!key){st.textContent='\u274C Entrez une cl\u00e9 API';st.style.color='#dc2626';return;}
        b.disabled=true;st.textContent='\u23F3 V\u00e9rification...';st.style.color='#6366f1';
        jQuery.post(ajaxUrl,{action:'hts_test_flux_key',nonce:nonce,flux_api_key:key},function(r){
            b.disabled=false;
            if(r.success){
                st.innerHTML='\u2705 '+r.data.message;st.style.color='#16a34a';
            } else {
                st.textContent='\u274C '+(r.data&&r.data.message||'Erreur');st.style.color='#dc2626';
            }
        }).fail(function(){b.disabled=false;st.textContent='\u274C R\u00e9seau';st.style.color='#dc2626';});
    };

    window.htsSaveImageSettings=function(b){
        b.disabled=true;var st=document.getElementById('hts-img-save-status');
        st.textContent='\u23F3';st.style.color='#6366f1';
        var types=[];document.querySelectorAll('.hts-img-type-cb:checked').forEach(function(c){types.push(c.value)});
        var q=document.querySelector('input[name="hts-img-feat-q"]:checked');
        var iq=document.querySelector('input[name="hts-img-inc-q"]:checked');
        var src=document.querySelector('input[name="hts-img-source"]:checked');
        var prov=document.querySelector('input[name="hts-img-provider"]:checked');
        var data={
            action:'hts_save_image_settings',nonce:nonce,
            image_provider:prov?prov.value:'openai',
            openai_model:document.getElementById('hts-openai-model').value,
            flux_api_key:document.getElementById('hts-flux-api-key').value,
            flux_model:document.getElementById('hts-flux-model').value,
            featured_enabled:document.getElementById('hts-img-feat-enabled').checked?'1':'0',
            featured_source:src?src.value:'ai',
            featured_style:document.getElementById('hts-img-feat-style').value,
            featured_quality:q?q.value:'medium',
            featured_text_overlay:document.getElementById('hts-img-feat-overlay').value,
            incontent_enabled:document.getElementById('hts-img-inc-enabled').checked?'1':'0',
            incontent_count:document.getElementById('hts-img-inc-count').value,
            incontent_quality:iq?iq.value:'medium',
            extra_instructions:document.getElementById('hts-img-extra').value,
            pexels_api_key:document.getElementById('hts-img-pexels-key').value,
            default_author:document.getElementById('hts-default-author').value
        };
        if(!types.length)types=['illustration'];
        types.forEach(function(t,i){data['incontent_types['+i+']']=t});
        jQuery.post(ajaxUrl,data,function(r){
            b.disabled=false;
            if(r.success){st.textContent='\u2705 Enregistr\u00e9';st.style.color='#16a34a'}
            else{st.textContent='\u274C '+(r.data&&r.data.message||'Erreur');st.style.color='#dc2626'}
        }).fail(function(){b.disabled=false;st.textContent='\u274C R\u00e9seau';st.style.color='#dc2626'});
    };

    // ═══ AUTO-SCHEDULE SETTINGS (migré depuis Cocon Commander) ═══
    window.htsSaveAutoSchedule=function(b){
        b.disabled=true;var st=document.getElementById('hts-as-save-status');
        st.textContent='\u23F3';st.style.color='#6366f1';
        var days=[];document.querySelectorAll('.hts-as-day:checked').forEach(function(c){days.push(c.value)});
        var jqData={action:'hts_save_auto_schedule',nonce:nonce,
            enabled:document.getElementById('hts-as-enabled').checked?'1':'0',
            time:document.getElementById('hts-as-time').value,
            max_per_day:document.getElementById('hts-as-max-day').value,
            min_gap_hours:document.getElementById('hts-as-gap').value};
        if(!days.length)days=['1','2','3','4','5'];
        days.forEach(function(d,i){jqData['days['+i+']']=d});
        jQuery.post(ajaxUrl,jqData,function(r){
            b.disabled=false;
            if(r.success){st.textContent='\u2705 Enregistr\u00e9';st.style.color='#16a34a';setTimeout(function(){location.reload()},1500)}
            else{st.textContent='\u274C '+(r.data||'Erreur');st.style.color='#dc2626'}
        }).fail(function(){b.disabled=false;st.textContent='\u274C R\u00e9seau';st.style.color='#dc2626'});
    };

    window.htsTriggerAutoSchedule=function(b){
        if(!document.getElementById('hts-as-enabled').checked){b.textContent='\u26a0\ufe0f Activez d\u0027abord';return}
        b.disabled=true;b.textContent='\u23F3 Planification...';
        jQuery.post(ajaxUrl,{action:'hts_trigger_auto_schedule',nonce:nonce},function(r){
            if(r.success){
                var d=r.data;
                if(d.skipped){b.textContent='\u26a0\ufe0f '+(d.skipped==='week_limit'?'Limite hebdo atteinte':d.skipped);b.disabled=false;return}
                var parts=[];
                if(d.generated>0)parts.push('\u2705 '+d.generated+' g\u00e9n\u00e9r\u00e9(s)');
                if(d.images>0)parts.push('\ud83c\udfa8 '+d.images+' image(s)');
                if(d.scheduled>0)parts.push('\ud83d\udcc5 '+d.scheduled+' planifi\u00e9(s)');
                if(parts.length>0){b.innerHTML=parts.join(' \u00b7 ');if(d.scheduled>0)setTimeout(function(){location.reload()},2500);else{b.disabled=false;setTimeout(function(){b.textContent='\u25b6 Planifier maintenant'},5000)}}
                else{b.textContent='\u2705 Aucun article en attente';b.disabled=false}
            }else{b.textContent='\u274c '+(r.data||'Erreur');b.disabled=false}
        }).fail(function(){b.textContent='\u274c R\u00e9seau';b.disabled=false});
    };

    // Toggle auto-schedule fields opacity
    var asToggle=document.getElementById('hts-as-enabled');
    if(asToggle){asToggle.addEventListener('change',function(){var f=document.getElementById('hts-as-fields');if(f){f.style.opacity=this.checked?'1':'.5';f.style.pointerEvents=this.checked?'':'none'}})}

})();
</script>
