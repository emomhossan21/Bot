/**
 * Hack The SEO — Admin Bootstrap
 *
 * This file serves as the anchor for wp_localize_script() which attaches
 * the htsAdmin global object (ajaxUrl, nonce, lang) used by all admin JS.
 *
 * @since 1.4.0
 */
(function () {
    'use strict';

    // Verify htsAdmin was localized by WordPress
    if (typeof htsAdmin === 'undefined') {
        console.warn('[HTS] htsAdmin not localized — AJAX calls will fail.');
    }
})();
