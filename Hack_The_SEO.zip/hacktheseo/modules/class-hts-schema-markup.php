<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Schema Markup — Full Takeover + Schema Pro
 *
 * HTS gère TOUS les schemas JSON-LD. Le concurrent est désactivé via HTS_Compat.
 *
 * Schemas générés :
 *   GLOBAL (toutes pages) :
 *   - Organization    → Identité du site (logo, social, contact)
 *   - WebSite         → SearchAction (sitelinks search box)
 *
 *   POSTS (is_singular post) :
 *   - Article         → Complet (author, dates, image, publisher, wordCount, about, mentions)
 *   - FAQPage         → Détecté depuis le contenu (H3?, details/summary, Gutenberg blocks)
 *   - HowTo           → Détecté depuis les étapes numérotées
 *   - VideoObject     → Détecté depuis les embeds YouTube/Vimeo
 *   - ItemList        → Détecté depuis les listicles
 *   - Speakable       → Optimisation voix + citations IA
 *
 *   SCHEMA PRO (sélection manuelle par post, meta box éditeur) :
 *   - Product         → Prix, marque, SKU/GTIN, note, disponibilité
 *   - LocalBusiness   → Adresse, geo, horaires, sous-types (Restaurant, Store…)
 *   - Event           → Dates, lieu, statut, billetterie
 *   - Course          → Organisme, mode (online/présentiel), langue, prix
 *   - Recipe          → Ingrédients, temps, portions, nutrition, étapes auto-detect
 *   - JobPosting      → Contrat, salaire, télétravail, entreprise, date limite
 *
 *   PAGES (is_singular page) :
 *   - WebPage         → Avec Speakable
 *   - Schema Pro      → Même sélection manuelle disponible
 *
 *   BREADCRUMBS :
 *   - BreadcrumbList  → Géré par class-hts-breadcrumbs.php (pas dupliqué ici)
 *
 * @since 3.3.0 — Full takeover rewrite
 * @since 5.0.0 — Schema Pro: 6 nouveaux types manuels + meta box éditeur
 */

class HTS_Schema_Markup {

    /* ══════════════════════════════════════════════
     *  SCHEMA PRO — Constants
     * ══════════════════════════════════════════════ */

    const META_TYPE = '_hts_schema_type';     // 'auto' | 'Product' | 'LocalBusiness' | ...
    const META_DATA = '_hts_schema_pro_data'; // array of type-specific fields
    const OPT_LOCAL = 'hts_schema_local_business'; // global LocalBusiness settings

    /**
     * Available manual schema types (beyond auto-detected ones).
     * Key = @type value, label = French admin label, icon = emoji.
     */
    const PRO_TYPES = array(
 'auto' => array( 'label' => 'Auto-détection (défaut)', 'icon' => '' ),
 'Product' => array( 'label' => 'Product (Produit)', 'icon' => '' ),
 'LocalBusiness' => array( 'label' => 'LocalBusiness (Commerce)','icon' => '' ),
 'Event' => array( 'label' => 'Event (Événement)', 'icon' => '' ),
 'Course' => array( 'label' => 'Course (Formation)', 'icon' => '' ),
 'Recipe' => array( 'label' => 'Recipe (Recette)', 'icon' => '' ),
 'JobPosting' => array( 'label' => 'JobPosting (Offre emploi)','icon' => '' ),
 'Book' => array( 'label' => 'Book (Livre)', 'icon' => '' ),
        'Review'        => array( 'label' => 'Review (Avis)',           'icon' => '⭐' ),
 'SoftwareApplication' => array( 'label' => 'SoftwareApplication (Logiciel)', 'icon' => '' ),
    );

    public function init() {
        // Loose check: handles '1', 1, true — anything truthy except explicit '0'
        $mod = get_option( 'hts_module_schema', '1' );
        if ( $mod === '0' || $mod === 0 || $mod === false ) {
            $this->debug_log( 'init', 'Module schema désactivé (option=' . var_export( $mod, true ) . ')' );
            return;
        }

        // ── Neutralize competitor schema JSON-LD EARLY ──
        // Must run before wp_footer where RM outputs its JSON-LD
        add_action( 'wp', array( $this, 'neutralize_competitor_schema' ), 1 );

        add_action( 'wp_head', array( $this, 'inject_global_schemas' ), 1 );
        add_action( 'wp_head', array( $this, 'inject_page_schemas' ),  5 );

        // ── Nuclear: clean competitor JSON-LD from wp_footer ──
        // Only activate when a competitor SEO plugin with schema output is present
        // (buffer wraps entire wp_footer — costly on sites with Elementor/heavy themes)
        $has_schema_competitor = class_exists( 'RankMath' )
            || defined( 'WPSEO_VERSION' )
            || function_exists( 'aioseo' )
            || defined( 'SEOPRESS_VERSION' );

        if ( $has_schema_competitor ) {
            add_action( 'wp_footer', array( $this, 'start_jsonld_cleanup_buffer' ), 0 );
            add_action( 'wp_footer', array( $this, 'end_jsonld_cleanup_buffer' ), 9999 );
        }

        add_filter( 'woocommerce_structured_data_product', '__return_empty_array', 999 );

        add_action( 'wp_ajax_hts_schema_preview', array( $this, 'ajax_preview' ) );

        // ── Schema Pro: register meta for Gutenberg REST save ──
        add_action( 'init', array( $this, 'register_schema_pro_meta' ) );

        // ── Schema Pro: meta box in post editor ──
        add_action( 'add_meta_boxes', array( $this, 'add_schema_pro_metabox' ) );
        add_action( 'save_post',      array( $this, 'save_schema_pro_metabox' ), 15, 2 );

        // ── Schema Pro: AJAX save (works in both Classic + Gutenberg) ──
        add_action( 'wp_ajax_hts_schema_pro_save', array( $this, 'ajax_save_schema_pro' ) );

        // ── Schema Pro: AJAX save LocalBusiness global settings ──
        add_action( 'wp_ajax_hts_schema_save_local', array( $this, 'ajax_save_local_settings' ) );

        $this->debug_log( 'init', 'Hooks wp_head enregistrés (prio 1 + 5)' );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  COMPETITOR SCHEMA NEUTRALIZATION
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Neutralize competitor JSON-LD output via filters.
     * Called early (wp action, priority 1) before any schema rendering.
     */
    public function neutralize_competitor_schema() {
        // Rank Math — JsonLD class hooks into wp_footer
        if ( class_exists( 'RankMath' ) || function_exists( 'rank_math' ) ) {
            add_filter( 'rank_math/json_ld', '__return_empty_array', 999 );
            $this->debug_log( 'compat', 'Rank Math schema JSON-LD neutralisé' );
        }

        // Yoast — Schema via wpseo_head presenters
        if ( defined( 'WPSEO_VERSION' ) ) {
            add_filter( 'wpseo_json_ld_output', '__return_empty_array', 999 );
            add_filter( 'wpseo_schema_graph', '__return_empty_array', 999 );
            $this->debug_log( 'compat', 'Yoast schema JSON-LD neutralisé' );
        }

        // AIOSEO
        if ( function_exists( 'aioseo' ) ) {
            add_filter( 'aioseo_schema_output', '__return_empty_array', 999 );
        }

        // SEOPress
        if ( defined( 'SEOPRESS_VERSION' ) ) {
            add_filter( 'seopress_schemas_auto_output', '__return_false', 999 );
            add_filter( 'seopress_jsonld_output', '__return_empty_array', 999 );
        }
    }

    /**
     * Start wp_footer output buffer to catch any remaining competitor JSON-LD.
     */
    public function start_jsonld_cleanup_buffer() {
        if ( is_admin() ) return;
        ob_start();
    }

    /**
     * End wp_footer buffer and strip non-HTS JSON-LD script blocks.
     */
    public function end_jsonld_cleanup_buffer() {
        if ( is_admin() ) return;
        $html = ob_get_clean();
        if ( empty( $html ) ) return;

        // Remove any <script type="application/ld+json"> not preceded by HackTheSEO comment
        $html = preg_replace_callback(
            '/(?:<!--[^>]*-->\\s*)?<script[^>]*type=["\']application\/ld\+json["\'][^>]*>.*?<\/script>\\s*/si',
            function( $match ) {
                // Keep our own JSON-LD (marked with HackTheSEO comment)
                if ( strpos( $match[0], 'HackTheSEO' ) !== false || strpos( $match[0], 'hack-the-seo' ) !== false ) {
                    return $match[0];
                }
                // Remove competitor JSON-LD
                return '';
            },
            $html
        );

        echo $html;
    }

    /**
     * Debug log — only when WP_DEBUG + WP_DEBUG_LOG are on.
     */
    private function debug_log( $context, $message ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
            hts_debug_log( '[Schema][' . $context . '] ' . $message );
        }
    }

    /**
     * Get the language for a specific post (or blog default for global schemas).
     * Uses HTS_Language for multilingual sites (Polylang, WPML, etc.).
     *
     * @param WP_Post|null $post  Post object, or null for global schemas.
     * @return string  Language in BCP-47 format (e.g. 'fr-FR', 'en-US').
     */
    private function get_post_language( $post = null ) {
        if ( $post && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $lang = HTS_Language::get_post_language( $post->ID );
            if ( $lang ) {
                $locale_map = array(
                    'fr' => 'fr-FR', 'en' => 'en-US', 'es' => 'es-ES',
                    'de' => 'de-DE', 'it' => 'it-IT', 'pt' => 'pt-PT',
                    'nl' => 'nl-NL', 'ja' => 'ja-JP', 'zh' => 'zh-CN',
                    'ar' => 'ar-SA', 'ru' => 'ru-RU', 'ko' => 'ko-KR',
                    'pl' => 'pl-PL', 'sv' => 'sv-SE', 'tr' => 'tr-TR',
                );
                return $locale_map[ $lang ] ?? $lang;
            }
        }
        return get_bloginfo( 'language' );
    }

    /**
     * Get auto-detected schema types toggle settings.
     * Returns assoc array with keys: faq, howto, video, itemlist, speakable — all '1' by default.
     */
    private function get_auto_types() {
        static $types = null;
        if ( null !== $types ) return $types;

        $defaults = array(
            'faq'       => '1',
            'howto'     => '1',
            'video'     => '1',
            'itemlist'  => '1',
            'speakable' => '1',
            // Sprint Robustesse: new auto-detected types
            'recipe'         => '1',
            'event'          => '1',
            'course'         => '1',
            'review'         => '1',
            'localbusiness'  => '1',
            'jobposting'     => '1',
            'software'       => '1',
            'service'        => '1',
            'profilepage'    => '1',
        );
        $types = wp_parse_args( get_option( 'hts_schema_auto_types', array() ), $defaults );
        return $types;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  GLOBAL SCHEMAS — Organization + WebSite
     * ═══════════════════════════════════════════════════════════════ */

    public function inject_global_schemas() {
        if ( is_admin() ) {
            $this->debug_log( 'global', 'Skipped — is_admin()' );
            return;
        }
        static $injected = false;
        if ( $injected ) return;
        $injected = true;

        $schemas = array();
        $org = $this->build_organization();
        if ( $org ) $schemas[] = $org;
        $schemas[] = $this->build_website();

        if ( ! empty( $schemas ) ) {
            echo "\n<!-- HackTheSEO Schema — Global -->\n";
            foreach ( $schemas as $s ) {
                echo '<script type="application/ld+json">';
                echo wp_json_encode( $s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
                echo "</script>\n";
            }
            $this->debug_log( 'global', count( $schemas ) . ' schema(s) injectés' );
        }
    }

    private function build_organization() {
        $name = get_bloginfo( 'name' );
        if ( ! $name ) return null;

        $org = array(
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            '@id'      => home_url( '/#organization' ),
            'name'     => $name,
            'url'      => home_url( '/' ),
        );

        // Logo
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $logo_url  = wp_get_attachment_image_url( $custom_logo_id, 'full' );
            $logo_meta = wp_get_attachment_metadata( $custom_logo_id );
            if ( $logo_url ) {
                $logo = array(
                    '@type' => 'ImageObject', '@id' => home_url( '/#logo' ),
                    'url' => $logo_url, 'contentUrl' => $logo_url, 'caption' => $name,
                );
                if ( $logo_meta && isset( $logo_meta['width'], $logo_meta['height'] ) ) {
                    $logo['width']  = (int) $logo_meta['width'];
                    $logo['height'] = (int) $logo_meta['height'];
                }
                $org['logo']  = $logo;
                $org['image'] = array( '@id' => home_url( '/#logo' ) );
            }
        }

        $desc = get_bloginfo( 'description' );
        if ( $desc ) $org['description'] = $desc;

        $social_urls = $this->get_social_urls();
        if ( ! empty( $social_urls ) ) $org['sameAs'] = $social_urls;

        return $org;
    }

    private function build_website() {
        $schema = array(
            '@context'  => 'https://schema.org',
            '@type'     => 'WebSite',
            '@id'       => home_url( '/#website' ),
            'name'      => get_bloginfo( 'name' ),
            'url'       => home_url( '/' ),
            'publisher' => array( '@id' => home_url( '/#organization' ) ),
        );
        $desc = get_bloginfo( 'description' );
        if ( $desc ) $schema['description'] = $desc;
        $lang = get_bloginfo( 'language' );
        if ( $lang ) $schema['inLanguage'] = $lang;

        $schema['potentialAction'] = array(
            '@type'       => 'SearchAction',
            'target'      => array( '@type' => 'EntryPoint', 'urlTemplate' => home_url( '/?s={search_term_string}' ) ),
            'query-input' => 'required name=search_term_string',
        );
        return $schema;
    }

    private function get_social_urls() {
        $urls = array();

        // HTS custom
        $hts_social = get_option( 'hts_social_profiles', array() );
        if ( is_array( $hts_social ) ) {
            foreach ( $hts_social as $url ) {
                if ( ! empty( $url ) && filter_var( $url, FILTER_VALIDATE_URL ) ) $urls[] = $url;
            }
        }
        // Fallback: Rank Math
        if ( empty( $urls ) ) {
            $rm = get_option( 'rank-math-options-titles', array() );
            foreach ( array( 'social_url_facebook', 'social_url_twitter', 'social_url_linkedin', 'social_url_instagram', 'social_url_youtube', 'social_url_pinterest' ) as $k ) {
                if ( ! empty( $rm[ $k ] ) && filter_var( $rm[ $k ], FILTER_VALIDATE_URL ) ) $urls[] = $rm[ $k ];
            }
        }
        // Fallback: Yoast
        if ( empty( $urls ) ) {
            $ys = get_option( 'wpseo_social', array() );
            foreach ( array( 'facebook_site', 'twitter_site', 'instagram_url', 'linkedin_url', 'youtube_url', 'pinterest_url' ) as $k ) {
                if ( ! empty( $ys[ $k ] ) ) {
                    $val = $ys[ $k ];
                    if ( $k === 'twitter_site' && strpos( $val, 'http' ) === false ) $val = 'https://twitter.com/' . ltrim( $val, '@' );
                    if ( filter_var( $val, FILTER_VALIDATE_URL ) ) $urls[] = $val;
                }
            }
        }
        return array_unique( $urls );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  PAGE SCHEMAS — Article + enrichments
     * ═══════════════════════════════════════════════════════════════ */

    public function inject_page_schemas() {
        if ( is_admin() ) {
            $this->debug_log( 'page', 'Skipped — is_admin()' );
            return;
        }

        if ( is_singular() && class_exists( 'HTS_Meta_Tags' ) && HTS_Meta_Tags::is_wc_system_page() ) return;

        try {
            if ( is_singular( 'post' ) ) {
                $this->debug_log( 'page', 'is_singular(post) → inject_post_schemas()' );
                $this->inject_post_schemas();
                return;
            }
            if ( is_singular( 'page' ) ) {
                $this->debug_log( 'page', 'is_singular(page) → inject_static_page_schemas()' );
                $this->inject_static_page_schemas();
                return;
            }
            // Support custom post types (public, non-builtin)
            if ( is_singular() ) {
                $pt = get_post_type();

                // ── Skip CPTs known to inject their own schema ──
                // These plugins generate their own JSON-LD (Event, Product, etc.)
                /**
                 * Filter: post types to skip for auto schema generation.
                 *
                 * @since 1.4.9
                 * @param array $skip_cpts Post type slugs to skip.
                 */
                $skip_cpts = apply_filters( 'hts_schema_skip_post_types', array(
                    // WooCommerce internals (Product schema handled via auto-detect)
                    'product_variation',    // WooCommerce
                    'shop_order',           // WooCommerce
                    // Plugin internals (not actual content pages)
                    'tribe_venue',          // The Events Calendar venues
                    'tribe_organizer',      // The Events Calendar organizers
                    'give_forms',           // GiveWP
                    'resume',               // WP Job Manager
                    // Note: tribe_events, event, mec-events, job_listing are now
                    // AUTO-DETECTED by HTS — we inject proper schema from plugin data.
                ) );

                if ( in_array( $pt, $skip_cpts, true ) ) {
                    $this->debug_log( 'page', 'Skipping CPT=' . $pt . ' (has own schema)' );
                    return;
                }

                $this->debug_log( 'page', 'is_singular() CPT=' . $pt . ' → inject_post_schemas()' );
                $this->inject_post_schemas();
                return;
            }

            $this->debug_log( 'page', 'Aucune condition remplie — is_singular()=' . ( is_singular() ? 'true' : 'false' ) . ' queried_object=' . get_class( get_queried_object() ?: new stdClass() ) );

            // ═══ Sprint Robustesse: ProfilePage for author archives ═══
            $auto_types = $this->get_auto_types();
            if ( is_author() && ! empty( $auto_types['profilepage'] ) ) {
                $author = get_queried_object();
                if ( $author && $author instanceof \WP_User ) {
                    $schema = array(
                        '@context'    => 'https://schema.org',
                        '@type'       => 'ProfilePage',
                        'name'        => $author->display_name,
                        'url'         => get_author_posts_url( $author->ID ),
                        'description' => get_the_author_meta( 'description', $author->ID ),
                        'mainEntity'  => array(
                            '@type' => 'Person',
                            'name'  => $author->display_name,
                            'url'   => get_author_posts_url( $author->ID ),
                        ),
                    );
                    $avatar = get_avatar_url( $author->ID, array( 'size' => 512 ) );
                    if ( $avatar ) $schema['mainEntity']['image'] = $avatar;
                    $bio = get_the_author_meta( 'description', $author->ID );
                    if ( $bio ) $schema['mainEntity']['description'] = wp_strip_all_tags( $bio );

                    echo "\n<!-- HackTheSEO Schema (ProfilePage) -->\n";
                    echo '<script type="application/ld+json">';
                    echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
                    echo "</script>\n";
                    $this->debug_log( 'page', 'ProfilePage schema for author #' . $author->ID );
                }
            }
        } catch ( \Throwable $e ) {
            $this->debug_log( 'page', 'EXCEPTION: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
        }
    }

    private function inject_post_schemas() {
        global $post;
        if ( ! $post ) {
            $this->debug_log( 'post', 'Skipped — global $post is null' );
            return;
        }

        try {
            $raw_content = $post->post_content; // Raw for inline schema detection
            $content     = HTS_Content_Extractor::get_content( $post->ID ); // Extracted for analysis
            $schemas  = array();
            $detected = array();

        // ═══ SCHEMA PRO: Check manual type override ═══
        $manual_type = get_post_meta( $post->ID, self::META_TYPE, true ) ?: 'auto';
        $pro_data    = get_post_meta( $post->ID, self::META_DATA, true ) ?: array();

        // Detect inline schemas from cocon create_draft (need raw post_content for <script> tags)
        $has_inline_faq     = ( strpos( $raw_content, '"@type":"FAQPage"' ) !== false || strpos( $raw_content, '"@type": "FAQPage"' ) !== false );
        $has_inline_article = ( strpos( $raw_content, 'HackTheSEO Schema Injection' ) !== false && strpos( $raw_content, '"@type":"Article"' ) !== false );

        // ═══ 1. PRIMARY SCHEMA — Manual type OR Article ═══
        if ( $manual_type !== 'auto' && array_key_exists( $manual_type, self::PRO_TYPES ) ) {
            // Manual Schema Pro type selected
            $builder_map = array(
                'Product'       => 'build_product_schema',
                'LocalBusiness' => 'build_local_business_schema',
                'Event'         => 'build_event_schema',
                'Course'        => 'build_course_schema',
                'Recipe'        => 'build_recipe_schema',
                'JobPosting'    => 'build_job_posting_schema',
                'Book'          => 'build_book_schema',
                'Review'        => 'build_review_schema',
                'SoftwareApplication' => 'build_software_schema',
            );
            if ( isset( $builder_map[ $manual_type ] ) ) {
                $method = $builder_map[ $manual_type ];
                $schemas[]  = $this->$method( $post, $pro_data );
                $detected[] = $manual_type;
                $this->debug_log( 'post', 'Schema Pro manual type: ' . $manual_type );
            }
            // Still add Article as secondary schema (for rich snippet coverage)
            if ( ! $has_inline_article ) {
                $schemas[]  = $this->build_article_schema( $post );
                $detected[] = 'Article';
            }
        } elseif ( $post->post_type === 'product' && function_exists( 'wc_get_product' ) ) {
            // ═══ WooCommerce auto-detect: Product schema from WC data ═══
            $wc_data = $this->get_wc_product_data( $post->ID );
            $merged  = array_merge( $wc_data, array_filter( $pro_data ) ); // Manual overrides win
            $schemas[]  = $this->build_product_schema( $post, $merged );
            $detected[] = 'Product';
            $this->debug_log( 'post', 'WooCommerce auto-detect Product schema for #' . $post->ID );
        } elseif ( ! $has_inline_article ) {
            // Auto mode: Article as primary
            $schemas[]  = $this->build_article_schema( $post );
            $detected[] = 'Article';
        }

        // ═══ 2. FAQPage ═══
        $auto_types = $this->get_auto_types();
        if ( ! empty( $auto_types['faq'] ) && ! $has_inline_faq ) {
            $faq = $this->detect_faq( $content );
            if ( ! empty( $faq ) ) {
                $schemas[]  = $this->build_faq_schema( $faq );
                $detected[] = 'FAQPage';
            }
        }

        // ═══ 3. HowTo ═══
        if ( ! empty( $auto_types['howto'] ) ) {
        $howto = $this->detect_howto( $content, $post );
        if ( ! empty( $howto ) ) {
            $schemas[]  = $this->build_howto_schema( $howto, $post );
            $detected[] = 'HowTo';
        }
        }

        // ═══ 4. VideoObject ═══
        if ( ! empty( $auto_types['video'] ) ) {
        $videos = $this->detect_videos( $content );
        if ( ! empty( $videos ) ) {
            foreach ( $videos as $v ) $schemas[] = $this->build_video_schema( $v, $post );
            $detected[] = 'VideoObject';
        }
        }

        // ═══ 5. ItemList ═══
        if ( ! empty( $auto_types['itemlist'] ) ) {
        $items = $this->detect_itemlist( $content, $post );
        if ( ! empty( $items ) ) {
            $schemas[]  = $this->build_itemlist_schema( $items, $post );
            $detected[] = 'ItemList';
        }
        }

        // ═══ 6. Speakable — merged into existing WebPage schema ═══
        if ( ! empty( $auto_types['speakable'] ) && ! $has_inline_article ) {
            // Find existing WebPage schema and add speakable to it
            $speakable_merged = false;
            foreach ( $schemas as &$s ) {
                if ( isset( $s['@type'] ) && $s['@type'] === 'WebPage' ) {
                    $s['speakable'] = array(
                        '@type' => 'SpeakableSpecification',
                        'cssSelector' => array( 'h1', '.entry-content p:first-of-type', '.post-content p:first-of-type', 'article p:first-of-type' ),
                    );
                    $speakable_merged = true;
                    break;
                }
            }
            unset( $s );
            if ( ! $speakable_merged ) {
                // No WebPage schema yet — add speakable as standalone (fallback)
                $schemas[] = $this->build_speakable_schema( $post );
            }
            $detected[] = 'Speakable';
        }

        // ═══════════════════════════════════════════════════════════════
        //  SPRINT ROBUSTESSE — AUTO-DETECTION OF PRO TYPES
        //  Only when manual_type = 'auto' (don't override explicit choice)
        // ═══════════════════════════════════════════════════════════════
        if ( $manual_type === 'auto' ) {

            // ═══ 7. Recipe — plugins + content patterns ═══
            if ( ! empty( $auto_types['recipe'] ) && ! in_array( 'Recipe', $detected, true ) ) {
                $recipe_data = $this->detect_recipe( $post, $content );
                if ( $recipe_data ) {
                    $schemas[]  = $this->build_recipe_schema( $post, $recipe_data );
                    $detected[] = 'Recipe';
                }
            }

            // ═══ 8. Event — plugins + future dates ═══
            if ( ! empty( $auto_types['event'] ) && ! in_array( 'Event', $detected, true ) ) {
                $event_data = $this->detect_event( $post, $content );
                if ( $event_data ) {
                    $schemas[]  = $this->build_event_schema( $post, $event_data );
                    $detected[] = 'Event';
                }
            }

            // ═══ 9. Course — LMS plugins + content patterns ═══
            if ( ! empty( $auto_types['course'] ) && ! in_array( 'Course', $detected, true ) ) {
                $course_data = $this->detect_course( $post, $content );
                if ( $course_data ) {
                    $schemas[]  = $this->build_course_schema( $post, $course_data );
                    $detected[] = 'Course';
                }
            }

            // ═══ 10. Review — rating patterns in content ═══
            if ( ! empty( $auto_types['review'] ) && ! in_array( 'Review', $detected, true ) ) {
                $review_data = $this->detect_review( $post, $content );
                if ( $review_data ) {
                    $schemas[]  = $this->build_review_schema( $post, $review_data );
                    $detected[] = 'Review';
                }
            }

            // ═══ 11. LocalBusiness — contact/about pages with address+phone ═══
            if ( ! empty( $auto_types['localbusiness'] ) && ! in_array( 'LocalBusiness', $detected, true ) ) {
                if ( $post->post_type === 'page' && $this->detect_local_business_page( $post, $content ) ) {
                    $schemas[]  = $this->build_local_business_schema( $post, $pro_data );
                    $detected[] = 'LocalBusiness';
                }
            }

            // ═══ 12. JobPosting — job manager plugins ═══
            if ( ! empty( $auto_types['jobposting'] ) && ! in_array( 'JobPosting', $detected, true ) ) {
                $job_data = $this->detect_job_posting( $post, $content );
                if ( $job_data ) {
                    $schemas[]  = $this->build_job_posting_schema( $post, $job_data );
                    $detected[] = 'JobPosting';
                }
            }

            // ═══ 13. SoftwareApplication — download/app pages ═══
            if ( ! empty( $auto_types['software'] ) && ! in_array( 'SoftwareApplication', $detected, true ) ) {
                $sw_data = $this->detect_software( $post, $content );
                if ( $sw_data ) {
                    $schemas[]  = $this->build_software_schema( $post, $sw_data );
                    $detected[] = 'SoftwareApplication';
                }
            }

        } // end manual_type === 'auto'

        // Save + inject (only write if changed to avoid DB writes on every page view)
        $old = get_post_meta( $post->ID, '_hts_schemas_detected', true );
        if ( $old !== $detected ) {
            update_post_meta( $post->ID, '_hts_schemas_detected', $detected );
        }
        $old_count = (int) get_post_meta( $post->ID, '_hts_schemas_count', true );
        if ( $old_count !== count( $schemas ) ) {
            update_post_meta( $post->ID, '_hts_schemas_count', count( $schemas ) );
        }

        if ( ! empty( $schemas ) ) {
            echo "\n<!-- HackTheSEO Schema (" . count( $schemas ) . " : " . esc_html( implode( ', ', $detected ) ) . ") -->\n";
            foreach ( array_filter( $schemas ) as $s ) {
                echo '<script type="application/ld+json">';
                echo wp_json_encode( $s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
                echo "</script>\n";
            }
            $this->debug_log( 'post', 'Post #' . $post->ID . ' — ' . count( $schemas ) . ' schema(s) : ' . implode( ', ', $detected ) );
        } else {
            $this->debug_log( 'post', 'Post #' . $post->ID . ' — aucun schema généré (inline_article=' . ( $has_inline_article ? 'Y' : 'N' ) . ', inline_faq=' . ( $has_inline_faq ? 'Y' : 'N' ) . ')' );
        }

        } catch ( \Throwable $e ) {
            $this->debug_log( 'post', 'EXCEPTION post #' . ( $post->ID ?? '?' ) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            // Fallback: at minimum output an Article schema comment so Health Check can trace
            echo "\n<!-- HackTheSEO Schema (ERROR: " . esc_html( $e->getMessage() ) . ") -->\n";
        }
    }

    private function inject_static_page_schemas() {
        global $post;
        if ( ! $post ) return;

        $schemas  = array();
        $detected = array();

        // ═══ SCHEMA PRO: Check manual type override ═══
        $manual_type = get_post_meta( $post->ID, self::META_TYPE, true ) ?: 'auto';
        $pro_data    = get_post_meta( $post->ID, self::META_DATA, true ) ?: array();

        if ( $manual_type !== 'auto' && array_key_exists( $manual_type, self::PRO_TYPES ) ) {
            $builder_map = array(
                'Product'       => 'build_product_schema',
                'LocalBusiness' => 'build_local_business_schema',
                'Event'         => 'build_event_schema',
                'Course'        => 'build_course_schema',
                'Recipe'        => 'build_recipe_schema',
                'JobPosting'    => 'build_job_posting_schema',
                'Book'          => 'build_book_schema',
                'Review'        => 'build_review_schema',
                'SoftwareApplication' => 'build_software_schema',
            );
            if ( isset( $builder_map[ $manual_type ] ) ) {
                $method = $builder_map[ $manual_type ];
                $schemas[]  = $this->$method( $post, $pro_data );
                $detected[] = $manual_type;
            }
        }

        $webpage_schema = $this->build_webpage_schema( $post );

        $auto_types = $this->get_auto_types();

        if ( ! empty( $auto_types['speakable'] ) ) {
            $webpage_schema['speakable'] = array(
                '@type' => 'SpeakableSpecification',
                'cssSelector' => array( 'h1', '.entry-content p:first-of-type', '.post-content p:first-of-type', 'article p:first-of-type' ),
            );
            $detected[] = 'Speakable';
        }

        $schemas[]  = $webpage_schema;
        $detected[] = 'WebPage';

        // Sprint Robustesse: full auto-detection chain on pages (same as posts)
        $content = HTS_Content_Extractor::get_content( $post->ID );

        // FAQPage
        if ( ! empty( $auto_types['faq'] ) ) {
            $faq = $this->detect_faq( $content );
            if ( ! empty( $faq ) ) {
                $schemas[]  = $this->build_faq_schema( $faq );
                $detected[] = 'FAQPage';
            }
        }

        // HowTo
        if ( ! empty( $auto_types['howto'] ) ) {
            $howto = $this->detect_howto( $content, $post );
            if ( ! empty( $howto ) ) {
                $schemas[]  = $this->build_howto_schema( $howto, $post );
                $detected[] = 'HowTo';
            }
        }

        // VideoObject
        if ( ! empty( $auto_types['video'] ) ) {
            $videos = $this->detect_videos( $content );
            if ( ! empty( $videos ) ) {
                foreach ( $videos as $v ) $schemas[] = $this->build_video_schema( $v, $post );
                $detected[] = 'VideoObject';
            }
        }

        // ItemList
        if ( ! empty( $auto_types['itemlist'] ) ) {
            $items = $this->detect_itemlist( $content, $post );
            if ( ! empty( $items ) ) {
                $schemas[]  = $this->build_itemlist_schema( $items, $post );
                $detected[] = 'ItemList';
            }
        }

        // Auto-detection of Pro types (only when manual_type = 'auto')
        if ( $manual_type === 'auto' ) {

            // Recipe
            if ( ! empty( $auto_types['recipe'] ) && ! in_array( 'Recipe', $detected, true ) ) {
                $recipe_data = $this->detect_recipe( $post, $content );
                if ( $recipe_data ) {
                    $schemas[]  = $this->build_recipe_schema( $post, $recipe_data );
                    $detected[] = 'Recipe';
                }
            }

            // Event
            if ( ! empty( $auto_types['event'] ) && ! in_array( 'Event', $detected, true ) ) {
                $event_data = $this->detect_event( $post, $content );
                if ( $event_data ) {
                    $schemas[]  = $this->build_event_schema( $post, $event_data );
                    $detected[] = 'Event';
                }
            }

            // Course
            if ( ! empty( $auto_types['course'] ) && ! in_array( 'Course', $detected, true ) ) {
                $course_data = $this->detect_course( $post, $content );
                if ( $course_data ) {
                    $schemas[]  = $this->build_course_schema( $post, $course_data );
                    $detected[] = 'Course';
                }
            }

            // Review
            if ( ! empty( $auto_types['review'] ) && ! in_array( 'Review', $detected, true ) ) {
                $review_data = $this->detect_review( $post, $content );
                if ( $review_data ) {
                    $schemas[]  = $this->build_review_schema( $post, $review_data );
                    $detected[] = 'Review';
                }
            }

            // LocalBusiness (pages only — already ensured by being in inject_static_page_schemas)
            if ( ! empty( $auto_types['localbusiness'] ) && ! in_array( 'LocalBusiness', $detected, true ) ) {
                if ( $this->detect_local_business_page( $post, $content ) ) {
                    $schemas[]  = $this->build_local_business_schema( $post, $pro_data );
                    $detected[] = 'LocalBusiness';
                }
            }

            // JobPosting
            if ( ! empty( $auto_types['jobposting'] ) && ! in_array( 'JobPosting', $detected, true ) ) {
                $job_data = $this->detect_job_posting( $post, $content );
                if ( $job_data ) {
                    $schemas[]  = $this->build_job_posting_schema( $post, $job_data );
                    $detected[] = 'JobPosting';
                }
            }

            // SoftwareApplication
            if ( ! empty( $auto_types['software'] ) && ! in_array( 'SoftwareApplication', $detected, true ) ) {
                $sw_data = $this->detect_software( $post, $content );
                if ( $sw_data ) {
                    $schemas[]  = $this->build_software_schema( $post, $sw_data );
                    $detected[] = 'SoftwareApplication';
                }
            }

        } // end manual_type === 'auto'

        // Save + inject (only write if changed to avoid DB writes on every page view)
        $old = get_post_meta( $post->ID, '_hts_schemas_detected', true );
        if ( $old !== $detected ) {
            update_post_meta( $post->ID, '_hts_schemas_detected', $detected );
        }
        $old_count = (int) get_post_meta( $post->ID, '_hts_schemas_count', true );
        if ( $old_count !== count( $schemas ) ) {
            update_post_meta( $post->ID, '_hts_schemas_count', count( $schemas ) );
        }

        echo "\n<!-- HackTheSEO Schema (" . count( $schemas ) . " : " . esc_html( implode( ', ', $detected ) ) . ") -->\n";
        foreach ( array_filter( $schemas ) as $s ) {
            echo '<script type="application/ld+json">';
            echo wp_json_encode( $s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
            echo "</script>\n";
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  BUILD — Article / BlogPosting (COMPLETE)
     * ═══════════════════════════════════════════════════════════════ */

    private function build_article_schema( $post ) {
        $schema = array(
            '@context'         => 'https://schema.org',
            '@type'            => 'Article',
            '@id'              => get_permalink( $post ) . '#article',
            'headline'         => get_the_title( $post ),
            'url'              => get_permalink( $post ),
            'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => get_permalink( $post ) ),
            'datePublished'    => get_the_date( 'c', $post ),
            'dateModified'     => get_the_modified_date( 'c', $post ),
            'isPartOf'         => array( '@id' => home_url( '/#website' ) ),
        );

        // ── Author ──
        $author = get_userdata( $post->post_author );
        if ( $author ) {
            $a = array( '@type' => 'Person', 'name' => $author->display_name, 'url' => get_author_posts_url( $author->ID ) );
            $bio = get_the_author_meta( 'description', $author->ID );
            if ( $bio ) $a['description'] = wp_strip_all_tags( $bio );
            $avatar = get_avatar_url( $author->ID, array( 'size' => 96 ) );
            if ( $avatar ) $a['image'] = $avatar;
            $schema['author'] = $a;
        }

        // ── Publisher ──
        $schema['publisher'] = array( '@id' => home_url( '/#organization' ) );

        // ── Image ──
        if ( has_post_thumbnail( $post->ID ) ) {
            $img_id   = get_post_thumbnail_id( $post->ID );
            $img_url  = wp_get_attachment_image_url( $img_id, 'full' );
            $img_meta = wp_get_attachment_metadata( $img_id );
            if ( $img_url ) {
                $image = array( '@type' => 'ImageObject', 'url' => $img_url );
                if ( $img_meta && isset( $img_meta['width'], $img_meta['height'] ) ) {
                    $image['width']  = (int) $img_meta['width'];
                    $image['height'] = (int) $img_meta['height'];
                }
                $schema['image']        = $image;
                $schema['thumbnailUrl'] = $img_url;
            }
        }

        // ── Description ──
        $desc = get_the_excerpt( $post );
        if ( ! $desc ) $desc = wp_trim_words( wp_strip_all_tags( HTS_Content_Extractor::get_content( $post->ID ) ), 30, '…' );
        if ( $desc ) $schema['description'] = $desc;

        // ── Word count ──
        $wc = hts_word_count( wp_strip_all_tags( HTS_Content_Extractor::get_content( $post->ID ) ) );
        if ( $wc > 0 ) $schema['wordCount'] = $wc;

        // ── Language ──
        $lang = $this->get_post_language( $post );
        if ( $lang ) $schema['inLanguage'] = $lang;

        // ── Categories ──
        $cats = get_the_category( $post->ID );
        if ( ! empty( $cats ) ) $schema['articleSection'] = wp_list_pluck( $cats, 'name' );

        // ── Focus keyword (HTS → RM → Yoast → API) ──
        $kw = get_post_meta( $post->ID, '_hts_focus_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post->ID, 'rank_math_focus_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true );
        if ( ! $kw ) $kw = get_post_meta( $post->ID, '_hts_api_keyword', true );
        if ( $kw ) $schema['keywords'] = $kw;

        // ── Tags as fallback keywords ──
        if ( ! $kw ) {
            $tags = get_the_tags( $post->ID );
            if ( ! empty( $tags ) ) $schema['keywords'] = implode( ', ', wp_list_pluck( $tags, 'name' ) );
        }

        // ── Cocon enrichments (about, mentions) ──
        $enrichments = get_post_meta( $post->ID, '_hts_schema_enrichments', true );
        if ( is_array( $enrichments ) ) {
            if ( ! empty( $enrichments['about'] ) )    $schema['about']    = $enrichments['about'];
            if ( ! empty( $enrichments['mentions'] ) ) $schema['mentions'] = $enrichments['mentions'];
        }

        // ── Comments ──
        $comments = (int) get_comments_number( $post->ID );
        if ( $comments > 0 ) $schema['commentCount'] = $comments;

        return $schema;
    }

    private function build_webpage_schema( $post ) {
        $schema = array(
            '@context'      => 'https://schema.org',
            '@type'         => 'WebPage',
            '@id'           => get_permalink( $post ) . '#webpage',
            'name'          => get_the_title( $post ),
            'url'           => get_permalink( $post ),
            'datePublished' => get_the_date( 'c', $post ),
            'dateModified'  => get_the_modified_date( 'c', $post ),
            'isPartOf'      => array( '@id' => home_url( '/#website' ) ),
        );
        $desc = get_the_excerpt( $post );
        if ( $desc ) $schema['description'] = $desc;
        if ( has_post_thumbnail( $post->ID ) ) $schema['thumbnailUrl'] = get_the_post_thumbnail_url( $post->ID, 'full' );
        $lang = $this->get_post_language( $post );
        if ( $lang ) $schema['inLanguage'] = $lang;
        return $schema;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  DETECTION — FAQ
     * ═══════════════════════════════════════════════════════════════ */

    private function detect_faq( $content ) {
        $faqs = array();

        // Méthode 1 : H3+ avec "?"
        $pattern = '/<h([2-6])[^>]*>(.*?\?)\s*<\/h\1>(.*?)(?=<h[2-6]|$)/si';
        if ( preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $m ) {
                $lvl = (int) $m[1]; $q = wp_strip_all_tags( $m[2] ); $raw = $m[3];
                $a = trim( wp_strip_all_tags( $raw ) );
                if ( preg_match( '/<h[2-6][^>]*>/i', $raw ) ) continue;
                if ( mb_strlen( $a ) < 50 || mb_strlen( $a ) > 600 ) continue;
                if ( mb_strpos( $a, '.' ) === false ) continue;
                if ( preg_match( '/<(img|figure|iframe)/i', $raw ) ) continue;
                $after = mb_strpos( $content, $raw ) + mb_strlen( $raw );
                if ( $after < mb_strlen( $content ) ) {
                    $next = mb_substr( $content, $after, 200 );
                    if ( preg_match( '/^\s*<h([2-6])/i', $next, $nh ) && (int) $nh[1] > $lvl ) continue;
                }
                if ( $lvl <= 2 ) continue;
                if ( mb_strlen( $a ) > 300 ) $a = mb_substr( $a, 0, 297 ) . '...';
                $faqs[] = array( 'question' => $q, 'answer' => $a );
            }
        }

        // Méthode 2 : Yoast FAQ block
        if ( preg_match_all( '/<!-- wp:yoast\/faq-block.*?-->(.*?)<!-- \/wp:yoast\/faq-block -->/si', $content, $yf ) ) {
            foreach ( $yf[1] as $block ) {
                if ( preg_match_all( '/<div class="schema-faq-question">(.*?)<\/div>.*?<div class="schema-faq-answer">(.*?)<\/div>/si', $block, $qas, PREG_SET_ORDER ) ) {
                    foreach ( $qas as $qa ) $faqs[] = array( 'question' => wp_strip_all_tags( $qa[1] ), 'answer' => wp_strip_all_tags( $qa[2] ) );
                }
            }
        }

        // Méthode 3 : <details><summary> — only if summary looks like a question
        if ( preg_match_all( '/<details[^>]*>\s*<summary[^>]*>(.*?)<\/summary>(.*?)<\/details>/si', $content, $dm, PREG_SET_ORDER ) ) {
            foreach ( $dm as $d ) {
                $q = html_entity_decode( trim( wp_strip_all_tags( $d[1] ) ), ENT_QUOTES, 'UTF-8' );
                $a = html_entity_decode( trim( wp_strip_all_tags( $d[2] ) ), ENT_QUOTES, 'UTF-8' );
                if ( mb_strlen( $q ) < 5 || mb_strlen( $a ) < 20 ) continue;
                // Must look like a question: ends with "?" OR starts with question word
                $is_question = ( mb_substr( trim( $q ), -1 ) === '?' )
                    || preg_match( '/^(comment|pourquoi|quand|combien|quel|quelle|quels|quelles|où|est-ce|peut-on|faut-il|how|what|when|where|why|which|can|do|does|is|are|should|wie|was|wann|wo|warum|welche|welcher|welches|kann|cómo|qué|cuándo|dónde|por\s?qué|cuál|cuáles|come|cosa|quando|dove|perché|quale|quali|como|quando|onde|por\s?que|qual|quais|hoe|wat|wanneer|waar|waarom|welke)/ui', $q );
                if ( ! $is_question ) continue;
                if ( mb_strlen( $a ) > 300 ) $a = mb_substr( $a, 0, 297 ) . '...';
                $faqs[] = array( 'question' => $q, 'answer' => $a );
            }
        }

        // Méthode 4 : Rank Math FAQ block
        if ( preg_match_all( '/<!-- wp:rank-math\/faq-block.*?-->(.*?)<!-- \/wp:rank-math\/faq-block -->/si', $content, $rf ) ) {
            foreach ( $rf[1] as $block ) {
                if ( preg_match_all( '/<div class="rank-math-faq-item"[^>]*>.*?<h[2-6][^>]*class="[^"]*faq-question[^"]*"[^>]*>(.*?)<\/h[2-6]>.*?<div class="[^"]*faq-answer[^"]*"[^>]*>(.*?)<\/div>/si', $block, $rqas, PREG_SET_ORDER ) ) {
                    foreach ( $rqas as $qa ) $faqs[] = array( 'question' => wp_strip_all_tags( $qa[1] ), 'answer' => wp_strip_all_tags( $qa[2] ) );
                }
            }
        }

        // Méthode 5 : Builder-agnostic — text Q&A after a "FAQ" heading
        // Catches Elementor addons, Brizy, Breakdance, etc. where accordion
        // outputs as plain text without <details> or structured HTML.
        if ( empty( $faqs ) ) {
            // Find the FAQ section (everything after a heading containing "FAQ" / "Questions")
            $faq_heading_pattern = '/<h[2-4][^>]*>[^<]*(faq|frequently\s+asked|questions?\s+fr[ée]quentes?|fragen|preguntas\s+frecuentes|domande\s+frequenti|perguntas\s+frequentes)[^<]*<\/h[2-4]>/iu';
            if ( preg_match( $faq_heading_pattern, $content, $faq_hm, PREG_OFFSET_CAPTURE ) ) {
                $faq_section = mb_substr( $content, $faq_hm[0][1] );

                // Extract Q&A pairs: any sentence ending with "?" followed by non-question text
                $plain = wp_strip_all_tags( $faq_section );
                // Split into lines/sentences
                $lines = preg_split( '/[\n\r]+/', $plain, -1, PREG_SPLIT_NO_EMPTY );
                $lines = array_map( 'trim', $lines );
                $lines = array_filter( $lines, function( $l ) { return mb_strlen( $l ) > 5; } );
                $lines = array_values( $lines );

                for ( $i = 0; $i < count( $lines ); $i++ ) {
                    $line = trim( $lines[ $i ] );
                    // Is this a question?
                    if ( mb_substr( $line, -1 ) === '?' && mb_strlen( $line ) >= 15 ) {
                        // Next line(s) = answer (concatenate until next question or end)
                        $answer_parts = array();
                        for ( $j = $i + 1; $j < count( $lines ); $j++ ) {
                            $next = trim( $lines[ $j ] );
                            if ( mb_substr( $next, -1 ) === '?' && mb_strlen( $next ) >= 15 ) break;
                            if ( mb_strlen( $next ) > 10 ) $answer_parts[] = $next;
                        }
                        $answer = implode( ' ', $answer_parts );
                        if ( mb_strlen( $answer ) >= 50 && mb_strlen( $answer ) <= 2000 ) {
                            if ( mb_strlen( $answer ) > 300 ) $answer = mb_substr( $answer, 0, 297 ) . '...';
                            $faqs[] = array( 'question' => $line, 'answer' => $answer );
                        }
                        $i = $j - 1; // Skip to next question
                    }
                }
            }
        }

        // Dedup
        $seen = array(); $unique = array();
        foreach ( $faqs as $f ) {
            $k = md5( $f['question'] );
            if ( isset( $seen[ $k ] ) ) continue;
            $seen[ $k ] = true; $unique[] = $f;
        }
        return count( $unique ) >= 2 ? array_slice( $unique, 0, 10 ) : array();
    }

    private function build_faq_schema( $faqs ) {
        $entities = array();
        foreach ( $faqs as $f ) {
            $entities[] = array( '@type' => 'Question', 'name' => $f['question'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['answer'] ) );
        }
        return array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $entities );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  DETECTION — HowTo
     * ═══════════════════════════════════════════════════════════════ */

    private function detect_howto( $content, $post ) {
        $steps = array();
        $pattern = '/<h[23][^>]*>\s*(?:(?:[eé]tape|step|schritt|paso|passo|stap|steg)\s*(\d+)\s*[:.\-—]?\s*(.*?)|((\d+)[.)]\s*(.*?)))\s*<\/h[23]>(.*?)(?=<h[23]|$)/si';
        if ( preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $m ) {
                $title = wp_strip_all_tags( ! empty( $m[2] ) ? $m[2] : ( $m[5] ?? '' ) );
                $desc  = trim( mb_substr( wp_strip_all_tags( $m[6] ?? '' ), 0, 250 ) );
                if ( empty( $title ) || mb_strlen( $title ) < 3 ) continue;
                $steps[] = array( 'name' => trim( $title ), 'text' => $desc );
            }
        }
        if ( empty( $steps ) && preg_match( '/<ol[^>]*>(.*?)<\/ol>/si', $content, $ol ) ) {
            if ( preg_match_all( '/<li[^>]*>(.*?)<\/li>/si', $ol[1], $lis ) && count( $lis[1] ) >= 3 ) {
                foreach ( $lis[1] as $li ) {
                    $t = wp_strip_all_tags( $li );
                    if ( mb_strlen( $t ) < 10 ) continue;
                    $steps[] = array( 'name' => mb_substr( $t, 0, 80 ), 'text' => $t );
                }
            }
        }
        return count( $steps ) >= 3 ? array_slice( $steps, 0, 15 ) : array();
    }

    private function build_howto_schema( $steps, $post ) {
        $items = array();
        foreach ( $steps as $i => $s ) {
            $items[] = array( '@type' => 'HowToStep', 'position' => $i + 1, 'name' => $s['name'], 'text' => $s['text'] ?: $s['name'] );
        }
        $schema = array( '@context' => 'https://schema.org', '@type' => 'HowTo', 'name' => get_the_title( $post ), 'step' => $items );
        $ex = get_the_excerpt( $post );
        if ( $ex ) $schema['description'] = wp_strip_all_tags( $ex );
        if ( has_post_thumbnail( $post ) ) {
            $img = wp_get_attachment_image_url( get_post_thumbnail_id( $post ), 'full' );
            if ( $img ) $schema['image'] = $img;
        }
        return $schema;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  DETECTION — VideoObject
     * ═══════════════════════════════════════════════════════════════ */

    private function detect_videos( $content ) {
        $videos = array();
        foreach ( array( '/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i', '/<!-- wp:embed.*?youtube.*?-->\s*<figure[^>]*>.*?(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/si' ) as $p ) {
            if ( preg_match_all( $p, $content, $m ) ) {
                foreach ( $m[1] as $vid ) {
                    $videos[] = array( 'platform' => 'youtube', 'id' => $vid, 'url' => 'https://www.youtube.com/watch?v=' . $vid, 'embed' => 'https://www.youtube.com/embed/' . $vid, 'thumb' => 'https://img.youtube.com/vi/' . $vid . '/maxresdefault.jpg' );
                }
            }
        }
        if ( preg_match_all( '/vimeo\.com\/(\d+)/i', $content, $vm ) ) {
            foreach ( $vm[1] as $vid ) {
                $videos[] = array( 'platform' => 'vimeo', 'id' => $vid, 'url' => 'https://vimeo.com/' . $vid, 'embed' => 'https://player.vimeo.com/video/' . $vid, 'thumb' => '' );
            }
        }
        $seen = array(); $unique = array();
        foreach ( $videos as $v ) { if ( isset( $seen[ $v['id'] ] ) ) continue; $seen[ $v['id'] ] = true; $unique[] = $v; }
        return array_slice( $unique, 0, 3 );
    }

    private function build_video_schema( $video, $post ) {
        $s = array( '@context' => 'https://schema.org', '@type' => 'VideoObject', 'name' => get_the_title( $post ), 'contentUrl' => $video['url'], 'embedUrl' => $video['embed'], 'uploadDate' => get_the_date( 'c', $post ) );
        $ex = get_the_excerpt( $post );
        $s['description'] = $ex ? wp_strip_all_tags( mb_substr( $ex, 0, 250 ) ) : get_the_title( $post );
        if ( ! empty( $video['thumb'] ) ) $s['thumbnailUrl'] = $video['thumb'];
        elseif ( has_post_thumbnail( $post ) ) $s['thumbnailUrl'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post ), 'full' );
        return $s;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  DETECTION — ItemList
     * ═══════════════════════════════════════════════════════════════ */

    private function detect_itemlist( $content, $post ) {
        $title = get_the_title( $post );
        if ( ! preg_match( '/\b(\d+)\s*(meilleur|best|top|conseil|astuce|tip|raison|reason|façon|way|outil|tool|étape|step|erreur|error|avantage|benefit|idée|idea|exemple|example|film|livre|book)/ui', $title ) ) return array();
        $items = array();
        if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $content, $h2s ) ) {
            foreach ( $h2s[1] as $h2 ) {
                $t = wp_strip_all_tags( $h2 );
                if ( mb_strlen( $t ) < 5 ) continue;
                if ( preg_match( '/^(faq|conclusion|sources?|références?|sommaire|table des|en résumé|pour aller)/ui', $t ) ) continue;
                $items[] = $t;
            }
        }
        return count( $items ) >= 3 ? array_slice( $items, 0, 20 ) : array();
    }

    private function build_itemlist_schema( $items, $post ) {
        $els = array();
        foreach ( $items as $i => $name ) $els[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $name );
        return array( '@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => get_the_title( $post ), 'numberOfItems' => count( $els ), 'itemListElement' => $els );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SPEAKABLE
     * ═══════════════════════════════════════════════════════════════ */

    private function build_speakable_schema( $post ) {
        return array(
            '@context' => 'https://schema.org', '@type' => 'WebPage',
            'name' => get_the_title( $post ), 'url' => get_permalink( $post ),
            'speakable' => array( '@type' => 'SpeakableSpecification', 'cssSelector' => array( 'h1', '.entry-content p:first-of-type', '.post-content p:first-of-type', 'article p:first-of-type' ) ),
        );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  AUTO-DETECTION — Sprint Robustesse
     *
     *  Conservative detection: better to miss than to generate wrong schema.
     *  Each function returns array (data for build_*) or false.
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Detect Recipe from:
     * - WP Recipe Maker plugin (wprm_recipe post type or shortcode)
     * - Tasty Recipes shortcode
     * - Content patterns: ingredients list + cooking instructions
     */
    private function detect_recipe( $post, $content ) {
        $raw = $post->post_content;

        // Plugin: WP Recipe Maker
        if ( strpos( $raw, '[wprm-recipe' ) !== false || $post->post_type === 'wprm_recipe' ) {
            return array(); // build_recipe_schema uses title + HowTo detection internally
        }

        // Plugin: Tasty Recipes
        if ( strpos( $raw, '[tasty-recipe' ) !== false ) {
            return array();
        }

        // Content-based: need at least 2 of 3 signals (ingredients, time, cooking verbs)
        $lower = mb_strtolower( $content );
        $signals = 0;

        // Signal 1: ingredient-like list (bullet points with quantities)
        if ( preg_match( '/(\d+\s*(g|ml|cl|kg|l|cuillère|tasse|cup|oz|lb|pincée|pinch))/iu', $content ) ) $signals++;
        if ( preg_match( '/(ingr[ée]dients?|ingredients?)/iu', $content ) ) $signals++;

        // Signal 2: time patterns
        if ( preg_match( '/(pr[ée]paration|pr[ée]p\.?|prep[\s:]|cuisson|cooking|baking)\s*:?\s*\d+\s*(min|h|hour|minute)/iu', $content ) ) $signals++;

        // Signal 3: cooking/recipe verbs in title or content
        $recipe_words = array( 'recette', 'recipe', 'ricetta', 'rezept', 'receta', 'cuisson', 'cooking', 'baking', 'four', 'oven', 'pâte', 'dough' );
        $title_lower = mb_strtolower( $post->post_title );
        foreach ( $recipe_words as $w ) {
            if ( mb_strpos( $title_lower, $w ) !== false || mb_strpos( $lower, $w ) !== false ) { $signals++; break; }
        }

        if ( $signals < 2 ) return false;

        // Extract prep/cook time if possible
        $data = array();
        if ( preg_match( '/(pr[ée]p(?:aration)?\.?\s*:?\s*)(\d+)\s*(min|h)/iu', $content, $tm ) ) {
            $data['recipe_prep_time'] = $tm[3] === 'h' ? (int) $tm[2] * 60 : (int) $tm[2];
        }
        if ( preg_match( '/(cuisson|cooking|baking)\s*:?\s*(\d+)\s*(min|h)/iu', $content, $tm ) ) {
            $data['recipe_cook_time'] = $tm[3] === 'h' ? (int) $tm[2] * 60 : (int) $tm[2];
        }

        return $data;
    }

    /**
     * Detect Event from:
     * - The Events Calendar plugin (tribe_events post type)
     * - Events Manager, Modern Events Calendar
     * - Content with future date + location patterns
     */
    private function detect_event( $post, $content ) {
        // Plugin: The Events Calendar
        if ( $post->post_type === 'tribe_events' ) {
            $data = array();
            $start = get_post_meta( $post->ID, '_EventStartDate', true );
            $end   = get_post_meta( $post->ID, '_EventEndDate', true );
            if ( $start ) $data['event_start'] = $start;
            if ( $end )   $data['event_end']   = $end;
            $venue_id = get_post_meta( $post->ID, '_EventVenueID', true );
            if ( $venue_id ) {
                $data['event_location'] = get_the_title( $venue_id );
                $data['event_address']  = get_post_meta( $venue_id, '_VenueAddress', true );
            }
            $cost = get_post_meta( $post->ID, '_EventCost', true );
            if ( $cost !== '' && $cost !== false ) $data['event_price'] = $cost;
            return $data;
        }

        // Plugin: Events Manager
        if ( $post->post_type === 'event' ) {
            $data = array();
            $start = get_post_meta( $post->ID, '_event_start_date', true );
            if ( $start ) $data['event_start'] = $start;
            $end = get_post_meta( $post->ID, '_event_end_date', true );
            if ( $end ) $data['event_end'] = $end;
            return $data;
        }

        // Plugin: Modern Events Calendar
        if ( $post->post_type === 'mec-events' ) {
            $data = array();
            $mec_start = get_post_meta( $post->ID, 'mec_start_date', true );
            if ( $mec_start ) $data['event_start'] = $mec_start;
            return $data;
        }

        // Content-based: need future date + event signals
        $lower = mb_strtolower( $content );
        $event_words = array( 'inscription', 'registration', 'anmeldung', 'inscripción', 'réservation', 'booking', 'événement', 'event', 'conférence', 'conference', 'webinaire', 'webinar', 'atelier', 'workshop', 'salon', 'séminaire', 'seminar' );
        $has_event_word = false;
        foreach ( $event_words as $w ) {
            if ( mb_strpos( $lower, $w ) !== false ) { $has_event_word = true; break; }
        }
        if ( ! $has_event_word ) return false;

        // Look for a future date in content
        if ( preg_match( '/(\d{1,2})\s*(janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre|january|february|march|april|may|june|july|august|september|october|november|december)\s*(\d{4})/iu', $content, $dm ) ) {
            $date_str = $dm[1] . ' ' . $dm[2] . ' ' . $dm[3];
            $ts = strtotime( $date_str );
            if ( $ts && $ts > time() ) {
                return array( 'event_start' => wp_date( 'Y-m-d', $ts ) );
            }
        }

        return false;
    }

    /**
     * Detect Course from:
     * - LearnDash, Sensei, Tutor LMS, LifterLMS post types
     * - Content patterns: programme, modules, durée, instructeur
     */
    private function detect_course( $post, $content ) {
        // Plugin: LearnDash
        if ( $post->post_type === 'sfwd-courses' ) {
            $data = array( 'course_name' => get_the_title( $post ) );
            $price = get_post_meta( $post->ID, '_sfwd-courses_course_price', true );
            if ( $price ) $data['course_price'] = $price;
            return $data;
        }

        // Plugin: Sensei LMS
        if ( $post->post_type === 'course' && class_exists( 'Sensei_Main' ) ) {
            return array( 'course_name' => get_the_title( $post ) );
        }

        // Plugin: Tutor LMS
        if ( $post->post_type === 'courses' && defined( 'TUTOR_VERSION' ) ) {
            $data = array( 'course_name' => get_the_title( $post ) );
            $price = get_post_meta( $post->ID, '_tutor_course_price', true );
            if ( $price ) $data['course_price'] = $price;
            return $data;
        }

        // Plugin: LifterLMS
        if ( $post->post_type === 'course' && class_exists( 'LifterLMS' ) ) {
            return array( 'course_name' => get_the_title( $post ) );
        }

        // Content-based: need 2+ signals
        $lower = mb_strtolower( $content );
        $title_lower = mb_strtolower( $post->post_title );
        $signals = 0;

        $course_words = array( 'formation', 'training', 'cours', 'course', 'cursus', 'programme', 'program', 'module', 'certification', 'kurs', 'formación', 'formazione' );
        foreach ( $course_words as $w ) {
            if ( mb_strpos( $title_lower, $w ) !== false ) { $signals += 2; break; }
            if ( mb_strpos( $lower, $w ) !== false ) { $signals++; break; }
        }

        $edu_signals = array( 'instructeur', 'instructor', 'formateur', 'trainer', 'durée', 'duration', 'prérequis', 'prerequisites', 'objectifs', 'objectives', 'compétences', 'skills', 'certificat', 'certificate', 'diplôme', 'diploma' );
        foreach ( $edu_signals as $w ) {
            if ( mb_strpos( $lower, $w ) !== false ) { $signals++; }
            if ( $signals >= 3 ) break;
        }

        if ( $signals < 2 ) return false;

        $data = array( 'course_name' => get_the_title( $post ) );
        // Try to extract duration
        if ( preg_match( '/(dur[ée]e|duration)\s*:?\s*(\d+)\s*(h|heures?|hours?|jours?|days?|semaines?|weeks?)/iu', $content, $dur ) ) {
            $data['course_duration'] = $dur[2] . ' ' . $dur[3];
        }
        return $data;
    }

    /**
     * Detect Review from:
     * - Star rating patterns (X/5, X/10, ★)
     * - Review verdict patterns in title or content
     */
    private function detect_review( $post, $content ) {
        $lower = mb_strtolower( $content );
        $title_lower = mb_strtolower( $post->post_title );

        // Signal 1: review words in title
        $review_words = array( 'avis', 'review', 'test', 'comparatif', 'comparison', 'verdict', 'bewertung', 'reseña', 'recensione', 'notre avis', 'our review', 'mon avis' );
        $has_review_title = false;
        foreach ( $review_words as $w ) {
            if ( mb_strpos( $title_lower, $w ) !== false ) { $has_review_title = true; break; }
        }

        if ( ! $has_review_title ) return false;

        // Signal 2: rating pattern in content
        $data = array();
        // Pattern: "Note : 8/10", "Rating: 4.5/5", "★★★★☆"
        if ( preg_match( '/(note|rating|score|bewertung|puntuación|voto)\s*:?\s*(\d+[.,]?\d*)\s*\/\s*(\d+)/iu', $content, $rm ) ) {
            $rating = floatval( str_replace( ',', '.', $rm[2] ) );
            $max    = (int) $rm[3];
            if ( $max === 10 ) $rating = $rating / 2; // normalize to /5
            if ( $max === 100 ) $rating = $rating / 20;
            $data['review_rating']   = min( 5, max( 0, round( $rating, 1 ) ) );
            $data['review_best']     = 5;
        } elseif ( preg_match_all( '/★/', $content, $stars ) ) {
            $count = count( $stars[0] );
            if ( $count >= 1 && $count <= 5 ) {
                $data['review_rating'] = $count;
                $data['review_best']   = 5;
            }
        }

        if ( empty( $data['review_rating'] ) ) return false;

        $data['review_name']   = get_the_title( $post );
        $data['review_author'] = get_the_author_meta( 'display_name', $post->post_author );

        return $data;
    }

    /**
     * Detect LocalBusiness page:
     * - Contact/About page with address + phone
     * - Only on pages (not posts)
     */
    private function detect_local_business_page( $post, $content ) {
        $slug  = $post->post_name;
        $lower = mb_strtolower( $content );

        // Must be a contact/about-like page
        $contact_slugs = array( 'contact', 'a-propos', 'about', 'about-us', 'notre-agence', 'qui-sommes-nous', 'impressum', 'kontakt', 'contacto', 'chi-siamo', 'quem-somos' );
        $is_contact = false;
        foreach ( $contact_slugs as $s ) {
            if ( strpos( $slug, $s ) !== false ) { $is_contact = true; break; }
        }

        if ( ! $is_contact ) {
            // Also check title
            $title_lower = mb_strtolower( $post->post_title );
            $contact_titles = array( 'contact', 'à propos', 'about', 'qui sommes', 'notre agence', 'impressum', 'kontakt', 'quiénes somos', 'chi siamo' );
            foreach ( $contact_titles as $t ) {
                if ( mb_strpos( $title_lower, $t ) !== false ) { $is_contact = true; break; }
            }
        }
        if ( ! $is_contact ) return false;

        // Need at least address OR phone in content
        $has_phone   = (bool) preg_match( '/(?:\+?\d{1,4}[\s.-]?)?\(?\d{1,5}\)?[\s.-]?\d{2,5}[\s.-]?\d{2,5}[\s.-]?\d{0,5}/', $content );
        $has_address = (bool) preg_match( '/\d{4,5}\s+\w/u', $content ); // postal code followed by city
        $has_tel     = ( strpos( $lower, 'tel:' ) !== false || strpos( $lower, 'téléphone' ) !== false || strpos( $lower, 'phone' ) !== false || strpos( $lower, 'telefon' ) !== false );

        // Check if LocalBusiness global settings exist (more reliable)
        $global = self::get_local_settings();
        $has_global = ! empty( $global['address'] ) || ! empty( $global['phone'] );

        return $has_global || ( $has_phone && ( $has_address || $has_tel ) );
    }

    /**
     * Detect JobPosting from:
     * - WP Job Manager plugin (job_listing post type)
     * - Simple Job Board, WP Job Openings
     * - Content patterns: salary + apply + job requirements
     */
    private function detect_job_posting( $post, $content ) {
        // Plugin: WP Job Manager
        if ( $post->post_type === 'job_listing' ) {
            $data = array( 'job_title' => get_the_title( $post ) );
            $loc = get_post_meta( $post->ID, '_job_location', true );
            if ( $loc ) $data['job_location'] = $loc;
            $company = get_post_meta( $post->ID, '_company_name', true );
            if ( $company ) $data['job_company'] = $company;
            $type = get_post_meta( $post->ID, '_job_type', true );
            if ( $type ) $data['job_employment_type'] = strtoupper( str_replace( array( '-', ' ' ), '_', $type ) );
            return $data;
        }

        // Plugin: Simple Job Board
        if ( $post->post_type === 'jobpost' ) {
            return array( 'job_title' => get_the_title( $post ) );
        }

        // Plugin: WP Job Openings
        if ( $post->post_type === 'awsm_job_openings' ) {
            return array( 'job_title' => get_the_title( $post ) );
        }

        // Content-based: need job title signals + apply/salary
        $lower = mb_strtolower( $content );
        $title_lower = mb_strtolower( $post->post_title );
        $signals = 0;

        // Must have job-related word in TITLE (not just content — too many false positives)
        $title_job_words = array( 'recrutement', 'hiring', 'we\'re hiring', 'on recrute', 'offre d\'emploi', 'job', 'stellenangebot', 'oferta de empleo', 'poste à pourvoir', 'cdi', 'cdd', 'stage', 'alternance' );
        $has_job_title = false;
        foreach ( $title_job_words as $w ) {
            if ( mb_strpos( $title_lower, $w ) !== false ) { $has_job_title = true; break; }
        }
        if ( ! $has_job_title ) return false;

        // Content must have apply/salary signals
        // Use word boundary \b to prevent 'intern' matching 'internal'
        $apply_patterns = array(
            '/\b(postuler|candidature|candidater|apply now|bewerben|solicitar)\b/iu',
            '/\b(salaire|salary|rémunération|compensation|gehalt|sueldo)\b/iu',
            '/\b(contrat|contract|temps plein|full[\s-]time|part[\s-]time|teilzeit)\b/iu',
            '/\b(télétravail|remote work|home[\s-]?office|freelance)\b/iu',
        );
        foreach ( $apply_patterns as $p ) {
            if ( preg_match( $p, $content ) ) { $signals++; }
        }

        if ( $signals < 1 ) return false;
        return array( 'job_title' => get_the_title( $post ) );
    }

    /**
     * Detect SoftwareApplication from:
     * - Download/app pages with version + OS requirements
     * - Plugin/theme pages
     */
    private function detect_software( $post, $content ) {
        $lower = mb_strtolower( $content );
        $title_lower = mb_strtolower( $post->post_title );
        $signals = 0;

        // MUST have software keyword in TITLE (not just content — avoids homepage false positives)
        $sw_title_words = array( 'logiciel', 'software', 'application', 'app', 'plugin', 'extension', 'outil', 'tool', 'saas' );
        $has_sw_title = false;
        foreach ( $sw_title_words as $w ) {
            // Use word boundary to avoid "tool" matching in "tooltip" etc.
            if ( preg_match( '/\b' . preg_quote( $w, '/' ) . '\b/iu', $post->post_title ) ) {
                $has_sw_title = true;
                $signals++;
                break;
            }
        }
        if ( ! $has_sw_title ) return false;

        // Version pattern
        if ( preg_match( '/v(?:ersion)?\s*\.?\s*\d+\.\d+/i', $content ) ) $signals++;

        // Download/install signals (word boundary)
        if ( preg_match( '/\b(télécharger|download|installer|install|herunterladen|descargar|scaricare)\b/iu', $content ) ) $signals++;

        // Pricing signals only count if specific to the software (not generic SaaS pricing)
        if ( preg_match( '/\b(plan gratuit|free plan|essai gratuit|free trial|open[\s-]?source)\b/iu', $content ) ) $signals++;

        // OS/platform mentions
        if ( preg_match( '/(windows|macos|linux|ios|android)/i', $content ) ) $signals++;

        if ( $signals < 2 ) return false;

        $data = array(
            'software_name' => get_the_title( $post ),
            'software_os'   => 'Web',
        );

        // Try to detect OS
        if ( preg_match( '/(windows|macos|linux|ios|android)/i', $content, $os ) ) {
            $data['software_os'] = ucfirst( strtolower( $os[1] ) );
        }

        return $data;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SCHEMA PRO — Register post meta for Gutenberg REST save
     *  (same pattern as canonical + robots — required for block editor)
     * ═══════════════════════════════════════════════════════════════ */

    public function register_schema_pro_meta() {
        foreach ( get_post_types( array( 'public' => true ) ) as $pt ) {
            register_post_meta( $pt, self::META_TYPE, array(
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'string',
                'default'       => 'auto',
                'auth_callback' => function() { return current_user_can( 'edit_posts' ); },
            ) );
            register_post_meta( $pt, self::META_DATA, array(
                'show_in_rest'  => array(
                    'schema' => array(
                        'type'                 => 'object',
                        'additionalProperties' => array( 'type' => 'string' ),
                    ),
                ),
                'single'        => true,
                'type'          => 'object',
                'default'       => array(),
                'auth_callback' => function() { return current_user_can( 'edit_posts' ); },
            ) );
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SCHEMA PRO — Meta Box (post editor)
     * ═══════════════════════════════════════════════════════════════ */

    public function add_schema_pro_metabox() {
        $post_types = get_post_types( array( 'public' => true ), 'names' );
        foreach ( $post_types as $pt ) {
 add_meta_box( 'hts-schema-pro', 'HTS Schema Pro', array( $this, 'render_schema_pro_metabox' ), $pt, 'side', 'default' );
        }
    }

    public function render_schema_pro_metabox( $post ) {
        wp_nonce_field( 'hts_schema_pro_save', 'hts_schema_pro_nonce' );
        $type = get_post_meta( $post->ID, self::META_TYPE, true ) ?: 'auto';
        $data = get_post_meta( $post->ID, self::META_DATA, true ) ?: array();
        ?>
        <style>
            .hts-sp-row { margin: 6px 0; }
            .hts-sp-row label { display: block; font-weight: 600; font-size: 11px; margin-bottom: 2px; color: #1e293b; }
            .hts-sp-row input, .hts-sp-row select, .hts-sp-row textarea { width: 100%; font-size: 12px; }
            .hts-sp-row textarea { min-height: 50px; }
            .hts-sp-fields { display: none; margin-top: 8px; padding: 8px; background: #f8fafc; border-radius: 6px; border: 1px solid #e2e8f0; }
            .hts-sp-fields.active { display: block; }
            .hts-sp-hint { font-size: 10px; color: #64748b; margin-top: 2px; }
        </style>

        <div class="hts-sp-row">
            <label for="hts_sp_schema_type">Type de Schema</label>
            <select name="hts_sp_schema_type" id="hts_sp_schema_type" onchange="htsSPToggle(this.value)">
                <?php foreach ( self::PRO_TYPES as $k => $v ) : ?>
                    <option value="<?php echo esc_attr( $k ); ?>" <?php selected( $type, $k ); ?>><?php echo esc_html( $v['icon'] . ' ' . $v['label'] ); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="hts-sp-hint">Auto = Article + FAQ/HowTo/Video détectés automatiquement</div>
        </div>

        <!-- Product fields -->
        <div class="hts-sp-fields" id="hts-sp-Product">
            <div class="hts-sp-row"><label>Nom du produit</label><input type="text" name="hts_sp[product_name]" value="<?php echo esc_attr( $data['product_name'] ?? '' ); ?>" placeholder="Ex: iPhone 15 Pro"></div>
            <div class="hts-sp-row"><label>Marque</label><input type="text" name="hts_sp[product_brand]" value="<?php echo esc_attr( $data['product_brand'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Prix (€)</label><input type="text" name="hts_sp[product_price]" value="<?php echo esc_attr( $data['product_price'] ?? '' ); ?>" placeholder="99.90"></div>
            <div class="hts-sp-row"><label>Disponibilité</label>
                <select name="hts_sp[product_availability]">
                    <?php foreach ( array( 'InStock' => 'En stock', 'OutOfStock' => 'Rupture', 'PreOrder' => 'Pré-commande', 'Discontinued' => 'Arrêté' ) as $av => $al ) : ?>
                        <option value="<?php echo esc_attr( $av ); ?>" <?php selected( $data['product_availability'] ?? 'InStock', $av ); ?>><?php echo esc_html( $al ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>SKU / GTIN / MPN</label><input type="text" name="hts_sp[product_sku]" value="<?php echo esc_attr( $data['product_sku'] ?? '' ); ?>" placeholder="Optionnel"></div>
            <div class="hts-sp-row"><label>Note (/5)</label><input type="text" name="hts_sp[product_rating]" value="<?php echo esc_attr( $data['product_rating'] ?? '' ); ?>" placeholder="4.5"></div>
            <div class="hts-sp-row"><label>Nb avis</label><input type="text" name="hts_sp[product_review_count]" value="<?php echo esc_attr( $data['product_review_count'] ?? '' ); ?>" placeholder="42"></div>
        </div>

        <!-- LocalBusiness fields -->
        <div class="hts-sp-fields" id="hts-sp-LocalBusiness">
 <div class="hts-sp-hint"> Les infos globales (nom, adresse, téléphone) sont dans Réglages HTS → Schema Local.<br>Champs ci-dessous = override par page.</div>
            <div class="hts-sp-row"><label>Sous-type</label>
                <select name="hts_sp[local_subtype]">
                    <?php foreach ( array( 'LocalBusiness', 'Restaurant', 'Store', 'MedicalBusiness', 'LegalService', 'FinancialService', 'RealEstateAgent', 'AutoRepair', 'HealthAndBeautyBusiness', 'HomeAndConstructionBusiness' ) as $sub ) : ?>
                        <option value="<?php echo esc_attr( $sub ); ?>" <?php selected( $data['local_subtype'] ?? 'LocalBusiness', $sub ); ?>><?php echo esc_html( $sub ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>Nom (override)</label><input type="text" name="hts_sp[local_name]" value="<?php echo esc_attr( $data['local_name'] ?? '' ); ?>" placeholder="Laisser vide = global"></div>
            <div class="hts-sp-row"><label>Adresse (override)</label><input type="text" name="hts_sp[local_address]" value="<?php echo esc_attr( $data['local_address'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Téléphone (override)</label><input type="text" name="hts_sp[local_phone]" value="<?php echo esc_attr( $data['local_phone'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Latitude</label><input type="text" name="hts_sp[local_lat]" value="<?php echo esc_attr( $data['local_lat'] ?? '' ); ?>" placeholder="48.8566"></div>
            <div class="hts-sp-row"><label>Longitude</label><input type="text" name="hts_sp[local_lng]" value="<?php echo esc_attr( $data['local_lng'] ?? '' ); ?>" placeholder="2.3522"></div>
            <div class="hts-sp-row"><label>Fourchette de prix</label><input type="text" name="hts_sp[local_price_range]" value="<?php echo esc_attr( $data['local_price_range'] ?? '' ); ?>" placeholder="€€"></div>
        </div>

        <!-- Event fields -->
        <div class="hts-sp-fields" id="hts-sp-Event">
            <div class="hts-sp-row"><label>Nom de l'événement</label><input type="text" name="hts_sp[event_name]" value="<?php echo esc_attr( $data['event_name'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Date de début</label><input type="datetime-local" name="hts_sp[event_start]" value="<?php echo esc_attr( $data['event_start'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Date de fin</label><input type="datetime-local" name="hts_sp[event_end]" value="<?php echo esc_attr( $data['event_end'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Lieu</label><input type="text" name="hts_sp[event_location]" value="<?php echo esc_attr( $data['event_location'] ?? '' ); ?>" placeholder="Nom du lieu"></div>
            <div class="hts-sp-row"><label>Adresse du lieu</label><input type="text" name="hts_sp[event_address]" value="<?php echo esc_attr( $data['event_address'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Statut</label>
                <select name="hts_sp[event_status]">
                    <?php foreach ( array( 'EventScheduled' => 'Prévu', 'EventPostponed' => 'Reporté', 'EventCancelled' => 'Annulé', 'EventMovedOnline' => 'En ligne' ) as $es => $el ) : ?>
                        <option value="<?php echo esc_attr( $es ); ?>" <?php selected( $data['event_status'] ?? 'EventScheduled', $es ); ?>><?php echo esc_html( $el ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>Prix (€)</label><input type="text" name="hts_sp[event_price]" value="<?php echo esc_attr( $data['event_price'] ?? '' ); ?>" placeholder="0 = gratuit"></div>
            <div class="hts-sp-row"><label>URL billetterie</label><input type="url" name="hts_sp[event_url]" value="<?php echo esc_attr( $data['event_url'] ?? '' ); ?>"></div>
        </div>

        <!-- Course fields -->
        <div class="hts-sp-fields" id="hts-sp-Course">
            <div class="hts-sp-row"><label>Nom de la formation</label><input type="text" name="hts_sp[course_name]" value="<?php echo esc_attr( $data['course_name'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Organisme</label><input type="text" name="hts_sp[course_provider]" value="<?php echo esc_attr( $data['course_provider'] ?? '' ); ?>" placeholder="Ex: HackTheSEO Academy"></div>
            <div class="hts-sp-row"><label>Mode</label>
                <select name="hts_sp[course_mode]">
                    <?php foreach ( array( 'Online' => 'En ligne', 'Onsite' => 'Présentiel', 'Blended' => 'Mixte' ) as $cm => $cl ) : ?>
                        <option value="<?php echo esc_attr( $cm ); ?>" <?php selected( $data['course_mode'] ?? 'Online', $cm ); ?>><?php echo esc_html( $cl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>Langue</label><input type="text" name="hts_sp[course_language]" value="<?php echo esc_attr( $data['course_language'] ?? 'fr' ); ?>"></div>
            <div class="hts-sp-row"><label>Prix (€)</label><input type="text" name="hts_sp[course_price]" value="<?php echo esc_attr( $data['course_price'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Note (/5)</label><input type="text" name="hts_sp[course_rating]" value="<?php echo esc_attr( $data['course_rating'] ?? '' ); ?>"></div>
        </div>

        <!-- Recipe fields -->
        <div class="hts-sp-fields" id="hts-sp-Recipe">
            <div class="hts-sp-row"><label>Nom de la recette</label><input type="text" name="hts_sp[recipe_name]" value="<?php echo esc_attr( $data['recipe_name'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Temps de préparation (min)</label><input type="number" name="hts_sp[recipe_prep_time]" value="<?php echo esc_attr( $data['recipe_prep_time'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Temps de cuisson (min)</label><input type="number" name="hts_sp[recipe_cook_time]" value="<?php echo esc_attr( $data['recipe_cook_time'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Portions</label><input type="text" name="hts_sp[recipe_yield]" value="<?php echo esc_attr( $data['recipe_yield'] ?? '' ); ?>" placeholder="4 personnes"></div>
            <div class="hts-sp-row"><label>Catégorie</label><input type="text" name="hts_sp[recipe_category]" value="<?php echo esc_attr( $data['recipe_category'] ?? '' ); ?>" placeholder="Plat principal"></div>
            <div class="hts-sp-row"><label>Cuisine</label><input type="text" name="hts_sp[recipe_cuisine]" value="<?php echo esc_attr( $data['recipe_cuisine'] ?? '' ); ?>" placeholder="Française"></div>
            <div class="hts-sp-row"><label>Calories (kcal)</label><input type="text" name="hts_sp[recipe_calories]" value="<?php echo esc_attr( $data['recipe_calories'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Ingrédients (1 par ligne)</label><textarea name="hts_sp[recipe_ingredients]" rows="4" placeholder="200g farine&#10;3 oeufs&#10;100ml lait"><?php echo esc_textarea( $data['recipe_ingredients'] ?? '' ); ?></textarea></div>
            <div class="hts-sp-row"><label>Note (/5)</label><input type="text" name="hts_sp[recipe_rating]" value="<?php echo esc_attr( $data['recipe_rating'] ?? '' ); ?>"></div>
        </div>

        <!-- JobPosting fields -->
        <div class="hts-sp-fields" id="hts-sp-JobPosting">
            <div class="hts-sp-row"><label>Titre du poste</label><input type="text" name="hts_sp[job_title]" value="<?php echo esc_attr( $data['job_title'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Entreprise</label><input type="text" name="hts_sp[job_company]" value="<?php echo esc_attr( $data['job_company'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Lieu</label><input type="text" name="hts_sp[job_location]" value="<?php echo esc_attr( $data['job_location'] ?? '' ); ?>" placeholder="Paris, France"></div>
            <div class="hts-sp-row"><label>Type de contrat</label>
                <select name="hts_sp[job_type]">
                    <?php foreach ( array( 'FULL_TIME' => 'CDI', 'PART_TIME' => 'Temps partiel', 'CONTRACTOR' => 'Freelance', 'TEMPORARY' => 'CDD', 'INTERN' => 'Stage' ) as $jt => $jl ) : ?>
                        <option value="<?php echo esc_attr( $jt ); ?>" <?php selected( $data['job_type'] ?? 'FULL_TIME', $jt ); ?>><?php echo esc_html( $jl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>Salaire (€/an)</label><input type="text" name="hts_sp[job_salary]" value="<?php echo esc_attr( $data['job_salary'] ?? '' ); ?>" placeholder="45000"></div>
            <div class="hts-sp-row"><label>Salaire max (€/an)</label><input type="text" name="hts_sp[job_salary_max]" value="<?php echo esc_attr( $data['job_salary_max'] ?? '' ); ?>" placeholder="60000"></div>
            <div class="hts-sp-row"><label>Télétravail</label>
                <select name="hts_sp[job_remote]">
                    <option value="" <?php selected( $data['job_remote'] ?? '', '' ); ?>>Non spécifié</option>
                    <option value="TELECOMMUTE" <?php selected( $data['job_remote'] ?? '', 'TELECOMMUTE' ); ?>>Télétravail possible</option>
                </select>
            </div>
            <div class="hts-sp-row"><label>Date limite candidature</label><input type="date" name="hts_sp[job_valid_through]" value="<?php echo esc_attr( $data['job_valid_through'] ?? '' ); ?>"></div>
        </div>

        <!-- Book fields -->
        <div class="hts-sp-fields" id="hts-sp-Book">
            <div class="hts-sp-row"><label>Titre du livre</label><input type="text" name="hts_sp[book_title]" value="<?php echo esc_attr( $data['book_title'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Auteur</label><input type="text" name="hts_sp[book_author]" value="<?php echo esc_attr( $data['book_author'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>ISBN</label><input type="text" name="hts_sp[book_isbn]" value="<?php echo esc_attr( $data['book_isbn'] ?? '' ); ?>" placeholder="978-2-10-XXXXX-X"></div>
            <div class="hts-sp-row"><label>Éditeur</label><input type="text" name="hts_sp[book_publisher]" value="<?php echo esc_attr( $data['book_publisher'] ?? '' ); ?>" placeholder="Dunod"></div>
            <div class="hts-sp-row"><label>Date de publication</label><input type="date" name="hts_sp[book_date]" value="<?php echo esc_attr( $data['book_date'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Langue</label><input type="text" name="hts_sp[book_language]" value="<?php echo esc_attr( $data['book_language'] ?? 'fr' ); ?>" placeholder="fr"></div>
            <div class="hts-sp-row"><label>Nombre de pages</label><input type="number" name="hts_sp[book_pages]" value="<?php echo esc_attr( $data['book_pages'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Genre</label><input type="text" name="hts_sp[book_genre]" value="<?php echo esc_attr( $data['book_genre'] ?? '' ); ?>" placeholder="Marketing digital"></div>
            <div class="hts-sp-row"><label>URL couverture</label><input type="url" name="hts_sp[book_image]" value="<?php echo esc_attr( $data['book_image'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Note moyenne (1-5)</label><input type="number" name="hts_sp[book_rating]" value="<?php echo esc_attr( $data['book_rating'] ?? '' ); ?>" min="1" max="5" step="0.1"></div>
            <div class="hts-sp-row"><label>Nombre d'avis</label><input type="number" name="hts_sp[book_review_count]" value="<?php echo esc_attr( $data['book_review_count'] ?? '' ); ?>"></div>
        </div>

        <!-- Review fields -->
        <div class="hts-sp-fields" id="hts-sp-Review">
            <div class="hts-sp-row"><label>Objet de l'avis</label><input type="text" name="hts_sp[review_item_name]" value="<?php echo esc_attr( $data['review_item_name'] ?? '' ); ?>" placeholder="Nom du produit/service"></div>
            <div class="hts-sp-row"><label>Type de l'objet</label>
                <select name="hts_sp[review_item_type]">
                    <?php foreach ( array( 'Product' => 'Produit', 'Book' => 'Livre', 'Movie' => 'Film', 'Restaurant' => 'Restaurant', 'SoftwareApplication' => 'Logiciel', 'LocalBusiness' => 'Commerce', 'Course' => 'Formation', 'Thing' => 'Autre' ) as $rt => $rl ) : ?>
                        <option value="<?php echo esc_attr( $rt ); ?>" <?php selected( $data['review_item_type'] ?? 'Thing', $rt ); ?>><?php echo esc_html( $rl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>Note (1-5)</label><input type="number" name="hts_sp[review_rating]" value="<?php echo esc_attr( $data['review_rating'] ?? '' ); ?>" min="1" max="5" step="0.1"></div>
            <div class="hts-sp-row"><label>Note max</label><input type="number" name="hts_sp[review_best_rating]" value="<?php echo esc_attr( $data['review_best_rating'] ?? '5' ); ?>" min="1" max="10"></div>
            <div class="hts-sp-row"><label>Auteur de l'avis</label><input type="text" name="hts_sp[review_author]" value="<?php echo esc_attr( $data['review_author'] ?? '' ); ?>" placeholder="Laisser vide = auteur de l'article"></div>
            <div class="hts-sp-row"><label>Corps de l'avis</label><textarea name="hts_sp[review_body]" rows="3" class="hts-w-full"><?php echo esc_textarea( $data['review_body'] ?? '' ); ?></textarea></div>
        </div>

        <!-- SoftwareApplication fields -->
        <div class="hts-sp-fields" id="hts-sp-SoftwareApplication">
            <div class="hts-sp-row"><label>Nom du logiciel</label><input type="text" name="hts_sp[soft_name]" value="<?php echo esc_attr( $data['soft_name'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Description</label><textarea name="hts_sp[soft_description]" rows="2" class="hts-w-full"><?php echo esc_textarea( $data['soft_description'] ?? '' ); ?></textarea></div>
            <div class="hts-sp-row"><label>Catégorie</label>
                <select name="hts_sp[soft_category]">
                    <?php foreach ( array( 'BusinessApplication' => 'Business', 'DeveloperApplication' => 'Développement', 'DesignApplication' => 'Design', 'EducationApplication' => 'Éducation', 'GameApplication' => 'Jeu', 'HealthApplication' => 'Santé', 'WebApplication' => 'Web App', 'BrowserApplication' => 'Navigateur', 'SecurityApplication' => 'Sécurité', '' => 'Autre' ) as $sc => $sl ) : ?>
                        <option value="<?php echo esc_attr( $sc ); ?>" <?php selected( $data['soft_category'] ?? '', $sc ); ?>><?php echo esc_html( $sl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="hts-sp-row"><label>Système d'exploitation</label><input type="text" name="hts_sp[soft_os]" value="<?php echo esc_attr( $data['soft_os'] ?? '' ); ?>" placeholder="Windows, macOS, Linux, Android, iOS"></div>
            <div class="hts-sp-row"><label>URL screenshot</label><input type="url" name="hts_sp[soft_screenshot]" value="<?php echo esc_attr( $data['soft_screenshot'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>URL téléchargement</label><input type="url" name="hts_sp[soft_download_url]" value="<?php echo esc_attr( $data['soft_download_url'] ?? '' ); ?>"></div>
            <div class="hts-sp-row"><label>Prix (€)</label><input type="text" name="hts_sp[soft_price]" value="<?php echo esc_attr( $data['soft_price'] ?? '' ); ?>" placeholder="0 = gratuit"></div>
            <div class="hts-sp-row"><label>Devise</label><input type="text" name="hts_sp[soft_currency]" value="<?php echo esc_attr( $data['soft_currency'] ?? 'EUR' ); ?>" placeholder="EUR"></div>
            <div class="hts-sp-row"><label>Note (1-5)</label><input type="number" name="hts_sp[soft_rating]" value="<?php echo esc_attr( $data['soft_rating'] ?? '' ); ?>" min="1" max="5" step="0.1"></div>
            <div class="hts-sp-row"><label>Nombre d'avis</label><input type="number" name="hts_sp[soft_review_count]" value="<?php echo esc_attr( $data['soft_review_count'] ?? '' ); ?>"></div>
        </div>

        <script>
        function htsSPToggle(val) {
            document.querySelectorAll('.hts-sp-fields').forEach(function(el) { el.classList.remove('active'); });
            var target = document.getElementById('hts-sp-' + val);
            if (target) target.classList.add('active');
        }
        htsSPToggle('<?php echo esc_js( $type ); ?>');

        /* ── AJAX auto-save Schema Pro (works in Classic + Gutenberg) ── */
        (function(){
            var postId = <?php echo (int) $post->ID; ?>;
            var saving = false;
            var statusEl = null;

            function htsSPSave() {
                if (saving) return;
                saving = true;

                // Collect all hts_sp fields
                var spData = {};
                document.querySelectorAll('[name^="hts_sp["]').forEach(function(el) {
                    var match = el.name.match(/hts_sp\[(\w+)\]/);
                    if (match) spData[match[1]] = el.value;
                });

                var type = document.getElementById('hts_sp_schema_type').value;

                // Show saving indicator
                if (!statusEl) {
                    statusEl = document.createElement('span');
                    statusEl.style.cssText = 'font-size:11px;margin-left:8px;';
                    var sel = document.getElementById('hts_sp_schema_type');
                    sel.parentNode.appendChild(statusEl);
                }
 statusEl.textContent = ' …';
                statusEl.style.color = '#6b7280';

                var fd = new FormData();
                fd.append('action', 'hts_schema_pro_save');
                fd.append('nonce', '<?php echo wp_create_nonce( 'hts_schema_pro_ajax' ); ?>');
                fd.append('post_id', postId);
                fd.append('schema_type', type);
                fd.append('schema_data', JSON.stringify(spData));

                fetch(ajaxurl, { method: 'POST', body: fd })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        saving = false;
                        if (data.success) {
 statusEl.textContent = '';
                            statusEl.style.color = '#10b981';
                        } else {
 statusEl.textContent = ' ' + (data.data && data.data.message || '');
                            statusEl.style.color = '#ef4444';
                        }
                        setTimeout(function() { statusEl.textContent = ''; }, 2000);
                    })
                    .catch(function() {
                        saving = false;
 statusEl.textContent = ' erreur';
                        statusEl.style.color = '#ef4444';
                    });
            }

            // Save on type change + sync SEO Panel select
            document.getElementById('hts_sp_schema_type').addEventListener('change', function() {
                htsSPToggle(this.value);
                // Sync SEO Panel's schema type select if present
                var panelSelect = document.querySelector('select[name="hts_schema_type"]');
                if (panelSelect) panelSelect.value = this.value;
                htsSPSave();
            });

            // Save on any field blur within Schema Pro
            document.querySelectorAll('.hts-sp-fields input, .hts-sp-fields select, .hts-sp-fields textarea').forEach(function(el) {
                el.addEventListener('change', htsSPSave);
            });

            // Reverse sync: if SEO Panel select changes, update Schema Pro
            var panelSelect = document.querySelector('select[name="hts_schema_type"]');
            if (panelSelect) {
                panelSelect.addEventListener('change', function() {
                    var spSelect = document.getElementById('hts_sp_schema_type');
                    if (spSelect) {
                        spSelect.value = this.value;
                        htsSPToggle(this.value);
                        htsSPSave();
                    }
                });
            }

            // Gutenberg: also save when post is saved (deferred to let store init)
            if (typeof wp !== 'undefined' && wp.data && wp.data.subscribe) {
                var wasSaving = false;
                setTimeout(function() {
                    try {
                        wp.data.subscribe(function() {
                            try {
                                var s = wp.data.select('core/editor');
                                if (!s || !s.isSavingPost) return;
                                var isSaving = s.isSavingPost();
                                if (wasSaving && !isSaving) {
                                    setTimeout(htsSPSave, 200);
                                }
                                wasSaving = isSaving;
                            } catch(e) {}
                        });
                    } catch(e) {}
                }, 3000);
            }
        })();
        </script>
        <?php
    }

    /**
     * AJAX save Schema Pro meta (primary save method — works in all editors).
     */
    public function ajax_save_schema_pro() {
        check_ajax_referer( 'hts_schema_pro_ajax', 'nonce' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( array( 'message' => 'Permission refusée.' ) );
        }

        $type = sanitize_text_field( $_POST['schema_type'] ?? 'auto' );
        if ( ! array_key_exists( $type, self::PRO_TYPES ) ) $type = 'auto';
        update_post_meta( $post_id, self::META_TYPE, $type );

        $raw = json_decode( wp_unslash( $_POST['schema_data'] ?? '{}' ), true );
        $data = array();
        if ( is_array( $raw ) ) {
            foreach ( $raw as $k => $v ) {
                $data[ sanitize_key( $k ) ] = sanitize_text_field( $v );
            }
        }
        update_post_meta( $post_id, self::META_DATA, $data );

        wp_send_json_success( array( 'type' => $type, 'fields' => count( $data ) ) );
    }

    /**
     * Fallback save via save_post (Classic Editor).
     */
    public function save_schema_pro_metabox( $post_id, $post ) {
        // Skip revisions and autosaves
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( wp_is_post_autosave( $post_id ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! isset( $_POST['hts_schema_pro_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['hts_schema_pro_nonce'], 'hts_schema_pro_save' ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        $type = sanitize_text_field( $_POST['hts_sp_schema_type'] ?? 'auto' );
        if ( ! array_key_exists( $type, self::PRO_TYPES ) ) $type = 'auto';
        update_post_meta( $post_id, self::META_TYPE, $type );

        $raw  = $_POST['hts_sp'] ?? array();
        $data = array();
        foreach ( $raw as $k => $v ) {
            $data[ sanitize_key( $k ) ] = is_array( $v ) ? array_map( 'sanitize_text_field', $v ) : sanitize_text_field( $v );
        }
        update_post_meta( $post_id, self::META_DATA, $data );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SCHEMA PRO — Global LocalBusiness settings
     * ═══════════════════════════════════════════════════════════════ */

    public static function get_local_settings() {
        return wp_parse_args( get_option( self::OPT_LOCAL, array() ), array(
            'name'         => '',
            'address'      => '',
            'city'         => '',
            'postal_code'  => '',
            'country'      => 'FR',
            'phone'        => '',
            'email'        => '',
            'url'          => '',
            'lat'          => '',
            'lng'          => '',
            'price_range'  => '',
            'opening_hours'=> '', // "Mo-Fr 09:00-18:00, Sa 09:00-12:00"
        ) );
    }

    public function ajax_save_local_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $data = array();
        foreach ( array( 'name', 'address', 'city', 'postal_code', 'country', 'phone', 'email', 'url', 'lat', 'lng', 'price_range', 'opening_hours' ) as $k ) {
            $data[ $k ] = sanitize_text_field( $_POST[ $k ] ?? '' );
        }
        update_option( self::OPT_LOCAL, $data, false );
        wp_send_json_success( array( 'message' => 'Paramètres Local Business sauvegardés.' ) );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SCHEMA PRO — Build methods (6 new types)
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Extract product data from WooCommerce for auto-schema.
     * Returns an array matching the Schema Pro fields format.
     *
     * @param int $post_id
     * @return array
     */
    private function get_wc_product_data( $post_id ) {
        $data = array();

        if ( ! function_exists( 'wc_get_product' ) ) return $data;

        $product = wc_get_product( $post_id );
        if ( ! $product ) return $data;

        $data['product_name'] = $product->get_name();

        // Brand: try WooCommerce Brands plugin taxonomy, then pa_marque, then fallback
        $brands = wp_get_post_terms( $post_id, 'product_brand', array( 'fields' => 'names' ) );
        if ( is_wp_error( $brands ) || empty( $brands ) ) {
            $brands = wp_get_post_terms( $post_id, 'pa_marque', array( 'fields' => 'names' ) );
        }
        if ( ! is_wp_error( $brands ) && ! empty( $brands ) ) {
            $data['product_brand'] = $brands[0];
        }

        // Price
        $price = $product->get_price();
        if ( $price !== '' && $price !== null ) {
            $data['product_price'] = $price;
        }

        // Availability
        $stock = $product->get_stock_status();
        $avail_map = array(
            'instock'     => 'InStock',
            'outofstock'  => 'OutOfStock',
            'onbackorder' => 'PreOrder',
        );
        $data['product_availability'] = isset( $avail_map[ $stock ] ) ? $avail_map[ $stock ] : 'InStock';

        // SKU / GTIN
        $sku = $product->get_sku();
        if ( $sku ) {
            $data['product_sku'] = $sku;
        }

        // Rating
        $rating = $product->get_average_rating();
        $count  = $product->get_review_count();
        if ( $rating && $count > 0 ) {
            $data['product_rating']       = $rating;
            $data['product_review_count'] = $count;
        }

        // Currency (WooCommerce store currency)
        $data['product_currency'] = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'EUR';

        return $data;
    }

    /**
     * Build Product schema.
     * @param WP_Post $post
     * @param array   $data  Schema Pro fields from meta.
     * @return array
     */
    private function build_product_schema( $post, $data ) {
        $name = ! empty( $data['product_name'] ) ? $data['product_name'] : get_the_title( $post );
        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Product',
            'name'        => $name,
            'url'         => get_permalink( $post ),
            'description' => $this->get_best_description( $post ),
        );

        if ( ! empty( $data['product_brand'] ) ) {
            $schema['brand'] = array( '@type' => 'Brand', 'name' => $data['product_brand'] );
        }

        if ( ! empty( $data['product_sku'] ) ) {
            $sku = $data['product_sku'];
            // Auto-detect GTIN (8/12/13/14 digits) vs MPN vs SKU
            if ( preg_match( '/^\d{8,14}$/', $sku ) ) {
                $len = strlen( $sku );
                if ( $len === 13 )     $schema['gtin13'] = $sku;
                elseif ( $len === 12 ) $schema['gtin12'] = $sku;
                elseif ( $len === 8 )  $schema['gtin8']  = $sku;
                elseif ( $len === 14 ) $schema['gtin14'] = $sku;
                else                   $schema['gtin']   = $sku;
            } else {
                $schema['sku'] = $sku;
            }
        }

        // Offer
        if ( ! empty( $data['product_price'] ) ) {
            $offer = array(
                '@type'         => 'Offer',
                'price'         => floatval( str_replace( ',', '.', $data['product_price'] ) ),
                'priceCurrency' => ! empty( $data['product_currency'] ) ? $data['product_currency'] : 'EUR',
                'url'           => get_permalink( $post ),
                'availability'  => 'https://schema.org/' . ( ! empty( $data['product_availability'] ) ? $data['product_availability'] : 'InStock' ),
            );
            $schema['offers'] = $offer;
        }

        // Rating
        if ( ! empty( $data['product_rating'] ) ) {
            $schema['aggregateRating'] = array(
                '@type'       => 'AggregateRating',
                'ratingValue' => floatval( $data['product_rating'] ),
                'bestRating'  => 5,
                'reviewCount' => max( 1, intval( ! empty( $data['product_review_count'] ) ? $data['product_review_count'] : 1 ) ),
            );
        }

        // Image
        if ( has_post_thumbnail( $post->ID ) ) {
            $schema['image'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post->ID ), 'full' );
        }

        return $schema;
    }

    /**
     * Build LocalBusiness schema.
     * Merges global settings with per-page overrides.
     */
    private function build_local_business_schema( $post, $data ) {
        $global  = self::get_local_settings();
        $subtype = ! empty( $data['local_subtype'] ) ? $data['local_subtype'] : 'LocalBusiness';
        $name    = ! empty( $data['local_name'] )    ? $data['local_name']    : ( $global['name'] ?: get_bloginfo( 'name' ) );

        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => $subtype,
            '@id'      => home_url( '/#localbusiness' ),
            'name'     => $name,
            'url'      => ! empty( $global['url'] ) ? $global['url'] : home_url( '/' ),
        );

        // Address
        $addr_street = ! empty( $data['local_address'] ) ? $data['local_address'] : $global['address'];
        if ( $addr_street ) {
            $schema['address'] = array(
                '@type'           => 'PostalAddress',
                'streetAddress'   => $addr_street,
                'addressLocality' => $global['city'] ?: '',
                'postalCode'      => $global['postal_code'] ?: '',
                'addressCountry'  => $global['country'] ?: 'FR',
            );
        }

        // Phone
        $phone = ! empty( $data['local_phone'] ) ? $data['local_phone'] : $global['phone'];
        if ( $phone ) $schema['telephone'] = $phone;
        if ( ! empty( $global['email'] ) ) $schema['email'] = $global['email'];

        // Geo
        $lat = ! empty( $data['local_lat'] ) ? $data['local_lat'] : $global['lat'];
        $lng = ! empty( $data['local_lng'] ) ? $data['local_lng'] : $global['lng'];
        if ( $lat && $lng ) {
            $schema['geo'] = array( '@type' => 'GeoCoordinates', 'latitude' => floatval( $lat ), 'longitude' => floatval( $lng ) );
        }

        // Price range
        $pr = ! empty( $data['local_price_range'] ) ? $data['local_price_range'] : $global['price_range'];
        if ( $pr ) $schema['priceRange'] = $pr;

        // Opening hours
        if ( ! empty( $global['opening_hours'] ) ) {
            $schema['openingHours'] = $global['opening_hours'];
        }

        // Logo + Image
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
            if ( $logo_url ) $schema['logo'] = $logo_url;
        }
        if ( has_post_thumbnail( $post->ID ) ) {
            $schema['image'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post->ID ), 'full' );
        }

        // Description
        $desc = $this->get_best_description( $post );
        if ( $desc ) $schema['description'] = $desc;

        return $schema;
    }

    /**
     * Build Event schema.
     */
    private function build_event_schema( $post, $data ) {
        $name = ! empty( $data['event_name'] ) ? $data['event_name'] : get_the_title( $post );

        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Event',
            'name'        => $name,
            'url'         => get_permalink( $post ),
            'description' => $this->get_best_description( $post ),
            'eventStatus' => 'https://schema.org/' . ( $data['event_status'] ?? 'EventScheduled' ),
        );

        if ( ! empty( $data['event_start'] ) ) $schema['startDate'] = wp_date( 'c', strtotime( $data['event_start'] ) );
        if ( ! empty( $data['event_end'] ) )   $schema['endDate']   = wp_date( 'c', strtotime( $data['event_end'] ) );

        // Location
        if ( ! empty( $data['event_location'] ) ) {
            $location = array( '@type' => 'Place', 'name' => $data['event_location'] );
            if ( ! empty( $data['event_address'] ) ) {
                $location['address'] = array( '@type' => 'PostalAddress', 'streetAddress' => $data['event_address'] );
            }
            $schema['location'] = $location;
        }

        // Attendance mode
        $status = $data['event_status'] ?? 'EventScheduled';
        if ( $status === 'EventMovedOnline' ) {
            $schema['eventAttendanceMode'] = 'https://schema.org/OnlineEventAttendanceMode';
            $schema['location'] = array( '@type' => 'VirtualLocation', 'url' => get_permalink( $post ) );
        } else {
            $schema['eventAttendanceMode'] = 'https://schema.org/OfflineEventAttendanceMode';
        }

        // Offer (ticket)
        if ( isset( $data['event_price'] ) && $data['event_price'] !== '' ) {
            $offer = array( '@type' => 'Offer', 'price' => floatval( $data['event_price'] ), 'priceCurrency' => 'EUR', 'availability' => 'https://schema.org/InStock' );
            if ( ! empty( $data['event_url'] ) ) $offer['url'] = $data['event_url'];
            $schema['offers'] = $offer;
        }

        // Image
        if ( has_post_thumbnail( $post->ID ) ) {
            $schema['image'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post->ID ), 'full' );
        }

        // Organizer
        $schema['organizer'] = array( '@type' => 'Organization', 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ) );

        return $schema;
    }

    /**
     * Build Course schema.
     */
    private function build_course_schema( $post, $data ) {
        $name = ! empty( $data['course_name'] ) ? $data['course_name'] : get_the_title( $post );

        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Course',
            'name'        => $name,
            'url'         => get_permalink( $post ),
            'description' => $this->get_best_description( $post ),
        );

        if ( ! empty( $data['course_provider'] ) ) {
            $schema['provider'] = array( '@type' => 'Organization', 'name' => $data['course_provider'], 'sameAs' => home_url( '/' ) );
        }

        // CourseInstance with mode
        $instance = array( '@type' => 'CourseInstance' );
        $mode_map = array( 'Online' => 'https://schema.org/OnlineCourseModeEnum', 'Onsite' => 'https://schema.org/OnsiteCourseModeEnum', 'Blended' => 'https://schema.org/BlendedCourseModeEnum' );
        $mode = $data['course_mode'] ?? 'Online';
        // Use courseMode as simple string for broader compatibility
        $instance['courseMode'] = $mode;

        if ( ! empty( $data['course_language'] ) ) {
            $schema['inLanguage'] = $data['course_language'];
            $instance['inLanguage'] = $data['course_language'];
        }

        $schema['hasCourseInstance'] = $instance;

        // Offer
        if ( ! empty( $data['course_price'] ) ) {
            $schema['offers'] = array( '@type' => 'Offer', 'price' => floatval( str_replace( ',', '.', $data['course_price'] ) ), 'priceCurrency' => 'EUR', 'availability' => 'https://schema.org/InStock' );
        }

        // Rating
        if ( ! empty( $data['course_rating'] ) ) {
            $schema['aggregateRating'] = array( '@type' => 'AggregateRating', 'ratingValue' => floatval( $data['course_rating'] ), 'bestRating' => 5, 'reviewCount' => 1 );
        }

        // Image
        if ( has_post_thumbnail( $post->ID ) ) {
            $schema['image'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post->ID ), 'full' );
        }

        return $schema;
    }

    /**
     * Build Recipe schema.
     */
    private function build_recipe_schema( $post, $data ) {
        $name = ! empty( $data['recipe_name'] ) ? $data['recipe_name'] : get_the_title( $post );

        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Recipe',
            'name'        => $name,
            'url'         => get_permalink( $post ),
            'description' => $this->get_best_description( $post ),
            'datePublished' => get_the_date( 'c', $post ),
        );

        // Author
        $author = get_userdata( $post->post_author );
        if ( $author ) $schema['author'] = array( '@type' => 'Person', 'name' => $author->display_name );

        // Times (ISO 8601 duration)
        if ( ! empty( $data['recipe_prep_time'] ) ) $schema['prepTime'] = 'PT' . intval( $data['recipe_prep_time'] ) . 'M';
        if ( ! empty( $data['recipe_cook_time'] ) ) $schema['cookTime'] = 'PT' . intval( $data['recipe_cook_time'] ) . 'M';
        $total = intval( $data['recipe_prep_time'] ?? 0 ) + intval( $data['recipe_cook_time'] ?? 0 );
        if ( $total > 0 ) $schema['totalTime'] = 'PT' . $total . 'M';

        if ( ! empty( $data['recipe_yield'] ) )    $schema['recipeYield']    = $data['recipe_yield'];
        if ( ! empty( $data['recipe_category'] ) ) $schema['recipeCategory'] = $data['recipe_category'];
        if ( ! empty( $data['recipe_cuisine'] ) )  $schema['recipeCuisine']  = $data['recipe_cuisine'];

        // Ingredients
        if ( ! empty( $data['recipe_ingredients'] ) ) {
            $lines = array_filter( array_map( 'trim', explode( "\n", $data['recipe_ingredients'] ) ) );
            if ( ! empty( $lines ) ) $schema['recipeIngredient'] = array_values( $lines );
        }

        // Instructions from content H2/H3 steps (auto-detect)
        $content = HTS_Content_Extractor::get_content( $post->ID );
        $howto = $this->detect_howto( $content, $post );
        if ( ! empty( $howto ) ) {
            $instructions = array();
            foreach ( $howto as $i => $s ) {
                $instructions[] = array( '@type' => 'HowToStep', 'position' => $i + 1, 'text' => $s['name'] . ( $s['text'] ? ': ' . $s['text'] : '' ) );
            }
            $schema['recipeInstructions'] = $instructions;
        }

        // Nutrition
        if ( ! empty( $data['recipe_calories'] ) ) {
            $schema['nutrition'] = array( '@type' => 'NutritionInformation', 'calories' => $data['recipe_calories'] . ' calories' );
        }

        // Rating
        if ( ! empty( $data['recipe_rating'] ) ) {
            $schema['aggregateRating'] = array( '@type' => 'AggregateRating', 'ratingValue' => floatval( $data['recipe_rating'] ), 'bestRating' => 5, 'reviewCount' => 1 );
        }

        // Image
        if ( has_post_thumbnail( $post->ID ) ) {
            $schema['image'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post->ID ), 'full' );
        }

        return $schema;
    }

    /**
     * Build JobPosting schema.
     */
    private function build_job_posting_schema( $post, $data ) {
        $title = ! empty( $data['job_title'] ) ? $data['job_title'] : get_the_title( $post );

        $schema = array(
            '@context'      => 'https://schema.org',
            '@type'         => 'JobPosting',
            'title'         => $title,
            'url'           => get_permalink( $post ),
            'description'   => $this->get_best_description( $post ),
            'datePosted'    => get_the_date( 'c', $post ),
            'employmentType'=> $data['job_type'] ?? 'FULL_TIME',
        );

        // Hiring organization
        $company = ! empty( $data['job_company'] ) ? $data['job_company'] : get_bloginfo( 'name' );
        $schema['hiringOrganization'] = array( '@type' => 'Organization', 'name' => $company, 'sameAs' => home_url( '/' ) );
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
            if ( $logo_url ) $schema['hiringOrganization']['logo'] = $logo_url;
        }

        // Location
        if ( ! empty( $data['job_location'] ) ) {
            $parts = array_map( 'trim', explode( ',', $data['job_location'] ) );
            $loc = array( '@type' => 'Place', 'address' => array( '@type' => 'PostalAddress', 'addressLocality' => $parts[0] ) );
            if ( isset( $parts[1] ) ) $loc['address']['addressCountry'] = $parts[1];
            $schema['jobLocation'] = $loc;
        }

        // Remote
        if ( ! empty( $data['job_remote'] ) ) {
            $schema['jobLocationType'] = $data['job_remote'];
            $schema['applicantLocationRequirements'] = array( '@type' => 'Country', 'name' => 'France' );
        }

        // Salary
        if ( ! empty( $data['job_salary'] ) ) {
            $salary = array(
                '@type'    => 'MonetaryAmount',
                'currency' => 'EUR',
                'value'    => array( '@type' => 'QuantitativeValue', 'unitText' => 'YEAR' ),
            );
            if ( ! empty( $data['job_salary_max'] ) ) {
                $salary['value']['minValue'] = floatval( $data['job_salary'] );
                $salary['value']['maxValue'] = floatval( $data['job_salary_max'] );
            } else {
                $salary['value']['value'] = floatval( $data['job_salary'] );
            }
            $schema['baseSalary'] = $salary;
        }

        // Valid through
        if ( ! empty( $data['job_valid_through'] ) ) {
            $schema['validThrough'] = wp_date( 'c', strtotime( $data['job_valid_through'] ) );
        }

        return $schema;
    }

    /**
     * Schema Pro: Book (Livre)
     * Fields: book_title, book_author, book_isbn, book_publisher, book_date,
     *         book_language, book_pages, book_genre, book_image, book_rating, book_review_count
     */
    private function build_book_schema( $post, $data ) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'Book',
            'name'     => ! empty( $data['book_title'] ) ? $data['book_title'] : get_the_title( $post ),
            'url'      => get_permalink( $post ),
        );

        if ( ! empty( $data['book_author'] ) )    $schema['author']        = array( '@type' => 'Person', 'name' => $data['book_author'] );
        if ( ! empty( $data['book_isbn'] ) )      $schema['isbn']          = $data['book_isbn'];
        if ( ! empty( $data['book_publisher'] ) ) $schema['publisher']     = array( '@type' => 'Organization', 'name' => $data['book_publisher'] );
        if ( ! empty( $data['book_date'] ) )      $schema['datePublished'] = $data['book_date'];
        if ( ! empty( $data['book_language'] ) )  $schema['inLanguage']    = $data['book_language'];
        if ( ! empty( $data['book_pages'] ) )     $schema['numberOfPages'] = (int) $data['book_pages'];
        if ( ! empty( $data['book_genre'] ) )     $schema['genre']         = $data['book_genre'];

        // Image: explicit or featured image
        if ( ! empty( $data['book_image'] ) ) {
            $schema['image'] = $data['book_image'];
        } elseif ( $thumb = get_the_post_thumbnail_url( $post->ID, 'full' ) ) {
            $schema['image'] = $thumb;
        }

        if ( ! empty( $data['book_rating'] ) ) {
            $schema['aggregateRating'] = array(
                '@type'       => 'AggregateRating',
                'ratingValue' => (float) $data['book_rating'],
                'bestRating'  => 5,
                'reviewCount' => (int) ( $data['book_review_count'] ?? 1 ),
            );
        }

        return $schema;
    }

    /**
     * Schema Pro: Review (Avis)
     * Fields: review_item_name, review_item_type, review_rating, review_best_rating,
     *         review_author, review_body
     */
    private function build_review_schema( $post, $data ) {
        $schema = array(
            '@context'      => 'https://schema.org',
            '@type'         => 'Review',
            'url'           => get_permalink( $post ),
            'datePublished' => get_the_date( 'c', $post ),
        );

        $schema['itemReviewed'] = array(
            '@type' => ! empty( $data['review_item_type'] ) ? $data['review_item_type'] : 'Thing',
            'name'  => ! empty( $data['review_item_name'] ) ? $data['review_item_name'] : get_the_title( $post ),
        );

        if ( ! empty( $data['review_rating'] ) ) {
            $schema['reviewRating'] = array(
                '@type'       => 'Rating',
                'ratingValue' => (float) $data['review_rating'],
                'bestRating'  => (int) ( $data['review_best_rating'] ?? 5 ),
            );
        }

        $author_name = ! empty( $data['review_author'] ) ? $data['review_author'] : get_the_author_meta( 'display_name', $post->post_author );
        $schema['author'] = array( '@type' => 'Person', 'name' => $author_name );

        if ( ! empty( $data['review_body'] ) ) {
            $schema['reviewBody'] = $data['review_body'];
        }

        return $schema;
    }

    /**
     * Schema Pro: SoftwareApplication (Logiciel)
     * Fields: soft_name, soft_description, soft_category, soft_os, soft_screenshot,
     *         soft_download_url, soft_price, soft_currency, soft_rating, soft_review_count
     */
    private function build_software_schema( $post, $data ) {
        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'SoftwareApplication',
            'name'        => ! empty( $data['soft_name'] ) ? $data['soft_name'] : get_the_title( $post ),
            'description' => ! empty( $data['soft_description'] ) ? $data['soft_description'] : $this->get_best_description( $post ),
            'url'         => get_permalink( $post ),
        );

        if ( ! empty( $data['soft_category'] ) )     $schema['applicationCategory'] = $data['soft_category'];
        if ( ! empty( $data['soft_os'] ) )           $schema['operatingSystem']     = $data['soft_os'];
        if ( ! empty( $data['soft_screenshot'] ) )   $schema['screenshot']          = $data['soft_screenshot'];
        if ( ! empty( $data['soft_download_url'] ) ) $schema['downloadUrl']         = $data['soft_download_url'];

        if ( isset( $data['soft_price'] ) && $data['soft_price'] !== '' ) {
            $schema['offers'] = array(
                '@type'         => 'Offer',
                'price'         => (float) $data['soft_price'],
                'priceCurrency' => ! empty( $data['soft_currency'] ) ? $data['soft_currency'] : 'EUR',
            );
        }

        if ( ! empty( $data['soft_rating'] ) ) {
            $schema['aggregateRating'] = array(
                '@type'       => 'AggregateRating',
                'ratingValue' => (float) $data['soft_rating'],
                'bestRating'  => 5,
                'reviewCount' => (int) ( $data['soft_review_count'] ?? 1 ),
            );
        }

        return $schema;
    }

    /**
     * Helper: get best description for a post (HTS meta → excerpt → content).
     */
    private function get_best_description( $post ) {
        $desc = get_post_meta( $post->ID, '_hts_meta_description', true );
        if ( ! $desc ) $desc = get_the_excerpt( $post );
        if ( ! $desc ) $desc = wp_trim_words( wp_strip_all_tags( HTS_Content_Extractor::get_content( $post->ID ) ), 30, '…' );
        return $desc ?: '';
    }

    /* ═══════════════════════════════════════════════════════════════
     *  AJAX — Preview
     * ═══════════════════════════════════════════════════════════════ */

    public function ajax_preview() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $post = get_post( absint( $_POST['post_id'] ?? 0 ) );
        if ( ! $post ) wp_send_json_error( array( 'message' => 'Article introuvable.' ) );

        $content  = HTS_Content_Extractor::get_content( $post->ID );
        $detected = array();

        // Schema Pro manual type
        $manual_type = get_post_meta( $post->ID, self::META_TYPE, true ) ?: 'auto';
        if ( $manual_type !== 'auto' && isset( self::PRO_TYPES[ $manual_type ] ) ) {
            $info = self::PRO_TYPES[ $manual_type ];
            $detected[] = array( 'type' => $manual_type, 'count' => 1, 'detail' => $info['icon'] . ' Schema Pro manuel', 'impact' => 'Rich snippet ' . $manual_type, 'source' => 'manual' );
        }

        $detected[] = array( 'type' => 'Article', 'count' => 1, 'detail' => 'Schema Article complet (auteur, dates, image, publisher)', 'impact' => 'Rich snippet + Knowledge Graph', 'source' => 'auto' );
        $faq = $this->detect_faq( $content );
        if ( ! empty( $faq ) ) $detected[] = array( 'type' => 'FAQPage', 'count' => count( $faq ), 'detail' => count( $faq ) . ' questions', 'impact' => 'Rich snippet FAQ + citations IA' );
        $howto = $this->detect_howto( $content, $post );
        if ( ! empty( $howto ) ) $detected[] = array( 'type' => 'HowTo', 'count' => count( $howto ), 'detail' => count( $howto ) . ' étapes', 'impact' => 'Rich snippet HowTo' );
        $videos = $this->detect_videos( $content );
        if ( ! empty( $videos ) ) $detected[] = array( 'type' => 'VideoObject', 'count' => count( $videos ), 'detail' => count( $videos ) . ' vidéo(s)', 'impact' => 'Vignette vidéo SERP' );
        $items = $this->detect_itemlist( $content, $post );
        if ( ! empty( $items ) ) $detected[] = array( 'type' => 'ItemList', 'count' => count( $items ), 'detail' => count( $items ) . ' items', 'impact' => 'Carrousel Google' );
        $detected[] = array( 'type' => 'Speakable', 'count' => 1, 'detail' => 'Voix + IA', 'impact' => 'Google Assistant + ChatGPT/Perplexity' );

        wp_send_json_success( array( 'post_title' => $post->post_title, 'schemas' => $detected, 'total' => count( $detected ) ) );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  PUBLIC API
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Diagnostic: verify hooks are registered and module is active.
     * Called by Health Check to provide precise error messages.
     */
    public function get_diagnostic() {
        $mod = get_option( 'hts_module_schema', '1' );
        $hooks_global = has_action( 'wp_head', array( $this, 'inject_global_schemas' ) );
        $hooks_page   = has_action( 'wp_head', array( $this, 'inject_page_schemas' ) );

        return array(
            'module_option_raw'  => $mod,
            'module_option_type' => gettype( $mod ),
            'module_active'      => ( $mod !== '0' && $mod !== 0 && $mod !== false ),
            'hook_global'        => $hooks_global !== false ? (int) $hooks_global : false,
            'hook_page'          => $hooks_page !== false   ? (int) $hooks_page   : false,
            'hooks_registered'   => ( $hooks_global !== false && $hooks_page !== false ),
        );
    }

    public function get_detected_schemas( $post_id ) {
        return get_post_meta( $post_id, '_hts_schemas_detected', true ) ?: array();
    }

    public function get_schema_stats() {
        $posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 50, 'meta_key' => '_hts_schemas_count', 'orderby' => 'meta_value_num', 'order' => 'DESC' ) );
        $stats = array( 'total_posts' => 0, 'article_count' => 0, 'faq_count' => 0, 'howto_count' => 0, 'video_count' => 0, 'itemlist_count' => 0, 'posts' => array() );
        foreach ( $posts as $p ) {
            $d = get_post_meta( $p->ID, '_hts_schemas_detected', true ) ?: array();
            $c = (int) get_post_meta( $p->ID, '_hts_schemas_count', true );
            if ( $c > 0 ) $stats['total_posts']++;
            if ( in_array( 'Article', $d ) ) $stats['article_count']++;
            if ( in_array( 'FAQPage', $d ) ) $stats['faq_count']++;
            if ( in_array( 'HowTo', $d ) ) $stats['howto_count']++;
            if ( in_array( 'VideoObject', $d ) ) $stats['video_count']++;
            if ( in_array( 'ItemList', $d ) ) $stats['itemlist_count']++;
            $stats['posts'][] = array( 'id' => $p->ID, 'title' => $p->post_title, 'schemas' => $d, 'count' => $c, 'edit_url' => get_edit_post_link( $p->ID, 'raw' ) );
        }
        return $stats;
    }
}
