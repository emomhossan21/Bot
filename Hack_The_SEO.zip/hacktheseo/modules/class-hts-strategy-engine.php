<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Strategy Engine — Phase 4b (Light)
 *
 * Pattern mining + propagation intelligente + plan mensuel.
 * Learns which action types work best on which article profiles,
 * then propagates successful patterns to similar untreated articles.
 *
 * Architecture:
 * - Strategy Ledger: table hts_strategy_patterns (persistent pattern storage)
 * - Pattern Mining: correlates action_type × article_profile → success rate
 * - Propagation: finds untreated articles matching successful patterns
 * - Monthly Plan: 4 weeks of prioritized actions based on confidence
 *
 * Light vs Full:
 * - No auto-execution (Light = user validates everything)
 * - No Content Doctor / GEO Score dependencies
 * - UX non-expert: plain French, why + how for every suggestion
 * - Simpler profile segmentation (length + category + age + traffic)
 *
 * @since 1.17.0
 * @depends HTS_Feedback_Loop (Phase 4a), HTS_Decision_Engine (Phase 3), HTS_Audit_Trail (Phase 3)
 */

class HTS_Strategy_Engine {

    const TABLE_SUFFIX      = 'hts_strategy_patterns';
    const TABLE_VERSION     = 1;
    const OPT_MONTHLY_PLAN  = 'hts_strategy_monthly_plan';
    const OPT_LAST_MINING   = 'hts_strategy_last_mining';
    const OPT_SETTINGS      = 'hts_strategy_settings';
    const MIN_ACTIONS_MINING = 20;
    const MIN_PATTERN_SAMPLE = 5;
    const CONFIDENCE_FLOOR   = 50; // Patterns below this are never proposed

    /* ──────────────────────────────────────────────
     *  INIT
     * ────────────────────────────────────────────── */

    public function init() {
        // Auto-create table on admin_init
        add_action( 'admin_init', array( __CLASS__, 'maybe_create_table' ) );

        // Run mining after Feedback Loop updates confidence (priority 30 = after FL at 10)
        add_action( 'hts_gsc_import_complete', array( $this, 'on_gsc_import' ), 30, 1 );

        // Weekly cron: regenerate monthly plan
        add_action( 'hts_strategy_weekly', array( $this, 'cron_weekly' ) );
        if ( ! wp_next_scheduled( 'hts_strategy_weekly' ) ) {
            // Schedule for Monday 3 AM
            $next_monday = strtotime( 'next monday 3:00:00' );
            wp_schedule_event( $next_monday, 'weekly', 'hts_strategy_weekly' );
        }

        // AJAX
        add_action( 'wp_ajax_hts_strategy_get_patterns',    array( $this, 'ajax_get_patterns' ) );
        add_action( 'wp_ajax_hts_strategy_get_plan',        array( $this, 'ajax_get_plan' ) );
        add_action( 'wp_ajax_hts_strategy_get_propagation', array( $this, 'ajax_get_propagation' ) );
        add_action( 'wp_ajax_hts_strategy_run_mining',      array( $this, 'ajax_run_mining' ) );
        add_action( 'wp_ajax_hts_strategy_validate_week',   array( $this, 'ajax_validate_week' ) );
        add_action( 'wp_ajax_hts_strategy_dismiss_prop',    array( $this, 'ajax_dismiss_propagation' ) );
        add_action( 'wp_ajax_hts_strategy_get_summary',     array( $this, 'ajax_get_summary' ) );
    }

    /* ──────────────────────────────────────────────
     *  TABLE CREATION — Strategy Ledger
     * ────────────────────────────────────────────── */

    /**
     * Auto-create or migrate table if needed.
     */
    public static function maybe_create_table() {
        $version_key    = 'hts_strategy_table_version';
        $stored_version = (int) get_option( $version_key, 0 );

        if ( $stored_version >= self::TABLE_VERSION ) return;

        global $wpdb;
        $table  = $wpdb->prefix . self::TABLE_SUFFIX;
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );

        if ( ! $exists ) {
            self::create_table();
        }

        update_option( $version_key, self::TABLE_VERSION, false );
    }

    /**
     * Create the hts_strategy_patterns table.
     *
     * Each row = one discovered pattern:
     *   action_type × profile_segment → confidence + avg_impact + sample_size
     */
    public static function create_table() {
        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE_SUFFIX;
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id              BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            action_type     VARCHAR(50)   NOT NULL DEFAULT '',
            profile_segment VARCHAR(100)  NOT NULL DEFAULT '',
            horizon         VARCHAR(10)   NOT NULL DEFAULT '30d',
            total_actions   INT           NOT NULL DEFAULT 0,
            positive        INT           NOT NULL DEFAULT 0,
            neutral         INT           NOT NULL DEFAULT 0,
            negative        INT           NOT NULL DEFAULT 0,
            confidence      DECIMAL(5,1)  NOT NULL DEFAULT 0.0,
            avg_position_delta DECIMAL(6,2) NOT NULL DEFAULT 0.0,
            avg_clicks_delta   DECIMAL(8,2) NOT NULL DEFAULT 0.0,
            status          VARCHAR(20)   NOT NULL DEFAULT 'observation',
            last_mined_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY idx_pattern (action_type, profile_segment, horizon),
            INDEX idx_confidence (confidence),
            INDEX idx_status (status)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /* ──────────────────────────────────────────────
     *  ARTICLE PROFILING
     * ────────────────────────────────────────────── */

    /**
     * Build a profile segment string for an article.
     * Segments: length (short/medium/long), age (fresh/recent/mature/old), traffic (none/low/medium/high)
     *
     * @param int $post_id
     * @return string e.g. "medium_mature_low"
     */
    public static function get_article_profile( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return 'unknown';

        // Length segment
        $content = wp_strip_all_tags( $post->post_content );
        $word_count = hts_word_count( $content );
        if ( $word_count < 500 ) {
            $length = 'short';
        } elseif ( $word_count < 1500 ) {
            $length = 'medium';
        } else {
            $length = 'long';
        }

        // Age segment
        $days_old = ( time() - get_post_time( 'U', false, $post_id ) ) / DAY_IN_SECONDS;
        if ( $days_old < 30 ) {
            $age = 'fresh';
        } elseif ( $days_old < 90 ) {
            $age = 'recent';
        } elseif ( $days_old < 365 ) {
            $age = 'mature';
        } else {
            $age = 'old';
        }

        // Traffic segment (based on GSC impressions)
        $impressions = (int) get_post_meta( $post_id, '_hts_gsc_impressions', true );
        if ( $impressions === 0 ) {
            $traffic = 'none';
        } elseif ( $impressions < 100 ) {
            $traffic = 'low';
        } elseif ( $impressions < 1000 ) {
            $traffic = 'medium';
        } else {
            $traffic = 'high';
        }

        return $length . '_' . $age . '_' . $traffic;
    }

    /**
     * Human-readable profile label.
     */
    public static function profile_label( $segment ) {
        $parts = explode( '_', $segment );
        if ( count( $parts ) < 3 ) return $segment;

        $length_map  = array( 'short' => 'Court', 'medium' => 'Moyen', 'long' => 'Long' );
        $age_map     = array( 'fresh' => 'Récent', 'recent' => '< 3 mois', 'mature' => '3-12 mois', 'old' => '> 1 an' );
        $traffic_map = array( 'none' => 'Sans trafic', 'low' => 'Peu de trafic', 'medium' => 'Trafic moyen', 'high' => 'Fort trafic' );

        return ( $length_map[ $parts[0] ] ?? $parts[0] )
             . ' · ' . ( $age_map[ $parts[1] ] ?? $parts[1] )
             . ' · ' . ( $traffic_map[ $parts[2] ] ?? $parts[2] );
    }

    /**
     * Human-readable action type label.
     */
    public static function action_label( $type ) {
        $labels = array(
            'link_outbound'     => 'Liens sortants',
            'link_inbound'      => 'Liens entrants',
            'link_sibling'      => 'Liens frères (cocon)',
            'link_cross_out'    => 'Liens cross-cocon sortants',
            'link_cross_in'     => 'Liens cross-cocon entrants',
            'link_manual'       => 'Liens manuels',
            'article_published' => 'Publications',
            'content_modified'  => 'Modifications contenu',
            'meta_auto_pilot'   => 'Metas optimisées',
            'optimize_meta'     => 'Optimisation meta',
            'fix_onpage'        => 'Correction On-Page',
            'add_internal_links'=> 'Maillage interne',
            'add_schema'        => 'Schema Markup',
            'create_redirect'   => 'Redirections 301',
        );
        return $labels[ $type ] ?? $type;
    }

    /* ──────────────────────────────────────────────
     *  PATTERN MINING — Core intelligence
     * ────────────────────────────────────────────── */

    /**
     * Triggered after GSC import (after Feedback Loop has updated impacts).
     * Throttled: max once per 24h.
     */
    public function on_gsc_import( $type = 'pages' ) {
        if ( $type !== 'pages' ) return;
        // FIX 4: sync hook (prio 5) already triggers SaaS mining — skip local
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            return;
        }
        $last = get_option( self::OPT_LAST_MINING, '' );
        if ( $last && strtotime( $last ) > strtotime( '-24 hours' ) ) return;

        $this->run_pattern_mining();
    }

    /**
     * Weekly cron: re-mine patterns + regenerate monthly plan.
     */
    public function cron_weekly() {
        if ( class_exists( 'HTS_Subscription' ) && HTS_Subscription::get_plan_tier() < 2 ) return;
        // P1 FIX: In remote mode, delegate to SaaS
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            HTS_Remote_Client::call( 'strategy/run-mining', array( 'lang' => $lang ) );
            return;
        }

        try {
        // Phase 5.6: guard anti-doublon — empêche le double-run si déjà en cours
        if ( get_transient( 'hts_strategy_running' ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Strategy cron_weekly ignoré — déjà en cours', 'info', 'strategy' );
            }
            return;
        }
        set_transient( 'hts_strategy_running', true, 600 ); // 10 min max

        $this->run_pattern_mining();
        $this->generate_monthly_plan();
        // Session K : orchestrer les propositions des agents Meta + Linking
        $this->orchestrate_proposals();

        delete_transient( 'hts_strategy_running' );
        } catch ( \Throwable $e ) {
            delete_transient( 'hts_strategy_running' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Strategy cron CRASH: ' . $e->getMessage() . ' L' . $e->getLine(), 'error', 'strategy' );
            }
        }
    }

    /**
     * Mine patterns from all measured actions in hts_actions.
     *
     * For each (action_type, profile_segment, horizon) combination:
     * - Count positive/neutral/negative outcomes
     * - Calculate confidence = positive / total × 100
     * - Calculate avg position delta and clicks delta
     * - Assign status: observation / fiable / mitige / inefficace
     */
    public function run_pattern_mining() {
        if ( ! class_exists( 'HTS_Audit_Trail' ) ) return;
        if ( ! class_exists( 'HTS_Feedback_Loop' ) ) return;

        global $wpdb;
        $actions_table = $wpdb->prefix . 'hts_actions';
        $pattern_table = $wpdb->prefix . self::TABLE_SUFFIX;

        // Ensure pattern table exists
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $pattern_table ) ) !== $pattern_table ) {
            self::create_table();
        }

        // Check minimum actions threshold
        $total_measured = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$actions_table}
             WHERE (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)"
        );

        if ( $total_measured < self::MIN_ACTIONS_MINING ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    'Strategy Engine : seulement ' . $total_measured . '/' . self::MIN_ACTIONS_MINING . ' actions mesurées — mining reporté.',
                    'info', 'strategy'
                );
            }
            return;
        }

        // Get all measured actions
        $actions = $wpdb->get_results(
            "SELECT id, action_type, post_id, impact_7d, impact_30d, created_at
             FROM {$actions_table}
             WHERE (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)
               AND action_type NOT IN ('rollback', 'test_diagnostic')
             ORDER BY created_at DESC",
            ARRAY_A
        );

        if ( empty( $actions ) ) return;

        // S18 FIX: Filter by current language to avoid mixing FR/EN patterns
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $se_lang = HTS_Language::get_current_lang();
            if ( $se_lang ) {
                $se_lang_args = array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => 'publish',
                    'posts_per_page' => -1,
                    'fields'         => 'ids',
                    'suppress_filters' => false,
                );
                $se_lang_args = HTS_Language::filter_query_args( $se_lang_args, $se_lang );
                $se_post_ids = get_posts( $se_lang_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $se_post_objects = array_map( 'get_post', $se_post_ids );
                    $se_post_objects = array_values( HTS_Language::filter_posts_by_lang( $se_post_objects, $se_lang ) );
                    $se_post_ids = wp_list_pluck( $se_post_objects, 'ID' );
                }
                if ( ! empty( $se_post_ids ) ) {
                    $actions = array_filter( $actions, function( $a ) use ( $se_post_ids ) {
                        return in_array( (int) $a['post_id'], $se_post_ids, true );
                    } );
                    $actions = array_values( $actions );
                }
            }
        }

        // Build patterns: [action_type][profile_segment][horizon] → stats
        $patterns = array();

        foreach ( $actions as $action ) {
            $type    = $action['action_type'];
            $post_id = absint( $action['post_id'] );
            $profile = self::get_article_profile( $post_id );

            // Process both horizons
            foreach ( array( '7d' => 'impact_7d', '30d' => 'impact_30d' ) as $horizon => $col ) {
                if ( empty( $action[ $col ] ) ) continue;

                $impact = json_decode( $action[ $col ], true );
                if ( empty( $impact ) ) continue;

                $key = $type . '|' . $profile . '|' . $horizon;
                if ( ! isset( $patterns[ $key ] ) ) {
                    $patterns[ $key ] = array(
                        'action_type'     => $type,
                        'profile_segment' => $profile,
                        'horizon'         => $horizon,
                        'total'           => 0,
                        'positive'        => 0,
                        'neutral'         => 0,
                        'negative'        => 0,
                        'sum_pos_delta'   => 0.0,
                        'sum_clk_delta'   => 0.0,
                    );
                }

                $p = &$patterns[ $key ];
                $p['total']++;
                $verdict = $impact['verdict'] ?? 'neutral';
                if ( $verdict === 'positive' ) $p['positive']++;
                elseif ( $verdict === 'negative' ) $p['negative']++;
                else $p['neutral']++;

                $p['sum_pos_delta'] += (float) ( $impact['position_delta'] ?? 0 );
                $p['sum_clk_delta'] += (float) ( $impact['clicks_delta'] ?? 0 );
            }
        }

        // Upsert patterns into the ledger
        $mined = 0;
        foreach ( $patterns as $p ) {
            $confidence = $p['total'] > 0 ? round( ( $p['positive'] / $p['total'] ) * 100, 1 ) : 0;
            $avg_pos    = $p['total'] > 0 ? round( $p['sum_pos_delta'] / $p['total'], 2 ) : 0;
            $avg_clk    = $p['total'] > 0 ? round( $p['sum_clk_delta'] / $p['total'], 2 ) : 0;

            // Status assignment
            if ( $p['total'] < self::MIN_PATTERN_SAMPLE ) {
                $status = 'observation';
            } elseif ( $confidence >= 60 ) {
                $status = 'fiable';
            } elseif ( $confidence >= self::CONFIDENCE_FLOOR ) {
                $status = 'mitige';
            } else {
                $status = 'inefficace';
            }

            // Upsert via REPLACE
            $wpdb->replace(
                $pattern_table,
                array(
                    'action_type'        => $p['action_type'],
                    'profile_segment'    => $p['profile_segment'],
                    'horizon'            => $p['horizon'],
                    'total_actions'      => $p['total'],
                    'positive'           => $p['positive'],
                    'neutral'            => $p['neutral'],
                    'negative'           => $p['negative'],
                    'confidence'         => $confidence,
                    'avg_position_delta' => $avg_pos,
                    'avg_clicks_delta'   => $avg_clk,
                    'status'             => $status,
                    'last_mined_at'      => current_time( 'mysql' ),
                ),
                array( '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%f', '%f', '%f', '%s', '%s' )
            );
            $mined++;
        }

        update_option( self::OPT_LAST_MINING, current_time( 'mysql' ), false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                '🧠 Strategy Engine : ' . $mined . ' pattern(s) miné(s) à partir de ' . count( $actions ) . ' actions mesurées.',
                'info', 'strategy'
            );
        }

        return $mined;
    }

    /* ──────────────────────────────────────────────
     *  PATTERN QUERIES
     * ────────────────────────────────────────────── */

    /**
     * Get all patterns from the ledger.
     *
     * @param string $status_filter Optional: 'fiable', 'mitige', 'observation', 'inefficace'
     * @return array
     */
    public static function get_patterns( $status_filter = '' ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return array();

        $where = '';
        if ( ! empty( $status_filter ) ) {
            $where = $wpdb->prepare( " WHERE status = %s", $status_filter );
        }

        return $wpdb->get_results(
            "SELECT * FROM {$table}{$where} ORDER BY confidence DESC, total_actions DESC",
            ARRAY_A
        );
    }

    /**
     * Get evergreen patterns: reliable at both 7d AND 30d horizons.
     */
    public static function get_evergreen_patterns() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return array();

        // Find action_type + profile_segment combos that are 'fiable' at both horizons
        return $wpdb->get_results(
            "SELECT p7.action_type, p7.profile_segment,
                    p7.confidence AS conf_7d, p30.confidence AS conf_30d,
                    p7.total_actions AS total_7d, p30.total_actions AS total_30d,
                    p30.avg_position_delta, p30.avg_clicks_delta
             FROM {$table} p7
             INNER JOIN {$table} p30
                ON p7.action_type = p30.action_type
                AND p7.profile_segment = p30.profile_segment
             WHERE p7.horizon = '7d' AND p30.horizon = '30d'
               AND p7.status = 'fiable' AND p30.status = 'fiable'
             ORDER BY p30.confidence DESC",
            ARRAY_A
        );
    }

    /**
     * Get pattern confidence for a specific action on a specific post.
     * Used by Decision Engine to adjust priorities.
     *
     * @param string $action_type
     * @param int    $post_id
     * @return array|null {confidence, status, sample_size, avg_position_delta}
     */
    public static function get_pattern_for_post( $action_type, $post_id ) {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'strategy/patterns', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data']['patterns'] ) ) {
                foreach ( $result['data']['patterns'] as $p ) {
                    if ( isset( $p['action_type'] ) && $p['action_type'] === $action_type ) {
                        return $p;
                    }
                }
            }
            return null;
        }
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return null;

        $profile = self::get_article_profile( $post_id );

        // Prefer 30d pattern, fallback to 7d
        $pattern = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table}
             WHERE action_type = %s AND profile_segment = %s AND horizon = '30d'",
            $action_type, $profile
        ), ARRAY_A );

        if ( ! $pattern ) {
            $pattern = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$table}
                 WHERE action_type = %s AND profile_segment = %s AND horizon = '7d'",
                $action_type, $profile
            ), ARRAY_A );
        }

        if ( ! $pattern ) return null;

        return array(
            'confidence'         => (float) $pattern['confidence'],
            'status'             => $pattern['status'],
            'sample_size'        => (int) $pattern['total_actions'],
            'avg_position_delta' => (float) $pattern['avg_position_delta'],
            'avg_clicks_delta'   => (float) $pattern['avg_clicks_delta'],
            'horizon'            => $pattern['horizon'],
            'profile'            => $profile,
            'profile_label'      => self::profile_label( $profile ),
        );
    }

    /* ──────────────────────────────────────────────
     *  PROPAGATION — Find untreated articles for proven patterns
     * ────────────────────────────────────────────── */

    /**
     * For a given reliable pattern, find articles that match the profile
     * but haven't been treated with that action type yet.
     *
     * @param string $action_type
     * @param string $profile_segment
     * @param int    $limit
     * @return array of post data
     */
    public static function find_propagation_candidates( $action_type, $profile_segment, $limit = 50 ) {
        global $wpdb;
        $actions_table = $wpdb->prefix . 'hts_actions';

        // Get all post IDs already treated with this action type
        $treated = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$actions_table} WHERE action_type = %s",
            $action_type
        ) );

        // Get all published posts
        $args = array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => 200,
            'fields'         => 'ids',
        );
        if ( ! empty( $treated ) ) {
            $args['post__not_in'] = $treated;
        }
        $candidates = get_posts( $args );

        // Filter by profile match
        $matches = array();
        foreach ( $candidates as $pid ) {
            $profile = self::get_article_profile( $pid );
            if ( $profile === $profile_segment ) {
                $matches[] = array(
                    'post_id'     => $pid,
                    'title'       => get_the_title( $pid ),
                    'profile'     => $profile,
                    'position'    => (float) get_post_meta( $pid, '_hts_gsc_position', true ),
                    'impressions' => (int) get_post_meta( $pid, '_hts_gsc_impressions', true ),
                    'meta_score'  => (int) get_post_meta( $pid, '_hts_meta_score', true ),
                    'onpage_score'=> (int) get_post_meta( $pid, '_hts_onpage_score', true ),
                );
                if ( count( $matches ) >= $limit ) break;
            }
        }

        // Sort by impressions desc (highest potential first)
        usort( $matches, function( $a, $b ) { return $b['impressions'] <=> $a['impressions']; } );

        return $matches;
    }

    /**
     * Get all propagation opportunities: reliable patterns with untreated articles.
     *
     * @return array of propagation groups
     */
    public static function get_propagation_opportunities() {
        $reliable = self::get_patterns( 'fiable' );
        if ( empty( $reliable ) ) return array();

        // Deduplicate: keep best horizon per (action_type, profile_segment)
        $best = array();
        foreach ( $reliable as $p ) {
            $key = $p['action_type'] . '|' . $p['profile_segment'];
            if ( ! isset( $best[ $key ] ) || $p['horizon'] === '30d' ) {
                $best[ $key ] = $p;
            }
        }

        $opportunities = array();
        foreach ( $best as $pattern ) {
            $candidates = self::find_propagation_candidates(
                $pattern['action_type'],
                $pattern['profile_segment'],
                50
            );

            if ( empty( $candidates ) ) continue;

            $opportunities[] = array(
                'pattern'     => $pattern,
                'action_type' => $pattern['action_type'],
                'action_label'=> self::action_label( $pattern['action_type'] ),
                'profile'     => $pattern['profile_segment'],
                'profile_label' => self::profile_label( $pattern['profile_segment'] ),
                'confidence'  => (float) $pattern['confidence'],
                'avg_impact'  => round( (float) $pattern['avg_position_delta'], 1 ),
                'sample_size' => (int) $pattern['total_actions'],
                'candidates'  => $candidates,
                'total_eligible' => count( $candidates ),
                // UX non-expert
                'why'         => sprintf(
                    'Ce type de modification a fonctionné dans %s%% des cas sur des articles similaires (%d tests).',
                    round( $pattern['confidence'] ),
                    $pattern['total_actions']
                ),
                'how'         => sprintf(
                    '%d article(s) éligible(s) n\'ont pas encore bénéficié de cette optimisation.',
                    count( $candidates )
                ),
            );
        }

        // Sort by confidence × total eligible
        usort( $opportunities, function( $a, $b ) {
            $score_a = $a['confidence'] * $a['total_eligible'];
            $score_b = $b['confidence'] * $b['total_eligible'];
            return $score_b <=> $score_a;
        } );

        return $opportunities;
    }

    /* ──────────────────────────────────────────────
     *  MONTHLY PLAN — 4 weeks of prioritized actions
     * ────────────────────────────────────────────── */

    /**
     * Generate a 4-week action plan based on pattern confidence and article opportunities.
     * Each week is independently validatable.
     *
     * @return array Plan with 4 weeks
     */
    public function generate_monthly_plan() {
        $opportunities = self::get_propagation_opportunities();
        $pending_recs  = array();

        // Also include Decision Engine recommendations if available
        if ( class_exists( 'HTS_Decision_Engine' ) ) {
            $pending_recs = HTS_Decision_Engine::get_pending_recommendations();
        }

        // Merge all actionable items
        $all_items = array();

        // From propagation opportunities: unpack candidates
        foreach ( $opportunities as $opp ) {
            foreach ( array_slice( $opp['candidates'], 0, 20 ) as $candidate ) {
                $pattern_info = self::get_pattern_for_post( $opp['action_type'], $candidate['post_id'] );
                $conf = $pattern_info ? $pattern_info['confidence'] : $opp['confidence'];

                $all_items[] = array(
                    'source'       => 'strategy',
                    'post_id'      => $candidate['post_id'],
                    'title'        => $candidate['title'],
                    'action_type'  => $opp['action_type'],
                    'action_label' => $opp['action_label'],
                    'confidence'   => $conf,
                    'impact_est'   => abs( $opp['avg_impact'] ),
                    'priority'     => $conf * abs( $opp['avg_impact'] + 1 ),
                    'why'          => $opp['why'],
                    'how'          => 'Ouvrez l\'article et appliquez la correction depuis le panneau SEO.',
                    'profile'      => $opp['profile'],
                    'profile_label'=> $opp['profile_label'],
                );
            }
        }

        // From Decision Engine pending recommendations
        foreach ( $pending_recs as $rec ) {
            $post_id = $rec['action_data']['post_id'] ?? 0;
            $pattern_info = $post_id ? self::get_pattern_for_post( $rec['type'] ?? '', $post_id ) : null;
            $conf = $pattern_info ? $pattern_info['confidence'] : 50; // default

            $all_items[] = array(
                'source'       => 'decision_engine',
                'post_id'      => $post_id,
                'title'        => $post_id ? get_the_title( $post_id ) : ( $rec['title'] ?? '' ),
                'action_type'  => $rec['type'] ?? 'unknown',
                'action_label' => self::action_label( $rec['type'] ?? '' ),
                'confidence'   => $conf,
                'impact_est'   => $rec['priority'] ?? 50,
                'priority'     => ( $rec['priority'] ?? 50 ) * ( $conf / 100 ),
                'why'          => $rec['why'] ?? '',
                'how'          => $rec['how'] ?? '',
                'profile'      => $post_id ? self::get_article_profile( $post_id ) : '',
                'profile_label'=> $post_id ? self::profile_label( self::get_article_profile( $post_id ) ) : '',
                'rec_id'       => $rec['id'] ?? '',
            );
        }

        // Sort by priority desc
        usort( $all_items, function( $a, $b ) { return $b['priority'] <=> $a['priority']; } );

        // Distribute into 4 weeks (round-robin by type for variety)
        $weeks = array(
            1 => array( 'items' => array(), 'status' => 'pending', 'validated_at' => null ),
            2 => array( 'items' => array(), 'status' => 'pending', 'validated_at' => null ),
            3 => array( 'items' => array(), 'status' => 'pending', 'validated_at' => null ),
            4 => array( 'items' => array(), 'status' => 'pending', 'validated_at' => null ),
        );

        $max_per_week = 15;
        $week_num = 1;

        foreach ( $all_items as $item ) {
            // Skip if all weeks full
            if ( $weeks[1]['items'] && count( $weeks[1]['items'] ) >= $max_per_week &&
                 $weeks[2]['items'] && count( $weeks[2]['items'] ) >= $max_per_week &&
                 $weeks[3]['items'] && count( $weeks[3]['items'] ) >= $max_per_week &&
                 $weeks[4]['items'] && count( $weeks[4]['items'] ) >= $max_per_week ) {
                break;
            }

            // Find next week with space, starting from preferred
            for ( $i = 0; $i < 4; $i++ ) {
                $w = ( ( $week_num - 1 + $i ) % 4 ) + 1;
                if ( count( $weeks[ $w ]['items'] ) < $max_per_week ) {
                    $weeks[ $w ]['items'][] = $item;
                    $week_num = ( $w % 4 ) + 1;
                    break;
                }
            }
        }

        // Build final plan
        $plan = array(
            'generated_at' => current_time( 'mysql' ),
            'total_items'  => count( $all_items ),
            'planned_items'=> array_sum( array_map( function( $w ) { return count( $w['items'] ); }, $weeks ) ),
            'weeks'        => $weeks,
            'patterns_used'=> count( $opportunities ),
        );

        // Preserve validated weeks from existing plan
        $existing_plan = get_option( self::OPT_MONTHLY_PLAN, null );
        if ( $existing_plan && ! empty( $existing_plan['weeks'] ) ) {
            foreach ( $existing_plan['weeks'] as $wn => $ew ) {
                if ( ( $ew['status'] ?? '' ) === 'validated' && isset( $plan['weeks'][ $wn ] ) ) {
                    $plan['weeks'][ $wn ]['status']       = 'validated';
                    $plan['weeks'][ $wn ]['validated_at']  = $ew['validated_at'] ?? null;
                }
            }
        }

        update_option( self::OPT_MONTHLY_PLAN, $plan, false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                '📅 Strategy Engine : plan mensuel généré — ' . $plan['planned_items'] . ' actions sur 4 semaines.',
                'info', 'strategy'
            );
        }

        return $plan;
    }

    /**
     * Get the current monthly plan.
     */
    public static function get_monthly_plan() {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'strategy/plan', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data'] ) ) {
                return $result['data'];
            }
        }
        return get_option( self::OPT_MONTHLY_PLAN, null );
    }

    /* ──────────────────────────────────────────────
     *  DECISION ENGINE INTEGRATION
     * ────────────────────────────────────────────── */

    /**
     * Adjust a recommendation priority based on Strategy patterns.
     * Called by Decision Engine to enrich its scoring.
     *
     * @param array $rec   A recommendation from Decision Engine
     * @return array        Enriched recommendation with strategy_confidence
     */
    public static function enrich_recommendation( $rec ) {
        $post_id     = $rec['action_data']['post_id'] ?? 0;
        $action_type = $rec['type'] ?? '';

        if ( ! $post_id || ! $action_type ) return $rec;

        $pattern = self::get_pattern_for_post( $action_type, $post_id );

        if ( $pattern ) {
            $rec['strategy_confidence'] = $pattern['confidence'];
            $rec['strategy_status']     = $pattern['status'];
            $rec['strategy_sample']     = $pattern['sample_size'];
            $rec['strategy_profile']    = $pattern['profile_label'];

            // Adjust priority: multiply by confidence factor (0.5 to 1.5)
            $factor = 0.5 + ( $pattern['confidence'] / 100 );
            $rec['priority'] = round( ( $rec['priority'] ?? 50 ) * $factor );

            // UX: add strategy explanation
            if ( $pattern['status'] === 'fiable' ) {
                $rec['strategy_note'] = sprintf(
                    'Ce type de correction a fonctionné %s%% du temps sur des articles similaires.',
                    round( $pattern['confidence'] )
                );
            } elseif ( $pattern['status'] === 'inefficace' ) {
                $rec['strategy_note'] = 'Ce type de correction a rarement fonctionné sur des articles similaires. Priorité réduite.';
            }
        }

        return $rec;
    }

    /* ──────────────────────────────────────────────
     *  SUMMARY — Dashboard data
     * ────────────────────────────────────────────── */

    /**
     * Get a summary for the Cockpit.
     */
    public static function get_summary() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            return null;
        }

        $total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $fiable   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'fiable'" );
        $mitige   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'mitige'" );
        $inefficace = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'inefficace'" );
        $observation = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'observation'" );

        $best = $wpdb->get_row(
            "SELECT action_type, profile_segment, confidence, avg_position_delta, total_actions
             FROM {$table} WHERE status = 'fiable' ORDER BY confidence DESC LIMIT 1",
            ARRAY_A
        );

        $plan = self::get_monthly_plan();
        $plan_items = $plan ? ( $plan['planned_items'] ?? 0 ) : 0;
        $plan_weeks_done = 0;
        if ( $plan && ! empty( $plan['weeks'] ) ) {
            foreach ( $plan['weeks'] as $w ) {
                if ( ( $w['status'] ?? '' ) === 'validated' ) $plan_weeks_done++;
            }
        }

        $last_mining = get_option( self::OPT_LAST_MINING, '' );

        return array(
            'total_patterns'   => $total,
            'fiable'           => $fiable,
            'mitige'           => $mitige,
            'inefficace'       => $inefficace,
            'observation'      => $observation,
            'best_pattern'     => $best ? array(
                'action'     => self::action_label( $best['action_type'] ),
                'profile'    => self::profile_label( $best['profile_segment'] ),
                'confidence' => round( (float) $best['confidence'] ),
                'sample'     => (int) $best['total_actions'],
                'avg_impact' => round( (float) $best['avg_position_delta'], 1 ),
            ) : null,
            'plan_items'       => $plan_items,
            'plan_weeks_done'  => $plan_weeks_done,
            'last_mining'      => $last_mining,
            'mining_ready'     => self::is_mining_ready(),
        );
    }

    /**
     * Check if there are enough measured actions for mining.
     */
    public static function is_mining_ready() {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return false;

        $count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)"
        );
        return $count >= self::MIN_ACTIONS_MINING;
    }

    /* ──────────────────────────────────────────────
     *  AJAX HANDLERS
     * ────────────────────────────────────────────── */

    public function ajax_get_patterns() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'strategy/patterns', array(
                'lang'   => $lang,
                'status' => isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : '',
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/patterns failed, fallback local', 'warning', 'remote' );
            }
        }

        $status  = sanitize_text_field( $_POST['status'] ?? '' );
        $patterns = self::get_patterns( $status );

        // Enrich with labels
        foreach ( $patterns as &$p ) {
            $p['action_label']  = self::action_label( $p['action_type'] );
            $p['profile_label'] = self::profile_label( $p['profile_segment'] );
        }

        $evergreen = self::get_evergreen_patterns();
        foreach ( $evergreen as &$e ) {
            $e['action_label']  = self::action_label( $e['action_type'] );
            $e['profile_label'] = self::profile_label( $e['profile_segment'] );
        }

        wp_send_json_success( array(
            'patterns'  => $patterns,
            'evergreen' => $evergreen,
            'total'     => count( $patterns ),
        ) );
    }

    public function ajax_get_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'strategy/plan', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/plan failed, fallback local', 'warning', 'remote' );
            }
        }

        $plan = self::get_monthly_plan();
        if ( ! $plan ) {
            wp_send_json_success( array( 'plan' => null, 'message' => 'Aucun plan disponible. Le mining doit être exécuté.' ) );
            return;
        }

        wp_send_json_success( array( 'plan' => $plan ) );
    }

    public function ajax_get_propagation() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'strategy/propagation', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/propagation failed, fallback local', 'warning', 'remote' );
            }
        }

        $opps = self::get_propagation_opportunities();

        wp_send_json_success( array(
            'opportunities' => $opps,
            'total'         => count( $opps ),
        ) );
    }

    public function ajax_run_mining() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'strategy/run-mining', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // P4 FIX: No fallback for write operations — return error instead
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/run-mining failed, no fallback (write op)', 'warning', 'remote' );
            }
            wp_send_json_error( array( 'message' => 'Le service est temporairement indisponible. Réessayez dans quelques minutes.' ) );
        }

        $mined = $this->run_pattern_mining();
        if ( $mined === null ) {
            // Get current count for informative message
            global $wpdb;
            $table = $wpdb->prefix . 'hts_actions';
            $count = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$table} WHERE (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)"
            );
            wp_send_json_success( array(
                'message' => 'Pas assez de données (' . $count . '/' . self::MIN_ACTIONS_MINING . ' actions mesurées). Le mining sera lancé automatiquement quand le seuil sera atteint.',
                'mined'   => 0,
                'ready'   => false,
            ) );
            return;
        }

        // Also regenerate plan
        $plan = $this->generate_monthly_plan();

        wp_send_json_success( array(
            'message' => $mined . ' pattern(s) analysé(s). Plan mensuel mis à jour.',
            'mined'   => $mined,
            'ready'   => true,
            'plan'    => $plan,
        ) );
    }

    public function ajax_validate_week() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $action_ids = isset( $_POST['action_ids'] ) ? array_map( 'absint', (array) $_POST['action_ids'] ) : array();
            $result = HTS_Remote_Client::call( 'strategy/validate-week', array(
                'lang'       => $lang,
                'week'       => isset( $_POST['week'] ) ? absint( $_POST['week'] ) : 0,
                'action_ids' => $action_ids,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // P4 FIX: No fallback for write operations — return error instead
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/validate-week failed, no fallback (write op)', 'warning', 'remote' );
            }
            wp_send_json_error( array( 'message' => 'Le service est temporairement indisponible. Réessayez dans quelques minutes.' ) );
        }

        $week = absint( $_POST['week'] ?? 0 );
        if ( $week < 1 || $week > 4 ) wp_send_json_error( 'Semaine invalide (1-4).' );

        $plan = get_option( self::OPT_MONTHLY_PLAN, null );
        if ( ! $plan || ! isset( $plan['weeks'][ $week ] ) ) {
            wp_send_json_error( 'Plan ou semaine introuvable.' );
        }

        $plan['weeks'][ $week ]['status']       = 'validated';
        $plan['weeks'][ $week ]['validated_at']  = current_time( 'mysql' );
        update_option( self::OPT_MONTHLY_PLAN, $plan, false );

        $items_count = count( $plan['weeks'][ $week ]['items'] );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                'Strategy Engine : semaine ' . $week . ' validée (' . $items_count . ' actions).',
                'success', 'strategy'
            );
        }

        wp_send_json_success( array(
            'message' => 'Semaine ' . $week . ' validée — ' . $items_count . ' actions à traiter.',
            'week'    => $week,
        ) );
    }

    public function ajax_dismiss_propagation() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'strategy/propagation', array(
                'lang'    => $lang,
                'dismiss' => true,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // P4 FIX: No fallback for write operations — return error instead
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/propagation (dismiss) failed, no fallback (write op)', 'warning', 'remote' );
            }
            wp_send_json_error( array( 'message' => 'Le service est temporairement indisponible. Réessayez dans quelques minutes.' ) );
        }

        // Dismiss is informational only (no persistence needed for now, pattern remains)
        wp_send_json_success( array( 'message' => 'Suggestion masquée.' ) );
    }

    public function ajax_get_summary() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'strategy/summary', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote strategy/summary failed, fallback local', 'warning', 'remote' );
            }
        }

        $summary = self::get_summary();
        wp_send_json_success( $summary );
    }

    /* ═══════════════════════════════════════════════════
     *  SESSION K — ORCHESTRATION INBOX
     * ═══════════════════════════════════════════════════ */

    /**
     * Orchestrer les propositions : appeler Meta Score et Internal Linking
     * pour générer des propositions priorisées dans l\'Inbox.
     *
     * Le Strategy Engine agit comme coordinateur : il déclenche les scans
     * des autres agents et ajoute un score de confiance basé sur les patterns.
     *
     * @since 2.4.7
     */
    public function orchestrate_proposals() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return;
        if ( ! HTS_Workflow_Engine::is_agent_enabled( 'strategy' ) ) return;

        $total = 0;

        // ── 1. Déclencher Meta Score si actif ──
        if ( class_exists( 'HTS_Meta_Score' ) && HTS_Workflow_Engine::is_agent_enabled( 'meta' ) ) {
            $meta = new HTS_Meta_Score();
            if ( method_exists( $meta, 'cron_scan_meta' ) ) {
                $meta->cron_scan_meta();
            }
        }

        // ── 2. Déclencher Internal Linking si actif ──
        if ( class_exists( 'HTS_Internal_Linking' ) && HTS_Workflow_Engine::is_agent_enabled( 'linking' ) ) {
            $linker = new HTS_Internal_Linking();
            if ( method_exists( $linker, 'cron_scan_linking' ) ) {
                $linker->cron_scan_linking();
            }
        }

        // ── 3. Proposer les opportunités de propagation ──
        $total += $this->propose_propagation_to_inbox();

        if ( $total > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Strategy Engine : {$total} proposition(s) de propagation créée(s)", 'info', 'strategy' );
        }
    }

    /**
     * Convertir les opportunités de propagation en propositions Inbox.
     *
     * Utilise les patterns fiables pour proposer des actions concrètes
     * sur des articles éligibles, avec score de confiance.
     *
     * @since 2.4.7
     * @return int Nombre de propositions créées
     */
    public function propose_propagation_to_inbox() {
        $opportunities = self::get_propagation_opportunities();
        if ( empty( $opportunities ) ) return 0;

        $count = 0;
        foreach ( $opportunities as $opp ) {
            // Max 5 propositions par pattern
            $candidates = array_slice( $opp['candidates'] ?? array(), 0, 5 );

            foreach ( $candidates as $candidate ) {
                $post_id = $candidate['post_id'] ?? 0;
                if ( $post_id <= 0 ) continue;

                $confidence = round( (float) ( $opp['confidence'] ?? 50 ) );
                $impact     = abs( round( (float) ( $opp['avg_impact'] ?? 0 ), 1 ) );

                $why = sprintf(
                    'Stratégie recommandée (confiance %d%%) : %s. Ce type de modification a amélioré les positions de %s place(s) en moyenne sur des articles similaires (%d tests).',
                    $confidence,
                    $opp['action_label'] ?? $opp['action_type'] ?? 'optimisation',
                    $impact > 0 ? $impact : '?',
                    (int) ( $opp['sample_size'] ?? 0 )
                );

                $action_type = $opp['action_type'] ?? 'geo_optimize';
                $priority    = $confidence >= 80 ? 'high' : ( $confidence >= 60 ? 'medium' : 'low' );

                $action_id = HTS_Workflow_Engine::propose(
                    'strategy',
                    $action_type,
                    $post_id,
                    array(
                        'reason'        => $why,
                        'confidence'    => $confidence,
                        'avg_impact'    => $impact,
                        'sample_size'   => (int) ( $opp['sample_size'] ?? 0 ),
                        'profile'       => $opp['profile'] ?? '',
                        'profile_label' => $opp['profile_label'] ?? '',
                        'source'        => 'strategy_propagation',
                    ),
                    $priority
                );

                if ( $action_id ) $count++;
                if ( $count >= 20 ) return $count; // Garde-fou global
            }
        }

        return $count;
    }
}
