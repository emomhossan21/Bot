<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Health Check — Monitoring automatique, circuit breaker & auto-repair.
 *
 * Fonctionnalités :
 *  - 15+ tests automatisés couvrant tous les modules critiques
 *  - Circuit breaker : auto-désactive les modules cassés pour les visiteurs
 *  - Auto-repair : corrections connues (flush cache, regen sitemap, etc.)
 *  - Cron : exécution toutes les 6h, alertes email en cas de problème
 *  - Historique : 30 derniers runs conservés
 *  - Score santé 0-100% avec pastilles vert/orange/rouge
 *  - Admin UI : section dédiée dans le Cockpit
 *
 * Adaptation Light vs Full :
 *  - Pas de webhook (trop complexe pour clients non-experts)
 *  - Messages en français clair, pas de jargon
 *  - Auto-repair conservateur (jamais destructif)
 *  - Circuit breaker = visiteurs seulement (admin voit tout pour diagnostiquer)
 *
 * @package HackTheSEO_Light
 * @since   1.18.0
 */

class HTS_Health_Check {

    /* ══════════════════════════════════════════════════
     *  CONSTANTS
     * ══════════════════════════════════════════════════ */

    const OPTION_RESULTS    = 'hts_health_results';
    const OPTION_HISTORY    = 'hts_health_history';
    const OPTION_BREAKER    = 'hts_circuit_breaker';
    const OPTION_CONFIG     = 'hts_health_config';
    const CRON_HOOK         = 'hts_health_cron';
    const MAX_HISTORY       = 30;
    const BREAKER_THRESHOLD = 3; // échecs consécutifs avant auto-disable

    /* ══════════════════════════════════════════════════
     *  INIT
     * ══════════════════════════════════════════════════ */

    public function init() {
        // Custom cron interval MUST be registered before scheduling
        add_filter( 'cron_schedules', array( $this, 'register_cron_interval' ) );

        // AJAX endpoints
        add_action( 'wp_ajax_hts_health_run_all',       array( $this, 'ajax_run_all' ) );
        add_action( 'wp_ajax_hts_health_run_single',    array( $this, 'ajax_run_single' ) );
        add_action( 'wp_ajax_hts_health_get_status',    array( $this, 'ajax_get_status' ) );
        add_action( 'wp_ajax_hts_health_repair',        array( $this, 'ajax_repair' ) );
        add_action( 'wp_ajax_hts_health_reset_breaker', array( $this, 'ajax_reset_breaker' ) );
        add_action( 'wp_ajax_hts_health_save_config',   array( $this, 'ajax_save_config' ) );
        add_action( 'wp_ajax_hts_health_send_report',  array( $this, 'ajax_send_report' ) );

        // Cron — uses 'hts_every_6h' interval (shared with Sitemap)
        add_action( self::CRON_HOOK, array( $this, 'cron_run' ) );
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 300, 'hts_every_6h', self::CRON_HOOK );
        }

        // Initialize circuit breaker option if not exists
        if ( get_option( self::OPTION_BREAKER ) === false ) {
            update_option( self::OPTION_BREAKER, array(), false );
        }
    }

    /**
     * Register 6h cron interval (re-uses hts_every_6h if already registered by Sitemap).
     */
    public function register_cron_interval( $schedules ) {
        if ( ! isset( $schedules['hts_every_6h'] ) ) {
            $schedules['hts_every_6h'] = array(
                'interval' => 6 * HOUR_IN_SECONDS,
                'display'  => 'Toutes les 6 heures (Hack The SEO)',
            );
        }
        return $schedules;
    }

    /* ══════════════════════════════════════════════════
     *  TEST REGISTRY — tous les tests disponibles
     * ══════════════════════════════════════════════════ */

    /**
     * @return array [ key => [ name, group, module, has_repair, description ] ]
     */
    public static function get_tests() {
        return array(

            // ── Infrastructure ──
            'content_extractor' => array(
                'name'        => 'Extracteur de contenu',
                'group'       => 'infrastructure',
                'module'      => 'HTS_Content_Extractor',
                'has_repair'  => true,
                'description' => 'Vérifie que le contenu des articles est correctement extrait (Gutenberg, Elementor, Divi...)',
            ),
            'cache_system' => array(
                'name'        => 'Système de cache',
                'group'       => 'infrastructure',
                'module'      => 'HTS_Content_Extractor',
                'has_repair'  => true,
                'description' => 'Vérifie que le cache WordPress (transients) fonctionne correctement',
            ),
            'ai_api' => array(
                'name'        => 'Connexion IA',
                'group'       => 'infrastructure',
                'module'      => null,
                'has_repair'  => false,
                'description' => 'Vérifie que les clés API IA sont configurées (OpenAI pour Meta/Liens, Anthropic pour le Coach)',
            ),

            // ── SEO Technique ──
            'sitemap_xml' => array(
                'name'        => 'Sitemap XML',
                'group'       => 'seo_technique',
                'module'      => 'HTS_Sitemap',
                'has_repair'  => true,
                'description' => 'Vérifie que le sitemap est accessible et contient du XML valide',
            ),
            'schema_jsonld' => array(
                'name'        => 'Schema JSON-LD',
                'group'       => 'seo_technique',
                'module'      => 'HTS_Schema_Markup',
                'has_repair'  => false,
                'description' => 'Vérifie que les données structurées sont présentes sur les articles',
            ),
            'meta_tags' => array(
                'name'        => 'Balises meta (title & description)',
                'group'       => 'seo_technique',
                'module'      => 'HTS_Meta_Tags',
                'has_repair'  => false,
                'description' => 'Vérifie la couverture des meta titles et descriptions',
            ),
            'redirects' => array(
                'name'        => 'Redirections',
                'group'       => 'seo_technique',
                'module'      => 'HTS_Redirects',
                'has_repair'  => false,
                'description' => 'Vérifie qu\'il n\'y a pas de boucles de redirection',
            ),
            'robots_meta' => array(
                'name'        => 'Robots meta (indexation)',
                'group'       => 'seo_technique',
                'module'      => 'HTS_Robots',
                'has_repair'  => false,
                'description' => 'Vérifie qu\'un trop grand nombre de pages ne sont pas en noindex',
            ),
            'canonical' => array(
                'name'        => 'URLs canoniques',
                'group'       => 'seo_technique',
                'module'      => 'HTS_Canonical',
                'has_repair'  => false,
                'description' => 'Vérifie que les URLs canoniques sont valides',
            ),
            'html_fingerprints' => array(
                'name'        => 'Empreintes HTML (doublons)',
                'group'       => 'seo_technique',
                'module'      => null,
                'has_repair'  => false,
                'description' => 'Vérifie qu\'il n\'y a pas de balises en double (title, canonical, OG...)',
            ),

            // ── Intelligence SEO ──
            'meta_score' => array(
                'name'        => 'Score Meta IA',
                'group'       => 'intelligence',
                'module'      => 'HTS_Meta_Score',
                'has_repair'  => true,
                'description' => 'Vérifie que le scoring des metas fonctionne et retourne des résultats cohérents',
            ),
            'onpage_score' => array(
                'name'        => 'Score On-Page',
                'group'       => 'intelligence',
                'module'      => 'HTS_On_Page_Score',
                'has_repair'  => true,
                'description' => 'Vérifie que le scoring du contenu fonctionne correctement',
            ),
            'embeddings' => array(
                'name'        => 'Embeddings sémantiques',
                'group'       => 'intelligence',
                'module'      => 'HTS_Embeddings',
                'has_repair'  => true,
                'description' => 'Vérifie que la table d\'embeddings existe et contient des données',
            ),
            'decision_engine' => array(
                'name'        => 'Moteur de décision',
                'group'       => 'intelligence',
                'module'      => 'HTS_Decision_Engine',
                'has_repair'  => false,
                'description' => 'Vérifie que le système de recommandations fonctionne',
            ),
            'feedback_loop' => array(
                'name'        => 'Boucle de mesure (GSC)',
                'group'       => 'intelligence',
                'module'      => 'HTS_Feedback_Loop',
                'has_repair'  => false,
                'description' => 'Vérifie la connexion GSC et la capacité de mesurer l\'impact des actions',
            ),
            'cocon_commander' => array(
                'name'        => 'Cocon Commander',
                'group'       => 'intelligence',
                'module'      => 'HTS_Cocon_Commander',
                'has_repair'  => false,
                'description' => 'Vérifie que le système de plans cocon fonctionne : réception, pre-check doublons, commande d\'articles',
            ),
            'editorial_calendar' => array(
                'name'        => 'Calendrier éditorial',
                'group'       => 'intelligence',
                'module'      => 'HTS_Cocon_Commander',
                'has_repair'  => false,
                'description' => 'Vérifie que le calendrier éditorial fonctionne : planification, priorités, auto-linking frères',
            ),
            'cannibalization' => array(
                'name'        => 'Cannibalisation',
                'group'       => 'intelligence',
                'module'      => 'HTS_Cannibalization',
                'has_repair'  => false,
                'description' => 'Vérifie que la détection de cannibalisation fonctionne : embeddings, keywords, titres',
            ),
        );
    }

    /**
     * Group labels for display (French, non-expert).
     */
    public static function get_group_labels() {
        return array(
            'infrastructure'  => 'Infrastructure',
            'seo_technique'   => 'SEO Technique',
            'intelligence'    => 'Intelligence SEO',
        );
    }

    /* ══════════════════════════════════════════════════
     *  INDIVIDUAL TESTS
     * ══════════════════════════════════════════════════ */

    /**
     * Run a single test.
     * @return array { status: ok|warn|fail, message: string, duration_ms: int, details: array }
     */
    public function run_test( $key ) {
        $start  = microtime( true );
        $method = 'test_' . $key;

        if ( ! method_exists( $this, $method ) ) {
            return $this->result( 'fail', 'Test non défini : ' . $key, $start );
        }

        try {
            $result = $this->$method();
        } catch ( \Throwable $e ) {
            return $this->result( 'fail', 'Erreur inattendue : ' . $e->getMessage(), $start );
        }

        $result['duration_ms'] = round( ( microtime( true ) - $start ) * 1000 );
        return $result;
    }

    // ── CONTENT EXTRACTOR ──

    private function test_content_extractor() {
        if ( ! class_exists( 'HTS_Content_Extractor' ) ) {
            return $this->result( 'fail', 'Le module d\'extraction de contenu n\'est pas chargé.' );
        }

        $posts = get_posts( array(
            'post_type'   => 'post',
            'post_status' => 'publish',
            'numberposts' => 3,
            'orderby'     => 'rand',
        ) );

        if ( empty( $posts ) ) {
            return $this->result( 'warn', 'Aucun article publié pour tester.' );
        }

        $issues = array();
        foreach ( $posts as $p ) {
            $diag = HTS_Content_Extractor::diagnose( $p->ID );
            if ( ( $diag['word_count'] ?? 0 ) === 0 ) {
                $issues[] = '#' . $p->ID . ' (' . mb_substr( $p->post_title, 0, 40 ) . '…) : 0 mots extraits — builder : ' . ( $diag['builder'] ?? '?' );
            }
        }

        if ( ! empty( $issues ) ) {
            return $this->result( 'warn', count( $issues ) . ' article(s) avec contenu vide.', 0, $issues );
        }

        return $this->result( 'ok', count( $posts ) . ' articles testés — extraction OK.' );
    }

    // ── CACHE SYSTEM ──

    private function test_cache_system() {
        $test_key = 'hts_cx_health_test_' . time();
        $test_val = array( 'content' => 'health_check_test', 'ts' => time() );

        set_transient( $test_key, $test_val, 60 );
        $read = get_transient( $test_key );
        delete_transient( $test_key );

        if ( $read === false ) {
            return $this->result( 'fail', 'Le cache WordPress ne fonctionne pas (impossible d\'écrire/lire un transient).' );
        }
        if ( $read !== $test_val ) {
            return $this->result( 'fail', 'Le cache WordPress est corrompu (données lues différentes des données écrites).' );
        }

        // Count existing HTS caches
        global $wpdb;
        $count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_cx_%'"
        );

        return $this->result( 'ok', 'Cache fonctionnel. ' . $count . ' extraction(s) en cache.' );
    }

    // ── OPENAI API ──

    private function test_ai_api() {
        $openai_key    = hts_get_openai_key();
        $anthropic_key = hts_get_anthropic_key();

        $has_openai    = $openai_key && strlen( $openai_key ) >= 20;
        $has_anthropic = $anthropic_key && strlen( $anthropic_key ) >= 20;

        // Si pas de clés locales et abonnement actif Pro/Ultra → forcer re-sync SaaS
        if ( ( ! $has_openai || ! $has_anthropic ) && class_exists( 'HTS_Subscription' ) && HTS_Subscription::is_active() && HTS_Subscription::get_plan_tier() >= 1 ) {
            HTS_Subscription::check_now();
            $openai_key    = hts_get_openai_key();
            $anthropic_key = hts_get_anthropic_key();
            $has_openai    = $openai_key && strlen( $openai_key ) >= 20;
            $has_anthropic = $anthropic_key && strlen( $anthropic_key ) >= 20;
        }

        $via_saas = class_exists( 'HTS_Subscription' ) && HTS_Subscription::is_active() && HTS_Subscription::get_plan_tier() >= 1;
        $source   = $via_saas ? ' (fournies par votre abonnement Hack The SEO)' : '';

        if ( $has_openai && $has_anthropic ) {
            return $this->result( 'ok', 'Anthropic + OpenAI configurées' . $source . '. Toutes les fonctions IA sont actives.' );
        }

        if ( ! $has_openai && $has_anthropic ) {
            return $this->result( 'ok', 'Anthropic configurée' . $source . ' — Meta, Liens et Coach actifs. Clé OpenAI manquante pour les Embeddings.' );
        }

        if ( $has_openai && ! $has_anthropic ) {
            return $this->result( 'warn', 'OpenAI configurée' . $source . ' (Embeddings OK) mais clé Anthropic manquante — Meta IA, Maillage IA et Coach désactivés.' );
        }

        if ( $via_saas ) {
            return $this->result( 'warn', 'Abonnement Hack The SEO actif mais clés IA non reçues du serveur. Cliquez "Vérifier" dans Connexions ou contactez le support.' );
        }

        return $this->result( 'warn', 'Aucune clé API IA configurée — les fonctions IA sont désactivées. Passez à un abonnement Pro pour activer l\'IA.' );
    }

    // ── SITEMAP XML ──

    private function test_sitemap_xml() {
        if ( ! class_exists( 'HTS_Sitemap' ) ) {
            return $this->result( 'warn', 'Module Sitemap non chargé.' );
        }

        if ( get_option( 'hts_module_sitemap', '1' ) !== '1' ) {
            return $this->result( 'warn', 'Module Sitemap désactivé par l\'utilisateur.' );
        }

        $sitemap_url = home_url( '/sitemap.xml' );
        $response    = wp_remote_get( $sitemap_url, array( 'timeout' => 10, 'sslverify' => false ) );

        if ( is_wp_error( $response ) ) {
            return $this->result( 'fail', 'Sitemap inaccessible : ' . $response->get_error_message() . '. Votre hébergeur bloque peut-être les requêtes internes.' );
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return $this->result( 'fail', 'Le sitemap retourne une erreur HTTP ' . $code . ' au lieu de 200.' );
        }

        $body = wp_remote_retrieve_body( $response );

        // XML validity
        libxml_use_internal_errors( true );
        $xml    = simplexml_load_string( $body );
        $errors = libxml_get_errors();
        libxml_clear_errors();

        if ( $xml === false || ! empty( $errors ) ) {
            $err_msgs = array();
            foreach ( array_slice( $errors, 0, 3 ) as $e ) {
                $err_msgs[] = 'Ligne ' . $e->line . ' : ' . trim( $e->message );
            }
            return $this->result( 'fail', 'Le XML du sitemap est invalide.', 0, $err_msgs );
        }

        // Count URLs
        $ns    = $xml->getNamespaces( true );
        $count = count( $xml->children( $ns[''] ?? '' ) );

        return $this->result( 'ok', 'Sitemap valide — ' . $count . ' entrée(s).' );
    }

    // ── SCHEMA JSON-LD ──

    private function test_schema_jsonld() {
        if ( ! class_exists( 'HTS_Schema_Markup' ) ) {
            return $this->result( 'warn', 'Module Schema non chargé.' );
        }

        if ( get_option( 'hts_module_schema', '1' ) === '0' ) {
            return $this->result( 'warn', 'Module Schema désactivé par l\'utilisateur.' );
        }

        $posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 2, 'orderby' => 'rand' ) );
        if ( empty( $posts ) ) {
            return $this->result( 'warn', 'Aucun article publié pour tester.' );
        }

        $issues = array();
        foreach ( $posts as $p ) {
            $url      = get_permalink( $p->ID );
            $response = wp_remote_get( $url, array( 'timeout' => 10, 'sslverify' => false ) );

            if ( is_wp_error( $response ) ) {
                $issues[] = '#' . $p->ID . ' : inaccessible — ' . $response->get_error_message();
                continue;
            }

            $body = wp_remote_retrieve_body( $response );

            // Check for HTS schema marker
            if ( stripos( $body, 'Hack The SEO' ) === false && stripos( $body, 'HackTheSEO' ) === false && stripos( $body, 'HTS Light' ) === false ) {
                $issues[] = '#' . $p->ID . ' (' . mb_substr( $p->post_title, 0, 40 ) . '…) : marqueur Hack The SEO absent du HTML';
                continue;
            }

            // Validate JSON-LD
            if ( preg_match_all( '/<script type="application\/ld\+json">(.*?)<\/script>/si', $body, $m ) ) {
                foreach ( $m[1] as $json_str ) {
                    $decoded = json_decode( $json_str, true );
                    if ( $decoded === null && json_last_error() !== JSON_ERROR_NONE ) {
                        $issues[] = '#' . $p->ID . ' : JSON-LD invalide — ' . json_last_error_msg();
                    }
                }
            }
        }

        if ( ! empty( $issues ) ) {
            return $this->result( 'fail', count( $issues ) . ' problème(s) sur les données structurées.', 0, $issues );
        }

        return $this->result( 'ok', count( $posts ) . ' articles vérifiés — Schema JSON-LD correct.' );
    }

    // ── META TAGS ──

    private function test_meta_tags() {
        if ( ! class_exists( 'HTS_Meta_Tags' ) ) {
            return $this->result( 'warn', 'Module Meta Tags non chargé.' );
        }

        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}" );
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_hts_meta_title' AND pm.meta_value != '' AND p.post_status = 'publish' AND p.post_type {$pt_in}" );

        if ( $total === 0 ) {
            return $this->result( 'warn', 'Aucun contenu publié.' );
        }

        $pct = round( ( $count / $total ) * 100 );

        if ( $pct < 30 ) {
            return $this->result( 'warn', $count . '/' . $total . ' articles ont un meta title personnalisé (' . $pct . '%). Les autres utilisent le titre WordPress par défaut.' );
        }

        return $this->result( 'ok', $count . '/' . $total . ' meta titles personnalisés (' . $pct . '%).' );
    }

    // ── REDIRECTS ──

    private function test_redirects() {
        if ( ! class_exists( 'HTS_Redirects' ) ) {
            return $this->result( 'warn', 'Module Redirections non chargé.' );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'hts_redirects';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
            return $this->result( 'warn', 'Table des redirections non créée (aucune redirection enregistrée).' );
        }

        // Check for loops
        $loops = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} a
             JOIN {$table} b ON a.target_url = b.source_url AND b.target_url = a.source_url
             WHERE a.enabled = 1 AND b.enabled = 1"
        );

        if ( $loops > 0 ) {
            return $this->result( 'fail', $loops . ' boucle(s) de redirection détectée(s). Les visiteurs restent bloqués dans une boucle infinie. Corrigez-les dans Redirections.' );
        }

        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE enabled = 1" );
        return $this->result( 'ok', $total . ' redirection(s) active(s) — aucune boucle.' );
    }

    // ── ROBOTS META ──

    private function test_robots_meta() {
        if ( ! class_exists( 'HTS_Robots' ) ) {
            return $this->result( 'warn', 'Module Robots non chargé.' );
        }

        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}" );

        // Count noindex pages (handles both array and string formats)
        $rows = $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_hts_robots_meta' AND meta_value != ''" );
        $noindex_count = 0;
        foreach ( $rows as $v ) {
            $a = maybe_unserialize( $v );
            if ( is_array( $a ) && in_array( 'noindex', $a, true ) ) { $noindex_count++; continue; }
            if ( is_string( $v ) && strpos( $v, 'noindex' ) !== false ) $noindex_count++;
        }

        if ( $total === 0 ) {
            return $this->result( 'warn', 'Aucun contenu publié.' );
        }

        $pct = round( ( $noindex_count / $total ) * 100 );

        if ( $pct > 30 ) {
            return $this->result( 'fail', $noindex_count . '/' . $total . ' pages sont en noindex (' . $pct . '%). C\'est trop — Google ne peut pas voir une grande partie de votre site.' );
        }
        if ( $pct > 15 ) {
            return $this->result( 'warn', $noindex_count . '/' . $total . ' pages en noindex (' . $pct . '%). Vérifiez que c\'est intentionnel.' );
        }

        return $this->result( 'ok', $noindex_count . ' page(s) en noindex sur ' . $total . ' (' . $pct . '%).' );
    }

    // ── CANONICAL ──

    private function test_canonical() {
        if ( ! class_exists( 'HTS_Canonical' ) ) {
            return $this->result( 'warn', 'Module Canonical non chargé.' );
        }

        global $wpdb;

        // Check for bad canonical URLs (not starting with http)
        $bad = $wpdb->get_results(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta}
             WHERE meta_key = '_hts_canonical_url' AND meta_value != ''
             AND meta_value NOT LIKE 'http%'"
        );

        if ( ! empty( $bad ) ) {
            $issues = array();
            foreach ( array_slice( $bad, 0, 5 ) as $b ) {
                $issues[] = '#' . $b->post_id . ' : "' . $b->meta_value . '"';
            }
            return $this->result( 'fail', count( $bad ) . ' URL(s) canonique(s) invalide(s) (ne commencent pas par http).', 0, $issues );
        }

        $customs = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_canonical_url' AND meta_value != ''" );
        return $this->result( 'ok', $customs . ' URL(s) canonique(s) personnalisée(s) — toutes valides.' );
    }

    // ── HTML FINGERPRINTS ──

    private function test_html_fingerprints() {
        $post = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 1, 'orderby' => 'rand' ) );
        if ( empty( $post ) ) {
            return $this->result( 'warn', 'Aucun article publié pour vérifier.' );
        }

        $url      = get_permalink( $post[0]->ID );
        $response = wp_remote_get( $url, array( 'timeout' => 15, 'sslverify' => false ) );

        if ( is_wp_error( $response ) ) {
            return $this->result( 'warn', 'Impossible de charger la page : ' . $response->get_error_message() );
        }

        $html   = wp_remote_retrieve_body( $response );
        $issues = array();

        // Extract <head> for performance
        $head = $html;
        $head_start = stripos( $html, '<head' );
        $head_end   = stripos( $html, '</head>' );
        if ( $head_start !== false && $head_end !== false ) {
            $head = substr( $html, $head_start, $head_end - $head_start + 7 );
        }

        // Double canonical
        $canonical_count = preg_match_all( '/<link[^>]+rel=["\']canonical["\'][^>]*>/i', $head );
        if ( $canonical_count > 1 ) $issues[] = $canonical_count . ' balises canonical (doublon — un plugin concurrent injecte la sienne)';

        // Double meta description
        $desc_count = preg_match_all( '/<meta[^>]+name=["\']description["\']/i', $head );
        if ( $desc_count > 1 ) $issues[] = $desc_count . ' meta descriptions (doublon)';

        // Double title
        $title_count = substr_count( strtolower( $head ), '<title' );
        if ( $title_count > 1 ) $issues[] = $title_count . ' balises <title> (doublon)';

        // Double OG
        $og_count = preg_match_all( '/<meta[^>]+property=["\']og:title["\']/i', $head );
        if ( $og_count > 1 ) $issues[] = $og_count . ' og:title (doublon)';

        // Double robots
        $robots_count = preg_match_all( '/<meta[^>]+name=["\']robots["\']/i', $head );
        if ( $robots_count > 1 ) $issues[] = $robots_count . ' meta robots (doublon)';

        // Competing plugin markers
        $markers = array(
            'Yoast SEO'      => array( 'yoast seo plugin', 'yoast-schema' ),
            'Rank Math'       => array( 'rank math', 'rank-math' ),
            'All in One SEO'  => array( 'all in one seo', 'aioseo' ),
            'SEOPress'        => array( 'seopress' ),
        );
        foreach ( $markers as $name => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( stripos( $html, $pattern ) !== false ) {
                    $issues[] = $name . ' injecte encore du HTML malgré Hack The SEO — désactivez-le';
                    break;
                }
            }
        }

        if ( ! empty( $issues ) ) {
            return $this->result( 'fail', count( $issues ) . ' problème(s) détecté(s) dans le HTML.', 0, $issues );
        }

        return $this->result( 'ok', 'HTML propre — aucun doublon, aucun conflit avec un plugin concurrent.' );
    }

    // ── META SCORE ──

    private function test_meta_score() {
        if ( ! class_exists( 'HTS_Meta_Score' ) ) {
            return $this->result( 'warn', 'Module Score Meta non chargé.' );
        }

        $posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 3, 'orderby' => 'rand' ) );
        if ( empty( $posts ) ) {
            return $this->result( 'warn', 'Aucun article pour tester.' );
        }

        $scorer = new HTS_Meta_Score();
        $issues = array();
        foreach ( $posts as $p ) {
            try {
                $score_data = $scorer->score_post( $p->ID );
                $score = $score_data['score'] ?? -1;
                if ( ! is_numeric( $score ) || $score < 0 || $score > 100 ) {
                    $issues[] = '#' . $p->ID . ' : score = ' . $score . ' (doit être entre 0 et 100)';
                }
            } catch ( \Throwable $e ) {
                $issues[] = '#' . $p->ID . ' : erreur — ' . $e->getMessage();
            }
        }

        if ( ! empty( $issues ) ) {
            return $this->result( 'fail', 'Le Score Meta retourne des résultats incohérents.', 0, $issues );
        }

        return $this->result( 'ok', count( $posts ) . ' articles scorés — résultats cohérents.' );
    }

    // ── ON-PAGE SCORE ──

    private function test_onpage_score() {
        if ( ! class_exists( 'HTS_On_Page_Score' ) ) {
            return $this->result( 'warn', 'Module Score On-Page non chargé.' );
        }

        $posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 3, 'orderby' => 'rand' ) );
        if ( empty( $posts ) ) {
            return $this->result( 'warn', 'Aucun article pour tester.' );
        }

        $scorer = new HTS_On_Page_Score();
        $issues = array();
        foreach ( $posts as $p ) {
            try {
                $score_data = $scorer->score_post( $p->ID );
                $score = $score_data['score'] ?? -1;
                if ( ! is_numeric( $score ) || $score < 0 || $score > 100 ) {
                    $issues[] = '#' . $p->ID . ' : score = ' . $score;
                }
            } catch ( \Throwable $e ) {
                $issues[] = '#' . $p->ID . ' : erreur — ' . $e->getMessage();
            }
        }

        if ( ! empty( $issues ) ) {
            return $this->result( 'fail', 'Le Score On-Page retourne des résultats incohérents.', 0, $issues );
        }

        return $this->result( 'ok', count( $posts ) . ' articles scorés — résultats cohérents.' );
    }

    // ── EMBEDDINGS ──

    private function test_embeddings() {
        if ( ! class_exists( 'HTS_Embeddings' ) ) {
            return $this->result( 'warn', 'Module Embeddings non chargé.' );
        }

        global $wpdb;
        $table  = $wpdb->prefix . 'hts_embeddings';
        $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" );

        if ( ! $exists ) {
            return $this->result( 'fail', 'La table d\'embeddings n\'existe pas. Désactivez et réactivez le plugin.' );
        }

        $count     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $published = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type = 'post'" );

        if ( $published === 0 ) {
            return $this->result( 'warn', 'Aucun article publié.' );
        }

        $pct = round( ( $count / max( 1, $published ) ) * 100 );

        if ( $pct < 30 ) {
            if ( empty( hts_get_openai_key() ) && empty( hts_get_api_key() ) ) {
                return $this->result( 'warn', $count . '/' . $published . ' embeddings (' . $pct . '%). Clé OpenAI absente — les embeddings nécessitent une clé pour fonctionner.' );
            }
            return $this->result( 'warn', $count . '/' . $published . ' embeddings calculés (' . $pct . '%). Le cron d\'indexation est peut-être bloqué.' );
        }

        return $this->result( 'ok', $count . '/' . $published . ' embeddings (' . $pct . '%).' );
    }

    // ── DECISION ENGINE ──

    private function test_decision_engine() {
        if ( ! class_exists( 'HTS_Decision_Engine' ) ) {
            return $this->result( 'warn', 'Module Moteur de décision non chargé.' );
        }

        // Check the table exists
        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
            return $this->result( 'fail', 'La table d\'actions (hts_actions) n\'existe pas.' );
        }

        // Check we can get recommendations for a random post
        $posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 1, 'orderby' => 'rand' ) );
        if ( empty( $posts ) ) {
            return $this->result( 'warn', 'Aucun article publié pour tester.' );
        }

        try {
            $recs = HTS_Decision_Engine::get_prioritized_actions( $posts[0]->ID );
            if ( ! is_array( $recs ) ) {
                return $this->result( 'fail', 'get_prioritized_actions() ne retourne pas un tableau.' );
            }
        } catch ( \Throwable $e ) {
            return $this->result( 'fail', 'Erreur : ' . $e->getMessage() );
        }

        $total_actions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        return $this->result( 'ok', 'Moteur de décision fonctionnel. ' . $total_actions . ' actions dans l\'historique.' );
    }

    // ── FEEDBACK LOOP ──

    private function test_feedback_loop() {
        if ( ! class_exists( 'HTS_Feedback_Loop' ) ) {
            return $this->result( 'warn', 'Module Boucle de mesure non chargé.' );
        }

        // Check GSC connection
        $gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
        if ( ! $gsc_connected ) {
            return $this->result( 'warn', 'Google Search Console n\'est pas connecté. La mesure d\'impact des actions est désactivée. Connectez GSC dans Réglages pour activer l\'apprentissage.' );
        }
        $gsc_meta = get_option( 'hts_gsc_meta', array() );
        $gsc_site = $gsc_meta['site_url'] ?? home_url();
        return $this->result( 'ok', 'GSC connecté (' . $gsc_site . '). La mesure d\'impact est active.' );
    }

    private function test_cocon_commander() {
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) {
            return $this->result( 'warn', 'Module Cocon Commander non chargé.' );
        }

        $commander = new HTS_Cocon_Commander();
        $plans = $commander->get_plans();
        $plan_count = count( $plans );

        // Check that required methods exist
        $required = array( 'get_plans', 'get_plan', 'save_plan', 'precheck_article', 'send_order', 'mark_received', 'get_plan_stats' );
        $missing = array();
        foreach ( $required as $m ) {
            if ( ! method_exists( $commander, $m ) ) $missing[] = $m;
        }
        if ( ! empty( $missing ) ) {
            return $this->result( 'fail', 'Méthodes manquantes : ' . implode( ', ', $missing ) );
        }

        // Check AJAX handlers are registered
        $has_ajax = has_action( 'wp_ajax_hts_cocon_plans' )
                 || has_action( 'wp_ajax_hts_cocon_order_article' );

        if ( $plan_count === 0 ) {
            return $this->result( 'ok', 'Cocon Commander opérationnel. Aucun plan reçu pour le moment — les plans seront envoyés depuis votre espace Hack The SEO.' );
        }

        // Analyze plans health
        $total_articles = 0;
        $stuck = 0;
        foreach ( $plans as $plan ) {
            $stats = $commander->get_plan_stats( $plan['cocon_id'] ?? '' );
            $total_articles += $stats['total'] ?? 0;
            $stuck += $stats['queued'] ?? 0; // queued for a long time = potential issue
        }

        return $this->result( 'ok',
            sprintf( '%d plan(s) cocon, %d articles. Système opérationnel.', $plan_count, $total_articles )
        );
    }

    /**
     * Health Check #17: Calendrier éditorial
     * Vérifie la planification, les priorités et l'auto-linking.
     */
    private function test_editorial_calendar() {
        // 1. Check class loaded and has required methods
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) {
            return $this->result( 'fail', 'Le module Cocon Commander n\'est pas chargé. Le calendrier éditorial en dépend.' );
        }

        $cc = new HTS_Cocon_Commander();

        // Check required Phase 6b methods exist
        $required_methods = array(
            'calculate_priority',
            'update_plan_priorities',
            'auto_link_siblings',
            'ajax_calendar_articles',
            'ajax_calendar_schedule',
        );

        $missing = array();
        foreach ( $required_methods as $m ) {
            if ( ! method_exists( $cc, $m ) ) {
                $missing[] = $m;
            }
        }

        if ( ! empty( $missing ) ) {
            return $this->result( 'fail', 'Méthodes manquantes dans le Commander : ' . implode( ', ', $missing ) );
        }

        // 2. Check calendar partial exists
        $cal_path = HTS__PLUGIN_DIR . 'admin/partials/editorial-calendar.php';
        if ( ! file_exists( $cal_path ) ) {
            return $this->result( 'warn', 'Le fichier du calendrier éditorial est manquant.' );
        }

        // 3. Check plans have priorities
        $plans = $cc->get_plans();
        $has_priority = false;
        foreach ( $plans as $plan ) {
            foreach ( $plan['articles'] ?? array() as $art ) {
                if ( isset( $art['publish_priority'] ) ) {
                    $has_priority = true;
                    break 2;
                }
            }
        }

        if ( ! empty( $plans ) && ! $has_priority ) {
            return $this->result( 'warn', 'Les priorités de publication ne sont pas encore calculées. Ouvrez le calendrier éditorial.' );
        }

        $plan_count = count( $plans );
        if ( $plan_count === 0 ) {
            return $this->result( 'ok', 'Aucun plan cocon reçu. Le calendrier se remplira automatiquement.' );
        }

        return $this->result( 'ok', sprintf(
            'Calendrier éditorial fonctionnel — %d plan(s) cocon, priorités calculées, auto-linking actif.',
            $plan_count
        ) );
    }

    /**
     * HC #18 — Cannibalization detection.
     */
    private function test_cannibalization() {
        if ( ! class_exists( 'HTS_Cannibalization' ) ) {
            return $this->result( 'fail', 'Le module de détection de cannibalisation n\'est pas chargé.' );
        }

        $cannibal = new HTS_Cannibalization();

        // Check required methods
        $methods = array( 'detect_by_embeddings', 'detect_by_keywords', 'detect_by_titles', 'calculate_cannibal_score', 'run_scan' );
        $missing = array();
        foreach ( $methods as $m ) {
            if ( ! method_exists( $cannibal, $m ) ) $missing[] = $m;
        }
        if ( ! empty( $missing ) ) {
            return $this->result( 'fail', 'Méthodes manquantes : ' . implode( ', ', $missing ) );
        }

        // Check if a scan has been done
        $data = $cannibal->get_pairs();
        if ( empty( $data['scanned_at'] ) ) {
            return $this->result( 'ok', 'Aucun scan de cannibalisation effectué. Lancez un scan pour détecter les conflits.' );
        }

        $critical = $data['critical'] ?? 0;
        if ( $critical > 0 ) {
            return $this->result( 'warn', sprintf( '%d paire(s) critique(s) de cannibalisation détectée(s). Ces pages se font concurrence.', $critical ) );
        }

        return $this->result( 'ok', sprintf(
            'Détection de cannibalisation opérationnelle — %d paire(s) détectée(s), aucune critique. Dernier scan : %s.',
            $data['total'] ?? 0, $data['scanned_at']
        ) );
    }

    /* ══════════════════════════════════════════════════
     *  RUN ALL TESTS
     * ══════════════════════════════════════════════════ */

    public function run_all() {
        $tests   = self::get_tests();
        $results = array();

        foreach ( $tests as $key => $info ) {
            $results[ $key ]          = $this->run_test( $key );
            $results[ $key ]['name']  = $info['name'];
            $results[ $key ]['group'] = $info['group'];
        }

        // Save
        $record = array(
            'timestamp' => current_time( 'mysql' ),
            'results'   => $results,
            'summary'   => $this->summarize( $results ),
        );

        update_option( self::OPTION_RESULTS, $record, false );

        // History
        $history = get_option( self::OPTION_HISTORY, array() );
        array_unshift( $history, $record );
        $history = array_slice( $history, 0, self::MAX_HISTORY );
        update_option( self::OPTION_HISTORY, $history, false );

        // Circuit breaker
        $this->process_circuit_breaker( $results );

        return $record;
    }

    private function summarize( $results ) {
        $ok = $warn = $fail = 0;
        foreach ( $results as $r ) {
            if ( ( $r['status'] ?? '' ) === 'ok' )   $ok++;
            if ( ( $r['status'] ?? '' ) === 'warn' ) $warn++;
            if ( ( $r['status'] ?? '' ) === 'fail' ) $fail++;
        }
        $total = count( $results );
        return compact( 'ok', 'warn', 'fail', 'total' );
    }

    /* ══════════════════════════════════════════════════
     *  CIRCUIT BREAKER
     * ══════════════════════════════════════════════════ */

    /**
     * Check if a module should be active for visitors.
     * Admin always sees everything (for debugging).
     *
     * @param string $module_key Test key from get_tests().
     * @return bool true if module should run.
     */
    public static function is_module_ok( $module_key ) {
        // Admin always sees everything
        if ( is_admin() && current_user_can( 'manage_options' ) ) {
            return true;
        }

        $breaker = get_option( self::OPTION_BREAKER, array() );
        $state   = $breaker[ $module_key ] ?? null;
        if ( ! $state ) return true;

        return ( $state['status'] ?? 'ok' ) !== 'disabled';
    }

    /**
     * Process test results → update circuit breaker states.
     */
    private function process_circuit_breaker( $results ) {
        $breaker = get_option( self::OPTION_BREAKER, array() );
        $tests   = self::get_tests();
        $alerts  = array();

        foreach ( $results as $key => $r ) {
            if ( ! isset( $breaker[ $key ] ) ) {
                $breaker[ $key ] = array( 'status' => 'ok', 'fail_count' => 0, 'last_change' => '' );
            }

            $state = &$breaker[ $key ];

            if ( ( $r['status'] ?? '' ) === 'fail' ) {
                $state['fail_count'] = ( $state['fail_count'] ?? 0 ) + 1;

                if ( $state['fail_count'] >= self::BREAKER_THRESHOLD && ( $state['status'] ?? '' ) !== 'disabled' ) {
                    $state['status']      = 'disabled';
                    $state['last_change'] = current_time( 'mysql' );
                    $state['reason']      = $r['message'] ?? '';
                    $alerts[] = ( $tests[ $key ]['name'] ?? $key ) . ' — désactivé automatiquement après ' . $state['fail_count'] . ' échecs : ' . ( $r['message'] ?? '' );
                }
            } elseif ( ( $r['status'] ?? '' ) === 'ok' ) {
                // Auto-recovery: if was disabled and now OK → re-enable
                if ( ( $state['status'] ?? '' ) === 'disabled' ) {
                    $state['status']      = 'ok';
                    $state['last_change'] = current_time( 'mysql' );
                }
                $state['fail_count'] = 0;
            }
        }

        update_option( self::OPTION_BREAKER, $breaker, false );

        // Send alert if modules were disabled
        if ( ! empty( $alerts ) ) {
            $this->send_alert( $alerts );
        }
    }

    /* ══════════════════════════════════════════════════
     *  AUTO-REPAIR
     * ══════════════════════════════════════════════════ */

    /**
     * Attempt auto-repair for a failed test.
     * @return array { success: bool, message: string, retest: string }
     */
    public function repair( $key ) {
        $method = 'repair_' . $key;
        if ( ! method_exists( $this, $method ) ) {
            return array( 'success' => false, 'message' => 'Aucune réparation automatique disponible pour ce test.' );
        }

        try {
            $result = $this->$method();
        } catch ( \Throwable $e ) {
            return array( 'success' => false, 'message' => 'Erreur : ' . $e->getMessage() );
        }

        // Re-test after repair
        $retest = $this->run_test( $key );
        $result['retest'] = $retest['status'];

        // If fixed, reset breaker
        if ( $retest['status'] === 'ok' ) {
            $breaker = get_option( self::OPTION_BREAKER, array() );
            if ( isset( $breaker[ $key ] ) ) {
                $breaker[ $key ]['status']      = 'ok';
                $breaker[ $key ]['fail_count']  = 0;
                $breaker[ $key ]['last_change'] = current_time( 'mysql' );
                update_option( self::OPTION_BREAKER, $breaker, false );
            }
        }

        return $result;
    }

    private function repair_content_extractor() {
        global $wpdb;
        $deleted = (int) $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_cx_%' OR option_name LIKE '_transient_timeout_hts_cx_%'"
        );
        return array( 'success' => true, 'message' => 'Cache de l\'extracteur vidé (' . $deleted . ' entrées). Le contenu sera ré-extrait au prochain chargement.' );
    }

    private function repair_cache_system() {
        global $wpdb;
        $deleted = (int) $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_%' OR option_name LIKE '_transient_timeout_hts_%'"
        );
        return array( 'success' => true, 'message' => $deleted . ' caches Hack The SEO supprimés.' );
    }

    private function repair_sitemap_xml() {
        if ( class_exists( 'HTS_Sitemap' ) ) {
            $sitemap = new HTS_Sitemap();
            if ( method_exists( $sitemap, 'invalidate_all_cache' ) ) {
                $sitemap->invalidate_all_cache();
            }
        }
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_sitemap%' OR option_name LIKE '_transient_timeout_hts_sitemap%'" );
        return array( 'success' => true, 'message' => 'Cache du sitemap vidé — il sera régénéré au prochain accès.' );
    }

    private function repair_meta_score() {
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_ms_%' OR option_name LIKE '_transient_timeout_hts_ms_%'" );
        $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_hts_meta_score_cache'" );
        return array( 'success' => true, 'message' => 'Cache du Score Meta vidé — les scores seront recalculés au prochain affichage.' );
    }

    private function repair_onpage_score() {
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_hts_onpage_score_cache'" );
        return array( 'success' => true, 'message' => 'Cache du Score On-Page vidé.' );
    }

    private function repair_embeddings() {
        // Just flag for re-indexation via cron
        if ( class_exists( 'HTS_Embeddings' ) ) {
            delete_option( 'hts_embeddings_last_indexed' );
            return array( 'success' => true, 'message' => 'Ré-indexation programmée — le cron traitera les embeddings manquants.' );
        }
        return array( 'success' => false, 'message' => 'Module Embeddings non disponible.' );
    }

    /* ══════════════════════════════════════════════════
     *  ALERTS
     * ══════════════════════════════════════════════════ */

    private function send_alert( $messages ) {
        $config  = get_option( self::OPTION_CONFIG, array() );
        $email   = ! empty( $config['alert_email'] ) ? $config['alert_email'] : get_option( 'admin_email' );
        $subject = '[Hack The SEO] Alerte santé plugin — ' . get_bloginfo( 'name' );

        $body  = "Le diagnostic automatique de Hack The SEO a détecté des problèmes :\n\n";
        foreach ( $messages as $msg ) {
            $body .= '• ' . $msg . "\n";
        }
        $body .= "\nVérifiez l'état de votre plugin dans :\n" . admin_url( 'admin.php?page=hts-api-settings&stab=health' );

        if ( $email ) {
            wp_mail( $email, $subject, $body );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Health Check : ' . count( $messages ) . ' problème(s) détecté(s)', 'error', 'health' );
        }
    }

    /* ══════════════════════════════════════════════════
     *  CRON
     * ══════════════════════════════════════════════════ */

    public function cron_run() {
        $record = $this->run_all();

        // Send summary email if issues detected (throttled: 1/week)
        $summary = $record['summary'] ?? array();
        if ( ( $summary['warn'] ?? 0 ) > 0 || ( $summary['fail'] ?? 0 ) > 0 ) {
            $this->send_summary_email( $record );
        }

        // Auto-repair if enabled
        $config = get_option( self::OPTION_CONFIG, array() );
        if ( ! empty( $config['auto_repair'] ) ) {
            $tests = self::get_tests();
            foreach ( $record['results'] as $key => $r ) {
                if ( ( $r['status'] ?? '' ) === 'fail' && ( $tests[ $key ]['has_repair'] ?? false ) ) {
                    $this->repair( $key );
                }
            }
        }
    }

    /**
     * Send health summary email (throttled: max 1 per week).
     */
    private function send_summary_email( $record ) {
        $last_sent = get_option( 'hts_health_last_email', 0 );
        if ( ( time() - $last_sent ) < WEEK_IN_SECONDS ) return;

        $config = get_option( self::OPTION_CONFIG, array() );
        $email  = ! empty( $config['alert_email'] ) ? $config['alert_email'] : get_option( 'admin_email' );
        if ( empty( $email ) ) return;

        $score   = self::get_health_score();
        $summary = $record['summary'] ?? array();
        $site    = get_bloginfo( 'name' ) . ' (' . home_url() . ')';

        $subject = '[Hack The SEO] Rapport santé ' . $score . '% — ' . get_bloginfo( 'name' );

        $body  = "Rapport automatique Hack The SEO\n";
        $body .= "Site : " . $site . "\n";
        $body .= "Score : " . $score . "%\n";
        $body .= "Résumé : " . ( $summary['ok'] ?? 0 ) . " OK, " . ( $summary['warn'] ?? 0 ) . " attention(s), " . ( $summary['fail'] ?? 0 ) . " problème(s)\n";
        $body .= "Version plugin : " . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ) . "\n";
        $body .= "WordPress : " . get_bloginfo( 'version' ) . "\n";
        $body .= "PHP : " . phpversion() . "\n\n";

        $body .= "=== DÉTAIL DES PROBLÈMES ===\n\n";
        foreach ( $record['results'] ?? array() as $key => $r ) {
            $status = $r['status'] ?? 'unknown';
            if ( $status === 'ok' ) continue;
            $body .= strtoupper( $status ) . " — " . ( $r['name'] ?? $key ) . "\n";
            $body .= "  → " . ( $r['message'] ?? '' ) . "\n";
            if ( ! empty( $r['details'] ) ) {
                foreach ( $r['details'] as $d ) {
                    $body .= "    • " . $d . "\n";
                }
            }
            $body .= "\n";
        }

        $body .= "Lien direct : " . admin_url( 'admin.php?page=hts-api-settings&stab=health' ) . "\n";

        wp_mail( $email, $subject, $body );
        update_option( 'hts_health_last_email', time(), false );
    }

    /* ══════════════════════════════════════════════════
     *  AJAX HANDLERS
     * ══════════════════════════════════════════════════ */

    public function ajax_run_all() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $record = $this->run_all();
        wp_send_json_success( $record );
    }

    public function ajax_run_single() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $key = sanitize_text_field( $_POST['test_key'] ?? '' );
        if ( ! $key ) wp_send_json_error( array( 'message' => 'Test non spécifié.' ) );

        $result = $this->run_test( $key );
        $tests  = self::get_tests();
        $result['name'] = $tests[ $key ]['name'] ?? $key;

        wp_send_json_success( $result );
    }

    public function ajax_get_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $results = get_option( self::OPTION_RESULTS, null );
        $breaker = get_option( self::OPTION_BREAKER, array() );
        $history = get_option( self::OPTION_HISTORY, array() );
        $config  = get_option( self::OPTION_CONFIG, array() );
        $next    = wp_next_scheduled( self::CRON_HOOK );

        wp_send_json_success( array(
            'results'   => $results,
            'breaker'   => $breaker,
            'history'   => array_slice( $history, 0, 10 ),
            'config'    => $config,
            'next_cron' => $next ? wp_date( 'Y-m-d H:i:s', $next ) : null,
            'tests'     => self::get_tests(),
        ) );
    }

    public function ajax_repair() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $key    = sanitize_text_field( $_POST['test_key'] ?? '' );
        $result = $this->repair( $key );
        wp_send_json_success( $result );
    }

    public function ajax_reset_breaker() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $key     = sanitize_text_field( $_POST['test_key'] ?? '' );
        $breaker = get_option( self::OPTION_BREAKER, array() );

        if ( isset( $breaker[ $key ] ) ) {
            $breaker[ $key ] = array( 'status' => 'ok', 'fail_count' => 0, 'last_change' => current_time( 'mysql' ) );
            update_option( self::OPTION_BREAKER, $breaker, false );
        }

        $tests = self::get_tests();
        wp_send_json_success( array( 'message' => ( $tests[ $key ]['name'] ?? $key ) . ' réactivé.' ) );
    }

    public function ajax_save_config() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $config = array(
            'alert_email' => sanitize_email( $_POST['alert_email'] ?? '' ),
            'auto_repair' => ! empty( $_POST['auto_repair'] ),
        );

        update_option( self::OPTION_CONFIG, $config, false );
        wp_send_json_success( array( 'message' => 'Configuration sauvegardée.' ) );
    }

    /**
     * AJAX: Send full health report to HTS support + client.
     */
    public function ajax_send_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( defined( 'HTS_VIEW_CAPABILITY' ) ? HTS_VIEW_CAPABILITY : 'edit_posts' ) ) {
            wp_send_json_error();
        }

        $record  = $this->run_all();
        $score   = self::get_health_score();
        $summary = $record['summary'] ?? array();
        $config  = get_option( self::OPTION_CONFIG, array() );
        $site    = get_bloginfo( 'name' ) . ' — ' . home_url();

        $subject = '[HTS Support] Rapport santé ' . $score . '% — ' . get_bloginfo( 'name' );

        $body  = "=== RAPPORT SANTÉ HACK THE SEO ===\n\n";
        $body .= "Site : " . $site . "\n";
        $body .= "Score : " . $score . "%\n";
        $body .= "Date : " . current_time( 'Y-m-d H:i:s' ) . "\n";
        $body .= "Plugin : v" . ( defined( 'HTS__VERSION' ) ? HTS__VERSION : '?' ) . "\n";
        $body .= "WordPress : " . get_bloginfo( 'version' ) . "\n";
        $body .= "PHP : " . phpversion() . "\n";
        $body .= "Thème : " . wp_get_theme()->get( 'Name' ) . "\n";
        $body .= "Résumé : " . ( $summary['ok'] ?? 0 ) . " OK, " . ( $summary['warn'] ?? 0 ) . " attention(s), " . ( $summary['fail'] ?? 0 ) . " problème(s)\n\n";

        $body .= "=== DÉTAIL COMPLET ===\n\n";
        foreach ( $record['results'] ?? array() as $key => $r ) {
            $icon = ( $r['status'] ?? '' ) === 'ok' ? '[OK]' : ( ( $r['status'] ?? '' ) === 'warn' ? '[!!]' : '[XX]' );
            $body .= $icon . " " . ( $r['name'] ?? $key ) . "\n";
            $body .= "    " . ( $r['message'] ?? '' ) . "\n";
            if ( ! empty( $r['details'] ) ) {
                foreach ( $r['details'] as $d ) {
                    $body .= "    • " . $d . "\n";
                }
            }
        }

        $body .= "\n=== INFOS TECHNIQUES ===\n\n";
        $body .= "API Key : " . ( get_option( 'hts_api_key' ) ? substr( get_option( 'hts_api_key' ), 0, 8 ) . '...' : 'MANQUANTE' ) . "\n";
        $body .= "Anthropic : " . ( function_exists( 'hts_get_anthropic_key' ) && hts_get_anthropic_key() ? 'Configurée' : 'Absente' ) . "\n";
        $body .= "OpenAI : " . ( function_exists( 'hts_get_openai_key' ) && hts_get_openai_key() ? 'Configurée' : 'Absente' ) . "\n";
        $body .= "Tier : " . ( class_exists( 'HTS_Subscription' ) ? HTS_Subscription::get_plan_tier() : '?' ) . "\n";
        $body .= "Plan : " . ( class_exists( 'HTS_Subscription' ) ? HTS_Subscription::get_plan_slug() : '?' ) . "\n";
        $body .= "GSC : " . ( class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected() ? 'Connecté' : 'Non' ) . "\n";
        $body .= "Base URL : " . get_option( 'hts_api_base_url', 'défaut' ) . "\n";
        $body .= "Crons actifs : " . ( wp_next_scheduled( 'hts_health_cron' ) ? 'oui' : 'non' ) . "\n";
        $body .= "Plugins actifs : " . count( get_option( 'active_plugins', array() ) ) . "\n";

        $to = array( 'eric@hacktheseo.com' );
        $client_email = ! empty( $config['alert_email'] ) ? $config['alert_email'] : get_option( 'admin_email' );
        if ( $client_email && $client_email !== 'eric@hacktheseo.com' ) {
            $to[] = $client_email;
        }

        $sent = wp_mail( $to, $subject, $body );

        if ( $sent ) {
            wp_send_json_success( array( 'message' => 'Rapport envoyé à l\'équipe Hack The SEO.' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Erreur d\'envoi. Vérifiez la configuration email de votre hébergeur.' ) );
        }
    }

    /* ══════════════════════════════════════════════════
     *  STATIC HELPERS (pour usage externe)
     * ══════════════════════════════════════════════════ */

    /**
     * Get overall health score (0-100).
     */
    public static function get_health_score() {
        $results = get_option( self::OPTION_RESULTS, null );
        if ( ! $results || ! isset( $results['summary'] ) ) return null;
        $s = $results['summary'];
        if ( ( $s['total'] ?? 0 ) === 0 ) return null;
        return (int) round( ( ( $s['ok'] * 100 + $s['warn'] * 50 ) / ( $s['total'] * 100 ) ) * 100 );
    }

    /**
     * Get count of issues (fails + warnings) for badges.
     */
    public static function get_issue_count() {
        $results = get_option( self::OPTION_RESULTS, null );
        if ( ! $results || ! isset( $results['summary'] ) ) return 0;
        return ( $results['summary']['fail'] ?? 0 ) + ( $results['summary']['warn'] ?? 0 );
    }

    /**
     * Get last run timestamp.
     */
    public static function get_last_run() {
        $results = get_option( self::OPTION_RESULTS, null );
        return $results['timestamp'] ?? null;
    }

    /**
     * Get breaker status for a module (for Cockpit integration).
     */
    public static function get_breaker_status( $module_key ) {
        $breaker = get_option( self::OPTION_BREAKER, array() );
        return $breaker[ $module_key ]['status'] ?? 'ok';
    }

    /**
     * Get summary for Cockpit display.
     */
    public static function get_cockpit_summary() {
        $results = get_option( self::OPTION_RESULTS, null );
        if ( ! $results ) return null;

        $score    = self::get_health_score();
        $summary  = $results['summary'] ?? array();
        $breaker  = get_option( self::OPTION_BREAKER, array() );
        $disabled = 0;
        foreach ( $breaker as $state ) {
            if ( ( $state['status'] ?? '' ) === 'disabled' ) $disabled++;
        }

        return array(
            'score'          => $score,
            'ok'             => $summary['ok'] ?? 0,
            'warn'           => $summary['warn'] ?? 0,
            'fail'           => $summary['fail'] ?? 0,
            'total'          => $summary['total'] ?? 0,
            'disabled_count' => $disabled,
            'last_run'       => $results['timestamp'] ?? null,
            'next_cron'      => wp_next_scheduled( self::CRON_HOOK ) ? wp_date( 'Y-m-d H:i:s', wp_next_scheduled( self::CRON_HOOK ) ) : null,
        );
    }

    /* ══════════════════════════════════════════════════
     *  INTERNAL HELPER
     * ══════════════════════════════════════════════════ */

    private function result( $status, $message, $start = 0, $details = array() ) {
        return array(
            'status'      => $status,
            'message'     => $message,
            'details'     => $details,
            'duration_ms' => $start ? round( ( microtime( true ) - $start ) * 1000 ) : 0,
        );
    }
}
