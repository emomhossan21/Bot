<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Semantic Embeddings — Vector Search for Internal Linking
 *
 * Generates embeddings for all published articles via OpenAI text-embedding-3-small.
 * Calculates cosine similarity to find semantically close articles.
 * Replaces "40 most recent" with "25 most semantically relevant" candidates
 * for the internal linking GPT prompt.
 *
 * Supports Money Page flagging for link equity sculpting.
 *
 * @since 1.14.5 (Light — ported from Full v3.0.0)
 */

class HTS_Embeddings {

    const TABLE_SUFFIX    = 'hts_embeddings';
    const EMBEDDING_MODEL = 'text-embedding-3-small';
    const DIMENSIONS      = 256;  // Compact vectors — fast cosine, low storage, great accuracy
    const BATCH_SIZE      = 20;   // Articles per cron run
    const CRON_HOOK       = 'hts_embeddings_index';
    const CRON_HOOK_SMART = 'hts_embeddings_smart_cron';

    // Auto-detection money page patterns
    // NOT contact (no SEO value) — YES service/prestation/pricing pages that drive revenue
    const MONEY_SLUGS    = array( 'devis', 'tarif', 'tarifs', 'pricing', 'prix',
                                   'offre', 'offres', 'formule', 'formules',
                                   'demo', 'essai', 'free-trial',
                                   'commande', 'checkout', 'panier', 'cart', 'boutique', 'shop',
                                   'inscription', 'signup', 'register',
                                   'rendez-vous', 'rdv', 'reservation', 'booking',
                                   'quote', 'estimate', 'achat',
                                   'services', 'prestations', 'solutions', 'accompagnement',
                                   'nos-services', 'nos-prestations', 'nos-offres', 'nos-solutions' );

    public function init() {
        // Auto-create table if missing
        self::maybe_create_table();

        // AJAX
        add_action( 'wp_ajax_hts_embeddings_status',       array( $this, 'ajax_status' ) );
        add_action( 'wp_ajax_hts_embeddings_index',        array( $this, 'ajax_index' ) );
        add_action( 'wp_ajax_hts_embeddings_reindex',      array( $this, 'ajax_reindex' ) );
        add_action( 'wp_ajax_hts_money_page_toggle',       array( $this, 'ajax_money_page_toggle' ) );
        add_action( 'wp_ajax_hts_embeddings_run_detection', array( $this, 'ajax_run_money_detection' ) );
        add_action( 'wp_ajax_hts_embeddings_diag',         array( $this, 'ajax_diag' ) );

        // Cron hooks
        add_action( self::CRON_HOOK,       array( $this, 'cron_index_batch' ) );
        add_action( self::CRON_HOOK_SMART, array( $this, 'cron_smart_run' ) );

        // Register custom cron intervals
        add_filter( 'cron_schedules', array( $this, 'register_cron_intervals' ) );

        // ── AUTO ONBOARDING ──
        // On first load: if no embeddings exist yet, launch onboarding mode
        $this->maybe_start_onboarding();

        // Schedule smart cron (weekly for maintenance, more frequent during onboarding)
        $this->schedule_smart_cron();

        // Flag article as needing re-embed on save
        add_action( 'save_post', array( $this, 'on_save_post' ), 20, 2 );
    }

    /* ══════════════════════════════════════════════
     *  SMART CRON — Auto onboarding + weekly maintenance
     * ══════════════════════════════════════════════ */

    /**
     * Detect first run → start onboarding mode (frequent indexing until 100%).
     */
    private function maybe_start_onboarding() {
        $mode = get_option( 'hts_embeddings_mode', '' );
        if ( $mode ) return; // Already initialized

        // First time ever: check if table has data
        $stats = self::get_stats();
        if ( $stats['indexed'] === 0 && $stats['total_posts'] > 0 ) {
            update_option( 'hts_embeddings_mode', 'onboarding', true );
            update_option( 'hts_embeddings_onboarding_started', current_time( 'mysql' ), true );

            // Run money page auto-detection immediately
            $this->auto_detect_money_pages();

            hts_add_log( '🧠 Embeddings : mode onboarding activé — scan complet du site lancé', 'success', 'embeddings' );
        } elseif ( $stats['coverage'] >= 95 ) {
            update_option( 'hts_embeddings_mode', 'weekly', true );
        } else {
            update_option( 'hts_embeddings_mode', 'onboarding', true );
        }
    }

    /**
     * Register custom cron intervals for embeddings.
     */
    public function register_cron_intervals( $schedules ) {
        $schedules['hts_15min_emb'] = array( 'interval' => 900, 'display' => 'Every 15 min (HTS Embeddings Onboarding)' );
        return $schedules;
    }

    /**
     * Schedule the right cron based on mode.
     * Onboarding = every 15 min (fast), Weekly = once a week.
     */
    private function schedule_smart_cron() {
        $mode = get_option( 'hts_embeddings_mode', 'onboarding' );

        // Always keep the hourly fallback
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 60, 'hourly', self::CRON_HOOK );
        }

        // Cleanup: unschedule old 5min cron if it exists (migration from previous version)
        $existing = wp_next_scheduled( self::CRON_HOOK_SMART );
        if ( $existing && wp_get_schedule( self::CRON_HOOK_SMART ) === 'hts_5min_emb' ) {
            wp_unschedule_event( $existing, self::CRON_HOOK_SMART );
            $existing = false;
        }

        // Smart cron: adjust based on mode
        $next = $existing;

        if ( $mode === 'onboarding' ) {
            // During onboarding: every 15 minutes for fast indexation
            if ( ! $next ) {
                wp_schedule_event( time() + 30, 'hts_15min_emb', self::CRON_HOOK_SMART );
            }
        } else {
            // Weekly mode: once a week
            if ( $next ) {
                wp_unschedule_event( $next, self::CRON_HOOK_SMART );
            }
            if ( ! wp_next_scheduled( self::CRON_HOOK_SMART ) ) {
                wp_schedule_event( time() + 3600, 'weekly', self::CRON_HOOK_SMART );
            }
        }
    }

    /**
     * Smart cron callback — adapts behavior based on mode.
     */
    public function cron_smart_run() {
        self::maybe_create_table();
        $mode  = get_option( 'hts_embeddings_mode', 'onboarding' );
        $stats = self::get_stats();

        if ( $mode === 'onboarding' ) {
            // Aggressive: index up to 30 articles per run
            $pending = $this->get_pending_posts( 30 );
            if ( empty( $pending ) || $stats['coverage'] >= 98 ) {
                // Onboarding complete → switch to weekly
                update_option( 'hts_embeddings_mode', 'weekly', true );
                update_option( 'hts_embeddings_onboarding_done', current_time( 'mysql' ), true );

                // Unschedule frequent cron
                $next = wp_next_scheduled( self::CRON_HOOK_SMART );
                if ( $next ) wp_unschedule_event( $next, self::CRON_HOOK_SMART );
                // Re-schedule weekly
                wp_schedule_event( time() + 3600, 'weekly', self::CRON_HOOK_SMART );

                // Re-run money page detection with full data
                $this->auto_detect_money_pages();

                hts_add_log(
                    '🧠 Embeddings : onboarding terminé (' . $stats['indexed'] . ' articles). Mode hebdomadaire activé.',
                    'success', 'embeddings'
                );
                return;
            }

            $indexed = 0;
            foreach ( $pending as $p ) {
                if ( $this->index_post( (int) $p['ID'] ) ) $indexed++;
                if ( $indexed % 5 === 0 ) usleep( 300000 );
            }

            if ( $indexed > 0 ) {
                $new_stats = self::get_stats();
                hts_add_log(
                    '🧠 Onboarding : ' . $indexed . ' indexé(s) — couverture ' . $new_stats['coverage'] . '%',
                    'info', 'embeddings'
                );
            }
        } else {
            // Weekly: re-index modified articles + detect new money pages
            $pending = $this->get_pending_posts( self::BATCH_SIZE );
            $indexed = 0;

            foreach ( $pending as $p ) {
                if ( $this->index_post( (int) $p['ID'] ) ) $indexed++;
                if ( $indexed % 5 === 0 ) usleep( 500000 );
            }

            // Re-detect money pages (new pages may have appeared)
            $detected = $this->auto_detect_money_pages();

            if ( $indexed > 0 || $detected > 0 ) {
                hts_add_log(
                    '🧠 Hebdo : ' . $indexed . ' article(s) réindexé(s), ' . $detected . ' money page(s) détectée(s)',
                    'info', 'embeddings'
                );
            }
        }
    }

    /* ══════════════════════════════════════════════
     *  AUTO-DETECT MONEY PAGES
     * ══════════════════════════════════════════════ */

    /**
     * Intelligently detect money pages based on signals.
     * Returns the number of newly detected pages.
     *
     * Signals:
     * 1. WooCommerce product pages, cart, checkout
     * 2. URL slugs matching conversion patterns (/devis, /tarifs, /services...)
     * 3. Pages with CTAs in content (demander un devis, réserver, buy now...)
     * 4. Scheduling/booking embeds (Calendly, HubSpot, Typeform, Acuity, Stripe...)
     * 5. Lead capture embeds (WPForms, Gravity, CF7, ConvertKit, Mailchimp...)
     * 6. Custom post types (landing pages, services, prestations)
     *
     * Filters:
     * - noindex pages are excluded (no SEO value)
     * - contact/legal pages are excluded (no ranking intent)
     */
    public function auto_detect_money_pages() {
        global $wpdb;
        $detected_ids = array();
        $reasons      = array();

        // ── 1. WooCommerce ──
        if ( class_exists( 'WooCommerce' ) ) {
            // Product pages
            $products = get_posts( array(
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
            ) );
            foreach ( $products as $pid ) {
                $detected_ids[ (int) $pid ] = 'woocommerce_product';
            }

            // WooCommerce special pages
            $woo_pages = array( 'woocommerce_cart_page_id', 'woocommerce_checkout_page_id', 'woocommerce_myaccount_page_id', 'woocommerce_shop_page_id' );
            foreach ( $woo_pages as $opt ) {
                $pid = (int) get_option( $opt, 0 );
                if ( $pid > 0 ) $detected_ids[ $pid ] = 'woocommerce_page';
            }
        }

        // ── 2. URL slug patterns ──
        $slug_placeholders = implode( ',', array_fill( 0, count( self::MONEY_SLUGS ), '%s' ) );
        $slug_matches = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_name, post_title FROM {$wpdb->posts}
            WHERE post_status = 'publish'
              AND post_type IN ('post','page')
              AND post_name IN ({$slug_placeholders})",
            ...self::MONEY_SLUGS
        ) );
        foreach ( $slug_matches as $m ) {
            $detected_ids[ (int) $m->ID ] = 'url_slug:' . $m->post_name;
        }

        // Also check partial slug matches (e.g., /demande-de-devis, /nos-tarifs)
        foreach ( self::MONEY_SLUGS as $slug ) {
            $partial = $wpdb->get_col( $wpdb->prepare( "
                SELECT ID FROM {$wpdb->posts}
                WHERE post_status = 'publish'
                  AND post_type IN ('post','page')
                  AND post_name LIKE %s
                  AND post_name NOT IN ('{$slugs_sql}')
            ", '%' . $wpdb->esc_like( $slug ) . '%' ) );
            foreach ( $partial as $pid ) {
                $detected_ids[ (int) $pid ] = 'url_partial:' . $slug;
            }
        }

        // ── 3. Pages with CTAs (buttons/links toward conversion) ──
        $cta_patterns = array(
            'demander un devis', 'demandez un devis', 'obtenir un devis', 'devis gratuit',
            'nous contacter', 'contactez-nous', 'prendre rendez-vous', 'prenez rendez-vous',
            'réserver', 'réservez', 'commander', 'commandez', 'acheter', 'achetez',
            'essai gratuit', 'essayer gratuitement', 'démarrer', 'commencer',
            'demander une démo', 'voir les tarifs', 'voir nos offres',
            'ajouter au panier', 'add to cart', 'buy now', 'get started',
            'request a quote', 'book now', 'schedule a call', 'free trial',
        );
        foreach ( $cta_patterns as $cta ) {
            $cta_pages = $wpdb->get_col( $wpdb->prepare( "
                SELECT ID FROM {$wpdb->posts}
                WHERE post_status = 'publish'
                  AND post_type IN ('post','page')
                  AND LOWER(post_content) LIKE %s
                  AND post_name NOT IN ('contact','nous-contacter','contactez-nous')
            ", '%' . $wpdb->esc_like( $cta ) . '%' ) );
            foreach ( $cta_pages as $pid ) {
                if ( ! isset( $detected_ids[ (int) $pid ] ) ) {
                    $detected_ids[ (int) $pid ] = 'cta:' . $cta;
                }
            }
        }

        // ── 4. Scheduling/booking embeds (Calendly, HubSpot, Acuity, etc.) ──
        $embed_patterns = array(
            'calendly.com'                  => 'calendly',
            'hubspot.com/meetings'          => 'hubspot_meeting',
            'meetings.hubspot.com'          => 'hubspot_meeting',
            'typeform.com'                  => 'typeform',
            'acuityscheduling.com'          => 'acuity',
            'koalendar.com'                 => 'koalendar',
            'tidycal.com'                   => 'tidycal',
            'cal.com'                       => 'cal_com',
            'savvycal.com'                  => 'savvycal',
            'zcal.co'                       => 'zcal',
            'youcanbook.me'                 => 'youcanbook',
            'oncehub.com'                   => 'oncehub',
            'book.stripe.com'              => 'stripe_checkout',
            'pay.google.com'               => 'google_pay',
            'checkout.stripe.com'          => 'stripe_checkout',
            'paypal.com/buttons'           => 'paypal',
            '[gravityform'                  => 'gravity_form',
            '[wpforms'                      => 'wpforms',
            '[contact-form-7'               => 'cf7',
            '[forminator_form'              => 'forminator',
            '[fluentform'                   => 'fluentform',
            'elementor-form'                => 'elementor_form',
            'data-formkit'                  => 'convertkit',
            'mailchimp.com/subscribe'       => 'mailchimp',
            'tally.so'                      => 'tally',
            'jotform.com'                   => 'jotform',
        );
        foreach ( $embed_patterns as $pattern => $label ) {
            $embed_pages = $wpdb->get_col( $wpdb->prepare( "
                SELECT ID FROM {$wpdb->posts}
                WHERE post_status = 'publish'
                  AND post_type IN ('post','page')
                  AND post_content LIKE %s
                  AND post_name NOT IN ('contact','nous-contacter','contactez-nous','mentions-legales','privacy-policy')
            ", '%' . $wpdb->esc_like( $pattern ) . '%' ) );
            foreach ( $embed_pages as $pid ) {
                if ( ! isset( $detected_ids[ (int) $pid ] ) ) {
                    $detected_ids[ (int) $pid ] = 'embed:' . $label;
                }
            }
        }

        // ── 5. Custom post types that are typically money pages ──
        $money_post_types = array( 'product', 'landing-page', 'landing_page', 'service', 'prestation' );
        foreach ( $money_post_types as $pt ) {
            if ( ! post_type_exists( $pt ) || $pt === 'product' ) continue; // product already handled by WooCommerce
            $cpt_pages = $wpdb->get_col( $wpdb->prepare( "
                SELECT ID FROM {$wpdb->posts}
                WHERE post_type = %s AND post_status = 'publish'
            ", $pt ) );
            foreach ( $cpt_pages as $pid ) {
                $detected_ids[ (int) $pid ] = 'post_type:' . $pt;
            }
        }

        // ── 6. FILTER: Remove noindex pages (no SEO value if not indexed) ──
        foreach ( array_keys( $detected_ids ) as $pid ) {
            if ( self::is_noindex( $pid ) ) {
                unset( $detected_ids[ $pid ] );
            }
        }

        // ── 7. Score & flag ──
        $new_count = 0;
        $existing  = self::get_money_pages();

        // Cleanup: remove pages that shouldn't be money pages
        $not_money_slugs = array( 'contact', 'nous-contacter', 'contactez-nous', 'mentions-legales', 'politique-de-confidentialite', 'privacy-policy', 'legal' );
        foreach ( $existing as $ex_id ) {
            $ex_post = get_post( $ex_id );
            if ( ! $ex_post ) continue;
            $is_auto = get_post_meta( $ex_id, '_hts_money_page_auto', true );
            // Remove auto-detected contact/legal pages
            $should_remove = $is_auto && in_array( $ex_post->post_name, $not_money_slugs, true );
            // Remove noindex pages (auto-detected only — preserve manual choices)
            if ( $is_auto && self::is_noindex( $ex_id ) ) $should_remove = true;
            if ( $should_remove ) {
                delete_post_meta( $ex_id, '_hts_money_page' );
                delete_post_meta( $ex_id, '_hts_money_page_auto' );
                delete_post_meta( $ex_id, '_hts_money_page_reason' );
            }
        }
        // Refresh existing list after cleanup
        $existing = self::get_money_pages();

        foreach ( $detected_ids as $pid => $reason ) {
            if ( in_array( (string) $pid, $existing, true ) || in_array( $pid, $existing, true ) ) continue;

            // Verify post still exists
            $post = get_post( $pid );
            if ( ! $post || $post->post_status !== 'publish' ) continue;

            update_post_meta( $pid, '_hts_money_page', '1' );
            update_post_meta( $pid, '_hts_money_page_auto', '1' );
            update_post_meta( $pid, '_hts_money_page_reason', $reason );
            $new_count++;
        }

        // Save last detection time
        update_option( 'hts_money_detection_last', current_time( 'mysql' ), true );
        update_option( 'hts_money_detection_count', count( $detected_ids ), true );

        return $new_count;
    }

    /**
     * Get breakdown of money pages by source (auto vs manual).
     */
    public static function get_money_pages_breakdown() {
        global $wpdb;
        $all = self::get_money_pages();
        $auto   = array();
        $manual = array();

        foreach ( $all as $pid ) {
            $is_auto = get_post_meta( $pid, '_hts_money_page_auto', true );
            $reason  = get_post_meta( $pid, '_hts_money_page_reason', true );
            $title   = get_the_title( $pid );
            if ( ! $title ) continue;

            $item = array( 'id' => (int) $pid, 'title' => $title, 'reason' => $reason ?: '' );
            if ( $is_auto ) {
                $auto[] = $item;
            } else {
                $manual[] = $item;
            }
        }

        return array( 'auto' => $auto, 'manual' => $manual, 'total' => count( $all ) );
    }

    /**
     * Check if a post is set to noindex (Yoast, RankMath, SEOPress, or WP native).
     * A noindex page has no SEO value → should not be a money page.
     */
    public static function is_noindex( $post_id ) {
        // Yoast SEO
        $yoast = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
        if ( $yoast === '1' ) return true;

        // RankMath
        $rm_robots = get_post_meta( $post_id, 'rank_math_robots', true );
        if ( is_array( $rm_robots ) && in_array( 'noindex', $rm_robots, true ) ) return true;
        if ( is_string( $rm_robots ) && strpos( $rm_robots, 'noindex' ) !== false ) return true;

        // SEOPress
        $seopress = get_post_meta( $post_id, '_seopress_robots_index', true );
        if ( $seopress === 'yes' ) return true; // SEOPress uses 'yes' for noindex

        // All in One SEO
        $aioseo = get_post_meta( $post_id, '_aioseo_noindex', true );
        if ( $aioseo === '1' || $aioseo === 'on' ) return true;

        // The SEO Framework
        $tsf = get_post_meta( $post_id, '_genesis_noindex', true );
        if ( $tsf === '1' ) return true;

        return false;
    }

    /**
     * Get human-readable reason for auto-detection.
     */
    public static function get_reason_label( $reason ) {
        if ( ! $reason ) return 'Manuel';
        $map = array(
            'woocommerce_product' => '🛒 Produit',
            'woocommerce_page'    => '🛒 WooCommerce',
        );
        if ( isset( $map[ $reason ] ) ) return $map[ $reason ];
        if ( strpos( $reason, 'url_slug:' ) === 0 )    return '🔗 /' . str_replace( 'url_slug:', '', $reason );
        if ( strpos( $reason, 'url_partial:' ) === 0 )  return '🔗 ' . str_replace( 'url_partial:', '', $reason );
        if ( strpos( $reason, 'post_type:' ) === 0 )    return '📄 ' . str_replace( 'post_type:', '', $reason );
        if ( strpos( $reason, 'cta:' ) === 0 )          return 'CTA';
        if ( strpos( $reason, 'embed:' ) === 0 ) {
            $embed_labels = array(
                'calendly'         => '📅 Calendly',
                'hubspot_meeting'  => '📅 HubSpot',
                'typeform'         => '📋 Typeform',
                'acuity'           => '📅 Acuity',
                'cal_com'          => '📅 Cal.com',
                'savvycal'         => '📅 SavvyCal',
                'tidycal'          => '📅 TidyCal',
                'stripe_checkout'  => '💳 Stripe',
                'paypal'           => '💳 PayPal',
                'gravity_form'     => 'Formulaire',
                'wpforms'          => 'Formulaire',
                'cf7'              => 'Formulaire',
                'forminator'       => 'Formulaire',
                'fluentform'       => 'Formulaire',
                'elementor_form'   => 'Formulaire',
                'convertkit'       => '📧 ConvertKit',
                'mailchimp'        => '📧 Mailchimp',
                'tally'            => '📋 Tally',
                'jotform'          => '📋 JotForm',
            );
            $key = str_replace( 'embed:', '', $reason );
            return $embed_labels[ $key ] ?? '📎 Embed';
        }
        return $reason;
    }

    /**
     * AJAX: Force re-detection of money pages.
     */
    public function ajax_run_money_detection() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        $count = $this->auto_detect_money_pages();
        $breakdown = self::get_money_pages_breakdown();

        hts_add_log( '💰 Détection money pages : ' . $count . ' nouvelle(s) détectée(s)', 'info', 'embeddings' );
        wp_send_json_success( array(
            'new_detected' => $count,
            'breakdown'    => $breakdown,
            'stats'        => self::get_stats(),
        ) );
    }

    /**
     * Create table if it doesn't exist yet.
     */
    public static function maybe_create_table() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        // Quick check — avoid running dbDelta on every page load
        if ( get_option( 'hts_embeddings_table_ok' ) === '1' ) {
            return;
        }
        // Check if table actually exists
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
            DB_NAME, $table
        ) );
        if ( $exists ) {
            update_option( 'hts_embeddings_table_ok', '1', true );
            return;
        }
        self::create_table();
        update_option( 'hts_embeddings_table_ok', '1', true );
    }

    /* ══════════════════════════════════════════════
     *  TABLE
     * ══════════════════════════════════════════════ */

    public static function create_table() {
        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE_SUFFIX;
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            post_id BIGINT(20) UNSIGNED NOT NULL,
            vector MEDIUMBLOB NOT NULL,
            content_hash CHAR(32) NOT NULL DEFAULT '',
            model VARCHAR(50) NOT NULL DEFAULT '',
            dims SMALLINT UNSIGNED NOT NULL DEFAULT 256,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (post_id),
            KEY idx_updated (updated_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /* ══════════════════════════════════════════════
     *  GENERATE EMBEDDING VIA OPENAI
     * ══════════════════════════════════════════════ */

    /**
     * Get embedding for a text string.
     * Returns array of floats or null on error.
     */
    public function get_embedding( $text ) {
        $api_key = hts_get_openai_key();
        if ( ! $api_key ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Embeddings: clé OpenAI absente — indexation impossible', 'warning', 'embeddings' );
            }
            return null;
        }

        // Truncate to ~6000 tokens (~24000 chars) to stay safe
        $text = mb_substr( $text, 0, 24000 );

        $response = wp_remote_post( 'https://api.openai.com/v1/embeddings', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'model'      => self::EMBEDDING_MODEL,
                'input'      => $text,
                'dimensions' => self::DIMENSIONS,
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                hts_debug_log( '[Embeddings] API error: ' . $response->get_error_message() );
            }
            return null;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                hts_debug_log( '[Embeddings] HTTP ' . $code . ': ' . ( $data['error']['message'] ?? 'Unknown' ) );
            }
            return null;
        }

        // Track token usage
        $tokens = (int) ( $data['usage']['total_tokens'] ?? 0 );
        if ( $tokens > 0 ) {
            $usage = get_option( 'hts_openai_usage', array() );
            $mk    = wp_date( 'Y-m' );
            $usage[ $mk ] = ( (int) ( $usage[ $mk ] ?? 0 ) ) + $tokens;
            update_option( 'hts_openai_usage', $usage, false );
        }

        return $data['data'][0]['embedding'] ?? null;
    }

    /**
     * Build the text representation of a post for embedding.
     * Title weighted 3x + categories + excerpt of content.
     */
    private function build_post_text( $post ) {
        $title = $post->post_title;
        $cats  = implode( ', ', wp_get_post_categories( $post->ID, array( 'fields' => 'names' ) ) );
        $body  = wp_strip_all_tags( $post->post_content );
        $body  = html_entity_decode( $body, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $body  = mb_substr( $body, 0, 8000 );

        // Title 3x for weight + keyword if available
        $keyword = get_post_meta( $post->ID, '_hts_api_keyword', true )
            ?: get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true )
            ?: get_post_meta( $post->ID, 'rank_math_focus_keyword', true );

        $text = $title . '. ' . $title . '. ' . $title . '. ';
        if ( $keyword ) $text .= 'Mot-clé : ' . $keyword . '. ';
        if ( $cats )    $text .= 'Catégories : ' . $cats . '. ';
        $text .= $body;

        return $text;
    }

    /**
     * Get content hash for change detection.
     */
    private function content_hash( $post ) {
        return md5( $post->post_title . '|' . mb_substr( $post->post_content, 0, 5000 ) );
    }

    /* ══════════════════════════════════════════════
     *  STORE / RETRIEVE
     * ══════════════════════════════════════════════ */

    /**
     * Store embedding as compact binary (4 bytes per float).
     */
    private function store_vector( $post_id, $vector, $content_hash ) {
        global $wpdb;
        $table  = $wpdb->prefix . self::TABLE_SUFFIX;
        $binary = pack( 'f*', ...$vector );

        $wpdb->replace( $table, array(
            'post_id'      => $post_id,
            'vector'       => $binary,
            'content_hash' => $content_hash,
            'model'        => self::EMBEDDING_MODEL,
            'dims'         => self::DIMENSIONS,
            'updated_at'   => current_time( 'mysql' ),
        ), array( '%d', '%s', '%s', '%s', '%d', '%s' ) );
    }

    /**
     * Load a single vector.
     */
    private function load_vector( $post_id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $wpdb->suppress_errors( true );
        $blob  = $wpdb->get_var( $wpdb->prepare( "SELECT vector FROM {$table} WHERE post_id = %d", $post_id ) );
        $wpdb->suppress_errors( false );
        if ( ! $blob ) return null;
        return array_values( unpack( 'f*', $blob ) );
    }

    /**
     * Load ALL vectors at once (for cosine comparison).
     * Returns [ post_id => [ float, float, ... ] ]
     * Filters out utility/skipped pages to keep clustering & linking clean.
     */
    public function load_all_vectors( $filter_skipped = true, $lang = '' ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // ── Sprint Robustesse: request-level cache to avoid multiple DB loads ──
        static $cache = array();
        $cache_key = ( $filter_skipped ? '1' : '0' ) . '_' . $lang;
        if ( isset( $cache[ $cache_key ] ) ) {
            return $cache[ $cache_key ];
        }

        // ── Sprint Robustesse: memory guard — abort if loading would exceed 80% of limit ──
        $mem_limit = $this->get_memory_limit_bytes();
        $mem_used  = memory_get_usage( true );
        $row_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        // Estimate: ~50KB per vector (1536 floats unpacked to PHP array)
        $estimated_mem = $row_count * 50 * 1024;
        if ( $mem_limit > 0 && ( $mem_used + $estimated_mem ) > ( $mem_limit * 0.80 ) ) {
            if ( function_exists( 'hts_debug_log' ) ) {
                hts_debug_log( sprintf(
                    '[Embeddings] Memory guard: %d vectors × ~50KB = %dMB, used=%dMB, limit=%dMB — skipping load',
                    $row_count, $estimated_mem / 1048576, $mem_used / 1048576, $mem_limit / 1048576
                ), 'embeddings' );
            }
            $cache[ $cache_key ] = array();
            return array();
        }

        // Safety LIMIT to prevent memory exhaustion on very large sites
        if ( $row_count > 5000 && function_exists( 'hts_debug_log' ) ) {
            hts_debug_log( sprintf(
                '[Embeddings] Warning: %d vectors in table, loading only first 5000',
                $row_count
            ), 'embeddings' );
        }

        $wpdb->suppress_errors( true );
        $results = $wpdb->get_results( "SELECT post_id, vector FROM {$table} ORDER BY post_id ASC LIMIT 5000", ARRAY_A );
        $wpdb->suppress_errors( false );

        if ( ! is_array( $results ) ) {
            $cache[ $cache_key ] = array();
            return array();
        }

        // Determine language filter
        $filter_lang = $lang;
        if ( ! $filter_lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $filter_lang = HTS_Language::get_current_lang();
        }

        // ── Sprint Robustesse: batch-prime the post cache to avoid N+1 get_post() ──
        if ( $filter_skipped && function_exists( '_prime_post_caches' ) ) {
            $all_pids = wp_list_pluck( $results, 'post_id' );
            _prime_post_caches( $all_pids, false, false );
        }

        $vectors = array();
        $purge_ids = array();
        foreach ( $results as $row ) {
            $pid = (int) $row['post_id'];

            // Check if this page should still be in the index
            if ( $filter_skipped ) {
                $post = get_post( $pid );
                if ( ! $post || $post->post_status !== 'publish' ) {
                    $purge_ids[] = $pid;
                    continue;
                }
                if ( self::should_skip_post( $pid, $post->post_name ) ) {
                    $purge_ids[] = $pid;
                    continue;
                }
            }

            // Language filter: only include posts matching the target language
            if ( $filter_lang && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
                $post_lang = HTS_Language::get_post_language( $pid );
                if ( $post_lang && $post_lang !== $filter_lang ) {
                    continue;
                }
            }

            $vectors[ $pid ] = array_values( unpack( 'f*', $row['vector'] ) );
        }

        // Auto-purge invalid entries from the database
        if ( ! empty( $purge_ids ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $purge_ids ), '%d' ) );
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE post_id IN ({$placeholders})", ...$purge_ids ) );
            hts_add_log(
                'Embeddings : ' . count( $purge_ids ) . ' entrée(s) utilitaire(s)/invalide(s) purgée(s) de l\'index',
                'info', 'embeddings'
            );
        }

        $cache[ $cache_key ] = $vectors;
        return $vectors;
    }

    /**
     * Get PHP memory limit in bytes.
     * @return int Memory limit in bytes (0 if unlimited)
     */
    private function get_memory_limit_bytes() {
        $limit = ini_get( 'memory_limit' );
        if ( $limit === '-1' ) return 0; // Unlimited
        $unit  = strtolower( substr( $limit, -1 ) );
        $value = (int) $limit;
        switch ( $unit ) {
            case 'g': $value *= 1024;
            case 'm': $value *= 1024;
            case 'k': $value *= 1024;
        }
        return $value;
    }

    /* ══════════════════════════════════════════════
     *  COSINE SIMILARITY
     * ══════════════════════════════════════════════ */

    /**
     * Calculate cosine similarity between two vectors.
     * Returns float 0-1 (1 = identical).
     */
    public static function cosine_similarity( $a, $b ) {
        $dot = 0.0;
        $na  = 0.0;
        $nb  = 0.0;
        $len = min( count( $a ), count( $b ) );

        for ( $i = 0; $i < $len; $i++ ) {
            $dot += $a[ $i ] * $b[ $i ];
            $na  += $a[ $i ] * $a[ $i ];
            $nb  += $b[ $i ] * $b[ $i ];
        }

        $denom = sqrt( $na ) * sqrt( $nb );
        return $denom > 0 ? $dot / $denom : 0.0;
    }

    /**
     * Find the N most similar posts to a given post.
     * Returns [ [ 'post_id' => int, 'similarity' => float ], ... ] sorted desc.
     */
    public function find_similar( $post_id, $top_n = 25, $min_similarity = 0.25 ) {
        $source_vector = $this->load_vector( $post_id );
        if ( ! $source_vector ) return array();

        // S18 FIX: Load vectors for same language only
        $source_lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $source_lang = function_exists( 'pll_get_post_language' )
                ? pll_get_post_language( $post_id, 'slug' )
                : HTS_Language::get_current_lang();
        }
        $all_vectors = $this->load_all_vectors( true, $source_lang );
        unset( $all_vectors[ $post_id ] ); // Exclude self

        $scores = array();
        foreach ( $all_vectors as $pid => $vec ) {
            $sim = self::cosine_similarity( $source_vector, $vec );
            if ( $sim >= $min_similarity ) {
                $scores[] = array( 'post_id' => $pid, 'similarity' => round( $sim, 4 ) );
            }
        }

        // Sort by similarity descending
        usort( $scores, function( $a, $b ) { return $b['similarity'] <=> $a['similarity']; } );

        return array_slice( $scores, 0, $top_n );
    }

    /* ══════════════════════════════════════════════
     *  MONEY PAGES
     * ══════════════════════════════════════════════ */

    /**
     * Check if a post is flagged as money page.
     */
    public static function is_money_page( $post_id ) {
        return (bool) get_post_meta( $post_id, '_hts_money_page', true );
    }

    /**
     * Get all money page IDs.
     */
    public static function get_money_pages() {
        global $wpdb;
        return $wpdb->get_col(
            "SELECT DISTINCT pm.post_id
             FROM {$wpdb->postmeta} pm
             WHERE pm.meta_key = '_hts_money_page'
               AND pm.meta_value = '1'
               AND pm.post_id NOT IN (
                   SELECT post_id FROM {$wpdb->postmeta}
                   WHERE meta_key = '_hts_money_page_dismissed'
                     AND meta_value = '1'
               )"
        );
    }

    /* ══════════════════════════════════════════════
     *  ENHANCED CANDIDATE SCORING
     * ══════════════════════════════════════════════ */

    /**
     * Get scored candidates for internal linking.
     * Combines: semantic similarity + GSC opportunity + money page boost.
     *
     * Score = (similarity × 50%) + (gsc_opportunity × 30%) + (money_page × 20%)
     *
     * Returns candidates array enriched with scores, sorted by final_score desc.
     */
    public function get_scored_candidates( $post_id, $max = 25 ) {
        // S18 FIX: find_similar now filters by source post language
        $similar = $this->find_similar( $post_id, 50, 0.20 );

        if ( empty( $similar ) ) return array();

        $money_pages = self::get_money_pages();
        $candidates  = array();

        foreach ( $similar as $s ) {
            $pid  = $s['post_id'];
            $post = get_post( $pid );
            if ( ! $post || $post->post_status !== 'publish' ) continue;
            // Double-check: skip utility pages that slipped through
            if ( self::should_skip_post( $pid, $post->post_name ) ) continue;

            $gsc_clicks      = (int) get_post_meta( $pid, '_hts_gsc_clicks', true );
            $gsc_impressions = (int) get_post_meta( $pid, '_hts_gsc_impressions', true );
            $gsc_position    = (float) get_post_meta( $pid, '_hts_gsc_position', true );

            // ── SIMILARITY SCORE (0-1) ──
            $sim_score = $s['similarity'];

            // ── GSC OPPORTUNITY SCORE (0-1) ──
            $gsc_score = 0.0;
            if ( $gsc_position >= 4 && $gsc_position <= 20 && $gsc_impressions > 10 ) {
                // Striking distance: position 4-20 with impressions = opportunity
                $pos_factor = 1.0 - ( ( $gsc_position - 4 ) / 16 ); // pos 4 = 1.0, pos 20 = 0.0
                $impr_factor = min( 1.0, log10( max( 1, $gsc_impressions ) ) / 3 ); // log scale
                $gsc_score = $pos_factor * 0.6 + $impr_factor * 0.4;
            } elseif ( $gsc_position > 0 && $gsc_position < 4 ) {
                // Top 3: already strong, moderate boost for authority transfer
                $gsc_score = 0.3;
            }

            // ── MONEY PAGE SCORE (0 or 1) ──
            $is_money = in_array( $pid, $money_pages, true ) ? 1.0 : 0.0;

            // ── FINAL COMPOSITE SCORE ──
            $final_score = ( $sim_score * 0.50 ) + ( $gsc_score * 0.30 ) + ( $is_money * 0.20 );

            $categories = wp_get_post_categories( $pid, array( 'fields' => 'names' ) );
            $excerpt    = mb_substr( wp_strip_all_tags( $post->post_content ), 0, 300 );

            $candidates[] = array(
                'id'               => $pid,
                'title'            => $post->post_title,
                'url'              => get_permalink( $pid ),
                'excerpt'          => $excerpt,
                'categories'       => $categories,
                'gsc_clicks'       => $gsc_clicks,
                'gsc_impressions'  => $gsc_impressions,
                'gsc_position'     => $gsc_position,
                'similarity'       => $sim_score,
                'gsc_opportunity'  => round( $gsc_score, 3 ),
                'is_money_page'    => (bool) $is_money,
                'final_score'      => round( $final_score, 4 ),
            );
        }

        // Sort by final_score descending
        usort( $candidates, function( $a, $b ) { return $b['final_score'] <=> $a['final_score']; } );

        return array_slice( $candidates, 0, $max );
    }

    /* ══════════════════════════════════════════════
     *  INDEXING
     * ══════════════════════════════════════════════ */

    /**
     * Index a single post: generate embedding and store.
     */
    public function index_post( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return false;
        if ( ! in_array( $post->post_type, array( 'post', 'page', 'product' ), true ) ) return false;
        if ( self::should_skip_post( $post_id, $post->post_name ) ) return false;

        $hash = $this->content_hash( $post );

        // Check if already indexed with same content
        global $wpdb;
        $table    = $wpdb->prefix . self::TABLE_SUFFIX;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT content_hash FROM {$table} WHERE post_id = %d", $post_id
        ) );
        if ( $existing === $hash ) {
            // Content hasn't changed — just touch updated_at so it's no longer "pending"
            $wpdb->update( $table,
                array( 'updated_at' => current_time( 'mysql' ) ),
                array( 'post_id' => $post_id )
            );
            return true;
        }

        $text   = $this->build_post_text( $post );
        $vector = $this->get_embedding( $text );

        if ( ! $vector ) return false;

        $this->store_vector( $post_id, $vector, $hash );
        return true;
    }

    /**
     * Get posts that need indexing (new or modified since last embed).
     */
    public function get_pending_posts( $limit = 50 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // Over-fetch to account for PHP-side filtering (should_skip_post)
        // Minimum 50 to ensure we find valid posts even when requesting just 1
        $sql_limit = max( 50, min( $limit * 5, 200 ) );

        $wpdb->suppress_errors( true );
        $results = $wpdb->get_results( $wpdb->prepare( "
            SELECT p.ID, p.post_title, p.post_type, p.post_name, p.post_modified,
                   e.updated_at AS embed_date, e.content_hash
            FROM {$wpdb->posts} p
            LEFT JOIN {$table} e ON p.ID = e.post_id
            LEFT JOIN {$wpdb->postmeta} skip ON p.ID = skip.post_id AND skip.meta_key = '_hts_embed_skip'
            WHERE p.post_type IN ('post','page')
              AND p.post_status = 'publish'
              AND ( e.post_id IS NULL OR p.post_modified > e.updated_at )
              AND ( skip.meta_value IS NULL OR skip.meta_value != '1' )
            ORDER BY e.post_id IS NULL DESC, p.post_modified DESC
            LIMIT %d
        ", $sql_limit ), ARRAY_A );
        $wpdb->suppress_errors( false );

        if ( ! is_array( $results ) ) return array();

        // Filter out pages that shouldn't be embedded
        $filtered = array_values( array_filter( $results, function( $r ) {
            return ! self::should_skip_post( (int) $r['ID'], $r['post_name'] ?? '' );
        } ) );

        // Return only the requested limit
        return array_slice( $filtered, 0, $limit );
    }

    /**
     * Determine if a post should be skipped from embedding.
     * Comprehensive filter matching the cocon pre-filter logic.
     *
     * Skips: noindex, legal/utility pages, password-protected, near-empty,
     * old/draft/test pages, partial slug matches, junk titles.
     */
    public static function should_skip_post( $post_id, $slug = '' ) {
        // Skip noindex pages
        if ( self::is_noindex( $post_id ) ) return true;

        $post = get_post( $post_id );
        if ( ! $post ) return true;
        if ( ! $slug ) $slug = $post->post_name;

        // ── 1. Exact slug match ──
        $skip_slugs_exact = array(
            'politique-de-confidentialite', 'privacy-policy', 'cookie-policy',
            'mentions-legales', 'legal-notice', 'legal',
            'cgv', 'cgu', 'conditions-generales',
            'terms-and-conditions', 'terms-of-service',
            'mon-compte', 'my-account', 'panier', 'cart', 'checkout',
            'contact', 'contact-2', 'formulaire', 'form', 'candidature',
            'plan-du-site', 'sitemap', 'cookie', 'cookies', 'rgpd', 'gdpr',
            'test', 'test-page', 'brouillon', 'draft', 'sample-page', 'hello-world',
            'account', 'login', 'register', 'commande',
            // Navigation / About / Team / Hub pages
            'qui-sommes-nous', 'a-propos', 'about', 'about-us',
            'equipe', 'lequipe', 'l-equipe', 'team', 'notre-equipe',
            'code-de-conduite', 'code-conduite',
            'home', 'accueil', 'homepage',
            'nos-articles', 'blog', 'articles', 'actualites', 'news',
            'faq', 'aide', 'help',
            'legislation', 'ressources',
        );
        if ( in_array( $slug, $skip_slugs_exact, true ) ) return true;

        // ── 2. Partial slug match (catches contact-2, contact-3, privacy-policy-fr, etc.) ──
        $skip_slug_fragments = array(
            'contact', 'formulaire', 'candidat',
            'confidentialite', 'privacy', 'mentions-legale',
            'cgv', 'cgu', 'cookie-policy',
            'qui-sommes', 'a-propos', 'about-us', 'notre-equipe', 'code-de-conduit',
            'nos-articles',
        );
        foreach ( $skip_slug_fragments as $frag ) {
            if ( strpos( $slug, $frag ) !== false ) return true;
        }

        // ── 3. Title-based exclusions ──
        $title_lower = mb_strtolower( trim( $post->post_title ) );

        // Exact junk title match
        $junk_titles = array( 'test', 'test page', 'brouillon', 'draft', 'hello world', 'sample page', 'exemple', 'accueil',
            'home', 'qui sommes-nous', 'qui sommes nous', 'l\'équipe', 'notre équipe',
            'code de conduite', 'faq', 'aide',
            'législation', 'legislation', 'blog', 'articles', 'actualités', 'actualites', 'ressources',
        );
        if ( in_array( $title_lower, $junk_titles, true ) ) return true;

        // Title contains utility patterns
        $utility_title_patterns = array(
            'politique de confidentialité', 'mentions légales', 'conditions générales',
            'formulaire de', 'politique de cookies',
            'nos articles', 'tous les articles', 'tous nos articles',
        );
        foreach ( $utility_title_patterns as $pat ) {
            if ( strpos( $title_lower, $pat ) !== false ) return true;
        }

        // Title ends with " - ancien" / " - old" / " - copie" / " (copie)" / " - draft"
        if ( preg_match( '/[\s\-–—]+(ancien|old|copie|copy|draft|brouillon|test)\s*$/i', $post->post_title ) ) return true;

        // ── 4. Password protected ──
        if ( ! empty( $post->post_password ) ) return true;

        // ── 5. Near-empty content (< 100 words = no semantic value) ──
        $plain = wp_strip_all_tags( $post->post_content );
        if ( hts_word_count( $plain ) < 100 ) return true;

        return false;
    }

    /**
     * Cron: index a batch of pending posts.
     */
    public function cron_index_batch() {
        self::maybe_create_table();
        $pending = $this->get_pending_posts( self::BATCH_SIZE );
        if ( empty( $pending ) ) return;

        $indexed = 0;
        $errors  = 0;

        foreach ( $pending as $p ) {
            $result = $this->index_post( (int) $p['ID'] );
            if ( $result ) {
                $indexed++;
            } else {
                $errors++;
            }

            // Rate limit: pause between API calls
            if ( $indexed % 5 === 0 ) {
                usleep( 500000 ); // 0.5s
            }
        }

        if ( $indexed > 0 ) {
            hts_add_log(
                '🧠 Embeddings : ' . $indexed . ' article(s) indexé(s)'
                . ( $errors > 0 ? ', ' . $errors . ' erreur(s)' : '' ),
                'info', 'embeddings'
            );
        }
    }

    /**
     * Flag post for re-indexing on save.
     */
    public function on_save_post( $post_id, $post ) {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;
        if ( ! in_array( $post->post_type, array( 'post', 'page', 'product' ), true ) ) return;
        if ( $post->post_status !== 'publish' ) return;

        // The cron will pick it up based on post_modified > embed updated_at
        // No need to do anything here — just let the cron handle it
    }

    /* ══════════════════════════════════════════════
     *  STATS
     * ══════════════════════════════════════════════ */

    /**
     * Get indexing statistics.
     */
    public static function get_stats() {
        // Request-level cache — called 2 times per cockpit load
        static $cached = null;
        if ( $cached !== null ) return $cached;

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        $mode = get_option( 'hts_embeddings_mode', 'unknown' );
        $onboarding_started = get_option( 'hts_embeddings_onboarding_started', '' );
        $onboarding_done    = get_option( 'hts_embeddings_onboarding_done', '' );
        $last_detection     = get_option( 'hts_money_detection_last', '' );

        // Slugs to exclude from stats (utility/legal pages — never embedded)
        $skip_slugs = array( 'politique-de-confidentialite','privacy-policy','cookie-policy','mentions-legales','legal-notice','legal','cgv','cgu','conditions-generales','terms-and-conditions','terms-of-service','mon-compte','my-account','panier','cart','checkout','contact','contact-2','formulaire','form','candidature','plan-du-site','sitemap','cookie','cookies','rgpd','gdpr','test','test-page','brouillon','draft','sample-page','hello-world','account','login','register','commande' );
        $skip_placeholders = implode( ',', array_fill( 0, count( $skip_slugs ), '%s' ) );

        // Count eligible posts only
        $total_eligible = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts}
            WHERE post_type IN ('post','page') AND post_status = 'publish'
              AND post_name NOT IN ({$skip_placeholders})",
            ...$skip_slugs
        ) );

        // Safety: check table exists
        $wpdb->suppress_errors( true );
        $test = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $wpdb->suppress_errors( false );

        if ( $test === null && ! empty( $wpdb->last_error ) ) {
            $breakdown = self::get_money_pages_breakdown();
            $cached = array(
                'total_posts'     => $total_eligible,
                'indexed'         => 0,
                'pending'         => $total_eligible,
                'money_pages'     => $breakdown['total'],
                'money_auto'      => count( $breakdown['auto'] ),
                'money_manual'    => count( $breakdown['manual'] ),
                'coverage'        => 0,
                'oldest_embed'    => null,
                'newest_embed'    => null,
                'table_missing'   => true,
                'mode'            => $mode,
                'onboarding_started' => $onboarding_started,
                'onboarding_done'    => $onboarding_done,
                'last_detection'     => $last_detection,
            );
            return $cached;
        }

        $indexed = (int) $test;
        $oldest  = $wpdb->get_var( "SELECT MIN(updated_at) FROM {$table}" );
        $newest  = $wpdb->get_var( "SELECT MAX(updated_at) FROM {$table}" );

        $pending = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
            LEFT JOIN {$table} e ON p.ID = e.post_id
            WHERE p.post_type IN ('post','page') AND p.post_status = 'publish'
              AND p.post_name NOT IN ({$skip_placeholders})
              AND ( e.post_id IS NULL OR p.post_modified > e.updated_at )",
            ...$skip_slugs
        ) );

        $breakdown = self::get_money_pages_breakdown();

        // ── Count truly skipped posts (noindex, <100 words, etc.) ──
        // These are in total_eligible (pass slug filter) but fail should_skip_post()
        $skipped = 0;
        $skip_reasons = array();
        if ( $pending > 0 ) {
            $pending_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT p.ID, p.post_name FROM {$wpdb->posts} p
                LEFT JOIN {$table} e ON p.ID = e.post_id
                WHERE p.post_type IN ('post','page') AND p.post_status = 'publish'
                  AND p.post_name NOT IN ({$skip_placeholders})
                  AND ( e.post_id IS NULL OR p.post_modified > e.updated_at )
                LIMIT 200",
                ...$skip_slugs
            ), ARRAY_A );
            foreach ( $pending_rows as $row ) {
                if ( self::should_skip_post( (int) $row['ID'], $row['post_name'] ?? '' ) ) {
                    $skipped++;
                    // Detect reason for first few
                    if ( count( $skip_reasons ) < 5 ) {
                        $p = get_post( (int) $row['ID'] );
                        if ( $p ) {
                            if ( self::is_noindex( $p->ID ) ) $skip_reasons[] = $p->post_title . ' (noindex)';
                            elseif ( hts_word_count( wp_strip_all_tags( $p->post_content ) ) < 100 ) $skip_reasons[] = $p->post_title . ' (<100 mots)';
                            else $skip_reasons[] = $p->post_title . ' (page utilitaire)';
                        }
                    }
                }
            }
        }
        $truly_pending = max( 0, $pending - $skipped );
        $truly_total   = $indexed + $truly_pending;

        $cached = array(
            'total_posts'     => $total_eligible,
            'indexed'         => $indexed,
            'pending'         => $truly_pending,
            'skipped'         => $skipped,
            'skip_reasons'    => $skip_reasons,
            'money_pages'     => $breakdown['total'],
            'money_auto'      => count( $breakdown['auto'] ),
            'money_manual'    => count( $breakdown['manual'] ),
            'coverage'        => $truly_total > 0 ? round( ( $indexed / $truly_total ) * 100 ) : 0,
            'oldest_embed'    => $oldest,
            'newest_embed'    => $newest,
            'mode'            => $mode,
            'onboarding_started' => $onboarding_started,
            'onboarding_done'    => $onboarding_done,
            'last_detection'     => $last_detection,
        );
        return $cached;
    }

    /* ══════════════════════════════════════════════
     *  AJAX
     * ══════════════════════════════════════════════ */

    public function ajax_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);
        wp_send_json_success( self::get_stats() );
    }

    public function ajax_index() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 60 );
        }

        self::maybe_create_table();

        // Process ONE post per AJAX call — JS loops until done
        $pending = $this->get_pending_posts( 1 );
        if ( empty( $pending ) ) {
            wp_send_json_success( array(
                'indexed'   => 0,
                'errors'    => 0,
                'remaining' => 0,
                'message'   => 'Tous les articles sont déjà indexés.',
                'stats'     => self::get_stats(),
            ) );
        }

        $p      = $pending[0];
        $pid    = (int) $p['ID'];
        $debug  = array( 'post_id' => $pid, 'title' => $p['post_title'] ?? '' );

        // ── Detailed failure tracking ──
        $post = get_post( $pid );
        if ( ! $post || $post->post_status !== 'publish' ) {
            wp_send_json_success( array(
                'indexed' => 0, 'errors' => 1, 'remaining' => max( 0, count( $this->get_pending_posts( 50 ) ) ),
                'debug' => 'Post introuvable ou non publié',
                'stats' => self::get_stats(),
            ) );
        }

        if ( self::should_skip_post( $pid, $post->post_name ) ) {
            // Mark this post so it stops appearing as pending
            update_post_meta( $pid, '_hts_embed_skip', '1' );
            wp_send_json_success( array(
                'indexed' => 0, 'errors' => 0, 'remaining' => max( 0, count( $this->get_pending_posts( 50 ) ) ),
                'skipped_reason' => 'Filtré (noindex, utilitaire ou <100 mots): ' . $post->post_name,
                'stats' => self::get_stats(),
            ) );
        }

        // Check API key exists
        $api_key = hts_get_openai_key();
        if ( ! $api_key ) {
            wp_send_json_success( array(
                'indexed' => 0, 'errors' => 1, 'remaining' => count( $this->get_pending_posts( 50 ) ),
                'debug' => 'Clé API OpenAI manquante — configurez-la dans Réglages > IA',
                'stats' => self::get_stats(),
            ) );
        }

        // Try to index
        $ok = $this->index_post( $pid );

        $remaining = max( 0, count( $this->get_pending_posts( 50 ) ) );

        if ( $ok ) {
            hts_add_log( '🧠 Embedding : ' . get_the_title( $pid ) . ' indexé', 'info', 'embeddings' );
        } else {
            $debug['fail_reason'] = 'get_embedding() a retourné null — vérifiez la clé OpenAI ou le réseau';
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                hts_debug_log( '[Embeddings] Failed to index post #' . $pid . ' (' . ( $post->post_title ?? '' ) . ')' );
            }
        }

        wp_send_json_success( array(
            'indexed'    => $ok ? 1 : 0,
            'errors'     => $ok ? 0 : 1,
            'remaining'  => $remaining,
            'post_title' => $ok ? get_the_title( $pid ) : '',
            'debug'      => $ok ? '' : ( $debug['fail_reason'] ?? 'Erreur inconnue' ),
            'stats'      => self::get_stats(),
        ) );
    }

    /**
     * AJAX: Diagnostic endpoint — tests each step of embedding pipeline without modifying anything.
     * Call from browser: jQuery.post(ajaxurl, {action:'hts_embeddings_diag', nonce: hts_admin.nonce}, function(r){alert(JSON.stringify(r))})
     */
    public function ajax_diag() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'No permission' );
        HTS_Subscription::require_tier(2);

        $diag = array();

        // 1. Table exists?
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $diag['table_exists'] = (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
            DB_NAME, $table
        ) );

        // 2. Current stats
        $diag['stats'] = self::get_stats();

        // 3. Pending posts (first 5)
        $pending = $this->get_pending_posts( 5 );
        $diag['pending_count'] = count( $this->get_pending_posts( 50 ) );
        $diag['pending_sample'] = array();
        foreach ( $pending as $p ) {
            $pid = (int) $p['ID'];
            $skip = self::should_skip_post( $pid, $p['post_name'] ?? '' );
            $meta_skip = get_post_meta( $pid, '_hts_embed_skip', true );
            $diag['pending_sample'][] = array(
                'ID'           => $pid,
                'title'        => $p['post_title'] ?? '',
                'slug'         => $p['post_name'] ?? '',
                'type'         => $p['post_type'] ?? '',
                'should_skip'  => $skip,
                'meta_skip'    => $meta_skip,
                'embed_date'   => $p['embed_date'] ?? null,
                'modified'     => $p['post_modified'] ?? '',
            );
        }

        // 4. API key check
        $api_key = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : '';
        $diag['api_key_set'] = ! empty( $api_key );
        $diag['api_key_preview'] = $api_key ? substr( $api_key, 0, 8 ) . '...' . substr( $api_key, -4 ) : '(vide)';

        // 5. Test API call with tiny text (only if key exists)
        if ( ! empty( $api_key ) ) {
            $test_response = wp_remote_post( 'https://api.openai.com/v1/embeddings', array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type'  => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'      => self::EMBEDDING_MODEL,
                    'input'      => 'test diagnostic HTS',
                    'dimensions' => self::DIMENSIONS,
                ) ),
            ) );

            if ( is_wp_error( $test_response ) ) {
                $diag['api_test'] = 'WP_Error: ' . $test_response->get_error_message();
            } else {
                $code = wp_remote_retrieve_response_code( $test_response );
                $body = json_decode( wp_remote_retrieve_body( $test_response ), true );
                $diag['api_test_code'] = $code;
                if ( $code === 200 ) {
                    $diag['api_test'] = 'OK — vecteur reçu (' . count( $body['data'][0]['embedding'] ?? array() ) . ' dims)';
                } else {
                    $diag['api_test'] = 'HTTP ' . $code . ': ' . ( $body['error']['message'] ?? 'Unknown error' );
                }
            }
        } else {
            $diag['api_test'] = 'Pas de clé API — impossible de tester';
        }

        // 6. PHP config
        $diag['php_version'] = PHP_VERSION;
        $diag['max_execution_time'] = (int) ini_get( 'max_execution_time' );
        $diag['memory_limit'] = ini_get( 'memory_limit' );

        wp_send_json_success( $diag );
    }

    public function ajax_reindex() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        global $wpdb;

        // 1. Truncate embeddings table
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $wpdb->query( "TRUNCATE TABLE {$table}" );
        delete_option( 'hts_embeddings_table_ok' );

        // 2. Clear ALL auto-detected money pages (keep manual ones)
        $auto_money = $wpdb->get_col(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_hts_money_page_auto' AND meta_value = '1'"
        );
        foreach ( $auto_money as $pid ) {
            delete_post_meta( $pid, '_hts_money_page' );
            delete_post_meta( $pid, '_hts_money_page_auto' );
            delete_post_meta( $pid, '_hts_money_page_reason' );
        }

        // 3. Reset mode → onboarding
        update_option( 'hts_embeddings_mode', 'onboarding', true );
        delete_option( 'hts_embeddings_onboarding_done' );
        update_option( 'hts_embeddings_onboarding_started', current_time( 'mysql' ), true );

        // 4. Reschedule smart cron for onboarding
        $next = wp_next_scheduled( self::CRON_HOOK_SMART );
        if ( $next ) wp_unschedule_event( $next, self::CRON_HOOK_SMART );
        wp_schedule_event( time() + 30, 'hts_15min_emb', self::CRON_HOOK_SMART );

        // 5. Purge embeddings logs
        $logs = get_option( 'hts_activity_logs' );
        if ( is_array( $logs ) ) {
            $logs = array_filter( $logs, function( $l ) { return ( $l['source'] ?? '' ) !== 'embeddings'; } );
            update_option( 'hts_activity_logs', array_values( $logs ) );
        }

        // 6. Re-run money page detection with latest code
        $detected = $this->auto_detect_money_pages();

        hts_add_log( '🧠 Reset complet — ' . $detected . ' money page(s) détectée(s). Onboarding relancé.', 'success', 'embeddings' );
        wp_send_json_success( array(
            'message'  => 'Reset complet. Onboarding relancé.',
            'detected' => $detected,
            'stats'    => self::get_stats(),
        ) );
    }

    public function ajax_money_page_toggle() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( array( 'message' => 'post_id requis' ) );

        $current = get_post_meta( $post_id, '_hts_money_page', true );
        $new_val = $current ? '0' : '1';
        update_post_meta( $post_id, '_hts_money_page', $new_val );

        wp_send_json_success( array(
            'post_id' => $post_id,
            'is_money_page' => (bool) $new_val,
            'message' => $new_val ? '💰 Page marquée comme Money Page' : 'Money Page retirée',
        ) );
    }
}
