/**
 * HTS Job Poller — Generic polling for batch jobs.
 *
 * Usage:
 *   htsJobPoller.start({
 *       initAction: 'hts_cocon_analyze_init',
 *       stepAction: 'hts_cocon_analyze_step',
 *       nonce: htsNonce,
 *       params: { lang: 'fr' },
 *       onProgress: function(data) { ... },
 *       onComplete: function(data) { ... },
 *       onError: function(msg) { ... },
 *   });
 *
 * @package HackTheSEO
 * @since   2.8.0
 */
window.htsJobPoller = (function() {
    'use strict';

    var POLL_INTERVAL = 2000;
    var RETRY_INTERVAL = 5000;

    function post(action, nonce, extra) {
        var fd = new FormData();
        fd.append('action', action);
        fd.append('nonce', nonce);
        if (extra) {
            Object.keys(extra).forEach(function(k) { fd.append(k, extra[k]); });
        }
        return fetch(ajaxurl, { method: 'POST', body: fd }).then(function(r) { return r.json(); });
    }

    function start(opts) {
        var initAction = opts.initAction;
        var stepAction = opts.stepAction;
        var nonce      = opts.nonce;
        var params     = opts.params || {};
        var onProgress = opts.onProgress || function() {};
        var onComplete = opts.onComplete || function() {};
        var onError    = opts.onError || function() {};

        onProgress({ step: 0, total: 0, progress: 0, message: 'Initialisation...' });

        post(initAction, nonce, params)
            .then(function(r) {
                if (!r.success || !r.data || !r.data.job_id) {
                    onError(r.data && r.data.message ? r.data.message : 'Erreur initialisation');
                    return;
                }
                onProgress({ step: 0, total: r.data.total || 0, progress: 0, message: 'Démarrage...' });
                pollStep(r.data.job_id, stepAction, nonce, onProgress, onComplete, onError, 0);
            })
            .catch(function(err) {
                onError('Erreur réseau : ' + err.message);
            });
    }

    function pollStep(jobId, stepAction, nonce, onProgress, onComplete, onError, retries) {
        post(stepAction, nonce, { job_id: jobId })
            .then(function(r) {
                if (!r.success) {
                    onError(r.data && r.data.message ? r.data.message : 'Erreur step');
                    return;
                }

                var d = r.data;

                if (d.status === 'done') {
                    onProgress({ step: d.step || 0, total: d.total || 0, progress: 100, message: 'Terminé !' });
                    onComplete(d);
                    return;
                }

                if (d.status === 'failed') {
                    onError(d.errors ? d.errors.join(', ') : 'Le traitement a échoué');
                    return;
                }

                onProgress({
                    step: d.step || 0,
                    total: d.total || 0,
                    processed: d.processed || 0,
                    progress: d.progress || 0,
                    message: d.message || ('Étape ' + (d.step || 0) + '...')
                });

                setTimeout(function() {
                    pollStep(jobId, stepAction, nonce, onProgress, onComplete, onError, 0);
                }, POLL_INTERVAL);
            })
            .catch(function(err) {
                if (retries < 2) {
                    setTimeout(function() {
                        pollStep(jobId, stepAction, nonce, onProgress, onComplete, onError, retries + 1);
                    }, RETRY_INTERVAL);
                } else {
                    onError('Erreur réseau après 3 tentatives');
                }
            });
    }

    return { start: start };
})();
