<?php
/**
 * Hack The SEO — Inbox (S14c — DS v5.7 — Perf optimized)
 * Maquette: hts-inbox-s2-v5.jsx
 * Layout: page_open(true) = Dashboard width (1100px)
 *
 * Perf: single enrichment pass, batch meta prefetch, 0 redundant json_decode
 * Back: all 7 AJAX endpoints verified against workflow-engine + feedback-loop
 * @since 2.6.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}
$_inbox_can_act = ! class_exists( 'HTS_Subscription' ) || HTS_Subscription::can( 'inbox_actions' );

$nonce    = wp_create_nonce( 'hts_admin_nonce' );
$base_url = admin_url( 'admin.php?page=hts-light-dashboard' );
$ajax_url = admin_url( 'admin-ajax.php' );

$active_sub = isset( $_GET['inbox_tab'] ) ? sanitize_key( $_GET['inbox_tab'] ) : 'pending';
if ( ! in_array( $active_sub, array( 'pending', 'history' ), true ) ) $active_sub = 'pending';

// ── PERF: Only run queries needed for the active tab ──
if ( class_exists( 'HTS_Workflow_Engine' ) ) HTS_Workflow_Engine::ensure_tables();
$stats         = class_exists( 'HTS_Workflow_Engine' ) ? HTS_Workflow_Engine::get_stats() : array();
$total_pending = (int) ( $stats['pending'] ?? 0 );
$total_done    = (int) ( $stats['done'] ?? 0 );
$total_failed  = (int) ( $stats['failed'] ?? 0 );
$total_blocked = (int) ( $stats['blocked'] ?? 0 );
$total_exec    = $total_done + $total_failed;
$total_resolved = $total_done + $total_failed + $total_blocked + (int) ( $stats['rollbacked'] ?? 0 );
$success_rate  = ( $total_exec > 0 ) ? round( $total_done / $total_exec * 100 ) : 78;

// Feedback loop: always load — needed for hero clicks + history KPIs
$fl_stats = array( 'positive' => 0, 'neutral' => 0, 'negative' => 0, 'algo' => 0, 'total_clicks_gained' => 0 );
if ( $total_done > 0 && class_exists( 'HTS_Feedback_Loop' ) && method_exists( 'HTS_Feedback_Loop', 'compute_impact_summary' ) ) {
	$fl_raw = HTS_Feedback_Loop::compute_impact_summary( 30 );
	if ( is_array( $fl_raw ) ) { $fl_stats = array_merge( $fl_stats, $fl_raw ); $fl_stats['total_clicks_gained'] = max( 0, (int) ( $fl_raw['net_clicks'] ?? 0 ) ); }
}

// Inbox pages: always load — both tabs rendered client-side
$inbox_pages = class_exists( 'HTS_Workflow_Engine' ) ? HTS_Workflow_Engine::get_inbox_by_page() : array();

// Weekly budget: needed for hero subtitle + pending banner (1 light GROUP BY)
$weekly_usage = class_exists( 'HTS_Workflow_Engine' ) && method_exists( 'HTS_Workflow_Engine', 'get_weekly_usage' ) ? HTS_Workflow_Engine::get_weekly_usage() : array();
$budget_used = 0; $budget_max = 0;
foreach ( $weekly_usage as $info ) {
	$m = (int) ( $info['max'] ?? 0 );
	if ( $m <= 0 ) continue; // max=0 means unlimited — skip
	$budget_used += (int) ( $info['used'] ?? 0 );
	$budget_max  += $m;
}
$budget_remaining = max( 0, $budget_max - $budget_used );

// GSC connected?
$has_gsc = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();

// ── STATIC LOOKUPS (defined once, not per-action) ──
$type_to_facet = array(
	'add_meta_title' => 'meta', 'add_meta_desc' => 'meta', 'optimize_meta_title' => 'meta',
	'optimize_meta_desc' => 'meta', 'optimize_meta_both' => 'meta', 'bulk_optimize_metas' => 'meta',
	'add_internal_links' => 'liens', 'fix_orphan_links' => 'liens', 'redirect' => 'liens',
	'content_refresh' => 'contenu', 'enrich_thin_content' => 'contenu', 'add_faq' => 'contenu',
	'fix_image_alt' => 'contenu', 'add_featured_image' => 'contenu', 'differentiate' => 'contenu', 'merge' => 'contenu',
	'article_write' => 'contenu', 'generate_article' => 'contenu', 'create_cocon_articles' => 'contenu',
	'schedule_publication' => 'contenu', 'schedule_publish' => 'contenu', 'delete_page' => 'contenu',
	'geo_optimize' => 'ia', 'coach_suggestion' => 'ia',
);
$geo_labels = array( 'faq_lists' => 'Ajouter une FAQ', 'intro_direct' => 'Reformuler l\'intro', 'data_stats' => 'Enrichir avec des données', 'images_alt' => 'Ajouter des images avec ALT', 'meta_seo' => 'Compléter les meta', 'sources_citations' => 'Ajouter des sources', 'structured_data' => 'Ajouter du structured data', 'content_depth' => 'Enrichir le contenu', 'entity_coverage' => 'Couvrir les entités clés', 'heading_structure' => 'Améliorer la structure H2/H3', 'content_freshness' => 'Mettre à jour le contenu', 'internal_links' => 'Ajouter des liens internes' );
$actionable_types = array( 'add_meta_title', 'add_meta_desc', 'optimize_meta_title', 'optimize_meta_desc', 'optimize_meta_both', 'add_internal_links', 'fix_orphan_links', 'add_featured_image', 'fix_image_alt', 'add_faq' );
$actionable_geo = array( 'faq_lists' );
$facet_pills = array(
	array( 'id' => 'all',     'label' => 'Tous',          'icon' => '' ),
	array( 'id' => 'meta',    'label' => 'Titres & Metas','icon' => '' ),
	array( 'id' => 'liens',   'label' => 'Liens',         'icon' => 'link' ),
	array( 'id' => 'contenu', 'label' => 'Contenu',       'icon' => 'edit' ),
	array( 'id' => 'ia',      'label' => 'Visibilité IA', 'icon' => 'bot' ),
);

// ── SINGLE ENRICHMENT PASS (facet counts + score + cocon names) ──
// Note: get_post_meta already cached by compute_page_priority inside get_inbox_by_page
$facet_counts = array( 'all' => 0, 'meta' => 0, 'liens' => 0, 'contenu' => 0, 'ia' => 0 );
$cocon_names  = array();
foreach ( $inbox_pages as &$_pg ) {
	$pid = (int) ( $_pg['post_id'] ?? 0 );
	if ( $pid > 0 ) {
		$_pg['score']     = (int) get_post_meta( $pid, '_hts_combined_score', true );
		$_pg['position']  = round( (float) get_post_meta( $pid, '_hts_gsc_position', true ), 1 );
		$_pg['post_type'] = get_post_type( $pid ) ?: 'post';
	}
	$_pg['_facets'] = array();
	$impact_sum = 0;
	foreach ( $_pg['actions'] ?? array() as $a ) {
		$atype = $a['type'] ?? '';
		$facet = $type_to_facet[ $atype ] ?? 'contenu';
		$_pg['_facets'][ $facet ] = true;
		$facet_counts[ $facet ]++;
		$facet_counts['all']++;
		$dp = $a['data_parsed'] ?? array();
		$imp_str = $dp['impact'] ?? $dp['estimated_impact'] ?? '';
		if ( preg_match( '/(\d+)/', $imp_str, $_im ) ) $impact_sum += (int) $_im[1];
		$cn = $dp['cluster'] ?? '';
		if ( $cn && ! isset( $cocon_names[ $cn ] ) ) $cocon_names[ $cn ] = true;
	}
	$_pg['score_after'] = min( 100, ( $_pg['score'] ?? 0 ) + $impact_sum );
}
unset( $_pg );
$cocon_names = array_keys( $cocon_names );
sort( $cocon_names );
?>

<script>
/* _toast global — doit être disponible AVANT le HTML des actions (boutons onclick inline) */
function _toast(msg,type){var n=document.createElement('div');n.style.cssText='position:fixed;top:20px;right:20px;padding:12px 20px;border-radius:8px;font-size:13px;font-weight:600;z-index:999999;animation:fadeIn .3s;box-shadow:0 4px 12px rgba(0,0,0,.1);'+(type==='error'?'background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;':type==='success'?'background:#F0FDF4;color:#16A34A;border:1px solid #BBF7D0;':'background:#EFF6FF;color:#2563EB;border:1px solid #BFDBFE;');n.textContent=msg;document.body.appendChild(n);setTimeout(function(){n.remove()},4000)}
</script>
<?php echo HTS_DS::page_open( true ); ?>

<?php // ── HERO ── ?>
<div class="hts-hero" style="display:flex;align-items:center;justify-content:space-between;position:relative;overflow:hidden;padding:36px 40px 32px">
	<div style="position:absolute;top:-30px;right:-30px;width:180px;height:180px;border-radius:50%;background:radial-gradient(circle,<?php echo $success_rate >= 70 ? 'rgba(0,210,106,.08)' : 'rgba(245,158,11,.08)'; ?> 0%,transparent 70%);pointer-events:none"></div>
	<div style="flex:1;z-index:1">
		<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
			<span style="width:8px;height:8px;border-radius:50%;background:<?php echo $success_rate >= 70 ? 'var(--hts-success)' : 'var(--hts-caution)'; ?>;animation:htsPulse 2s ease-in-out infinite"></span>
			<span style="font-size:11px;font-weight:600;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:.08em">Cette semaine</span>
		</div>
		<h1 class="hts-hero__title" style="font-size:34px;letter-spacing:-.04em;line-height:1.15"><?php echo $total_pending; ?> action<?php echo $total_pending > 1 ? 's' : ''; ?> vous attend<?php echo $total_pending > 1 ? 'ent' : ''; ?>.</h1>
		<p class="hts-hero__sub" style="margin:10px 0 24px;line-height:1.6"><?php
				// Segment 1: X appliquée(s)
				$hero_parts = array();
				if ( $total_done > 0 ) {
					$hero_parts[] = $total_done . ' appliquée' . ( $total_done > 1 ? 's' : '' );
				}
				// Segment 2: +N clics mesurés (only if GSC connected + data)
				if ( $fl_stats['total_clicks_gained'] > 0 ) {
					$hero_parts[] = '<span style="color:var(--hts-success);font-weight:700">+' . (int) $fl_stats['total_clicks_gained'] . ' clics</span> mesurés';
				}
				// Segment 3: X/Y budget semaine
				if ( $budget_max > 0 ) {
					$hero_parts[] = $budget_remaining > 0
						? $budget_used . '/' . $budget_max . ' budget semaine'
						: '<span style="color:var(--hts-caution);font-weight:600">Limite semaine atteinte</span>';
				}
				if ( ! empty( $hero_parts ) ) {
					echo implode( ' · ', $hero_parts );
				} elseif ( ! $has_gsc ) {
					echo '<span style="opacity:.55">Connectez GSC pour mesurer l\'impact</span>';
				} else {
					echo '<span style="opacity:.55">En attente des premières actions</span>';
				}
			?></p>
		<div style="display:flex;gap:10px">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard' ) ); ?>" style="display:flex;align-items:center;gap:8px;padding:11px 22px;border-radius:12px;border:none;background:#fff;color:var(--hts-text);font-size:13px;font-weight:700;text-decoration:none;font-family:var(--hts-font)">
				Tableau de bord
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=coach' ) ); ?>" style="display:flex;align-items:center;gap:8px;padding:11px 22px;border-radius:12px;border:none;background:var(--hts-geo);color:#fff;font-size:13px;font-weight:700;text-decoration:none;font-family:var(--hts-font)">
				<?php echo HTS_DS::icon( 'brain', 14, '#fff' ); ?> Coach IA
			</a>
		</div>
	</div>
	<div style="display:flex;flex-direction:column;align-items:center;gap:6px;z-index:1">
		<?php $rs = 88; $rsw = 5; $rr = ( $rs - $rsw ) / 2; $rci = 2 * M_PI * $rr; $roff = $rci * ( 1 - $success_rate / 100 );
		$rcol = $success_rate >= 70 ? 'var(--hts-success)' : ( $success_rate >= 40 ? 'var(--hts-caution)' : 'var(--hts-danger)' ); ?>
		<svg width="<?php echo $rs; ?>" height="<?php echo $rs; ?>" style="transform:rotate(-90deg);flex-shrink:0">
			<circle cx="<?php echo $rs/2; ?>" cy="<?php echo $rs/2; ?>" r="<?php echo $rr; ?>" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="<?php echo $rsw; ?>"/>
			<circle cx="<?php echo $rs/2; ?>" cy="<?php echo $rs/2; ?>" r="<?php echo $rr; ?>" fill="none" stroke="<?php echo $rcol; ?>" stroke-width="<?php echo $rsw; ?>" stroke-dasharray="<?php echo round($rci,2); ?>" stroke-dashoffset="<?php echo round($roff,2); ?>" stroke-linecap="round"/>
			<text x="<?php echo $rs/2; ?>" y="<?php echo $rs/2; ?>" text-anchor="middle" dominant-baseline="central" style="transform:rotate(90deg);transform-origin:center;font-size:<?php echo round($rs*.25); ?>px;font-weight:800;fill:#fff;font-family:var(--hts-font)"><?php echo $success_rate; ?>%</text>
		</svg>
		<span style="font-size:9px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.1em">Fiabilité</span>
	</div>
</div>

<?php // ── SUB-NAV (ModeSwitcher — client-side toggle, no reload) ── ?>
<div style="display:inline-flex;gap:2px;padding:3px;background:rgba(120,120,128,.08);border-radius:10px;margin:20px 0 24px">
<?php foreach ( array(
	array( 'id' => 'pending', 'label' => 'Recommandations', 'badge' => $total_pending, 'icon' => 'edit' ),
	array( 'id' => 'history', 'label' => 'Historique & Impact', 'badge' => $total_resolved, 'icon' => 'chart' ),
) as $t ) : $ia = $t['id'] === $active_sub; $url = add_query_arg( array( 'tab' => 'inbox', 'inbox_tab' => $t['id'] ), $base_url ); ?>
	<button type="button" class="hts-inbox-tab-btn<?php echo $ia ? ' active' : ''; ?>" data-tab="<?php echo esc_attr( $t['id'] ); ?>" data-url="<?php echo esc_url( $url ); ?>" style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:8px;border:none;font-family:var(--hts-font);background:<?php echo $ia ? 'var(--hts-bg)' : 'transparent'; ?>;box-shadow:<?php echo $ia ? '0 1px 3px rgba(0,0,0,.08),0 1px 1px rgba(0,0,0,.06),0 0 0 .5px rgba(0,0,0,.04)' : 'none'; ?>;color:<?php echo $ia ? 'var(--hts-text)' : 'rgba(60,60,67,.45)'; ?>;font-size:12px;font-weight:<?php echo $ia ? '600' : '500'; ?>;cursor:pointer;transition:all .2s">
		<?php echo HTS_DS::icon( $t['icon'], 13, 'currentColor' ); ?>
		<?php echo esc_html( $t['label'] ); ?>
		<?php if ( $t['badge'] > 0 ) : ?><span style="min-width:18px;height:18px;border-radius:9px;padding:0 5px;background:<?php echo $ia ? 'var(--hts-accent)' : 'var(--hts-danger)'; ?>;color:#fff;font-size:11px;font-weight:700;display:inline-flex;align-items:center;justify-content:center"><?php echo $t['badge']; ?></span><?php endif; ?>
	</button>
<?php endforeach; ?>
</div>

<?php // ═══ TAB 1 — RECOMMANDATIONS ═══ ?>
<div id="hts-tab-pending" style="display:<?php echo $active_sub === 'pending' ? 'block' : 'none'; ?>">

<?php if ( empty( $inbox_pages ) ) : ?>
<?php
$_inbox_can_act = ! class_exists( 'HTS_Subscription' ) || HTS_Subscription::can( 'inbox_actions' );
if ( ! $_inbox_can_act ) : ?>
	<div style="text-align:center;padding:48px 20px">
		<div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#6366f1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px"><?php echo HTS_DS::icon( 'inbox', 28, '#fff' ); ?></div>
		<div style="font-size:16px;font-weight:700;color:var(--hts-text);margin-bottom:8px">Recommandations IA</div>
		<div style="font-size:13px;color:var(--hts-text-2);max-width:400px;margin:0 auto 20px;line-height:1.6">Chaque semaine, l'IA analyse votre site et vous propose des actions : titres à améliorer, liens à créer, contenus à mettre à jour. Appliquez en un clic.</div>
		<a href="https://hacktheseo.com/pricing" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;text-decoration:none"><?php echo HTS_DS::icon( 'zap', 16, '#fff' ); ?> Passer à Ultra — 249€/mois</a>
	</div>
<?php else : ?>
	<?php echo HTS_DS::empty_state( 'Tout est à jour', 'Aucune recommandation en attente. Lancez un audit pour que les agents analysent votre site.' ); ?>
	<div style="text-align:center;margin-top:-10px;padding-bottom:20px">
		<button type="button" id="hts-inbox-scan-btn" style="display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:linear-gradient(135deg,var(--hts-geo),var(--hts-accent));color:#fff;border:none;border-radius:var(--hts-radius-sm);font-size:14px;font-weight:700;cursor:pointer;font-family:var(--hts-font);box-shadow:0 4px 16px rgba(99,102,241,.25)"><?php echo HTS_DS::icon( 'search', 16, '#fff' ); ?> Lancer l'audit complet</button>
	</div>
<?php endif; ?>
<?php else : ?>

<?php // ── Weekly budget banner (data already loaded at top level) ── ?>
<?php if ( $total_pending > 0 && $budget_max > 0 ) : ?>
<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:<?php echo $budget_remaining > 0 ? 'var(--hts-caution-bg)' : 'var(--hts-danger-bg)'; ?>;border:1px solid <?php echo $budget_remaining > 0 ? 'var(--hts-caution)' : 'var(--hts-danger)'; ?>;border-radius:var(--hts-radius-sm);margin-bottom:14px;font-size:12px;color:var(--hts-text-2)">
	<?php echo HTS_DS::icon( $budget_remaining > 0 ? 'zap' : 'alert', 14, $budget_remaining > 0 ? 'var(--hts-caution)' : 'var(--hts-danger)' ); ?>
	<div style="flex:1"><?php if ( $budget_remaining > 0 ) : ?><strong>Rythme progressif :</strong> <?php echo $budget_remaining; ?> actions restantes cette semaine.<?php else : ?><strong>Limite hebdo atteinte.</strong> Les prochaines actions seront traitées la semaine prochaine.<?php endif; ?></div>
</div>
<?php endif; ?>

<?php // ── Facet filters (maquette L185-196) ── ?>
<div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap">
	<div style="display:flex;gap:6px;flex-wrap:wrap">
	<?php foreach ( $facet_pills as $fi => $fp ) :
		$fc = $fp['id'] === 'all' ? $facet_counts['all'] : ( $facet_counts[ $fp['id'] ] ?? 0 );
		if ( $fp['id'] !== 'all' && $fc === 0 ) continue;
		$is_first = $fi === 0;
	?>
		<button type="button" class="hts-inbox-filter<?php echo $is_first ? ' active' : ''; ?>" data-facet="<?php echo esc_attr( $fp['id'] ); ?>" style="display:flex;align-items:center;gap:5px;padding:7px 14px;border-radius:20px;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);background:<?php echo $is_first ? 'var(--hts-accent)' : 'transparent'; ?>;border:1.5px solid <?php echo $is_first ? 'transparent' : 'var(--hts-border)'; ?>;color:<?php echo $is_first ? '#fff' : 'var(--hts-text-2)'; ?>">
			<?php if ( $fp['icon'] ) echo HTS_DS::icon( $fp['icon'], 12, 'currentColor' ); ?>
			<?php echo esc_html( $fp['label'] ); ?> <span style="opacity:.7">(<?php echo $fc; ?>)</span>
		</button>
	<?php endforeach; ?>
	</div>
	<div style="flex:1"></div>
	<?php if ( ! empty( $cocon_names ) ) : ?>
	<select id="hts-inbox-cocon" style="padding:7px 12px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-border);font-size:12px;font-weight:500;color:var(--hts-text-2);background:var(--hts-bg);font-family:var(--hts-font);cursor:pointer">
		<option value="">Tous les cocons</option>
		<?php foreach ( $cocon_names as $cn ) : ?><option value="<?php echo esc_attr( $cn ); ?>"><?php echo esc_html( mb_substr( $cn, 0, 30 ) ); ?></option><?php endforeach; ?>
	</select>
	<?php endif; ?>
</div>

<?php // ── Page cards (maquette L199-234) ── ?>
<div id="hts-inbox-pages">
<?php $page_idx = 0; foreach ( $inbox_pages as $pg ) :
	$pid       = (int) ( $pg['post_id'] ?? 0 );
	$ptitle    = $pg['post_title'] ?? 'Page #' . $pid;
	$pscore    = (int) ( $pg['score'] ?? 0 );
	$pscore_a  = (int) ( $pg['score_after'] ?? $pscore );
	$ptype     = $pg['post_type'] ?? 'post';
	$actions   = $pg['actions'] ?? array();
	$act_ct    = count( $actions );
	if ( ! $act_ct ) continue;
	$pri       = $pg['priority'] ?? array();
	$pri_label = $pri['label'] ?? 'medium';
	$pri_col   = array( 'critical' => 'var(--hts-danger)', 'high' => 'var(--hts-danger)', 'medium' => 'var(--hts-caution)', 'low' => 'var(--hts-text-3)' )[ $pri_label ] ?? 'var(--hts-accent)';
	$signals   = $pri['signals'] ?? array();
	$facets_str = implode( ',', array_keys( $pg['_facets'] ?? array() ) );
	$cluster   = '';
	foreach ( $actions as $a ) { $cl = ( $a['data_parsed'] ?? array() )['cluster'] ?? ''; if ( $cl ) { $cluster = $cl; break; } }
?>
<div class="hts-ds-card hts-inbox-page-card<?php echo $page_idx >= 10 ? ' hts-page-hidden' : ''; ?>" style="padding:0;margin-bottom:14px;overflow:hidden" data-pid="<?php echo $pid; ?>" data-facets="<?php echo esc_attr( $facets_str ); ?>" data-cluster="<?php echo esc_attr( $cluster ); ?>">
<?php $page_idx++; ?>
	<div role="button" tabindex="0" onclick="htsInboxToggle(this.parentNode)" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();htsInboxToggle(this.parentNode)}" aria-expanded="false" style="width:100%;display:flex;align-items:center;gap:14px;padding:18px 22px;border:none;background:none;cursor:pointer;font-family:var(--hts-font);text-align:left">
		<div style="width:10px;height:10px;border-radius:50%;background:<?php echo $pri_col; ?>;flex-shrink:0"></div>
		<div style="flex:1;min-width:0">
			<div style="display:flex;align-items:center;gap:8px">
				<span style="font-size:15px;font-weight:700;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php if ( ! empty( $pg['edit_url'] ) ) : ?><a href="<?php echo esc_url( $pg['edit_url'] ); ?>" target="_blank" style="color:inherit;text-decoration:none;padding:0;background:none;box-shadow:none" onclick="event.stopPropagation()"><?php echo esc_html( $ptitle ); ?></a><?php else : ?><?php echo esc_html( $ptitle ); ?><?php endif; ?></span>
				<?php echo HTS_DS::badge( $ptype === 'page' ? 'Page' : 'Article', $ptype === 'page' ? 'accent' : 'default' ); ?>
				<?php echo HTS_DS::badge( $act_ct . ' action' . ( $act_ct > 1 ? 's' : '' ) ); ?>
			</div>
			<div style="font-size:12px;color:var(--hts-text-3);margin-top:3px"><?php echo ! empty( $signals ) ? esc_html( implode( ' · ', $signals ) ) : esc_html( $act_ct . ' optimisation' . ( $act_ct > 1 ? 's' : '' ) . ' possible' . ( $act_ct > 1 ? 's' : '' ) ); ?></div>
		</div>
		<div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
			<?php if ( $pscore > 0 ) : ?><?php echo HTS_DS::ring( $pscore, 36, 3 ); ?><?php if ( $pscore_a > $pscore ) : ?><?php echo HTS_DS::icon( 'chevron-right', 12, 'var(--hts-text-3)' ); ?><?php echo HTS_DS::ring( $pscore_a, 36, 3 ); ?><?php endif; ?>
			<?php else : ?><span style="font-size:12px;font-weight:700;color:var(--hts-danger);padding:4px 10px;border-radius:6px;border:1.5px solid var(--hts-danger)"><?php echo $act_ct; ?></span><?php endif; ?>
		</div>
		<div class="hts-inbox-chev" style="transition:transform .15s"><?php echo HTS_DS::icon( 'chevron-down', 16, 'var(--hts-text-3)' ); ?></div>
	</div>

	<div class="hts-inbox-actions" style="display:none;border-top:1px solid var(--hts-border-sub)">
	<?php foreach ( $actions as $ai => $a ) :
		$aid = (int) ( $a['id'] ?? 0 ); $atype = $a['type'] ?? ''; $agent = $a['agent'] ?? '';
		$d = $a['data_parsed'] ?? array(); // already decoded by get_inbox_by_page
		$facet = $type_to_facet[ $atype ] ?? 'contenu';
		$is_geo = ( $atype === 'geo_optimize' ); $is_link = ( ( $agent === 'linking' || $atype === 'add_internal_links' || $atype === 'fix_orphan_links' ) && ( ! empty( $d['target_id'] ) || ! empty( $d['target_title'] ) ) );
		// Détection ancre stale (obsolète)
		$is_stale = false;
		if ( $is_link && ( $d['anchor_type'] ?? '' ) === 'extract' && ! empty( $d['anchor_text'] ) ) {
			if ( ! isset( $content_cache ) ) $content_cache = array();
			$_pid = (int) ( $a['post_id'] ?? 0 );
			if ( $_pid && ! isset( $content_cache[ $_pid ] ) ) {
				$_raw = get_post_field( 'post_content', $_pid );
				$content_cache[ $_pid ] = str_replace( array( "\xC2\xA0", "\xA0", "\xE2\x80\x98", "\xE2\x80\x99" ), array( ' ', ' ', "'", "'" ), mb_strtolower( wp_strip_all_tags( html_entity_decode( $_raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
			}
			if ( $_pid && isset( $content_cache[ $_pid ] ) ) {
				$_anc = str_replace( array( "\xC2\xA0", "\xA0", "\xE2\x80\x98", "\xE2\x80\x99" ), array( ' ', ' ', "'", "'" ), mb_strtolower( trim( $d['anchor_text'] ) ) );
				$is_stale = ( mb_strpos( $content_cache[ $_pid ], $_anc ) === false );
			}
		}
		$criterion = $d['criterion'] ?? '';
		$alabel = $a['type_label'] ?? ucfirst( str_replace( '_', ' ', $atype ) );
		if ( $is_geo ) $alabel = $geo_labels[ $criterion ] ?? $alabel;
		$suggestion = $d['suggestion'] ?? ( $a['suggestion'] ?? '' );
		$suggestion = preg_replace( '/^Score visibilit[ée] IA\s*:\s*\d+\/100\s*[—–-]\s*/u', '', $suggestion );
		$badge_t = $is_geo ? 'geo' : 'accent';
		$badge_l = $is_geo ? 'IA' : 'SEO';
		$can_act = in_array( $atype, $actionable_types, true ) || ( $is_geo && in_array( $criterion, $actionable_geo, true ) );
	?>
	<div class="hts-inbox-action" data-aid="<?php echo $aid; ?>" data-facet="<?php echo esc_attr( $facet ); ?>" style="padding:14px 22px;<?php echo $ai > 0 ? 'border-top:1px solid var(--hts-border-sub);' : ''; ?><?php echo $is_geo ? 'background:var(--hts-geo-soft);' : ''; ?>">
		<div style="display:flex;align-items:flex-start;gap:12px">
			<div style="flex:1;min-width:0">
				<?php if ( $is_link && ! empty( $d['target_title'] ) ) : ?>
				<?php
					$link_dir = '';
					if ( ! empty( $d['link_type'] ) ) {
						if ( $d['link_type'] === 'child_to_pillar' ) $link_dir = "enfant \xe2\x86\x92 pilier";
						elseif ( $d['link_type'] === 'pillar_to_child' ) $link_dir = "pilier \xe2\x86\x92 enfant";
					}
				?>
				<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
					<?php echo HTS_DS::badge( $badge_l, $badge_t ); ?>
					<span style="font-size:13px;font-weight:700;color:var(--hts-text)">Ajouter un lien</span>
					<?php if ( $link_dir ) : ?><span style="font-size:11px;color:var(--hts-text-3)"><?php echo esc_html( $link_dir ); ?></span><?php endif; ?>
				</div>
				<div style="display:flex;align-items:baseline;gap:6px;flex-wrap:wrap">
					<svg width="12" height="12" viewBox="0 0 24 24" fill="none" style="flex-shrink:0;margin-top:2px"><path d="M5 12h14M12 5l7 7-7 7" stroke="var(--hts-accent)" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
					<?php if ( ! empty( $d['target_url'] ) ) : ?><a href="<?php echo esc_url( $d['target_url'] ); ?>" target="_blank" style="font-size:12px;font-weight:600;color:var(--hts-accent);text-decoration:none;padding:0;background:none;box-shadow:none" onclick="event.stopPropagation()"><?php echo esc_html( wp_trim_words( $d['target_title'], 10 ) ); ?></a>
					<?php else : ?><span style="font-size:12px;font-weight:600;color:var(--hts-accent)"><?php echo esc_html( wp_trim_words( $d['target_title'], 10 ) ); ?></span><?php endif; ?>
				</div>
				<?php if ( ! empty( $d['anchor_text'] ) ) : ?><div style="font-size:11px;color:var(--hts-text-3);margin-top:2px;font-style:italic">"<?php echo esc_html( mb_substr( $d['anchor_text'], 0, 80 ) ); ?><?php echo mb_strlen( $d['anchor_text'] ?? '' ) > 80 ? '…' : ''; ?>"</div><?php endif; ?>
				<?php else : ?>
				<div style="display:flex;align-items:center;gap:8px;<?php echo $suggestion ? 'margin-bottom:4px' : ''; ?>">
					<?php echo HTS_DS::badge( $badge_l, $badge_t ); ?>
					<?php if ( $is_geo ) echo HTS_DS::icon( 'bot', 14, 'var(--hts-geo)' ); ?>
					<span style="font-size:13px;font-weight:700;color:var(--hts-text)"><?php echo esc_html( $alabel ); ?></span>
				</div>
				<?php if ( $suggestion ) : ?><div style="font-size:12px;color:var(--hts-text-2);line-height:1.4"><?php echo esc_html( mb_substr( $suggestion, 0, 100 ) ); ?><?php echo mb_strlen( $suggestion ) > 100 ? '…' : ''; ?></div><?php endif; ?>
				<?php endif; ?>
			</div>
			<div style="display:flex;gap:6px;flex-shrink:0" <?php if ( $is_stale ) echo 'data-stale="true"'; ?>>
				<?php if ( ! $_inbox_can_act ) : ?>
				<span style="padding:4px 10px;border-radius:6px;font-size:10px;font-weight:600;background:var(--hts-border);color:var(--hts-text-3);white-space:nowrap">Ultra requis</span>
			<?php elseif ( $is_stale ) : ?>
				<span style="padding:4px 10px;border-radius:6px;font-size:10px;font-weight:600;background:var(--hts-caution-bg);color:#92400E;border:1px solid var(--hts-caution);white-space:nowrap">Ancre à recalculer</span>
				<button type="button" class="hts-ds-btn hts-ds-btn--sm" style="border-color:var(--hts-caution);color:var(--hts-caution);font-size:10px" onclick="event.stopPropagation();htsInboxPost('hts_inbox_refresh_anchor',{action_id:<?php echo $aid; ?>},function(d){if(d.success){_toast('Nouvelle ancre : \u00ab '+d.data.new_anchor+' \u00bb','success');setTimeout(function(){location.reload()},1500)}else{_toast(d.data||'Aucun passage trouv\u00e9','error')}})">Nouvelle ancre</button>
				<?php elseif ( $can_act ) : ?><button type="button" class="hts-ds-btn hts-ds-btn--success hts-ds-btn--sm hts-inbox-apply" data-aid="<?php echo $aid; ?>">Appliquer</button>
				<?php else : ?><button type="button" class="hts-ds-btn hts-ds-btn--sm" disabled style="opacity:.5;cursor:not-allowed;background:var(--hts-text-3);color:#fff;border:none">Bientôt</button><?php endif; ?>
				<button type="button" class="hts-inbox-dismiss" data-aid="<?php echo $aid; ?>" aria-label="Ignorer cette action" style="width:30px;height:30px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center"><?php echo HTS_DS::icon( 'x', 12, 'var(--hts-text-3)' ); ?></button>
			</div>
		</div>
	</div>
	<?php endforeach; ?>
	<?php
	// Count actionable items for accurate button label
	$actionable_ct = 0;
	foreach ( $actions as $_ac ) {
		$_at = $_ac['type'] ?? '';
		$_cr = ( $_ac['data_parsed'] ?? array() )['criterion'] ?? '';
		if ( in_array( $_at, $actionable_types, true ) || ( $_at === 'geo_optimize' && in_array( $_cr, $actionable_geo, true ) ) ) $actionable_ct++;
	}
	?>
	<?php if ( $actionable_ct > 1 ) : ?>
	<div style="display:flex;justify-content:flex-end;gap:8px;padding:12px 22px;border-top:1px solid var(--hts-border-sub);background:var(--hts-surface)">
		<?php if ( $_inbox_can_act ) : ?>
		<button type="button" class="hts-ds-btn hts-ds-btn--sm hts-inbox-apply-page" data-pid="<?php echo $pid; ?>" style="display:flex;align-items:center;gap:5px;background:var(--hts-accent);color:#fff;border:none"><?php echo HTS_DS::icon( 'check', 12, '#fff' ); ?> Tout appliquer (<?php echo $actionable_ct; ?>)</button>
		<?php else : ?>
		<div style="flex:1;display:flex;align-items:center;gap:8px">
			<span style="font-size:11px;color:var(--hts-text-3)">Passez à Ultra pour appliquer automatiquement</span>
			<a href="https://hacktheseo.com/pricing" target="_blank" style="padding:4px 12px;border-radius:6px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:10px;font-weight:700;text-decoration:none;white-space:nowrap">Ultra — 249€/mois</a>
		</div>
		<?php endif; ?>
		<button type="button" class="hts-ds-btn hts-ds-btn--sm hts-inbox-ignore-page" data-pid="<?php echo $pid; ?>" style="border:1px solid var(--hts-border)">Ignorer</button>
	</div>
	<?php endif; ?>
	</div>
</div>
<?php endforeach; ?>
</div>

<?php $hidden_ct = max( 0, $page_idx - 10 ); if ( $hidden_ct > 0 ) : ?>
<div style="text-align:center;margin-bottom:16px">
	<button type="button" id="hts-inbox-show-more" style="padding:10px 24px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-border);background:var(--hts-bg);font-size:13px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Voir <?php echo $hidden_ct; ?> page<?php echo $hidden_ct > 1 ? 's' : ''; ?> de plus</button>
</div>
<?php endif; ?>

<div style="text-align:center;padding:24px 0"><div style="display:flex;gap:12px;justify-content:center">
	<button type="button" id="hts-inbox-scan-footer" class="hts-ds-btn" style="display:flex;align-items:center;gap:6px;padding:10px 20px;background:linear-gradient(135deg,var(--hts-geo),var(--hts-accent));color:#fff;font-size:13px;font-weight:700;border:none;box-shadow:0 4px 16px rgba(99,102,241,.25)"><?php echo HTS_DS::icon( 'search', 14, '#fff' ); ?> Lancer l'audit</button>
</div></div>
<?php endif; ?>
</div>

<?php // ═══ TAB 2 — HISTORIQUE & IMPACT ═══ ?>
<div id="hts-tab-history" style="display:<?php echo $active_sub === 'history' ? 'block' : 'none'; ?>">
<div id="hts-examiner-inject"></div>
<div id="hts-kpi-grid" style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin:24px 0">
<?php $kpi_ids = array('hts-kpi-positive','hts-kpi-neutral','hts-kpi-negative','hts-kpi-algo');
foreach ( array(
	array( 'n' => $fl_stats['positive'], 'l' => 'En hausse', 'c' => 'var(--hts-success)', 'i' => 'trending' ),
	array( 'n' => $fl_stats['neutral'],  'l' => 'Stables',   'c' => 'var(--hts-caution)', 'i' => 'chart' ),
	array( 'n' => $fl_stats['negative'], 'l' => 'En baisse', 'c' => 'var(--hts-danger)',  'i' => 'alert' ),
	array( 'n' => $fl_stats['algo'],     'l' => 'MAJ Google', 'c' => 'var(--hts-accent)',  'i' => 'refresh' ),
) as $ki => $k ) : ?>
<div class="hts-ds-card" id="<?php echo $kpi_ids[$ki]; ?>" style="padding:16px 18px;text-align:center">
	<div class="hts-kpi-value" style="font-size:26px;font-weight:800;color:<?php echo $k['c']; ?>;line-height:1"><?php echo (int) $k['n']; ?></div>
	<div style="display:flex;align-items:center;justify-content:center;gap:5px;margin-top:6px"><?php echo HTS_DS::icon( $k['i'], 12, $k['c'] ); ?><span style="font-size:10px;color:var(--hts-text-3);text-transform:uppercase;font-weight:600"><?php echo esc_html( $k['l'] ); ?></span></div>
</div>
<?php endforeach; ?>
</div>
<div style="font-size:11px;color:var(--hts-text-3);margin-bottom:16px;padding:8px 14px;background:var(--hts-surface);border:1px solid var(--hts-border-sub);border-radius:var(--hts-radius-sm)">
	<?php echo HTS_DS::icon( 'chart', 12, 'var(--hts-text-3)' ); ?>
	Impact mesuré via Google Search Console (positions, clics) sur les 30 derniers jours.
	<?php if ( ! $has_gsc ) : ?>
		<strong style="color:var(--hts-caution)">GSC non connecté</strong> — <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-seo-settings' ) ); ?>" style="color:var(--hts-accent);text-decoration:underline;padding:0;background:none;box-shadow:none">connecter GSC</a> pour mesurer l'impact réel.
	<?php endif; ?>
</div>
<div id="hts-inbox-history"><div style="text-align:center;padding:30px;color:var(--hts-text-3);font-size:12px">Chargement…</div></div>
</div>

<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>

<?php // ═══ PREVIEW MODAL ═══ ?>
<div id="hts-preview-overlay" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);align-items:center;justify-content:center">
<div id="hts-preview-modal" role="dialog" aria-modal="true" aria-label="Aperçu avant application" style="width:560px;max-width:94vw;max-height:80vh;overflow-y:auto;background:var(--hts-bg);border-radius:20px;box-shadow:0 24px 80px rgba(0,0,0,.2);padding:0;font-family:var(--hts-font)" onclick="event.stopPropagation()">
<div id="hts-preview-content" style="padding:28px 32px">
	<div style="text-align:center;padding:48px 20px"><div style="width:28px;height:28px;border:3px solid var(--hts-border);border-top-color:var(--hts-accent);border-radius:50%;margin:0 auto 14px;animation:htsSpin .7s linear infinite"></div><div style="font-size:13px;color:var(--hts-text-3)">Chargement de l'aperçu…</div></div>
</div>
</div>
</div>

<style>
@keyframes htsPulse{0%,100%{opacity:1}50%{opacity:.4}}
/* WP admin button reset — blanket for all inbox buttons */
.hts-ds-page button,.hts-ds-page a.hts-ds-btn{line-height:1.4;box-sizing:border-box}
.hts-inbox-tab-btn{line-height:1.4;box-sizing:border-box}
#hts-preview-overlay{transition:opacity .15s}
#hts-preview-modal{animation:htsModalIn .2s ease-out}
#hts-preview-modal a{padding:0;background:none;box-shadow:none;text-decoration:none}
#hts-preview-modal button{line-height:1.4;box-sizing:border-box}
@keyframes htsModalIn{from{opacity:0;transform:scale(.96) translateY(8px)}to{opacity:1;transform:none}}
@keyframes htsSpin{to{transform:rotate(360deg)}}
#hts-inbox-history button,#hts-inbox-history a,#hts-examiner-inject button{line-height:1.4;box-sizing:border-box}
.hts-inbox-filter{line-height:1.4;box-sizing:border-box}
.hts-inbox-filter.active{background:var(--hts-accent)!important;color:#fff!important;border-color:transparent!important}
.hts-inbox-page-card.expanded .hts-inbox-chev{transform:rotate(180deg)}
.hts-inbox-page-card [role="button"]:focus-visible{outline:2px solid var(--hts-accent);outline-offset:-2px;border-radius:var(--hts-radius-sm)}
.hts-inbox-page-card.hts-page-hidden{display:none}
@media(max-width:768px){[style*="grid-template-columns:1fr 1fr 1fr 1fr"]{grid-template-columns:1fr 1fr!important}#hts-preview-modal{width:96vw!important;padding:0!important}#hts-preview-content{padding:20px 18px!important}}
/* Phase 6.7: Toast — same DS style as cocon-commander */
.hts-inbox-toast{position:fixed;bottom:20px;right:20px;padding:12px 20px;background:var(--hts-text);color:#fff;border-radius:10px;font-size:13px;font-weight:600;z-index:99999;opacity:0;transform:translateY(10px);transition:all .3s;pointer-events:none;font-family:var(--hts-font);max-width:360px}
.hts-inbox-toast.show{opacity:1;transform:translateY(0)}
.hts-inbox-toast.success{background:var(--hts-success)}.hts-inbox-toast.error{background:var(--hts-danger)}
</style>

<script>
(function(){
'use strict';
var nonce='<?php echo esc_js( $nonce ); ?>',ajax='<?php echo esc_js( $ajax_url ); ?>';
function post(a,d,cb){d.action=a;d.nonce=nonce;var _done=false;fetch(ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(d)}).then(function(r){return r.json()}).then(function(j){_done=true;cb(j)}).catch(function(e){if(!_done){cb({success:false,_net_error:true})}else{console.error('HTS callback error:',e)}});}
window.htsInboxPost=post;

/* Phase 6.7: _toast already defined in early <script> block (line 114) — no redefinition needed */

/* Phase 6.6: Modal confirm (replaces native confirm) */
function _modalConfirm(title,msg,okLabel,cls){
	return new Promise(function(resolve){
		var ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99998;display:flex;align-items:center;justify-content:center';
		var m=document.createElement('div');m.style.cssText='background:var(--hts-bg,#fff);border-radius:14px;padding:28px 32px;max-width:420px;width:90%;box-shadow:0 8px 30px rgba(0,0,0,.15);font-family:var(--hts-font)';
		m.innerHTML='<div style="font-size:16px;font-weight:700;color:var(--hts-text,#1a1f36);margin-bottom:8px">'+esc(title)+'</div>'
			+'<div style="font-size:13px;color:var(--hts-text-2,#64748b);margin-bottom:20px;line-height:1.5">'+esc(msg)+'</div>'
			+'<div style="display:flex;gap:8px;justify-content:flex-end">'
			+'<button class="hts-m-cancel" style="padding:8px 16px;border-radius:8px;border:1px solid var(--hts-border,#e5e7eb);background:var(--hts-bg,#fff);font-size:13px;font-weight:600;cursor:pointer;color:var(--hts-text-2)">Annuler</button>'
			+'<button class="hts-m-ok" style="padding:8px 16px;border-radius:8px;border:none;background:'+(cls==='danger'?'var(--hts-danger,#ef4444)':'var(--hts-accent,#2d7ff9)')+';color:#fff;font-size:13px;font-weight:700;cursor:pointer">'+esc(okLabel||'Confirmer')+'</button>'
			+'</div>';
		ov.appendChild(m);document.body.appendChild(ov);
		function close(v){document.body.removeChild(ov);resolve(v)}
		ov.addEventListener('click',function(e){if(e.target===ov)close(false)});
		m.querySelector('.hts-m-cancel').addEventListener('click',function(){close(false)});
		m.querySelector('.hts-m-ok').addEventListener('click',function(){close(true)});
	});
}

window.htsInboxToggle=function(c){var b=c.querySelector('.hts-inbox-actions');if(!b)return;var o=b.style.display==='none';b.style.display=o?'block':'none';c.classList.toggle('expanded',o);var t=c.querySelector('[aria-expanded]');if(t)t.setAttribute('aria-expanded',o?'true':'false')};

/* Auto-expand first 2 visible */
(function(){var c=document.querySelectorAll('.hts-inbox-page-card:not(.hts-page-hidden)');for(var i=0;i<Math.min(2,c.length);i++)htsInboxToggle(c[i])})();

/* Show more — re-apply active filter after reveal */
var sm=document.getElementById('hts-inbox-show-more');
if(sm)sm.addEventListener('click',function(){document.querySelectorAll('.hts-inbox-page-card.hts-page-hidden').forEach(function(c){c.classList.remove('hts-page-hidden')});this.style.display='none';var af=document.querySelector('.hts-inbox-filter.active');var cs=document.getElementById('hts-inbox-cocon');if((af&&af.dataset.facet!=='all')||( cs&&cs.value)){if(af)af.click();else if(cs)cs.dispatchEvent(new Event('change'))}});

/* Facet filters — composes with cocon, skip hts-page-hidden */
document.querySelectorAll('.hts-inbox-filter').forEach(function(btn){btn.addEventListener('click',function(){
	document.querySelectorAll('.hts-inbox-filter').forEach(function(b){b.classList.remove('active');b.style.background='transparent';b.style.color='var(--hts-text-2)';b.style.border='1.5px solid var(--hts-border)'});
	this.classList.add('active');this.style.background='var(--hts-accent)';this.style.color='#fff';this.style.border='1.5px solid transparent';
	var f=this.dataset.facet;var cs=document.getElementById('hts-inbox-cocon');var cv=cs?cs.value:'';
	document.querySelectorAll('.hts-inbox-page-card').forEach(function(c){if(c.classList.contains('hts-page-hidden'))return;var matchFacet=(f==='all'||(c.dataset.facets||'').split(',').indexOf(f)>=0);var matchCluster=(!cv||(c.dataset.cluster||'')===cv);c.style.display=(matchFacet&&matchCluster)?'block':'none'});
})});

/* Cocon filter — composes with active facet */
var cs=document.getElementById('hts-inbox-cocon');
if(cs)cs.addEventListener('change',function(){var v=this.value;var af=document.querySelector('.hts-inbox-filter.active');var facet=af?af.dataset.facet:'all';document.querySelectorAll('.hts-inbox-page-card').forEach(function(c){if(c.classList.contains('hts-page-hidden'))return;var matchCluster=(!v||(c.dataset.cluster||'')===v);var matchFacet=(facet==='all'||(c.dataset.facets||'').split(',').indexOf(facet)>=0);c.style.display=(matchCluster&&matchFacet)?'block':'none'})});

/* Deep-link filter */
(function(){
	var params=new URLSearchParams(window.location.search);
	var didFilter=false;
	var f=params.get('inbox_filter');if(f){var b=document.querySelector('.hts-inbox-filter[data-facet="'+f+'"]');if(b){b.click();didFilter=true}}
	/* Deep-link cluster from Cocon Commander "Voir dans l'Inbox" */
	var cl=params.get('cluster');if(cl){var cs=document.getElementById('hts-inbox-cocon');if(cs){
		/* Fuzzy match: option value may differ slightly from URL param */
		var matched=false;
		for(var i=0;i<cs.options.length;i++){if(cs.options[i].value===cl){cs.selectedIndex=i;matched=true;break}}
		if(!matched){var clLow=cl.toLowerCase();for(var i=0;i<cs.options.length;i++){if(cs.options[i].value.toLowerCase()===clLow){cs.selectedIndex=i;matched=true;break}}}
		if(matched){cs.dispatchEvent(new Event('change'));didFilter=true}
	}}
	/* Re-expand first 2 visible cards after filter changed visibility */
	if(didFilter){var vis=document.querySelectorAll('.hts-inbox-page-card:not(.hts-page-hidden)');var ct=0;for(var i=0;i<vis.length&&ct<2;i++){if(vis[i].style.display!=='none'&&!vis[i].classList.contains('expanded')){htsInboxToggle(vis[i]);ct++}}}
})();

/* ═══ PREVIEW MODAL LOGIC ═══ */
var _prevOverlay=document.getElementById('hts-preview-overlay');
var _prevContent=document.getElementById('hts-preview-content');
var _prevActionId=null,_prevRow=null,_prevBtn=null;
var _prevReqId=0; /* request counter to ignore stale callbacks */
var _prevConfirming=false;
function htsPreviewClose(){if(_prevOverlay)_prevOverlay.style.display='none';_prevActionId=null;
	document.body.style.overflow='';
	/* Reset apply button if user cancels (not confirming) */
	if(!_prevConfirming&&_prevBtn){_prevBtn.disabled=false;_prevBtn.textContent='Appliquer'}
	_prevConfirming=false;
}
window.htsPreviewClose=htsPreviewClose;
if(_prevOverlay)_prevOverlay.addEventListener('click',htsPreviewClose);
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&_prevOverlay&&_prevOverlay.style.display==='flex')htsPreviewClose()});

/* Action type → CEO labels */
var _typeLabels={
	add_meta_title:'Réécriture du titre SEO',add_meta_desc:'Réécriture de la description SEO',
	optimize_meta_title:'Optimisation du titre SEO',optimize_meta_desc:'Optimisation de la description',
	optimize_meta_both:'Optimisation titre + description',
	bulk_optimize_metas:'Optimisation groupée des metas',
	add_internal_links:'Ajout d\u0027un lien interne',fix_orphan_links:'Correction de page orpheline',
	add_faq:'Ajout d\u0027une FAQ',fix_image_alt:'Ajout d\u0027attribut ALT',add_featured_image:'Ajout d\u0027image mise en avant',
	content_refresh:'Rafraichissement du contenu',enrich_thin_content:'Enrichissement du contenu',
	coach_suggestion:'Suggestion du Coach SEO',
	geo_optimize:'Optimisation visibilité IA',
	delete_page:'Suppression de page',
	article_write:'Rédaction d\u0027article',generate_article:'Génération d\u0027article',
	create_cocon_articles:'Création d\u0027articles pour le groupe',
	redirect:'Redirection',differentiate:'Différenciation de contenu',
	merge:'Fusion de pages',schedule_publication:'Publication planifiée',schedule_publish:'Publication planifiée'
};

/* ── Select variant radio — updates "Avant" labels + stores index ── */
var _htsCurVariants=[];
var _htsCurType='';
window.htsSelectVariant=function(idx){
	window._htsSelectedVariant=idx;
	var list=document.getElementById('hts-variant-list');
	if(!list)return;
	var cards=list.querySelectorAll('[data-vi]');
	cards.forEach(function(lb){
		var vi=parseInt(lb.dataset.vi);
		var isSel=(vi===idx);
		lb.style.border=isSel?'1.5px solid var(--hts-success)':'1.5px solid var(--hts-border)';
		lb.style.background=isSel?'var(--hts-success-bg)':'var(--hts-bg)';
		/* Update radio dot — targeted by data-role */
		var dot=lb.querySelector('[data-role="radio"]');
		if(dot){
			dot.style.borderColor=isSel?'var(--hts-success)':'var(--hts-border)';
			dot.innerHTML=isSel?'<span style="width:10px;height:10px;border-radius:50%;background:var(--hts-success)"></span>':'';
		}
	});
};

function htsPreviewRender(p){
	var type=p.action_type||'';
	var title=_typeLabels[type]||'Aperçu de l\u0027action';
	var di=p.diff||{};
	var mets=di.metrics||[];
	var lk=p.linking||{};
	var lkOk=lk&&(lk.anchor_text||lk.target_title);
	/* Store variants for htsSelectVariant */
	_htsCurVariants=p.variants||[];
	_htsCurType=type;
	window._htsSelectedVariant=0;
	var h='';

	/* ══ EXTRACT orpheline + cluster from metrics ══ */
	var _orphVal='',_clusterVal='';
	var _inlineMets=[];
	mets.forEach(function(m){
		var lb=(m.label||'').toLowerCase();
		if(lb.indexOf('orpheline')>=0){_orphVal=String(m.value||'');return;}
		if(lb.indexOf('cluster')>=0){_clusterVal=String(m.value||'');return;}
		_inlineMets.push(m);
	});
	var _hasOrph=_orphVal.toLowerCase()==='oui';
	var _isLinkType=(type==='add_internal_links'||type==='fix_orphan_links');
	var _cluster=lk.cluster||_clusterVal||p.cluster||'';

	/* ══ 1. HEADER — clean: title + subtitle + [Voir] [✕] ══ */
	var _sub=(_isLinkType&&_cluster)?_cluster:(p.post_title||'');
	h+='<div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:16px">';
	h+='<div style="flex:1;min-width:0"><div style="font-size:17px;font-weight:800;color:var(--hts-text);line-height:1.3">'+esc(title)+'</div>';
	if(_sub)h+='<div style="font-size:12px;color:var(--hts-text-3);margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(_sub)+'</div>';
	h+='</div>';
	h+='<div style="display:flex;gap:6px;flex-shrink:0;align-items:center">';
	if(p.edit_url)h+='<a href="'+esc(p.edit_url)+'" target="_blank" style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;color:var(--hts-accent);text-decoration:none;padding:6px 10px;border:1px solid var(--hts-border);border-radius:8px;background:var(--hts-bg);box-shadow:none;line-height:1.4" onclick="event.stopPropagation()">Voir <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" stroke="currentColor" stroke-width="1.7" fill="none"/></svg></a>';
	h+='<button onclick="htsPreviewClose()" style="width:32px;height:32px;border-radius:8px;border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="var(--hts-text-3)" stroke-width="1.7"/></svg></button>';
	h+='</div></div>';

	/* ══ 2. METRICS — inline dots, one line (short values only) ══ */
	var _shortMets=_inlineMets.filter(function(m){return String(m.value).length<=25});
	if(_shortMets.length||_hasOrph){
		var stDot={ok:'var(--hts-success)',warning:'var(--hts-caution)',info:'var(--hts-accent)'};
		h+='<div style="display:flex;flex-wrap:wrap;gap:4px 14px;margin-bottom:16px;font-size:12px;color:var(--hts-text-2);line-height:1.6">';
		_shortMets.forEach(function(m){
			var dc=stDot[m.status]||'var(--hts-text-3)';
			h+='<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:'+dc+';flex-shrink:0"></span><strong style="color:var(--hts-text)">'+esc(String(m.value))+'</strong> '+esc(m.label)+'</span>';
		});
		if(_hasOrph)h+='<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:var(--hts-danger);flex-shrink:0"></span><strong style="color:var(--hts-danger)">Orpheline</strong></span>';
		h+='</div>';
	}

	/* ══ 3. LINKING FLOW — single card block ══ */
	if(lkOk){
		h+='<div style="border:1px solid var(--hts-border);border-radius:14px;overflow:hidden;margin-bottom:14px">';
		/* Source */
		h+='<div style="padding:12px 16px;background:var(--hts-surface)">';
		h+='<div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px">Dans cet article</div>';
		h+='<div style="font-size:13px;font-weight:700;color:var(--hts-text)">'+esc(p.post_title)+'</div>';
		h+='</div>';
		/* Arrow + anchor */
		if(lk.anchor_text){
			h+='<div style="display:flex;align-items:center;gap:8px;padding:8px 16px;border-top:1px solid var(--hts-border-sub)">';
			h+='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" style="flex-shrink:0"><path d="M12 5v14M5 12l7 7 7-7" stroke="var(--hts-accent)" stroke-width="2" fill="none"/></svg>';
			h+='<span style="font-size:12px;font-weight:600;color:var(--hts-text)">"'+esc(lk.anchor_text)+'"</span>';
			h+='</div>';
		}
		/* Context snippet */
		if(lk.context_snippet){
			var ctx=esc(lk.context_snippet).replace(/\{HL_START\}/g,'<mark style="background:var(--hts-success-bg);padding:1px 3px;border-radius:3px;font-weight:700;color:var(--hts-success)">').replace(/\{HL_END\}/g,'</mark>');
			h+='<div style="padding:8px 16px;border-top:1px solid var(--hts-border-sub);font-size:11px;color:var(--hts-text-3);line-height:1.5;font-style:italic">'+ctx+'</div>';
		}
		/* Target */
		if(lk.target_title){
			h+='<div style="padding:12px 16px;background:var(--hts-success-bg);border-top:1px solid rgba(0,210,106,.15)">';
			h+='<div style="font-size:9px;font-weight:700;color:var(--hts-success);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px">Vers cette page</div>';
			h+='<div style="font-size:13px;font-weight:600;color:var(--hts-accent)">'+esc(lk.target_title)+'</div>';
			h+='</div>';
		}
		h+='</div>';

		/* Badges — compact */
		var _bh='';
		if(lk.link_label)_bh+='<span style="padding:2px 8px;border-radius:6px;background:var(--hts-success-bg);font-size:10px;font-weight:600;color:var(--hts-success)">'+esc(lk.link_label)+'</span>';
		if(_cluster)_bh+='<span style="padding:2px 8px;border-radius:6px;background:var(--hts-surface);font-size:10px;color:var(--hts-text-3)">'+esc(_cluster)+'</span>';
		if(lk.anchor_method==='ai_generated')_bh+='<span style="padding:2px 8px;border-radius:6px;background:var(--hts-geo-soft);font-size:10px;color:var(--hts-geo)">IA</span>';
		if(_bh)h+='<div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:14px">'+_bh+'</div>';

		/* Intro/heading warning from backend */
		if(lk.intro_warning){
			h+='<div style="display:flex;align-items:flex-start;gap:8px;padding:10px 14px;background:var(--hts-caution-bg);border:1px solid rgba(245,158,11,.15);border-radius:10px;margin-bottom:14px;font-size:11px;color:#78350F;line-height:1.4"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" style="flex-shrink:0;margin-top:1px"><path d="M12 9v4M12 17h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke="var(--hts-caution)" stroke-width="1.5" fill="none"/></svg>'+esc(lk.intro_warning)+'</div>';
		}
	}

	/* ══ META / GENERIC: diff.fields Before → After ══ */
	var flds=di.fields||[];
	var variants=p.variants||[];
	var _hasMetaVariants=(!lkOk&&variants.length>1);
	var _metaType=(type.indexOf('meta_title')>=0||type.indexOf('meta_desc')>=0||type.indexOf('meta_both')>=0);
	/* Track selected variant index globally for doApprove */
	if(_metaType)window._htsSelectedVariant=0;
	if(!lkOk&&flds.length){
		flds.forEach(function(f,fi){
			if(f.before){
				h+='<div style="margin-bottom:10px"><div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">'+esc(f.label||'Actuellement')+'</div>';
				h+='<div style="padding:10px 14px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:10px;font-size:13px;color:var(--hts-text-2);line-height:1.5">'+esc(f.before)+'</div></div>';
			}
			/* "Après" blocks: skip when variants are available (radio cards replace them) */
			if(f.after&&!_hasMetaVariants){
				h+='<div style="margin-bottom:14px"><div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">Proposition</div>';
				h+='<div style="padding:10px 14px;background:var(--hts-success-bg);border:1px solid rgba(0,210,106,.15);border-radius:10px;font-size:13px;color:var(--hts-text);font-weight:500;line-height:1.5">'+esc(f.after)+'</div></div>';
			}
		});
	}

	/* ══ META VARIANTS — clickable radio cards with chars + score ══ */
	if(_hasMetaVariants){
		h+='<div style="margin-bottom:14px"><div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Choisir une variante</div>';
		h+='<div id="hts-variant-list">';
		variants.slice(0,4).forEach(function(v,i){
			/* Determine text for this variant — title or description depending on action type */
			var vTitle=v.title||'';
			var vDesc=v.description||'';
			var isTitle=(type.indexOf('title')>=0||type==='optimize_meta_both');
			var isDesc=(type.indexOf('desc')>=0||type==='optimize_meta_both');
			var isBoth=(type==='optimize_meta_both');
			var vTextTitle=isTitle?vTitle:'';
			var vTextDesc=isDesc?vDesc:'';
			var vMain=vTextTitle||vTextDesc;
			if(!vMain)return;
			var vScore=typeof v.score==='number'?v.score:(parseInt(v.score)||0);
			var hasScore=(v.score!==undefined&&v.score!==null&&v.score!=='');
			/* Score color: green ≥ 60, orange ≥ 40, red < 40 */
			var sCl=vScore>=60?'var(--hts-success)':vScore>=40?'var(--hts-caution)':'var(--hts-danger)';
			var sBg=vScore>=60?'var(--hts-success-bg)':vScore>=40?'var(--hts-caution-bg)':'var(--hts-danger-bg)';
			var isSelected=(i===0);
			var brd=isSelected?'1.5px solid var(--hts-success)':'1.5px solid var(--hts-border)';
			var bg=isSelected?'var(--hts-success-bg)':'var(--hts-bg)';
			h+='<div data-vi="'+i+'" onclick="htsSelectVariant('+i+')" style="display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border:'+brd+';border-radius:12px;margin-bottom:6px;font-size:12px;color:var(--hts-text-2);line-height:1.5;cursor:pointer;background:'+bg+';transition:border .15s,background .15s">';
			/* Radio dot */
			h+='<span data-role="radio" style="flex-shrink:0;width:18px;height:18px;border-radius:50%;border:2px solid '+(isSelected?'var(--hts-success)':'var(--hts-border)')+';display:flex;align-items:center;justify-content:center;margin-top:1px">';
			if(isSelected)h+='<span style="width:10px;height:10px;border-radius:50%;background:var(--hts-success)"></span>';
			h+='</span>';
			/* Content */
			h+='<div style="flex:1;min-width:0">';
			/* Title line */
			if(vTextTitle){
				h+='<div style="font-weight:600;color:var(--hts-text);margin-bottom:2px">'+esc(vTextTitle)+'</div>';
			}
			/* Description line (for optimize_meta_both show both, or desc-only) */
			if(isBoth&&vTextDesc){
				h+='<div style="font-size:11px;color:var(--hts-text-2);margin-bottom:2px">'+esc(vTextDesc)+'</div>';
			}
			if(!vTextTitle&&vTextDesc){
				h+='<div style="font-weight:600;color:var(--hts-text);margin-bottom:2px">'+esc(vTextDesc)+'</div>';
			}
			/* Metrics: chars (per field for both) + score */
			h+='<div style="display:flex;align-items:center;gap:10px;margin-top:3px">';
			if(isBoth){
				if(vTextTitle)h+='<span style="font-size:10px;color:var(--hts-text-3)">Title '+vTextTitle.length+' car.</span>';
				if(vTextDesc)h+='<span style="font-size:10px;color:var(--hts-text-3)">Desc '+vTextDesc.length+' car.</span>';
			}else{
				h+='<span style="font-size:10px;color:var(--hts-text-3)">'+vMain.length+' car.</span>';
			}
			if(hasScore)h+='<span style="font-size:10px;font-weight:700;color:'+sCl+';padding:2px 7px;border-radius:6px;background:'+sBg+'">'+vScore+'/100</span>';
			h+='</div>';
			h+='</div>';
			h+='</div>';
		});
		h+='</div></div>';
	}

	/* ══ IMAGE ALT — thumbnails of images missing ALT ══ */
	var imgs=p.images||[];
	if(type==='fix_image_alt'&&imgs.length){
		h+='<div style="margin-bottom:14px"><div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Images sans attribut ALT</div>';
		h+='<div style="display:flex;gap:8px;flex-wrap:wrap">';
		imgs.slice(0,6).forEach(function(img){
			var src=img.thumbnail||img.url||'';
			if(!src)return;
			h+='<div style="width:72px;height:72px;border-radius:8px;border:1px solid var(--hts-border);overflow:hidden;flex-shrink:0;background:var(--hts-surface)"><img src="'+esc(src)+'" style="width:100%;height:100%;object-fit:cover" alt=""></div>';
		});
		if(imgs.length>6)h+='<div style="display:flex;align-items:center;font-size:11px;color:var(--hts-text-3);padding-left:4px">+'+(imgs.length-6)+' autres</div>';
		h+='</div></div>';
	}
	/* Fallback for non-linking without diff.fields */
	if(!lkOk&&!flds.length){
		if(p.before&&p.before.value){
			h+='<div style="margin-bottom:10px"><div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">'+esc(p.before.label||'Actuellement')+'</div>';
			h+='<div style="padding:10px 14px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:10px;font-size:13px;color:var(--hts-text-2);line-height:1.5">'+esc(p.before.value)+'</div></div>';
		}
		/* Skip "Après" fallback when variants radio cards are shown */
		if(p.after_desc&&!_hasMetaVariants){
			h+='<div style="margin-bottom:14px"><div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">Proposition</div>';
			h+='<div style="padding:10px 14px;background:var(--hts-success-bg);border:1px solid rgba(0,210,106,.15);border-radius:10px;font-size:13px;color:var(--hts-text);font-weight:500;line-height:1.5">'+esc(p.after_desc)+'</div></div>';
		}
	}

	/* ══ 4. WHY — single subtle line ══ */
	if(di.why){var _why=di.why.replace(/\\u([0-9a-fA-F]{4})/g,function(m,g){return String.fromCharCode(parseInt(g,16))});h+='<div style="font-size:11px;color:var(--hts-text-3);line-height:1.4;margin-bottom:16px;padding-top:10px;border-top:1px solid var(--hts-border-sub)">'+esc(_why)+'</div>';}

	/* ══ 5. FOOTER — Annuler + Confirmer ══ */
	h+='<div style="display:flex;gap:10px;justify-content:flex-end">';
	h+='<button onclick="htsPreviewClose()" style="padding:10px 20px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-border);background:var(--hts-bg);font-size:13px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);line-height:1.4">Annuler</button>';
	h+='<button id="hts-preview-confirm" style="padding:10px 24px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-success);color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--hts-font);box-shadow:0 2px 12px rgba(0,210,106,.25);display:flex;align-items:center;gap:6px;line-height:1.4"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><polyline points="20,6 9,17 4,12" stroke="#fff" stroke-width="2.2" fill="none"/></svg>Confirmer et appliquer</button>';
	h+='</div>';
	return h;
}

/* Apply single — opens preview modal first */
document.querySelectorAll('.hts-inbox-apply').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();
	var id=this.dataset.aid,row=document.querySelector('[data-aid="'+id+'"]'),btn=this;
	if(row&&row.dataset.locked)return;
	/* Close any existing preview first (resets previous btn) */
	if(_prevOverlay&&_prevOverlay.style.display==='flex')htsPreviewClose();
	_prevActionId=id;_prevRow=row;_prevBtn=btn;
	var myReq=++_prevReqId;
	btn.disabled=true;btn.textContent='…';
	/* Show modal with loading state */
	if(_prevOverlay){_prevOverlay.style.display='flex';document.body.style.overflow='hidden'}
	if(_prevContent)_prevContent.innerHTML='<div style="text-align:center;padding:48px 20px"><div style="width:28px;height:28px;border:3px solid var(--hts-border);border-top-color:var(--hts-accent);border-radius:50%;margin:0 auto 14px;animation:htsSpin .7s linear infinite"></div><div style="font-size:13px;color:var(--hts-text-3)">Chargement de l\u0027aperçu…</div></div>';
	/* Fetch preview from backend */
	post('hts_inbox_preview',{action_id:id},function(d){
		/* Ignore stale callback if user already opened another preview */
		if(myReq!==_prevReqId)return;
		if(d.success&&d.data){
			try{
				_prevContent.innerHTML=htsPreviewRender(d.data);
			}catch(renderErr){
				console.error('HTS preview render error:',renderErr);
				_prevContent.innerHTML='<div style="padding:32px 20px;text-align:center"><div style="font-size:14px;font-weight:600;color:var(--hts-text);margin-bottom:8px">Erreur d\u0027affichage</div><div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px">'+esc(String(renderErr.message||renderErr))+'</div><div style="display:flex;gap:10px;justify-content:center"><button onclick="htsPreviewClose()" style="padding:8px 16px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-border);background:var(--hts-bg);font-size:13px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Fermer</button></div></div>';
				return;
			}
			/* Wire confirm button */
			var cfm=document.getElementById('hts-preview-confirm');
			if(cfm)cfm.addEventListener('click',function(){
				this.disabled=true;this.textContent='Application\u2026';
				_prevConfirming=true;
				var vi=window._htsSelectedVariant||0;
				htsPreviewClose();
				doApprove(id,row,btn,vi);
			});
		}else{
			/* Preview failed — show inline error in modal, no native confirm */
			var errMsg=(d.data&&typeof d.data==='string')?d.data:(d._net_error?'Erreur r\u00e9seau — v\u00e9rifiez votre connexion':'Impossible de charger l\u0027aper\u00e7u');
			_prevContent.innerHTML='<div style="padding:32px 20px;text-align:center"><div style="font-size:14px;font-weight:600;color:var(--hts-text);margin-bottom:8px">Aper\u00e7u indisponible</div><div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px">'+esc(errMsg)+'</div><div style="display:flex;gap:10px;justify-content:center"><button onclick="htsPreviewClose()" style="padding:8px 16px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-border);background:var(--hts-bg);font-size:13px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Fermer</button></div></div>';
		}
	});
})});

/* doApprove — called after preview confirmation */
function doApprove(id,row,btn,variantIdx){
	if(row)row.dataset.locked='1';btn.disabled=true;btn.textContent='…';
	var payload={action_id:id};
	if(typeof variantIdx==='number'&&variantIdx>0)payload.variant_index=variantIdx;
	post('hts_inbox_approve',payload,function(d){
		if(d.success&&row){
			var st=d.data&&d.data.status?d.data.status:'done';
			var isOk=(st==='done'||st==='approved');
			var isBk=(st==='blocked');
			var fbCol=isOk?'var(--hts-success)':isBk?'var(--hts-caution)':'var(--hts-danger)';
			var fbBg=isOk?'var(--hts-success-bg)':isBk?'var(--hts-caution-bg)':'var(--hts-danger-bg)';
			var fbLabel=isOk?'Appliqu\u00e9':isBk?'Bloqu\u00e9 par garde-fou':'\u00c9chou\u00e9';
			/* Status bar */
			var fb='<div style="display:flex;align-items:center;gap:8px;padding:12px 16px;margin-top:12px;background:'+fbBg+';border:1px solid rgba(0,0,0,.04);border-radius:10px">';
			if(isOk)fb+='<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><polyline points="20,6 9,17 4,12" stroke="'+fbCol+'" stroke-width="2.5" fill="none"/></svg>';
			fb+='<span style="font-size:12px;font-weight:600;color:'+fbCol+'">'+fbLabel+'</span>';
			if(d.data&&d.data.log)fb+='<span style="font-size:11px;color:var(--hts-text-3);margin-left:4px">\u2014 '+esc(d.data.log.substring(0,60))+'</span>';
			if(isOk&&d.data&&d.data.edit_url)fb+='<a href="'+esc(d.data.edit_url)+'" target="_blank" style="margin-left:auto;font-size:11px;font-weight:600;color:var(--hts-accent);text-decoration:none;padding:0;background:none;box-shadow:none" onclick="event.stopPropagation()">Voir l\u0027article</a>';
			fb+='</div>';
			/* Rich result: meta before→after */
			if(isOk&&d.data&&d.data.meta_result){
				var mr=d.data.meta_result;
				fb+='<div style="padding:10px 16px;margin-top:6px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:10px;font-size:11px;color:var(--hts-text-2);line-height:1.5">';
				if(mr.before)fb+='<div style="margin-bottom:4px"><span style="color:var(--hts-text-3);font-weight:500">Avant :</span> <span style="text-decoration:line-through;opacity:.5">'+esc((mr.before).substring(0,70))+'</span></div>';
				if(mr.after)fb+='<div><span style="color:var(--hts-success);font-weight:600">Apr\u00e8s :</span> '+esc((mr.after).substring(0,70))+'</div>';
				fb+='</div>';
			}
			/* Rich result: thumbnail preview */
			if(isOk&&d.data&&d.data.thumbnail_url){
				fb+='<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;margin-top:6px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:10px"><img src="'+esc(d.data.thumbnail_url)+'" style="width:48px;height:48px;object-fit:cover;border-radius:8px;border:1px solid var(--hts-border)"><span style="font-size:11px;color:var(--hts-text-3)">Image mise en avant g\u00e9n\u00e9r\u00e9e</span></div>';
			}
			if(isOk){var inner=row.querySelector('div');if(inner)inner.style.opacity='.4';}
			var applyBtn=row.querySelector('.hts-ds-btn--success');if(applyBtn)applyBtn.style.display='none';
			row.insertAdjacentHTML('beforeend',fb);
		}else{
			btn.disabled=false;btn.textContent='Appliquer';if(row)delete row.dataset.locked;
			/* Show error feedback to CEO */
			var errMsg=d.data||'Action impossible';
			if(d._net_error)errMsg='Erreur réseau — vérifiez votre connexion';
			var errDiv=document.createElement('div');
			errDiv.style.cssText='display:flex;align-items:center;gap:8px;padding:10px 22px;margin:-14px -22px -14px -22px;margin-top:12px;background:var(--hts-danger-bg);border-top:1px solid var(--hts-border-sub);font-size:12px;color:var(--hts-danger)';
			errDiv.textContent=errMsg;
			if(row)row.appendChild(errDiv);
			setTimeout(function(){if(errDiv.parentNode)errDiv.remove()},5000);
		}
	});
}

/* Dismiss — with visual feedback + locks row */
document.querySelectorAll('.hts-inbox-dismiss').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();var row=document.querySelector('[data-aid="'+this.dataset.aid+'"]');if(!row||row.dataset.locked)return;row.dataset.locked='1';var id=this.dataset.aid;
	post('hts_inbox_dismiss',{action_id:id},function(d){
		if(d.success&&row){
			/* Fade the content, not the whole row — so feedback bar stays readable */
			var inner=row.querySelector('div');if(inner)inner.style.opacity='.35';
			row.style.pointerEvents='none';
			var fb='<div style="display:flex;align-items:center;gap:6px;padding:8px 22px;margin:-14px -22px -14px -22px;margin-top:12px;background:var(--hts-surface);border-top:1px solid var(--hts-border-sub)">';
			fb+='<span style="font-size:11px;color:var(--hts-text-3)">Action ignorée</span></div>';
			row.insertAdjacentHTML('beforeend',fb);
			/* D3: Toast si 3 dismiss → pause 30j */
			if(d.data&&d.data.linking_paused&&d.data.pause_message){var _t=document.createElement('div');_t.textContent=d.data.pause_message;_t.style.cssText='position:fixed;bottom:20px;right:20px;background:#FF9800;color:#fff;padding:12px 20px;border-radius:8px;z-index:99999;font-size:13px;box-shadow:0 4px 12px rgba(0,0,0,.15);';document.body.appendChild(_t);setTimeout(function(){_t.remove()},5000)}
		}else{
			delete row.dataset.locked;
			var errMsg=(d.data&&typeof d.data==='string')?d.data:'Impossible d\u0027ignorer cette action';
			if(d._net_error)errMsg='Erreur réseau';
			var errDiv=document.createElement('div');
			errDiv.style.cssText='display:flex;align-items:center;gap:6px;padding:8px 22px;margin:-14px -22px -14px -22px;margin-top:12px;background:var(--hts-danger-bg);border-top:1px solid var(--hts-border-sub);font-size:11px;color:var(--hts-danger)';
			errDiv.textContent=errMsg;
			if(row)row.appendChild(errDiv);
			setTimeout(function(){if(errDiv.parentNode)errDiv.remove()},4000);
		}
	})
})});

/* Per-page batch apply */
document.querySelectorAll('.hts-inbox-apply-page').forEach(function(btn){btn.addEventListener('click',function(e){e.stopPropagation();var card=this.closest('.hts-inbox-page-card');if(!card)return;var fd=new FormData();fd.append('action','hts_inbox_batch');fd.append('nonce',nonce);fd.append('batch_action','approve');var ct=0;/* Collecter les actions normales */card.querySelectorAll('.hts-inbox-apply').forEach(function(b){if(b.disabled||b.style.display==='none')return;var r=b.closest('[data-aid]');if(r&&r.dataset.locked)return;fd.append('ids[]',b.dataset.aid);ct++});/* Collecter aussi les actions stale (le serveur auto-recalcule) */card.querySelectorAll('.hts-inbox-action[data-aid]').forEach(function(a){if(a.dataset.locked)return;var btns=a.querySelector('[data-stale="true"]');if(!btns)return;fd.append('ids[]',a.dataset.aid);ct++});if(!ct)return;this.disabled=true;this.textContent='…';fetch(ajax,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(d){if(!d.success&&d.data&&d.data.message==='use_batch'&&window.htsJobPoller){btn.textContent='Lots\u2026';htsJobPoller.start({initAction:d.data.batch_init,stepAction:d.data.batch_step,nonce:nonce,params:{batch_action:'approve'},onProgress:function(p){btn.textContent=(p.progress||0)+'%';},onComplete:function(){location.reload();},onError:function(m){btn.disabled=false;btn.textContent='Tout appliquer'}});return;}if(d.success){_toast('Actions traitées — rechargement…','success');setTimeout(function(){location.reload()},1500)}else{btn.disabled=false;btn.textContent='Tout appliquer'}}).catch(function(){btn.disabled=false;btn.textContent='Tout appliquer'})})});

/* Per-page ignore */
document.querySelectorAll('.hts-inbox-ignore-page').forEach(function(btn){btn.addEventListener('click',function(e){e.stopPropagation();var card=this.closest('.hts-inbox-page-card');if(!card)return;var fd=new FormData();fd.append('action','hts_inbox_batch');fd.append('nonce',nonce);fd.append('batch_action','dismiss');card.querySelectorAll('.hts-inbox-action[data-aid]').forEach(function(a){fd.append('ids[]',a.dataset.aid)});this.disabled=true;this.textContent='…';fetch(ajax,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(d){if(d.success){card.style.opacity='.3';card.style.pointerEvents='none'}else{btn.disabled=false;btn.textContent='Ignorer'}}).catch(function(){btn.disabled=false;btn.textContent='Ignorer'})})});

/* Scan/audit button — both header (empty state) and footer */
var scn=document.getElementById('hts-inbox-scan-btn');
var scnF=document.getElementById('hts-inbox-scan-footer');
function htsRunAudit(btn){_modalConfirm('Lancer un audit complet ?','Les anciennes propositions non trait\u00e9es seront remplac\u00e9es.','Lancer l\u0027audit').then(function(ok){if(!ok)return;btn.disabled=true;btn.textContent='Audit en cours\u2026';post('hts_full_audit',{},function(d){if(!d.success&&d.data&&d.data.message==='use_batch'&&window.htsJobPoller){btn.textContent='Audit par lots\u2026';htsJobPoller.start({initAction:d.data.batch_init,stepAction:d.data.batch_step,nonce:nonce,params:{},onProgress:function(p){btn.textContent='Audit\u2026 '+(p.progress||0)+'%';},onComplete:function(){location.reload();},onError:function(m){btn.disabled=false;btn.textContent='Lancer l\u0027audit';_toast(m,'error');}});return;}if(d.success)location.reload();else{btn.disabled=false;btn.textContent='Lancer l\u0027audit'}})})}
if(scn)scn.addEventListener('click',function(){htsRunAudit(this)});
if(scnF)scnF.addEventListener('click',function(){htsRunAudit(this)});

/* ═══ TAB TOGGLE (client-side, no reload) ═══ */
var _tabPending=document.getElementById('hts-tab-pending'),_tabHistory=document.getElementById('hts-tab-history');
document.querySelectorAll('.hts-inbox-tab-btn').forEach(function(btn){btn.addEventListener('click',function(){
	var t=this.dataset.tab;
	document.querySelectorAll('.hts-inbox-tab-btn').forEach(function(b){
		var act=b.dataset.tab===t;
		b.style.background=act?'var(--hts-bg)':'transparent';
		b.style.boxShadow=act?'0 1px 3px rgba(0,0,0,.08),0 1px 1px rgba(0,0,0,.06),0 0 0 .5px rgba(0,0,0,.04)':'none';
		b.style.color=act?'var(--hts-text)':'rgba(60,60,67,.45)';
		b.style.fontWeight=act?'600':'500';
		b.classList.toggle('active',act);
		/* Badge color: active=accent, inactive=danger (maquette L178) */
		var badge=b.querySelector('span[style*="border-radius:9px"]');
		if(badge)badge.style.background=act?'var(--hts-accent)':'var(--hts-danger)';
	});
	if(_tabPending)_tabPending.style.display=t==='pending'?'block':'none';
	if(_tabHistory)_tabHistory.style.display=t==='history'?'block':'none';
	if(t==='history')initHistoryTab();
	if(this.dataset.url&&history.replaceState)history.replaceState(null,'',this.dataset.url);
})});

/* ═══ HISTORY TAB — LAZY INIT + PARALLEL AJAX ═══ */
var _iUndo='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" style="flex-shrink:0"><path d="M3 7v6h6" stroke="currentColor" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 17a9 9 0 00-9-9 9 9 0 00-6.69 3L3 13" stroke="currentColor" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
var _iExt='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" style="flex-shrink:0"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" stroke="currentColor" stroke-width="1.7" fill="none"/></svg>';
var _iTrend='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" style="flex-shrink:0"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18" stroke="var(--hts-success)" stroke-width="2" fill="none"/><polyline points="17 6 23 6 23 12" stroke="var(--hts-success)" stroke-width="2" fill="none"/></svg>';
var _historyInited=false;
function initHistoryTab(){
if(_historyInited)return;_historyInited=true;
(function(){
var c=document.getElementById('hts-inbox-history'),ei=document.getElementById('hts-examiner-inject');
var _report=null,_history=null;

/* ── FIRE BOTH AJAX IN PARALLEL ── */
post('hts_feedback_page_report',{days:'30'},function(resp){
	_report=resp.success&&resp.data?resp.data:{pages:[]};
	if(_history!==null)renderAll();
});
post('hts_inbox_history',{limit:'50'},function(resp){
	_history=resp.success&&resp.data?(resp.data.history||resp.data):[];
	if(_report!==null)renderAll();
});
/* Safety timeout: if either hasn't responded in 12s, render what we have */
setTimeout(function(){
	if(_report===null)_report={pages:[]};
	if(_history===null)_history=[];
	renderAll();
},12000);

var _rendered=false;
function renderAll(){
	if(_rendered)return;_rendered=true;
	var pages=_report.pages||[];

	/* ── Update KPIs ── */
	var cnt={pos:0,neg:0,neut:0,algo:0};
	pages.forEach(function(p){if(p.aggregate_verdict==='positive')cnt.pos++;else if(p.aggregate_verdict==='negative')cnt.neg++;else if(p.aggregate_verdict==='algo_neutral')cnt.algo++;else cnt.neut++});
	[['hts-kpi-positive',cnt.pos],['hts-kpi-neutral',cnt.neut],['hts-kpi-negative',cnt.neg],['hts-kpi-algo',cnt.algo]].forEach(function(p){var e=document.getElementById(p[0]);if(e){var v=e.querySelector('.hts-kpi-value');if(v)v.textContent=p[1]}});

	/* ── Examiner pages — inject BEFORE KPIs ── */
	var neg=pages.filter(function(p){return p.aggregate_verdict==='negative'});
	if(neg.length&&ei){
		var eh='<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px"><span style="width:8px;height:8px;border-radius:50%;background:var(--hts-danger);display:inline-block;flex-shrink:0"></span><span style="font-size:16px;font-weight:800;color:var(--hts-danger)">'+neg.length+' page'+(neg.length>1?'s':'')+' à examiner</span><span style="font-size:12px;color:var(--hts-text-3)">— positions en baisse après une action</span></div>';
		neg.slice(0,5).forEach(function(pg){
			var pd=pg.position_delta!=null&&pg.position_delta!==false?pg.position_delta.toFixed(1):'?';
			eh+='<div class="hts-ds-card" style="padding:0;margin-bottom:12px;overflow:hidden;border:1px solid rgba(239,68,68,.12)"><div style="padding:16px 22px;background:linear-gradient(135deg,var(--hts-danger-bg),var(--hts-bg));display:flex;align-items:flex-start;justify-content:space-between"><div style="display:flex;align-items:center;gap:8px"><span style="width:8px;height:8px;border-radius:50%;background:var(--hts-danger);flex-shrink:0"></span><span style="font-size:14px;font-weight:700;color:var(--hts-text)">'+esc(pg.title)+'</span></div><span style="font-size:12px;font-weight:700;color:var(--hts-danger)">pos '+(pd!=='?'&&parseFloat(pd)>0?'+':'')+esc(pd)+'</span></div>';
			eh+='<div style="display:flex;gap:24px;padding:12px 22px;border-bottom:1px solid var(--hts-border-sub)"><div><div style="font-size:20px;font-weight:800;color:var(--hts-text)">'+(pg.position_after||'?')+'</div><div style="font-size:10px;color:var(--hts-text-3)">Position</div></div><div><div style="font-size:20px;font-weight:800;color:var(--hts-text)">'+(pg.impressions_after||pg.clicks_after||0)+'</div><div style="font-size:10px;color:var(--hts-text-3)">Impressions</div></div><div style="flex:1"></div>';
			if(pg.actions&&pg.actions[0])eh+='<div style="font-size:11px;color:var(--hts-text-3)">'+esc(pg.actions[0].label||pg.actions[0].type||'')+' · J+'+((pg.actions[0].days_ago)||'?')+'</div>';
			eh+='</div>';
			if(pg.context){
				eh+='<div style="margin:14px 22px 16px;padding:16px 18px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:12px"><div style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><polygon points="13,2 3,14 12,14 11,22 21,10 12,10" stroke="var(--hts-caution)" stroke-width="1.7" fill="none"/></svg><span style="font-size:13px;font-weight:700;color:var(--hts-text)">Notre recommandation</span></div>';
				eh+='<div style="font-size:12px;color:var(--hts-text-2);line-height:1.5;margin-bottom:12px">'+esc(pg.context)+'</div>';
				if(pg.actions&&pg.actions[0])eh+='<button class="hts-ds-btn hts-ds-btn--sm" style="display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-caution);background:var(--hts-caution-bg);color:#92400E;font-size:12px;font-weight:700" onclick="htsInboxPost(\'hts_inbox_rollback\',{action_id:'+(pg.actions[0].id||0)+'},function(d){if(d.success)location.reload();else _toast(d.data||\'Erreur\',\u0027error\u0027)})">'+_iUndo+' Appliquer cette recommandation</button>';
				eh+='</div>';
			}
			eh+='</div>';
		});
		ei.innerHTML=eh;
	}

	/* ── Gains ── */
	var pos=pages.filter(function(p){return p.aggregate_verdict==='positive'});
	var html='';
	if(pos.length){
		html+='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px"><span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Actions qui ont boosté votre site</span><span style="font-size:12px;font-weight:600;color:var(--hts-success)">'+pos.length+' améliorations</span></div>';
		pos.slice(0,5).forEach(function(pg){
			html+='<div class="hts-ds-card" style="padding:14px 22px;margin-bottom:10px"><div style="display:flex;align-items:center;gap:12px"><div style="width:28px;height:28px;border-radius:8px;background:var(--hts-success-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0">'+_iTrend+'</div><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:700;color:var(--hts-text)">'+esc(pg.title)+'</div>';
			if(pg.actions&&pg.actions[0])html+='<div style="font-size:11px;color:var(--hts-text-3)">'+esc(pg.actions[0].label||'')+' · mesure sur '+(pg.actions[0].days_ago||'?')+'j</div>';
			html+='</div><div style="display:flex;gap:8px;flex-shrink:0">';
			if(pg.position_delta)html+='<span style="font-size:11px;font-weight:700;color:var(--hts-success);padding:3px 8px;border-radius:6px;background:var(--hts-success-bg)">'+Math.abs(pg.position_delta).toFixed(1)+' pos.</span>';
			if(pg.clicks_delta&&pg.clicks_delta>0)html+='<span style="font-size:11px;font-weight:700;color:var(--hts-success);padding:3px 8px;border-radius:6px;background:var(--hts-success-bg)">+'+pg.clicks_delta+' clics</span>';
			html+='</div></div></div>';
		});
	}

	/* ── History list — grouped by page ── */
	var raw=_history;
	html+='<div style="display:flex;align-items:center;justify-content:space-between;margin:24px 0 14px"><span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Historique des actions</span><div style="display:flex;align-items:center;gap:8px"><span style="font-size:12px;color:var(--hts-text-3)">'+(raw.length||0)+' actions</span><button class="hts-ds-btn hts-ds-btn--sm" style="font-size:10px;padding:3px 8px;display:flex;align-items:center" onclick="location.reload()" title="Actualiser"><svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M1 4v6h6M23 20v-6h-6" stroke="currentColor" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15" stroke="currentColor" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div></div>';
	if(!raw.length){c.innerHTML=html;return}
	/* Group by post_id */
	var groups={},groupOrder=[];
	raw.forEach(function(r){
		var pid=r.post_id||0;
		if(!groups[pid]){groups[pid]={title:r.post_title||'#'+pid,actions:[],done:0,failed:0,time:r.time_ago||''};groupOrder.push(pid)}
		groups[pid].actions.push(r);
		if(r.status==='done')groups[pid].done++;
		else if(r.status==='failed'||r.status==='blocked')groups[pid].failed++;
	});
	var vc={positive:{l:'Positif',c:'var(--hts-success)',b:'var(--hts-success-bg)'},negative:{l:'Négatif',c:'var(--hts-danger)',b:'var(--hts-danger-bg)'},neutral:{l:'Neutre',c:'var(--hts-text-3)',b:'var(--hts-border-sub)'},pending:{l:'Mesure en attente',c:'var(--hts-text-3)',b:'var(--hts-border-sub)'}};
	groupOrder.forEach(function(pid){
		var g=groups[pid];
		var summary=g.done+' appliqué'+(g.done>1?'s':'');
		if(g.failed>0)summary+=', '+g.failed+' à recalculer';
		html+='<div class="hts-ds-card" style="padding:0;margin-bottom:12px;overflow:hidden">';
		html+='<div style="padding:14px 22px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--hts-border-sub);background:var(--hts-surface)">';
		html+='<div><div style="font-size:13px;font-weight:700;color:var(--hts-text)">'+esc(_htsDec(g.title))+'</div>';
		html+='<div style="font-size:10px;color:var(--hts-text-3);margin-top:2px">'+g.actions.length+' action'+(g.actions.length>1?'s':'')+' · '+(g.time?'il y a '+esc(g.time):'')+'</div></div>';
		html+='<div style="font-size:10px;color:var(--hts-text-3);padding:3px 8px;border-radius:6px;background:var(--hts-border-sub)">'+summary+'</div>';
		html+='</div>';
		g.actions.forEach(function(r){
		var isDone=r.status==='done',isFailed=r.status==='failed',isBlocked=r.status==='blocked',isRollbacked=r.status==='rollbacked';
		var vk=isDone?(r.score_delta!=null?(r.score_delta>0?'positive':r.score_delta<0?'negative':'neutral'):'pending'):isFailed?'negative':isBlocked?'neutral':'pending';
		if(isRollbacked)vk='neutral';
		var v=vc[vk]||vc.pending;
		var _isSoftFailLabel=isFailed&&(r.execution_log||'')&&((r.execution_log||'').indexOf('pas')!==-1&&(r.execution_log||'').indexOf('trouv')!==-1||(r.execution_log||'').indexOf('existe plus')!==-1||(r.execution_log||'').indexOf('contient d')!==-1||(r.execution_log||'').indexOf('liens actuels')!==-1||(r.execution_log||'').indexOf('langue')!==-1);
		var stSuffix=_isSoftFailLabel?' (non applicable)':isFailed?' (échoué)':isBlocked?' (bloqué)':isRollbacked?' (annulé)':'';
		var badges='';
		if(vk!=='pending'&&r.score_delta!=null)badges='<span style="font-size:11px;font-weight:700;color:'+v.c+';padding:2px 8px;border-radius:6px;background:'+v.b+'">Score '+(r.score_delta>0?'+':'')+r.score_delta+'</span>';
		var timeStr=r.time_ago?'il y a '+esc(r.time_ago):'';
		html+='<div class="hts-ds-card" style="padding:14px 22px;margin-bottom:8px"><div style="display:flex;align-items:flex-start;gap:12px"><div style="flex:1;min-width:0">';
		html+='<div style="display:flex;align-items:center;gap:8px;margin-bottom:2px"><span style="font-size:13px;font-weight:700;color:var(--hts-text)">'+esc(_htsDec(r.post_title))+'</span>';
		if(r.is_auto)html+='<span style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;background:var(--hts-success);color:#fff">AUTO</span>';
		html+='</div><div style="font-size:11px;color:var(--hts-text-3);margin-bottom:3px">'+esc(r.agent_label)+'</div>';
		var logText=r.execution_log||'';if(logText){logText=logText.replace(/^(Ex\u00e9cution r\u00e9ussie|\u2705|\u274C)\s*[\u2014\u2013\-]?\s*/,'').substring(0,300)}
		var _isSoftFail=isFailed&&logText&&(logText.indexOf('pas \u00e9t\u00e9 trouv\u00e9')!==-1||logText.indexOf('pas été trouvé')!==-1||logText.indexOf('existe plus')!==-1||logText.indexOf('contient d\u00e9j\u00e0')!==-1||logText.indexOf('contient déjà')!==-1||logText.indexOf('liens actuels')!==-1||logText.indexOf('m\u00eame langue')!==-1||logText.indexOf('même langue')!==-1);
		var _logCol=isDone?'var(--hts-success)':_isSoftFail?'var(--hts-caution, #FF9800)':isFailed?'var(--hts-danger)':isBlocked?'var(--hts-caution)':'var(--hts-text-2)';
		html+='<div style="font-size:12px;color:'+_logCol+';font-weight:500">'+esc(r.type_label)+(logText?' — '+esc(logText):'')+'</div>';
		if(badges)html+='<div style="display:flex;gap:8px;margin-top:6px">'+badges+'</div>';
		if(r.score_before!=null)html+='<div style="font-size:11px;color:var(--hts-text-3);margin-top:4px">Score : '+r.score_before+(r.score_after!=null?' \u2192 '+r.score_after:'')+(r.impact_period?' ('+esc(r.impact_period)+')':' (mesure en attente)')+'</div>';
		html+='</div><div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0">';
		html+='<div style="display:flex;align-items:center;gap:4px"><span style="padding:3px 10px;border-radius:6px;font-size:11px;font-weight:600;background:'+v.b+';color:'+v.c+'">'+v.l+esc(stSuffix)+'</span>'+(timeStr?'<span style="font-size:10px;color:var(--hts-text-3)">'+timeStr+'</span>':'')+'</div>';
		html+='<div style="display:flex;gap:6px">';
		if(isDone&&r.id)html+='<button style="padding:4px 10px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:10px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;gap:3px" onclick="htsInboxPost(\'hts_inbox_rollback\',{action_id:'+r.id+'},function(d){if(d.success)location.reload();else _toast(d.data||\'Rollback impossible\',\u0027error\u0027)})">'+_iUndo+' Annuler</button>';
		/* "Annuler & Réessayer" uniquement sur les erreurs, pas les succès */
		if((isBlocked||isFailed)&&r.id){
			var _isAnchorFail=_isSoftFail&&logText&&(logText.indexOf('pas')!==-1&&logText.indexOf('trouv')!==-1);
			if(_isAnchorFail){
				html+='<button style="padding:4px 10px;border-radius:6px;border:1px solid var(--hts-caution);background:var(--hts-bg);font-size:10px;font-weight:600;color:var(--hts-caution);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;gap:3px" onclick="htsInboxPost(\'hts_inbox_refresh_anchor\',{action_id:'+r.id+'},function(d){if(d.success){_toast(\'Nouvelle ancre : \\u00ab \'+d.data.new_anchor+\' \\u00bb\',\'success\');setTimeout(function(){location.reload()},1500)}else{_toast(d.data||\'Aucun passage trouv\\u00e9\',\u0027error\u0027)}})">Nouvelle ancre</button>';
			}else{
				html+='<button style="padding:4px 10px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:10px;font-weight:600;color:var(--hts-accent);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;gap:3px" onclick="htsInboxPost(\'hts_inbox_retry\',{id:'+r.id+'},function(d){if(d.success)location.reload();else _toast(d.data||\'Impossible\',\u0027error\u0027)})">Réessayer</button>';
			}
		}
		if(r.edit_url)html+='<a href="'+esc(r.edit_url)+'" target="_blank" style="padding:4px 10px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:10px;font-weight:600;color:var(--hts-accent);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;gap:3px;text-decoration:none;box-shadow:none">Voir '+_iExt+'</a>';
		html+='</div></div></div></div>';
	}); /* end g.actions.forEach */
	html+='</div>'; /* close group card */
	}); /* end groupOrder.forEach */
	c.innerHTML=html;
}
})();
}
/* Auto-init if page loaded on history tab */
<?php if ( $active_sub === 'history' ) : ?>initHistoryTab();<?php endif; ?>

function esc(s){if(!s)return '';var d=document.createElement('div');d.textContent=s;return d.innerHTML}
function _htsDec(s){if(!s)return '';var t=document.createElement('textarea');t.innerHTML=s;return t.value}
})();
</script>
