<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS On-Page Score — Content Quality Scoring Engine (Light)
 *
 * 7 criteria scoring (0-100), AI suggestions, apply/rollback via Content Writer.
 * Adapted from Full v3.5.0 → Light Phase 2.
 *
 * Criteria: H1(20), Images(25), Headings(15), Length(10), Density(10), Links(10), Readability(10)
 *
 * @since 1.14.0
 */

class HTS_On_Page_Score {

    const VERSION      = '1.0.0';
    const SCORE_META   = '_hts_onpage_score';
    const DETAIL_META  = '_hts_onpage_detail';
    const HISTORY_META = '_hts_onpage_history';

    /**
     * Seuil "contenu court" en mots (depuis agent settings 'content_quality').
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_thin_content_words() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'content_quality' );
            if ( isset( $s['thin_content_words'] ) ) {
                return max( 100, min( 1000, (int) $s['thin_content_words'] ) );
            }
        }
        return 300;
    }

    /**
     * Vérifier les ALT des images (depuis agent settings 'content_quality').
     *
     * @since 2.4.3
     * @return bool
     */
    public static function get_check_alt_enabled() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'content_quality' );
            if ( isset( $s['check_alt'] ) ) {
                return (bool) $s['check_alt'];
            }
        }
        return true;
    }

    public function init() {
        add_action( 'save_post', array( $this, 'on_save_post' ), 35, 2 );
        add_action( 'wp_ajax_hts_onpage_score_get',   array( $this, 'ajax_get_score' ) );
        add_action( 'wp_ajax_hts_onpage_generate',     array( $this, 'ajax_generate' ) );
        add_action( 'wp_ajax_hts_onpage_apply',        array( $this, 'ajax_apply' ) );
        add_action( 'wp_ajax_hts_onpage_rollback',     array( $this, 'ajax_rollback' ) );
        add_action( 'wp_ajax_hts_onpage_history',      array( $this, 'ajax_history' ) );
    }

    public function on_save_post( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) return;
        if ( ! in_array( $post->post_status, array( 'publish', 'draft', 'future' ), true ) ) return;
        $this->score_post( $post_id );
    }

    /* ═══ PUBLIC API ═══ */

    public function compute( $post_id, $use_cache = false ) {
        if ( $use_cache ) {
            $cached = get_post_meta( $post_id, self::DETAIL_META, true );
            if ( is_array( $cached ) && ! empty( $cached['score'] ) ) return $cached;
        }
        return $this->score_post( $post_id );
    }

    /* ═══ 1. SCORING ENGINE (0-100) ═══ */

    public function score_post( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'publish', 'draft', 'future' ), true ) ) {
            return array( 'score' => 0, 'grade' => 'D', 'criteria' => array(), 'issues' => array() );
        }

        $content = '';
        $builder = 'standard';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content = HTS_Content_Extractor::get_content( $post_id );
            $builder = HTS_Content_Extractor::get_detected_builder();
        }
        if ( ! $content ) $content = $post->post_content;
        $keyword = $this->get_focus_keyword( $post_id );

        $criteria = array();
        $issues   = array();

        $h1r = $this->score_h1( $content, $post->post_title, $keyword, $post_id );
        $criteria[] = $h1r['criterion'];
        if ( ! empty( $h1r['issues'] ) ) $issues = array_merge( $issues, $h1r['issues'] );

        $imgr = $this->score_images( $content, $keyword, $post_id );
        $criteria[] = $imgr['criterion'];
        if ( ! empty( $imgr['issues'] ) ) $issues = array_merge( $issues, $imgr['issues'] );

        $hr = $this->score_heading_structure( $content );
        $criteria[] = $hr['criterion'];
        if ( ! empty( $hr['issues'] ) ) $issues = array_merge( $issues, $hr['issues'] );

        $criteria[] = $this->score_content_length( $content );
        $criteria[] = $this->score_keyword_density( $content, $keyword );

        $lr = $this->score_internal_links( $content, $post_id );
        $criteria[] = $lr['criterion'];

        $criteria[] = $this->score_readability( $content );

        $raw = 0; $max = 0;
        foreach ( $criteria as $c ) { $raw += $c['score']; $max += $c['max']; }
        $total = $max > 0 ? round( $raw / $max * 100 ) : 0;

        $result = array(
            'score' => $total, 'grade' => $this->grade( $total ),
            'criteria' => $criteria, 'issues' => $issues,
            'post_id' => $post_id, 'scored_at' => time(), 'builder' => $builder,
        );

        update_post_meta( $post_id, self::SCORE_META, $total );
        update_post_meta( $post_id, self::DETAIL_META, $result );
        return $result;
    }

    /* ─── Individual Criteria ─── */

    private function score_h1( $content, $post_title, $keyword, $post_id = 0 ) {
        $issues = array();
        preg_match_all( '/<h1[^>]*>(.*?)<\/h1>/is', $content, $matches );
        $h1s = $matches[1] ?? array();
        $effective_h1 = ! empty( $h1s ) ? wp_strip_all_tags( $h1s[0] ) : $post_title;
        $score = 0; $detail = ''; $len = mb_strlen( $effective_h1 );

        if ( count( $h1s ) > 1 ) {
            $score = 4; $detail = '' . count( $h1s ) . ' H1 détectés — un seul H1 recommandé';
            $issues[] = array( 'type' => 'h1_multiple', 'element' => 'h1', 'current' => implode( ' | ', array_map( 'wp_strip_all_tags', $h1s ) ), 'detail' => count( $h1s ) . ' balises H1', 'post_id' => $post_id );
        } else {
            $source = ! empty( $h1s ) ? 'contenu' : 'thème (titre)';
            $score = ! empty( $h1s ) ? 14 : 12;
            $detail = '✓ H1 via ' . $source;
            if ( $keyword ) {
                if ( mb_stripos( $effective_h1, $keyword ) !== false ) {
                    $score = 20; $detail .= ' + mot-clé présent — Parfait';
                } else {
                    $kw_parts = explode( ' ', mb_strtolower( $keyword ) );
                    $h1_lower = mb_strtolower( $effective_h1 );
                    $found = 0;
                    foreach ( $kw_parts as $part ) { if ( mb_strlen( $part ) > 3 && mb_strpos( $h1_lower, $part ) !== false ) $found++; }
                    if ( count( $kw_parts ) > 0 && $found / count( $kw_parts ) >= 0.5 ) {
                        $score = 14; $detail .= ' — mot-clé partiel (' . $found . '/' . count( $kw_parts ) . ')';
                    } else {
                        $score = max( 6, $score - 6 ); $detail .= ' — mot-clé absent';
                        $issues[] = array( 'type' => 'h1_no_keyword', 'element' => 'h1', 'current' => $effective_h1, 'detail' => 'Mot-clé absent du H1', 'post_id' => $post_id );
                    }
                }
            } else { $score = min( 16, $score + 2 ); }
            if ( $len > 80 ) { $score = max( 4, $score - 4 ); $detail .= ' — trop long (' . $len . ' car.)'; }
            elseif ( $len < 15 ) { $score = max( 4, $score - 3 ); $detail .= ' — très court (' . $len . ' car.)'; }
        }
        return array( 'criterion' => array( 'id' => 'h1', 'label' => 'Balise H1', 'weight' => 20, 'score' => min( 20, $score ), 'max' => 20, 'detail' => $detail ), 'issues' => $issues );
    }

    private function score_images( $content, $keyword, $post_id ) {
        $issues = array();
        $check_alt = self::get_check_alt_enabled();
        $featured_id = get_post_thumbnail_id( $post_id );
        $has_featured = (bool) $featured_id;
        $featured_alt = $has_featured ? trim( get_post_meta( $featured_id, '_wp_attachment_image_alt', true ) ) : '';
        preg_match_all( '/<img[^>]+>/i', $content, $matches );
        $imgs = $matches[0] ?? array();

        if ( empty( $imgs ) && ! $has_featured ) {
            return array( 'criterion' => array( 'id' => 'images', 'label' => 'Images & Alt', 'weight' => 25, 'score' => 5, 'max' => 25, 'detail' => 'Aucune image' ), 'issues' => array( array( 'type' => 'no_images', 'element' => 'img', 'current' => '', 'detail' => 'Aucune image — ajoutez au moins 1 image', 'post_id' => $post_id ) ) );
        }

        // Si le check ALT est désactivé, on compte les images et on retourne un score neutre
        if ( ! $check_alt ) {
            $total_imgs = count( $imgs ) + ( $has_featured ? 1 : 0 );
            $score = $total_imgs > 0 ? 20 : 10;
            return array(
                'criterion' => array(
                    'id'     => 'images',
                    'label'  => 'Images & Alt',
                    'weight' => 25,
                    'score'  => $score,
                    'max'    => 25,
                    'detail' => $total_imgs . ' image(s) — vérification ALT désactivée dans les réglages',
                    'alt_check_disabled' => true,
                ),
                'issues' => array(),
            );
        }

        $total_imgs = count( $imgs ) + ( $has_featured ? 1 : 0 );
        $missing_alt = 0; $empty_alt = 0; $generic_alt = 0; $with_keyword = 0;
        $generic_pat = '/^(image|img|photo|screenshot|capture|picture|untitled|sans.titre|dsc|dcim|img_?\d+)/i';

        if ( $has_featured ) {
            if ( ! $featured_alt ) { $missing_alt++; $issues[] = array( 'type' => 'featured_no_alt', 'element' => 'featured', 'current' => '', 'detail' => 'Image mise en avant : alt manquant', 'post_id' => $post_id, 'attachment_id' => $featured_id ); }
            elseif ( preg_match( $generic_pat, $featured_alt ) ) { $generic_alt++; $issues[] = array( 'type' => 'featured_generic_alt', 'element' => 'featured', 'current' => $featured_alt, 'detail' => 'Image mise en avant : alt générique', 'post_id' => $post_id, 'attachment_id' => $featured_id ); }
            elseif ( $keyword && mb_stripos( $featured_alt, $keyword ) !== false ) { $with_keyword++; }
        }

        $seen_srcs = array();
        $feat_src_base = '';
        if ( $has_featured ) { $f_url = wp_get_attachment_url( $featured_id ); $fb = strtolower( basename( $f_url ?: '' ) ); if ( $fb ) $seen_srcs[] = $fb; $feat_src_base = preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', $fb ); }

        foreach ( $imgs as $img ) {
            if ( class_exists( 'HTS_Content_Extractor' ) ) $img = HTS_Content_Extractor::resolve_lazy_src( $img );
            $full_src = ''; if ( preg_match( '/src\s*=\s*["\']([^"\']+)["\']/', $img, $sm ) ) $full_src = $sm[1];
            if ( strpos( $full_src, 'data:' ) === 0 ) { $total_imgs--; continue; }
            if ( preg_match( '/width\s*=\s*["\']?1["\']?/i', $img ) && preg_match( '/height\s*=\s*["\']?1["\']?/i', $img ) ) { $total_imgs--; continue; }
            if ( class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_decorative_svg( $img ) ) { $total_imgs--; continue; }
            $img_src = basename( $full_src ); $src_lower = strtolower( $img_src );
            if ( $has_featured && $img_src ) {
                $att_id = 0; if ( preg_match( '/class\s*=\s*["\'][^"\']*wp-image-(\d+)/', $img, $cm ) ) $att_id = (int) $cm[1];
                if ( $att_id && $att_id === $featured_id ) { $total_imgs--; continue; }
                $sb = preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', $src_lower );
                if ( $sb && $feat_src_base && $sb === $feat_src_base ) { $total_imgs--; continue; }
            }
            if ( $src_lower && in_array( $src_lower, $seen_srcs, true ) ) { $total_imgs--; continue; }
            if ( $src_lower ) $seen_srcs[] = $src_lower;

            if ( ! preg_match( '/alt\s*=\s*["\']([^"\']*)["\']/', $img, $am ) ) {
                $missing_alt++; $issues[] = array( 'type' => 'img_no_alt', 'element' => 'img', 'current' => '', 'src' => $img_src, 'detail' => 'Alt manquant: ' . $img_src, 'post_id' => $post_id, 'img_tag' => mb_substr( $img, 0, 300 ) ); continue;
            }
            $alt = trim( $am[1] );
            if ( $alt === '' ) { $empty_alt++; $issues[] = array( 'type' => 'img_empty_alt', 'element' => 'img', 'current' => '', 'src' => $img_src, 'detail' => 'Alt vide: ' . $img_src, 'post_id' => $post_id, 'img_tag' => mb_substr( $img, 0, 300 ) ); continue; }
            if ( preg_match( $generic_pat, $alt ) ) { $generic_alt++; $issues[] = array( 'type' => 'img_generic_alt', 'element' => 'img', 'current' => $alt, 'detail' => 'Alt générique', 'post_id' => $post_id, 'img_tag' => mb_substr( $img, 0, 300 ) ); }
            if ( $keyword && mb_stripos( $alt, $keyword ) !== false ) $with_keyword++;
        }

        $bad = $missing_alt + $empty_alt + $generic_alt;
        $total_imgs = max( 1, $total_imgs );
        if ( $bad === 0 && $with_keyword >= 1 ) { $score = 25; $detail = '✓ ' . $total_imgs . ' images — Toutes optimisées'; }
        elseif ( $bad === 0 ) { $score = 20; $detail = '✓ ' . $total_imgs . ' images — Alt OK'; }
        else { $pct = $bad / $total_imgs; $score = $pct > 0.5 ? 5 : ( $pct > 0.25 ? 12 : 17 ); $detail = $total_imgs . ' images — ' . $bad . ' alt à corriger'; }

        return array( 'criterion' => array( 'id' => 'images', 'label' => 'Images & Alt', 'weight' => 25, 'score' => min( 25, $score ), 'max' => 25, 'detail' => $detail ), 'issues' => $issues );
    }

    private function score_heading_structure( $content ) {
        $issues = array(); $headings = array();
        if ( preg_match_all( '/<h([2-6])[^>]*>(.*?)<\/h\1>/is', $content, $m ) ) {
            foreach ( $m[1] as $i => $l ) $headings[] = array( 'level' => (int) $l, 'text' => wp_strip_all_tags( $m[2][$i] ) );
        }
        if ( empty( $headings ) ) {
            return array( 'criterion' => array( 'id' => 'headings', 'label' => 'Structure Hn', 'weight' => 15, 'score' => 3, 'max' => 15, 'detail' => 'Aucun sous-titre H2-H6' ), 'issues' => array( array( 'type' => 'no_headings', 'element' => 'headings', 'current' => '', 'detail' => 'Ajoutez des sous-titres H2/H3' ) ) );
        }
        $score = 9; $dp = array( count( $headings ) . ' sous-titres' );
        $h2c = count( array_filter( $headings, function( $h ) { return $h['level'] === 2; } ) );
        if ( $h2c === 0 ) { $score -= 3; $dp[] = 'pas de H2'; $issues[] = array( 'type' => 'no_h2', 'element' => 'headings', 'current' => '', 'detail' => 'Aucun H2' ); }
        elseif ( $h2c >= 2 ) { $score += 3; $dp[] = $h2c . ' H2'; }
        $skip = false;
        for ( $i = 1; $i < count( $headings ); $i++ ) { if ( $headings[$i]['level'] > $headings[$i-1]['level'] + 1 ) { $skip = true; break; } }
        if ( $skip ) { $score -= 2; $dp[] = 'hiérarchie cassée'; $issues[] = array( 'type' => 'heading_skip', 'element' => 'headings', 'current' => '', 'detail' => 'Saut de niveau Hn' ); }
        else { $score += 3; $dp[] = '✓ hiérarchie OK'; }
        return array( 'criterion' => array( 'id' => 'headings', 'label' => 'Structure Hn', 'weight' => 15, 'score' => min( 15, max( 0, $score ) ), 'max' => 15, 'detail' => implode( ' | ', $dp ) ), 'issues' => $issues );
    }

    private function score_content_length( $content ) {
        $w = hts_word_count( wp_strip_all_tags( $content ) );
        $thin = self::get_thin_content_words();
        if ( $w >= 1500 ) return array( 'id' => 'length', 'label' => 'Longueur contenu', 'weight' => 10, 'score' => 10, 'max' => 10, 'detail' => '✓ ' . $w . ' mots — Excellent' );
        if ( $w >= 800 )  return array( 'id' => 'length', 'label' => 'Longueur contenu', 'weight' => 10, 'score' => 8, 'max' => 10, 'detail' => '✓ ' . $w . ' mots — Bon' );
        if ( $w >= $thin ) return array( 'id' => 'length', 'label' => 'Longueur contenu', 'weight' => 10, 'score' => 5, 'max' => 10, 'detail' => $w . ' mots — Court (800+ recommandé)' );
        return array( 'id' => 'length', 'label' => 'Longueur contenu', 'weight' => 10, 'score' => 2, 'max' => 10, 'detail' => '' . $w . ' mots — Très court (moins de ' . $thin . ')' );
    }

    private function score_keyword_density( $content, $keyword ) {
        if ( ! $keyword ) return array( 'id' => 'density', 'label' => 'Densité mot-clé', 'weight' => 10, 'score' => 5, 'max' => 10, 'detail' => 'Aucun mot-clé focus défini' );
        $text = mb_strtolower( wp_strip_all_tags( $content ) ); $kw = mb_strtolower( $keyword );
        $words = hts_word_count( $text );
        if ( $words === 0 ) return array( 'id' => 'density', 'label' => 'Densité mot-clé', 'weight' => 10, 'score' => 0, 'max' => 10, 'detail' => 'Contenu vide' );
        $count = $this->count_keyword_fuzzy( $text, $kw );
        $d = ( $count * hts_word_count( $kw ) ) / $words * 100;
        if ( $d >= 0.5 && $d <= 2.5 ) return array( 'id' => 'density', 'label' => 'Densité mot-clé', 'weight' => 10, 'score' => 10, 'max' => 10, 'detail' => '✓ ' . round( $d, 1 ) . '% (' . $count . 'x) — Idéal' );
        if ( $d > 2.5 ) return array( 'id' => 'density', 'label' => 'Densité mot-clé', 'weight' => 10, 'score' => 4, 'max' => 10, 'detail' => round( $d, 1 ) . '% — Suroptimisation' );
        if ( $d > 0 ) return array( 'id' => 'density', 'label' => 'Densité mot-clé', 'weight' => 10, 'score' => 6, 'max' => 10, 'detail' => round( $d, 1 ) . '% — Trop faible' );
        return array( 'id' => 'density', 'label' => 'Densité mot-clé', 'weight' => 10, 'score' => 0, 'max' => 10, 'detail' => 'Mot-clé absent' );
    }

    private function score_internal_links( $content, $post_id ) {
        $home = home_url(); preg_match_all( '/<a\s[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $content, $m );
        $int = 0; foreach ( $m[1] ?? array() as $u ) { if ( strpos( $u, $home ) !== false || ( strpos( $u, '/' ) === 0 && strpos( $u, '//' ) !== 0 ) ) $int++; }

        // Fix 3: Brouillons — ne pas pénaliser, les liens frères sont ajoutés à la publication
        $post_status = get_post_status( $post_id );
        if ( $post_status === 'draft' || $post_status === 'auto-draft' ) {
            $note = $int > 0 ? $int . ' lien(s) interne(s)' : 'Les liens seront ajoutés automatiquement à la publication';
            return array( 'criterion' => array( 'id' => 'links', 'label' => 'Liens internes', 'weight' => 10, 'score' => 8, 'max' => 10, 'detail' => $note ) );
        }

        if ( $int >= 3 ) return array( 'criterion' => array( 'id' => 'links', 'label' => 'Liens internes', 'weight' => 10, 'score' => 10, 'max' => 10, 'detail' => '✓ ' . $int . ' liens internes' ) );
        if ( $int >= 1 ) return array( 'criterion' => array( 'id' => 'links', 'label' => 'Liens internes', 'weight' => 10, 'score' => 6, 'max' => 10, 'detail' => $int . ' lien(s) interne(s) — Ajoutez-en (min 3)' ) );
        return array( 'criterion' => array( 'id' => 'links', 'label' => 'Liens internes', 'weight' => 10, 'score' => 1, 'max' => 10, 'detail' => 'Aucun lien interne' ) );
    }

    private function score_readability( $content ) {
        $text = wp_strip_all_tags( $content ); $sents = preg_split( '/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $c = count( $sents ); if ( $c === 0 ) return array( 'id' => 'readability', 'label' => 'Lisibilité', 'weight' => 10, 'score' => 0, 'max' => 10, 'detail' => 'Contenu vide' );
        $tw = 0; $long = 0; foreach ( $sents as $s ) { $w = hts_word_count( trim( $s ) ); $tw += $w; if ( $w > 25 ) $long++; }
        $avg = $tw / $c;
        if ( $avg <= 20 && $long / $c < 0.2 ) return array( 'id' => 'readability', 'label' => 'Lisibilité', 'weight' => 10, 'score' => 10, 'max' => 10, 'detail' => '✓ Phrases courtes (moy. ' . round( $avg ) . ' mots)' );
        if ( $avg <= 25 ) return array( 'id' => 'readability', 'label' => 'Lisibilité', 'weight' => 10, 'score' => 7, 'max' => 10, 'detail' => 'Phrases moyennes (' . round( $avg ) . ' mots, ' . $long . ' longues)' );
        return array( 'id' => 'readability', 'label' => 'Lisibilité', 'weight' => 10, 'score' => 4, 'max' => 10, 'detail' => 'Phrases trop longues (moy. ' . round( $avg ) . ' mots)' );
    }

    /* ═══ 2. AI SUGGESTIONS ═══ */

    public function generate_suggestions( $post_id, $issues = null ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'suggestions' => array() );
        $keyword = $this->get_focus_keyword( $post_id );
        $title = $post->post_title;
        $content = class_exists( 'HTS_Content_Extractor' ) ? HTS_Content_Extractor::get_content( $post_id ) : $post->post_content;
        $detail = get_post_meta( $post_id, self::DETAIL_META, true );
        $cmap = array(); foreach ( ($detail['criteria'] ?? array()) as $c ) $cmap[ $c['id'] ] = $c;

        $suggestions = array();
        $suggestions = array_merge( $suggestions, $this->suggest_images( $content, $keyword, $title, $post_id ) );
        $suggestions = array_merge( $suggestions, $this->suggest_links( $post_id, $content, $keyword, $cmap ) );
        $suggestions = array_merge( $suggestions, $this->suggest_headings( $post_id, $content, $keyword, $title, $cmap ) );
        $suggestions = array_merge( $suggestions, $this->suggest_h1( $title, $keyword ) );
        $suggestions = array_merge( $suggestions, $this->suggest_density( $content, $keyword, $cmap ) );
        $suggestions = array_merge( $suggestions, $this->suggest_length( $content, $keyword, $title, $cmap ) );
        return array( 'suggestions' => $suggestions );
    }

    private function suggest_images( $content, $keyword, $title, $post_id ) {
        $needs_fix = array();
        $featured_id = get_post_thumbnail_id( $post_id );
        $generic_pat = '/^(image|img|photo|screenshot|capture|picture|untitled|sans.titre|dsc|dcim|img_?\d+)/i';

        if ( $featured_id ) {
            $fa = trim( get_post_meta( $featured_id, '_wp_attachment_image_alt', true ) );
            $fu = wp_get_attachment_url( $featured_id );
            $st = 'ok';
            if ( ! $fa ) $st = 'missing'; elseif ( preg_match( $generic_pat, $fa ) ) $st = 'generic'; elseif ( mb_strlen( $fa ) > 125 ) $st = 'too_long';
            if ( $st !== 'ok' ) $needs_fix[] = array( 'src' => basename( $fu ?: 'featured' ), 'alt' => $fa, 'status' => $st, 'is_featured' => true, 'attachment_id' => $featured_id, 'img_tag' => '' );
        }

        preg_match_all( '/<img[^>]+>/i', $content, $matches );
        $seen = array();
        foreach ( $matches[0] ?? array() as $img ) {
            if ( class_exists( 'HTS_Content_Extractor' ) ) $img = HTS_Content_Extractor::resolve_lazy_src( $img );
            $fs = ''; if ( preg_match( '/src\s*=\s*["\']([^"\']+)["\']/', $img, $sm ) ) $fs = $sm[1];
            if ( strpos( $fs, 'data:' ) === 0 ) continue;
            $src = basename( $fs ); $sl = strtolower( $src );
            if ( $sl && in_array( $sl, $seen, true ) ) continue; if ( $sl ) $seen[] = $sl;
            $aid = 0; if ( preg_match( '/wp-image-(\d+)/', $img, $cm ) ) $aid = (int) $cm[1];
            if ( $aid && $featured_id && $aid === $featured_id ) continue;

            $ha = preg_match( '/alt\s*=\s*["\']([^"\']*)["\']/', $img, $am ); $alt = $ha ? $am[1] : null;
            $st = 'ok';
            if ( $alt === null ) $st = 'missing'; elseif ( trim( $alt ) === '' ) $st = 'empty'; elseif ( preg_match( $generic_pat, $alt ) ) $st = 'generic';
            if ( $st !== 'ok' ) $needs_fix[] = array( 'src' => $src, 'alt' => $alt ?? '', 'status' => $st, 'is_featured' => false, 'attachment_id' => $aid, 'img_tag' => mb_substr( $img, 0, 300 ) );
        }
        if ( empty( $needs_fix ) ) return array();

        $sugs = array();
        $sugs[] = array( 'type' => 'img_summary', 'current' => '', 'auto' => false, 'suggestion' => count( $needs_fix ) . ' image(s) à corriger', 'reason' => 'Les textes alt améliorent votre référencement dans Google Images' );
        foreach ( $needs_fix as $img ) {
            $cs = preg_replace( '/[-_\d]+\.(jpg|jpeg|png|gif|webp|avif|svg)$/i', '', $img['src'] );
            $cs = str_replace( array('-','_'), ' ', $cs );
            $as = $keyword ? $keyword . ' — ' . ucfirst( $cs ) : ucfirst( $cs );
            $sugs[] = array( 'type' => 'img_alt', 'current' => $img['alt'], 'src' => $img['src'], 'img_tag' => $img['img_tag'], 'is_featured' => $img['is_featured'], 'attachment_id' => $img['attachment_id'], 'suggestion' => mb_substr( $as, 0, 120 ), 'reason' => ($img['is_featured'] ? '⭐ ' : '') . 'Alt ' . $img['status'], 'auto' => true );
        }
        return $sugs;
    }

    private function suggest_links( $post_id, $content, $keyword, $cmap ) {
        $lc = $cmap['links'] ?? null;
        if ( $lc && $lc['max'] > 0 && $lc['score'] / $lc['max'] >= 0.8 ) return array();
        $home = home_url(); preg_match_all( '/<a\s[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $content, $lm );
        $eu = array(); foreach ( $lm[1] ?? array() as $u ) { if ( strpos( $u, $home ) !== false || ( strpos( $u, '/' ) === 0 && strpos( $u, '//' ) !== 0 ) ) $eu[] = $u; }
        $ic = count( $eu );
        if ( $ic >= 3 || ! $keyword ) return array();

        $related = get_posts( array( 'post_type' => array('post','page'), 'post_status' => 'publish', 'posts_per_page' => 10, 's' => $keyword, 'exclude' => array( $post_id ) ) );
        $items = array(); $plain = mb_strtolower( wp_strip_all_tags( $content ) );
        foreach ( $related as $rel ) {
            $ru = get_permalink( $rel->ID ); if ( in_array( $ru, $eu, true ) ) continue;
            $anchor = '';
            if ( mb_stripos( $plain, mb_strtolower( $rel->post_title ) ) !== false ) { $pos = mb_stripos( wp_strip_all_tags( $content ), $rel->post_title ); $anchor = $pos !== false ? mb_substr( wp_strip_all_tags( $content ), $pos, mb_strlen( $rel->post_title ) ) : $rel->post_title; }
            elseif ( mb_stripos( $plain, mb_strtolower( $keyword ) ) !== false && mb_stripos( mb_strtolower( $rel->post_title ), mb_strtolower( $keyword ) ) !== false ) { $anchor = $keyword; }
            if ( ! $anchor ) continue;
            if ( preg_match( '/<a[^>]*>[^<]*' . preg_quote( $anchor, '/' ) . '[^<]*<\/a>/i', $content ) ) continue;
            $items[] = array( 'type' => 'internal_link', 'anchor_text' => $anchor, 'target_id' => $rel->ID, 'target_url' => $ru, 'target_title' => $rel->post_title, 'reason' => 'Renforcez votre maillage interne', 'suggestion' => $anchor . ' → ' . $rel->post_title, 'current' => $anchor, 'auto' => true );
            if ( count( $items ) >= 5 ) break;
        }
        if ( ! empty( $items ) ) array_unshift( $items, array( 'type' => 'link_summary', 'auto' => false, 'suggestion' => $ic . ' liens internes · ' . count( $items ) . ' opportunité(s)', 'reason' => 'Les liens internes aident Google à comprendre la structure de votre site', 'current' => '' ) );
        return $items;
    }

    private function suggest_headings( $post_id, $content, $keyword, $title, $cmap ) {
        $hc = $cmap['headings'] ?? null;
        if ( $hc && $hc['max'] > 0 && $hc['score'] / $hc['max'] >= 0.8 ) return array();
        $blocks = preg_split( '/(<h[2-6][^>]*>.*?<\/h[2-6]>)/is', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
        $orphans = array(); $cp = 0; $cos = '';
        foreach ( $blocks as $b ) {
            $t = trim( $b ); if ( empty( $t ) ) continue;
            if ( preg_match( '/^<h[2-6]/i', $t ) ) { if ( $cp >= 3 && $cos ) $orphans[] = array( 'ib' => mb_substr( $cos, 0, 200 ), 'pc' => $cp ); $cp = 0; $cos = ''; }
            else { $cp += max( 1, preg_match_all( '/<p[^>]*>/i', $b ) ); if ( ! $cos && mb_strlen( trim( wp_strip_all_tags( $b ) ) ) > 20 ) $cos = trim( wp_strip_all_tags( $b ) ); }
        }
        if ( $cp >= 3 && $cos ) $orphans[] = array( 'ib' => mb_substr( $cos, 0, 200 ), 'pc' => $cp );

        preg_match_all( '/<h([2-6])[^>]*>/i', $content, $eh );
        $hcount = count( $eh[0] ?? array() );
        if ( empty( $orphans ) && $hcount > 0 ) return array();

        $sugs = array();
        foreach ( array_slice( $orphans, 0, 4 ) as $o ) {
            $ht = ucfirst( implode( ' ', array_slice( explode( ' ', $o['ib'] ), 0, 6 ) ) ) . '…';
            $sugs[] = array( 'type' => 'heading_insert', 'suggestion' => $ht, 'heading_level' => 2, 'insert_before' => $o['ib'], 'reason' => $o['pc'] . ' paragraphes sans sous-titre', 'current' => '', 'auto' => true );
        }
        if ( ! empty( $sugs ) ) array_unshift( $sugs, array( 'type' => 'heading_summary', 'auto' => false, 'suggestion' => $hcount . ' sous-titres · ' . count( $sugs ) . ' à ajouter', 'reason' => 'Structurez votre contenu pour les lecteurs et Google', 'current' => '' ) );
        return $sugs;
    }

    private function suggest_h1( $title, $keyword ) {
        $tips = array(); $len = mb_strlen( $title );
        if ( $keyword && mb_stripos( $title, $keyword ) === false ) $tips[] = 'Intégrez "' . $keyword . '" dans votre titre/H1.';
        if ( $len > 70 ) $tips[] = 'H1 trop long (' . $len . ' car.) — 60-70 max.';
        if ( $len < 20 ) $tips[] = 'H1 très court — enrichissez-le.';
        if ( empty( $tips ) ) return array();
        $s = array();
        foreach ( $tips as $t ) $s[] = array( 'type' => 'h1_advice', 'current' => $title, 'suggestion' => $t, 'reason' => 'À modifier dans l\'éditeur WordPress', 'auto' => false );
        return $s;
    }

    private function suggest_density( $content, $keyword, $cmap ) {
        if ( ! $keyword ) return array();
        $dc = $cmap['density'] ?? null;
        if ( $dc && $dc['max'] > 0 && $dc['score'] / $dc['max'] >= 0.8 ) return array();
        $text = mb_strtolower( wp_strip_all_tags( $content ) ); $kw = mb_strtolower( $keyword );
        $words = hts_word_count( $text );
        $count = $this->count_keyword_fuzzy( $text, $kw );
        $d = $words > 0 ? round( ( $count * hts_word_count( $kw ) ) / $words * 100, 1 ) : 0;
        if ( $d >= 0.5 && $d <= 2.5 ) return array();
        if ( $d < 0.5 ) {
            $target = max( 1, (int) ceil( $words * 0.01 / max( 1, hts_word_count( $kw ) ) ) );
            return array( array( 'type' => 'density_advice', 'auto' => false, 'suggestion' => 'Densité: ' . $d . '% — ajoutez ~' . max( 0, $target - $count ) . ' occurrence(s)', 'reason' => 'Votre mot-clé est trop rare dans le texte', 'current' => $d . '% (' . $count . 'x)' ) );
        }
        return array( array( 'type' => 'density_advice', 'auto' => false, 'suggestion' => 'Densité: ' . $d . '% — remplacez certaines occurrences par des synonymes', 'reason' => 'Risque de suroptimisation', 'current' => $d . '% (' . $count . 'x)' ) );
    }

    private function suggest_length( $content, $keyword, $title, $cmap ) {
        $lc = $cmap['length'] ?? null;
        if ( $lc && $lc['max'] > 0 && $lc['score'] / $lc['max'] >= 0.8 ) return array();
        $w = hts_word_count( wp_strip_all_tags( $content ) );
        if ( $w >= 800 ) return array();
        $target = $w < 300 ? 1200 : 800; $gap = $target - $w;
        return array( array( 'type' => 'content_advice', 'auto' => false, 'suggestion' => $w . ' mots — ajoutez ~' . $gap . ' mots', 'reason' => 'Les articles plus longs se positionnent mieux sur Google', 'current' => $w . ' mots' ) );
    }

    /* ═══ 3. APPLY + ROLLBACK ═══ */

    public function apply_suggestion( $post_id, $suggestion ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'success' => false, 'message' => 'Article introuvable.' );
        $type = $suggestion['type'] ?? '';
        if ( $type === 'h1' || $type === 'h1_advice' ) return array( 'success' => false, 'message' => 'Le H1 ne peut pas être modifié automatiquement.' );

        $writer_backup = class_exists( 'HTS_Content_Writer' ) ? HTS_Content_Writer::get_raw_backup( $post_id ) : null;
        $changed = false; $change_desc = ''; $rollback_data = null;

        if ( $type === 'img_alt' ) {
            $new_alt = sanitize_text_field( $suggestion['suggestion'] );
            $is_feat = ! empty( $suggestion['is_featured'] );
            $att_id  = absint( $suggestion['attachment_id'] ?? 0 );
            $img_tag = $suggestion['img_tag'] ?? '';

            if ( $is_feat || ( $att_id && ! $img_tag ) ) {
                if ( ! $att_id ) $att_id = get_post_thumbnail_id( $post_id );
                if ( ! $att_id ) return array( 'success' => false, 'message' => 'Image mise en avant introuvable.' );
                $old_alt = get_post_meta( $att_id, '_wp_attachment_image_alt', true );
                update_post_meta( $att_id, '_wp_attachment_image_alt', $new_alt );
                $change_desc = '⭐ Alt featured: → "' . mb_substr( $new_alt, 0, 40 ) . '"';
                $changed = true; $rollback_data = array( 'attachment_id' => $att_id, 'old_alt' => $old_alt );
            } else {
                $img_src = ''; if ( $img_tag && preg_match( '/src=["\']([^"\']+)["\']/', $img_tag, $sm ) ) $img_src = $sm[1];
                if ( ! $img_src ) return array( 'success' => false, 'message' => 'Src image introuvable.' );
                if ( ! class_exists( 'HTS_Content_Writer' ) ) return array( 'success' => false, 'message' => 'Content Writer non disponible.' );
                $wr = HTS_Content_Writer::update_image_alt( $post_id, $img_src, $new_alt );
                if ( ! $wr['success'] ) return $wr;
                if ( $att_id ) update_post_meta( $att_id, '_wp_attachment_image_alt', $new_alt );
                $change_desc = '🖼️ Alt (' . ($wr['builder'] ?? 'std') . '): → "' . mb_substr( $new_alt, 0, 40 ) . '"';
                $changed = true; $rollback_data = array( 'writer_backup' => $writer_backup );
                if ( $att_id ) { $rollback_data['attachment_id'] = $att_id; $rollback_data['old_alt'] = $suggestion['current'] ?? ''; }
            }
        } elseif ( $type === 'internal_link' ) {
            $anchor = $suggestion['anchor_text'] ?? $suggestion['current'] ?? '';
            $turl = $suggestion['target_url'] ?? ''; $tt = $suggestion['target_title'] ?? '';
            if ( ! $anchor || ! $turl ) return array( 'success' => false, 'message' => 'Anchor ou URL manquant.' );
            if ( ! class_exists( 'HTS_Content_Writer' ) ) return array( 'success' => false, 'message' => 'Content Writer non disponible.' );
            $check = class_exists( 'HTS_Content_Extractor' ) ? HTS_Content_Extractor::get_content( $post_id ) : $post->post_content;
            if ( preg_match( '/<a[^>]*>[^<]*' . preg_quote( $anchor, '/' ) . '[^<]*<\/a>/iu', $check ) ) return array( 'success' => false, 'message' => 'Ce texte est déjà un lien.' );
            $wr = HTS_Content_Writer::insert_link( $post_id, $anchor, $turl, array( 'title' => $tt ) );
            if ( ! $wr['success'] ) return $wr;
            $change_desc = '🔗 Lien: "' . mb_substr( $anchor, 0, 30 ) . '" → ' . mb_substr( $tt, 0, 40 );
            $changed = true; $rollback_data = array( 'writer_backup' => $writer_backup );
        } elseif ( $type === 'heading_insert' ) {
            $ht = sanitize_text_field( $suggestion['suggestion'] ?? '' );
            $hl = min( 6, max( 2, (int) ($suggestion['heading_level'] ?? 2) ) );
            $ib = $suggestion['insert_before'] ?? '';
            if ( ! $ht || ! $ib ) return array( 'success' => false, 'message' => 'Texte ou position manquant.' );
            if ( ! class_exists( 'HTS_Content_Writer' ) ) return array( 'success' => false, 'message' => 'Content Writer non disponible.' );
            $hhtml = '<h' . $hl . '>' . esc_html( $ht ) . '</h' . $hl . '>';
            $snip = mb_substr( trim( $ib ), 0, 80 );
            $wr = HTS_Content_Writer::replace_text( $post_id, $snip, $hhtml . "\n" . $snip );
            if ( ! $wr['success'] ) return array( 'success' => false, 'message' => 'Position introuvable.' );
            $change_desc = '📐 H' . $hl . ': "' . mb_substr( $ht, 0, 40 ) . '"';
            $changed = true; $rollback_data = array( 'writer_backup' => $writer_backup );
        } else {
            return array( 'success' => false, 'message' => 'Type non supporté: ' . $type );
        }

        if ( ! $changed ) return array( 'success' => false, 'message' => 'Aucune modification.' );

        $old_score = (int) get_post_meta( $post_id, self::SCORE_META, true );
        $new_score = $this->score_post( $post_id );

        $history = get_post_meta( $post_id, self::HISTORY_META, true );
        if ( ! is_array( $history ) ) $history = array();
        $history[] = array( 'action' => $change_desc, 'type' => $type, 'score_before' => $old_score, 'score_after' => $new_score['score'], 'delta' => $new_score['score'] - $old_score, 'source' => 'ai_onpage', 'date' => current_time( 'Y-m-d H:i' ), 'rollback_data' => $rollback_data, 'content_hash_after' => md5( get_post( $post_id )->post_content ?? '' ) );
        update_post_meta( $post_id, self::HISTORY_META, array_slice( $history, -30 ) );

        if ( function_exists( 'hts_add_log' ) ) {
            $icons = array( 'img_alt' => '🖼️', 'internal_link' => '🔗', 'heading_insert' => '📐' );
            hts_add_log( ($icons[$type] ?? '✏️') . ' On-Page: "' . get_the_title( $post_id ) . '" — ' . $old_score . ' → ' . $new_score['score'] . ' | ' . $change_desc, $new_score['score'] > $old_score ? 'success' : 'warning', 'onpage' );
        }
        return array( 'success' => true, 'message' => $change_desc . ' — Score ' . $new_score['score'] . '/100', 'score' => $new_score );
    }

    public function rollback( $post_id, $entry_index ) {
        $history = get_post_meta( $post_id, self::HISTORY_META, true );
        if ( ! is_array( $history ) || ! isset( $history[ $entry_index ] ) ) return array( 'success' => false, 'message' => 'Entrée introuvable.' );
        $entry = $history[ $entry_index ];
        $rd = $entry['rollback_data'] ?? null;
        if ( ! $rd ) return array( 'success' => false, 'message' => 'Données rollback manquantes.' );

        // Staleness check
        if ( isset( $rd['writer_backup'] ) || isset( $rd['post_content'] ) ) {
            $cc = get_post( $post_id )->post_content ?? '';
            $hash = $entry['content_hash_after'] ?? null;
            if ( $hash && md5( $cc ) !== $hash ) return array( 'success' => false, 'message' => 'Le contenu a été modifié depuis. Rollback bloqué par sécurité.' );
        }
        foreach ( $history as $h ) { if ( ($h['type'] ?? '') === 'rollback' && ($h['rolled_back'] ?? -1) === $entry_index ) return array( 'success' => false, 'message' => 'Déjà annulée.' ); }

        if ( isset( $rd['writer_backup'] ) && class_exists( 'HTS_Content_Writer' ) ) HTS_Content_Writer::restore_backup( $post_id, $rd['writer_backup'] );
        elseif ( isset( $rd['post_content'] ) ) { $rb = wp_update_post( array( 'ID' => $post_id, 'post_content' => $rd['post_content'] ) ); if ( is_wp_error( $rb ) || 0 === $rb ) { if ( function_exists( 'hts_add_log' ) ) hts_add_log( 'On-Page rollback échec post #' . $post_id, 'error', 'onpage' ); } if ( class_exists( 'HTS_Content_Extractor' ) ) HTS_Content_Extractor::invalidate_cache( $post_id ); }
        if ( ! empty( $rd['attachment_id'] ) && isset( $rd['old_alt'] ) ) update_post_meta( $rd['attachment_id'], '_wp_attachment_image_alt', $rd['old_alt'] );

        $ns = $this->score_post( $post_id );
        $history[] = array( 'action' => '↩️ Rollback: ' . ($entry['action'] ?? ''), 'type' => 'rollback', 'score_before' => $entry['score_after'] ?? 0, 'score_after' => $ns['score'], 'delta' => $ns['score'] - ($entry['score_after'] ?? 0), 'source' => 'rollback', 'date' => current_time( 'Y-m-d H:i' ), 'rolled_back' => $entry_index );
        update_post_meta( $post_id, self::HISTORY_META, $history );
        if ( function_exists( 'hts_add_log' ) ) hts_add_log( '↩️ On-Page Rollback: "' . get_the_title( $post_id ) . '"', 'warning', 'onpage' );
        return array( 'success' => true, 'message' => 'Rollback OK — Score ' . $ns['score'] . '/100', 'score' => $ns );
    }

    /* ═══ 4. AJAX ENDPOINTS ═══ */

    public function ajax_get_score() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        $pid = absint( $_POST['post_id'] ?? 0 );
        if ( ! $pid ) wp_send_json_error( 'post_id requis' );
        wp_send_json_success( $this->score_post( $pid ) );
    }

    public function ajax_generate() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission refusée' );
        $pid = absint( $_POST['post_id'] ?? 0 );
        if ( ! $pid ) wp_send_json_error( 'post_id requis' );
        $detail = get_post_meta( $pid, self::DETAIL_META, true );
        if ( ! $detail ) $detail = $this->score_post( $pid );
        $result = $this->generate_suggestions( $pid, $detail['issues'] ?? array() );
        wp_send_json_success( array( 'suggestions' => $result['suggestions'], 'current' => $detail, 'post_id' => $pid ) );
    }

    public function ajax_apply() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission refusée' );
        $pid = absint( $_POST['post_id'] ?? 0 );
        $type = sanitize_text_field( $_POST['type'] ?? '' );

        // Double-click lock (3s)
        $lock = 'hts_onpage_apply_' . $pid . '_' . md5( $type . ($_POST['suggestion'] ?? '') );
        if ( get_transient( $lock ) ) wp_send_json_error( array( 'message' => 'Action en cours — veuillez patienter.' ) );
        set_transient( $lock, 1, 3 );

        $sug = sanitize_text_field( wp_unslash( $_POST['suggestion'] ?? '' ) );
        if ( ! $pid || ! $type || ! $sug ) wp_send_json_error( 'Paramètres manquants.' );

        $result = $this->apply_suggestion( $pid, array(
            'type' => $type, 'current' => sanitize_text_field( wp_unslash( $_POST['current'] ?? '' ) ),
            'suggestion' => $sug, 'src' => sanitize_text_field( wp_unslash( $_POST['src'] ?? '' ) ),
            'img_tag' => wp_unslash( $_POST['img_tag'] ?? '' ),
            'is_featured' => ! empty( $_POST['is_featured'] ),
            'attachment_id' => absint( $_POST['attachment_id'] ?? 0 ),
            'anchor_text' => sanitize_text_field( wp_unslash( $_POST['anchor_text'] ?? '' ) ),
            'target_url' => esc_url_raw( wp_unslash( $_POST['target_url'] ?? '' ) ),
            'target_title' => sanitize_text_field( wp_unslash( $_POST['target_title'] ?? '' ) ),
            'heading_level' => absint( $_POST['heading_level'] ?? 2 ),
            'insert_before' => wp_unslash( $_POST['insert_before'] ?? '' ),
        ) );
        $result['success'] ? wp_send_json_success( $result ) : wp_send_json_error( $result );
    }

    public function ajax_rollback() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission refusée' );
        $pid = absint( $_POST['post_id'] ?? 0 );
        $idx = (int) ( $_POST['entry_index'] ?? -1 );
        if ( ! $pid || $idx < 0 ) wp_send_json_error( 'Paramètres manquants.' );
        $result = $this->rollback( $pid, $idx );
        $result['success'] ? wp_send_json_success( $result ) : wp_send_json_error( $result );
    }

    public function ajax_history() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        $pid = absint( $_POST['post_id'] ?? 0 );
        if ( ! $pid ) wp_send_json_error( 'post_id requis' );
        $history = get_post_meta( $pid, self::HISTORY_META, true );
        if ( ! is_array( $history ) ) $history = array();
        $clean = array(); $total = count( $history );
        foreach ( array_reverse( $history ) as $di => $e ) {
            $oi = $total - 1 - $di;
            $clean[] = array( 'action' => $e['action'] ?? '', 'type' => $e['type'] ?? '', 'score_before' => $e['score_before'] ?? 0, 'score_after' => $e['score_after'] ?? 0, 'delta' => $e['delta'] ?? 0, 'date' => $e['date'] ?? '', 'has_rollback' => ! empty( $e['rollback_data'] ), 'original_idx' => $oi );
        }
        wp_send_json_success( array( 'history' => $clean, 'post_id' => $pid, 'title' => get_the_title( $pid ) ) );
    }

    /* ═══ HELPERS ═══ */

    private function get_focus_keyword( $post_id ) {
        $kw = get_post_meta( $post_id, '_hts_focus_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, '_hts_api_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, '_hts_gsc_top_query', true );
        return $kw ?: '';
    }

    private function grade( $score ) {
        if ( $score >= 80 ) return 'A'; if ( $score >= 60 ) return 'B'; if ( $score >= 40 ) return 'C'; return 'D';
    }

    private function count_keyword_fuzzy( $text, $kw ) {
        $count = mb_substr_count( $text, $kw );
        $kw_words = preg_split( '/\s+/', $kw );
        if ( count( $kw_words ) >= 2 ) {
            $pp = array(); foreach ( $kw_words as $w ) { $base = preg_replace( '/(s|x|es)$/iu', '', $w ); $pp[] = preg_quote( $base, '/' ) . '(?:s|x|es)?'; }
            $fuzzy = preg_match_all( '/' . implode( '\s+', $pp ) . '/iu', $text );
            return max( $count, $fuzzy );
        }
        $base = preg_replace( '/(s|x|es)$/iu', '', $kw );
        $fuzzy = preg_match_all( '/' . preg_quote( $base, '/' ) . '(?:s|x|es)?/iu', $text );
        return max( $count, $fuzzy );
    }
}
