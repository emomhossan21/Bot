<?php
defined( 'ABSPATH' ) || exit;
/**
 * Article Pipeline — Post-traitement unifié pour tout article créé.
 *
 * Appelé par :
 *  - HTS_Cocon_Commander::ajax_create_draft()
 *  - HTS_API_Receiver::process_article()
 *  - (futur) Cron batch auto-write
 *
 * Chaque étape est déléguée aux méthodes publiques de
 * HTS_Synchronise_Articles_Admin (qui restent la source unique de vérité).
 *
 * @since 1.30.0
 * @package HackTheSEO
 */

class HTS_Article_Pipeline {

    /**
     * Enrichit un brouillon après création WordPress.
     *
     * @param int    $post_id  Post WordPress créé
     * @param string $title    Titre H1
     * @param string $keyword  Keyword cible
     * @param string $content  Contenu HTML nettoyé
     * @return array {
     *     @type int      $images_count  Nombre d'images générées
     *     @type int      $cross_links   Nombre de cross-links (outbound+inbound)
     *     @type array    $schemas       Schemas JSON-LD détectés
     *     @type bool     $stuffing      Keyword stuffing détecté
     *     @type string   $content       Contenu final (peut avoir été modifié par images/schemas)
     * }
     */
    public static function enrich_draft( $post_id, $title, $keyword, $content ) {

        $result = array(
            'images_count' => 0,
            'cross_links'  => 0,
            'schemas'      => array(),
            'stuffing'     => false,
            'content'      => $content,
        );

        // Vérifier que la classe admin est chargée
        if ( ! class_exists( 'HTS_Synchronise_Articles_Admin' ) ) {
            self::log( 'pipeline_error', 'Classe HTS_Synchronise_Articles_Admin non disponible', array( 'post_id' => $post_id ) );
            return $result;
        }

        $admin = 'HTS_Synchronise_Articles_Admin';

        // ── 1. Keyword stuffing detection (fast, sync) ──
        $stuffing = $admin::cocon_check_keyword_stuffing( $content, $keyword, $post_id );
        if ( ! empty( $stuffing['flagged'] ) ) {
            update_post_meta( $post_id, '_hts_keyword_stuffing', $stuffing );
            $result['stuffing'] = true;
        }

        // ── 2. Schemas: handled by the plugin's frontend module (not injected into content) ──
        $result['schemas'] = array();

        // ── 4. Content update deferred to cron (images + cross-linking) ──
        // No wp_update_post here — content hasn't changed yet.
        // The hts_deferred_images cron will update content after image insertion.

        // ── 5. Defer heavy operations to cron (images 30-90s + cross-linking 30-80s) ──
        // This prevents AJAX timeouts and page freezes during article generation.
        // Cross-linking ALWAYS runs; image generation only if agent is enabled.
        $image_agent_on = ! class_exists( 'HTS_Workflow_Engine' ) || HTS_Workflow_Engine::is_agent_enabled( 'image' );

        // Always schedule deferred cron (cross-linking needs it even without images)
        // IMG1: Utiliser un timestamp (cohérent avec phase_auto_images cleanup stale)
        update_post_meta( $post_id, '_hts_images_pending', current_time( 'mysql' ) );
        update_post_meta( $post_id, '_hts_images_pending_since', time() );
        if ( ! $image_agent_on ) {
            update_post_meta( $post_id, '_hts_skip_image_gen', 1 );
        }
        if ( ! wp_next_scheduled( 'hts_deferred_images', array( $post_id, $title, $keyword ) ) ) {
            wp_schedule_single_event( time() + 10, 'hts_deferred_images', array( $post_id, $title, $keyword ) );
        }
        self::log( 'pipeline_deferred', 'Images + maillage programmés en arrière-plan' . ( $image_agent_on ? '' : ' (images désactivées, maillage seul)' ), array( 'post_id' => $post_id ) );

        // ── 6. Store enrichment meta ──
        update_post_meta( $post_id, '_hts_pipeline_enriched', 1 );
        update_post_meta( $post_id, '_hts_pipeline_enriched_at', current_time( 'Y-m-d H:i:s' ) );
        update_post_meta( $post_id, '_hts_pipeline_schemas', $result['schemas'] );
        update_post_meta( $post_id, '_hts_pipeline_images', 0 );       // Updated by deferred cron
        update_post_meta( $post_id, '_hts_pipeline_cross_links', 0 );  // Updated by deferred cron

        // ── 7. Log ──
        self::log( 'pipeline_complete', 'Pipeline enrichissement terminé', array(
            'post_id'      => $post_id,
            'images'       => $result['images_count'],
            'cross_links'  => $result['cross_links'],
            'schemas'      => implode( ', ', $result['schemas'] ),
            'stuffing'     => $result['stuffing'] ? 'oui' : 'non',
        ) );

        // Audit Trail si disponible
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log( $post_id, 'pipeline_enriched', array(
                'images'      => $result['images_count'],
                'cross_links' => $result['cross_links'],
                'schemas'     => $result['schemas'],
            ) );
        }

        return $result;
    }

    /**
     * Logging helper — délègue au système de log existant.
     */
    private static function log( $type, $message, $data = array() ) {
        if ( class_exists( 'HTS_Synchronise_Articles_Admin' ) && method_exists( 'HTS_Synchronise_Articles_Admin', 'cocon_log' ) ) {
            HTS_Synchronise_Articles_Admin::cocon_log( $type, $message, $data );
        } elseif ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( $message, 'info', 'article-pipeline' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  COACH INTEGRATION STUB — Sprint 5.1
     * ═══════════════════════════════════════════════ */

    /**
     * Schedule publication of a draft post.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_id: int, publish_date?: string }
     * @return bool
     */
    public static function schedule_from_coach( $params ) {
        $post_id = isset( $params['post_id'] ) ? (int) $params['post_id'] : 0;
        if ( $post_id <= 0 ) return false;

        $post = get_post( $post_id );
        if ( ! $post || $post->post_status === 'publish' ) return false;

        $publish_date = ! empty( $params['publish_date'] ) ? sanitize_text_field( $params['publish_date'] ) : '';

        if ( $publish_date ) {
            // Schedule for a future date
            $timestamp = strtotime( $publish_date );
            if ( $timestamp && $timestamp > time() ) {
                $result = wp_update_post( array(
                    'ID'            => $post_id,
                    'post_status'   => 'future',
                    'post_date'     => get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $timestamp ) ),
                    'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $timestamp ),
                ) );
                if ( is_wp_error( $result ) || 0 === $result ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( "Coach: schedule_from_coach wp_update_post failed for post #{$post_id}: " . ( is_wp_error( $result ) ? $result->get_error_message() : 'returned 0' ), 'error', 'coach' );
                    }
                    return false;
                }
            } else {
                // Date in the past or invalid → publish now
                $result = wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );
                if ( is_wp_error( $result ) || 0 === $result ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( "Coach: schedule_from_coach wp_update_post failed for post #{$post_id}: " . ( is_wp_error( $result ) ? $result->get_error_message() : 'returned 0' ), 'error', 'coach' );
                    }
                    return false;
                }
            }
        } else {
            // No date specified → publish now
            $result = wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );
            if ( is_wp_error( $result ) || 0 === $result ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Coach: schedule_from_coach wp_update_post failed for post #{$post_id}: " . ( is_wp_error( $result ) ? $result->get_error_message() : 'returned 0' ), 'error', 'coach' );
                }
                return false;
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach: schedule_from_coach post #{$post_id} → " . ( $publish_date ?: 'immédiat' ), 'info', 'coach' );
        }

        return true;
    }
}
