<?php
defined( 'ABSPATH' ) || exit;
/**
 * Module Coach SEO — IA connectée aux vrais scores du client.
 *
 * Phase 6 v2.0 — Killer Feature
 * Utilise l'API Anthropic (Claude) avec le contexte réel du site
 * pour donner des conseils SEO personnalisés.
 *
 * @since 1.35.0
 */

if ( ! defined( 'WPINC' ) ) die;

class HTS_Coach {

    /* ═══════════════════════════════════════════════
     *  CONSTANTES
     * ═══════════════════════════════════════════════ */

    const OPT_API_KEY          = 'hts_coach_api_key';
    const OPT_BUDGET           = 'hts_coach_budget';
    const OPT_USAGE            = 'hts_coach_usage';
    const OPT_HISTORY          = 'hts_coach_history';

    const RATE_LIMIT_TRANSIENT = 'hts_coach_rate_';
    const RATE_LIMIT_MAX       = 60;            // 60 requêtes/heure (optim coûts — était 200)
    const RATE_LIMIT_WINDOW    = 3600;         // 1h en secondes

    const HARD_LIMIT_TOKENS    = 2000000;      // 2M tokens/mois hard limit (optim coûts — était 99999999)
    const DEFAULT_BUDGET       = 2000000;      // 2M tokens/mois par défaut (optim coûts — était 99999999)
    const MAX_CONTEXT_PAGES    = 500;          // tronquer au-delà
    const MAX_HISTORY_TURNS    = 30;           // N derniers échanges gardés (v4: augmenté de 10→30)
    const TIMEOUT_SECONDS      = 60;           // 60s timeout (v4: augmenté de 30→60 pour plans longs)
    const TOOL_MAX_ITERATIONS  = 3;            // Sprint 4.5: max tool_use round-trips per question
    const MAX_RETRIES          = 1;

    const API_URL              = 'https://api.anthropic.com/v1/messages';
    const OPENAI_API_URL       = 'https://api.openai.com/v1/chat/completions';
    const MODEL                = 'claude-haiku-4-5-20251001'; // fallback Anthropic
    const OPENAI_MODEL         = 'gpt-4o-mini';               // tier 1 : support/debug
    const OPENAI_MODEL_MID     = 'gpt-4.1-mini';              // tier 2 : analyse SEO
    const MAX_TOKENS_RESPONSE  = 2048;         // default — adapté par intent dans get_max_tokens()
    const MAX_TOKENS_LIGHT     = 800;          // simple/memory/debug → 4o-mini
    const MAX_TOKENS_MEDIUM    = 3000;         // S13-B : global/article/cluster → 4.1-mini (report JSON)
    const MAX_TOKENS_HEAVY     = 5000;         // S13-B : plan/cannibalization → 4.1-mini ou Haiku (stratégie complète)

    const OPT_OPENAI_API_KEY   = 'hts_coach_openai_api_key';

    /* ─── Intent → Provider routing (3 tiers) ─── */
    const HEAVY_INTENTS        = array( 'cannibalization' ); // → Haiku 4.5 (raisonnement complexe)
    const MEDIUM_INTENTS       = array( 'cluster', 'article', 'gsc_analysis', 'global', 'plan', 'data_query' );   // → gpt-4.1-mini (rapports + stratégies)
    const LIGHT_INTENTS        = array( 'memory', 'debug', 'simple' );// → gpt-4o-mini (suivi, questions rapides)

    /* ─── Deep Context (v3.0) ─── */
    const MAX_DEEP_CONTENT_WORDS = 3000;       // max mots contenu full par article
    const MAX_ARTICLES_DEEP      = 3;          // max articles full en contexte simultané
    const DEEP_CONTEXT_TTL       = 300;        // cache transient 5min par article

    /* ─── Memory System (v3.2 — Sprint S3) ─── */
    const SESSIONS_TABLE         = 'hts_coach_sessions';
    const MEMORY_TABLE           = 'hts_coach_memory';
    const MESSAGES_TABLE         = 'hts_coach_messages';    // v4.0 : messages en DB
    const ARTIFACTS_TABLE        = 'hts_coach_artifacts';   // v4.0 : charts persistés
    const SESSION_TIMEOUT        = 1800;       // 30min → nouvelle session auto
    const MAX_MEMORY_ITEMS       = 200;        // max facts mémorisés par site
    const MAX_SESSION_SUMMARIES  = 10;         // N derniers résumés injectés dans prompt
    const SITE_PROFILE_OPT       = 'hts_coach_site_profile';
    const MEMORY_VERSION_OPT     = 'hts_coach_memory_db_version';
    const MEMORY_DB_VERSION      = '2.2';     // v4.0 Sprint 4.8 : ajout table analytics

    /* ─── Debug + Upsell + Proactive (v3.3 — Sprint S4) ─── */
    const UPSELL_CONFIG_OPT      = 'hts_coach_upsell_config';
    const DIAGNOSTIC_CACHE_TTL   = 300;          // 5min cache pour diagnostic context
    const MAX_STARTUP_SUGGESTIONS = 4;           // max suggestions à l'ouverture

    /* ─── Agent Mode (v4.0 — Sprint 4.1) ─── */
    const AGENT_MODEL             = 'gpt-4.1-mini';               // Agent Mode : 4.1-mini suffit pour les plans JSON structurés
    const AGENT_MAX_TOKENS        = 4096;        // plans longs = plus de tokens
    const AGENT_MAX_STEPS         = 10;          // max étapes dans un plan

    /* ─── Sprint 4.8 : Analytics ─── */
    const ANALYTICS_TABLE          = 'hts_coach_analytics';

    /**
     * Sprint 4.7c : Max tokens adaptatif selon l'intent.
     * Les réponses courtes pour les questions simples, longues pour les plans.
     *
     * @since 4.0.0 Sprint 4.7c
     * @param string $intent
     * @return int
     */
    public static function get_max_tokens( $intent = 'global' ) {
        if ( in_array( $intent, array( 'simple', 'memory', 'debug' ), true ) ) {
            return self::MAX_TOKENS_LIGHT; // 800
        }
        // S13-B: Plans et stratégies → 5000 tokens pour rapports complets agence
        if ( in_array( $intent, array( 'plan', 'cannibalization' ), true ) ) {
            return self::MAX_TOKENS_HEAVY; // 5000
        }
        // GSC analysis → 4000 tokens (tableaux larges)
        if ( $intent === 'gsc_analysis' ) {
            return 4000;
        }
        // Action (agent mode) → 4096 (plans d'exécution multi-step)
        if ( $intent === 'action' ) {
            return self::AGENT_MAX_TOKENS; // 4096
        }
        // global, article, cluster, data_query → 3000 (report JSON + texte)
        return self::MAX_TOKENS_MEDIUM; // 3000
    }

    /**
     * Catalogue des actions exécutables par l'Agent Mode.
     * Chaque entrée mappe vers un module HTS existant.
     *
     * @since 4.0.0 Sprint 4.1
     */
    const AGENT_ACTION_CATALOG = array(
        'generate_article' => array(
            'label'       => 'Générer un article SEO',
            'module'      => 'HTS_Auto_Write',
            'method'      => 'generate_from_coach',
            'params'      => array( 'keyword', 'cluster_id', 'tone', 'word_count' ),
            'required'    => array( 'keyword' ),
            'description' => 'Genere un article complet optimise SEO+GEO a partir d\u0027un mot-cle.',
        ),
        'schedule_publication' => array(
            'label'       => 'Programmer la publication',
            'module'      => 'HTS_Article_Pipeline',
            'method'      => 'schedule_from_coach',
            'params'      => array( 'post_id', 'publish_date' ),
            'required'    => array( 'post_id' ),
            'description' => 'Programme la publication d\u0027un brouillon a une date donnee.',
        ),
        'content_refresh' => array(
            'label'       => 'Rafraîchir le contenu',
            'module'      => 'HTS_Content_Refresh',
            'method'      => 'refresh_from_coach',
            'params'      => array( 'post_id', 'sections', 'add_faq' ),
            'required'    => array( 'post_id' ),
            'description' => 'Rafraichit et optimise un article existant (contenu, structure, FAQ).',
        ),
        'add_internal_links' => array(
            'label'       => 'Ajouter des liens internes',
            'module'      => 'HTS_Internal_Linking',
            'method'      => 'suggest_from_coach',
            'params'      => array( 'post_id', 'max_links', 'target_ids' ),
            'required'    => array( 'post_id' ),
            'description' => 'Propose et insere des liens internes pertinents dans un article.',
        ),
        'optimize_meta_both' => array(
            'label'       => 'Optimiser titre + description',
            'module'      => 'HTS_Meta_Tags',
            'method'      => 'optimize_from_coach',
            'params'      => array( 'post_id', 'meta_title', 'meta_desc' ),
            'required'    => array( 'post_id' ),
            'description' => 'Genere le meta title ET la meta description. UNIQUEMENT quand le client demande "les metas" ou "titre et description" ensemble.',
        ),
        'optimize_meta_title' => array(
            'label'       => 'Optimiser le meta title',
            'module'      => 'HTS_Meta_Tags',
            'method'      => 'optimize_from_coach',
            'params'      => array( 'post_id' ),
            'required'    => array( 'post_id' ),
            'description' => 'Genere ou ameliore UNIQUEMENT le meta title. Quand le client dit "titre", "title", "titres".',
        ),
        'optimize_meta_desc' => array(
            'label'       => 'Optimiser la meta description',
            'module'      => 'HTS_Meta_Tags',
            'method'      => 'optimize_from_coach',
            'params'      => array( 'post_id' ),
            'required'    => array( 'post_id' ),
            'description' => 'Genere ou ameliore UNIQUEMENT la meta description. Quand le client dit "description(s)", "meta desc".',
        ),
        'add_faq' => array(
            'label'       => 'Ajouter une FAQ',
            'module'      => 'HTS_Content_Refresh',
            'method'      => 'add_faq_from_coach',
            'params'      => array( 'post_id', 'questions' ),
            'required'    => array( 'post_id' ),
            'description' => 'Ajoute une section FAQ optimisee GEO a un article.',
        ),
        'create_cocon_articles' => array(
            'label'       => 'Creer les articles d\u0027un cocon',
            'module'      => 'HTS_Cocon_Commander',
            'method'      => 'generate_satellites_from_coach',
            'params'      => array( 'cluster_id', 'count', 'keywords' ),
            'required'    => array( 'cluster_id' ),
            'description' => 'Genere les articles satellites manquants d\u0027un cluster/cocon.',
        ),
        'fix_orphan_links' => array(
            'label'       => 'Corriger les pages orphelines',
            'module'      => 'HTS_Internal_Linking',
            'method'      => 'fix_orphans_from_coach',
            'params'      => array( 'post_ids' ),
            'required'    => array( 'post_ids' ),
            'description' => 'Insere des liens internes vers les pages orphelines detectees.',
        ),
        'geo_optimize' => array(
            'label'       => 'Optimiser pour les moteurs IA',
            'module'      => 'HTS_Content_Refresh',
            'method'      => 'geo_optimize_from_coach',
            'params'      => array( 'post_id', 'add_schema', 'add_faq', 'restructure' ),
            'required'    => array( 'post_id' ),
            'description' => 'Optimise un article pour les moteurs IA (FAQ, schemas, structure).',
        ),
        'bulk_optimize_metas' => array(
            'label'       => 'Optimiser les metas en masse',
            'module'      => 'HTS_Meta_Tags',
            'method'      => 'bulk_optimize_from_coach',
            'params'      => array( 'post_ids', 'scope' ),
            'required'    => array( 'post_ids' ),
            'description' => 'Genere les meta title/desc pour plusieurs articles d\u0027un coup.',
        ),
    );

    /**
     * Modèle à utiliser (depuis agent settings 'coach').
     * Supporte Anthropic (Claude) et OpenAI (GPT-4o-mini).
     *
     * @since 2.4.3
     * @param string $intent  Intent détecté (pour auto-routing).
     * @return string
     */
    public static function get_model( $intent = '' ) {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'coach' );
            $model = $s['model'] ?? '';

            // Mode "auto" : routing 3 tiers selon l'intent
            if ( $model === 'auto' && $intent ) {
                $has_openai = ! empty( self::get_openai_api_key() );

                // Agent Mode — 4.1-mini : les plans JSON sont structurés, pas besoin de Sonnet
                if ( $intent === 'action' ) {
                    if ( $has_openai ) {
                        return self::AGENT_MODEL;
                    }
                    return 'claude-haiku-4-5-20251001'; // fallback Haiku si pas d'OpenAI
                }

                // Tier 3 — HEAVY : raisonnement complexe, stratégie, cannibalisation → Haiku 4.5
                if ( in_array( $intent, self::HEAVY_INTENTS, true ) ) {
                    return 'claude-haiku-4-5-20251001';
                }

                // Tier 2 — MEDIUM : analyse SEO, clusters, articles → gpt-4.1-mini
                if ( in_array( $intent, self::MEDIUM_INTENTS, true ) ) {
                    if ( $has_openai ) {
                        return self::OPENAI_MODEL_MID;
                    }
                    return 'claude-haiku-4-5-20251001';
                }

                // Tier 1 — LIGHT : debug, support, questions simples → gpt-4o-mini
                if ( $has_openai ) {
                    return self::OPENAI_MODEL;
                }
                return 'claude-haiku-4-5-20251001';
            }

            $allowed = array(
                'claude-haiku-4-5-20251001',
                'gpt-4o-mini',
                'gpt-4.1-mini',
                'auto',
            );
            if ( in_array( $model, $allowed, true ) && $model !== 'auto' ) {
                return $model;
            }
        }
        return self::MODEL;
    }

    /**
     * Détermine le provider (anthropic|openai) d'après le modèle.
     *
     * @since 2.5.0
     * @param string $model
     * @return string 'anthropic' ou 'openai'
     */
    public static function get_provider( $model ) {
        return ( strpos( $model, 'gpt-' ) === 0 ) ? 'openai' : 'anthropic';
    }

    /**
     * Récupère la clé API OpenAI.
     *
     * @since 2.5.0
     * @return string
     */
    public static function get_openai_api_key() {
        // Priorité : constante wp-config.php > option Coach > option Settings globale
        if ( defined( 'HTS_OPENAI_API_KEY' ) && HTS_OPENAI_API_KEY ) {
            return HTS_OPENAI_API_KEY;
        }
        $key = trim( (string) get_option( self::OPT_OPENAI_API_KEY, '' ) );
        if ( ! empty( $key ) ) {
            return $key;
        }
        // Fallback : clé sauvée depuis la page Settings globale
        return trim( (string) get_option( 'hts_openai_api_key', '' ) );
    }

    /**
     * Température pour les réponses du Coach (depuis agent settings 'coach').
     *
     * @since 2.4.3
     * @return float
     */
    public static function get_temperature() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'coach' );
            if ( isset( $s['temperature'] ) ) {
                return max( 0.0, min( 1.0, (float) $s['temperature'] ) );
            }
        }
        return 0.3;
    }

    /* ─── Freemium (v2.1) ─── */
    const FREEMIUM_LIMIT       = 5;              // questions gratuites/mois sans clé API
    const OPT_FREEMIUM_USAGE   = 'hts_coach_freemium_usage';
    const SAAS_COACH_ENDPOINT  = '/api/coach/ask';

    /* ─── Dispatch Coach → Workflow (v2.1) ─── */
    const COACH_ACTION_TYPES   = array(
        'add_meta_title',
        'add_meta_desc',
        'add_faq',
        'add_internal_links',
        // 'content_refresh', // NOT YET IMPLEMENTED — disabled S13-B
        'geo_optimize',
        'delete_page',
        'coach_suggestion',        // Sprint 4.9 bugfix: fallback type must be approuvable
        'schedule_publication',    // Sprint 5.0: from AGENT_ACTION_CATALOG
        'generate_article',        // Sprint 5.0: from AGENT_ACTION_CATALOG
        'optimize_meta_both',      // Sprint 5.0: from AGENT_ACTION_CATALOG
        'optimize_meta_title',     // Sprint 5.0: from AGENT_ACTION_CATALOG
        'optimize_meta_desc',      // Sprint 5.0: from AGENT_ACTION_CATALOG
        'create_cocon_articles',   // Sprint 5.0: from AGENT_ACTION_CATALOG
        'fix_orphan_links',        // Sprint 5.0: from AGENT_ACTION_CATALOG
        'bulk_optimize_metas',     // Sprint 5.0: from AGENT_ACTION_CATALOG
    );

    /* ═══════════════════════════════════════════════
     *  INIT
     * ═══════════════════════════════════════════════ */

    public function init() {
        // AJAX handlers — admin only (no nopriv!)
        add_action( 'wp_ajax_hts_coach_ask',     array( $this, 'ajax_ask' ) );
        add_action( 'wp_ajax_hts_coach_config',  array( $this, 'ajax_config' ) );
        add_action( 'wp_ajax_hts_coach_history', array( $this, 'ajax_history' ) );
        add_action( 'wp_ajax_hts_coach_clear',   array( $this, 'ajax_clear_history' ) );
        add_action( 'wp_ajax_hts_coach_context', array( $this, 'ajax_context' ) );
        add_action( 'wp_ajax_hts_coach_upload_gsc', array( $this, 'ajax_upload_gsc' ) );
        add_action( 'wp_ajax_hts_coach_delete_gsc', array( $this, 'ajax_delete_gsc' ) );

        // ── Memory System AJAX (v3.2) ──
        add_action( 'wp_ajax_hts_coach_sessions',       array( $this, 'ajax_sessions' ) );
        add_action( 'wp_ajax_hts_coach_session_messages', array( $this, 'ajax_session_messages' ) ); // v4.0
        add_action( 'wp_ajax_hts_coach_new_session',     array( $this, 'ajax_new_session' ) );       // v4.0
        add_action( 'wp_ajax_hts_coach_memory',          array( $this, 'ajax_memory' ) );
        add_action( 'wp_ajax_hts_coach_memory_delete',   array( $this, 'ajax_memory_delete' ) );
        add_action( 'wp_ajax_hts_coach_memory_update',   array( $this, 'ajax_memory_update' ) );    // v4.0 Sprint 3.1
        add_action( 'wp_ajax_hts_coach_memory_add',      array( $this, 'ajax_memory_add' ) );       // v4.0 Sprint 3.1
        add_action( 'wp_ajax_hts_coach_site_profile',    array( $this, 'ajax_site_profile' ) );

        // ── Debug + Startup + Upsell AJAX (v3.3 — Sprint S4) ──
        add_action( 'wp_ajax_hts_coach_startup',         array( $this, 'ajax_startup' ) );
        add_action( 'wp_ajax_hts_coach_diagnostic',      array( $this, 'ajax_diagnostic' ) );
        add_action( 'wp_ajax_hts_coach_upsell_config',   array( $this, 'ajax_upsell_config' ) );

        // ── v4.0 Sprint 1.3 : Artifacts gallery ──
        add_action( 'wp_ajax_hts_coach_artifacts',       array( $this, 'ajax_artifacts' ) );

        // ── v4.0 Sprint 2.2 : Streaming SSE ──
        add_action( 'wp_ajax_hts_coach_ask_stream',      array( $this, 'ajax_ask_stream' ) );

        // ── S13-B : Rapport hebdomadaire ──
        add_action( 'wp_ajax_hts_coach_weekly_report',   array( $this, 'ajax_weekly_report' ) );
        add_action( 'wp_ajax_hts_coach_generate_report', array( $this, 'ajax_generate_weekly_report' ) );
        add_action( 'hts_coach_weekly_report_cron',      array( __CLASS__, 'cron_generate_weekly_report' ) );
        if ( ! wp_next_scheduled( 'hts_coach_weekly_report_cron' ) ) {
            wp_schedule_event( strtotime( 'next monday 06:00' ), 'weekly', 'hts_coach_weekly_report_cron' );
        }

        // ── v2.6.3 : Rapport direct (0 token LLM) ──
        add_action( 'wp_ajax_hts_coach_generate_report_direct', array( $this, 'ajax_generate_report_direct' ) );
        add_action( 'wp_ajax_hts_coach_load_report',            array( $this, 'ajax_load_report' ) );

        // Table rapports — migration auto
        $db_ver = get_option( 'hts_coach_reports_db_ver', '0' );
        if ( $db_ver !== '1.0' ) {
            self::create_reports_table();
            update_option( 'hts_coach_reports_db_ver', '1.0' );
        }

        // ── v4.0 Sprint 4.2 : Agent Mode Preview + Execute ──
        add_action( 'wp_ajax_hts_coach_preview_step',    array( $this, 'ajax_preview_step' ) );
        add_action( 'wp_ajax_hts_coach_execute_step',    array( $this, 'ajax_execute_step' ) );
        add_action( 'wp_ajax_hts_coach_execute_plan',    array( $this, 'ajax_execute_plan' ) );
        add_action( 'wp_ajax_hts_coach_plan_init',      array( $this, 'ajax_coach_plan_init' ) );
        add_action( 'wp_ajax_hts_coach_plan_step',      array( $this, 'ajax_coach_plan_step' ) );

        // ── Ping / diagnostic rapide (v2.5.0) ──
        add_action( 'wp_ajax_hts_coach_ping',            array( $this, 'ajax_ping' ) );

        // ── Sprint 4.8 : Analytics dashboard + feedback ──
        add_action( 'wp_ajax_hts_coach_analytics',       array( $this, 'ajax_coach_analytics' ) );
        add_action( 'wp_ajax_hts_coach_feedback',        array( $this, 'ajax_coach_feedback' ) );
        // Sprint 5.4b: Apply SEO plan actions to Inbox
        add_action( 'wp_ajax_hts_coach_apply_seo_plan', array( $this, 'ajax_apply_seo_plan' ) );

        // Reset mensuel du compteur
        if ( ! wp_next_scheduled( 'hts_coach_monthly_reset' ) ) {
            wp_schedule_event( time(), 'monthly', 'hts_coach_monthly_reset' );
        }
        add_action( 'hts_coach_monthly_reset', array( $this, 'monthly_reset_usage' ) );

        // v4.0 : Purge hebdo des messages > 6 mois (garder les résumés de sessions)
        if ( ! wp_next_scheduled( 'hts_coach_weekly_purge' ) ) {
            wp_schedule_event( time(), 'weekly', 'hts_coach_weekly_purge' );
        }
        add_action( 'hts_coach_weekly_purge', array( $this, 'purge_old_messages' ) );

        // Ensure agent "coach" exists in Workflow Engine
        add_action( 'admin_init', array( $this, 'ensure_workflow_agent' ) );

        // ── Memory tables auto-create (v3.2) ──
        add_action( 'admin_init', array( $this, 'maybe_create_memory_tables' ) );

        // Dispatch Coach actions via Workflow Engine (v2.1)
        add_filter( 'hts_workflow_dispatch', array( $this, 'dispatch_coach_action' ), 10, 5 );
    }

    /**
     * Vérifie que l'agent "coach" est bien enregistré dans le Workflow Engine.
     * Auto-insert si absent (migration depuis versions antérieures).
     */
    public function ensure_workflow_agent() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return;

        $agents = HTS_Workflow_Engine::get_all_agents();
        if ( isset( $agents['coach'] ) ) return;

        // Insérer l'agent coach manuellement
        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_agents';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return;

        $wpdb->insert( $table, array(
            'agent'    => 'coach',
            'enabled'  => 1,
            'mode'     => 'review',
            'settings' => '{}',
        ), array( '%s', '%d', '%s', '%s' ) );
    }

    /* ═══════════════════════════════════════════════
     *  CONTEXT BUILDER — Le cœur du Coach
     * ═══════════════════════════════════════════════ */

    /**
     * Compile le contexte SEO du site pour l'envoyer à l'IA.
     * Ne contient JAMAIS de clé API ni de données sensibles.
     *
     * v3.0 : accepte $question pour détecter les articles mentionnés et charger le deep context.
     *
     * @param int    $post_id   Optionnel — article spécifique (depuis la page en cours).
     * @param string $question  Optionnel — question du client (pour détection auto).
     * @return array
     */
    public static function build_context( $post_id = 0, $question = '' ) {
        // ── Cache transient (5 min) pour le contexte global ──
        $cache_key = 'hts_coach_ctx';
        $context = get_transient( $cache_key );

        if ( $context === false ) {
            $context = array(
                'site_url'    => site_url(),
                'site_name'   => get_bloginfo( 'name' ),
                // S18 FIX: Use HTS_Language for accurate current language
                'language'    => ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
                    ? HTS_Language::get_current_lang()
                    : get_option( 'hts_language', get_locale() ),
                'total_posts' => (int) wp_count_posts( 'post' )->publish,
                'total_pages' => (int) wp_count_posts( 'page' )->publish,
            );

            // ── Score global moyen ──
            $context['global_score'] = self::get_average_score();

            // ── Top 5 pires articles ──
            $context['worst_pages'] = self::get_worst_pages( 5 );

            // ── Top 5 meilleurs articles ──
            $context['best_pages'] = self::get_best_pages( 5 );

            // ── GEO Score moyen ──
            $context['geo_score_avg'] = self::get_average_geo_score();

            // ── Actions pending dans l'Inbox ──
            $context['pending_actions'] = self::get_pending_count();
            $context['inbox_details']   = self::get_inbox_details();

            // ── Cocons stats enrichis (v3.0) ──
            $context['cocons'] = self::get_cocon_stats_full();

            // ── GSC top queries (si connecté) ──
            $context['gsc'] = self::get_gsc_summary();

            // ── Tableau croisé : pages avec scores + données GSC ──
            $context['pages_overview'] = self::get_pages_overview( 15 );

            // ── v4.0 Sprint 1.3 : Derniers artifacts (charts) pour enrichir le contexte ──
            $context['recent_artifacts'] = self::get_recent_artifacts_for_prompt( get_current_user_id(), 5 );

            // ── v4.0 Sprint 2.1 : Contexte enrichi — le Coach voit tout ──
            $context['drafts_ready']        = self::get_drafts_ready_to_publish();
            $context['gsc_delta']           = self::get_gsc_delta();
            $context['inbox_by_type']       = self::get_inbox_by_type();
            $context['health_alerts']       = self::get_health_alerts();
            $context['recent_publications'] = self::get_recent_publications( 10 );
            $context['all_cocons_summary']  = self::get_all_cocons_summary();
            $context['chantiers']           = self::get_chantiers_en_cours();

            // Sprint 5.4b : AI bot traffic summary for Coach analysis
            $context['ai_crawl'] = self::get_ai_crawl_summary();

            // S13-B : Feedback loop confidence + impact summary for AI recommendations
            if ( class_exists( 'HTS_Feedback_Loop' ) ) {
                $fl_confidence = HTS_Feedback_Loop::get_confidence();
                $fl_summary    = HTS_Feedback_Loop::compute_impact_summary( 30 );
                $fl_alerts     = HTS_Feedback_Loop::get_active_alerts();
                $compact_conf  = array();
                foreach ( $fl_confidence as $atype => $cs ) {
                    if ( ( $cs['total'] ?? 0 ) >= 3 ) {
                        $compact_conf[ $atype ] = array(
                            'success_rate' => $cs['confidence'] . '%',
                            'measured'     => $cs['total'],
                            'positive'     => $cs['positive'],
                            'negative'     => $cs['negative'],
                        );
                    }
                }
                if ( ! empty( $compact_conf ) || $fl_summary ) {
                    $context['feedback_loop'] = array(
                        'confidence'    => $compact_conf,
                        'impact_30d'    => $fl_summary ? array(
                            'actions_measured' => $fl_summary['total'],
                            'positive'         => $fl_summary['positive'],
                            'negative'         => $fl_summary['negative'],
                            'net_position'     => $fl_summary['net_position'],
                            'net_clicks'       => $fl_summary['net_clicks'],
                        ) : null,
                        'active_alerts' => is_array( $fl_alerts ) ? count( array_filter( $fl_alerts, function( $a ) { return empty( $a['dismissed'] ); } ) ) : 0,
                    );
                }
            }

            // S13-B : Inject weekly report summary for follow-up questions
            $weekly = get_option( self::WEEKLY_REPORT_OPT, null );
            if ( is_array( $weekly ) && ! empty( $weekly['title'] ) ) {
                $age_days = ( time() - strtotime( $weekly['generated_at'] ?? '2000-01-01' ) ) / DAY_IN_SECONDS;
                if ( $age_days < 8 ) {
                    // Compact version — only KPIs + insights (saves tokens)
                    $compact = array(
                        'title'    => $weekly['title'],
                        'kpis'     => $weekly['kpis'] ?? array(),
                        'insights' => $weekly['insights'] ?? array(),
                        'summary'  => $weekly['summary'] ?? '',
                    );
                    $context['weekly_report'] = $compact;
                }
            }

            set_transient( $cache_key, $context, 5 * MINUTE_IN_SECONDS );
        }

        // ── v3.1 : Détection d'intention ──
        $intent = ! empty( $question ) ? self::detect_intent( $question ) : 'global';
        $context['_intent'] = $intent;

        // ── v3.1 : Cluster context quand intent=cluster ──
        if ( $intent === 'cluster' && ! empty( $question ) ) {
            $cluster_name = self::detect_cluster_in_question( $question );
            if ( $cluster_name ) {
                $cluster_ctx = self::get_cluster_context( $cluster_name );
                if ( $cluster_ctx ) {
                    $context['cluster_detail'] = $cluster_ctx;
                }
            }
        }

        // ── v3.0 : Détection automatique des articles dans la question ──
        $deep_post_ids = array();
        if ( $post_id > 0 ) {
            $deep_post_ids[] = $post_id;
        }
        if ( ! empty( $question ) && in_array( $intent, array( 'article', 'global', 'plan', 'action' ), true ) ) {
            $detected = self::detect_articles_in_question( $question );
            $deep_post_ids = array_unique( array_merge( $deep_post_ids, $detected ) );
        }

        // ── v3.0 : Deep context pour les articles détectés ──
        if ( ! empty( $deep_post_ids ) ) {
            $context['deep_pages'] = array();
            foreach ( array_slice( $deep_post_ids, 0, self::MAX_ARTICLES_DEEP ) as $pid ) {
                $deep = self::get_page_deep_context( $pid );
                if ( $deep ) {
                    $context['deep_pages'][] = $deep;
                }
            }
        } elseif ( $post_id > 0 ) {
            // Fallback : contexte light si pas de deep context
            $context['current_page'] = self::get_page_context( $post_id );
        }

        // Sprint 5.4b: Enrichir pages_overview avec les top requêtes GSC par page
        // Uniquement pour gsc_analysis et plan (intents lourds qui ont besoin de mots-clés)
        if ( in_array( $intent, array( 'gsc_analysis', 'plan' ), true )
             && ! empty( $context['pages_overview'] )
             && class_exists( 'HTS_GSC_Connect' ) ) {
            try {
                $gsc_enrich = new \HTS_GSC_Connect();
                if ( $gsc_enrich->is_connected() && $gsc_enrich->has_data() ) {
                    // Top 5 pages by GSC clicks → enrich with their queries
                    $pages_with_gsc = array_filter( $context['pages_overview'], function( $p ) {
                        return ! empty( $p['gsc_clicks'] ) && $p['gsc_clicks'] > 0;
                    });
                    usort( $pages_with_gsc, function( $a, $b ) {
                        return ( $b['gsc_impressions'] ?? 0 ) - ( $a['gsc_impressions'] ?? 0 );
                    });
                    $top_page_ids = array_slice( array_column( $pages_with_gsc, 'id' ), 0, 10 );

                    foreach ( $context['pages_overview'] as &$page_ref ) {
                        if ( in_array( $page_ref['id'], $top_page_ids, true ) ) {
                            $pq = $gsc_enrich->get_post_queries( $page_ref['id'], 30, 8 );
                            if ( ! empty( $pq ) ) {
                                $page_ref['top_queries'] = array();
                                foreach ( $pq as $q ) {
                                    $q = is_object( $q ) ? (array) $q : $q;
                                    $page_ref['top_queries'][] = array(
                                        'q'   => $q['query'] ?? '',
                                        'c'   => (int) ( $q['clicks'] ?? 0 ),
                                        'i'   => (int) ( $q['impressions'] ?? 0 ),
                                        'p'   => round( (float) ( $q['avg_position'] ?? 0 ), 1 ),
                                        'ctr' => round( (float) ( $q['avg_ctr'] ?? 0 ), 2 ),
                                    );
                                }
                            }
                        }
                    }
                    unset( $page_ref );
                }
            } catch ( \Throwable $e ) {
                // Silently fail — queries are enrichment, not critical
            }
        }

        return $context;
    }

    /**
     * Score global moyen du site.
     */
    private static function get_average_score() {
        global $wpdb;

        $avg = $wpdb->get_var(
            "SELECT AVG( CAST( m.meta_value AS DECIMAL(5,1) ) )
             FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key = '_hts_global_score'
               AND p.post_status = 'publish'
               AND p.post_type IN ('post','page')"
        );

        return $avg ? round( (float) $avg, 1 ) : null;
    }

    /**
     * Top N pires articles (score le plus bas).
     */
    private static function get_worst_pages( $limit = 5 ) {
        global $wpdb;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title,
                    CAST( m.meta_value AS DECIMAL(5,1) ) as score
             FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key = '_hts_global_score'
               AND p.post_status = 'publish'
               AND p.post_type IN ('post','page')
               AND m.meta_value > 0
             ORDER BY score ASC
             LIMIT %d",
            $limit
        ) );

        $pages = array();
        foreach ( $rows as $row ) {
            $pages[] = array(
                'id'    => (int) $row->ID,
                'title' => $row->post_title,
                'score' => (float) $row->score,
                'url'   => get_permalink( $row->ID ),
            );
        }
        return $pages;
    }

    /**
     * Top N meilleurs articles (score le plus haut).
     */
    private static function get_best_pages( $limit = 5 ) {
        global $wpdb;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title,
                    CAST( m.meta_value AS DECIMAL(5,1) ) as score
             FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key = '_hts_global_score'
               AND p.post_status = 'publish'
               AND p.post_type IN ('post','page')
               AND m.meta_value > 0
             ORDER BY score DESC
             LIMIT %d",
            $limit
        ) );

        $pages = array();
        foreach ( $rows as $row ) {
            $pages[] = array(
                'id'    => (int) $row->ID,
                'title' => $row->post_title,
                'score' => (float) $row->score,
            );
        }
        return $pages;
    }

    /**
     * Vue croisée : articles avec scores SEO + GEO + données GSC.
     * C'est le tableau que le Coach utilise pour répondre aux questions transversales.
     */
    private static function get_pages_overview( $limit = 15 ) {
        global $wpdb;

        // Récupérer les articles publiés avec un score global
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_modified, p.post_content,
                    CAST( m.meta_value AS DECIMAL(5,1) ) as global_score
             FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key = '_hts_global_score'
               AND p.post_status = 'publish'
               AND p.post_type IN ('post','page')
               AND m.meta_value > 0
             ORDER BY CAST( m.meta_value AS DECIMAL(5,1) ) ASC
             LIMIT %d",
            $limit
        ) );

        $overview = array();
        foreach ( $rows as $row ) {
            $pid = (int) $row->ID;

            // Intro : 100 premiers mots du contenu (nettoyé)
            $plain = wp_strip_all_tags( $row->post_content );
            $words = preg_split( '/\s+/', $plain, 101 );
            $intro = implode( ' ', array_slice( $words, 0, 100 ) );
            if ( count( $words ) > 100 ) $intro .= '…';

            // Meta title + description
            $meta_title = get_post_meta( $pid, '_hts_meta_title', true );
            if ( ! $meta_title ) $meta_title = get_post_meta( $pid, '_yoast_wpseo_title', true );
            $meta_desc = get_post_meta( $pid, '_hts_meta_description', true );
            if ( ! $meta_desc ) $meta_desc = get_post_meta( $pid, '_yoast_wpseo_metadesc', true );

            $entry = array(
                'id'           => $pid,
                'title'        => $row->post_title,
                'meta_title'   => $meta_title ?: null,
                'meta_desc'    => $meta_desc ?: null,
                'intro'        => $intro,
                'modified'     => wp_date( 'Y-m-d', strtotime( $row->post_modified ) ),
                'global_score' => (float) $row->global_score,
                'geo_score'    => (float) get_post_meta( $pid, '_hts_geo_score', true ),
                'keyword'      => get_post_meta( $pid, '_hts_api_keyword', true )
                                  ?: get_post_meta( $pid, '_hts_focus_keyword', true ),
            );

            // Données GSC si disponibles (matchées par match_pages_to_posts)
            $gsc_clicks = get_post_meta( $pid, '_hts_gsc_clicks', true );
            if ( $gsc_clicks !== '' ) {
                $entry['gsc_clicks']      = (int) $gsc_clicks;
                $entry['gsc_impressions'] = (int) get_post_meta( $pid, '_hts_gsc_impressions', true );
                $entry['gsc_position']    = (float) get_post_meta( $pid, '_hts_gsc_position', true );
                $entry['gsc_ctr']         = (float) get_post_meta( $pid, '_hts_gsc_ctr', true );
            }

            // Liens internes
            $entry['links_in']  = (int) get_post_meta( $pid, '_hts_internal_links_in', true );
            $entry['links_out'] = (int) get_post_meta( $pid, '_hts_internal_links_out', true );

            $overview[] = $entry;
        }

        return $overview;
    }

    /**
     * GEO Score moyen.
     */
    private static function get_average_geo_score() {
        global $wpdb;

        $avg = $wpdb->get_var(
            "SELECT AVG( CAST( m.meta_value AS DECIMAL(5,1) ) )
             FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key = '_hts_geo_score'
               AND p.post_status = 'publish'
               AND p.post_type IN ('post','page')"
        );

        return $avg ? round( (float) $avg, 1 ) : null;
    }

    /**
     * Nombre d'actions pending dans l'Inbox.
     */
    private static function get_pending_count() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;
        $stats = HTS_Workflow_Engine::get_stats();
        return (int) ( $stats['pending'] ?? 0 );
    }

    /**
     * Détail des actions pending dans l'Inbox pour le contexte Coach.
     *
     * @since 2.3.0
     * @return array
     */
    private static function get_inbox_details() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) || ! HTS_Workflow_Engine::tables_exist() ) {
            return array();
        }

        $cards = HTS_Workflow_Engine::get_inbox_cards();
        $details = array();

        foreach ( $cards as $card ) {
            $items = array();
            foreach ( array_slice( $card['actions'], 0, 5 ) as $action ) {
                $action = (array) $action;
                $data = is_string( $action['data'] ?? '' ) ? json_decode( $action['data'], true ) : ( $action['data'] ?? array() );
                $items[] = array(
                    'id'        => (int) ( $action['id'] ?? 0 ),
                    'post_id'   => (int) ( $action['post_id'] ?? 0 ),
                    'title'     => $action['post_title'] ?? '',
                    'reason'    => $data['reason'] ?? ( $action['reason'] ?? '' ),
                    'suggestion'=> $data['suggestion'] ?? ( $data['top_fix'] ?? '' ),
                );
            }
            $details[] = array(
                'agent'    => $card['agent_label'],
                'type'     => $card['type_label'],
                'priority' => $card['priority_max'],
                'count'    => $card['count'],
                'items'    => $items,
            );
        }

        return $details;
    }

    /**
     * Stats enrichies des cocons sémantiques (v3.0).
     * Expose les clusters avec noms, piliers, densité, orphelins.
     */
    private static function get_cocon_stats_full() {
        global $wpdb;

        $table = $wpdb->prefix . 'hts_cocons';
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( ! $exists ) return array( 'count' => 0, 'clusters' => array() );

        // Charger le dernier résultat d'analyse cocon
        $last = get_option( 'hts_cocon_last_result', array() );
        if ( empty( $last ) || ! isset( $last['clusters'] ) ) {
            $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
            return array( 'count' => $count, 'clusters' => array() );
        }

        $clusters_summary = array();
        foreach ( $last['clusters'] as $cl ) {
            $name = $cl['name'] ?? 'Sans nom';
            if ( in_array( $name, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;

            $clusters_summary[] = array(
                'name'       => $name,
                'page_count' => $cl['page_count'] ?? 0,
                'pillar_id'  => $cl['pillar_id'] ?? 0,
                'density'    => $cl['density'] ?? 0,
                'orphans'    => $cl['orphans'] ?? 0,
                'theme'      => $cl['theme'] ?? '',
            );
        }

        return array(
            'count'    => count( $clusters_summary ),
            'clusters' => $clusters_summary,
            'orphans'  => $last['metrics']['orphan_count'] ?? 0,
            'coverage' => $last['metrics']['cluster_coverage'] ?? 0,
        );
    }

    /**
     * Résumé GSC : top 5 requêtes, clics totaux.
     */
    private static function get_gsc_summary() {
        // 1. Vraie connexion GSC (API live via proxy ou direct)
        if ( class_exists( 'HTS_GSC_Connect' ) ) {
            $gsc = new HTS_GSC_Connect();
            if ( $gsc->is_connected() ) {
                $data = $gsc->get_site_data( 30 );
                if ( ! empty( $data ) && ! empty( $data['clicks'] ) ) {
                    // get_site_data() retourne un array structuré — ne PAS passer à format_gsc_rows()
                    $result = array(
                        'connected'    => true,
                        'source'       => 'api',
                        'data'         => true,
                        'total_clicks' => (int) ( $data['clicks'] ?? 0 ),
                        'impressions'  => (int) ( $data['impressions'] ?? 0 ),
                        'avg_position' => (float) ( $data['avg_position'] ?? 0 ),
                        'avg_ctr'      => (float) ( $data['avg_ctr'] ?? 0 ),
                        'pages_count'  => (int) ( $data['pages'] ?? 0 ),
                        'clicks_trend' => $data['clicks_trend'] ?? 0,
                        'top_pages'    => $data['top_pages'] ?? array(),
                        'daily'        => $data['daily'] ?? array(),
                        'total_rows'   => count( $data['top_pages'] ?? array() ),
                        'top_queries'  => array(),
                    );

                    // Enrichir avec les top queries depuis la table queries
                    $queries_data = $gsc->get_queries_data( 30 );
                    if ( ! empty( $queries_data ) ) {
                        $result['top_queries'] = array_slice( $queries_data, 0, 10 );
                    }

                    return $result;
                }
            }
        }

        // 2. Données importées (CSV ou autre) — même format que le Full
        $queries = get_option( 'hts_gsc_queries', array() );
        $pages   = get_option( 'hts_gsc_pages', array() );

        $result = array( 'connected' => false );

        if ( ! empty( $queries ) ) {
            $result = self::format_gsc_rows( $queries, 'csv' );
        }

        if ( ! empty( $pages ) ) {
            $result['top_pages'] = array_slice( $pages, 0, 10 );
            $result['connected'] = true;
            $result['source']    = $result['source'] ?? 'csv';
            $result['data']      = true;
        }

        return $result;
    }

    /**
     * Formate des rows GSC (API ou CSV) pour le contexte Coach.
     */
    private static function format_gsc_rows( $data, $source = 'api' ) {
        $rows = array();
        foreach ( $data as $row ) {
            $rows[] = is_object( $row ) ? (array) $row : $row;
        }

        usort( $rows, function( $a, $b ) {
            return ( $b['clicks'] ?? 0 ) - ( $a['clicks'] ?? 0 );
        } );

        $top = array();
        foreach ( array_slice( $rows, 0, 10 ) as $row ) {
            $top[] = array(
                'query'       => $row['query'] ?? '',
                'clicks'      => (int) ( $row['clicks'] ?? 0 ),
                'impressions' => (int) ( $row['impressions'] ?? 0 ),
                'position'    => round( (float) ( $row['position'] ?? 0 ), 1 ),
            );
        }

        $total_clicks = 0;
        foreach ( $rows as $r ) {
            $total_clicks += (int) ( $r['clicks'] ?? 0 );
        }

        return array(
            'connected'    => true,
            'source'       => $source,
            'data'         => true,
            'total_clicks' => $total_clicks,
            'total_rows'   => count( $rows ),
            'top_queries'  => $top,
        );
    }

    /* ═══════════════════════════════════════════════
     *  SPRINT 2.1 — CONTEXTE ENRICHI
     *  Le Coach voit tout : brouillons, delta GSC, inbox, health, publications
     * ═══════════════════════════════════════════════ */

    /**
     * Sprint 2.1 : Articles prêts à publier (brouillons HTS / cocon).
     *
     * @return array
     */
    private static function get_drafts_ready_to_publish() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT p.ID, p.post_title, p.post_date,
                    pm1.meta_value AS source,
                    pm2.meta_value AS keyword
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_hts_source'
             LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_hts_api_keyword'
             WHERE p.post_status = 'draft'
               AND (EXISTS (SELECT 1 FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_hts_auto_write')
                    OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_hts_api_generated')
                    OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_hts_source'))
             ORDER BY p.post_date DESC LIMIT 20",
            ARRAY_A
        );
        return is_array( $rows ) ? $rows : array();
    }

    /**
     * Sprint 2.1 : Delta GSC — évolution des métriques sur 7j et 30j.
     * Compare les données GSC actuelles avec les snapshots précédents.
     *
     * @return array
     */
    private static function get_gsc_delta() {
        // Snapshots stockés par le cron GSC quotidien
        $snapshots = get_option( 'hts_gsc_snapshots', array() );
        if ( empty( $snapshots ) || ! is_array( $snapshots ) ) {
            return array( 'available' => false );
        }

        $now = time();
        $current = end( $snapshots );
        $snap_7d = null;
        $snap_30d = null;

        // Trouver le snapshot le plus proche de -7j et -30j
        foreach ( $snapshots as $snap ) {
            $ts = strtotime( $snap['date'] ?? '' );
            if ( ! $ts ) continue;
            $diff = $now - $ts;
            if ( $diff >= 6 * DAY_IN_SECONDS && $diff <= 9 * DAY_IN_SECONDS && ! $snap_7d ) {
                $snap_7d = $snap;
            }
            if ( $diff >= 28 * DAY_IN_SECONDS && $diff <= 35 * DAY_IN_SECONDS && ! $snap_30d ) {
                $snap_30d = $snap;
            }
        }

        $delta = array( 'available' => true );

        if ( $snap_7d ) {
            $delta['7d'] = array(
                'clicks'      => self::calc_delta( $current['clicks'] ?? 0, $snap_7d['clicks'] ?? 0 ),
                'impressions' => self::calc_delta( $current['impressions'] ?? 0, $snap_7d['impressions'] ?? 0 ),
                'avg_position' => round( ( $current['avg_position'] ?? 0 ) - ( $snap_7d['avg_position'] ?? 0 ), 1 ),
            );
        }

        if ( $snap_30d ) {
            $delta['30d'] = array(
                'clicks'      => self::calc_delta( $current['clicks'] ?? 0, $snap_30d['clicks'] ?? 0 ),
                'impressions' => self::calc_delta( $current['impressions'] ?? 0, $snap_30d['impressions'] ?? 0 ),
                'avg_position' => round( ( $current['avg_position'] ?? 0 ) - ( $snap_30d['avg_position'] ?? 0 ), 1 ),
            );
        }

        return $delta;
    }

    /**
     * GSC Time Series — returns last 30 snapshots for Chart.js line chart.
     */
    private static function get_gsc_timeseries() {
        $snapshots = get_option( 'hts_gsc_snapshots', array() );
        if ( empty( $snapshots ) || ! is_array( $snapshots ) || count( $snapshots ) < 3 ) {
            return null;
        }

        // Sort by date, take last 30
        usort( $snapshots, function( $a, $b ) {
            return strtotime( $a['date'] ?? '' ) - strtotime( $b['date'] ?? '' );
        });
        $snapshots = array_slice( $snapshots, -30 );

        $labels = array();
        $clicks = array();
        $impressions = array();

        foreach ( $snapshots as $s ) {
            $ts = strtotime( $s['date'] ?? '' );
            if ( ! $ts ) continue;
            $labels[] = wp_date( 'j M', $ts );
            $clicks[] = (int) ( $s['clicks'] ?? 0 );
            $impressions[] = (int) ( $s['impressions'] ?? 0 );
        }

        if ( count( $labels ) < 3 ) return null;

        return array(
            'labels'      => $labels,
            'clicks'      => $clicks,
            'impressions' => $impressions,
        );
    }

    /**
     * Calcule un delta en pourcentage.
     */
    private static function calc_delta( $current, $previous ) {
        if ( $previous <= 0 ) return $current > 0 ? '+100%' : '0%';
        $pct = round( ( ( $current - $previous ) / $previous ) * 100, 1 );
        return ( $pct >= 0 ? '+' : '' ) . $pct . '%';
    }

    /**
     * Sprint 2.1 : Actions Inbox groupées par type.
     *
     * @return array
     */
    private static function get_inbox_by_type() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) || ! HTS_Workflow_Engine::tables_exist() ) {
            return array();
        }

        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';
        $rows = $wpdb->get_results(
            "SELECT type, COUNT(*) AS cnt, MAX(priority) AS max_priority
             FROM {$table}
             WHERE status = 'pending'
             GROUP BY type
             ORDER BY cnt DESC",
            ARRAY_A
        );

        $result = array();
        foreach ( ( $rows ?: array() ) as $row ) {
            $result[] = array(
                'type'     => $row['type'],
                'count'    => (int) $row['cnt'],
                'priority' => $row['max_priority'] ?? 'medium',
            );
        }

        return $result;
    }

    /**
     * Sprint 2.1 : Alertes santé du plugin.
     *
     * @return array
     */
    private static function get_health_alerts() {
        $health = get_option( 'hts_health_results', array() );
        if ( empty( $health ) ) return array();

        $results = $health['results'] ?? $health;
        $alerts = array();

        foreach ( $results as $key => $test ) {
            $test = (array) $test;
            $status = $test['status'] ?? '';
            if ( in_array( $status, array( 'fail', 'warn' ), true ) ) {
                $alerts[] = array(
                    'test'     => $test['name'] ?? $key,
                    'status'   => $status,
                    'detail'   => mb_substr( $test['detail'] ?? '', 0, 200 ),
                    'fix_hint' => $test['fix'] ?? '',
                );
            }
        }

        return array_slice( $alerts, 0, 10 );
    }

    /**
     * Sprint 2.1 : Publications récentes (10 dernières).
     *
     * @param int $limit
     * @return array
     */
    private static function get_recent_publications( $limit = 10 ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_date, p.post_type,
                    pm.meta_value AS global_score
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_global_score'
             WHERE p.post_status = 'publish'
               AND p.post_type IN ('post','page')
             ORDER BY p.post_date DESC
             LIMIT %d",
            absint( $limit )
        ), ARRAY_A );

        $result = array();
        foreach ( ( $rows ?: array() ) as $row ) {
            $result[] = array(
                'id'    => (int) $row['ID'],
                'title' => $row['post_title'],
                'date'  => $row['post_date'],
                'score' => $row['global_score'] ? round( (float) $row['global_score'], 1 ) : null,
            );
        }
        return $result;
    }

    /**
     * Sprint 2.1 : Résumé de tous les cocons avec densité complète.
     *
     * @return array
     */
    private static function get_all_cocons_summary() {
        $last = get_option( 'hts_cocon_last_result', array() );
        if ( empty( $last ) || empty( $last['clusters'] ) ) return array();

        $summary = array();
        foreach ( $last['clusters'] as $cl ) {
            $name = $cl['name'] ?? 'Sans nom';
            if ( in_array( $name, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;

            $summary[] = array(
                'name'        => $name,
                'pages'       => (int) ( $cl['page_count'] ?? 0 ),
                'density'     => (int) ( $cl['density'] ?? 0 ),
                'orphans'     => (int) ( $cl['orphans'] ?? 0 ),
                'avg_score'   => round( (float) ( $cl['avg_score'] ?? 0 ), 1 ),
                'pillar'      => $cl['pillar_title'] ?? '',
                'missing_links' => (int) ( $cl['missing_links_count'] ?? 0 ),
            );
        }

        return $summary;
    }

    /**
     * Sprint 2.1 : Chantiers en cours — pending par type + récemment exécutés + clusters actifs.
     *
     * @return array
     */
    private static function get_chantiers_en_cours() {
        $chantiers = array();

        // Actions récemment exécutées (7 derniers jours)
        if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
            global $wpdb;
            $table = $wpdb->prefix . 'hts_workflow_actions';
            $rows = $wpdb->get_results(
                "SELECT type, COUNT(*) AS cnt
                 FROM {$table}
                 WHERE status IN ('done','approved')
                   AND resolved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                 GROUP BY type
                 ORDER BY cnt DESC LIMIT 10",
                ARRAY_A
            );
            $chantiers['recently_executed'] = array();
            foreach ( ( $rows ?: array() ) as $row ) {
                $chantiers['recently_executed'][] = array(
                    'type'  => $row['type'],
                    'count' => (int) $row['cnt'],
                );
            }
        }

        // Clusters actifs (avec des actions en attente)
        $cocons = self::get_cocon_stats_full();
        $active = array();
        foreach ( ( $cocons['clusters'] ?? array() ) as $cl ) {
            if ( ( $cl['orphans'] ?? 0 ) > 0 || ( $cl['density'] ?? 100 ) < 50 ) {
                $active[] = $cl['name'] ?? '';
            }
        }
        $chantiers['clusters_needing_work'] = array_slice( $active, 0, 5 );

        return $chantiers;
    }

    /**
     * Sprint 5.4b : Résumé trafic IA (bots) pour le Coach.
     * Léger en tokens : totaux + top 5 pages visitées par les IA.
     *
     * @return array|null
     */
    private static function get_ai_crawl_summary() {
        try {
            if ( ! class_exists( 'HTS_Impact_Tracker' ) ) {
                return null;
            }

            global $wpdb;

            // Vérifier que la table visits existe
            $vt = $wpdb->prefix . 'hts_visits';
            $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $vt ) );
            if ( ! $table_exists ) {
                return null;
            }

            // Vérifier que la colonne is_ai existe
            $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$vt}", 0 );
            if ( ! in_array( 'is_ai', $columns, true ) ) {
                return null;
            }

            $cutoff_30 = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );

            // Total AI visits (30j)
            $ai_total = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$vt} WHERE is_ai = 1 AND visited_at > %s",
                $cutoff_30
            ) );

            if ( $ai_total === 0 ) {
                return array( 'total_30d' => 0 );
            }

            // AI source breakdown
            $has_ai_source = in_array( 'ai_source', $columns, true );
            $src_list = array();
            if ( $has_ai_source ) {
                $sources = $wpdb->get_results( $wpdb->prepare(
                    "SELECT ai_source, COUNT(*) AS cnt FROM {$vt}
                     WHERE is_ai = 1 AND visited_at > %s
                     GROUP BY ai_source ORDER BY cnt DESC LIMIT 5",
                    $cutoff_30
                ) );
                foreach ( ( $sources ?: array() ) as $s ) {
                    $src_list[] = ( $s->ai_source ?: 'unknown' ) . ': ' . (int) $s->cnt;
                }
            }

            // Top 5 pages most visited by AI
            $top_pages = $wpdb->get_results( $wpdb->prepare(
                "SELECT post_id, COUNT(*) AS ai_visits FROM {$vt}
                 WHERE is_ai = 1 AND visited_at > %s
                 GROUP BY post_id ORDER BY ai_visits DESC LIMIT 5",
                $cutoff_30
            ) );
            $top_list = array();
            foreach ( ( $top_pages ?: array() ) as $r ) {
                $top_list[] = array(
                    'post_id'   => (int) $r->post_id,
                    'title'     => get_the_title( $r->post_id ),
                    'ai_visits' => (int) $r->ai_visits,
                );
            }

            // Human vs AI ratio
            $total_visits = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$vt} WHERE visited_at > %s",
                $cutoff_30
            ) );

            return array(
                'total_30d'   => $ai_total,
                'total_human' => $total_visits - $ai_total,
                'ratio_pct'   => $total_visits > 0 ? round( $ai_total / $total_visits * 100, 1 ) : 0,
                'sources'     => implode( ', ', $src_list ),
                'top_pages'   => $top_list,
            );
        } catch ( \Exception $e ) {
            return null;
        } catch ( \Error $e ) {
            return null;
        }
    }

    /**
     * Sprint 2.1 : Smart Debug Tree — diagnostic structuré AVANT le LLM.
     * Le LLM reformule, zéro hallucination.
     *
     * @return array
     */
    public static function run_diagnostic_tree() {
        $issues = array();
        $ok     = array();

        // 1. Clés API
        $has_anthropic = ! empty( self::get_api_key() );
        $has_openai    = ! empty( self::get_openai_api_key() );
        if ( ! $has_anthropic && ! $has_openai ) {
            $issues[] = array(
                'severity' => 'critical',
                'problem'  => 'Aucune clé API configurée',
                'fix'      => 'Allez dans Hack The SEO > Réglages > API & Connexion et renseignez votre clé Anthropic ou OpenAI.',
                'link'     => admin_url( 'admin.php?page=hts-light-api' ),
            );
        } else {
            $ok[] = 'Clés API configurées';
        }

        // 2. Crons
        $expected_crons = array(
            'hts_embed_batch'       => 'Calcul des embeddings',
            'hts_health_cron'       => 'Vérification santé',
            'hts_content_refresh_cron' => 'Rafraîchissement contenu',
            'hts_auto_write_cron'   => 'Publication automatique',
            'hts_gsc_daily_import'  => 'Import GSC quotidien',
        );
        $missing_crons = array();
        foreach ( $expected_crons as $hook => $label ) {
            if ( ! wp_next_scheduled( $hook ) ) {
                $missing_crons[] = $label;
            }
        }
        if ( ! empty( $missing_crons ) ) {
            $issues[] = array(
                'severity' => 'warning',
                'problem'  => count( $missing_crons ) . ' tâche(s) planifiée(s) manquante(s) : ' . implode( ', ', $missing_crons ),
                'fix'      => 'Allez dans Hack The SEO > Réglages > Maintenance et cliquez "Relancer les crons".',
            );
        } else {
            $ok[] = 'Toutes les tâches planifiées sont actives';
        }

        // 3. Agents activés
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $agents = HTS_Workflow_Engine::get_all_agents();
            $disabled = array();
            foreach ( $agents as $name => $a ) {
                if ( empty( $a['enabled'] ) ) $disabled[] = $name;
            }
            if ( count( $disabled ) > 2 ) {
                $issues[] = array(
                    'severity' => 'info',
                    'problem'  => count( $disabled ) . ' agent(s) désactivé(s) : ' . implode( ', ', array_slice( $disabled, 0, 4 ) ),
                    'fix'      => 'Activez les agents utiles dans Réglages > Agents pour profiter de l\'automatisation complète.',
                );
            } else {
                $ok[] = 'Agents actifs';
            }
        }

        // 4. GSC connexion
        $gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
        $gsc_csv = ! empty( get_option( 'hts_gsc_queries', array() ) ) || ! empty( get_option( 'hts_gsc_pages', array() ) );
        if ( ! $gsc_connected && ! $gsc_csv ) {
            $issues[] = array(
                'severity' => 'warning',
                'problem'  => 'Aucune donnée Search Console disponible',
                'fix'      => 'Connectez Search Console dans Réglages > API & Connexion, ou importez un CSV dans le Coach (sidebar).',
            );
        } else {
            $ok[] = 'Données Search Console disponibles (' . ( $gsc_connected ? 'API' : 'CSV' ) . ')';
        }

        // 5. Embeddings
        global $wpdb;
        $embed_table = $wpdb->prefix . 'hts_embeddings';
        $embed_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $embed_table ) ) === $embed_table;
        $embed_count = 0;
        if ( $embed_exists ) {
            $embed_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$embed_table} WHERE vector IS NOT NULL" );
            $total_posts = (int) wp_count_posts( 'post' )->publish + (int) wp_count_posts( 'page' )->publish;
            $coverage = $total_posts > 0 ? round( ( $embed_count / $total_posts ) * 100 ) : 0;
            if ( $coverage < 50 ) {
                $issues[] = array(
                    'severity' => 'info',
                    'problem'  => 'Seulement ' . $coverage . '% de vos pages ont un embedding (' . $embed_count . '/' . $total_posts . ')',
                    'fix'      => 'Les embeddings permettent au Coach de trouver des pages similaires. Lancez le calcul dans Réglages > Maintenance.',
                );
            } else {
                $ok[] = 'Embeddings : ' . $coverage . '% de couverture';
            }
        }

        // 6. Erreurs récentes
        $recent_errors = array();
        if ( function_exists( 'hts_get_logs' ) ) {
            $logs = hts_get_logs( 'error', 5 );
            foreach ( ( $logs ?: array() ) as $log ) {
                $recent_errors[] = array(
                    'date'    => $log['date'] ?? '',
                    'message' => mb_substr( $log['message'] ?? '', 0, 200 ),
                    'source'  => $log['source'] ?? '',
                );
            }
        }

        // 7. Health Check
        $health = get_option( 'hts_health_results', array() );
        $health_fails = array();
        $results = $health['results'] ?? $health;
        foreach ( $results as $test ) {
            $test = (array) $test;
            if ( ( $test['status'] ?? '' ) === 'fail' ) {
                $health_fails[] = ( $test['name'] ?? 'Test' ) . ' : ' . mb_substr( $test['detail'] ?? '', 0, 100 );
            }
        }
        if ( ! empty( $health_fails ) ) {
            $issues[] = array(
                'severity' => 'warning',
                'problem'  => count( $health_fails ) . ' test(s) de santé en échec : ' . implode( '; ', array_slice( $health_fails, 0, 3 ) ),
                'fix'      => 'Consultez l\'onglet Santé du plugin pour les détails et solutions.',
            );
        }

        return array(
            'issues'        => $issues,
            'ok'            => $ok,
            'recent_errors' => $recent_errors,
            'gsc_connected' => $gsc_connected || $gsc_csv,
            'embeddings'    => $embed_count,
            'summary'       => empty( $issues )
                ? 'Tout est opérationnel. Aucun problème détecté.'
                : '' . count( $issues ) . ' point(s) à vérifier.',
        );
    }

    /* ═══════════════════════════════════════════════
     *  GSC CSV UPLOAD (temporaire — sera remplacé par connexion API)
     *  Stocke dans hts_gsc_queries / hts_gsc_pages (même format que le Full)
     * ═══════════════════════════════════════════════ */

    /**
     * Parse un CSV Search Console (export Google standard).
     * Auto-détecte si c'est un fichier Requêtes ou Pages.
     *
     * @return array { type: 'queries'|'pages', data: array }
     */
    public static function parse_gsc_csv( $file_path ) {
        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            return new \WP_Error( 'file', 'Fichier introuvable.' );
        }

        $handle = fopen( $file_path, 'r' );
        if ( ! $handle ) {
            return new \WP_Error( 'file', 'Impossible de lire le fichier.' );
        }

        // Auto-detect delimiter
        $first_line = fgets( $handle );
        rewind( $handle );
        if ( ! $first_line ) {
            fclose( $handle );
            return new \WP_Error( 'format', 'Fichier CSV vide.' );
        }
        $semicolons = substr_count( $first_line, ';' );
        $commas     = substr_count( $first_line, ',' );
        $tabs       = substr_count( $first_line, "\t" );
        $delimiter  = ',';
        if ( $semicolons > $commas && $semicolons > $tabs ) $delimiter = ';';
        if ( $tabs > $semicolons && $tabs > $commas ) $delimiter = "\t";

        // Header
        $header = fgetcsv( $handle, 0, $delimiter );
        if ( ! $header ) {
            fclose( $handle );
            return new \WP_Error( 'format', 'En-têtes CSV manquants.' );
        }

        // Normaliser les noms de colonnes (même mapping que le Full)
        $col_names = array(
            'page' => 'page', 'pages' => 'page', 'url' => 'page',
            'pages les plus populaires' => 'page', 'top pages' => 'page', 'landing page' => 'page',
            'clics' => 'clicks', 'clicks' => 'clicks', 'nb clics' => 'clicks',
            'impressions' => 'impressions',
            'ctr' => 'ctr', 'taux de clics' => 'ctr',
            'position' => 'position', 'position moyenne' => 'position', 'average position' => 'position',
            'requête' => 'query', 'requete' => 'query', 'query' => 'query',
            'top queries' => 'query', 'requêtes' => 'query',
            'requêtes les plus fréquentes' => 'query', 'search query' => 'query',
        );

        $header = array_map( function( $h ) use ( $col_names ) {
            $h = mb_strtolower( trim( $h ) );
            $h = preg_replace( '/^\xEF\xBB\xBF/', '', $h ); // BOM
            return isset( $col_names[ $h ] ) ? $col_names[ $h ] : $h;
        }, $header );

        // Détecter le type : queries ou pages
        $is_queries = in_array( 'query', $header, true );
        $is_pages   = in_array( 'page', $header, true );

        if ( ! $is_queries && ! $is_pages ) {
            fclose( $handle );
            return new \WP_Error( 'format', 'Colonnes non reconnues. Utilisez un export Requêtes ou Pages de Search Console.' );
        }

        $rows = array();
        $max  = 500;
        while ( ( $line = fgetcsv( $handle, 0, $delimiter ) ) !== false && count( $rows ) < $max ) {
            if ( count( $line ) !== count( $header ) ) continue;
            $assoc = array_combine( $header, $line );
            if ( $assoc === false ) continue;

            $clicks      = (int) str_replace( array( ',', ' ' ), '', $assoc['clicks'] ?? '0' );
            $impressions = (int) str_replace( array( ',', ' ' ), '', $assoc['impressions'] ?? '0' );
            $position    = round( (float) str_replace( ',', '.', $assoc['position'] ?? '0' ), 1 );
            $ctr_raw     = str_replace( array( '%', ' ' ), '', $assoc['ctr'] ?? '0' );
            $ctr         = round( (float) str_replace( ',', '.', $ctr_raw ), 2 );

            if ( $is_queries ) {
                $q = trim( $assoc['query'] ?? '' );
                if ( empty( $q ) ) continue;
                $rows[] = array(
                    'query'       => sanitize_text_field( $q ),
                    'clicks'      => $clicks,
                    'impressions' => $impressions,
                    'ctr'         => $ctr,
                    'position'    => $position,
                );
            } else {
                $url = trim( $assoc['page'] ?? '' );
                if ( empty( $url ) ) continue;
                $rows[] = array(
                    'url'         => esc_url_raw( $url ),
                    'clicks'      => $clicks,
                    'impressions' => $impressions,
                    'ctr'         => $ctr,
                    'position'    => $position,
                );
            }
        }

        fclose( $handle );

        if ( empty( $rows ) ) {
            return new \WP_Error( 'empty', 'Aucune donnée trouvée dans le CSV.' );
        }

        // Trier par clics desc
        usort( $rows, function( $a, $b ) { return ( $b['clicks'] ?? 0 ) - ( $a['clicks'] ?? 0 ); } );

        return array(
            'type' => $is_queries ? 'queries' : 'pages',
            'data' => $rows,
        );
    }

    /**
     * Associe les URLs GSC importées aux posts WordPress (post_meta).
     */
    private static function match_pages_to_posts( $pages ) {
        foreach ( $pages as $page ) {
            $url = $page['url'] ?? '';
            if ( empty( $url ) ) continue;

            $post_id = hts_url_to_postid( $url );

            // Fallback par slug
            if ( ! $post_id ) {
                $path = wp_parse_url( $url, PHP_URL_PATH );
                $slug = basename( rtrim( $path, '/' ) );
                if ( ! empty( $slug ) ) {
                    $found = get_page_by_path( $slug, OBJECT, array( 'post', 'page' ) );
                    if ( $found ) $post_id = $found->ID;
                }
            }

            if ( $post_id ) {
                update_post_meta( $post_id, '_hts_gsc_clicks', $page['clicks'] );
                update_post_meta( $post_id, '_hts_gsc_impressions', $page['impressions'] );
                update_post_meta( $post_id, '_hts_gsc_position', $page['position'] );
                update_post_meta( $post_id, '_hts_gsc_ctr', $page['ctr'] ?? 0 );
            }
        }
    }

    /**
     * Contexte d'un article spécifique.
     */
    private static function get_page_context( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return null;

        $ctx = array(
            'id'           => $post_id,
            'title'        => $post->post_title,
            'url'          => get_permalink( $post_id ),
            'type'         => $post->post_type,
            'status'       => $post->post_status,
            'word_count'   => hts_word_count( wp_strip_all_tags( $post->post_content ) ),
            'global_score' => (float) get_post_meta( $post_id, '_hts_global_score', true ),
            'geo_score'    => (float) get_post_meta( $post_id, '_hts_geo_score', true ),
            'meta_score'   => (float) get_post_meta( $post_id, '_hts_meta_score', true ),
            'keyword'      => get_post_meta( $post_id, '_hts_api_keyword', true )
                              ?: get_post_meta( $post_id, '_hts_focus_keyword', true ),
        );

        // Détails GEO score si dispo
        $geo_detail = get_post_meta( $post_id, '_hts_geo_criteria', true );
        if ( is_array( $geo_detail ) ) {
            $ctx['geo_detail'] = $geo_detail;
        }

        // Liens internes
        $links_in  = (int) get_post_meta( $post_id, '_hts_internal_links_in', true );
        $links_out = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );
        $ctx['internal_links'] = array( 'in' => $links_in, 'out' => $links_out );

        // Données GSC si matchées
        $gsc_clicks = get_post_meta( $post_id, '_hts_gsc_clicks', true );
        if ( $gsc_clicks !== '' ) {
            $ctx['gsc'] = array(
                'clicks'      => (int) $gsc_clicks,
                'impressions' => (int) get_post_meta( $post_id, '_hts_gsc_impressions', true ),
                'position'    => (float) get_post_meta( $post_id, '_hts_gsc_position', true ),
                'ctr'         => (float) get_post_meta( $post_id, '_hts_gsc_ctr', true ),
            );
        }

        // Sprint 4.4 fix : Sous-scores radar (vrais chiffres pour les graphiques)
        $detail_raw = get_post_meta( $post_id, '_hts_global_score_detail', true );
        $detail = is_string( $detail_raw ) ? json_decode( $detail_raw, true ) : ( is_array( $detail_raw ) ? $detail_raw : array() );
        $fresh = get_post_meta( $post_id, '_hts_freshness_score', true );
        // Maillage : score dérivé des liens internes (cible : 3+ in, 3+ out = 100)
        $maillage = min( 100, (int) round( ( min( $links_in, 5 ) / 5 * 50 ) + ( min( $links_out, 5 ) / 5 * 50 ) ) );
        $ctx['score_breakdown'] = array(
            'technique'  => (int) round( $detail['tech_score'] ?? 0 ),
            'contenu'    => (int) round( $detail['panel_score'] ?? $ctx['global_score'] ),
            'geo'        => (int) round( $ctx['geo_score'] ),
            'maillage'   => $maillage,
            'fraicheur'  => ( $fresh !== '' && $fresh !== false ) ? (int) round( (float) $fresh ) : null,
        );

        return $ctx;
    }

    /* ═══════════════════════════════════════════════════
     *  DEEP CONTEXT — v3.0 : Le Coach lit les articles
     * ═══════════════════════════════════════════════════ */

    /**
     * F.1 — Détecte les articles mentionnés dans la question par fuzzy match sur les titres.
     *
     * @since 3.0.0
     * @param string $question  Question de l'utilisateur.
     * @return array  Post IDs trouvés (max MAX_ARTICLES_DEEP).
     */
    public static function detect_articles_in_question( $question ) {
        global $wpdb;

        $q = mb_strtolower( trim( $question ) );
        if ( mb_strlen( $q ) < 5 ) return array();

        // Charger tous les titres publiés (cache transient 10min)
        $cache_key = 'hts_coach_titles_map';
        $titles    = get_transient( $cache_key );

        if ( $titles === false ) {
            $rows = $wpdb->get_results(
                "SELECT ID, post_title FROM {$wpdb->posts}
                 WHERE post_status = 'publish'
                   AND post_type IN ('post','page')
                   AND post_title != ''
                 ORDER BY ID DESC
                 LIMIT 500"
            );
            $titles = array();
            foreach ( $rows as $r ) {
                $titles[ (int) $r->ID ] = mb_strtolower( $r->post_title );
            }
            set_transient( $cache_key, $titles, 10 * MINUTE_IN_SECONDS );
        }

        $matched = array();
        $q_clean = preg_replace( '/[^\p{L}\p{N}\s]/u', '', $q );

        foreach ( $titles as $pid => $title ) {
            $title_clean = preg_replace( '/[^\p{L}\p{N}\s]/u', '', $title );
            $title_words = array_filter( explode( ' ', $title_clean ), function( $w ) {
                return mb_strlen( $w ) >= 4;
            } );

            if ( empty( $title_words ) ) continue;

            // Compter les mots significatifs du titre trouvés dans la question
            $found = 0;
            foreach ( $title_words as $tw ) {
                if ( mb_strpos( $q_clean, $tw ) !== false ) {
                    $found++;
                }
            }

            $ratio = $found / count( $title_words );

            // Match si ≥50% des mots significatifs sont dans la question, min 2 mots
            if ( $ratio >= 0.5 && $found >= 2 ) {
                $matched[ $pid ] = $ratio;
            }
            // Match exact pour les titres courts (2-3 mots significatifs)
            if ( count( $title_words ) <= 3 && $found === count( $title_words ) ) {
                $matched[ $pid ] = 1.0;
            }
        }

        // Trier par ratio desc et retourner les meilleurs
        arsort( $matched );
        return array_slice( array_keys( $matched ), 0, self::MAX_ARTICLES_DEEP );
    }

    /**
     * F.2 — Contexte profond d'un article : contenu full, H2/H3, liens avec URLs+ancres,
     *        voisins sémantiques, GEO détaillé, freshness.
     *
     * @since 3.0.0
     * @param int $post_id
     * @return array|null
     */
    public static function get_page_deep_context( $post_id ) {
        // Cache transient par article (5 min)
        $cache_key = 'hts_coach_deep_' . $post_id;
        $cached    = get_transient( $cache_key );
        if ( $cached !== false ) return $cached;

        $post = get_post( $post_id );
        if ( ! $post ) return null;

        $content_raw   = $post->post_content;
        $content_plain = wp_strip_all_tags( $content_raw );

        // ── Contenu nettoyé (max N mots) ──
        $words = preg_split( '/\s+/', $content_plain );
        $content_text = implode( ' ', array_slice( $words, 0, self::MAX_DEEP_CONTENT_WORDS ) );
        if ( count( $words ) > self::MAX_DEEP_CONTENT_WORDS ) {
            $content_text .= '… (tronqué)';
        }

        // ── Structure H2/H3/H4 ──
        $headings = self::extract_headings( $content_raw );

        // ── Meta ──
        $meta_title = get_post_meta( $post_id, '_hts_meta_title', true )
                      ?: get_post_meta( $post_id, '_yoast_wpseo_title', true );
        $meta_desc  = get_post_meta( $post_id, '_hts_meta_description', true )
                      ?: get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );

        $ctx = array(
            'id'           => $post_id,
            'title'        => $post->post_title,
            'url'          => get_permalink( $post_id ),
            'type'         => $post->post_type,
            'status'       => $post->post_status,
            'modified'     => wp_date( 'Y-m-d', strtotime( $post->post_modified ) ),
            'word_count'   => count( $words ),
            'content'      => $content_text,
            'headings'     => $headings,
            'meta_title'   => $meta_title ?: null,
            'meta_desc'    => $meta_desc ?: null,
            'keyword'      => get_post_meta( $post_id, '_hts_api_keyword', true )
                              ?: get_post_meta( $post_id, '_hts_focus_keyword', true ),
            'global_score' => (float) get_post_meta( $post_id, '_hts_global_score', true ),
            'geo_score'    => (float) get_post_meta( $post_id, '_hts_geo_score', true ),
            'meta_score'   => (float) get_post_meta( $post_id, '_hts_meta_score', true ),
            'on_page_score'=> (float) get_post_meta( $post_id, '_hts_on_page_score', true ),
        );

        // ── GEO détail (12 critères avec notes individuelles) ──
        $geo_detail = get_post_meta( $post_id, '_hts_geo_criteria', true );
        if ( is_array( $geo_detail ) ) {
            $ctx['geo_detail'] = $geo_detail;
        }

        // ── F.6 : Linking map (liens sortants/entrants avec URLs+ancres) ──
        $ctx['linking_map'] = self::get_linking_map( $post_id );

        // ── F.7 : Voisins sémantiques via embeddings (cosine similarity) ──
        $ctx['semantic_neighbors'] = self::get_semantic_neighbors( $post_id );

        // ── Données GSC ──
        $gsc_clicks = get_post_meta( $post_id, '_hts_gsc_clicks', true );
        if ( $gsc_clicks !== '' ) {
            $ctx['gsc'] = array(
                'clicks'      => (int) $gsc_clicks,
                'impressions' => (int) get_post_meta( $post_id, '_hts_gsc_impressions', true ),
                'position'    => (float) get_post_meta( $post_id, '_hts_gsc_position', true ),
                'ctr'         => (float) get_post_meta( $post_id, '_hts_gsc_ctr', true ),
            );
        }

        // ── Freshness ──
        $fresh = get_post_meta( $post_id, '_hts_freshness_score', true );
        if ( $fresh !== '' ) {
            $ctx['freshness_score'] = (float) $fresh;
        }

        // Sprint 4.4 fix : Sous-scores radar (vrais chiffres pour les graphiques)
        $detail_raw = get_post_meta( $post_id, '_hts_global_score_detail', true );
        $detail = is_string( $detail_raw ) ? json_decode( $detail_raw, true ) : ( is_array( $detail_raw ) ? $detail_raw : array() );
        $links_in  = 0;
        $links_out = 0;
        if ( ! empty( $ctx['linking_map'] ) ) {
            $links_in  = count( $ctx['linking_map']['incoming'] ?? array() );
            $links_out = count( $ctx['linking_map']['outgoing'] ?? array() );
        }
        $maillage = min( 100, (int) round( ( min( $links_in, 5 ) / 5 * 50 ) + ( min( $links_out, 5 ) / 5 * 50 ) ) );
        $ctx['score_breakdown'] = array(
            'technique'  => (int) round( $detail['tech_score'] ?? 0 ),
            'contenu'    => (int) round( $detail['panel_score'] ?? $ctx['global_score'] ),
            'geo'        => (int) round( $ctx['geo_score'] ),
            'maillage'   => $maillage,
            'fraicheur'  => ( $fresh !== '' && $fresh !== false ) ? (int) round( (float) $fresh ) : null,
        );

        set_transient( $cache_key, $ctx, self::DEEP_CONTEXT_TTL );
        return $ctx;
    }

    /**
     * Extrait la structure H2/H3/H4 d'un contenu HTML.
     *
     * @since 3.0.0
     * @param string $content  HTML brut.
     * @return array  [ { level, text } ]
     */
    private static function extract_headings( $content ) {
        $headings = array();
        if ( preg_match_all( '/<h([2-4])[^>]*>(.*?)<\/h[2-4]>/si', $content, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $m ) {
                $headings[] = array(
                    'level' => (int) $m[1],
                    'text'  => wp_strip_all_tags( $m[2] ),
                );
            }
        }
        return $headings;
    }

    /**
     * F.6 — Carte des liens internes d'un article (in + out avec URLs et ancres).
     *
     * @since 3.0.0
     * @param int $post_id
     * @return array { outgoing: [], incoming: [] }
     */
    public static function get_linking_map( $post_id ) {
        $map = array( 'outgoing' => array(), 'incoming' => array() );

        $post = get_post( $post_id );
        if ( ! $post ) return $map;

        $site_url = trailingslashit( site_url() );

        // ── Liens sortants (extraits du contenu) ──
        if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/si', $post->post_content, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $m ) {
                $href = $m[1];
                $is_internal = ( strpos( $href, $site_url ) === 0 )
                    || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 );

                if ( $is_internal ) {
                    $target_id = hts_url_to_postid( $href );
                    if ( $target_id > 0 && $target_id !== $post_id ) {
                        $map['outgoing'][] = array(
                            'target_id'    => $target_id,
                            'target_title' => get_the_title( $target_id ),
                            'anchor_text'  => wp_strip_all_tags( $m[2] ),
                        );
                    }
                }
            }
        }

        // Dédupliquer par target_id
        $seen = array();
        $map['outgoing'] = array_values( array_filter( $map['outgoing'], function( $l ) use ( &$seen ) {
            if ( isset( $seen[ $l['target_id'] ] ) ) return false;
            $seen[ $l['target_id'] ] = true;
            return true;
        } ) );

        // ── Liens entrants (articles qui linkent vers celui-ci) ──
        global $wpdb;
        $url  = get_permalink( $post_id );
        $slug = basename( rtrim( wp_parse_url( $url, PHP_URL_PATH ) ?: '', '/' ) );
        if ( empty( $slug ) ) return $map;

        $pattern = '%' . $wpdb->esc_like( $slug ) . '%';
        $rows    = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_content
             FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ('post','page')
               AND ID != %d
               AND post_content LIKE %s
             LIMIT 20",
            $post_id, $pattern
        ) );

        foreach ( $rows as $row ) {
            $esc_slug = preg_quote( $slug, '/' );
            if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']*' . $esc_slug . '[^"\']*)["\'][^>]*>(.*?)<\/a>/si', $row->post_content, $lm, PREG_SET_ORDER ) ) {
                foreach ( $lm as $link ) {
                    $linked_id = hts_url_to_postid( $link[1] );
                    if ( $linked_id === $post_id ) {
                        $map['incoming'][] = array(
                            'source_id'    => (int) $row->ID,
                            'source_title' => $row->post_title,
                            'anchor_text'  => wp_strip_all_tags( $link[2] ),
                        );
                        break; // Un seul lien par source suffit
                    }
                }
            }
        }

        return $map;
    }

    /**
     * F.7 — Voisins sémantiques via embeddings (cosine similarity).
     * Retourne les N articles les plus proches avec info de lien bidirectionnel.
     *
     * @since 3.0.0
     * @param int $post_id
     * @param int $top_n
     * @return array [ { id, title, similarity, has_link_to, has_link_from } ]
     */
    public static function get_semantic_neighbors( $post_id, $top_n = 5 ) {
        if ( ! class_exists( 'HTS_Embeddings' ) ) return array();

        $emb = new HTS_Embeddings();
        if ( ! method_exists( $emb, 'find_similar' ) ) return array();

        $similar = $emb->find_similar( $post_id, $top_n, 0.3 );
        if ( empty( $similar ) ) return array();

        // Charger la linking map pour enrichir
        $link_map    = self::get_linking_map( $post_id );
        $out_ids     = array_column( $link_map['outgoing'], 'target_id' );
        $in_ids      = array_column( $link_map['incoming'], 'source_id' );

        $neighbors = array();
        foreach ( $similar as $s ) {
            $sid = (int) ( $s['post_id'] ?? $s['id'] ?? 0 );
            if ( $sid <= 0 ) continue;

            $neighbors[] = array(
                'id'            => $sid,
                'title'         => get_the_title( $sid ),
                'similarity'    => round( (float) ( $s['similarity'] ?? $s['score'] ?? 0 ), 3 ),
                'has_link_to'   => in_array( $sid, $out_ids ),
                'has_link_from' => in_array( $sid, $in_ids ),
            );
        }

        return $neighbors;
    }

    /* ═══════════════════════════════════════════════════
     *  COCON AWARENESS — v3.1 : Le Coach comprend les clusters
     * ═══════════════════════════════════════════════════ */

    /**
     * G.3 — Détecte l'intention de la question du client.
     *
     * Catégories :
     *  - article  : question sur un ou des articles spécifiques
     *  - cluster  : question sur un cocon / cluster / thématique
     *  - global   : question sur le site en général (scores, santé, stratégie)
     *  - debug    : question technique (crons, erreurs, config)
     *  - plan     : demande de plan d'action / to-do
     *  - memory   : question sur l'historique des échanges (future)
     *
     * @since 3.1.0
     * @param string $question
     * @return string  Intent type.
     */
    public static function detect_intent( $question ) {
        $q = mb_strtolower( trim( $question ) );
        if ( mb_strlen( $q ) < 3 ) return 'simple';

        // ── Greetings / small talk → simple (no heavy context needed) ──
        $greeting_kw = array( 'bonjour', 'salut', 'hello', 'hey', 'coucou', 'bonsoir', 'yo', 'hi', 'merci', 'thanks', 'ok', 'oui', 'non', 'd\'accord', 'super', 'top', 'cool', 'parfait', 'ça roule', 'ca roule', 'comment ça va', 'comment ca va' );
        foreach ( $greeting_kw as $kw ) {
            // Exact match only OR starts with greeting AND message is short (< 25 chars)
            if ( $q === $kw || ( mb_strpos( $q, $kw ) === 0 && mb_strlen( $q ) < 25 ) ) return 'simple';
        }
        // Ultra-short messages (< 15 chars, no SEO keyword) → simple
        if ( mb_strlen( $q ) < 15 ) {
            $has_seo_word = false;
            $seo_words = array( 'score', 'seo', 'geo', 'article', 'page', 'cluster', 'cocon', 'trafic', 'plan', 'audit', 'inbox', 'meta', 'lien', 'maillage', 'cron', 'erreur', 'bug' );
            foreach ( $seo_words as $sw ) {
                if ( mb_strpos( $q, $sw ) !== false ) { $has_seo_word = true; break; }
            }
            if ( ! $has_seo_word ) return 'simple';
        }

        // ── Memory intent (v3.2) ──
        $memory_kw = array( 'souviens', 'souvenir', 'rappelle', 'rappeler', 'mémoire', 'memoire', 'memory', 'dernière session', 'derniere session', 'session précédente', 'session precedente', 'on avait parlé', 'on avait parle', 'tu te rappelles', 'profil du site', 'profil site' );
        foreach ( $memory_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'memory';
        }

        // ── Debug/support intent (tier 1 — 4o-mini) ──
        $debug_kw = array( 'cron', 'erreur', 'error', 'bug', 'debug', 'config', 'log', 'agent', 'workflow', 'embedding', 'api key', 'clé api', 'fonctionne', 'marche pas', 'ne marche', 'cassé', 'casse', 'problème technique', 'probleme technique', 'support', 'aide technique', 'activer', 'désactiver', 'desactiver', 'réglage', 'reglage', 'paramètre', 'parametre' );
        foreach ( $debug_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'debug';
        }

        // ── Sprint 4.5 / 4.7a: Data query intent → needs tools (Anthropic + OpenAI) ──
        // Must be BEFORE simple_kw to intercept "score", "stats", "montre", etc.
        $data_query_kw = array(
            // Page audit
            'score de', 'score du', 'score la', 'score ma', 'score mon', 'score l\'',
            'audite', 'audit de', 'audit du', 'audit la', 'audit ma', 'audit mon',
            'analyse ma', 'analyse mon', 'analyse la', 'analyse le', 'analyse l\'',
            'diagnostique', 'diagnostic de', 'diagnostic du',
            // GSC
            'stats google', 'stats gsc', 'search console',
            'clics google', 'impressions google', 'positions google',
            'mes stats', 'mes clics', 'mes positions', 'mes impressions',
            'trafic google', 'trafic gsc', 'données gsc', 'donnees gsc',
            'page d\'accueil',
            // Charts
            'graphique pour', 'radar pour', 'graphique de', 'radar de',
            // Articles list
            'pires articles', 'pires pages', 'meilleurs articles', 'meilleures pages',
            'liste des articles', 'liste des pages', 'mes articles', 'mes pages',
            'articles sous', 'pages sous', 'articles en dessous', 'pages en dessous',
            'articles au dessus', 'pages au dessus',
            // Cocon
            'mon cocon', 'mes cocons', 'état du cocon', 'etat du cocon',
            'détail du cocon', 'detail du cocon', 'structure du cocon',
            'maillage du', 'maillage de', 'pages orphelines',
            'liens manquants', 'densité du cocon', 'densite du cocon',
            // Inbox
            'inbox', 'actions en attente', 'actions pending', 'actions exécutées',
            'actions executees', 'historique des actions', 'actions échouées',
            'actions echouees', 'quoi de neuf', 'qu\'est-ce qui a été fait',
            'optimisations en cours', 'optimisations appliquées',
            // S13-B: Score and diagnostic keywords (moved from simple_kw)
            'score global', 'score geo', 'score seo', 'mes scores', 'mon score',
            'état seo', 'etat seo', 'état de mon site', 'etat de mon site',
            'état du site', 'etat du site', 'santé seo', 'sante seo',
            'comment va mon site', 'diagnostic seo', 'bilan seo', 'rapport seo',
            'top pages', 'mes pages google', 'mes résultats', 'mes resultats',
            'un diagnostic', 'le diagnostic', 'mon diagnostic', 'fais un audit',
            'résumé du site', 'resume du site', 'vue d\'ensemble', 'tableau de bord',
        );
        foreach ( $data_query_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'data_query';
        }
        // Pattern: "quel est le score" / "montre-moi les stats" + SEO context
        if ( preg_match( '/\b(quel|quelle|quels|quelles)\b.*\b(score|position|ctr|clics?|impressions?|trafic)\b/ui', $q ) ) {
            return 'data_query';
        }
        if ( preg_match( '/\b(montre|affiche|donne)\b.*\b(stats?|statistiques?|données|donnees|chiffres?|clics?|positions?|articles?|pages?|cocons?|inbox)\b/ui', $q ) ) {
            return 'data_query';
        }
        // Sprint 5.2: "quels articles besoin/manque/sans FAQ/meta/liens" → data_query (tools fetch the data)
        if ( preg_match( '/\b(quel|quelle|quels|quelles|trouve|cherche|identifie|liste)\b.*\b(articles?|pages?)\b.*\b(besoin|manque|sans|pas de|n.ont pas|n.a pas|faq|meta|liens?|orphelin|faible|pire|problème|probleme)\b/ui', $q ) ) {
            return 'data_query';
        }
        if ( preg_match( '/\b(articles?|pages?)\b.*\b(besoin|ont besoin|qui ont besoin|nécessit|necessit|manque|sans)\b.*\b(faq|meta|lien|optimis|refresh|rafraîch|rafraich)\b/ui', $q ) ) {
            return 'data_query';
        }

        // ── Simple intent (tier 1 — 4o-mini) : questions de lecture pure ──
        $simple_kw = array( 'combien', 'c\'est quoi', 'qu\'est-ce que', 'qu\'est ce que', 'définition', 'definition', 'résumé rapide', 'resume rapide' );
        foreach ( $simple_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'simple';
        }

        // ── Cannibalization intent (tier 3 — Haiku) ──
        $cannibal_kw = array( 'cannibal', 'cannibalis', 'pages se battent', 'même mot', 'meme mot', 'doublon', 'contenu dupliqué', 'contenu duplique', 'pages similaires', 'pages identiques', 'fusionner', 'consolider' );
        foreach ( $cannibal_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'cannibalization';
        }

        // ── Sprint 4.9 (O4 fix): Disambiguation plan vs action ──
        // "Fais-moi un plan" / "Crée-moi un plan" → plan intent, NOT action
        // Must check BEFORE action verb patterns to avoid false positive
        if ( preg_match( '/\b(fais|fait|faites|cr[eé]{1,2}|pr[eé]par|donne|propose|fais-moi|fais moi|crée-moi|cree-moi)\b.*\b(plan|planning|roadmap|strat[eé]gie|to-?do|todo)\b/ui', $q ) ) {
            return 'plan';
        }

        // ── Agent Mode intent (v4.0 Sprint 4.1) : le client veut que le Coach EXÉCUTE ──
        // Phase 1 : Verbes d'action + complément — regex pour gérer toutes les conjugaisons
        // (tu optimises, optimisez, optimiser les... → match)
        $action_verb_patterns = array(
            // optimise/optimiser + complément
            'optimis(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // corrige/corriger + complément
            'corrig(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // améliore/améliorer + complément
            'am[eé]lior(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // génère/générer + complément
            'g[eé]n[eè]r(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // lance/lancer + complément
            'lanc(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|le|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // ajoute/ajouter + complément
            'ajout(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|le|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // programme/programmer + complément
            'programm(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // planifie/planifier + complément
            'planifi(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // rafraîchis/rafraîchir + complément
            'rafra[iî]chi(?:s|r|t|ssez|ssons)?\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // rédige/rédiger + complément
            'r[eé]dig(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // publie/publier + complément
            'publi(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // mets/mettre à jour
            'met(?:s|tre|tez|tons)?\\s+[àa]\\s+jour',
            // fais/faire + pronom
            'fai(?:s|t|tes|re)[\\ \\-]+(?:le|la|les|moi|nous|tout)',
            // crée/créer + complément
            'cr[eé]{1,2}(?:e[szr]?|es|ez|er|ons)\\s+(?:les?|la|le|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
            // écris/écrire + complément
            '[eé]cri(?:s|t|vez|vons|re)\\s+(?:les?|la|le|mon|mes|ma|un|une|des|ce|cette|ces|tout|toutes)',
        );
        foreach ( $action_verb_patterns as $pattern ) {
            if ( preg_match( '/' . $pattern . '/ui', $q ) ) return 'action';
        }

        // Phase 2 : Keywords exactes pour les formes courtes ou impératives
        $action_kw = array( 'fais-le', 'fais le', 'fais-moi', 'fais moi', 'exécute', 'execute', 'lance', 'planifie', 'crée-moi', 'cree-moi', 'crée moi', 'cree moi', 'écris-moi', 'ecris-moi', 'écris moi', 'ecris moi', 'optimise-moi', 'optimise moi', 'corrige-moi', 'corrige moi', 'publie', 'rédige', 'redige', 'approuve', 'valide le plan', 'go', 'c\'est bon lance', 'ajoute des liens', 'ajoute une faq', 'ajoute la faq', 'ajoute les liens', 'lance le refresh', 'lance un refresh', 'crée la tâche', 'cree la tache', 'crée la tache', 'crée la tâche', 'fais la tâche', 'fais la tache', 'génère la faq', 'genere la faq', 'génère les metas', 'genere les metas', 'génère une faq', 'genere une faq', 'ajoute faq', 'ajouter faq', 'ajouter une faq', 'ajouter la faq', 'rafraîchis', 'rafraichis', 'mets à jour', 'mets a jour', 'applique' );
        foreach ( $action_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'action';
        }
        // Patterns plus complexes : "fais monter", "fais passer en top 3", etc.
        if ( preg_match( '/\\b(fais|fait|faites)\\s+(monter|descendre|passer|grimper|remonter|progresser)\\b/ui', $q ) ) {
            return 'action';
        }
        // "mes X articles/pages de la semaine" + verbe d'action implicite
        if ( preg_match( '/\\b(programm|planifi|g[eé]n[eè]r|cr[eé]{1,2}|[eé]cri|pr[eé]par)[a-zéèêë]*\\b.*\\b(articles?|pages?|brouillons?|contenus?|metas?)\\b/ui', $q ) ) {
            return 'action';
        }
        // Références à un plan affiché : "fait la 2", "juste la 3", "lance l'étape 1"
        if ( preg_match( '/\\b(fait|fais|lance|ok|oui|valide|approuve|go)\\b.*\\b(la|étape|etape|step|numéro|numero)\\s*(\\d)/u', $q ) ) {
            return 'action';
        }
        // Ultra-short plan confirmations : "ok la 2", "juste la 2", "fait la 2"
        if ( preg_match( '/\\b(ok|oui|juste|fait|fais|lance|seulement)\\b.*\\bla\\s+\\d/u', $q ) ) {
            return 'action';
        }

        // ── Plan/strategy intent (tier 3 — Haiku) ──
        $plan_kw = array( 'plan d', 'plan pour', 'to-do', 'todo', 'planning', 'priorité', 'priorite', 'prochaines étapes', 'prochaines etapes', 'par où commencer', 'par ou commencer', 'que dois-je', 'que faire', 'plan hebdo', 'plan semaine', 'roadmap', 'stratégie', 'strategie', 'doubler mon trafic', 'augmenter mon trafic', 'objectif', 'trimestre', 'this month', 'cette semaine', 'ce mois' );
        foreach ( $plan_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'plan';
        }

        // ── GSC analysis intent (tier 2 — 4.1-mini) ──
        $gsc_kw = array( 'gsc', 'search console', 'clics', 'impressions', 'ctr', 'position moyenne', 'requêtes', 'requetes', 'queries', 'top pages', 'trafic organique', 'trafic google', 'mots-clés', 'mots clés', 'mots cles' );
        foreach ( $gsc_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'gsc_analysis';
        }

        // ── Cluster intent (tier 2 — 4.1-mini) ──
        $cluster_kw = array( 'cocon', 'cluster', 'thématique', 'thematique', 'silo', 'pilier', 'maillage du cluster', 'maillage du cocon', 'satellite', 'topical authority', 'couverture thém', 'couverture them' );
        foreach ( $cluster_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'cluster';
        }

        // ── Cluster intent : fuzzy match sur noms de clusters existants ──
        $cluster_names = self::get_cluster_names();
        foreach ( $cluster_names as $cn ) {
            $cn_lower = mb_strtolower( $cn );
            if ( mb_strlen( $cn_lower ) >= 4 && mb_strpos( $q, $cn_lower ) !== false ) {
                return 'cluster';
            }
            $cn_words = array_filter( explode( ' ', preg_replace( '/[^\p{L}\p{N}\s]/u', '', $cn_lower ) ), function( $w ) {
                return mb_strlen( $w ) >= 4;
            } );
            if ( count( $cn_words ) >= 2 ) {
                $found = 0;
                foreach ( $cn_words as $w ) {
                    if ( mb_strpos( $q, $w ) !== false ) $found++;
                }
                if ( $found >= 2 || ( $found === count( $cn_words ) ) ) return 'cluster';
            }
        }

        // ── Article intent (tier 2 — 4.1-mini) : détection via titres ──
        $detected_articles = self::detect_articles_in_question( $question );
        if ( ! empty( $detected_articles ) ) return 'article';

        // ── Analyse keywords catch-all (tier 2) ──
        $analyse_kw = array( 'analyse', 'analyser', 'diagnostic', 'améliorer', 'ameliorer', 'optimiser', 'opportunité', 'opportunite', 'recommand', 'audit', 'comparer', 'performance', 'maillage' );
        foreach ( $analyse_kw as $kw ) {
            if ( mb_strpos( $q, $kw ) !== false ) return 'gsc_analysis';
        }

        // ── Sprint 5.0: Followup detection — avoid downgrading follow-up questions to global/4o-mini ──
        // If no keyword matched and a recent intent exists (<5 min), check for anaphoric patterns
        $followup_patterns = array(
            'les \\d+ premiers',  'les \\d+ derniers',  'le premier', 'le dernier',
            'pour ceux', 'pour celles', 'pour ces', 'pour celui', 'pour celle',
            'les mêmes', 'les memes', 'ceux-là', 'ceux-ci', 'celles-là', 'celles-ci',
            'sur ceux', 'sur celles', 'donne.?moi (les|le|la|des) d[eé]tails',
            'plus de d[eé]tails', 'développe', 'developpe', 'explique.?moi',
            'et pour (le|la|les|l\')', 'qu\'en est.?il', 'quoi d\'autre',
            'continue', 'la suite', 'ensuite', 'et après', 'et apres',
            'note', 'notes', 'les scores', 'le score', 'quel score',
        );
        foreach ( $followup_patterns as $pattern ) {
            if ( preg_match( '/' . $pattern . '/ui', $q ) ) {
                $last = self::get_last_intent();
                if ( $last && ! in_array( $last, self::LIGHT_INTENTS, true ) ) {
                    return $last;
                }
                break;
            }
        }

        // ── Default : global (tier 1 — 4o-mini) ──
        return 'global';
    }

    /**
     * Retourne la liste des noms de clusters connus (cache transient 10min).
     *
     * @since 3.1.0
     * @return array  [ 'Nom cluster 1', 'Nom cluster 2', ... ]
     */
    private static function get_cluster_names() {
        $cache_key = 'hts_coach_cluster_names';
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) return $cached;

        $last = get_option( 'hts_cocon_last_result', array() );
        if ( empty( $last['clusters'] ) ) return array();

        $names = array();
        foreach ( $last['clusters'] as $cl ) {
            $name = $cl['name'] ?? '';
            if ( ! empty( $name ) && ! in_array( $name, array( 'Non classé', 'Thématiques émergentes' ), true ) ) {
                $names[] = $name;
            }
        }

        set_transient( $cache_key, $names, 10 * MINUTE_IN_SECONDS );
        return $names;
    }

    /**
     * Sprint 5.0: Get the last intent for the current user (from transient, TTL 5 min).
     * Used for follow-up routing to avoid downgrading to global/4o-mini.
     *
     * @since 5.0
     * @return string|false  Last intent or false if expired/none.
     */
    private static function get_last_intent() {
        $user_id = get_current_user_id();
        if ( ! $user_id ) return false;
        return get_transient( 'hts_coach_last_intent_' . $user_id );
    }

    /**
     * Sprint 5.0: Store the current intent for follow-up detection (TTL 5 min).
     *
     * @since 5.0
     * @param string $intent  The intent to store.
     * @param int    $user_id WordPress user ID.
     */
    private static function set_last_intent( $intent, $user_id = 0 ) {
        if ( ! $user_id ) $user_id = get_current_user_id();
        if ( ! $user_id ) return;
        // Only store non-trivial intents (no point caching 'simple' or 'global')
        if ( in_array( $intent, self::LIGHT_INTENTS, true ) ) return;
        set_transient( 'hts_coach_last_intent_' . $user_id, $intent, 5 * MINUTE_IN_SECONDS );
    }

    /**
     * G.1 — Contexte détaillé d'un cluster pour le Coach.
     * Fuzzy match le nom, retourne pages, pilier, liens manquants, scores.
     *
     * @since 3.1.0
     * @param string $cluster_name  Nom du cluster (fuzzy match).
     * @return array|null
     */
    public static function get_cluster_context( $cluster_name ) {
        if ( ! class_exists( 'HTS_Cocon' ) ) return null;

        $cocon = new \HTS_Cocon();
        $data  = $cocon->get_cocon_data();
        if ( empty( $data['clusters'] ) ) return null;

        // ── Fuzzy match sur le nom du cluster ──
        $matched_key = self::fuzzy_match_cluster( $cluster_name, array_keys( $data['clusters'] ) );
        if ( $matched_key === null ) return null;

        $cl    = $data['clusters'][ $matched_key ];
        $nodes = $data['nodes'] ?? array();

        // ── Pages du cluster avec détails ──
        $pages = array();
        $pillar_title = '';
        foreach ( $cl['pages'] ?? array() as $pid ) {
            if ( ! isset( $nodes[ $pid ] ) ) continue;
            $n = $nodes[ $pid ];

            $page_data = array(
                'id'          => $pid,
                'title'       => $n['title'] ?? get_the_title( $pid ),
                'url'         => $n['url'] ?? get_permalink( $pid ),
                'role'        => $n['role'] ?? 'satellite',
                'in_count'    => $n['in_count'] ?? 0,
                'out_count'   => $n['out_count'] ?? 0,
                'is_orphan'   => $n['is_orphan'] ?? false,
                'score'       => $n['pillar_score'] ?? 0,
                'global_score' => (float) get_post_meta( $pid, '_hts_global_score', true ),
                'geo_score'    => (float) get_post_meta( $pid, '_hts_geo_score', true ),
            );

            if ( $page_data['role'] === 'pilier' ) {
                $pillar_title = $page_data['title'];
            }

            $pages[] = $page_data;
        }

        // Trier : pilier d'abord, puis par score desc
        usort( $pages, function( $a, $b ) {
            if ( $a['role'] === 'pilier' ) return -1;
            if ( $b['role'] === 'pilier' ) return 1;
            return $b['score'] - $a['score'];
        } );

        // ── Liens manquants intra-cluster ──
        $missing_links = self::find_missing_cluster_links_for( $cl, $nodes, $data );

        // ── Métriques agrégées ──
        $avg_global = 0;
        $avg_geo    = 0;
        $orphan_count = 0;
        $n_pages = count( $pages );
        foreach ( $pages as $p ) {
            $avg_global += $p['global_score'];
            $avg_geo    += $p['geo_score'];
            if ( $p['is_orphan'] ) $orphan_count++;
        }

        return array(
            'name'             => $matched_key,
            'theme'            => $cl['theme'] ?? '',
            'page_count'       => $n_pages,
            'pillar_id'        => $cl['pillar_id'] ?? 0,
            'pillar_title'     => $pillar_title,
            'pillar_coverage'  => $cl['pillar_coverage'] ?? 0,
            'density'          => $cl['density'] ?? 0,
            'sibling_density'  => $cl['sibling_density'] ?? null,
            'coherence'        => $cl['coherence'] ?? null,
            'orphan_count'     => $orphan_count,
            'avg_global_score' => $n_pages > 0 ? round( $avg_global / $n_pages, 1 ) : 0,
            'avg_geo_score'    => $n_pages > 0 ? round( $avg_geo / $n_pages, 1 ) : 0,
            'pages'            => $pages,
            'missing_links'    => $missing_links,
        );
    }

    /**
     * Fuzzy match un nom de cluster parmi les clusters existants.
     *
     * @since 3.1.0
     * @param string $input      Nom recherché.
     * @param array  $candidates Noms exacts des clusters.
     * @return string|null        Nom exact trouvé ou null.
     */
    private static function fuzzy_match_cluster( $input, $candidates ) {
        $input_lower = mb_strtolower( trim( $input ) );
        if ( empty( $input_lower ) ) return null;

        // 1. Match exact (case-insensitive)
        foreach ( $candidates as $c ) {
            if ( mb_strtolower( $c ) === $input_lower ) return $c;
        }

        // 2. Un candidat contient l'input (ou l'inverse)
        foreach ( $candidates as $c ) {
            $c_lower = mb_strtolower( $c );
            if ( mb_strpos( $c_lower, $input_lower ) !== false || mb_strpos( $input_lower, $c_lower ) !== false ) {
                return $c;
            }
        }

        // 3. Match par mots significatifs (≥4 chars)
        $input_words = array_filter( explode( ' ', preg_replace( '/[^\p{L}\p{N}\s]/u', '', $input_lower ) ), function( $w ) {
            return mb_strlen( $w ) >= 4;
        } );
        if ( empty( $input_words ) ) return null;

        $best_match = null;
        $best_ratio = 0;

        foreach ( $candidates as $c ) {
            $c_clean = preg_replace( '/[^\p{L}\p{N}\s]/u', '', mb_strtolower( $c ) );
            $found = 0;
            foreach ( $input_words as $w ) {
                if ( mb_strpos( $c_clean, $w ) !== false ) $found++;
            }
            $ratio = $found / count( $input_words );
            if ( $ratio > $best_ratio && $ratio >= 0.5 ) {
                $best_ratio = $ratio;
                $best_match = $c;
            }
        }

        return $best_match;
    }

    /**
     * G.2 — Trouve les paires de pages similaires sans lien au sein d'un cluster.
     *
     * @since 3.1.0
     * @param array $cl     Cluster data.
     * @param array $nodes  All nodes.
     * @param array $data   Full cocon data (with links).
     * @return array  [ { source_id, source_title, target_id, target_title, similarity?, reason } ]
     */
    private static function find_missing_cluster_links_for( $cl, $nodes, $data ) {
        $pages = $cl['pages'] ?? array();
        if ( count( $pages ) < 2 ) return array();

        // ── Construire la map des liens existants ──
        $existing_links = array();
        foreach ( $data['links'] ?? array() as $link ) {
            $src = (int) $link['source'];
            $tgt = (int) $link['target'];
            $existing_links[ $src . '-' . $tgt ] = true;
        }

        $missing = array();
        $pillar_id = (int) ( $cl['pillar_id'] ?? 0 );

        // ── Vérifier que chaque satellite linke vers le pilier ──
        if ( $pillar_id > 0 ) {
            foreach ( $pages as $pid ) {
                $pid = (int) $pid;
                if ( $pid === $pillar_id ) continue;
                if ( ! isset( $existing_links[ $pid . '-' . $pillar_id ] ) ) {
                    $missing[] = array(
                        'source_id'    => $pid,
                        'source_title' => $nodes[ $pid ]['title'] ?? get_the_title( $pid ),
                        'target_id'    => $pillar_id,
                        'target_title' => $nodes[ $pillar_id ]['title'] ?? get_the_title( $pillar_id ),
                        'reason'       => 'satellite_to_pillar',
                    );
                }
            }
            // ── Vérifier que le pilier linke vers ses satellites ──
            foreach ( $pages as $pid ) {
                $pid = (int) $pid;
                if ( $pid === $pillar_id ) continue;
                if ( ! isset( $existing_links[ $pillar_id . '-' . $pid ] ) ) {
                    $missing[] = array(
                        'source_id'    => $pillar_id,
                        'source_title' => $nodes[ $pillar_id ]['title'] ?? get_the_title( $pillar_id ),
                        'target_id'    => $pid,
                        'target_title' => $nodes[ $pid ]['title'] ?? get_the_title( $pid ),
                        'reason'       => 'pillar_to_satellite',
                    );
                }
            }
        }

        // ── Paires satellites proches sans lien (via embeddings si dispo) ──
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb = new \HTS_Embeddings();
            $has_find = method_exists( $emb, 'find_similar' );

            // Pour chaque page du cluster, trouver ses voisins dans le cluster
            $checked_pairs = array();
            foreach ( array_slice( $pages, 0, 15 ) as $pid ) {  // Limiter pour perf
                $pid = (int) $pid;
                if ( ! $has_find ) break;

                $similar = $emb->find_similar( $pid, 10, 0.4 );
                if ( empty( $similar ) ) continue;

                foreach ( $similar as $s ) {
                    $sid = (int) ( $s['post_id'] ?? $s['id'] ?? 0 );
                    if ( $sid <= 0 || $sid === $pid ) continue;
                    if ( ! in_array( $sid, $pages ) ) continue;  // Pas dans ce cluster

                    $pair_key = min( $pid, $sid ) . '-' . max( $pid, $sid );
                    if ( isset( $checked_pairs[ $pair_key ] ) ) continue;
                    $checked_pairs[ $pair_key ] = true;

                    $sim = round( (float) ( $s['similarity'] ?? $s['score'] ?? 0 ), 3 );

                    // Vérifier lien dans les 2 sens
                    $has_a_to_b = isset( $existing_links[ $pid . '-' . $sid ] );
                    $has_b_to_a = isset( $existing_links[ $sid . '-' . $pid ] );

                    if ( ! $has_a_to_b && ! $has_b_to_a && $sim >= 0.5 ) {
                        $missing[] = array(
                            'source_id'    => $pid,
                            'source_title' => $nodes[ $pid ]['title'] ?? get_the_title( $pid ),
                            'target_id'    => $sid,
                            'target_title' => $nodes[ $sid ]['title'] ?? get_the_title( $sid ),
                            'similarity'   => $sim,
                            'reason'       => 'similar_no_link',
                        );
                    }
                }
            }
        }

        // Limiter à 15 suggestions max pour ne pas surcharger le contexte
        return array_slice( $missing, 0, 15 );
    }

    /**
     * Extrait le nom du cluster mentionné dans la question (fuzzy).
     *
     * @since 3.1.0
     * @param string $question
     * @return string|null  Nom exact du cluster ou null.
     */
    public static function detect_cluster_in_question( $question ) {
        $names = self::get_cluster_names();
        if ( empty( $names ) ) return null;

        return self::fuzzy_match_cluster( $question, $names );
    }

    /* ═══════════════════════════════════════════════
     *  SYSTEM PROMPT
     * ═══════════════════════════════════════════════ */

    /**
     * Construit le system prompt pour l'IA Coach.
     * Ne contient JAMAIS de clé API.
     */
    public static function build_system_prompt( $context, $user_id = 0 ) {
        $intent = $context['_intent'] ?? 'global';

        // ── Sprint 3.1 : Contexte adaptatif — filtrer selon l'intent pour économiser les tokens ──
        $ctx_for_prompt = $context;

        // Clés lourdes du Sprint 2.1 (chacune peut peser 500-2000 tokens)
        $heavy_keys = array( 'all_cocons_summary', 'chantiers', 'pages_overview', 'deep_pages', 'cluster_detail', 'cocons', 'gsc', 'inbox_details', 'recent_publications', 'drafts_ready', 'gsc_delta', 'inbox_by_type', 'health_alerts', 'recent_artifacts', 'ai_crawl' );

        if ( in_array( $intent, array( 'simple', 'memory' ), true ) ) {
            // Simple/memory : garder SEULEMENT les stats de base
            foreach ( $heavy_keys as $k ) {
                unset( $ctx_for_prompt[ $k ] );
            }
            // Garder juste : site_url, site_name, global_score, geo_score_avg, pending_actions, total_posts, worst_pages(3), best_pages(3)
            if ( isset( $ctx_for_prompt['worst_pages'] ) ) $ctx_for_prompt['worst_pages'] = array_slice( $ctx_for_prompt['worst_pages'], 0, 3 );
            if ( isset( $ctx_for_prompt['best_pages'] ) )  $ctx_for_prompt['best_pages']  = array_slice( $ctx_for_prompt['best_pages'], 0, 3 );
        } elseif ( $intent === 'data_query' ) {
            // Sprint 4.5: data_query — strip per-article data to force tool_use
            foreach ( $heavy_keys as $k ) {
                unset( $ctx_for_prompt[ $k ] );
            }
            unset( $ctx_for_prompt['worst_pages'] );
            unset( $ctx_for_prompt['best_pages'] );
        } elseif ( in_array( $intent, array( 'global', 'debug' ), true ) ) {
            // Global/debug : contexte allégé — pas de deep pages/clusters/publications détaillés
            $medium_strip = array( 'all_cocons_summary', 'deep_pages', 'cluster_detail', 'pages_overview', 'recent_publications', 'recent_artifacts', 'chantiers' );
            foreach ( $medium_strip as $k ) {
                unset( $ctx_for_prompt[ $k ] );
            }
            if ( isset( $ctx_for_prompt['worst_pages'] ) ) $ctx_for_prompt['worst_pages'] = array_slice( $ctx_for_prompt['worst_pages'], 0, 3 );
            if ( isset( $ctx_for_prompt['best_pages'] ) )  $ctx_for_prompt['best_pages']  = array_slice( $ctx_for_prompt['best_pages'], 0, 3 );
        }

        // S13-B FIX: ALWAYS inject compact GSC summary for ALL intents (~150 tokens)
        // The AI MUST know site-level traffic even for simple/global/data_query questions
        if ( ! isset( $ctx_for_prompt['gsc'] ) || empty( $ctx_for_prompt['gsc'] ) ) {
            $gsc_full = $context['gsc'] ?? array();
            if ( ! empty( $gsc_full['connected'] ) && ! empty( $gsc_full['data'] ) ) {
                $ctx_for_prompt['gsc_kpis'] = array(
                    'connected'    => true,
                    'clicks_30j'   => (int) ( $gsc_full['total_clicks'] ?? 0 ),
                    'impressions'  => (int) ( $gsc_full['impressions'] ?? 0 ),
                    'avg_position' => round( (float) ( $gsc_full['avg_position'] ?? 0 ), 1 ),
                    'avg_ctr'      => round( (float) ( $gsc_full['avg_ctr'] ?? 0 ), 2 ) . '%',
                    'pages_count'  => (int) ( $gsc_full['pages_count'] ?? 0 ),
                );
            } else {
                $ctx_for_prompt['gsc_kpis'] = array( 'connected' => false );
            }
        }

        // S13-B: ALWAYS inject GSC delta for ALL intents (~100 tokens)
        if ( ! isset( $ctx_for_prompt['gsc_delta'] ) ) {
            $delta = $context['gsc_delta'] ?? array();
            if ( ! empty( $delta['available'] ) ) {
                $ctx_for_prompt['gsc_delta_7j'] = $delta['7d'] ?? null;
            }
        }
        // plan/cannibalization/article/cluster/gsc_analysis : contexte COMPLET (pas de filtre)

        // Sprint 5.4b: Pour gsc_analysis, trier pages_overview par impressions GSC (pas par score)
        if ( $intent === 'gsc_analysis' && ! empty( $ctx_for_prompt['pages_overview'] ) ) {
            usort( $ctx_for_prompt['pages_overview'], function( $a, $b ) {
                return ( $b['gsc_impressions'] ?? 0 ) - ( $a['gsc_impressions'] ?? 0 );
            });
            // Garder top 10 (les plus visibles sur Google) pour limiter les tokens
            $ctx_for_prompt['pages_overview'] = array_slice( $ctx_for_prompt['pages_overview'], 0, 10 );
            // Retirer les intros (100 mots) pour économiser ~500 tokens
            foreach ( $ctx_for_prompt['pages_overview'] as &$po ) {
                unset( $po['intro'] );
            }
            unset( $po );
        }

        $json_ctx = wp_json_encode( $ctx_for_prompt, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

        // Tronquer selon l'intent — limites adaptatives
        // Sprint 5.2: limites réduites pour économiser les tokens
        $max_ctx_len = 15000; // default for heavy intents (plan, article, cluster, cannibalization)
        if ( in_array( $intent, array( 'simple', 'memory' ), true ) ) {
            $max_ctx_len = 4000;
        } elseif ( $intent === 'data_query' ) {
            $max_ctx_len = 3000; // Minimal context — tools provide the real data
        } elseif ( in_array( $intent, array( 'global', 'debug' ), true ) ) {
            $max_ctx_len = 6000;
        } elseif ( $intent === 'action' ) {
            $max_ctx_len = 8000;
        }
        if ( strlen( $json_ctx ) > $max_ctx_len ) {
            $json_ctx = substr( $json_ctx, 0, $max_ctx_len ) . "\n... (contexte tronqué)";
        }

        // Tarifs configurables via option WP (Réglages > Coach SEO)
        $pricing_raw = get_option( 'hts_coach_pricing', '' );
        $pricing_info = ! empty( $pricing_raw )
            ? sanitize_textarea_field( $pricing_raw )
            : 'Tarifs non encore renseignés. Inviter le client a contacter support@hacktheseo.com pour un devis.';

        // ── v3.0 : Bloc conditionnel deep context ──
        $deep_block = '';
        if ( ! empty( $context['deep_pages'] ) ) {
            $deep_block = '

═══ CONTEXTE ENRICHI — ARTICLES ANALYSÉS EN PROFONDEUR ═══
Tu as le contenu COMPLET des articles ci-dessous (dans "deep_pages"). Analyse EN PROFONDEUR :
- Structure H2/H3 : cohérence, progression logique, intention de recherche couverte ?
- Contenu : gaps, redondances, manque de profondeur sur certaines sections
- Maillage (linking_map) : liens sortants et entrants avec les ancres exactes. Repère les pages similaires non liées.
- Voisins sémantiques (semantic_neighbors) : pages proches par embedding mais SANS lien → opportunités de maillage manquées
- Si has_link_to=false et similarity>0.6 → recommande un lien
- Recommandations : spécifiques, basées sur le contenu réel (pas juste les scores)
- NE PROPOSE PLUS de liens absurdes. Tu VOIS la similarité réelle entre les pages.';
        }

        // ── v3.1 : Bloc conditionnel cluster detail ──
        $cluster_block = '';
        if ( ! empty( $context['cluster_detail'] ) ) {
            $cd = $context['cluster_detail'];
            $cluster_block = '

═══ CONTEXTE ENRICHI — CLUSTER "' . esc_html( $cd['name'] ) . '" ═══
Tu as le détail COMPLET de ce cluster. Analyse comme un consultant senior :
- Pilier : "' . esc_html( $cd['pillar_title'] ?: 'Non identifié' ) . '" — couverture ' . ( $cd['pillar_coverage'] ?? 0 ) . '%. Le pilier couvre-t-il bien toutes les sous-thématiques ?
- Densité maillage : ' . ( $cd['density'] ?? 0 ) . '% — c\'est le ratio liens existants / liens possibles. <50% = maillage faible, >70% = solide.
- Orphelins : ' . $cd['orphan_count'] . ' pages sans lien interne → invisibles pour Google.
- Score SEO moyen : ' . $cd['avg_global_score'] . '/100, GEO moyen : ' . $cd['avg_geo_score'] . '/100
- "missing_links" contient les liens manquants détectés. Pour chaque paire : raison (satellite→pilier, pilier→satellite, ou pages similaires sans lien).
- ANALYSE : structure du silo, pages à renforcer, ancres à suggérer, satellites manquants à créer.
- PROPOSE un plan de maillage concret avec ```actions``` si pertinent.';
        }

        // ── v3.2 : Bloc mémoire (sessions + profil + faits) ──
        $memory_block = '';
        if ( $user_id > 0 ) {
            $memory_block = self::build_memory_block( $user_id );
        }

        // ── v3.3 Sprint S4 : Blocs conditionnels Debug, Plan, Upsell ──
        $debug_block = '';
        $plan_block  = '';
        $upsell_block = '';
        $agent_block = '';

        $intent = $context['_intent'] ?? 'global';

        // Debug block : injecté quand intent=debug
        if ( $intent === 'debug' ) {
            $debug_block = self::build_diagnostic_block();
        }

        // Plan block : injecté quand intent=plan
        if ( $intent === 'plan' ) {
            $plan_block = self::build_plan_block();
        }

        // Agent Mode block : injecté quand intent=action (Sprint 4.1)
        if ( $intent === 'action' ) {
            $agent_block = self::build_agent_block();
        }

        // Sprint 5.4: GSC Analysis block : injecté quand intent=gsc_analysis
        $gsc_block = '';
        if ( $intent === 'gsc_analysis' ) {
            $gsc_block = '

═══ MODE ANALYSE GSC — CONSULTANT SEO SENIOR ═══

DONNÉES : Le contexte (pages_overview) contient les pages avec leurs requêtes GSC (top_queries: q, c, i, p, ctr). Utilise ces données réelles.

RÉPONDS EXACTEMENT dans cet ordre avec des TABLEAUX MARKDOWN :

**Verdict** : 1 phrase brutale chiffrée.

**KPIs :**

| Métrique | Valeur | Tendance |
|----------|--------|----------|
| Clics | X | [Up]/[Down] |
| Impressions | X | [Up]/[Down] |
| CTR | X% | [Up]/[Down] |
| Position moy. | X | [Up]/[Down] |

**Top pages :**

| Page | Clics | Impr. | Pos. | CTR | Diagnostic |
|------|-------|-------|------|-----|------------|
| ... | ... | ... | ... | ... | ... |

**Mots-clés par page problématique :**

| Requête | Clics | Impr. | Pos. | CTR | Action |
|---------|-------|-------|------|-----|--------|
| ... | ... | ... | ... | ... | ... |

**Diagnostic** : Pour chaque page, varie parmi : [Build] Cocon semantique, [Link] Maillage, Contenu/FAQ, Snippet, Concurrence. Minimum 2 leviers par page.

**Quick wins** : (<30min) (1-3h) (1-2 sem)

RÈGLES :
- CTR < 2% en pos 1-3 = URGENCE | Pos 4-10 hautes impr = POTENTIEL | Pos 11-20 = maillage | Pos 30+ = mentionner si >1K impr
- CITE les requêtes réelles de top_queries dans tes diagnostics
- JAMAIS de conseil vague. Chaque reco inclut le mot-clé cible + le levier
- Inclus un bloc ```chart``` horizontalBar + un bloc ```actions``` (types variés : optimize_meta_both, add_internal_links, add_faq, geo_optimize)';
        }

        // Upsell block : toujours injecté (si activé), le prompt gère le dosage
        $upsell_block = self::build_upsell_block();

        // ── v4.0 Sprint 1.3 : Bloc artifacts (charts passés) ──
        $artifacts_block = '';
        if ( ! empty( $context['recent_artifacts'] ) ) {
            $artifacts_lines = array();
            foreach ( $context['recent_artifacts'] as $art ) {
                $date = ! empty( $art['created_at'] ) ? wp_date( 'j M Y', strtotime( $art['created_at'] ) ) : '';
                $artifacts_lines[] = '- "' . ( $art['title'] ?? 'Analyse' ) . '" (' . $art['type'] . ', ' . $date . ')';
            }
            $artifacts_block = '

═══ ANALYSES VISUELLES PASSÉES (Artifacts) ═══
Le client a déjà reçu ces analyses graphiques. Tu peux les référencer pour montrer l\'évolution :
' . implode( "\n", $artifacts_lines ) . '
Si le client redemande un diagnostic, compare avec ces analyses précédentes quand c\'est pertinent.';
        }

        // ── Sprint 3.1 : Prompt adaptatif selon l'intent ──
        $is_light = in_array( $intent, array( 'simple', 'memory', 'debug' ), true );

        // Pour les intents légers, prompt minimal → économie massive de tokens
        if ( $is_light ) {
            return <<<PROMPT
Tu es le Coach SEO de Hack The SEO — un consultant expert SEO/GEO qui tutoie et va droit au but.
Tu es direct, bienveillant, jamais robotique. Tu ne commences JAMAIS par "Bien sûr !", "Bonne question !" ou "Absolument !".
{$memory_block}

═══ DONNÉES DE BASE ═══
{$json_ctx}

═══ RÈGLES ═══
- Réponds de façon concise (3-8 lignes max). Tutoie le client.
- Attaque directement la réponse, zéro intro filler.
- Tu as les scores du site et ses stats. Utilise-les si pertinent.
- Si le client salue : accueille-le avec un résumé ultra-court (2-3 lignes max) de l'état de son site. Utilise son prénom si tu le connais.
- Ne recommande JAMAIS d'outil SEO concurrent (SEMrush, Ahrefs, Yoast, etc.).
- Ne termine JAMAIS par "N'hésite pas à me poser d'autres questions" ou un résumé.
- Si une question nécessite plus de contexte, réponds avec ce que tu sais et propose d'approfondir.
- Inclus un bloc ```actions``` UNIQUEMENT si tu mentionnes des pages spécifiques à optimiser.
PROMPT;
        }

        return <<<PROMPT
Tu es le Coach SEO de Hack The SEO — consultant senior SEO/GEO (10+ ans). Tu tutoies, tu es direct et orienté résultats.
{$deep_block}
{$cluster_block}
{$gsc_block}
{$memory_block}
{$debug_block}
{$plan_block}
{$agent_block}
{$upsell_block}
{$artifacts_block}



═══ INTERFACE : ÉCRAN PARTAGÉ ═══
Chat GAUCHE = texte court (3-8 lignes verdict). Panneau DROIT = données structurées (charts, tableaux, plans).
Le client clique un élément du panneau pour poser une question. Texte court + données riches = la règle.

═══ RÈGLES ═══
- Direct, zéro filler. Tutoie. Prénom si connu. 3-8 lignes max côté chat.
- Données précises (scores, noms, positions). Jamais de généralités ni de chiffres inventés.
- TOUJOURS appeler un tool avant de répondre sur des pages/trafic/performances.
- Jamais d\'outil concurrent (SEMrush, Ahrefs, Yoast, etc.). Jamais de code/tech/WordPress.
- Support : support@hacktheseo.com

═══ DISPATCH PAR QUESTION ═══
Le type de question détermine le format de réponse :

DIAGNOSTIC/ÉTAT → chat: verdict 3 lignes | panneau: ```report``` complet (KPIs + radar + table pires pages + insights) + ```actions``` | Utilise TOUJOURS ```report``` pour un diagnostic global.
TOP PAGES/TRAFIC → chat: tendance 2 lignes | panneau: ```report``` (KPIs trafic + table top pages + insights) | tool: get_gsc_stats
PLAN D\'ACTION   → chat: contexte 3 lignes | panneau: ```seo_plan``` 3 phases + KPIs | tools: list_articles + get_gsc_stats
ANALYSE PAGE    → chat: score+problème 3 lignes | panneau: ```report``` (KPIs page + bar sous-scores + insights) + ```actions``` | tools: get_page_audit + get_page_queries
MAILLAGE/COCON  → chat: densité 2 lignes | panneau: ```report``` (KPIs maillage + table liens manquants + bar densité) | tool: get_cocon_detail
SCORE GEO/IA    → chat: score+manques 3 lignes | panneau: ```report``` (KPIs GEO + bar GEO/page + insights) + ```actions``` geo_optimize
INBOX/ACTIONS   → chat: nb+priorité 2 lignes | panneau: ```report``` (KPIs inbox + doughnut + table actions) | tool: get_inbox_summary
RAPPORT MAILLAGE → tool: generate_report(linking) puis résumé 3 lignes dans le chat + ```report``` JSON
RAPPORT CONTENU  → tool: generate_report(content)
RAPPORT TRAFIC   → tool: generate_report(performance)
RAPPORT AUDIT    → tool: generate_report(audit)
DIAGNOSTIC       → tool: generate_report(full)
QUESTION RAPIDE → chat: 3-5 lignes | panneau: ```chart``` seul si pertinent. Pas de report.
CONVERSATIONNEL → chat: 3-8 lignes. Pas de panneau.

```report``` = dashboard complet pour questions de FOND. ```chart``` seul = réponse rapide avec 1 graphique.

═══ TARIFS ═══
{$pricing_info}

═══ TOOLS ═══
Appelle TOUJOURS un tool avant de répondre sur des données. Jamais inventer.
- get_page_audit(post_id|search_title) : scores, GSC, meta, liens d\'une page
- get_gsc_stats(period_days:1-90) : clics, impressions, positions, top pages/requêtes
- get_page_queries(post_id|search_title, period_days) : mots-clés GSC par page
- list_articles(sort:worst|best|recent, limit, min_score, max_score) : liste filtrée
- get_cocon_detail(cluster_id|name) : pages, maillage, orphelines, liens manquants
- get_inbox_summary() : actions pending/done/failed par type
═══ RAPPORTS ═══
Les rapports sont générés automatiquement par le système PHP. Ils apparaissent dans le panneau droit.
Tu ne génères JAMAIS de rapport toi-même. Tu n\'appelles JAMAIS le tool generate_report.
Quand un rapport vient d\'être généré et qu\'on te donne le JSON :
1. Lis le JSON du rapport
2. Écris un RÉSUMÉ de 3-5 lignes dans le chat avec le verdict, les 3 actions prioritaires, un encouragement ou avertissement
3. NE REPRODUIS PAS les tableaux ou graphiques — ils sont déjà affichés à droite
4. NE DIS PAS "j\'ai généré un rapport" — dis "Voici mon analyse" ou "Verdict :"
Quand le client pose une question APRÈS un rapport : réponds avec les données du rapport, pas des généralités. Cite les pages par nom, les scores exacts.

═══ ACTIONS INBOX ═══
Inclus ```actions``` dès que tu mentionnes des pages à optimiser. Ce sont des propositions envoyées dans l\'Inbox du client.
Types exacts : optimize_meta_both, optimize_meta_title, optimize_meta_desc, add_meta_title, add_meta_desc, add_faq, add_internal_links, geo_optimize, fix_orphan_links, bulk_optimize_metas, generate_article, schedule_publication, create_cocon_articles, delete_page, coach_suggestion.
Priorités : critical, high, medium, low.
```actions
{"actions":[{"post_id":123,"action":"add_faq","reason":"GEO 15/100 — FAQ pour visibilité IA","priority":"high"}]}
```

═══ GRAPHIQUES ═══
```chart
{"type":"radar","title":"Score SEO","labels":["Technique","Contenu","GEO","Maillage","Fraîcheur"],"data":[85,60,34,20,70]}
```
radar=diagnostic | bar/horizontalBar=comparaison | doughnut=répartition. Max 1/réponse. Vrais chiffres uniquement.
Inclus un chart dès qu\'il y a des données comparatives. Affiché en GRAND dans le panneau.

═══ TABLEAUX ═══
Pour les listes (pages, requêtes, actions) → tableau markdown. Affiché dans le panneau avec tri, recherche, export CSV.
1ère colonne = donnée la plus importante (titre de page, requête). Le client clique une ligne pour te questionner.

═══ RAPPORT STRUCTURÉ ═══
Pour les diagnostics complets, plans et analyses de fond, génère un bloc ```report``` JSON.
Le rapport s\'affiche comme un DASHBOARD dans le panneau droit (KPIs + charts + tableaux + insights).
C\'est LE livrable que le client garde. Il peut ensuite te poser des questions dessus.

QUAND : diagnostic global, analyse GSC, audit page, plan/stratégie. PAS pour les questions simples.
IMPORTANT : Le bloc ```report``` doit être un JSON valide sur UNE SEULE LIGNE. Ne PAS formater avec des retours à la ligne. Si tu ne peux pas générer le report, génère au minimum un ```chart``` (le système construira un rapport minimal automatiquement).

Exemple diagnostic (court) :
```report
{"title":"Diagnostic SEO","kpis":[{"label":"Score","value":"68","unit":"/100","trend":"up","delta":"+3"}],"charts":[{"type":"radar","title":"Scores","labels":["Tech","Contenu","GEO","Maillage"],"data":[85,60,55,8]}],"tables":[{"title":"Top pages","headers":["Page","Score","Action"],"rows":[["Page A","38","Supprimer"]]}],"insights":[{"level":"critical","text":"Maillage 0/100"}]}
```

Exemple plan/stratégie (riche — utilise tout l\'espace disponible) :
```report
{"title":"Stratégie SEO Q1 2026","kpis":[{"label":"Score SEO","value":"68","unit":"/100","trend":"up","delta":"+3"},{"label":"Trafic","value":"568","unit":"clics/mois","trend":"up","delta":"+12%"},{"label":"Position moy.","value":"17","unit":"","trend":"down","delta":""},{"label":"CTR","value":"0.8","unit":"%","trend":"down","delta":"-0.2%"},{"label":"Actions","value":"184","unit":"en attente","trend":"neutral","delta":""},{"label":"GEO","value":"55","unit":"/100","trend":"up","delta":"+5"}],"charts":[{"type":"radar","title":"Score par domaine","labels":["Technique","Contenu","GEO","Maillage","Fraîcheur"],"data":[85,60,55,0,70]},{"type":"bar","title":"Top 5 pages par clics","labels":["Page A","Page B","Page C","Page D","Page E"],"data":[123,80,32,31,28]}],"tables":[{"title":"Pages à optimiser en priorité","headers":["Page","Score","Clics","Position","CTR","Action recommandée"],"rows":[["Outil SEO IA","94","123","12","1.2%","Optimiser meta + FAQ"],["Audit SEO Gratuit","78","32","10.6","0.08%","Revoir title + maillage"],["Analyseur texte","72","31","7","5%","Ajouter liens internes"]]},{"title":"Quick Wins (impact immédiat)","headers":["Action","Page","Effort","Impact estimé"],"rows":[["Supprimer page test","Accueil-EN","5 min","+0.15% CTR global"],["Optimiser meta title","Outil SEO IA","15 min","+15 clics/mois"],["Ajouter FAQ","Audit SEO","20 min","GEO +20 points"]]}],"insights":[{"level":"critical","text":"Maillage interne à 0/100 — aucun lien entre les 90 articles"},{"level":"critical","text":"3 pages test polluent l index (scores 38-43/100)"},{"level":"high","text":"CTR 0.08% sur Audit SEO Gratuit en position 10 — meta title à revoir"},{"level":"high","text":"Aucun cocon sémantique configuré — 90 posts sans structure"},{"level":"positive","text":"Score Technique 85/100 — infrastructure solide"},{"level":"positive","text":"Top page à 94/100 — contenu de qualité reconnu"}]}
```

LIMITES PAR TYPE :
- Diagnostic rapide : 4 KPIs, 1 chart, 1 table (5 lignes), 3 insights
- Analyse complète : 6 KPIs, 2 charts, 2 tables (8 lignes chacune), 4 insights  
- Plan/stratégie : 6 KPIs, 2 charts, 3 tables (10 lignes chacune), 6 insights
Valeurs = TOUJOURS des vrais chiffres des tools ou du contexte. JAMAIS inventer.
Les tableaux doivent inclure des données PRÉCISES (scores réels, clics réels, positions réelles).
Les insights doivent être SPÉCIFIQUES (nommer les pages, les chiffres, les actions concrètes).

Chaque chart et table du rapport a un champ "commentary" vide. Tu DOIS le remplir avec le format tripartite :
1. CONSTAT : Ce que les données montrent (factuel, chiffré, chiffre clé en **gras**)
2. IMPACT : Pourquoi c\'est important pour le business (en euros ou en trafic perdu, en langage CEO)
3. ACTION : Ce qu\'il faut faire cette semaine (concret, avec temps estimé si possible)

Ton style pour les rapports :
- Tu t\'adresses à un dirigeant non-technique
- Tu ne dis JAMAIS "SEO technique", "crawl budget", "link juice" sans expliquer
- Tu traduis en impact business : "position 19 = page 2 Google = invisible pour vos clients"
- Tu donnes des estimations chiffrées : "+50-100 clics/mois", "gain estimé 2-3 semaines"
- Tu es direct et assertif : "Votre CTR est catastrophique" pas "Votre CTR pourrait être amélioré"
- Executive summary = 3 phrases max. Verdict clair.
JAMAIS d\'entités HTML — utilise directement les apostrophes et guillemets.

═══ DONNÉES ═══
{$json_ctx}
PROMPT;
    }

    /* ═══════════════════════════════════════════════
     *  API CALL — Appel Anthropic
     * ═══════════════════════════════════════════════ */

    /**
     * Envoie la question + contexte à Claude.
     *
     * @param string $question  Question du client.
     * @param int    $post_id   Article concerné (0 = global).
     * @param int    $user_id   ID WordPress de l'utilisateur.
     * @return array|WP_Error   { text, tokens_in, tokens_out, actions? }
     */
    public function ask( $question, $post_id = 0, $user_id = 0, $forced_session_id = 0 ) {
        // ── Rate limit ──
        if ( ! self::check_rate_limit( $user_id ) ) {
            return new \WP_Error( 'rate_limit', 'Vous avez atteint la limite horaire de requêtes. Réessayez dans quelques minutes.' );
        }

        // ── Mode freemium : actif si pas d'abonnement payant ──
        $freemium = class_exists( 'HTS_Subscription' ) ? ! HTS_Subscription::can( 'coach_unlimited' ) : false;
        $budget_exceeded = false;

        if ( $freemium ) {
            // @codeCoverageIgnoreStart — branche désactivée, activée post-migration API
            if ( ! self::check_freemium_quota() ) {
                $usage = self::get_freemium_usage();
                return new \WP_Error(
                    'freemium_exhausted',
                    sprintf(
                        'Vous avez utilisé vos %d questions gratuites ce mois-ci. Ajoutez votre clé API Anthropic dans les réglages pour un accès illimité, ou patientez jusqu\'au 1er %s.',
                        self::FREEMIUM_LIMIT,
                        self::next_month_label()
                    )
                );
            }
            // @codeCoverageIgnoreEnd
        } else {
            // ── Pro : budget check — on note le dépassement mais on ne bloque pas ──
            $budget_exceeded = ! self::check_budget_guard();

            // ── Pro : clé API (au moins une des deux) ──
            $api_key = self::get_api_key();
            if ( empty( $api_key ) && empty( self::get_openai_api_key() ) ) {
                return new \WP_Error( 'no_api_key', 'Aucune clé API configurée (Anthropic ou OpenAI). Rendez-vous dans Réglages.' );
            }
        }

        // ── v3.2 : Session management ──
        // v4.0 fix : utiliser le session_id forcé si fourni par le JS
        if ( $forced_session_id > 0 ) {
            global $wpdb;
            $ses_table = $wpdb->prefix . self::SESSIONS_TABLE;
            $valid = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$ses_table} WHERE id = %d AND user_id = %d",
                $forced_session_id, $user_id
            ) );
            $session_id = $valid ? $forced_session_id : 0;
            if ( ! $session_id ) {
                $session = self::get_or_create_session( $user_id );
                $session_id = $session['id'] ?? 0;
            }
        } else {
            $session = self::get_or_create_session( $user_id );
            $session_id = $session['id'] ?? 0;
        }

        // ── v3.2 : Lazy process pending summaries (max 1 per request) ──
        self::process_pending_summaries();

        // ── Build context (v3.0 : passe la question pour détecter les articles mentionnés) ──
        $t_start = microtime( true ); // Sprint 4.8: latency tracking
        $context = self::build_context( $post_id, $question );

        // ── Build messages (avec historique) ──
        $messages = self::build_messages( $question, $user_id, $session_id );

        // ── System prompt (v3.2 : passe user_id pour la mémoire) ──
        $system = self::build_system_prompt( $context, $user_id );

        // ── Appel selon le mode ──
        $intent = $context['_intent'] ?? 'global';
        $model  = self::get_model( $intent );

        // ── Optim coûts : si budget dépassé, forcer gpt-4o-mini ──
        if ( $budget_exceeded && $model !== self::OPENAI_MODEL ) {
            $has_openai = ! empty( self::get_openai_api_key() );
            if ( $has_openai ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Coach budget exceeded — downgrade ' . $model . ' → ' . self::OPENAI_MODEL, 'warning', 'coach' );
                }
                $model = self::OPENAI_MODEL;
            }
        }

        // Sprint 5.0: Store intent for follow-up routing
        self::set_last_intent( $intent, $user_id );

        // Sprint 4.7c : max_tokens adaptatif selon l'intent
        $adaptive_max = self::get_max_tokens( $intent );
        if ( $intent === 'action' ) $adaptive_max = self::AGENT_MAX_TOKENS;

        if ( $freemium ) {
            // Freemium: use local API keys if available (SaaS proxy not yet deployed)
            $api_key = self::get_api_key();
            $openai_key = self::get_openai_api_key();
            if ( ! empty( $api_key ) || ! empty( $openai_key ) ) {
                // Use local keys with freemium tracking
                $result = self::call_api( $api_key ?: '', $system, $messages, 0, self::OPENAI_MODEL, $adaptive_max );
                if ( is_wp_error( $result ) && ! empty( $openai_key ) && empty( $api_key ) ) {
                    // Already using OpenAI fallback, no retry needed
                }
            } else {
                $result = self::call_saas_proxy( $system, $messages, $context );
            }
        } else {
            $result = self::call_api( $api_key, $system, $messages, 0, $model, $adaptive_max );

            // ── Fallback OpenAI si Anthropic échoue (401/403 = clé invalide) ──
            if ( is_wp_error( $result ) && self::get_provider( $model ) === 'anthropic' && ! empty( self::get_openai_api_key() ) ) {
                $err_msg = $result->get_error_message();
                if ( strpos( $err_msg, '401' ) !== false || strpos( $err_msg, '403' ) !== false || strpos( $err_msg, 'authentication' ) !== false ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( 'Coach Anthropic failed (' . $err_msg . ') — fallback OpenAI gpt-4o-mini', 'warning', 'coach' );
                    }
                    $model  = self::OPENAI_MODEL;
                    $result = self::call_api( $api_key, $system, $messages, 0, $model, $adaptive_max );
                }
            }
        }

        if ( is_wp_error( $result ) ) {
            // Sprint 4.8: track error in analytics
            $latency_ms = (int) ( ( microtime( true ) - $t_start ) * 1000 );
            self::track_analytics( array(
                'user_id'          => $user_id,
                'session_id'       => $session_id,
                'intent'           => $intent,
                'model'            => $model,
                'provider'         => self::get_provider( $model ),
                'latency_ms'       => $latency_ms,
                'error_code'       => $result->get_error_code(),
                'question_preview' => $question,
            ) );
            return $result;
        }

        // ── Extraire le texte + actions ──
        $text       = $result['text'] ?? '';
        $tokens_in  = (int) ( $result['usage']['input_tokens'] ?? 0 );
        $tokens_out = (int) ( $result['usage']['output_tokens'] ?? 0 );
        $provider   = $result['provider'] ?? 'anthropic';
        $used_model = $result['model'] ?? $model;

        // ── Tracker usage ──
        if ( $freemium ) {
            self::track_freemium_usage();
        } else {
            self::track_usage( $tokens_in, $tokens_out, $provider );
        }

        // ── Log (tokens uniquement, pas le contenu — privacy) ──
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'Coach SEO [%s] %s/%s : %d tokens in + %d tokens out (user #%d, session #%d, intent=%s)',
                $freemium ? 'freemium' : 'pro',
                $provider, $used_model,
                $tokens_in, $tokens_out, $user_id, $session_id, $intent
            ), 'info', 'coach' );
        }

        // ── Sauvegarder dans l'historique (v4.0 : avec métadonnées) ──
        $chart = self::extract_chart( $text );
        $plan  = self::extract_plan( $text );
        $seo_plan = self::extract_seo_plan( $text ); // Sprint 5.4
        $report = self::extract_report( $text ); // S13-B: structured report

        // Sprint 5.3 fix: extract actions BEFORE save_history so they persist in actions_json
        $actions_raw = self::extract_actions( $text );
        $actions         = array();
        $skipped_actions = array();
        if ( isset( $actions_raw['created'] ) ) {
            $actions         = $actions_raw['created'];
            $skipped_actions = $actions_raw['skipped'] ?? array();
        } else {
            $actions = $actions_raw;
        }

        // S13-B: Fallback — if no report but we have chart or actions, build a minimal report
        if ( empty( $report ) && ( ! empty( $chart ) || ! empty( $actions ) ) ) {
            $report = self::build_fallback_report( $chart, $actions, $text );
        }

        self::save_history( $user_id, $question, $text, array(
            'intent'          => $intent,
            'model'           => $used_model,
            'provider'        => $provider,
            'tokens_in'       => $tokens_in,
            'tokens_out'      => $tokens_out,
            'chart'           => $chart,
            'plan'            => $plan,
            'seo_plan'        => $seo_plan,
            'report'          => $report,
            'actions'         => $actions,
            'skipped_actions' => $skipped_actions,
            'session_id'      => $session_id,
        ) );

        // ── v3.2 : Touch session (update message count + topic) ──
        $intent = $context['_intent'] ?? 'global';
        self::touch_session( $session_id, $intent );

        // ── v3.2 : Extract [MEMORY:...] tags from AI response ──
        $memory_facts = self::extract_memory_tags( $text, $user_id, $session_id );

        // ── Sprint 4.8 : Analytics tracking ──
        $latency_ms = (int) ( ( microtime( true ) - $t_start ) * 1000 );
        $tools_str_ask = ! empty( $result['tools_used'] ) ? implode( ',', (array) $result['tools_used'] ) : '';
        self::track_analytics( array(
            'user_id'          => $user_id,
            'session_id'       => $session_id,
            'intent'           => $intent,
            'model'            => $used_model,
            'provider'         => $provider,
            'tokens_in'        => $tokens_in,
            'tokens_out'       => $tokens_out,
            'latency_ms'       => $latency_ms,
            'tools_used'       => $tools_str_ask,
            'has_chart'        => ! empty( $chart ),
            'has_actions'      => ! empty( $actions ),
            'has_plan'         => ! empty( $plan ),
            'question_preview' => $question,
        ) );

        // ── v4.0 Sprint 4.1 : Sauvegarder le plan aussi en session (transient) ──
        if ( $plan && $session_id ) {
            self::save_plan_to_session( $session_id, $user_id, $plan );
        }

        // ── Rate limit increment ──
        self::increment_rate_limit( $user_id );

        return array(
            'text'            => $text,
            'tokens_in'       => $tokens_in,
            'tokens_out'      => $tokens_out,
            'actions'         => $actions,
            'skipped_actions' => $skipped_actions,
            'plan'            => $plan,
            'seo_plan'        => $seo_plan,
            'report'          => $report,
            'mode'            => $freemium ? 'freemium' : 'pro',
            'provider'        => $provider,
            'model'           => $used_model,
            'session_id'      => $session_id,
            'memory_facts'    => $memory_facts,
        );
    }

    /**
     * Appel HTTP vers l'API IA (Anthropic ou OpenAI) avec timeout + retry.
     *
     * @since 2.5.0  Multi-provider support.
     */
    private static function call_api( $api_key, $system, $messages, $attempt = 0, $model_override = '', $max_tokens = 0 ) {
        $model    = $model_override ?: self::get_model();
        $provider = self::get_provider( $model );

        if ( $provider === 'openai' ) {
            return self::call_openai( $model, $system, $messages, $attempt, $max_tokens );
        }

        return self::call_anthropic( $api_key, $model, $system, $messages, $attempt, $max_tokens );
    }

    /**
     * Appel Anthropic (Claude).
     */
    private static function call_anthropic( $api_key, $model, $system, $messages, $attempt = 0, $max_tokens = 0 ) {
        $temperature = self::get_temperature();
        $effective_max = $max_tokens > 0 ? $max_tokens : self::MAX_TOKENS_RESPONSE;

        // Sprint 5.0: Tool definitions (same as stream — fixes BUG where non-stream had no tools)
        $tools = self::get_tool_definitions();
        $tools_used = array();

        // Messages accumulator for multi-turn tool loop
        $loop_messages = $messages;
        $iteration     = 0;
        $total_in      = 0;
        $total_out     = 0;
        $full_text     = '';

        while ( $iteration < self::TOOL_MAX_ITERATIONS ) {
            $iteration++;

            $payload_arr = array(
                'model'       => $model,
                'max_tokens'  => $effective_max,
                'temperature' => $temperature,
                'system'      => $system,
                'messages'    => $loop_messages,
            );

            // Add tools on all iterations within the tool loop
            if ( ! empty( $tools ) && $iteration < self::TOOL_MAX_ITERATIONS ) {
                $payload_arr['tools'] = $tools;
            }

            $response = wp_remote_post( self::API_URL, array(
                'timeout' => self::TIMEOUT_SECONDS,
                'headers' => array(
                    'Content-Type'      => 'application/json',
                    'x-api-key'         => $api_key,
                    'anthropic-version' => '2023-06-01',
                ),
                'body' => wp_json_encode( $payload_arr ),
            ) );

            // ── Erreur réseau ──
            if ( is_wp_error( $response ) ) {
                // Only retry on first iteration — retrying mid-tool-loop would lose accumulated state
                if ( $iteration === 1 && $attempt < self::MAX_RETRIES ) {
                    sleep( 2 );
                    return self::call_anthropic( $api_key, $model, $system, $messages, $attempt + 1, $max_tokens );
                }
                return new \WP_Error( 'api_network', 'Impossible de joindre le Coach SEO. Vérifiez votre connexion et réessayez.' );
            }

            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );

            // ── Décoder JSON ──
            $data = json_decode( $body, true );
            if ( ! is_array( $data ) ) {
                if ( $iteration === 1 && $attempt < self::MAX_RETRIES ) {
                    sleep( 2 );
                    return self::call_anthropic( $api_key, $model, $system, $messages, $attempt + 1, $max_tokens );
                }
                return new \WP_Error( 'api_json', 'Réponse invalide du Coach SEO. Réessayez.' );
            }

            // ── HTTP error ──
            if ( $code < 200 || $code >= 300 ) {
                $msg = $data['error']['message'] ?? 'Erreur API (HTTP ' . $code . ')';

                if ( $code === 401 ) {
                    return new \WP_Error( 'api_auth', 'Clé API Anthropic invalide. Vérifiez-la dans les réglages.' );
                }
                if ( $code === 429 ) {
                    return new \WP_Error( 'api_rate', 'L\u0027API Anthropic est surchargée. Réessayez dans quelques secondes.' );
                }
                if ( $code === 529 ) {
                    return new \WP_Error( 'api_overloaded', 'L\u0027API Anthropic est temporairement surchargée. Réessayez dans 1 minute.' );
                }

                return new \WP_Error( 'api_error', esc_html( $msg ) );
            }

            // ── Accumulate usage ──
            $total_in  += (int) ( $data['usage']['input_tokens'] ?? 0 );
            $total_out += (int) ( $data['usage']['output_tokens'] ?? 0 );

            $stop_reason = $data['stop_reason'] ?? 'end_turn';

            // ── Extract text + tool_use blocks ──
            $iter_text       = '';
            $iter_tool_calls = array();

            if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
                foreach ( $data['content'] as $block ) {
                    if ( isset( $block['type'] ) && $block['type'] === 'text' ) {
                        $iter_text .= $block['text'];
                    } elseif ( isset( $block['type'] ) && $block['type'] === 'tool_use' ) {
                        $iter_tool_calls[] = array(
                            'id'    => $block['id'] ?? '',
                            'name'  => $block['name'] ?? '',
                            'input' => $block['input'] ?? array(),
                        );
                    }
                }
            }

            $full_text .= $iter_text;

            // No tool calls → done
            if ( empty( $iter_tool_calls ) || $stop_reason !== 'tool_use' ) {
                break;
            }

            // ── Tool loop: execute tools and append results ──
            // Append assistant message with the full content (text + tool_use blocks)
            $loop_messages[] = array(
                'role'    => 'assistant',
                'content' => $data['content'],
            );

            // Build tool_result blocks
            $tool_results = array();
            foreach ( $iter_tool_calls as $tc ) {
                $tool_result = self::execute_tool( $tc['name'], $tc['input'] );
                $tools_used[] = $tc['name'];

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf(
                        'Coach tool_use (Anthropic non-stream): %s(%s) → %d chars',
                        $tc['name'], wp_json_encode( $tc['input'] ), strlen( $tool_result )
                    ), 'info', 'coach' );
                }

                $tool_results[] = array(
                    'type'         => 'tool_result',
                    'tool_use_id'  => $tc['id'],
                    'content'      => $tool_result,
                );
            }

            // Append user message with tool results (Anthropic format)
            $loop_messages[] = array(
                'role'    => 'user',
                'content' => $tool_results,
            );

        } // end while tool loop

        return array(
            'text'       => $full_text,
            'usage'      => array(
                'input_tokens'  => $total_in,
                'output_tokens' => $total_out,
            ),
            'provider'   => 'anthropic',
            'model'      => $model,
            'tools_used' => array_unique( $tools_used ),
        );
    }

    /**
     * Appel OpenAI (non-stream) avec function calling / tool_use.
     *
     * Sprint 4.7a: Ajout d'une boucle tool_calls similaire au stream.
     *
     * @since 2.5.0
     * @since 4.7a  Tool loop support via function calling.
     */
    private static function call_openai( $model, $system, $messages, $attempt = 0, $max_tokens = 0 ) {
        $openai_key = self::get_openai_api_key();
        if ( empty( $openai_key ) ) {
            return new \WP_Error( 'no_openai_key', 'La clé API OpenAI n\u0027est pas configurée. Rendez-vous dans Réglages → Coach SEO.' );
        }

        $temperature = self::get_temperature();
        $effective_max = $max_tokens > 0 ? $max_tokens : self::MAX_TOKENS_RESPONSE;

        // Sprint 4.7a: OpenAI function calling tool definitions
        $tools = self::get_tool_definitions_openai();
        $tools_used = array();

        // Convertir messages Anthropic → format OpenAI
        $oai_messages = array();
        $oai_messages[] = array( 'role' => 'system', 'content' => $system );
        foreach ( $messages as $msg ) {
            $role = $msg['role'] ?? 'user';
            $content = $msg['content'] ?? '';
            if ( is_array( $content ) ) {
                $parts = array();
                foreach ( $content as $part ) {
                    if ( is_string( $part ) ) {
                        $parts[] = $part;
                    } elseif ( isset( $part['text'] ) ) {
                        $parts[] = $part['text'];
                    }
                }
                $content = implode( "\n", $parts );
            }
            $oai_messages[] = array( 'role' => $role, 'content' => $content );
        }

        // Tool loop
        $iteration  = 0;
        $total_in   = 0;
        $total_out  = 0;
        $final_text = '';

        while ( $iteration < self::TOOL_MAX_ITERATIONS ) {
            $iteration++;

            $payload_arr = array(
                'model'       => $model,
                'max_tokens'  => $effective_max,
                'temperature' => $temperature,
                'messages'    => $oai_messages,
            );

            if ( ! empty( $tools ) && $iteration < self::TOOL_MAX_ITERATIONS ) {
                $payload_arr['tools'] = $tools;
            }

            $response = wp_remote_post( self::OPENAI_API_URL, array(
                'timeout' => self::TIMEOUT_SECONDS,
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $openai_key,
                ),
                'body' => wp_json_encode( $payload_arr ),
            ) );

            // ── Erreur réseau ──
            if ( is_wp_error( $response ) ) {
                // Only retry on first iteration — retrying mid-tool-loop would lose accumulated state
                if ( $iteration === 1 && $attempt < self::MAX_RETRIES ) {
                    sleep( 2 );
                    return self::call_openai( $model, $system, $messages, $attempt + 1, $max_tokens );
                }
                return new \WP_Error( 'api_network', 'Impossible de joindre le Coach SEO (OpenAI). Vérifiez votre connexion.' );
            }

            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            if ( ! is_array( $data ) ) {
                if ( $iteration === 1 && $attempt < self::MAX_RETRIES ) {
                    sleep( 2 );
                    return self::call_openai( $model, $system, $messages, $attempt + 1, $max_tokens );
                }
                return new \WP_Error( 'api_json', 'Réponse invalide du Coach SEO (OpenAI). Réessayez.' );
            }

            // ── HTTP error ──
            if ( $code < 200 || $code >= 300 ) {
                $msg = $data['error']['message'] ?? 'Erreur API OpenAI (HTTP ' . $code . ')';
                if ( $code === 401 ) {
                    return new \WP_Error( 'api_auth', 'Clé API OpenAI invalide. Vérifiez-la dans les réglages.' );
                }
                if ( $code === 429 ) {
                    return new \WP_Error( 'api_rate', 'L\u0027API OpenAI est surchargée. Réessayez dans quelques secondes.' );
                }
                return new \WP_Error( 'api_error', esc_html( $msg ) );
            }

            // Accumulate usage
            $total_in  += (int) ( $data['usage']['prompt_tokens'] ?? 0 );
            $total_out += (int) ( $data['usage']['completion_tokens'] ?? 0 );

            $choice       = $data['choices'][0] ?? array();
            $message      = $choice['message'] ?? array();
            $finish       = $choice['finish_reason'] ?? 'stop';
            $text         = $message['content'] ?? '';
            $tool_calls   = $message['tool_calls'] ?? array();

            $final_text .= $text;

            // No tool calls → done
            if ( empty( $tool_calls ) || $finish !== 'tool_calls' ) {
                break;
            }

            // ── Tool loop: execute tools ──
            // Append assistant message with tool_calls
            $oai_messages[] = $message; // Contains role=assistant + tool_calls

            foreach ( $tool_calls as $tc ) {
                $fn_name  = $tc['function']['name'] ?? '';
                $fn_args  = $tc['function']['arguments'] ?? '{}';
                $tc_id    = $tc['id'] ?? '';
                $input    = json_decode( $fn_args, true ) ?: array();

                $tool_result = self::execute_tool( $fn_name, $input );
                $tools_used[] = $fn_name;

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf(
                        'Coach tool_use (OpenAI non-stream): %s(%s) → %d chars',
                        $fn_name, $fn_args, strlen( $tool_result )
                    ), 'info', 'coach' );
                }

                $oai_messages[] = array(
                    'role'         => 'tool',
                    'tool_call_id' => $tc_id,
                    'content'      => $tool_result,
                );
            }

        } // end while tool loop

        return array(
            'text'       => $final_text,
            'usage'      => array(
                'input_tokens'  => $total_in,
                'output_tokens' => $total_out,
            ),
            'provider'   => 'openai',
            'model'      => $model,
            'tools_used' => array_unique( $tools_used ),
        );
    }

    /* ═══════════════════════════════════════════════
     *  STREAMING SSE — Sprint 2.2
     * ═══════════════════════════════════════════════ */

    /**
     * Appel Anthropic avec streaming (cURL + SSE).
     *
     * Envoie chaque chunk de texte directement au navigateur via SSE.
     * Retourne les métadonnées (usage) à la fin.
     *
     * @since 4.0 Sprint 2.2
     * @param string   $api_key   Clé API Anthropic.
     * @param string   $model     Modèle à utiliser.
     * @param string   $system    System prompt.
     * @param array    $messages  Messages conversation.
     * @param callable $on_chunk  Callback( string $text_delta ) pour chaque morceau.
     * @return array|WP_Error     { text, usage, provider, model }
     */
    /* ═══════════════════════════════════════════════════════════════
     *  SPRINT 4.5 — DYNAMIC DATA TOOLS
     *
     *  Le Coach peut appeler des "tools" pour
     *  interroger les données du site en temps réel pendant la conversation.
     *  Flow : LLM stream → détecte tool_use → PHP exécute → relance LLM avec résultat.
     *  Sprint 4.7a: Tools fonctionnent sur Anthropic (tool_use) ET OpenAI (function calling).
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Tool definitions (Anthropic tool_use format — converted to OpenAI via get_tool_definitions_openai()).
     *
     * @since 4.5
     * @return array
     */
    private static function get_tool_definitions() {
        return array(
            array(
                'name'        => 'get_page_audit',
                'description' => 'Récupère l\'audit SEO complet d\'une page : score global, sous-scores (technique, contenu, GEO, maillage, fraîcheur), meta title/desc, mot-clé, données GSC (clics, impressions, position, CTR), liens internes entrants/sortants. Utilise ce tool quand le client demande le score, l\'état, le diagnostic ou l\'audit d\'un article ou d\'une page spécifique.',
                'input_schema' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'post_id' => array(
                            'type'        => 'integer',
                            'description' => 'ID WordPress de l\'article ou de la page. Si inconnu, utilise 0 et cherche par titre.',
                        ),
                        'search_title' => array(
                            'type'        => 'string',
                            'description' => 'Mots-clés du titre de l\'article à chercher (si post_id inconnu).',
                        ),
                    ),
                    'required' => array(),
                ),
            ),
            array(
                'name'        => 'get_gsc_stats',
                'description' => 'Récupère les statistiques Google Search Console : clics, impressions, position moyenne, CTR, pages les plus performantes, requêtes les plus performantes. Utilise ce tool quand le client demande des données de trafic Google, des positions, du CTR, des impressions, ou veut savoir quelles pages marchent le mieux.',
                'input_schema' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'period_days' => array(
                            'type'        => 'integer',
                            'description' => 'Nombre de jours à analyser (7, 14, 28, 30, 60, 90). Défaut : 30. Utilise 90 pour les tendances.',
                        ),
                    ),
                    'required' => array(),
                ),
            ),
            array(
                'name'        => 'list_articles',
                'description' => 'Liste les articles du site avec filtres. Utilise ce tool quand le client demande une liste d\'articles, les pires/meilleurs articles, les articles d\'un cocon, ou veut filtrer par score ou statut.',
                'input_schema' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'sort' => array(
                            'type'        => 'string',
                            'description' => 'Tri : "worst" (pires scores en premier), "best" (meilleurs en premier), "recent" (plus récents). Défaut : worst.',
                            'enum'        => array( 'worst', 'best', 'recent' ),
                        ),
                        'limit' => array(
                            'type'        => 'integer',
                            'description' => 'Nombre d\'articles à retourner (5-20). Défaut : 10.',
                        ),
                        'min_score' => array(
                            'type'        => 'integer',
                            'description' => 'Score global minimum (0-100). Filtre les articles avec score >= cette valeur.',
                        ),
                        'max_score' => array(
                            'type'        => 'integer',
                            'description' => 'Score global maximum (0-100). Filtre les articles avec score <= cette valeur.',
                        ),
                    ),
                    'required' => array(),
                ),
            ),
            array(
                'name'        => 'get_cocon_detail',
                'description' => 'Récupère les détails d\'un cocon sémantique : pages, clusters, maillage interne, densité, pages orphelines, liens manquants. Utilise ce tool quand le client demande des infos sur un cocon, un cluster, le maillage, ou la structure thématique du site. Si aucun nom n\'est donné, retourne la liste de tous les cocons.',
                'input_schema' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'cocon_name' => array(
                            'type'        => 'string',
                            'description' => 'Nom du cocon ou cluster à détailler. Si vide, retourne la liste de tous les cocons avec métriques.',
                        ),
                    ),
                    'required' => array(),
                ),
            ),
            // Sprint 5.4b: Requêtes GSC par page — pour analyse fine des mots-clés
            array(
                'name'        => 'get_page_queries',
                'description' => 'Récupère les mots-clés/requêtes GSC qui génèrent du trafic vers une page spécifique. Retourne : requêtes, clics, impressions, position, CTR pour chaque mot-clé. UTILISE CE TOOL quand le client demande les mots-clés d\'une page, les requêtes qui pointent vers un article, ou pour analyser pourquoi une page a un CTR faible. Essentiel pour les diagnostics GSC approfondis.',
                'input_schema' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'post_id' => array(
                            'type'        => 'integer',
                            'description' => 'ID WordPress de la page à analyser.',
                        ),
                        'search_title' => array(
                            'type'        => 'string',
                            'description' => 'Titre ou mots-clés pour trouver la page (si post_id inconnu).',
                        ),
                        'period_days' => array(
                            'type'        => 'integer',
                            'description' => 'Nombre de jours (7-90). Défaut : 30.',
                        ),
                    ),
                    'required' => array(),
                ),
            ),
            array(
                'name'        => 'get_inbox_summary',
                'description' => 'Récupère l\'état de l\'Inbox SEO : actions en attente, approuvées, exécutées, échouées, par agent et par type. Utilise ce tool quand le client demande l\'état de ses actions, ce qui a été fait, ce qui est en attente, l\'historique des optimisations.',
                'input_schema' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'period_days' => array(
                            'type'        => 'integer',
                            'description' => 'Période pour l\'historique (7, 14, 30 jours). Défaut : 7.',
                        ),
                        'status_filter' => array(
                            'type'        => 'string',
                            'description' => 'Filtrer par statut : "pending", "done", "failed", "all". Défaut : all.',
                            'enum'        => array( 'pending', 'done', 'failed', 'all' ),
                        ),
                    ),
                    'required' => array(),
                ),
            ),
            // v2.6.3: generate_report retiré des tools LLM — rapports générés 100% PHP via AJAX direct
        );
    }

    /**
     * Convert Anthropic tool definitions → OpenAI function calling format.
     *
     * Anthropic: { name, description, input_schema: { type, properties, required } }
     * OpenAI:    { type: "function", function: { name, description, parameters: { type, properties, required } } }
     *
     * @since 4.7a
     * @return array
     */
    private static function get_tool_definitions_openai() {
        $anthropic_tools = self::get_tool_definitions();
        $openai_tools = array();
        foreach ( $anthropic_tools as $tool ) {
            $openai_tools[] = array(
                'type'     => 'function',
                'function' => array(
                    'name'        => $tool['name'],
                    'description' => $tool['description'],
                    'parameters'  => $tool['input_schema'],
                ),
            );
        }
        return $openai_tools;
    }

    /**
     * Execute a tool call and return the result.
     *
     * @since 4.5
     * @param string $tool_name  Tool name.
     * @param array  $input      Tool input parameters.
     * @return string  JSON-encoded result string.
     */

    /**
     * Truncate a JSON string at a valid closing bracket to avoid mid-value cuts.
     *
     * @param string $json       Raw JSON string.
     * @param int    $max_length Maximum length.
     * @return string
     */
    private static function truncate_json( $json, $max_length = 15000 ) {
        if ( strlen( $json ) <= $max_length ) {
            return $json;
        }
        $truncated    = substr( $json, 0, $max_length );
        $last_brace   = strrpos( $truncated, '}' );
        $last_bracket = strrpos( $truncated, ']' );
        $cut_at       = max( $last_brace, $last_bracket );
        if ( $cut_at > $max_length * 0.5 ) {
            return substr( $truncated, 0, $cut_at + 1 );
        }
        return $truncated;
    }

    private static function execute_tool( $tool_name, $input ) {
        switch ( $tool_name ) {
            case 'get_page_audit':
                return self::tool_page_audit( $input );
            case 'get_gsc_stats':
                return self::tool_gsc_stats( $input );
            case 'list_articles':
                return self::tool_list_articles( $input );
            case 'get_cocon_detail':
                return self::tool_cocon_detail( $input );
            case 'get_page_queries':
                return self::tool_page_queries( $input );
            case 'get_inbox_summary':
                return self::tool_inbox_summary( $input );
            case 'generate_report':
                return self::tool_generate_report( $input );
            default:
                return wp_json_encode( array( 'error' => 'Outil inconnu : ' . $tool_name ) );
        }
    }

    /**
     * Tool: get_page_audit — Audit SEO complet d'une page.
     *
     * @since 4.5
     * @param array $input { post_id, search_title }
     * @return string JSON result
     */
    private static function tool_page_audit( $input ) {
        global $wpdb;
        $post_id = (int) ( $input['post_id'] ?? 0 );
        $search_title = sanitize_text_field( $input['search_title'] ?? '' );

        // Sprint 4.5 fix: Détection spéciale "page d'accueil" / "homepage"
        if ( $post_id <= 0 && ! empty( $search_title ) ) {
            $home_keywords = array( 'accueil', 'homepage', 'home', 'page d\'accueil', 'page accueil', 'front page' );
            $search_lower  = mb_strtolower( $search_title );
            $is_homepage   = false;
            foreach ( $home_keywords as $hk ) {
                if ( mb_strpos( $search_lower, $hk ) !== false ) {
                    $is_homepage = true;
                    break;
                }
            }
            if ( $is_homepage ) {
                // WordPress static front page
                $front_id = (int) get_option( 'page_on_front', 0 );
                if ( $front_id > 0 ) {
                    $post_id = $front_id;
                } else {
                    // Blog page or try to find a page titled "Accueil"
                    $post_id = (int) $wpdb->get_var(
                        "SELECT ID FROM {$wpdb->posts}
                         WHERE post_status = 'publish' AND post_type = 'page'
                         AND ( post_title LIKE '%accueil%' OR post_title LIKE '%home%' )
                         ORDER BY ID ASC LIMIT 1"
                    );
                }
            }
        }

        // Recherche par titre si post_id toujours absent
        if ( $post_id <= 0 && ! empty( $search_title ) ) {
            $search = '%' . $wpdb->esc_like( $search_title ) . '%';
            $post_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_status = 'publish' AND post_type IN ('post','page')
                 AND post_title LIKE %s
                 ORDER BY ID DESC LIMIT 1",
                $search
            ) );
        }

        if ( $post_id <= 0 ) {
            // Dernier recours : recherche floue (mots significatifs du titre)
            $words = array_filter( explode( ' ', $search_title ), function( $w ) {
                return mb_strlen( $w ) >= 4;
            } );
            if ( count( $words ) >= 2 ) {
                $like_clauses = array();
                $like_args    = array();
                foreach ( array_slice( $words, 0, 4 ) as $w ) {
                    $like_clauses[] = 'LOWER(post_title) LIKE %s';
                    $like_args[]    = '%' . $wpdb->esc_like( mb_strtolower( $w ) ) . '%';
                }
                $sql = "SELECT ID FROM {$wpdb->posts}
                        WHERE post_status = 'publish' AND post_type IN ('post','page')
                        AND ( " . implode( ' AND ', $like_clauses ) . " )
                        ORDER BY ID DESC LIMIT 1";
                $post_id = (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$like_args ) );
            }
        }

        if ( $post_id <= 0 ) {
            return wp_json_encode( array( 'error' => 'Article introuvable. Précisez le titre exact ou le post_id.' ) );
        }

        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'publish', 'draft' ), true ) ) {
            return wp_json_encode( array( 'error' => 'Article #' . $post_id . ' introuvable ou non publié.' ) );
        }

        // Scores
        $global_score = (float) get_post_meta( $post_id, '_hts_global_score', true );
        $geo_score    = (float) get_post_meta( $post_id, '_hts_geo_score', true );
        $meta_score   = (float) get_post_meta( $post_id, '_hts_meta_score', true );

        // Score breakdown
        $detail_raw = get_post_meta( $post_id, '_hts_global_score_detail', true );
        $detail = is_string( $detail_raw ) ? json_decode( $detail_raw, true ) : ( is_array( $detail_raw ) ? $detail_raw : array() );

        // Meta tags
        $meta_title = get_post_meta( $post_id, '_hts_meta_title', true ) ?: '';
        $meta_desc  = get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
        $keyword    = get_post_meta( $post_id, '_hts_api_keyword', true )
                      ?: get_post_meta( $post_id, '_hts_focus_keyword', true );

        // Internal links
        $links_in  = (int) get_post_meta( $post_id, '_hts_internal_links_in', true );
        $links_out = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );

        // GSC data
        $gsc = null;
        $gsc_clicks = get_post_meta( $post_id, '_hts_gsc_clicks', true );
        if ( $gsc_clicks !== '' && $gsc_clicks !== false ) {
            $gsc = array(
                'clicks'      => (int) $gsc_clicks,
                'impressions' => (int) get_post_meta( $post_id, '_hts_gsc_impressions', true ),
                'position'    => (float) get_post_meta( $post_id, '_hts_gsc_position', true ),
                'ctr'         => (float) get_post_meta( $post_id, '_hts_gsc_ctr', true ),
            );
        }

        // Freshness
        $fresh = get_post_meta( $post_id, '_hts_freshness_score', true );

        // Maillage score
        $maillage = min( 100, (int) round( ( min( $links_in, 5 ) / 5 * 50 ) + ( min( $links_out, 5 ) / 5 * 50 ) ) );

        // Word count
        $word_count = hts_word_count( wp_strip_all_tags( $post->post_content ) );

        // Pending actions for this page
        $pending_actions = 0;
        if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
            $wf_table = $wpdb->prefix . 'hts_workflow_actions';
            $pending_actions = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wf_table} WHERE post_id = %d AND status = 'pending'",
                $post_id
            ) );
        }

        $result = array(
            'post_id'      => $post_id,
            'title'        => $post->post_title,
            'url'          => get_permalink( $post_id ),
            'type'         => $post->post_type,
            'word_count'   => $word_count,
            'modified'     => wp_date( 'Y-m-d', strtotime( $post->post_modified ) ),
            'keyword'      => $keyword ?: '(non défini)',
            'meta_title'   => $meta_title ?: '(non défini)',
            'meta_desc'    => $meta_desc ? mb_substr( $meta_desc, 0, 160 ) : '(non défini)',
            'global_score' => $global_score,
            'score_breakdown' => array(
                'technique'  => (int) round( $detail['tech_score'] ?? 0 ),
                'contenu'    => (int) round( $detail['panel_score'] ?? $global_score ),
                'geo'        => (int) round( $geo_score ),
                'maillage'   => $maillage,
                'fraicheur'  => ( $fresh !== '' && $fresh !== false ) ? (int) round( (float) $fresh ) : null,
            ),
            'internal_links' => array( 'in' => $links_in, 'out' => $links_out ),
            'gsc'            => $gsc,
            'pending_actions' => $pending_actions,
        );

        return wp_json_encode( $result, JSON_UNESCAPED_UNICODE );
    }

    /**
     * Tool: get_gsc_stats — Google Search Console stats.
     *
     * @since 4.5
     * @param array $input { period_days }
     * @return string JSON result
     */
    private static function tool_gsc_stats( $input ) {
        $days = (int) ( $input['period_days'] ?? 30 );
        $days = max( 1, min( 90, $days ) );

        if ( ! class_exists( 'HTS_GSC_Connect' ) ) {
            return wp_json_encode( array( 'error' => 'Le module Google Search Console n\'est pas installé.' ) );
        }

        $gsc = new \HTS_GSC_Connect();
        if ( ! $gsc->is_connected() || ! $gsc->has_data() ) {
            return wp_json_encode( array( 'error' => 'Google Search Console n\'est pas connecté. Allez dans Réglages → Google Search Console pour le connecter.' ) );
        }

        $site_data = $gsc->get_site_data( $days );
        if ( ! is_array( $site_data ) ) {
            return wp_json_encode( array( 'error' => 'Impossible de récupérer les données GSC.' ) );
        }

        $result = array(
            'period'       => $days . ' jours',
            'clicks'       => (int) ( $site_data['clicks'] ?? 0 ),
            'impressions'  => (int) ( $site_data['impressions'] ?? 0 ),
            'avg_position' => round( (float) ( $site_data['avg_position'] ?? 0 ), 1 ),
            'avg_ctr'      => round( (float) ( $site_data['avg_ctr'] ?? 0 ), 2 ),
            'clicks_trend' => round( (float) ( $site_data['clicks_trend'] ?? 0 ), 1 ),
        );

        // Top pages
        if ( ! empty( $site_data['top_pages'] ) ) {
            $result['top_pages'] = array_values( array_slice( array_map( function( $p ) {
                $p = is_object( $p ) ? (array) $p : $p;
                return array(
                    'title'       => $p['title'] ?? basename( $p['url'] ?? '' ),
                    'url'         => $p['url'] ?? '',
                    'clicks'      => (int) ( $p['clicks'] ?? 0 ),
                    'impressions' => (int) ( $p['impressions'] ?? 0 ),
                    'position'    => round( (float) ( $p['position'] ?? 0 ), 1 ),
                    'ctr'         => round( (float) ( $p['ctr'] ?? 0 ), 2 ),
                );
            }, $site_data['top_pages'] ), 0, 10 ) );
        }

        // Top queries
        if ( method_exists( $gsc, 'get_top_queries' ) ) {
            $queries = $gsc->get_top_queries( $days, 10 );
            if ( is_array( $queries ) && ! empty( $queries ) ) {
                $result['top_queries'] = array_values( array_slice( array_map( function( $q ) {
                    $q = is_object( $q ) ? (array) $q : $q;
                    return array(
                        'query'       => $q['query'] ?? '',
                        'clicks'      => (int) ( $q['clicks'] ?? 0 ),
                        'impressions' => (int) ( $q['impressions'] ?? 0 ),
                        'position'    => round( (float) ( $q['position'] ?? $q['avg_position'] ?? 0 ), 1 ),
                        'ctr'         => round( (float) ( $q['ctr'] ?? $q['avg_ctr'] ?? 0 ), 2 ),
                    );
                }, $queries ), 0, 10 ) );
            }
        }

        return wp_json_encode( $result, JSON_UNESCAPED_UNICODE );
    }

    /**
     * Tool: list_articles — Liste filtrée des articles du site.
     *
     * @since 4.5
     * @param array $input { sort, limit, min_score, max_score }
     * @return string JSON result
     */

    /**
     * Sprint 5.4b: Tool — Requêtes GSC par page.
     * Retourne les mots-clés qui génèrent du trafic vers une page spécifique.
     *
     * @param array $input { post_id, search_title, period_days }
     * @return string JSON
     */
    private static function tool_page_queries( $input ) {
        $post_id = absint( $input['post_id'] ?? 0 );
        $search  = sanitize_text_field( $input['search_title'] ?? '' );
        $days    = max( 7, min( 90, (int) ( $input['period_days'] ?? 30 ) ) );

        // Résoudre post_id par titre si nécessaire
        if ( $post_id === 0 && ! empty( $search ) ) {
            global $wpdb;
            $post_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_status = 'publish' AND post_type IN ('post','page')
                 AND post_title LIKE %s
                 ORDER BY post_date DESC LIMIT 1",
                '%' . $wpdb->esc_like( $search ) . '%'
            ) );
        }

        if ( $post_id === 0 ) {
            return wp_json_encode( array( 'error' => 'Page non trouvée. Précise le post_id ou un titre plus spécifique.' ) );
        }

        if ( ! class_exists( 'HTS_GSC_Connect' ) ) {
            return wp_json_encode( array( 'error' => 'Module GSC non installé.' ) );
        }

        $gsc = new \HTS_GSC_Connect();
        if ( ! $gsc->is_connected() || ! $gsc->has_data() ) {
            return wp_json_encode( array( 'error' => 'GSC non connecté.' ) );
        }

        $queries = $gsc->get_post_queries( $post_id, $days, 20 );

        if ( empty( $queries ) ) {
            return wp_json_encode( array(
                'post_id'    => $post_id,
                'title'      => get_the_title( $post_id ),
                'period'     => $days . ' jours',
                'queries'    => array(),
                'note'       => 'Aucune requête GSC trouvée pour cette page. Soit elle n\'a pas d\'impressions, soit les données GSC ne sont pas encore synchronisées.',
            ) );
        }

        $result_queries = array();
        $total_clicks = 0;
        $total_impr   = 0;

        foreach ( $queries as $q ) {
            $q = is_object( $q ) ? (array) $q : $q;
            $clicks = (int) ( $q['clicks'] ?? 0 );
            $impr   = (int) ( $q['impressions'] ?? 0 );
            $total_clicks += $clicks;
            $total_impr   += $impr;

            $result_queries[] = array(
                'query'       => $q['query'] ?? '',
                'clicks'      => $clicks,
                'impressions' => $impr,
                'position'    => round( (float) ( $q['avg_position'] ?? 0 ), 1 ),
                'ctr'         => round( (float) ( $q['avg_ctr'] ?? 0 ), 2 ),
            );
        }

        return wp_json_encode( array(
            'post_id'       => $post_id,
            'title'         => get_the_title( $post_id ),
            'url'           => get_permalink( $post_id ),
            'period'        => $days . ' jours',
            'total_clicks'  => $total_clicks,
            'total_impressions' => $total_impr,
            'avg_ctr'       => $total_impr > 0 ? round( $total_clicks / $total_impr * 100, 2 ) : 0,
            'queries_count' => count( $result_queries ),
            'queries'       => $result_queries,
        ), JSON_UNESCAPED_UNICODE );
    }

    private static function tool_list_articles( $input ) {
        global $wpdb;

        $sort      = $input['sort'] ?? 'worst';
        $limit     = max( 5, min( 20, (int) ( $input['limit'] ?? 10 ) ) );
        $min_score = isset( $input['min_score'] ) ? (int) $input['min_score'] : null;
        $max_score = isset( $input['max_score'] ) ? (int) $input['max_score'] : null;

        $order = 'ASC'; // worst first
        if ( $sort === 'best' )   $order = 'DESC';
        if ( $sort === 'recent' ) $order = 'DESC';

        $order_col = $sort === 'recent'
            ? 'p.post_modified'
            : 'CAST( pm.meta_value AS DECIMAL(5,1) )';

        $where_extra = '';
        $where_args  = array();
        if ( $min_score !== null ) {
            $where_extra .= ' AND CAST( pm.meta_value AS UNSIGNED ) >= %d';
            $where_args[] = $min_score;
        }
        if ( $max_score !== null ) {
            $where_extra .= ' AND CAST( pm.meta_value AS UNSIGNED ) <= %d';
            $where_args[] = $max_score;
        }

        $sql = "SELECT p.ID, p.post_title, p.post_type, p.post_modified,
                       CAST( pm.meta_value AS DECIMAL(5,1) ) as global_score
                FROM {$wpdb->postmeta} pm
                INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                WHERE pm.meta_key = '_hts_global_score'
                  AND p.post_status = 'publish'
                  AND p.post_type IN ('post','page')
                  AND pm.meta_value > 0
                  {$where_extra}
                ORDER BY {$order_col} {$order}
                LIMIT %d";

        $where_args[] = $limit;
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$where_args ) );

        $articles = array();
        foreach ( $rows as $row ) {
            $pid = (int) $row->ID;
            $geo = (float) get_post_meta( $pid, '_hts_geo_score', true );
            $kw  = get_post_meta( $pid, '_hts_api_keyword', true )
                   ?: get_post_meta( $pid, '_hts_focus_keyword', true );

            $entry = array(
                'id'           => $pid,
                'title'        => $row->post_title,
                'type'         => $row->post_type,
                'global_score' => (float) $row->global_score,
                'geo_score'    => $geo,
                'keyword'      => $kw ?: null,
                'modified'     => wp_date( 'Y-m-d', strtotime( $row->post_modified ) ),
                'links_in'     => (int) get_post_meta( $pid, '_hts_internal_links_in', true ),
                'links_out'    => (int) get_post_meta( $pid, '_hts_internal_links_out', true ),
            );

            // GSC si disponible
            $gsc_clicks = get_post_meta( $pid, '_hts_gsc_clicks', true );
            if ( $gsc_clicks !== '' && $gsc_clicks !== false ) {
                $entry['gsc_clicks']   = (int) $gsc_clicks;
                $entry['gsc_position'] = (float) get_post_meta( $pid, '_hts_gsc_position', true );
            }

            $articles[] = $entry;
        }

        // Total published
        $total = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_hts_global_score' AND p.post_status = 'publish'
             AND p.post_type IN ('post','page') AND pm.meta_value > 0"
        );

        return wp_json_encode( array(
            'total_scored' => $total,
            'showing'      => count( $articles ),
            'sort'         => $sort,
            'filters'      => array( 'min_score' => $min_score, 'max_score' => $max_score ),
            'articles'     => $articles,
        ), JSON_UNESCAPED_UNICODE );
    }

    /**
     * Tool: get_cocon_detail — Détails d'un cocon ou liste de tous les cocons.
     *
     * @since 4.5
     * @param array $input { cocon_name }
     * @return string JSON result
     */
    private static function tool_cocon_detail( $input ) {
        $cocon_name = trim( $input['cocon_name'] ?? '' );

        // Charger les données cocon — méthode robuste pour contexte AJAX
        $data = self::load_cocon_data_robust();

        if ( empty( $data ) || empty( $data['clusters'] ) ) {
            return wp_json_encode( array(
                'error' => 'Aucun cocon sémantique n\'a été analysé. Lancez une analyse cocon dans le Cockpit → onglet Cocon.',
            ) );
        }

        // Si pas de nom → retourner la liste de tous les cocons
        if ( empty( $cocon_name ) ) {
            $summary = array();
            foreach ( $data['clusters'] as $cname => $cl ) {
                if ( in_array( $cname, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;
                if ( ( $cl['page_count'] ?? count( $cl['pages'] ?? array() ) ) < 1 ) continue;
                $summary[] = array(
                    'name'          => $cname,
                    'pages'         => (int) ( $cl['page_count'] ?? count( $cl['pages'] ?? array() ) ),
                    'density'       => (int) ( $cl['density'] ?? 0 ),
                    'orphans'       => (int) ( $cl['orphans'] ?? 0 ),
                    'avg_score'     => round( (float) ( $cl['avg_score'] ?? 0 ), 1 ),
                    'pillar'        => $cl['pillar_title'] ?? ( isset( $cl['pillar_id'] ) && $cl['pillar_id'] ? get_the_title( (int) $cl['pillar_id'] ) : '' ),
                    'missing_links' => (int) ( $cl['missing_links_count'] ?? 0 ),
                );
            }
            return wp_json_encode( array(
                'mode'   => 'list',
                'count'  => count( $summary ),
                'cocons' => $summary,
            ), JSON_UNESCAPED_UNICODE );
        }

        // Détail d'un cocon spécifique — fuzzy match direct sur les données chargées
        $cluster_names = array_keys( $data['clusters'] );
        $matched_key = self::fuzzy_match_cluster( $cocon_name, $cluster_names );

        if ( $matched_key && isset( $data['clusters'][ $matched_key ] ) ) {
            $cl    = $data['clusters'][ $matched_key ];
            $nodes = $data['nodes'] ?? array();

            // Construire le détail des pages
            $pages = array();
            $pillar_title = '';
            foreach ( $cl['pages'] ?? array() as $pid ) {
                $pid = (int) $pid;
                $n = $nodes[ $pid ] ?? null;
                $page_data = array(
                    'id'           => $pid,
                    'title'        => $n ? ( $n['title'] ?? get_the_title( $pid ) ) : get_the_title( $pid ),
                    'role'         => $n['role'] ?? 'satellite',
                    'in_count'     => (int) ( $n['in_count'] ?? 0 ),
                    'out_count'    => (int) ( $n['out_count'] ?? 0 ),
                    'is_orphan'    => (bool) ( $n['is_orphan'] ?? false ),
                    'global_score' => (float) get_post_meta( $pid, '_hts_global_score', true ),
                    'geo_score'    => (float) get_post_meta( $pid, '_hts_geo_score', true ),
                );
                if ( $page_data['role'] === 'pilier' ) $pillar_title = $page_data['title'];
                $pages[] = $page_data;
            }

            // Trier : pilier d'abord, puis orphelins, puis par score
            usort( $pages, function( $a, $b ) {
                if ( $a['role'] === 'pilier' ) return -1;
                if ( $b['role'] === 'pilier' ) return 1;
                if ( $a['is_orphan'] !== $b['is_orphan'] ) return $a['is_orphan'] ? -1 : 1;
                return $b['global_score'] <=> $a['global_score'];
            } );

            if ( count( $pages ) > 15 ) {
                $pages = array_slice( $pages, 0, 15 );
            }

            // Métriques
            $n_pages = count( $cl['pages'] ?? array() );
            $avg_global = $n_pages > 0 ? round( array_sum( array_column( $pages, 'global_score' ) ) / min( $n_pages, count( $pages ) ), 1 ) : 0;
            $orphan_count = count( array_filter( $pages, function( $p ) { return $p['is_orphan']; } ) );

            $detail = array(
                'name'             => $matched_key,
                'page_count'       => $n_pages,
                'density'          => (int) ( $cl['density'] ?? 0 ),
                'orphan_count'     => (int) ( $cl['orphans'] ?? $orphan_count ),
                'avg_global_score' => $avg_global,
                'pillar_title'     => $pillar_title ?: ( isset( $cl['pillar_id'] ) ? get_the_title( (int) $cl['pillar_id'] ) : '' ),
                'pillar_id'        => (int) ( $cl['pillar_id'] ?? 0 ),
                'missing_links'    => (int) ( $cl['missing_links_count'] ?? 0 ),
                'pages'            => $pages,
            );

            return wp_json_encode( $detail, JSON_UNESCAPED_UNICODE );
        }

        // Pas trouvé → suggestions
        $suggestions = array();
        foreach ( $cluster_names as $n ) {
            if ( in_array( $n, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;
            $suggestions[] = $n;
        }

        return wp_json_encode( array(
            'error'     => 'Cocon "' . $cocon_name . '" introuvable.',
            'available' => $suggestions,
        ), JSON_UNESCAPED_UNICODE );
    }

    /**
     * Load cocon data robustly — tries all possible option keys.
     * Handles AJAX context where HTS_Language might not detect the right language.
     *
     * @since 4.5
     * @return array Cocon data with nodes, links, clusters.
     */
    private static function load_cocon_data_robust() {
        // Method 1: Use HTS_Cocon if available (handles exclusions, language)
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new \HTS_Cocon();
            $data = $cocon->get_cocon_data();
            if ( ! empty( $data ) && ! empty( $data['clusters'] ) ) {
                return $data;
            }
        }

        // Method 2: Try language-specific options directly
        $langs_to_try = array( 'fr', 'en', 'es', 'de', 'it', 'pt' );
        if ( class_exists( 'HTS_Language' ) ) {
            $current = HTS_Language::get_current_lang();
            if ( $current ) array_unshift( $langs_to_try, $current );
        }

        foreach ( $langs_to_try as $lang ) {
            $data = get_option( 'hts_cocon_data_' . $lang, array() );
            if ( ! empty( $data ) && ! empty( $data['clusters'] ) ) {
                return $data;
            }
        }

        // Method 3: Try unscoped option
        $data = get_option( 'hts_cocon_data', array() );
        if ( ! empty( $data ) && ! empty( $data['clusters'] ) ) {
            return $data;
        }

        return array();
    }

    /**
     * Tool: get_inbox_summary — État de l'Inbox SEO.
     *
     * @since 4.5
     * @param array $input { period_days, status_filter }
     * @return string JSON result
     */
    private static function tool_inbox_summary( $input ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) || ! HTS_Workflow_Engine::tables_exist() ) {
            return wp_json_encode( array( 'error' => 'Le module Workflow n\'est pas actif.' ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';
        $days  = max( 1, min( 90, (int) ( $input['period_days'] ?? 7 ) ) );
        $filter = $input['status_filter'] ?? 'all';

        // Stats globales
        $stats = HTS_Workflow_Engine::get_stats();

        // Historique récent
        $status_where = '';
        if ( $filter !== 'all' ) {
            $status_where = $wpdb->prepare( ' AND status = %s', $filter );
        }

        $recent = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, agent, type, status, post_id,
                    created_at, resolved_at,
                    SUBSTRING(data, 1, 200) AS data_preview
             FROM {$table}
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             {$status_where}
             ORDER BY created_at DESC
             LIMIT 20",
            $days
        ) );

        $actions = array();
        $agent_labels = HTS_Workflow_Engine::get_agent_labels();
        foreach ( $recent as $row ) {
            $title = '';
            if ( (int) $row->post_id > 0 ) {
                $title = get_the_title( (int) $row->post_id );
            }

            $actions[] = array(
                'id'         => (int) $row->id,
                'agent'      => $agent_labels[ $row->agent ] ?? $row->agent,
                'type'       => $row->type,
                'status'     => $row->status,
                'post_title' => $title ?: null,
                'created'    => $row->created_at,
                'resolved'   => $row->resolved_at,
            );
        }

        // Résumé par agent
        $by_agent_summary = array();
        foreach ( $stats['by_agent'] ?? array() as $agent => $agent_stats ) {
            $by_agent_summary[] = array(
                'agent'   => $agent_labels[ $agent ] ?? $agent,
                'pending' => (int) ( $agent_stats['pending'] ?? 0 ),
                'done'    => (int) ( $agent_stats['done'] ?? 0 ),
                'failed'  => (int) ( $agent_stats['failed'] ?? 0 ),
            );
        }

        return wp_json_encode( array(
            'totals' => array(
                'pending'  => (int) ( $stats['pending'] ?? 0 ),
                'approved' => (int) ( $stats['approved'] ?? 0 ),
                'done'     => (int) ( $stats['done'] ?? 0 ),
                'failed'   => (int) ( $stats['failed'] ?? 0 ),
                'rejected' => (int) ( $stats['rejected'] ?? 0 ),
                'total'    => (int) ( $stats['total'] ?? 0 ),
            ),
            'by_agent'       => $by_agent_summary,
            'period_days'    => $days,
            'recent_actions' => $actions,
        ), JSON_UNESCAPED_UNICODE );
    }

    // ═══════════════════════════════════════════════════════════════
    // RAPPORTS THÉMATIQUES — v2.6.3
    // ═══════════════════════════════════════════════════════════════

    /**
     * Crée la table wp_hts_coach_reports.
     */
    public static function create_reports_table() {
        global $wpdb;
        $table   = $wpdb->prefix . 'hts_coach_reports';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id BIGINT UNSIGNED DEFAULT NULL,
            report_type VARCHAR(30) NOT NULL DEFAULT 'full',
            report_json LONGTEXT NOT NULL,
            report_hash VARCHAR(32) DEFAULT NULL,
            source VARCHAR(20) NOT NULL DEFAULT 'user',
            period_days INT UNSIGNED NOT NULL DEFAULT 30,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_session (session_id),
            KEY idx_type_date (report_type, created_at),
            KEY idx_source (source, created_at)
        ) {$charset};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Génère un rapport 100% PHP (0 token LLM), le sauve en DB.
     */
    public function ajax_generate_report_direct() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier(1);
        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 120 );

        // Ensure reports table exists
        self::create_reports_table();

        $type   = sanitize_text_field( $_POST['report_type'] ?? 'full' );
        $period = max( 7, min( 90, (int) ( $_POST['period_days'] ?? 30 ) ) );

        switch ( $type ) {
            case 'linking':     $report = self::generate_report_linking( $period ); break;
            case 'content':     $report = self::generate_report_content( $period ); break;
            case 'performance': $report = self::generate_report_performance( $period ); break;
            case 'audit':       $report = self::generate_report_audit( $period ); break;
            default:            $report = self::generate_report_full( $period ); break;
        }

        // Sauver en DB
        global $wpdb;
        $table = $wpdb->prefix . 'hts_coach_reports';
        $json  = wp_json_encode( $report, JSON_UNESCAPED_UNICODE );
        $session_id = (int) ( $_POST['session_id'] ?? 0 ) ?: null;

        $wpdb->insert( $table, array(
            'session_id'  => $session_id,
            'report_type' => $type,
            'report_json' => $json,
            'report_hash' => md5( $json ),
            'source'      => 'user',
            'period_days' => $period,
        ), array( '%d', '%s', '%s', '%s', '%s', '%d' ) );

        $report['_report_db_id'] = $wpdb->insert_id;

        wp_send_json_success( array( 'report' => $report ) );
    }

    /**
     * Charge un rapport sauvé par ID ou le dernier par type.
     */
    public function ajax_load_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier(1);

        global $wpdb;
        $table = $wpdb->prefix . 'hts_coach_reports';
        $report_id = (int) ( $_POST['report_id'] ?? 0 );

        if ( $report_id ) {
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $report_id ) );
        } else {
            $type = sanitize_text_field( $_POST['report_type'] ?? 'full' );
            $row  = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$table} WHERE report_type = %s ORDER BY created_at DESC LIMIT 1", $type
            ) );
        }

        if ( ! $row ) { wp_send_json_error( array( 'message' => 'Rapport non trouvé.' ) ); }

        $report = json_decode( $row->report_json, true );
        $report['_report_db_id'] = (int) $row->id;
        $report['_created_at']   = $row->created_at;

        wp_send_json_success( array( 'report' => $report ) );
    }

    private static function tool_generate_report( $input ) {
        $type   = $input['report_type'] ?? 'full';
        $period = max( 7, min( 90, (int) ( $input['period_days'] ?? 30 ) ) );

        switch ( $type ) {
            case 'linking':     $report = self::generate_report_linking( $period ); break;
            case 'content':     $report = self::generate_report_content( $period ); break;
            case 'performance': $report = self::generate_report_performance( $period ); break;
            case 'audit':       $report = self::generate_report_audit( $period ); break;
            case 'full':
            default:            $report = self::generate_report_full( $period ); break;
        }

        return wp_json_encode( $report );
    }

    private static function generate_report_linking( $period = 30 ) {
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";

        // Données
        $total_published = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in}" );

        $orphan_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_internal_links_in' WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND (pm.meta_value IS NULL OR pm.meta_value = '0' OR pm.meta_value = '')" );
        $orphans = $wpdb->get_results( "SELECT p.ID, p.post_title FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_internal_links_in' WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND (pm.meta_value IS NULL OR pm.meta_value = '0' OR pm.meta_value = '') LIMIT 20" );

        $dead_ends = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_internal_links_out' WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND (pm.meta_value IS NULL OR pm.meta_value = '0' OR pm.meta_value = '')" );

        $table = $wpdb->prefix . 'hts_workflow_actions';
        $table_exists = (bool) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        $links_added = 0;
        $pending = 0;
        if ( $table_exists ) {
            $links_added = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE type = 'add_internal_links' AND status = 'done' AND resolved_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $period ) );
            $pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE type = 'add_internal_links' AND status = 'pending'" );
        }

        // Cocons
        $cocon_data = array();
        $cocon_count = 0;
        $avg_density = 0;
        $cocon_labels = array();
        $cocon_values = array();
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new \HTS_Cocon();
            $data = $cocon->get_cocon_data();
            $clusters = $data['clusters'] ?? array();
            $cocon_count = count( $clusters );
            $densities = array();
            foreach ( $clusters as $name => $cl ) {
                if ( in_array( $name, array( 'Non classé', 'Thématiques émergentes' ), true ) ) continue;
                $pages = $cl['pages'] ?? array();
                $n = count( $pages );
                if ( $n < 2 ) continue;
                $possible = $n * ( $n - 1 );
                $existing = 0;
                // Quick count via nodes
                foreach ( $pages as $pid ) {
                    $existing += (int) ( $data['nodes'][ $pid ]['out_count_semantic'] ?? $data['nodes'][ $pid ]['out_count'] ?? 0 );
                }
                $density = $possible > 0 ? round( $existing / $possible * 100 ) : 0;
                $densities[] = $density;
                $cocon_labels[] = mb_substr( $name, 0, 25 );
                $cocon_values[] = $density;
                $cocon_data[] = array( 'name' => $name, 'pages' => $n, 'density' => $density, 'orphans' => 0 );
            }
            $avg_density = ! empty( $densities ) ? round( array_sum( $densities ) / count( $densities ) ) : 0;
        }

        // Top pages liées
        $top_linked = $wpdb->get_results( "SELECT p.ID, p.post_title, CAST(pm.meta_value AS UNSIGNED) as links_in FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_internal_links_in' WHERE p.post_status = 'publish' ORDER BY links_in DESC LIMIT 10" );

        // Build report
        $orphan_pct = $total_published > 0 ? round($orphan_count / $total_published * 100) : 0;
        $report = array(
            'title' => 'Rapport Maillage Interne',
            'summary' => "Votre maillage interne a une densité moyenne de **{$avg_density}%** "
                . ($avg_density < 30 ? "(critique — vos pages ne se transmettent pas de jus SEO)" : ($avg_density < 60 ? "(passable — il y a de la marge)" : "(bon niveau)"))
                . ". **{$orphan_count} pages orphelines** ({$orphan_pct}% du site) sont invisibles pour Google car aucun lien interne ne pointe vers elles. "
                . ($pending > 0 ? "**{$pending} propositions de liens** vous attendent dans l'Inbox — appliquez-les pour un gain immédiat." : ""),
            'kpis' => array(
                array( 'label' => 'Densité moyenne', 'value' => $avg_density . '%', 'unit' => '', 'trend' => $avg_density >= 40 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Pages orphelines', 'value' => (string) $orphan_count, 'unit' => '', 'trend' => $orphan_count === 0 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Dead ends', 'value' => (string) $dead_ends, 'unit' => '', 'trend' => $dead_ends === 0 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Liens ajoutés', 'value' => (string) $links_added, 'unit' => '/' . $period . 'j', 'trend' => $links_added > 0 ? 'up' : 'neutral', 'delta' => '' ),
                array( 'label' => 'En attente', 'value' => (string) $pending, 'unit' => '', 'trend' => 'neutral', 'delta' => '' ),
                array( 'label' => 'Cocons actifs', 'value' => (string) $cocon_count, 'unit' => '', 'trend' => 'neutral', 'delta' => '' ),
            ),
            'charts' => array(),
            'tables' => array(),
            'insights' => array(),
        );

        // Charts
        if ( ! empty( $cocon_labels ) ) {
            $report['charts'][] = array(
                'type' => 'bar', 'title' => 'Densité maillage par cocon',
                'labels' => $cocon_labels, 'data' => $cocon_values,
                'commentary' => 'Un cocon sémantique doit avoir une densité de maillage d\'au moins **40%** pour être efficace. '
                    . 'En dessous, Google ne comprend pas la relation entre vos pages = il ne remonte pas votre thématique. '
                    . 'Action : ouvrez l\'Inbox et appliquez les propositions de liens internes pour chaque cocon sous les 40%.',
            );
        }

        $well_linked = max( 0, $total_published - $orphan_count - $dead_ends );
        $report['charts'][] = array(
            'type' => 'doughnut', 'title' => 'Répartition des pages',
            'labels' => array( 'Bien maillées', 'Orphelines', 'Dead ends' ),
            'data' => array( $well_linked, $orphan_count, $dead_ends ),
            'commentary' => "**{$orphan_count} pages orphelines** = {$orphan_pct}% de votre site est invisible pour Google. "
                . "Ces pages n'ont aucun lien interne pointant vers elles, donc Google les découvre très lentement (ou jamais). "
                . ($dead_ends > 0 ? "**{$dead_ends} dead ends** bloquent le PageRank — ces pages reçoivent du jus SEO mais ne le redistribuent pas. Ajoutez 2-3 liens sortants sur chacune." : ""),
        );

        // Tables
        if ( ! empty( $orphans ) ) {
            $orphan_rows = array();
            foreach ( $orphans as $o ) {
                $score = (int) get_post_meta( $o->ID, '_hts_global_score', true );
                $orphan_rows[] = array( mb_substr( $o->post_title, 0, 50 ), (string) $score, get_edit_post_link( $o->ID, 'raw' ) ?: '' );
            }
            $report['tables'][] = array(
                'title' => 'Pages orphelines prioritaires',
                'headers' => array( 'Page', 'Score SEO', 'Lien' ),
                'rows' => array_slice( $orphan_rows, 0, 10 ),
                'commentary' => 'Ces pages n\'ont **aucun lien interne** pointant vers elles. Google doit les découvrir par le sitemap uniquement, ce qui prend des semaines. '
                    . 'Action immédiate : ajoutez 2-3 liens depuis vos pages les plus fortes vers chacune de ces orphelines. Résultat attendu : indexation en 3-5 jours au lieu de 3-5 semaines.',
            );
        }

        if ( ! empty( $cocon_data ) ) {
            $cocon_rows = array();
            foreach ( $cocon_data as $cd ) {
                $cocon_rows[] = array( $cd['name'], (string) $cd['pages'], $cd['density'] . '%' );
            }
            $report['tables'][] = array(
                'title' => 'Cocons à renforcer',
                'headers' => array( 'Cocon', 'Pages', 'Densité' ),
                'rows' => $cocon_rows,
                'commentary' => 'Les cocons avec une densité inférieure à **40%** n\'envoient pas assez de signaux thématiques à Google. '
                    . 'Chaque lien interne entre articles d\'un même cocon renforce votre autorité sur la thématique. '
                    . 'Objectif : amenez chaque cocon au-dessus de 50% — les propositions de liens sont déjà calculées dans votre Inbox.',
            );
        }

        // Insights
        if ( $avg_density < 30 ) {
            $report['insights'][] = array( 'level' => 'critical', 'text' => 'La densité moyenne du maillage (' . $avg_density . '%) est très faible. Les cocons ne sont pas suffisamment liés entre eux. Action : appliquez les propositions de liens dans l\'Inbox.' );
        }
        if ( $orphan_count > 0 ) {
            $pct = $total_published > 0 ? round( $orphan_count / $total_published * 100 ) : 0;
            $level = $pct > 20 ? 'critical' : ( $pct > 10 ? 'high' : 'info' );
            $report['insights'][] = array( 'level' => $level, 'text' => $orphan_count . ' page(s) orpheline(s) (' . $pct . '% du site). Ces pages ne reçoivent aucun lien interne — Google les indexe plus lentement.' );
        }
        if ( $dead_ends > 0 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => $dead_ends . ' page(s) sans lien sortant (dead ends). Le PageRank reste bloqué sur ces pages au lieu de circuler vers le reste du site.' );
        }
        if ( $links_added > 5 ) {
            $report['insights'][] = array( 'level' => 'positive', 'text' => $links_added . ' liens ajoutés ces ' . $period . ' derniers jours. Le maillage s\'améliore activement.' );
        }
        if ( $pending > 0 ) {
            $report['insights'][] = array( 'level' => 'info', 'text' => $pending . ' proposition(s) de liens en attente dans l\'Inbox. Validez-les pour renforcer votre maillage.' );
        }

        return $report;
    }

    private static function generate_report_content( $period = 30 ) {
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";

        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in}" );
        $avg_score = class_exists( 'HTS_Coach' ) ? (int) self::get_average_score() : 0;
        $avg_geo = class_exists( 'HTS_Coach' ) ? (int) self::get_average_geo_score() : 0;

        // Distribution scores
        $dist = $wpdb->get_row( "SELECT SUM(CASE WHEN CAST(pm.meta_value AS UNSIGNED) < 30 THEN 1 ELSE 0 END) as critical, SUM(CASE WHEN CAST(pm.meta_value AS UNSIGNED) BETWEEN 30 AND 59 THEN 1 ELSE 0 END) as low, SUM(CASE WHEN CAST(pm.meta_value AS UNSIGNED) BETWEEN 60 AND 79 THEN 1 ELSE 0 END) as medium, SUM(CASE WHEN CAST(pm.meta_value AS UNSIGNED) >= 80 THEN 1 ELSE 0 END) as good FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_global_score' WHERE p.post_status = 'publish' AND p.post_type {$pt_in}" );

        $critical_count = (int) ( $dist->critical ?? 0 );

        // Articles IA
        $ai_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_ai_generated' AND pm.meta_value = '1' WHERE p.post_status IN ('publish','draft')" );
        $ai_30d = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_ai_generated' AND pm.meta_value = '1' WHERE p.post_date >= DATE_SUB(NOW(), INTERVAL %d DAY)", $period ) );

        // Brouillons
        $drafts = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='draft' AND post_type {$pt_in}" );

        // Stale articles
        $stale = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in} AND post_modified < DATE_SUB(NOW(), INTERVAL 6 MONTH)" );

        // Worst articles
        $worst = $wpdb->get_results( "SELECT p.ID, p.post_title, CAST(pm.meta_value AS UNSIGNED) as score FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_global_score' WHERE p.post_status = 'publish' AND p.post_type {$pt_in} ORDER BY score ASC LIMIT 10" );

        $report = array(
            'title' => 'Rapport Contenu & IA',
            'summary' => '',
            'kpis' => array(
                array( 'label' => 'Score SEO moyen', 'value' => (string) $avg_score, 'unit' => '/100', 'trend' => $avg_score >= 60 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Score GEO moyen', 'value' => (string) $avg_geo, 'unit' => '/100', 'trend' => $avg_geo >= 50 ? 'up' : 'neutral', 'delta' => '' ),
                array( 'label' => 'Articles publiés', 'value' => (string) $total, 'unit' => '', 'trend' => 'neutral', 'delta' => '' ),
                array( 'label' => 'Articles IA', 'value' => (string) $ai_30d, 'unit' => '/' . $period . 'j', 'trend' => $ai_30d > 0 ? 'up' : 'neutral', 'delta' => '' ),
                array( 'label' => 'Brouillons prêts', 'value' => (string) $drafts, 'unit' => '', 'trend' => 'neutral', 'delta' => '' ),
                array( 'label' => 'Articles critiques', 'value' => (string) $critical_count, 'unit' => 'score inf. 30', 'trend' => $critical_count === 0 ? 'up' : 'down', 'delta' => '' ),
            ),
            'charts' => array(
                array(
                    'type' => 'bar', 'title' => 'Distribution des scores SEO',
                    'labels' => array( 'Critique (0-29)', 'Faible (30-59)', 'Moyen (60-79)', 'Bon (80-100)' ),
                    'data' => array( (int) ( $dist->critical ?? 0 ), (int) ( $dist->low ?? 0 ), (int) ( $dist->medium ?? 0 ), (int) ( $dist->good ?? 0 ) ),
                    'commentary' => '',
                ),
            ),
            'tables' => array(),
            'insights' => array(),
        );

        // === PRE-COMPUTE COMMENTARIES ===
        $crit_n = (int)($dist->critical ?? 0); $low_n = (int)($dist->low ?? 0);
        $med_n = (int)($dist->medium ?? 0); $good_n = (int)($dist->good ?? 0);
        $scored_n = $crit_n + $low_n + $med_n + $good_n;
        $weak_pct = $scored_n > 0 ? round(($crit_n + $low_n) / $scored_n * 100) : 0;

        $report['charts'][0]['commentary'] = "**{$weak_pct}% de vos contenus** ({$crit_n} critiques + {$low_n} faibles) ont un score SEO insuffisant — Google ne les positionne pas, vos clients ne les trouvent pas. "
            . ($crit_n > 0
                ? "Les **{$crit_n} articles critiques** (score < 30) diluent la qualité globale. Action : supprimez-les ou réécrivez-les cette semaine."
                : "Bonne nouvelle : aucun article critique. Concentrez-vous sur les **{$low_n} articles faibles** pour les passer au-dessus de 60/100.");

        $report['summary'] = "Votre site compte **{$total} contenus** avec un score SEO moyen de **{$avg_score}/100** "
            . ($avg_score < 50 ? "(insuffisant)" : ($avg_score < 70 ? "(en progression)" : "(bon niveau)"))
            . " et une visibilité IA de **{$avg_geo}/100**. "
            . ($drafts > 0 ? "**{$drafts} brouillons** attendent d'être publiés. " : "")
            . ($stale > 5 ? "**{$stale} articles** n'ont pas été mis à jour depuis 6 mois." : "");

        // Table worst articles
        if ( ! empty( $worst ) ) {
            $rows = array();
            foreach ( $worst as $w ) {
                $wc = function_exists( 'hts_word_count' ) ? hts_word_count( wp_strip_all_tags( get_post_field( 'post_content', $w->ID ) ) ) : str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $w->ID ) ) );
                $rows[] = array( mb_substr( $w->post_title, 0, 45 ), (string) $w->score, (string) $wc );
            }
            $report['tables'][] = array(
                'title' => 'Articles à améliorer en priorité',
                'headers' => array( 'Article', 'Score', 'Mots' ),
                'rows' => $rows,
                'commentary' => 'Ces ' . count($rows) . ' articles ont les plus mauvais scores de votre site. '
                    . 'Les articles avec **moins de 300 mots** sont considérés comme "thin content" par Google — ils n\'apportent rien et peuvent pénaliser votre site. '
                    . 'Action : réécrivez chaque article pour atteindre au minimum 800 mots, ou supprimez-les s\'ils n\'ont aucun trafic.',
            );
        }

        // Insights
        if ( $avg_score < 50 ) {
            $report['insights'][] = array( 'level' => 'critical', 'text' => 'Score SEO moyen de ' . $avg_score . '/100. Plus de la moitié de vos articles ont besoin d\'améliorations. Commencez par les articles critiques (score < 30).' );
        } elseif ( $avg_score < 70 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => 'Score SEO moyen de ' . $avg_score . '/100. Votre site est en progression. Concentrez-vous sur les articles entre 30 et 60 pour un gain rapide.' );
        } else {
            $report['insights'][] = array( 'level' => 'positive', 'text' => 'Score SEO moyen de ' . $avg_score . '/100. Excellent niveau de qualité. Continuez la mise à jour régulière.' );
        }
        if ( $stale > 5 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => $stale . ' articles n\'ont pas été mis à jour depuis plus de 6 mois. Google favorise le contenu frais. Planifiez une mise à jour mensuelle.' );
        }
        if ( $drafts > 0 ) {
            $report['insights'][] = array( 'level' => 'info', 'text' => $drafts . ' brouillon(s) prêt(s) à publier. Publiez-les pour renforcer vos cocons sémantiques.' );
        }

        return $report;
    }

    private static function generate_report_performance( $period = 30 ) {
        global $wpdb;

        // Guard GSC
        $gsc_connected = ! empty( get_option( 'hts_gsc_tokens', '' ) ) || ! empty( get_option( 'hts_gsc_site', '' ) );
        if ( ! $gsc_connected ) {
            return array(
                'title' => 'Rapport Performance',
                'summary' => 'Google Search Console n\'est pas connecté.',
                'kpis' => array(),
                'charts' => array(),
                'tables' => array(),
                'insights' => array( array( 'level' => 'critical', 'text' => 'Connectez Google Search Console dans Réglages → GSC pour débloquer ce rapport. Les données de trafic, positions et requêtes sont indispensables pour piloter votre SEO.' ) ),
            );
        }

        $gsc_summary = array();
        if ( method_exists( __CLASS__, 'get_gsc_summary' ) ) {
            $gsc_summary = self::get_gsc_summary() ?: array();
        }

        $clicks     = (int) ( $gsc_summary['total_clicks'] ?? $gsc_summary['clicks'] ?? 0 );
        $impressions = (int) ( $gsc_summary['impressions'] ?? 0 );
        $position   = round( (float) ( $gsc_summary['avg_position'] ?? $gsc_summary['position'] ?? 0 ), 1 );
        $ctr        = round( (float) ( $gsc_summary['avg_ctr'] ?? $gsc_summary['ctr'] ?? 0 ), 2 );

        // Top pages
        $gsc_table = $wpdb->prefix . 'hts_gsc_pages';
        $gsc_exists = (bool) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $gsc_table ) );
        $top_pages = array();
        $quick_wins = array();
        if ( $gsc_exists ) {
            $top_pages = $wpdb->get_results( "SELECT page_url, clicks, impressions, position, ctr FROM {$gsc_table} ORDER BY clicks DESC LIMIT 10" );
            $quick_wins = $wpdb->get_results( "SELECT page_url, clicks, impressions, position FROM {$gsc_table} WHERE position BETWEEN 5 AND 15 AND impressions > 10 ORDER BY impressions DESC LIMIT 10" );
        }

        // Top queries
        $gsc_q_table = $wpdb->prefix . 'hts_gsc_queries';
        $gsc_q_exists = (bool) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $gsc_q_table ) );
        $top_queries = array();
        if ( $gsc_q_exists ) {
            $top_queries = $wpdb->get_results( "SELECT query, clicks, impressions, position, ctr FROM {$gsc_q_table} ORDER BY clicks DESC LIMIT 15" );
        }

        $report = array(
            'title' => 'Rapport Performance SEO',
            'summary' => $clicks > 0
                ? '**' . number_format( $clicks ) . ' clics/mois** pour **' . number_format( $impressions ) . ' impressions** (CTR ' . $ctr . '%). Position moyenne : **' . $position . '** '
                  . ( $position > 15 ? '= page 2+ Google, quasi invisible.' : ( $position > 7 ? '= bas de page 1, potentiel à débloquer.' : '= bonne visibilité.' ) )
                  . ( ! empty( $quick_wins ) ? ' **' . count( $quick_wins ) . ' quick wins** détectés.' : '' )
                : 'Aucune donnée Search Console disponible sur cette période.',
            'kpis' => array(
                array( 'label' => 'Clics', 'value' => number_format( $clicks ), 'unit' => '/' . $period . 'j', 'trend' => 'neutral', 'delta' => '' ),
                array( 'label' => 'Impressions', 'value' => number_format( $impressions ), 'unit' => '/' . $period . 'j', 'trend' => 'neutral', 'delta' => '' ),
                array( 'label' => 'Position moy.', 'value' => (string) $position, 'unit' => '', 'trend' => $position <= 15 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'CTR moyen', 'value' => $ctr . '%', 'unit' => '', 'trend' => $ctr >= 3 ? 'up' : 'neutral', 'delta' => '' ),
                array( 'label' => 'Quick wins', 'value' => (string) count( $quick_wins ), 'unit' => 'pos 5-15', 'trend' => count( $quick_wins ) > 0 ? 'up' : 'neutral', 'delta' => '' ),
            ),
            'charts' => array(),
            'tables' => array(),
            'insights' => array(),
        );

        // Chart top pages
        if ( ! empty( $top_pages ) ) {
            $labels = array();
            $data = array();
            foreach ( array_slice( $top_pages, 0, 10 ) as $tp ) {
                $path = wp_parse_url( $tp->page_url, PHP_URL_PATH ) ?: $tp->page_url;
                $labels[] = mb_substr( $path, 0, 30 );
                $data[] = (int) $tp->clicks;
            }
            $report['charts'][] = array( 'type' => 'bar', 'title' => 'Top 10 pages par clics', 'labels' => $labels, 'data' => $data, 'commentary' => ! empty( $labels ) ? 'Vos ' . count( $labels ) . ' meilleures pages concentrent le trafic. Si une seule page capte plus de 40% des clics, votre site est vulnérable — diversifiez vos sources de trafic.' : '' );
        }

        // Tables
        if ( ! empty( $top_queries ) ) {
            $rows = array();
            foreach ( $top_queries as $q ) {
                $rows[] = array( mb_substr( $q->query, 0, 40 ), (string) $q->clicks, (string) $q->impressions, (string) round( $q->position, 1 ), $q->ctr . '%' );
            }
            $report['tables'][] = array( 'title' => 'Top requêtes', 'headers' => array( 'Requête', 'Clics', 'Impressions', 'Position', 'CTR' ), 'rows' => $rows, 'commentary' => 'Les requêtes avec beaucoup d\'impressions mais peu de clics = votre snippet n\'attire pas. Réécrivez meta title et description des pages correspondantes.' );
        }

        if ( ! empty( $quick_wins ) ) {
            $rows = array();
            foreach ( $quick_wins as $qw ) {
                $path = wp_parse_url( $qw->page_url, PHP_URL_PATH ) ?: $qw->page_url;
                $rows[] = array( mb_substr( $path, 0, 40 ), (string) $qw->impressions, (string) round( $qw->position, 1 ) );
            }
            $report['tables'][] = array( 'title' => 'Quick Wins (position 5-15)', 'headers' => array( 'Page', 'Impressions', 'Position' ), 'rows' => $rows, 'commentary' => ! empty( $rows ) ? count( $rows ) . ' pages en position 5-15 = vos meilleurs leviers. Chaque page qui monte de position 10 à 3 = **x5 à x10 clics**.' : 'Aucun quick win détecté.' );
        }

        // Insights
        if ( $position > 0 && $position <= 10 ) {
            $report['insights'][] = array( 'level' => 'positive', 'text' => 'Position moyenne de ' . $position . '. Vos pages se positionnent bien dans le top 10 Google.' );
        } elseif ( $position > 20 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => 'Position moyenne de ' . $position . '. Vos pages apparaissent en page 2-3 de Google. Améliorez le contenu et le maillage pour gagner des positions.' );
        }
        if ( count( $quick_wins ) > 3 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => count( $quick_wins ) . ' pages en position 5-15 avec du trafic. Ce sont des opportunités immédiates : améliorez leur contenu pour les faire monter en top 3.' );
        }
        if ( $ctr > 0 && $ctr < 2 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => 'CTR moyen de ' . $ctr . '%. Vos titres et méta descriptions n\'attirent pas assez de clics. Réécrivez les metas des pages à fort potentiel.' );
        }

        return $report;
    }

    private static function generate_report_audit( $period = 30 ) {
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";

        $no_title = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_meta_title' WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND (pm.meta_value IS NULL OR pm.meta_value = '')" );
        $no_desc = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_hts_meta_description' WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND (pm.meta_value IS NULL OR pm.meta_value = '')" );
        $no_alt = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT a.ID) FROM {$wpdb->posts} a LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = a.ID AND pm.meta_key = '_wp_attachment_image_alt' WHERE a.post_type = 'attachment' AND a.post_mime_type LIKE 'image/%' AND (pm.meta_value IS NULL OR pm.meta_value = '')" );

        $redirects = 0;
        $redir_table = $wpdb->prefix . 'hts_redirects';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $redir_table ) ) ) {
            $redirects = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$redir_table} WHERE status = 'active'" );
        }

        $health_alerts = array();
        if ( method_exists( __CLASS__, 'get_health_alerts' ) ) {
            $health_alerts = self::get_health_alerts() ?: array();
        }

        $avg_score = class_exists( 'HTS_Coach' ) ? (int) self::get_average_score() : 0;

        $report = array(
            'title' => 'Audit Technique SEO',
            'summary' => 'Score technique **' . $avg_score . '/100**. '
                . ( $no_title > 0 ? '**' . $no_title . ' pages sans meta title** = CTR bloqué. ' : '' )
                . ( $no_desc > 0 ? '**' . $no_desc . ' pages sans meta description**. ' : '' )
                . ( count( $health_alerts ) > 0 ? count( $health_alerts ) . ' alertes santé actives.' : 'Aucune alerte critique.' ),
            'kpis' => array(
                array( 'label' => 'Score technique', 'value' => (string) $avg_score, 'unit' => '/100', 'trend' => $avg_score >= 60 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Sans meta title', 'value' => (string) $no_title, 'unit' => '', 'trend' => $no_title === 0 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Sans meta desc', 'value' => (string) $no_desc, 'unit' => '', 'trend' => $no_desc === 0 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Redirections', 'value' => (string) $redirects, 'unit' => 'actives', 'trend' => 'neutral', 'delta' => '' ),
                array( 'label' => 'Images sans ALT', 'value' => (string) $no_alt, 'unit' => '', 'trend' => $no_alt === 0 ? 'up' : 'down', 'delta' => '' ),
                array( 'label' => 'Alertes santé', 'value' => (string) count( $health_alerts ), 'unit' => '', 'trend' => count( $health_alerts ) === 0 ? 'up' : 'down', 'delta' => '' ),
            ),
            'charts' => array(
                array(
                    'type' => 'bar', 'title' => 'Problèmes par catégorie',
                    'labels' => array( 'Meta title', 'Meta desc', 'Images ALT', 'Redirections', 'Alertes' ),
                    'data' => array( $no_title, $no_desc, $no_alt, $redirects, count( $health_alerts ) ),
                    'commentary' => 'Votre priorité = la barre la plus haute. Les meta title/description manquantes bloquent votre CTR dans Google. Les images sans ALT sont une opportunité manquée pour Google Images.',
                ),
            ),
            'tables' => array(),
            'insights' => array(),
        );

        // Table alertes
        if ( ! empty( $health_alerts ) ) {
            $rows = array();
            foreach ( array_slice( $health_alerts, 0, 10 ) as $a ) {
                $rows[] = array( $a['test'] ?? $a['type'] ?? '?', mb_substr( $a['detail'] ?? $a['message'] ?? $a['text'] ?? '', 0, 60 ), $a['status'] ?? $a['severity'] ?? $a['level'] ?? 'info' );
            }
            $report['tables'][] = array( 'title' => 'Alertes santé', 'headers' => array( 'Type', 'Description', 'Sévérité' ), 'rows' => $rows, 'commentary' => count( $rows ) . ' alertes détectées. Les alertes critiques bloquent votre référencement — Google refuse d\'indexer un site avec des erreurs techniques.' );
        }

        // Insights
        if ( $no_title > 0 ) {
            $report['insights'][] = array( 'level' => $no_title > 5 ? 'critical' : 'high', 'text' => $no_title . ' page(s) sans meta title. Google affiche le titre de la page dans les résultats — sans meta title optimisé, votre CTR chute. Action : utilisez le panneau SEO de chaque article.' );
        }
        if ( $no_desc > 0 ) {
            $report['insights'][] = array( 'level' => $no_desc > 5 ? 'critical' : 'high', 'text' => $no_desc . ' page(s) sans meta description. La description apparaît sous le titre dans Google — c\'est votre argument de vente. Rédigez-la pour chaque page.' );
        }
        if ( $no_alt > 10 ) {
            $report['insights'][] = array( 'level' => 'high', 'text' => $no_alt . ' images sans texte alternatif (ALT). Google Images génère du trafic — chaque image doit avoir un ALT descriptif contenant votre mot-clé.' );
        }
        if ( count( $health_alerts ) === 0 && $no_title === 0 && $no_desc === 0 ) {
            $report['insights'][] = array( 'level' => 'positive', 'text' => 'Aucun problème technique majeur détecté. Votre site est techniquement sain.' );
        }

        return $report;
    }

    private static function generate_report_full( $period = 30 ) {
        $linking = self::generate_report_linking( $period );
        $content = self::generate_report_content( $period );
        $perf    = self::generate_report_performance( $period );
        $audit   = self::generate_report_audit( $period );

        $report = array(
            'title' => 'Diagnostic SEO Complet',
            'summary' => '',
            'kpis' => array(),
            'charts' => array(),
            'tables' => array(),
            'insights' => array(),
        );

        // Top 2 KPIs de chaque
        foreach ( array( $content, $perf, $linking, $audit ) as $sub ) {
            $kpis = $sub['kpis'] ?? array();
            $report['kpis'] = array_merge( $report['kpis'], array_slice( $kpis, 0, 2 ) );
        }

        // 1 chart de chaque (le premier)
        foreach ( array( $content, $perf, $linking, $audit ) as $sub ) {
            if ( ! empty( $sub['charts'][0] ) ) {
                $report['charts'][] = $sub['charts'][0];
            }
        }

        // 1 table de chaque (5 lignes max)
        foreach ( array( $content, $perf, $linking, $audit ) as $sub ) {
            if ( ! empty( $sub['tables'][0] ) ) {
                $t = $sub['tables'][0];
                $t['rows'] = array_slice( $t['rows'] ?? array(), 0, 5 );
                $report['tables'][] = $t;
            }
        }

        // Tous les insights critical + high
        foreach ( array( $linking, $content, $perf, $audit ) as $sub ) {
            foreach ( $sub['insights'] ?? array() as $ins ) {
                if ( in_array( $ins['level'] ?? '', array( 'critical', 'high', 'positive' ), true ) ) {
                    $report['insights'][] = $ins;
                }
            }
        }
        // Max 8 insights
        $report['insights'] = array_slice( $report['insights'], 0, 8 );

        return $report;
    }

    /**
     * Anthropic streaming API call with tool_use support (Sprint 4.5).
     *
     * Replaces the simple stream with a multi-turn tool loop:
     * 1. Send initial request with tools
     * 2. If LLM returns tool_use → execute tool → append tool_result → retry
     * 3. When LLM returns text (end_turn) → stream to client
     *
     * Tool calls are invisible to the user (no text streamed during tool phase).
     * A "thinking" indicator is sent so the UI can show a spinner.
     *
     * @since 4.5
     */
    private static function call_anthropic_stream( $api_key, $model, $system, $messages, $on_chunk, $max_tokens_override = 0 ) {
        $temperature = self::get_temperature();
        $max_tokens  = $max_tokens_override > 0 ? $max_tokens_override : self::MAX_TOKENS_RESPONSE;

        // Sprint 4.5: Tool definitions (only for Anthropic models that support it)
        $tools = self::get_tool_definitions();

        $full_text  = '';
        $usage      = array( 'input_tokens' => 0, 'output_tokens' => 0 );
        $tools_used = array(); // Sprint 4.7a: track tool names for analytics

        // Messages accumulator for multi-turn tool loop
        $loop_messages = $messages;
        $iteration     = 0;

        while ( $iteration < self::TOOL_MAX_ITERATIONS ) {
            $iteration++;

            // Sprint 5.4b: Debug tool loop
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf(
                    'Coach stream iter %d/%d, model=%s, msgs=%d, full_text=%d chars',
                    $iteration, self::TOOL_MAX_ITERATIONS, $model, count( $loop_messages ), strlen( $full_text )
                ), 'info', 'coach' );
            }

            $payload_arr = array(
                'model'       => $model,
                'max_tokens'  => $max_tokens,
                'temperature' => $temperature,
                'system'      => $system,
                'messages'    => $loop_messages,
                'stream'      => true,
            );

            // Add tools on all iterations within the tool loop
            if ( ! empty( $tools ) && $iteration < self::TOOL_MAX_ITERATIONS ) {
                $payload_arr['tools'] = $tools;
            }

            $payload = wp_json_encode( $payload_arr );

            // Accumulators for this iteration
            $iter_text       = '';
            $iter_tool_calls = array();
            $iter_stop       = '';
            $current_tool    = null;
            $tool_input_json = '';
            $curl_line_buffer = ''; // S14 fix: SSE line buffer persists between WRITEFUNCTION calls

            $ch = curl_init( self::API_URL );
            curl_setopt_array( $ch, array(
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $payload,
                CURLOPT_HTTPHEADER     => array(
                    'Content-Type: application/json',
                    'x-api-key: ' . $api_key,
                    'anthropic-version: 2023-06-01',
                ),
                CURLOPT_TIMEOUT        => self::TIMEOUT_SECONDS,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_RETURNTRANSFER => false,
                CURLOPT_WRITEFUNCTION  => function( $ch, $data ) use ( &$iter_text, &$iter_tool_calls, &$iter_stop, &$current_tool, &$tool_input_json, &$usage, &$full_text, $on_chunk, $iteration, &$curl_line_buffer ) {
                    // S14 fix: buffer incomplete lines between curl WRITEFUNCTION calls
                    // curl can split data at ANY byte boundary, breaking JSON mid-line
                    $curl_line_buffer .= $data;

                    // Process only complete lines (terminated by \n)
                    while ( ( $nl_pos = strpos( $curl_line_buffer, "\n" ) ) !== false ) {
                        $line = substr( $curl_line_buffer, 0, $nl_pos );
                        $curl_line_buffer = substr( $curl_line_buffer, $nl_pos + 1 );

                        $line = trim( $line );
                        if ( strpos( $line, 'data: ' ) !== 0 ) continue;

                        $json_str = substr( $line, 6 );
                        if ( $json_str === '[DONE]' ) continue;

                        $event = json_decode( $json_str, true );
                        if ( ! is_array( $event ) ) continue;

                        $type = $event['type'] ?? '';

                        // content_block_start → detect tool_use block
                        if ( $type === 'content_block_start' ) {
                            $block_type = $event['content_block']['type'] ?? '';
                            if ( $block_type === 'tool_use' ) {
                                $current_tool = array(
                                    'id'    => $event['content_block']['id'] ?? '',
                                    'name'  => $event['content_block']['name'] ?? '',
                                );
                                $tool_input_json = '';
                            } else {
                                $current_tool = null;
                            }
                        }

                        // content_block_delta → text or tool input
                        if ( $type === 'content_block_delta' ) {
                            if ( $current_tool !== null ) {
                                // Accumulate tool input JSON
                                $partial = $event['delta']['partial_json'] ?? '';
                                $tool_input_json .= $partial;
                            } else {
                                // Regular text delta
                                $delta = $event['delta']['text'] ?? '';
                                if ( $delta !== '' ) {
                                    $iter_text .= $delta;
                                    $full_text .= $delta;
                                    if ( is_callable( $on_chunk ) ) {
                                        $on_chunk( $delta );
                                    }
                                }
                            }
                        }

                        // content_block_stop → finalize tool call
                        if ( $type === 'content_block_stop' && $current_tool !== null ) {
                            $input = json_decode( $tool_input_json, true ) ?: array();
                            $iter_tool_calls[] = array(
                                'id'    => $current_tool['id'],
                                'name'  => $current_tool['name'],
                                'input' => $input,
                            );
                            $current_tool    = null;
                            $tool_input_json = '';
                        }

                        // message_delta → stop reason + usage
                        if ( $type === 'message_delta' ) {
                            $iter_stop = $event['delta']['stop_reason'] ?? $iter_stop;
                            if ( isset( $event['usage'] ) ) {
                                $usage['output_tokens'] += (int) ( $event['usage']['output_tokens'] ?? 0 );
                            }
                        }

                        // message_start → input usage
                        if ( $type === 'message_start' && isset( $event['message']['usage'] ) ) {
                            $usage['input_tokens'] += (int) ( $event['message']['usage']['input_tokens'] ?? 0 );
                        }

                        // Sprint 5.4b: Handle error events in stream
                        if ( $type === 'error' ) {
                            $err_msg = $event['error']['message'] ?? 'Unknown stream error';
                            if ( function_exists( 'hts_add_log' ) ) {
                                hts_add_log( 'Coach SSE error event: ' . $err_msg, 'error', 'coach' );
                            }
                            // Send error to client via text
                            $error_text = "\n\nErreur API : " . $err_msg;
                            $iter_text .= $error_text;
                            $full_text .= $error_text;
                            if ( is_callable( $on_chunk ) ) {
                                $on_chunk( $error_text );
                            }
                        }
                    }

                    return strlen( $data );
                },
            ) );

            $result    = curl_exec( $ch );
            $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
            $curl_err  = curl_error( $ch );
            curl_close( $ch );

            if ( $result === false || ! empty( $curl_err ) ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Coach stream curl error iter ' . $iteration . ': ' . $curl_err, 'error', 'coach' );
                }
                return new \WP_Error( 'stream_network', 'Erreur de connexion au Coach SEO : ' . $curl_err );
            }

            if ( $http_code < 200 || $http_code >= 300 ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Coach stream HTTP ' . $http_code . ' iter ' . $iteration . ', text so far: ' . substr( $full_text, 0, 200 ), 'error', 'coach' );
                }
                return new \WP_Error( 'stream_http', 'Erreur API (HTTP ' . $http_code . ')' );
            }

            // If no tool calls → we're done
            if ( empty( $iter_tool_calls ) || $iter_stop !== 'tool_use' ) {
                break;
            }

            // ── Tool loop: execute tools and continue conversation ──
            // Send a "thinking" indicator to the user
            if ( is_callable( $on_chunk ) ) {
                $on_chunk( "\n\n*Analyse des données en cours…*\n\n" );
            }

            // Build assistant message with tool_use blocks
            $assistant_content = array();
            if ( $iter_text !== '' ) {
                $assistant_content[] = array( 'type' => 'text', 'text' => $iter_text );
            }
            foreach ( $iter_tool_calls as $tc ) {
                $assistant_content[] = array(
                    'type'  => 'tool_use',
                    'id'    => $tc['id'],
                    'name'  => $tc['name'],
                    'input' => $tc['input'],
                );
            }
            $loop_messages[] = array( 'role' => 'assistant', 'content' => $assistant_content );

            // Build tool results message
            $tool_results_content = array();
            foreach ( $iter_tool_calls as $tc ) {
                $tool_result = self::execute_tool( $tc['name'], $tc['input'] );
                $tools_used[] = $tc['name']; // Sprint 4.7a: track for analytics

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf(
                        'Coach tool_use: %s(%s) → %d chars',
                        $tc['name'],
                        wp_json_encode( $tc['input'] ),
                        strlen( $tool_result )
                    ), 'info', 'coach' );
                }

                $tool_results_content[] = array(
                    'type'       => 'tool_result',
                    'tool_use_id' => $tc['id'],
                    'content'    => $tool_result,
                );
            }
            $loop_messages[] = array( 'role' => 'user', 'content' => $tool_results_content );

        } // end while tool loop

        return array(
            'text'       => $full_text,
            'usage'      => $usage,
            'provider'   => 'anthropic',
            'model'      => $model,
            'tools_used' => array_unique( $tools_used ),
        );
    }

    /**
     * OpenAI streaming API call with function calling / tool_use support.
     *
     * Sprint 4.7a: Mirrors the Anthropic tool loop pattern:
     * 1. Send initial request with tools (function calling)
     * 2. If LLM returns tool_calls → execute tool → append tool result → retry
     * 3. When LLM returns text (no tool_calls) → stream to client
     *
     * @since 4.0 Sprint 2.2
     * @since 4.7a  Tool loop via function calling.
     * @param string   $model     Modèle OpenAI.
     * @param string   $system    System prompt.
     * @param array    $messages  Messages (format Anthropic, sera converti).
     * @param callable $on_chunk  Callback( string $text_delta ).
     * @return array|WP_Error     { text, usage, provider, model, tools_used }
     */
    private static function call_openai_stream( $model, $system, $messages, $on_chunk, $max_tokens_override = 0 ) {
        $openai_key = self::get_openai_api_key();
        if ( empty( $openai_key ) ) {
            return new \WP_Error( 'no_openai_key', 'La clé API OpenAI n\u0027est pas configurée.' );
        }

        $temperature = self::get_temperature();
        $max_tokens  = $max_tokens_override > 0 ? $max_tokens_override : self::MAX_TOKENS_RESPONSE;

        // Sprint 4.7a: OpenAI function calling tool definitions
        $tools = self::get_tool_definitions_openai();

        $full_text   = '';
        $usage       = array( 'input_tokens' => 0, 'output_tokens' => 0 );
        $tools_used  = array();

        // Convertir messages Anthropic → OpenAI (initial conversion)
        $oai_messages = array();
        $oai_messages[] = array( 'role' => 'system', 'content' => $system );
        foreach ( $messages as $msg ) {
            $role    = $msg['role'] ?? 'user';
            $content = $msg['content'] ?? '';
            if ( is_array( $content ) ) {
                $parts = array();
                foreach ( $content as $part ) {
                    if ( is_string( $part ) ) {
                        $parts[] = $part;
                    } elseif ( isset( $part['text'] ) ) {
                        $parts[] = $part['text'];
                    }
                }
                $content = implode( "\n", $parts );
            }
            $oai_messages[] = array( 'role' => $role, 'content' => $content );
        }

        // Tool loop (max iterations = TOOL_MAX_ITERATIONS)
        $iteration = 0;
        $http_code = 200;
        $curl_err  = '';

        while ( $iteration < self::TOOL_MAX_ITERATIONS ) {
            $iteration++;

            $payload_arr = array(
                'model'          => $model,
                'max_tokens'     => $max_tokens,
                'temperature'    => $temperature,
                'messages'       => $oai_messages,
                'stream'         => true,
                'stream_options' => array( 'include_usage' => true ),
            );

            // Add tools on all iterations within the tool loop
            if ( ! empty( $tools ) && $iteration < self::TOOL_MAX_ITERATIONS ) {
                $payload_arr['tools'] = $tools;
            }

            $payload = wp_json_encode( $payload_arr );

            // Accumulators for this iteration
            $iter_text       = '';
            $iter_tool_calls = array(); // { id, name, arguments_json }
            $iter_finish     = '';
            $curl_line_buffer_oai = ''; // S14 fix: SSE line buffer

            $ch = curl_init( self::OPENAI_API_URL );
            curl_setopt_array( $ch, array(
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $payload,
                CURLOPT_HTTPHEADER     => array(
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $openai_key,
                ),
                CURLOPT_TIMEOUT        => self::TIMEOUT_SECONDS,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_RETURNTRANSFER => false,
                CURLOPT_WRITEFUNCTION  => function( $ch, $data ) use ( &$iter_text, &$iter_tool_calls, &$iter_finish, &$usage, &$full_text, $on_chunk, $iteration, &$curl_line_buffer_oai ) {
                    $curl_line_buffer_oai .= $data;

                    while ( ( $nl_pos = strpos( $curl_line_buffer_oai, "\n" ) ) !== false ) {
                        $line = substr( $curl_line_buffer_oai, 0, $nl_pos );
                        $curl_line_buffer_oai = substr( $curl_line_buffer_oai, $nl_pos + 1 );

                        $line = trim( $line );
                        if ( strpos( $line, 'data: ' ) !== 0 ) continue;

                        $json_str = substr( $line, 6 );
                        if ( $json_str === '[DONE]' ) continue;

                        $event = json_decode( $json_str, true );
                        if ( ! is_array( $event ) ) continue;

                        $delta  = $event['choices'][0]['delta'] ?? array();
                        $finish = $event['choices'][0]['finish_reason'] ?? null;

                        if ( $finish ) {
                            $iter_finish = $finish;
                        }

                        // ── Text content delta ──
                        $text_delta = $delta['content'] ?? '';
                        if ( $text_delta !== '' ) {
                            $iter_text .= $text_delta;
                            $full_text .= $text_delta;
                            if ( is_callable( $on_chunk ) ) {
                                $on_chunk( $text_delta );
                            }
                        }

                        // ── Tool calls delta (OpenAI streams tool calls incrementally) ──
                        if ( isset( $delta['tool_calls'] ) ) {
                            foreach ( $delta['tool_calls'] as $tc_delta ) {
                                $idx = (int) ( $tc_delta['index'] ?? 0 );

                                // Initialize tool call entry if new
                                if ( ! isset( $iter_tool_calls[ $idx ] ) ) {
                                    $iter_tool_calls[ $idx ] = array(
                                        'id'             => $tc_delta['id'] ?? '',
                                        'name'           => $tc_delta['function']['name'] ?? '',
                                        'arguments_json' => '',
                                    );
                                }

                                // Accumulate ID (first chunk only)
                                if ( ! empty( $tc_delta['id'] ) ) {
                                    $iter_tool_calls[ $idx ]['id'] = $tc_delta['id'];
                                }
                                // Accumulate function name (first chunk only)
                                if ( ! empty( $tc_delta['function']['name'] ) ) {
                                    $iter_tool_calls[ $idx ]['name'] = $tc_delta['function']['name'];
                                }
                                // Accumulate arguments JSON (streamed incrementally)
                                if ( isset( $tc_delta['function']['arguments'] ) ) {
                                    $iter_tool_calls[ $idx ]['arguments_json'] .= $tc_delta['function']['arguments'];
                                }
                            }
                        }

                        // ── Usage (last chunk with stream_options.include_usage) ──
                        if ( isset( $event['usage'] ) ) {
                            $usage['input_tokens']  += (int) ( $event['usage']['prompt_tokens'] ?? 0 );
                            $usage['output_tokens'] += (int) ( $event['usage']['completion_tokens'] ?? 0 );
                        }
                    }

                    return strlen( $data );
                },
            ) );

            $result    = curl_exec( $ch );
            $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
            $curl_err  = curl_error( $ch );
            curl_close( $ch );

            if ( $result === false || ! empty( $curl_err ) ) {
                return new \WP_Error( 'stream_network', 'Erreur de connexion (OpenAI) : ' . $curl_err );
            }

            if ( $http_code < 200 || $http_code >= 300 ) {
                return new \WP_Error( 'stream_http', 'Erreur API OpenAI (HTTP ' . $http_code . ')' );
            }

            // If no tool calls → we're done
            if ( empty( $iter_tool_calls ) || $iter_finish !== 'tool_calls' ) {
                break;
            }

            // ── Tool loop: execute tools and continue conversation ──
            if ( is_callable( $on_chunk ) ) {
                $on_chunk( "\n\n*Analyse des données en cours…*\n\n" );
            }

            // Build assistant message with tool_calls (OpenAI format)
            $assistant_msg = array(
                'role'       => 'assistant',
                'content'    => $iter_text !== '' ? $iter_text : null,
                'tool_calls' => array(),
            );
            foreach ( $iter_tool_calls as $tc ) {
                $assistant_msg['tool_calls'][] = array(
                    'id'       => $tc['id'],
                    'type'     => 'function',
                    'function' => array(
                        'name'      => $tc['name'],
                        'arguments' => $tc['arguments_json'],
                    ),
                );
            }
            $oai_messages[] = $assistant_msg;

            // Execute each tool and append results
            foreach ( $iter_tool_calls as $tc ) {
                $input       = json_decode( $tc['arguments_json'], true ) ?: array();
                $tool_result = self::execute_tool( $tc['name'], $input );

                $tools_used[] = $tc['name'];

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf(
                        'Coach tool_use (OpenAI): %s(%s) → %d chars',
                        $tc['name'],
                        $tc['arguments_json'],
                        strlen( $tool_result )
                    ), 'info', 'coach' );
                }

                $oai_messages[] = array(
                    'role'         => 'tool',
                    'tool_call_id' => $tc['id'],
                    'content'      => $tool_result,
                );
            }

        } // end while tool loop

        return array(
            'text'       => $full_text,
            'usage'      => $usage,
            'provider'   => 'openai',
            'model'      => $model,
            'tools_used' => array_unique( $tools_used ),
        );
    }

    /**
     * Version streaming de ask().
     *
     * Identique à ask() mais utilise les méthodes *_stream() avec callback.
     * Le callback envoie directement les SSE events au navigateur.
     *
     * @since 4.0 Sprint 2.2
     * @param string   $question    Question utilisateur.
     * @param int      $post_id     Post ID contexte.
     * @param int      $user_id     User ID.
     * @param callable $on_chunk    Callback( string $text_delta ).
     * @return array|WP_Error       Résultat complet (pour post-traitement).
     */
    public function ask_stream( $question, $post_id, $user_id, $on_chunk, $forced_session_id = 0 ) {
        // ── Rate limit ──
        if ( ! self::check_rate_limit( $user_id ) ) {
            return new \WP_Error( 'rate_limit', 'Vous avez atteint la limite horaire de requêtes. Réessayez dans quelques minutes.' );
        }

        $freemium = class_exists( 'HTS_Subscription' ) ? ! HTS_Subscription::can( 'coach_unlimited' ) : false;
        $budget_exceeded = false;

        if ( $freemium ) {
            // V2.7 fix: Check freemium quota in streaming path (was missing)
            if ( ! self::check_freemium_quota() ) {
                $usage = self::get_freemium_usage();
                return new \WP_Error(
                    'freemium_exhausted',
                    sprintf(
                        'Vous avez utilisé vos %d questions gratuites ce mois-ci. Passez à Pro pour un accès illimité, ou patientez jusqu\'au 1er %s.',
                        self::FREEMIUM_LIMIT,
                        self::next_month_label()
                    )
                );
            }
        } else {
            $budget_exceeded = ! self::check_budget_guard();
            $api_key = self::get_api_key();
            if ( empty( $api_key ) && empty( self::get_openai_api_key() ) ) {
                return new \WP_Error( 'no_api_key', 'Aucune clé API configurée (Anthropic ou OpenAI). Rendez-vous dans Réglages.' );
            }
        }

        // ── Session ──
        // Si le JS envoie un session_id valide, l'utiliser directement
        // Sinon fallback sur get_or_create_session()
        if ( $forced_session_id > 0 ) {
            $session_id = $forced_session_id;
            // Vérifier que la session existe et appartient à l'utilisateur
            global $wpdb;
            $ses_table = $wpdb->prefix . self::SESSIONS_TABLE;
            $valid = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$ses_table} WHERE id = %d AND user_id = %d",
                $session_id, $user_id
            ) );
            if ( ! $valid ) {
                // Session invalide → fallback
                $session    = self::get_or_create_session( $user_id );
                $session_id = $session['id'] ?? 0;
            }
        } else {
            $session    = self::get_or_create_session( $user_id );
            $session_id = $session['id'] ?? 0;
        }
        self::process_pending_summaries();

        // ── Contexte + messages + prompt ──
        $t_start = microtime( true ); // Sprint 4.8: latency tracking
        try {
            $context  = self::build_context( $post_id, $question );
        } catch ( \Throwable $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Coach build_context crash: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine(), 'error', 'coach' );
            }
            $context = array(
                'site_url'    => site_url(),
                'site_name'   => get_bloginfo( 'name' ),
                '_intent'     => 'simple',
                '_error'      => 'Contexte partiel (erreur interne)',
            );
        }
        $messages = self::build_messages( $question, $user_id, $session_id );
        $system   = self::build_system_prompt( $context, $user_id );
        $intent   = $context['_intent'] ?? 'global';
        $model    = self::get_model( $intent );
        $provider = self::get_provider( $model );

        // ── Optim coûts : si budget dépassé, forcer gpt-4o-mini (le moins cher) ──
        if ( $budget_exceeded && $model !== self::OPENAI_MODEL ) {
            $has_openai = ! empty( self::get_openai_api_key() );
            if ( $has_openai ) {
                $original_model = $model;
                $model    = self::OPENAI_MODEL; // gpt-4o-mini
                $provider = 'openai';
                if ( is_callable( $on_chunk ) ) {
                    $on_chunk( "*Le mode analyse avancée a atteint sa limite mensuelle. Je continue en mode rapide.*\n\n" );
                }
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Coach budget exceeded — downgrade ' . $original_model . ' → ' . $model, 'warning', 'coach' );
                }
            } else {
                // Pas d'OpenAI, pas de fallback possible → on laisse passer sur Haiku quand même
                // (le hard limit 2M est assez haut pour ne pas bloquer en pratique)
            }
        }

        // Sprint 5.4b: Debug intent routing
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'Coach ask_stream: intent=%s, model=%s, provider=%s, system_len=%d, msgs=%d, q="%s"',
                $intent, $model, $provider, strlen( $system ), count( $messages ), mb_substr( $question, 0, 60 )
            ), 'info', 'coach' );
        }

        // Sprint 5.0: Store intent for follow-up routing
        self::set_last_intent( $intent, $user_id );

        // v4.0 Sprint 4.1 : Agent Mode → plus de tokens pour les plans
        // Sprint 4.7c : adaptive max_tokens par intent
        $max_tokens_override = self::get_max_tokens( $intent );
        if ( $intent === 'action' ) $max_tokens_override = self::AGENT_MAX_TOKENS;

        // ── Appel streaming selon provider ──
        if ( $provider === 'openai' ) {
            $result = self::call_openai_stream( $model, $system, $messages, $on_chunk, $max_tokens_override );
        } else {
            $result = self::call_anthropic_stream( $api_key, $model, $system, $messages, $on_chunk, $max_tokens_override );

            // ── Fallback OpenAI si Anthropic échoue (401/403 = clé invalide) ──
            if ( is_wp_error( $result ) && ! empty( self::get_openai_api_key() ) ) {
                $err_code = $result->get_error_code();
                if ( in_array( $err_code, array( 'stream_http', 'stream_network', 'anthropic_error' ), true )
                    || strpos( $result->get_error_message(), '401' ) !== false
                    || strpos( $result->get_error_message(), '403' ) !== false
                ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( 'Coach Anthropic failed (' . $result->get_error_message() . ') — fallback OpenAI gpt-4o-mini', 'warning', 'coach' );
                    }
                    if ( is_callable( $on_chunk ) ) {
                        $on_chunk( "\n\n*Basculement vers le mode rapide.*\n\n" );
                    }
                    $model    = self::OPENAI_MODEL;
                    $provider = 'openai';
                    $result   = self::call_openai_stream( $model, $system, $messages, $on_chunk, $max_tokens_override );
                }
            }
        }

        if ( is_wp_error( $result ) ) {
            // Sprint 4.8: track error in analytics
            $latency_ms = (int) ( ( microtime( true ) - $t_start ) * 1000 );
            self::track_analytics( array(
                'user_id'          => $user_id,
                'session_id'       => $session_id,
                'intent'           => $intent,
                'model'            => $model,
                'provider'         => $provider,
                'latency_ms'       => $latency_ms,
                'error_code'       => $result->get_error_code(),
                'question_preview' => $question,
            ) );
            return $result;
        }

        // ── Post-traitement identique à ask() ──
        $text       = $result['text'] ?? '';
        $tokens_in  = (int) ( $result['usage']['input_tokens'] ?? 0 );
        $tokens_out = (int) ( $result['usage']['output_tokens'] ?? 0 );
        $used_model = $result['model'] ?? $model;
        $prov       = $result['provider'] ?? $provider;

        // Sprint 5.4b: Debug empty responses
        if ( empty( $text ) && function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'Coach EMPTY response! intent=%s, model=%s, tokens_in=%d, tokens_out=%d, tools_used=%s',
                $intent, $used_model, $tokens_in, $tokens_out,
                implode( ',', $result['tools_used'] ?? array() )
            ), 'error', 'coach' );
        }

        // V2.7 fix: Track freemium usage in streaming path
        if ( $freemium ) {
            self::track_freemium_usage();
        } else {
            self::track_usage( $tokens_in, $tokens_out, $prov );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'Coach SEO [stream/%s] %s/%s : %d tokens in + %d tokens out (user #%d, session #%d, intent=%s)',
                $freemium ? 'free' : 'pro', $prov, $used_model, $tokens_in, $tokens_out, $user_id, $session_id, $intent
            ), 'info', 'coach' );
        }

        $chart = self::extract_chart( $text );
        $plan  = self::extract_plan( $text );
        $seo_plan = self::extract_seo_plan( $text ); // Sprint 5.4
        $report = self::extract_report( $text ); // S13-B: structured report

        // Sprint 5.3 fix: extract actions BEFORE save_history so they persist in actions_json
        $actions_raw  = self::extract_actions( $text );
        $actions         = array();
        $skipped_actions = array();
        if ( isset( $actions_raw['created'] ) ) {
            $actions         = $actions_raw['created'];
            $skipped_actions = $actions_raw['skipped'] ?? array();
        } else {
            $actions = $actions_raw;
        }

        // Sprint 5.4b: Auto-generate actions from GSC data when LLM produces too few
        // Haiku often outputs 0-1 generic "coach_suggestion" — PHP compensates
        if ( $intent === 'gsc_analysis' && count( $actions ) < 3 && ! empty( $context['pages_overview'] ) ) {
            $auto_actions = self::auto_generate_gsc_actions( $context );
            if ( ! empty( $auto_actions ) ) {
                $auto_result = self::extract_actions_from_array( $auto_actions );
                if ( isset( $auto_result['created'] ) ) {
                    $actions = array_merge( $actions, $auto_result['created'] );
                    $skipped_actions = array_merge( $skipped_actions, $auto_result['skipped'] ?? array() );
                }
            }
        }

        // S13-B: Fallback — if no report but we have chart or actions, build a minimal report
        if ( empty( $report ) && ( ! empty( $chart ) || ! empty( $actions ) ) ) {
            $report = self::build_fallback_report( $chart, $actions, $text );
        }

        self::save_history( $user_id, $question, $text, array(
            'intent'          => $intent,
            'model'           => $used_model,
            'provider'        => $prov,
            'tokens_in'       => $tokens_in,
            'tokens_out'      => $tokens_out,
            'chart'           => $chart,
            'plan'            => $plan,
            'seo_plan'        => $seo_plan,
            'report'          => $report,
            'actions'         => $actions,
            'skipped_actions' => $skipped_actions,
            'session_id'      => $session_id,
        ) );

        self::touch_session( $session_id, $intent );
        $memory_facts = self::extract_memory_tags( $text, $user_id, $session_id );
        self::increment_rate_limit( $user_id );

        if ( $plan && $session_id ) {
            self::save_plan_to_session( $session_id, $user_id, $plan );
        }

        // ── Sprint 4.8 : Analytics tracking ──
        $latency_ms = (int) ( ( microtime( true ) - $t_start ) * 1000 );
        // Detect tools used from the result (Sprint 4.5 tool loop sets this)
        $tools_str = ! empty( $result['tools_used'] ) ? implode( ',', (array) $result['tools_used'] ) : '';
        self::track_analytics( array(
            'user_id'          => $user_id,
            'session_id'       => $session_id,
            'intent'           => $intent,
            'model'            => $used_model,
            'provider'         => $prov,
            'tokens_in'        => $tokens_in,
            'tokens_out'       => $tokens_out,
            'latency_ms'       => $latency_ms,
            'tools_used'       => $tools_str,
            'has_chart'        => ! empty( $chart ),
            'has_actions'      => ! empty( $actions ),
            'has_plan'         => ! empty( $plan ),
            'question_preview' => $question,
        ) );

        return array(
            'text'             => $text,
            'tokens_in'        => $tokens_in,
            'tokens_out'       => $tokens_out,
            'actions'          => $actions,
            'skipped_actions'  => $skipped_actions,
            'plan'             => $plan,
            'seo_plan'         => $seo_plan,
            'mode'             => 'pro',
            'provider'         => $prov,
            'model'            => $used_model,
            'session_id'       => $session_id,
            'memory_facts'     => $memory_facts,
            'chart'            => $chart,
            'report'           => $report,
        );
    }

    /* ═══════════════════════════════════════════════
     *  RATE LIMIT
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifie si l'utilisateur n'a pas dépassé la limite horaire.
     */
    public static function check_rate_limit( $user_id ) {
        $key   = self::RATE_LIMIT_TRANSIENT . absint( $user_id );
        $count = (int) get_transient( $key );
        return $count < self::RATE_LIMIT_MAX;
    }

    /**
     * Incrémente le compteur de rate limit.
     */
    private static function increment_rate_limit( $user_id ) {
        $key   = self::RATE_LIMIT_TRANSIENT . absint( $user_id );
        $count = (int) get_transient( $key );
        set_transient( $key, $count + 1, self::RATE_LIMIT_WINDOW );
    }

    /* ═══════════════════════════════════════════════
     *  FREEMIUM — 5 questions/mois via SaaS (v2.1)
     * ═══════════════════════════════════════════════ */

    /**
     * Mode freemium = pas de clé API Anthropic configurée.
     * Le client utilise le proxy SaaS avec quota limité.
     *
     * @since 2.1.0
     * @return bool
     */
    public static function is_freemium_mode() {
        return empty( self::get_api_key() );
    }

    /**
     * Vérifie si le quota freemium n'est pas dépassé.
     *
     * @since 2.1.0
     * @return bool  true = quota OK, false = épuisé
     */
    public static function check_freemium_quota() {
        $usage = self::get_freemium_usage();
        return (int) $usage['used'] < self::FREEMIUM_LIMIT;
    }

    /**
     * Retourne l'usage freemium du mois en cours.
     *
     * @since 2.1.0
     * @return array { used: int, limit: int, month: string }
     */
    public static function get_freemium_usage() {
        $raw   = get_option( self::OPT_FREEMIUM_USAGE, array() );
        $month = wp_date( 'Y-m' );

        if ( ! is_array( $raw ) || ( $raw['month'] ?? '' ) !== $month ) {
            return array(
                'used'  => 0,
                'limit' => self::FREEMIUM_LIMIT,
                'month' => $month,
            );
        }

        return array(
            'used'  => (int) ( $raw['used'] ?? 0 ),
            'limit' => self::FREEMIUM_LIMIT,
            'month' => $month,
        );
    }

    /**
     * Incrémente le compteur freemium.
     *
     * @since 2.1.0
     */
    private static function track_freemium_usage() {
        $usage = self::get_freemium_usage();
        $month = wp_date( 'Y-m' );

        update_option( self::OPT_FREEMIUM_USAGE, array(
            'used'  => $usage['used'] + 1,
            'month' => $month,
        ), false );
    }

    /**
     * Appel Coach via le SaaS proxy (mode freemium).
     * Le SaaS gère l'appel IA côté serveur avec sa propre clé.
     * N'envoie JAMAIS la clé API Anthropic du client.
     *
     * @since 2.1.0
     * @param string $system    System prompt.
     * @param array  $messages  Messages conversationnels.
     * @param array  $context   Contexte site (pour le SaaS).
     * @return array|WP_Error   { text, usage }
     */
    private static function call_saas_proxy( $system, $messages, $context = array() ) {
        $api_key  = get_option( 'hts_api_key', '' );
        $base_url = rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' );
        $url      = $base_url . self::SAAS_COACH_ENDPOINT;

        $body = array(
            'system'   => $system,
            'messages' => $messages,
            'site_url' => site_url(),
        );

        $headers = array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        );

        // Authentification SaaS (si clé API HTS configurée)
        if ( ! empty( $api_key ) ) {
            $headers['X-API-KEY'] = $api_key;
        }

        $response = wp_remote_post( $url, array(
            'timeout' => self::TIMEOUT_SECONDS,
            'headers' => $headers,
            'body'    => wp_json_encode( $body ),
        ) );

        // ── Erreur réseau ──
        if ( is_wp_error( $response ) ) {
            return new \WP_Error(
                'saas_network',
                'Impossible de joindre le Coach SEO. Vérifiez votre connexion Internet.'
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        if ( ! is_array( $data ) ) {
            return new \WP_Error( 'saas_json', 'Réponse invalide du serveur. Réessayez.' );
        }

        // ── Quota épuisé côté SaaS ──
        if ( $code === 429 ) {
            return new \WP_Error(
                'freemium_exhausted',
                $data['message'] ?? 'Quota de questions gratuites atteint pour ce mois.'
            );
        }

        // ── Auth error ──
        if ( $code === 401 || $code === 403 ) {
            return new \WP_Error(
                'saas_auth',
                'Erreur d\'authentification avec le serveur. Vérifiez votre clé API dans les réglages.'
            );
        }

        // ── Erreur serveur ──
        if ( $code < 200 || $code >= 300 ) {
            $msg = $data['message'] ?? $data['error'] ?? 'Erreur serveur (HTTP ' . $code . ')';
            return new \WP_Error( 'saas_error', esc_html( $msg ) );
        }

        // ── Extraire la réponse ──
        $text = $data['text'] ?? $data['response'] ?? '';
        if ( empty( $text ) && isset( $data['content'] ) && is_array( $data['content'] ) ) {
            foreach ( $data['content'] as $block ) {
                if ( isset( $block['type'] ) && $block['type'] === 'text' ) {
                    $text .= $block['text'];
                }
            }
        }

        return array(
            'text'  => $text,
            'usage' => $data['usage'] ?? array( 'input_tokens' => 0, 'output_tokens' => 0 ),
        );
    }

    /**
     * Label du mois suivant en français (pour les messages d'erreur).
     *
     * @since 2.1.0
     * @return string
     */
    private static function next_month_label() {
        $months = array(
            1 => 'janvier', 2 => 'février', 3 => 'mars', 4 => 'avril',
            5 => 'mai', 6 => 'juin', 7 => 'juillet', 8 => 'août',
            9 => 'septembre', 10 => 'octobre', 11 => 'novembre', 12 => 'décembre',
        );
        $next = (int) wp_date( 'n' ) + 1;
        if ( $next > 12 ) $next = 1;
        return $months[ $next ];
    }

    /* ═══════════════════════════════════════════════
     *  BUDGET TRACKING
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifie que le budget mensuel n'est pas dépassé.
     */
    public static function check_budget_guard() {
        $usage  = self::get_usage();
        $budget = self::get_monthly_budget();

        $total = ( $usage['tokens_in'] ?? 0 ) + ( $usage['tokens_out'] ?? 0 );
        return $total < $budget;
    }

    /**
     * Budget mensuel configurable, avec hard limit.
     */
    public static function get_monthly_budget() {
        $budget = (int) get_option( self::OPT_BUDGET, self::DEFAULT_BUDGET );
        // Hard limit : jamais plus que HARD_LIMIT_TOKENS
        return min( max( $budget, 1000 ), self::HARD_LIMIT_TOKENS );
    }

    /**
     * Retourne l'usage du mois en cours.
     */
    public static function get_usage() {
        $usage = get_option( self::OPT_USAGE, array() );
        $month = wp_date( 'Y-m' );

        if ( ! is_array( $usage ) || ( $usage['month'] ?? '' ) !== $month ) {
            return array( 'month' => $month, 'tokens_in' => 0, 'tokens_out' => 0, 'requests' => 0 );
        }

        return $usage;
    }

    /**
     * Track tokens utilisés.
     */
    private static function track_usage( $tokens_in, $tokens_out, $provider = '' ) {
        $usage = self::get_usage();
        $month = wp_date( 'Y-m' );

        if ( ( $usage['month'] ?? '' ) !== $month ) {
            $usage = array( 'month' => $month, 'tokens_in' => 0, 'tokens_out' => 0, 'requests' => 0 );
        }

        $usage['tokens_in']  += $tokens_in;
        $usage['tokens_out'] += $tokens_out;
        $usage['requests']   += 1;

        update_option( self::OPT_USAGE, $usage, false );

        // ── Sprint 2 : Compteurs granulaires pour page de coûts ──
        $calls_key  = 'hts_coach_calls_' . $month;
        $tokens_key = 'hts_coach_tokens_' . $month;
        update_option( $calls_key, (int) get_option( $calls_key, 0 ) + 1, false );
        update_option( $tokens_key, (int) get_option( $tokens_key, 0 ) + $tokens_in + $tokens_out, false );

        // Ventilation par provider
        if ( $provider ) {
            $prov_key = 'hts_coach_tokens_' . $provider . '_' . $month;
            update_option( $prov_key, (int) get_option( $prov_key, 0 ) + $tokens_in + $tokens_out, false );
        }
    }

    /**
     * Sprint 4.8 : Enregistre une entrée analytics granulaire.
     *
     * @since 4.0.0 Sprint 4.8
     * @param array $data {
     *     @type int    $user_id
     *     @type int    $session_id
     *     @type string $intent
     *     @type string $model
     *     @type string $provider
     *     @type int    $tokens_in
     *     @type int    $tokens_out
     *     @type int    $latency_ms
     *     @type string $tools_used   Comma-separated tool names
     *     @type bool   $has_chart
     *     @type bool   $has_actions
     *     @type bool   $has_plan
     *     @type string $error_code   Null if success
     *     @type string $question_preview  First 200 chars of question
     * }
     * @return int|false  Insert ID or false
     */
    public static function track_analytics( $data ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ANALYTICS_TABLE;

        // Quick check : table exists? (cached)
        static $table_ok = null;
        if ( $table_ok === null ) {
            $table_ok = (bool) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        }
        if ( ! $table_ok ) return false;

        $wpdb->insert( $table, array(
            'user_id'          => absint( $data['user_id'] ?? 0 ),
            'session_id'       => absint( $data['session_id'] ?? 0 ),
            'intent'           => sanitize_key( $data['intent'] ?? 'global' ),
            'model'            => sanitize_text_field( $data['model'] ?? '' ),
            'provider'         => sanitize_text_field( $data['provider'] ?? '' ),
            'tokens_in'        => absint( $data['tokens_in'] ?? 0 ),
            'tokens_out'       => absint( $data['tokens_out'] ?? 0 ),
            'latency_ms'       => absint( $data['latency_ms'] ?? 0 ),
            'tools_used'       => sanitize_text_field( $data['tools_used'] ?? '' ),
            'has_chart'        => ! empty( $data['has_chart'] ) ? 1 : 0,
            'has_actions'      => ! empty( $data['has_actions'] ) ? 1 : 0,
            'has_plan'         => ! empty( $data['has_plan'] ) ? 1 : 0,
            'error_code'       => ! empty( $data['error_code'] ) ? sanitize_text_field( $data['error_code'] ) : null,
            'question_preview' => mb_substr( sanitize_text_field( $data['question_preview'] ?? '' ), 0, 200 ),
            'created_at'       => current_time( 'mysql' ),
        ), array( '%d', '%d', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%d', '%d', '%d', '%s', '%s', '%s' ) );

        return $wpdb->insert_id;
    }

    /**
     * Reset mensuel (cron).
     */
    public function monthly_reset_usage() {
        update_option( self::OPT_USAGE, array(
            'month'      => wp_date( 'Y-m' ),
            'tokens_in'  => 0,
            'tokens_out' => 0,
            'requests'   => 0,
        ), false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Coach SEO : reset mensuel du compteur de tokens', 'info', 'coach' );
        }
    }

    /**
     * v4.0 : Purge les messages de plus de 6 mois.
     * Les résumés de sessions sont préservés (dans hts_coach_sessions.summary_text).
     * Les artifacts sont gardés 1 an.
     */
    public function purge_old_messages() {
        if ( ! self::messages_table_exists() ) return;

        global $wpdb;

        // Purger les messages > 6 mois dont la session a un résumé
        $msg_table = $wpdb->prefix . self::MESSAGES_TABLE;
        $ses_table = $wpdb->prefix . self::SESSIONS_TABLE;

        $deleted = $wpdb->query(
            "DELETE m FROM {$msg_table} m
             INNER JOIN {$ses_table} s ON m.session_id = s.id
             WHERE m.created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH)
             AND s.summary_status = 'done'"
        );

        // Purger les artifacts > 1 an
        $art_table = $wpdb->prefix . self::ARTIFACTS_TABLE;
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $art_table ) ) ) {
            $wpdb->query(
                "DELETE FROM {$art_table} WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR)"
            );
        }

        if ( function_exists( 'hts_add_log' ) && $deleted > 0 ) {
            hts_add_log( sprintf( 'Coach SEO : purge hebdo — %d messages supprimés (>6 mois)', $deleted ), 'info', 'coach' );
        }
    }

    /* ═══════════════════════════════════════════════
     *  HISTORIQUE CONVERSATIONS
     * ═══════════════════════════════════════════════ */

    /**
     * Construit les messages pour l'API (avec historique multi-tour).
     */
    private static function build_messages( $question, $user_id, $session_id = 0 ) {
        $history  = self::get_history( $user_id, $session_id );
        $messages = array();

        // Ajouter les N derniers échanges comme contexte
        foreach ( $history as $turn ) {
            $messages[] = array( 'role' => 'user',      'content' => $turn['q'] );
            $messages[] = array( 'role' => 'assistant',  'content' => $turn['a'] );
        }

        // Ajouter la question actuelle
        $messages[] = array( 'role' => 'user', 'content' => $question );

        return $messages;
    }

    /**
     * Récupère l'historique des conversations d'un user.
     */
    public static function get_history( $user_id = 0, $session_id = 0 ) {
        // ── v4.0 : Lire depuis la table messages si elle existe ──
        if ( self::messages_table_exists() ) {
            return self::get_history_from_db( $user_id, $session_id );
        }

        // ── Fallback wp_options (ancien système) ──
        $all = get_option( self::OPT_HISTORY, array() );
        if ( ! is_array( $all ) ) return array();

        $key = 'user_' . absint( $user_id );
        $user_history = $all[ $key ] ?? array();

        if ( ! is_array( $user_history ) ) return array();

        // Garder seulement les N derniers tours
        return array_slice( $user_history, -self::MAX_HISTORY_TURNS );
    }

    /**
     * v4.0 : Récupère l'historique depuis hts_coach_messages.
     * Charge les messages de la session active + résumés des sessions précédentes.
     */
    private static function get_history_from_db( $user_id, $session_id = 0 ) {
        global $wpdb;
        $table   = $wpdb->prefix . self::MESSAGES_TABLE;

        // Utiliser le session_id fourni, sinon fallback sur get_or_create_session
        if ( $session_id <= 0 ) {
            $session = self::get_or_create_session( $user_id );
            $session_id = $session['id'] ?? 0;
        }

        if ( ! $session_id ) return array();

        // Charger les N derniers échanges de la session active (paires Q/R)
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT role, content FROM {$table}
             WHERE session_id = %d AND user_id = %d
             ORDER BY created_at ASC
             LIMIT %d",
            $session_id, absint( $user_id ), self::MAX_HISTORY_TURNS * 2
        ), ARRAY_A );

        if ( empty( $rows ) ) return array();

        // Reconstruire en paires q/a pour compatibilité build_messages()
        $history = array();
        $current = array();
        foreach ( $rows as $row ) {
            if ( $row['role'] === 'user' ) {
                $current = array( 'q' => $row['content'] );
            } elseif ( $row['role'] === 'assistant' && ! empty( $current ) ) {
                $current['a']  = $row['content'];
                $current['ts'] = 0; // pas critique ici
                $history[]     = $current;
                $current       = array();
            }
        }

        return array_slice( $history, -self::MAX_HISTORY_TURNS );
    }

    /**
     * v4.0 : Vérifie rapidement si la table messages existe (avec cache statique).
     */
    private static function messages_table_exists() {
        static $exists = null;
        if ( $exists !== null ) return $exists;

        global $wpdb;
        $table = $wpdb->prefix . self::MESSAGES_TABLE;
        $exists = (bool) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        return $exists;
    }

    /**
     * Sauvegarde un échange dans l'historique.
     */
    private static function save_history( $user_id, $question, $answer, $meta = array() ) {
        // ── v4.0 : Sauvegarder dans la table messages ──
        if ( self::messages_table_exists() ) {
            self::save_message_to_db( $user_id, $question, $answer, $meta );
            return;
        }

        // ── Fallback wp_options ──
        $all = get_option( self::OPT_HISTORY, array() );
        if ( ! is_array( $all ) ) $all = array();

        $key = 'user_' . absint( $user_id );
        if ( ! isset( $all[ $key ] ) || ! is_array( $all[ $key ] ) ) {
            $all[ $key ] = array();
        }

        $all[ $key ][] = array(
            'q'  => mb_substr( $question, 0, 1000 ),
            'a'  => mb_substr( $answer, 0, 5000 ),
            'ts' => time(),
        );

        // Garder max turns
        if ( count( $all[ $key ] ) > self::MAX_HISTORY_TURNS ) {
            $all[ $key ] = array_slice( $all[ $key ], -self::MAX_HISTORY_TURNS );
        }

        update_option( self::OPT_HISTORY, $all, false );
    }

    /**
     * v4.0 : Insère un échange (question + réponse) dans hts_coach_messages.
     * Sauvegarde aussi le chart en JSON si présent.
     */
    private static function save_message_to_db( $user_id, $question, $answer, $meta = array() ) {
        global $wpdb;
        $table      = $wpdb->prefix . self::MESSAGES_TABLE;

        // Utiliser le session_id passé en meta (déjà résolu par ask_stream/ask)
        // Évite d'appeler get_or_create_session() une 2e fois (risque de session différente)
        $session_id = absint( $meta['session_id'] ?? 0 );
        if ( ! $session_id ) {
            $session    = self::get_or_create_session( $user_id );
            $session_id = $session['id'] ?? 0;
        }

        if ( ! $session_id ) return;

        $user_id = absint( $user_id );

        // ── Anti-doublon : vérifier si ce message n'a pas déjà été sauvé dans les 10 dernières secondes ──
        $recent_dup = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE session_id = %d AND user_id = %d AND role = 'user'
               AND content = %s AND created_at > DATE_SUB(NOW(), INTERVAL 10 SECOND)",
            $session_id, $user_id, mb_substr( $question, 0, 10000 )
        ) );
        if ( (int) $recent_dup > 0 ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Coach SEO : doublon détecté, message ignoré (session #' . $session_id . ')', 'debug', 'coach' );
            }
            return;
        }

        // ── Message utilisateur ──
        $wpdb->insert( $table, array(
            'session_id' => $session_id,
            'user_id'    => $user_id,
            'role'       => 'user',
            'content'    => mb_substr( $question, 0, 10000 ),
            'intent'     => sanitize_key( $meta['intent'] ?? '' ),
            'created_at' => current_time( 'mysql' ),
        ), array( '%d', '%d', '%s', '%s', '%s', '%s' ) );

        // ── Message assistant ──
        $chart_json = null;
        if ( ! empty( $meta['chart'] ) ) {
            $chart_json = wp_json_encode( $meta['chart'] );
        }

        // Sprint 4.2 : sauver le plan dans actions_json du message assistant (pour SSR au F5)
        // Sprint 5.3 : sauver aussi les action cards (AMÉL-2)
        // Sprint 5.4 : sauver aussi les seo_plan structurés
        $actions_json = null;
        $actions_data = array();
        if ( ! empty( $meta['plan'] ) && is_array( $meta['plan'] ) && ! empty( $meta['plan']['steps'] ) ) {
            $actions_data['plan'] = $meta['plan'];
        }
        if ( ! empty( $meta['seo_plan'] ) && is_array( $meta['seo_plan'] ) && ! empty( $meta['seo_plan']['phases'] ) ) {
            $actions_data['seo_plan'] = $meta['seo_plan'];
        }
        if ( ! empty( $meta['actions'] ) && is_array( $meta['actions'] ) ) {
            $actions_data['actions'] = $meta['actions'];
        }
        if ( ! empty( $meta['skipped_actions'] ) && is_array( $meta['skipped_actions'] ) ) {
            $actions_data['skipped'] = $meta['skipped_actions'];
        }
        if ( ! empty( $actions_data ) ) {
            $actions_json = wp_json_encode( $actions_data, JSON_UNESCAPED_UNICODE );
        }

        // Vérifier si la colonne actions_json existe (ajoutée en Sprint 4.1)
        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );
        $has_actions_col = in_array( 'actions_json', $columns, true );

        $insert_data = array(
            'session_id'   => $session_id,
            'user_id'      => $user_id,
            'role'         => 'assistant',
            'content'      => $answer,
            'intent'       => sanitize_key( $meta['intent'] ?? '' ),
            'model'        => sanitize_text_field( $meta['model'] ?? '' ),
            'provider'     => sanitize_text_field( $meta['provider'] ?? '' ),
            'tokens_in'    => absint( $meta['tokens_in'] ?? 0 ),
            'tokens_out'   => absint( $meta['tokens_out'] ?? 0 ),
            'chart_json'   => $chart_json,
            'created_at'   => current_time( 'mysql' ),
        );
        $insert_fmt = array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s' );

        if ( $has_actions_col ) {
            $insert_data['actions_json'] = $actions_json;
            $insert_fmt[] = '%s';
        }

        $wpdb->insert( $table, $insert_data, $insert_fmt );

        // ── v4.0 : Sauvegarder l'artifact chart si présent ──
        if ( ! empty( $meta['chart'] ) ) {
            self::save_artifact( $session_id, $wpdb->insert_id, $user_id, $meta['chart'] );
        }
    }

    /**
     * v4.0 : Sauvegarde un artifact (chart) en DB.
     */
    private static function save_artifact( $session_id, $message_id, $user_id, $chart_data ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ARTIFACTS_TABLE;

        // Vérifier que la table existe
        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            return;
        }

        $wpdb->insert( $table, array(
            'session_id' => absint( $session_id ),
            'message_id' => absint( $message_id ),
            'user_id'    => absint( $user_id ),
            'type'       => 'chart',
            'title'      => sanitize_text_field( $chart_data['title'] ?? 'Chart' ),
            'data_json'  => wp_json_encode( $chart_data ),
            'created_at' => current_time( 'mysql' ),
        ), array( '%d', '%d', '%d', '%s', '%s', '%s', '%s' ) );
    }

    /**
     * v4.0 Sprint 1.3 : Charge les N derniers artifacts pour enrichir le prompt.
     *
     * @param int $user_id
     * @param int $limit
     * @return array
     */
    public static function get_recent_artifacts_for_prompt( $user_id, $limit = 5 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ARTIFACTS_TABLE;

        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            return array();
        }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, type, title, created_at
             FROM {$table}
             WHERE user_id = %d
             ORDER BY created_at DESC
             LIMIT %d",
            absint( $user_id ), absint( $limit )
        ), ARRAY_A );

        return is_array( $rows ) ? $rows : array();
    }

    /**
     * v4.0 Sprint 1.3 AJAX : Endpoint galerie des artifacts.
     * Retourne la liste des artifacts avec les topics de session associés.
     */
    public function ajax_artifacts() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        global $wpdb;
        $user_id = get_current_user_id();
        $art_table = $wpdb->prefix . self::ARTIFACTS_TABLE;
        $ses_table = $wpdb->prefix . self::SESSIONS_TABLE;

        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $art_table ) ) ) {
            wp_send_json_success( array( 'artifacts' => array() ) );
            return;
        }

        $limit = absint( $_POST['limit'] ?? 20 );
        if ( $limit < 1 || $limit > 50 ) $limit = 20;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT a.id, a.type, a.title, a.data_json, a.session_id, a.created_at,
                    s.topics AS session_topics
             FROM {$art_table} a
             LEFT JOIN {$ses_table} s ON a.session_id = s.id
             WHERE a.user_id = %d
             ORDER BY a.created_at DESC
             LIMIT %d",
            $user_id, $limit
        ), ARRAY_A );

        $artifacts = array();
        foreach ( ( $rows ?: array() ) as $row ) {
            $chart_data = json_decode( $row['data_json'] ?? '{}', true );
            $topics = json_decode( $row['session_topics'] ?? '[]', true );
            $artifacts[] = array(
                'id'         => (int) $row['id'],
                'type'       => $row['type'],
                'title'      => $row['title'],
                'chart'      => is_array( $chart_data ) ? $chart_data : null,
                'topics'     => is_array( $topics ) ? $topics : array(),
                'session_id' => (int) $row['session_id'],
                'created_at' => $row['created_at'],
            );
        }

        wp_send_json_success( array( 'artifacts' => $artifacts ) );
    }

    /**
     * Efface l'historique d'un user.
     */
    public static function clear_history( $user_id ) {
        // ── v4.0 : Nettoyer la table messages ──
        if ( self::messages_table_exists() ) {
            global $wpdb;
            $table = $wpdb->prefix . self::MESSAGES_TABLE;
            $wpdb->delete( $table, array( 'user_id' => absint( $user_id ) ), array( '%d' ) );
        }

        // ── Nettoyer aussi wp_options (compat) ──
        $all = get_option( self::OPT_HISTORY, array() );
        if ( ! is_array( $all ) ) return;

        $key = 'user_' . absint( $user_id );
        unset( $all[ $key ] );

        update_option( self::OPT_HISTORY, $all, false );
    }

    /* ═══════════════════════════════════════════════
     *  EXTRACT ACTIONS — Suggestions Inbox
     * ═══════════════════════════════════════════════ */

    /**
     * Extrait le bloc JSON d'actions de la réponse IA.
     * Crée les propositions dans l'Inbox si trouvées.
     */
    public static function extract_actions( $text ) {
        // Chercher un bloc ```actions ... ``` ou inline {"actions":[...]}
        $json_str = '';
        if ( preg_match( '/```actions\s*\n(.*?)```/s', $text, $m ) ) {
            $json_str = trim( $m[1] );
        } elseif ( preg_match( '/\{"actions"\s*:\s*\[(?:[^\[\]]*|\[(?:[^\[\]]*|\[[^\[\]]*\])*\])*\]\s*\}/s', $text, $m ) ) {
            $json_str = $m[0];
        }

        // Sprint 4.9 bugfix (Fix 3): fallback — chercher dans un bloc ```json contenant "actions"
        if ( empty( $json_str ) && preg_match( '/```json\s*\n(.*?)```/s', $text, $m ) ) {
            $maybe = trim( $m[1] );
            if ( strpos( $maybe, '"actions"' ) !== false ) {
                $json_str = $maybe;
            }
        }

        if ( empty( $json_str ) ) return array();

        $json = json_decode( $json_str, true );
        if ( ! is_array( $json ) || empty( $json['actions'] ) ) {
            return array();
        }

        $created = array();
        $skipped = array();

        foreach ( $json['actions'] as $action ) {
            if ( ! is_array( $action ) ) continue;

            $post_id  = absint( $action['post_id'] ?? 0 );
            $type     = sanitize_key( $action['action'] ?? 'coach_suggestion' );
            $reason   = sanitize_text_field( $action['reason'] ?? '' );
            $priority = sanitize_key( $action['priority'] ?? 'medium' );

            // Sprint 4.9 bugfix (Fix 4): fallback reason from alternative fields
            if ( empty( $reason ) ) {
                $reason = sanitize_text_field(
                    $action['description'] ?? $action['label'] ?? $action['details'] ?? $action['ancre'] ?? ''
                );
            }
            if ( empty( $reason ) && ! empty( $type ) ) {
                $reason_map = array(
                    'add_internal_links'   => 'Ajouter des liens internes pour améliorer le maillage',
                    'add_faq'              => 'Ajouter une FAQ pour améliorer la visibilité IA',
                    'add_meta_title'       => 'Optimiser le title pour améliorer le CTR',
                    'add_meta_desc'        => 'Ajouter une meta description optimisée',
                    'content_refresh'      => 'Rafraîchir le contenu pour maintenir les positions',
                    'geo_optimize'         => 'Optimiser pour les moteurs IA (GEO)',
                    'delete_page'          => 'Supprimer cette page zombie (thin content)',
                    'schedule_publication' => 'Programmer la publication de ce brouillon',
                    'generate_article'     => 'Générer un nouvel article SEO optimisé',
                    'optimize_meta_both'   => 'Optimiser le meta title et la meta description',
                    'optimize_meta_title'  => 'Optimiser le meta title pour le CTR',
                    'optimize_meta_desc'   => 'Optimiser la meta description',
                    'create_cocon_articles'=> 'Créer les articles satellites du cocon',
                    'fix_orphan_links'     => 'Corriger les pages orphelines avec des liens internes',
                    'bulk_optimize_metas'  => 'Optimiser les metas en masse',
                );
                $reason = $reason_map[ $type ] ?? 'Suggestion du Coach SEO';
            }

            // Valider la priorité
            if ( ! in_array( $priority, array( 'low', 'medium', 'high', 'critical' ), true ) ) {
                $priority = 'medium';
            }

            // Valider le type d'action
            if ( ! in_array( $type, self::COACH_ACTION_TYPES, true ) ) {
                $type = 'coach_suggestion';
            }

            // Dédoublonnage : ne pas recréer si une action pending existe déjà
            if ( $post_id > 0 && self::has_pending_action( $type, $post_id ) ) {
                // Sprint 5.2: Log + track skipped actions for UI feedback
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Coach: action {$type} pour post #{$post_id} ignorée (déjà pending)", 'info', 'coach' );
                }
                $skipped[] = array(
                    'type'        => $type,
                    'post_id'     => $post_id,
                    'post_title'  => $post_id > 0 ? get_the_title( $post_id ) : '',
                    'reason'      => $reason,
                    'skip_reason' => 'Déjà en attente dans l\'Inbox',
                );
                continue;
            }

            // Proposer dans l'Inbox via le Workflow Engine
            if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                $id = HTS_Workflow_Engine::propose(
                    'coach',
                    $type,
                    $post_id,
                    array( 'reason' => $reason, 'source' => 'coach_ai' ),
                    $priority
                );

                if ( $id ) {
                    $created[] = array(
                        'action_id'  => $id,
                        'type'       => $type,
                        'post_id'    => $post_id,
                        'post_title' => $post_id > 0 ? get_the_title( $post_id ) : '',
                        'action'     => $type,
                        'reason'     => $reason,
                    );
                } else {
                    // Sprint 5.2: Log quand propose() refuse (garde-fou, blacklist, cooldown)
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( "Coach: propose() a refusé {$type} pour post #{$post_id} (garde-fou)", 'warn', 'coach' );
                    }
                    $skipped[] = array(
                        'type'        => $type,
                        'post_id'     => $post_id,
                        'post_title'  => $post_id > 0 ? get_the_title( $post_id ) : '',
                        'reason'      => $reason,
                        'skip_reason' => 'Bloqué par les garde-fous',
                    );
                }
            }
        }

        // Sprint 5.2: Retourner aussi les actions sautées pour feedback UI
        if ( ! empty( $skipped ) ) {
            return array( 'created' => $created, 'skipped' => $skipped );
        }
        return $created;
    }

    /**
     * Extrait un bloc chart JSON de la réponse IA.
     *
     * @param  string $text  Réponse IA brute.
     * @return array|null    { type, title, labels, data } ou null.
     */
    public static function extract_chart( $text ) {
        if ( ! preg_match( '/```chart\s*\n(.*?)```/s', $text, $m ) ) {
            return null;
        }

        $json = json_decode( trim( $m[1] ), true );
        if ( ! is_array( $json ) || empty( $json['type'] ) ) {
            return null;
        }

        $allowed_types = array( 'radar', 'bar', 'doughnut', 'horizontalBar', 'line' );
        if ( ! in_array( $json['type'], $allowed_types, true ) ) {
            return null;
        }

        return array(
            'type'   => $json['type'],
            'title'  => sanitize_text_field( $json['title'] ?? '' ),
            'labels' => array_map( 'sanitize_text_field', (array) ( $json['labels'] ?? array() ) ),
            'data'   => array_map( 'floatval', (array) ( $json['data'] ?? array() ) ),
            'data2'  => isset( $json['data2'] ) ? array_map( 'floatval', (array) $json['data2'] ) : null,
        );
    }

    /**
     * Nettoie la réponse IA des blocs JSON techniques pour l'affichage.
     */
    public static function clean_response( $text ) {
        // Retirer les blocs ```chart ... ```
        $text = preg_replace( '/```chart\s*\n.*?```/s', '', $text );
        // Retirer les blocs ```actions ... ```
        $text = preg_replace( '/```actions\s*\n.*?```/s', '', $text );
        // v4.0 Sprint 4.1 : Retirer les blocs ```plan ... ```
        $text = preg_replace( '/```plan\s*\n.*?```/s', '', $text );
        // Sprint 5.4 : Retirer les blocs ```seo_plan ... ```
        $text = preg_replace( '/```seo_plan\s*\n.*?```/s', '', $text );
        // S13-B : Retirer les blocs ```report ... ```
        $text = preg_replace( '/```report\s*\n.*?```/s', '', $text );
        // Retirer inline {"actions":[...]} (multi-ligne, imbriqué)
        $text = preg_replace( '/\{"actions"\s*:\s*\[(?:[^\[\]]*|\[(?:[^\[\]]*|\[[^\[\]]*\])*\])*\]\s*\}/s', '', $text );
        // S14 : Retirer inline {"goal":..., "steps":[...]} et variantes JSON structurés
        $text = preg_replace( '/```(?:json)?\s*\n\s*\{[\s]*"(?:goal|steps|params|estimate|strategy)"[\s]*:.*?```/s', '', $text );
        $text = preg_replace( '/\{[\s]*"goal"[\s]*:[\s]*"[^"]*"[\s]*,[\s]*"steps"[\s]*:[\s]*\[(?:[^\[\]]*|\[(?:[^\[\]]*|\[[^\[\]]*\])*\])*\](?:[\s]*,[\s]*"[^"]*"[\s]*:[\s]*"[^"]*")*[\s]*\}/s', '', $text );
        // v3.2 : Retirer les tags [MEMORY:...] (invisibles pour le client)
        $text = preg_replace( '/\[MEMORY:[a-z_]+:[a-z_]+\]\s*[^\n]*/i', '', $text );
        // Nettoyer les lignes vides multiples résultantes
        $text = preg_replace( '/\n{3,}/', "\n\n", $text );
        return trim( $text );
    }

    /**
     * S13-B : Extrait un bloc report JSON de la réponse IA.
     * Robuste : répare les JSON tronqués/malformés de gpt-4.1-mini.
     *
     * @param  string $text  Réponse IA brute.
     * @return array|null    Rapport structuré ou null.
     */
    public static function extract_report( $text ) {
        // 1. Try standard extraction
        $json_str = null;
        if ( preg_match( '/```report\s*\n(.*?)```/s', $text, $m ) ) {
            $json_str = trim( $m[1] );
        } elseif ( preg_match( '/```report\s*\n(.*)/s', $text, $m ) ) {
            // Truncated: no closing ```, take everything after ```report
            $json_str = trim( $m[1] );
        }

        if ( empty( $json_str ) ) {
            return null;
        }

        // 2. Repair common JSON issues from LLMs
        // Remove trailing commas before } or ]
        $json_str = preg_replace( '/,\s*([}\]])/', '$1', $json_str );
        // Remove any text after the last }
        if ( preg_match( '/^(\{.*\})/s', $json_str, $brace_m ) ) {
            $json_str = $brace_m[1];
        } else {
            // Try to close truncated JSON — count open brackets
            $opens = substr_count( $json_str, '{' ) + substr_count( $json_str, '[' );
            $closes = substr_count( $json_str, '}' ) + substr_count( $json_str, ']' );
            $diff = $opens - $closes;
            // Try to close with the right brackets (heuristic)
            for ( $i = 0; $i < $diff && $i < 10; $i++ ) {
                // Find the last unclosed bracket type
                $last_open = max( (int) strrpos( $json_str, '{' ), (int) strrpos( $json_str, '[' ) );
                $last_close = max( (int) strrpos( $json_str, '}' ), (int) strrpos( $json_str, ']' ) );
                if ( $last_open > $last_close ) {
                    $char = $json_str[ $last_open ] === '{' ? '}' : ']';
                } else {
                    $char = '}';
                }
                // Remove any trailing incomplete value
                $json_str = preg_replace( '/,?\s*"[^"]*"\s*:\s*"?[^"}\]]*$/', '', $json_str );
                $json_str .= $char;
            }
        }

        // 3. Parse
        $json = json_decode( $json_str, true );
        if ( ! is_array( $json ) || empty( $json['title'] ) ) {
            // Last resort: try to find ANY valid JSON object with "title"
            if ( preg_match( '/\{[^{}]*"title"\s*:\s*"[^"]+"/s', $json_str ) ) {
                // Trim to first valid-looking object
                $json = json_decode( preg_replace( '/[^\x20-\x7E\xC0-\xFF]/', '', $json_str ), true );
            }
            if ( ! is_array( $json ) || empty( $json['title'] ) ) {
                return null;
            }
        }

        // 4. Build sanitized report
        $report = array(
            'title' => sanitize_text_field( $json['title'] ),
        );

        // KPIs
        if ( ! empty( $json['kpis'] ) && is_array( $json['kpis'] ) ) {
            $report['kpis'] = array();
            foreach ( array_slice( $json['kpis'], 0, 6 ) as $kpi ) {
                if ( ! is_array( $kpi ) || empty( $kpi['label'] ) ) continue;
                $report['kpis'][] = array(
                    'label' => sanitize_text_field( $kpi['label'] ),
                    'value' => sanitize_text_field( (string) ( $kpi['value'] ?? '—' ) ),
                    'unit'  => sanitize_text_field( $kpi['unit'] ?? '' ),
                    'trend' => in_array( $kpi['trend'] ?? '', array( 'up', 'down', 'neutral' ), true ) ? $kpi['trend'] : 'neutral',
                    'delta' => sanitize_text_field( $kpi['delta'] ?? '' ),
                );
            }
        }

        // Charts (max 2)
        if ( ! empty( $json['charts'] ) && is_array( $json['charts'] ) ) {
            $report['charts'] = array();
            $allowed_types = array( 'radar', 'bar', 'doughnut', 'horizontalBar', 'line' );
            foreach ( array_slice( $json['charts'], 0, 2 ) as $ch ) {
                if ( ! is_array( $ch ) || ! in_array( $ch['type'] ?? '', $allowed_types, true ) ) continue;
                if ( empty( $ch['labels'] ) || empty( $ch['data'] ) ) continue;
                $report['charts'][] = array(
                    'type'   => $ch['type'],
                    'title'  => sanitize_text_field( $ch['title'] ?? '' ),
                    'labels' => array_map( 'sanitize_text_field', (array) $ch['labels'] ),
                    'data'   => array_map( 'floatval', (array) $ch['data'] ),
                );
            }
        }

        // Tables (max 3)
        if ( ! empty( $json['tables'] ) && is_array( $json['tables'] ) ) {
            $report['tables'] = array();
            foreach ( array_slice( $json['tables'], 0, 3 ) as $tbl ) {
                if ( ! is_array( $tbl ) || empty( $tbl['headers'] ) || empty( $tbl['rows'] ) ) continue;
                $t = array(
                    'title'   => sanitize_text_field( $tbl['title'] ?? '' ),
                    'headers' => array_map( 'sanitize_text_field', (array) $tbl['headers'] ),
                    'rows'    => array(),
                );
                foreach ( array_slice( (array) $tbl['rows'], 0, 15 ) as $row ) {
                    if ( ! is_array( $row ) ) continue;
                    $t['rows'][] = array_map( function( $v ) { return sanitize_text_field( (string) $v ); }, $row );
                }
                if ( ! empty( $t['rows'] ) ) {
                    $report['tables'][] = $t;
                }
            }
        }

        // Insights
        if ( ! empty( $json['insights'] ) && is_array( $json['insights'] ) ) {
            $report['insights'] = array();
            $levels = array( 'critical', 'high', 'medium', 'low', 'positive' );
            foreach ( array_slice( $json['insights'], 0, 6 ) as $ins ) {
                if ( ! is_array( $ins ) || empty( $ins['text'] ) ) continue;
                $report['insights'][] = array(
                    'level' => in_array( $ins['level'] ?? '', $levels, true ) ? $ins['level'] : 'medium',
                    'text'  => sanitize_text_field( $ins['text'] ),
                );
            }
        }

        return $report;
    }

    /**
     * S13-B : Fallback — construit un rapport minimal à partir des données existantes
     * quand le LLM ne génère pas de bloc ```report``` mais a produit un chart ou des actions.
     */
    public static function build_fallback_report( $chart, $actions, $text ) {
        // Need at least a chart or meaningful actions
        if ( empty( $chart ) && empty( $actions ) ) {
            return null;
        }

        $report = array( 'title' => 'Diagnostic SEO' );

        // Build chart section from extracted chart
        if ( ! empty( $chart ) && ! empty( $chart['labels'] ) && ! empty( $chart['data'] ) ) {
            $report['charts'] = array( array(
                'type'   => $chart['type'],
                'title'  => $chart['title'] ?: 'Analyse',
                'labels' => $chart['labels'],
                'data'   => $chart['data'],
            ) );

            // Auto-generate KPIs from chart data
            $data = $chart['data'];
            $labels = $chart['labels'];
            if ( count( $data ) >= 3 ) {
                $avg = round( array_sum( $data ) / count( $data ) );
                $max_i = array_search( max( $data ), $data );
                $min_i = array_search( min( $data ), $data );
                $report['kpis'] = array(
                    array( 'label' => 'Score moyen', 'value' => (string) $avg, 'unit' => '/100', 'trend' => $avg > 50 ? 'up' : 'down', 'delta' => '' ),
                    array( 'label' => 'Meilleur', 'value' => $labels[ $max_i ] ?? '', 'unit' => (string) round( $data[ $max_i ] ), 'trend' => 'positive', 'delta' => '' ),
                    array( 'label' => 'Plus faible', 'value' => $labels[ $min_i ] ?? '', 'unit' => (string) round( $data[ $min_i ] ), 'trend' => 'down', 'delta' => '' ),
                );
            }
        }

        // Build insights from actions
        if ( ! empty( $actions ) ) {
            $report['insights'] = array();
            foreach ( array_slice( $actions, 0, 5 ) as $a ) {
                $level = 'medium';
                if ( ( $a['priority'] ?? '' ) === 'critical' ) $level = 'critical';
                elseif ( ( $a['priority'] ?? '' ) === 'high' ) $level = 'high';
                elseif ( ( $a['priority'] ?? '' ) === 'low' ) $level = 'low';
                $report['insights'][] = array(
                    'level' => $level,
                    'text'  => sanitize_text_field( $a['reason'] ?? ( $a['action'] ?? 'Action recommandée' ) ),
                );
            }
        }

        return $report;
    }

    /**
     * Sprint 5.4 : Extrait un bloc ```seo_plan JSON de la réponse IA.
     *
     * @param  string $text  Réponse IA brute.
     * @return array|null    Plan SEO structuré ou null.
     */
    /**
     * Sprint 5.4b: Auto-generate typed actions from GSC context data.
     * Compensates when Haiku/small models produce 0-1 generic actions.
     *
     * @param array $context Build context with pages_overview.
     * @return array Actions array in the same format as LLM ```actions``` block.
     */
    private static function auto_generate_gsc_actions( $context ) {
        $pages = $context['pages_overview'] ?? array();
        if ( empty( $pages ) ) return array();

        // Sort by impressions desc to prioritize high-visibility pages
        usort( $pages, function( $a, $b ) {
            return ( $b['gsc_impressions'] ?? 0 ) - ( $a['gsc_impressions'] ?? 0 );
        });

        $actions = array();
        $max_actions = 4;

        foreach ( $pages as $page ) {
            if ( count( $actions ) >= $max_actions ) break;

            $pid   = (int) ( $page['id'] ?? 0 );
            $title = $page['title'] ?? '';
            $impr  = (int) ( $page['gsc_impressions'] ?? 0 );
            $ctr   = (float) ( $page['gsc_ctr'] ?? 0 );
            $pos   = (float) ( $page['gsc_position'] ?? 0 );
            $clicks = (int) ( $page['gsc_clicks'] ?? 0 );
            $links_in = (int) ( $page['links_in'] ?? 0 );
            $geo   = (float) ( $page['geo_score'] ?? 0 );

            if ( $pid === 0 || $impr < 500 ) continue;

            // Rule 1: High impressions + low CTR → optimize metas
            if ( $impr > 2000 && $ctr < 1.5 && count( $actions ) < $max_actions ) {
                $top_kw = '';
                if ( ! empty( $page['top_queries'][0]['q'] ) ) {
                    $top_kw = ' (requête: "' . $page['top_queries'][0]['q'] . '")';
                }
                $actions[] = array(
                    'post_id'  => $pid,
                    'action'   => 'optimize_meta_both',
                    'reason'   => sprintf(
                        'CTR %.2f%% sur %s impressions%s — title/desc à optimiser pour augmenter les clics',
                        $ctr, number_format( $impr, 0, ',', '.' ), $top_kw
                    ),
                    'priority' => $ctr < 0.5 ? 'critical' : 'high',
                );
            }

            // Rule 2: Few internal links → add internal links
            if ( $links_in < 3 && $impr > 1000 && count( $actions ) < $max_actions ) {
                $actions[] = array(
                    'post_id'  => $pid,
                    'action'   => 'add_internal_links',
                    'reason'   => sprintf(
                        '%d lien(s) entrant(s) seulement — maillage massif pour renforcer pos. %.1f',
                        $links_in, $pos
                    ),
                    'priority' => $links_in === 0 ? 'critical' : 'high',
                );
            }

            // Rule 3: Low GEO score → add FAQ
            if ( $geo < 40 && $impr > 1000 && count( $actions ) < $max_actions ) {
                $actions[] = array(
                    'post_id'  => $pid,
                    'action'   => 'add_faq',
                    'reason'   => sprintf(
                        'Score GEO %d/100 — FAQ structurée pour visibilité IA (ChatGPT/Perplexity)',
                        (int) $geo
                    ),
                    'priority' => 'high',
                );
            }
        }

        return $actions;
    }

    /**
     * Sprint 5.4b: Create Inbox actions from a PHP-generated array.
     * Same dedup/propose logic as extract_actions() but without JSON parsing.
     *
     * @param array $actions_array Array of action arrays with post_id, action, reason, priority.
     * @return array { created: [...], skipped: [...] }
     */
    private static function extract_actions_from_array( $actions_array ) {
        $created = array();
        $skipped = array();

        foreach ( $actions_array as $action ) {
            $post_id  = absint( $action['post_id'] ?? 0 );
            $type     = sanitize_key( $action['action'] ?? 'coach_suggestion' );
            $reason   = sanitize_text_field( $action['reason'] ?? '' );
            $priority = sanitize_key( $action['priority'] ?? 'medium' );

            if ( ! in_array( $type, self::COACH_ACTION_TYPES, true ) ) {
                $type = 'coach_suggestion';
            }
            if ( ! in_array( $priority, array( 'low', 'medium', 'high', 'critical' ), true ) ) {
                $priority = 'medium';
            }

            // Dedup
            if ( $post_id > 0 && self::has_pending_action( $type, $post_id ) ) {
                $skipped[] = array(
                    'type'        => $type,
                    'post_id'     => $post_id,
                    'post_title'  => get_the_title( $post_id ),
                    'reason'      => $reason,
                    'skip_reason' => 'Déjà en attente dans l\'Inbox',
                );
                continue;
            }

            if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                $id = HTS_Workflow_Engine::propose(
                    'coach',
                    $type,
                    $post_id,
                    array( 'reason' => $reason, 'source' => 'coach_ai' ),
                    $priority
                );
                if ( $id ) {
                    $created[] = array(
                        'action_id'  => $id,
                        'type'       => $type,
                        'action'     => $type,
                        'post_id'    => $post_id,
                        'post_title' => $post_id > 0 ? get_the_title( $post_id ) : '',
                        'reason'     => $reason,
                        'priority'   => $priority,
                    );
                }
            }
        }

        return array( 'created' => $created, 'skipped' => $skipped );
    }

    public static function extract_seo_plan( $text ) {
        if ( ! preg_match( '/```seo_plan\s*\n(.*?)```/s', $text, $m ) ) {
            return null;
        }

        $json = json_decode( trim( $m[1] ), true );
        if ( ! is_array( $json ) || empty( $json['phases'] ) ) {
            return null;
        }

        $plan = array(
            'title'     => sanitize_text_field( $json['title'] ?? 'Plan SEO' ),
            'objective' => sanitize_text_field( $json['objective'] ?? '' ),
            'phases'    => array(),
            'kpis'      => array(),
        );

        foreach ( $json['phases'] as $phase ) {
            if ( ! is_array( $phase ) ) continue;
            $p = array(
                'name'     => sanitize_text_field( $phase['name'] ?? '' ),
                'timeline' => sanitize_text_field( $phase['timeline'] ?? '' ),
                'icon'     => sanitize_text_field( $phase['icon'] ?? 'clipboard' ),
                'actions'  => array(),
            );
            foreach ( ( $phase['actions'] ?? array() ) as $action ) {
                if ( ! is_array( $action ) ) continue;
                $p['actions'][] = array(
                    'post_id'  => absint( $action['post_id'] ?? 0 ),
                    'action'   => sanitize_key( $action['action'] ?? 'coach_suggestion' ),
                    'title'    => sanitize_text_field( $action['title'] ?? '' ),
                    'task'     => sanitize_text_field( $action['task'] ?? '' ),
                    'current'  => sanitize_text_field( $action['current'] ?? '' ),
                    'target'   => sanitize_text_field( $action['target'] ?? '' ),
                    'effort'   => sanitize_text_field( $action['effort'] ?? '' ),
                    'priority' => sanitize_key( $action['priority'] ?? 'medium' ),
                );
            }
            if ( ! empty( $p['actions'] ) ) {
                $plan['phases'][] = $p;
            }
        }

        if ( ! empty( $json['kpis'] ) && is_array( $json['kpis'] ) ) {
            foreach ( $json['kpis'] as $kpi ) {
                if ( ! is_array( $kpi ) ) continue;
                $plan['kpis'][] = array(
                    'label' => sanitize_text_field( $kpi['label'] ?? '' ),
                    'value' => sanitize_text_field( $kpi['value'] ?? '' ),
                );
            }
        }

        return ! empty( $plan['phases'] ) ? $plan : null;
    }

    /* ═══════════════════════════════════════════════
     *  AGENT MODE — Plan Extraction + Validation (v4.0 Sprint 4.1)
     * ═══════════════════════════════════════════════ */

    /**
     * Extrait un bloc ```plan JSON de la réponse IA (Agent Mode).
     *
     * @since 4.0.0 Sprint 4.1
     * @param  string $text  Réponse IA brute.
     * @return array|null    Plan structuré ou null.
     */
    public static function extract_plan( $text ) {
        if ( preg_match( '/```plan\s*\n(.*?)```/s', $text, $m ) ) {
            $plan = json_decode( trim( $m[1] ), true );
            if ( is_array( $plan ) && ! empty( $plan['steps'] ) ) {
                $validated = array(
                    'goal'     => sanitize_text_field( $plan['goal'] ?? '' ),
                    'steps'    => array(),
                    'estimate' => sanitize_text_field( $plan['estimate'] ?? '' ),
                    'status'   => 'pending_approval',
                );
                $step_num = 0;
                foreach ( $plan['steps'] as $step ) {
                    if ( ! is_array( $step ) ) continue;
                    if ( ++$step_num > self::AGENT_MAX_STEPS ) break;
                    $vs = self::validate_plan_step( $step, $step_num );
                    if ( $vs ) $validated['steps'][] = $vs;
                }
                if ( ! empty( $validated['steps'] ) ) return $validated;
            }
        }

        // ── Fallback : construire un plan à partir des post_id mentionnés dans la réponse ──
        // Si le LLM a mentionné des IDs de pages avec des suggestions, on fabrique un plan
        $post_ids_found = array();
        // Pattern 1: ID: 123, ID=123, ID 123
        if ( preg_match_all( '/\bID\s*[:=]?\s*(\d{3,})\b/i', $text, $id_matches ) ) {
            $post_ids_found = array_merge( $post_ids_found, array_map( 'intval', $id_matches[1] ) );
        }
        // Pattern 2: post_id: 123, post_id=123
        if ( preg_match_all( '/\bpost_id\s*[:=]\s*(\d+)\b/i', $text, $pid_matches ) ) {
            $post_ids_found = array_merge( $post_ids_found, array_map( 'intval', $pid_matches[1] ) );
        }
        // Pattern 3: #123 (article reference)
        if ( preg_match_all( '/\b#(\d{3,})\b/', $text, $hash_matches ) ) {
            $post_ids_found = array_merge( $post_ids_found, array_map( 'intval', $hash_matches[1] ) );
        }
        // Pattern 4: (ID 123) or (id: 123)
        if ( preg_match_all( '/\(\s*(?:id|ID)\s*[:=]?\s*(\d{3,})\s*\)/', $text, $paren_matches ) ) {
            $post_ids_found = array_merge( $post_ids_found, array_map( 'intval', $paren_matches[1] ) );
        }
        $post_ids_found = array_unique( $post_ids_found );

        if ( empty( $post_ids_found ) ) return null;

        // Deviner le type d'action depuis le contexte du texte
        $action_type = 'optimize_meta_both'; // default
        $q_lower = mb_strtolower( $text );
        if ( mb_strpos( $q_lower, 'refresh' ) !== false || mb_strpos( $q_lower, 'rafraîch' ) !== false ) {
            $action_type = 'content_refresh';
        } elseif ( mb_strpos( $q_lower, 'faq' ) !== false ) {
            $action_type = 'add_faq';
        } elseif ( mb_strpos( $q_lower, 'lien' ) !== false || mb_strpos( $q_lower, 'maillage' ) !== false ) {
            $action_type = 'add_internal_links';
        } elseif ( mb_strpos( $q_lower, 'geo' ) !== false || mb_strpos( $q_lower, 'moteurs ia' ) !== false ) {
            $action_type = 'geo_optimize';
        }

        if ( ! isset( self::AGENT_ACTION_CATALOG[ $action_type ] ) ) return null;
        $cat = self::AGENT_ACTION_CATALOG[ $action_type ];

        $steps = array();
        foreach ( array_slice( $post_ids_found, 0, self::AGENT_MAX_STEPS ) as $i => $pid ) {
            $title = get_the_title( $pid );
            if ( empty( $title ) ) continue;
            $steps[] = array(
                'step'        => $i + 1,
                'action'      => $action_type,
                'label'       => $cat['label'],
                'module'      => $cat['module'],
                'method'      => $cat['method'],
                'params'      => array( 'post_id' => $pid ),
                'missing'     => array(),
                'description' => $cat['label'] . ' pour "' . mb_substr( $title, 0, 60 ) . '"',
                'status'      => 'ready',
            );
        }

        if ( empty( $steps ) ) return null;

        return array(
            'goal'     => $cat['label'] . ' — ' . count( $steps ) . ' page' . ( count( $steps ) > 1 ? 's' : '' ),
            'steps'    => $steps,
            'estimate' => 'Temps estimé : ~' . ( count( $steps ) * 2 ) . ' minutes',
            'status'   => 'pending_approval',
        );
    }

    /**
     * Valide une étape de plan contre le catalogue.
     *
     * @since 4.0.0 Sprint 4.1
     */
    private static function validate_plan_step( $step, $step_num ) {
        $action_key = sanitize_key( $step['action'] ?? '' );
        if ( ! isset( self::AGENT_ACTION_CATALOG[ $action_key ] ) ) {
            return null;
        }
        $cat = self::AGENT_ACTION_CATALOG[ $action_key ];
        $params = array();
        if ( ! empty( $step['params'] ) && is_array( $step['params'] ) ) {
            foreach ( $step['params'] as $k => $v ) {
                $k = sanitize_key( $k );
                if ( in_array( $k, $cat['params'], true ) ) {
                    $params[ $k ] = is_array( $v ) ? array_map( 'sanitize_text_field', $v ) : ( is_numeric( $v ) ? $v : sanitize_text_field( $v ) );
                }
            }
        }
        $missing = array();
        foreach ( $cat['required'] as $req ) {
            if ( empty( $params[ $req ] ) ) $missing[] = $req;
        }
        return array(
            'step'        => $step_num,
            'action'      => $action_key,
            'label'       => $cat['label'],
            'module'      => $cat['module'],
            'method'      => $cat['method'],
            'params'      => $params,
            'missing'     => $missing,
            'description' => sanitize_text_field( $step['description'] ?? $cat['description'] ),
            'status'      => empty( $missing ) ? 'ready' : 'incomplete',
        );
    }

    /**
     * Bloc prompt Agent Mode.
     *
     * @since 4.0.0 Sprint 4.1
     */
    private static function build_agent_block() {
        $catalog_lines = array();
        foreach ( self::AGENT_ACTION_CATALOG as $key => $entry ) {
            $catalog_lines[] = '- `' . $key . '` : ' . $entry['description'] . ' — Params: [' . implode( ', ', $entry['params'] ) . '] (requis: ' . implode( ', ', $entry['required'] ) . ')';
        }
        return '

═══ MODE AGENT — TU EXÉCUTES (Sprint 4.3) ═══
OBLIGATION ABSOLUE : ta réponse DOIT contenir un bloc ```plan``` JSON. TOUJOURS. Même pour une seule action.
Le client te demande de FAIRE quelque chose. Tu dois :
1. Expliquer brièvement ce que tu vas faire (3-5 lignes max)
2. Inclure le bloc ```plan``` JSON ci-dessous — C\'EST OBLIGATOIRE, NE L\'OUBLIE JAMAIS

CATALOGUE D\'ACTIONS DISPONIBLES :
' . implode( "\n", $catalog_lines ) . '

FORMAT EXACT DU BLOC PLAN (à inclure OBLIGATOIREMENT dans ta réponse) :
```plan
{
  "goal": "Description courte de l\'objectif",
  "steps": [
    {
      "action": "cle_du_catalogue",
      "description": "Ce que cette étape fait concrètement",
      "params": { "post_id": 123 }
    }
  ],
  "estimate": "Temps estimé : ~X minutes"
}
```

EXEMPLE CONCRET — Si le client dit "ajoute une FAQ à ma page Assurance Vie (ID 1234)" :
```plan
{
  "goal": "Ajouter une FAQ optimisée SEO",
  "steps": [
    {
      "action": "add_faq",
      "description": "Générer et ajouter une FAQ pour \"Assurance Vie\"",
      "params": { "post_id": 1234 }
    }
  ],
  "estimate": "Temps estimé : ~2 minutes"
}
```

RÈGLES :
1. N\'utilise QUE les actions du catalogue. "action" = clé exacte du catalogue.
2. post_id = IDs réels des données du site. Si tu proposes des metas pour Sitemap (ID 8339), mets post_id: 8339.
3. Maximum ' . self::AGENT_MAX_STEPS . ' étapes.
4. Le plan s\'affichera comme des cartes cliquables pour approbation AVANT exécution.
5. RAPPEL CRITIQUE : le bloc ```plan``` est OBLIGATOIRE. Sans lui, le client ne verra pas de boutons d\'action.
   Si tu réponds sans bloc plan, ta réponse est INUTILE car le client ne pourra rien faire.
6. META TAGS — CHOISIS LA BONNE ACTION :
   - "optimise les metas" / "titre et description" → `optimize_meta_both` (les deux)
   - "optimise les titres" / "les meta titles" → `optimize_meta_title` (titre seul)
   - "optimise les descriptions" / "les meta descriptions" → `optimize_meta_desc` (desc seule)
   Il n\'existe PAS d\'action "optimize_meta". Utilise toujours `optimize_meta_both`, `optimize_meta_title`, ou `optimize_meta_desc`.
   EXEMPLES :
   - Client : "optimise les metas descriptions des pires pages" → action = "optimize_meta_desc"
   - Client : "améliore les titres SEO" → action = "optimize_meta_title"
   - Client : "optimise les metas de cette page" → action = "optimize_meta_both"
7. UNE étape par page et par action. Ne crée PAS 2 étapes pour la même page.
8. Si le client mentionne une page par son TITRE (et pas par ID), cherche dans le contexte fourni pour trouver l\'ID correspondant. Si tu ne trouves pas l\'ID exact, dis-le et demande confirmation.
9. MÊME si tu dois expliquer ou poser une question, inclus TOUJOURS le bloc plan avec les infos que tu as.';
    }

    /**
     * Sauvegarde un plan Agent Mode dans la session.
     *
     * @since 4.0.0 Sprint 4.1
     */
    private static function save_plan_to_session( $session_id, $user_id, $plan ) {
        if ( ! self::messages_table_exists() ) return;
        global $wpdb;
        $table = $wpdb->prefix . self::MESSAGES_TABLE;

        $insert_data = array(
            'session_id'   => $session_id,
            'user_id'      => $user_id,
            'role'         => 'system',
            'content'      => '[PLAN] ' . ( $plan['goal'] ?? '' ),
            'intent'       => 'action',
            'created_at'   => current_time( 'mysql' ),
        );
        $insert_fmt = array( '%d', '%d', '%s', '%s', '%s', '%s' );

        // Sprint 4.2 : colonne actions_json peut ne pas encore exister
        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );
        if ( is_array( $columns ) && in_array( 'actions_json', $columns, true ) ) {
            $insert_data['actions_json'] = wp_json_encode( $plan, JSON_UNESCAPED_UNICODE );
            $insert_fmt[] = '%s';
        }

        $wpdb->insert( $table, $insert_data, $insert_fmt );
        set_transient( 'hts_coach_plan_' . $session_id, $plan, HOUR_IN_SECONDS );
    }

    /**
     * Récupère le dernier plan en attente pour une session.
     *
     * @since 4.0.0 Sprint 4.1
     */
    public static function get_pending_plan( $session_id ) {
        $plan = get_transient( 'hts_coach_plan_' . $session_id );
        if ( is_array( $plan ) && ( $plan['status'] ?? '' ) === 'pending_approval' ) {
            return $plan;
        }
        if ( ! self::messages_table_exists() ) return null;
        global $wpdb;
        $row = $wpdb->get_var( $wpdb->prepare(
            "SELECT actions_json FROM {$wpdb->prefix}" . self::MESSAGES_TABLE . "
             WHERE session_id = %d AND intent = 'action' AND role = 'system'
             ORDER BY id DESC LIMIT 1",
            $session_id
        ) );
        if ( ! $row ) return null;
        $plan = json_decode( $row, true );
        return ( is_array( $plan ) && ( $plan['status'] ?? '' ) === 'pending_approval' ) ? $plan : null;
    }

    /* ═══════════════════════════════════════════════
     *  AGENT MODE — Preview + Execute (v4.0 Sprint 4.2)
     * ═══════════════════════════════════════════════ */

    /**
     * Met à jour l'état du plan dans actions_json après exécution batch.
     * Permet au SSR de rendre les steps avec le bon état (sent/duplicate/error) après F5.
     *
     * @since 4.0.0 Sprint 4.2
     * @param int   $session_id  Session ID.
     * @param array $results     Résultats de l'exécution batch.
     */
    private static function update_plan_execution_state( $session_id, $results ) {
        if ( ! self::messages_table_exists() ) return;
        global $wpdb;
        $table = $wpdb->prefix . self::MESSAGES_TABLE;

        // Récupérer le dernier plan pour cette session
        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );
        if ( ! is_array( $columns ) || ! in_array( 'actions_json', $columns, true ) ) return;

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, actions_json FROM {$table}
             WHERE session_id = %d AND intent = 'action' AND role IN ('system','assistant')
             ORDER BY id DESC LIMIT 1",
            $session_id
        ) );

        if ( ! $row || empty( $row->actions_json ) ) return;

        $decoded = json_decode( $row->actions_json, true );
        if ( ! is_array( $decoded ) ) return;

        // Sprint 5.3: handle both wrapped {plan:{steps:...}} and legacy {steps:...} formats
        $is_wrapped = isset( $decoded['plan'] );
        $plan = $is_wrapped ? ( $decoded['plan'] ?? array() ) : $decoded;
        if ( empty( $plan['steps'] ) ) return;

        // Mettre à jour le status de chaque step
        foreach ( $results as $res ) {
            $idx = ( $res['step'] ?? 0 ) - 1;
            if ( isset( $plan['steps'][ $idx ] ) ) {
                $new_status = $res['status'] ?? 'unknown';
                if ( $new_status === 'proposed' ) {
                    $plan['steps'][ $idx ]['status'] = 'sent';
                } elseif ( $new_status === 'merged' ) {
                    $plan['steps'][ $idx ]['status'] = 'merged';
                    $plan['steps'][ $idx ]['merged_with'] = $res['merged_with'] ?? 1;
                } elseif ( $new_status === 'duplicate' ) {
                    $plan['steps'][ $idx ]['status'] = 'duplicate';
                } else {
                    $plan['steps'][ $idx ]['status'] = 'error';
                }
            }
        }

        // Marquer le plan comme exécuté
        $plan['status'] = 'executed';

        // Sprint 5.3: rewrap into the original format for DB save
        if ( $is_wrapped ) {
            $decoded['plan'] = $plan;
            $save_data = $decoded;
        } else {
            $save_data = $plan;
        }

        $wpdb->update(
            $table,
            array( 'actions_json' => wp_json_encode( $save_data, JSON_UNESCAPED_UNICODE ) ),
            array( 'id' => $row->id ),
            array( '%s' ),
            array( '%d' )
        );
    }

    /**
     * AJAX : Preview d'une étape de plan Agent Mode.
     * Génère un aperçu before/after sans rien modifier en DB.
     *
     * @since 4.0.0 Sprint 4.2
     */
    public function ajax_preview_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(2);

        $session_id = absint( $_POST['session_id'] ?? 0 );
        $step_index = absint( $_POST['step_index'] ?? 0 );
        $action_key = sanitize_key( $_POST['step_action'] ?? '' );
        $params     = isset( $_POST['params'] ) ? (array) $_POST['params'] : array();

        // Sprint 4.2 fix7 : Normaliser legacy optimize_meta
        if ( $action_key === 'optimize_meta' ) {
            $reclassified = self::reclassify_meta_action( $session_id );
            $action_key = $reclassified ?: 'optimize_meta_both';
        }

        if ( ! isset( self::AGENT_ACTION_CATALOG[ $action_key ] ) ) {
            wp_send_json_error( array( 'message' => 'Action inconnue : ' . $action_key ) );
        }

        $cat = self::AGENT_ACTION_CATALOG[ $action_key ];

        // Sanitize params
        $clean_params = array();
        foreach ( $params as $k => $v ) {
            $k = sanitize_key( $k );
            if ( in_array( $k, $cat['params'], true ) ) {
                if ( is_array( $v ) ) {
                    $clean_params[ $k ] = array_map( 'sanitize_text_field', $v );
                } else {
                    $clean_params[ $k ] = is_numeric( $v ) ? (int) $v : sanitize_text_field( $v );
                }
            }
        }

        $preview = self::generate_step_preview( $action_key, $clean_params );

        if ( is_wp_error( $preview ) ) {
            wp_send_json_error( array( 'message' => $preview->get_error_message() ) );
        }

        wp_send_json_success( $preview );
    }

    /**
     * AJAX : Exécute une étape de plan Agent Mode.
     * Propose l'action dans l'Inbox via Workflow Engine.
     *
     * @since 4.0.0 Sprint 4.2
     */
    public function ajax_execute_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(2);

        $session_id = absint( $_POST['session_id'] ?? 0 );
        $step_index = absint( $_POST['step_index'] ?? 0 );
        $action_key = sanitize_key( $_POST['step_action'] ?? '' );
        $params     = isset( $_POST['params'] ) ? (array) $_POST['params'] : array();

        // Sprint 4.2 fix7 : Normaliser legacy optimize_meta
        if ( $action_key === 'optimize_meta' ) {
            $reclassified = self::reclassify_meta_action( $session_id );
            $action_key = $reclassified ?: 'optimize_meta_both';
        }

        if ( ! isset( self::AGENT_ACTION_CATALOG[ $action_key ] ) ) {
            wp_send_json_error( array( 'message' => 'Action inconnue : ' . $action_key ) );
        }

        $cat = self::AGENT_ACTION_CATALOG[ $action_key ];

        // Sanitize
        $clean_params = array();
        foreach ( $params as $k => $v ) {
            $k = sanitize_key( $k );
            if ( in_array( $k, $cat['params'], true ) ) {
                if ( is_array( $v ) ) {
                    $clean_params[ $k ] = array_map( 'sanitize_text_field', $v );
                } else {
                    $clean_params[ $k ] = is_numeric( $v ) ? (int) $v : sanitize_text_field( $v );
                }
            }
        }

        // Vérifier params requis
        foreach ( $cat['required'] as $req ) {
            if ( empty( $clean_params[ $req ] ) ) {
                wp_send_json_error( array( 'message' => 'Paramètre manquant : ' . $req ) );
            }
        }

        $result = self::execute_agent_step( $action_key, $clean_params, $session_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        // Duplicate = succès partiel (action déjà dans l'Inbox)
        if ( is_array( $result ) && ( $result['status'] ?? '' ) === 'duplicate' ) {
            wp_send_json_success( $result );
        }

        wp_send_json_success( $result );
    }

    /**
     * AJAX : Exécute toutes les étapes "ready" d'un plan Agent Mode.
     *
     * @since 4.0.0 Sprint 4.2
     */
    public function ajax_execute_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(2);

        // Auto-detect limited server
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time <= 60 && class_exists( 'HTS_Job_Runner' ) ) {
            wp_send_json_error( array( 'message' => 'use_batch', 'batch_init' => 'hts_coach_plan_init', 'batch_step' => 'hts_coach_plan_step' ) );
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 );

        $session_id = absint( $_POST['session_id'] ?? 0 );
        $plan_json  = isset( $_POST['plan'] ) ? wp_unslash( $_POST['plan'] ) : '';

        if ( is_string( $plan_json ) ) {
            $plan = json_decode( $plan_json, true );
        } else {
            $plan = (array) $plan_json;
        }

        if ( empty( $plan['steps'] ) || ! is_array( $plan['steps'] ) ) {
            wp_send_json_error( array( 'message' => 'Plan invalide ou vide.' ) );
        }

        $results = array();
        $success = 0;
        $failed  = 0;
        $total_proposed = 0; // Nombre réel d'actions créées dans l'Inbox

        hts_debug_log( '[Coach] ajax_execute_plan: session=' . $session_id . ', steps=' . count( $plan['steps'] ) );

        // ── Dédupliquer les steps identiques (même action + même post_id) ──
        // L'AI génère parfois 2 steps "optimize_meta" pour title et desc séparément,
        // mais notre handler optimize_meta crée déjà les 2 en une seule passe.
        $seen_steps = array();

        foreach ( $plan['steps'] as $i => $step ) {
            if ( ( $step['status'] ?? '' ) !== 'ready' ) {
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' skipped: status=' . ( $step['status'] ?? 'null' ) );
                $results[] = array( 'step' => $i + 1, 'status' => 'skipped', 'message' => 'Étape incomplète' );
                continue;
            }

            $action_key = sanitize_key( $step['action'] ?? '' );
            $params     = is_array( $step['params'] ?? null ) ? $step['params'] : array();

            // Sprint 4.2 fix7 : Normaliser les legacy action keys
            // L'AI pourrait encore envoyer "optimize_meta" depuis un cache ou hallucination
            if ( $action_key === 'optimize_meta' ) {
                $reclassified = self::reclassify_meta_action( $session_id );
                $action_key = $reclassified ?: 'optimize_meta_both';
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' normalized legacy optimize_meta → ' . $action_key );
            }

            // Valider que l'action existe dans le catalogue (ou legacy compat)
            if ( ! isset( self::AGENT_ACTION_CATALOG[ $action_key ] ) && $action_key !== 'optimize_meta_both' ) {
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' UNKNOWN action: ' . $action_key );
                $results[] = array( 'step' => $i + 1, 'status' => 'error', 'message' => 'Action inconnue : ' . $action_key );
                $failed++;
                continue;
            }
            $post_id_s  = absint( $params['post_id'] ?? 0 );

            // Clé de dédup : action + post_id
            $dedup_key = $action_key . '::' . $post_id_s;
            if ( isset( $seen_steps[ $dedup_key ] ) ) {
                $first_step = $seen_steps[ $dedup_key ];
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' MERGED with step ' . $first_step . ' (same ' . $dedup_key . ')' );
                $results[] = array(
                    'step'    => $i + 1,
                    'status'  => 'merged',
                    'merged_with' => $first_step,
                    'message' => 'Inclus dans l\'étape ' . $first_step . '.',
                );
                continue;
            }
            $seen_steps[ $dedup_key ] = $i + 1;

            hts_debug_log( '[Coach] Executing step ' . ( $i + 1 ) . ': action=' . $action_key . ', post_id=' . ( $params['post_id'] ?? '0' ) );

            $result = self::execute_agent_step( $action_key, $params, $session_id );

            if ( is_wp_error( $result ) ) {
                $failed++;
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' ERROR: ' . $result->get_error_message() );
                $results[] = array( 'step' => $i + 1, 'status' => 'error', 'message' => $result->get_error_message() );
            } elseif ( is_array( $result ) && ( $result['status'] ?? '' ) === 'duplicate' ) {
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' DUPLICATE' );
                $results[] = array( 'step' => $i + 1, 'status' => 'duplicate', 'message' => $result['message'] );
            } else {
                $success++;
                // Compter les actions réelles proposées (optimize_meta = 2 actions)
                $total_proposed += max( 1, absint( $result['proposed'] ?? 1 ) );
                hts_debug_log( '[Coach] Step ' . ( $i + 1 ) . ' OK: ' . wp_json_encode( $result ) );
                $results[] = array_merge( array( 'step' => $i + 1 ), $result );
            }
        }

        // Invalider le transient plan
        if ( $session_id > 0 ) {
            delete_transient( 'hts_coach_plan_' . $session_id );

            // Persister l'état d'exécution dans actions_json pour que le F5 affiche le bon état
            self::update_plan_execution_state( $session_id, $results );
        }

        // Compter les duplicates
        $dup_count = 0;
        foreach ( $results as $r ) {
            if ( ( $r['status'] ?? '' ) === 'duplicate' ) $dup_count++;
        }

        $msg = '';
        if ( $total_proposed > 0 ) {
            $msg = $total_proposed . ' action(s) envoyée(s) dans l\'Inbox';
            if ( $dup_count > 0 ) $msg .= ' (' . $dup_count . ' déjà en attente)';
        } elseif ( $dup_count > 0 ) {
            $msg = 'Toutes les actions sont déjà dans l\'Inbox. Rendez-vous dans l\'Inbox pour les valider.';
        } else {
            $msg = 'Aucune action proposée';
        }
        if ( $failed > 0 ) $msg .= ', ' . $failed . ' en erreur';
        if ( $total_proposed > 0 || $failed > 0 ) $msg .= '.';

        wp_send_json_success( array(
            'success' => $success,
            'failed'  => $failed,
            'total'   => count( $plan['steps'] ),
            'results' => $results,
            'message' => $msg,
        ) );
    }

    /**
     * Génère un aperçu (preview) pour une étape de plan, sans modifier la DB.
     *
     * @since 4.0.0 Sprint 4.2
     * @param string $action_key  Clé du catalogue d'actions.
     * @param array  $params      Paramètres sanitizés.
     * @return array|WP_Error     Preview data ou erreur.
     */
    private static function generate_step_preview( $action_key, $params ) {
        $post_id = absint( $params['post_id'] ?? 0 );

        $post_actions = array(
            'optimize_meta_both', 'optimize_meta_title', 'optimize_meta_desc',
            'optimize_meta', 'content_refresh', 'add_faq',
            'add_internal_links', 'geo_optimize', 'schedule_publication',
        );

        $post = null;
        if ( in_array( $action_key, $post_actions, true ) ) {
            if ( ! $post_id ) {
                return new \WP_Error( 'missing_post', 'Aucun article ciblé (post_id manquant).' );
            }
            $post = get_post( $post_id );
            if ( ! $post ) {
                return new \WP_Error( 'invalid_post', 'Article introuvable (ID: ' . $post_id . ').' );
            }
        }

        $preview = array(
            'action'      => $action_key,
            'type'        => 'info',
            'title'       => '',
            'before'      => null,
            'after'       => null,
            'description' => '',
            'warnings'    => array(),
            'can_execute' => true,
            'target'      => '',
            'post_id'     => $post_id,
            'edit_url'    => $post_id ? get_edit_post_link( $post_id, 'raw' ) : '',
            'view_url'    => $post_id ? get_permalink( $post_id ) : '',
        );

        switch ( $action_key ) {

            case 'optimize_meta':
            case 'optimize_meta_both':
                $cur_title = get_post_meta( $post_id, '_hts_meta_title', true );
                $cur_desc  = get_post_meta( $post_id, '_hts_meta_description', true );
                if ( empty( $cur_title ) ) $cur_title = $post->post_title;
                if ( empty( $cur_desc ) )  $cur_desc  = wp_trim_words( wp_strip_all_tags( $post->post_content ), 25 );

                $preview['type']        = 'diff';
                $preview['title']       = 'Optimisation des metas (titre + description)';
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['before']      = array(
                    'meta_title' => $cur_title ?: '(vide)',
                    'meta_desc'  => mb_substr( $cur_desc ?: '(vide)', 0, 160 ),
                );
                $preview['after']       = array(
                    'meta_title' => "\xe2\x86\x92 Sera g\xc3\xa9n\xc3\xa9r\xc3\xa9 par l'IA (Meta Score)",
                    'meta_desc'  => "\xe2\x86\x92 Sera g\xc3\xa9n\xc3\xa9r\xc3\xa9 par l'IA (Meta Score)",
                );
                $preview['description'] = "L'IA va analyser votre page et g\xc3\xa9n\xc3\xa9rer un meta title et une meta description optimis\xc3\xa9s pour le CTR et le SEO.";

                if ( class_exists( 'HTS_Workflow_Engine' ) && method_exists( 'HTS_Workflow_Engine', 'check_traffic_threshold' ) && ! HTS_Workflow_Engine::check_traffic_threshold( $post_id ) ) {
                    $preview['warnings'][] = "Cette page a un bon trafic. La modification sera propos\xc3\xa9e dans l'Inbox pour validation manuelle.";
                }
                if ( self::has_pending_action( 'add_meta_title', $post_id ) ) {
                    $preview['warnings'][]  = "Une optimisation meta est d\xc3\xa9j\xc3\xa0 en attente dans l'Inbox pour cette page.";
                    $preview['can_execute'] = false;
                }
                break;

            case 'optimize_meta_title':
                $cur_title = get_post_meta( $post_id, '_hts_meta_title', true );
                if ( empty( $cur_title ) ) $cur_title = $post->post_title;

                $preview['type']        = 'diff';
                $preview['title']       = 'Optimisation du meta title';
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['before']      = array( 'meta_title' => $cur_title ?: '(vide)' );
                $preview['after']       = array( 'meta_title' => "\xe2\x86\x92 Sera g\xc3\xa9n\xc3\xa9r\xc3\xa9 par l'IA" );
                $preview['description'] = "L'IA va g\xc3\xa9n\xc3\xa9rer un meta title optimis\xc3\xa9 (titre uniquement).";

                if ( self::has_pending_action( 'add_meta_title', $post_id ) ) {
                    $preview['warnings'][]  = "Un meta title est d\xc3\xa9j\xc3\xa0 en attente dans l'Inbox.";
                    $preview['can_execute'] = false;
                }
                break;

            case 'optimize_meta_desc':
                $cur_desc = get_post_meta( $post_id, '_hts_meta_description', true );
                if ( empty( $cur_desc ) ) $cur_desc = wp_trim_words( wp_strip_all_tags( $post->post_content ), 25 );

                $preview['type']        = 'diff';
                $preview['title']       = 'Optimisation de la meta description';
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['before']      = array( 'meta_desc' => mb_substr( $cur_desc ?: '(vide)', 0, 160 ) );
                $preview['after']       = array( 'meta_desc' => "\xe2\x86\x92 Sera g\xc3\xa9n\xc3\xa9r\xc3\xa9e par l'IA" );
                $preview['description'] = "L'IA va g\xc3\xa9n\xc3\xa9rer une meta description optimis\xc3\xa9e (description uniquement).";

                if ( self::has_pending_action( 'add_meta_desc', $post_id ) ) {
                    $preview['warnings'][]  = "Une meta description est d\xc3\xa9j\xc3\xa0 en attente dans l'Inbox.";
                    $preview['can_execute'] = false;
                }
                break;

            case 'content_refresh':
                $word_count    = hts_word_count( wp_strip_all_tags( $post->post_content ) );
                $last_modified = $post->post_modified;

                $preview['type']        = 'diff';
                $preview['title']       = "Rafra\xc3\xaechissement du contenu";
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['description'] = "Article de {$word_count} mots, derni\xc3\xa8re modification le " . wp_date( 'j F Y', strtotime( $last_modified ) ) . ". L'IA va r\xc3\xa9\xc3\xa9crire et enrichir les sections obsolètes.";
                $preview['before']      = array(
                    'mots'     => $word_count . ' mots',
                    'modifié'  => wp_date( 'd/m/Y', strtotime( $last_modified ) ),
                );
                $preview['after'] = array(
                    'mots'     => "\xe2\x86\x92 Contenu enrichi (+20-40%)",
                    'modifié'  => "\xe2\x86\x92 Mis \xc3\xa0 jour aujourd'hui",
                );
                break;

            case 'add_faq':
                $has_faq = (bool) get_post_meta( $post_id, '_hts_has_faq', true );

                $preview['type']        = 'info';
                $preview['title']       = "Ajout d'une FAQ";
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['description'] = $has_faq
                    ? "Cet article a d\xc3\xa9j\xc3\xa0 une FAQ. L'IA va l'enrichir avec de nouvelles questions."
                    : "L'IA va g\xc3\xa9n\xc3\xa9rer une FAQ pertinente avec schema.org pour booster la visibilit\xc3\xa9 GEO.";
                if ( $has_faq ) {
                    $preview['warnings'][] = "Une FAQ existe d\xc3\xa9j\xc3\xa0. Les nouvelles questions seront ajout\xc3\xa9es \xc3\xa0 la suite.";
                }
                break;

            case 'add_internal_links':
                $content    = $post->post_content;
                $link_count = preg_match_all( '/<a\s+[^>]*href\s*=/i', $content );

                $preview['type']        = 'diff';
                $preview['title']       = 'Liens internes';
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['description'] = "L'outil va analyser le contenu et proposer des liens internes pertinents vers d'autres pages de votre site.";
                $preview['before'] = array( 'liens_internes' => $link_count . ' liens internes actuels' );
                $preview['after']  = array( 'liens_internes' => "\xe2\x86\x92 Suggestions ajout\xc3\xa9es dans l'Inbox" );
                break;

            case 'generate_article':
                $keyword    = sanitize_text_field( $params['keyword'] ?? '' );
                $cluster_id = absint( $params['cluster_id'] ?? 0 );
                $word_count = absint( $params['word_count'] ?? 1500 );

                $preview['type']        = 'info';
                $preview['title']       = "G\xc3\xa9n\xc3\xa9ration d'article";
                $preview['target']      = 'Mot-cl\xc3\xa9 : "' . $keyword . '"';
                $preview['description'] = "Un article SEO de ~{$word_count} mots sera g\xc3\xa9n\xc3\xa9r\xc3\xa9 par l'IA et cr\xc3\xa9\xc3\xa9 comme brouillon WordPress.";
                if ( $cluster_id ) {
                    $preview['description'] .= " Il sera rattach\xc3\xa9 au cocon #{$cluster_id}.";
                }
                $preview['after'] = array( 'statut' => "\xe2\x86\x92 Brouillon WordPress pr\xc3\xaat \xc3\xa0 relire" );
                break;

            case 'schedule_publication':
                $date = sanitize_text_field( $params['publish_date'] ?? '' );

                $preview['type']        = 'diff';
                $preview['title']       = 'Programmation publication';
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['description'] = $date
                    ? "L'article sera programm\xc3\xa9 pour publication le {$date}."
                    : "L'article sera publi\xc3\xa9 imm\xc3\xa9diatement.";
                $preview['before'] = array( 'statut' => 'Statut actuel : ' . get_post_status( $post_id ) );
                $preview['after']  = array( 'statut' => "\xe2\x86\x92 " . ( $date ? "Programm\xc3\xa9 ({$date})" : "Publi\xc3\xa9" ) );
                break;

            case 'create_cocon_articles':
                $cluster_id = absint( $params['cluster_id'] ?? 0 );
                $count      = absint( $params['count'] ?? 5 );

                $preview['type']        = 'info';
                $preview['title']       = "Cr\xc3\xa9ation d'articles cocon";
                $preview['target']      = 'Cluster #' . $cluster_id;
                $preview['description'] = "{$count} articles satellites seront g\xc3\xa9n\xc3\xa9r\xc3\xa9s pour compl\xc3\xa9ter le cocon.";
                $preview['after'] = array( 'articles' => "\xe2\x86\x92 {$count} brouillons cr\xc3\xa9\xc3\xa9s" );
                break;

            case 'fix_orphan_links':
                $post_ids = isset( $params['post_ids'] ) ? array_map( 'absint', (array) $params['post_ids'] ) : array();
                $preview['type']        = 'info';
                $preview['title']       = 'Correction pages orphelines';
                $preview['target']      = count( $post_ids ) . ' page(s)';
                $preview['description'] = "Des liens internes seront ajout\xc3\xa9s vers les pages orphelines pour am\xc3\xa9liorer le maillage.";
                break;

            case 'geo_optimize':
                $preview['type']        = 'info';
                $preview['title']       = 'Optimisation moteurs IA';
                $preview['target']      = mb_substr( $post->post_title, 0, 60 ) . ' (ID ' . $post_id . ')';
                $preview['description'] = "L'article sera optimis\xc3\xa9 pour les moteurs IA (FAQ, sch\xc3\xa9mas structur\xc3\xa9s, restructuration).";
                break;

            case 'bulk_optimize_metas':
                $post_ids = isset( $params['post_ids'] ) ? array_map( 'absint', (array) $params['post_ids'] ) : array();
                $count    = count( $post_ids );
                $preview['type']        = 'info';
                $preview['title']       = 'Optimisation metas en masse';
                $preview['target']      = $count . ' page(s)';
                $preview['description'] = "Les meta title/description seront g\xc3\xa9n\xc3\xa9r\xc3\xa9s pour {$count} articles.";
                break;

            default:
                $cat = self::AGENT_ACTION_CATALOG[ $action_key ] ?? null;
                $preview['title']       = $cat ? $cat['label'] : $action_key;
                $preview['description'] = $cat ? $cat['description'] : 'Action disponible.';
                break;
        }

        return $preview;
    }

    /**
     * Exécute une étape Agent Mode : propose dans l'Inbox via Workflow Engine.
     * Pattern TOUJOURS : propose dans l'Inbox → l'utilisateur valide.
     *
     * @since 4.0.0 Sprint 4.2
     * @param string $action_key  Clé catalogue.
     * @param array  $params      Params sanitizés.
     * @param int    $session_id  Session Coach.
     * @return array|WP_Error
     */
    private static function execute_agent_step( $action_key, $params, $session_id = 0 ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) {
            return new \WP_Error( 'no_workflow', "Le module Workflow Engine n'est pas disponible." );
        }

        // ── Sprint 4.2 fix7 : Fallback PHP meta_scope ──
        // Si l'AI envoie optimize_meta (legacy) au lieu de optimize_meta_both/title/desc,
        // on reclassifie en analysant la question originale de l'utilisateur.
        if ( $action_key === 'optimize_meta' ) {
            $reclassified = self::reclassify_meta_action( $session_id );
            $action_key = $reclassified ?: 'optimize_meta_both';
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf(
                    'Coach Agent : reclassified legacy optimize_meta → %s (session=%d)',
                    $action_key, $session_id
                ), 'info', 'coach' );
            }
        }

        if ( ! isset( self::AGENT_ACTION_CATALOG[ $action_key ] ) ) {
            return new \WP_Error( 'invalid_action', 'Action inconnue : ' . $action_key );
        }

        // Vérifier que l'agent Coach est activé dans les réglages
        if ( ! HTS_Workflow_Engine::is_agent_enabled( 'coach' ) ) {
            return new \WP_Error( 'agent_disabled', "L'agent Coach SEO n'est pas activ\xc3\xa9 dans R\xc3\xa9glages \xe2\x86\x92 Agents SEO. Activez-le pour envoyer des actions dans l'Inbox." );
        }

        $cat     = self::AGENT_ACTION_CATALOG[ $action_key ];
        $post_id = absint( $params['post_id'] ?? 0 );

        // Mapper action_key du catalogue vers le type Workflow Engine
        $wf_type_map = array(
            'optimize_meta_both'    => 'add_meta_title', // handled specially below (creates 2 actions)
            'optimize_meta'         => 'add_meta_title', // legacy compat — reclassified by fallback
            'optimize_meta_title'   => 'add_meta_title',
            'optimize_meta_desc'    => 'add_meta_desc',
            'content_refresh'       => 'content_refresh',
            'add_faq'               => 'add_faq',
            'add_internal_links'    => 'add_internal_links',
            'geo_optimize'          => 'geo_optimize',
            // Sprint 5.3 fix: these must use their OWN type so Coach catalog dispatches to the correct *_from_coach() method
            'generate_article'      => 'generate_article',
            'schedule_publication'  => 'schedule_publication',
            'create_cocon_articles' => 'create_cocon_articles',
            'fix_orphan_links'      => 'fix_orphan_links',
            'bulk_optimize_metas'   => 'bulk_optimize_metas',
        );

        $wf_type = $wf_type_map[ $action_key ] ?? $action_key;

        // optimize_meta_both = titre + description → proposer les 2 actions dans l'Inbox
        // optimize_meta_title / optimize_meta_desc = une seule action → passer au flow standard
        if ( $action_key === 'optimize_meta_both' && $post_id > 0 ) {
            $proposed = 0;
            $duplicates = 0;
            $errors = array();
            foreach ( array( 'add_meta_title', 'add_meta_desc' ) as $meta_type ) {
                if ( self::has_pending_action( $meta_type, $post_id ) ) {
                    $duplicates++;
                    continue;
                }
                $id = HTS_Workflow_Engine::propose(
                    'coach',
                    $meta_type,
                    $post_id,
                    array_merge( $params, array( 'source' => 'coach_agent', 'session_id' => $session_id ) ),
                    'high'
                );
                if ( $id ) {
                    $proposed++;
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf(
                            'Coach Agent : step "%s" (%s) → Inbox #%d (post_id=%d, session=%d)',
                            $action_key, $meta_type, $id, $post_id, $session_id
                        ), 'info', 'coach' );
                    }
                } else {
                    $errors[] = $meta_type;
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf(
                            'Coach Agent : propose() a retourné false pour %s (post_id=%d). Agent désactivé ou erreur DB.',
                            $meta_type, $post_id
                        ), 'warn', 'coach' );
                    }
                }
            }
            if ( $proposed === 0 && $duplicates > 0 ) {
                return array(
                    'status'  => 'duplicate',
                    'message' => "Ces metas sont d\xc3\xa9j\xc3\xa0 en attente dans l'Inbox (propos\xc3\xa9es par un autre agent). Rendez-vous dans l'Inbox pour les valider.",
                );
            }
            if ( $proposed === 0 ) {
                return new \WP_Error( 'propose_failed',
                    "Impossible de proposer les metas dans l'Inbox. "
                    . "V\xc3\xa9rifiez que l'agent Coach est activ\xc3\xa9 (R\xc3\xa9glages \xe2\x86\x92 Agents SEO) "
                    . "et que le mode est \xc2\xab Review \xc2\xbb ou \xc2\xab Auto \xc2\xbb."
                );
            }
            return array(
                'status'    => 'proposed',
                'proposed'  => $proposed,
                'message'   => "\xe2\x9c\x85 " . $cat['label'] . " propos\xc3\xa9 dans l'Inbox (" . $proposed . " action" . ( $proposed > 1 ? 's' : '' ) . ').',
                'inbox_url' => admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ),
            );
        }

        // Pour les actions bulk, on boucle
        if ( in_array( $action_key, array( 'bulk_optimize_metas', 'fix_orphan_links' ), true ) ) {
            $post_ids = isset( $params['post_ids'] ) ? array_map( 'absint', (array) $params['post_ids'] ) : array();
            if ( empty( $post_ids ) ) {
                return new \WP_Error( 'no_targets', 'Aucun article cible.' );
            }
            $proposed = 0;
            $skipped  = 0;
            foreach ( $post_ids as $pid ) {
                if ( self::has_pending_action( $wf_type, $pid ) ) {
                    $skipped++;
                    continue;
                }
                $id = HTS_Workflow_Engine::propose(
                    'coach',
                    $wf_type,
                    $pid,
                    array_merge( $params, array( 'source' => 'coach_agent', 'session_id' => $session_id ) ),
                    'high'
                );
                if ( $id ) $proposed++;
            }
            return array(
                'status'   => 'proposed',
                'proposed' => $proposed,
                'skipped'  => $skipped,
                'message'  => $proposed . " action(s) propos\xc3\xa9e(s) dans l'Inbox" . ( $skipped ? " ({$skipped} d\xc3\xa9j\xc3\xa0 en attente)" : '' ) . '.',
            );
        }

        // Dédoublonnage single
        if ( $post_id > 0 && self::has_pending_action( $wf_type, $post_id ) ) {
            return array(
                'status'  => 'duplicate',
                'message' => "Cette action est d\xc3\xa9j\xc3\xa0 en attente dans l'Inbox. Rendez-vous dans l'Inbox pour la valider.",
            );
        }

        // Proposer dans l'Inbox
        $id = HTS_Workflow_Engine::propose(
            'coach',
            $wf_type,
            $post_id,
            array_merge( $params, array( 'source' => 'coach_agent', 'session_id' => $session_id ) ),
            'high'
        );

        if ( ! $id ) {
            return new \WP_Error( 'propose_failed', "Impossible de proposer cette action. V\xc3\xa9rifiez que l'agent Coach est activ\xc3\xa9 dans les r\xc3\xa9glages." );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                'Coach Agent : step "%s" → Inbox #%d (post_id=%d, session=%d)',
                $action_key, $id, $post_id, $session_id
            ), 'info', 'coach' );
        }

        return array(
            'status'    => 'proposed',
            'action_id' => $id,
            'message'   => "\xe2\x9c\x85 " . $cat['label'] . " propos\xc3\xa9 dans l'Inbox.",
            'inbox_url' => admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ),
        );
    }

    /* ═══════════════════════════════════════════════
     *  DISPATCH COACH ACTIONS → MODULES (v2.1)
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifie s'il existe déjà une action pending du même type sur le même post.
     * Évite les doublons quand le client repose la même question.
     *
     * @since 2.1.0
     * @param string $type     Type d'action.
     * @param int    $post_id  Post concerné.
     * @return bool  true = action pending existe déjà.
     */
    public static function has_pending_action( $type, $post_id ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return false;

        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return false;

        // Vérifier TOUS les agents — si l'agent meta a déjà proposé un add_meta_title
        // pour cette page, inutile que le Coach en crée un doublon.
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE type = %s AND post_id = %d AND status = 'pending' LIMIT 1",
            $type, $post_id
        ) );

        return ! empty( $exists );
    }

    /**
     * Sprint 4.2 fix7 — Reclassifie une action legacy `optimize_meta` en analysant
     * la question originale de l'utilisateur dans la session.
     *
     * Analyse les mots-clés pour déterminer si l'user voulait :
     * - UNIQUEMENT les descriptions → optimize_meta_desc
     * - UNIQUEMENT les titres → optimize_meta_title
     * - Les deux (ou indéterminé) → optimize_meta_both
     *
     * @since 4.0.0 Sprint 4.2 fix7
     * @param int $session_id  Session ID courante.
     * @return string|null     Clé d'action reclassifiée, ou null si pas de contexte.
     */
    private static function reclassify_meta_action( $session_id ) {
        if ( $session_id <= 0 ) return null;
        if ( ! self::messages_table_exists() ) return null;

        global $wpdb;
        $table = $wpdb->prefix . self::MESSAGES_TABLE;

        // Récupérer le dernier message utilisateur de la session
        $user_msg = $wpdb->get_var( $wpdb->prepare(
            "SELECT content FROM {$table}
             WHERE session_id = %d AND role = 'user'
             ORDER BY id DESC LIMIT 1",
            $session_id
        ) );

        if ( empty( $user_msg ) ) return null;

        $q = mb_strtolower( trim( $user_msg ) );

        // Patterns pour "description" seule
        $desc_patterns = array(
            'description',
            'meta desc',
            'meta-desc',
            'meta_desc',
            'descriptions',
        );
        // Patterns pour "titre" seul
        $title_patterns = array(
            'titre',
            'titres',
            'title',
            'titles',
            'meta title',
            'meta-title',
            'meta_title',
        );

        $has_desc  = false;
        $has_title = false;

        foreach ( $desc_patterns as $p ) {
            if ( mb_strpos( $q, $p ) !== false ) { $has_desc = true; break; }
        }
        foreach ( $title_patterns as $p ) {
            if ( mb_strpos( $q, $p ) !== false ) { $has_title = true; break; }
        }

        // Si les deux sont mentionnés ou aucun → both
        if ( ( $has_desc && $has_title ) || ( ! $has_desc && ! $has_title ) ) {
            return 'optimize_meta_both';
        }

        // Un seul mentionné
        if ( $has_desc ) return 'optimize_meta_desc';
        if ( $has_title ) return 'optimize_meta_title';

        return 'optimize_meta_both';
    }

    /**
     * Dispatch une action Coach approuvée vers le bon module.
     * Hookée sur le filtre `hts_workflow_dispatch`.
     *
     * @since 2.1.0
     * @param bool|null $result   null = pas géré.
     * @param string    $agent    Agent name.
     * @param string    $type     Action type.
     * @param int       $post_id  Post ID.
     * @param array     $data     Action data.
     * @return bool|null
     */
    public function dispatch_coach_action( $result, $agent, $type, $post_id, $data ) {
        // Ne gérer que les actions de l'agent "coach"
        if ( $agent !== 'coach' ) {
            return $result;
        }

        // Valider le type
        if ( ! in_array( $type, self::COACH_ACTION_TYPES, true ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach dispatch : type inconnu '{$type}'", 'warn', 'coach' );
            }
            return false;
        }

        $success = false;

        // Sprint 5.2: Priorité au catalog pour les types qui y sont définis.
        // Les méthodes *_from_coach() sont plus riches que les legacy execute_*().
        if ( isset( self::AGENT_ACTION_CATALOG[ $type ] ) ) {
            $catalog_result = self::dispatch_catalog_action( $type, $post_id, $data );
            // Sprint 5.3: catalog can return array {success, log} for rich feedback
            if ( is_array( $catalog_result ) ) {
                $success = $catalog_result; // propagate to Workflow Engine execute()
            } else {
                $success = (bool) $catalog_result;
            }
        } else {
            // Types legacy sans entrée catalog
            switch ( $type ) {

                case 'add_meta_title':
                case 'add_meta_desc':
                    $success = self::execute_meta_generation( $type, $post_id );
                    break;

                case 'delete_page':
                    $success = self::execute_delete_page( $post_id, $data );
                    break;

                case 'coach_suggestion':
                    // Suggestions are informational — no execution needed, always "success"
                    $success = true;
                    break;

                default:
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( "Coach dispatch : type '{$type}' sans handler (ni catalog ni legacy)", 'warn', 'coach' );
                    }
                    break;
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            if ( is_array( $success ) ) {
                $log_msg = $success['log'] ?? 'OK (rich return)';
                $status  = ! empty( $success['success'] ) ? 'success' : 'warning';
            } else {
                $log_msg = $success ? 'OK' : 'échec';
                $status  = $success ? 'success' : 'warning';
            }
            hts_add_log( "Coach dispatch : {$type} sur post #{$post_id} → {$log_msg}", $status, 'coach' );
        }

        return $success;
    }

    /**
     * Exécute add_meta_title ou add_meta_desc.
     * Appelle Meta Score pour générer des variantes, puis applique la meilleure.
     *
     * @since 2.1.0
     */
    private static function execute_meta_generation( $type, $post_id ) {
        if ( ! class_exists( 'HTS_Meta_Score' ) ) return false;
        if ( ! get_post( $post_id ) ) return false;

        $meta_score = new HTS_Meta_Score();
        if ( ! method_exists( $meta_score, 'generate_variants' ) ) return false;

        $result = $meta_score->generate_variants( $post_id );

        // Si erreur (pas de clé API, rate limit, etc.)
        if ( isset( $result['error'] ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach meta gen : {$result['error']}", 'warn', 'coach' );
            }
            return false;
        }

        // Appliquer la première variante (meilleur score CTR)
        if ( ! empty( $result['variants'] ) ) {
            $best = $result['variants'][0];

            if ( $type === 'add_meta_title' && ! empty( $best['title'] ) ) {
                update_post_meta( $post_id, '_hts_meta_title', sanitize_text_field( $best['title'] ) );
                return true;
            }

            if ( $type === 'add_meta_desc' && ! empty( $best['description'] ) ) {
                update_post_meta( $post_id, '_hts_meta_description', sanitize_textarea_field( $best['description'] ) );
                return true;
            }
        }

        return false;
    }

    /**
     * @deprecated Sprint 5.3 — Remplacé par HTS_Content_Refresh::add_faq_from_coach()
     * via le catalog dispatch. Conservé temporairement pour référence.
     * @see AGENT_ACTION_CATALOG['add_faq']
     */
    private static function execute_add_faq( $post_id, $data ) {
        if ( ! get_post( $post_id ) ) return false;

        // Marquer l'article comme "nécessite FAQ"
        update_post_meta( $post_id, '_hts_needs_faq', 1 );
        update_post_meta( $post_id, '_hts_faq_reason', sanitize_text_field( $data['reason'] ?? 'Recommandé par le Coach SEO' ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach : article #{$post_id} marqué pour ajout FAQ", 'info', 'coach' );
        }

        return true;
    }

    /**
     * Exécute add_internal_links : lance l'analyse de maillage sur l'article.
     *
     * @since 2.1.0
     */
    private static function execute_add_internal_links( $post_id ) {
        if ( ! class_exists( 'HTS_Internal_Linking' ) ) return false;
        if ( ! get_post( $post_id ) ) return false;

        $linker = new HTS_Internal_Linking();
        if ( method_exists( $linker, 'analyze_post' ) ) {
            $linker->analyze_post( $post_id );
            return true;
        }

        return false;
    }

    /**
     * Exécute content_refresh : envoie la demande de réécriture à l'API HTS.
     *
     * @since 2.1.0
     */
    private static function execute_content_refresh( $post_id ) {
        if ( ! class_exists( 'HTS_Content_Refresh' ) ) return false;
        if ( ! get_post( $post_id ) ) return false;

        $refresher = new HTS_Content_Refresh();
        if ( method_exists( $refresher, 'request_rewrite' ) ) {
            $result = $refresher->request_rewrite( $post_id );
            return ! isset( $result['error'] );
        }

        return false;
    }

    /**
     * Exécute geo_optimize : recalcule le GEO Score et stocke les gaps.
     *
     * @since 2.1.0
     */
    private static function execute_geo_optimize( $post_id ) {
        if ( ! class_exists( 'HTS_Geo_Score' ) ) return false;
        if ( ! get_post( $post_id ) ) return false;

        $geo = new HTS_Geo_Score();
        if ( method_exists( $geo, 'calculate' ) ) {
            $result = $geo->calculate( $post_id, true ); // force recalcul
            return ! empty( $result );
        }

        return false;
    }

    /**
     * Exécute delete_page : met en CORBEILLE (jamais de suppression directe).
     * Enregistre un log d'audit pour traçabilité.
     *
     * @since 2.1.0
     */
    private static function execute_delete_page( $post_id, $data ) {
        $post = get_post( $post_id );
        if ( ! $post ) return false;

        // Sauvegarder le titre et la raison avant la mise en corbeille
        $reason = sanitize_text_field( $data['reason'] ?? 'Recommandé par le Coach SEO' );

        // Log audit trail avant suppression
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( 'Coach : article "%s" (#%d) → corbeille. Raison : %s', $post->post_title, $post_id, $reason ),
                'warning',
                'coach'
            );
        }

        // Audit trail structuré si disponible
        if ( class_exists( 'HTS_Audit_Trail' ) && method_exists( 'HTS_Audit_Trail', 'log' ) ) {
            HTS_Audit_Trail::log( 'coach_delete', $post_id, array(
                'title'  => $post->post_title,
                'reason' => $reason,
            ) );
        }

        // Corbeille — JAMAIS wp_delete_post
        $result = wp_trash_post( $post_id );
        return ! empty( $result );
    }

    /* ═══════════════════════════════════════════════
     *  API KEY — Sécurité
     * ═══════════════════════════════════════════════ */

    /**
     * Sprint 5.0: Dispatch actions defined in AGENT_ACTION_CATALOG to their target modules.
     *
     * @since 5.0
     * @param string $type    Action type (key in AGENT_ACTION_CATALOG).
     * @param int    $post_id WordPress post ID.
     * @param array  $data    Extra action data (reason, params, etc.).
     * @return bool
     */
    private static function dispatch_catalog_action( $type, $post_id, $data ) {
        if ( ! isset( self::AGENT_ACTION_CATALOG[ $type ] ) ) {
            return false;
        }

        $catalog = self::AGENT_ACTION_CATALOG[ $type ];
        $module  = $catalog['module'] ?? '';
        $method  = $catalog['method'] ?? '';

        if ( empty( $module ) || empty( $method ) || ! class_exists( $module ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach catalog dispatch : module {$module} non disponible pour {$type}", 'warn', 'coach' );
            }
            return false;
        }

        if ( ! method_exists( $module, $method ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach catalog dispatch : méthode {$module}::{$method} introuvable pour {$type}", 'warn', 'coach' );
            }
            return false;
        }

        // Build params from catalog definition + action data
        $params = array();
        // Sprint 5.2: Toujours passer le type d'action pour que les méthodes
        // mutualisées (ex: optimize_from_coach) sachent quel type les a appelées.
        $params['_action_type'] = $type;
        foreach ( $catalog['params'] as $p ) {
            if ( $p === 'post_id' ) {
                $params[ $p ] = $post_id;
            } elseif ( $p === 'post_ids' ) {
                $params[ $p ] = isset( $data['post_ids'] ) ? array_map( 'intval', (array) $data['post_ids'] ) : array( $post_id );
            } else {
                $params[ $p ] = $data[ $p ] ?? null;
            }
        }

        try {
            $result = call_user_func( array( $module, $method ), $params );
            // Sprint 5.3: Handle rich returns (skipped, array with success key)
            if ( is_array( $result ) ) {
                if ( ! empty( $result['skipped'] ) ) {
                    // Action was skipped (e.g. FAQ already exists) — still "success" but with explanation
                    return array( 'success' => true, 'log' => $result['reason'] ?? 'Action ignorée (déjà appliquée)' );
                }
                return ! empty( $result['success'] );
            }
            return ! empty( $result ) && ! is_wp_error( $result );
        } catch ( \Throwable $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach catalog dispatch exception ({$type}) : " . $e->getMessage(), 'error', 'coach' );
            }
            return false;
        }
    }

    /**
     * Récupère la clé API Anthropic.
     * JAMAIS exposée dans le system prompt ni dans les logs.
     */
    public static function get_api_key() {
        // Priorité : constante PHP > option DB
        if ( defined( 'HTS_ANTHROPIC_API_KEY' ) && HTS_ANTHROPIC_API_KEY ) {
            return HTS_ANTHROPIC_API_KEY;
        }
        return get_option( self::OPT_API_KEY, '' );
    }

    /**
     * Masque la clé pour l'affichage UI.
     */
    public static function mask_api_key( $key ) {
        if ( strlen( $key ) < 12 ) return '••••••••';
        return substr( $key, 0, 8 ) . '••••••••' . substr( $key, -4 );
    }

    /* ═══════════════════════════════════════════════
     *  AJAX HANDLERS
     * ═══════════════════════════════════════════════ */

    /**
     * Batch: Coach plan init.
     */
    public function ajax_coach_plan_init() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $session_id = absint( $_POST['session_id'] ?? 0 );
        $plan_json  = isset( $_POST['plan'] ) ? wp_unslash( $_POST['plan'] ) : '';
        $plan       = is_string( $plan_json ) ? json_decode( $plan_json, true ) : (array) $plan_json;
        $steps      = $plan['steps'] ?? array();

        if ( empty( $steps ) ) wp_send_json_error( array( 'message' => 'Plan vide' ) );

        $job = HTS_Job_Runner::create( 'coach_plan', array(
            'session_id' => $session_id,
            'plan'       => $plan,
        ), count( $steps ) );

        wp_send_json_success( array( 'job_id' => $job['job_id'], 'total' => count( $steps ) ) );
    }

    /**
     * Batch: Coach plan step — execute 1 step per call.
     */
    public function ajax_coach_plan_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        $job = HTS_Job_Runner::load( $job_id );
        if ( ! $job ) wp_send_json_error( array( 'message' => 'Job introuvable ou expiré' ) );

        $plan      = $job['params']['plan'] ?? array();
        $steps     = $plan['steps'] ?? array();
        $processed = (int) $job['processed'];
        $results   = $job['result']['step_results'] ?? array();

        if ( $processed < count( $steps ) ) {
            $step       = $steps[ $processed ];
            $action_key = sanitize_key( $step['action'] ?? '' );
            $params     = is_array( $step['params'] ?? null ) ? $step['params'] : array();

            if ( ( $step['status'] ?? '' ) !== 'ready' ) {
                $results[] = array( 'step' => $processed + 1, 'status' => 'skipped' );
            } else {
                try {
                    $r = $this->dispatch_plan_action( $action_key, $params, $job['params']['session_id'] ?? 0 );
                    $results[] = array( 'step' => $processed + 1, 'status' => 'done', 'result' => $r );
                } catch ( \Throwable $e ) {
                    $results[] = array( 'step' => $processed + 1, 'status' => 'error', 'error' => $e->getMessage() );
                }
            }
            $processed++;
        }

        $done = ( $processed >= count( $steps ) );
        $upd = array( 'processed' => $processed, 'step' => $job['step'] + 1, 'result' => array( 'step_results' => $results ) );
        if ( $done ) { $upd['status'] = 'done'; }
        HTS_Job_Runner::update( $job_id, $upd );

        wp_send_json_success( array(
            'status'    => $done ? 'done' : 'running',
            'step'      => $processed,
            'total'     => count( $steps ),
            'processed' => $processed,
            'progress'  => count( $steps ) > 0 ? round( $processed / count( $steps ) * 100 ) : 100,
            'message'   => $done ? 'Plan exécuté !' : 'Étape ' . $processed . '/' . count( $steps ) . '...',
            'result'    => $done ? array( 'step_results' => $results ) : null,
        ) );
    }

    /**
     * Dispatch a single plan action (used by both legacy and batch).
     */
    private function dispatch_plan_action( $action_key, $params, $session_id ) {
        // Delegate to the existing plan execution logic
        // This wraps the core of the foreach loop in ajax_execute_plan
        $post_id = (int) ( $params['post_id'] ?? $params['id'] ?? 0 );
        if ( ! $post_id ) return array( 'status' => 'error', 'message' => 'post_id manquant' );

        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            return HTS_Workflow_Engine::propose_action( $action_key, $post_id, $params, 'coach', $session_id );
        }
        return array( 'status' => 'error', 'message' => 'Workflow Engine non disponible' );
    }

    /**
     * AJAX : question au Coach.
     */
    public function ajax_ask() {
        // ── Capturer toute erreur PHP pour ne jamais retourner du HTML ──
        ob_start();

        try {
            check_ajax_referer( 'hts_admin_nonce', 'nonce' );

            if ( ! current_user_can( 'manage_options' ) ) {
                ob_end_clean();
                wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
            }

            $question = sanitize_textarea_field( wp_unslash( $_POST['question'] ?? '' ) );
            if ( empty( $question ) || mb_strlen( $question ) < 3 ) {
                ob_end_clean();
                wp_send_json_error( array( 'message' => 'Posez une question (minimum 3 caractères).' ) );
            }

            // Limiter la longueur
            $question = mb_substr( $question, 0, 2000 );

            $post_id = absint( $_POST['post_id'] ?? 0 );
            $user_id = get_current_user_id();
            $forced_session_id = absint( $_POST['session_id'] ?? 0 );

            $result = $this->ask( $question, $post_id, $user_id, $forced_session_id );

            // Capturer d'éventuels warnings/notices PHP
            $php_output = ob_get_clean();

            if ( is_wp_error( $result ) ) {
                wp_send_json_error( array(
                    'message'    => $result->get_error_message(),
                    'code'       => $result->get_error_code(),
                    'php_output' => ! empty( $php_output ) ? substr( $php_output, 0, 500 ) : '',
                ) );
            }

            wp_send_json_success( array(
                'text'             => self::clean_response( $result['text'] ),
                'raw'              => $result['text'],
                'chart'            => self::extract_chart( $result['text'] ),
                'plan'             => $result['plan'] ?? null,
                'seo_plan'         => $result['seo_plan'] ?? null,
                'report'           => $result['report'] ?? null,
                'tokens_in'        => $result['tokens_in'],
                'tokens_out'       => $result['tokens_out'],
                'actions'          => $result['actions'],
                'skipped_actions'  => $result['skipped_actions'] ?? array(),
                'usage'            => self::get_usage(),
                'mode'             => $result['mode'] ?? ( self::is_freemium_mode() ? 'freemium' : 'pro' ),
                'provider'         => $result['provider'] ?? 'anthropic',
                'model'            => $result['model'] ?? '',
                'freemium'         => self::get_freemium_usage(),
                'session_id'       => $result['session_id'] ?? 0,
                'memory_facts'     => $result['memory_facts'] ?? array(),
            ) );

        } catch ( \Throwable $e ) {
            ob_end_clean();
            wp_send_json_error( array(
                'message' => 'Erreur interne du Coach : ' . $e->getMessage(),
                'code'    => 'php_error',
                'file'    => basename( $e->getFile() ) . ':' . $e->getLine(),
            ) );
        }
    }

    /**
     * AJAX : question au Coach — mode streaming SSE.
     *
     * Envoie les chunks texte mot par mot via Server-Sent Events,
     * puis un event "done" avec les métadonnées finales.
     *
     * Format SSE :
     *   event: chunk\ndata: {"text":"..."}\n\n
     *   event: done\ndata: {"text":"...","chart":{...},"actions":[...],...}\n\n
     *   event: error\ndata: {"message":"..."}\n\n
     *
     * @since 4.0 Sprint 2.2
     */
    public function ajax_ask_stream() {
        // ── Vérifications standard ──
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            header( 'Content-Type: text/event-stream; charset=UTF-8' );
            header( 'Cache-Control: no-cache' );
            echo "event: error\ndata: " . wp_json_encode( array( 'message' => 'Accès refusé.' ) ) . "\n\n";
            exit;
        }

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 120 );
        }

        $question = sanitize_textarea_field( wp_unslash( $_POST['question'] ?? '' ) );
        if ( empty( $question ) || mb_strlen( $question ) < 3 ) {
            header( 'Content-Type: text/event-stream; charset=UTF-8' );
            header( 'Cache-Control: no-cache' );
            echo "event: error\ndata: " . wp_json_encode( array( 'message' => 'Posez une question (minimum 3 caractères).' ) ) . "\n\n";
            exit;
        }

        $question = mb_substr( $question, 0, 2000 );
        $post_id  = absint( $_POST['post_id'] ?? 0 );
        $user_id  = get_current_user_id();

        // ── Configuration SSE ──
        // Désactiver le output buffering PHP/serveur
        while ( ob_get_level() ) {
            ob_end_clean();
        }

        header( 'Content-Type: text/event-stream; charset=UTF-8' );
        header( 'Cache-Control: no-cache' );
        header( 'Connection: keep-alive' );
        header( 'X-Accel-Buffering: no' ); // Nginx

        // Désactiver les limites serveur pour le streaming
        if ( function_exists( 'apache_setenv' ) ) {
            @apache_setenv( 'no-gzip', '1' );
        }
        @ini_set( 'zlib.output_compression', '0' );
        @ini_set( 'implicit_flush', '1' );

        // ── Callback SSE : envoie chaque chunk ──
        $chunk_count = 0;
        $on_chunk = function( $text_delta ) use ( &$chunk_count ) {
            $chunk_count++;
            echo "event: chunk\ndata: " . wp_json_encode( array( 'text' => $text_delta ) ) . "\n\n";
            if ( ob_get_level() ) {
                ob_flush();
            }
            flush();
        };

        // ── Appel streaming ──
        // v4.0 fix : Le JS envoie le session_id pour éviter les désynchronisations
        $forced_session_id = absint( $_POST['session_id'] ?? 0 );
        try {
            $result = $this->ask_stream( $question, $post_id, $user_id, $on_chunk, $forced_session_id );

            if ( is_wp_error( $result ) ) {
                echo "event: error\ndata: " . wp_json_encode( array(
                    'message' => $result->get_error_message(),
                    'code'    => $result->get_error_code(),
                ) ) . "\n\n";
                flush();
                exit;
            }

            // ── Event "done" avec toutes les métadonnées ──
            $clean_text = self::clean_response( $result['text'] );
            $raw_text   = $result['text'];

            // Sprint 5.4b: Safety — if text is empty, show debug info
            if ( empty( trim( $clean_text ) ) && empty( trim( $raw_text ) ) ) {
                $clean_text = "L'analyse n'a pas produit de réponse visible. Vérifiez les logs Coach pour le diagnostic.\n\n"
                    . 'Intent: ' . ( $result['intent'] ?? 'unknown' )
                    . ' | Model: ' . ( $result['model'] ?? 'unknown' )
                    . ' | Tokens: ' . ( $result['tokens_in'] ?? 0 ) . ' in / ' . ( $result['tokens_out'] ?? 0 ) . ' out';
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Coach done event with EMPTY text! Result keys: ' . implode( ',', array_keys( $result ) ), 'error', 'coach' );
                }
            }

            echo "event: done\ndata: " . wp_json_encode( array(
                'text'         => $clean_text,
                'raw'          => $raw_text,
                'chart'        => $result['chart'] ?? self::extract_chart( $result['text'] ),
                'tokens_in'    => $result['tokens_in'],
                'tokens_out'   => $result['tokens_out'],
                'actions'          => $result['actions'],
                'skipped_actions'  => $result['skipped_actions'] ?? array(),
                'plan'         => $result['plan'] ?? null,
                'seo_plan'     => $result['seo_plan'] ?? null,
                'report'       => $result['report'] ?? null,
                'usage'        => self::get_usage(),
                'mode'         => $result['mode'] ?? 'pro',
                'provider'     => $result['provider'] ?? 'anthropic',
                'model'        => $result['model'] ?? '',
                'freemium'     => self::get_freemium_usage(),
                'session_id'   => $result['session_id'] ?? 0,
                'memory_facts' => $result['memory_facts'] ?? array(),
                'chunks'       => $chunk_count,
            ) ) . "\n\n";
            flush();

        } catch ( \Throwable $e ) {
            echo "event: error\ndata: " . wp_json_encode( array(
                'message' => 'Erreur interne du Coach : ' . $e->getMessage(),
                'code'    => 'php_error',
            ) ) . "\n\n";
            flush();
        }

        exit;
    }

    /**
     * AJAX : diagnostic rapide du Coach (pas besoin d'API).
     * Retourne l'état de la config sans appeler d'IA.
     *
     * @since 2.5.0
     */
    public function ajax_ping() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        $anthropic_key = self::get_api_key();
        $openai_key    = self::get_openai_api_key();

        // Tester l'intent routing
        $test_intent = self::detect_intent( 'test question globale' );
        $test_model  = self::get_model( $test_intent );

        wp_send_json_success( array(
            'status'           => 'ok',
            'php_version'      => PHP_VERSION,
            'has_anthropic_key'=> ! empty( $anthropic_key ),
            'has_openai_key'   => ! empty( $openai_key ),
            'model_setting'    => class_exists( 'HTS_Workflow_Engine' )
                ? ( HTS_Workflow_Engine::get_agent_settings_with_defaults( 'coach' )['model'] ?? 'unknown' )
                : 'no_wf',
            'test_intent'      => $test_intent,
            'test_model'       => $test_model,
            'test_provider'    => self::get_provider( $test_model ),
            'memory_tables'    => self::check_memory_tables(),
            'budget'           => self::get_monthly_budget(),
            'usage'            => self::get_usage(),
        ) );
    }

    /**
     * Vérifie si les tables mémoire existent.
     * @since 2.5.0
     */
    public static function check_memory_tables() {
        global $wpdb;
        $sessions  = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::SESSIONS_TABLE ) );
        $memory    = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::MEMORY_TABLE ) );
        $messages  = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::MESSAGES_TABLE ) );
        $artifacts = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::ARTIFACTS_TABLE ) );
        return array(
            'sessions'  => ! empty( $sessions ),
            'memory'    => ! empty( $memory ),
            'messages'  => ! empty( $messages ),
            'artifacts' => ! empty( $artifacts ),
        );
    }

    /**
     * AJAX : config du Coach (clé API, budget).
     */
    public function ajax_config() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        // GET : renvoyer la config actuelle
        if ( empty( $_POST['save'] ) ) {
            $key = self::get_api_key();
            $oai_key = self::get_openai_api_key();
            wp_send_json_success( array(
                'has_key'         => ! empty( $key ),
                'key_masked'      => $key ? self::mask_api_key( $key ) : '',
                'key_source'      => defined( 'HTS_ANTHROPIC_API_KEY' ) ? 'constant' : 'database',
                'has_openai_key'  => ! empty( $oai_key ),
                'openai_masked'   => $oai_key ? self::mask_api_key( $oai_key ) : '',
                'openai_source'   => defined( 'HTS_OPENAI_API_KEY' ) ? 'constant' : 'database',
                'budget'          => self::get_monthly_budget(),
                'usage'           => self::get_usage(),
                'mode'            => self::is_freemium_mode() ? 'freemium' : 'pro',
                'freemium'        => self::get_freemium_usage(),
            ) );
        }

        // POST : sauvegarder
        if ( isset( $_POST['api_key'] ) ) {
            $new_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ) );
            if ( defined( 'HTS_ANTHROPIC_API_KEY' ) ) {
                wp_send_json_error( array( 'message' => 'La clé API Anthropic est définie dans wp-config.php et ne peut pas être modifiée ici.' ) );
            }
            update_option( self::OPT_API_KEY, $new_key, false );
        }

        if ( isset( $_POST['openai_api_key'] ) ) {
            $new_oai = sanitize_text_field( wp_unslash( $_POST['openai_api_key'] ) );
            if ( defined( 'HTS_OPENAI_API_KEY' ) ) {
                wp_send_json_error( array( 'message' => 'La clé API OpenAI est définie dans wp-config.php et ne peut pas être modifiée ici.' ) );
            }
            update_option( self::OPT_OPENAI_API_KEY, $new_oai, false );
        }

        if ( isset( $_POST['budget'] ) ) {
            $budget = absint( $_POST['budget'] );
            $budget = min( max( $budget, 1000 ), self::HARD_LIMIT_TOKENS );
            update_option( self::OPT_BUDGET, $budget, false );
        }

        if ( isset( $_POST['pricing'] ) ) {
            $pricing = sanitize_textarea_field( wp_unslash( $_POST['pricing'] ) );
            update_option( 'hts_coach_pricing', $pricing, false );
        }

        wp_send_json_success( array( 'saved' => true ) );
    }

    /**
     * AJAX : historique.
     */
    public function ajax_history() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        $user_id = get_current_user_id();

        // ── v4.0 Sprint 1.3 : Enrichir l'historique avec chart_json pour re-render ──
        if ( self::messages_table_exists() ) {
            $history = self::get_history_with_charts( $user_id );
            wp_send_json_success( array( 'history' => $history ) );
            return;
        }

        $history = self::get_history( $user_id );
        wp_send_json_success( array( 'history' => $history ) );
    }

    /**
     * v4.0 Sprint 1.3 : Récupère l'historique avec chart_json inclus pour re-render côté JS.
     */
    private static function get_history_with_charts( $user_id ) {
        global $wpdb;
        $table   = $wpdb->prefix . self::MESSAGES_TABLE;
        $session = self::get_or_create_session( $user_id );
        $session_id = $session['id'] ?? 0;

        if ( ! $session_id ) return array();

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT role, content, chart_json FROM {$table}
             WHERE session_id = %d AND user_id = %d
             ORDER BY created_at ASC
             LIMIT %d",
            $session_id, absint( $user_id ), self::MAX_HISTORY_TURNS * 2
        ), ARRAY_A );

        if ( empty( $rows ) ) return array();

        // Reconstruire en paires q/a avec chart
        $history = array();
        $current = array();
        foreach ( $rows as $row ) {
            if ( $row['role'] === 'user' ) {
                $current = array( 'q' => $row['content'] );
            } elseif ( $row['role'] === 'assistant' && ! empty( $current ) ) {
                $current['a']  = $row['content'];
                $current['ts'] = 0;
                // Sprint 1.3 : inclure le chart pour re-render
                if ( ! empty( $row['chart_json'] ) ) {
                    $chart = json_decode( $row['chart_json'], true );
                    if ( is_array( $chart ) ) {
                        $current['chart'] = $chart;
                    }
                }
                $history[] = $current;
                $current   = array();
            }
        }

        return array_slice( $history, -self::MAX_HISTORY_TURNS );
    }

    /**
     * AJAX : effacer l'historique.
     */
    public function ajax_clear_history() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        self::clear_history( get_current_user_id() );
        wp_send_json_success( array( 'cleared' => true ) );
    }

    /**
     * v4.0 AJAX : Charger tous les messages d'une session passée.
     * Permet de naviguer entre sessions dans l'UI.
     */
    public function ajax_session_messages() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        $session_id = absint( $_POST['session_id'] ?? 0 );
        if ( ! $session_id ) {
            wp_send_json_error( array( 'message' => 'Session manquante.' ) );
        }

        if ( ! self::messages_table_exists() ) {
            wp_send_json_error( array( 'message' => 'Table messages non initialisée.' ) );
        }

        global $wpdb;
        $table   = $wpdb->prefix . self::MESSAGES_TABLE;
        $user_id = get_current_user_id();

        // Détecter les colonnes disponibles
        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );
        $has_actions_col = in_array( 'actions_json', $columns, true );
        $has_chart_col   = in_array( 'chart_json', $columns, true );

        $select_cols = 'id, role, content, intent, model, provider, tokens_in, tokens_out, created_at';
        if ( $has_chart_col )   $select_cols .= ', chart_json';
        if ( $has_actions_col ) $select_cols .= ', actions_json';

        // Charger tous les messages de cette session pour cet user
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT {$select_cols}
             FROM {$table}
             WHERE session_id = %d AND user_id = %d
             ORDER BY created_at ASC
             LIMIT 200",
            $session_id, $user_id
        ), ARRAY_A );

        // Récupérer aussi les infos de la session
        $sessions_table = $wpdb->prefix . self::SESSIONS_TABLE;
        $session_info = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, session_start, session_end, messages_count, topics, summary_text
             FROM {$sessions_table}
             WHERE id = %d AND user_id = %d",
            $session_id, $user_id
        ), ARRAY_A );

        // Décoder topics JSON
        if ( $session_info && ! empty( $session_info['topics'] ) ) {
            $decoded = json_decode( $session_info['topics'], true );
            $session_info['topics'] = is_array( $decoded ) ? $decoded : array( $session_info['topics'] );
        }

        // Décoder chart_json et actions_json dans les messages
        foreach ( $rows as &$row ) {
            // Sprint 4.2 : nettoyer les blocs JSON (plan, actions, chart) du contenu affiché
            if ( $row['role'] === 'assistant' ) {
                $row['content'] = self::clean_response( $row['content'] );
            }

            if ( $has_chart_col && ! empty( $row['chart_json'] ) ) {
                $row['chart'] = json_decode( $row['chart_json'], true );
            } else {
                $row['chart'] = null;
            }
            unset( $row['chart_json'] );

            // v4.0 Sprint 4.1 fix : plan data pour re-render des cartes Agent Mode
            // Sprint 5.3 fix AMÉL-2 : unwrap format { plan: {...}, actions: [...], skipped: [...] }
            if ( $has_actions_col && ! empty( $row['actions_json'] ) ) {
                $decoded = json_decode( $row['actions_json'], true );
                if ( is_array( $decoded ) ) {
                    // Format Sprint 5.3 : wrapped { plan, actions, skipped }
                    if ( isset( $decoded['plan'] ) || isset( $decoded['actions'] ) || isset( $decoded['skipped'] ) ) {
                        $row['plan']    = ! empty( $decoded['plan'] ) ? $decoded['plan'] : null;
                        $row['actions'] = ! empty( $decoded['actions'] ) ? $decoded['actions'] : null;
                        $row['skipped'] = ! empty( $decoded['skipped'] ) ? $decoded['skipped'] : null;
                    }
                    // Format ancien : raw plan { goal, steps }
                    elseif ( isset( $decoded['steps'] ) ) {
                        $row['plan']    = $decoded;
                        $row['actions'] = null;
                        $row['skipped'] = null;
                    } else {
                        $row['plan']    = null;
                        $row['actions'] = null;
                        $row['skipped'] = null;
                    }
                } else {
                    $row['plan']    = null;
                    $row['actions'] = null;
                    $row['skipped'] = null;
                }
            } else {
                $row['plan']    = null;
                $row['actions'] = null;
                $row['skipped'] = null;
            }
            unset( $row['actions_json'] );
        }
        unset( $row );

        // Sprint 5.3: Enrich action cards with live status from Workflow Engine
        // This prevents showing "Appliquer" buttons on already-done/rejected actions after F5
        $all_action_ids = array();
        foreach ( $rows as $row ) {
            if ( ! empty( $row['actions'] ) && is_array( $row['actions'] ) ) {
                foreach ( $row['actions'] as $act ) {
                    if ( ! empty( $act['action_id'] ) ) {
                        $all_action_ids[] = (int) $act['action_id'];
                    }
                }
            }
        }
        if ( ! empty( $all_action_ids ) && class_exists( 'HTS_Workflow_Engine' ) ) {
            $we_table = $wpdb->prefix . 'hts_workflow_actions';
            $ids_in   = implode( ',', array_map( 'intval', array_unique( $all_action_ids ) ) );
            $statuses = $wpdb->get_results(
                "SELECT id, status FROM {$we_table} WHERE id IN ({$ids_in})",
                OBJECT_K
            );
            foreach ( $rows as &$row ) {
                if ( ! empty( $row['actions'] ) && is_array( $row['actions'] ) ) {
                    foreach ( $row['actions'] as &$act ) {
                        $aid = (int) ( $act['action_id'] ?? 0 );
                        if ( $aid && isset( $statuses[ $aid ] ) ) {
                            $act['live_status'] = $statuses[ $aid ]->status;
                        }
                    }
                    unset( $act );
                }
            }
            unset( $row );
        }

        wp_send_json_success( array(
            'messages' => $rows,
            'session'  => $session_info,
        ) );
    }

    /**
     * v4.0 AJAX : Démarrer une nouvelle session (ferme l'actuelle).
     * Bouton "Nouvelle conversation" dans l'UI.
     */
    public function ajax_new_session() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        $user_id = get_current_user_id();

        if ( ! self::memory_tables_exist() ) {
            wp_send_json_error( array( 'message' => 'Tables non initialisées.' ) );
        }

        global $wpdb;
        $sessions_table = $wpdb->prefix . self::SESSIONS_TABLE;

        // Fermer la session active (mettre session_end)
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$sessions_table}
             SET session_end = %s, summary_status = 'pending'
             WHERE user_id = %d AND session_end IS NULL",
            current_time( 'mysql' ), $user_id
        ) );

        // Créer une nouvelle session
        $wpdb->insert( $sessions_table, array(
            'user_id'       => $user_id,
            'session_start' => current_time( 'mysql' ),
            'messages_count' => 0,
            'created_at'    => current_time( 'mysql' ),
        ), array( '%d', '%s', '%d', '%s' ) );

        $new_id = $wpdb->insert_id;

        wp_send_json_success( array(
            'session_id' => $new_id,
            'message'    => 'Nouvelle conversation démarrée.',
        ) );
    }

    /**
     * AJAX : contexte du site (pour le sidebar).
     */
    public function ajax_context() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        wp_send_json_success( array(
            'context'  => self::build_context(),
            'usage'    => self::get_usage(),
            'budget'   => self::get_monthly_budget(),
            'has_key'  => ! empty( self::get_api_key() ),
            'mode'     => self::is_freemium_mode() ? 'freemium' : 'pro',
            'freemium' => self::get_freemium_usage(),
        ) );
    }

    /**
     * AJAX : upload CSV Search Console.
     * Stocke dans hts_gsc_queries ou hts_gsc_pages (même format que le Full).
     */
    public function ajax_upload_gsc() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        if ( empty( $_FILES['gsc_file'] ) ) {
            wp_send_json_error( array( 'message' => 'Aucun fichier envoyé.' ) );
        }

        $file = $_FILES['gsc_file'];

        // Vérifier extension
        $ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        if ( ! in_array( $ext, array( 'csv', 'tsv' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Format accepté : CSV ou TSV uniquement.' ) );
        }

        // Vérifier taille (max 5MB)
        if ( $file['size'] > 5 * 1024 * 1024 ) {
            wp_send_json_error( array( 'message' => 'Fichier trop volumineux (max 5 Mo).' ) );
        }

        $result = self::parse_gsc_csv( $file['tmp_name'] );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        $csv_type = $result['type']; // 'queries' ou 'pages'
        $data     = $result['data'];

        // Stocker dans les mêmes options que le Full
        if ( $csv_type === 'queries' ) {
            update_option( 'hts_gsc_queries', $data, false );
        } else {
            update_option( 'hts_gsc_pages', $data, false );
            // Matcher les URLs aux posts WordPress
            self::match_pages_to_posts( $data );
        }

        // Meta import
        update_option( 'hts_gsc_import_meta', array(
            'type'     => $csv_type,
            'date'     => current_time( 'mysql' ),
            'rows'     => count( $data ),
            'filename' => sanitize_file_name( $file['name'] ),
        ), false );

        // Invalider le cache contexte
        delete_transient( 'hts_coach_ctx' );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Coach SEO : CSV GSC importé — ' . count( $data ) . ' ' . $csv_type . ' depuis ' . $file['name'], 'success', 'coach' );
        }

        wp_send_json_success( array(
            'rows'    => count( $data ),
            'type'    => $csv_type,
            'message' => count( $data ) . ' ' . ( $csv_type === 'queries' ? 'requêtes' : 'pages' ) . ' importées.',
        ) );
    }

    /**
     * AJAX : supprimer les données CSV GSC.
     */
    public function ajax_delete_gsc() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        delete_option( 'hts_gsc_queries' );
        delete_option( 'hts_gsc_pages' );
        delete_option( 'hts_gsc_import_meta' );
        delete_transient( 'hts_coach_ctx' );

        wp_send_json_success( array( 'message' => 'Données CSV supprimées.' ) );
    }

    /* ═══════════════════════════════════════════════════════════════════
     *  SPRINT S3 — MEMORY SYSTEM (v3.2)
     *  Le Coach se souvient des conversations précédentes.
     * ═══════════════════════════════════════════════════════════════════ */

    /* ─── G.5 : Tables DB ─── */

    /**
     * Crée les tables sessions + memory si absentes.
     * Appelé via admin_init, protégé par version option.
     *
     * @since 3.2.0
     */
    public function maybe_create_memory_tables() {
        $current_version = get_option( self::MEMORY_VERSION_OPT, '0' );
        if ( $current_version === self::MEMORY_DB_VERSION ) {
            return;
        }
        self::create_memory_tables();
        update_option( self::MEMORY_VERSION_OPT, self::MEMORY_DB_VERSION );

        // v4.0 : Migrer l'historique wp_options → table messages (one-shot)
        if ( version_compare( $current_version, '2.0', '<' ) ) {
            self::migrate_history_to_db();
        }
    }

    /**
     * v4.0 : Migration one-shot wp_options → hts_coach_messages.
     * Transfère l'historique existant dans la nouvelle table.
     */
    private static function migrate_history_to_db() {
        $all = get_option( self::OPT_HISTORY, array() );
        if ( ! is_array( $all ) || empty( $all ) ) return;

        global $wpdb;
        $msg_table = $wpdb->prefix . self::MESSAGES_TABLE;
        $ses_table = $wpdb->prefix . self::SESSIONS_TABLE;

        foreach ( $all as $key => $turns ) {
            if ( ! is_array( $turns ) || empty( $turns ) ) continue;

            // Extraire user_id du format "user_X"
            $user_id = absint( str_replace( 'user_', '', $key ) );
            if ( ! $user_id ) continue;

            // Créer une session de migration
            $wpdb->insert( $ses_table, array(
                'user_id'        => $user_id,
                'session_start'  => wp_date( 'Y-m-d H:i:s', $turns[0]['ts'] ?? time() ),
                'messages_count' => count( $turns ) * 2,
                'topics'         => wp_json_encode( array( 'conversation migrée' ) ),
                'summary_status' => 'migrated',
                'created_at'     => current_time( 'mysql' ),
            ), array( '%d', '%s', '%d', '%s', '%s', '%s' ) );

            $session_id = $wpdb->insert_id;
            if ( ! $session_id ) continue;

            // Insérer chaque tour Q/R
            foreach ( $turns as $turn ) {
                $ts = isset( $turn['ts'] ) ? wp_date( 'Y-m-d H:i:s', $turn['ts'] ) : current_time( 'mysql' );

                if ( ! empty( $turn['q'] ) ) {
                    $wpdb->insert( $msg_table, array(
                        'session_id' => $session_id,
                        'user_id'    => $user_id,
                        'role'       => 'user',
                        'content'    => $turn['q'],
                        'created_at' => $ts,
                    ), array( '%d', '%d', '%s', '%s', '%s' ) );
                }

                if ( ! empty( $turn['a'] ) ) {
                    $wpdb->insert( $msg_table, array(
                        'session_id' => $session_id,
                        'user_id'    => $user_id,
                        'role'       => 'assistant',
                        'content'    => $turn['a'],
                        'created_at' => $ts,
                    ), array( '%d', '%d', '%s', '%s', '%s' ) );
                }
            }
        }

        // Supprimer l'ancien historique de wp_options (nettoyage)
        delete_option( self::OPT_HISTORY );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Coach v4.0 : migration historique wp_options → hts_coach_messages terminée', 'info', 'coach' );
        }
    }

    /**
     * CREATE TABLE hts_coach_sessions + hts_coach_memory.
     *
     * @since 3.2.0
     */
    public static function create_memory_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ── Table sessions ──
        $sessions = $wpdb->prefix . self::SESSIONS_TABLE;
        $sql_sessions = "CREATE TABLE IF NOT EXISTS {$sessions} (
            id             BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id        BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            session_start  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            session_end    DATETIME     NULL,
            messages_count INT          UNSIGNED NOT NULL DEFAULT 0,
            topics         TEXT         NULL,
            summary_text   TEXT         NULL,
            summary_status VARCHAR(20)  NOT NULL DEFAULT 'pending',
            created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user    (user_id),
            INDEX idx_start   (session_start),
            INDEX idx_status  (summary_status)
        ) {$charset};";
        dbDelta( $sql_sessions );

        // ── Table memory (faits persistants) ──
        $memory = $wpdb->prefix . self::MEMORY_TABLE;
        $sql_memory = "CREATE TABLE IF NOT EXISTS {$memory} (
            id          BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id     BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            area        VARCHAR(50)  NOT NULL DEFAULT 'general',
            category    VARCHAR(100) NOT NULL DEFAULT '',
            content     TEXT         NOT NULL,
            confidence  FLOAT        NOT NULL DEFAULT 0.8,
            source      VARCHAR(20)  NOT NULL DEFAULT 'extracted',
            session_id  BIGINT(20)   UNSIGNED NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user     (user_id),
            INDEX idx_area     (area),
            INDEX idx_category (category),
            INDEX idx_source   (source)
        ) {$charset};";
        dbDelta( $sql_memory );

        // ── v4.0 : Table messages (historique en DB, remplace wp_options) ──
        $messages = $wpdb->prefix . self::MESSAGES_TABLE;
        $sql_messages = "CREATE TABLE IF NOT EXISTS {$messages} (
            id          BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            user_id     BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            role        VARCHAR(10)  NOT NULL DEFAULT 'user',
            content     LONGTEXT     NOT NULL,
            intent      VARCHAR(50)  NULL,
            model       VARCHAR(80)  NULL,
            provider    VARCHAR(30)  NULL,
            tokens_in   INT UNSIGNED NOT NULL DEFAULT 0,
            tokens_out  INT UNSIGNED NOT NULL DEFAULT 0,
            chart_json  TEXT         NULL,
            actions_json TEXT        NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_session   (session_id),
            INDEX idx_user_date (user_id, created_at),
            INDEX idx_role      (role)
        ) {$charset};";
        dbDelta( $sql_messages );

        // Sprint 4.2 : migration — ajouter actions_json si manquante (sites existants)
        $msg_cols = $wpdb->get_col( "SHOW COLUMNS FROM {$messages}", 0 );
        if ( is_array( $msg_cols ) && ! in_array( 'actions_json', $msg_cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$messages} ADD COLUMN actions_json TEXT NULL AFTER chart_json" );
        }

        // ── v4.0 : Table artifacts (charts persistés) ──
        $artifacts = $wpdb->prefix . self::ARTIFACTS_TABLE;
        $sql_artifacts = "CREATE TABLE IF NOT EXISTS {$artifacts} (
            id          BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            message_id  BIGINT(20) UNSIGNED NULL,
            user_id     BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            type        VARCHAR(30)  NOT NULL DEFAULT 'chart',
            title       VARCHAR(255) NULL,
            data_json   LONGTEXT     NOT NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_session (session_id),
            INDEX idx_user    (user_id),
            INDEX idx_type    (type)
        ) {$charset};";
        dbDelta( $sql_artifacts );

        // ── Sprint 4.8 : Table analytics (métriques granulaires par requête) ──
        $analytics = $wpdb->prefix . self::ANALYTICS_TABLE;
        $sql_analytics = "CREATE TABLE IF NOT EXISTS {$analytics} (
            id          BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id     BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            session_id  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            message_id  BIGINT(20) UNSIGNED NULL,
            intent      VARCHAR(50)  NOT NULL DEFAULT 'global',
            model       VARCHAR(80)  NULL,
            provider    VARCHAR(30)  NULL,
            tokens_in   INT UNSIGNED NOT NULL DEFAULT 0,
            tokens_out  INT UNSIGNED NOT NULL DEFAULT 0,
            latency_ms  INT UNSIGNED NOT NULL DEFAULT 0,
            tools_used  VARCHAR(255) NULL,
            has_chart   TINYINT(1)   NOT NULL DEFAULT 0,
            has_actions TINYINT(1)   NOT NULL DEFAULT 0,
            has_plan    TINYINT(1)   NOT NULL DEFAULT 0,
            feedback    TINYINT(1)   NULL COMMENT '-1=bad, 0=neutral, 1=good',
            error_code  VARCHAR(50)  NULL,
            question_preview VARCHAR(200) NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user      (user_id),
            INDEX idx_intent    (intent),
            INDEX idx_created   (created_at),
            INDEX idx_provider  (provider),
            INDEX idx_feedback  (feedback)
        ) {$charset};";
        dbDelta( $sql_analytics );
    }

    /**
     * Vérifie que les tables memory existent.
     *
     * @since 3.2.0
     * @return bool
     */
    public static function memory_tables_exist() {
        global $wpdb;
        $a = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::SESSIONS_TABLE ) );
        $b = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::MEMORY_TABLE ) );
        $c = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . self::MESSAGES_TABLE ) );
        return ( ! empty( $a ) && ! empty( $b ) && ! empty( $c ) );
    }

    /* ─── G.7 : Session Management ─── */

    /**
     * Retourne la session active ou en crée une nouvelle (timeout 30min).
     *
     * @since 3.2.0
     * @param int $user_id
     * @return array { id, session_start, messages_count } ou vide si pas de tables
     */
    public static function get_or_create_session( $user_id = 0 ) {
        if ( ! self::memory_tables_exist() ) {
            return array();
        }

        global $wpdb;
        $table   = $wpdb->prefix . self::SESSIONS_TABLE;
        $user_id = absint( $user_id );

        // Chercher la dernière session du user
        $last = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY session_start DESC LIMIT 1",
            $user_id
        ), ARRAY_A );

        $now = current_time( 'mysql' );

        if ( $last ) {
            // Si session_end est set → la session a été fermée volontairement (via "Nouvelle conversation")
            // NE PAS rouvrir — respecter la fermeture
            if ( ! empty( $last['session_end'] ) ) {
                // Session fermée → créer une nouvelle
                // (sauf si c'est la seule et qu'il n'y en a pas d'ouverte)
            } else {
                // session_end IS NULL → session potentiellement active
                // Vérifier le timeout via le dernier message
                $last_activity = $last['session_start'];
                if ( self::messages_table_exists() ) {
                    $msg_table = $wpdb->prefix . self::MESSAGES_TABLE;
                    $last_msg_time = $wpdb->get_var( $wpdb->prepare(
                        "SELECT created_at FROM {$msg_table}
                         WHERE session_id = %d
                         ORDER BY created_at DESC LIMIT 1",
                        $last['id']
                    ) );
                    if ( $last_msg_time ) {
                        $last_activity = $last_msg_time;
                    }
                }

                $diff = strtotime( $now ) - strtotime( $last_activity );

                if ( $diff < self::SESSION_TIMEOUT ) {
                    return $last;
                }

                // Timeout dépassé → clore
                self::close_session( (int) $last['id'] );
            }
        }

        // Créer nouvelle session
        $wpdb->insert( $table, array(
            'user_id'        => $user_id,
            'session_start'  => $now,
            'messages_count' => 0,
            'summary_status' => 'pending',
        ), array( '%d', '%s', '%d', '%s' ) );

        $new_id = (int) $wpdb->insert_id;

        return array(
            'id'             => $new_id,
            'user_id'        => $user_id,
            'session_start'  => $now,
            'messages_count' => 0,
            'summary_status' => 'pending',
        );
    }

    /**
     * Incrémente le compteur de messages de la session et met à jour session_end.
     *
     * @since 3.2.0
     * @param int    $session_id
     * @param string $topic  Sujet détecté (intent ou extrait).
     */
    public static function touch_session( $session_id, $topic = '' ) {
        if ( ! self::memory_tables_exist() || $session_id <= 0 ) return;

        global $wpdb;
        $table = $wpdb->prefix . self::SESSIONS_TABLE;
        $now   = current_time( 'mysql' );

        // Incrémenter messages_count — NE PAS toucher session_end (reste NULL = session active)
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$table} SET messages_count = messages_count + 1 WHERE id = %d",
            $session_id
        ) );

        // Accumuler les topics (JSON array)
        if ( ! empty( $topic ) ) {
            $row = $wpdb->get_var( $wpdb->prepare(
                "SELECT topics FROM {$table} WHERE id = %d", $session_id
            ) );
            $topics = ! empty( $row ) ? json_decode( $row, true ) : array();
            if ( ! is_array( $topics ) ) $topics = array();
            if ( ! in_array( $topic, $topics, true ) ) {
                $topics[] = $topic;
                // Garder max 10 topics par session
                $topics = array_slice( $topics, -10 );
                $wpdb->update( $table, array(
                    'topics' => wp_json_encode( $topics, JSON_UNESCAPED_UNICODE ),
                ), array( 'id' => $session_id ), array( '%s' ), array( '%d' ) );
            }
        }
    }

    /**
     * Clore une session (set session_end, déclenche le résumé si assez de messages).
     *
     * @since 3.2.0
     * @param int $session_id
     */
    public static function close_session( $session_id ) {
        if ( ! self::memory_tables_exist() || $session_id <= 0 ) return;

        global $wpdb;
        $table = $wpdb->prefix . self::SESSIONS_TABLE;

        $session = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d", $session_id
        ), ARRAY_A );

        if ( ! $session ) return;

        $now = current_time( 'mysql' );
        $wpdb->update( $table, array(
            'session_end' => $now,
        ), array( 'id' => $session_id ), array( '%s' ), array( '%d' ) );

        // Si ≥3 messages, générer le résumé en background (via transient flag)
        if ( (int) $session['messages_count'] >= 3 && $session['summary_status'] === 'pending' ) {
            set_transient( 'hts_coach_summarize_' . $session_id, true, HOUR_IN_SECONDS );
        }
    }

    /* ─── G.8 : Session Summary ─── */

    /**
     * Génère un résumé IA d'une session close.
     * Appelé lazy : au prochain ask() si un transient de summarize existe.
     *
     * @since 3.2.0
     * @param int $session_id
     * @return string|false  Le résumé ou false si échec.
     */
    public static function save_session_summary( $session_id ) {
        if ( ! self::memory_tables_exist() ) return false;

        global $wpdb;
        $table = $wpdb->prefix . self::SESSIONS_TABLE;

        $session = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d", $session_id
        ), ARRAY_A );

        if ( ! $session || $session['summary_status'] === 'done' ) return false;

        // Récupérer l'historique de cette session via les timestamps
        $user_id = (int) $session['user_id'];
        $all_history = get_option( self::OPT_HISTORY, array() );
        $key = 'user_' . $user_id;
        $user_history = $all_history[ $key ] ?? array();

        // Filtrer les messages de cette session (entre session_start et session_end)
        $start_ts = strtotime( $session['session_start'] );
        $end_ts   = ! empty( $session['session_end'] ) ? strtotime( $session['session_end'] ) : time();

        $session_messages = array();
        foreach ( $user_history as $turn ) {
            $ts = $turn['ts'] ?? 0;
            if ( $ts >= $start_ts && $ts <= $end_ts + 60 ) { // +60s de marge
                $session_messages[] = $turn;
            }
        }

        if ( empty( $session_messages ) ) {
            // Pas de messages trouvés — marquer done sans résumé
            $wpdb->update( $table, array(
                'summary_status' => 'done',
                'summary_text'   => '',
            ), array( 'id' => $session_id ), array( '%s', '%s' ), array( '%d' ) );
            return false;
        }

        // Construire le transcript
        $transcript = '';
        foreach ( $session_messages as $turn ) {
            $transcript .= "Client : " . mb_substr( $turn['q'], 0, 500 ) . "\n";
            $transcript .= "Coach : " . mb_substr( $turn['a'], 0, 1000 ) . "\n\n";
        }
        $transcript = mb_substr( $transcript, 0, 6000 ); // max 6K chars

        // Appel IA pour résumé (utilise Haiku pour économiser)
        $api_key = self::get_api_key();
        if ( empty( $api_key ) ) return false;

        $summary_prompt = "Résume cette session de coaching SEO en 2-3 phrases. " .
            "Identifie : les sujets abordés, les recommandations données, les actions proposées, " .
            "et les décisions du client. Sois factuel et concis.\n\n" .
            "Transcript :\n" . $transcript;

        $result = self::call_api( $api_key, 'Tu es un assistant qui résume des sessions de coaching SEO. Réponds en français, 2-3 phrases max.', array(
            array( 'role' => 'user', 'content' => $summary_prompt ),
        ) );

        if ( is_wp_error( $result ) ) {
            // Marquer en erreur, on réessaiera plus tard
            return false;
        }

        $summary = mb_substr( trim( $result['text'] ?? '' ), 0, 2000 );

        $wpdb->update( $table, array(
            'summary_text'   => $summary,
            'summary_status' => 'done',
        ), array( 'id' => $session_id ), array( '%s', '%s' ), array( '%d' ) );

        // Tracker usage du résumé
        $tokens_in  = (int) ( $result['usage']['input_tokens'] ?? 0 );
        $tokens_out = (int) ( $result['usage']['output_tokens'] ?? 0 );
        self::track_usage( $tokens_in, $tokens_out );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'Coach Memory : résumé session #%d généré (%d tokens)', $session_id, $tokens_in + $tokens_out ), 'info', 'coach' );
        }

        // Supprimer le transient
        delete_transient( 'hts_coach_summarize_' . $session_id );

        return $summary;
    }

    /**
     * Traitement lazy des résumés en attente (appelé dans ask() avant l'appel IA principal).
     * Résume AU PLUS 1 session par requête pour ne pas ralentir.
     *
     * @since 3.2.0
     */
    private static function process_pending_summaries() {
        if ( ! self::memory_tables_exist() ) return;

        global $wpdb;
        $table = $wpdb->prefix . self::SESSIONS_TABLE;

        // Chercher une session close avec summary pending (la plus ancienne)
        $pending = $wpdb->get_var(
            "SELECT id FROM {$table} WHERE summary_status = 'pending' AND session_end IS NOT NULL AND messages_count >= 3 ORDER BY session_start ASC LIMIT 1"
        );

        if ( $pending ) {
            self::save_session_summary( (int) $pending );
        }
    }

    /**
     * Récupère les N derniers résumés de sessions pour injection dans le prompt.
     *
     * @since 3.2.0
     * @param int $user_id
     * @param int $limit
     * @return array [ { id, summary_text, topics, session_start, messages_count }, ... ]
     */
    public static function get_recent_session_summaries( $user_id, $limit = 0 ) {
        if ( ! self::memory_tables_exist() ) return array();
        if ( $limit <= 0 ) $limit = self::MAX_SESSION_SUMMARIES;

        global $wpdb;
        $table = $wpdb->prefix . self::SESSIONS_TABLE;

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT id, summary_text, topics, session_start, messages_count
             FROM {$table}
             WHERE user_id = %d AND summary_status = 'done' AND summary_text != ''
             ORDER BY session_start DESC LIMIT %d",
            $user_id, $limit
        ), ARRAY_A ) ?: array();
    }

    /* ─── G.9 : Site Profile ─── */

    /**
     * Récupère le profil auto-généré du site.
     *
     * @since 3.2.0
     * @return array { theme, audience, strengths, weaknesses, goals, last_updated }
     */
    public static function get_site_profile() {
        $profile = get_option( self::SITE_PROFILE_OPT, array() );
        if ( ! is_array( $profile ) ) return array();
        return $profile;
    }

    /**
     * Met à jour le profil du site (manuellement ou via extraction IA).
     *
     * @since 3.2.0
     * @param array $data  Champs à mettre à jour (merge).
     */
    public static function update_site_profile( $data ) {
        $current = self::get_site_profile();
        $allowed_keys = array( 'theme', 'audience', 'strengths', 'weaknesses', 'goals', 'niche', 'competitors', 'tone' );

        foreach ( $allowed_keys as $k ) {
            if ( isset( $data[ $k ] ) ) {
                $current[ $k ] = sanitize_textarea_field( $data[ $k ] );
            }
        }

        $current['last_updated'] = current_time( 'mysql' );
        update_option( self::SITE_PROFILE_OPT, $current, false );
    }

    /**
     * Génère ou met à jour le profil du site via IA (basé sur le contexte actuel).
     * Coûteux → appelé max 1 fois par semaine via transient.
     *
     * @since 3.2.0
     * @return bool
     */
    public static function auto_generate_site_profile() {
        // Throttle : 1 fois par semaine max
        if ( get_transient( 'hts_coach_profile_generated' ) ) return false;

        $api_key = self::get_api_key();
        if ( empty( $api_key ) ) return false;

        // Contexte minimal (pas besoin de deep context)
        $context = self::build_context( 0, '' );
        $json_ctx = wp_json_encode( $context, JSON_UNESCAPED_UNICODE );
        if ( strlen( $json_ctx ) > 10000 ) {
            $json_ctx = self::truncate_json( $json_ctx, 10000 );
        }

        $prompt = "Analyse ces données SEO et génère un profil du site en JSON strict (pas de markdown) :\n" .
            "{\n" .
            "  \"theme\": \"thème principal du site en 1 phrase\",\n" .
            "  \"audience\": \"audience cible en 1 phrase\",\n" .
            "  \"niche\": \"niche/secteur\",\n" .
            "  \"strengths\": \"3 points forts SEO\",\n" .
            "  \"weaknesses\": \"3 faiblesses SEO\",\n" .
            "  \"goals\": \"objectifs déduits\",\n" .
            "  \"tone\": \"ton éditorial détecté\"\n" .
            "}\n\nDonnées :\n" . $json_ctx;

        $result = self::call_api( $api_key, 'Tu analyses des sites web. Réponds UNIQUEMENT en JSON valide, en français.', array(
            array( 'role' => 'user', 'content' => $prompt ),
        ) );

        if ( is_wp_error( $result ) ) return false;

        $text = trim( $result['text'] ?? '' );
        // Nettoyer les backticks markdown
        $text = preg_replace( '/^```(?:json)?\s*/i', '', $text );
        $text = preg_replace( '/\s*```$/', '', $text );

        $parsed = json_decode( $text, true );
        if ( ! is_array( $parsed ) ) return false;

        self::update_site_profile( $parsed );

        // Tracker usage
        $tokens_in  = (int) ( $result['usage']['input_tokens'] ?? 0 );
        $tokens_out = (int) ( $result['usage']['output_tokens'] ?? 0 );
        self::track_usage( $tokens_in, $tokens_out );

        set_transient( 'hts_coach_profile_generated', true, 7 * DAY_IN_SECONDS );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Coach Memory : profil site auto-généré', 'success', 'coach' );
        }

        return true;
    }

    /* ─── G.10 : [MEMORY:...] Tag Extraction ─── */

    /**
     * Extrait les tags [MEMORY:...] de la réponse IA et les stocke.
     *
     * Format attendu dans la réponse IA :
     *   [MEMORY:area:category] contenu du fait
     *   Exemples :
     *     [MEMORY:seo:objectif] Le client veut doubler son trafic en 6 mois
     *     [MEMORY:site:technique] Le site utilise WooCommerce
     *     [MEMORY:client:preference] Le client préfère les réponses courtes
     *
     * @since 3.2.0
     * @param string $text        Réponse IA complète.
     * @param int    $user_id     ID du user.
     * @param int    $session_id  ID de la session en cours.
     * @return array  Faits extraits [ { area, category, content }, ... ]
     */
    public static function extract_memory_tags( $text, $user_id = 0, $session_id = 0 ) {
        if ( ! self::memory_tables_exist() ) return array();

        $facts = array();

        // Pattern : [MEMORY:area:category] contenu jusqu'à fin de ligne
        if ( preg_match_all( '/\[MEMORY:([a-z_]+):([a-z_]+)\]\s*(.+?)(?:\n|$)/i', $text, $matches, PREG_SET_ORDER ) ) {
            global $wpdb;
            $table = $wpdb->prefix . self::MEMORY_TABLE;

            foreach ( $matches as $m ) {
                $area     = sanitize_key( mb_strtolower( $m[1] ) );
                $category = sanitize_key( mb_strtolower( $m[2] ) );
                $content  = sanitize_textarea_field( trim( $m[3] ) );

                if ( empty( $content ) || mb_strlen( $content ) < 5 ) continue;

                // Vérifier si un fait similaire existe déjà (même area+category, contenu proche)
                $existing = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$table} WHERE user_id = %d AND area = %s AND category = %s AND content = %s LIMIT 1",
                    $user_id, $area, $category, $content
                ) );

                if ( $existing ) {
                    // Mettre à jour le timestamp (confirme le fait)
                    $wpdb->update( $table, array(
                        'updated_at' => current_time( 'mysql' ),
                        'confidence' => 0.9,
                    ), array( 'id' => $existing ), array( '%s', '%f' ), array( '%d' ) );
                } else {
                    // Insérer nouveau fait
                    $wpdb->insert( $table, array(
                        'user_id'    => $user_id,
                        'area'       => $area,
                        'category'   => $category,
                        'content'    => mb_substr( $content, 0, 1000 ),
                        'confidence' => 0.8,
                        'source'     => 'extracted',
                        'session_id' => $session_id > 0 ? $session_id : null,
                    ), array( '%d', '%s', '%s', '%s', '%f', '%s', '%d' ) );
                }

                $facts[] = array(
                    'area'     => $area,
                    'category' => $category,
                    'content'  => $content,
                );
            }

            // Purger si trop de faits (garder les plus récents)
            $count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d", $user_id
            ) );
            if ( $count > self::MAX_MEMORY_ITEMS ) {
                $excess = $count - self::MAX_MEMORY_ITEMS;
                $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$table} WHERE user_id = %d ORDER BY updated_at ASC LIMIT %d",
                    $user_id, $excess
                ) );
            }
        }

        return $facts;
    }

    /**
     * Récupère tous les faits mémorisés pour un user.
     *
     * @since 3.2.0
     * @param int    $user_id
     * @param string $area     Filtre optionnel par area.
     * @return array
     */
    public static function get_memory_facts( $user_id, $area = '' ) {
        if ( ! self::memory_tables_exist() ) return array();

        global $wpdb;
        $table = $wpdb->prefix . self::MEMORY_TABLE;

        if ( ! empty( $area ) ) {
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$table} WHERE user_id = %d AND area = %s ORDER BY updated_at DESC",
                $user_id, $area
            ), ARRAY_A ) ?: array();
        }

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY area, category, updated_at DESC",
            $user_id
        ), ARRAY_A ) ?: array();
    }

    /**
     * Supprime un fait mémorisé.
     *
     * @since 3.2.0
     * @param int $memory_id
     * @param int $user_id  Pour vérifier l'ownership.
     * @return bool
     */
    public static function delete_memory_fact( $memory_id, $user_id ) {
        if ( ! self::memory_tables_exist() ) return false;

        global $wpdb;
        $table = $wpdb->prefix . self::MEMORY_TABLE;

        return (bool) $wpdb->delete( $table, array(
            'id'      => $memory_id,
            'user_id' => $user_id,
        ), array( '%d', '%d' ) );
    }

    /* ─── G.12 : Inject Memory into System Prompt ─── */

    /**
     * Construit le bloc mémoire à injecter dans le system prompt.
     * Contient : résumés des sessions passées + profil site + faits mémorisés.
     *
     * @since 3.2.0
     * @param int $user_id
     * @return string  Bloc texte à injecter (ou vide si rien).
     */
    public static function build_memory_block( $user_id ) {
        $parts = array();

        // ── Profil du site ──
        $profile = self::get_site_profile();
        if ( ! empty( $profile ) && ! empty( $profile['theme'] ) ) {
            $profile_lines = array();
            if ( ! empty( $profile['theme'] ) )      $profile_lines[] = "Thème : " . $profile['theme'];
            if ( ! empty( $profile['audience'] ) )    $profile_lines[] = "Audience : " . $profile['audience'];
            if ( ! empty( $profile['niche'] ) )       $profile_lines[] = "Niche : " . $profile['niche'];
            if ( ! empty( $profile['strengths'] ) )   $profile_lines[] = "Forces : " . $profile['strengths'];
            if ( ! empty( $profile['weaknesses'] ) )  $profile_lines[] = "Faiblesses : " . $profile['weaknesses'];
            if ( ! empty( $profile['goals'] ) )       $profile_lines[] = "Objectifs : " . $profile['goals'];
            if ( ! empty( $profile['tone'] ) )        $profile_lines[] = "Ton éditorial : " . $profile['tone'];
            $parts[] = "PROFIL DU SITE :\n" . implode( "\n", $profile_lines );
        }

        // ── Faits mémorisés (regroupés par area) ──
        $facts = self::get_memory_facts( $user_id );
        if ( ! empty( $facts ) ) {
            $grouped = array();
            foreach ( $facts as $f ) {
                $key = $f['area'] . '/' . $f['category'];
                $grouped[ $key ][] = $f['content'];
            }
            $fact_lines = array();
            foreach ( $grouped as $key => $contents ) {
                $fact_lines[] = "- [{$key}] " . implode( ' | ', array_slice( $contents, 0, 3 ) );
            }
            if ( ! empty( $fact_lines ) ) {
                $parts[] = "FAITS MÉMORISÉS :\n" . implode( "\n", array_slice( $fact_lines, 0, 30 ) );
            }
        }

        // ── Résumés des sessions précédentes ──
        $summaries = self::get_recent_session_summaries( $user_id );
        if ( ! empty( $summaries ) ) {
            $sum_lines = array();
            foreach ( $summaries as $s ) {
                $date = wp_date( 'j M Y', strtotime( $s['session_start'] ) );
                $topics_arr = ! empty( $s['topics'] ) ? json_decode( $s['topics'], true ) : array();
                $topics_str = ! empty( $topics_arr ) ? ' [' . implode( ', ', $topics_arr ) . ']' : '';
                $sum_lines[] = "- {$date}{$topics_str} : " . mb_substr( $s['summary_text'], 0, 300 );
            }
            $parts[] = "SESSIONS PRÉCÉDENTES :\n" . implode( "\n", $sum_lines );
        }

        if ( empty( $parts ) ) return '';

        return "\n\n═══ MÉMOIRE DU COACH ═══\n" .
            "Tu as une mémoire des échanges précédents avec ce client. Utilise ces informations pour personnaliser tes conseils.\n" .
            "Si tu apprends un fait important sur le client ou son site, ajoute un tag [MEMORY:area:category] dans ta réponse.\n" .
            "Areas : seo, geo, site, client, business, technique. Categories : objectif, preference, probleme, decision, fait.\n" .
            "Exemple : [MEMORY:client:objectif] Le client veut atteindre 10K visiteurs/mois\n\n" .
            implode( "\n\n", $parts );
    }

    /* ═══════════════════════════════════════════════
     *  AJAX — Memory System Endpoints (v3.2)
     * ═══════════════════════════════════════════════ */

    /**
     * AJAX : liste les sessions de coaching.
     *
     * @since 3.2.0
     */
    public function ajax_sessions() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        if ( ! self::memory_tables_exist() ) {
            wp_send_json_success( array( 'sessions' => array(), 'message' => 'Tables mémoire non initialisées.' ) );
        }

        global $wpdb;
        $table   = $wpdb->prefix . self::SESSIONS_TABLE;
        $user_id = get_current_user_id();
        $limit   = min( 50, max( 1, absint( $_POST['limit'] ?? 20 ) ) );

        $sessions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, session_start, session_end, messages_count, topics, summary_text, summary_status
             FROM {$table}
             WHERE user_id = %d
             ORDER BY session_start DESC
             LIMIT %d",
            $user_id, $limit
        ), ARRAY_A );

        // Session active = celle sans session_end OU dont le dernier message est récent
        $active_id = 0;
        $now_ts = strtotime( current_time( 'mysql' ) );

        // Décoder les topics JSON + marquer session active
        foreach ( $sessions as &$s ) {
            $s['topics'] = ! empty( $s['topics'] ) ? json_decode( $s['topics'], true ) : array();

            // Déterminer si la session est active : session_end NULL ou dernier message < 30min
            $s['is_active'] = false;
            if ( empty( $s['session_end'] ) ) {
                $s['is_active'] = true;
            } elseif ( self::messages_table_exists() ) {
                // Fallback pour les anciennes sessions dont session_end a été set par l'ancien bug
                $msg_table = $wpdb->prefix . self::MESSAGES_TABLE;
                $last_msg = $wpdb->get_var( $wpdb->prepare(
                    "SELECT created_at FROM {$msg_table}
                     WHERE session_id = %d ORDER BY created_at DESC LIMIT 1",
                    $s['id']
                ) );
                if ( $last_msg && ( $now_ts - strtotime( $last_msg ) ) < self::SESSION_TIMEOUT ) {
                    $s['is_active'] = true;
                }
            }
            if ( $s['is_active'] && ! $active_id ) $active_id = (int) $s['id'];

            // v4.0 : Récupérer le premier message user comme "preview"
            if ( self::messages_table_exists() && (int) $s['messages_count'] > 0 ) {
                $msg_table = $wpdb->prefix . self::MESSAGES_TABLE;
                $preview = $wpdb->get_var( $wpdb->prepare(
                    "SELECT content FROM {$msg_table}
                     WHERE session_id = %d AND role = 'user'
                     ORDER BY created_at ASC LIMIT 1",
                    $s['id']
                ) );
                $s['preview'] = $preview ? mb_substr( $preview, 0, 100 ) : '';

                // Sprint 4.1 fix : détecter si la session contient un plan Agent
                $has_plan = $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$msg_table}
                     WHERE session_id = %d AND intent = 'action' AND role = 'system'
                     LIMIT 1",
                    $s['id']
                ) );
                $s['has_plan'] = (int) $has_plan > 0;
            } else {
                $s['preview'] = '';
                $s['has_plan'] = false;
            }
        }
        unset( $s );

        wp_send_json_success( array(
            'sessions'   => $sessions ?: array(),
            'active_id'  => $active_id,
        ) );
    }

    /**
     * AJAX : liste les faits mémorisés.
     *
     * @since 3.2.0
     */
    public function ajax_memory() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(1);

        $user_id = get_current_user_id();
        $area    = sanitize_key( $_POST['area'] ?? '' );
        $facts   = self::get_memory_facts( $user_id, $area );

        wp_send_json_success( array(
            'facts' => $facts,
            'count' => count( $facts ),
        ) );
    }

    /**
     * AJAX : supprimer un fait mémorisé.
     *
     * @since 3.2.0
     */
    public function ajax_memory_delete() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(1);

        $memory_id = absint( $_POST['memory_id'] ?? 0 );
        if ( ! $memory_id ) {
            wp_send_json_error( array( 'message' => 'ID manquant.' ) );
        }

        $deleted = self::delete_memory_fact( $memory_id, get_current_user_id() );
        if ( $deleted ) {
            wp_send_json_success( array( 'message' => 'Fait supprimé.' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Impossible de supprimer ce fait.' ) );
        }
    }

    /**
     * AJAX : modifier un fait mémorisé (inline edit).
     *
     * @since 4.0 Sprint 3.1
     */
    public function ajax_memory_update() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(1);

        $memory_id = absint( $_POST['memory_id'] ?? 0 );
        if ( ! $memory_id ) {
            wp_send_json_error( array( 'message' => 'ID manquant.' ) );
        }

        if ( ! self::memory_tables_exist() ) {
            wp_send_json_error( array( 'message' => 'Tables mémoire non initialisées.' ) );
        }

        global $wpdb;
        $table   = $wpdb->prefix . self::MEMORY_TABLE;
        $user_id = get_current_user_id();

        // Vérifier ownership
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d AND user_id = %d LIMIT 1",
            $memory_id, $user_id
        ), ARRAY_A );

        if ( ! $existing ) {
            wp_send_json_error( array( 'message' => 'Fait introuvable.' ) );
        }

        $update = array( 'updated_at' => current_time( 'mysql' ) );
        $format = array( '%s' );

        if ( isset( $_POST['content'] ) ) {
            $content = sanitize_textarea_field( wp_unslash( $_POST['content'] ) );
            if ( mb_strlen( $content ) < 3 ) {
                wp_send_json_error( array( 'message' => 'Contenu trop court (min 3 caractères).' ) );
            }
            $update['content'] = mb_substr( $content, 0, 1000 );
            $format[] = '%s';
        }

        if ( isset( $_POST['area'] ) ) {
            $update['area'] = sanitize_key( mb_strtolower( wp_unslash( $_POST['area'] ) ) );
            $format[] = '%s';
        }

        if ( isset( $_POST['category'] ) ) {
            $update['category'] = sanitize_key( mb_strtolower( wp_unslash( $_POST['category'] ) ) );
            $format[] = '%s';
        }

        $updated = $wpdb->update( $table, $update, array( 'id' => $memory_id, 'user_id' => $user_id ), $format, array( '%d', '%d' ) );

        if ( $updated !== false ) {
            wp_send_json_success( array( 'message' => 'Fait mis à jour.' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Erreur lors de la mise à jour.' ) );
        }
    }

    /**
     * AJAX : ajouter manuellement un fait mémorisé.
     *
     * @since 4.0 Sprint 3.1
     */
    public function ajax_memory_add() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(1);

        if ( ! self::memory_tables_exist() ) {
            wp_send_json_error( array( 'message' => 'Tables mémoire non initialisées.' ) );
        }

        $content  = sanitize_textarea_field( wp_unslash( $_POST['content'] ?? '' ) );
        $area     = sanitize_key( mb_strtolower( wp_unslash( $_POST['area'] ?? 'general' ) ) );
        $category = sanitize_key( mb_strtolower( wp_unslash( $_POST['category'] ?? '' ) ) );

        if ( mb_strlen( $content ) < 3 ) {
            wp_send_json_error( array( 'message' => 'Contenu trop court (min 3 caractères).' ) );
        }

        global $wpdb;
        $table   = $wpdb->prefix . self::MEMORY_TABLE;
        $user_id = get_current_user_id();

        // Vérifier la limite
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d", $user_id
        ) );

        if ( $count >= self::MAX_MEMORY_ITEMS ) {
            wp_send_json_error( array( 'message' => 'Limite de ' . self::MAX_MEMORY_ITEMS . ' faits atteinte. Supprimez-en avant d\u0027en ajouter.' ) );
        }

        $inserted = $wpdb->insert( $table, array(
            'user_id'    => $user_id,
            'area'       => $area,
            'category'   => $category,
            'content'    => mb_substr( $content, 0, 1000 ),
            'confidence' => 1.0,
            'source'     => 'manual',
        ), array( '%d', '%s', '%s', '%s', '%f', '%s' ) );

        if ( $inserted ) {
            wp_send_json_success( array(
                'message'   => 'Fait ajouté.',
                'memory_id' => $wpdb->insert_id,
            ) );
        } else {
            wp_send_json_error( array( 'message' => 'Erreur lors de l\u0027ajout.' ) );
        }
    }

    /**
     * AJAX : get/update site profile.
     *
     * @since 3.2.0
     */
    public function ajax_site_profile() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        // POST = update, GET = read (support method param for JS compatibility)
        $method = strtoupper( sanitize_key( $_POST['method'] ?? $_SERVER['REQUEST_METHOD'] ) );
        if ( $method === 'POST' ) {
            $data = array();
            $allowed = array( 'theme', 'audience', 'strengths', 'weaknesses', 'goals', 'niche', 'competitors', 'tone' );
            foreach ( $allowed as $k ) {
                if ( isset( $_POST[ $k ] ) ) {
                    $data[ $k ] = sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) );
                }
            }

            if ( ! empty( $data ) ) {
                self::update_site_profile( $data );
                wp_send_json_success( array(
                    'profile' => self::get_site_profile(),
                    'message' => 'Profil mis à jour.',
                ) );
            }

            // Action spéciale : auto-generate
            if ( ! empty( $_POST['auto_generate'] ) ) {
                $ok = self::auto_generate_site_profile();
                wp_send_json_success( array(
                    'profile'   => self::get_site_profile(),
                    'generated' => $ok,
                    'message'   => $ok ? 'Profil auto-généré avec succès.' : 'Impossible de générer le profil (vérifiez la clé API).',
                ) );
            }

            wp_send_json_error( array( 'message' => 'Aucune donnée à mettre à jour.' ) );
        }

        // GET
        wp_send_json_success( array( 'profile' => self::get_site_profile() ) );
    }

    /* ═══════════════════════════════════════════════
     *  SPRINT S4 — Debug + Upsell + Proactive (v3.3)
     * ═══════════════════════════════════════════════ */

    /**
     * H.1 — Contexte diagnostic complet pour le Coach.
     *
     * Collecte : config plugin, agents health, embeddings stats, crons status,
     * erreurs récentes, tables DB, versions PHP/WP.
     *
     * @since 3.3.0
     * @return array
     */
    public static function get_diagnostic_context() {
        $cache_key = 'hts_coach_diagnostic_ctx';
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        global $wpdb;
        $ctx = array();

        // ── Environnement ──
        $ctx['environment'] = array(
            'php_version'    => PHP_VERSION,
            'wp_version'     => get_bloginfo( 'version' ),
            'plugin_version' => defined( 'HTS__VERSION' ) ? HTS__VERSION : 'inconnue',
            'memory_limit'   => ini_get( 'memory_limit' ),
            'max_execution'  => ini_get( 'max_execution_time' ),
            'is_multisite'   => is_multisite(),
        );

        // ── Clés API ──
        $ctx['api_keys'] = array(
            'anthropic'  => ! empty( self::get_api_key() ) ? 'ok' : 'manquante',
            'openai'     => ! empty( self::get_openai_api_key() ) ? 'ok' : 'manquante',
            'saas_token' => ! empty( get_option( 'hts_api_token', '' ) ) ? 'ok' : 'manquante',
        );

        // ── Agents status ──
        $ctx['agents'] = array();
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $all_agents = HTS_Workflow_Engine::get_all_agents();
            foreach ( $all_agents as $slug => $agent ) {
                $ctx['agents'][ $slug ] = array(
                    'enabled'  => ! empty( $agent['enabled'] ),
                    'mode'     => $agent['mode'] ?? 'review',
                );
            }
        }

        // ── Crons status ──
        $expected_crons = array(
            'hts_content_refresh_cron', 'hts_embeddings_cron', 'hts_auto_write_cron',
            'hts_geo_score_cron', 'hts_health_cron', 'hts_coach_monthly_reset',
            'hts_gsc_daily_import', 'hts_sitemap_cron',
        );
        $ctx['crons'] = array();
        foreach ( $expected_crons as $hook ) {
            $next = wp_next_scheduled( $hook );
            $ctx['crons'][ $hook ] = $next ? array(
                'status'    => 'planifie',
                'next_run'  => wp_date( 'Y-m-d H:i', $next ),
                'in_hours'  => round( ( $next - time() ) / 3600, 1 ),
            ) : array( 'status' => 'absent' );
        }

        // ── Embeddings stats ──
        $embed_table = $wpdb->prefix . 'hts_embeddings';
        $embed_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $embed_table ) ) === $embed_table;
        if ( $embed_exists ) {
            $ctx['embeddings'] = array(
                'total'         => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$embed_table}" ),
                'with_vector'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$embed_table} WHERE vector IS NOT NULL" ),
                'last_updated'  => $wpdb->get_var( "SELECT MAX(updated_at) FROM {$embed_table}" ),
            );
            if ( $ctx['embeddings']['total'] > 0 ) {
                $ctx['embeddings']['coverage_pct'] = round( ( $ctx['embeddings']['with_vector'] / $ctx['embeddings']['total'] ) * 100 );
            }
        } else {
            $ctx['embeddings'] = array( 'status' => 'table_absente' );
        }

        // ── Inbox stats ──
        $inbox_table = $wpdb->prefix . 'hts_workflow_actions';
        $inbox_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $inbox_table ) ) === $inbox_table;
        if ( $inbox_exists ) {
            $ctx['inbox'] = array(
                'pending'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$inbox_table} WHERE status = 'pending'" ),
                'approved'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$inbox_table} WHERE status = 'approved'" ),
                'done'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$inbox_table} WHERE status = 'done'" ),
                'failed'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$inbox_table} WHERE status = 'failed'" ),
            );
        }

        // ── Health Check last results ──
        $health = get_option( 'hts_health_results', array() );
        if ( ! empty( $health ) ) {
            $ctx['health_check'] = array(
                'pass' => 0, 'fail' => 0, 'warn' => 0,
            );
            foreach ( $health as $test ) {
                $st = $test['status'] ?? 'skip';
                if ( isset( $ctx['health_check'][ $st ] ) ) {
                    $ctx['health_check'][ $st ]++;
                }
            }
            // Extraire les failures pour le Coach
            $failures = array();
            foreach ( $health as $test ) {
                if ( ( $test['status'] ?? '' ) === 'fail' ) {
                    $failures[] = ( $test['name'] ?? 'Test inconnu' ) . ' : ' . ( $test['detail'] ?? '' );
                }
            }
            if ( ! empty( $failures ) ) {
                $ctx['health_check']['failures'] = array_slice( $failures, 0, 5 );
            }
        }

        // ── Erreurs PHP récentes (logs) ──
        if ( function_exists( 'hts_get_logs' ) ) {
            $logs = hts_get_logs( 'error', 10 );
            if ( ! empty( $logs ) ) {
                $ctx['recent_errors'] = array();
                foreach ( array_slice( $logs, 0, 5 ) as $log ) {
                    $ctx['recent_errors'][] = array(
                        'date'    => $log['date'] ?? '',
                        'message' => mb_substr( $log['message'] ?? '', 0, 200 ),
                        'source'  => $log['source'] ?? '',
                    );
                }
            }
        }

        // ── Circuit breaker ──
        $breaker = get_option( 'hts_circuit_breaker', array() );
        if ( ! empty( $breaker ) ) {
            $ctx['circuit_breaker'] = array();
            foreach ( $breaker as $module => $info ) {
                if ( ! empty( $info['disabled'] ) ) {
                    $ctx['circuit_breaker'][] = $module;
                }
            }
        }

        // ── GSC connection ──
        $ctx['gsc_connected'] = class_exists( 'HTS_GSC_Connect' ) && ( new \HTS_GSC_Connect() )->is_connected();
        $ctx['gsc_csv_imported'] = ! empty( get_option( 'hts_gsc_queries', array() ) ) || ! empty( get_option( 'hts_gsc_pages', array() ) );

        // ── Coach memory tables ──
        $ctx['memory_tables'] = self::memory_tables_exist();

        set_transient( $cache_key, $ctx, self::DIAGNOSTIC_CACHE_TTL );
        return $ctx;
    }

    /**
     * H.2 — Génère 3-4 suggestions dynamiques à l'ouverture du Coach.
     *
     * Les suggestions sont contextuelles : basées sur les scores, l'Inbox,
     * les embeddings, les erreurs, etc.
     *
     * @since 3.3.0
     * @return array [ [ 'text' => '...', 'icon' => '...', 'priority' => int ], ... ]
     */
    public static function get_startup_suggestions() {
        $suggestions = array();

        // ── Score global faible → suggestion urgente ──
        $avg_score = self::get_average_score();
        if ( $avg_score > 0 && $avg_score < 50 ) {
            $suggestions[] = array(
                'text'     => 'Mon score SEO est faible (' . $avg_score . '/100). Par ou commencer ?',
                'icon'     => 'alert',
                'priority' => 100,
            );
        }

        // ── GEO score faible ──
        $geo_avg = self::get_average_geo_score();
        if ( $geo_avg > 0 && $geo_avg < 40 ) {
            $suggestions[] = array(
                'text'     => 'Mon score GEO est a ' . $geo_avg . '/100. Comment le remonter ?',
                'icon'     => 'cpu',
                'priority' => 90,
            );
        }

        // ── Actions pending dans l'Inbox ──
        $pending = self::get_pending_count();
        if ( $pending > 0 ) {
            $suggestions[] = array(
                'text'     => 'J\u0027ai ' . $pending . ' action' . ( $pending > 1 ? 's' : '' ) . ' en attente. Lesquelles prioriser ?',
                'icon'     => 'inbox',
                'priority' => 85,
            );
        }

        // ── Embeddings incomplets ──
        $embed_coverage = self::get_embeddings_coverage();
        if ( $embed_coverage !== null && $embed_coverage < 80 ) {
            $suggestions[] = array(
                'text'     => 'Seulement ' . $embed_coverage . '% de mes articles ont des embeddings. C\u0027est normal ?',
                'icon'     => 'dna',
                'priority' => 70,
            );
        }

        // ── Health check failures ──
        $health = get_option( 'hts_health_results', array() );
        $fail_count = 0;
        foreach ( $health as $t ) {
            if ( ( $t['status'] ?? '' ) === 'fail' ) $fail_count++;
        }
        if ( $fail_count > 0 ) {
            $suggestions[] = array(
                'text'     => 'Le diagnostic sante montre ' . $fail_count . ' probleme' . ( $fail_count > 1 ? 's' : '' ) . '. Que se passe-t-il ?',
                'icon'     => "\xF0\x9F\xA9\xBA", // 🩺
                'priority' => 95,
            );
        }

        // ── Pas de GSC connecté ──
        $gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new \HTS_GSC_Connect() )->is_connected();
        $gsc_csv = ! empty( get_option( 'hts_gsc_queries', array() ) );
        if ( ! $gsc_connected && ! $gsc_csv ) {
            $suggestions[] = array(
                'text'     => 'Comment connecter la Search Console pour de meilleurs conseils ?',
                'icon'     => 'bar-chart',
                'priority' => 60,
            );
        }

        // ── Plan hebdo (toujours proposé) ──
        $suggestions[] = array(
            'text'     => 'Genere-moi un plan d\u0027action SEO pour cette semaine',
            'icon'     => 'clipboard',
            'priority' => 50,
        );

        // ── Suggestion cluster si cocons existent ──
        $cocon_stats = self::get_cocon_stats_full();
        if ( ! empty( $cocon_stats['clusters'] ) && count( $cocon_stats['clusters'] ) > 0 ) {
            $weakest = null;
            $weakest_density = 100;
            foreach ( $cocon_stats['clusters'] as $cl ) {
                $density = $cl['density'] ?? 100;
                if ( $density < $weakest_density ) {
                    $weakest_density = $density;
                    $weakest = $cl;
                }
            }
            if ( $weakest && $weakest_density < 50 ) {
                $suggestions[] = array(
                    'text'     => 'Le cocon "' . ( $weakest['name'] ?? 'principal' ) . '" a un maillage de ' . $weakest_density . '%. Comment l\u0027ameliorer ?',
                    'icon'     => 'network',
                    'priority' => 75,
                );
            }
        }

        // ── Pages les plus anciennes ──
        $worst = self::get_worst_pages( 1 );
        if ( ! empty( $worst[0] ) && ( $worst[0]['score'] ?? 100 ) < 30 ) {
            $suggestions[] = array(
                'text'     => 'Mon pire article "' . mb_substr( $worst[0]['title'] ?? '', 0, 40 ) . '" a un score de ' . $worst[0]['score'] . '. Que faire ?',
                'icon'     => 'flame',
                'priority' => 80,
            );
        }

        // Trier par priorité descendante et limiter
        usort( $suggestions, function( $a, $b ) {
            return ( $b['priority'] ?? 0 ) - ( $a['priority'] ?? 0 );
        } );

        return array_slice( $suggestions, 0, self::MAX_STARTUP_SUGGESTIONS );
    }

    /**
     * Helper : couverture embeddings en pourcentage.
     *
     * @since 3.3.0
     * @return int|null  Pourcentage ou null si table absente.
     */
    private static function get_embeddings_coverage() {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_embeddings';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            return null;
        }
        // Vérifier que la colonne 'vector' existe avant de la requêter
        $col_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'vector'",
                DB_NAME,
                $table
            )
        );
        if ( ! $col_exists ) {
            return null;
        }
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        if ( $total === 0 ) return 0;
        $with_vec = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE vector IS NOT NULL" );
        return (int) round( ( $with_vec / $total ) * 100 );
    }

    /**
     * Sprint 3.3 : Compte les alertes proactives pour le badge notification.
     *
     * Méthode légère — ne collecte que les signaux qui justifient un badge
     * (critical + warning). Résultat caché en transient 10 min pour perf menu WP.
     *
     * @since 4.0.0 Sprint 3.3
     * @return int  Nombre d'alertes (0 = pas de badge).
     */
    public static function get_alert_count() {
        $cached = get_transient( 'hts_coach_alert_count' );
        if ( $cached !== false ) {
            return (int) $cached;
        }

        $count = 0;

        // 1. Santé critique
        $health = get_option( 'hts_health_results', array() );
        $results = $health['results'] ?? $health;
        if ( is_array( $results ) ) {
            foreach ( $results as $t ) {
                $t = (array) $t;
                if ( ( $t['status'] ?? '' ) === 'fail' ) { $count++; break; }
            }
        }

        // 2. Chute GSC
        $gsc_delta = self::get_gsc_delta();
        if ( ! empty( $gsc_delta['available'] ) && ! empty( $gsc_delta['7d'] ) ) {
            $clicks_num = (float) str_replace( array( '+', '%' ), '', $gsc_delta['7d']['clicks'] ?? '0%' );
            if ( $clicks_num <= -15 ) $count++;
        }

        // 3. Actions pending nombreuses
        $pending = self::get_pending_count();
        if ( $pending >= 5 ) $count++;

        // 4. Score très faible
        $avg = self::get_average_score();
        if ( $avg !== null && $avg < 30 ) $count++;

        // 5. Brouillons prêts
        $drafts = self::get_drafts_ready_to_publish();
        if ( count( $drafts ) >= 3 ) $count++;

        // 6. Sprint 4.3: Coach actions recently completed in Inbox (last 24h)
        $recent_done = self::get_recently_completed_coach_count();
        if ( $recent_done > 0 ) $count += $recent_done;

        set_transient( 'hts_coach_alert_count', $count, 600 ); // cache 10 min
        return $count;
    }

    /**
     * Sprint 4.3 — Nombre d'actions Coach terminées récemment (24h).
     * Sert à alimenter le badge notification du Coach.
     *
     * @since 4.0.0 Sprint 4.3
     * @return int
     */
    public static function get_recently_completed_coach_count() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;
        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return 0;
        $count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE agent = 'coach'
               AND status = 'done'
               AND resolved_at >= %s",
            gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS )
        ) );
        return (int) $count;
    }

    /**
     * H.3 — Lecture de la configuration upsell.
     *
     * @since 3.3.0
     * @return array  [ 'enabled' => bool, 'features' => [...], 'tone' => 'subtle'|'direct' ]
     */
    public static function get_upsell_config() {
        $defaults = array(
            'enabled'  => true,
            'tone'     => 'subtle',  // 'subtle' | 'direct'
            'features' => array(
                'content_refresh'  => array( 'enabled' => true, 'label' => 'Rafraichissement automatique du contenu' ),
                'auto_write'       => array( 'enabled' => true, 'label' => 'Generation d\u0027articles optimises SEO+GEO' ),
                'internal_linking' => array( 'enabled' => true, 'label' => 'Maillage interne automatique' ),
                'geo_optimize'     => array( 'enabled' => true, 'label' => 'Optimisation pour les moteurs IA' ),
                'meta_optimize'    => array( 'enabled' => true, 'label' => 'Meta titles et descriptions IA' ),
                'coach_unlimited'  => array( 'enabled' => true, 'label' => 'Coach SEO illimite avec memoire' ),
            ),
        );
        $saved = get_option( self::UPSELL_CONFIG_OPT, array() );
        if ( empty( $saved ) || ! is_array( $saved ) ) return $defaults;
        return wp_parse_args( $saved, $defaults );
    }

    /**
     * H.3 — Mise à jour de la configuration upsell.
     *
     * @since 3.3.0
     * @param array $data
     * @return bool
     */
    public static function update_upsell_config( $data ) {
        $clean = array(
            'enabled'  => ! empty( $data['enabled'] ),
            'tone'     => in_array( $data['tone'] ?? '', array( 'subtle', 'direct' ), true ) ? $data['tone'] : 'subtle',
            'features' => array(),
        );
        if ( ! empty( $data['features'] ) && is_array( $data['features'] ) ) {
            foreach ( $data['features'] as $key => $feat ) {
                $clean_key = sanitize_key( $key );
                $clean['features'][ $clean_key ] = array(
                    'enabled' => ! empty( $feat['enabled'] ),
                    'label'   => sanitize_text_field( $feat['label'] ?? '' ),
                );
            }
        }
        return update_option( self::UPSELL_CONFIG_OPT, $clean, false );
    }

    /**
     * H.3 — Génère le bloc upsell pour le system prompt.
     *
     * @since 3.3.0
     * @return string
     */
    private static function build_upsell_block() {
        $config = self::get_upsell_config();
        if ( empty( $config['enabled'] ) ) return '';

        $enabled_features = array();
        foreach ( $config['features'] as $key => $feat ) {
            if ( ! empty( $feat['enabled'] ) && ! empty( $feat['label'] ) ) {
                $enabled_features[] = $feat['label'];
            }
        }
        if ( empty( $enabled_features ) ) return '';

        $tone_instruction = $config['tone'] === 'direct'
            ? 'Mentionne ces fonctionnalites de maniere directe quand elles resolvent le probleme du client.'
            : 'Mentionne ces fonctionnalites de maniere SUBTILE — maximum 1 mention naturelle par reponse, comme un consultant qui recommande ses services en passant.';

        return '

═══ FONCTIONNALITES HACK THE SEO A VALORISER ═══
' . $tone_instruction . '
Fonctionnalites disponibles :
- ' . implode( "\n- ", $enabled_features ) . '
Ne liste JAMAIS ces fonctionnalites de maniere brute. Integre-les naturellement dans tes recommandations.
Exemple : si le client a du contenu obsolete, mentionne que "Hack The SEO peut rafraichir ce contenu automatiquement".';
    }

    /**
     * H.1/H.5 — Génère le bloc diagnostic pour le system prompt.
     *
     * Injecté uniquement quand intent=debug.
     *
     * @since 3.3.0
     * @return string
     */
    private static function build_diagnostic_block() {
        // ── Sprint 2.1 : Smart Debug Tree — diagnostic structuré PRÉ-LLM ──
        $tree = self::run_diagnostic_tree();

        $lines = array();
        $lines[] = '═══ DIAGNOSTIC STRUCTURÉ (données vérifiées, pas d\'hallucination) ═══';
        $lines[] = '';
        $lines[] = 'RÉSUMÉ : ' . $tree['summary'];
        $lines[] = '';

        if ( ! empty( $tree['ok'] ) ) {
            $lines[] = 'CE QUI FONCTIONNE :';
            foreach ( $tree['ok'] as $item ) {
                $lines[] = '' . $item;
            }
            $lines[] = '';
        }

        if ( ! empty( $tree['issues'] ) ) {
            $lines[] = 'PROBLÈMES DÉTECTÉS :';
            foreach ( $tree['issues'] as $issue ) {
                $severity_icon = $issue['severity'] === 'critical' ? '[CRITICAL]' : ( $issue['severity'] === 'warning' ? '[WARNING]' : '[INFO]' );
                $lines[] = $severity_icon . ' ' . $issue['problem'];
                $lines[] = '   → Solution : ' . $issue['fix'];
                if ( ! empty( $issue['link'] ) ) {
                    $lines[] = '   → Lien : ' . $issue['link'];
                }
            }
            $lines[] = '';
        }

        if ( ! empty( $tree['recent_errors'] ) ) {
            $lines[] = 'ERREURS RÉCENTES (logs) :';
            foreach ( array_slice( $tree['recent_errors'], 0, 3 ) as $err ) {
                $lines[] = '- [' . ( $err['source'] ?? '' ) . '] ' . $err['message'];
            }
            $lines[] = '';
        }

        // Aussi injecter le diagnostic raw pour contexte supplémentaire
        $raw_diag = self::get_diagnostic_context();
        $json_raw = wp_json_encode( $raw_diag, JSON_UNESCAPED_UNICODE );
        if ( strlen( $json_raw ) > 6000 ) {
            $json_raw = self::truncate_json( $json_raw, 6000 );
        }

        return '

' . implode( "\n", $lines ) . '

INSTRUCTIONS :
- Reformule les problèmes et solutions ci-dessus en langage simple pour le client
- Donne les étapes EXACTES (menu > sous-menu > bouton) pour chaque solution
- NE JAMAIS parler de code, PHP, base de données, architecture technique
- NE JAMAIS inventer des informations absentes du diagnostic ci-dessus
- Si tout est OK, félicite le client et propose des améliorations

DONNÉES TECHNIQUES BRUTES (pour référence) :
' . $json_raw;
    }

    /**
     * H.4/H.5 — Génère le bloc plan hebdo pour le system prompt.
     *
     * Injecté uniquement quand intent=plan.
     *
     * @since 3.3.0
     * @return string
     */
    private static function build_plan_block() {
        // ── Sprint 2.1 : Enrichir avec les chantiers en cours ──
        $chantiers_block = '';
        $chantiers = self::get_chantiers_en_cours();

        if ( ! empty( $chantiers['recently_executed'] ) ) {
            $lines = array();
            foreach ( $chantiers['recently_executed'] as $ch ) {
                $lines[] = '- ' . $ch['type'] . ' : ' . $ch['count'] . ' action(s) exécutée(s)';
            }
            $chantiers_block .= "\n\nCHANTIERS COMPLÉTÉS (7 derniers jours) :\n" . implode( "\n", $lines );
        }

        if ( ! empty( $chantiers['clusters_needing_work'] ) ) {
            $chantiers_block .= "\n\nCLUSTERS À RENFORCER :\n- " . implode( "\n- ", $chantiers['clusters_needing_work'] );
        }

        $current_date = wp_date( 'j F Y' );
        $week_end     = wp_date( 'j F', strtotime( '+6 days' ) );

        return '

═══ MODE PLAN SEO — CONSULTANT SENIOR ═══
Tu génères un plan d\'action SEO structuré de niveau agence. Date du jour : ' . $current_date . '.
' . $chantiers_block . '

Tu DOIS inclure un bloc ```seo_plan``` JSON dans ta réponse (en plus de ton texte de conseil).
Le bloc sera parsé et rendu comme une carte professionnelle dans le chat.

FORMAT STRICT du bloc ```seo_plan``` :
```seo_plan
{
  "title": "Plan SEO — Semaine du ' . $current_date . ' au ' . $week_end . '",
  "objective": "Objectif en 1 ligne (chiffré si possible)",
  "phases": [
    {
      "name": "Quick Wins",
      "timeline": "Jour 1-2",
      "icon": "⚡",
      "actions": [
        {
          "post_id": 123,
          "action": "optimize_meta_both",
          "title": "Titre exact de l\'article",
          "task": "Description concrète de ce qu\'il faut faire",
          "current": "CTR 0.1% | Pos. 5.2",
          "target": "CTR estimé 2% = +350 clics/mois",
          "effort": "15 min",
          "priority": "critical"
        }
      ]
    }
  ],
  "kpis": [
    {"label": "Clics estimés", "value": "+500/mois"},
    {"label": "Pages optimisées", "value": "8"},
    {"label": "Temps total", "value": "~4h"}
  ]
}
```

RÈGLES DE CONSTRUCTION DU PLAN :
1. TOUJOURS 3 phases exactement :
   - Phase 1 "Quick Wins" (Jour 1-2) : icône — actions rapides à fort impact (meta titles, meta descriptions, FAQ)
   - Phase 2 "Contenu & Maillage" (Jour 3-5) : icone [Link] -- refonte contenu, liens internes, enrichissement
   - Phase 3 "Mesure & Ajustement" (Jour 6-7) : icône — vérifier métriques, valider Inbox, planifier la suite
2. Max 3 actions par phase. Chaque action DOIT :
   - Citer un article/page RÉEL avec son post_id et son titre exact
   - Avoir un "current" avec les métriques actuelles (score, CTR, position)
   - Avoir un "target" avec l\'estimation d\'impact CHIFFRÉE
   - Avoir un "effort" réaliste (le client n\'est PAS un SEO full-time)
   - Utiliser un type d\'action valide : add_meta_title, add_meta_desc, optimize_meta_both, add_faq, add_internal_links, content_refresh, geo_optimize, fix_orphan_links
3. Le "priority" est : critical, high, medium, low
4. Les KPIs en bas résument l\'impact total attendu (au moins 3 KPIs)
5. Tiens compte des CHANTIERS COMPLÉTÉS pour ne pas reproposer ce qui est fait
6. Le contexte contient DÉJÀ les pages_overview avec top_queries par page (mots-clés réels GSC). Utilise-les pour baser chaque action sur des DONNÉES RÉELLES.
   - Complète avec get_gsc_stats(period_days=90) si besoin de tendances globales
   - Complète avec list_articles si besoin de filtrer par score
   Ne propose JAMAIS un plan basé sur des suppositions. Cite les mots-clés réels dans tes recommandations.

TEXTE D\'ACCOMPAGNEMENT (en dehors du bloc seo_plan) :
- 3-5 lignes MAX de contexte avant le bloc (pourquoi ce plan, quel est le diagnostic)
- Ne répète PAS le contenu du plan dans le texte
- Inclus aussi un bloc ```actions``` classique pour l\'Inbox (même actions que dans les phases)';
    }

    /**
     * H.5 — Build system prompt enrichi avec blocs conditionnels Sprint S4.
     *
     * Modification de build_system_prompt : les blocs debug, plan et upsell sont
     * injectés selon l'intent détecté.
     *
     * Note : cette méthode est appelée par le build_system_prompt existant
     * via les blocs ajoutés.
     */
    // (intégré directement dans build_system_prompt — voir modification ci-dessous)

    /* ═══════════════════════════════════════════════
     *  Sprint 3.2 : Welcome Proactif
     *  Message d'ouverture personnalisé basé sur l'état réel du site.
     *  Pas d'appel LLM — template PHP pur = instantané + gratuit.
     * ═══════════════════════════════════════════════ */

    /**
     * Construit le message de bienvenue proactif.
     *
     * Collecte tous les signaux disponibles (alertes santé, delta GSC,
     * actions pending, pires pages, brouillons prêts, cocons faibles)
     * et génère un message contextuel priorisé.
     *
     * @since 4.0.0 Sprint 3.2
     * @return array { 'greeting' => string, 'alerts' => array, 'nudge' => string|null }
     */
    public static function build_proactive_welcome() {
        $user      = wp_get_current_user();
        $firstname = ! empty( $user->first_name ) ? $user->first_name : $user->display_name;
        $hour      = (int) current_time( 'G' );

        // ── Greeting contextuel ──
        if ( $hour < 12 ) {
            $time_greeting = 'Bonjour';
        } elseif ( $hour < 18 ) {
            $time_greeting = 'Bon après-midi';
        } else {
            $time_greeting = 'Bonsoir';
        }

        // ── Collecter les signaux ──
        $alerts = array(); // { type, severity, icon, text, priority }

        // 1. Santé du site
        $health = get_option( 'hts_health_results', array() );
        $health_results = $health['results'] ?? $health;
        $fail_count = 0;
        $warn_count = 0;
        if ( is_array( $health_results ) ) {
            foreach ( $health_results as $t ) {
                $t = (array) $t;
                $status = $t['status'] ?? '';
                if ( $status === 'fail' ) $fail_count++;
                elseif ( $status === 'warn' ) $warn_count++;
            }
        }
        if ( $fail_count > 0 ) {
            $alerts[] = array(
                'type'     => 'health_critical',
                'severity' => 'critical',
                'icon'     => "\xF0\x9F\x9A\xA8",
                'text'     => $fail_count . ' problème' . ( $fail_count > 1 ? 's' : '' ) . ' critique' . ( $fail_count > 1 ? 's' : '' ) . ' détecté' . ( $fail_count > 1 ? 's' : '' ) . ' sur votre site. Je vous recommande de les corriger en priorité.',
                'priority' => 100,
            );
        } elseif ( $warn_count > 0 ) {
            $alerts[] = array(
                'type'     => 'health_warning',
                'severity' => 'warning',
                'icon'     => "\xE2\x9A\xA0\xEF\xB8\x8F",
                'text'     => $warn_count . ' avertissement' . ( $warn_count > 1 ? 's' : '' ) . ' dans le diagnostic santé. Rien de bloquant, mais à surveiller.',
                'priority' => 70,
            );
        }

        // 2. Delta GSC (tendance trafic)
        $gsc_delta = self::get_gsc_delta();
        if ( ! empty( $gsc_delta['available'] ) && ! empty( $gsc_delta['7d'] ) ) {
            $clicks_delta = $gsc_delta['7d']['clicks'] ?? '0%';
            $clicks_num   = (float) str_replace( array( '+', '%' ), '', $clicks_delta );
            $pos_delta    = $gsc_delta['7d']['avg_position'] ?? 0;

            if ( $clicks_num <= -15 ) {
                $alerts[] = array(
                    'type'     => 'gsc_drop',
                    'severity' => 'critical',
                    'icon'     => "\xF0\x9F\x93\x89",
                    'text'     => 'Vos clics ont chuté de ' . abs( $clicks_num ) . '% cette semaine. On devrait identifier les pages impactées.',
                    'priority' => 95,
                );
            } elseif ( $clicks_num >= 10 ) {
                $alerts[] = array(
                    'type'     => 'gsc_growth',
                    'severity' => 'positive',
                    'icon'     => "\xF0\x9F\x93\x88",
                    'text'     => 'Bonne nouvelle ! Vos clics sont en hausse de ' . $clicks_delta . ' cette semaine. Continuons sur cette lancée.',
                    'priority' => 60,
                );
            }

            if ( is_numeric( $pos_delta ) && $pos_delta > 2 ) {
                $alerts[] = array(
                    'type'     => 'position_drop',
                    'severity' => 'warning',
                    'icon'     => "\xF0\x9F\x94\xBB",
                    'text'     => 'Votre position moyenne a reculé de ' . round( $pos_delta, 1 ) . ' places cette semaine.',
                    'priority' => 80,
                );
            }
        }

        // 3. Actions pending
        $pending = self::get_pending_count();
        if ( $pending >= 5 ) {
            $alerts[] = array(
                'type'     => 'pending_actions',
                'severity' => 'info',
                'icon'     => "\xF0\x9F\x93\xA5",
                'text'     => $pending . ' actions SEO sont prêtes dans votre Inbox. Voulez-vous qu\u0027on les passe en revue ?',
                'priority' => 75,
            );
        } elseif ( $pending > 0 ) {
            $alerts[] = array(
                'type'     => 'pending_actions',
                'severity' => 'info',
                'icon'     => "\xF0\x9F\x93\xA5",
                'text'     => $pending . ' action' . ( $pending > 1 ? 's' : '' ) . ' en attente dans votre Inbox.',
                'priority' => 50,
            );
        }

        // 4. Brouillons prêts à publier
        $drafts = self::get_drafts_ready_to_publish();
        $draft_count = count( $drafts );
        if ( $draft_count > 0 ) {
            $alerts[] = array(
                'type'     => 'drafts_ready',
                'severity' => 'info',
                'icon'     => "\xF0\x9F\x93\x9D",
                'text'     => $draft_count . ' article' . ( $draft_count > 1 ? 's' : '' ) . ' en brouillon ' . ( $draft_count > 1 ? 'attendent' : 'attend' ) . ' d\u0027être publié' . ( $draft_count > 1 ? 's' : '' ) . '. Prêt à planifier la publication ?',
                'priority' => 65,
            );
        }

        // 5. Score global faible
        $avg_score = self::get_average_score();
        if ( $avg_score !== null && $avg_score < 40 ) {
            $alerts[] = array(
                'type'     => 'score_low',
                'severity' => 'warning',
                'icon'     => "\xF0\x9F\x93\x8A",
                'text'     => 'Votre score SEO moyen est de ' . $avg_score . '/100. Il y a un bon potentiel d\u0027amélioration — on regarde ensemble ?',
                'priority' => 72,
            );
        }

        // 6. Pire page critique
        $worst = self::get_worst_pages( 1 );
        if ( ! empty( $worst[0] ) && ( $worst[0]['score'] ?? 100 ) < 25 ) {
            $title_short = mb_substr( $worst[0]['title'] ?? '', 0, 50 );
            $alerts[] = array(
                'type'     => 'worst_page',
                'severity' => 'warning',
                'icon'     => "\xF0\x9F\x94\xA5",
                'text'     => 'La page « ' . $title_short . ' » n\u0027a que ' . $worst[0]['score'] . '/100. Un petit refresh pourrait faire une grande différence.',
                'priority' => 68,
            );
        }

        // 7. Cocon faible (maillage incomplet)
        $cocon_stats = self::get_cocon_stats_full();
        if ( ! empty( $cocon_stats['clusters'] ) ) {
            $weakest = null;
            $weakest_density = 100;
            foreach ( $cocon_stats['clusters'] as $cl ) {
                $density = $cl['density'] ?? 100;
                if ( $density < $weakest_density ) {
                    $weakest_density = $density;
                    $weakest = $cl;
                }
            }
            if ( $weakest && $weakest_density < 40 ) {
                $alerts[] = array(
                    'type'     => 'cocon_weak',
                    'severity' => 'info',
                    'icon'     => "\xF0\x9F\x95\xB8\xEF\xB8\x8F",
                    'text'     => 'Le cocon « ' . ( $weakest['name'] ?? 'principal' ) . ' » n\u0027a que ' . $weakest_density . '% de maillage. Quelques liens internes pourraient le renforcer.',
                    'priority' => 55,
                );
            }
        }

        // 8. GSC non connectée
        $gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new \HTS_GSC_Connect() )->is_connected();
        $gsc_csv = ! empty( get_option( 'hts_gsc_queries', array() ) );
        if ( ! $gsc_connected && ! $gsc_csv ) {
            $alerts[] = array(
                'type'     => 'no_gsc',
                'severity' => 'info',
                'icon'     => "\xF0\x9F\x94\x97",
                'text'     => 'Connectez la Search Console pour que je puisse suivre vos positions et détecter les baisses de trafic automatiquement.',
                'priority' => 45,
            );
        }

        // 9. Embeddings faibles
        $embed_coverage = self::get_embeddings_coverage();
        if ( $embed_coverage !== null && $embed_coverage < 50 ) {
            $alerts[] = array(
                'type'     => 'embeddings_low',
                'severity' => 'info',
                'icon'     => "\xF0\x9F\xA7\xAC",
                'text'     => 'Seulement ' . $embed_coverage . '% de vos articles ont des embeddings. Lancez une indexation pour améliorer mes recommandations.',
                'priority' => 40,
            );
        }

        // ── Trier par priorité et prendre les top 3 ──
        usort( $alerts, function( $a, $b ) {
            return ( $b['priority'] ?? 0 ) - ( $a['priority'] ?? 0 );
        } );
        $top_alerts = array_slice( $alerts, 0, 3 );

        // ── Construire le message ──
        $parts = array();
        $parts[] = '**' . $time_greeting . ( $firstname ? ', ' . $firstname : '' ) . ' !** Je suis votre Coach SEO.';

        if ( empty( $top_alerts ) ) {
            // Pas d'alerte — message positif générique
            if ( $avg_score !== null && $avg_score >= 70 ) {
                $parts[] = 'Votre site se porte bien avec un score moyen de ' . $avg_score . '/100. Voyons comment aller encore plus loin.';
            } else {
                $parts[] = 'Je connais les scores de votre site, vos articles et votre trafic. Posez-moi n\u0027importe quelle question sur votre référencement.';
            }
        } else {
            // Intro contextuelle
            $has_critical = false;
            foreach ( $top_alerts as $a ) {
                if ( in_array( $a['severity'] ?? '', array( 'critical', 'warning' ), true ) ) {
                    $has_critical = true;
                    break;
                }
            }
            if ( $has_critical ) {
                $parts[] = 'Voici ce que j\u0027ai repéré depuis ma dernière analyse :';
            } else {
                $parts[] = 'Voici les points que je voulais porter à votre attention :';
            }
        }

        // ── Sprint 4.4: Suggestions contextuelles multiples ──
        $suggestions = array();

        // Générer des suggestions basées sur chaque alerte active
        $suggestion_map = array(
            'health_critical'  => 'Lancer un diagnostic complet',
            'health_warning'   => 'Vérifier les avertissements de mon site',
            'gsc_drop'         => 'Analyser les pages qui ont baissé',
            'gsc_growth'       => 'Quelles pages performent le mieux ?',
            'position_drop'    => 'Quelles pages ont perdu des positions ?',
            'pending_actions'  => 'Passer en revue mes actions en attente',
            'drafts_ready'     => 'Planifier la publication de mes brouillons',
            'score_low'        => 'Par où commencer pour améliorer mon score ?',
            'worst_page'       => 'Comment améliorer ma pire page ?',
            'cocon_weak'       => 'Renforcer le maillage de mon cocon le plus faible',
            'no_gsc'           => 'Comment connecter la Search Console ?',
            'embeddings_low'   => 'Lancer l\u0027indexation des embeddings',
        );

        // 1. Suggestions des alertes détectées
        foreach ( $top_alerts as $alert ) {
            $type = $alert['type'] ?? '';
            if ( isset( $suggestion_map[ $type ] ) ) {
                $suggestions[] = $suggestion_map[ $type ];
            }
        }

        // 2. Ajouter des suggestions génériques pour compléter (max 4 total)
        $generic = array(
            'Fais-moi un plan d\u0027action SEO pour cette semaine',
            'Analyse mon site',
            'Optimise mes 5 pires metas',
            'Montre-moi mes cocons sémantiques',
        );
        foreach ( $generic as $g ) {
            if ( count( $suggestions ) >= 4 ) break;
            if ( ! in_array( $g, $suggestions, true ) ) {
                $suggestions[] = $g;
            }
        }

        // Le nudge reste le premier pour rétro-compatibilité
        $nudge = ! empty( $suggestions ) ? $suggestions[0] : null;

        return array(
            'greeting'    => implode( "\n\n", $parts ),
            'alerts'      => $top_alerts,
            'nudge'       => $nudge,
            'suggestions' => array_values( array_slice( $suggestions, 0, 4 ) ),
        );
    }

    /**
     * H.6 — AJAX : suggestions de démarrage + welcome proactif.
     *
     * Retourne les suggestions dynamiques, le contexte sidebar résumé,
     * et le message de bienvenue personnalisé (Sprint 3.2).
     *
     * @since 3.3.0
     * @since 4.0.0 Sprint 3.2 — ajout welcome proactif
     */
    public function ajax_startup() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Acces refuse.' ), 403 );
        }

        $suggestions = self::get_startup_suggestions();
        $welcome     = self::build_proactive_welcome();

        // Mini résumé pour la sidebar
        $summary = array(
            'score_global'     => self::get_average_score(),
            'score_geo'        => self::get_average_geo_score(),
            'pending_actions'  => self::get_pending_count(),
            'total_posts'      => (int) wp_count_posts( 'post' )->publish,
        );

        wp_send_json_success( array(
            'suggestions' => $suggestions,
            'summary'     => $summary,
            'welcome'     => $welcome,
        ) );
    }

    /**
     * H.6 — AJAX : diagnostic complet.
     *
     * @since 3.3.0
     */
    public function ajax_diagnostic() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Acces refuse.' ), 403 );
        }

        wp_send_json_success( array(
            'diagnostic' => self::get_diagnostic_context(),
        ) );
    }

    /**
     * H.6 — AJAX : configuration upsell (GET/POST).
     *
     * @since 3.3.0
     */
    public function ajax_upsell_config() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Acces refuse.' ), 403 );
        }

        // POST : mise à jour
        if ( ! empty( $_POST['save'] ) ) {
            $data = array(
                'enabled'  => ! empty( $_POST['enabled'] ),
                'tone'     => sanitize_text_field( wp_unslash( $_POST['tone'] ?? 'subtle' ) ),
                'features' => array(),
            );
            // Features envoyées en JSON
            if ( ! empty( $_POST['features'] ) ) {
                $raw = wp_unslash( $_POST['features'] );
                if ( is_string( $raw ) ) {
                    $raw = json_decode( $raw, true );
                }
                if ( is_array( $raw ) ) {
                    $data['features'] = $raw;
                }
            }
            self::update_upsell_config( $data );
            wp_send_json_success( array(
                'config'  => self::get_upsell_config(),
                'message' => 'Configuration upsell mise a jour.',
            ) );
        }

        // GET
        wp_send_json_success( array( 'config' => self::get_upsell_config() ) );
    }

    /* ═══════════════════════════════════════════════
     *  SPRINT 4.8 — COACH ANALYTICS DASHBOARD
     * ═══════════════════════════════════════════════ */

    /**
     * Sprint 4.8 : AJAX endpoint — retourne les données analytics du Coach.
     *
     * Paramètres GET/POST :
     * - period : '7d' (default), '30d', '90d', 'all'
     *
     * @since 4.0.0 Sprint 4.8
     */
    public function ajax_coach_analytics() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(1);

        global $wpdb;
        $table = $wpdb->prefix . self::ANALYTICS_TABLE;

        // Vérifier que la table existe
        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            wp_send_json_success( array( 'empty' => true, 'message' => 'Aucune donnée analytics. La table sera créée au prochain message Coach.' ) );
        }

        $period = sanitize_key( $_POST['period'] ?? '30d' );
        $days = 30;
        if ( $period === '7d' )  $days = 7;
        if ( $period === '90d' ) $days = 90;
        if ( $period === 'all' ) $days = 9999;

        $since = wp_date( 'Y-m-d', strtotime( "-{$days} days" ) );

        // ── KPIs globaux ──
        $totals = $wpdb->get_row( $wpdb->prepare(
            "SELECT
                COUNT(*) AS total_requests,
                SUM(tokens_in) AS total_tokens_in,
                SUM(tokens_out) AS total_tokens_out,
                AVG(latency_ms) AS avg_latency,
                MIN(latency_ms) AS min_latency,
                MAX(latency_ms) AS max_latency,
                SUM(has_chart) AS charts_generated,
                SUM(has_actions) AS with_actions,
                SUM(has_plan) AS plans_generated,
                SUM(CASE WHEN feedback = 1 THEN 1 ELSE 0 END) AS thumbs_up,
                SUM(CASE WHEN feedback = -1 THEN 1 ELSE 0 END) AS thumbs_down,
                SUM(CASE WHEN error_code IS NOT NULL AND error_code != '' THEN 1 ELSE 0 END) AS errors
             FROM {$table}
             WHERE created_at >= %s",
            $since
        ), ARRAY_A );

        // ── Breakdown par intent ──
        $by_intent = $wpdb->get_results( $wpdb->prepare(
            "SELECT intent, COUNT(*) AS cnt,
                    SUM(tokens_in + tokens_out) AS total_tokens,
                    AVG(latency_ms) AS avg_latency
             FROM {$table}
             WHERE created_at >= %s
             GROUP BY intent ORDER BY cnt DESC",
            $since
        ), ARRAY_A );

        // ── Breakdown par provider/model ──
        $by_model = $wpdb->get_results( $wpdb->prepare(
            "SELECT provider, model, COUNT(*) AS cnt,
                    SUM(tokens_in + tokens_out) AS total_tokens
             FROM {$table}
             WHERE created_at >= %s
             GROUP BY provider, model ORDER BY cnt DESC",
            $since
        ), ARRAY_A );

        // ── Volume quotidien (pour chart) ──
        $daily = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(created_at) AS day, COUNT(*) AS requests,
                    SUM(tokens_in + tokens_out) AS tokens,
                    AVG(latency_ms) AS avg_latency
             FROM {$table}
             WHERE created_at >= %s
             GROUP BY DATE(created_at) ORDER BY day ASC",
            $since
        ), ARRAY_A );

        // ── Top 10 questions (preview) ──
        $top_questions = $wpdb->get_results( $wpdb->prepare(
            "SELECT question_preview, intent, feedback, latency_ms, created_at
             FROM {$table}
             WHERE created_at >= %s AND question_preview IS NOT NULL AND question_preview != ''
             ORDER BY created_at DESC LIMIT 20",
            $since
        ), ARRAY_A );

        // ── Tools usage ──
        $tools_raw = $wpdb->get_results( $wpdb->prepare(
            "SELECT tools_used FROM {$table}
             WHERE created_at >= %s AND tools_used IS NOT NULL AND tools_used != ''",
            $since
        ), ARRAY_A );
        $tools_count = array();
        foreach ( $tools_raw as $row ) {
            $tools = explode( ',', $row['tools_used'] );
            foreach ( $tools as $t ) {
                $t = trim( $t );
                if ( ! empty( $t ) ) {
                    $tools_count[ $t ] = ( $tools_count[ $t ] ?? 0 ) + 1;
                }
            }
        }
        arsort( $tools_count );

        // ── Coût estimé (tarifs Anthropic + OpenAI approx.) ──
        $cost_data = $wpdb->get_results( $wpdb->prepare(
            "SELECT provider, model,
                    SUM(tokens_in) AS total_in,
                    SUM(tokens_out) AS total_out
             FROM {$table}
             WHERE created_at >= %s
             GROUP BY provider, model",
            $since
        ), ARRAY_A );
        $estimated_cost = 0.0;
        foreach ( $cost_data as $cd ) {
            $in  = (int) $cd['total_in'];
            $out = (int) $cd['total_out'];
            $m   = $cd['model'] ?? '';
            // Tarifs approx USD par million tokens (input/output)
            if ( strpos( $m, 'haiku' ) !== false ) {
                $estimated_cost += ( $in * 0.80 + $out * 4.00 ) / 1000000;
            } elseif ( strpos( $m, 'sonnet' ) !== false ) {
                $estimated_cost += ( $in * 3.00 + $out * 15.00 ) / 1000000;
            } elseif ( strpos( $m, '4o-mini' ) !== false ) {
                $estimated_cost += ( $in * 0.15 + $out * 0.60 ) / 1000000;
            } elseif ( strpos( $m, '4.1-mini' ) !== false ) {
                $estimated_cost += ( $in * 0.40 + $out * 1.60 ) / 1000000;
            } else {
                // Fallback generic
                $estimated_cost += ( $in * 1.00 + $out * 3.00 ) / 1000000;
            }
        }

        // ── Satisfaction score ──
        $total_fb = ( (int) ( $totals['thumbs_up'] ?? 0 ) ) + ( (int) ( $totals['thumbs_down'] ?? 0 ) );
        $satisfaction = $total_fb > 0 ? round( ( (int) $totals['thumbs_up'] / $total_fb ) * 100 ) : null;

        wp_send_json_success( array(
            'period'         => $period,
            'days'           => $days,
            'totals'         => $totals,
            'by_intent'      => $by_intent,
            'by_model'       => $by_model,
            'daily'          => $daily,
            'top_questions'  => $top_questions,
            'tools_usage'    => $tools_count,
            'estimated_cost' => round( $estimated_cost, 4 ),
            'satisfaction'   => $satisfaction,
        ) );
    }

    /**
     * Sprint 4.8 : AJAX endpoint — enregistre un feedback (thumbs up/down) sur un message.
     *
     * Paramètres POST :
     * - message_id : ID du message dans hts_coach_messages
     * - feedback   : 1 (good) ou -1 (bad)
     *
     * Met à jour la dernière entrée analytics correspondante.
     *
     * @since 4.0.0 Sprint 4.8
     */
    /**
     * Sprint 5.4b: AJAX — Envoie les actions d'un plan SEO vers l'Inbox.
     * Appelé quand l'utilisateur clique "Appliquer ce plan dans l'Inbox".
     * Distingue les actions automatisables (→ Inbox) des actions manuelles (→ info).
     */
    public function ajax_apply_seo_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(2);

        $plan_json = wp_unslash( $_POST['seo_plan'] ?? '' );
        $plan = json_decode( $plan_json, true );

        if ( ! is_array( $plan ) || empty( $plan['phases'] ) ) {
            wp_send_json_error( array( 'message' => 'Plan SEO invalide ou vide.' ) );
        }

        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) {
            wp_send_json_error( array( 'message' => 'Workflow Engine non disponible.' ) );
        }

        // Actions automatisables = celles qui ont un module dans AGENT_ACTION_CATALOG
        $automatable_types = array_keys( self::AGENT_ACTION_CATALOG );

        $created  = 0;
        $skipped  = 0;
        $manual   = array();

        foreach ( $plan['phases'] as $phase ) {
            if ( ! is_array( $phase ) || empty( $phase['actions'] ) ) continue;

            foreach ( $phase['actions'] as $action ) {
                if ( ! is_array( $action ) ) continue;

                $post_id    = absint( $action['post_id'] ?? 0 );
                $type       = sanitize_key( $action['action'] ?? 'coach_suggestion' );
                $task       = sanitize_text_field( $action['task'] ?? '' );
                $title      = sanitize_text_field( $action['title'] ?? '' );
                $priority   = sanitize_key( $action['priority'] ?? 'medium' );
                $phase_name = sanitize_text_field( $phase['name'] ?? '' );

                // Valider priorité
                if ( ! in_array( $priority, array( 'low', 'medium', 'high', 'critical' ), true ) ) {
                    $priority = 'medium';
                }

                $reason = $task ?: ( $title ? 'Plan SEO : ' . $title : 'Action du plan SEO' );

                // Vérifier si le type est automatisable
                if ( ! in_array( $type, $automatable_types, true ) ) {
                    // Action manuelle : on ne l'envoie pas dans l'Inbox
                    $manual[] = array(
                        'title'  => $title,
                        'task'   => $task,
                        'type'   => $type,
                        'phase'  => $phase_name,
                    );
                    continue;
                }

                // Valider le type dans la liste autorisée
                if ( ! in_array( $type, self::COACH_ACTION_TYPES, true ) ) {
                    $type = 'coach_suggestion';
                }

                $id = HTS_Workflow_Engine::propose(
                    'coach',
                    $type,
                    $post_id,
                    array(
                        'reason'   => $reason,
                        'source'   => 'coach_ai',
                        'seo_plan' => true,
                        'phase'    => $phase_name,
                    ),
                    $priority
                );

                if ( $id ) {
                    $created++;
                } else {
                    $skipped++;
                }
            }
        }

        $msg_parts = array();
        if ( $created > 0 ) {
            $msg_parts[] = sprintf( '%d action%s envoyée%s dans l\'Inbox', $created, $created > 1 ? 's' : '', $created > 1 ? 's' : '' );
        }
        if ( $skipped > 0 ) {
            $msg_parts[] = sprintf( '%d déjà en attente', $skipped );
        }
        if ( ! empty( $manual ) ) {
            $msg_parts[] = sprintf( '%d action%s manuelle%s (voir ci-dessous)', count( $manual ), count( $manual ) > 1 ? 's' : '', count( $manual ) > 1 ? 's' : '' );
        }

        wp_send_json_success( array(
            'created' => $created,
            'skipped' => $skipped,
            'manual'  => $manual,
            'message' => ! empty( $msg_parts ) ? implode( ', ', $msg_parts ) . '.' : 'Aucune action à traiter.',
        ) );
    }

    public function ajax_coach_feedback() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }

        $feedback = (int) ( $_POST['feedback'] ?? 0 );
        if ( ! in_array( $feedback, array( -1, 1 ), true ) ) {
            wp_send_json_error( array( 'message' => 'Feedback invalide (-1 ou 1).' ) );
        }

        $session_id = absint( $_POST['session_id'] ?? 0 );
        $user_id    = get_current_user_id();

        global $wpdb;
        $table = $wpdb->prefix . self::ANALYTICS_TABLE;

        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            wp_send_json_error( array( 'message' => 'Table analytics absente.' ) );
        }

        // Trouver la dernière entrée analytics de cette session pour cet user
        $analytics_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table}
             WHERE user_id = %d AND session_id = %d
             ORDER BY created_at DESC LIMIT 1",
            $user_id, $session_id
        ) );

        if ( ! $analytics_id ) {
            wp_send_json_error( array( 'message' => 'Aucune entrée analytics trouvée.' ) );
        }

        $wpdb->update(
            $table,
            array( 'feedback' => $feedback ),
            array( 'id' => $analytics_id ),
            array( '%d' ),
            array( '%d' )
        );

        wp_send_json_success( array(
            'analytics_id' => $analytics_id,
            'feedback'     => $feedback,
        ) );
    }

    /**
     * Sprint 4.8 : Retourne les données analytics pour affichage dans le cockpit.
     * Méthode publique statique pour usage depuis class-hts-cockpit.php.
     *
     * @since 4.0.0 Sprint 4.8
     * @param int $days
     * @return array
     */
    public static function get_analytics_summary( $days = 30 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ANALYTICS_TABLE;

        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) ) {
            return array( 'available' => false );
        }

        $since = wp_date( 'Y-m-d', strtotime( "-{$days} days" ) );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total,
                    SUM(tokens_in + tokens_out) AS tokens,
                    AVG(latency_ms) AS avg_latency,
                    SUM(CASE WHEN feedback = 1 THEN 1 ELSE 0 END) AS up,
                    SUM(CASE WHEN feedback = -1 THEN 1 ELSE 0 END) AS down
             FROM {$table} WHERE created_at >= %s",
            $since
        ), ARRAY_A );

        return array(
            'available'    => true,
            'total'        => (int) ( $row['total'] ?? 0 ),
            'tokens'       => (int) ( $row['tokens'] ?? 0 ),
            'avg_latency'  => (int) ( $row['avg_latency'] ?? 0 ),
            'thumbs_up'    => (int) ( $row['up'] ?? 0 ),
            'thumbs_down'  => (int) ( $row['down'] ?? 0 ),
        );
    }

    /* ═══════════════════════════════════════════════
     *  WEEKLY REPORT — Rapport SEO Hebdomadaire (S13-B)
     *  Pré-généré par Haiku le lundi à 6h, stocké en option WP.
     *  Le client voit le rapport instantanément en ouvrant le Coach.
     * ═══════════════════════════════════════════════ */

    const WEEKLY_REPORT_OPT = 'hts_coach_weekly_report';

    /**
     * Cron: génère le rapport hebdomadaire.
     */
    public static function cron_generate_weekly_report() {
        $lock_key = 'hts_lock_weekly_report';
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, 120 );

        try {
            // Vérifier qu'une clé API est disponible
            $api_key = self::get_api_key();
            if ( empty( $api_key ) ) {
                delete_transient( $lock_key );
                return;
            }

            $report = self::generate_weekly_report();
            if ( $report ) {
                update_option( self::WEEKLY_REPORT_OPT, $report, false );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Weekly report generated: ' . ( $report['title'] ?? 'OK' ), 'success', 'coach' );
                }
            }
            delete_transient( $lock_key );
        } catch ( \Throwable $e ) {
            delete_transient( $lock_key );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'cron', 'coach_weekly_report error: ' . $e->getMessage() );
            }
        }
    }

    /**
     * Génère le rapport hebdomadaire complet.
     * Architecture : PHP construit les data (100% fiable), Haiku ajoute les insights (expert).
     */
    public static function generate_weekly_report() {
        $report = self::build_report_data();
        if ( ! $report ) return null;

        $api_key = self::get_api_key();
        if ( ! empty( $api_key ) ) {
            $insights = self::generate_report_insights( $report, $api_key );
            if ( $insights ) {
                $report['insights']              = $insights['insights'] ?? array();
                $report['recommendations']       = $insights['recommendations'] ?? array();
                $report['summary']               = $insights['summary'] ?? '';
                $report['section_performance']   = $insights['section_performance'] ?? '';
                $report['section_gsc']           = $insights['section_gsc'] ?? '';
                $report['section_quickwins']     = $insights['section_quickwins'] ?? '';
                $report['section_geo']           = $insights['section_geo'] ?? '';
                $report['section_activity']      = $insights['section_activity'] ?? '';
                $report['section_impact']        = $insights['section_impact'] ?? '';
                $report['section_opportunities'] = $insights['section_opportunities'] ?? '';
            }
        }

        $report['generated_at'] = current_time( 'mysql' );
        $report['week_start']   = wp_date( 'Y-m-d', strtotime( 'monday this week' ) );
        $report['week_end']     = wp_date( 'Y-m-d', strtotime( 'sunday this week' ) );

        return $report;
    }

    /**
     * PHP Report Builder — 100% data-driven, ZERO hallucination.
     * Adaptatif: montre SEULEMENT les sections avec de la vraie data.
     */
    public static function build_report_data() {
        $site_name = get_bloginfo( 'name' );
        // Monday of current week (works correctly on Monday AND on other days)
        $monday_ts = strtotime( 'monday this week' );
        $date_lbl  = wp_date( 'j F Y', $monday_ts );
        $date_end  = wp_date( 'j F Y' );

        $global_score = self::get_average_score();
        $geo_avg      = self::get_average_geo_score();
        $gsc          = self::get_gsc_summary();
        $gsc_delta    = self::get_gsc_delta();
        $pages_all    = self::get_pages_overview( 30 );

        // Guard: need at least 1 scored page for a meaningful report
        if ( empty( $pages_all ) && $global_score <= 0 ) {
            return null;
        }
        $pending      = self::get_pending_count();
        $inbox_types  = self::get_inbox_by_type();
        $cocons       = self::get_cocon_stats_full();
        $chantiers    = self::get_chantiers_en_cours();
        $health       = self::get_health_alerts();
        $drafts       = self::get_drafts_ready_to_publish();
        $publications = self::get_recent_publications( 10 );
        $ai_crawl     = self::get_ai_crawl_summary();
        $total_posts  = (int) wp_count_posts( 'post' )->publish;
        $total_pages  = (int) wp_count_posts( 'page' )->publish;

        // ── Detect data availability ──
        $has_gsc = ! empty( $gsc['connected'] ) && ! empty( $gsc['data'] );
        $has_delta = ! empty( $gsc_delta['available'] ) && ! empty( $gsc_delta['7d'] );

        $clicks      = $has_gsc ? (int) ( $gsc['total_clicks'] ?? 0 ) : 0;
        $impressions = $has_gsc ? (int) ( $gsc['impressions'] ?? 0 ) : 0;
        $avg_pos     = $has_gsc ? round( (float) ( $gsc['avg_position'] ?? 0 ), 1 ) : 0;

        $click_delta = '';
        $click_trend = 'neutral';
        if ( $has_delta && ! empty( $gsc_delta['7d']['clicks'] ) ) {
            $click_delta = $gsc_delta['7d']['clicks'];
            $click_trend = strpos( $click_delta, '+' ) === 0 ? 'up' : ( strpos( $click_delta, '-' ) === 0 ? 'down' : 'neutral' );
        }

        // ── KPIs — only show what we have ──
        $kpis = array(
            array( 'label' => 'Score SEO', 'value' => $global_score > 0 ? (string) round( $global_score ) : 'N/D', 'unit' => '/100', 'trend' => $global_score >= 70 ? 'up' : ( $global_score > 0 && $global_score < 40 ? 'down' : 'neutral' ), 'delta' => '' ),
            array( 'label' => 'Visibilite IA', 'value' => $geo_avg > 0 ? (string) round( $geo_avg ) : 'N/D', 'unit' => '/100', 'trend' => $geo_avg >= 50 ? 'up' : ( $geo_avg > 0 && $geo_avg < 25 ? 'down' : 'neutral' ), 'delta' => '' ),
            array( 'label' => 'Contenus', 'value' => (string) ( $total_posts + $total_pages ), 'unit' => 'publies', 'trend' => 'neutral', 'delta' => '' ),
        );

        if ( $has_gsc ) {
            $kpis[] = array( 'label' => 'Trafic organique', 'value' => (string) $clicks, 'unit' => 'clics/30j', 'trend' => $click_trend, 'delta' => $click_delta );
            $kpis[] = array( 'label' => 'Impressions', 'value' => $impressions > 999 ? number_format( $impressions / 1000, 1 ) . 'K' : (string) $impressions, 'unit' => '/30j', 'trend' => 'neutral', 'delta' => $has_delta && ! empty( $gsc_delta['7d']['impressions'] ) ? $gsc_delta['7d']['impressions'] : '' );
            $kpis[] = array( 'label' => 'Position moy.', 'value' => $avg_pos > 0 ? (string) $avg_pos : 'N/D', 'unit' => '', 'trend' => $avg_pos > 0 && $avg_pos <= 10 ? 'up' : ( $avg_pos > 30 ? 'down' : 'neutral' ), 'delta' => '' );
            $avg_ctr = ! empty( $gsc['avg_ctr'] ) ? round( (float) $gsc['avg_ctr'], 2 ) : 0;
            $kpis[] = array( 'label' => 'CTR moyen', 'value' => $avg_ctr > 0 ? (string) $avg_ctr . '%' : 'N/D', 'unit' => '', 'trend' => $avg_ctr >= 2 ? 'up' : ( $avg_ctr > 0 && $avg_ctr < 0.5 ? 'down' : 'neutral' ), 'delta' => '' );
        } else {
            $kpis[] = array( 'label' => 'Google Search', 'value' => 'Non connecte', 'unit' => '', 'trend' => 'down', 'delta' => '' );
            $kpis[] = array( 'label' => 'Maillage', 'value' => is_array( $cocons ) && count( $cocons ) > 0 ? (string) count( $cocons ) . ' cocons' : '0 cocon', 'unit' => '', 'trend' => ! empty( $cocons ) ? 'up' : 'down', 'delta' => '' );
            $kpis[] = array( 'label' => 'Actions', 'value' => (string) $pending, 'unit' => 'en attente', 'trend' => 'neutral', 'delta' => '' );
        }

        // ── Charts ──

        // Chart 1: Radar — only include axes with real data
        $dims = array();
        $has_breakdown = false;
        foreach ( $pages_all as $p ) {
            $bd = get_post_meta( $p['id'], '_hts_score_breakdown', true );
            if ( is_array( $bd ) ) {
                $has_breakdown = true;
                if ( isset( $bd['technical'] ) )  $dims['Technique'][]  = (float) $bd['technical'];
                if ( isset( $bd['content'] ) )    $dims['Contenu'][]    = (float) $bd['content'];
                if ( isset( $bd['freshness'] ) )  $dims['Fraicheur'][]  = (float) $bd['freshness'];
            }
            $dims['GEO'][] = (float) $p['geo_score'];
            $ml = ( $p['links_in'] + $p['links_out'] ) > 0 ? min( 100, ( $p['links_in'] + $p['links_out'] ) * 10 ) : 0;
            $dims['Maillage'][] = $ml;
        }

        // If no breakdown: use simpler radar with just 3 axes
        $radar_labels = array();
        $radar_data   = array();
        if ( $has_breakdown ) {
            foreach ( $dims as $l => $v ) {
                if ( ! empty( $v ) ) {
                    $radar_labels[] = $l;
                    $radar_data[]   = round( array_sum( $v ) / count( $v ) );
                }
            }
        } else {
            // Fallback: 3-axis radar from global data
            if ( $global_score > 0 ) {
                $radar_labels = array( 'SEO', 'GEO', 'Maillage' );
                $geo_vals = array_column( $pages_all, 'geo_score' );
                $ml_vals = array();
                foreach ( $pages_all as $p ) {
                    $ml_vals[] = ( $p['links_in'] + $p['links_out'] ) > 0 ? min( 100, ( $p['links_in'] + $p['links_out'] ) * 10 ) : 0;
                }
                $radar_data = array(
                    round( $global_score ),
                    ! empty( $geo_vals ) ? round( array_sum( $geo_vals ) / count( $geo_vals ) ) : 0,
                    ! empty( $ml_vals ) ? round( array_sum( $ml_vals ) / count( $ml_vals ) ) : 0,
                );
            }
        }

        $charts = array();
        if ( ! empty( $radar_data ) && array_sum( $radar_data ) > 0 ) {
            $charts[] = array( 'type' => 'radar', 'title' => 'Score par domaine', 'labels' => $radar_labels, 'data' => $radar_data );
        }

        // Chart 2: Line — GSC timeseries (clicks + impressions over time)
        if ( $has_gsc ) {
            $ts = self::get_gsc_timeseries();
            if ( $ts ) {
                $charts[] = array( 'type' => 'line', 'title' => 'Évolution du trafic organique', 'labels' => $ts['labels'], 'data' => $ts['clicks'], 'data2' => $ts['impressions'] );
            }
        }

        // Chart 3: Bar — GSC top pages (only if GSC)
        if ( $has_gsc ) {
            $pbc = $pages_all;
            usort( $pbc, function( $a, $b ) { return ( $b['gsc_clicks'] ?? 0 ) - ( $a['gsc_clicks'] ?? 0 ); } );
            $bar_labels = array();
            $bar_data   = array();
            foreach ( array_slice( $pbc, 0, 8 ) as $p ) {
                if ( ( $p['gsc_clicks'] ?? 0 ) <= 0 ) continue;
                $t = $p['title'];
                if ( mb_strlen( $t ) > 26 ) $t = mb_substr( $t, 0, 24 ) . '..';
                $bar_labels[] = $t;
                $bar_data[]   = (int) $p['gsc_clicks'];
            }
            if ( ! empty( $bar_data ) && count( $bar_data ) >= 2 ) {
                $charts[] = array( 'type' => 'bar', 'title' => 'Top pages par clics (30j)', 'labels' => $bar_labels, 'data' => $bar_data );
            }
        }

        // Chart 3 (if no GSC): Score distribution doughnut
        if ( ! $has_gsc && count( $pages_all ) >= 5 ) {
            $above80 = 0; $s50_80 = 0; $below50 = 0;
            foreach ( $pages_all as $p ) {
                $s = $p['global_score'];
                if ( $s >= 80 ) $above80++;
                elseif ( $s >= 50 ) $s50_80++;
                else $below50++;
            }
            // Only show doughnut if at least 2 non-zero segments
            $non_zero = ( $above80 > 0 ? 1 : 0 ) + ( $s50_80 > 0 ? 1 : 0 ) + ( $below50 > 0 ? 1 : 0 );
            if ( $non_zero >= 2 ) {
                $charts[] = array( 'type' => 'doughnut', 'title' => 'Repartition des scores', 'labels' => array( '80+', '50-79', '<50' ), 'data' => array( $above80, $s50_80, $below50 ) );
            }
        }

        // ── Tables ──

        // Table 1: Performance pages — ADAPTIVE columns
        $sort_pages = $pages_all;
        if ( $has_gsc ) {
            usort( $sort_pages, function( $a, $b ) { return ( $b['gsc_clicks'] ?? 0 ) - ( $a['gsc_clicks'] ?? 0 ); } );
        } else {
            usort( $sort_pages, function( $a, $b ) { return $a['global_score'] - $b['global_score']; } );
        }

        $perf_headers = array( 'Page', 'Score', 'GEO' );
        if ( $has_gsc ) {
            $perf_headers = array_merge( $perf_headers, array( 'Clics', 'Pos.', 'CTR' ) );
        }
        $perf_headers[] = 'Diagnostic';

        $perf_rows = array();
        foreach ( array_slice( $sort_pages, 0, 10 ) as $p ) {
            $d = self::diagnose_page( $p );
            $t = $p['title'];
            if ( mb_strlen( $t ) > 36 ) $t = mb_substr( $t, 0, 34 ) . '..';
            $row = array( $t, (string) round( $p['global_score'] ), (string) round( $p['geo_score'] ) );
            if ( $has_gsc ) {
                $row[] = (string) ( $p['gsc_clicks'] ?? 0 );
                $row[] = ( $p['gsc_position'] ?? 0 ) > 0 ? (string) round( $p['gsc_position'], 1 ) : '-';
                $ctr_val = (float) ( $p['gsc_ctr'] ?? 0 );
                // CTR can be stored as decimal (0.0122) or percentage (1.22). Normalize.
                $ctr_pct = $ctr_val > 1 ? round( $ctr_val, 2 ) : round( $ctr_val * 100, 2 );
                $row[] = $ctr_pct > 0 ? (string) $ctr_pct . '%' : '-';
            }
            $row[] = $d;
            $perf_rows[] = $row;
        }

        // Table 2: Actions de la semaine — TRANSLATED labels
        $act_rows = array();
        if ( ! empty( $chantiers['recently_executed'] ) ) {
            foreach ( array_slice( $chantiers['recently_executed'], 0, 5 ) as $ch ) {
                $act_rows[] = array( self::translate_action_type( $ch['type'] ?? '' ), (string) ( $ch['count'] ?? 0 ) . ' page(s)', 'Fait', 'Appliqué' );
            }
        }
        if ( ! empty( $publications ) ) {
            foreach ( array_slice( $publications, 0, 3 ) as $pub ) {
                $t_pub = sanitize_text_field( $pub['title'] ?? '' );
                if ( mb_strlen( $t_pub ) > 40 ) $t_pub = mb_substr( $t_pub, 0, 38 ) . '..';
                $act_rows[] = array( 'Article publié', $t_pub, wp_date( 'j M', strtotime( $pub['date'] ?? '' ) ), 'En ligne' );
            }
        }
        if ( ! empty( $inbox_types ) ) {
            foreach ( array_slice( $inbox_types, 0, 3 ) as $it ) {
                $act_rows[] = array( self::translate_action_type( $it['type'] ?? '' ), (string) ( $it['count'] ?? 0 ) . ' en attente', 'À faire', 'Prioritaire' );
            }
        }

        // Table 3: Opportunites
        $opps = self::find_opportunities( $pages_all, $cocons );
        $opp_rows = array();
        foreach ( array_slice( $opps, 0, 8 ) as $o ) {
            $opp_rows[] = array( sanitize_text_field( $o['opportunity'] ), sanitize_text_field( $o['page'] ), sanitize_text_field( $o['effort'] ), sanitize_text_field( $o['impact'] ) );
        }

        // Table 4: GSC Top Queries (if connected)
        $query_rows = array();
        if ( $has_gsc && class_exists( 'HTS_GSC_Connect' ) ) {
            $gsc_obj = new HTS_GSC_Connect();
            if ( method_exists( $gsc_obj, 'get_queries_data' ) ) {
                $queries = $gsc_obj->get_queries_data( 30 );
                foreach ( array_slice( $queries, 0, 10 ) as $q ) {
                    $q = is_array( $q ) ? $q : (array) $q;
                    $ctr_q = (float) ( $q['position'] ?? 0 );
                    $query_rows[] = array(
                        sanitize_text_field( $q['query'] ?? '' ),
                        (string) ( $q['clicks'] ?? 0 ),
                        (string) ( $q['impressions'] ?? 0 ),
                        $ctr_q > 0 ? (string) round( $ctr_q, 1 ) : '-',
                    );
                }
            }
        }

        // Table 5: Quick Wins — pages position 11-20 (page 2 → push to page 1)
        $qw_rows = array();
        if ( $has_gsc ) {
            $page2 = array_filter( $pages_all, function( $p ) {
                $pos = (float) ( $p['gsc_position'] ?? 0 );
                return $pos >= 11 && $pos <= 20 && ( $p['gsc_impressions'] ?? 0 ) > 50;
            });
            usort( $page2, function( $a, $b ) {
                return ( $a['gsc_position'] ?? 99 ) - ( $b['gsc_position'] ?? 99 );
            });
            foreach ( array_slice( $page2, 0, 5 ) as $p ) {
                $t = mb_strlen( $p['title'] ) > 33 ? mb_substr( $p['title'], 0, 31 ) . '..' : $p['title'];
                $qw_rows[] = array(
                    $t,
                    (string) round( $p['gsc_position'], 1 ),
                    (string) ( $p['gsc_impressions'] ?? 0 ),
                    (string) ( $p['gsc_clicks'] ?? 0 ),
                    empty( $p['meta_title'] ) ? 'Meta manquante' : ( $p['links_in'] == 0 ? '0 lien entrant' : 'Contenu à enrichir' ),
                );
            }
        }

        // Table 6: Feedback Loop — impact of recent actions (if available)
        $impact_rows = array();
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            global $wpdb;
            $act_table = $wpdb->prefix . 'hts_actions';
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $act_table ) ) === $act_table ) {
                $recent_impacts = $wpdb->get_results(
                    "SELECT action_type, post_id, impact_7d, created_at
                     FROM {$act_table}
                     WHERE impact_7d IS NOT NULL AND impact_7d != ''
                     ORDER BY created_at DESC LIMIT 5",
                    ARRAY_A
                );
                foreach ( $recent_impacts as $imp ) {
                    $impact = json_decode( $imp['impact_7d'], true );
                    if ( ! is_array( $impact ) ) continue;
                    $title = get_the_title( $imp['post_id'] );
                    if ( mb_strlen( $title ) > 30 ) $title = mb_substr( $title, 0, 28 ) . '..';
                    $verdict = $impact['verdict'] ?? 'inconnu';
                    $pos_delta = isset( $impact['position_delta'] ) ? round( $impact['position_delta'], 1 ) : '-';
                    $click_delta = isset( $impact['clicks_delta'] ) ? (string) $impact['clicks_delta'] : '-';
                    $impact_rows[] = array(
                        self::translate_action_type( $imp['action_type'] ),
                        $title,
                        ( $pos_delta > 0 ? '+' : '' ) . $pos_delta,
                        ( is_numeric( $click_delta ) && $click_delta > 0 ? '+' : '' ) . $click_delta,
                        ucfirst( $verdict ),
                    );
                }
            }
        }

        $tables = array();
        if ( ! empty( $perf_rows ) ) {
            $tables[] = array( 'title' => 'Performance des pages', 'headers' => $perf_headers, 'rows' => $perf_rows );
        }
        if ( ! empty( $query_rows ) ) {
            $tables[] = array( 'title' => 'Top requetes Google (30j)', 'headers' => array( 'Requete', 'Clics', 'Impressions', 'Position' ), 'rows' => $query_rows );
        }
        if ( ! empty( $qw_rows ) ) {
            $tables[] = array( 'title' => 'Quick Wins — Pages en position 11-20', 'headers' => array( 'Page', 'Position', 'Impressions', 'Clics', 'Action recommandee' ), 'rows' => $qw_rows );
        }
        if ( ! empty( $impact_rows ) ) {
            $tables[] = array( 'title' => 'Impact des dernieres actions', 'headers' => array( 'Action', 'Page', 'Position \u0394', 'Clics \u0394', 'Verdict' ), 'rows' => $impact_rows );
        }
        if ( ! empty( $act_rows ) ) {
            $tables[] = array( 'title' => 'Activite de la semaine', 'headers' => array( 'Type', 'Detail', 'Statut', 'Resultat' ), 'rows' => $act_rows );
        }
        if ( ! empty( $opp_rows ) ) {
            $tables[] = array( 'title' => 'Opportunités identifiées', 'headers' => array( 'Opportunité', 'Page/Cible', 'Effort', 'Impact estimé' ), 'rows' => $opp_rows );
        }

        // ── Health summary for Haiku insights ──
        $hs = array(
            'total_content' => $total_posts + $total_pages,
            'orphan_count' => 0, 'no_meta_count' => 0,
            'low_geo_count' => 0, 'low_score_count' => 0,
            'cocon_count' => is_array( $cocons ) ? count( $cocons ) : 0,
            'drafts_count' => is_array( $drafts ) ? count( $drafts ) : 0,
            'has_gsc' => $has_gsc,
            'health_alerts' => $health,
        );
        foreach ( $pages_all as $p ) {
            if ( $p['links_in'] == 0 && $p['links_out'] == 0 ) $hs['orphan_count']++;
            if ( empty( $p['meta_title'] ) || empty( $p['meta_desc'] ) ) $hs['no_meta_count']++;
            if ( $p['geo_score'] < 30 ) $hs['low_geo_count']++;
            if ( $p['global_score'] < 50 ) $hs['low_score_count']++;
        }

        return array(
            'title'     => 'Rapport SEO — Semaine du ' . $date_lbl,
            'site_name' => $site_name,
            'kpis'      => $kpis,
            'charts'    => $charts,
            'tables'    => $tables,
            'insights'  => array(),
            'summary'   => '',
            '_health'   => $hs,
        );
    }

    /**
     * Traduit les types d'actions internes en français business.
     */
    private static function translate_action_type( $type ) {
        // S13-B: Use centralized labels from Feedback Loop (single source of truth)
        if ( class_exists( 'HTS_Feedback_Loop' ) && method_exists( 'HTS_Feedback_Loop', 'translate_action_type' ) ) {
            return HTS_Feedback_Loop::translate_action_type( $type );
        }
        // Fallback if feedback loop not loaded
        $map = array(
            'add_featured_image' => 'Ajout image à la une',
            'fix_image_alt'      => 'Correction balises images',
            'add_internal_links' => 'Ajout liens internes',
            'add_meta_desc'      => 'Ajout meta description',
            'add_meta_title'     => 'Ajout meta title',
            'optimize_meta_both' => 'Optimisation titre + description',
            'optimize_meta_title'=> 'Optimisation title',
            'optimize_meta_desc' => 'Optimisation description',
            'add_faq'            => 'Ajout FAQ structurée',
            'content_refresh'    => 'Rafraîchissement contenu',
            'geo_optimize'       => 'Optimisation visibilité IA',
            'fix_orphan_links'   => 'Correction liens orphelins',
            'bulk_optimize_metas'=> 'Optimisation metas en lot',
            'generate_article'   => 'Génération article',
            'schedule_publication'=> 'Planification publication',
            'create_cocon_articles'=> 'Création cocon sémantique',
            'delete_page'        => 'Suppression page',
            'coach_suggestion'   => 'Suggestion Coach',
        );
        return isset( $map[ $type ] ) ? $map[ $type ] : ucfirst( str_replace( '_', ' ', $type ) );
    }

    private static function diagnose_page( $page ) {
        $issues = array();
        $s = (float) ( $page['global_score'] ?? 0 );
        $g = (float) ( $page['geo_score'] ?? 0 );
        $c = (float) ( $page['gsc_ctr'] ?? 0 );
        $c_dec = $c > 1 ? $c / 100 : $c; // normalize to decimal
        $p = (float) ( $page['gsc_position'] ?? 0 );
        $li = (int) ( $page['links_in'] ?? 0 );
        $lo = (int) ( $page['links_out'] ?? 0 );
        if ( $s < 40 ) $issues[] = 'Score critique';
        if ( $li == 0 && $lo == 0 ) $issues[] = 'Orpheline';
        elseif ( $li == 0 ) $issues[] = '0 lien entrant';
        if ( empty( $page['meta_title'] ) ) $issues[] = 'Pas de meta title';
        if ( empty( $page['meta_desc'] ) ) $issues[] = 'Pas de meta desc';
        if ( $g < 20 ) $issues[] = 'GEO faible';
        if ( $p > 0 && $p <= 10 && $c_dec < 0.02 ) $issues[] = 'CTR faible top 10';
        if ( $p > 10 && $p <= 20 ) $issues[] = 'Page 2';
        if ( empty( $issues ) ) return $s >= 80 ? 'Excellente' : ( $s >= 60 ? 'Correcte' : 'A surveiller' );
        return implode( ' / ', array_slice( $issues, 0, 2 ) );
    }

    private static function find_opportunities( $pages, $cocons ) {
        $opps = array();
        $seen = array(); // dedup by page ID

        // Priority 1: High impressions, low CTR → meta optimization
        foreach ( $pages as $p ) {
            $pid = $p['id'] ?? 0;
            if ( isset( $seen[ $pid ] ) ) continue;
            $ctr_raw = (float) ( $p['gsc_ctr'] ?? 0 );
            $ctr_dec = $ctr_raw > 1 ? $ctr_raw / 100 : $ctr_raw; // normalize to decimal
            if ( ( $p['gsc_impressions'] ?? 0 ) > 300 && $ctr_dec < 0.015 ) {
                $t = mb_strlen( $p['title'] ) > 33 ? mb_substr( $p['title'], 0, 31 ) . '..' : $p['title'];
                $opps[] = array( 'opportunity' => 'Optimiser meta title/desc', 'page' => $t, 'effort' => '15 min', 'impact' => '+' . round( ( $p['gsc_impressions'] ?? 0 ) * 0.02 ) . ' clics/mois' );
                $seen[ $pid ] = true;
            }
        }
        // Priority 2: Orphans with good score
        foreach ( $pages as $p ) {
            $pid = $p['id'] ?? 0;
            if ( isset( $seen[ $pid ] ) ) continue;
            if ( $p['links_in'] == 0 && $p['links_out'] == 0 && $p['global_score'] > 60 ) {
                $t = mb_strlen( $p['title'] ) > 33 ? mb_substr( $p['title'], 0, 31 ) . '..' : $p['title'];
                $opps[] = array( 'opportunity' => 'Liens internes (orpheline)', 'page' => $t, 'effort' => '20 min', 'impact' => '+2-5 positions' );
                $seen[ $pid ] = true;
            }
        }
        // Priority 3: Low GEO with good SEO score
        foreach ( $pages as $p ) {
            $pid = $p['id'] ?? 0;
            if ( isset( $seen[ $pid ] ) ) continue;
            if ( $p['geo_score'] < 25 && $p['global_score'] > 60 ) {
                $t = mb_strlen( $p['title'] ) > 33 ? mb_substr( $p['title'], 0, 31 ) . '..' : $p['title'];
                $opps[] = array( 'opportunity' => 'FAQ structuree (GEO)', 'page' => $t, 'effort' => '25 min', 'impact' => 'GEO +20-30 pts' );
                $seen[ $pid ] = true;
            }
        }
        // Priority 4: Missing metas
        foreach ( $pages as $p ) {
            $pid = $p['id'] ?? 0;
            if ( isset( $seen[ $pid ] ) ) continue;
            if ( empty( $p['meta_title'] ) || empty( $p['meta_desc'] ) ) {
                $t = mb_strlen( $p['title'] ) > 33 ? mb_substr( $p['title'], 0, 31 ) . '..' : $p['title'];
                $m = array();
                if ( empty( $p['meta_title'] ) ) $m[] = 'title';
                if ( empty( $p['meta_desc'] ) ) $m[] = 'desc';
                $opps[] = array( 'opportunity' => 'Generer meta ' . implode( '+', $m ), 'page' => $t, 'effort' => '5 min (auto)', 'impact' => 'CTR +0.5-1%' );
                $seen[ $pid ] = true;
            }
        }
        // Priority 5: No cocons configured
        if ( empty( $cocons ) || ( is_array( $cocons ) && count( $cocons ) == 0 ) ) {
            $tp = (int) wp_count_posts( 'post' )->publish;
            if ( $tp > 10 ) {
                $opps[] = array( 'opportunity' => 'Creer 1er cocon semantique', 'page' => $tp . ' articles non structures', 'effort' => '1-2h', 'impact' => '+100 liens internes' );
            }
        }
        return array_slice( $opps, 0, 8 );
    }

    private static function generate_report_insights( $report, $api_key ) {
        $h = $report['_health'] ?? array();
        $site = $report['site_name'] ?? '';

        // Build a rich data summary for Haiku
        $kpi_lines = '';
        foreach ( $report['kpis'] ?? array() as $k ) {
            $kpi_lines .= '- ' . $k['label'] . ': ' . $k['value'] . $k['unit'] . ( $k['delta'] ? ' (' . $k['delta'] . ')' : '' ) . "\n";
        }

        // Top pages summary
        $pages_lines = '';
        $perf_table = null;
        foreach ( $report['tables'] ?? array() as $t ) {
            if ( ! empty( $t['title'] ) && strpos( $t['title'], 'Performance' ) !== false ) {
                $perf_table = $t;
                foreach ( array_slice( $t['rows'] ?? array(), 0, 5 ) as $r ) {
                    $pages_lines .= '- ' . ( $r[0] ?? '' ) . ' | Score:' . ( $r[1] ?? '' ) . ' GEO:' . ( $r[2] ?? '' );
                    if ( isset( $r[3] ) ) $pages_lines .= ' Clics:' . $r[3];
                    $pages_lines .= ' | ' . ( $r[ count( $r ) - 1 ] ?? '' ) . "\n";
                }
            }
        }

        // Opportunities summary
        $opp_lines = '';
        foreach ( $report['tables'] ?? array() as $t ) {
            if ( ! empty( $t['title'] ) && strpos( $t['title'], 'pportunit' ) !== false ) {
                foreach ( $t['rows'] ?? array() as $r ) {
                    $opp_lines .= '- ' . ( $r[0] ?? '' ) . ' → ' . ( $r[1] ?? '' ) . ' (' . ( $r[2] ?? '' ) . ', ' . ( $r[3] ?? '' ) . ")\n";
                }
            }
        }

        // Queries summary
        $query_lines = '';
        foreach ( $report['tables'] ?? array() as $t ) {
            if ( ! empty( $t['title'] ) && strpos( $t['title'], 'requetes' ) !== false ) {
                foreach ( array_slice( $t['rows'] ?? array(), 0, 5 ) as $r ) {
                    $query_lines .= '- "' . ( $r[0] ?? '' ) . '" | Clics:' . ( $r[1] ?? '' ) . ' Impr:' . ( $r[2] ?? '' ) . ' Pos:' . ( $r[3] ?? '' ) . "\n";
                }
            }
        }

        // Quick wins summary
        $qw_lines = '';
        foreach ( $report['tables'] ?? array() as $t ) {
            if ( ! empty( $t['title'] ) && strpos( $t['title'], 'Quick' ) !== false ) {
                foreach ( $t['rows'] ?? array() as $r ) {
                    $qw_lines .= '- ' . ( $r[0] ?? '' ) . ' (pos ' . ( $r[1] ?? '' ) . ', ' . ( $r[2] ?? '' ) . ' impr) → ' . ( $r[4] ?? '' ) . "\n";
                }
            }
        }

        // Impact summary
        $impact_lines = '';
        foreach ( $report['tables'] ?? array() as $t ) {
            if ( ! empty( $t['title'] ) && strpos( $t['title'], 'Impact' ) !== false ) {
                foreach ( $t['rows'] ?? array() as $r ) {
                    $impact_lines .= '- ' . ( $r[0] ?? '' ) . ' sur "' . ( $r[1] ?? '' ) . '" → Position ' . ( $r[2] ?? '' ) . ', Clics ' . ( $r[3] ?? '' ) . ' (' . ( $r[4] ?? '' ) . ")\n";
                }
            }
        }

        $prompt = 'Tu es un consultant SEO/GEO senior (15+ ans) mandaté par une agence premium. Tu rédiges le COMMENTAIRE EXPERT du rapport hebdomadaire pour "' . $site . '".

DONNÉES DU RAPPORT :
' . $kpi_lines . '
Santé du site : ' . ( $h['total_content'] ?? 0 ) . ' contenus, ' . ( $h['orphan_count'] ?? 0 ) . ' orphelines, ' . ( $h['no_meta_count'] ?? 0 ) . ' sans meta, ' . ( $h['low_geo_count'] ?? 0 ) . ' GEO<30, ' . ( $h['low_score_count'] ?? 0 ) . ' score<50, ' . ( $h['cocon_count'] ?? 0 ) . ' cocons, ' . ( $h['drafts_count'] ?? 0 ) . ' brouillons.
' . ( ! empty( $pages_lines ) ? "\nTop pages :\n" . $pages_lines : '' )
. ( ! empty( $query_lines ) ? "\nTop requêtes Google :\n" . $query_lines : '' )
. ( ! empty( $qw_lines ) ? "\nQuick Wins (pages position 11-20) :\n" . $qw_lines : '' )
. ( ! empty( $impact_lines ) ? "\nImpact des dernières actions :\n" . $impact_lines : '' )
. ( ! empty( $opp_lines ) ? "\nOpportunités détectées :\n" . $opp_lines : '' )
. ( empty( $h['has_gsc'] ) ? "\nGoogle Search Console NON connectée." : '' );

        $messages = array( array( 'role' => 'user', 'content' => 'Génère le commentaire expert en JSON strict sur PLUSIEURS LIGNES. Structure :

```json
{
  "summary": "3-5 lignes de verdict exécutif pour un CEO. Commence par le positif, puis les priorités. Ton direct et chiffré.",
  "section_performance": "2-3 lignes expliquant ce que le tableau des pages révèle. Quelles pages performent, lesquelles sont problématiques, pourquoi. Mentionne des noms de pages RÉELS.",
  "section_gsc": "2-3 lignes sur le trafic Google : CTR moyen, position moyenne, requêtes les plus performantes. Cite des requêtes RÉELLES et leur potentiel.",
  "section_quickwins": "2-3 lignes sur les pages en position 11-20 (page 2 de Google). Cite les pages par nom et explique pourquoi elles sont à portée de page 1.",
  "section_geo": "2-3 lignes sur la visibilité IA du site. Score GEO moyen, ce que ça signifie concrètement (est-ce que ChatGPT/Perplexity citent ce site ?), et 2 actions pour améliorer.",
  "section_activity": "1-2 lignes commentant les actions exécutées cette semaine. Ce qui a été fait, l\'impact attendu.",
  "section_impact": "1-2 lignes sur les résultats mesurés des actions passées (feedback loop). Quelles actions ont eu un impact positif ou négatif sur les positions/clics.",
  "section_opportunities": "2-3 lignes sur les opportunités identifiées. Prioriser : quelle est LA première action à faire cette semaine et pourquoi.",
  "recommendations": [
    {"priority": 1, "action": "Titre court de l\'action", "detail": "Explication détaillée en 2 phrases avec chiffres concrets et impact estimé.", "effort": "30 min", "impact": "Fort"},
    {"priority": 2, "action": "...", "detail": "...", "effort": "1h", "impact": "Moyen"},
    {"priority": 3, "action": "...", "detail": "...", "effort": "2h", "impact": "Fort"}
  ],
  "insights": [
    {"level": "critical", "text": "Observation chiffrée + action concrète"},
    {"level": "critical", "text": "..."},
    {"level": "high", "text": "..."},
    {"level": "high", "text": "..."},
    {"level": "positive", "text": "..."},
    {"level": "positive", "text": "..."}
  ]
}
```

RÈGLES :
- Chaque section = texte CONCRET avec des noms de pages réels, des chiffres réels, des actions spécifiques
- Les recommandations = les 3 actions les plus impactantes à faire CETTE SEMAINE
- Les insights = 2 critiques (urgences), 2 high (opportunités), 2 positifs (victoires)
- Vocabulaire CEO : pas de jargon technique, explique comme à un dirigeant non-technique
- Si GEO < 50 : insiste sur la visibilité IA comme priorité stratégique
- Si orphelines > 30% : maillage = priorité n°1
- JAMAIS inventer de chiffres. Utilise UNIQUEMENT les données fournies.' ) );

        $result = self::call_anthropic( $api_key, 'claude-haiku-4-5-20251001', $prompt, $messages, 0, 8000 );
        if ( is_wp_error( $result ) ) return null;

        $text = $result['text'] ?? '';
        // Extract JSON — try code block first, then raw
        $text = preg_replace( '/```json?\s*\n?/i', '', $text );
        $text = preg_replace( '/```/', '', $text );
        $text = preg_replace( '/,\s*([}\]])/', '$1', $text ); // trailing commas
        if ( preg_match( '/\{.*\}/s', $text, $m ) ) {
            $json = json_decode( $m[0], true );
            if ( is_array( $json ) ) {
                // Sanitize insights
                $ins = array();
                $lvl = array( 'critical', 'high', 'medium', 'low', 'positive' );
                foreach ( (array) ( $json['insights'] ?? array() ) as $i ) {
                    if ( ! is_array( $i ) || empty( $i['text'] ) ) continue;
                    $ins[] = array(
                        'level' => in_array( $i['level'] ?? '', $lvl, true ) ? $i['level'] : 'medium',
                        'text'  => sanitize_text_field( $i['text'] ),
                    );
                }
                // Sanitize recommendations
                $recs = array();
                foreach ( (array) ( $json['recommendations'] ?? array() ) as $r ) {
                    if ( ! is_array( $r ) || empty( $r['action'] ) ) continue;
                    $recs[] = array(
                        'priority' => (int) ( $r['priority'] ?? 99 ),
                        'action'   => sanitize_text_field( $r['action'] ),
                        'detail'   => sanitize_text_field( $r['detail'] ?? '' ),
                        'effort'   => sanitize_text_field( $r['effort'] ?? '' ),
                        'impact'   => sanitize_text_field( $r['impact'] ?? '' ),
                    );
                }
                return array(
                    'insights'             => array_slice( $ins, 0, 6 ),
                    'recommendations'      => array_slice( $recs, 0, 5 ),
                    'summary'              => sanitize_text_field( $json['summary'] ?? '' ),
                    'section_performance'  => sanitize_text_field( $json['section_performance'] ?? '' ),
                    'section_gsc'          => sanitize_text_field( $json['section_gsc'] ?? '' ),
                    'section_quickwins'    => sanitize_text_field( $json['section_quickwins'] ?? '' ),
                    'section_geo'          => sanitize_text_field( $json['section_geo'] ?? '' ),
                    'section_activity'     => sanitize_text_field( $json['section_activity'] ?? '' ),
                    'section_impact'       => sanitize_text_field( $json['section_impact'] ?? '' ),
                    'section_opportunities'=> sanitize_text_field( $json['section_opportunities'] ?? '' ),
                );
            }
        }
        return null;
    }

    /**
     * AJAX : récupère le dernier rapport hebdomadaire.
     */
    public function ajax_weekly_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ), 403 );
        }
        HTS_Subscription::require_tier(2);

        $report = get_option( self::WEEKLY_REPORT_OPT, null );

        if ( ! $report || ! is_array( $report ) || empty( $report['title'] ) ) {
            wp_send_json_success( array( 'has_report' => false ) );
        }

        // Vérifier fraîcheur (< 8 jours)
        $gen_time = strtotime( $report['generated_at'] ?? '2000-01-01' );
        $age_days = ( time() - $gen_time ) / DAY_IN_SECONDS;
        if ( $age_days > 8 ) {
            wp_send_json_success( array( 'has_report' => false, 'reason' => 'stale' ) );
        }

        wp_send_json_success( array(
            'has_report'   => true,
            'report'       => array_diff_key( $report, array( '_health' => 1 ) ),
            'summary_text' => $report['summary'] ?? '',
            'generated_at' => $report['generated_at'] ?? '',
            'week_start'   => $report['week_start'] ?? '',
            'week_end'     => $report['week_end'] ?? '',
        ) );
    }

    /**
     * Génère le rapport manuellement (pour test ou bouton admin).
     */
    public function ajax_generate_weekly_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Accès refusé.' ) );
        }
        HTS_Subscription::require_tier(2);

        $report = self::generate_weekly_report();
        if ( $report ) {
            update_option( self::WEEKLY_REPORT_OPT, $report, false );
            wp_send_json_success( array( 'report' => array_diff_key( $report, array( '_health' => 1 ) ) ) );
        } else {
            wp_send_json_error( array( 'message' => 'Échec de génération du rapport.' ) );
        }
    }
}
