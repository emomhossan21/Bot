<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS LLMs.txt — AI Discovery File Generator
 *
 * Generates a virtual /llms.txt file that helps LLMs (ChatGPT, Claude, Gemini, Perplexity)
 * understand the site's most important content.
 *
 * Features:
 *   - Virtual file served via template_redirect (no physical file)
 *   - Auto-selects top content: pillar pages (cocon), recent posts, key pages
 *   - Respects noindex (excluded automatically)
 *   - Manual override: user can pick specific URLs
 *   - Cached in transient (regenerated weekly or on demand)
 *   - Toggle in Expert settings
 *
 * Format follows the llms.txt specification:
 *   # Site Name
 *   > Site description
 *   ## Posts
 *   - [Title](URL): Description
 *   ## Pages
 *   - [Title](URL): Description
 *
 * @since 1.3.1
 */

class HTS_LLMs_Txt {

    const OPTION_ENABLED = 'hts_llmstxt_enabled';
    const OPTION_MODE    = 'hts_llmstxt_mode';       // 'auto' | 'manual'
    const OPTION_MANUAL  = 'hts_llmstxt_manual_ids';  // array of post IDs
    const CACHE_KEY      = 'hts_llmstxt_cache';
    const CACHE_KEY_FULL = 'hts_llmstxt_full_cache';
    const CACHE_TTL      = WEEK_IN_SECONDS;
    const MAX_POSTS      = 15;
    const MAX_PAGES      = 10;
    const MAX_POSTS_FULL = 50;
    const MAX_PAGES_FULL = 30;
    const MAX_CONTENT_WORDS = 300;

    public function init() {
        // Serve /llms.txt as virtual file — intercept EARLY before WP processes the 404
        add_action( 'init', array( $this, 'serve_llmstxt' ), 0 );

        // Invalidate cache on content changes
        add_action( 'save_post',     array( $this, 'invalidate_cache' ), 20 );
        add_action( 'delete_post',   array( $this, 'invalidate_cache' ), 20 );
        add_action( 'transition_post_status', array( $this, 'invalidate_cache' ), 20 );

        // AJAX endpoints
        add_action( 'wp_ajax_hts_llmstxt_preview',  array( $this, 'ajax_preview' ) );
        add_action( 'wp_ajax_hts_llmstxt_refresh',   array( $this, 'ajax_refresh' ) );
    }

    /* ══════════════════════════════════════════════
     *  SERVE /llms.txt
     * ══════════════════════════════════════════════ */

    public function serve_llmstxt() {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) return;
        if ( ! $this->is_enabled() ) return;

        // Build the expected path: home_url path + /llms.txt
        // Handles subdirectory installs (e.g. /blog/llms.txt)
        $home_path = wp_parse_url( home_url(), PHP_URL_PATH );
        $home_path = $home_path ? rtrim( $home_path, '/' ) : '';
        $expected  = $home_path . '/llms.txt';

        $request = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
        $path    = wp_parse_url( $request, PHP_URL_PATH );

        $expected_full = $home_path . '/llms-full.txt';

        if ( $path !== $expected && $path !== $expected_full ) return;

        $is_full = ( $path === $expected_full );

        // Serve the file
        $content = $is_full ? $this->get_full_content() : $this->get_content();

        // UTF-8 plain text (cleaner for AI parsers)
        status_header( 200 );
        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'X-Robots-Tag: noindex' );
        header( 'Cache-Control: public, max-age=86400' );
        header( 'Content-Length: ' . strlen( $content ) );
        echo $content;
        exit;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE CONTENT
     * ══════════════════════════════════════════════ */

    public function get_content() {
        // Check cache first
        $cached = get_transient( self::CACHE_KEY );
        if ( false !== $cached ) return $cached;

        // Generate fresh
        $content = $this->generate();

        // Cache
        set_transient( self::CACHE_KEY, $content, self::CACHE_TTL );

        return $content;
    }

    /**
     * Get the full (extended) llms-full.txt content with caching.
     *
     * Per the llms.txt spec, /llms-full.txt is an extended version containing
     * detailed content summaries, headings structure, and key topics for each page.
     * This gives LLMs deeper context to cite and reference site content accurately.
     *
     * @return string
     */
    public function get_full_content() {
        $cached = get_transient( self::CACHE_KEY_FULL );
        if ( false !== $cached ) return $cached;

        $content = $this->generate_full();
        set_transient( self::CACHE_KEY_FULL, $content, self::CACHE_TTL );

        return $content;
    }

    /**
     * Generate the extended llms-full.txt content.
     *
     * Format per spec:
     *   # Site Name
     *   > Site description
     *   ## Section
     *   ### [Page Title](URL)
     *   Summary of page content (first 300 words).
     *   **Topics:** topic1, topic2, topic3
     *   **Headings:** H2 list
     *
     * @return string
     */
    public function generate_full() {
        $site_name = get_bloginfo( 'name' );
        $site_desc = get_bloginfo( 'description' );
        $site_url  = home_url( '/' );
        $site_lang = get_bloginfo( 'language' );

        $lines = array();

        // ── Header ──
        $lines[] = '# ' . $site_name;
        if ( $site_desc ) {
            $lines[] = '';
            $lines[] = '> ' . $site_desc;
        }
        $lines[] = '';
        $lines[] = 'Website: ' . $site_url;
        $lines[] = 'Language: ' . ( $site_lang ? $site_lang : 'fr' );
        $lines[] = 'Format: llms-full.txt (extended version with content summaries)';
        $lines[] = '';

        $mode = get_option( self::OPTION_MODE, 'auto' );
        $excluded_ids = array();

        if ( $mode === 'manual' ) {
            $manual_ids = get_option( self::OPTION_MANUAL, array() );
            if ( ! empty( $manual_ids ) ) {
                $lines[] = '## Key Content';
                $lines[] = '';
                foreach ( $manual_ids as $pid ) {
                    $this->append_full_post( $lines, (int) $pid );
                    $excluded_ids[] = (int) $pid;
                }
            }
        } else {
            // ── Pillar pages ──
            $pillar_ids = $this->get_pillar_ids();
            if ( ! empty( $pillar_ids ) ) {
                $lines[] = '## Pillar Content';
                $lines[] = '';
                foreach ( $pillar_ids as $pid ) {
                    if ( $this->is_excluded( $pid ) ) continue;
                    $this->append_full_post( $lines, $pid );
                    $excluded_ids[] = $pid;
                }
            }

            // ── Key pages ──
            $key_pages = $this->get_key_pages_full( $excluded_ids );
            if ( ! empty( $key_pages ) ) {
                $lines[] = '## Pages';
                $lines[] = '';
                foreach ( $key_pages as $pid ) {
                    $this->append_full_post( $lines, $pid );
                    $excluded_ids[] = $pid;
                }
            }

            // ── Posts ──
            $posts = $this->get_top_posts_full( $excluded_ids );
            if ( ! empty( $posts ) ) {
                $lines[] = '## Posts';
                $lines[] = '';
                foreach ( $posts as $pid ) {
                    $this->append_full_post( $lines, $pid );
                    $excluded_ids[] = $pid;
                }
            }
        }

        // ── Resources ──
        $lines[] = '## Resources';
        $lines[] = '';
        $lines[] = '- [XML Sitemap](' . home_url( '/sitemap.xml' ) . '): Complete sitemap';
        $lines[] = '- [llms.txt](' . home_url( '/llms.txt' ) . '): Compact version of this file';
        $feed_url = get_feed_link( 'rss2' );
        if ( $feed_url ) {
            $lines[] = '- [RSS Feed](' . $feed_url . '): Latest content';
        }
        $lines[] = '';

        // ── Usage ──
        $lines[] = '## Usage Guidelines';
        $lines[] = '';
        $lines[] = '- Please attribute content to "' . $site_name . '" when referencing';
        $lines[] = '- Link back to original source URLs when possible';
        $lines[] = '- This file contains summaries; visit the URLs for complete content';
        $lines[] = '';

        // ── Footer ──
        $lines[] = '---';
        $lines[] = 'Generated by Hack The SEO — ' . gmdate( 'Y-m-d' );
        $lines[] = 'Total entries: ' . count( $excluded_ids );

        return implode( "\n", $lines );
    }

    /**
     * Append a full post entry (title, URL, summary, headings, topics) to lines.
     *
     * @param array $lines  Reference to output lines array.
     * @param int   $post_id The post ID.
     */
    private function append_full_post( &$lines, $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return;

        $title = get_the_title( $post );
        $url   = get_permalink( $post );

        // Clean title for Markdown
        $title = str_replace( array( '[', ']', '(', ')' ), '', $title );

        $lines[] = '### [' . $title . '](' . $url . ')';
        $lines[] = '';

        // Meta description
        $meta_desc = get_post_meta( $post_id, '_hts_meta_description', true );
        if ( ! $meta_desc ) {
            foreach ( array( 'rank_math_description', '_yoast_wpseo_metadesc', '_seopress_titles_desc' ) as $key ) {
                $meta_desc = get_post_meta( $post_id, $key, true );
                if ( $meta_desc ) break;
            }
        }
        if ( $meta_desc ) {
            $lines[] = '> ' . str_replace( array( "\r", "\n" ), ' ', $meta_desc );
            $lines[] = '';
        }

        // Content summary (first N words, stripped of HTML)
        $content = $post->post_content;

        // Handle page builders
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $extracted = HTS_Content_Extractor::get_content( $post_id );
            if ( ! empty( $extracted ) ) {
                $content = $extracted;
            }
        }

        $clean = wp_strip_all_tags( $content );
        $clean = preg_replace( '/\s+/', ' ', $clean );
        $clean = trim( $clean );

        if ( $clean ) {
            $summary = wp_trim_words( $clean, self::MAX_CONTENT_WORDS, '...' );
            $lines[] = $summary;
            $lines[] = '';
        }

        // Extract H2 headings for structure
        $headings = array();
        if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/is', $content, $h2_matches ) ) {
            foreach ( $h2_matches[1] as $h2 ) {
                $h2_clean = trim( wp_strip_all_tags( $h2 ) );
                if ( $h2_clean ) {
                    $headings[] = $h2_clean;
                }
            }
        }
        if ( ! empty( $headings ) ) {
            $lines[] = '**Headings:** ' . implode( ' | ', array_slice( $headings, 0, 10 ) );
        }

        // Focus keyword if available
        $keyword = get_post_meta( $post_id, '_hts_focus_keyword', true );
        if ( ! $keyword ) {
            $keyword = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        }
        if ( ! $keyword ) {
            $keyword = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
        }
        if ( $keyword ) {
            $lines[] = '**Focus keyword:** ' . $keyword;
        }

        // Word count
        $wc = (int) get_post_meta( $post_id, '_hts_word_count', true );
        if ( ! $wc && function_exists( 'hts_word_count' ) ) {
            $wc = hts_word_count( $clean );
        }
        if ( $wc ) {
            $lines[] = '**Word count:** ' . number_format( $wc );
        }

        // Last modified
        $lines[] = '**Last updated:** ' . get_the_modified_date( 'Y-m-d', $post );

        $lines[] = '';
    }

    /**
     * Get key pages for full version (higher limits).
     *
     * @param array $exclude_ids IDs to exclude.
     * @return array Post IDs.
     */
    private function get_key_pages_full( $exclude_ids = array() ) {
        $structural_slugs = array(
            'a-propos', 'about', 'about-us', 'qui-sommes-nous',
            'services', 'prestations', 'offres',
            'contact', 'nous-contacter',
            'tarifs', 'pricing', 'prix',
            'faq', 'aide', 'help',
            'blog', 'articles', 'actualites', 'news',
            'portfolio', 'realisations', 'projets', 'projects',
            'formations', 'resources', 'ressources',
            'equipe', 'team',
            'mentions-legales', 'legal', 'terms', 'conditions-generales',
            'politique-de-confidentialite', 'privacy', 'privacy-policy',
        );

        $args = array(
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => self::MAX_PAGES_FULL,
            'post__not_in'   => $exclude_ids,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
            'suppress_filters' => false,
        );

        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }

        $pages = get_posts( $args );
        $ids   = array();

        $front_page_id = (int) get_option( 'page_on_front' );
        if ( $front_page_id && ! in_array( $front_page_id, $exclude_ids, true ) ) {
            $ids[] = $front_page_id;
        }

        foreach ( $pages as $p ) {
            if ( ! $this->is_excluded( $p->ID ) ) {
                $ids[] = $p->ID;
            }
        }

        return array_slice( array_unique( $ids ), 0, self::MAX_PAGES_FULL );
    }

    /**
     * Get top posts for full version (higher limits).
     *
     * @param array $exclude_ids IDs to exclude.
     * @return array Post IDs.
     */
    private function get_top_posts_full( $exclude_ids = array() ) {
        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => self::MAX_POSTS_FULL * 2,
            'post__not_in'   => $exclude_ids,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'suppress_filters' => false,
        );

        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }

        $posts = get_posts( $args );
        $scored = array();

        $cocon_nodes = array();
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new HTS_Cocon();
            $data  = $cocon->get_cocon_data();
            $cocon_nodes = isset( $data['nodes'] ) ? $data['nodes'] : array();
        }

        foreach ( $posts as $p ) {
            if ( $this->is_excluded( $p->ID ) ) continue;

            $score = 0;

            $mod_time = strtotime( $p->post_modified );
            $months_ago = ( time() - $mod_time ) / ( 30 * DAY_IN_SECONDS );
            if ( $months_ago <= 3 )  $score += 10;
            elseif ( $months_ago <= 6 ) $score += 5;

            $clicks = (int) get_post_meta( $p->ID, '_hts_gsc_clicks', true );
            if ( $clicks >= 100 ) $score += 15;
            elseif ( $clicks >= 20 ) $score += 10;
            elseif ( $clicks > 0 ) $score += 5;

            $wc = (int) get_post_meta( $p->ID, '_hts_word_count', true );
            if ( ! $wc && function_exists( 'hts_word_count' ) ) {
                $wc = hts_word_count( wp_strip_all_tags( $p->post_content ) );
            }
            if ( $wc >= 2000 ) $score += 8;
            elseif ( $wc >= 1000 ) $score += 4;

            if ( ! empty( $cocon_nodes[ $p->ID ] ) ) $score += 5;

            $scored[] = array( 'id' => $p->ID, 'score' => $score );
        }

        usort( $scored, function( $a, $b ) { return $b['score'] <=> $a['score']; } );

        $result = array();
        foreach ( array_slice( $scored, 0, self::MAX_POSTS_FULL ) as $item ) {
            $result[] = $item['id'];
        }

        return $result;
    }

    /**
     * Generate the llms.txt content in Markdown format.
     *
     * Follows the llmstxt.org specification:
     *   - H1 with site name (required)
     *   - Blockquote summary
     *   - Context paragraphs
     *   - H2 sections with categorized links
     *   - Optional: usage guidelines, contact
     */
    public function generate() {
        $site_name = get_bloginfo( 'name' );
        $site_desc = get_bloginfo( 'description' );
        $site_url  = home_url( '/' );
        $site_lang = get_bloginfo( 'language' ) ?: 'fr';

        $lines = array();

        // ── H1 — Required by spec ──
        $lines[] = '# ' . $site_name;

        // ── Blockquote summary — Recommended by spec ──
        if ( $site_desc ) {
            $lines[] = '';
            $lines[] = '> ' . $site_desc;
        }

        // ── Context paragraph ──
        $lines[] = '';
        $lines[] = 'Website: ' . $site_url;
        $lines[] = 'Language: ' . $site_lang;

        // Add contact if available
        $contact_page = $this->find_page_by_slugs( array( 'contact', 'nous-contacter', 'contactez-nous', 'contact-us' ) );
        if ( $contact_page ) {
            $lines[] = 'Contact: ' . get_permalink( $contact_page );
        }
        $lines[] = '';

        $mode = get_option( self::OPTION_MODE, 'auto' );

        if ( $mode === 'manual' ) {
            $manual_ids = get_option( self::OPTION_MANUAL, array() );
            if ( ! empty( $manual_ids ) ) {
                $lines[] = '## Key Content';
                $lines[] = '';
                foreach ( $manual_ids as $pid ) {
                    $line = $this->format_post_line( (int) $pid );
                    if ( $line ) $lines[] = $line;
                }
            }
        } else {
            // Auto mode: smart selection
            $this->generate_auto( $lines );
        }

        // ── Machine-readable references ──
        $lines[] = '## Resources';
        $lines[] = '';
        $lines[] = '- [XML Sitemap](' . home_url( '/sitemap.xml' ) . '): Complete sitemap for crawling';
        $feed_url = get_feed_link( 'rss2' );
        if ( $feed_url ) {
            $lines[] = '- [RSS Feed](' . $feed_url . '): Latest published content';
        }
        $lines[] = '';

        // ── Usage Guidelines (best practice from Rankability/Stripe examples) ──
        $lines[] = '## Usage Guidelines';
        $lines[] = '';
        $lines[] = '- Please attribute content to "' . $site_name . '" when referencing';
        $lines[] = '- Link back to original source URLs when possible';
        $lines[] = '';

        // ── Footer ──
        $lines[] = '---';
        $lines[] = 'Generated by Hack The SEO — ' . gmdate( 'Y-m-d' );

        return implode( "\n", $lines );
    }

    /**
     * Auto-generate content sections.
     */
    private function generate_auto( &$lines ) {
        $excluded_ids = array();

        // ── 1. Pillar pages from Cocon (if available) ──
        $pillar_ids = $this->get_pillar_ids();
        if ( ! empty( $pillar_ids ) ) {
            $lines[] = '## Pillar Content';
            $lines[] = '';
            foreach ( $pillar_ids as $pid ) {
                if ( $this->is_excluded( $pid ) ) continue;
                $line = $this->format_post_line( $pid );
                if ( $line ) {
                    $lines[]        = $line;
                    $excluded_ids[] = $pid;
                }
            }
            $lines[] = '';
        }

        // ── 2. Key pages (About, Contact, Services, etc.) ──
        $key_pages = $this->get_key_pages( $excluded_ids );
        if ( ! empty( $key_pages ) ) {
            $lines[] = '## Pages';
            $lines[] = '';
            foreach ( $key_pages as $pid ) {
                $line = $this->format_post_line( $pid );
                if ( $line ) {
                    $lines[]        = $line;
                    $excluded_ids[] = $pid;
                }
            }
            $lines[] = '';
        }

        // ── 3. Recent/important posts ──
        $posts = $this->get_top_posts( $excluded_ids );
        if ( ! empty( $posts ) ) {
            $lines[] = '## Posts';
            $lines[] = '';
            foreach ( $posts as $pid ) {
                $line = $this->format_post_line( $pid );
                if ( $line ) {
                    $lines[]        = $line;
                    $excluded_ids[] = $pid;
                }
            }
            $lines[] = '';
        }
    }

    /* ══════════════════════════════════════════════
     *  CONTENT SELECTORS
     * ══════════════════════════════════════════════ */

    /**
     * Get pillar page IDs from Cocon data (if HTS_Cocon available).
     */
    private function get_pillar_ids() {
        if ( ! class_exists( 'HTS_Cocon' ) ) return array();

        $cocon = new HTS_Cocon();
        $data  = $cocon->get_cocon_data();

        if ( empty( $data['clusters'] ) ) return array();

        $ids = array();
        foreach ( $data['clusters'] as $cluster_name => $cl ) {
            $pillar_id = (int) ( $cl['pillar_id'] ?? 0 );
            if ( $pillar_id && get_post_status( $pillar_id ) === 'publish' ) {
                $ids[] = $pillar_id;
            }
        }
        return array_unique( $ids );
    }

    /**
     * Get key pages (structural pages).
     */
    private function get_key_pages( $exclude_ids = array() ) {
        $structural_slugs = array(
            'a-propos', 'about', 'about-us', 'qui-sommes-nous',
            'services', 'prestations', 'offres',
            'contact', 'nous-contacter',
            'tarifs', 'pricing', 'prix',
            'faq', 'aide', 'help',
            'blog', 'articles', 'actualites', 'news',
            'portfolio', 'realisations', 'projets', 'projects',
            'formations', 'resources', 'ressources',
            'equipe', 'team',
        );

        $args = array(
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'post_name__in'  => $structural_slugs,
            'posts_per_page' => self::MAX_PAGES,
            'post__not_in'   => $exclude_ids,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        );

        // Filter by language if multilingual
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }

        $pages = get_posts( $args );
        $ids   = array();

        // Also add homepage if it's a static page
        $front_page_id = (int) get_option( 'page_on_front' );
        if ( $front_page_id && ! in_array( $front_page_id, $exclude_ids, true ) ) {
            $ids[] = $front_page_id;
        }

        foreach ( $pages as $p ) {
            if ( ! $this->is_excluded( $p->ID ) ) {
                $ids[] = $p->ID;
            }
        }

        return array_slice( array_unique( $ids ), 0, self::MAX_PAGES );
    }

    /**
     * Get top posts: prioritize recently modified, with GSC clicks, cornerstone.
     */
    private function get_top_posts( $exclude_ids = array() ) {
        global $wpdb;

        // Strategy: recently modified published posts, not noindex
        // Prioritize those with GSC data (clicks > 0)
        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => self::MAX_POSTS * 2, // Fetch extra to filter
            'post__not_in'   => $exclude_ids,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'date_query'     => array(
                array(
                    'column' => 'post_modified',
                    'after'  => '12 months ago',
                ),
            ),
        );

        // Filter by language if multilingual
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }

        $posts = get_posts( $args );
        $scored = array();

        // Pre-fetch cocon data once (if available)
        $cocon_nodes = array();
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new HTS_Cocon();
            $data  = $cocon->get_cocon_data();
            $cocon_nodes = $data['nodes'] ?? array();
        }

        foreach ( $posts as $p ) {
            if ( $this->is_excluded( $p->ID ) ) continue;

            $score = 0;

            // Recency bonus (modified within last 3 months = +10)
            $mod_time = strtotime( $p->post_modified );
            $months_ago = ( time() - $mod_time ) / ( 30 * DAY_IN_SECONDS );
            if ( $months_ago <= 3 )  $score += 10;
            elseif ( $months_ago <= 6 ) $score += 5;

            // GSC clicks bonus
            $clicks = (int) get_post_meta( $p->ID, '_hts_gsc_clicks', true );
            if ( $clicks >= 100 ) $score += 15;
            elseif ( $clicks >= 20 ) $score += 10;
            elseif ( $clicks > 0 ) $score += 5;

            // Word count bonus (long-form = authority)
            $wc = (int) get_post_meta( $p->ID, '_hts_word_count', true );
            if ( ! $wc ) $wc = hts_word_count( wp_strip_all_tags( $p->post_content ) );
            if ( $wc >= 2000 ) $score += 8;
            elseif ( $wc >= 1000 ) $score += 4;

            // In cocon = bonus
            if ( ! empty( $cocon_nodes[ $p->ID ] ) ) $score += 5;

            $scored[] = array( 'id' => $p->ID, 'score' => $score );
        }

        // Sort by score descending
        usort( $scored, function( $a, $b ) { return $b['score'] <=> $a['score']; } );

        $result = array();
        foreach ( array_slice( $scored, 0, self::MAX_POSTS ) as $item ) {
            $result[] = $item['id'];
        }

        return $result;
    }

    /* ══════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════ */

    /**
     * Format a post as a Markdown list item.
     * - [Title](URL): Description
     */
    private function format_post_line( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return null;

        $title = get_the_title( $post );
        $url   = get_permalink( $post );

        // Description: HTS meta desc → excerpt → trimmed content
        $desc = get_post_meta( $post_id, '_hts_meta_description', true );
        if ( ! $desc ) {
            // Try competitor meta descriptions
            foreach ( array( 'rank_math_description', '_yoast_wpseo_metadesc', '_seopress_titles_desc' ) as $key ) {
                $desc = get_post_meta( $post_id, $key, true );
                if ( $desc ) break;
            }
        }
        if ( ! $desc ) $desc = $post->post_excerpt;
        if ( ! $desc ) $desc = wp_trim_words( wp_strip_all_tags( $post->post_content ), 25, '…' );

        // Clean markdown special chars in title/desc
        $title = str_replace( array( '[', ']', '(', ')' ), '', $title );
        $desc  = str_replace( array( '[', ']', '(', ')' ), '', $desc );
        $desc  = trim( $desc );

        if ( $desc ) {
            return '- [' . $title . '](' . $url . '): ' . $desc;
        }
        return '- [' . $title . '](' . $url . ')';
    }

    /**
     * Check if a post should be excluded (noindex, private, etc.)
     */
    private function is_excluded( $post_id ) {
        // Check HTS noindex
        if ( class_exists( 'HTS_Robots' ) && HTS_Robots::is_noindex( $post_id ) ) {
            return true;
        }

        // Check competitor noindex (Rank Math)
        $rm_robots = get_post_meta( $post_id, 'rank_math_robots', true );
        if ( is_array( $rm_robots ) && in_array( 'noindex', $rm_robots, true ) ) {
            return true;
        }

        // Check Yoast noindex
        $yoast_noindex = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
        if ( $yoast_noindex === '1' ) {
            return true;
        }

        return false;
    }

    /**
     * Find a published page by a list of possible slugs.
     */
    private function find_page_by_slugs( $slugs ) {
        $pages = get_posts( array(
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'post_name__in'  => $slugs,
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ) );
        return ! empty( $pages ) ? $pages[0] : null;
    }

    /**
     * Is llms.txt enabled?
     */
    public function is_enabled() {
        return get_option( self::OPTION_ENABLED, '1' ) === '1';
    }

    /**
     * Invalidate cache when content changes.
     */
    public function invalidate_cache() {
        delete_transient( self::CACHE_KEY );
        delete_transient( self::CACHE_KEY_FULL );
    }

    /* ══════════════════════════════════════════════
     *  AJAX
     * ══════════════════════════════════════════════ */

    public function ajax_preview() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        // Force fresh generation (bypass cache)
        delete_transient( self::CACHE_KEY );
        $content = $this->generate();

        $url_count = substr_count( $content, '](http' );

        wp_send_json_success( array(
            'content'   => $content,
            'url_count' => $url_count,
            'url'       => home_url( '/llms.txt' ),
        ) );
    }

    public function ajax_refresh() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        // Clear cache + regenerate
        delete_transient( self::CACHE_KEY );
        $content = $this->get_content(); // Will regenerate + cache

        if ( function_exists( 'hts_add_log' ) ) {
 hts_add_log( ' llms.txt régénéré manuellement', 'success', 'llmstxt' );
        }

        wp_send_json_success( array(
            'content'   => $content,
            'url_count' => substr_count( $content, '](http' ),
        ) );
    }

    /* ══════════════════════════════════════════════
     *  PUBLIC API
     * ══════════════════════════════════════════════ */

    /**
     * Get stats for Cockpit display.
     */
    public function get_stats() {
        $enabled = $this->is_enabled();
        $content = $enabled ? $this->get_content() : '';
        $url_count = $content ? substr_count( $content, '](http' ) : 0;
        $cached = get_transient( self::CACHE_KEY );

        return array(
            'enabled'   => $enabled,
            'url_count' => $url_count,
            'cached'    => ( false !== $cached ),
            'mode'      => get_option( self::OPTION_MODE, 'auto' ),
            'url'       => home_url( '/llms.txt' ),
            'url_full'  => home_url( '/llms-full.txt' ),
        );
    }
}
