<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS IndexNow Module
 *
 * Automatically pings IndexNow-compatible search engines (Bing, Yandex, Naver, Seznam)
 * when content is published or updated, for near-instant crawling.
 *
 * Features:
 *   - Auto-ping on publish/update (posts + pages)
 *   - API key auto-generated and served at /{key}.txt
 *   - Batch ping support (up to 10,000 URLs per call)
 *   - Rate limiting: max 1 ping per URL per 10 minutes
 *   - Manual ping from admin bar / Cockpit
 *   - Stats: total pings, last ping, success rate
 *   - Compatible with all IndexNow engines
 *
 * @since 1.3.2
 */

class HTS_IndexNow {

    const OPTION_ENABLED  = 'hts_indexnow_enabled';
    const OPTION_KEY      = 'hts_indexnow_key';
    const OPTION_STATS    = 'hts_indexnow_stats';
    const TRANSIENT_RATE  = 'hts_indexnow_rate_';
    const ENDPOINT        = 'https://api.indexnow.org/indexnow';

    public function init() {
        // ── Guard: module must be enabled ──
        if ( get_option( self::OPTION_ENABLED, '0' ) !== '1' ) return;

        // ── Auto-ping on publish/update ──
        add_action( 'transition_post_status', array( $this, 'on_post_status_change' ), 20, 3 );

        // ── Serve API key file at /{key}.txt — intercept early ──
        add_action( 'init', array( $this, 'serve_key_file' ), 0 );

        // ── AJAX endpoints ──
        add_action( 'wp_ajax_hts_indexnow_ping',     array( $this, 'ajax_manual_ping' ) );
        add_action( 'wp_ajax_hts_indexnow_ping_all',  array( $this, 'ajax_ping_recent' ) );
        add_action( 'wp_ajax_hts_indexnow_stats',     array( $this, 'ajax_get_stats' ) );
        add_action( 'wp_ajax_hts_indexnow_reset_key', array( $this, 'ajax_reset_key' ) );
    }

    /* ══════════════════════════════════════════════
     *  API KEY MANAGEMENT
     * ══════════════════════════════════════════════ */

    /**
     * Get or generate the IndexNow API key.
     * Format: 32 hex chars (IndexNow spec: 8-128 hex chars).
     */
    public static function get_api_key() {
        $key = get_option( self::OPTION_KEY, '' );
        if ( empty( $key ) || strlen( $key ) < 8 ) {
            $key = wp_generate_password( 32, false, false );
            // IndexNow spec requires hex-like chars only (a-f, 0-9)
            $key = substr( md5( $key . wp_salt() ), 0, 32 );
            update_option( self::OPTION_KEY, $key, false );
        }
        return $key;
    }

    /**
     * Serve the API key verification file at /{key}.txt
     */
    public function serve_key_file() {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) return;

        $key = self::get_api_key();

        // Build expected path: handle subdirectory installs
        $home_path = wp_parse_url( home_url(), PHP_URL_PATH );
        $home_path = $home_path ? rtrim( $home_path, '/' ) : '';
        $expected  = $home_path . '/' . $key . '.txt';

        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? strtok( $_SERVER['REQUEST_URI'], '?' ) : '';
        $path = wp_parse_url( $request_uri, PHP_URL_PATH );

        if ( $path === $expected ) {
            status_header( 200 );
            header( 'Content-Type: text/plain; charset=utf-8' );
            header( 'X-Robots-Tag: noindex' );
            echo $key;
            exit;
        }
    }

    /* ══════════════════════════════════════════════
     *  AUTO PING ON PUBLISH / UPDATE
     * ══════════════════════════════════════════════ */

    /**
     * Hook into post status transitions.
     * Fires on: draft→publish, pending→publish, future→publish, publish→publish (update).
     */
    public function on_post_status_change( $new_status, $old_status, $post ) {
        // Only fire for public post types going to 'publish'
        if ( $new_status !== 'publish' ) return;
        if ( ! in_array( $post->post_type, self::get_pingable_types(), true ) ) return;
        if ( wp_is_post_revision( $post->ID ) || wp_is_post_autosave( $post->ID ) ) return;

        // Don't ping noindex pages
        if ( class_exists( 'HTS_Robots' ) && HTS_Robots::is_noindex( $post->ID ) ) return;

        $url = get_permalink( $post->ID );
        if ( ! $url ) return;

        // Rate limit: max 1 ping per URL per 10 minutes
        $rate_key = self::TRANSIENT_RATE . md5( $url );
        if ( get_transient( $rate_key ) ) return;

        $result = self::ping_url( $url );

        if ( $result['success'] ) {
            set_transient( $rate_key, 1, 600 ); // 10 min cooldown
            self::update_stats( 'success' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
 sprintf( 'IndexNow : %s ping OK (%s)', esc_html( $post->post_title ), $result['code'] ),
                    'info', 'indexnow'
                );
            }
        } else {
            self::update_stats( 'error' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
 sprintf( 'IndexNow : %s échec (%s)', esc_html( $post->post_title ), $result['error'] ),
                    'warning', 'indexnow'
                );
            }
        }
    }

    /* ══════════════════════════════════════════════
     *  PING ENGINE
     * ══════════════════════════════════════════════ */

    /**
     * Ping a single URL to IndexNow.
     *
     * @param string $url Full URL to ping.
     * @return array { success: bool, code: int, error: string }
     */
    public static function ping_url( $url ) {
        $key  = self::get_api_key();
        $host = wp_parse_url( home_url(), PHP_URL_HOST );

        $api_url = add_query_arg( array(
            'url'    => $url,
            'key'    => $key,
        ), self::ENDPOINT );

        $response = wp_remote_get( $api_url, array(
            'timeout'    => 10,
            'user-agent' => 'HTS-IndexNow/1.0 (WordPress; +' . home_url() . ')',
            'headers'    => array(
                'Host' => wp_parse_url( self::ENDPOINT, PHP_URL_HOST ),
            ),
        ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'code' => 0, 'error' => $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );

        // IndexNow returns:
        // 200 = URL submitted successfully
        // 202 = URL received, pending processing
        // 400 = Bad request
        // 403 = Forbidden (key mismatch)
        // 422 = Unprocessable (invalid URL)
        // 429 = Too many requests
        if ( in_array( $code, array( 200, 202 ), true ) ) {
            return array( 'success' => true, 'code' => $code, 'error' => '' );
        }

        return array( 'success' => false, 'code' => $code, 'error' => 'HTTP ' . $code );
    }

    /**
     * Batch ping multiple URLs (IndexNow batch API — POST).
     *
     * @param array $urls Array of full URLs.
     * @return array { success: bool, code: int, submitted: int, error: string }
     */
    public static function ping_batch( $urls ) {
        if ( empty( $urls ) ) {
            return array( 'success' => false, 'code' => 0, 'submitted' => 0, 'error' => 'No URLs' );
        }

        // IndexNow batch limit: 10,000 URLs per request
        $urls = array_slice( array_unique( array_filter( $urls ) ), 0, 10000 );
        $key  = self::get_api_key();
        $host = wp_parse_url( home_url(), PHP_URL_HOST );

        $body = wp_json_encode( array(
            'host'    => $host,
            'key'     => $key,
            'urlList' => array_values( $urls ),
        ) );

        $response = wp_remote_post( self::ENDPOINT, array(
            'timeout'    => 30,
            'user-agent' => 'HTS-IndexNow/1.0 (WordPress; +' . home_url() . ')',
            'headers'    => array(
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body' => $body,
        ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'code' => 0, 'submitted' => 0, 'error' => $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( in_array( $code, array( 200, 202 ), true ) ) {
            return array( 'success' => true, 'code' => $code, 'submitted' => count( $urls ), 'error' => '' );
        }

        return array( 'success' => false, 'code' => $code, 'submitted' => 0, 'error' => 'HTTP ' . $code );
    }

    /* ══════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════ */

    /**
     * Get public post types eligible for IndexNow pinging.
     */
    public static function get_pingable_types() {
        $types = get_post_types( array( 'public' => true ), 'names' );
        unset( $types['attachment'] );
        return array_values( $types );
    }

    /**
     * Update stats counter.
     */
    private static function update_stats( $type ) {
        $stats = get_option( self::OPTION_STATS, array(
            'total'   => 0,
            'success' => 0,
            'errors'  => 0,
            'last'    => '',
        ) );
        $stats['total']   = (int) ( $stats['total'] ?? 0 ) + 1;
        $stats['last']    = current_time( 'mysql' );
        if ( $type === 'success' ) {
            $stats['success'] = (int) ( $stats['success'] ?? 0 ) + 1;
        } else {
            $stats['errors'] = (int) ( $stats['errors'] ?? 0 ) + 1;
        }
        update_option( self::OPTION_STATS, $stats, false );
    }

    /**
     * Get stats for display.
     */
    public static function get_stats() {
        return wp_parse_args( get_option( self::OPTION_STATS, array() ), array(
            'total'   => 0,
            'success' => 0,
            'errors'  => 0,
            'last'    => '',
        ) );
    }

    /* ══════════════════════════════════════════════
     *  AJAX HANDLERS
     * ══════════════════════════════════════════════ */

    /**
     * Manual ping for a single post.
     */
    public function ajax_manual_ping() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'ID requis' );

        $url = get_permalink( $post_id );
        if ( ! $url ) wp_send_json_error( 'URL introuvable' );

        $result = self::ping_url( $url );
        if ( $result['success'] ) {
            self::update_stats( 'success' );
            wp_send_json_success( array( 'message' => 'Ping envoyé (HTTP ' . $result['code'] . ')', 'url' => $url ) );
        } else {
            self::update_stats( 'error' );
            wp_send_json_error( 'Échec : ' . $result['error'] );
        }
    }

    /**
     * Batch ping recent posts (last 50 published).
     */
    public function ajax_ping_recent() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $posts = get_posts( array(
            'post_type'   => self::get_pingable_types(),
            'post_status' => 'publish',
            'numberposts' => 50,
            'orderby'     => 'modified',
            'order'       => 'DESC',
            'fields'      => 'ids',
        ) );

        $urls = array();
        foreach ( $posts as $pid ) {
            // Skip noindex pages
            if ( class_exists( 'HTS_Robots' ) && HTS_Robots::is_noindex( $pid ) ) continue;
            $url = get_permalink( $pid );
            if ( $url ) $urls[] = $url;
        }

        if ( empty( $urls ) ) wp_send_json_error( 'Aucune URL éligible' );

        $result = self::ping_batch( $urls );
        if ( $result['success'] ) {
            self::update_stats( 'success' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
 sprintf( 'IndexNow batch : %d URLs soumises (HTTP %d)', $result['submitted'], $result['code'] ),
                    'success', 'indexnow'
                );
            }
            wp_send_json_success( array(
                'message'   => $result['submitted'] . ' URLs soumises',
                'submitted' => $result['submitted'],
                'code'      => $result['code'],
            ) );
        } else {
            self::update_stats( 'error' );
            wp_send_json_error( 'Batch échoué : ' . $result['error'] );
        }
    }

    /**
     * Get stats.
     */
    public function ajax_get_stats() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $stats = self::get_stats();
        $key   = self::get_api_key();
        wp_send_json_success( array(
            'stats'    => $stats,
            'key'      => $key,
            'key_url'  => home_url( '/' . $key . '.txt' ),
            'enabled'  => get_option( self::OPTION_ENABLED, '0' ),
        ) );
    }

    /**
     * Reset API key.
     */
    public function ajax_reset_key() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        delete_option( self::OPTION_KEY );
        $new_key = self::get_api_key(); // Re-generate
        if ( function_exists( 'hts_add_log' ) ) {
 hts_add_log( 'IndexNow : clé API régénérée', 'info', 'indexnow' );
        }
        wp_send_json_success( array(
            'key'     => $new_key,
            'key_url' => home_url( '/' . $new_key . '.txt' ),
        ) );
    }
}
