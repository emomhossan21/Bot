<?php
/**
 * HTS Support Docs — Help Center + Chat Widget (Intercom-like)
 *
 * Provides:
 *  - JSON-based documentation (SaaS + WP Plugin, FR + EN)
 *  - AJAX full-text search across all articles
 *  - Chat support powered by gpt-4.1-mini (cheap, fast)
 *  - Escalation to Coach SEO for complex/strategy questions
 *  - Escalation to email for out-of-scope questions
 *  - Contextual article suggestions based on current admin page
 *  - Intercom-like widget (bottom-right bubble, slide-up panel)
 *  - DS v5.7 styling (Lucide icons, zero emoji)
 *
 * @package HackTheSEO
 * @since 2.7.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class HTS_Support_Docs {

    /** @var array Parsed documentation database */
    private static $docs = null;

    /** @var string Path to the JSON docs file */
    private static $json_path;

    /* ═══════════════════════════════════════════
       BOOT
       ═══════════════════════════════════════════ */

    public static function init() {
        self::$json_path = HTS__PLUGIN_DIR . 'modules/docs-database.json';

        // Admin widget on all HTS pages
        add_action( 'admin_footer', array( __CLASS__, 'render_widget' ) );

        // AJAX endpoints
        add_action( 'wp_ajax_hts_docs_search', array( __CLASS__, 'ajax_search' ) );
        add_action( 'wp_ajax_hts_docs_chat',   array( __CLASS__, 'ajax_chat' ) );
        add_action( 'wp_ajax_hts_docs_articles', array( __CLASS__, 'ajax_get_articles' ) );
        add_action( 'wp_ajax_hts_docs_email',  array( __CLASS__, 'ajax_send_email' ) );

        // Enqueue widget assets
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    /* ═══════════════════════════════════════════
       DATA LOADING
       ═══════════════════════════════════════════ */

    private static function load_docs() {
        if ( self::$docs !== null ) return self::$docs;

        $json = file_get_contents( self::$json_path );
        if ( ! $json ) {
            self::$docs = array( 'articles' => array(), 'categories' => array() );
            return self::$docs;
        }

        self::$docs = json_decode( $json, true );
        if ( ! self::$docs || ! isset( self::$docs['articles'] ) ) {
            self::$docs = array( 'articles' => array(), 'categories' => array() );
        }

        return self::$docs;
    }

    /**
     * Get user language (fr or en)
     */
    private static function get_lang() {
        $locale = get_user_locale();
        return ( strpos( $locale, 'fr' ) === 0 ) ? 'fr' : 'en';
    }

    /* ═══════════════════════════════════════════
       AJAX — SEARCH
       ═══════════════════════════════════════════ */

    public static function ajax_search() {
        check_ajax_referer( 'hts_docs_nonce', 'nonce' );

        $query = sanitize_text_field( wp_unslash( $_POST['query'] ?? '' ) );
        if ( strlen( $query ) < 2 ) {
            wp_send_json_success( array( 'results' => array() ) );
        }

        $docs = self::load_docs();
        $lang = self::get_lang();
        $q    = mb_strtolower( $query );
        $results = array();

        foreach ( $docs['articles'] as $article ) {
            $localized = $article[ $lang ] ?? $article['en'];
            $score = 0;

            // Title match (highest weight)
            if ( mb_stripos( $localized['title'], $q ) !== false ) {
                $score += 10;
            }

            // Excerpt match
            if ( mb_stripos( $localized['excerpt'] ?? '', $q ) !== false ) {
                $score += 5;
            }

            // Section body match
            $snippet = '';
            foreach ( $localized['sections'] ?? array() as $sec ) {
                if ( mb_stripos( $sec['body'], $q ) !== false ) {
                    $score += 3;
                    $pos = mb_stripos( mb_strtolower( $sec['body'] ), $q );
                    $start = max( 0, $pos - 40 );
                    $snippet = '...' . mb_substr( $sec['body'], $start, 120 ) . '...';
                    break;
                }
                if ( mb_stripos( $sec['heading'], $q ) !== false ) {
                    $score += 4;
                }
            }

            if ( $score > 0 ) {
                $results[] = array(
                    'id'       => $article['id'],
                    'title'    => $localized['title'],
                    'excerpt'  => $localized['excerpt'] ?? '',
                    'snippet'  => $snippet,
                    'category' => $article['category'],
                    'product'  => $article['product'],
                    'icon'     => $article['icon'] ?? 'file',
                    'score'    => $score,
                    'url'      => $article['url'] ?? '',
                );
            }
        }

        // Sort by score desc
        usort( $results, function( $a, $b ) { return $b['score'] - $a['score']; } );

        wp_send_json_success( array( 'results' => array_slice( $results, 0, 8 ) ) );
    }

    /* ═══════════════════════════════════════════
       AJAX — GET ARTICLES (contextual)
       ═══════════════════════════════════════════ */

    public static function ajax_get_articles() {
        check_ajax_referer( 'hts_docs_nonce', 'nonce' );

        $context_page = sanitize_text_field( wp_unslash( $_POST['context_page'] ?? '' ) );
        $category     = sanitize_text_field( wp_unslash( $_POST['category'] ?? '' ) );

        $docs = self::load_docs();
        $lang = self::get_lang();
        $articles = array();

        foreach ( $docs['articles'] as $article ) {
            $localized = $article[ $lang ] ?? $article['en'];

            // Filter by context page if provided
            $context_match = empty( $context_page ) || in_array( $context_page, $article['context_pages'] ?? array(), true );

            // Filter by category if provided
            $cat_match = empty( $category ) || $article['category'] === $category;

            if ( $context_match || $cat_match ) {
                $articles[] = array(
                    'id'       => $article['id'],
                    'title'    => $localized['title'],
                    'excerpt'  => $localized['excerpt'] ?? '',
                    'category' => $article['category'],
                    'product'  => $article['product'],
                    'icon'     => $article['icon'] ?? 'file',
                    'order'    => $article['order'] ?? 99,
                    'url'      => $article['url'] ?? '',
                    'sections' => $localized['sections'] ?? array(),
                );
            }
        }

        usort( $articles, function( $a, $b ) { return $a['order'] - $b['order']; } );

        // If context gave results, return those; otherwise return all
        if ( ! empty( $context_page ) && empty( $articles ) ) {
            // Fallback: return all
            foreach ( $docs['articles'] as $article ) {
                $localized = $article[ $lang ] ?? $article['en'];
                $articles[] = array(
                    'id'       => $article['id'],
                    'title'    => $localized['title'],
                    'excerpt'  => $localized['excerpt'] ?? '',
                    'category' => $article['category'],
                    'product'  => $article['product'],
                    'icon'     => $article['icon'] ?? 'file',
                    'order'    => $article['order'] ?? 99,
                    'url'      => $article['url'] ?? '',
                );
            }
            usort( $articles, function( $a, $b ) { return $a['order'] - $b['order']; } );
        }

        // Return categories too
        $categories = $docs['categories'][ $lang ] ?? $docs['categories']['en'] ?? array();

        wp_send_json_success( array(
            'articles'   => array_slice( $articles, 0, 20 ),
            'categories' => $categories,
        ) );
    }

    /* ═══════════════════════════════════════════
       AJAX — CHAT (gpt-4.1-mini)
       ═══════════════════════════════════════════ */

    public static function ajax_chat() {
        check_ajax_referer( 'hts_docs_nonce', 'nonce' );

        $message      = sanitize_text_field( wp_unslash( $_POST['message'] ?? '' ) );
        $context_page = sanitize_text_field( wp_unslash( $_POST['context_page'] ?? '' ) );

        if ( empty( $message ) ) {
            wp_send_json_error( array( 'message' => 'Empty message' ) );
        }

        // Check if question is complex/strategic → escalate to Coach
        $escalate_keywords = array(
            'strategy', 'strategie', 'plan action', 'action plan',
            'audit complet', 'full audit', 'rapport', 'report',
            'analyse complete', 'analyze my site', 'analyser mon site',
            'cocon semantique', 'semantic cluster', 'maillage complet',
            'improve my ranking', 'ameliorer mon classement',
        );

        $msg_lower = mb_strtolower( $message );
        $is_complex = false;
        foreach ( $escalate_keywords as $kw ) {
            if ( mb_stripos( $msg_lower, $kw ) !== false ) {
                $is_complex = true;
                break;
            }
        }

        // NOTE: is_complex is used AFTER the bot responds — we let the bot answer first,
        // then flag 'coach' so the JS adds a "Ask the Coach" button below the response.

        // Retrieve relevant docs for context
        $docs = self::load_docs();
        $lang = self::get_lang();
        $context_chunks = self::find_relevant_chunks( $message, $context_page, $lang, 5 );

        // Build system prompt
        $system = self::build_system_prompt( $lang, $context_chunks );

        // Call gpt-4.1-mini via OpenAI-compatible endpoint
        $api_key = get_option( 'hts_openai_api_key', '' );
        if ( empty( $api_key ) ) {
            // Fallback: try HTS SaaS API key
            $api_key = get_option( 'hts_api_key', '' );
        }

        if ( empty( $api_key ) ) {
            $lang = self::get_lang();
            $fallback = ( $lang === 'fr' )
                ? 'Le chat support necessite une cle API. Verifie dans Reglages > Connexions. En attendant, consulte la documentation ci-dessus ou contacte support@hacktheseo.com.'
                : 'The support chat requires an API key. Check Settings > Connections. In the meantime, browse the documentation above or contact support@hacktheseo.com.';
            wp_send_json_success( array( 'reply' => $fallback, 'escalate' => 'none' ) );
        }

        // Build conversation history (last 3-4 exchanges for context)
        $history_raw = wp_unslash( $_POST['history'] ?? '[]' );
        $history = json_decode( $history_raw, true );
        if ( ! is_array( $history ) ) $history = array();
        // Keep only last 4 exchanges (8 messages max) to limit tokens
        $history = array_slice( $history, -8 );

        $messages = array();
        $messages[] = array( 'role' => 'system', 'content' => $system );
        // Inject history
        foreach ( $history as $h ) {
            $role = ( $h['role'] ?? '' ) === 'user' ? 'user' : 'assistant';
            $text = sanitize_text_field( $h['text'] ?? '' );
            if ( ! empty( $text ) ) {
                $messages[] = array( 'role' => $role, 'content' => $text );
            }
        }
        // Current message
        $messages[] = array( 'role' => 'user', 'content' => $message );

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ),
            'body' => wp_json_encode( array(
                'model'       => 'gpt-4.1-mini',
                'max_tokens'  => 500,
                'temperature' => 0.3,
                'messages'    => $messages,
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            wp_send_json_success( array(
                'reply'    => ( $lang === 'fr' )
                    ? 'Impossible de contacter le service. Contacte support@hacktheseo.com pour de l\'aide.'
                    : 'Unable to reach the service. Contact support@hacktheseo.com for help.',
                'escalate' => 'email',
            ) );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $reply = $body['choices'][0]['message']['content'] ?? '';

        if ( empty( $reply ) ) {
            $reply = ( $lang === 'fr' )
                ? 'Je n\'ai pas pu generer une reponse. Contacte support@hacktheseo.com.'
                : 'I could not generate a response. Contact support@hacktheseo.com.';
        }

        wp_send_json_success( array(
            'reply'    => $reply,
            'escalate' => $is_complex ? 'coach' : 'none',
        ) );
    }

    /**
     * Find relevant documentation chunks for the chat context
     */
    private static function find_relevant_chunks( $query, $context_page, $lang, $limit = 5 ) {
        $docs = self::load_docs();
        $q = mb_strtolower( $query );
        $scored = array();

        foreach ( $docs['articles'] as $article ) {
            $localized = $article[ $lang ] ?? $article['en'];
            $base_score = 0;

            // WORDPRESS PRODUCT BOOST — we are inside the WP plugin, prioritize WP articles
            if ( ( $article['product'] ?? '' ) === 'wordpress' ) {
                $base_score += 5;
            }

            // Context page boost
            if ( ! empty( $context_page ) && in_array( $context_page, $article['context_pages'] ?? array(), true ) ) {
                $base_score += 3;
            }

            foreach ( $localized['sections'] ?? array() as $sec ) {
                $score = $base_score;
                $text = $sec['heading'] . ' ' . $sec['body'];

                // Keyword matching
                $words = preg_split( '/\s+/', $q );
                foreach ( $words as $word ) {
                    if ( strlen( $word ) >= 3 && mb_stripos( $text, $word ) !== false ) {
                        $score += 2;
                    }
                }

                if ( $score > 0 ) {
                    $scored[] = array(
                        'score'   => $score,
                        'heading' => $sec['heading'],
                        'body'    => $sec['body'],
                        'article' => $localized['title'],
                        'product' => $article['product'] ?? 'saas',
                    );
                }
            }
        }

        usort( $scored, function( $a, $b ) { return $b['score'] - $a['score']; } );
        return array_slice( $scored, 0, $limit );
    }

    /**
     * Build system prompt with relevant doc chunks
     */
    private static function build_system_prompt( $lang, $chunks ) {

        $prompt = ( $lang === 'fr' )
            ? "Tu es l'assistant support de Hack The SEO, integre dans le plugin WordPress. L'utilisateur est un client qui utilise le plugin WordPress. Regles strictes :

CONTEXTE PLUGIN WORDPRESS :
- Tu es dans le plugin WordPress Hack The SEO. Voici les vrais menus du plugin :
  * Hack The SEO > Tableau de bord (score de sante, alertes, onglet Coach IA)
  * Hack The SEO > Reglages (meta tags, schema, robots, canonical, breadcrumbs, API, connexion Google)
  * Hack The SEO > Redirections (301, detection 404)
  * Hack The SEO > Analytics (donnees Google Search Console)
  * Hack The SEO > Groupes de contenus (cocons semantiques, page pilier + satellites, maillage)
  * Hack The SEO > Planification (calendrier editorial)
  * Hack The SEO > Pages en concurrence (cannibalisation de mots-cles)
- Le Coach IA est un onglet dans le Tableau de bord (pas une page separee).
- Le maillage interne, les recommandations (Inbox) et les meta tags se configurent dans Reglages.
- Ne reponds PAS avec les instructions de la plateforme SaaS (app.hacktheseo.com) sauf si demande explicitement.

FORMAT DE REPONSE :
- Reponds en francais, de maniere claire et structuree.
- Utilise du markdown simple : **gras** pour les termes importants, des retours a la ligne entre les paragraphes.
- Pour les listes, utilise des tirets sur des lignes separees.
- Pour les tutoriels, utilise des etapes numerotees sur des lignes separees.
- Structure TOUJOURS ta reponse en paragraphes courts. Jamais plus de 3 phrases sans saut de ligne.
- Commence par une reponse directe en 1-2 phrases, puis developpe.
- Maximum 150 mots par reponse.

CONTENU :
- Appuie-toi uniquement sur la documentation fournie ci-dessous.
- Si la reponse n'est pas dans la documentation, dis-le honnetement et propose de contacter l'equipe support.
- Pour les questions de strategie SEO complexe, oriente vers le Coach IA (onglet Coach dans le Tableau de bord Hack The SEO).
- Tutoie l'utilisateur. Sois utile et direct."

            : "You are the Hack The SEO support assistant, embedded in the WordPress plugin. The user is a client using the WordPress plugin. Strict rules:

WORDPRESS PLUGIN CONTEXT:
- You are inside the WordPress plugin. Here are the actual plugin menus:
  * Hack The SEO > Dashboard (health score, alerts, AI Coach tab)
  * Hack The SEO > Settings (meta tags, schema, robots, canonical, breadcrumbs, API, Google connection)
  * Hack The SEO > Redirections (301, 404 detection)
  * Hack The SEO > Analytics (Google Search Console data)
  * Hack The SEO > Content Groups (semantic clusters, pillar + satellites, internal linking)
  * Hack The SEO > Scheduling (editorial calendar)
  * Hack The SEO > Competing Pages (keyword cannibalization)
- The AI Coach is a tab inside the Dashboard (not a separate page).
- Internal linking, recommendations (Inbox) and meta tags are configured in Settings.
- Do NOT answer with SaaS platform (app.hacktheseo.com) instructions unless explicitly asked.

RESPONSE FORMAT:
- Respond in English, clearly and with structure.
- Use simple markdown: **bold** for key terms, line breaks between paragraphs.
- For lists use dashes on separate lines.
- For tutorials use numbered steps on separate lines.
- ALWAYS structure in short paragraphs. Never more than 3 sentences without a line break.
- Start with a direct answer in 1-2 sentences, then elaborate.
- Maximum 150 words per response.

CONTENT:
- Only use the documentation provided below.
- If not in docs, say so and suggest contacting support team.
- For complex SEO strategy, direct to the AI Coach (Coach tab in the Hack The SEO Dashboard).
- Be helpful and direct.";

        if ( ! empty( $chunks ) ) {
            $prompt .= "\n\n--- DOCUMENTATION ---\n";
            foreach ( $chunks as $c ) {
                $prompt .= "\n[" . $c['article'] . ' > ' . $c['heading'] . "]\n" . $c['body'] . "\n";
            }
            $prompt .= "\n--- END DOCUMENTATION ---";
        }

        return $prompt;
    }

    /* ═══════════════════════════════════════════
       AJAX — SEND CONVERSATION BY EMAIL
       ═══════════════════════════════════════════ */

    public static function ajax_send_email() {
        check_ajax_referer( 'hts_docs_nonce', 'nonce' );

        $client_email = sanitize_email( wp_unslash( $_POST['client_email'] ?? '' ) );
        $conversation = sanitize_textarea_field( wp_unslash( $_POST['conversation'] ?? '' ) );
        $site_url     = home_url();
        $user         = wp_get_current_user();
        $user_name    = $user->display_name ?: $user->user_login;

        if ( ! is_email( $client_email ) ) {
            wp_send_json_error( array( 'message' => 'Invalid email' ) );
        }

        $subject = '[HTS Support] Conversation de ' . $user_name . ' — ' . wp_parse_url( $site_url, PHP_URL_HOST );

        $body  = "Nouvelle conversation support Hack The SEO\n";
        $body .= "==========================================\n\n";
        $body .= "Client : " . $user_name . " <" . $client_email . ">\n";
        $body .= "Site : " . $site_url . "\n";
        $body .= "Date : " . current_time( 'Y-m-d H:i' ) . "\n\n";
        $body .= "--- Conversation ---\n\n";
        $body .= $conversation . "\n\n";
        $body .= "--- Fin ---\n";

        $headers = array(
            'Content-Type: text/plain; charset=UTF-8',
            'Reply-To: ' . $client_email,
        );

        $sent = wp_mail( 'support@hacktheseo.com', $subject, $body, $headers );

        // Also send a copy to the client
        if ( $sent ) {
            $lang = self::get_lang();
            $client_subject = ( $lang === 'fr' )
                ? 'Votre conversation avec le support Hack The SEO'
                : 'Your conversation with Hack The SEO support';
            $client_body = ( $lang === 'fr' )
                ? "Bonjour " . $user_name . ",\n\nVoici une copie de votre conversation avec notre support.\nNotre equipe vous repondra dans les plus brefs delais.\n\n--- Conversation ---\n\n" . $conversation . "\n\n--- Fin ---\n\nL'equipe Hack The SEO\nsupport@hacktheseo.com"
                : "Hello " . $user_name . ",\n\nHere is a copy of your conversation with our support.\nOur team will respond as soon as possible.\n\n--- Conversation ---\n\n" . $conversation . "\n\n--- End ---\n\nThe Hack The SEO Team\nsupport@hacktheseo.com";

            wp_mail( $client_email, $client_subject, $client_body, $headers );
        }

        $lang = self::get_lang();
        $confirm = ( $lang === 'fr' )
            ? 'Conversation envoyee a notre equipe. Vous recevrez une copie a ' . $client_email . '. Nous vous repondrons rapidement.'
            : 'Conversation sent to our team. You will receive a copy at ' . $client_email . '. We will respond shortly.';

        wp_send_json_success( array( 'message' => $confirm ) );
    }

    /* ═══════════════════════════════════════════
       ASSETS
       ═══════════════════════════════════════════ */

    public static function enqueue_assets( $hook ) {
        // Only on HTS admin pages
        if ( strpos( $hook, 'hack-the-seo' ) === false && strpos( $hook, 'hts' ) === false ) {
            // Also load on all admin pages for the floating widget
            // Comment this return to restrict to HTS pages only
            // return;
        }

        wp_localize_script( 'jquery', 'htsDocs', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'hts_docs_nonce' ),
            'lang'    => self::get_lang(),
            'supportEmail' => 'support@hacktheseo.com',
        ) );
    }

    /* ═══════════════════════════════════════════
       WIDGET RENDER
       ═══════════════════════════════════════════ */

    public static function render_widget() {
        // Detect current admin page context
        $screen = get_current_screen();
        $context = '';
        if ( $screen ) {
            $map = array(
                'toplevel_page_hack-the-seo' => 'dashboard',
                'hack-the-seo_page_hts-inbox' => 'inbox',
                'hack-the-seo_page_hts-analytics' => 'analytics',
                'hack-the-seo_page_hts-cocon' => 'cocon-commander',
                'hack-the-seo_page_hts-coach' => 'coach',
                'hack-the-seo_page_hts-settings' => 'settings-unified',
                'hack-the-seo_page_hts-redirections' => 'redirections',
                'hack-the-seo_page_hts-health' => 'health',
                'hack-the-seo_page_hts-planning' => 'planning',
            );
            $context = $map[ $screen->id ] ?? '';
        }

        $lang = self::get_lang();
        $is_fr = ( $lang === 'fr' );
        ?>
        <!-- HTS Support Widget — Intercom Style -->
        <div id="hts-iw" style="display:none">
            <!-- Bubble -->
            <div id="hts-iw-bubble">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
            </div>

            <!-- Panel -->
            <div id="hts-iw-panel">
                <!-- ═══ VIEW: HOME ═══ -->
                <div class="hts-iw-view" id="hts-iw-home" data-view="home">
                    <div class="hts-iw-topbar">
                        <span class="hts-iw-topbar-title">Hack The SEO</span>
                        <button class="hts-iw-close-btn" data-close>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>
                        </button>
                    </div>
                    <div class="hts-iw-home-content">
                        <!-- Welcome card → goes to chat -->
                        <div class="hts-iw-welcome-card" id="hts-iw-goto-chat">
                            <div class="hts-iw-welcome-text">
                                <div class="hts-iw-welcome-title"><?php echo $is_fr ? 'Poser une question' : 'Ask a question'; ?></div>
                                <div class="hts-iw-welcome-sub"><?php echo $is_fr ? 'Notre assistant IA peut vous aider' : 'Our AI assistant can help you'; ?></div>
                            </div>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </div>
                        <!-- Search -->
                        <div class="hts-iw-search-box">
                            <input type="text" id="hts-iw-search" placeholder="<?php echo $is_fr ? 'Trouver une reponse' : 'Find an answer'; ?>" autocomplete="off" />
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                        </div>
                        <!-- Search results (hidden by default) -->
                        <div id="hts-iw-search-results" style="display:none"></div>
                        <!-- Suggested article (contextual) -->
                        <div id="hts-iw-suggested" style="display:none">
                            <div class="hts-iw-section-label"><?php echo $is_fr ? 'Suggere pour vous' : 'Suggested for you'; ?></div>
                            <div id="hts-iw-suggested-list"></div>
                        </div>
                    </div>
                </div>

                <!-- ═══ VIEW: CHAT ═══ -->
                <div class="hts-iw-view" id="hts-iw-chat" data-view="chat" style="display:none">
                    <div class="hts-iw-topbar">
                        <button class="hts-iw-back-btn" data-nav="home">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                        </button>
                        <div class="hts-iw-topbar-center">
                            <div class="hts-iw-topbar-title" style="font-size:14px">Support IA</div>
                            <div class="hts-iw-topbar-sub"><?php echo $is_fr ? 'Repond en quelques secondes' : 'Responds in seconds'; ?></div>
                        </div>
                        <button class="hts-iw-close-btn" data-close>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>
                        </button>
                    </div>
                    <div id="hts-iw-messages">
                        <div class="hts-iw-msg bot">
                            <div class="hts-iw-msg-bubble bot"><?php echo $is_fr ? 'Bonjour ! Comment puis-je vous aider avec Hack The SEO ?' : 'Hello! How can I help you with Hack The SEO?'; ?></div>
                            <div class="hts-iw-msg-meta">Support IA</div>
                        </div>
                    </div>
                    <div id="hts-iw-chat-input-area">
                        <input type="text" id="hts-iw-chat-input" placeholder="<?php echo $is_fr ? 'Posez une question...' : 'Ask a question...'; ?>" autocomplete="off" />
                        <button id="hts-iw-send">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        </button>
                    </div>
                </div>

                <!-- ═══ VIEW: AIDE (Collections) ═══ -->
                <div class="hts-iw-view" id="hts-iw-aide" data-view="aide" style="display:none">
                    <div class="hts-iw-topbar">
                        <span class="hts-iw-topbar-title"><?php echo $is_fr ? 'Aide' : 'Help'; ?></span>
                        <button class="hts-iw-close-btn" data-close>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>
                        </button>
                    </div>
                    <div class="hts-iw-aide-content">
                        <div class="hts-iw-search-box">
                            <input type="text" id="hts-iw-aide-search" placeholder="<?php echo $is_fr ? 'Trouver une reponse' : 'Find an answer'; ?>" autocomplete="off" />
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                        </div>
                        <div id="hts-iw-collections"></div>
                        <!-- Article list within a collection (hidden) -->
                        <div id="hts-iw-collection-articles" style="display:none"></div>
                        <!-- Article detail (hidden) -->
                        <div id="hts-iw-article-detail" style="display:none"></div>
                    </div>
                </div>

                <!-- ═══ BOTTOM NAV ═══ -->
                <div id="hts-iw-nav">
                    <button class="hts-iw-nav-item active" data-nav="home">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
                        <span><?php echo $is_fr ? 'Accueil' : 'Home'; ?></span>
                    </button>
                    <button class="hts-iw-nav-item" data-nav="chat">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                        <span><?php echo $is_fr ? 'Chat' : 'Chat'; ?></span>
                    </button>
                    <button class="hts-iw-nav-item" data-nav="aide">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                        <span><?php echo $is_fr ? 'Aide' : 'Help'; ?></span>
                    </button>
                </div>
            </div>
        </div>

        <style>
        /* ─── HTS Intercom Widget ─── */
        :root { --iw-bg: #1a1a1f; --iw-surface: #242429; --iw-border: #2e2e36; --iw-text: #f0f0f5; --iw-text2: #9ca3af; --iw-text3: #6b7280; --iw-accent: #2D7FF9; --iw-accent2: #1B6EF3; --iw-success: #00D26A; --iw-radius: 18px; --iw-font: -apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',system-ui,sans-serif; }

        #hts-iw { position:fixed; bottom:24px; right:24px; z-index:999999; font-family:var(--iw-font); }

        /* Bubble */
        #hts-iw-bubble { width:56px; height:56px; border-radius:50%; background:var(--iw-accent); display:flex; align-items:center; justify-content:center; cursor:pointer; box-shadow:0 4px 16px rgba(45,127,249,.4); transition:transform .2s cubic-bezier(.16,1,.3,1); }
        #hts-iw-bubble:hover { transform:scale(1.08); }

        /* Panel */
        #hts-iw-panel { display:none; position:absolute; bottom:72px; right:0; width:420px; height:640px; background:var(--iw-bg); border-radius:var(--iw-radius); box-shadow:0 12px 48px rgba(0,0,0,.4); overflow:hidden; flex-direction:column; border:1px solid var(--iw-border); }
        #hts-iw-panel.open { display:flex; animation:htsIWSlide .3s cubic-bezier(.16,1,.3,1); }
        @keyframes htsIWSlide { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

        /* Views */
        .hts-iw-view { display:flex; flex-direction:column; flex:1; min-height:0; overflow:hidden; }

        /* Topbar */
        .hts-iw-topbar { display:flex; align-items:center; justify-content:space-between; padding:16px 18px; border-bottom:1px solid var(--iw-border); flex-shrink:0; }
        .hts-iw-topbar-title { font-size:16px; font-weight:700; color:var(--iw-text); }
        .hts-iw-topbar-center { text-align:center; flex:1; }
        .hts-iw-topbar-sub { font-size:11px; color:var(--iw-text3); margin-top:1px; }
        .hts-iw-close-btn, .hts-iw-back-btn { background:none; border:none; cursor:pointer; color:var(--iw-text2); padding:4px; border-radius:8px; display:flex; align-items:center; }
        .hts-iw-close-btn:hover, .hts-iw-back-btn:hover { background:var(--iw-surface); color:var(--iw-text); }

        /* Home content */
        .hts-iw-home-content { flex:1; overflow-y:auto; padding:16px; }

        /* Welcome card */
        .hts-iw-welcome-card { display:flex; align-items:center; justify-content:space-between; padding:16px 18px; background:var(--iw-surface); border-radius:14px; cursor:pointer; transition:background .15s; margin-bottom:16px; }
        .hts-iw-welcome-card:hover { background:#2c2c34; }
        .hts-iw-welcome-card svg { color:var(--iw-text3); flex-shrink:0; }
        .hts-iw-welcome-title { font-size:15px; font-weight:600; color:var(--iw-text); }
        .hts-iw-welcome-sub { font-size:12px; color:var(--iw-text3); margin-top:2px; }

        /* Search box */
        .hts-iw-search-box { position:relative; margin-bottom:16px; }
        .hts-iw-search-box input { width:100%; padding:11px 40px 11px 14px; border-radius:10px; border:1px solid var(--iw-border); background:var(--iw-surface); color:var(--iw-text); font-size:13px; font-family:var(--iw-font); outline:none; box-sizing:border-box; }
        .hts-iw-search-box input:focus { border-color:var(--iw-accent); }
        .hts-iw-search-box input::placeholder { color:var(--iw-text3); }
        .hts-iw-search-box svg { position:absolute; right:12px; top:50%; transform:translateY(-50%); color:var(--iw-text3); pointer-events:none; }

        /* Section label */
        .hts-iw-section-label { font-size:12px; font-weight:700; color:var(--iw-text2); margin-bottom:10px; }

        /* Suggested / search result items */
        .hts-iw-item { display:flex; align-items:center; justify-content:space-between; padding:12px 14px; background:var(--iw-surface); border-radius:10px; cursor:pointer; transition:background .12s; margin-bottom:8px; }
        .hts-iw-item:hover { background:#2c2c34; }
        .hts-iw-item-title { font-size:13px; font-weight:600; color:var(--iw-text); }
        .hts-iw-item-sub { font-size:11px; color:var(--iw-text3); margin-top:2px; }
        .hts-iw-item svg { color:var(--iw-text3); flex-shrink:0; }
        .hts-iw-item-badge { font-size:9px; font-weight:600; padding:2px 6px; border-radius:6px; margin-left:8px; }
        .hts-iw-item-badge.saas { background:rgba(45,127,249,.15); color:var(--iw-accent); }
        .hts-iw-item-badge.wp { background:rgba(0,210,106,.12); color:var(--iw-success); }

        /* Chat messages */
        #hts-iw-messages { flex:1; overflow-y:auto; padding:16px; display:flex; flex-direction:column; gap:12px; }
        .hts-iw-msg { display:flex; flex-direction:column; }
        .hts-iw-msg.user { align-items:flex-end; }
        .hts-iw-msg.bot { align-items:flex-start; }
        .hts-iw-msg-bubble { max-width:85%; padding:12px 16px; border-radius:16px; font-size:13.5px; line-height:1.55; word-wrap:break-word; }
        .hts-iw-msg-bubble.user { background:var(--iw-accent); color:#fff; border-bottom-right-radius:4px; }
        .hts-iw-msg-bubble.bot { background:var(--iw-surface); color:var(--iw-text); border-bottom-left-radius:4px; border:1px solid var(--iw-border); }
        .hts-iw-msg-bubble.bot b, .hts-iw-msg-bubble.bot strong { color:#fff; font-weight:700; }
        .hts-iw-msg-bubble.bot br + br { display:block; content:""; margin:4px 0; }
        .hts-iw-msg-meta { font-size:10px; color:var(--iw-text3); margin-top:4px; padding:0 4px; }
        .hts-iw-msg-bubble.escalate { border-color:rgba(255,149,0,.4); background:rgba(255,149,0,.08); }

        /* Typing indicator */
        .hts-iw-typing { display:flex; gap:4px; padding:12px 16px; }
        .hts-iw-typing span { width:7px; height:7px; border-radius:50%; background:var(--iw-text3); animation:htsIWBounce 1.2s infinite; }
        .hts-iw-typing span:nth-child(2) { animation-delay:.15s; }
        .hts-iw-typing span:nth-child(3) { animation-delay:.3s; }
        @keyframes htsIWBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }

        /* Chat input */
        #hts-iw-chat-input-area { display:flex; align-items:center; gap:8px; padding:12px 16px; border-top:1px solid var(--iw-border); flex-shrink:0; }
        #hts-iw-chat-input { flex:1; padding:10px 14px; border:1px solid var(--iw-border); border-radius:12px; background:var(--iw-surface); color:var(--iw-text); font-size:13px; font-family:var(--iw-font); outline:none; box-sizing:border-box; }
        #hts-iw-chat-input:focus { border-color:var(--iw-accent); }
        #hts-iw-chat-input::placeholder { color:var(--iw-text3); }
        #hts-iw-send { width:38px; height:38px; border-radius:50%; border:none; background:var(--iw-accent); color:#fff; cursor:pointer; display:flex; align-items:center; justify-content:center; flex-shrink:0; transition:background .12s; }
        #hts-iw-send:hover { background:var(--iw-accent2); }

        /* Aide content */
        .hts-iw-aide-content { flex:1; overflow-y:auto; padding:16px; }

        /* Collection row */
        .hts-iw-collection { display:flex; align-items:center; justify-content:space-between; padding:14px 0; border-bottom:1px solid var(--iw-border); cursor:pointer; }
        .hts-iw-collection:hover .hts-iw-collection-title { color:var(--iw-accent); }
        .hts-iw-collection-title { font-size:14px; font-weight:600; color:var(--iw-text); transition:color .12s; }
        .hts-iw-collection-count { font-size:12px; color:var(--iw-text3); }
        .hts-iw-collection svg { color:var(--iw-text3); flex-shrink:0; }

        /* Article detail */
        .hts-iw-detail-back { display:flex; align-items:center; gap:4px; font-size:12px; color:var(--iw-accent); cursor:pointer; border:none; background:none; padding:0; margin-bottom:16px; font-weight:600; font-family:var(--iw-font); }
        .hts-iw-detail h3 { font-size:17px; font-weight:700; color:var(--iw-text); margin:0 0 16px; }
        .hts-iw-detail-sec { margin-bottom:18px; }
        .hts-iw-detail-sec h4 { font-size:13px; font-weight:700; color:var(--iw-text); margin:0 0 6px; }
        .hts-iw-detail-sec p { font-size:12.5px; color:var(--iw-text2); line-height:1.65; margin:0; }

        /* Bottom nav */
        #hts-iw-nav { display:flex; border-top:1px solid var(--iw-border); background:var(--iw-surface); flex-shrink:0; }
        .hts-iw-nav-item { flex:1; display:flex; flex-direction:column; align-items:center; gap:3px; padding:10px 0; border:none; background:none; cursor:pointer; color:var(--iw-text3); font-size:10px; font-weight:500; font-family:var(--iw-font); transition:color .15s; }
        .hts-iw-nav-item.active { color:var(--iw-text); }
        .hts-iw-nav-item:hover { color:var(--iw-text2); }

        /* No results */
        .hts-iw-empty { text-align:center; padding:32px 16px; color:var(--iw-text3); font-size:13px; }
        </style>

        <script>
        (function(){
            var $=jQuery, cfg=window.htsDocs||{}, ctx='<?php echo esc_js($context); ?>';
            var bubble=document.getElementById('hts-iw-bubble');
            var panel=document.getElementById('hts-iw-panel');
            var widget=document.getElementById('hts-iw');
            var isOpen=false, articlesCache=null, catsCache=null;

            widget.style.display='block';

            // ── Toggle ──
            bubble.addEventListener('click',function(){
                isOpen=true; panel.classList.add('open'); bubble.style.display='none';
                if(!articlesCache) loadAllData();
                // Open directly on Chat
                showView('chat');
                document.querySelectorAll('.hts-iw-nav-item').forEach(function(n){ n.classList.toggle('active',n.dataset.nav==='chat'); });
                setTimeout(function(){ document.getElementById('hts-iw-chat-input').focus(); },300);
            });
            document.querySelectorAll('[data-close]').forEach(function(b){
                b.addEventListener('click',function(){ isOpen=false; panel.classList.remove('open'); bubble.style.display='flex'; });
            });

            // ── Navigation ──
            document.querySelectorAll('[data-nav]').forEach(function(b){
                b.addEventListener('click',function(){
                    var target=this.dataset.nav;
                    if(target==='email'){ window.open('mailto:support@hacktheseo.com','_blank'); return; }
                    showView(target);
                    document.querySelectorAll('.hts-iw-nav-item').forEach(function(n){ n.classList.toggle('active',n.dataset.nav===target); });
                });
            });
            document.getElementById('hts-iw-goto-chat').addEventListener('click',function(){
                showView('chat');
                document.querySelectorAll('.hts-iw-nav-item').forEach(function(n){ n.classList.toggle('active',n.dataset.nav==='chat'); });
                document.getElementById('hts-iw-chat-input').focus();
            });

            function showView(name){
                document.querySelectorAll('.hts-iw-view').forEach(function(v){ v.style.display='none'; });
                var el=document.getElementById('hts-iw-'+name);
                if(el){ el.style.display='flex'; }
                if(name==='aide') renderCollections();
            }

            // ── Data loading ──
            function loadAllData(){
                $.post(cfg.ajaxUrl,{action:'hts_docs_articles',nonce:cfg.nonce,context_page:'',category:''},function(r){
                    if(r.success){ articlesCache=r.data.articles; catsCache=r.data.categories; }
                });
            }
            function loadSuggested(){
                $.post(cfg.ajaxUrl,{action:'hts_docs_articles',nonce:cfg.nonce,context_page:ctx,category:''},function(r){
                    if(!r.success||!r.data.articles.length) return;
                    var box=document.getElementById('hts-iw-suggested');
                    var list=document.getElementById('hts-iw-suggested-list');
                    var html='';
                    r.data.articles.slice(0,3).forEach(function(a){
                        var badge=a.product==='wordpress'?'<span class="hts-iw-item-badge wp">WP</span>':'<span class="hts-iw-item-badge saas">SaaS</span>';
                        html+='<div class="hts-iw-item" data-id="'+a.id+'"><div><div class="hts-iw-item-title">'+a.title+badge+'</div><div class="hts-iw-item-sub">'+a.excerpt+'</div></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></div>';
                    });
                    list.innerHTML=html; box.style.display='block';
                    list.querySelectorAll('.hts-iw-item').forEach(function(el){
                        el.addEventListener('click',function(){
                            var a=r.data.articles.find(function(x){return x.id===el.dataset.id;});
                            if(a) showArticle(a);
                        });
                    });
                });
            }

            // ── Search (both home and aide) ──
            var searchTO;
            ['hts-iw-search','hts-iw-aide-search'].forEach(function(id){
                var inp=document.getElementById(id);
                if(!inp) return;
                inp.addEventListener('input',function(){
                    var q=this.value; clearTimeout(searchTO);
                    if(q.length<2){ document.getElementById('hts-iw-search-results').style.display='none'; return; }
                    searchTO=setTimeout(function(){
                        $.post(cfg.ajaxUrl,{action:'hts_docs_search',nonce:cfg.nonce,query:q},function(r){
                            if(!r.success) return;
                            var target=document.getElementById('hts-iw-search-results');
                            if(!r.data.results.length){ target.innerHTML='<div class="hts-iw-empty"><?php echo $is_fr ? "Aucun resultat" : "No results"; ?></div>'; target.style.display='block'; return; }
                            var html='';
                            r.data.results.forEach(function(res){
                                var badge=res.product==='wordpress'?'<span class="hts-iw-item-badge wp">WP</span>':'<span class="hts-iw-item-badge saas">SaaS</span>';
                                html+='<div class="hts-iw-item" data-id="'+res.id+'"><div><div class="hts-iw-item-title">'+res.title+badge+'</div><div class="hts-iw-item-sub">'+(res.snippet||res.excerpt)+'</div></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></div>';
                            });
                            target.innerHTML=html; target.style.display='block';
                        });
                    },300);
                });
            });

            // ── Collections (Aide) ──
            function renderCollections(){
                if(!catsCache){ loadAllData(); setTimeout(renderCollections,500); return; }
                var el=document.getElementById('hts-iw-collections');
                var detail=document.getElementById('hts-iw-collection-articles');
                var artDetail=document.getElementById('hts-iw-article-detail');
                detail.style.display='none'; artDetail.style.display='none'; el.style.display='block';

                var counts={};
                (articlesCache||[]).forEach(function(a){ counts[a.category]=(counts[a.category]||0)+1; });

                var html='<div class="hts-iw-section-label">'+(catsCache.length)+' collections</div>';
                catsCache.forEach(function(c){
                    html+='<div class="hts-iw-collection" data-cat="'+c.id+'"><div><div class="hts-iw-collection-title">'+c.label+'</div><div class="hts-iw-collection-count">'+(counts[c.id]||0)+' article'+(counts[c.id]>1?'s':'')+'</div></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></div>';
                });
                el.innerHTML=html;

                el.querySelectorAll('.hts-iw-collection').forEach(function(row){
                    row.addEventListener('click',function(){
                        var cat=this.dataset.cat;
                        var arts=(articlesCache||[]).filter(function(a){return a.category===cat;});
                        showCollectionArticles(cat,arts);
                    });
                });
            }

            function showCollectionArticles(catId,articles){
                document.getElementById('hts-iw-collections').style.display='none';
                var el=document.getElementById('hts-iw-collection-articles');
                var catLabel=(catsCache||[]).find(function(c){return c.id===catId;});
                var html='<button class="hts-iw-detail-back" id="hts-iw-col-back"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg> <?php echo $is_fr ? "Retour" : "Back"; ?></button>';
                html+='<div class="hts-iw-section-label">'+(catLabel?catLabel.label:catId)+'</div>';
                articles.forEach(function(a){
                    var badge=a.product==='wordpress'?'<span class="hts-iw-item-badge wp">WP</span>':'<span class="hts-iw-item-badge saas">SaaS</span>';
                    html+='<div class="hts-iw-item" data-id="'+a.id+'"><div><div class="hts-iw-item-title">'+a.title+badge+'</div><div class="hts-iw-item-sub">'+a.excerpt+'</div></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></div>';
                });
                el.innerHTML=html; el.style.display='block';
                document.getElementById('hts-iw-col-back').addEventListener('click',function(){ renderCollections(); });
                el.querySelectorAll('.hts-iw-item').forEach(function(item){
                    item.addEventListener('click',function(){
                        var a=articles.find(function(x){return x.id===item.dataset.id;});
                        if(a&&a.sections) showArticle(a);
                    });
                });
            }

            function showArticle(article){
                showView('aide');
                document.getElementById('hts-iw-collections').style.display='none';
                document.getElementById('hts-iw-collection-articles').style.display='none';
                var el=document.getElementById('hts-iw-article-detail');
                var html='<div class="hts-iw-detail"><button class="hts-iw-detail-back" id="hts-iw-art-back"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg> <?php echo $is_fr ? "Retour" : "Back"; ?></button>';
                html+='<h3>'+article.title+'</h3>';
                (article.sections||[]).forEach(function(s){
                    html+='<div class="hts-iw-detail-sec"><h4>'+s.heading+'</h4><p>'+s.body+'</p></div>';
                });
                if(article.url) html+='<a href="'+article.url+'" target="_blank" style="display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--iw-accent);font-weight:600;text-decoration:none;margin-top:8px;"><?php echo $is_fr ? "Documentation complete" : "Full documentation"; ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></a>';
                html+='</div>';
                el.innerHTML=html; el.style.display='block';
                document.getElementById('hts-iw-art-back').addEventListener('click',function(){ renderCollections(); });
                document.querySelectorAll('.hts-iw-nav-item').forEach(function(n){ n.classList.toggle('active',n.dataset.nav==='aide'); });
            }

            // ── Chat ──
            var msgBox=document.getElementById('hts-iw-messages');
            var chatHistory=[];
            var waitingForEmail=false;

            function mdToHtml(text){
                // Sanitize first (escape HTML from user input)
                var s=text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                // Bold: **text** → <strong>text</strong>
                s=s.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
                // Line breaks: double newline → paragraph break
                s=s.replace(/\n\n/g,'<br><br>');
                // Single newline → <br>
                s=s.replace(/\n/g,'<br>');
                // Numbered steps: "1. " at start of line → styled
                s=s.replace(/(^|<br>)(\d+)\.\s/g,'$1<strong>$2.</strong> ');
                // Bullet: "- " at start of line → styled
                s=s.replace(/(^|<br>)- /g,'$1<span style="color:var(--iw-accent);margin-right:4px">&#8226;</span> ');
                return s;
            }

            function addMsg(role,text,extra){
                var div=document.createElement('div'); div.className='hts-iw-msg '+role;
                var bubble=document.createElement('div'); bubble.className='hts-iw-msg-bubble '+role;
                if(extra==='escalate') bubble.classList.add('escalate');
                // User messages: plain text. Bot messages: markdown rendered
                if(role==='user'){
                    bubble.textContent=text;
                } else {
                    bubble.innerHTML=mdToHtml(text);
                }
                div.appendChild(bubble);
                var meta=document.createElement('div'); meta.className='hts-iw-msg-meta';
                meta.textContent=role==='bot'?'Support IA':'';
                div.appendChild(meta); msgBox.appendChild(div);
                msgBox.scrollTop=msgBox.scrollHeight;
                chatHistory.push({role:role,text:text});
            }

            function addCoachButton(){
                var div=document.createElement('div'); div.className='hts-iw-msg bot';
                var bubble=document.createElement('div'); bubble.className='hts-iw-msg-bubble bot';
                bubble.style.borderColor='rgba(99,102,241,.4)';
                bubble.style.background='rgba(99,102,241,.08)';
                bubble.innerHTML='<?php echo $is_fr ? "Pour une analyse personnalisee basee sur les donnees de ton site, le <b>Coach SEO</b> peut t\'aider." : "For a personalized analysis based on your site data, the <b>SEO Coach</b> can help."; ?><br><br><button class="hts-iw-coach-btn" style="background:#6366F1;color:#fff;border:none;padding:8px 16px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--iw-font);display:inline-flex;align-items:center;gap:6px"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg><?php echo $is_fr ? "Demander au Coach" : "Ask the Coach"; ?></button>';
                div.appendChild(bubble);
                var meta=document.createElement('div'); meta.className='hts-iw-msg-meta';
                meta.textContent='Support IA'; div.appendChild(meta);
                msgBox.appendChild(div); msgBox.scrollTop=msgBox.scrollHeight;

                bubble.querySelector('.hts-iw-coach-btn').addEventListener('click',function(){
                    // Navigate to Coach SEO page
                    // Coach is a tab in the dashboard
                    var coachUrl=window.location.href.replace(/page=[^&]*/,'page=hts-light-dashboard').replace(/&tab=[^&]*/,'')+'&tab=coach';
                    if(coachUrl.indexOf('page=hts-light-dashboard')===-1){
                        coachUrl=window.location.pathname+'?page=hts-light-dashboard&tab=coach';
                    }
                    window.location.href=coachUrl;
                });
            }

            function addEmailButton(){
                var div=document.createElement('div'); div.className='hts-iw-msg bot';
                var bubble=document.createElement('div'); bubble.className='hts-iw-msg-bubble bot';
                bubble.innerHTML='<?php echo $is_fr ? "Vous souhaitez qu\'un membre de notre equipe vous recontacte ? Entrez votre email et nous vous enverrons une copie de cette conversation." : "Would you like a team member to follow up? Enter your email and we will send you a copy of this conversation."; ?><br><br><button class="hts-iw-email-escalate-btn" style="background:var(--iw-accent);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--iw-font)"><?php echo $is_fr ? "Contacter l\'equipe" : "Contact the team"; ?></button>';
                div.appendChild(bubble);
                var meta=document.createElement('div'); meta.className='hts-iw-msg-meta';
                meta.textContent='Support IA'; div.appendChild(meta);
                msgBox.appendChild(div); msgBox.scrollTop=msgBox.scrollHeight;

                bubble.querySelector('.hts-iw-email-escalate-btn').addEventListener('click',function(){
                    waitingForEmail=true;
                    addMsg('bot','<?php echo $is_fr ? "Entrez votre adresse email :" : "Enter your email address:"; ?>');
                    document.getElementById('hts-iw-chat-input').placeholder='<?php echo $is_fr ? "votre@email.com" : "your@email.com"; ?>';
                    document.getElementById('hts-iw-chat-input').focus();
                });
            }

            function sendEmailEscalation(email){
                waitingForEmail=false;
                document.getElementById('hts-iw-chat-input').placeholder='<?php echo $is_fr ? "Posez une question..." : "Ask a question..."; ?>';

                var convoText='';
                chatHistory.forEach(function(m){
                    convoText+=(m.role==='user'?'Client':'Support IA')+': '+m.text.replace(/<[^>]*>/g,'')+'\n\n';
                });

                showTyping();
                $.post(cfg.ajaxUrl,{
                    action:'hts_docs_email',
                    nonce:cfg.nonce,
                    client_email:email,
                    conversation:convoText
                },function(r){
                    hideTyping();
                    if(r.success){ addMsg('bot',r.data.message); }
                    else { addMsg('bot','<?php echo $is_fr ? "Erreur d\'envoi. Contactez directement support@hacktheseo.com" : "Send error. Contact support@hacktheseo.com directly"; ?>','escalate'); }
                }).fail(function(){
                    hideTyping();
                    addMsg('bot','<?php echo $is_fr ? "Erreur de connexion." : "Connection error."; ?>','escalate');
                });
            }

            function showTyping(){
                var d=document.createElement('div');d.className='hts-iw-typing';d.id='hts-iw-typing';
                d.innerHTML='<span></span><span></span><span></span>';
                msgBox.appendChild(d); msgBox.scrollTop=msgBox.scrollHeight;
            }
            function hideTyping(){ var e=document.getElementById('hts-iw-typing'); if(e)e.remove(); }

            function sendChat(){
                var inp=document.getElementById('hts-iw-chat-input');
                var msg=inp.value.trim(); if(!msg) return; inp.value='';

                // If waiting for email
                if(waitingForEmail){
                    addMsg('user',msg);
                    if(msg.indexOf('@')>-1 && msg.indexOf('.')>-1){
                        sendEmailEscalation(msg);
                    } else {
                        addMsg('bot','<?php echo $is_fr ? "Ce n\'est pas une adresse email valide. Reessayez :" : "That doesn\'t look like a valid email. Try again:"; ?>');
                    }
                    return;
                }

                addMsg('user',msg); showTyping();
                // Build history for API (last 4 exchanges)
                var historyForApi=chatHistory.slice(-8).map(function(m){
                    return {role:m.role==='user'?'user':'assistant',text:m.text.replace(/<[^>]*>/g,'').substring(0,500)};
                });
                $.post(cfg.ajaxUrl,{action:'hts_docs_chat',nonce:cfg.nonce,message:msg,context_page:ctx,history:JSON.stringify(historyForApi)},function(r){
                    hideTyping();
                    if(r.success){
                        addMsg('bot',r.data.reply,r.data.escalate!=='none'?'escalate':'');
                        // Coach escalation: bot answered + show "Ask the Coach" button
                        if(r.data.escalate==='coach'){
                            addCoachButton();
                        }
                        // Email escalation: bot could not answer
                        if(r.data.escalate==='email'||r.data.reply.indexOf('support@hacktheseo.com')>-1){
                            addEmailButton();
                        }
                    } else {
                        addMsg('bot','<?php echo $is_fr ? "Erreur. Essayez a nouveau." : "Error. Try again."; ?>','escalate');
                        addEmailButton();
                    }
                }).fail(function(){ hideTyping(); addMsg('bot','<?php echo $is_fr ? "Erreur de connexion." : "Connection error."; ?>','escalate'); addEmailButton(); });
            }
            document.getElementById('hts-iw-send').addEventListener('click',sendChat);
            document.getElementById('hts-iw-chat-input').addEventListener('keypress',function(e){ if(e.key==='Enter') sendChat(); });
        })();
        </script>
        <?php
    }
}

// Boot
add_action( 'plugins_loaded', array( 'HTS_Support_Docs', 'init' ), 20 );
