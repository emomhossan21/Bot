<?php
defined( 'ABSPATH' ) || exit;
/**
 * Admin functionality for Hack The SEO plugin
 *
 * @link       https://app.hacktheseo.com/
 * @since      2.0.0
 * @package    Hack_The_SEO
 * @subpackage Hack_The_SEO/admin
 *
 * v2.0.0 :
 * - FIX : CSS/JS chargés UNIQUEMENT sur les pages du plugin (plus de Bootstrap global)
 * - FIX : AJAX validation de la clé API contre l'API réelle
 * - FIX : XSS dans le JS (innerHTML brut → échappé côté PHP)
 * - NEW : Dashboard avec stats, logs, détection SEO plugin
 * - NEW : Design moderne sans Bootstrap
 */

class Hts_Synchronise_Articles_Admin {

    private $plugin_name;
    private $version;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version     = $version;
    }

    /**
     * Enqueue styles — UNIQUEMENT sur les pages du plugin
     */
    public function enqueue_styles( $hook ) {
        if ( ! $this->is_plugin_page( $hook ) ) {
            return;
        }
        wp_enqueue_style(
            'hts-admin',
            plugin_dir_url( __FILE__ ) . 'css/hts-synchronise-articles-admin.css',
            [],
            $this->version
        );
    }

    /**
     * Enqueue scripts — UNIQUEMENT sur les pages du plugin
     */
    public function enqueue_scripts( $hook ) {
        if ( ! $this->is_plugin_page( $hook ) ) {
            return;
        }
        wp_enqueue_script(
            'hts-admin',
            plugin_dir_url( __FILE__ ) . 'js/hts-synchronise-articles-admin.js',
            [],
            $this->version,
            true
        );
        $lang_data = array(
            'isMultilingual' => false,
            'currentLang'    => '',
            'languages'      => array(),
        );
        if ( class_exists( 'HTS_Language' ) ) {
            $lang_data['isMultilingual'] = HTS_Language::is_multilingual();
            $lang_data['currentLang']    = HTS_Language::get_current_lang();
            $lang_data['languages']      = HTS_Language::get_available_languages();
        }

        wp_localize_script( 'hts-admin', 'htsAdmin', [
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'hts_admin_nonce' ),
            'lang'    => $lang_data,
        ] );

        // ── SEO Tools panel JS (split from seo-tools.php for maintainability) ──
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'hts-seo-tools' ) {
            wp_enqueue_script( 'hts-common',       plugin_dir_url( __FILE__ ) . 'js/hts-common.js',       [ 'hts-admin' ], $this->version, true );
            wp_enqueue_script( 'hts-meta-score',   plugin_dir_url( __FILE__ ) . 'js/hts-meta-score.js',   [ 'hts-common' ], $this->version, true );
            wp_enqueue_script( 'hts-onpage-score', plugin_dir_url( __FILE__ ) . 'js/hts-onpage-score.js', [ 'hts-common' ], $this->version, true );
        }
    }

    /**
     * Vérifie si on est sur une page du plugin
     */
    private function is_plugin_page( $hook ) {
        if ( ! isset( $_GET['page'] ) ) {
            return false;
        }
        return in_array( $_GET['page'], [ 'hts-synchronise-articles', 'api-settings', 'hts-seo-tools', 'hts-seo-settings', 'hts-migration-wizard', 'hts-light-dashboard', 'hts-upgrade', 'hts-api-settings', 'hts-onboarding', 'hts-redirections', 'hts-analytics', 'hts-cocon-commander', 'hts-editorial-calendar', 'hts-cannibalization', 'hts-planning' ], true );
    }

    public function init() {
        add_action( 'admin_menu', [ $this, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
        add_action( 'wp_ajax_hts_save_and_validate_api_key', [ $this, 'ajax_save_and_validate_api_key' ] );
        add_action( 'wp_ajax_hts_diagnostic', [ $this, 'ajax_diagnostic' ] );
        add_action( 'wp_ajax_hts_download_logs', [ $this, 'ajax_download_logs' ] );
        add_action( 'wp_ajax_hts_save_modules', [ $this, 'ajax_save_modules' ] );
        /* ── API Test AJAX — DÉSACTIVÉ (réactiver si besoin de debug) ──
        add_action( 'wp_ajax_hts_api_test_plan', [ $this, 'ajax_api_test_plan' ] );
        add_action( 'wp_ajax_hts_api_test_article', [ $this, 'ajax_api_test_article' ] );
        add_action( 'wp_ajax_hts_api_test_status', [ $this, 'ajax_api_test_status' ] );
        add_action( 'wp_ajax_hts_api_test_create_draft', [ $this, 'ajax_api_test_create_draft' ] );
        add_action( 'wp_ajax_hts_api_test_clear', [ $this, 'ajax_api_test_clear' ] );
        */
        add_action( 'wp_ajax_hts_save_env', [ $this, 'ajax_save_env' ] );
        add_action( 'wp_ajax_hts_dev_set_tier', [ $this, 'ajax_dev_set_tier' ] );
        /* ── Brouillons AJAX ── */
        add_action( 'wp_ajax_hts_draft_publish', [ $this, 'ajax_draft_publish' ] );
        add_action( 'wp_ajax_hts_draft_schedule', [ $this, 'ajax_draft_schedule' ] );
        add_action( 'wp_ajax_hts_draft_delete', [ $this, 'ajax_draft_delete' ] );
        add_action( 'wp_ajax_hts_draft_checklist', [ $this, 'ajax_draft_checklist' ] );
        /* ── Publication strategy + auto/batch schedule (v2.5.1) ── */
        add_action( 'wp_ajax_hts_save_pub_strategy', [ $this, 'ajax_save_pub_strategy' ] );
        add_action( 'wp_ajax_hts_draft_auto_schedule', [ $this, 'ajax_draft_auto_schedule' ] );
        add_action( 'wp_ajax_hts_draft_batch_schedule', [ $this, 'ajax_draft_batch_schedule' ] );
        add_action( 'wp_ajax_hts_draft_unschedule', [ $this, 'ajax_draft_unschedule' ] );
        add_action( 'wp_ajax_hts_draft_reschedule', [ $this, 'ajax_draft_reschedule' ] );
        /* ── Cocon API — Production (v2.6.0) ── */
        add_action( 'wp_ajax_hts_cocon_generate_plan', [ $this, 'ajax_cocon_generate_plan' ] );
        add_action( 'wp_ajax_hts_cocon_poll_plan', [ $this, 'ajax_cocon_poll_plan' ] );
        add_action( 'wp_ajax_hts_cocon_generate_article', [ $this, 'ajax_cocon_generate_article' ] );
        add_action( 'wp_ajax_hts_cocon_poll_article', [ $this, 'ajax_cocon_poll_article' ] );
        // create_draft est géré uniquement par HTS_Cocon_Commander (+ Article Pipeline)
        add_action( 'wp_ajax_hts_cocon_delete_plan', [ $this, 'ajax_cocon_delete_plan' ] );
        add_action( 'wp_ajax_hts_cocon_get_logs', [ $this, 'ajax_cocon_get_logs' ] );
        /* ── Brand Identity (v2.7.0) ── */
        add_action( 'wp_ajax_hts_save_brand_identity', [ $this, 'ajax_save_brand_identity' ] );
        add_action( 'wp_ajax_hts_save_image_settings', [ $this, 'ajax_save_image_settings' ] );
        add_action( 'wp_ajax_hts_test_flux_key', [ $this, 'ajax_test_flux_key' ] );
        add_action( 'wp_ajax_hts_test_image_generate', [ $this, 'ajax_test_image_generate' ] );
        add_action( 'hts_deferred_images', array( __CLASS__, 'handle_deferred_images' ), 10, 3 );
        add_action( 'hts_deferred_cross_interlink', array( __CLASS__, 'handle_deferred_cross_interlink' ), 10, 1 );
        add_action( 'wp_ajax_hts_detect_brand_colors', [ $this, 'ajax_detect_brand_colors' ] );
        add_action( 'wp_ajax_hts_save_cross_interlink', [ $this, 'ajax_save_cross_interlink' ] );

        // ── Cron / Scheduler (AJAX only — le hook cron est dans hack-the-seo.php) ──
        add_action( 'wp_ajax_hts_save_schedule',       [ $this, 'ajax_save_schedule' ] );
        add_action( 'wp_ajax_hts_cron_run_now',        [ $this, 'ajax_cron_run_now' ] );
        add_action( 'wp_ajax_hts_cron_poll_progress',  [ $this, 'ajax_cron_poll_progress' ] );
        add_action( 'wp_ajax_hts_cron_queue_action',   [ $this, 'ajax_cron_queue_action' ] );

        // ── SEO Settings (v3.3.1) ──
        add_action( 'wp_ajax_hts_save_seo_settings',     [ $this, 'ajax_save_seo_settings' ] );
        add_action( 'wp_ajax_hts_save_settings_mode',    [ $this, 'ajax_save_settings_mode' ] );
        add_action( 'wp_ajax_hts_seo_import_competitor',  [ $this, 'ajax_seo_import_competitor' ] );
        // NOTE: add_action('hts_cron_generate_article') et add_filter('cron_schedules')
        // sont désormais dans hack-the-seo.php pour être chargés même par wp-cron.php
    }

    /**
     * Menu admin
     */
    public function register_menu() {
        // Light has its own simplified menu — skip Full menu
        if ( defined( 'HTS__IS_LIGHT' ) && HTS__IS_LIGHT ) return;

        add_menu_page(
            'Hack The SEO',
            'Hack The SEO',
            'manage_options',
            'hts-synchronise-articles',
            [ $this, 'render_dashboard' ],
            'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0id2hpdGUiPjxwYXRoIGQ9Ik0xNS45LDYuMlY0LjFsLTIuNSwyLjUtNC4zLDQuMy0zLDNMMy44LDExLjZsLS45LS45YzAsLjMuMS43LjEsMSwuNSwyLjIsMi41LDMuOCw0LjgsMy44czUtMi4yLDUtNSwwLS43LS4xLTEuMWwxLjEtMS4xYy4yLjcuNCwxLjQuNCwyLjIsMCwxLjItLjQsMi40LTEsMy4zbDMuNCwzLjRjLjYuNi42LDEuNSwwLDJsLS4xLjFjLS42LjYtMS41LjYtMiwwbC0zLjQtMy40Yy0uOS41LTIsLjgtMy4xLjgtMy41LDAtNi4zLTIuOC02LjMtNi4zczAtLjIsMC0uM2MwLS4yLDAtLjMsMC0uNSwwLS4yLDAtLjMuMS0uNS42LTIuOSwzLjEtNSw2LjItNXMzLjMuNyw0LjUsMS45bC0xLDFjLS45LS45LTIuMi0xLjUtMy41LTEuNXMtMy42LDEuMS00LjUsMi44Yy0uMS4yLS4yLjQtLjIuNmwuNi42LDIuMy0yLjMsMywzLDIuNy0yLjcsMS0xLDItMmgtMnYtMS40aDQuNHY0LjVoLTEuNFoiLz48L3N2Zz4K',
            30
        );

        add_submenu_page(
            'hts-synchronise-articles',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'hts-synchronise-articles',
            [ $this, 'render_dashboard' ]
        );

        add_submenu_page(
            'hts-synchronise-articles',
            'Réglages API',
            'Réglages API',
            'manage_options',
            'api-settings',
            [ $this, 'render_settings' ]
        );

        add_submenu_page(
            'hts-synchronise-articles',
            'Outils SEO',
            'Outils SEO',
            'manage_options',
            'hts-seo-tools',
            [ $this, 'render_seo_tools' ]
        );

        add_submenu_page(
            'hts-synchronise-articles',
            'Réglages SEO',
 'Réglages SEO',
            'manage_options',
            'hts-seo-settings',
            [ $this, 'render_seo_settings' ]
        );

        // Brouillons intégrés dans Outils SEO (v2.5.0)

        /* ── TEST API — DÉSACTIVÉ (réactiver si besoin de debug) ──
        add_submenu_page(
            'hts-synchronise-articles',
 'Test API Cocon',
 'Test API',
            'manage_options',
            'hts-api-test',
            [ $this, 'render_api_test' ]
        );
        */
    }

    /**
     * Page dashboard principale
     */
    public function render_dashboard() {
        // Stats de base
        $published_posts = (int) wp_count_posts()->publish;

        // API
        $api_key       = hts_get_api_key();
        $api_connected = ! empty( $api_key );

        // Plugin SEO détecté
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $seo_plugin = 'Aucun';
        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) $seo_plugin = 'Yoast SEO';
        elseif ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) $seo_plugin = 'RankMath';

        // ── Données croisées de tous les modules ──

        // Cocon
        $cocon = null;
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new \HTS_Cocon();
            $cocon_stats = $cocon->get_quick_stats();
        } else {
            $cocon_stats = array( 'analyzed' => false );
        }

        // Fraîcheur
        $freshness_stats = array( 'total' => 0, 'fresh' => 0, 'review' => 0, 'stale' => 0, 'avg' => 0 );
        if ( class_exists( 'HTS_Freshness' ) ) {
            $f = new \HTS_Freshness();
            $freshness_stats = $f->get_freshness_stats();
        }

        // Content Doctor
        $cd_avg = 0;
        $cd_weak = 0;
        $cd_total = 0;
        global $wpdb;
        $cd_scores = $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_hts_geo_score'" );
        if ( ! empty( $cd_scores ) ) {
            $cd_total = count( $cd_scores );
            $cd_avg   = round( array_sum( $cd_scores ) / $cd_total );
            $cd_weak  = count( array_filter( $cd_scores, function( $s ) { return (int) $s < 40; } ) );
        }

        // GSC
        $gsc_pages  = get_option( 'hts_gsc_pages', array() );
        $gsc_clicks = 0;
        $gsc_impressions = 0;
        if ( ! empty( $gsc_pages ) ) {
            foreach ( $gsc_pages as $gp ) {
                $gsc_clicks      += (int) ( $gp['clicks'] ?? 0 );
                $gsc_impressions += (int) ( $gp['impressions'] ?? 0 );
            }
        }

        // Engagement
        $engagement_stats = array( 'at_risk' => 0 );
        $at_risk_pages = get_option( 'hts_engagement_at_risk', array() );
        $engagement_stats['at_risk'] = count( $at_risk_pages );

        // Citations IA
        $citation_stats = get_option( 'hts_citation_stats', array( 'total' => 0, 'visible' => 0 ) );

        // ── Score global du site ──
        $scores = array();
        $scores_detail = array();

        // Maillage
        if ( $cocon_stats['analyzed'] ) {
            $cs = $cocon_stats['stats'] ?? array();
            $total_pages = max( 1, (int) ( $cs['total_pages'] ?? 1 ) );
            $orphan_pct  = ( 1 - (int) ( $cs['total_orphans'] ?? 0 ) / $total_pages ) * 100;
            $maillage_score = round( $orphan_pct * 0.6 + min( 100, ( (int) ( $cs['total_links'] ?? 0 ) / $total_pages ) * 10 ) * 0.4 );
            $scores['maillage'] = $maillage_score;
 $scores_detail['maillage'] = array( 'score' => $maillage_score, 'label' => 'Structure & maillage', 'icon' => 'link-2' );
        }

        // Contenu
        if ( $cd_total > 0 ) {
            $scores['contenu'] = $cd_avg;
 $scores_detail['contenu'] = array( 'score' => $cd_avg, 'label' => 'Qualité du contenu', 'icon' => 'file-text' );
        }

        // Fraîcheur
        if ( $freshness_stats['total'] > 0 ) {
            $scores['fraicheur'] = (int) $freshness_stats['avg'];
 $scores_detail['fraicheur'] = array( 'score' => (int) $freshness_stats['avg'], 'label' => 'Fraîcheur', 'icon' => 'clock' );
        }

        // Performance
        if ( ! empty( $gsc_pages ) ) {
            $perf = min( 100, ( $gsc_clicks / max( 1, $published_posts ) ) * 5 );
            $scores['performance'] = round( $perf );
 $scores_detail['performance'] = array( 'score' => round( $perf ), 'label' => 'Trafic organique', 'icon' => 'trending-up' );
        }

        $global_score = ! empty( $scores ) ? round( array_sum( $scores ) / count( $scores ) ) : 0;

        // ── Tâches prioritaires ──
        $tasks = array();

        if ( $cocon_stats['analyzed'] ) {
            $orphans = (int) ( $cocon_stats['stats']['total_orphans'] ?? 0 );
            if ( $orphans > 0 ) {
 $tasks[] = array( 'priority' => 'high', 'icon' => 'alert-triangle', 'title' => $orphans . ' page(s) isolée(s)', 'detail' => 'Google ne peut pas les découvrir. Allez dans le Cocon Sémantique pour ajouter des liens.', 'panel' => 'cocon', 'impact' => 'Visibilité Google + IA' );
            }
        } else {
 $tasks[] = array( 'priority' => 'high', 'icon' => 'search', 'title' => 'Analysez votre site', 'detail' => 'Le Cocon Sémantique n\'a pas encore été lancé. C\'est la première étape.', 'panel' => 'cocon', 'impact' => 'Diagnostic complet' );
        }

        if ( $cd_weak > 0 ) {
 $tasks[] = array( 'priority' => 'high', 'icon' => 'alert-circle', 'title' => $cd_weak . ' page(s) avec un contenu faible', 'detail' => 'Score Content Doctor < 40. Améliorez-les pour que les IA vous citent.', 'panel' => 'doctor', 'impact' => 'Autorité + citations IA' );
        } elseif ( $cd_total === 0 ) {
 $tasks[] = array( 'priority' => 'medium', 'icon' => 'stethoscope', 'title' => 'Lancez le Content Doctor', 'detail' => 'Aucune page n\'a été analysée. Scannez vos contenus pour voir leur score.', 'panel' => 'doctor', 'impact' => 'Qualité de contenu' );
        }

        if ( $freshness_stats['stale'] > 0 ) {
 $tasks[] = array( 'priority' => 'medium', 'icon' => 'clock', 'title' => $freshness_stats['stale'] . ' page(s) obsolète(s)', 'detail' => 'Contenu de plus de 6 mois. Les IA privilégient la fraîcheur.', 'panel' => 'freshness', 'impact' => 'Fraîcheur + GEO' );
        }

        if ( empty( $gsc_pages ) ) {
 $tasks[] = array( 'priority' => 'medium', 'icon' => 'trending-up', 'title' => 'Importez vos données Search Console', 'detail' => 'Sans données GSC, impossible de mesurer vos performances réelles.', 'panel' => 'gsc', 'impact' => 'Mesure des résultats' );
        }

        if ( $engagement_stats['at_risk'] > 0 ) {
 $tasks[] = array( 'priority' => 'low', 'icon' => 'activity', 'title' => $engagement_stats['at_risk'] . ' page(s) à risque d\'engagement', 'detail' => 'Temps de lecture faible ou taux de rebond élevé.', 'panel' => 'engagement', 'impact' => 'Rétention utilisateurs' );
        }

        // Sort tasks by priority
        $prio_map = array( 'high' => 0, 'medium' => 1, 'low' => 2 );
        usort( $tasks, function( $a, $b ) use ( $prio_map ) {
            return ( $prio_map[ $a['priority'] ] ?? 2 ) - ( $prio_map[ $b['priority'] ] ?? 2 );
        } );

        // Logs
        $logs = hts_get_logs( 20 );

        include plugin_dir_path( __FILE__ ) . 'partials/hts-synchronise-articles-admin-display.php';
    }

    /**
     * Page réglages API
     */
    public function render_settings() {
        $api_key = hts_get_api_key();

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $seo_plugin = 'Aucun';
        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            $seo_plugin = 'Yoast SEO';
        } elseif ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            $seo_plugin = 'RankMath';
        }

        $webhook_url = rest_url( 'hts-seo-sync/update' );

        // Cron settings
        $cron_enabled  = get_option( 'hts_cron_enabled', '0' );
        $cron_interval = get_option( 'hts_cron_interval', 'hts_daily' );
        $cron_type     = get_option( 'hts_cron_type', 'articles' );
        $cron_status   = get_option( 'hts_cron_status', 'draft' );
        $cron_category = get_option( 'hts_cron_category', 0 );
        $cron_next     = wp_next_scheduled( 'hts_cron_sync_event' );
        $categories    = (array) get_categories( array( 'get' => 'all' ) );

        include plugin_dir_path( __FILE__ ) . 'partials/settings.php';
    }

    /* ══════════════════════════════════════════════════════════════════
     *  SEO SETTINGS PAGE (v3.3.1) — home title/desc, separator, social
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Page Réglages SEO
     */
    public function render_seo_settings() {
        // Current HTS settings
        $settings = array(
            'home_title'       => get_option( 'hts_home_title', '' ),
            'home_description' => get_option( 'hts_home_description', '' ),
            'title_separator'  => get_option( 'hts_title_separator', '—' ),
            'twitter_handle'   => get_option( 'hts_twitter_handle', '' ),
            'social_profiles'  => get_option( 'hts_social_profiles', array() ),
        );
        if ( ! is_array( $settings['social_profiles'] ) ) {
            $settings['social_profiles'] = array();
        }

        // Detect competitor + auto-read their settings as fallback
        $competitor = $this->detect_seo_competitor();
        $competitor_settings = $this->read_competitor_seo_settings( $competitor );

        // Enqueue the specific JS
        wp_enqueue_script(
            'hts-seo-settings',
            plugin_dir_url( __FILE__ ) . 'js/hts-seo-settings.js',
            array(),
            HTS_SYNCHRONISE_ARTICLES_VERSION,
            true
        );

        include plugin_dir_path( __FILE__ ) . 'partials/seo-settings.php';
    }

    /**
     * AJAX: Save SEO settings
     */
    public function ajax_save_seo_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission refusée' ) );
        }

        // Sanitize & save individual options (modules already read them separately)
        $home_title = sanitize_text_field( wp_unslash( $_POST['home_title'] ?? '' ) );
        $home_desc  = sanitize_textarea_field( wp_unslash( $_POST['home_description'] ?? '' ) );
        $separator  = sanitize_text_field( wp_unslash( $_POST['title_separator'] ?? '—' ) );
        $twitter    = sanitize_text_field( wp_unslash( $_POST['twitter_handle'] ?? '' ) );

        // Ensure twitter handle starts with @
        if ( $twitter && strpos( $twitter, '@' ) !== 0 ) {
            $twitter = '@' . $twitter;
        }

        // Social profiles
        $social_raw = json_decode( wp_unslash( $_POST['social_profiles'] ?? '{}' ), true );
        $social = array();
        if ( is_array( $social_raw ) ) {
            foreach ( $social_raw as $key => $url ) {
                $clean = esc_url_raw( $url );
                if ( $clean ) {
                    $social[ sanitize_key( $key ) ] = $clean;
                }
            }
        }

        // Module toggles
        $modules_raw = json_decode( wp_unslash( $_POST['modules'] ?? '{}' ), true );
        if ( is_array( $modules_raw ) ) {
            foreach ( $modules_raw as $mod_key => $val ) {
                $opt = 'hts_module_' . sanitize_key( $mod_key );
                update_option( $opt, $val === '1' ? '1' : '0', false );
            }
        }

        // Save
        update_option( 'hts_home_title', $home_title, false );
        update_option( 'hts_home_description', $home_desc, false );
        update_option( 'hts_title_separator', $separator, false );
        update_option( 'hts_twitter_handle', $twitter, false );
        update_option( 'hts_social_profiles', $social, false );

        // Also build the flat sameAs array for Schema (backward compat)
        $same_as = array_values( $social );
        // Schema module reads hts_social_profiles which is now the keyed array
        // It iterates values, so both formats work

        // Local SEO settings (Schema Pro LocalBusiness)
        $local_raw = json_decode( wp_unslash( $_POST['local_seo'] ?? '{}' ), true );
        if ( is_array( $local_raw ) ) {
            $local_data = array();
            $local_keys = array( 'name', 'address', 'city', 'postal_code', 'country', 'phone', 'email', 'url', 'lat', 'lng', 'price_range', 'opening_hours' );
            foreach ( $local_keys as $k ) {
                $local_data[ $k ] = sanitize_text_field( $local_raw[ $k ] ?? '' );
            }
            if ( ! empty( $local_data['email'] ) ) {
                $local_data['email'] = sanitize_email( $local_data['email'] );
            }
            if ( ! empty( $local_data['url'] ) ) {
                $local_data['url'] = esc_url_raw( $local_data['url'] );
            }
            update_option( 'hts_schema_local_business', $local_data, false );
        }

        // Sitemap settings
        $sitemap_raw = json_decode( wp_unslash( $_POST['sitemap_settings'] ?? '{}' ), true );
        if ( is_array( $sitemap_raw ) && ! empty( $sitemap_raw ) ) {
            $current_sitemap = get_option( 'hts_sitemap_settings', array() );

            // Post types: sanitize array of strings
            if ( isset( $sitemap_raw['post_types'] ) && is_array( $sitemap_raw['post_types'] ) ) {
                $current_sitemap['post_types'] = array_map( 'sanitize_key', $sitemap_raw['post_types'] );
            }

            // Boolean toggles
            $bool_keys = array( 'image_sitemap', 'cocon_sitemaps', 'ping_google', 'ping_bing', 'include_legacy_tags' );
            foreach ( $bool_keys as $bk ) {
                if ( isset( $sitemap_raw[ $bk ] ) ) {
                    $current_sitemap[ $bk ] = (bool) $sitemap_raw[ $bk ];
                }
            }

            // Max URLs per sitemap
            if ( isset( $sitemap_raw['max_urls_per_sitemap'] ) ) {
                $max = (int) $sitemap_raw['max_urls_per_sitemap'];
                $current_sitemap['max_urls_per_sitemap'] = max( 100, min( 50000, $max ) );
            }

            update_option( 'hts_sitemap_settings', $current_sitemap, false );
            update_option( 'hts_sitemap_flush_needed', true );
        }

        // Notification settings
        $notif_raw = json_decode( wp_unslash( $_POST['notif_settings'] ?? '{}' ), true );
        if ( is_array( $notif_raw ) && ! empty( $notif_raw ) ) {
            $allowed_freq = array( 'weekly', 'biweekly', 'monthly' );
            $freq = in_array( $notif_raw['frequency'] ?? '', $allowed_freq, true ) ? $notif_raw['frequency'] : 'weekly';
            $sections = array();
            foreach ( array( 'wins', 'alerts', 'kpis', 'gsc' ) as $sk ) {
                $sections[ $sk ] = ( $notif_raw['sections'][ $sk ] ?? '1' ) === '1' ? '1' : '0';
            }
            update_option( 'hts_notif_settings', array( 'frequency' => $freq, 'sections' => $sections ), false );
        }
        // Notification email
        $notif_email = isset( $_POST['notif_email'] ) ? sanitize_email( wp_unslash( $_POST['notif_email'] ) ) : '';
        if ( $notif_email ) {
            update_option( 'hts_notif_email', $notif_email, false );
        }

        // Robots global rules
        $robots_raw = json_decode( wp_unslash( $_POST['robots_global'] ?? '{}' ), true );
        if ( is_array( $robots_raw ) ) {
            $robots_clean = array();
            $allowed_types = array( 'category', 'post_tag', 'author', 'date', 'search', 'pagination' );
            $allowed_dirs  = array( 'noindex', 'nofollow' );
            foreach ( $robots_raw as $type => $dirs ) {
                if ( in_array( $type, $allowed_types, true ) && is_array( $dirs ) ) {
                    $robots_clean[ $type ] = array_values( array_intersect( $dirs, $allowed_dirs ) );
                }
            }
            update_option( 'hts_robots_global', $robots_clean, false );
        }

        // Breadcrumbs settings
        $bc_raw = json_decode( wp_unslash( $_POST['breadcrumbs_settings'] ?? '{}' ), true );
        if ( is_array( $bc_raw ) && ! empty( $bc_raw ) ) {
            $bc_clean = array(
                'enabled'         => in_array( $bc_raw['enabled'] ?? '1', array( '0', '1' ), true ) ? $bc_raw['enabled'] : '1',
                'separator'       => sanitize_text_field( $bc_raw['separator'] ?? ' › ' ),
                'home_label'      => sanitize_text_field( $bc_raw['home_label'] ?? 'Accueil' ),
                'show_home'       => '1',
                'max_title_chars' => max( 20, min( 200, (int) ( $bc_raw['max_title_chars'] ?? 60 ) ) ),
            );
            update_option( 'hts_breadcrumbs_settings', $bc_clean, false );
        }

        // llms.txt settings
        $llmstxt_raw = json_decode( wp_unslash( $_POST['llmstxt_settings'] ?? '{}' ), true );
        if ( is_array( $llmstxt_raw ) && ! empty( $llmstxt_raw ) ) {
            $enabled = in_array( $llmstxt_raw['enabled'] ?? '0', array( '0', '1' ), true ) ? $llmstxt_raw['enabled'] : '0';
            $mode    = in_array( $llmstxt_raw['mode'] ?? 'auto', array( 'auto', 'manual' ), true ) ? $llmstxt_raw['mode'] : 'auto';
            update_option( 'hts_llmstxt_enabled', $enabled, false );
            update_option( 'hts_llmstxt_mode', $mode, false );
            // Invalidate cache when settings change
            delete_transient( 'hts_llmstxt_cache' );
        }

        // Schema auto-detected types toggles
        $schema_types_raw = json_decode( wp_unslash( $_POST['schema_auto_types'] ?? '{}' ), true );
        if ( is_array( $schema_types_raw ) && ! empty( $schema_types_raw ) ) {
            $allowed_keys = array( 'faq', 'howto', 'video', 'itemlist', 'speakable' );
            $schema_clean = array();
            foreach ( $allowed_keys as $k ) {
                $schema_clean[ $k ] = in_array( $schema_types_raw[ $k ] ?? '1', array( '0', '1' ), true ) ? $schema_types_raw[ $k ] : '1';
            }
            update_option( 'hts_schema_auto_types', $schema_clean, false );
        }

        // TOC settings
        $toc_raw = json_decode( wp_unslash( $_POST['toc_settings'] ?? '{}' ), true );
        if ( is_array( $toc_raw ) && ! empty( $toc_raw ) ) {
            if ( in_array( $toc_raw['depth'] ?? 'h2h3', array( 'h2', 'h2h3' ), true ) ) {
                update_option( 'hts_toc_depth', $toc_raw['depth'], false );
            }
            update_option( 'hts_toc_min', max( 2, min( 10, (int) ( $toc_raw['min'] ?? 3 ) ) ), false );
            if ( in_array( $toc_raw['style'] ?? 'hts', array( 'hts', 'minimal' ), true ) ) {
                update_option( 'hts_toc_style', $toc_raw['style'], false );
            }
        }

        // Webmaster verification codes
        $wm_raw = json_decode( wp_unslash( $_POST['webmaster_verification'] ?? '{}' ), true );
        if ( is_array( $wm_raw ) ) {
            $wm_clean = array();
            foreach ( array( 'google', 'bing', 'pinterest', 'yandex' ) as $wk ) {
                $wm_clean[ $wk ] = sanitize_text_field( $wm_raw[ $wk ] ?? '' );
            }
            update_option( 'hts_webmaster_verification', $wm_clean, false );
        }

        // OG default image
        if ( isset( $_POST['og_default_image'] ) ) {
            $og_img = esc_url_raw( $_POST['og_default_image'] );
            update_option( 'hts_og_default_image', $og_img, false );
        }

        // Robots.txt custom content
        if ( isset( $_POST['robotstxt_custom'] ) ) {
            $robotstxt_raw = wp_unslash( $_POST['robotstxt_custom'] );
            // Sanitize: allow standard robots.txt directives, comments, and blank lines
            $robotstxt_lines = explode( "\n", $robotstxt_raw );
            $robotstxt_clean = array();
            foreach ( $robotstxt_lines as $line ) {
                // Strip any HTML tags, keep the text
                $line = wp_strip_all_tags( $line );
                // Limit line length to 500 chars to prevent abuse
                $robotstxt_clean[] = mb_substr( $line, 0, 500 );
            }
            $robotstxt = implode( "\n", $robotstxt_clean );
            // Limit total size to 10KB
            $robotstxt = mb_substr( $robotstxt, 0, 10240 );
            update_option( 'hts_robotstxt_custom', $robotstxt, false );

            // Log if dangerous rules detected
            if ( class_exists( 'HTS_Robots' ) ) {
                $warnings = HTS_Robots::validate_robotstxt( $robotstxt );
                foreach ( $warnings as $w ) {
                    if ( $w['type'] === 'danger' ) {
 hts_add_log( ' robots.txt : règle dangereuse détectée — ' . wp_strip_all_tags( $w['message'] ), 'warning', 'robots' );
                    }
                }
            }
        }

        // IndexNow enabled
        if ( isset( $_POST['indexnow_enabled'] ) ) {
            $indexnow_val = in_array( $_POST['indexnow_enabled'], array( '0', '1' ), true ) ? $_POST['indexnow_enabled'] : '0';
            update_option( 'hts_indexnow_enabled', $indexnow_val, false );
            // Auto-generate key on first enable
            if ( $indexnow_val === '1' && class_exists( 'HTS_IndexNow' ) ) {
                HTS_IndexNow::get_api_key();
            }
        }

        // Settings mode (amateur/expert)
        if ( isset( $_POST['settings_mode'] ) ) {
            $mode = in_array( $_POST['settings_mode'], array( 'amateur', 'expert' ), true ) ? $_POST['settings_mode'] : 'amateur';
            update_option( 'hts_settings_mode', $mode, false );
        }

        // Article default status (from SaaS push)
        if ( isset( $_POST['article_default_status'] ) ) {
            $status = in_array( $_POST['article_default_status'], array( 'draft', 'publish', 'pending' ), true )
                ? $_POST['article_default_status'] : 'draft';
            update_option( 'hts_article_default_status', $status, false );
        }

        // Rel prev/next
        if ( isset( $_POST['rel_prev_next'] ) ) {
            update_option( 'hts_rel_prev_next', $_POST['rel_prev_next'] === '1' ? '1' : '0', false );
        }

        // Hreflang
        if ( isset( $_POST['hreflang'] ) ) {
            update_option( 'hts_hreflang', $_POST['hreflang'] === '1' ? '1' : '0', false );
        }

        // Log
 hts_add_log( 'Réglages SEO mis à jour (title sep: ' . $separator . ', social: ' . count( $social ) . ' profils)', 'info', 'settings' );

        wp_send_json_success( array( 'message' => 'Réglages SEO sauvegardés' ) );
    }

    /**
     * AJAX: Save settings mode (amateur/expert) immediately on toggle
     * @since 1.5.0
     */
    public function ajax_save_settings_mode() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission refusée' ) );
        }
        $mode = isset( $_POST['mode'] ) && in_array( $_POST['mode'], array( 'amateur', 'expert' ), true )
            ? $_POST['mode'] : 'amateur';
        update_option( 'hts_settings_mode', $mode, false );
        wp_send_json_success( array( 'mode' => $mode ) );
    }

    /**
     * AJAX: Import competitor SEO settings into HTS options
     */
    public function ajax_seo_import_competitor() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission refusée' ) );
        }

        $competitor = $this->detect_seo_competitor();
        if ( ! $competitor ) {
            wp_send_json_error( array( 'message' => 'Aucun plugin SEO concurrent détecté' ) );
        }

        $imported = $this->read_competitor_seo_settings( $competitor );
        $imported['source'] = ucfirst( $competitor );

        wp_send_json_success( $imported );
    }

    /**
     * Detect which SEO competitor is active
     * @return string|false 'rank_math', 'yoast', 'aioseo', 'seopress' or false
     */
    private function detect_seo_competitor() {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) return 'rank_math';
        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) )       return 'yoast';
        if ( is_plugin_active( 'all-in-one-seo-pack/all_in_one_seo_pack.php' ) ) return 'aioseo';
        if ( is_plugin_active( 'wp-seopress/seopress.php' ) )       return 'seopress';

        return false;
    }

    /**
     * Read competitor SEO settings (home title, desc, social profiles, twitter)
     *
     * @param string|false $competitor
     * @return array
     */
    private function read_competitor_seo_settings( $competitor ) {
        $result = array(
            'home_title'       => '',
            'home_description' => '',
            'title_separator'  => '',
            'twitter_handle'   => '',
            'social_profiles'  => array(),
        );

        if ( ! $competitor ) return $result;

        switch ( $competitor ) {
            case 'rank_math':
                $rm_titles = get_option( 'rank-math-options-titles', array() );
                $rm_general = get_option( 'rank-math-options-general', array() );

                $result['home_title']       = $rm_titles['homepage_title'] ?? '';
                $result['home_description'] = $rm_titles['homepage_description'] ?? '';
                $result['title_separator']  = $rm_titles['title_separator'] ?? '';

                // Social
                $rm_social_urls = array();
                $social_map = array(
                    'facebook'  => 'social_url_facebook',
                    'twitter'   => 'social_url_twitter',
                    'linkedin'  => 'social_url_linkedin',
                    'youtube'   => 'social_url_youtube',
                    'instagram' => 'social_url_instagram',
                    'pinterest' => 'social_url_pinterest',
                );
                foreach ( $social_map as $key => $rm_key ) {
                    $val = $rm_titles[ $rm_key ] ?? '';
                    if ( $val ) $rm_social_urls[ $key ] = $val;
                }
                $result['social_profiles'] = $rm_social_urls;
                $result['twitter_handle'] = $rm_titles['twitter_author_names'] ?? '';
                break;

            case 'yoast':
                $wpseo = get_option( 'wpseo', array() );
                $wpseo_titles = get_option( 'wpseo_titles', array() );
                $wpseo_social = get_option( 'wpseo_social', array() );

                $result['home_title']       = $wpseo_titles['title-home-wpseo'] ?? '';
                $result['home_description'] = $wpseo_titles['metadesc-home-wpseo'] ?? '';
                $result['title_separator']  = $wpseo_titles['separator'] ?? '';

                // Yoast separator codes → characters
                $yoast_seps = array(
                    'sc-dash'   => '—',
                    'sc-ndash'  => '–',
                    'sc-pipe'   => '|',
                    'sc-middot' => '·',
                    'sc-bull'   => '•',
                    'sc-star'   => '*',
                    'sc-gt'     => '>',
                    'sc-lt'     => '<',
                );
                if ( isset( $yoast_seps[ $result['title_separator'] ] ) ) {
                    $result['title_separator'] = $yoast_seps[ $result['title_separator'] ];
                }

                // Social
                $yoast_social = array();
                if ( ! empty( $wpseo_social['facebook_site'] ) )  $yoast_social['facebook']  = $wpseo_social['facebook_site'];
                if ( ! empty( $wpseo_social['twitter_site'] ) )   $yoast_social['twitter']   = 'https://x.com/' . ltrim( $wpseo_social['twitter_site'], '@' );
                if ( ! empty( $wpseo_social['linkedin_url'] ) )   $yoast_social['linkedin']  = $wpseo_social['linkedin_url'];
                if ( ! empty( $wpseo_social['youtube_url'] ) )    $yoast_social['youtube']   = $wpseo_social['youtube_url'];
                if ( ! empty( $wpseo_social['instagram_url'] ) )  $yoast_social['instagram'] = $wpseo_social['instagram_url'];
                if ( ! empty( $wpseo_social['pinterest_url'] ) )  $yoast_social['pinterest'] = $wpseo_social['pinterest_url'];
                $result['social_profiles'] = $yoast_social;
                $result['twitter_handle'] = ! empty( $wpseo_social['twitter_site'] ) ? '@' . ltrim( $wpseo_social['twitter_site'], '@' ) : '';
                break;

            case 'aioseo':
                $aioseo = get_option( 'aioseo_options', '' );
                if ( is_string( $aioseo ) ) {
                    $aioseo = json_decode( $aioseo, true );
                }
                if ( is_array( $aioseo ) ) {
                    $result['home_title']       = $aioseo['searchAppearance']['global']['homepageTitle'] ?? '';
                    $result['home_description'] = $aioseo['searchAppearance']['global']['homepageDescription'] ?? '';
                    $result['title_separator']  = $aioseo['searchAppearance']['global']['separator'] ?? '';

                    $social = $aioseo['social']['profiles'] ?? array();
                    $aio_social = array();
                    if ( ! empty( $social['urls']['facebookPageUrl'] ) )  $aio_social['facebook']  = $social['urls']['facebookPageUrl'];
                    if ( ! empty( $social['urls']['twitterUrl'] ) )       $aio_social['twitter']   = $social['urls']['twitterUrl'];
                    if ( ! empty( $social['urls']['linkedinUrl'] ) )      $aio_social['linkedin']  = $social['urls']['linkedinUrl'];
                    if ( ! empty( $social['urls']['youtubeUrl'] ) )       $aio_social['youtube']   = $social['urls']['youtubeUrl'];
                    if ( ! empty( $social['urls']['instagramUrl'] ) )     $aio_social['instagram'] = $social['urls']['instagramUrl'];
                    if ( ! empty( $social['urls']['pinterestUrl'] ) )     $aio_social['pinterest'] = $social['urls']['pinterestUrl'];
                    if ( ! empty( $social['urls']['tiktokUrl'] ) )        $aio_social['tiktok']    = $social['urls']['tiktokUrl'];
                    $result['social_profiles'] = $aio_social;

                    $result['twitter_handle'] = $aioseo['social']['twitter']['general']['showAuthor'] ?? '';
                }
                break;

            case 'seopress':
                $result['home_title']       = get_option( 'seopress_titles_option' )['seopress_titles_home_site_title'] ?? '';
                $result['home_description'] = get_option( 'seopress_titles_option' )['seopress_titles_home_site_desc'] ?? '';
                $result['title_separator']  = get_option( 'seopress_titles_option' )['seopress_titles_sep'] ?? '';

                $sp_social = get_option( 'seopress_social_option', array() );
                $sp_profiles = array();
                if ( ! empty( $sp_social['seopress_social_accounts_facebook'] ) )  $sp_profiles['facebook']  = $sp_social['seopress_social_accounts_facebook'];
                if ( ! empty( $sp_social['seopress_social_accounts_twitter'] ) )   $sp_profiles['twitter']   = 'https://x.com/' . ltrim( $sp_social['seopress_social_accounts_twitter'], '@' );
                if ( ! empty( $sp_social['seopress_social_accounts_linkedin'] ) )  $sp_profiles['linkedin']  = $sp_social['seopress_social_accounts_linkedin'];
                if ( ! empty( $sp_social['seopress_social_accounts_youtube'] ) )   $sp_profiles['youtube']   = $sp_social['seopress_social_accounts_youtube'];
                if ( ! empty( $sp_social['seopress_social_accounts_instagram'] ) ) $sp_profiles['instagram'] = $sp_social['seopress_social_accounts_instagram'];
                if ( ! empty( $sp_social['seopress_social_accounts_pinterest'] ) ) $sp_profiles['pinterest'] = $sp_social['seopress_social_accounts_pinterest'];
                $result['social_profiles'] = $sp_profiles;
                $result['twitter_handle'] = ! empty( $sp_social['seopress_social_accounts_twitter'] ) ? '@' . ltrim( $sp_social['seopress_social_accounts_twitter'], '@' ) : '';
                break;
        }

        return $result;
    }

    /**
     * Page Outils SEO
     */
    public function render_seo_tools() {
        // Définition des modules
        $modules = array(
 'schema' => array( 'name' => 'Schema Enrichi', 'icon' => 'code-2', 'desc' => 'FAQ, HowTo, Video, ItemList, Speakable — schemas que Yoast ne génère pas' ),
 'toc' => array( 'name' => 'Sommaire auto', 'icon' => 'list-ordered', 'desc' => 'Table des matières cliquable basée sur les H2/H3' ),
 'freshness' => array( 'name' => 'Fraîcheur contenu', 'icon' => 'clock', 'desc' => 'Score de fraîcheur et détection des articles obsolètes' ),
 'citations' => array( 'name' => 'Citation Tracker', 'icon' => 'satellite-dish', 'desc' => 'Track le trafic depuis ChatGPT, Perplexity, Gemini...' ),
 'linking' => array( 'name' => 'Maillage interne', 'icon' => 'link-2', 'desc' => 'Suggestions de liens internes par IA (OpenAI)' ),
 'cocon' => array( 'name' => 'Cocon Sémantique', 'icon' => 'list-tree', 'desc' => 'Visualisation des clusters, orphelins et maillage par cocon' ),
 'gsc' => array( 'name' => 'GSC Connect', 'icon' => 'trending-up', 'desc' => 'Import CSV Google Search Console — positions, clics, CTR' ),
 'engagement' => array( 'name' => 'Engagement Tracker', 'icon' => 'activity', 'desc' => 'Scroll depth + temps actif par page — détecte les pages à risque' ),
 'doctor' => array( 'name' => 'Content Doctor', 'icon' => 'stethoscope', 'desc' => 'GEO Score + diagnostic complet + recommandations par article' ),
        );

        // Freshness stats
        $freshness_stats = array( 'total' => 0, 'fresh' => 0, 'review' => 0, 'stale' => 0, 'avg' => 0, 'oldest' => array() );
        if ( get_option( 'hts_module_freshness', '1' ) === '1' && class_exists( 'HTS_Content_Freshness' ) ) {
            $freshness = new HTS_Content_Freshness();
            $freshness_stats = $freshness->get_freshness_stats();
        }

        // Citation stats
        $citation_stats = array( 'total' => 0, 'sources' => array(), 'top_pages' => array(), 'trend' => 0 );
        if ( get_option( 'hts_module_citations', '1' ) === '1' && class_exists( 'HTS_Citation_Tracker' ) ) {
            $tracker = new HTS_Citation_Tracker();
            $citation_stats = $tracker->get_stats( 30 );
        }

        // AI Monitor stats (Phase 8)
        $ai_monitor_stats = array( 'has_data' => false );
        if ( class_exists( 'HTS_AI_Monitor' ) ) {
            $ai_monitor_stats = HTS_AI_Monitor::get_quick_stats();
        }

        // Pending link suggestions
        $pending_links = array();
        if ( get_option( 'hts_module_linking', '1' ) === '1' && class_exists( 'HTS_Internal_Linking' ) ) {
            $linking = new HTS_Internal_Linking();
            $pending_links = $linking->get_all_pending_suggestions();
        }

        // GSC stats
        $gsc_stats = array( 'total_pages' => 0, 'total_clicks' => 0, 'avg_position' => 0, 'last_import' => null );
        $gsc_declining = array();
        $gsc_opportunities = array();
        if ( get_option( 'hts_module_gsc', '1' ) === '1' && class_exists( 'HTS_GSC_Connect' ) ) {
            $gsc = new HTS_GSC_Connect();
            $gsc_stats = $gsc->get_dashboard_stats();
            $gsc_declining = $gsc->get_declining_pages();
            $gsc_opportunities = $gsc->get_opportunity_pages();
        }

        // Engagement stats
        $engagement_stats = array( 'total_views' => 0, 'avg_time' => 0, 'avg_scroll' => 0 );
        $at_risk_pages = array();
        if ( get_option( 'hts_module_engagement', '1' ) === '1' && class_exists( 'HTS_Engagement_Tracker' ) ) {
            $eng = new HTS_Engagement_Tracker();
            $engagement_stats = $eng->get_dashboard_stats( 30 );
            $at_risk_pages = $eng->get_at_risk_pages();
        }

        // Content Doctor cached results
        $doctor_results = array();
        if ( get_option( 'hts_module_doctor', '1' ) === '1' && class_exists( 'HTS_Content_Doctor' ) ) {
            $doctor = new HTS_Content_Doctor();
            $doctor_results = $doctor->get_cached_results( 20 );
        }

        // Cocon Sémantique
        $cocon_stats = array( 'analyzed' => false );
        if ( get_option( 'hts_module_cocon', '1' ) === '1' && class_exists( 'HTS_Cocon' ) ) {
            $cocon = new HTS_Cocon();
            $cocon_stats = $cocon->get_quick_stats();
        }

        include plugin_dir_path( __FILE__ ) . 'partials/seo-tools.php';
    }

    /* ── BROUILLONS DATA (pour Outils SEO) ── */
    public static function get_drafts_with_priority() {
        $drafts_query = new \WP_Query( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => array( 'draft', 'future' ),
            'posts_per_page' => 100,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );

        $drafts = array();
        foreach ( $drafts_query->posts as $d ) {
            $cl = self::get_draft_checklist( $d->ID );
            $priority = self::get_draft_priority( $d->ID, $cl );

            $keyword = get_post_meta( $d->ID, '_hts_api_keyword', true );
            if ( ! $keyword && defined( 'WPSEO_VERSION' ) ) {
                $keyword = get_post_meta( $d->ID, '_yoast_wpseo_focuskw', true );
            }
            if ( ! $keyword && class_exists( 'RankMath' ) ) {
                $keyword = get_post_meta( $d->ID, 'rank_math_focus_keyword', true );
            }

            $drafts[] = array(
                'post'      => $d,
                'checklist' => $cl,
                'priority'  => $priority,
                'is_api'    => (bool) get_post_meta( $d->ID, '_hts_api_generated', true ),
                'keyword'   => $keyword ?: '',
            );
        }

        // Sort by priority score DESC
        usort( $drafts, function( $a, $b ) {
            return $b['priority']['score'] - $a['priority']['score'];
        } );

        return $drafts;
    }

    /* ── TEST API COCON — À commenter après les tests ── */
    public function render_api_test() {
        include plugin_dir_path( __FILE__ ) . 'partials/api-test.php';
    }

    /* ── BROUILLONS ── */
    public function render_drafts() {
        include plugin_dir_path( __FILE__ ) . 'partials/drafts.php';
    }

    /**
     * AJAX : Sauvegarde des modules ON/OFF + clé OpenAI
     */
    public function ajax_save_modules() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ), 403 );
        }

        $module_keys = array( 'schema', 'toc', 'freshness', 'citations', 'linking', 'cocon', 'gsc', 'engagement', 'doctor' );

        foreach ( $module_keys as $key ) {
            $value = isset( $_POST[ 'mod_' . $key ] ) ? sanitize_text_field( $_POST[ 'mod_' . $key ] ) : '0';
            update_option( 'hts_module_' . $key, $value );
        }

        // Clé OpenAI
        if ( isset( $_POST['openai_key'] ) ) {
            $openai_key = sanitize_text_field( $_POST['openai_key'] );
            update_option( 'hts_openai_api_key', $openai_key );
        }
        // Limite mensuelle OpenAI
        if ( isset( $_POST['openai_limit'] ) ) {
            $limit = max( 0, absint( $_POST['openai_limit'] ) );
            update_option( 'hts_openai_monthly_limit', $limit );
        }

        // Options TOC
        if ( isset( $_POST['toc_depth'] ) ) {
            $depth = in_array( $_POST['toc_depth'], array( 'h2', 'h2h3' ), true ) ? $_POST['toc_depth'] : 'h2h3';
            update_option( 'hts_toc_depth', $depth );
        }
        if ( isset( $_POST['toc_style'] ) ) {
            $style = in_array( $_POST['toc_style'], array( 'hts', 'minimal' ), true ) ? $_POST['toc_style'] : 'hts';
            update_option( 'hts_toc_style', $style );
        }
        if ( isset( $_POST['toc_min'] ) ) {
            $min = max( 2, min( 10, absint( $_POST['toc_min'] ) ) );
            update_option( 'hts_toc_min', $min );
        }

        wp_send_json_success( array( 'message' => 'Modules mis à jour. Rechargez la page pour voir les changements.' ) );
    }

    /**
     * AJAX : Sauvegarde ET validation de la clé API
     * Appelle l'API réelle pour vérifier que la clé est valide
     */
    public function ajax_save_and_validate_api_key() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Permissions insuffisantes.' ], 403 );
        }

        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';

        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'message' => 'La clé API ne peut pas être vide.' ] );
        }

        // Valider la clé en appelant l'API HackTheSEO (utilise l'env actif)
        $base_url = self::get_api_base_url();
        $api_url  = $base_url . '/api/articles';

        $response = wp_remote_get( $api_url . '?page=1', [
            'headers' => [
                'x-api-key'    => $api_key,
                'Content-Type' => 'application/json',
            ],
            'timeout' => 15,
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [
                'message' => 'Impossible de contacter l\'API : ' . $response->get_error_message(),
            ] );
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $status_code === 401 || $status_code === 403 || ( isset( $body['error'] ) && $body['error'] ) ) {
            hts_add_log( 'Clé API invalide (code ' . $status_code . ')', 'error', 'api' );
            wp_send_json_error( [
                'message' => 'Clé API invalide. Vérifiez votre clé sur ' . str_replace( 'https://', '', $base_url ) . '.',
            ] );
        }

        if ( $status_code >= 500 ) {
            wp_send_json_error( [
                'message' => 'L\'API HackTheSEO est temporairement indisponible (erreur ' . $status_code . ').',
            ] );
        }

        // La clé est valide → sauvegarder
        update_option( 'hts_api_key', $api_key );

        // Fetch enriched plan data (tier, features, quotas) from validate-key
        $vk_response = wp_remote_get( $base_url . '/api/validate-key', array(
            'headers' => array( 'x-api-key' => $api_key, 'Accept' => 'application/json' ),
            'timeout' => 10,
        ) );
        if ( ! is_wp_error( $vk_response ) && wp_remote_retrieve_response_code( $vk_response ) === 200 ) {
            $vk_body = json_decode( wp_remote_retrieve_body( $vk_response ), true );
            if ( is_array( $vk_body ) && class_exists( 'HTS_Subscription' ) ) {
                HTS_Subscription::store_plan_data( $vk_body );
                if ( ! empty( $vk_body['active'] ) ) {
                    update_option( 'hts_subscription_status', 'active', false );
                }
                update_option( 'hts_subscription_data', $vk_body, false );
                update_option( 'hts_subscription_checked_at', time(), false );
                hts_add_log( sprintf( 'Plan détecté: %s (tier %d)', $vk_body['plan'] ?? 'free', $vk_body['tier'] ?? 0 ), 'info', 'api' );
            }
        }

        hts_add_log( 'Clé API enregistrée et validée', 'success', 'api' );

        wp_send_json_success( [
            'message' => 'Clé API valide et enregistrée avec succès !',
        ] );
    }

    /**
     * AJAX : Diagnostic complet — teste logs, API, config
     */
    public function ajax_diagnostic() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Permissions insuffisantes.' ], 403 );
        }

        $checks = array();

        // 1. Test écriture logs
        $log_fn_exists = function_exists( 'hts_add_log' );
        $checks[] = array(
            'label'  => 'Fonction hts_add_log()',
            'ok'     => $log_fn_exists,
            'detail' => $log_fn_exists ? 'Disponible' : 'MANQUANTE — hack-the-seo.php pas à jour',
        );

        if ( $log_fn_exists ) {
            hts_add_log( 'Diagnostic exécuté', 'info', 'system' );
            $logs = get_option( 'hts_activity_logs' );
            $log_saved = ( is_array( $logs ) && count( $logs ) > 0 );
            $checks[] = array(
                'label'  => 'Écriture logs en base',
                'ok'     => $log_saved,
                'detail' => $log_saved ? count( $logs ) . ' log(s) en base' : 'ÉCHEC écriture option',
            );
        }

        // 2. Test clé API
        $api_key = hts_get_api_key();
        $checks[] = array(
            'label'  => 'Clé API (wp_options)',
            'ok'     => ! empty( $api_key ),
            'detail' => ! empty( $api_key ) ? substr( $api_key, 0, 8 ) . '...' : 'VIDE — allez dans Réglages API',
        );

        // 3. Test config
        $config_ok = defined( 'HTS_CONFIG' ) && is_array( HTS_CONFIG );
        $checks[] = array(
            'label'  => 'HTS_CONFIG',
            'ok'     => $config_ok,
            'detail' => $config_ok ? 'api_url = ' . ( HTS_CONFIG['api_url'] ?? 'NON DÉFINI' ) : 'MANQUANTE',
        );

        // 4. Test appel API articles
        if ( ! empty( $api_key ) && $config_ok ) {
            $api_url  = HTS_CONFIG['api_url'] ?? '';
            $response = wp_remote_get( $api_url . '?page=1', array(
                'headers' => array(
                    'x-api-key'    => $api_key,
                    'Content-Type' => 'application/json',
                ),
                'timeout' => 15,
            ) );

            if ( is_wp_error( $response ) ) {
                $checks[] = array(
                    'label'  => 'API Articles (' . $api_url . ')',
                    'ok'     => false,
                    'detail' => 'ERREUR : ' . $response->get_error_message(),
                );
            } else {
                $http_code = wp_remote_retrieve_response_code( $response );
                $body      = wp_remote_retrieve_body( $response );
                $json      = json_decode( $body, true );
                $has_data  = ( $http_code === 200 && isset( $json['data'] ) );
                $checks[] = array(
                    'label'  => 'API Articles',
                    'ok'     => $has_data,
                    'detail' => 'HTTP ' . $http_code . ' — ' . ( $has_data ? 'OK' : substr( $body, 0, 150 ) ),
                );
            }
        }

        // 5. Test appel API corrections
        if ( ! empty( $api_key ) && $config_ok && isset( HTS_CONFIG['api_url_correction'] ) ) {
            $api_url  = HTS_CONFIG['api_url_correction'];
            $response = wp_remote_get( $api_url, array(
                'headers' => array(
                    'x-api-key'    => $api_key,
                    'Content-Type' => 'application/json',
                ),
                'timeout' => 15,
            ) );

            if ( is_wp_error( $response ) ) {
                $checks[] = array(
                    'label'  => 'API Corrections (' . $api_url . ')',
                    'ok'     => false,
                    'detail' => 'ERREUR : ' . $response->get_error_message(),
                );
            } else {
                $http_code = wp_remote_retrieve_response_code( $response );
                $body      = wp_remote_retrieve_body( $response );
                $checks[] = array(
                    'label'  => 'API Corrections',
                    'ok'     => ( $http_code === 200 ),
                    'detail' => 'HTTP ' . $http_code . ' — ' . substr( $body, 0, 150 ),
                );
            }
        }

        // 6. Version plugin
        $checks[] = array(
            'label'  => 'Version plugin',
            'ok'     => true,
            'detail' => defined( 'HTS_SYNCHRONISE_ARTICLES_VERSION' ) ? HTS_SYNCHRONISE_ARTICLES_VERSION : 'INCONNUE',
        );

        // 7. PHP version
        $checks[] = array(
            'label'  => 'PHP',
            'ok'     => true,
            'detail' => phpversion(),
        );

        wp_send_json_success( array( 'checks' => $checks ) );
    }

    /**
     * AJAX : Télécharger les logs en fichier texte
     */
    public function ajax_download_logs() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ), 403 );
        }

        $logs = get_option( 'hts_activity_logs' );
        if ( ! is_array( $logs ) || empty( $logs ) ) {
            wp_send_json_error( array( 'message' => 'Aucun log disponible.' ) );
        }

        // Infos système
        $lines = array();
        $lines[] = '=== HACK THE SEO — RAPPORT DE LOGS ===';
        $lines[] = 'Date export : ' . current_time( 'Y-m-d H:i:s' );
        $lines[] = 'Site : ' . get_site_url();
        $lines[] = 'WordPress : ' . get_bloginfo( 'version' );
        $lines[] = 'PHP : ' . phpversion();
        $lines[] = 'Plugin : ' . ( defined( 'HTS_SYNCHRONISE_ARTICLES_VERSION' ) ? HTS_SYNCHRONISE_ARTICLES_VERSION : 'inconnu' );
        $lines[] = 'Clé API : ' . ( hts_get_api_key() ? substr( hts_get_api_key(), 0, 8 ) . '...' : 'NON CONFIGURÉE' );
        $lines[] = '';
        $lines[] = '=== LOGS (' . count( $logs ) . ' entrées) ===';
        $lines[] = '';

        foreach ( $logs as $log ) {
            $time    = isset( $log['time'] ) ? $log['time'] : '—';
            $type    = isset( $log['type'] ) ? strtoupper( $log['type'] ) : 'INFO';
            $source  = isset( $log['source'] ) ? $log['source'] : '—';
            $message = isset( $log['message'] ) ? $log['message'] : ( is_string( $log ) ? $log : '' );
            $lines[] = '[' . $time . '] [' . $type . '] [' . $source . '] ' . $message;
        }

        $lines[] = '';
        $lines[] = '=== FIN DU RAPPORT ===';

        wp_send_json_success( array( 'content' => implode( "\n", $lines ) ) );
    }

    /* ═══════════════════════════════════════════════════════════
     *  API TEST HANDLERS — À commenter après les tests
     * ═══════════════════════════════════════════════════════════ */

    private function api_test_call( $method, $endpoint, $body = array() ) {
        $api_key = hts_get_api_key();
        $base    = self::get_api_base_url() . '/api/v1/cocon';
        $url     = $base . '/' . ltrim( $endpoint, '/' );
        $start   = microtime( true );

        $args = array(
            'timeout' => 120,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ),
        );

        if ( $method === 'POST' ) {
            $args['method'] = 'POST';
            $args['body']   = wp_json_encode( $body );
            $response = wp_remote_post( $url, $args );
        } else {
            $response = wp_remote_get( $url, $args );
        }

        $elapsed = round( ( microtime( true ) - $start ) * 1000 );

        if ( is_wp_error( $response ) ) {
            return array(
                'success'  => false,
                'error'    => $response->get_error_message(),
                'url'      => $url,
                'elapsed'  => $elapsed,
                'status'   => 0,
                'raw_body' => '',
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        return array(
            'success'  => $code >= 200 && $code < 300,
            'status'   => $code,
            'data'     => $data,
            'url'      => $url,
            'elapsed'  => $elapsed,
            'raw_body' => $raw,
        );
    }

    /** Test: generate-plan */
    public function ajax_api_test_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $body = array(
            'site_url'     => sanitize_url( $_POST['site_url'] ?? site_url() ),
            'pillar_url'   => sanitize_url( $_POST['pillar_url'] ?? '' ),
            'main_keyword' => sanitize_text_field( $_POST['main_keyword'] ?? '' ),
            'language'     => sanitize_text_field( $_POST['language'] ?? 'fr' ),
            'max_articles' => (int) ( $_POST['max_articles'] ?? 15 ),
        );

        $result = $this->api_test_call( 'POST', 'generate-plan', $body );

        // Store plan in wp_options for later use
        if ( $result['success'] && ! empty( $result['data']['plan'] ) ) {
            $stored = get_option( 'hts_api_test_plans', array() );
            $stored[] = array(
                'date'      => current_time( 'mysql' ),
                'cocon_id'  => $result['data']['cocon_id'] ?? '',
                'keyword'   => $body['main_keyword'],
                'pillar'    => $body['pillar_url'],
                'plan'      => $result['data']['plan'],
            );
            // Keep last 10
            $stored = array_slice( $stored, -10 );
            update_option( 'hts_api_test_plans', $stored, false );
        }

        // Log
        $this->api_test_log( 'generate-plan', $body, $result );

        wp_send_json_success( $result );
    }

    /** Test: generate-article */
    public function ajax_api_test_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $siblings_raw = $_POST['siblings'] ?? '[]';
        $siblings = json_decode( stripslashes( $siblings_raw ), true );
        if ( ! is_array( $siblings ) ) $siblings = array();

        $body = array(
            'site_url'      => sanitize_url( $_POST['site_url'] ?? site_url() ),
            'article'       => array(
                'keyword' => sanitize_text_field( $_POST['article_keyword'] ?? '' ),
                'title'   => sanitize_text_field( $_POST['article_title'] ?? '' ),
            ),
            'language'      => sanitize_text_field( $_POST['language'] ?? 'fr' ),
            'auto_validate' => true,
        );

        // Optional fields — only include if provided
        $cocon_id = sanitize_text_field( $_POST['cocon_id'] ?? '' );
        if ( $cocon_id ) $body['cocon_id'] = $cocon_id;

        $pillar_url = sanitize_url( $_POST['pillar_url'] ?? '' );
        if ( $pillar_url ) {
            $body['pillar_url']   = $pillar_url;
            $body['pillar_title'] = sanitize_text_field( $_POST['pillar_title'] ?? '' );
        }

        if ( ! empty( $siblings ) ) $body['siblings'] = $siblings;

        $result = $this->api_test_call( 'POST', 'generate-article', $body );

        // If queued, store job for polling
        if ( $result['success'] && ! empty( $result['data']['job_id'] ) ) {
            $jobs = get_option( 'hts_api_test_jobs', array() );
            $jobs[ $result['data']['job_id'] ] = array(
                'date'     => current_time( 'mysql' ),
                'keyword'  => $body['article']['keyword'],
                'title'    => $body['article']['title'],
                'status'   => $result['data']['status'] ?? 'queued',
                'cocon_id' => $cocon_id,
            );
            update_option( 'hts_api_test_jobs', $jobs, false );
        }

        // If already completed (synchronous), store article
        if ( $result['success'] && ( $result['data']['status'] ?? '' ) === 'completed' && ! empty( $result['data']['article'] ) ) {
            $this->api_test_store_article( $result['data'] );
        }

        $this->api_test_log( 'generate-article', $body, $result );
        wp_send_json_success( $result );
    }

    /** Test: status polling */
    public function ajax_api_test_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        if ( ! $job_id ) wp_send_json_error( array( 'message' => 'job_id requis' ) );

        $result = $this->api_test_call( 'GET', 'status/' . $job_id );

        // If completed, store article
        if ( $result['success'] && ( $result['data']['status'] ?? '' ) === 'completed' ) {
            $this->api_test_store_article( $result['data'] );
            // Update job status
            $jobs = get_option( 'hts_api_test_jobs', array() );
            if ( isset( $jobs[ $job_id ] ) ) {
                $jobs[ $job_id ]['status'] = 'completed';
                update_option( 'hts_api_test_jobs', $jobs, false );
            }
        }

        wp_send_json_success( $result );
    }

    /** Test: create WordPress draft from received article */
    public function ajax_api_test_create_draft() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $idx = (int) ( $_POST['article_index'] ?? -1 );
        $articles = get_option( 'hts_api_test_articles', array() );
        if ( ! isset( $articles[ $idx ] ) ) wp_send_json_error( array( 'message' => 'Article introuvable' ) );

        $art = $articles[ $idx ];
        $post_id = wp_insert_post( array(
            'post_title'   => $art['title'] ?? 'Article sans titre',
            'post_content' => $art['content_html'] ?? '',
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'meta_input'   => array(
                '_hts_api_generated' => 1,
                '_hts_api_keyword'   => $art['keyword'] ?? '',
                '_hts_api_cocon_id'  => $art['cocon_id'] ?? '',
                '_yoast_wpseo_metadesc' => $art['meta_description'] ?? '',
            ),
        ) );

        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
        }

        // Mark as drafted
        $articles[ $idx ]['draft_id'] = $post_id;
        $articles[ $idx ]['draft_date'] = current_time( 'mysql' );
        update_option( 'hts_api_test_articles', $articles, false );

        // Set slug if provided
        if ( ! empty( $art['slug'] ) ) {
            wp_update_post( array( 'ID' => $post_id, 'post_name' => sanitize_title( $art['slug'] ) ) );
        }

        wp_send_json_success( array(
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link( $post_id, 'raw' ),
            'message'  => 'Brouillon créé : #' . $post_id,
        ) );
    }

    /** Helper: store a completed article */
    private function api_test_store_article( $data ) {
        $articles = get_option( 'hts_api_test_articles', array() );
        $art = $data['article'] ?? $data;
        $art['received_at'] = current_time( 'mysql' );
        $art['job_id'] = $data['job_id'] ?? '';
        $articles[] = $art;
        update_option( 'hts_api_test_articles', $articles, false );
    }

    /** Helper: log API call */
    private function api_test_log( $endpoint, $request, $result ) {
        $logs = get_option( 'hts_api_test_logs', array() );
        $logs[] = array(
            'time'     => current_time( 'mysql' ),
            'endpoint' => $endpoint,
            'request'  => $request,
            'status'   => $result['status'] ?? 0,
            'success'  => $result['success'],
            'elapsed'  => $result['elapsed'] ?? 0,
            'url'      => $result['url'] ?? '',
            'error'    => $result['error'] ?? null,
            'response' => $result['data'] ?? ( $result['raw_body'] ?? '' ),
        );
        // Keep last 50
        $logs = array_slice( $logs, -50 );
        update_option( 'hts_api_test_logs', $logs, false );
    }

    /** Clear all test data */
    public function ajax_api_test_clear() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        delete_option( 'hts_api_test_plans' );
        delete_option( 'hts_api_test_articles' );
        delete_option( 'hts_api_test_jobs' );
        delete_option( 'hts_api_test_logs' );
        wp_send_json_success();
    }

    /** Save API environment (preprod/prod) */
    public function ajax_save_env() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $url = sanitize_url( $_POST['env_url'] ?? 'https://app.hacktheseo.com' );
        // Only allow known URLs
        $allowed = array( 'https://prep.hacktheseo.com', 'https://app.hacktheseo.com' );
        if ( ! in_array( $url, $allowed, true ) ) {
            wp_send_json_error( array( 'message' => 'URL non autorisée' ) );
        }
        update_option( 'hts_api_base_url', $url );

        // Force re-validate the API key against the new env
        // This updates hts_api_tier from the SaaS subscription
        delete_transient( 'hts_subscription_cache' );
        wp_cache_delete( 'hts_api_tier', 'options' );
        wp_cache_delete( 'hts_api_plan', 'options' );
        wp_cache_delete( 'hts_subscription_status', 'options' );

        wp_send_json_success( array( 'url' => $url ) );
    }

    /**
     * Dev only: set tier manually for testing gating.
     * Only works on prep/local environments.
     */
    public function ajax_dev_set_tier() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        // Only allow on dev/prep environments
        $base = get_option( 'hts_api_base_url', '' );
        $home = home_url();
        $is_dev = strpos( $home, '.test' ) !== false;
        if ( ! $is_dev ) wp_send_json_error( array( 'message' => 'Dev only' ) );

        $tier = max( 0, min( 2, (int) ( $_POST['tier'] ?? 0 ) ) );
        $slug = sanitize_key( $_POST['slug'] ?? 'free' );

        update_option( 'hts_api_tier', $tier, false );
        update_option( 'hts_api_plan', $slug, false );
        update_option( 'hts_subscription_status', 'active', false );

        wp_send_json_success( array( 'tier' => $tier, 'slug' => $slug ) );
    }

    /* ═══════════════════════════════════════════════════════════
     *  COCON API — PRODUCTION (v2.6.0)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Proper API call using X-API-KEY header (matches API documentation)
     */
    private function cocon_api_call( $method, $endpoint, $body = array() ) {
        $api_key = hts_get_api_key();
        $base    = self::get_api_base_url() . '/api/v1/cocon';
        $url     = $base . '/' . ltrim( $endpoint, '/' );

        $args = array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'X-API-KEY'    => $api_key,
            ),
        );

        if ( $method === 'POST' ) {
            $args['method'] = 'POST';
            $args['body']   = wp_json_encode( $body );
            $response = wp_remote_post( $url, $args );
        } else {
            $response = wp_remote_get( $url, $args );
        }

        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'error'   => $response->get_error_message(),
                'status'  => 0,
                'data'    => null,
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        return array(
            'success' => $code >= 200 && $code < 300,
            'status'  => $code,
            'data'    => $data,
            'error'   => $code >= 400 ? ( $data['message'] ?? $data['error'] ?? 'HTTP ' . $code ) : null,
        );
    }

    /**
     * Get stored cocon plans from wp_options
     */
    public static function get_cocon_plans() {
        return get_option( 'hts_cocon_plans', array() );
    }

    /**
     * Save a cocon plan to wp_options
     */
    private static function save_cocon_plan( $plan ) {
        $plans = self::get_cocon_plans();
        // Update existing or append
        $found = false;
        foreach ( $plans as $i => $p ) {
            if ( (int) $p['cocon_id'] === (int) $plan['cocon_id'] ) {
                $plans[ $i ] = $plan;
                $found = true;
                break;
            }
        }
        if ( ! $found ) $plans[] = $plan;
        // Keep last 20
        $plans = array_slice( $plans, -20 );
        update_option( 'hts_cocon_plans', $plans, false );
    }

    /**
     * Get siblings for a cocon (published articles from same cocon)
     */
    private static function get_cocon_siblings( $cocon_id ) {
        $siblings = array();
        $posts = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'meta_query'     => array(
                array( 'key' => '_hts_cocon_id', 'value' => $cocon_id ),
            ),
        ) );
        foreach ( $posts as $p ) {
            $siblings[] = array(
                'url'   => get_permalink( $p->ID ),
                'title' => $p->post_title,
            );
        }
        return $siblings;
    }

    /** AJAX: POST /generate-plan */
    public function ajax_cocon_generate_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $pillar_url   = sanitize_url( $_POST['pillar_url'] ?? '' );
        $main_keyword = sanitize_text_field( $_POST['main_keyword'] ?? '' );
        $language     = sanitize_text_field( $_POST['language'] ?? 'fr-FR' );
        $max_articles = max( 1, min( 50, (int) ( $_POST['max_articles'] ?? 15 ) ) );

        if ( ! $pillar_url || ! $main_keyword ) {
            wp_send_json_error( array( 'message' => 'URL pilier et mot-clé requis' ) );
        }

        $result = $this->cocon_api_call( 'POST', 'generate-plan', array(
            'site_url'     => site_url(),
            'pillar_url'   => $pillar_url,
            'main_keyword' => $main_keyword,
            'language'     => $language,
            'max_articles' => $max_articles,
        ) );

        if ( ! $result['success'] ) {
            $msg = $result['data']['message'] ?? $result['error'] ?? 'Erreur API';
            wp_send_json_error( array( 'message' => $msg, 'http' => $result['status'] ?? 0 ) );
        }

        $cocon_id = $result['data']['cocon_id'] ?? 0;

 self::cocon_log( 'plan_queued', 'Plan lancé', array(
            'cocon_id' => $cocon_id,
            'keyword'  => $main_keyword,
            'pillar'   => $pillar_url,
            'language' => $language,
        ) );

        // Store plan stub
        self::save_cocon_plan( array(
            'cocon_id'     => $cocon_id,
            'keyword'      => $main_keyword,
            'pillar_url'   => $pillar_url,
            'language'     => $language,
            'status'       => 'queued',
            'plan'         => array(),
            'created_at'   => current_time( 'mysql' ),
            'articles_gen' => array(), // track generated article topic_ids
        ) );

        wp_send_json_success( array(
            'cocon_id' => $cocon_id,
            'message'  => $result['data']['message'] ?? 'Plan en cours de génération',
        ) );
    }

    /** AJAX: GET /plan-status/{cocon_id} */
    public function ajax_cocon_poll_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $cocon_id = (int) ( $_POST['cocon_id'] ?? 0 );
        if ( ! $cocon_id ) wp_send_json_error( array( 'message' => 'cocon_id requis' ) );

        $result = $this->cocon_api_call( 'GET', 'plan-status/' . $cocon_id );

        if ( ! $result['success'] ) {
            wp_send_json_error( array( 'message' => $result['data']['message'] ?? 'Erreur polling' ) );
        }

        $status = $result['data']['status'] ?? 'unknown';

        // If plan is ready, save it locally
        if ( $status === 'success' && ! empty( $result['data']['plan'] ) ) {
            $total = 0;
            foreach ( $result['data']['plan'] as $cat ) { $total += count( $cat['articles'] ?? array() ); }
 self::cocon_log( 'plan_ready', 'Plan prêt', array(
                'cocon_id'   => $cocon_id,
                'categories' => count( $result['data']['plan'] ),
                'articles'   => $total,
            ) );
            $plans = self::get_cocon_plans();
            foreach ( $plans as $i => $p ) {
                if ( (int) $p['cocon_id'] === $cocon_id ) {
                    $plans[ $i ]['status'] = 'success';
                    $plans[ $i ]['plan']   = $result['data']['plan'];
                    break;
                }
            }
            update_option( 'hts_cocon_plans', $plans, false );
        }

        wp_send_json_success( array(
            'status'   => $status,
            'cocon_id' => $cocon_id,
            'plan'     => $result['data']['plan'] ?? array(),
        ) );
    }

    /** AJAX: POST /generate-article */
    public function ajax_cocon_generate_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        // Note: article generation is SaaS-side (no local batch needed).
        // Timeout is handled by the Remote Client circuit breaker.
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time < 120 ) {
            @set_time_limit( 120 );
        }

        $cocon_id = (int) ( $_POST['cocon_id'] ?? 0 );
        $topic_id = (int) ( $_POST['topic_id'] ?? 0 );
        if ( ! $cocon_id || ! $topic_id ) {
            wp_send_json_error( array( 'message' => 'cocon_id et topic_id requis' ) );
        }

        // Get plan info for pillar_url and language
        $plans = self::get_cocon_plans();
        $plan_info = null;
        foreach ( $plans as $p ) {
            if ( (int) $p['cocon_id'] === $cocon_id ) { $plan_info = $p; break; }
        }
        if ( ! $plan_info ) {
            wp_send_json_error( array( 'message' => 'Plan local introuvable' ) );
        }

        // Sprint Robustesse: set lock AFTER validation — atomic counter
        self::acquire_generation_lock();

        // Get siblings (already published articles in this cocon)
        $siblings = self::get_cocon_siblings( $cocon_id );

        // Get pillar title from the pillar URL
        $pillar_post_id = hts_url_to_postid( $plan_info['pillar_url'] );
        $pillar_title = $pillar_post_id ? get_the_title( $pillar_post_id ) : '';

        $result = $this->cocon_api_call( 'POST', 'generate-article', array(
            'cocon_id'      => $cocon_id,
            'topic_id'      => $topic_id,
            'site_url'      => site_url(),
            'pillar_url'    => $plan_info['pillar_url'],
            'pillar_title'  => $pillar_title,
            'siblings'      => $siblings,
            'language'      => $plan_info['language'],
            'auto_validate' => true,
        ) );

        if ( ! $result['success'] ) {
            // Release lock on API failure
            self::release_generation_lock();
            $msg = $result['data']['message'] ?? $result['error'] ?? 'Erreur API';
 self::cocon_log( 'article_error', ' ' . $msg, array( 'cocon_id' => $cocon_id, 'topic_id' => $topic_id ) );
            wp_send_json_error( array( 'message' => $msg, 'http' => $result['status'] ?? 0 ) );
        }

 self::cocon_log( 'article_queued', 'Article lancé', array(
            'cocon_id' => $cocon_id,
            'topic_id' => $topic_id,
            'job_id'   => $result['data']['job_id'] ?? '',
        ) );

        wp_send_json_success( array(
            'job_id'   => $result['data']['job_id'] ?? '',
            'status'   => $result['data']['status'] ?? 'queued',
            'message'  => $result['data']['message'] ?? 'Génération en cours',
            'topic_id' => $topic_id,
        ) );
    }

    /** AJAX: GET /article-status/{job_id} */
    public function ajax_cocon_poll_article() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_id   = sanitize_text_field( $_POST['job_id'] ?? '' );
        $topic_id = (int) ( $_POST['topic_id'] ?? 0 );
        $cocon_id = (int) ( $_POST['cocon_id'] ?? 0 );
        if ( ! $job_id ) wp_send_json_error( array( 'message' => 'job_id requis' ) );

        $result = $this->cocon_api_call( 'GET', 'article-status/' . $job_id );

        if ( ! $result['success'] ) {
 self::cocon_log( 'poll_article', 'Erreur HTTP', array( 'job_id' => $job_id ) );
            wp_send_json_error( array( 'message' => $result['data']['message'] ?? 'Erreur polling' ) );
        }

        $status = $result['data']['status'] ?? 'unknown';

        // Log phase changes
        self::cocon_log( 'poll_article', $status, array(
            'job_id'  => $job_id,
            'phase'   => $result['data']['phase'] ?? '',
        ) );

        // If completed, store article server-side in a transient (avoid JS→PHP encoding issues)
        if ( $status === 'completed' && ! empty( $result['data']['article'] ) ) {
            $transient_key = 'hts_article_' . $job_id;
            set_transient( $transient_key, $result['data']['article'], 3600 ); // 1h expiry
 self::cocon_log( 'article_ready', 'Article prêt', array(
                'job_id'   => $job_id,
                'topic_id' => $topic_id,
                'title'    => $result['data']['article']['title'] ?? '',
                'words'    => $result['data']['article']['word_count'] ?? 0,
            ) );
        }

        wp_send_json_success( array(
            'status'  => $status,
            'phase'   => $result['data']['phase'] ?? '',
            'job_id'  => $job_id,
            // Don't send full article to JS — it's stored server-side
            'article_ready' => ( $status === 'completed' ),
            'article_title' => ( $status === 'completed' && ! empty( $result['data']['article'] ) )
                ? ( $result['data']['article']['title'] ?? '' ) : '',
            'article_words' => ( $status === 'completed' && ! empty( $result['data']['article'] ) )
                ? ( $result['data']['article']['word_count'] ?? 0 ) : 0,
        ) );
    }

    /** AJAX: Create WordPress draft from server-stored article (v2.7.0 — enhanced metas + multi-plugin SEO) */
    /**
     * @deprecated 2.5.0 — Replaced by HTS_Cocon_Commander::create_draft_from_article() + HTS_Article_Pipeline::enrich_draft().
     * This method is NOT registered as an AJAX handler. Kept for reference only.
     */
    public function ajax_cocon_create_draft() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $cocon_id = (int) ( $_POST['cocon_id'] ?? 0 );
        $topic_id = (int) ( $_POST['topic_id'] ?? 0 );
        $job_id   = sanitize_text_field( $_POST['job_id'] ?? '' );

        // Retrieve article from transient (stored server-side during polling)
        $transient_key = 'hts_article_' . $job_id;
        $article = get_transient( $transient_key );

        if ( ! $article || empty( $article['content_html'] ) ) {
 self::cocon_log( 'create_draft', 'Article introuvable dans transient', array( 'job_id' => $job_id ) );
            self::release_generation_lock();
            wp_send_json_error( array( 'message' => 'Article introuvable — le transient a expiré ou le polling a échoué.' ) );
        }

        $content_html = $article['content_html'];
        $keyword      = $article['keyword'] ?? '';

        // ── 1. Extract raw metas from HTML (material for AI optimization) ──
        $extracted = self::cocon_extract_metas_from_html( $content_html );

        // ── 2. Strip <html>, <head>, <body> wrappers ──
        if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $content_html, $body_match ) ) {
            $content_html = $body_match[1];
        }

        // ── 3. Extract H1 for title (clean, no tags) ──
        $wp_title = '';
        if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/si', $content_html, $h1m ) ) {
            $wp_title = wp_strip_all_tags( $h1m[1] );
        }
        if ( empty( $wp_title ) ) {
            $wp_title = wp_strip_all_tags( $article['title'] ?? 'Article sans titre' );
        }

        // ── 4. Collect raw metas (API or HTML extraction — to be optimized by AI) ──
        $raw_meta_title = $article['meta_title'] ?? '';
        if ( empty( $raw_meta_title ) ) $raw_meta_title = $extracted['meta_title'];

        $raw_meta_desc = $article['meta_description'] ?? '';
        if ( empty( $raw_meta_desc ) ) $raw_meta_desc = $extracted['meta_description'];

        // ── 5. ALWAYS optimize via OpenAI (strict lengths + smart slug) ──
        $ai_metas = self::cocon_generate_seo_metas( $wp_title, $keyword, $content_html, $raw_meta_title, $raw_meta_desc );

        $meta_title = ! empty( $ai_metas['meta_title'] )       ? $ai_metas['meta_title']       : $raw_meta_title;
        $meta_desc  = ! empty( $ai_metas['meta_description'] ) ? $ai_metas['meta_description'] : $raw_meta_desc;
        $wp_slug    = ! empty( $ai_metas['slug'] )             ? $ai_metas['slug']             : self::cocon_generate_short_slug( $keyword, $article['slug'] ?? '' );

        // ── 6. Hard safety net: truncate if still over limits ──
        $meta_title = self::cocon_truncate_meta( $meta_title, 60 );
        $meta_desc  = self::cocon_truncate_meta( $meta_desc, 155 );

        // ── 7. Clean HTML: remove <meta>, <h1>, <title>, STOP marker, comments ──
        // Each preg_replace is null-safe: if PCRE fails, keep previous value
        $wp_content = $content_html;
        $wp_content = preg_replace( '/<meta[^>]*>/i', '', $wp_content )           ?? $wp_content;
        $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content )   ?? $wp_content;
        $wp_content = preg_replace( '/<title>.*?<\/title>/si', '', $wp_content )   ?? $wp_content;
        $wp_content = preg_replace( '/\nSTOP\n.*$/s', '', $wp_content )            ?? $wp_content;
        $wp_content = preg_replace( '/<!--.*?-->/s', '', $wp_content )             ?? $wp_content;

        // ── 7b. Fix markdown-style citation links from AI → proper HTML <a> ──
        $links_result = self::cocon_fix_markdown_links( $wp_content );
        $wp_content   = ( $links_result !== null && $links_result !== '' ) ? $links_result : $wp_content;

        // ── 7c. Remove AI-generated spam blocks (keyword stuffing, semantic notes) ──
        // Pattern: "Note sémantique", random foreign-language keyword dumps, etc.
        $wp_content = preg_replace(
            '/\s*(?:<p>)?\s*(?:Note\s+s[ée]mantique|S[ée]mantique\s*[:\(]|Keywords?\s*[:\(])[^<]*(?:downloads|cookies|technologien|lunacourses|gutscheine|personalisierte|anleitung|hinzuf[üu]gen|kollektion|werbung)[^<]*(?:<\/p>)?\s*/si',
            '',
            $wp_content
        ) ?? $wp_content;
        // Broader catch: paragraphs with 10+ comma-separated single words (keyword lists)
        $wp_content = preg_replace(
            '/<p>[^<]{20,}(?:(?:,\s*\w+){10,})[^<]*<\/p>/si',
            '',
            $wp_content
        ) ?? $wp_content;

        $wp_content = trim( $wp_content );

        // ── 7c. Safety net: if content is empty after cleaning, log + use raw fallback ──
        if ( empty( $wp_content ) ) {
 self::cocon_log( 'create_draft', 'Contenu vide après nettoyage — fallback sur content_html brut', array(
                'job_id'       => $job_id,
                'raw_len'      => mb_strlen( $content_html ),
                'preg_error'   => preg_last_error(),
            ) );
            // Fallback: use content_html with minimal cleaning (just strip body/h1)
            $wp_content = $content_html;
            if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $wp_content, $fb ) ) {
                $wp_content = $fb[1];
            }
            $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content ) ?? $wp_content;
            $wp_content = trim( $wp_content );
        }

        // ── 8. Create draft post (with duplicate guard on cocon_id + topic_id) ──
        // Sprint Robustesse: atomic lock to prevent double-click / parallel AJAX creating 2 drafts
        $draft_lock_key = 'hts_creating_draft_' . $cocon_id . '_' . $topic_id;
        if ( get_transient( $draft_lock_key ) ) {
            // Another request is already creating this draft — return the existing post
            $existing = get_posts( array(
                'post_type'   => 'post',
                'post_status' => array( 'draft', 'pending' ),
                'numberposts' => 1,
                'fields'      => 'ids',
                'meta_query'  => array(
                    'relation' => 'AND',
                    array( 'key' => '_hts_cocon_id',       'value' => $cocon_id ),
                    array( 'key' => '_hts_cocon_topic_id', 'value' => $topic_id ),
                ),
            ) );
            if ( ! empty( $existing ) ) {
                self::release_generation_lock();
                wp_send_json_success( array(
                    'post_id'  => (int) $existing[0],
                    'edit_url' => get_edit_post_link( $existing[0], 'raw' ),
                    'title'    => get_the_title( $existing[0] ),
                    'message'  => 'Brouillon déjà créé : #' . $existing[0],
                    'duplicate_prevented' => true,
                ) );
            }
            // Lock exists but no post yet — wait briefly then check again
            usleep( 500000 ); // 500ms
            $existing2 = get_posts( array(
                'post_type' => 'post', 'post_status' => array( 'draft', 'pending' ),
                'numberposts' => 1, 'fields' => 'ids',
                'meta_query' => array( 'relation' => 'AND',
                    array( 'key' => '_hts_cocon_id', 'value' => $cocon_id ),
                    array( 'key' => '_hts_cocon_topic_id', 'value' => $topic_id ),
                ),
            ) );
            if ( ! empty( $existing2 ) ) {
                self::release_generation_lock();
                wp_send_json_success( array(
                    'post_id' => (int) $existing2[0], 'edit_url' => get_edit_post_link( $existing2[0], 'raw' ),
                    'title' => get_the_title( $existing2[0] ), 'message' => 'Brouillon déjà créé : #' . $existing2[0],
                    'duplicate_prevented' => true,
                ) );
            }
        }
        set_transient( $draft_lock_key, time(), 120 ); // 2 min TTL

        // If a previous draft exists for this exact topic, trash it first to free the slug.
        if ( $cocon_id > 0 && $topic_id > 0 ) {
            $old_drafts = get_posts( array(
                'post_type'   => 'post',
                'post_status' => array( 'draft', 'pending' ),
                'numberposts' => 5,
                'fields'      => 'ids',
                'meta_query'  => array(
                    'relation' => 'AND',
                    array( 'key' => '_hts_cocon_id',       'value' => $cocon_id ),
                    array( 'key' => '_hts_cocon_topic_id', 'value' => $topic_id ),
                ),
            ) );
            foreach ( $old_drafts as $old_id ) {
                wp_trash_post( $old_id );
                self::cocon_log( 'duplicate_trashed', 'Ancien brouillon #' . $old_id . ' mis en corbeille (même topic)', array(
                    'cocon_id' => $cocon_id, 'topic_id' => $topic_id,
                ) );
            }
        }

        // Also check if slug already taken (by a published/future post) and make unique
        $desired_slug = sanitize_title( $wp_slug );
        $slug_check = get_posts( array(
            'post_type'   => 'post',
            'post_status' => array( 'publish', 'future', 'private' ),
            'name'        => $desired_slug,
            'numberposts' => 1,
            'fields'      => 'ids',
        ) );
        if ( ! empty( $slug_check ) ) {
            // Append keyword hash to make unique without ugly -2
            $desired_slug .= '-' . substr( md5( $keyword . $cocon_id ), 0, 4 );
        }

        // Sprint 6.2c: Final UTM cleanup — catch any remaining ?utm_source=openai in href attributes
        $wp_content = preg_replace_callback(
            '/<a\s([^>]*href=["\'])(https?:\/\/[^"\']+)(["\'][^>]*)>/i',
            function( $m ) {
                $url = preg_replace( '/[?&]utm_source=(openai|perplexity|chatgpt|anthropic|claude)/', '', $m[2] );
                $url = rtrim( $url, '?&' );
                $url = str_replace( '?&', '?', $url );
                return '<a ' . $m[1] . esc_url( $url ) . $m[3] . '>';
            },
            $wp_content
        ) ?? $wp_content;

        $default_author = (int) get_option( 'hts_default_author', 0 );
        $post_args = array(
            'post_title'   => $wp_title,
            'post_name'    => $desired_slug,
            'post_content' => $wp_content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'meta_input'   => array(
                '_hts_api_generated'        => 1,
                '_hts_api_keyword'          => $keyword,
                '_hts_cocon_id'             => $cocon_id,
                '_hts_cocon_topic_id'       => $topic_id,
                '_hts_cocon_job_id'         => $job_id,
            ),
        );
        if ( $default_author > 0 ) {
            $post_args['post_author'] = $default_author;
        }
        $post_id = wp_insert_post( $post_args );

        if ( is_wp_error( $post_id ) ) {
            self::release_generation_lock();
            delete_transient( 'hts_creating_draft_' . $cocon_id . '_' . $topic_id );
            wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
        }
        $plan_info = null;
        foreach ( self::get_cocon_plans() as $p ) {
            if ( (int) ( $p['cocon_id'] ?? 0 ) === $cocon_id ) { $plan_info = $p; break; }
        }
        if ( $plan_info && ! empty( $plan_info['plan'] ) ) {
            // Sprint Robustesse: category strategy — same as cocon-commander
            // Priority 1: inherit pillar's category
            // Priority 2: fuzzy match plan group name against existing WP categories
            // Priority 3: create ONE category per cocon keyword (not per group)
            $cat_id = 0;

            // Priority 1: pillar's category
            $pillar_post_id_cat = hts_url_to_postid( $plan_info['pillar_url'] ?? '' );
            if ( $pillar_post_id_cat ) {
                $pillar_cats = wp_get_post_categories( $pillar_post_id_cat );
                $pillar_cats = array_filter( $pillar_cats, function( $c ) { return (int) $c !== 1; } );
                if ( ! empty( $pillar_cats ) ) {
                    $cat_id = (int) array_values( $pillar_cats )[0];
                }
            }

            // Priority 2: fuzzy match plan group name
            if ( ! $cat_id ) {
                $topic_cat = '';
                foreach ( $plan_info['plan'] as $cat_group ) {
                    foreach ( $cat_group['articles'] ?? array() as $art ) {
                        if ( (int) ( $art['topic_id'] ?? 0 ) === $topic_id ) {
                            $topic_cat = $cat_group['category'] ?? $art['category'] ?? '';
                            break 2;
                        }
                    }
                }
                if ( ! empty( $topic_cat ) ) {
                    $cat_id = self::cocon_ensure_category( $topic_cat );
                }
            }

            // Priority 3: create ONE category per cocon keyword
            if ( ! $cat_id ) {
                $cocon_kw = $plan_info['keyword'] ?? '';
                if ( $cocon_kw ) {
                    $cat_id = get_cat_ID( $cocon_kw );
                    if ( ! $cat_id ) {
                        $slug_term = get_term_by( 'slug', sanitize_title( $cocon_kw ), 'category' );
                        if ( $slug_term ) $cat_id = (int) $slug_term->term_id;
                    }
                    if ( ! $cat_id ) {
                        $parent = 0;
                        if ( $pillar_post_id_cat ) {
                            $pc = wp_get_post_categories( $pillar_post_id_cat );
                            if ( ! empty( $pc ) && (int) $pc[0] !== 1 ) $parent = (int) $pc[0];
                        }
                        $cat_id = wp_create_category( $cocon_kw, $parent );
                    }
                }
            }

            if ( $cat_id > 0 && ! is_wp_error( $cat_id ) ) {
                wp_set_post_categories( $post_id, array( (int) $cat_id ) );
                self::cocon_log( 'category_matched', '📂 Catégorie assignée : « ' . ( get_cat_name( $cat_id ) ?: $cat_id ) . ' »', array( 'post_id' => $post_id, 'cat_id' => $cat_id ) );
            }
        }

        // ── 9. Apply SEO metas to all detected SEO plugins ──
        self::cocon_apply_seo_metas( $post_id, array(
            'metatitle'       => $meta_title,
            'metadescription' => $meta_desc,
            'keyword'         => $keyword,
        ) );

        // ── 9b. Keyword stuffing detection (log only, no rewrite) ──
        $stuffing = self::cocon_check_keyword_stuffing( $wp_content, $keyword, $post_id );
        if ( $stuffing['flagged'] ) {
            update_post_meta( $post_id, '_hts_keyword_stuffing', $stuffing );
        }

        // ── 10. Schedule image + cross-linking in background (prevents AJAX timeout) ──
        // Images take 30-90s — running them synchronously causes timeouts and double-submissions.
        // Cross-linking ALWAYS runs; image generation only if agent is enabled.
        $image_agent_on = ! class_exists( 'HTS_Workflow_Engine' ) || HTS_Workflow_Engine::is_agent_enabled( 'image' );
        update_post_meta( $post_id, '_hts_images_pending', 1 );
        update_post_meta( $post_id, '_hts_images_pending_since', time() );
        if ( ! $image_agent_on ) {
            update_post_meta( $post_id, '_hts_skip_image_gen', 1 );
        }
        wp_schedule_single_event( time() + 10, 'hts_deferred_images', array( $post_id, $wp_title, $keyword ) );
        $images_result = array( 'count' => 0, 'images' => array(), 'content' => $wp_content );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                $image_agent_on
                    ? 'Images IA + maillage : programmés en arrière-plan (brouillon #' . $post_id . ')'
                    : 'Maillage seul : programmé en arrière-plan (images désactivées, brouillon #' . $post_id . ')',
                'info', 'cocon'
            );
        }

        // ── 11. Schemas: handled automatically by the plugin's frontend module ──
        // Do NOT inject JSON-LD into post_content — it causes raw JSON visible in the article.
        $schemas_detected = array();

        // ── 13. Cross-cocon interlinking → déféré en arrière-plan (avec images) ──
        // Le cross-linking appelle Anthropic par cible (~10s chacun) — trop lent en AJAX synchrone.
        // Il est déjà inclus dans handle_deferred_images() qui tourne en cron.
        $cross_links = array( 'outbound' => 0, 'inbound' => 0 );

 self::cocon_log( 'ai_metas', 'Metas + slug optimisés par IA', array(
            'meta_title'   => $meta_title,
            'meta_desc'    => mb_substr( $meta_desc, 0, 60 ) . '...',
            'slug'         => $wp_slug,
            'images'       => $images_result['count'] ?? 0,
            'schemas'      => implode( ', ', $schemas_detected ),
            'cross_links'  => ( $cross_links['outbound'] + $cross_links['inbound'] ),
        ) );

        // Mark topic as generated in local plan
        $plans = self::get_cocon_plans();
        foreach ( $plans as $i => $p ) {
            if ( (int) $p['cocon_id'] === $cocon_id ) {
                if ( ! isset( $plans[ $i ]['articles_gen'] ) ) $plans[ $i ]['articles_gen'] = array();
                $plans[ $i ]['articles_gen'][ $topic_id ] = array(
                    'post_id'  => $post_id,
                    'title'    => $wp_title,
                    'date'     => current_time( 'mysql' ),
                );
                break;
            }
        }
        update_option( 'hts_cocon_plans', $plans, false );

        // Clean transient
        delete_transient( $transient_key );

 self::cocon_log( 'draft_created', 'Brouillon #' . $post_id, array(
            'job_id'     => $job_id,
            'topic_id'   => $topic_id,
            'cocon_id'   => $cocon_id,
            'title'      => $wp_title,
            'slug'       => $wp_slug,
            'words'      => $article['word_count'] ?? 0,
            'has_metas'  => ( ! empty( $meta_title ) && ! empty( $meta_desc ) ) ? 'yes' : 'partial',
            'images'     => $images_result['count'] ?? 0,
            'schemas'    => implode( ', ', $schemas_detected ),
        ) );

        // Sprint Robustesse: release heavy job lock + draft lock BEFORE wp_send_json_success
        self::release_generation_lock();
        delete_transient( 'hts_creating_draft_' . $cocon_id . '_' . $topic_id );

        wp_send_json_success( array(
            'post_id'     => $post_id,
            'edit_url'    => get_edit_post_link( $post_id, 'raw' ),
            'title'       => $wp_title,
            'cross_links' => ( $cross_links['outbound'] + $cross_links['inbound'] ),
 'message' => 'Brouillon créé : #' . $post_id . ( $image_agent_on ? ' · 🎨 images en arrière-plan' : '' ) . ( ( $cross_links['outbound'] + $cross_links['inbound'] ) > 0 ? ' + ' . ( $cross_links['outbound'] + $cross_links['inbound'] ) . ' cross-link(s)' : '' ),
        ) );
    }

    /* ─── COCON HELPERS — Meta Extraction, AI Generation, SEO Multi-Plugin (v2.7.0) ─── */

    /**
     * Extract meta_title and meta_description from full HTML (including <head>)
     * Fallback 1: regex from <title> and <meta name="description">
     */
    public static function cocon_extract_metas_from_html( $html ) {
        $meta_title = '';
        $meta_desc  = '';

        // Extract <title>
        if ( preg_match( '/<title>(.*?)<\/title>/si', $html, $tm ) ) {
            $meta_title = trim( wp_strip_all_tags( $tm[1] ) );
        }

        // Extract <meta name="description" content="...">
        if ( preg_match( '/<meta\s+name=["\']description["\']\s+content=["\'](.*?)["\']/si', $html, $dm ) ) {
            $meta_desc = trim( $dm[1] );
        }

        return array(
            'meta_title'       => $meta_title,
            'meta_description' => $meta_desc,
        );
    }

    /**
     * Generate short SEO-friendly slug from keyword
     * Priority: keyword-based slug (short) > API slug (often too long)
     */
    /**
     * Match a category name to an existing WordPress category.
     * Does NOT create new categories — returns 0 if no match found.
     *
     * @param string $cat_name Category name from the cocon plan
     * @return int WordPress category ID, or 0 if no match
     */
    public static function cocon_ensure_category( $cat_name ) {
        if ( empty( $cat_name ) ) return 0;

        $cat_name = trim( $cat_name );

        // 1. Exact match (case-insensitive)
        $term = get_term_by( 'name', $cat_name, 'category' );
        if ( $term ) return (int) $term->term_id;

        // 2. Slug match (handles accents: "Référencement" → "referencement")
        $slug = sanitize_title( $cat_name );
        $term = get_term_by( 'slug', $slug, 'category' );
        if ( $term ) return (int) $term->term_id;

        // 3. Fuzzy match against all existing categories
        $all_cats = get_categories( array( 'hide_empty' => false ) );
        $best_id    = 0;
        $best_score = 0;
        $cat_lower  = mb_strtolower( $cat_name );

        foreach ( $all_cats as $cat ) {
            // Skip "Uncategorized" / "Non classé"
            if ( (int) $cat->term_id === 1 ) continue;

            $name_lower = mb_strtolower( $cat->name );

            // Contains match (either direction)
            if ( mb_strpos( $name_lower, $cat_lower ) !== false || mb_strpos( $cat_lower, $name_lower ) !== false ) {
                return (int) $cat->term_id;
            }

            // Similarity score
            similar_text( $cat_lower, $name_lower, $pct );
            if ( $pct > $best_score ) {
                $best_score = $pct;
                $best_id    = (int) $cat->term_id;
            }
        }

        // Accept fuzzy match only if > 75% similar
        if ( $best_score >= 75 ) {
            return $best_id;
        }

        return 0; // No match → leave uncategorized
    }

    /**
     * Sprint Robustesse: release the article generation lock.
     * Decrements the counter; clears the heavy_job lock when all articles are done.
     */
    private static function release_generation_lock() {
        global $wpdb;
        // Atomic decrement using SQL UPDATE (not get+set which has race conditions)
        $wpdb->query(
            "UPDATE {$wpdb->options} SET option_value = GREATEST(0, CAST(option_value AS SIGNED) - 1) WHERE option_name = '_transient_hts_articles_generating'"
        );
        $remaining = (int) get_transient( 'hts_articles_generating' );
        if ( $remaining <= 0 ) {
            delete_transient( 'hts_articles_generating' );
            delete_transient( 'hts_heavy_job_running' );
        }
    }

    /**
     * Sprint Robustesse: atomically increment the article generation counter.
     * Uses SQL for atomicity to prevent race conditions with parallel AJAX calls.
     */
    private static function acquire_generation_lock() {
        global $wpdb;
        $key = '_transient_hts_articles_generating';
        // Try atomic increment
        $updated = $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->options} SET option_value = CAST(option_value AS SIGNED) + 1 WHERE option_name = %s",
            $key
        ) );
        if ( ! $updated ) {
            // Transient doesn't exist yet — create it
            set_transient( 'hts_articles_generating', 1, 600 );
        }
        // Always set the heavy job flag
        set_transient( 'hts_heavy_job_running', 'article_generation', 600 );
        // Refresh TTL
        $count = (int) get_transient( 'hts_articles_generating' );
        if ( $count > 0 ) {
            set_transient( 'hts_articles_generating', $count, 600 );
        }
    }

    private static function cocon_generate_short_slug( $keyword, $api_slug = '' ) {
        if ( ! empty( $keyword ) ) {
            $slug = sanitize_title( $keyword );
            // If keyword slug is reasonable (< 60 chars), use it
            if ( strlen( $slug ) <= 60 ) {
                return $slug;
            }
        }

        // Fallback to API slug, but truncate if too long
        if ( ! empty( $api_slug ) ) {
            $slug = sanitize_title( $api_slug );
            // Truncate at last full word before 60 chars
            if ( strlen( $slug ) > 60 ) {
                $slug = substr( $slug, 0, 60 );
                $slug = preg_replace( '/-[^-]*$/', '', $slug );
            }
            return $slug;
        }

        return sanitize_title( $keyword ?: 'article' );
    }

    /**
     * Generate SEO metas via OpenAI (Fallback 2 — when API + HTML extraction both fail)
     * Uses SEO 2026 optimized prompt for maximum CTR + GEO readability
     *
     * @param string $title   Article H1 title
     * @param string $keyword Target keyword
     * @param string $content Article HTML content
     * @return array { meta_title, meta_description, slug }
     */
    /**
     * Generate SEO metas via OpenAI — ALWAYS called to optimize (v2.7.1)
     * Takes raw metas as input, outputs strictly sized optimized versions
     *
     * @param string $title          Article H1 title
     * @param string $keyword        Target keyword
     * @param string $content        Article HTML content
     * @param string $raw_meta_title Existing meta title (from HTML or API) — may be too long
     * @param string $raw_meta_desc  Existing meta desc (from HTML or API) — may be too long
     * @return array { meta_title, meta_description, slug }
     */
    public static function cocon_generate_seo_metas( $title, $keyword, $content, $raw_meta_title = '', $raw_meta_desc = '' ) {
        $openai_key = hts_get_openai_key();
        if ( empty( $openai_key ) ) {
            return array( 'meta_title' => '', 'meta_description' => '', 'slug' => '' );
        }

        // Extract first 200 words for context
        $text = wp_strip_all_tags( $content );
        $words = explode( ' ', $text );
        $excerpt = implode( ' ', array_slice( $words, 0, 200 ) );

        // Extract H2 headings
        preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $content, $h2_matches );
        $h2_list = ! empty( $h2_matches[1] ) ? implode( ' | ', array_map( 'wp_strip_all_tags', array_slice( $h2_matches[1], 0, 5 ) ) ) : '';

        // Build context about existing metas
        $existing_context = '';
        if ( ! empty( $raw_meta_title ) ) {
            $existing_context .= "\n- Meta title existante (à optimiser, trop longue ou pas assez CTR) : {$raw_meta_title}";
        }
        if ( ! empty( $raw_meta_desc ) ) {
            $existing_context .= "\n- Meta description existante (à raccourcir et optimiser) : {$raw_meta_desc}";
        }

        $prompt = <<<PROMPT
Expert SEO. Optimise les métadonnées pour Google SERP 2026 + visibilité dans les réponses IA (GEO).

ARTICLE :
- H1 : {$title}
- Keyword : {$keyword}
- H2 : {$h2_list}
- Extrait : {$excerpt}{$existing_context}

CONTRAINTES STRICTES — respecte les compteurs de caractères à la lettre :

meta_title : MAXIMUM 58 caractères (espaces compris). Compte avant de répondre.
- Keyword dans les 3-4 premiers mots
- Séparateur : ou | ou —
- Un power word ou chiffre si la place le permet
- Pas de date/année, pas de marque sauf si pertinent

meta_description : ENTRE 140 et 155 caractères (espaces compris). Compte avant de répondre.
- Phrase 1 = réponse directe à l'intention (les LLMs extraient ça)
- Keyword dans les 12 premiers mots
- Finir par une valeur ajoutée concrète
- INTERDIT : "Découvrez", "Dans cet article", "Apprenez", "Vous cherchez"

slug : ENTRE 15 et 40 caractères (tirets compris), kebab-case
- Basé sur le keyword + un mot de contexte du titre si ça aide
- Pas de stop words (le, la, les, de, du, en, pour, et, un, une, des, comment, pourquoi)
- Pas de "guide-complet", pas de date

VÉRIFIE que meta_title ≤ 58 chars et meta_description ≤ 155 chars AVANT de répondre.

JSON strict uniquement :
{"meta_title":"...","meta_description":"...","slug":"..."}
PROMPT;

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 25,
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $openai_key,
            ),
            'body' => wp_json_encode( array(
                'model'       => 'gpt-4o-mini',
                'messages'    => array(
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'temperature' => 0.3,
                'max_tokens'  => 250,
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
 self::cocon_log( 'ai_metas_error', 'OpenAI error: ' . $response->get_error_message() );
            return array( 'meta_title' => '', 'meta_description' => '', 'slug' => '' );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $text = $body['choices'][0]['message']['content'] ?? '';

        // Strip markdown fences
        $text = preg_replace( '/```json\s*|```\s*/', '', $text );
        $text = trim( $text );

        $parsed = json_decode( $text, true );
        if ( ! is_array( $parsed ) ) {
 self::cocon_log( 'ai_metas_error', 'JSON parse failed', array( 'raw' => mb_substr( $text, 0, 200 ) ) );
            return array( 'meta_title' => '', 'meta_description' => '', 'slug' => '' );
        }

        return array(
            'meta_title'       => sanitize_text_field( $parsed['meta_title'] ?? '' ),
            'meta_description' => sanitize_textarea_field( $parsed['meta_description'] ?? '' ),
            'slug'             => sanitize_title( $parsed['slug'] ?? '' ),
        );
    }

    /**
     * Hard truncation safety net — cuts at last full word before limit
     */
    private static function cocon_truncate_meta( $text, $max_chars = 155 ) {
        $text = trim( $text );
        if ( mb_strlen( $text ) <= $max_chars ) return $text;

        $truncated = mb_substr( $text, 0, $max_chars );
        // Cut at last space to avoid mid-word cut
        $last_space = mb_strrpos( $truncated, ' ' );
        if ( $last_space > ( $max_chars * 0.7 ) ) {
            $truncated = mb_substr( $truncated, 0, $last_space );
        }
        // Remove trailing punctuation then add period if needed
        $truncated = rtrim( $truncated, ' ,;:-–—' );
        if ( ! preg_match( '/[.!?]$/', $truncated ) ) {
            // Only add period if we have room
            if ( mb_strlen( $truncated ) < $max_chars ) {
                $truncated .= '.';
            }
        }
        return $truncated;
    }

    /* ═══════════════════════════════════════════════════════════
     *  KEYWORD STUFFING DETECTION (v2.7.5)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Analyze keyword density in article content.
     * Returns density info + logs a warning if above threshold.
     * Does NOT modify the content — detection only.
     *
     * @param string $content  HTML content
     * @param string $keyword  Target keyword (can be multi-word)
     * @param int    $post_id  For logging context
     * @return array { density, count, total_words, flagged, details[] }
     */
    public static function cocon_check_keyword_stuffing( $content, $keyword, $post_id = 0 ) {
        $text        = mb_strtolower( wp_strip_all_tags( $content ) );
        $keyword_low = mb_strtolower( trim( $keyword ) );
        $total_words = hts_word_count( $text );

        if ( $total_words < 50 || empty( $keyword_low ) ) {
            return array( 'density' => 0, 'count' => 0, 'total_words' => $total_words, 'flagged' => false, 'details' => array() );
        }

        // ── 1. Exact match count ──
        $kw_words      = hts_word_count( $keyword_low );
        $exact_count   = mb_substr_count( $text, $keyword_low );
        $exact_density = ( $exact_count * $kw_words ) / $total_words * 100;

        // ── 2. Check individual words of multi-word keywords (partial stuffing) ──
        $kw_parts       = preg_split( '/\s+/', $keyword_low );
        $partial_details = array();
        if ( count( $kw_parts ) > 1 ) {
            foreach ( $kw_parts as $part ) {
                if ( mb_strlen( $part ) < 3 ) continue; // skip "de", "le", etc.
                $part_count   = mb_substr_count( $text, $part );
                $part_density = $part_count / $total_words * 100;
                if ( $part_density > 3.0 ) {
                    $partial_details[] = $part . ': ' . round( $part_density, 1 ) . '% (' . $part_count . 'x)';
                }
            }
        }

        // ── 3. Check H1/H2/H3 concentration ──
        preg_match_all( '/<h[1-3][^>]*>(.*?)<\/h[1-3]>/si', $content, $headings );
        $heading_stuffed = 0;
        $total_headings  = count( $headings[1] ?? array() );
        foreach ( ( $headings[1] ?? array() ) as $h ) {
            if ( mb_stripos( wp_strip_all_tags( $h ), $keyword_low ) !== false ) {
                $heading_stuffed++;
            }
        }
        $heading_ratio = $total_headings > 0 ? round( $heading_stuffed / $total_headings * 100 ) : 0;

        // ── 4. Threshold decision ──
        // - Exact density > 2.5% → warning
        // - Keyword in > 70% of headings → warning
        // - Any partial word > 3% → warning
        $flagged  = false;
        $warnings = array();

        if ( $exact_density > 2.5 ) {
            $flagged    = true;
            $warnings[] = 'Densité exacte: ' . round( $exact_density, 1 ) . '% (' . $exact_count . 'x "' . $keyword_low . '" / ' . $total_words . ' mots)';
        }
        if ( $heading_ratio > 70 && $total_headings > 3 ) {
            $flagged    = true;
            $warnings[] = 'Keyword dans ' . $heading_stuffed . '/' . $total_headings . ' titres (' . $heading_ratio . '%)';
        }
        if ( ! empty( $partial_details ) ) {
            $flagged    = true;
            $warnings[] = 'Sur-représentation partielle: ' . implode( ', ', $partial_details );
        }

        // ── 5. Log if flagged ──
        if ( $flagged ) {
 self::cocon_log( 'keyword_stuffing', 'Keyword stuffing détecté', array(
                'post_id'  => $post_id,
                'keyword'  => $keyword,
                'density'  => round( $exact_density, 1 ) . '%',
                'warnings' => $warnings,
            ) );
        }

        return array(
            'density'     => round( $exact_density, 2 ),
            'count'       => $exact_count,
            'total_words' => $total_words,
            'flagged'     => $flagged,
            'details'     => $warnings,
            'heading_ratio' => $heading_ratio,
        );
    }

    /* ═══════════════════════════════════════════════════════════
     *  GLOBAL INTERLINKING (v2.8.0)
     *
     *  After a new article is created, find semantically relevant
     *  articles across the ENTIRE site and:
     *  1. Insert 1-3 outbound links into the new article
     *     → towards other cocons, historical content, pages
     *  2. Insert 1-2 inbound links from existing articles to this one
     *     → any published article on the site can link back
     *
     *  Scope: ALL site content (not just HTS cocons)
     *   - Same cocon siblings (already partially handled by API,
     *     but we add missing contextual links)
     *   - Other cocon articles
     *   - Historical / manually written articles & pages
     *
     *  Tracks everything with post_meta + UI badges.
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Main entry point: apply global interlinking on a newly created post.
     *
     * @param int    $post_id  WordPress post ID (draft or published)
     * @param bool   $is_cron  Whether called from cron (for log routing)
     * @return array { outbound: int, inbound: int }
     */
    public static function cocon_cross_interlink( $post_id, $is_cron = false ) {
        // ── Guard: feature toggle ──
        $toggle = get_option( 'hts_cross_interlink_enabled', '1' );
        if ( $toggle !== '1' ) {
            self::cocon_log( 'interlink_skip', '⏭️ Maillage désactivé (toggle=' . $toggle . ')', array( 'post_id' => $post_id ) );
            return array( 'outbound' => 0, 'inbound' => 0 );
        }

        $openai_key = hts_get_openai_key();
        if ( empty( $openai_key ) ) {
            self::cocon_log( 'interlink_skip', '⏭️ Maillage impossible — clé OpenAI absente', array(
                'post_id'    => $post_id,
                'has_option' => get_option( 'hts_openai_api_key' ) ? 'yes' : 'no',
                'has_const'  => defined( 'HTS_OPENAI_API_KEY' ) ? 'yes' : 'no',
            ) );
            return array( 'outbound' => 0, 'inbound' => 0 );
        }

        $post = get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) {
            self::cocon_log( 'interlink_skip', '⏭️ Maillage impossible — post vide ou introuvable', array( 'post_id' => $post_id ) );
            return array( 'outbound' => 0, 'inbound' => 0 );
        }

        $my_cocon_id = get_post_meta( $post_id, '_hts_cocon_id', true );
        $my_keyword  = get_post_meta( $post_id, '_hts_api_keyword', true );

        // ── Load per-cocon linking config ──
        $link_config = HTS_Cocon_Commander::get_linking_config( $my_cocon_id );

        // ── Collect ALL candidates across the site ──
        $candidates = self::global_interlink_get_candidates( $post_id );
        if ( empty( $candidates ) ) {
            self::cocon_log( 'interlink_skip', '⏭️ Aucun candidat trouvé pour le maillage', array(
                'post_id' => $post_id,
                'cocon_id' => $my_cocon_id,
            ) );
            return array( 'outbound' => 0, 'inbound' => 0 );
        }

        // ── Filter candidates by depth setting ──
        // depth 1 = same cocon only (strict), depth 2 = all site (default, TF-IDF + OpenAI handle relevance), depth 3 = whole site (legacy alias)
        $depth = (int) ( $link_config['depth'] ?? 2 );
        if ( $depth === 1 && $my_cocon_id ) {
            // Strict mode: only articles from the exact same cocon
            $candidates = array_filter( $candidates, function( $c ) use ( $my_cocon_id ) {
                return $c['cocon_id'] === $my_cocon_id;
            } );
            $candidates = array_values( $candidates );
        }
        // depth 2 & 3: keep ALL candidates — TF-IDF pre-filter + OpenAI will select the best ones

        // ── Debug: log candidate count and breakdown ──
        $same_cocon = 0;
        $other_cocon = 0;
        $no_cocon = 0;
        foreach ( $candidates as $c ) {
            if ( $c['cocon_id'] && $c['cocon_id'] === $my_cocon_id ) $same_cocon++;
            elseif ( $c['cocon_id'] ) $other_cocon++;
            else $no_cocon++;
        }
        self::cocon_log( 'interlink_candidates', '🔍 Candidats maillage trouvés', array(
            'post_id'    => $post_id,
            'total'      => count( $candidates ),
            'same_cocon' => $same_cocon,
            'other_cocon' => $other_cocon,
            'historique' => $no_cocon,
            'my_cocon'   => $my_cocon_id ?: '(aucun)',
            'keyword'    => $my_keyword ?: '(aucun)',
            'openai_key' => mb_substr( $openai_key, 0, 8 ) . '...',
        ) );

        // ── Pre-filter by TF-IDF keyword overlap (top 25) ──
        $my_content_text = mb_strtolower( wp_strip_all_tags( $post->post_content ) );
        $my_keywords = self::cross_interlink_extract_keywords( $my_content_text );
        $candidates = self::cross_interlink_rank_candidates( $candidates, $my_keywords );
        $candidates = array_slice( $candidates, 0, 25 );

        // ── Inject recommended links from Cocon analysis as priority candidates ──
        // These are pending/lost link suggestions already validated by the V3 pipeline.
        // They go BEFORE TF-IDF candidates so OpenAI sees them first.
        if ( $my_cocon_id && class_exists( 'HTS_Cocon_Commander' ) ) {
            $commander_inst = new \HTS_Cocon_Commander();
            $recommended = $commander_inst->get_recommended_links( $my_cocon_id );
            if ( ! empty( $recommended ) ) {
                $existing_ids = array_column( $candidates, 'id' );
                $injected = 0;
                foreach ( $recommended as $rec ) {
                    $rec_pid = hts_url_to_postid( $rec['url'] ?? '' );
                    if ( ! $rec_pid || $rec_pid === $post_id ) continue;
                    if ( in_array( $rec_pid, $existing_ids, true ) ) continue;

                    // Insert at the beginning as priority candidate
                    array_unshift( $candidates, array(
                        'id'              => $rec_pid,
                        'title'           => $rec['title'] ?? get_the_title( $rec_pid ),
                        'url'             => $rec['url'] ?? get_permalink( $rec_pid ),
                        'keyword'         => $rec['keyword'] ?? '',
                        'cocon_id'        => $my_cocon_id,
                        'origin'          => 'Recommandation maillage Cocon',
                        'anchor_hint'     => $rec['anchor_text'] ?? '',
                        'gsc_clicks'      => 0,
                        'gsc_impressions' => 0,
                        'gsc_position'    => 0,
                    ) );
                    $injected++;
                }
                if ( $injected > 0 ) {
                    self::cocon_log( 'interlink_recommended', '📌 ' . $injected . ' lien(s) recommandé(s) Cocon injectés en priorité', array(
                        'post_id' => $post_id,
                        'cocon_id' => $my_cocon_id,
                    ) );
                }
            }
        }

        if ( empty( $candidates ) ) return array( 'outbound' => 0, 'inbound' => 0 );

        // ── Detect existing internal links in the new article ──
        preg_match_all( '/<a[^>]+href=["\']([^"\']*)["\'][^>]*>/i', $post->post_content, $existing_matches );
        $existing_link_count = 0;
        $site_host = wp_parse_url( site_url(), PHP_URL_HOST );
        foreach ( $existing_matches[1] ?? array() as $href ) {
            $h = wp_parse_url( $href, PHP_URL_HOST );
            if ( ! $h || $h === $site_host ) $existing_link_count++;
        }

        // ── 1. OUTBOUND: links FROM this article TO other articles ──
        $outbound = self::global_interlink_outbound( $post_id, $post, $candidates, $my_cocon_id, $existing_link_count, $openai_key, $link_config );

        // ── 2. INBOUND: links FROM existing articles TO this article ──
        $inbound = self::global_interlink_inbound( $post_id, $post, $my_keyword, $candidates, $openai_key, $link_config );

        // ── Store metadata ──
        update_post_meta( $post_id, '_hts_cross_links_out', $outbound['count'] );
        update_post_meta( $post_id, '_hts_cross_links_in', $inbound['count'] );

        // ── Sync cocon_data so the UI (orphan status, link counts) reflects new links ──
        $total_applied = $outbound['count'] + $inbound['count'];
        if ( $total_applied > 0 ) {
            self::sync_cocon_data_after_interlink( $post_id, $outbound, $inbound );
        }

        // ── Log ──
        $summary = 'Maillage global: ' . $outbound['count'] . ' sortant(s), ' . $inbound['count'] . ' entrant(s)';
        if ( $is_cron ) {
            self::cron_add_log( 'info', $summary, array( 'keyword' => $my_keyword ?: $post->post_title ) );
        } else {
            self::cocon_log( 'global_interlink', $summary, array(
                'post_id'  => $post_id,
                'outbound' => $outbound['details'],
                'inbound'  => $inbound['details'],
            ) );
        }

        return array( 'outbound' => $outbound['count'], 'inbound' => $inbound['count'] );
    }

    /**
     * Sync hts_cocon_data after cross-interlinking.
     *
     * Updates the cocon graph (incoming/outgoing arrays, link counts, orphan flag)
     * so the UI shows correct link counts and orphan status immediately
     * without requiring a full "Analyser le site" re-scan.
     *
     * @param int   $post_id  The article that was just interlinked
     * @param array $outbound { count, details[] } — outbound links applied
     * @param array $inbound  { count, details[] } — inbound links applied
     */
    /**
     * Sprint 6.3: Resolve the correct wp_option key for cocon_data,
     * respecting Polylang/WPML multilingual setup.
     *
     * @return string Option key like 'hts_cocon_data' or 'hts_cocon_data_fr'
     */
    private static function resolve_cocon_data_option_key() {
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $lang = HTS_Language::get_current_lang();
            if ( $lang && $lang !== 'all' ) {
                $key = 'hts_cocon_data_' . $lang;
                // Verify this key actually has data; if not, fall back
                $data = get_option( $key, array() );
                if ( ! empty( $data['nodes'] ) || ! empty( $data['clusters'] ) ) {
                    return $key;
                }
            }
        }
        return 'hts_cocon_data';
    }

    private static function sync_cocon_data_after_interlink( $post_id, $outbound, $inbound ) {
        $opt_key    = self::resolve_cocon_data_option_key();
        $cocon_data = get_option( $opt_key, array() );
        if ( empty( $cocon_data['nodes'] ) ) return;

        $changed = false;

        // ── Update outbound links (this article → targets) ──
        foreach ( $outbound['details'] ?? array() as $link ) {
            $target_id = (int) ( $link['target_id'] ?? 0 );
            if ( ! $target_id ) continue;

            // Add target to this article's outgoing
            if ( isset( $cocon_data['nodes'][ $post_id ] ) ) {
                if ( ! in_array( $target_id, $cocon_data['nodes'][ $post_id ]['outgoing'] ?? array() ) ) {
                    $cocon_data['nodes'][ $post_id ]['outgoing'][] = $target_id;
                    $changed = true;
                }
            }

            // Add this article to target's incoming
            if ( isset( $cocon_data['nodes'][ $target_id ] ) ) {
                if ( ! in_array( $post_id, $cocon_data['nodes'][ $target_id ]['incoming'] ?? array() ) ) {
                    $cocon_data['nodes'][ $target_id ]['incoming'][] = $post_id;
                    $changed = true;
                }
            }
        }

        // ── Update inbound links (sources → this article) ──
        foreach ( $inbound['details'] ?? array() as $link ) {
            $source_id = (int) ( $link['source_id'] ?? 0 );
            if ( ! $source_id ) continue;

            // Add this article to source's outgoing
            if ( isset( $cocon_data['nodes'][ $source_id ] ) ) {
                if ( ! in_array( $post_id, $cocon_data['nodes'][ $source_id ]['outgoing'] ?? array() ) ) {
                    $cocon_data['nodes'][ $source_id ]['outgoing'][] = $post_id;
                    $changed = true;
                }
            }

            // Add source to this article's incoming
            if ( isset( $cocon_data['nodes'][ $post_id ] ) ) {
                if ( ! in_array( $source_id, $cocon_data['nodes'][ $post_id ]['incoming'] ?? array() ) ) {
                    $cocon_data['nodes'][ $post_id ]['incoming'][] = $source_id;
                    $changed = true;
                }
            }
        }

        // ── Recalculate link counts and orphan status for affected nodes ──
        if ( $changed ) {
            $affected_ids = array( $post_id );
            foreach ( $outbound['details'] ?? array() as $l ) {
                if ( ! empty( $l['target_id'] ) ) $affected_ids[] = (int) $l['target_id'];
            }
            foreach ( $inbound['details'] ?? array() as $l ) {
                if ( ! empty( $l['source_id'] ) ) $affected_ids[] = (int) $l['source_id'];
            }

            foreach ( array_unique( $affected_ids ) as $nid ) {
                if ( ! isset( $cocon_data['nodes'][ $nid ] ) ) continue;
                $node = &$cocon_data['nodes'][ $nid ];
                $node['outgoing']  = array_values( array_unique( $node['outgoing'] ?? array() ) );
                $node['incoming']  = array_values( array_unique( $node['incoming'] ?? array() ) );
                $node['out_count'] = count( $node['outgoing'] );
                $node['in_count']  = count( $node['incoming'] );
                $node['out_links'] = $node['out_count'];
                $node['in_links']  = $node['in_count'];
                // Orphan = no incoming links at all
                $node['is_orphan'] = $node['in_count'] === 0;
                unset( $node );
            }

            // ── Recalculate cluster stats (orphan count, link density) ──
            if ( ! empty( $cocon_data['clusters'] ) ) {
                foreach ( $cocon_data['clusters'] as $cname => &$cluster ) {
                    if ( empty( $cluster['pages'] ) ) continue;
                    $c_orphans = 0;
                    $c_links   = 0;
                    foreach ( $cluster['pages'] as $pid ) {
                        if ( ! isset( $cocon_data['nodes'][ $pid ] ) ) continue;
                        if ( $cocon_data['nodes'][ $pid ]['is_orphan'] ) $c_orphans++;
                        $c_links += $cocon_data['nodes'][ $pid ]['out_count'] ?? 0;
                    }
                    $cluster['orphans']    = $c_orphans;
                    $cluster['link_count'] = $c_links;
                    $page_count = count( $cluster['pages'] );
                    $max_links  = $page_count * ( $page_count - 1 );
                    $cluster['density']    = $max_links > 0 ? round( ( $c_links / $max_links ) * 100 ) : 0;
                }
                unset( $cluster );
            }

            // ── Recalculate global stats ──
            $total_orphans = 0;
            $total_links   = 0;
            foreach ( $cocon_data['nodes'] as $n ) {
                if ( ! empty( $n['is_orphan'] ) ) $total_orphans++;
                $total_links += $n['out_count'] ?? 0;
            }
            if ( isset( $cocon_data['stats'] ) ) {
                $cocon_data['stats']['total_orphans'] = $total_orphans;
                $cocon_data['stats']['total_links']   = $total_links;
            }

            update_option( $opt_key, $cocon_data, false );

            self::cocon_log( 'cocon_data_synced', '🔄 Cocon data synchronisé après maillage', array(
                'post_id'        => $post_id,
                'outbound_added' => count( $outbound['details'] ?? array() ),
                'inbound_added'  => count( $inbound['details'] ?? array() ),
                'is_orphan_now'  => $cocon_data['nodes'][ $post_id ]['is_orphan'] ?? 'N/A',
            ) );
        }
    }

    /**
     * ══════════════════════════════════════════════════════════════════
     *  WEEKLY AUTO-MAINTENANCE CRON — Cocon health & link hygiene
     * ══════════════════════════════════════════════════════════════════
     *
     * Runs weekly via WP-Cron. Always active.
     *
     * ALWAYS (no config needed):
     *   1. CLEAN broken links (pointing to drafts, trashed, or deleted)
     *   2. REFRESH cocon_data (recount links, orphans, density per cluster)
     *
     * ONLY IF agent "linking" is in mode "auto":
     *   3. RE-INTERLINK orphans & under-linked (budgeted, max N per week)
     */
    public static function cron_weekly_interlink_maintenance() {
        $start_time = microtime( true );

        self::cron_add_log( 'info', '🔧 Maintenance hebdo — démarrage' );

        // ═══ PHASE 1: TOUJOURS — Nettoyage liens cassés ═══
        $cleaned = self::maintenance_clean_broken_links();

        // ═══ PHASE 2: TOUJOURS — Refresh cocon_data (recompte liens, orphelins, densité) ═══
        $stats = self::maintenance_refresh_cocon_data();

        // ═══ PHASE 3: CONDITIONNEL — Re-maillage auto (seulement si agent linking = auto) ═══
        $relinked_count = 0;
        $needs_linking  = array();
        $linking_mode   = 'off';

        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $linking_mode = HTS_Workflow_Engine::get_agent_mode( 'linking' );
        }

        if ( $linking_mode === 'auto' ) {
            $openai_key = hts_get_openai_key();

            if ( ! empty( $openai_key ) ) {
                // Detect articles needing links
                $needs_linking = self::maintenance_find_articles_needing_links();

                // Budget: max 5 articles per week, max 3 new links per article
                $max_per_run   = 5;
                $to_process    = array_slice( $needs_linking, 0, $max_per_run );

                foreach ( $to_process as $article ) {
                    $post_id = $article['id'];
                    $reason  = $article['reason'];

                    self::cocon_log( 'maintenance_interlink', "🔗 Re-maillage auto: {$reason}", array(
                        'post_id' => $post_id,
                        'title'   => get_the_title( $post_id ),
                    ) );

                    $result = self::cocon_cross_interlink( $post_id, true );

                    if ( ( $result['outbound'] ?? 0 ) + ( $result['inbound'] ?? 0 ) > 0 ) {
                        $relinked_count++;
                    }

                    // Rate limiting entre articles
                    sleep( 2 );
                }
            }
        }

        // ═══ LOG summary ═══
        $elapsed = round( microtime( true ) - $start_time, 1 );
        $summary = sprintf(
            '🔧 Maintenance terminée — %d liens cassés nettoyés, %d cocons actualisés (%d orphelins, %d liens)%s (%.1fs)',
            $cleaned,
            $stats['clusters_updated'],
            $stats['total_orphans'],
            $stats['total_links'],
            $linking_mode === 'auto'
                ? sprintf( ', %d articles re-maillés/%d à traiter', $relinked_count, count( $needs_linking ) )
                : ' [maillage auto off — agent linking en mode ' . $linking_mode . ']',
            $elapsed
        );
        self::cron_add_log( 'info', $summary );
        self::cocon_log( 'maintenance_done', $summary );
    }

    /**
     * Refresh cocon_data: recount all links, orphans, density from actual post_content.
     * This ensures the UI always reflects reality (especially after manual edits or external changes).
     *
     * @return array { clusters_updated, total_orphans, total_links }
     */
    private static function maintenance_refresh_cocon_data() {
        global $wpdb;

        $opt_key    = self::resolve_cocon_data_option_key();
        $cocon_data = get_option( $opt_key, array() );
        if ( empty( $cocon_data['nodes'] ) ) {
            return array( 'clusters_updated' => 0, 'total_orphans' => 0, 'total_links' => 0 );
        }

        $site_host    = wp_parse_url( site_url(), PHP_URL_HOST );
        $all_post_ids = array_keys( $cocon_data['nodes'] );

        // Build a reverse map: URL/path → post_id for fast lookup
        $url_to_id = array();
        foreach ( $all_post_ids as $pid ) {
            $permalink = get_permalink( $pid );
            if ( $permalink ) {
                $url_to_id[ $permalink ] = $pid;
                $path = wp_parse_url( $permalink, PHP_URL_PATH );
                if ( $path ) $url_to_id[ $path ] = $pid;
            }
            // Also map ?p=ID format
            $url_to_id[ '?p=' . $pid ] = $pid;
        }

        // Recount outgoing links for each node from actual content
        foreach ( $cocon_data['nodes'] as $pid => &$node ) {
            $post = get_post( $pid );
            if ( ! $post || $post->post_status !== 'publish' ) {
                // Article no longer published — mark for removal from UI
                $node['is_orphan'] = true;
                $node['outgoing']  = array();
                $node['incoming']  = array();
                continue;
            }

            // Parse outgoing internal links from content
            $outgoing = array();
            if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $post->post_content, $link_matches ) ) {
                foreach ( $link_matches[1] as $href ) {
                    $h = wp_parse_url( $href, PHP_URL_HOST );
                    if ( $h && $h !== $site_host ) continue; // external

                    // Resolve target post ID
                    $target_id = 0;
                    if ( isset( $url_to_id[ $href ] ) ) {
                        $target_id = $url_to_id[ $href ];
                    } else {
                        $path = wp_parse_url( $href, PHP_URL_PATH );
                        if ( $path && isset( $url_to_id[ $path ] ) ) {
                            $target_id = $url_to_id[ $path ];
                        } else {
                            $target_id = hts_url_to_postid( $href );
                        }
                    }

                    if ( $target_id && $target_id !== $pid && isset( $cocon_data['nodes'][ $target_id ] ) ) {
                        $outgoing[] = $target_id;
                    }
                }
            }

            $node['outgoing']  = array_values( array_unique( $outgoing ) );
            $node['out_count'] = count( $node['outgoing'] );
            $node['out_links'] = $node['out_count'];
        }
        unset( $node );

        // Rebuild incoming from outgoing (ground truth)
        foreach ( $cocon_data['nodes'] as $pid => &$node ) {
            $node['incoming'] = array();
        }
        unset( $node );

        foreach ( $cocon_data['nodes'] as $pid => $node ) {
            foreach ( $node['outgoing'] as $target_id ) {
                if ( isset( $cocon_data['nodes'][ $target_id ] ) ) {
                    $cocon_data['nodes'][ $target_id ]['incoming'][] = $pid;
                }
            }
        }

        // Deduplicate incoming + set counts + orphan flag
        $total_orphans = 0;
        $total_links   = 0;
        foreach ( $cocon_data['nodes'] as $pid => &$node ) {
            $node['incoming']  = array_values( array_unique( $node['incoming'] ) );
            $node['in_count']  = count( $node['incoming'] );
            $node['in_links']  = $node['in_count'];
            $node['is_orphan'] = $node['in_count'] === 0;
            if ( $node['is_orphan'] ) $total_orphans++;
            $total_links += $node['out_count'];
        }
        unset( $node );

        // Recalculate cluster stats
        $clusters_updated = 0;
        if ( ! empty( $cocon_data['clusters'] ) ) {
            foreach ( $cocon_data['clusters'] as $cname => &$cluster ) {
                if ( empty( $cluster['pages'] ) ) continue;
                $c_orphans = 0;
                $c_links   = 0;
                foreach ( $cluster['pages'] as $cpid ) {
                    if ( ! isset( $cocon_data['nodes'][ $cpid ] ) ) continue;
                    if ( $cocon_data['nodes'][ $cpid ]['is_orphan'] ) $c_orphans++;
                    $c_links += $cocon_data['nodes'][ $cpid ]['out_count'] ?? 0;
                }
                $cluster['orphans']    = $c_orphans;
                $cluster['link_count'] = $c_links;
                $page_count = count( $cluster['pages'] );
                $max_links  = $page_count * ( $page_count - 1 );
                $cluster['density']    = $max_links > 0 ? round( ( $c_links / $max_links ) * 100 ) : 0;
                $clusters_updated++;
            }
            unset( $cluster );
        }

        // Update global stats
        if ( isset( $cocon_data['stats'] ) ) {
            $cocon_data['stats']['total_orphans'] = $total_orphans;
            $cocon_data['stats']['total_links']   = $total_links;
        }

        update_option( $opt_key, $cocon_data, false );

        return array(
            'clusters_updated' => $clusters_updated,
            'total_orphans'    => $total_orphans,
            'total_links'      => $total_links,
        );
    }

    /**
     * Clean broken internal links — links pointing to non-published posts.
     * Scans all published articles and removes <a> tags pointing to drafts/trashed/deleted.
     *
     * @return int Number of links removed
     */
    private static function maintenance_clean_broken_links() {
        global $wpdb;

        // Get all published articles that contain internal links
        $site_host = wp_parse_url( site_url(), PHP_URL_HOST );
        $site_url  = rtrim( site_url(), '/' );

        $posts = $wpdb->get_results(
            "SELECT ID, post_content FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ('post', 'page')
               AND post_content LIKE '%<a %'
             ORDER BY post_date DESC
             LIMIT 500",
            ARRAY_A
        );

        $total_cleaned = 0;

        foreach ( $posts as $row ) {
            $content  = $row['post_content'];
            $post_id  = (int) $row['ID'];
            $modified = false;

            // Find all internal links
            if ( ! preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/si', $content, $matches, PREG_SET_ORDER ) ) {
                continue;
            }

            foreach ( $matches as $match ) {
                $full_tag = $match[0];
                $href     = $match[1];
                $anchor   = $match[2];

                // Only process internal links
                $parsed = wp_parse_url( $href );
                $link_host = $parsed['host'] ?? '';
                if ( $link_host && $link_host !== $site_host ) continue;

                // Resolve to post ID
                $target_id = hts_url_to_postid( $href );
                if ( ! $target_id ) continue;

                // Check if target is still published
                $target_status = get_post_status( $target_id );
                if ( $target_status === 'publish' ) continue;

                // Target is draft/trash/deleted — remove the link but keep anchor text
                $content = str_replace( $full_tag, strip_tags( $anchor ), $content );
                $modified = true;
                $total_cleaned++;

                self::cocon_log( 'maintenance_clean', '🗑️ Lien cassé supprimé', array(
                    'source_id'     => $post_id,
                    'target_id'     => $target_id,
                    'target_status' => $target_status ?: 'deleted',
                    'anchor'        => mb_substr( strip_tags( $anchor ), 0, 60 ),
                ) );
            }

            if ( $modified ) {
                wp_update_post( array(
                    'ID'           => $post_id,
                    'post_content' => $content,
                ) );
            }
        }

        return $total_cleaned;
    }

    /**
     * Find articles that need more links — orphans (0 incoming) and under-linked (< 2 outgoing).
     * Only published articles. Prioritizes: orphans first, then under-linked, then oldest articles.
     *
     * @return array [ { id, reason, in_count, out_count } ]
     */
    private static function maintenance_find_articles_needing_links() {
        global $wpdb;

        $site_host = wp_parse_url( site_url(), PHP_URL_HOST );

        // Get all published articles
        $posts = $wpdb->get_results(
            "SELECT ID, post_title, post_content FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ('post', 'page')
               AND LENGTH(post_content) > 500
             ORDER BY post_date ASC
             LIMIT 200",
            ARRAY_A
        );

        $needs_linking = array();

        foreach ( $posts as $row ) {
            $post_id = (int) $row['ID'];
            $content = $row['post_content'];

            // Count internal outgoing links
            $out_count = 0;
            $in_count  = 0;

            if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $content, $link_matches ) ) {
                foreach ( $link_matches[1] as $href ) {
                    $h = wp_parse_url( $href, PHP_URL_HOST );
                    if ( ! $h || $h === $site_host ) $out_count++;
                }
            }

            // Count incoming links from other articles
            $in_count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts}
                 WHERE post_status = 'publish'
                   AND post_type IN ('post', 'page')
                   AND ID != %d
                   AND post_content LIKE %s",
                $post_id,
                '%' . $wpdb->esc_like( '?p=' . $post_id ) . '%'
            ) );

            // Also count permalink-based incoming links
            $permalink = get_permalink( $post_id );
            $path_only = wp_parse_url( $permalink, PHP_URL_PATH );
            if ( $path_only && strlen( $path_only ) > 1 ) {
                $in_count += (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts}
                     WHERE post_status = 'publish'
                       AND post_type IN ('post', 'page')
                       AND ID != %d
                       AND post_content LIKE %s",
                    $post_id,
                    '%' . $wpdb->esc_like( $path_only ) . '%'
                ) );
            }

            // Determine if this article needs links
            $reason = '';
            if ( $in_count === 0 ) {
                $reason = 'Orphelin (0 lien entrant)';
            } elseif ( $out_count < 2 ) {
                $reason = 'Sous-maillé (' . $out_count . ' lien(s) sortant)';
            }

            if ( $reason ) {
                $needs_linking[] = array(
                    'id'        => $post_id,
                    'title'     => $row['post_title'],
                    'reason'    => $reason,
                    'in_count'  => $in_count,
                    'out_count' => $out_count,
                );
            }
        }

        // Sort: orphans first, then under-linked
        usort( $needs_linking, function( $a, $b ) {
            // Orphans (in_count=0) first
            if ( $a['in_count'] === 0 && $b['in_count'] > 0 ) return -1;
            if ( $a['in_count'] > 0 && $b['in_count'] === 0 ) return 1;
            // Then by lowest out_count
            return $a['out_count'] - $b['out_count'];
        } );

        return $needs_linking;
    }

    /**
     * Get ALL candidate articles across the entire site.
     *
     * Includes:
     *  - Other cocon articles
     *  - Same cocon articles (for complementary links)
     *  - Historical / manually written posts
     *  - Pages
     *
     * Excludes only the current post itself.
     */
    private static function global_interlink_get_candidates( $exclude_post_id ) {
        global $wpdb;

        // Get homepage ID to exclude
        $homepage_id = (int) get_option( 'page_on_front', 0 );

        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_content, p.post_status, p.post_type,
                    kw.meta_value AS keyword,
                    cc.meta_value AS cocon_id,
                    gc.meta_value AS gsc_clicks,
                    gi.meta_value AS gsc_impressions,
                    gp.meta_value AS gsc_position,
                    gt.meta_value AS gsc_ctr
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} kw ON p.ID = kw.post_id AND kw.meta_key = '_hts_api_keyword'
             LEFT JOIN {$wpdb->postmeta} cc ON p.ID = cc.post_id AND cc.meta_key = '_hts_cocon_id'
             LEFT JOIN {$wpdb->postmeta} gc ON p.ID = gc.post_id AND gc.meta_key = '_hts_gsc_clicks'
             LEFT JOIN {$wpdb->postmeta} gi ON p.ID = gi.post_id AND gi.meta_key = '_hts_gsc_impressions'
             LEFT JOIN {$wpdb->postmeta} gp ON p.ID = gp.post_id AND gp.meta_key = '_hts_gsc_position'
             LEFT JOIN {$wpdb->postmeta} gt ON p.ID = gt.post_id AND gt.meta_key = '_hts_gsc_ctr'
             WHERE p.post_type " . hts_sql_post_types_in() . "
               AND p.post_status = 'publish'
               AND p.ID != %d
               AND LENGTH(p.post_content) > 200
             ORDER BY p.post_date DESC
             LIMIT 200",
            $exclude_post_id
        ), ARRAY_A );

        $candidates = array();
        // ── Detect source article language (simple heuristic: first 500 chars) ──
        $source_post = get_post( $exclude_post_id );
        $source_lang = 'fr'; // default
        if ( $source_post ) {
            $sample = mb_strtolower( mb_substr( wp_strip_all_tags( $source_post->post_content ), 0, 500 ) );
            // Simple heuristic: count French vs English common words
            $fr_words = preg_match_all( '/\b(les|des|une|est|dans|pour|avec|sur|qui|que|cette|sont|pas|peut|mais|ses|leur)\b/u', $sample );
            $en_words = preg_match_all( '/\b(the|and|for|this|that|with|from|your|are|not|you|was|has|have|can|will|all|been)\b/u', $sample );
            $source_lang = ( $en_words > $fr_words ) ? 'en' : 'fr';
        }

        foreach ( $results as $r ) {
            // Skip homepage — linking to it from articles has no SEO value
            if ( $homepage_id > 0 && (int) $r['ID'] === $homepage_id ) continue;

            // ── Language filter: skip articles in a different language ──
            $candidate_sample = mb_strtolower( mb_substr( wp_strip_all_tags( $r['post_content'] ), 0, 500 ) );
            $c_fr = preg_match_all( '/\b(les|des|une|est|dans|pour|avec|sur|qui|que|cette|sont|pas|peut|mais|ses|leur)\b/u', $candidate_sample );
            $c_en = preg_match_all( '/\b(the|and|for|this|that|with|from|your|are|not|you|was|has|have|can|will|all|been)\b/u', $candidate_sample );
            $candidate_lang = ( $c_en > $c_fr ) ? 'en' : 'fr';
            if ( $candidate_lang !== $source_lang ) continue;

            $text = wp_strip_all_tags( $r['post_content'] );
            // Tag the origin for the prompt
            $cocon_id = $r['cocon_id'] ?: '';
            if ( $cocon_id ) {
                $origin = 'Cocon #' . $cocon_id;
            } elseif ( $r['post_type'] === 'page' ) {
                $origin = 'Page';
            } else {
                $origin = 'Historique';
            }

            $gsc_clicks      = (int) ( $r['gsc_clicks'] ?: 0 );
            $gsc_impressions  = (int) ( $r['gsc_impressions'] ?: 0 );
            $gsc_position     = (float) ( $r['gsc_position'] ?: 0 );
            $gsc_ctr          = (float) ( $r['gsc_ctr'] ?: 0 );

            $candidates[] = array(
                'id'       => (int) $r['ID'],
                'title'    => $r['post_title'],
                'keyword'  => $r['keyword'] ?: '',
                'cocon_id' => $cocon_id,
                'origin'   => $origin,
                'url'      => get_permalink( (int) $r['ID'] ),
                'excerpt'  => mb_substr( $text, 0, 300 ),
                'status'   => $r['post_status'],
                'type'     => $r['post_type'],
                // GSC metrics
                'gsc_clicks'      => $gsc_clicks,
                'gsc_impressions' => $gsc_impressions,
                'gsc_position'    => $gsc_position,
                'gsc_ctr'         => $gsc_ctr,
            );
        }

        return $candidates;
    }

    /**
     * Simple TF-IDF keyword extraction for pre-filtering
     */
    private static function cross_interlink_extract_keywords( $text, $max = 15 ) {
        $text = preg_replace( '/[^a-zàâäéèêëïîôùûüÿçœæ\s\'-]/u', ' ', $text );
        $stop = array_flip( explode( ',', 'le,la,les,un,une,des,du,de,d,l,au,aux,en,et,ou,mais,donc,car,ni,que,qui,quoi,dont,où,ce,ces,cette,cet,se,son,sa,ses,leur,leurs,mon,ma,mes,ton,ta,tes,nous,vous,ils,elles,je,tu,il,elle,on,ne,pas,plus,très,aussi,bien,pour,par,sur,dans,avec,sans,sous,entre,vers,chez,est,sont,être,avoir,faire,fait,dit,peut,tout,tous,toute,toutes,comme,même,autre,autres,quand,comment,pourquoi,si,alors,donc,puis,après,avant,depuis,encore,déjà,peu,beaucoup,trop,assez,article,page,the,and,for,this,that,with,from,your,are,not,you,was,has,have,can,will,all,been,more,into' ) );
        $words = preg_split( '/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $words = array_filter( $words, function( $w ) use ( $stop ) { return mb_strlen( $w ) >= 3 && ! isset( $stop[ $w ] ); } );

        $freq = array_count_values( $words );
        arsort( $freq );

        // Bigrams
        $prev = '';
        $bigrams = array();
        foreach ( $words as $w ) {
            if ( $prev ) {
                $bg = $prev . ' ' . $w;
                $bigrams[ $bg ] = ( $bigrams[ $bg ] ?? 0 ) + 1;
            }
            $prev = $w;
        }
        arsort( $bigrams );

        $scores = array();
        foreach ( array_slice( $bigrams, 0, 10 ) as $bg => $c ) {
            if ( $c >= 2 ) $scores[ $bg ] = $c * 2.5;
        }
        foreach ( array_slice( $freq, 0, 20 ) as $w => $c ) {
            if ( $c >= 2 ) $scores[ $w ] = ( $scores[ $w ] ?? 0 ) + $c;
        }
        arsort( $scores );
        return array_slice( array_keys( $scores ), 0, $max );
    }

    /**
     * Rank candidates by keyword overlap with the source article + GSC metrics.
     *
     * GSC scoring logic:
     *  - High clicks = strong page (good to link TO for authority sharing)
     *  - High impressions + position 4-20 = opportunity page (needs inbound boost)
     *  - Position 1-3 = already strong, still valuable for outbound
     *  - No GSC data = neutral (don't penalize new content)
     */
    private static function cross_interlink_rank_candidates( $candidates, $source_keywords ) {
        if ( empty( $source_keywords ) || empty( $candidates ) ) return $candidates;

        // Check if ANY candidate has GSC data (to avoid skewing when no GSC imported)
        $has_gsc = false;
        foreach ( $candidates as $c ) {
            if ( ( $c['gsc_clicks'] ?? 0 ) > 0 || ( $c['gsc_impressions'] ?? 0 ) > 0 ) {
                $has_gsc = true;
                break;
            }
        }

        foreach ( $candidates as &$c ) {
            // ── 1. Keyword overlap score (0-15) ──
            $c_text = mb_strtolower( $c['title'] . ' ' . $c['keyword'] . ' ' . $c['excerpt'] );
            $overlap = 0;
            foreach ( $source_keywords as $kw ) {
                if ( mb_strpos( $c_text, $kw ) !== false ) $overlap++;
            }

            // ── 2. GSC boost (0-10) — only if data exists ──
            $gsc_score = 0;
            if ( $has_gsc ) {
                $clicks      = (int) ( $c['gsc_clicks'] ?? 0 );
                $impressions = (int) ( $c['gsc_impressions'] ?? 0 );
                $position    = (float) ( $c['gsc_position'] ?? 0 );

                // Clicks boost: log scale (1 clic = +1, 10 = +3.3, 100 = +6.6, 1000 = +10)
                if ( $clicks > 0 ) {
                    $gsc_score += min( 10, round( log10( $clicks + 1 ) * 3.3, 1 ) );
                }
                // Opportunity boost: high impressions + mediocre position = needs link juice
                if ( $impressions >= 50 && $position >= 4 && $position <= 20 ) {
                    $gsc_score += min( 5, round( log10( $impressions ) * 1.5, 1 ) );
                }
                // Position bonus: top 3 pages are authoritative link sources
                if ( $position > 0 && $position <= 3 ) {
                    $gsc_score += 2;
                }
            }

            $c['_relevance'] = $overlap + $gsc_score;
            $c['_gsc_score'] = $gsc_score;
        }
        unset( $c );

        usort( $candidates, function( $a, $b ) {
            return ( $b['_relevance'] ?? 0 ) - ( $a['_relevance'] ?? 0 );
        } );

        // Only keep candidates with at least 1 keyword overlap
        return array_values( array_filter( $candidates, function( $c ) {
            return ( $c['_relevance'] ?? 0 ) >= 1;
        } ) );
    }

    /**
     * OUTBOUND: Insert links FROM the new article TO the best matching articles.
     * Uses connector sentences (not exact anchor matching) for reliable insertion.
     *
     * @return array { count, details[] }
     */
    private static function global_interlink_outbound( $post_id, $post, $candidates, $my_cocon_id, $existing_link_count, $openai_key, $link_config = array() ) {
        $html = $post->post_content;
        $my_keyword = get_post_meta( $post_id, '_hts_api_keyword', true );

        // ── Smart max: use per-cocon config ──
        $word_count = hts_word_count( wp_strip_all_tags( $html ) );
        $max_links = HTS_Cocon_Commander::calc_max_outbound( $link_config, $word_count, $existing_link_count );
        $min_relevance = (int) ( $link_config['min_relevance'] ?? 50 );

        // Detect existing internal links (to skip already-linked targets)
        preg_match_all( '/<a[^>]+href=["\']([^"\']*)["\'][^>]*>/i', $html, $existing_links );
        $existing_urls = array_map( 'trailingslashit', $existing_links[1] ?? array() );

        // Format candidates (exclude already linked)
        $candidates_text = '';
        $count = 0;
        foreach ( $candidates as $c ) {
            if ( in_array( trailingslashit( $c['url'] ), $existing_urls, true ) ) continue;
            if ( $count >= 20 ) break;
            $label = $c['origin'];
            if ( $c['cocon_id'] && $c['cocon_id'] === $my_cocon_id ) {
                $label = 'Même cocon #' . $c['cocon_id'];
            }
            $gsc_tag = '';
            if ( ( $c['gsc_clicks'] ?? 0 ) > 0 || ( $c['gsc_impressions'] ?? 0 ) > 0 ) {
                $gsc_parts = array();
                if ( $c['gsc_clicks'] > 0 ) $gsc_parts[] = $c['gsc_clicks'] . ' clics';
                if ( $c['gsc_impressions'] > 0 ) $gsc_parts[] = $c['gsc_impressions'] . ' impr';
                if ( $c['gsc_position'] > 0 ) $gsc_parts[] = 'pos ' . $c['gsc_position'];
                $gsc_tag = ' | ' . implode( ', ', $gsc_parts );
            }
            $candidates_text .= "- ID:{$c['id']} | \"{$c['title']}\" | KW: {$c['keyword']} | [{$label}]{$gsc_tag}\n";
            $count++;
        }

        if ( empty( $candidates_text ) ) {
            return array( 'count' => 0, 'details' => array() );
        }

        // ── PROMPT: pick targets + generate diverse anchor text ──
        $lang_name = self::get_lang_name_for_prompt();
        $prompt = "Tu es un consultant SEO senior. Choisis les articles les plus pertinents pour un maillage interne sortant, et génère une ancre optimisée pour chacun.
LANGUE DU SITE : {$lang_name} — les ancres DOIVENT être rédigées en {$lang_name}.

═══ ARTICLE SOURCE ═══
Titre : \"{$post->post_title}\"
Keyword : \"{$my_keyword}\"

═══ ARTICLES CIBLES DISPONIBLES ═══
{$candidates_text}

═══ RÈGLES DE SÉLECTION ═══
1. Choisis jusqu'à {$max_links} articles cibles pertinents pour le lecteur.
2. PRIORITÉ : Même cocon d'abord, puis articles thématiquement proches, puis historique.
3. PRIORITÉ GSC : À pertinence égale, favorise les articles avec clics/impressions.
4. Ne PAS lier vers des articles non pertinents juste pour remplir le quota.

═══ RÈGLES ANCRE (CRITIQUE) ═══
L'ancre est le texte cliquable du lien. Elle doit :
- Faire 3 à 7 mots, descriptive et naturelle dans la langue du site
- Décrire ce que le lecteur va trouver sur la page cible
- VARIER les formes : NE JAMAIS utiliser le keyword exact de la cible tel quel
- Utiliser des variations sémantiques, synonymes partiels ou reformulations naturelles
  Exemple pour KW \"récepteurs 5-HT2A\" → ancre \"le rôle des récepteurs sérotoninergiques\"
  Exemple pour KW \"conversion psilocine\" → ancre \"la transformation en psilocine\"
  Exemple pour KW \"connectivité cérébrale\" → ancre \"les connexions entre réseaux cérébraux\"
- INTERDIT : ancre = keyword exact, ancre = titre exact, ancre générique (\"cliquez ici\", \"en savoir plus\")

═══ FORMAT JSON strict ═══
[{\"target_id\":123,\"anchor\":\"variation sémantique naturelle\",\"relevance_score\":85,\"reason\":\"Explication courte\"}]
Si aucun lien pertinent → []";

        $result = self::cross_interlink_openai_call( $openai_key, $prompt );
        if ( empty( $result ) || ! is_array( $result ) ) {
            return array( 'count' => 0, 'details' => array() );
        }

        // ── Apply outbound links via connector sentences ──
        $content = $post->post_content;
        $applied = array();
        $candidate_map = array_column( $candidates, null, 'id' );

        foreach ( $result as $s ) {
            $target_id = absint( $s['target_id'] ?? 0 );
            $score     = (int) ( $s['relevance_score'] ?? 0 );
            $ai_anchor = trim( $s['anchor'] ?? '' );

            if ( ! $target_id || $score < $min_relevance ) continue;
            if ( ! isset( $candidate_map[ $target_id ] ) ) continue;

            $target     = $candidate_map[ $target_id ];
            $target_url = esc_url( $target['url'] );

            // Skip if already linked (double-check)
            if ( mb_strpos( $content, $target_url ) !== false ) continue;

            // Skip homepage
            if ( trailingslashit( $target['url'] ) === trailingslashit( home_url() ) ) continue;

            // Use AI anchor if valid, else fallback to keyword or title
            $anchor_text = '';
            if ( ! empty( $ai_anchor ) && mb_strlen( $ai_anchor ) >= 5 && mb_strlen( $ai_anchor ) <= 80 ) {
                $anchor_text = $ai_anchor;
            } elseif ( ! empty( $target['keyword'] ) ) {
                $anchor_text = $target['keyword'];
            } else {
                $anchor_text = $target['title'];
            }

            // ── Insert via connector sentence into a relevant paragraph ──
            $new_content = self::insert_connector_link(
                $content,
                $target['url'],
                $target['title'],
                $target['keyword'],
                $anchor_text
            );

            if ( $new_content && $new_content !== $content ) {
                $content = $new_content;
                $applied[] = array(
                    'target_id'    => $target_id,
                    'target_title' => $target['title'],
                    'anchor'       => $anchor_text,
                    'origin'       => $target['origin'],
                );
                self::cocon_log( 'interlink_outbound_ok', '✅ Lien sortant inséré', array(
                    'target' => $target['title'], 'anchor' => $anchor_text,
                ) );
            } else {
                self::cocon_log( 'interlink_outbound_skip', '⏭️ Pas de paragraphe adapté pour lien sortant', array(
                    'target' => $target['title'],
                ) );
            }

            if ( count( $applied ) >= $max_links ) break;
        }

        // Save updated content
        if ( ! empty( $applied ) ) {
            $content_before = $post->post_content;
            // Sprint 6.2d: clean internal link attributes before save
            $content = self::fix_internal_link_attrs( $content );
            wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );

            // Sprint 6.2d: sync outbound link counter
            if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                \HTS_Workflow_Engine::recount_internal_links( $post_id );
            }

            if ( class_exists( 'HTS_Audit_Trail' ) ) {
                foreach ( $applied as $a ) {
                    HTS_Audit_Trail::log_link( $post_id, $a['target_id'], $a['anchor'], 'outbound', $content_before, $content, HTS_Audit_Trail::get_gsc_snapshot( $post_id ) );
                }
            }
        }

        return array( 'count' => count( $applied ), 'details' => $applied );
    }

    /**
     * Disperse dense internal-link blocks.
     *
     * When SaaS generates a <ul> with 4+ internal links stacked together,
     * keep the first 2 in the <ul> and redistribute the rest as connector
     * sentences appended to the next available <p> tags (1 link per paragraph).
     * Overflow links (no available paragraph) are dropped — cross-linking
     * will re-insert them more naturally later.
     *
     * @param string $content HTML content
     * @return string Modified content
     */
    private static function disperse_dense_link_blocks( $content ) {
        $site_host = wp_parse_url( site_url(), PHP_URL_HOST );
        $max_in_block = 2; // max internal links to keep in a single <ul>

        // Find all <ul>...</ul> blocks
        if ( ! preg_match_all( '/<ul[^>]*>.*?<\/ul>/si', $content, $ul_matches, PREG_OFFSET_CAPTURE ) ) {
            return $content;
        }

        // Connector phrases for dispersed links
        $lang = self::get_site_lang_code();
        $dispersal_phrases = array(
            'fr' => array(
                'Voir aussi %s.',
                'Ce point est abord\u00e9 dans %s.',
                'Pour aller plus loin : %s.',
                'Consultez \u00e9galement %s.',
            ),
            'en' => array(
                'See also %s.',
                'This point is discussed in %s.',
                'For more on this: %s.',
                'You may also want to read %s.',
            ),
            'es' => array( 'Vea tambi\u00e9n %s.', 'Este punto se aborda en %s.' ),
            'de' => array( 'Siehe auch %s.', 'Dieser Punkt wird behandelt in %s.' ),
            'it' => array( 'Vedi anche %s.', 'Questo punto \u00e8 trattato in %s.' ),
            'pt' => array( 'Veja tambi\u00e9n %s.', 'Este ponto \u00e9 abordado em %s.' ),
            'nl' => array( 'Zie ook %s.', 'Dit punt wordt besproken in %s.' ),
            'ja' => array( '%s もご覧ください。', 'この点は %s で解説しています。' ),
            'zh' => array( '另请参阅 %s。', '此问题在 %s 中有讨论。' ),
            'ar' => array( 'انظر أيضًا %s.', 'تمت مناقشة هذه النقطة في %s.' ),
            'ru' => array( 'Смотрите также %s.', 'Этот вопрос рассматривается в %s.' ),
            'ko' => array( '%s도 참고하세요.', '이 내용은 %s에서 다루고 있습니다.' ),
            'pl' => array( 'Zobacz także %s.', 'Ten temat jest omawiany w %s.' ),
            'sv' => array( 'Se även %s.', 'Denna punkt diskuteras i %s.' ),
            'tr' => array( 'Ayrıca bakınız: %s.', 'Bu konu %s içinde ele alınmaktadır.' ),
        );
        $phrases = $dispersal_phrases[ $lang ] ?? $dispersal_phrases['en'];

        $links_to_disperse = array(); // array of full <a> tags to redistribute
        $removals = array();          // array of [ offset, length, replacement ]

        foreach ( $ul_matches[0] as $match ) {
            $ul_html = $match[0];
            $ul_offset = $match[1];

            // v19: Skip nested <ul> — regex non-greedy can cut at wrong </ul>
            if ( preg_match( '/<ul[^>]*>/i', substr( $ul_html, 4 ) ) ) {
                continue;
            }

            // Extract all <li> items
            if ( ! preg_match_all( '/<li[^>]*>(.*?)<\/li>/si', $ul_html, $li_matches ) ) {
                continue;
            }

            // Count internal links per <li>
            $internal_lis = array();
            $other_lis = array();
            foreach ( $li_matches[0] as $idx => $li_full ) {
                $li_inner = $li_matches[1][ $idx ];
                // Check if this <li> contains an internal link
                $has_internal = false;
                if ( preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/si', $li_inner, $a_matches, PREG_SET_ORDER ) ) {
                    foreach ( $a_matches as $a ) {
                        $href_host = wp_parse_url( $a[1], PHP_URL_HOST );
                        if ( ! $href_host || $href_host === $site_host ) {
                            $has_internal = true;
                            break;
                        }
                    }
                }
                if ( $has_internal ) {
                    $internal_lis[] = array( 'full' => $li_full, 'inner' => $li_inner );
                } else {
                    $other_lis[] = $li_full;
                }
            }

            // Only process if too many internal links
            if ( count( $internal_lis ) <= $max_in_block ) {
                continue;
            }

            // Keep first N, extract the rest
            $keep = array_slice( $internal_lis, 0, $max_in_block );
            $extract = array_slice( $internal_lis, $max_in_block );

            // Collect extracted links
            foreach ( $extract as $ex ) {
                // Get the first <a> tag from this <li>
                if ( preg_match( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/si', $ex['inner'], $am ) ) {
                    $links_to_disperse[] = $am[0]; // full <a> tag
                }
            }

            // Rebuild <ul> with only kept items + non-internal items
            $new_lis = array();
            foreach ( $keep as $k ) $new_lis[] = $k['full'];
            foreach ( $other_lis as $o ) $new_lis[] = $o;

            if ( empty( $new_lis ) ) {
                // Remove entire <ul> + any preceding intro sentence
                $removals[] = array( $ul_offset, strlen( $ul_html ), '' );
            } else {
                $new_ul = "<ul>\n" . implode( "\n", $new_lis ) . "\n</ul>";
                $removals[] = array( $ul_offset, strlen( $ul_html ), $new_ul );
            }
        }

        if ( empty( $links_to_disperse ) && empty( $removals ) ) {
            return $content;
        }

        // Apply removals in reverse offset order (so offsets stay valid)
        usort( $removals, function( $a, $b ) { return $b[0] - $a[0]; } );
        foreach ( $removals as $r ) {
            $content = substr_replace( $content, $r[2], $r[0], $r[1] );
        }

        // Now disperse extracted links into following paragraphs
        if ( ! empty( $links_to_disperse ) ) {

            // v19-AM1: Filter out links whose href already appears elsewhere in content (avoid duplicates)
            $content_no_ul = preg_replace( '/<ul[^>]*>.*?<\/ul>/si', '', $content );
            $links_to_disperse = array_filter( $links_to_disperse, function( $link_tag ) use ( $content_no_ul ) {
                if ( preg_match( '/href=["\']([^"\']+)["\']/i', $link_tag, $m ) ) {
                    return strpos( $content_no_ul, $m[1] ) === false;
                }
                return true;
            } );
            $links_to_disperse = array_values( $links_to_disperse );

            // v19-BUG2: Re-scan <p> AFTER removals — offsets are now correct
            preg_match_all( '/<p[^>]*>.*?<\/p>/si', $content, $p_matches, PREG_OFFSET_CAPTURE );
            $available_ps = array();
            foreach ( $p_matches[0] ?? array() as $pm ) {
                $p_html = $pm[0];
                $p_text = wp_strip_all_tags( $p_html );
                // Skip short paragraphs, paragraphs with too many links, or already-dispersed ones
                if ( mb_strlen( trim( $p_text ) ) < 50 ) continue;
                if ( substr_count( mb_strtolower( $p_html ), '<a ' ) > 2 ) continue;
                if ( strpos( $p_html, 'data-hts-connector' ) !== false ) continue;
                if ( preg_match( '/Voir aussi|Consultez|Ce point est|Pour aller plus loin|See also|For more on/i', $p_html ) ) continue;
                $available_ps[] = $pm;
            }

            // Distribute: 1 link per paragraph, spread evenly
            $p_count = count( $available_ps );
            $l_count = count( $links_to_disperse );
            if ( $p_count > 0 && $l_count > 0 ) {
                $step = max( 1, (int) floor( $p_count / $l_count ) );
                $placed = 0;
                // v19-BUG2: Use offset-based insertion (reverse order to preserve offsets)
                $insertions = array();
                for ( $i = 0; $i < $l_count && ( $i * $step ) < $p_count; $i++ ) {
                    $p_idx = min( $i * $step, $p_count - 1 );
                    $p_html   = $available_ps[ $p_idx ][0];
                    $p_offset = $available_ps[ $p_idx ][1];
                    $p_len    = strlen( $p_html );
                    $link_tag = $links_to_disperse[ $i ];
                    $phrase = sprintf( $phrases[ $i % count( $phrases ) ], $link_tag );
                    $connector = ' ' . $phrase;
                    $insertions[] = array( $p_offset, $p_len, $p_html, $connector );
                    $placed++;
                }

                // Apply in reverse offset order (so earlier offsets remain valid)
                usort( $insertions, function( $a, $b ) { return $b[0] - $a[0]; } );
                foreach ( $insertions as $ins ) {
                    $new_p = str_replace( '</p>', $ins[3] . '</p>', $ins[2] );
                    $content = substr_replace( $content, $new_p, $ins[0], $ins[1] );
                }

                if ( $placed > 0 ) {
                    self::cocon_log( 'link_density', $placed . ' lien(s) redistribué(s) depuis bloc <ul> dense', array(
                        'extracted' => $l_count,
                        'placed'    => $placed,
                        'dropped'   => $l_count - $placed,
                    ) );
                }
            }
        }

        return $content;
    }

    /**
     * Insert a connector sentence with link into content at a relevant paragraph.
     * Protects intro zone (before first H2) and heading tags.
     *
     * @param string $content        HTML content
     * @param string $target_url     URL to link to
     * @param string $target_title   Title of target article
     * @param string $target_keyword Keyword of target article
     * @return string|null Modified content or null
     */
    private static function insert_connector_link( $content, $target_url, $target_title, $target_keyword, $anchor_text = '' ) {
        // Use provided anchor, else fallback to keyword or title
        if ( empty( $anchor_text ) ) {
            $anchor_text = ! empty( $target_keyword ) ? $target_keyword : $target_title;
        }

        // Detect site language for connector phrases and hreflang
        $lang = self::get_site_lang_code();
        $hreflang = self::get_site_hreflang();

        // Build link HTML with hreflang attribute
        $link_html = sprintf(
            '<a href="%s" title="%s" hreflang="%s">%s</a>',
            esc_url( $target_url ),
            esc_attr( $target_title ),
            esc_attr( $hreflang ),
            esc_html( $anchor_text )
        );

        // Connector phrases per language (4 variants each)
        $phrases_by_lang = array(
            'fr' => array(
                'Pour approfondir ce sujet, consultez notre article sur %s.',
                'Retrouvez également notre analyse complète : %s.',
                'Ce thème est détaillé dans %s.',
                'Voir aussi : %s.',
            ),
            'en' => array(
                'For more details, see our article on %s.',
                'Learn more in our comprehensive guide: %s.',
                'This topic is covered in depth in %s.',
                'See also: %s.',
            ),
            'es' => array(
                'Para profundizar en este tema, consulte nuestro artículo sobre %s.',
                'Encuentre también nuestro análisis completo: %s.',
                'Este tema se detalla en %s.',
                'Vea también: %s.',
            ),
            'de' => array(
                'Mehr dazu erfahren Sie in unserem Artikel über %s.',
                'Lesen Sie auch unsere ausführliche Analyse: %s.',
                'Dieses Thema wird ausführlich behandelt in %s.',
                'Siehe auch: %s.',
            ),
            'it' => array(
                'Per approfondire questo argomento, consultate il nostro articolo su %s.',
                'Trovate anche la nostra analisi completa: %s.',
                'Questo tema è trattato in dettaglio in %s.',
                'Vedi anche: %s.',
            ),
            'pt' => array(
                'Para aprofundar este tema, consulte nosso artigo sobre %s.',
                'Confira também nossa análise completa: %s.',
                'Este tema é detalhado em %s.',
                'Veja também: %s.',
            ),
            'nl' => array(
                'Lees meer in ons artikel over %s.',
                'Bekijk ook onze uitgebreide analyse: %s.',
                'Dit onderwerp wordt uitgebreid behandeld in %s.',
                'Zie ook: %s.',
            ),
            'ja' => array(
                '%s に関する記事もご覧ください。',
                '詳細については %s をお読みください。',
                'こちらもご参照ください: %s。',
            ),
            'zh' => array(
                '有关此主题的更多信息，请参阅 %s。',
                '了解更多详情: %s。',
                '另请参阅: %s。',
            ),
            'ar' => array(
                'لمزيد من التفاصيل، اطلع على مقالنا حول %s.',
                'اقرأ أيضًا تحليلنا الشامل: %s.',
                'انظر أيضًا: %s.',
            ),
            'ru' => array(
                'Подробнее об этой теме в нашей статье: %s.',
                'Ознакомьтесь также с нашим анализом: %s.',
                'Смотрите также: %s.',
            ),
            'ko' => array(
                '이 주제에 대해 자세히 알아보세요: %s.',
                '관련 분석 보기: %s.',
                '참고: %s.',
            ),
            'pl' => array(
                'Więcej na ten temat w naszym artykule: %s.',
                'Sprawdź również naszą pełną analizę: %s.',
                'Zobacz także: %s.',
            ),
            'sv' => array(
                'Läs mer i vår artikel om %s.',
                'Se även vår fullständiga analys: %s.',
                'Se även: %s.',
            ),
            'tr' => array(
                'Bu konu hakkında daha fazla bilgi için makalemize bakın: %s.',
                'Kapsamlı analizimize de göz atın: %s.',
                'Ayrıca bakınız: %s.',
            ),
        );

        $phrases = $phrases_by_lang[ $lang ] ?? $phrases_by_lang['en'];
        // v19-BUG4: Deterministic phrase selection — prevents duplicates on cron re-run
        $phrase_idx = abs( crc32( $target_url ) ) % count( $phrases );
        $phrase = sprintf( $phrases[ $phrase_idx ], $link_html );

        // Find paragraphs
        if ( ! preg_match_all( '/<p[^>]*>(.*?)<\/p>/si', $content, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
            return null;
        }

        // Position of first H2 (intro protection)
        $first_h2_pos = stripos( $content, '<h2' );

        // Extract keyword words for scoring (>3 chars)
        $kw_words = array_filter( explode( ' ', mb_strtolower( $target_keyword ) ), function( $w ) {
            return mb_strlen( $w ) > 3;
        } );

        $best_match = null;
        $best_score = -1;

        foreach ( $matches as $match ) {
            $full_tag = $match[0][0];
            $inner    = $match[1][0];
            $offset   = $match[0][1];

            // Skip before first H2 (intro zone)
            if ( $first_h2_pos !== false && $offset < $first_h2_pos ) continue;

            // Skip headings embedded in containers
            if ( preg_match( '/<h[1-6]/i', $full_tag ) ) continue;

            // Skip paragraphs with too many links already (>2)
            if ( substr_count( mb_strtolower( $full_tag ), '<a ' ) > 2 ) continue;

            // Skip paragraphs already containing a connector phrase from a previous link
            // v19-BUG5: Also check data-hts-connector attribute for robust detection
            if ( strpos( $full_tag, 'data-hts-connector' ) !== false ) continue;
            if ( preg_match( '/(?:Voir aussi|Retrouvez également|Pour approfondir|Ce thème est détaillé|See also|Learn more|For more details|This topic is covered|Vea también|Siehe auch|Vedi anche|Veja também|Zie ook)\s*[:\.]/ui', $full_tag ) ) continue;

            // Skip very short paragraphs
            $visible = wp_strip_all_tags( $inner );
            if ( mb_strlen( trim( $visible ) ) < 30 ) continue;

            // Score by keyword relevance
            $p_lower = mb_strtolower( $visible );
            $score = 0;
            foreach ( $kw_words as $w ) {
                if ( mb_strpos( $p_lower, $w ) !== false ) $score++;
            }

            if ( $score > $best_score ) {
                $best_score = $score;
                $best_match = $match;
            }
        }

        // Fallback: 3rd-to-last paragraph after H2
        if ( ! $best_match ) {
            $after_h2 = array();
            foreach ( $matches as $m ) {
                if ( $first_h2_pos === false || $m[0][1] >= $first_h2_pos ) {
                    if ( preg_match( '/<h[1-6]/i', $m[0][0] ) ) continue;
                    if ( mb_strlen( trim( wp_strip_all_tags( $m[1][0] ) ) ) < 30 ) continue;
                    if ( strpos( $m[0][0], 'data-hts-connector' ) !== false ) continue;
                    if ( preg_match( '/(?:Voir aussi|Retrouvez également|Pour approfondir|Ce thème est détaillé|See also|Learn more|For more details|This topic is covered|Vea también|Siehe auch|Vedi anche|Veja também|Zie ook)\s*[:\.]/ui', $m[0][0] ) ) continue;
                    $after_h2[] = $m;
                }
            }
            $cnt = count( $after_h2 );
            if ( $cnt >= 3 ) {
                $best_match = $after_h2[ $cnt - 3 ];
            } elseif ( $cnt >= 1 ) {
                $best_match = $after_h2[ $cnt - 1 ];
            }
        }

        if ( ! $best_match ) return null;

        // Insert connector phrase before closing </p>
        $full_tag = $best_match[0][0];
        // v19-BUG5: Mark paragraph with data attribute for robust re-detection
        $new_tag  = str_replace( '<p', '<p data-hts-connector="1"', $full_tag );
        $new_tag  = str_replace( '</p>', ' ' . $phrase . '</p>', $new_tag );

        // Replace only the first occurrence of this exact paragraph
        $pos = strpos( $content, $full_tag );
        if ( $pos !== false ) {
            return substr_replace( $content, $new_tag, $pos, strlen( $full_tag ) );
        }

        return null;
    }

    /**
     * INBOUND: Insert links FROM existing published articles TO the new article.
     * Uses connector sentences for reliable placement.
     *
     * @return array { count, details[] }
     */
    private static function global_interlink_inbound( $new_post_id, $new_post, $new_keyword, $candidates, $openai_key, $link_config = array() ) {
        // Only link from published articles
        $published_candidates = array_filter( $candidates, function( $c ) {
            return $c['status'] === 'publish';
        } );
        $published_candidates = array_values( array_slice( $published_candidates, 0, 15 ) );

        if ( empty( $published_candidates ) ) {
            return array( 'count' => 0, 'details' => array() );
        }

        $new_url = get_permalink( $new_post_id );

        // Filter out candidates that already link to the new article
        $filtered = array();
        foreach ( $published_candidates as $c ) {
            $source_content = get_post( $c['id'] )->post_content ?? '';
            if ( mb_strpos( $source_content, $new_url ) !== false ) continue;
            $filtered[] = $c;
        }
        $published_candidates = array_slice( $filtered, 0, 12 );
        if ( empty( $published_candidates ) ) {
            return array( 'count' => 0, 'details' => array() );
        }

        // Format candidates for prompt
        $candidates_text = '';
        foreach ( $published_candidates as $c ) {
            $gsc_tag = '';
            if ( ( $c['gsc_clicks'] ?? 0 ) > 0 || ( $c['gsc_impressions'] ?? 0 ) > 0 ) {
                $gsc_parts = array();
                if ( $c['gsc_clicks'] > 0 ) $gsc_parts[] = $c['gsc_clicks'] . ' clics';
                if ( $c['gsc_impressions'] > 0 ) $gsc_parts[] = $c['gsc_impressions'] . ' impr';
                if ( $c['gsc_position'] > 0 ) $gsc_parts[] = 'pos ' . $c['gsc_position'];
                $gsc_tag = ' | ' . implode( ', ', $gsc_parts );
            }
            $candidates_text .= "- ID:{$c['id']} | \"{$c['title']}\" | KW: {$c['keyword']} | [{$c['origin']}]{$gsc_tag}\n";
        }

        $max_inbound = (int) ( $link_config['max_inbound'] ?? 5 );

        // ── PROMPT: pick sources + generate diverse anchor text ──
        $lang_name_in = self::get_lang_name_for_prompt();
        $prompt = "Tu es un consultant SEO senior. Choisis les articles existants qui devraient contenir un lien vers ce nouvel article, et génère une ancre optimisée pour chacun.
LANGUE DU SITE : {$lang_name_in} — les ancres DOIVENT être rédigées en {$lang_name_in}.

═══ NOUVEL ARTICLE (cible du lien) ═══
Titre : \"{$new_post->post_title}\"
Keyword : \"{$new_keyword}\"

═══ ARTICLES EXISTANTS (sources potentielles) ═══
{$candidates_text}

═══ RÈGLES DE SÉLECTION ═══
1. Choisis jusqu'à {$max_inbound} articles sources les plus pertinents.
2. PRIORITÉ : Même cocon d'abord, puis thématiquement proches, puis historique.
3. Le lien doit être cohérent pour un lecteur de l'article source.
4. PRIORITÉ GSC : Favorise les articles avec beaucoup de clics comme sources (transfert d'autorité).

═══ RÈGLES ANCRE (CRITIQUE) ═══
L'ancre est le texte cliquable du lien vers le nouvel article. Elle doit :
- Faire 3 à 7 mots, descriptive et naturelle dans la langue du site
- Décrire ce que le lecteur va trouver sur le nouvel article
- VARIER entre les différentes sources : chaque ancre doit être DIFFÉRENTE
- Utiliser des variations sémantiques du keyword \"{$new_keyword}\", pas l'exact match
  Exemple pour KW \"flexibilité cognitive\" → ancres possibles : \"la souplesse mentale sous psilocybine\", \"assouplir les schémas de pensée\", \"comment regagner en flexibilité psychologique\"
- INTERDIT : ancre = keyword exact, ancre = titre exact, ancre générique (\"cliquez ici\")

═══ FORMAT JSON strict ═══
[{\"source_id\":456,\"anchor\":\"variation sémantique naturelle\",\"relevance_score\":80,\"reason\":\"Explication courte\"}]
Si aucun lien pertinent → []";

        $result = self::cross_interlink_openai_call( $openai_key, $prompt );
        if ( empty( $result ) || ! is_array( $result ) ) {
            return array( 'count' => 0, 'details' => array() );
        }

        $applied = array();
        $candidate_map = array_column( $published_candidates, null, 'id' );

        foreach ( $result as $s ) {
            $source_id = absint( $s['source_id'] ?? 0 );
            $score     = (int) ( $s['relevance_score'] ?? 0 );
            $ai_anchor = trim( $s['anchor'] ?? '' );

            if ( ! $source_id || $score < 60 ) continue;
            if ( ! isset( $candidate_map[ $source_id ] ) ) continue;

            $source_post = get_post( $source_id );
            if ( ! $source_post ) continue;

            $content = $source_post->post_content;

            // Double-check: skip if already links to new article
            if ( mb_strpos( $content, $new_url ) !== false ) continue;

            // Use AI anchor if valid, else fallback to keyword
            $anchor_text = '';
            if ( ! empty( $ai_anchor ) && mb_strlen( $ai_anchor ) >= 5 && mb_strlen( $ai_anchor ) <= 80 ) {
                $anchor_text = $ai_anchor;
            } else {
                $anchor_text = ! empty( $new_keyword ) ? $new_keyword : $new_post->post_title;
            }

            // ── Insert via connector sentence ──
            $new_content = self::insert_connector_link(
                $content,
                $new_url,
                $new_post->post_title,
                $new_keyword,
                $anchor_text
            );

            if ( $new_content && $new_content !== $content ) {
                $content_before_inbound = $content;

                // Sprint 6.2d: clean internal link attributes before save
                $new_content = self::fix_internal_link_attrs( $new_content );
                wp_update_post( array( 'ID' => $source_id, 'post_content' => $new_content ) );

                // Sprint 6.2d: sync outbound link counter on source page
                if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                    \HTS_Workflow_Engine::recount_internal_links( $source_id );
                }

                if ( class_exists( 'HTS_Audit_Trail' ) ) {
                    HTS_Audit_Trail::log_link( $source_id, $new_post_id, $anchor_text, 'inbound', $content_before_inbound, $new_content, HTS_Audit_Trail::get_gsc_snapshot( $source_id ) );
                }

                $existing_out = (int) get_post_meta( $source_id, '_hts_cross_links_out', true );
                update_post_meta( $source_id, '_hts_cross_links_out', $existing_out + 1 );

                $applied[] = array(
                    'source_id'    => $source_id,
                    'source_title' => $source_post->post_title,
                    'anchor'       => $anchor_text,
                    'origin'       => $candidate_map[ $source_id ]['origin'],
                );

                self::cocon_log( 'interlink_inbound_ok', '✅ Lien entrant inséré', array(
                    'source' => $source_post->post_title, 'anchor' => $anchor_text,
                ) );
            } else {
                self::cocon_log( 'interlink_inbound_skip', '⏭️ Pas de paragraphe adapté pour lien entrant', array(
                    'source' => $source_post->post_title,
                ) );
            }

            if ( count( $applied ) >= $max_inbound ) break;
        }

        return array( 'count' => count( $applied ), 'details' => $applied );
    }


    /**
     * Get primary language code (2-letter) from WordPress locale.
     * e.g. fr_FR → fr, en_US → en, de_DE → de, es_ES → es
     */
    private static function get_site_lang_code() {
        $locale = get_locale(); // e.g. fr_FR, en_US, de_DE
        $lang = strtolower( substr( $locale, 0, 2 ) );
        // Supported languages for connector phrases
        $supported = array( 'fr', 'en', 'es', 'de', 'it', 'pt', 'nl', 'ja', 'zh', 'ar', 'ru', 'ko', 'pl', 'sv', 'tr' );
        return in_array( $lang, $supported, true ) ? $lang : 'en';
    }

    /**
     * Get hreflang code from WordPress locale.
     * e.g. fr_FR → fr-FR, en_US → en-US, fr_BE → fr-BE
     */
    private static function get_site_hreflang() {
        $locale = get_locale();
        return str_replace( '_', '-', $locale ); // fr_FR → fr-FR
    }

    /**
     * Get language name for OpenAI prompts.
     */
    private static function get_lang_name_for_prompt() {
        $names = array(
            'fr' => 'français', 'en' => 'English', 'es' => 'español',
            'de' => 'Deutsch', 'it' => 'italiano', 'pt' => 'português', 'nl' => 'Nederlands',
        );
        $lang = self::get_site_lang_code();
        return $names[ $lang ] ?? 'English';
    }

    /**
     * OpenAI call helper for global interlinking
     */
    private static function cross_interlink_openai_call( $api_key, $prompt ) {
        // ── Check monthly token budget ──
        $monthly_limit = (int) get_option( 'hts_openai_monthly_limit', 1000000 );
        $usage = get_option( 'hts_openai_usage', array() );
        $month_key = date( 'Y-m' );
        $current_usage = (int) ( $usage[ $month_key ] ?? 0 );
        if ( $monthly_limit > 0 && $current_usage >= $monthly_limit ) {
            self::cocon_log( 'interlink_budget', '⏭️ Budget OpenAI mensuel épuisé', array(
                'usage' => $current_usage,
                'limit' => $monthly_limit,
            ) );
            return array(); // Budget exhausted — skip silently
        }

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'model'       => 'gpt-4o-mini',
                'messages'    => array(
                    array( 'role' => 'system', 'content' => 'Tu réponds UNIQUEMENT en JSON valide, sans markdown, sans backticks, sans commentaire.' ),
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'temperature' => 0.2,
                'max_tokens'  => 1500,
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            self::cocon_log( 'interlink_openai_error', '❌ Erreur réseau OpenAI', array(
                'error' => $response->get_error_message(),
            ) );
            return array();
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( $code !== 200 ) {
            self::cocon_log( 'interlink_openai_error', '❌ OpenAI HTTP ' . $code, array(
                'error' => $data['error']['message'] ?? mb_substr( $body, 0, 200 ),
            ) );
            return array();
        }

        // Track token usage
        $tokens_used = (int) ( $data['usage']['total_tokens'] ?? 0 );
        if ( $tokens_used > 0 ) {
            $usage[ $month_key ] = $current_usage + $tokens_used;
            $keep = array( $month_key, date( 'Y-m', strtotime( '-1 month' ) ), date( 'Y-m', strtotime( '-2 months' ) ) );
            $usage = array_intersect_key( $usage, array_flip( $keep ) );
            update_option( 'hts_openai_usage', $usage, false );
        }

        $text = $data['choices'][0]['message']['content'] ?? '';
        $text = trim( $text );
        $text = preg_replace( '/^```json\s*/', '', $text );
        $text = preg_replace( '/\s*```$/', '', $text );

        $result = json_decode( $text, true );
        return is_array( $result ) ? $result : array();
    }

    /* ═══════════════════════════════════════════════════════════
     *  DALL-E IMAGE GENERATION (v2.7.1)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Generate AI images for article and set featured image
     *
     * Pipeline:
     * 1. OpenAI analyzes article → identifies 1 image opportunity (featured)
     * 2. DALL-E generates the image
     * 3. Image downloaded to WP media library
     * 4. Set as featured image (_thumbnail_id)
     *
     * @param int    $post_id    WordPress post ID
     * @param string $title      Article title
     * @param string $keyword    Target keyword
     * @param string $content    Article HTML content
     * @return array { count, images[] }
     */
    public static function cocon_generate_article_images( $post_id, $title, $keyword, $content ) {
        $openai_key = hts_get_openai_key();
        $img_cfg    = self::get_image_settings();
        $source     = $img_cfg['featured_source'] ?? 'ai';

        // ── Pexels featured image (modes: 'pexels' or 'both') ──
        $pexels_result = array( 'count' => 0, 'images' => array() );
        if ( in_array( $source, array( 'pexels', 'both' ), true ) && $img_cfg['featured_enabled'] ) {
            $pexels_result = self::cocon_pexels_featured_image( $post_id, $keyword, $title, $content );
        }

        // If source is 'pexels' only (no AI at all), return just Pexels result
        if ( $source === 'pexels' ) {
            return array(
                'count'   => $pexels_result['count'],
                'images'  => $pexels_result['images'],
                'content' => $content,
            );
        }

        // ── AI images (modes: 'ai' or 'both') ──
        $provider = $img_cfg['image_provider'] ?? 'openai';

        // Guard: need at least one API key for the chosen provider
        if ( $provider === 'flux' ) {
            $flux_key = $img_cfg['flux_api_key'] ?? '';
            if ( empty( $flux_key ) ) {
                self::cocon_log( 'image_error', 'Provider Flux sélectionné mais clé API BFL manquante' );
                // Fallback: if we have a Pexels result, return it
                return array(
                    'count'   => $pexels_result['count'],
                    'images'  => $pexels_result['images'],
                    'content' => $content,
                );
            }
        } else {
            // OpenAI provider — need OpenAI key
            if ( empty( $openai_key ) ) {
                return array(
                    'count'   => $pexels_result['count'],
                    'images'  => $pexels_result['images'],
                    'content' => $content,
                );
            }
        }

        $brand   = self::get_brand_identity();

        // In 'both' mode, skip AI featured (Pexels already handled it)
        $ai_do_featured = ( $source === 'ai' ) && $img_cfg['featured_enabled'];

        // ── Cron re-run protection: skip featured if post already has a thumbnail ──
        if ( $ai_do_featured && has_post_thumbnail( $post_id ) ) {
            $ai_do_featured = false;
            self::cocon_log( 'image_generating', 'Featured déjà existante — skip (cron re-run ?)', array( 'post_id' => $post_id ) );
        }

        // If AI featured disabled AND in-content disabled, return Pexels only
        if ( ! $ai_do_featured && ! $img_cfg['incontent_enabled'] ) {
            return array(
                'count'   => $pexels_result['count'],
                'images'  => $pexels_result['images'],
                'content' => $content,
            );
        }

        $brand_name = $brand['brand_name'] ?? get_bloginfo( 'name' );

        // ── Site context for prompts (Best practice: ground the visual in the site's domain) ──
        // Flux/DALL-E produce better results when they understand the website's field/niche.
        $site_description = get_bloginfo( 'description' );
        $site_context = '';
        if ( ! empty( $site_description ) ) {
            $site_context = 'Website: ' . $brand_name . ' — ' . mb_substr( $site_description, 0, 80 ) . '. ';
        } elseif ( ! empty( $brand_name ) ) {
            // Infer niche from top categories
            $top_cats = get_categories( array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 3, 'hide_empty' => true ) );
            $cat_names = array_map( function( $c ) { return $c->name; }, $top_cats );
            $site_context = 'Website: ' . $brand_name;
            if ( ! empty( $cat_names ) ) {
                $site_context .= ' (topics: ' . implode( ', ', $cat_names ) . ')';
            }
            $site_context .= '. ';
        }

        // ── Brand color palette for consistent visuals ──
        // BP-3: BFL best practice — always associate hex codes with specific visual elements.
        // "The car is #FF0000" works better than "use red #FF0000 in the image."
        $color_palette = sprintf(
            'Main elements in color %s, background accents in %s, highlights in %s.',
            $brand['primary_color'], $brand['secondary_color'], $brand['accent_color']
        );

        // ── Style definitions ──
        // BFL Best Practice: Subject → Action → Style → Context. Front-load the subject.
        // Style is a MODIFIER, not the main prompt. Keep style descriptions concise (15-20 words).
        // CRITICAL: Flux generates text by default. Every style must include explicit no-text.
        // NOTE: Keys MUST match allowed_types in ajax_save_image_settings() + type_patterns below.
        $style_prompts = array(
            'illustration'    => 'Modern editorial illustration, flat design with subtle gradients, bold shapes and clean lines.',
            'photo_realistic' => 'Professional editorial photograph, 50mm f/2.8 lens, shallow depth of field, natural soft lighting.',
            '3d_render'       => 'Polished 3D render, soft global illumination, matte and glass materials, contact shadows, neutral backdrop.',
            'watercolor'      => 'Refined watercolor painting, luminous wet-on-wet washes, crisp focal details, organic paper texture.',
            'minimalist'      => 'Ultra-clean minimalist design, precise geometry, generous negative space, two-to-three color scheme.',
            'isometric'       => 'Polished isometric 3D illustration, soft pastel tones, subtle drop shadows, flat background.',
            'infographic'     => 'Professional data infographic with comparison table, side-by-side columns, icons paired with key metrics, color-coded categories, structured grid layout with clear visual hierarchy. Clean modern SaaS style.',
            'schema_diagram'  => 'Clear labeled diagram with readable text on each node, directional arrows showing relationships, structured top-to-bottom or left-to-right flow, professional clean style.',
        );

        // BP-5: Specific camera setups for photo_realistic — BFL docs: "Shot on Fujifilm X-T5, 35mm f/1.4
        // produces more authentic results than just 'professional photo'."
        $camera_setups = array(
            'Shot on Sony A7IV, 50mm f/2.8, natural soft lighting, high dynamic range.',
            'Shot on Canon 5D Mark IV, 35mm f/1.4, golden hour, shallow depth of field.',
            'Shot on Fujifilm X-T5, 23mm f/2, clean sharp detail, soft diffused light.',
            'Shot on Hasselblad X2D, 80mm f/2.8, studio lighting, medium format detail.',
            'Shot on Nikon Z9, 85mm f/1.8, warm afternoon light, creamy bokeh.',
        );

        // Cycle rotatif pour le mode 'mixed' — variété maximale entre les images d'un même article
        // SEO 2026: infographic et isometric sont les plus utiles pour la citabilité (GEO)
        $mixed_cycle = array( 'infographic', 'illustration', 'isometric', 'infographic', 'photo_realistic', 'minimalist' );

        $featured_style      = $img_cfg['featured_style'];
        $featured_style_desc = $style_prompts[ $featured_style ] ?? $style_prompts['illustration'];
        // BP-5: Use rotating camera setup for photo_realistic featured images
        if ( $featured_style === 'photo_realistic' ) {
            $featured_style_desc = $camera_setups[ $post_id % count( $camera_setups ) ];
        }
        $extra_instructions  = ! empty( $img_cfg['extra_instructions'] ) ? ' ' . $img_cfg['extra_instructions'] : '';

        // BP-1: Flux does NOT support negative prompts — mentioning "no text" can CAUSE text to appear.
        // BFL docs: "Focus on describing what you want, not what you don't want."
        // Use positive formulations only.
        $clean_image_suffix = ' Clean visual composition, sharp focus throughout, pure imagery without any typography or watermarks.';
        // Legacy alias kept for fallback prompt compatibility
        $no_text_suffix = $clean_image_suffix;

        // ── Build article context for prompts ──
        // Best practice: give the model the article's core idea so it can infer accurate visuals.
        // Structure: topic → audience takeaway → key concepts
        $meta_desc_for_img = get_post_meta( $post_id, '_hts_meta_description', true );
        if ( empty( $meta_desc_for_img ) ) {
            // Fallback: first 30 words of content
            $meta_desc_for_img = implode( ' ', array_slice( explode( ' ', wp_strip_all_tags( $content ) ), 0, 30 ) );
        }
        // Truncate meta to ~60 words max (Flux prompt sweet spot: 50-80 words total)
        $meta_desc_for_img = implode( ' ', array_slice( explode( ' ', $meta_desc_for_img ), 0, 25 ) );

        // Extract H2 headings + section content
        preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $content, $h2_matches );
        $h2_texts = ! empty( $h2_matches[1] ) ? array_map( 'wp_strip_all_tags', $h2_matches[1] ) : array();

        // Section content for in-content images (first 40 words per section — concise)
        $h2_section_contents = array();
        if ( ! empty( $h2_matches[0] ) ) {
            foreach ( $h2_texts as $idx => $h2_title ) {
                $pattern = preg_quote( $h2_matches[0][ $idx ], '/' );
                $parts   = preg_split( '/' . $pattern . '/si', $content, 2 );
                if ( isset( $parts[1] ) ) {
                    $section_html = preg_split( '/<h2[^>]*>/si', $parts[1], 2 );
                    $section_text = wp_strip_all_tags( $section_html[0] ?? '' );
                    $words = array_slice( explode( ' ', trim( $section_text ) ), 0, 80 );
                    $h2_section_contents[ $idx ] = implode( ' ', $words );
                }
            }
        }

        // ── Determine image counts ──
        $do_featured   = $ai_do_featured;
        $num_incontent = 0;

        $skip_patterns = array( 'faq', 'synthèse', 'synthese', 'conclusion', 'résumé', 'resume', 'points à retenir', 'récapitulatif' );
        $body_h2_indices = array();
        foreach ( $h2_texts as $idx => $h2 ) {
            $h2_lower = mb_strtolower( $h2 );
            $skip = false;
            foreach ( $skip_patterns as $pat ) {
                if ( mb_strpos( $h2_lower, $pat ) !== false ) { $skip = true; break; }
            }
            if ( ! $skip ) $body_h2_indices[] = $idx;
        }

        if ( $img_cfg['incontent_enabled'] ) {
            $num_incontent = min( (int) $img_cfg['incontent_count'], max( 0, count( $body_h2_indices ) - 1 ) );
        }

        // ── Cron re-run protection: skip in-content if images already inserted ──
        if ( $num_incontent > 0 && strpos( $content, 'hts-incontent-image' ) !== false ) {
            preg_match_all( '/class="[^"]*hts-incontent-image/', $content, $existing_imgs );
            $already_count = count( $existing_imgs[0] );
            if ( $already_count >= $num_incontent ) {
                $num_incontent = 0;
                self::cocon_log( 'image_generating', $already_count . ' image(s) in-content déjà présente(s) — skip', array( 'post_id' => $post_id ) );
            } else {
                $num_incontent = $num_incontent - $already_count;
            }
        }
        $total_images = ( $do_featured ? 1 : 0 ) + $num_incontent;

        if ( $total_images === 0 ) {
            return array( 'count' => 0, 'images' => array(), 'content' => $content );
        }

        // ── Select which H2s get in-content images ──
        $selected_h2_indices = array();
        if ( $num_incontent > 0 ) {
            $eligible = array_slice( $body_h2_indices, 1 );
            if ( count( $eligible ) > $num_incontent ) {
                $step = max( 1, floor( count( $eligible ) / $num_incontent ) );
                for ( $i = 0; $i < count( $eligible ) && count( $selected_h2_indices ) < $num_incontent; $i += $step ) {
                    $selected_h2_indices[] = $eligible[ $i ];
                }
            } else {
                $selected_h2_indices = array_slice( $eligible, 0, $num_incontent );
            }
        }

        // ── Composition rotation (Cookbook: specify framing, viewpoint, lighting) ──
        $compositions = array(
            'medium shot, eye-level, warm natural lighting, shallow depth of field',
            'overhead flat-lay view, cool even lighting, organized layout',
            'close-up detail shot, dramatic side lighting, high contrast',
            'wide shot with context, soft diffused light, atmospheric depth',
            'three-quarter angle, golden hour warmth, gentle bokeh background',
        );

        // ── Build image specs (Cookbook: concise 50-70 words, structured, concrete) ──
        $image_specs = array();
        $is_first_incontent = true; // IMG-11: first in-content gets keyword in alt, others get brand

        if ( $do_featured ) {
            // Featured text overlay
            $overlay_text = '';
            if ( $img_cfg['featured_text_overlay'] === 'title' ) {
                $overlay_text = " Include the text \"{$title}\" elegantly integrated.";
            } elseif ( $img_cfg['featured_text_overlay'] === 'keyword' ) {
                $overlay_text = " Include the text \"{$keyword}\" elegantly integrated.";
            } elseif ( $img_cfg['featured_text_overlay'] === 'brand' ) {
                $overlay_text = " Include \"{$brand_name}\" as a subtle watermark.";
            }
            $no_text_feat = ( $img_cfg['featured_text_overlay'] === 'none' ) ? $no_text_suffix : '';

            // ── Featured prompt structure (Best practice for Flux/DALL-E): ──
            // 1. Medium/style (most important — sets the visual language)
            // 2. Subject (what to depict — grounded in article topic)
            // 3. Scene details (composition, lighting, mood)
            // 4. Context (site niche helps model choose appropriate imagery)
            // 5. Constraints (no text, format)
            $image_specs[] = array(
                'type'     => 'featured',
                'prompt'   => "\"{$keyword}\". "
                    . "{$site_context}"
                    . "Style: {$featured_style_desc} "
                    . "{$compositions[ $post_id % count( $compositions ) ]}. Landscape 16:9 format. "
                    . "{$color_palette} "
                    . "Object-focused composition, depopulated scene."
                    . $overlay_text . $no_text_feat . $extra_instructions,
                'alt_text'   => mb_substr( $keyword . ' — ' . $title, 0, 120 ),
                'img_title'  => mb_substr( $title, 0, 55 ),
                'caption'    => mb_substr( $keyword . ' — ' . str_replace( '_', ' ', $featured_style ), 0, 80 ),
                'image_type' => $featured_style,
            );
        }

        foreach ( $selected_h2_indices as $img_idx => $h2_idx ) {
            $h2_text     = $h2_texts[ $h2_idx ] ?? '';
            $section_ctx = $h2_section_contents[ $h2_idx ] ?? '';
            $composition = $compositions[ ( $img_idx + 1 ) % count( $compositions ) ];

            // ── Adaptive image type selection ──
            // Priority: 1) type_patterns keyword match  2) user config  3) mixed cycle
            $incontent_types_cfg = $img_cfg['incontent_types'] ?? 'mixed';

            // Determine user's preferred default (used when no pattern matches)
            $user_default = null;
            if ( is_string( $incontent_types_cfg ) && $incontent_types_cfg !== 'mixed' ) {
                $user_default = $incontent_types_cfg; // e.g. 'infographic', 'photo_realistic'
            } elseif ( is_array( $incontent_types_cfg ) && ! empty( $incontent_types_cfg ) ) {
                $user_default = $incontent_types_cfg[ $img_idx % count( $incontent_types_cfg ) ];
            }
            // mixed mode or no valid config → cycle through styles for variety
            if ( $user_default === null ) {
                $user_default = $mixed_cycle[ $img_idx % count( $mixed_cycle ) ];
            }

            // Adaptive: analyze H2 + section to pick best style (overrides default if match found)
            $img_type = $user_default;
            $h2_lower = mb_strtolower( $h2_text . ' ' . mb_substr( $section_ctx, 0, 200 ) );

            $type_patterns = array(
                // infographic: comparisons, rankings, data, specs — most useful for SEO articles
                'infographic'     => array( 'versus', ' vs ', 'statistique', 'classement', 'tableau comparatif', 'chiffre', 'donnée', 'pourcentage', 'proportion', 'top ', 'meilleur', 'notation', 'score', 'dépist', 'inventaire', 'comparaison', 'comparer', 'avantage', 'inconvénient', 'prix', 'tarif', 'coût', 'budget', 'alternative', 'différence', 'caractéristique', 'critère', 'grille', 'benchmark', 'performance', 'résultat', 'taux', 'mesure', 'indicateur', 'kpi', 'retour sur', 'roi ', 'rendement', 'analyse comparative' ),
                'photo_realistic' => array( 'témoignage', 'expérience vécue', 'cas réel', 'cas concret', 'exemple concret', 'en pratique', 'sur le terrain', 'quotidien', 'visite', 'reportage', 'entretien', 'interview' ),
                '3d_render'       => array( 'anatomie', 'structure', 'molécule', 'cellule', 'organe', 'dispositif', 'composant', 'architecture', 'maquette', 'prototype', 'modèle 3d', 'coupe', 'section' ),
                'minimalist'      => array( 'définition de', 'concept clé', 'principe fondamental', 'essentiel', 'en bref', 'résumé', 'introduction à', 'comprendre', 'qu\'est-ce que' ),
                'isometric'       => array( 'écosystème', 'système', 'infrastructure', 'plateforme', 'outil', 'technologie', 'logiciel', 'réseau', 'circuit', 'pipeline', 'flux de', 'processus', 'workflow', 'étape', 'fonctionnement' ),
                'illustration'    => array( 'bienfait', 'bénéfice', 'vertu', 'propriété', 'histoire', 'origine', 'tradition', 'culture', 'philosophie', 'vision', 'valeur' ),
                'watercolor'      => array( 'émotion', 'ressenti', 'bien-être', 'relaxation', 'méditation', 'spirituel', 'nature', 'paysage', 'saison', 'ambiance' ),
            );

            foreach ( $type_patterns as $candidate_type => $patterns ) {
                // Respect user config: skip types not in the allowed list
                if ( is_array( $incontent_types_cfg ) && ! in_array( $candidate_type, $incontent_types_cfg, true ) ) {
                    continue;
                }
                foreach ( $patterns as $pat ) {
                    if ( mb_strpos( $h2_lower, $pat ) !== false ) {
                        $img_type = $candidate_type;
                        break 2;
                    }
                }
            }

            // -- v19: Detection DIAGRAMME + fleches dans le contenu --
            // Le redacteur/IA ecrit "DIAGRAMME : X -> Y -> Z" dans le texte.
            // On detecte ce pattern et on genere un HTML inline a la place d'une image.
            // v19-BUG7: Use extended section text (200 words) for detection — 80-word cap missed patterns
            if ( $img_type !== 'schema_diagram' ) {
                $section_check = '';
                if ( ! empty( $h2_texts[ $h2_idx ] ) && ! empty( $h2_matches[0][ $h2_idx ] ) ) {
                    $pat_detect = preg_quote( $h2_matches[0][ $h2_idx ], '/' );
                    $parts_det  = preg_split( '/' . $pat_detect . '/si', $content, 2 );
                    if ( isset( $parts_det[1] ) ) {
                        $sec_det = preg_split( '/<h2[^>]*>/si', $parts_det[1], 2 );
                        $section_check = implode( ' ', array_slice(
                            explode( ' ', wp_strip_all_tags( $sec_det[0] ?? '' ) ), 0, 200
                        ) );
                    }
                }
                // Fallback to $section_ctx if extraction failed
                if ( empty( $section_check ) ) {
                    $section_check = $section_ctx;
                }
                if ( ! empty( $section_check ) ) {
                    // v19-BUG8: Fix duplicate arrow unicode in regex
                    if ( preg_match( '/diagramme/i', $section_check ) && preg_match_all( '/\x{2192}|->/u', $section_check, $_arrows ) >= 2 ) {
                        $schema_ok = ! is_array( $incontent_types_cfg ) || in_array( 'schema_diagram', $incontent_types_cfg, true );
                        if ( $schema_ok && ! empty( hts_get_openai_key() ) ) {
                            self::cocon_log( 'image_routing', 'DIAGRAMME detecte dans contenu -> schema_diagram HTML', array(
                                'h2'     => $h2_text,
                                'arrows' => count( $_arrows[0] ),
                            ) );
                            $img_type = 'schema_diagram';
                        }
                    }
                }
            }

            $type_style = $style_prompts[ $img_type ] ?? $style_prompts['illustration'];

            // BP-5: Rotate camera setups for photo_realistic to avoid same rendering every time.
            if ( $img_type === 'photo_realistic' ) {
                $type_style = $camera_setups[ $img_idx % count( $camera_setups ) ];
            }

            // ── Build prompt: BFL Best Practice = Subject first → Context → Style last ──
            $section_for_prompt = '';
            if ( ! empty( $section_ctx ) ) {
                // Infographic/schema: concepts_hint handles context, raw text dilutes prompt
                if ( ! in_array( $img_type, array( 'infographic', 'schema_diagram' ), true ) ) {
                    $word_limit = 30;
                    $section_words = array_slice( explode( ' ', $section_ctx ), 0, $word_limit );
                    $section_for_prompt = implode( ' ', $section_words );
                }
            }

            // ── Contextual prompt enrichment for infographic/schema types ──
            $visual_structure_hint = '';
            $concepts_hint = '';
            if ( in_array( $img_type, array( 'infographic', 'schema_diagram' ), true ) ) {
                // Detect visual structure from section content
                $detect_text = $h2_lower . ' ' . mb_strtolower( $section_for_prompt . ' ' . ( $section_ctx ?? '' ) );
                if ( preg_match( '/(\d+)\s*(étape|step|phase|point)/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: numbered step-by-step process flow. ';
                } elseif ( preg_match( '/vs\.?|versus|compar|contre|différence/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: side-by-side comparison with two distinct columns. ';
                } elseif ( preg_match( '/\d+\s*%|pourcentage|proportion|ratio/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: proportional chart or pie segments. ';
                } elseif ( preg_match( '/avantage|inconvénient|pro|contra|pour|contre/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: pros and cons balance or split layout. ';
                } elseif ( preg_match( '/cycle|boucle|récurrent|répét/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: circular cycle diagram. ';
                } elseif ( preg_match( '/hiérarch|niveau|catégor|class/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: hierarchical tree or pyramid. ';
                } elseif ( preg_match( '/symptôme|signe|signal|indicateur|critère|dépist/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: checklist or screening list with checkmarks. ';
                } elseif ( preg_match( '/type|catégorie|forme|variété|sorte/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: categorized grid or card layout. ';
                } elseif ( preg_match( '/cause|conséquence|effet|impact|résultat|facteur/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: cause-and-effect chain or flow diagram. ';
                } elseif ( preg_match( '/risque|danger|précaution|attention|vigilance|contre-indication/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: warning or risk assessment layout. ';
                } elseif ( preg_match( '/conseil|recommandation|astuce|bonne pratique|règle/iu', $detect_text ) ) {
                    $visual_structure_hint = 'Visual structure: numbered tips or best practices list. ';
                } else {
                    $visual_structure_hint = 'Visual structure: organized summary with labeled key points. ';
                }

                // ── Extract concrete visual concepts from section (2-level) ──
                $key_concepts = array();

                // Level 1: Enumerated terms after "notamment", "inclut", "comme", etc.
                preg_match_all( '/(?:notamment|inclut?|comme|tels? que|par exemple|c[\x{2019}\']est-à-dire)\s+(?:des?\s+|les?\s+|la\s+|l[\x{2019}\'])?(.{5,60}?)(?:[,;\.]|$)/ui', $section_ctx, $enum_matches );
                if ( ! empty( $enum_matches[1] ) ) {
                    foreach ( $enum_matches[1] as $raw_term ) {
                        // Split on comma/ou/et to get individual items
                        $sub_terms = preg_split( '/\s*(?:,|(?:\s+ou\s+)|(?:\s+et\s+))\s*/u', $raw_term );
                        foreach ( $sub_terms as $st ) {
                            $st = trim( preg_replace( '/^(?:des?\s+|les?\s+|la\s+|le\s+|un[e]?\s+|l[\x{2019}\'])/ui', '', trim( $st ) ) );
                            if ( mb_strlen( $st ) >= 4 && count( $key_concepts ) < 5 ) {
                                $key_concepts[] = mb_strtolower( $st );
                            }
                        }
                    }
                    $key_concepts = array_unique( $key_concepts );
                }

                // Level 2: Noun phrases with determiners (filtered with stopwords)
                if ( count( $key_concepts ) < 3 ) {
                    preg_match_all( '/(?:le|la|les|l[\x{2019}\']|un|une|des|du|au)\s+(\w{5,}(?:\s+\w{4,}){0,2})/ui', $section_ctx, $noun_matches );
                    if ( ! empty( $noun_matches[1] ) ) {
                        $stopwords = array( 'cette', 'celui', 'entre', 'avoir', 'faire', 'aussi', 'après', 'avant', 'autre', 'leurs', 'notre', 'votre', 'comme', 'encore', 'depuis', 'pendant', 'toujours', 'parfois', 'moment', 'place', 'première', 'partir', 'travers', 'ensemble', 'manière', 'façon', 'niveau', 'mesure', 'personne', 'chose' );
                        $filtered = array_filter( $noun_matches[1], function( $w ) use ( $stopwords, $key_concepts ) {
                            $lower = mb_strtolower( trim( $w ) );
                            return ! in_array( $lower, $stopwords, true ) && ! in_array( $lower, $key_concepts, true );
                        });
                        foreach ( array_values( $filtered ) as $f ) {
                            if ( count( $key_concepts ) < 5 ) {
                                $key_concepts[] = mb_strtolower( trim( $f ) );
                            }
                        }
                        $key_concepts = array_unique( $key_concepts );
                    }
                }

                $key_concepts = array_slice( $key_concepts, 0, 5 );
                $concepts_hint = ! empty( $key_concepts )
                    ? 'Key elements to label on the visual: ' . implode( ', ', $key_concepts ) . '. '
                    : '';
            }

            // ── IMG-23: Compositions conditionnelles par famille de type ──
            $is_data_type = in_array( $img_type, array( 'infographic', 'schema_diagram', 'minimalist', 'isometric' ), true );
            if ( $is_data_type ) {
                $data_compositions = array(
                    'clean white background, structured grid layout, professional presentation',
                    'light neutral background, centered composition, balanced spacing',
                    'subtle gradient background, organized sections, clear visual hierarchy',
                    'minimal background, generous whitespace, focused central element',
                );
                $composition = $data_compositions[ ( $img_idx + 1 ) % count( $data_compositions ) ];
            }

            // ── IMG-24: Palette réduite pour infographies ──
            $color_hint = in_array( $img_type, array( 'infographic', 'schema_diagram' ), true )
                ? sprintf( 'Accent color: %s. Use neutral tones for readability.', $brand['accent_color'] )
                : $color_palette;

            // ── IMG-25: Caption préfixée par type de visuel ──
            $type_labels = array(
                'infographic'     => 'Infographie',
                'schema_diagram'  => 'Schéma',
                'photo_realistic' => 'Illustration',
                'illustration'    => 'Illustration',
                '3d_render'       => 'Vue 3D',
                'watercolor'      => 'Illustration',
                'minimalist'      => 'Résumé visuel',
                'isometric'       => 'Vue schématique',
            );
            $type_label = $type_labels[ $img_type ] ?? 'Illustration';

            // ── IMP-7: Langue des labels ──
            $lang_code = get_locale();
            $lang_prefix = strtolower( substr( $lang_code, 0, 2 ) );
            $lang_names = array( 'fr' => 'French', 'en' => 'English', 'es' => 'Spanish', 'de' => 'German', 'it' => 'Italian', 'pt' => 'Portuguese', 'nl' => 'Dutch', 'ja' => 'Japanese', 'zh' => 'Chinese', 'ar' => 'Arabic', 'ru' => 'Russian', 'ko' => 'Korean', 'pl' => 'Polish', 'sv' => 'Swedish', 'tr' => 'Turkish' );
            $lang_name = $lang_names[ $lang_prefix ] ?? 'English';

            $image_specs[] = array(
                'type'       => 'incontent',
                'h2_target'  => $h2_text,
                'prompt'     => ( in_array( $img_type, array( 'infographic', 'schema_diagram' ), true )
                    // ── BP-2: JSON-structured prompt for infographic/schema (BFL best practice) ──
                    ? self::build_json_infographic_prompt(
                        $img_type, $h2_text, $keyword, $key_concepts,
                        $visual_structure_hint, $brand, $lang_name, $extra_instructions
                    )
                    // ── BP-6: Subject-first prompt for other types, BP-1: positive formulations ──
                    : "\"{$h2_text}\", topic: {$keyword}. "
                        . ( ! empty( $section_for_prompt ) ? "Context: {$section_for_prompt}. " : '' )
                        . "Style: {$type_style} "
                        . "{$composition}. "
                        . "{$color_hint} "
                        . "Object-focused composition, depopulated scene."
                        . $clean_image_suffix . $extra_instructions
                        // BP-8: Cultural context for photo_realistic in non-English locales
                        . ( $img_type === 'photo_realistic' && $lang_prefix !== 'en' ? ' ' . $lang_name . ' cultural context.' : '' )
                ),
                'alt_text'   => $is_first_incontent
                    ? mb_substr( $keyword . ' — ' . $h2_text, 0, 120 )
                    : mb_substr( $h2_text . ' | ' . $brand_name, 0, 120 ),
                'img_title'  => mb_substr( $h2_text, 0, 55 ),
                'caption'    => mb_substr( $type_label . ' — ' . $h2_text, 0, 100 ),
                'image_type' => $img_type,
                // IMP-2: Adaptive dimensions — infographics/schemas in portrait, others landscape
                'flux_width'  => in_array( $img_type, array( 'infographic', 'schema_diagram' ), true ) ? 1024 : 1536,
                'flux_height' => in_array( $img_type, array( 'infographic', 'schema_diagram' ), true ) ? 1536 : 1024,
                'visual_structure_hint' => $visual_structure_hint,
                'key_concepts' => $key_concepts,
            );
            $is_first_incontent = false;
        }

        // ── Generate each image via configured provider (OpenAI or Flux) ──
        $all_images      = array();
        $updated_content = $content;

        foreach ( $image_specs as $spec ) {
            $is_featured = ( $spec['type'] === 'featured' );
            $is_dalle3   = false; // IMG-9: reset per iteration to avoid scope leak
            $quality     = $is_featured ? $img_cfg['featured_quality'] : ( $img_cfg['incontent_quality'] ?? 'medium' );

            // Map legacy quality values
            $quality_map = array( 'standard' => 'medium', 'hd' => 'high' );
            $quality     = $quality_map[ $quality ] ?? $quality;

            // ── SCHEMA_DIAGRAM → HTML inline (no image generation) ──
            // Schema diagrams are rendered as pure HTML with inline styles.
            // This avoids Flux/DALL-E text rendering issues and produces SEO-friendly,
            // accessible, pixel-perfect text at zero image-generation cost.
            // Featured images are excluded (they need a real image file for og:image, etc.).
            $schema_handled = false;
            if ( ( $spec['image_type'] ?? '' ) === 'schema_diagram' && ! $is_featured ) {
                $schema_json = $spec['prompt']; // Already a JSON string from build_json_infographic_prompt()
                $section_ctx = '';
                // Dedicated full-text extraction for schema diagrams (independent of
                // the 80-word cap in $h2_section_contents used for Flux prompts).
                // Schema HTML needs ~500 words of context for accurate diagrams.
                if ( ! empty( $spec['h2_target'] ) ) {
                    $h2_idx_for_ctx = array_search( $spec['h2_target'], $h2_texts, true );
                    if ( $h2_idx_for_ctx !== false && ! empty( $h2_matches[0][ $h2_idx_for_ctx ] ) ) {
                        $pat_ctx   = preg_quote( $h2_matches[0][ $h2_idx_for_ctx ], '/' );
                        $parts_ctx = preg_split( '/' . $pat_ctx . '/si', $content, 2 );
                        if ( isset( $parts_ctx[1] ) ) {
                            $section_parts = preg_split( '/<h2[^>]*>/si', $parts_ctx[1], 2 );
                            $section_ctx   = wp_strip_all_tags( $section_parts[0] ?? '' );
                        }
                    }
                }

                self::cocon_log( 'image_generating', 'Schema HTML : in-content "' . ( $spec['h2_target'] ?? '' ) . '"', array(
                    'post_id' => $post_id,
                    'mode'    => 'html_inline',
                ) );

                $schema_html = self::generate_schema_diagram_html( $schema_json, $spec['h2_target'] ?? '', $keyword, $section_ctx, $brand, $spec['visual_structure_hint'] ?? '', $spec['key_concepts'] ?? array() );

                if ( ! empty( $schema_html ) ) {
                    // Insert HTML diagram into content at the same position as images
                    $h2_target_s = $spec['h2_target'] ?? '';
                    $position    = $img_cfg['incontent_position'] ?? 'after_h2_p';
                    $caption     = $spec['caption'] ?? $spec['alt_text'];

                    // Wrap in a figure for consistent styling with other HTS visuals
                    $figure_html = "\n\n<figure class=\"hts-incontent-image hts-schema-diagram\" style=\"margin:1.5em auto;max-width:90%;\">"
                        . $schema_html
                        . '<figcaption style="font-size:0.82em;color:#6b7280;margin-top:0.4em;font-style:italic;text-align:center;">' . esc_html( $caption ) . '</figcaption>'
                        . "</figure>\n";

                    // Re-use the same H2-based insertion logic as images
                    $inserted = false;
                    if ( ! empty( $h2_target_s ) ) {
                        $h2_esc = preg_quote( $h2_target_s, '/' );
                        $h2_pat = '/<h2[^>]*>' . $h2_esc . '<\/h2>/si';
                        // v19-BUG10: Fallback with decoded entities if direct match fails
                        if ( ! preg_match( $h2_pat, $updated_content ) ) {
                            $h2_decoded = html_entity_decode( $h2_target_s, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                            $h2_esc = preg_quote( $h2_decoded, '/' );
                            $h2_pat = '/<h2[^>]*>' . $h2_esc . '<\/h2>/si';
                        }
                        if ( preg_match( $h2_pat, $updated_content, $h2m, PREG_OFFSET_CAPTURE ) ) {
                            $h2_end_pos = $h2m[0][1] + strlen( $h2m[0][0] );
                            $after_h2   = substr( $updated_content, $h2_end_pos );
                            if ( $position === 'after_h2' ) {
                                $updated_content = substr( $updated_content, 0, $h2_end_pos ) . $figure_html . $after_h2;
                                $inserted = true;
                            } elseif ( $position === 'mid_section' ) {
                                if ( preg_match( '/^((?:(?!<h2).)*?<\/p>(?:(?!<h2).)*?<\/p>)/si', $after_h2, $mid_m ) ) {
                                    $insert_at = $h2_end_pos + strlen( $mid_m[1] );
                                    $updated_content = substr( $updated_content, 0, $insert_at ) . $figure_html . substr( $updated_content, $insert_at );
                                    $inserted = true;
                                }
                            }
                            if ( ! $inserted ) {
                                if ( preg_match( '/^((?:(?!<h2).)*?<\/p>)/si', $after_h2, $p_m ) ) {
                                    $insert_at = $h2_end_pos + strlen( $p_m[1] );
                                    $updated_content = substr( $updated_content, 0, $insert_at ) . $figure_html . substr( $updated_content, $insert_at );
                                    $inserted = true;
                                } else {
                                    $updated_content = substr( $updated_content, 0, $h2_end_pos ) . $figure_html . $after_h2;
                                    $inserted = true;
                                }
                            }
                        }
                    }

                    if ( $inserted ) {
                        self::cocon_log( 'image_created', 'Schema HTML inséré dans le contenu', array(
                            'post_id' => $post_id,
                            'h2'      => $h2_target_s,
                            'mode'    => 'html_inline',
                        ) );
                        // Keep structure consistent with image entries (attachment_id = 0 for HTML)
                        $all_images[] = array(
                            'attachment_id' => 0,
                            'type'          => 'schema_html',
                            'alt'           => $spec['alt_text'],
                        );
                    } else {
                        self::cocon_log( 'image_error', 'Schema HTML : impossible de trouver le H2 cible pour insertion', array(
                            'h2' => $h2_target_s,
                        ) );
                    }
                    $schema_handled = true;
                } else {
                    self::cocon_log( 'image_error', 'Schema HTML : génération échouée, fallback image', array( 'post_id' => $post_id ) );
                    // $schema_handled remains false → falls through to normal Flux/OpenAI
                }
            } elseif ( ( $spec['image_type'] ?? '' ) === 'schema_diagram' && $is_featured ) {
                self::cocon_log( 'image_generating', 'Schema diagram featured : utilisation image (HTML réservé aux in-content)', array(
                    'post_id' => $post_id,
                ) );
            }

            // Schema HTML was successfully inserted → skip image generation
            if ( $schema_handled ) {
                continue;
            }

            // ── INFOGRAPHIC + Flux provider → reroute to GPT Image (OpenAI) ──
            // Flux cannot render readable text; GPT Image 1.5 has best text rendering + cheaper than 1.0.
            $force_openai_for_infographic = false;
            if ( ( $spec['image_type'] ?? '' ) === 'infographic' && $provider === 'flux' && ! empty( $openai_key ) ) {
                $force_openai_for_infographic = true;
            }

            // ── Schema diagram fallback (HTML failed) + Flux provider → reroute to GPT Image ──
            // Schema diagrams have text labels/arrows that Flux can't render legibly.
            $force_openai_for_schema_fallback = false;
            if ( ( $spec['image_type'] ?? '' ) === 'schema_diagram' && $provider === 'flux' && ! empty( $openai_key ) ) {
                $force_openai_for_schema_fallback = true;
            }

            // ── FLUX (BFL) provider ──
            if ( $provider === 'flux' && ! $force_openai_for_infographic && ! $force_openai_for_schema_fallback ) {
                // IMP-2: Adaptive dimensions — infographics/schemas use portrait ratio
                $flux_width  = $spec['flux_width']  ?? 1536;
                $flux_height = $spec['flux_height'] ?? 1024;

                // v19-AM5: Truncate Flux prompt to ~85 words (BFL sweet spot: 50-80 words)
                $flux_prompt = $spec['prompt'];
                if ( ! isset( $flux_prompt[0] ) || $flux_prompt[0] !== '{' ) {
                    // Only truncate text prompts, not JSON (infographic/schema)
                    $prompt_words = explode( ' ', $flux_prompt );
                    if ( count( $prompt_words ) > 85 ) {
                        $flux_prompt = implode( ' ', array_slice( $prompt_words, 0, 85 ) );
                    }
                }

                self::cocon_log( 'image_generating', 'Flux : ' . ( $is_featured ? 'featured' : 'in-content "' . ( $spec['h2_target'] ?? '' ) . '"' ), array(
                    'post_id' => $post_id,
                    'model'   => $img_cfg['flux_model'] ?? 'flux-2-pro',
                    'prompt'  => ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? $flux_prompt : mb_substr( $flux_prompt, 0, 200 ) . '...',
                ) );

                $flux_result = self::flux_generate_image(
                    $flux_prompt,
                    $flux_width,
                    $flux_height,
                    $img_cfg['flux_model'] ?? 'flux-2-pro',
                    'jpeg'
                );

                // ── Retry once on timeout or moderation with a simplified prompt ──
                if ( is_wp_error( $flux_result ) ) {
                    $err_code = $flux_result->get_error_code();
                    if ( in_array( $err_code, array( 'flux_timeout', 'flux_moderated' ), true ) ) {
                        // IMP-10: Retry with minimal but pertinent prompt (strip section content, keep subject)
                        $retry_h2 = $spec['h2_target'] ?? $keyword;
                        $retry_style = $style_prompts[ $spec['image_type'] ?? 'illustration' ] ?? $style_prompts['illustration'];
                        $safe_prompt = "\"{$keyword}\", topic: {$retry_h2}. "
                            . "Style: {$retry_style} "
                            . "{$color_palette} Object-focused composition, depopulated scene." . $clean_image_suffix;

                        self::cocon_log( 'image_generating', 'Flux retry avec prompt simplifié (' . $err_code . ')', array(
                            'post_id' => $post_id,
                            'prompt'  => mb_substr( $safe_prompt, 0, 150 ) . '...',
                        ) );

                        $flux_result = self::flux_generate_image(
                            $safe_prompt,
                            $flux_width,
                            $flux_height,
                            $img_cfg['flux_model'] ?? 'flux-2-pro',
                            'jpeg'
                        );
                    }
                }

                if ( is_wp_error( $flux_result ) ) {
                    self::cocon_log( 'image_error', 'Flux error: ' . $flux_result->get_error_message() );
                    continue;
                }

                $image_url     = $flux_result['url'];
                $b64_data      = ''; // Flux returns URLs, not base64
                $attachment_id = self::cocon_sideload_image( $image_url, $post_id, $spec['alt_text'], $spec['img_title'], $keyword );

            } else {
                // ── OPENAI provider (or infographic rerouted from Flux) ──
                $size    = '1536x1024';
                $openai_model = $img_cfg['openai_model'] ?? 'gpt-image-1';

                // Infographic or schema_diagram rerouted from Flux: use gpt-image-1.5 (best text rendering + cheaper)
                if ( $force_openai_for_infographic || $force_openai_for_schema_fallback ) {
                    $openai_model = 'gpt-image-1.5';

                    // GPT Image expects natural language, NOT JSON (unlike Flux).
                    // Convert the structured JSON prompt to a descriptive text prompt.
                    $spec['prompt'] = self::convert_json_prompt_to_text( $spec['prompt'], $brand );

                    $reroute_type = $force_openai_for_infographic ? 'Infographic' : 'Schema diagram';
                    self::cocon_log( 'image_generating', $reroute_type . ' rerouted Flux→GPT Image 1.5 (text rendering)', array(
                        'post_id' => $post_id,
                        'h2'      => $spec['h2_target'] ?? '',
                        'prompt'  => mb_substr( $spec['prompt'], 0, 200 ) . '...',
                    ) );
                }

                // DALL-E 3 uses different parameter names
                $is_dalle3 = ( $openai_model === 'dall-e-3' );

                // Schema diagrams have JSON prompts from build_json_infographic_prompt().
                // Convert to natural text for OpenAI image models (gpt-image-1, gpt-image-1.5, dall-e-3).
                // Infographic rerouting is handled above via $force_openai_for_infographic.
                if ( ( $spec['image_type'] ?? '' ) === 'schema_diagram' ) {
                    $spec['prompt'] = self::convert_json_prompt_to_text( $spec['prompt'], $brand );
                    self::cocon_log( 'image_generating', 'Schema featured : JSON prompt converti en texte pour ' . $openai_model, array(
                        'post_id' => $post_id,
                        'prompt'  => mb_substr( $spec['prompt'], 0, 200 ) . '...',
                    ) );
                }

                self::cocon_log( 'image_generating', $openai_model . ' : ' . ( $is_featured ? 'featured' : 'in-content "' . ( $spec['h2_target'] ?? '' ) . '"' ), array(
                    'post_id' => $post_id,
                    'quality' => $quality,
                    'prompt'  => mb_substr( $spec['prompt'], 0, 200 ) . '...',
                ) );

                $api_body = array(
                    'model'  => $openai_model,
                    'prompt' => $spec['prompt'],
                    'n'      => 1,
                    'size'   => $is_dalle3 ? '1792x1024' : $size,
                );

                if ( $is_dalle3 ) {
                    $api_body['quality'] = ( $quality === 'high' ) ? 'hd' : 'standard';
                    // DALL-E 3 does not support output_format
                } else {
                    $api_body['quality']       = $quality;
                    $api_body['output_format'] = 'png';
                }

                $response = wp_remote_post( 'https://api.openai.com/v1/images/generations', array(
                    'timeout' => 90,
                    'headers' => array(
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'Bearer ' . $openai_key,
                    ),
                    'body' => wp_json_encode( $api_body ),
                ) );

                if ( is_wp_error( $response ) ) {
                    self::cocon_log( 'image_error', $openai_model . ' request failed: ' . $response->get_error_message() );
                    continue;
                }

                $resp_code = wp_remote_retrieve_response_code( $response );
                $resp_body = json_decode( wp_remote_retrieve_body( $response ), true );

                $b64_data  = $resp_body['data'][0]['b64_json'] ?? '';
                $image_url = $resp_body['data'][0]['url'] ?? '';

                if ( $resp_code !== 200 || ( empty( $b64_data ) && empty( $image_url ) ) ) {
                    $err = $resp_body['error']['message'] ?? 'HTTP ' . $resp_code;
                    self::cocon_log( 'image_error', $openai_model . ' error: ' . $err );
                    continue;
                }

                // ── Sideload into WP media library ──
                if ( ! empty( $b64_data ) ) {
                    $attachment_id = self::cocon_sideload_base64_image( $b64_data, $post_id, $spec['alt_text'], $spec['img_title'], $keyword );
                } else {
                    $attachment_id = self::cocon_sideload_image( $image_url, $post_id, $spec['alt_text'], $spec['img_title'], $keyword );
                }
            }

            if ( ! $attachment_id ) {
                self::cocon_log( 'image_error', 'Sideload failed for ' . ( $is_featured ? 'featured' : 'in-content' ) );
                continue;
            }

            // Common vars for both featured & in-content (fixes undefined refs)
            $alt_text  = $spec['alt_text'];
            $img_title = $spec['img_title'];
            $img_size  = ( $provider === 'flux' )
                ? ( ( $spec['flux_width'] ?? 1536 ) . 'x' . ( $spec['flux_height'] ?? 1024 ) )
                : ( $is_dalle3 ? '1792x1024' : '1536x1024' );

            if ( $is_featured ) {
                set_post_thumbnail( $post_id, $attachment_id );
                self::cocon_log( 'image_created', 'Image featured créée (' . $provider . ')', array(
                    'attachment_id' => $attachment_id,
                    'post_id'       => $post_id,
                    'provider'      => $provider,
                    'quality'       => $quality,
                ) );
            } else {
                // Insert in-content image
                $img_url    = wp_get_attachment_url( $attachment_id );
                $h2_target  = $spec['h2_target'] ?? '';
                $position   = $img_cfg['incontent_position'] ?? 'after_h2_p';
                $caption    = $spec['caption'] ?? $alt_text;
                $img_type   = $spec['image_type'] ?? 'illustration';

                // Layout: adapt width based on image orientation
                // Portrait infographics/schemas get narrower to avoid oversized display
                $is_portrait = in_array( $img_type, array( 'infographic', 'schema_diagram' ), true );
                $max_w = $is_portrait ? '70%' : '85%';
                $figure_style = "margin:1.5em auto;text-align:center;max-width:{$max_w};";
                $fig_class    = 'hts-incontent-image hts-img--full';

                $figure_html = "\n\n<figure class=\"{$fig_class}\" style=\"{$figure_style}\">"
                    . '<img src="' . esc_url( $img_url ) . '" alt="' . esc_attr( $alt_text ) . '" '
                    . 'title="' . esc_attr( $img_title ) . '" loading="lazy" decoding="async" '
                    . 'style="width:100%;height:auto;border-radius:8px;">'
                    . '<figcaption style="font-size:0.82em;color:#6b7280;margin-top:0.4em;font-style:italic;">' . esc_html( $caption ) . '</figcaption>'
                    . "</figure>\n";

                $inserted = false;
                if ( ! empty( $h2_target ) ) {
                    // Offset-based approach: find H2, then Nth </p> after it
                    // Handles H3/H4/ul between H2 and first <p> (common in real articles)
                    $h2_esc = preg_quote( $h2_target, '/' );
                    $h2_pat = '/<h2[^>]*>' . $h2_esc . '<\/h2>/si';
                    // v19-BUG10: Fallback with decoded entities if direct match fails
                    if ( ! preg_match( $h2_pat, $updated_content ) ) {
                        $h2_decoded = html_entity_decode( $h2_target, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                        $h2_esc = preg_quote( $h2_decoded, '/' );
                        $h2_pat = '/<h2[^>]*>' . $h2_esc . '<\/h2>/si';
                    }

                    if ( preg_match( $h2_pat, $updated_content, $h2m, PREG_OFFSET_CAPTURE ) ) {
                        $h2_end_pos = $h2m[0][1] + strlen( $h2m[0][0] );
                        $after_h2   = substr( $updated_content, $h2_end_pos );

                        if ( $position === 'after_h2' ) {
                            $updated_content = substr( $updated_content, 0, $h2_end_pos ) . $figure_html . $after_h2;
                            $inserted = true;
                        } elseif ( $position === 'mid_section' ) {
                            // After 2nd </p> in this section (stop at next <h2>)
                            if ( preg_match( '/^((?:(?!<h2).)*?<\/p>(?:(?!<h2).)*?<\/p>)/si', $after_h2, $mid_m ) ) {
                                $insert_at = $h2_end_pos + strlen( $mid_m[1] );
                                $updated_content = substr( $updated_content, 0, $insert_at ) . $figure_html . substr( $updated_content, $insert_at );
                                $inserted = true;
                            }
                        }

                        // Default / fallback: after_h2_p — first </p> after H2 (skip H3/ul between)
                        if ( ! $inserted ) {
                            if ( preg_match( '/^((?:(?!<h2).)*?<\/p>)/si', $after_h2, $p_m ) ) {
                                $insert_at = $h2_end_pos + strlen( $p_m[1] );
                                $updated_content = substr( $updated_content, 0, $insert_at ) . $figure_html . substr( $updated_content, $insert_at );
                                $inserted = true;
                            } else {
                                $updated_content = substr( $updated_content, 0, $h2_end_pos ) . $figure_html . $after_h2;
                                $inserted = true;
                            }
                        }
                    }
                }

                // Fallback: fuzzy match on H2 text
                if ( ! $inserted && ! empty( $h2_target ) ) {
                    foreach ( $h2_texts as $h2t ) {
                        $esc = preg_quote( $h2t, '/' );
                        $pat = '/<h2[^>]*>.*?' . $esc . '.*?<\/h2>/si';
                        if ( preg_match( $pat, $updated_content, $fm, PREG_OFFSET_CAPTURE ) ) {
                            $pos = $fm[0][1] + strlen( $fm[0][0] );
                            $after = substr( $updated_content, $pos );
                            if ( preg_match( '/^((?:(?!<h2).)*?<\/p>)/si', $after, $fp ) ) {
                                $ia = $pos + strlen( $fp[1] );
                                $updated_content = substr( $updated_content, 0, $ia ) . $figure_html . substr( $updated_content, $ia );
                            } else {
                                $updated_content = substr( $updated_content, 0, $pos ) . $figure_html . $after;
                            }
                            $inserted = true;
                            break;
                        }
                    }
                }

                if ( $inserted ) {
 self::cocon_log( 'image_created', 'Image in-content insérée (' . $provider . ')', array(
                        'attachment_id' => $attachment_id,
                        'h2_target'     => $h2_target,
                        'position'      => $position,
                        'layout'        => $img_type,
                        'size'          => $img_size,
                        'alt'           => $alt_text,
                    ) );
                } else {
 self::cocon_log( 'image_warning', 'Image in-content créée mais H2 cible introuvable', array(
                        'attachment_id' => $attachment_id,
                        'h2_target'     => $h2_target,
                    ) );
                }
            }

            $all_images[] = array(
                'attachment_id' => $attachment_id,
                'type'          => $is_featured ? 'featured' : 'incontent',
                'alt'           => $alt_text,
            );
        }

        // Update post content with in-content images
        if ( $updated_content !== $content ) {
            wp_update_post( array(
                'ID'           => $post_id,
                'post_content' => $updated_content,
            ) );
        }

        // Save image count as post meta for UI display
        // Merge Pexels results with AI results
        $merged_images = array_merge( $pexels_result['images'] ?? array(), $all_images );
        if ( count( $merged_images ) > 0 ) {
            update_post_meta( $post_id, '_hts_image_count', count( $merged_images ) );
        }

        return array(
            'count'   => count( $merged_images ),
            'images'  => $merged_images,
            'content' => $updated_content,
        );
    }

    /**
     * Fetch a featured image from Pexels API and set it on the post.
     *
     * @param int    $post_id  WordPress post ID
     * @param string $keyword  Search keyword
     * @param string $title    Article title (used for alt text)
     * @param string $content  Post content (passed through unchanged)
     * @return array { count, images[], content }
     */
    /**
     * BP-2: Build a JSON-structured prompt for infographic/schema_diagram types.
     *
     * BFL recommends JSON format for complex infographics — Flux interprets structured
     * JSON prompts natively, producing better labeled sections and visual hierarchy.
     *
     * @param string $img_type            'infographic' or 'schema_diagram'.
     * @param string $h2_text             Section heading text.
     * @param string $keyword             Article main keyword.
     * @param array  $key_concepts        Extracted key concepts to label.
     * @param string $visual_structure    Visual structure hint (e.g. "checklist").
     * @param array  $brand               Brand identity (colors).
     * @param string $lang_name           Language name for labels.
     * @param string $extra_instructions  User-defined extra instructions.
     * @return string JSON-encoded prompt.
     */
    private static function build_json_infographic_prompt( $img_type, $h2_text, $keyword, $key_concepts, $visual_structure, $brand, $lang_name, $extra_instructions ) {
        $json_prompt = array(
            'type'    => $img_type === 'schema_diagram' ? 'diagram' : 'infographic',
            'title'   => $h2_text,
            'topic'   => $keyword,
            'sections' => array(),
            // BP-3: Colors associated to concrete elements
            'color_scheme' => array(
                'title_text'        => $brand['primary_color'],
                'section_background' => $brand['secondary_color'],
                'accent_icons'      => $brand['accent_color'],
            ),
            'style'    => 'modern, clean, professional, readable labels',
            'language' => $lang_name,
        );

        // Add sections from extracted concepts
        if ( ! empty( $key_concepts ) ) {
            // Visual element mapping based on diagram type
            $visual_element = $img_type === 'schema_diagram' ? 'node with label' : 'icon with label';
            foreach ( $key_concepts as $concept ) {
                $json_prompt['sections'][] = array(
                    'heading' => ucfirst( $concept ),
                    'visual'  => $visual_element,
                );
            }
        }

        // Add visual structure layout
        if ( ! empty( $visual_structure ) ) {
            $json_prompt['layout'] = trim( str_replace( 'Visual structure: ', '', rtrim( $visual_structure, '. ' ) ) );
        }

        $prompt = wp_json_encode( $json_prompt, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

        // Append extra instructions as plain text after JSON (Flux handles mixed format)
        if ( ! empty( $extra_instructions ) ) {
            $prompt .= "\n" . trim( $extra_instructions );
        }

        return $prompt;
    }

    /**
     * Convert a JSON-structured infographic prompt to natural language for GPT Image.
     *
     * Flux interprets JSON prompts natively, but GPT Image (gpt-image-1/1.5) expects
     * descriptive text. This converts the structured JSON into a rich text prompt
     * that GPT Image can render with proper text labels.
     *
     * @param string $json_prompt  JSON prompt (from build_json_infographic_prompt).
     * @param array  $brand        Brand identity (colors).
     * @return string Natural language prompt for GPT Image.
     */
    private static function convert_json_prompt_to_text( $json_prompt, $brand ) {
        // Extract JSON part (may have extra_instructions appended as plain text)
        $extra_text  = '';
        $json_part   = $json_prompt;

        // Try direct json_decode first (fastest, handles braces inside strings correctly)
        $direct_decode = json_decode( $json_prompt, true );
        if ( is_array( $direct_decode ) ) {
            $data = $direct_decode;
        } else {
            // Fallback: extract JSON via brace depth counter (handles extra_instructions appended after JSON)
            $first_brace = strpos( $json_prompt, '{' );
            if ( $first_brace !== false ) {
                $depth = 0;
                $len   = strlen( $json_prompt );
                $json_end = $len;
                for ( $i = $first_brace; $i < $len; $i++ ) {
                    if ( $json_prompt[ $i ] === '{' ) $depth++;
                    elseif ( $json_prompt[ $i ] === '}' ) {
                        $depth--;
                        if ( $depth === 0 ) {
                            $json_end = $i + 1;
                            break;
                        }
                    }
                }
            }
            $json_part  = substr( $json_prompt, $first_brace, $json_end - $first_brace );
            $extra_text = trim( substr( $json_prompt, $json_end ) );

            $data = json_decode( $json_part, true );
            if ( ! is_array( $data ) ) {
                // If JSON parse fails even after brace extraction, return raw prompt
                return $json_prompt;
            }
        }

        $title    = $data['title'] ?? '';
        $topic    = $data['topic'] ?? '';
        $type     = $data['type'] ?? 'infographic';
        $layout   = $data['layout'] ?? '';
        $language = $data['language'] ?? 'French';
        $sections = $data['sections'] ?? array();
        $colors   = $data['color_scheme'] ?? array();

        // Build descriptive prompt
        $prompt_parts = array();
        $prompt_parts[] = "Professional {$type} about \"{$title}\"";
        if ( ! empty( $topic ) && $topic !== $title ) {
            $prompt_parts[] = "topic: {$topic}";
        }

        // Sections with readable labels
        if ( ! empty( $sections ) ) {
            $labels = array();
            foreach ( $sections as $s ) {
                if ( ! empty( $s['heading'] ) ) {
                    $labels[] = $s['heading'];
                }
            }
            if ( ! empty( $labels ) ) {
                $prompt_parts[] = 'Sections with readable text labels: ' . implode( ', ', $labels );
            }
        }

        // Layout
        if ( ! empty( $layout ) ) {
            $prompt_parts[] = "Layout: {$layout}";
        }

        // Colors associated to elements (BP-3)
        $primary = $colors['title_text'] ?? ( $brand['primary_color'] ?? '#2563eb' );
        $secondary = $colors['section_background'] ?? ( $brand['secondary_color'] ?? '#10b981' );
        $accent = $colors['accent_icons'] ?? ( $brand['accent_color'] ?? '#f59e0b' );
        $prompt_parts[] = "Title text in {$primary}, section backgrounds in {$secondary}, accent icons in {$accent}";

        // Language and style
        $prompt_parts[] = "All text in {$language}";
        $prompt_parts[] = 'Modern clean professional style, structured layout with clear reading flow, icons paired with keywords';
        $prompt_parts[] = 'Every section must have clearly readable text labels';

        $prompt = implode( '. ', $prompt_parts ) . '.';

        if ( ! empty( $extra_text ) ) {
            $prompt .= ' ' . $extra_text;
        }

        return $prompt;
    }

    /**
     * Generate an HTML inline schema diagram via LLM (gpt-4.1-mini).
     *
     * Produces a self-contained HTML block with ONLY inline styles (no <style>, no CSS classes,
     * no JavaScript) so it works universally across any WordPress theme without conflicts.
     *
     * @param string $json_prompt    JSON prompt (from build_json_infographic_prompt, may have extra text appended).
     * @param string $h2_text        Section heading.
     * @param string $keyword        Article main keyword.
     * @param string $section_ctx    Section content for context.
     * @param array  $brand          Brand identity (colors).
     * @return string HTML string or empty on failure.
     */
    private static function generate_schema_diagram_html( $json_prompt, $h2_text, $keyword, $section_ctx, $brand, $visual_structure_hint = '', $key_concepts = array() ) {
        $openai_key = hts_get_openai_key();
        if ( empty( $openai_key ) ) {
            self::cocon_log( 'image_error', 'Schema HTML : clé OpenAI manquante' );
            return '';
        }

        // ── Budget check (reuse the same monthly budget as other OpenAI calls) ──
        $monthly_limit = (int) get_option( 'hts_openai_monthly_limit', 1000000 );
        $usage         = get_option( 'hts_openai_usage', array() );
        $month_key     = date( 'Y-m' );
        $current_usage = (int) ( $usage[ $month_key ] ?? 0 );
        if ( $monthly_limit > 0 && $current_usage >= $monthly_limit ) {
            self::cocon_log( 'image_error', 'Schema HTML : budget OpenAI mensuel épuisé' );
            return '';
        }

        $primary_color   = $brand['primary_color'] ?? '#2563eb';
        $secondary_color = $brand['secondary_color'] ?? '#10b981';
        $accent_color    = $brand['accent_color'] ?? '#f59e0b';

        // Parse JSON prompt - build_json_infographic_prompt may append extra_instructions
        // as plain text after the JSON, so we extract only the JSON part.
        $extra_text    = '';
        $diagram_data  = null;

        // Try direct json_decode first (handles braces inside strings correctly)
        $direct_decode = json_decode( $json_prompt, true );
        if ( is_array( $direct_decode ) ) {
            $diagram_data = $direct_decode;
        } else {
            // Fallback: extract JSON via brace depth counter
            $json_part    = $json_prompt;
            $first_brace  = strpos( $json_prompt, '{' );
            if ( $first_brace !== false ) {
                $depth = 0;
                $len   = strlen( $json_prompt );
                $json_end = $len;
                for ( $i = $first_brace; $i < $len; $i++ ) {
                    if ( $json_prompt[ $i ] === '{' ) $depth++;
                    elseif ( $json_prompt[ $i ] === '}' ) {
                        $depth--;
                        if ( $depth === 0 ) {
                            $json_end = $i + 1;
                            break;
                        }
                    }
                }
                $json_part  = substr( $json_prompt, $first_brace, $json_end - $first_brace );
                $extra_text = trim( substr( $json_prompt, $json_end ) );

                $diagram_data = json_decode( $json_part, true );
            }
        }
        if ( ! is_array( $diagram_data ) ) {
            // JSON parse failed — use fallback values
            $diagram_data = array();
            self::cocon_log( 'image_warning', 'Schema HTML : JSON parse échoué, utilisation des fallbacks', array(
                'json_start' => mb_substr( $json_part, 0, 100 ),
            ) );
        }
        $title    = $diagram_data['title'] ?? $h2_text;
        $sections = $diagram_data['sections'] ?? array();
        $layout   = $diagram_data['layout'] ?? 'organized summary with labeled key points';

        // Use full section content — schema diagrams need complete text for accuracy.
        // Cap at ~500 words to stay within token budget while capturing all key info.
        $ctx_snippet = '';
        if ( ! empty( $section_ctx ) ) {
            $clean_text  = wp_strip_all_tags( $section_ctx );
            $all_words   = explode( ' ', trim( $clean_text ) );
            $ctx_snippet = implode( ' ', array_slice( $all_words, 0, 500 ) );
        }

        // ── Layout-specific HTML directives ──
        // Without these, gpt-4.1-mini defaults to the same "flex cards" layout every time.
        // Each layout type gets concrete structural guidance for distinct visual rendering.
        // DESIGN RULE: no emojis anywhere — use inline SVG or plain text symbols only.
        $layout_directives = array(
            'numbered step-by-step process flow'
                => 'Structure : colonne verticale de blocs numerotes (1, 2, 3) relies par une ligne verticale SVG (trait fin continu ou pointille). Chaque etape = numero dans un cercle SVG a gauche + bloc texte a droite. Style sobre et lineaire.',
            'side-by-side comparison with two distinct columns'
                => 'Structure : deux colonnes cote a cote (display:flex), chacune avec un en-tete sobre. Separation par une fine bordure verticale (1px solid). Chaque colonne liste ses points avec un tiret ou une puce SVG minimale (check/cross 12px). En-tetes contrastes (couleur principale vs secondaire).',
            'proportional chart or pie segments'
                => 'Structure : barres horizontales proportionnelles aux donnees REELLES du contexte uniquement. Si aucun chiffre reel, utiliser blocs etiquetes. JAMAIS de pourcentages inventes.',
            'pros and cons balance or split layout'
                => 'Structure : deux colonnes (display:flex). Colonne gauche = fond neutre, en-tete texte simple. Colonne droite = fond neutre. Chaque point avec un petit SVG (check ou cross, 12px) + texte. Fine bordure separatrice. Aucun emoji.',
            'circular cycle diagram'
                => 'Structure : disposition en boucle avec 3-6 elements. Fleches SVG fines reliant chaque element au suivant (et le dernier au premier). Chaque noeud = bloc arrondi (border-radius pill) sobre. Couleurs alternees subtiles.',
            'hierarchical tree or pyramid'
                => 'Structure : pyramide a niveaux. Bloc parent en haut (large, fond couleur principale pale), connecte par des lignes SVG fines vers 2-3 blocs enfants. Chaque niveau progressivement plus large. Style minimaliste.',
            'checklist or screening list with checkmarks'
                => 'Structure : liste verticale. Chaque item = petit SVG checkmark (12px, trait fin) + texte. Fond alterne tres leger (pair/impair : transparent / gris #f9fafb). Compact, sobre, scannable. Pas de checkbox fantaisie.',
            'categorized grid or card layout'
                => 'Structure : grille responsive (display:flex, flex-wrap:wrap) de 2-3 cartes par ligne. Chaque carte = titre bold + texte court. Bordure gauche fine coloree (3px) ou fond pastel tres leger distinct par categorie. Pas d icone decorative.',
            'cause-and-effect chain or flow diagram'
                => 'Structure : blocs cause a gauche relies par une fleche SVG fine vers blocs effet a droite. Fond cause = couleur principale pale, fond effet = couleur accent pale. Si ramifications, connecteurs SVG en T. Design epure.',
            'warning or risk assessment layout'
                => 'Structure : blocs empiles verticalement. Bordure gauche epaisse (4px) rouge/orange/jaune selon gravite. Texte de niveau en bold. Description en regular. Pas d icone, le code couleur suffit a indiquer la gravite.',
            'numbered tips or best practices list'
                => 'Structure : liste numerotee. Chaque item = numero large (22px, font-weight:700, couleur principale) a gauche + texte a droite. Fond neutre tres leger, alternance subtile. Pas de decoration.',
            'organized summary with labeled key points'
                => 'Structure : blocs empiles avec un petit label sobre (texte uppercase 11px, fond couleur principale, texte blanc, border-radius 3px) en haut de chaque point. Texte descriptif en dessous. Fond neutre, espacement genereux. PAS de barres ni pourcentages — labels textuels uniquement.',
        );

        // visual_structure_hint prioritaire sur layout JSON
        $effective_layout = $layout;
        if ( ! empty( $visual_structure_hint ) ) {
            $hint_layout = trim( str_replace( 'Visual structure: ', '', rtrim( $visual_structure_hint, '. ' ) ) );
            if ( isset( $layout_directives[ $hint_layout ] ) ) {
                $effective_layout = $hint_layout;
            }
        }
        $layout_hint = $layout_directives[ $effective_layout ] ?? $layout_directives['organized summary with labeled key points'];

        $system_prompt = "Tu es un expert en data visualization HTML. Tu generes des schemas/diagrammes en HTML pur avec UNIQUEMENT des styles inline.\n\n"
            . "REGLES STRICTES :\n"
            . "- UNIQUEMENT des balises HTML avec attribut style=\"\" inline\n"
            . "- JAMAIS de balise <style>, JAMAIS de CSS classes, JAMAIS de <script>, JAMAIS de JavaScript\n"
            . "- JAMAIS de balise <html>, <head>, <body> — juste le contenu du diagramme\n"
            . "- JAMAIS d emoji Unicode (pas de symboles type icones emoticones). Pour les marqueurs visuels, utilise UNIQUEMENT des SVG inline simples (petits, < 20px) ou des caracteres texte simples (tirets, puces, numeros)\n"
            . "- Utilise des <div>, <span>, <table>, <svg> (inline SVG pour fleches et connecteurs)\n"
            . "- Le HTML doit etre responsive (max-width, width en %, flexbox inline)\n"
            . "- Texte en francais\n"
            . "- NE JAMAIS inventer de donnees chiffrees (pourcentages, statistiques, scores). Utilise UNIQUEMENT les chiffres presents dans le contexte fourni. Sans chiffres, utilise des labels textuels.\n"
            . "- Si le layout suggere des barres proportionnelles mais sans donnees numeriques, genere un layout en blocs etiquetes a la place.\n\n"
            . "DIRECTION ARTISTIQUE — style sobre et premium :\n"
            . "- Minimaliste, epure, beaucoup d espace blanc (padding genereux)\n"
            . "- Couleurs tres desaturees pour les fonds (ex: #f8fafc, #f1f5f9), couleurs vives UNIQUEMENT pour les accents fins (bordures, titres)\n"
            . "- Couleur principale : " . $primary_color . ", secondaire : " . $secondary_color . ", accent : " . $accent_color . "\n"
            . "- Texte : #1f2937 corps, " . $primary_color . " titres, #6b7280 texte secondaire\n"
            . "- Typographie : font-weight 600 max pour les titres (pas 800/900), 400 pour le corps\n"
            . "- Bordures fines (1px solid #e2e8f0), border-radius: 8px, ombres tres legeres (box-shadow: 0 1px 3px rgba(0,0,0,0.04))\n"
            . "- Taille de police : 14px corps, 15px sous-titres. Pas de texte en dessous de 12px\n"
            . "- NE PAS repeter le titre H2 de la section (deja dans l article)\n"
            . "- Commence directement par le contenu du diagramme\n\n"
            . "STRUCTURE HTML A SUIVRE pour ce layout :\n" . $layout_hint . "\n\n"
            . "Reponds UNIQUEMENT avec le HTML, sans explication, sans backticks markdown, sans commentaire.";


        $sections_desc = '';
        if ( ! empty( $sections ) ) {
            $labels = array_map( function( $s ) { return $s['heading'] ?? ''; }, $sections );
            $sections_desc = 'Éléments à inclure : ' . implode( ', ', array_filter( $labels ) ) . ".\n";
        }

        $user_prompt = "Génère un schéma/diagramme HTML inline pour cette section d'article :\n\n"
            . "Sujet : " . $keyword . "\n"
            . "Section : " . $title . "\n"
            . "Layout souhaité : " . $layout . "\n"
            . $sections_desc
            . ( ! empty( $key_concepts ) ? "Termes clés à intégrer : " . implode( ', ', $key_concepts ) . ".\n" : '' )
            . ( ! empty( $extra_text ) ? "Instructions supplémentaires : " . $extra_text . "\n" : '' )
            . "\nContexte du contenu :\n" . $ctx_snippet . "\n\n"
            . "Le diagramme doit illustrer visuellement les relations, étapes ou concepts décrits. "
            . "Utilise des connecteurs visuels (flèches SVG inline ou bordures) pour montrer les liens entre éléments.";

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $openai_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( array(
                // v18: gpt-4.1-mini pour meilleur HTML
                'model'       => 'gpt-4.1-mini',
                'messages'    => array(
                    array( 'role' => 'system', 'content' => $system_prompt ),
                    array( 'role' => 'user',   'content' => $user_prompt ),
                ),
                'temperature' => 0.3,
                'max_tokens'  => ( hts_word_count( $ctx_snippet ) > 300 ) ? 4500 : 3500,
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            self::cocon_log( 'image_error', 'Schema HTML : erreur réseau OpenAI — ' . $response->get_error_message() );
            return '';
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            $err = $body['error']['message'] ?? 'HTTP ' . $code;
            self::cocon_log( 'image_error', 'Schema HTML : OpenAI erreur — ' . $err );
            return '';
        }

        // Track token usage
        $tokens_used = (int) ( $body['usage']['total_tokens'] ?? 0 );
        if ( $tokens_used > 0 ) {
            $usage[ $month_key ] = $current_usage + $tokens_used;
            $keep = array( $month_key, date( 'Y-m', strtotime( '-1 month' ) ), date( 'Y-m', strtotime( '-2 months' ) ) );
            $usage = array_intersect_key( $usage, array_flip( $keep ) );
            update_option( 'hts_openai_usage', $usage, false );
        }

        $html = $body['choices'][0]['message']['content'] ?? '';
        $html = trim( $html );

        // Strip markdown code fences if the LLM wrapped it
        $html = preg_replace( '/^```(?:html)?\s*/i', '', $html );
        $html = preg_replace( '/\s*```\s*$/', '', $html );
        $html = trim( $html );

        // Sanitize: remove any <script>, <style>, <link> tags for security
        $html = preg_replace( '/<script\b[^>]*>.*?<\/script>/si', '', $html );
        $html = preg_replace( '/<style\b[^>]*>.*?<\/style>/si', '', $html );
        $html = preg_replace( '/<link\b[^>]*>/si', '', $html );

        // Strip inline event handlers (on*="...") — XSS vector even from LLM output
        $html = preg_replace( '/\s+on\w+\s*=\s*"[^"]*"/si', '', $html );
        $html = preg_replace( '/\s+on\w+\s*=\s*\'[^\']*\'/si', '', $html );
        $html = preg_replace( '/\s+on\w+\s*=\s*[^\s>]*/si', '', $html );

        // Strip dangerous tags: iframe, form, input, button, textarea, object, embed
        $html = preg_replace( '/<iframe\b[^>]*>.*?<\/iframe>/si', '', $html );
        $html = preg_replace( '/<iframe\b[^>]*>/si', '', $html );
        $html = preg_replace( '/<form\b[^>]*>.*?<\/form>/si', '', $html );
        $html = preg_replace( '/<input\b[^>]*>/si', '', $html );
        $html = preg_replace( '/<button\b[^>]*>.*?<\/button>/si', '', $html );
        $html = preg_replace( '/<textarea\b[^>]*>.*?<\/textarea>/si', '', $html );
        $html = preg_replace( '/<object\b[^>]*>.*?<\/object>/si', '', $html );
        $html = preg_replace( '/<embed\b[^>]*>/si', '', $html );

        // Repair HTML tronque (div non fermees)
        $open_divs  = preg_match_all( '/<div\\b/i', $html, $_m );
        $close_divs = preg_match_all( '/<\\/div>/i', $html, $_m );
        if ( $open_divs > $close_divs ) {
            $missing = $open_divs - $close_divs;
            $html .= str_repeat( '</div>', $missing );
            self::cocon_log( 'image_warning', 'Schema HTML tronqué : ' . $missing . ' </div> ajoutés' );
        }

        // Basic validation: must contain at least some div/table structure
        if ( mb_strlen( $html ) < 50 || ( stripos( $html, '<div' ) === false && stripos( $html, '<table' ) === false && stripos( $html, '<svg' ) === false ) ) {
            self::cocon_log( 'image_error', 'Schema HTML : réponse invalide (trop courte ou pas de structure)', array(
                'length' => mb_strlen( $html ),
            ) );
            return '';
        }

        self::cocon_log( 'image_generating', 'Schema HTML généré avec succès', array(
            'tokens'  => $tokens_used,
            'layout'  => $layout,
            'html_kb' => round( strlen( $html ) / 1024, 1 ),
        ) );

        return $html;
    }

    public static function cocon_pexels_featured_image( $post_id, $keyword, $title, $content ) {
        $img_cfg    = self::get_image_settings();
        $pexels_key = $img_cfg['pexels_api_key'] ?? '';

        if ( empty( $pexels_key ) ) {
            self::cocon_log( 'image_error', 'Pexels : clé API manquante — configurez-la dans Réglages images' );
            return array( 'count' => 0, 'images' => array(), 'content' => $content );
        }

        // Build a concise search query: keyword + first meaningful words
        $search_query = mb_substr( trim( $keyword ), 0, 80 );

        $response = wp_remote_get( 'https://api.pexels.com/v1/search?' . http_build_query( array(
            'query'       => $search_query,
            'per_page'    => 5,
            'orientation' => 'landscape',
            'size'        => 'large',
        ) ), array(
            'timeout' => 15,
            'headers' => array( 'Authorization' => $pexels_key ),
        ) );

        if ( is_wp_error( $response ) ) {
            self::cocon_log( 'image_error', 'Pexels API error: ' . $response->get_error_message() );
            return array( 'count' => 0, 'images' => array(), 'content' => $content );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 || empty( $body['photos'] ) ) {
            self::cocon_log( 'image_warning', 'Pexels : aucune photo trouvée pour "' . $search_query . '"', array( 'http' => $code ) );
            return array( 'count' => 0, 'images' => array(), 'content' => $content );
        }

        // Pick a random photo from top results for variety across cocon articles
        $pick_max = min( count( $body['photos'] ) - 1, 4 );
        $photo    = $body['photos'][ wp_rand( 0, $pick_max ) ];

        // Use the 'large2x' size (~1500px wide, perfect for featured)
        $img_url      = $photo['src']['large2x'] ?? $photo['src']['large'] ?? $photo['src']['original'];
        $photographer = $photo['photographer'] ?? '';
        $pexels_url   = $photo['url'] ?? '';

        // Build SEO-optimized alt text
        $alt_text  = mb_substr( $keyword . ' — ' . $title, 0, 120 );
        $img_title = mb_substr( $title, 0, 55 );

        // Download and sideload into WordPress media library
        $attachment_id = self::cocon_sideload_image( $img_url, $post_id, $alt_text, $img_title, $keyword );

        if ( ! $attachment_id ) {
            self::cocon_log( 'image_error', 'Pexels : sideload échoué pour "' . $search_query . '"' );
            return array( 'count' => 0, 'images' => array(), 'content' => $content );
        }

        // Set as featured image
        set_post_thumbnail( $post_id, $attachment_id );

        // Store Pexels attribution as post meta (for optional credit display)
        update_post_meta( $post_id, '_hts_pexels_photographer', $photographer );
        update_post_meta( $post_id, '_hts_pexels_url', $pexels_url );

        // Add photo credit as attachment description
        if ( $photographer ) {
            wp_update_post( array(
                'ID'           => $attachment_id,
                'post_excerpt' => 'Photo: ' . $photographer . ' / Pexels',
            ) );
        }

        self::cocon_log( 'image_created', 'Image featured Pexels', array(
            'attachment_id' => $attachment_id,
            'photographer'  => $photographer,
            'search'        => $search_query,
            'post_id'       => $post_id,
        ) );

        return array(
            'count'   => 1,
            'images'  => array( array(
                'attachment_id' => $attachment_id,
                'type'          => 'featured',
                'source'        => 'pexels',
                'alt'           => $alt_text,
            ) ),
            'content' => $content,
        );
    }

    public static function cocon_sideload_image( $url, $post_id, $alt_text, $img_title, $keyword ) {
        if ( ! function_exists( 'media_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        // ── 1. Download original ──
        $tmp_original = download_url( $url, 60 );
        if ( is_wp_error( $tmp_original ) ) {
            // Retry once (Flux URLs expire in 10min, network glitches)
            usleep( 500000 ); // 0.5s
            $tmp_original = download_url( $url, 60 );
            if ( is_wp_error( $tmp_original ) ) {
                self::cocon_log( 'image_error', 'Download failed (2 attempts): ' . $tmp_original->get_error_message() );
                return false;
            }
        }

        $original_size = filesize( $tmp_original );
        $filename      = sanitize_title( $keyword ) . '-' . wp_generate_password( 4, false );

        // Detect original format from file content (not URL, which may be opaque)
        $finfo    = function_exists( 'finfo_open' ) ? finfo_open( FILEINFO_MIME_TYPE ) : null;
        $src_mime = $finfo ? finfo_file( $finfo, $tmp_original ) : '';
        if ( $finfo ) finfo_close( $finfo );
        $src_ext = 'png'; // safe default
        if ( strpos( $src_mime, 'jpeg' ) !== false || strpos( $src_mime, 'jpg' ) !== false ) $src_ext = 'jpg';
        elseif ( strpos( $src_mime, 'webp' ) !== false ) $src_ext = 'webp';

        // ── 2. Use WP_Image_Editor (most reliable cross-hosting method) ──
        $editor = wp_get_image_editor( $tmp_original );

        if ( is_wp_error( $editor ) ) {
            // WP_Image_Editor failed → upload original as-is
 self::cocon_log( 'image_convert', 'WP_Image_Editor unavailable — uploading original ' . strtoupper( $src_ext ), array(
                'error'    => $editor->get_error_message(),
                'original' => self::cocon_format_bytes( $original_size ),
            ) );

            $file_array = array(
                'name'     => $filename . '.' . $src_ext,
                'tmp_name' => $tmp_original,
            );
            $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $tmp_original );
                return false;
            }
            self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
            return $attachment_id;
        }

        // ── 3. Resize to max 1200px width (optimal for featured images) ──
        $size = $editor->get_size();
        if ( $size['width'] > 1200 ) {
            $editor->resize( 1200, null, false );
        }

        // ── 4. Set quality ──
        $editor->set_quality( 82 );

        // ── 5. Try saving as WebP ──
        $tmp_webp    = null;
        $final_ext   = 'png';
        $final_mime  = 'image/png';

        // Check if WP supports WebP output (WP 5.8+ with GD/Imagick WebP)
        $supported_types = $editor->supports_mime_type( 'image/webp' );

        if ( $supported_types ) {
            $tmp_webp = wp_tempnam( $filename . '.webp' );
            $saved    = $editor->save( $tmp_webp, 'image/webp' );

            if ( ! is_wp_error( $saved ) && file_exists( $saved['path'] ) && filesize( $saved['path'] ) > 100 ) {
                $webp_size = filesize( $saved['path'] );
                $reduction = $original_size > 0 ? round( ( 1 - $webp_size / $original_size ) * 100 ) : 0;

 self::cocon_log( 'image_convert', strtoupper( $src_ext ) . '→WebP', array(
                    'original' => self::cocon_format_bytes( $original_size ),
                    'webp'     => self::cocon_format_bytes( $webp_size ),
                    'saved'    => $reduction . '%',
                ) );

                @unlink( $tmp_original );

                $file_array = array(
                    'name'     => $filename . '.webp',
                    'tmp_name' => $saved['path'],
                    'type'     => 'image/webp',
                );
                $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
                if ( is_wp_error( $attachment_id ) ) {
                    @unlink( $saved['path'] );
                    return false;
                }
                self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
                return $attachment_id;
            }

            // WebP save failed, clean up
            // v19-BUG12: Always cleanup $tmp_webp (WP_Image_Editor may save to a different path)
            if ( $tmp_webp && file_exists( $tmp_webp ) ) @unlink( $tmp_webp );
            if ( ! is_wp_error( $saved ) && isset( $saved['path'] ) && $saved['path'] !== $tmp_webp && file_exists( $saved['path'] ) ) @unlink( $saved['path'] );
        }

        // ── 6. Fallback: Save as compressed JPEG (better than raw PNG) ──
        $tmp_jpg = wp_tempnam( $filename . '.jpg' );
        $saved   = $editor->save( $tmp_jpg, 'image/jpeg' );

        if ( ! is_wp_error( $saved ) && file_exists( $saved['path'] ) ) {
            $jpg_size  = filesize( $saved['path'] );
            $reduction = $original_size > 0 ? round( ( 1 - $jpg_size / $original_size ) * 100 ) : 0;

 self::cocon_log( 'image_convert', strtoupper( $src_ext ) . '→JPEG (WebP non supporté)', array(
                'original' => self::cocon_format_bytes( $original_size ),
                'jpeg'     => self::cocon_format_bytes( $jpg_size ),
                'saved'    => $reduction . '%',
            ) );

            @unlink( $tmp_original );

            $file_array = array(
                'name'     => $filename . '.jpg',
                'tmp_name' => $saved['path'],
                'type'     => 'image/jpeg',
            );
            $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $saved['path'] );
                return false;
            }
            self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
            return $attachment_id;
        }

        // ── 7. Last resort: upload original ──
 self::cocon_log( 'image_convert', 'All conversions failed — uploading original', array(
            'original' => self::cocon_format_bytes( $original_size ),
        ) );

        $file_array = array(
            'name'     => $filename . '.' . $src_ext,
            'tmp_name' => $tmp_original,
        );
        $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp_original );
            return false;
        }
        self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
        return $attachment_id;
    }

    /**
     * Set image alt text + short title on attachment
     */
    public static function cocon_set_image_meta( $attachment_id, $alt_text, $img_title ) {
        // Alt text (SEO — screen readers + LLMs) — max 125 chars
        $alt = mb_substr( sanitize_text_field( $alt_text ), 0, 125 );
        update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );

        // Title (SEO — hover + media library) — max 60 chars
        $title = mb_substr( sanitize_text_field( $img_title ), 0, 60 );
        wp_update_post( array(
            'ID'         => $attachment_id,
            'post_title' => $title,
        ) );
    }

    /**
     * Sideload a base64-encoded image (from gpt-image-1.5) into the WP media library.
     * Decodes base64 → temp file → reuses cocon_sideload_image pipeline (resize + WebP conversion).
     */
    public static function cocon_sideload_base64_image( $b64_data, $post_id, $alt_text, $img_title, $keyword ) {
        if ( ! function_exists( 'media_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        // Decode base64 to binary
        $image_data = base64_decode( $b64_data );
        if ( empty( $image_data ) || strlen( $image_data ) < 100 ) {
 self::cocon_log( 'image_error', 'Base64 decode failed or image too small' );
            return false;
        }

        $original_size = strlen( $image_data );
        $filename      = sanitize_title( $keyword ) . '-' . wp_generate_password( 4, false );

        // Write to temp file
        $tmp_file = wp_tempnam( $filename . '.png' );
        if ( ! $tmp_file || ! file_put_contents( $tmp_file, $image_data ) ) {
 self::cocon_log( 'image_error', 'Failed to write base64 image to temp file' );
            return false;
        }
        unset( $image_data ); // free memory

        // Use WP_Image_Editor for resize + format conversion (same as URL-based pipeline)
        $editor = wp_get_image_editor( $tmp_file );

        if ( is_wp_error( $editor ) ) {
            // Editor unavailable — upload original PNG as-is
 self::cocon_log( 'image_convert', 'WP_Image_Editor unavailable — uploading original PNG (base64)', array(
                'original' => self::cocon_format_bytes( $original_size ),
            ) );
            $file_array = array(
                'name'     => $filename . '.png',
                'tmp_name' => $tmp_file,
            );
            $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $tmp_file );
                return false;
            }
            self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
            return $attachment_id;
        }

        // Resize to max 1200px width
        $size = $editor->get_size();
        if ( $size['width'] > 1200 ) {
            $editor->resize( 1200, null, false );
        }
        $editor->set_quality( 82 );

        // Try WebP
        if ( $editor->supports_mime_type( 'image/webp' ) ) {
            $tmp_webp = wp_tempnam( $filename . '.webp' );
            $saved    = $editor->save( $tmp_webp, 'image/webp' );

            if ( ! is_wp_error( $saved ) && file_exists( $saved['path'] ) && filesize( $saved['path'] ) > 100 ) {
                $webp_size = filesize( $saved['path'] );
                $reduction = $original_size > 0 ? round( ( 1 - $webp_size / $original_size ) * 100 ) : 0;

 self::cocon_log( 'image_convert', 'Base64 PNG→WebP', array(
                    'original' => self::cocon_format_bytes( $original_size ),
                    'webp'     => self::cocon_format_bytes( $webp_size ),
                    'saved'    => $reduction . '%',
                ) );

                @unlink( $tmp_file );
                $file_array = array(
                    'name'     => $filename . '.webp',
                    'tmp_name' => $saved['path'],
                    'type'     => 'image/webp',
                );
                $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
                if ( is_wp_error( $attachment_id ) ) {
                    @unlink( $saved['path'] );
                    return false;
                }
                self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
                return $attachment_id;
            }
            if ( $tmp_webp && file_exists( $tmp_webp ) ) @unlink( $tmp_webp );
            if ( ! is_wp_error( $saved ) && isset( $saved['path'] ) && file_exists( $saved['path'] ) ) @unlink( $saved['path'] );
        }

        // Fallback: JPEG
        $tmp_jpg = wp_tempnam( $filename . '.jpg' );
        $saved   = $editor->save( $tmp_jpg, 'image/jpeg' );

        if ( ! is_wp_error( $saved ) && file_exists( $saved['path'] ) ) {
            @unlink( $tmp_file );
            $file_array = array(
                'name'     => $filename . '.jpg',
                'tmp_name' => $saved['path'],
                'type'     => 'image/jpeg',
            );
            $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $saved['path'] );
                return false;
            }
            self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
            return $attachment_id;
        }

        // Last resort: upload original PNG
        $file_array = array(
            'name'     => $filename . '.png',
            'tmp_name' => $tmp_file,
        );
        $attachment_id = media_handle_sideload( $file_array, $post_id, $alt_text );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp_file );
            return false;
        }
        self::cocon_set_image_meta( $attachment_id, $alt_text, $img_title );
        return $attachment_id;
    }

    /** Format bytes to human readable */
    private static function cocon_format_bytes( $bytes ) {
        if ( $bytes >= 1048576 ) return round( $bytes / 1048576, 1 ) . ' MB';
        if ( $bytes >= 1024 )    return round( $bytes / 1024 ) . ' KB';
        return $bytes . ' B';
    }

    /* ═══════════════════════════════════════════════════════════
     *  MARKDOWN LINKS FIX (v2.7.3)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Convert markdown-style citation links from AI to proper HTML <a> tags
     * and strip utm_source=openai tracking params.
     *
     * Patterns handled:
     *  - ([domain.com](https://url?utm_source=openai))
     *  - [domain.com](https://url?utm_source=openai)
     *  - Already-HTML <a> with utm_source=openai → strip UTM only
     *
     * @param string $content HTML content with possible markdown links
     * @return string Cleaned HTML with proper <a> tags
     */
    public static function cocon_fix_markdown_links( $content ) {
        if ( empty( $content ) ) return $content;
        $fixed_count = 0;

        // Sprint 6.2d: site host for internal/external link detection
        $site_host = parse_url( get_site_url(), PHP_URL_HOST );

        // ── Pattern 1: ([anchor text](https://url)) — parenthesized citation ──
        $result = preg_replace_callback(
            '/\(\[([^\]]+)\]\((https?:\/\/[^\)]+)\)\)/',
            function( $m ) use ( &$fixed_count, $site_host ) {
                $fixed_count++;
                $anchor = trim( $m[1] );
                $url    = self::cocon_strip_ai_utm( $m[2] );
                $link_host = parse_url( $url, PHP_URL_HOST );
                // Sprint 6.2d: Internal links — no target="_blank", no rel
                if ( $link_host && $site_host && ( $link_host === $site_host || str_ends_with( $link_host, '.' . $site_host ) ) ) {
                    return '<a href="' . esc_url( $url ) . '">' . esc_html( $anchor ) . '</a>';
                }
                return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $anchor ) . '</a>';
            },
            $content
        );
        if ( $result !== null ) $content = $result;

        // ── Pattern 2: [anchor text](https://url) — bare markdown link ──
        // FIX v2.7.4: replaced variable-length lookbehind (?<![<]a[^>]*>) which caused
        // PCRE null return on large content. Now uses a simpler match + skip approach.
        $result = preg_replace_callback(
            '/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/',
            function( $m ) use ( &$fixed_count, $content, $site_host ) {
                // Skip if this match is already inside an <a href="..."> context
                $pos = strpos( $content, $m[0] );
                if ( $pos !== false ) {
                    $before = substr( $content, max( 0, $pos - 200 ), min( $pos, 200 ) );
                    // Check if we're inside an existing <a> tag (opened but not closed)
                    $last_a_open  = strrpos( $before, '<a ' );
                    $last_a_close = strrpos( $before, '</a>' );
                    if ( $last_a_open !== false && ( $last_a_close === false || $last_a_close < $last_a_open ) ) {
                        return $m[0]; // Already inside <a> — don't convert
                    }
                    // Check if preceded by href="
                    if ( preg_match( '/href=["\']$/', $before ) ) {
                        return $m[0]; // Part of href — don't convert
                    }
                }
                $fixed_count++;
                $anchor = trim( $m[1] );
                $url    = self::cocon_strip_ai_utm( $m[2] );
                $link_host = parse_url( $url, PHP_URL_HOST );
                // Sprint 6.2d: Internal links — no target="_blank", no rel
                if ( $link_host && $site_host && ( $link_host === $site_host || str_ends_with( $link_host, '.' . $site_host ) ) ) {
                    return '<a href="' . esc_url( $url ) . '">' . esc_html( $anchor ) . '</a>';
                }
                return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $anchor ) . '</a>';
            },
            $content
        );
        if ( $result !== null ) $content = $result;

        // ── Pattern 3: Clean UTM params from existing <a href="..."> tags ──
        $result = preg_replace_callback(
            '/<a\s([^>]*href=["\'])(https?:\/\/[^"\']+)(["\'][^>]*)>/i',
            function( $m ) {
                $url = self::cocon_strip_ai_utm( $m[2] );
                return '<a ' . $m[1] . esc_url( $url ) . $m[3] . '>';
            },
            $content
        );
        if ( $result !== null ) $content = $result;

        // ── Pattern 4: Ensure all external links have target="_blank" rel="noopener" ──
        // Sprint 6.2d: $site_host already declared above; noopener only (noreferrer loses referrer analytics)
        $result = preg_replace_callback(
            '/<a\s+([^>]*href=["\']https?:\/\/(?!' . preg_quote( $site_host, '/' ) . ')[^"\']+["\'][^>]*)>/i',
            function( $m ) {
                $attrs = $m[1];
                if ( stripos( $attrs, 'target=' ) === false ) {
                    $attrs .= ' target="_blank"';
                }
                if ( stripos( $attrs, 'rel=' ) === false ) {
                    $attrs .= ' rel="noopener"';
                } elseif ( stripos( $attrs, 'noopener' ) === false ) {
                    $attrs = preg_replace( '/rel=["\']([^"\']*)["\']/', 'rel="$1 noopener"', $attrs );
                }
                return '<a ' . $attrs . '>';
            },
            $content
        );
        if ( $result !== null ) $content = $result;

        // ── Pattern 5: Remove redundant parenthesized citation links ──
        // AI often outputs: <a href="url">Source Name</a> (<a href="url?utm_source=openai">domain.com</a>)
        // The second <a> in parentheses is redundant — remove it, keep only the first.
        $result = preg_replace(
            '/\s*\(<a\s[^>]*href=["\']https?:\/\/[^"\']*(?:\?[^"\']*utm_source=(?:openai|perplexity|chatgpt|anthropic|claude)[^"\']*)["\'][^>]*>[^<]*<\/a>\)/',
            '',
            $content
        );
        if ( $result !== null ) $content = $result;

        // ── Pattern 6 (Sprint 6.2d): Clean internal links — strip rel and target="_self" ──
        $content = self::fix_internal_link_attrs( $content );

        if ( $fixed_count > 0 ) {
 self::cocon_log( 'links_fixed', ' ' . $fixed_count . ' liens markdown → HTML', array( 'count' => $fixed_count ) );
        }

        return $content;
    }

    /**
     * Strip AI-injected UTM parameters from URLs
     */
    private static function cocon_strip_ai_utm( $url ) {
        // Remove utm_source=openai, utm_source=perplexity, utm_source=chatgpt, etc.
        $url = preg_replace( '/[?&]utm_source=(openai|perplexity|chatgpt|anthropic|claude)/', '', $url );
        // Clean leftover ? or & at end
        $url = rtrim( $url, '?&' );
        // Fix ?& → ?
        $url = str_replace( '?&', '?', $url );
        return $url;
    }

    /**
     * Sprint 6.2d: Strip useless attributes from internal links.
     *
     * Removes rel="noopener noreferrer" / rel="noopener" and target="_self"
     * from internal <a> tags. These attributes are only meaningful for
     * target="_blank" (external) links. AI models and Content Writer
     * sometimes add them on internal links.
     *
     * @since 2.5.0
     * @param string $content HTML content
     * @return string Cleaned content
     */
    public static function fix_internal_link_attrs( $content ) {
        if ( empty( $content ) ) return $content;

        $site_host = parse_url( get_site_url(), PHP_URL_HOST );
        if ( ! $site_host ) return $content;

        // Match internal links: href starts with site host OR relative path (not //)
        $result = preg_replace_callback(
            '/<a\s+([^>]*href=["\'](?:https?:\/\/' . preg_quote( $site_host, '/' ) . '|\/(?!\/))' . '[^"\']*["\'][^>]*)>/i',
            function( $m ) {
                $attrs = $m[1];
                // Remove target="_self" (default, redundant)
                $attrs = preg_replace( '/\s*target=["\']_self["\']/i', '', $attrs );
                // Remove rel="noopener noreferrer" or rel="noopener" (meaningless without _blank)
                $attrs = preg_replace( '/\s*rel=["\']noopener(?:\s+noreferrer)?["\']/i', '', $attrs );
                // If rel has other values mixed with noopener, just strip noopener/noreferrer parts
                $attrs = preg_replace_callback( '/rel=["\']([^"\']*)["\']/', function( $rm ) {
                    $vals = preg_replace( '/\b(?:noopener|noreferrer)\b/', '', $rm[1] );
                    $vals = trim( preg_replace( '/\s+/', ' ', $vals ) );
                    return $vals ? 'rel="' . $vals . '"' : '';
                }, $attrs );
                $attrs = trim( preg_replace( '/\s+/', ' ', $attrs ) );
                return '<a ' . $attrs . '>';
            },
            $content
        );

        return ( $result !== null ) ? $result : $content;
    }

    /* ═══════════════════════════════════════════════════════════
     *  INLINE JSON-LD SCHEMA BUILDER (v2.7.3)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Build JSON-LD schemas to inject directly into post content.
     * These complement (not duplicate) what Yoast/RankMath generate.
     *
     * Generates: FAQPage, Article enrichments (about, speakable, mentions)
     *
     * @return string HTML comment + <script type="application/ld+json"> blocks, or empty
     */
    public static function cocon_build_inline_schemas( $post_id, $title, $keyword, $content ) {
        $schemas = array();
        $detected = get_post_meta( $post_id, '_hts_schemas_predetected', true );
        if ( ! is_array( $detected ) ) $detected = array();

        $enrichments = get_post_meta( $post_id, '_hts_schema_enrichments', true );
        if ( ! is_array( $enrichments ) ) $enrichments = array();

        $permalink = get_permalink( $post_id );
        $site_name = get_bloginfo( 'name' );

        // ── FAQPage schema (from <details><summary> blocks) ──
        if ( in_array( 'FAQPage', $detected ) ) {
            $faqs = array();
            if ( preg_match_all( '/<details[^>]*>\s*<summary[^>]*>(.*?)<\/summary>(.*?)<\/details>/si', $content, $faq_matches, PREG_SET_ORDER ) ) {
                foreach ( $faq_matches as $fm ) {
                    $question = wp_strip_all_tags( $fm[1] );
                    $answer   = wp_strip_all_tags( $fm[2] );
                    $question = html_entity_decode( trim( $question ), ENT_QUOTES, 'UTF-8' );
                    $answer   = html_entity_decode( trim( $answer ), ENT_QUOTES, 'UTF-8' );
                    if ( mb_strlen( $question ) >= 5 && mb_strlen( $answer ) >= 20 ) {
                        if ( mb_strlen( $answer ) > 300 ) $answer = mb_substr( $answer, 0, 297 ) . '...';
                        $faqs[] = array(
                            '@type'          => 'Question',
                            'name'           => $question,
                            'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $answer ),
                        );
                    }
                }
            }
            if ( count( $faqs ) >= 2 ) {
                $schemas[] = array(
                    '@context'   => 'https://schema.org',
                    '@type'      => 'FAQPage',
                    'mainEntity' => $faqs,
                );
            }
        }

        // ── Article enrichment schema (about, mentions, speakable, keywords) ──
        $article_schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Article',
            'headline'    => $title,
            'url'         => $permalink ?: '',
            'keywords'    => $keyword,
            'inLanguage'  => 'fr',
            'publisher'   => array(
                '@type' => 'Organization',
                'name'  => $site_name,
                'url'   => get_site_url(),
            ),
        );

        if ( ! empty( $enrichments['about'] ) ) {
            $article_schema['about'] = $enrichments['about'];
        }

        if ( ! empty( $enrichments['mentions'] ) ) {
            $article_schema['mentions'] = $enrichments['mentions'];
        }

        if ( ! empty( $enrichments['wordCount'] ) ) {
            $article_schema['wordCount'] = (int) $enrichments['wordCount'];
        }

        // Speakable (first 2 paragraphs → Google Assistant + AI citation priority)
        if ( ! empty( $enrichments['speakable'] ) ) {
            $article_schema['speakable'] = array(
                '@type'       => 'SpeakableSpecification',
                'cssSelector' => array( 'article p:nth-of-type(1)', 'article p:nth-of-type(2)' ),
            );
        }

        // Featured image
        $thumb_url = get_the_post_thumbnail_url( $post_id, 'full' );
        if ( $thumb_url ) {
            $article_schema['image'] = $thumb_url;
            $article_schema['thumbnailUrl'] = $thumb_url;
        }

        $schemas[] = $article_schema;

        // ── Build HTML output ──
        if ( empty( $schemas ) ) return '';

        $schema_names = array();
        foreach ( $schemas as $s ) {
            $schema_names[] = $s['@type'] ?? 'Unknown';
        }

        $html = "\n\n<!-- HackTheSEO Schema Injection (" . implode( ', ', $schema_names ) . ") -->\n";
        foreach ( $schemas as $s ) {
            $html .= '<script type="application/ld+json">';
            $html .= wp_json_encode( $s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            $html .= "</script>\n";
        }

        return $html;
    }

    /* ═══════════════════════════════════════════════════════════
     *  SCHEMA PRE-DETECTION + ENRICHMENT (v2.7.2)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Pre-detect schema types in content at draft creation time.
     * Stores hints in post_meta so the frontend schema module (class-hts-schema-markup.php)
     * can render them without re-parsing, and the dashboard shows which schemas each article gets.
     *
     * Also injects additional structured data that Yoast/RankMath don't generate:
     * - Article.about (from keyword)
     * - Article.mentions (from internal links)
     * - Article.speakable (intro paragraph for Google Assistant + AI citations)
     * - Article.thumbnailUrl (from featured image)
     *
     * @return array List of detected schema types
     */
    public static function cocon_predetect_schemas( $post_id, $content, $title, $keyword ) {
        $detected = array();
        $schema_data = array();

        // ── FAQPage detection (details/summary + H3 questions) ──
        $faq_count = 0;
        // Method 1: <details><summary> blocks
        if ( preg_match_all( '/<details[^>]*>\s*<summary[^>]*>(.*?)<\/summary>(.*?)<\/details>/si', $content, $faq_matches ) ) {
            $faq_count += count( $faq_matches[0] );
        }
        // Method 2: H3/H4 ending with "?"
        if ( preg_match_all( '/<h[3-4][^>]*>[^<]*\?\s*<\/h[3-4]>/si', $content, $h_questions ) ) {
            $faq_count += count( $h_questions[0] );
        }
        if ( $faq_count >= 2 ) {
            $detected[] = 'FAQPage';
            $schema_data['faq_count'] = $faq_count;
        }

        // ── HowTo detection (numbered steps, "étape" patterns) ──
        $howto_patterns = array(
            '/<h[2-4][^>]*>.*?[EÉeé]tape\s*\d/si',
            '/<h[2-4][^>]*>.*?Step\s*\d/si',
            '/<ol[^>]*>.*?<li/si',
        );
        $howto_score = 0;
        foreach ( $howto_patterns as $p ) {
            if ( preg_match_all( $p, $content, $m ) ) {
                $howto_score += count( $m[0] );
            }
        }
        if ( $howto_score >= 3 ) {
            $detected[] = 'HowTo';
            $schema_data['howto_steps'] = $howto_score;
        }

        // ── ItemList detection (listicle patterns: "top X", "X meilleurs") ──
        if ( preg_match( '/\b(top|meilleur|best|\d+\s+(outils|méthodes|astuces|conseils|étapes|stratégies|exemples|types|avantages))/i', $title ) ) {
            // Verify there are actually H2/H3 list items
            if ( preg_match_all( '/<h[2-3][^>]*>/si', $content, $headings ) && count( $headings[0] ) >= 3 ) {
                $detected[] = 'ItemList';
                $schema_data['list_items'] = count( $headings[0] );
            }
        }

        // ── VideoObject detection (YouTube/Vimeo embeds) ──
        if ( preg_match( '/(youtube\.com|youtu\.be|vimeo\.com)/i', $content ) ) {
            $detected[] = 'VideoObject';
        }

        // ── Speakable — always on cocon articles (optimizes Google Assistant + AI citations) ──
        $detected[] = 'Speakable';

        // ── Table detection (comparative content = high GEO value) ──
        if ( preg_match_all( '/<table/i', $content, $tables ) ) {
            $schema_data['tables'] = count( $tables[0] );
            if ( count( $tables[0] ) >= 1 ) {
                $detected[] = 'Table';
            }
        }

        // ── Store schema pre-detection in post meta ──
        update_post_meta( $post_id, '_hts_schemas_predetected', $detected );
        update_post_meta( $post_id, '_hts_schemas_data', $schema_data );
        update_post_meta( $post_id, '_hts_cocon_article', 1 );

        // ── Store Article enrichments (what Yoast/RankMath don't generate) ──
        $enrichments = array();

        // about: keyword-based topic entity
        $enrichments['about'] = array(
            '@type' => 'Thing',
            'name'  => $keyword,
        );

        // mentions: extract internal link anchors
        if ( preg_match_all( '/<a[^>]+href=["\'][^"\']*' . preg_quote( parse_url( get_site_url(), PHP_URL_HOST ), '/' ) . '[^"\']*["\'][^>]*>(.*?)<\/a>/si', $content, $links ) ) {
            $mentions = array();
            foreach ( array_slice( $links[1], 0, 5 ) as $anchor ) {
                $anchor_text = wp_strip_all_tags( $anchor );
                if ( mb_strlen( $anchor_text ) > 3 ) {
                    $mentions[] = array( '@type' => 'Thing', 'name' => $anchor_text );
                }
            }
            if ( ! empty( $mentions ) ) {
                $enrichments['mentions'] = $mentions;
            }
        }

        // speakable: first 2 paragraphs (Google Assistant + AI extraction priority)
        if ( preg_match_all( '/<p[^>]*>(.*?)<\/p>/si', $content, $paragraphs ) ) {
            $speakable_text = '';
            foreach ( array_slice( $paragraphs[1], 0, 2 ) as $p ) {
                $speakable_text .= wp_strip_all_tags( $p ) . ' ';
            }
            $enrichments['speakable'] = trim( $speakable_text );
        }

        // wordCount for Article schema
        $enrichments['wordCount'] = hts_word_count( wp_strip_all_tags( $content ) );

        update_post_meta( $post_id, '_hts_schema_enrichments', $enrichments );

        // ── Log ──
        if ( ! empty( $detected ) ) {
 self::cocon_log( 'schema_detected', 'Schemas pré-détectés', array(
                'schemas' => implode( ', ', $detected ),
                'faq'     => $schema_data['faq_count'] ?? 0,
                'howto'   => $schema_data['howto_steps'] ?? 0,
            ) );
        }

        return $detected;
    }

    /**
     * Apply SEO metas to all detected SEO plugins (Yoast, Rank Math, SEOPress, native)
     * Uses the same detection pattern as SeoManager for consistency
     */
    public static function cocon_apply_seo_metas( $post_id, $data ) {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $metatitle = $data['metatitle'] ?? '';
        $metadesc  = $data['metadescription'] ?? '';
        $keyword   = $data['keyword'] ?? '';

        // ── Yoast SEO ──
        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            if ( ! empty( $metatitle ) ) update_post_meta( $post_id, '_yoast_wpseo_title', $metatitle );
            if ( ! empty( $metadesc ) )  update_post_meta( $post_id, '_yoast_wpseo_metadesc', $metadesc );
            if ( ! empty( $keyword ) )   update_post_meta( $post_id, '_yoast_wpseo_focuskw', $keyword );
            // Clear Yoast indexable cache
            if ( class_exists( 'Yoast\WP\SEO\Repositories\Indexable_Repository' ) ) {
                delete_post_meta( $post_id, '_yoast_wpseo_estimated-reading-time-minutes' );
            }
        }

        // ── Rank Math ──
        if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            if ( ! empty( $metatitle ) ) update_post_meta( $post_id, 'rank_math_title', $metatitle );
            if ( ! empty( $metadesc ) )  update_post_meta( $post_id, 'rank_math_description', $metadesc );
            if ( ! empty( $keyword ) )   update_post_meta( $post_id, 'rank_math_focus_keyword', $keyword );
        }

        // ── SEOPress ──
        if ( is_plugin_active( 'wp-seopress/seopress.php' ) || is_plugin_active( 'wp-seopress-pro/seopress-pro.php' ) ) {
            if ( ! empty( $metatitle ) ) update_post_meta( $post_id, '_seopress_titles_title', $metatitle );
            if ( ! empty( $metadesc ) )  update_post_meta( $post_id, '_seopress_titles_desc', $metadesc );
            if ( ! empty( $keyword ) )   update_post_meta( $post_id, '_seopress_analysis_target_kw', $keyword );
        }

        // ── All in One SEO ──
        if ( is_plugin_active( 'all-in-one-seo-pack/all_in_one_seo_pack.php' ) || defined( 'AIOSEO_VERSION' ) ) {
            if ( ! empty( $metatitle ) ) update_post_meta( $post_id, '_aioseo_title', $metatitle );
            if ( ! empty( $metadesc ) )  update_post_meta( $post_id, '_aioseo_description', $metadesc );
            if ( ! empty( $keyword ) )   update_post_meta( $post_id, '_aioseo_keywords', $keyword );
        }

        // ── Natif (aucun plugin SEO détecté) ──
        $has_seo_plugin = is_plugin_active( 'wordpress-seo/wp-seo.php' )
            || is_plugin_active( 'seo-by-rank-math/rank-math.php' )
            || is_plugin_active( 'wp-seopress/seopress.php' )
            || is_plugin_active( 'wp-seopress-pro/seopress-pro.php' )
            || defined( 'AIOSEO_VERSION' );

        if ( ! $has_seo_plugin ) {
            if ( ! empty( $metatitle ) ) update_post_meta( $post_id, '_meta_title', $metatitle );
            if ( ! empty( $metadesc ) )  update_post_meta( $post_id, '_meta_description', $metadesc );
            if ( ! empty( $keyword ) )   update_post_meta( $post_id, '_meta_keywords', $keyword );
        }

        // ── Always store HTS internal reference ──
        update_post_meta( $post_id, '_hts_seo_meta_title', $metatitle );
        update_post_meta( $post_id, '_hts_seo_meta_desc', $metadesc );
    }

    /* ═══════════════════════════════════════════════════════════
     *  BRAND IDENTITY — Colors + Style for AI Image Generation (v2.7.0)
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Get brand identity settings
     */
    public static function get_brand_identity() {
        return get_option( 'hts_brand_identity', array(
            'primary_color'   => '#2563eb',
            'secondary_color' => '#f59e0b',
            'accent_color'    => '#10b981',
            'style'           => 'modern',
            'font_style'      => 'sans-serif',
            'logo_url'        => '',
            'brand_name'      => get_bloginfo( 'name' ),
        ) );
    }

    /** AJAX: Save brand identity settings */
    public function ajax_save_brand_identity() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $identity = array(
            'primary_color'   => sanitize_hex_color( $_POST['primary_color'] ?? '#2563eb' ),
            'secondary_color' => sanitize_hex_color( $_POST['secondary_color'] ?? '#f59e0b' ),
            'accent_color'    => sanitize_hex_color( $_POST['accent_color'] ?? '#10b981' ),
            'style'           => sanitize_text_field( $_POST['style'] ?? 'modern' ),
            'font_style'      => sanitize_text_field( $_POST['font_style'] ?? 'sans-serif' ),
            'logo_url'        => esc_url_raw( $_POST['logo_url'] ?? '' ),
            'brand_name'      => sanitize_text_field( $_POST['brand_name'] ?? get_bloginfo( 'name' ) ),
        );

        // Also save default author if provided
        if ( isset( $_POST['default_author'] ) ) {
            update_option( 'hts_default_author', (int) $_POST['default_author'], false );
        }

        update_option( 'hts_brand_identity', $identity, false );
 wp_send_json_success( array( 'message' => 'Identité visuelle enregistrée ' ) );
    }

    /** Get image generation settings with defaults.
     *  Merges from 3 sources (priority order):
     *    1. hts_image_settings option (main source of truth)
     *    2. Agent 'image' settings in hts_workflow_agents table (synced on save)
     *    3. Hardcoded defaults
     */
    public static function get_image_settings() {
        $defaults = array(
            'image_provider'        => 'openai',
            'openai_model'          => 'gpt-image-1',
            'flux_api_key'          => '',
            'flux_model'            => 'flux-2-pro',
            'flux_safety_tolerance' => 3,
            'featured_enabled'      => true,
            'featured_source'       => 'ai',
            'featured_style'        => 'illustration',
            'featured_quality'      => 'medium',
            'featured_text_overlay' => 'none',
            'incontent_enabled'     => true,
            'incontent_count'       => 2,
            'incontent_position'    => 'after_h2_p',
            'incontent_quality'     => 'medium',
            'incontent_types'       => 'mixed',
            'extra_instructions'    => '',
            'pexels_api_key'        => '',
        );

        $opts = get_option( 'hts_image_settings', array() );

        // ── Merge from agent table if keys are empty in option ──
        // This covers the case where the user saved via the Agents panel
        // but the sync to hts_image_settings failed or was never triggered.
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $agent_settings = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'image' );
            if ( is_array( $agent_settings ) ) {
                foreach ( $agent_settings as $ak => $av ) {
                    // Only fill in if the option is empty/missing and agent has a value
                    if ( ( ! isset( $opts[ $ak ] ) || $opts[ $ak ] === '' || $opts[ $ak ] === null ) && $av !== '' && $av !== null ) {
                        $opts[ $ak ] = $av;
                    }
                }
            }
        }

        $settings = wp_parse_args( $opts, $defaults );

        return apply_filters( 'hts_image_settings', $settings );
    }

    /**
     * Handle deferred image generation (called via WP Cron, 10-60s after draft creation).
     * Generates images + runs cross-linking that couldn't run during the AJAX call.
     *
     * @param int    $post_id  WordPress post ID
     * @param string $title    Article title
     * @param string $keyword  Target keyword
     */
    public static function handle_deferred_images( $post_id, $title, $keyword ) {
        // ── Sprint Robustesse: wait for articles to finish generating first ──
        $generating = (int) get_transient( 'hts_articles_generating' );
        if ( $generating > 0 ) {
            // Reschedule 60s later — let articles finish first
            if ( ! wp_next_scheduled( 'hts_deferred_images', array( $post_id, $title, $keyword ) ) ) {
                wp_schedule_single_event( time() + 60, 'hts_deferred_images', array( $post_id, $title, $keyword ) );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( '⏳ Images reportées #' . $post_id . ' — ' . $generating . ' article(s) en cours', 'info', 'cocon' );
            }
            return;
        }

        // ── Set heavy job lock (images + Flux API can be long) ──
        set_transient( 'hts_heavy_job_running', 'deferred_images', 600 );

        // ── Extend PHP timeout if possible (not available on shared hosting) ──
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time < 300 ) {
            @set_time_limit( 300 );
        }

        // Guard: check post still exists and is a draft
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'draft', 'pending', 'future' ), true ) ) {
            delete_post_meta( $post_id, '_hts_images_pending' );
            return;
        }

        // Guard: check not already processed
        if ( ! get_post_meta( $post_id, '_hts_images_pending', true ) ) {
            return;
        }

        // ── Stale flag protection: if pending for > 30 min, something crashed last time ──
        $pending_since = get_post_meta( $post_id, '_hts_images_pending_since', true );
        if ( $pending_since && ( time() - (int) $pending_since ) > 1800 ) {
            // Stale: previous cron crashed — clean up and retry
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( '⚠️ Flag images_pending stale pour #' . $post_id . ' (>' . round( ( time() - (int) $pending_since ) / 60 ) . ' min) — retry', 'warning', 'cocon' );
            }
        }
        // CRON1: Ne pas rafraîchir le timer si déjà en cours (sinon stale jamais détecté)
        if ( ! get_post_meta( $post_id, '_hts_images_pending_since', true ) ) {
            update_post_meta( $post_id, '_hts_images_pending_since', time() );
        }

        $content = $post->post_content;

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( '🎨 Démarrage images différées pour #' . $post_id . ' (' . $keyword . ')', 'info', 'cocon' );
        }

        // ── Generate images (with error protection) ──
        // Skip image generation if agent was disabled at schedule time (cross-linking still runs below)
        $images_result = array( 'count' => 0, 'images' => array() );
        $skip_images = (bool) get_post_meta( $post_id, '_hts_skip_image_gen', true );
        if ( $skip_images ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( '⏭️ Images IA désactivées pour #' . $post_id . ' — maillage seul', 'info', 'cocon' );
            }
            delete_post_meta( $post_id, '_hts_skip_image_gen' );
        } else {
            try {
                // Note: cocon_generate_article_images() handles wp_update_post internally
                $images_result = self::cocon_generate_article_images( $post_id, $title, $keyword, $content );
            } catch ( \Exception $e ) {
                self::cocon_log( 'image_error', '❌ Exception images différées: ' . $e->getMessage(), array( 'post_id' => $post_id ) );
            } catch ( \Error $e ) {
                self::cocon_log( 'image_error', '❌ Fatal error images différées: ' . $e->getMessage(), array( 'post_id' => $post_id ) );
            }
        }

        // ── Sprint 6.2d: Defer cross-linking to separate cron (avoids 2min+ blocking in pseudo-cron) ──
        // Cross-linking involves multiple OpenAI API calls (30-80s) — running it synchronously
        // inside handle_deferred_images causes WP pseudo-cron to block polling AJAX requests.
        if ( ! wp_next_scheduled( 'hts_deferred_cross_interlink', array( $post_id ) ) ) {
            wp_schedule_single_event( time() + 30, 'hts_deferred_cross_interlink', array( $post_id ) );
        }
        $cross_links = array( 'outbound' => 0, 'inbound' => 0 );

        // ── Sprint 6.2c: Final cleanup after all content modifications ──
        $post_final = get_post( $post_id );
        if ( $post_final ) {
            $final_content = $post_final->post_content;
            $content_changed = false;

            // A. Clean UTM params from all <a> href attributes
            $cleaned = preg_replace_callback(
                '/<a\s([^>]*href=["\'])(https?:\/\/[^"\']+)(["\'][^>]*)>/i',
                function( $m ) {
                    $url = preg_replace( '/[?&]utm_source=(openai|perplexity|chatgpt|anthropic|claude)/', '', $m[2] );
                    $url = rtrim( $url, '?&' );
                    $url = str_replace( '?&', '?', $url );
                    return '<a ' . $m[1] . esc_url( $url ) . $m[3] . '>';
                },
                $final_content
            );
            if ( $cleaned !== null && $cleaned !== $final_content ) {
                $final_content = $cleaned;
                $content_changed = true;
            }

            // B. Remove redundant parenthesized citation links: (<a href="...?utm_source=...">domain</a>)
            $cleaned2 = preg_replace(
                '/\s*\(<a\s[^>]*href=["\']https?:\/\/[^"\']+["\'][^>]*>[^<]*<\/a>\)/',
                '',
                $final_content
            );
            if ( $cleaned2 !== null && $cleaned2 !== $final_content ) {
                $final_content = $cleaned2;
                $content_changed = true;
            }

            // C. Auto-inject money page link if missing
            $cocon_id_final = get_post_meta( $post_id, '_hts_cocon_id', true );
            if ( $cocon_id_final && class_exists( 'HTS_Cocon_Commander' ) ) {
                $money_id = get_post_meta( $post_id, '_hts_money_target', true );
                if ( ! $money_id ) {
                    // Search for money page in NLP clusters
                    $lang = '';
                    if ( class_exists( 'HTS_Language' ) && method_exists( 'HTS_Language', 'get_current_lang' ) ) {
                        $lang = \HTS_Language::get_current_lang();
                    }
                    $cd = $lang ? get_option( 'hts_cocon_data_' . $lang, array() ) : get_option( 'hts_cocon_data', array() );
                    if ( empty( $cd ) && $lang ) $cd = get_option( 'hts_cocon_data', array() );
                    foreach ( $cd['clusters'] ?? array() as $cl_f ) {
                        $cpages = array_map( 'intval', $cl_f['pages'] ?? array() );
                        $in_cl = in_array( $post_id, $cpages, true );
                        if ( ! $in_cl ) {
                            foreach ( $cpages as $chk ) {
                                if ( get_post_meta( $chk, '_hts_cocon_id', true ) === $cocon_id_final ) { $in_cl = true; break; }
                            }
                        }
                        if ( ! $in_cl ) continue;
                        foreach ( $cpages as $cpid ) {
                            if ( $cpid !== $post_id && get_post_meta( $cpid, '_hts_money_page', true ) ) {
                                $money_id = $cpid; break 2;
                            }
                        }
                        break;
                    }
                }
                if ( $money_id ) {
                    $mp = get_post( (int) $money_id );
                    if ( $mp ) {
                        $mp_url = get_permalink( $mp->ID );
                        $mp_rel = wp_make_link_relative( $mp_url );
                        $has_mp = ( strpos( $final_content, $mp_url ) !== false );
                        if ( ! $has_mp && $mp_rel ) $has_mp = ( strpos( $final_content, $mp_rel ) !== false );
                        if ( ! $has_mp ) {
                            $mp_kw   = get_post_meta( $mp->ID, '_hts_focus_keyword', true ) ?: $mp->post_title;
                            $mp_anch = $mp_kw;
                            $mp_html = '<a href="' . esc_url( $mp_url ) . '" data-hts="money" title="' . esc_attr( $mp->post_title ) . '">' . esc_html( $mp_anch ) . '</a>';

                            // Insert after first <h2> or at end of first paragraph
                            $inserted = false;
                            // Try after second </p>
                            $p_pos = strpos( $final_content, '</p>' );
                            if ( $p_pos !== false ) {
                                $p_pos2 = strpos( $final_content, '</p>', $p_pos + 4 );
                                if ( $p_pos2 !== false ) {
                                    $insert_at = $p_pos2 + 4;
                                    $bridge = "\nDécouvrez également " . $mp_html . ".\n";
                                    $final_content = substr( $final_content, 0, $insert_at ) . $bridge . substr( $final_content, $insert_at );
                                    $inserted = true;
                                }
                            }
                            if ( ! $inserted ) {
                                // Fallback: append before last </p>
                                $last_p = strrpos( $final_content, '</p>' );
                                if ( $last_p !== false ) {
                                    $bridge = " Découvrez également " . $mp_html . ".";
                                    $final_content = substr( $final_content, 0, $last_p ) . $bridge . substr( $final_content, $last_p );
                                    $inserted = true;
                                }
                            }
                            if ( $inserted ) {
                                $content_changed = true;
                                if ( function_exists( 'hts_add_log' ) ) {
                                    hts_add_log( sprintf( '💰 Money link injecté (deferred) #%d → « %s »', $post_id, mb_substr( $mp->post_title, 0, 40 ) ), 'success', 'cocon' );
                                }
                            }
                        }
                    }
                }
            }

            // Sprint 6.2d: ALWAYS clean internal link attributes (AI puts rel="noopener noreferrer" on internals)
            $cleaned_content = self::fix_internal_link_attrs( $final_content );
            if ( $cleaned_content !== $final_content ) {
                $final_content = $cleaned_content;
                $content_changed = true;
            }

            if ( $content_changed ) {
                wp_update_post( array( 'ID' => $post_id, 'post_content' => $final_content ) );
            }
        }

        // ── ALWAYS clean up pending flag (even on error) ──
        delete_post_meta( $post_id, '_hts_images_pending' );
        delete_post_meta( $post_id, '_hts_images_pending_since' );
        update_post_meta( $post_id, '_hts_deferred_images_done', current_time( 'Y-m-d H:i:s' ) );

        // Fix 2: Compter les images (inline + featured) et stocker le compteur
        $post_after = get_post( $post_id );
        $inline_count = $post_after ? preg_match_all( '/<img[^>]+>/i', $post_after->post_content ) : 0;
        $has_thumb = (bool) get_post_meta( $post_id, '_thumbnail_id', true );
        update_post_meta( $post_id, '_hts_image_count', $inline_count + ( $has_thumb ? 1 : 0 ) );

        // Sprint Robustesse: release heavy job lock
        delete_transient( 'hts_heavy_job_running' );

        if ( function_exists( 'hts_add_log' ) ) {
            $cl_total = ( $cross_links['outbound'] ?? 0 ) + ( $cross_links['inbound'] ?? 0 );
            hts_add_log( '✅ Images différées terminées #' . $post_id . ' : ' . ( $images_result['count'] ?? 0 ) . ' image(s) + ' . $cl_total . ' lien(s)', 'info', 'cocon' );
        }
    }

    /**
     * Sprint 6.2d: Deferred cross-linking cron handler.
     * Runs 30s after handle_deferred_images to avoid blocking pseudo-cron.
     *
     * @since 2.5.1
     * @param int $post_id
     */
    public static function handle_deferred_cross_interlink( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status === 'trash' ) return;

        // Sprint Robustesse: if articles are still generating, reschedule
        $generating = (int) get_transient( 'hts_articles_generating' );
        if ( $generating > 0 ) {
            if ( ! wp_next_scheduled( 'hts_deferred_cross_interlink', array( $post_id ) ) ) {
                wp_schedule_single_event( time() + 90, 'hts_deferred_cross_interlink', array( $post_id ) );
            }
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( '⏳ Cross-linking reporté pour #' . $post_id . ' — ' . $generating . ' article(s) en cours', 'info', 'interlink' );
            }
            return;
        }

        try {
            $cross_links = self::cocon_cross_interlink( $post_id, true );
            $total = ( $cross_links['outbound'] ?? 0 ) + ( $cross_links['inbound'] ?? 0 );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( '🔗 Cross-linking différé terminé #%d : %d lien(s)', $post_id, $total ),
                    'info', 'interlink'
                );
            }
        } catch ( \Exception $e ) {
            self::cocon_log( 'interlink_error', '❌ Exception cross-linking différé: ' . $e->getMessage(), array( 'post_id' => $post_id ) );
        } catch ( \Error $e ) {
            self::cocon_log( 'interlink_error', '❌ Fatal error cross-linking différé: ' . $e->getMessage(), array( 'post_id' => $post_id ) );
        }
    }

    /** AJAX: Save image generation settings */
    public function ajax_save_image_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $allowed_styles  = array( 'illustration', 'photo_realistic', 'infographic', '3d_render', 'watercolor', 'minimalist', 'isometric' );
        $allowed_types   = array( 'illustration', 'photo_realistic', '3d_render', 'watercolor', 'minimalist', 'isometric', 'infographic', 'schema_diagram' );
        $allowed_quality = array( 'low', 'medium', 'high', 'standard', 'hd' ); // accept legacy values too
        $allowed_providers    = array( 'openai', 'flux' );
        $allowed_openai_models = array( 'gpt-image-1', 'gpt-image-1-mini', 'gpt-image-1.5', 'dall-e-3' );
        $allowed_flux_models  = array( 'flux-2-pro', 'flux-2-max', 'flux-2-klein-9b', 'flux-2-klein-4b', 'flux-2-flex' );

        $types_raw = isset( $_POST['incontent_types'] ) && is_array( $_POST['incontent_types'] )
            ? array_intersect( array_map( 'sanitize_text_field', $_POST['incontent_types'] ), $allowed_types )
            : array( 'illustration' );

        // Preserve fields that may not be in the form (no UI yet or all unchecked)
        $existing = self::get_image_settings();

        $settings = array(
            'image_provider'        => in_array( $_POST['image_provider'] ?? '', $allowed_providers ) ? $_POST['image_provider'] : 'openai',
            'openai_model'          => in_array( $_POST['openai_model'] ?? '', $allowed_openai_models ) ? $_POST['openai_model'] : 'gpt-image-1',
            'flux_api_key'          => sanitize_text_field( $_POST['flux_api_key'] ?? '' ),
            'flux_model'            => in_array( $_POST['flux_model'] ?? '', $allowed_flux_models ) ? $_POST['flux_model'] : 'flux-2-pro',
            'flux_safety_tolerance' => max( 1, min( 6, (int) ( $_POST['flux_safety_tolerance'] ?? 3 ) ) ),
            'featured_enabled'      => ( $_POST['featured_enabled'] ?? '1' ) === '1',
            'featured_source'       => in_array( $_POST['featured_source'] ?? '', array( 'ai', 'pexels', 'both' ) ) ? $_POST['featured_source'] : 'ai',
            'featured_style'        => in_array( $_POST['featured_style'] ?? '', $allowed_styles ) ? $_POST['featured_style'] : 'illustration',
            'featured_quality'      => in_array( $_POST['featured_quality'] ?? '', $allowed_quality ) ? $_POST['featured_quality'] : 'medium',
            'featured_text_overlay' => in_array( $_POST['featured_text_overlay'] ?? '', array( 'none', 'title', 'keyword', 'brand' ) ) ? $_POST['featured_text_overlay'] : 'none',
            'incontent_enabled'     => ( $_POST['incontent_enabled'] ?? '1' ) === '1',
            'incontent_count'       => max( 1, min( 5, (int) ( $_POST['incontent_count'] ?? 2 ) ) ),
            'incontent_position'    => isset( $_POST['incontent_position'] ) && in_array( $_POST['incontent_position'], array( 'after_h2', 'after_h2_p', 'mid_section' ) )
                                        ? $_POST['incontent_position'] : ( $existing['incontent_position'] ?? 'after_h2_p' ),
            'incontent_quality'     => in_array( $_POST['incontent_quality'] ?? '', $allowed_quality ) ? $_POST['incontent_quality'] : 'medium',
            'incontent_types'       => ! empty( $types_raw ) ? array_values( $types_raw ) : ( $existing['incontent_types'] ?? array( 'illustration' ) ),
            'extra_instructions'    => mb_substr( sanitize_textarea_field( $_POST['extra_instructions'] ?? '' ), 0, 500 ),
            'pexels_api_key'        => sanitize_text_field( $_POST['pexels_api_key'] ?? '' ),
        );

        // Also save default author if provided in this form
        if ( isset( $_POST['default_author'] ) ) {
            update_option( 'hts_default_author', (int) $_POST['default_author'], false );
        }

        update_option( 'hts_image_settings', $settings, false );
 wp_send_json_success( array( 'message' => 'Configuration images enregistrée ' ) );
    }

    /** AJAX: Save cross-cocon interlinking toggle */
    public function ajax_save_cross_interlink() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $enabled = ( $_POST['enabled'] ?? '0' ) === '1' ? '1' : '0';
        update_option( 'hts_cross_interlink_enabled', $enabled, false );
        wp_send_json_success();
    }

    /**
     * AJAX: Test BFL (Black Forest Labs) Flux API key.
     * Checks credits via the /me endpoint.
     */
    public function ajax_test_flux_key() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $key = sanitize_text_field( $_POST['flux_api_key'] ?? '' );
        if ( empty( $key ) ) {
            wp_send_json_error( array( 'message' => 'Clé API vide' ) );
        }

        // BFL has no /me endpoint — test by submitting a tiny request to the cheapest model
        // A malformed request with valid key returns 422 (Unprocessable), invalid key returns 401/403
        $response = wp_remote_post( 'https://api.bfl.ai/v1/flux-2-klein-4b', array(
            'timeout' => 15,
            'headers' => array(
                'x-key'        => $key,
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ),
            // Send invalid dimensions on purpose — just testing auth
            'body' => wp_json_encode( array( 'prompt' => 'test', 'width' => 64, 'height' => 64 ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( array( 'message' => $response->get_error_message() ) );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 401 || $code === 403 ) {
            wp_send_json_error( array( 'message' => 'Clé invalide ou non autorisée (HTTP ' . $code . ')' ) );
        } elseif ( $code === 402 ) {
            // Payment required = key is valid but no credits
            wp_send_json_success( array( 'message' => 'Clé valide — mais solde insuffisant. Ajoutez des crédits sur dashboard.bfl.ai' ) );
        } elseif ( $code === 200 && ! empty( $body['id'] ) ) {
            // Request accepted = key valid + has credits (we'll discard the result)
            wp_send_json_success( array( 'message' => 'Clé valide ✓ — connexion OK' ) );
        } elseif ( $code === 422 ) {
            // Validation error = auth passed, just bad params = key is valid
            wp_send_json_success( array( 'message' => 'Clé valide ✓ — connexion OK' ) );
        } else {
            // Any other response with 2xx or 4xx that isn't 401/403 means auth passed
            if ( $code >= 200 && $code < 500 && $code !== 401 && $code !== 403 ) {
                wp_send_json_success( array( 'message' => 'Clé valide ✓ (HTTP ' . $code . ')' ) );
            }
            wp_send_json_error( array( 'message' => 'HTTP ' . $code . ' — ' . ( $body['detail'] ?? $body['message'] ?? 'Erreur serveur BFL' ) ) );
        }
    }

    // ═══════════════════════════════════════════════════════════
    // ══  TEST IMAGE GENERATION (Agents panel)  ════════════════
    // ═══════════════════════════════════════════════════════════

    /**
     * AJAX: Generate a single test image using the current provider/model settings.
     * Returns the image URL, elapsed time, provider, model and prompt used.
     */
    public function ajax_test_image_generate() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Permission refusée' ) );

        @set_time_limit( 180 );

        $img_cfg  = self::get_image_settings();
        $provider = $img_cfg['image_provider'] ?? 'openai';
        $prompt   = sanitize_text_field( $_POST['prompt'] ?? '' );

        // Auto-prompt if empty
        if ( empty( $prompt ) ) {
            $site_name = get_bloginfo( 'name' );
            $site_desc = get_bloginfo( 'description' );
            $prompt = "Editorial illustration. Subject: a modern visual representing the brand \"{$site_name}\". "
                . ( ! empty( $site_desc ) ? "Context: {$site_desc}. " : '' )
                . "Clean composition, professional look, soft natural lighting. Landscape 16:9. "
                . "Object-focused composition, depopulated scene. Clean visual, sharp focus, pure imagery without any typography or watermarks.";
        }

        $start = microtime( true );

        if ( $provider === 'flux' ) {
            $flux_key = $img_cfg['flux_api_key'] ?? '';
            if ( empty( $flux_key ) ) {
                wp_send_json_error( array( 'message' => "Provider Flux sélectionné mais clé API BFL manquante.\n\nVérifiez que la clé est bien enregistrée dans les réglages ci-dessus, puis cliquez « Enregistrer » avant de tester." ) );
            }
            $model  = $img_cfg['flux_model'] ?? 'flux-2-pro';
            $result = self::flux_generate_image( $prompt, 1024, 576, $model, 'jpeg' ); // 16:9 landscape

            if ( is_wp_error( $result ) ) {
                wp_send_json_error( array( 'message' => 'Flux: ' . $result->get_error_message() ) );
            }

            $elapsed = round( microtime( true ) - $start, 1 );
            $costs   = array( 'flux-2-pro' => '0.03', 'flux-2-max' => '0.07', 'flux-2-klein-9b' => '0.015', 'flux-2-klein-4b' => '0.014', 'flux-2-flex' => '0.05' );

            wp_send_json_success( array(
                'url'         => $result['url'] ?? '',
                'prompt_used' => $prompt,
                'provider'    => 'Flux (BFL)',
                'model'       => $model,
                'elapsed'     => $elapsed,
                'cost'        => $costs[ $model ] ?? '?',
            ) );

        } else {
            // OpenAI
            $openai_key = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : '';
            if ( empty( $openai_key ) ) {
                wp_send_json_error( array( 'message' => 'Clé OpenAI manquante' ) );
            }
            $model = $img_cfg['openai_model'] ?? 'gpt-image-1';

            $body = array(
                'model'  => $model,
                'prompt' => $prompt,
                'n'      => 1,
                'size'   => '1536x1024',
            );
            if ( $model === 'dall-e-3' ) {
                $body['size']    = '1792x1024';
                $body['quality'] = 'standard';
            }

            $response = wp_remote_post( 'https://api.openai.com/v1/images/generations', array(
                'timeout' => 120,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $openai_key,
                    'Content-Type'  => 'application/json',
                ),
                'body' => wp_json_encode( $body ),
            ) );

            if ( is_wp_error( $response ) ) {
                wp_send_json_error( array( 'message' => 'OpenAI: ' . $response->get_error_message() ) );
            }

            $code = wp_remote_retrieve_response_code( $response );
            $data = json_decode( wp_remote_retrieve_body( $response ), true );

            if ( $code !== 200 || empty( $data['data'][0] ) ) {
                $err = $data['error']['message'] ?? ( 'HTTP ' . $code );
                wp_send_json_error( array( 'message' => 'OpenAI: ' . $err ) );
            }

            $img_url = $data['data'][0]['url'] ?? ( $data['data'][0]['b64_json'] ? 'data:image/png;base64,' . $data['data'][0]['b64_json'] : '' );
            $elapsed = round( microtime( true ) - $start, 1 );

            wp_send_json_success( array(
                'url'         => $img_url,
                'prompt_used' => $prompt,
                'provider'    => 'OpenAI',
                'model'       => $model,
                'elapsed'     => $elapsed,
                'cost'        => '~0.02-0.07',
            ) );
        }
    }

    // ═══════════════════════════════════════════════════════════
    // ══  FLUX (BFL) IMAGE GENERATION  ═════════════════════════
    // ═══════════════════════════════════════════════════════════

    /**
     * Generate an image via the BFL Flux API (async: POST → poll → download).
     *
     * BFL flow:
     *   1. POST https://api.bfl.ai/v1/{model} with prompt, width, height → { "polling_url": "..." }
     *   2. GET  polling_url until { "status": "Ready", "result": { "sample": "https://..." } }
     *   3. Download the image URL (expires in 10 min)
     *
     * @param string $prompt      Image generation prompt.
     * @param int    $width       Width (must be multiple of 16, max 2048).
     * @param int    $height      Height (must be multiple of 16, max 2048).
     * @param string $model       Flux model endpoint slug (default: from settings).
     * @param string $format      Output format: 'png' or 'jpeg' (default: 'jpeg').
     * @return array|WP_Error     { 'url' => string, 'seed' => int } on success, or WP_Error.
     */
    public static function flux_generate_image( $prompt, $width = 1024, $height = 1024, $model = null, $format = 'jpeg' ) {
        $img_cfg = self::get_image_settings();
        $api_key = $img_cfg['flux_api_key'] ?? '';
        if ( empty( $api_key ) ) {
            return new \WP_Error( 'flux_no_key', 'Clé API BFL Flux non configurée.' );
        }

        $model = $model ?: ( $img_cfg['flux_model'] ?? 'flux-2-pro' );

        // Ensure dimensions are multiple of 16 and within limits
        $width  = min( 2048, max( 256, (int) round( $width / 16 ) * 16 ) );
        $height = min( 2048, max( 256, (int) round( $height / 16 ) * 16 ) );

        // ── Step 1: Submit generation request ──
        $submit_url = 'https://api.bfl.ai/v1/' . $model;

        $payload = array(
            'prompt'           => $prompt,
            'width'            => $width,
            'height'           => $height,
            'output_format'    => $format,
            'safety_tolerance' => (int) ( $img_cfg['flux_safety_tolerance'] ?? 3 ),
        );

        // BP-4: Enable prompt_upsampling for illustration/photo types (enriches short prompts).
        // Disabled for infographics/schemas where we want precise control.
        // Detect JSON prompts (infographic/schema) by checking if prompt starts with '{'
        $is_structured_prompt = ( isset( $prompt[0] ) && $prompt[0] === '{' );
        $payload['prompt_upsampling'] = ! $is_structured_prompt;

        // BP-9: Fixed seed in debug mode for reproducibility
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $payload['seed'] = crc32( $prompt ) % 2147483647;
            self::cocon_log( 'image_generating', 'Debug seed: ' . $payload['seed'] );
        }

        self::cocon_log( 'image_generating', 'Flux ' . $model . ' : soumission...', array(
            'prompt' => mb_substr( $prompt, 0, 200 ) . '...',
            'size'   => $width . 'x' . $height,
        ) );

        $response = wp_remote_post( $submit_url, array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-key'        => $api_key,
            ),
            'body' => wp_json_encode( $payload ),
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $resp_code = wp_remote_retrieve_response_code( $response );
        $resp_body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $resp_code !== 200 || empty( $resp_body['polling_url'] ) ) {
            $err_msg = $resp_body['message'] ?? $resp_body['detail'] ?? 'HTTP ' . $resp_code;
            return new \WP_Error( 'flux_submit_error', 'Flux submit error: ' . $err_msg );
        }

        $polling_url = $resp_body['polling_url'];

        // v19-BUG11: Validate polling URL to avoid 240s wasted loop
        if ( empty( $polling_url ) || filter_var( $polling_url, FILTER_VALIDATE_URL ) === false ) {
            return new \WP_Error( 'flux_invalid_poll', 'Flux: polling URL invalide — ' . mb_substr( $polling_url ?? '', 0, 100 ) );
        }

        // ── Step 2: Poll for result (adaptive interval: start 1s, grow to 3s) ──
        $elapsed = 0;
        // flux-2-pro/max can take 180s+ under load; klein models are much faster
        $is_heavy_model = in_array( $model, array( 'flux-2-pro', 'flux-2-max' ), true );
        $max_elapsed    = $is_heavy_model ? 240 : 180;
        $poll_interval  = ( strpos( $model, 'klein' ) !== false ) ? 1 : 2; // start faster for klein

        while ( $elapsed < $max_elapsed ) {
            sleep( $poll_interval );
            $elapsed += $poll_interval;
            // Grow interval: 1→1→2→2→3→3→3...
            if ( $poll_interval < 3 && $elapsed > 10 ) $poll_interval = 3;

            $poll_resp = wp_remote_get( $polling_url, array(
                'timeout' => 15,
                'headers' => array( 'x-key' => $api_key ),
            ) );

            if ( is_wp_error( $poll_resp ) ) {
                continue; // retry poll
            }

            $poll_body = json_decode( wp_remote_retrieve_body( $poll_resp ), true );
            $status    = $poll_body['status'] ?? '';

            if ( $status === 'Ready' ) {
                $image_url = $poll_body['result']['sample'] ?? '';
                $seed      = $poll_body['result']['seed'] ?? 0;
                if ( empty( $image_url ) ) {
                    return new \WP_Error( 'flux_no_url', 'Flux: résultat Ready mais pas d\'URL image.' );
                }
                self::cocon_log( 'image_generating', 'Flux ' . $model . ' : image prête (' . $elapsed . 's)', array(
                    'seed' => $seed,
                ) );
                return array( 'url' => $image_url, 'seed' => $seed );
            }

            if ( $status === 'Error' ) {
                $err = $poll_body['result']['error'] ?? $poll_body['message'] ?? 'Unknown error';
                return new \WP_Error( 'flux_gen_error', 'Flux generation error: ' . $err );
            }

            // ── BFL moderation: fail fast instead of polling 180s for nothing ──
            if ( in_array( $status, array( 'Content Moderated', 'Request Moderated' ), true ) ) {
                $reason = $poll_body['result']['message'] ?? $poll_body['result']['error'] ?? $status;
                self::cocon_log( 'image_error', 'Flux modération : ' . $reason, array(
                    'status' => $status,
                    'prompt' => mb_substr( $prompt, 0, 120 ) . '...',
                ) );
                return new \WP_Error( 'flux_moderated', 'Flux: contenu modéré par BFL (' . $status . '). Prompt trop sensible pour le modèle.' );
            }

            // ── Task not found (expired or invalid) ──
            if ( $status === 'Task not found' || $status === '' ) {
                $http_code = wp_remote_retrieve_response_code( $poll_resp );
                if ( $http_code === 404 || ( $http_code === 200 && $status === 'Task not found' ) ) {
                    return new \WP_Error( 'flux_task_lost', 'Flux: tâche introuvable (expirée ou invalide).' );
                }
            }

            // Status is 'Pending' or 'Processing' — continue polling
        }

        return new \WP_Error( 'flux_timeout', 'Flux: dépassement du délai de ' . $max_elapsed . 's.' );
    }

    // ═══════════════════════════════════════════════════════════
    // ══  CRON / SCHEDULER  ═══════════════════════════════════
    // ═══════════════════════════════════════════════════════════
    //
    // Architecture:
    //   "Run Now" (manual):
    //     Step 1: ajax_cron_run_now    → find target, call API, return job_id  (~3s)
    //     Step 2: ajax_cron_poll       → check article-status, return phase    (~2s)
    //             When completed → save to transient, return {step:'ready'}
    //     Step 3: JS calls hts_cocon_create_draft (existing tested code)       (~30-90s)
    //
    //   Scheduled cron (background):
    //     Uses same 2-step via wp_schedule_single_event chains
    //     Final step creates draft via cron_create_simple_draft (no images)

    /** Register custom cron intervals */
    public function register_cron_intervals( $schedules ) {
        $schedules['hts_daily']    = array( 'interval' => 86400,  'display' => 'Once daily (HTS)' );
        $schedules['hts_12h']      = array( 'interval' => 43200,  'display' => 'Twice daily (HTS)' );
        $schedules['hts_3xweek']   = array( 'interval' => 201600, 'display' => '3x per week (HTS)' );
        $schedules['hts_2xweek']   = array( 'interval' => 302400, 'display' => '2x per week (HTS)' );
        $schedules['hts_weekly']   = array( 'interval' => 604800, 'display' => 'Weekly (HTS)' );
        return $schedules;
    }

    /** Get schedule settings */
    public static function get_schedule_settings() {
        return wp_parse_args( get_option( 'hts_schedule_settings', array() ), array(
            'enabled'         => false,
            'frequency'       => 'hts_3xweek',
            'post_status'     => 'draft',
            'source'          => 'both',
            'active_cocon_id' => 0,
            'max_per_run'     => 1,
        ) );
    }

    /** Get/add cron log */
    public static function get_cron_log() {
        return get_option( 'hts_cron_log', array() );
    }

    private static function cron_add_log( $status, $message, $extra = array() ) {
        $log = get_option( 'hts_cron_log', array() );
        array_unshift( $log, array_merge( array(
            'time'    => current_time( 'mysql' ),
            'status'  => $status,
            'message' => $message,
        ), $extra ) );
        update_option( 'hts_cron_log', array_slice( $log, 0, 50 ), false );
    }

    /** Get queue */
    public static function get_cron_queue() {
        return get_option( 'hts_cron_queue', array() );
    }

    // ── Settings AJAX ──

    public function ajax_save_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $allowed_freq   = array( 'hts_daily', 'hts_12h', 'hts_3xweek', 'hts_2xweek', 'hts_weekly' );
        $allowed_status = array( 'draft', 'publish' );
        $allowed_source = array( 'queue', 'auto', 'both' );

        $settings = array(
            'enabled'         => ( $_POST['enabled'] ?? '0' ) === '1',
            'frequency'       => in_array( $_POST['frequency'] ?? '', $allowed_freq ) ? $_POST['frequency'] : 'hts_3xweek',
            'post_status'     => in_array( $_POST['post_status'] ?? '', $allowed_status ) ? $_POST['post_status'] : 'draft',
            'source'          => in_array( $_POST['source'] ?? '', $allowed_source ) ? $_POST['source'] : 'both',
            'active_cocon_id' => (int) ( $_POST['active_cocon_id'] ?? 0 ),
            'max_per_run'     => max( 1, min( 3, (int) ( $_POST['max_per_run'] ?? 1 ) ) ),
        );
        update_option( 'hts_schedule_settings', $settings, false );

        // Reschedule WP cron
        $hook = 'hts_cron_generate_article';
        $ts   = wp_next_scheduled( $hook );
        if ( $ts ) wp_unschedule_event( $ts, $hook );

        if ( $settings['enabled'] ) {
            wp_schedule_event( time() + 60, $settings['frequency'], $hook );
            $next = wp_next_scheduled( $hook );
 wp_send_json_success( array( 'message' => 'Planification activée — Prochaine : ' . wp_date( 'd/m/Y H:i', $next ) . ' (heure locale)' ) );
        } else {
 wp_send_json_success( array( 'message' => 'Planification désactivée ' ) );
        }
    }

    // ── Queue AJAX ──

    public function ajax_cron_queue_action() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $act   = sanitize_text_field( $_POST['queue_action'] ?? '' );
        $queue = self::get_cron_queue();

        if ( $act === 'add' ) {
            $cid = (int) ( $_POST['cocon_id'] ?? 0 );
            $tid = (int) ( $_POST['topic_id'] ?? 0 );
            $kw  = sanitize_text_field( $_POST['keyword'] ?? '' );
            if ( ! $cid || ! $tid ) wp_send_json_error( array( 'message' => 'cocon_id et topic_id requis' ) );
            foreach ( $queue as $q ) {
                if ( (int) $q['topic_id'] === $tid && (int) $q['cocon_id'] === $cid ) {
                    wp_send_json_error( array( 'message' => 'Déjà dans la file' ) );
                    return;
                }
            }
            $queue[] = array( 'cocon_id' => $cid, 'topic_id' => $tid, 'keyword' => $kw, 'added_at' => current_time( 'mysql' ) );
            update_option( 'hts_cron_queue', $queue, false );
 wp_send_json_success( array( 'message' => 'Ajouté ', 'queue' => $queue ) );
            return;
        }
        if ( $act === 'remove' ) {
            $idx = (int) ( $_POST['index'] ?? -1 );
            if ( isset( $queue[ $idx ] ) ) array_splice( $queue, $idx, 1 );
            update_option( 'hts_cron_queue', array_values( $queue ), false );
            wp_send_json_success( array( 'queue' => $queue ) );
            return;
        }
        if ( $act === 'clear' ) {
            update_option( 'hts_cron_queue', array(), false );
            wp_send_json_success( array( 'queue' => array() ) );
            return;
        }
        wp_send_json_error( array( 'message' => 'Action inconnue' ) );
    }

    // ══════════════════════════════════════════════════
    // ══  "RUN NOW" — JS-driven 3-step pipeline  ═════
    // ══════════════════════════════════════════════════

    /**
     * Step 1: Find target article, call generate-article API, return job_id.
     * Duration: ~3s. No polling, no post creation.
     */
    public function ajax_cron_run_now() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        // Sprint Robustesse: check if another heavy job is running
        $busy = get_transient( 'hts_heavy_job_running' );
        if ( $busy ) {
            wp_send_json_error( array( 'message' => 'Un processus est en cours (' . $busy . '). Réessayez dans quelques minutes.' ) );
        }

        // Clean any stale state
        delete_option( 'hts_cron_active_job' );

        // Set lock
        self::acquire_generation_lock();

        $settings = self::get_schedule_settings();
 self::cron_add_log( 'start', 'Cron démarré (manuel)' );

        // ── Find next article ──
        $target = $this->cron_pick_next_target( $settings );
        if ( ! $target ) {
 self::cron_add_log( 'skip', 'Aucun article à générer' );
            self::release_generation_lock();
            wp_send_json_success( array( 'step' => 'skip', 'message' => 'Aucun article à générer (file vide ou cocon complet)' ) );
            return;
        }

 self::cron_add_log( 'info', 'Cible : ' . $target['keyword'], array( 'keyword' => $target['keyword'] ) );

        // ── Get plan ──
        $plan_info = $this->cron_get_plan( $target['cocon_id'] );
        if ( ! $plan_info ) {
 self::cron_add_log( 'error', 'Plan introuvable pour cocon #' . $target['cocon_id'] );
            self::release_generation_lock();
            wp_send_json_error( array( 'message' => 'Plan introuvable' ) );
            return;
        }

        // ── Launch API ──
        $siblings     = self::get_cocon_siblings( $target['cocon_id'] );
        $pillar_post  = hts_url_to_postid( $plan_info['pillar_url'] );
        $pillar_title = $pillar_post ? get_the_title( $pillar_post ) : '';

        $gen = $this->cocon_api_call( 'POST', 'generate-article', array(
            'cocon_id'      => $target['cocon_id'],
            'topic_id'      => $target['topic_id'],
            'site_url'      => site_url(),
            'pillar_url'    => $plan_info['pillar_url'],
            'pillar_title'  => $pillar_title,
            'siblings'      => $siblings,
            'language'      => $plan_info['language'],
            'auto_validate' => true,
        ) );

        if ( ! $gen['success'] || empty( $gen['data']['job_id'] ) ) {
            $msg = $gen['data']['message'] ?? $gen['error'] ?? 'Erreur API';
 self::cron_add_log( 'error', ' ' . $msg );
            self::release_generation_lock();
            wp_send_json_error( array( 'message' => $msg ) );
            return;
        }

        $job_id = $gen['data']['job_id'];
 self::cron_add_log( 'info', 'Génération lancée (job: ' . substr( $job_id, 0, 12 ) . '…)', array( 'keyword' => $target['keyword'], 'job_id' => $job_id ) );

        // Save job state for polling
        update_option( 'hts_cron_active_job', array(
            'job_id'     => $job_id,
            'target'     => $target,
            'started_at' => time(),
        ), false );

        wp_send_json_success( array(
            'step'     => 'poll',
            'job_id'   => $job_id,
            'cocon_id' => $target['cocon_id'],
            'topic_id' => $target['topic_id'],
            'keyword'  => $target['keyword'],
        ) );
    }

    /**
     * Step 2: Poll article-status. ONLY checks status + saves to transient when ready.
     * Duration: ~2s. Never creates posts.
     */
    public function ajax_cron_poll_progress() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_data = get_option( 'hts_cron_active_job', null );

        // ── If no active job, check if a draft creation is still in progress ──
        if ( ! $job_data || empty( $job_data['job_id'] ) ) {
            // Check for any active draft creation lock (set during DALL-E phase)
            $creating_job = get_transient( 'hts_creating_draft_lock' );
            if ( $creating_job ) {
                wp_send_json_success( array(
                    'step'    => 'poll',
                    'phase'   => 'creating',
 'label' => 'Création du post',
                    'elapsed' => time() - (int) $creating_job,
 'message' => 'Création du post WordPress + images en cours...',
                    'log'     => array_slice( self::get_cron_log(), 0, 15 ),
                ) );
                return;
            }
            // Truly idle
            $log = self::get_cron_log();
            wp_send_json_success( array( 'step' => 'idle', 'log' => array_slice( $log, 0, 10 ) ) );
            return;
        }

        $job_id  = $job_data['job_id'];
        $target  = $job_data['target'];
        $started = $job_data['started_at'] ?? time();
        $elapsed = time() - $started;
        $poll_count   = ( $job_data['poll_count'] ?? 0 ) + 1;
        $api_errors   = $job_data['api_errors'] ?? 0;
        $last_phase   = $job_data['last_phase'] ?? '';

        // Hard timeout: 8 minutes (article ~4min + DALL-E images ~3min)
        // But skip timeout if draft creation is already in progress (lock exists)
        $lock_key = 'hts_creating_draft_lock';
        if ( $elapsed > 480 ) {
            if ( ! get_transient( $lock_key ) ) {
 self::cron_add_log( 'error', 'Timeout 8 min — article non reçu (polls: ' . $poll_count . ', erreurs API: ' . $api_errors . ')', array( 'job_id' => $job_id, 'keyword' => $target['keyword'] ?? '' ) );
                // ── Anti-doublon : marquer le topic comme failed pour ne pas le reprendre immédiatement ──
                set_transient( 'hts_topic_failed_' . ( $target['topic_id'] ?? 0 ), time(), 3600 ); // 1h cooldown
                delete_option( 'hts_cron_active_job' );
                self::release_generation_lock();
                wp_send_json_success( array(
                    'step'    => 'error',
                    'message' => 'L\'API n\'a pas terminé en 8 min (polls: ' . $poll_count . ', erreurs: ' . $api_errors . '). Vérifiez le dashboard HTS.',
                    'log'     => array_slice( self::get_cron_log(), 0, 10 ),
                ) );
                return;
            }
            // Lock exists → draft creation in progress, let it finish
        }

        // ── If draft creation is in progress by another poll, wait ──
        if ( get_transient( $lock_key ) ) {
            wp_send_json_success( array(
                'step'    => 'poll',
                'phase'   => 'creating',
 'label' => 'Création du post',
                'elapsed' => $elapsed,
 'message' => 'Création du post WordPress + images en cours...',
                'log'     => array_slice( self::get_cron_log(), 0, 15 ),
            ) );
            return;
        }

        // ── Poll the API ──
        $poll = $this->cocon_api_call( 'GET', 'article-status/' . $job_id );

        if ( ! $poll['success'] ) {
            $api_errors++;
            $err_detail = $poll['error'] ?? ( 'HTTP ' . ( $poll['status'] ?? '?' ) );
            // Log first failure + every 5th failure
            if ( $api_errors === 1 || $api_errors % 5 === 0 ) {
 self::cron_add_log( 'info', 'Poll #' . $poll_count . ' échoué: ' . $err_detail . ' (total erreurs: ' . $api_errors . ')', array( 'job_id' => $job_id ) );
            }
            // Update error count in job state
            $job_data['poll_count'] = $poll_count;
            $job_data['api_errors'] = $api_errors;
            update_option( 'hts_cron_active_job', $job_data, false );

            // If too many consecutive API failures, abort early
            if ( $api_errors >= 10 ) {
 self::cron_add_log( 'error', ' ' . $api_errors . ' erreurs API consécutives — abandon', array( 'job_id' => $job_id ) );
                set_transient( 'hts_topic_failed_' . ( $target['topic_id'] ?? 0 ), time(), 3600 );
                delete_option( 'hts_cron_active_job' );
                self::release_generation_lock();
                wp_send_json_success( array(
                    'step'    => 'error',
                    'message' => $api_errors . ' erreurs API consécutives. Vérifiez votre connexion et le dashboard HTS.',
                    'log'     => array_slice( self::get_cron_log(), 0, 10 ),
                ) );
                return;
            }

            wp_send_json_success( array(
                'step'    => 'poll',
                'phase'   => 'waiting',
                'elapsed' => $elapsed,
                'message' => 'Connexion API en attente... (erreur #' . $api_errors . ': ' . $err_detail . ')',
            ) );
            return;
        }

        $status = $poll['data']['status'] ?? 'unknown';
        $phase  = $poll['data']['phase'] ?? $status;

        // ── Log phase transitions (not every poll) ──
        if ( $phase !== $last_phase ) {
 self::cron_add_log( 'info', 'Phase: ' . $last_phase . ' → ' . $phase . ' (' . $elapsed . 's)', array( 'job_id' => $job_id ) );
            $job_data['last_phase'] = $phase;
        }
        // Reset API errors on success + save state
        $job_data['poll_count'] = $poll_count;
        $job_data['api_errors'] = 0;
        update_option( 'hts_cron_active_job', $job_data, false );

        // ── Failed ──
        if ( in_array( $status, array( 'failed', 'error' ) ) ) {
            $msg = $poll['data']['message'] ?? 'Échec de la génération';
 self::cron_add_log( 'error', ' ' . $msg, array( 'job_id' => $job_id ) );
            set_transient( 'hts_topic_failed_' . ( $target['topic_id'] ?? 0 ), time(), 3600 );
            delete_option( 'hts_cron_active_job' );
            self::release_generation_lock();
            wp_send_json_success( array(
                'step'    => 'error',
                'message' => $msg,
                'log'     => array_slice( self::get_cron_log(), 0, 10 ),
            ) );
            return;
        }

        // ── Completed → create draft directly (unified with cron flow) ──
        if ( $status === 'completed' && ! empty( $poll['data']['article'] ) ) {

            // ══ ATOMIC LOCK: prevent concurrent polls from creating duplicate drafts ══
            // Multiple polls can see "completed" simultaneously because DALL-E takes ~2min.
            // Only the FIRST poll to reach here creates the draft.
            // Uses a GLOBAL lock key so the idle check at the top can detect it.
            $lock_key = 'hts_creating_draft_lock';
            if ( get_transient( $lock_key ) ) {
                // Another poll request is already creating this draft → wait
                wp_send_json_success( array(
                    'step'    => 'poll',
                    'phase'   => 'creating',
 'label' => 'Création du post',
                    'elapsed' => $elapsed,
 'message' => 'Création du post WordPress + images en cours...',
                    'log'     => array_slice( self::get_cron_log(), 0, 15 ),
                ) );
                return;
            }
            // Acquire lock BEFORE starting draft creation (5min TTL safety)
            set_transient( $lock_key, time(), 300 );
            // Clear job state immediately so other polls hit the lock check at top
            delete_option( 'hts_cron_active_job' );

 self::cron_add_log( 'info', 'Article reçu en ' . $elapsed . 's', array( 'keyword' => $target['keyword'] ) );

            $article     = $poll['data']['article'];
            $settings    = self::get_schedule_settings();
            $post_status = $settings['post_status'] ?? 'draft';

            $result = $this->cron_create_simple_draft( $article, $target, $job_id, $post_status );

            if ( $result['success'] ) {
                $this->cron_mark_topic_generated( $target['cocon_id'], $target['topic_id'], $result['post_id'], $result['title'] );
 $img_label = ( $result['images'] ?? 0 ) > 0 ? ' | ' . $result['images'] . ' img' : '';
 $cross_label = ( $result['cross_links'] ?? 0 ) > 0 ? ' | ' . $result['cross_links'] . ' cross' : '';
 self::cron_add_log( 'success', ' ' . $result['title'] . $img_label . $cross_label, array(
                    'post_id' => $result['post_id'], 'keyword' => $target['keyword'],
                ) );

                // Release lock AFTER logs are written (prevents idle poll seeing no success log)
                delete_transient( $lock_key );

                // Sprint Robustesse: release generation lock
                self::release_generation_lock();

                // Return 'done' to this poll request (the one that acquired the lock)
                wp_send_json_success( array(
                    'step'        => 'done',
                    'post_id'     => $result['post_id'],
                    'title'       => $result['title'],
                    'images'      => $result['images'] ?? 0,
                    'cross_links' => $result['cross_links'] ?? 0,
                    'edit_url'    => get_edit_post_link( $result['post_id'], 'raw' ),
                    'elapsed'     => $elapsed,
                    'log'         => array_slice( self::get_cron_log(), 0, 20 ),
                ) );
            } else {
 self::cron_add_log( 'error', 'Création post: ' . $result['message'] );
                delete_transient( $lock_key );
                self::release_generation_lock();
                wp_send_json_error( array(
                    'message' => $result['message'],
                    'log'     => array_slice( self::get_cron_log(), 0, 20 ),
                ) );
            }
            return;
        }

        // ── Still processing ──
        $labels = array(
 'queued' => 'En file',
 'generating' => 'Rédaction',
 'writing' => ' Écriture',
 'researching' => 'Recherche',
 'finalizing' => 'Finalisation',
 'processing' => 'Traitement',
        );
 $label = $labels[ $phase ] ?? ( ' ' . ucfirst( $phase ) );

        wp_send_json_success( array(
            'step'    => 'poll',
            'phase'   => $phase,
            'label'   => $label,
            'elapsed' => $elapsed,
            'message' => $label . ' — ' . $elapsed . 's',
            'log'     => array_slice( self::get_cron_log(), 0, 15 ),
        ) );
    }

    // ══════════════════════════════════════════════════
    // ══  BACKGROUND CRON (scheduled)  ════════════════
    // ══════════════════════════════════════════════════
    //
    // Architecture v2.7.4 — INLINE POLLING
    // Avant : chaining via wp_schedule_single_event → impossible sur site sans trafic
    // Maintenant : un seul process PHP qui lance l'API + poll en boucle + crée le post
    // Le tout dans un set_time_limit(480) = 8 min max

    /** WP Cron hook callback — process complet en une seule exécution */
    public function cron_execute() {
        @set_time_limit( 720 ); // 12 min — polling ~4 min + DALL-E images ~3 min
        ignore_user_abort( true );

        // Prevent concurrent runs
        if ( get_transient( 'hts_cron_running' ) ) {
 self::cron_add_log( 'skip', 'Cron déjà en cours' );
            return;
        }
        set_transient( 'hts_cron_running', 1, 900 ); // 15 min safety

        try {
            $this->cron_bg_full_cycle();
        } catch ( \Exception $e ) {
 self::cron_add_log( 'error', 'Exception: ' . $e->getMessage() );
        } catch ( \Error $e ) {
 self::cron_add_log( 'error', 'Fatal: ' . $e->getMessage() );
        }

        // Cleanup
        delete_option( 'hts_cron_active_job' );
        self::release_generation_lock();
        delete_transient( 'hts_cron_running' );
    }

    /**
     * Full cycle: pick target → launch API → poll inline → create draft
     * Tout dans un seul process PHP, pas de wp_schedule_single_event
     */
    private function cron_bg_full_cycle() {
        $settings = self::get_schedule_settings();
        if ( ! $settings['enabled'] ) return;

 self::cron_add_log( 'start', 'Cron auto' );

        // ── 1. Pick target ──
        $target = $this->cron_pick_next_target( $settings );
        if ( ! $target ) {
 self::cron_add_log( 'skip', 'Rien à générer' );
            return;
        }

        $plan_info = $this->cron_get_plan( $target['cocon_id'] );
        if ( ! $plan_info ) {
 self::cron_add_log( 'error', 'Plan introuvable pour cocon #' . $target['cocon_id'] );
            return;
        }

        // ── 2. Launch API ──
        $siblings     = self::get_cocon_siblings( $target['cocon_id'] );
        $pillar_post  = hts_url_to_postid( $plan_info['pillar_url'] );
        $pillar_title = $pillar_post ? get_the_title( $pillar_post ) : '';

        $gen = $this->cocon_api_call( 'POST', 'generate-article', array(
            'cocon_id'      => $target['cocon_id'],
            'topic_id'      => $target['topic_id'],
            'site_url'      => site_url(),
            'pillar_url'    => $plan_info['pillar_url'],
            'pillar_title'  => $pillar_title,
            'siblings'      => $siblings,
            'language'      => $plan_info['language'],
            'auto_validate' => true,
        ) );

        if ( ! $gen['success'] || empty( $gen['data']['job_id'] ) ) {
 self::cron_add_log( 'error', 'API: ' . ( $gen['data']['message'] ?? $gen['error'] ?? 'Erreur inconnue' ) );
            return;
        }

        $job_id = $gen['data']['job_id'];
 self::cron_add_log( 'info', 'Lancé (auto)', array( 'keyword' => $target['keyword'], 'job_id' => $job_id ) );

        // Save state (pour que le poll manuel puisse le voir aussi)
        update_option( 'hts_cron_active_job', array(
            'job_id' => $job_id, 'target' => $target, 'started_at' => time(),
        ), false );

        // ── 3. Poll INLINE — sleep(15) entre chaque, max 7 min ──
        $max_wait   = 420; // 7 minutes
        $poll_delay = 15;  // secondes entre chaque poll
        $started_at = time();
        $article    = null;

        sleep( 20 ); // Attendre un peu avant le 1er poll

        while ( ( time() - $started_at ) < $max_wait ) {
            $poll   = $this->cocon_api_call( 'GET', 'article-status/' . $job_id );
            $status = $poll['data']['status'] ?? 'unknown';
            $phase  = $poll['data']['phase'] ?? $status;

            // ── Completed ──
            if ( $status === 'completed' && ! empty( $poll['data']['article'] ) ) {
                $elapsed = time() - $started_at;
 self::cron_add_log( 'info', 'Article reçu en ' . $elapsed . 's', array( 'keyword' => $target['keyword'] ) );
                $article = $poll['data']['article'];
                break;
            }

            // ── Failed ──
            if ( in_array( $status, array( 'failed', 'error' ) ) ) {
 self::cron_add_log( 'error', ' ' . ( $poll['data']['message'] ?? 'Génération échouée' ) );
                set_transient( 'hts_topic_failed_' . ( $target['topic_id'] ?? 0 ), time(), 3600 );
                return;
            }

            // ── Still processing — sleep then retry ──
            sleep( $poll_delay );
        }

        if ( ! $article ) {
            $elapsed = time() - $started_at;
 self::cron_add_log( 'error', 'Timeout ' . $elapsed . 's — article non reçu (auto)' );
            set_transient( 'hts_topic_failed_' . ( $target['topic_id'] ?? 0 ), time(), 3600 );
            return;
        }

        // ── 4. Create draft ──
        $result = $this->cron_create_simple_draft( $article, $target, $job_id, $settings['post_status'] );
        if ( $result['success'] ) {
            $this->cron_mark_topic_generated( $target['cocon_id'], $target['topic_id'], $result['post_id'], $result['title'] );
 $img_label = ( $result['images'] ?? 0 ) > 0 ? ' | ' . $result['images'] . ' img' : '';
 $cross_label = ( $result['cross_links'] ?? 0 ) > 0 ? ' | ' . $result['cross_links'] . ' cross' : '';
 self::cron_add_log( 'success', ' ' . $result['title'] . $img_label . $cross_label, array(
                'post_id' => $result['post_id'], 'keyword' => $target['keyword'],
            ) );
        } else {
 self::cron_add_log( 'error', 'Création post: ' . $result['message'] );
        }
    }

    // ══════════════════════════════════════════════════
    // ══  SHARED HELPERS  ═════════════════════════════
    // ══════════════════════════════════════════════════

    /** Pick next article target from queue or cocon */
    private function cron_pick_next_target( $settings ) {
        // Priority 1: manual queue
        if ( in_array( $settings['source'], array( 'queue', 'both' ) ) ) {
            $queue   = self::get_cron_queue();
            $changed = false;
            while ( ! empty( $queue ) ) {
                $target = array_shift( $queue );
                $changed = true;
                // Check duplicate before returning queue item
                $dup = self::cocon_detect_duplicate( $target['keyword'] ?? '' );
                if ( $dup['is_duplicate'] ) {
 self::cron_add_log( 'skip', 'Doublon (queue): "' . ( $target['keyword'] ?? '' ) . '" → ' . $dup['reason'], array( 'keyword' => $target['keyword'] ?? '' ) );
                    continue; // skip this one, try next in queue
                }
                update_option( 'hts_cron_queue', array_values( $queue ), false );
                return $target;
            }
            if ( $changed ) {
                update_option( 'hts_cron_queue', array(), false );
            }
        }
        // Priority 2: auto from cocon
        if ( in_array( $settings['source'], array( 'auto', 'both' ) ) ) {
            return $this->cron_find_next_from_cocon( $settings['active_cocon_id'] );
        }
        return null;
    }

    /** Get plan info for a cocon_id */
    private function cron_get_plan( $cocon_id ) {
        foreach ( self::get_cocon_plans() as $p ) {
            if ( (int) $p['cocon_id'] === (int) $cocon_id ) return $p;
        }
        return null;
    }

    /** Find next ungenerated topic from cocon(s) */
    private function cron_find_next_from_cocon( $cocon_id = 0 ) {
        foreach ( self::get_cocon_plans() as $plan ) {
            if ( $plan['status'] !== 'success' || empty( $plan['plan'] ) ) continue;
            if ( $cocon_id > 0 && (int) $plan['cocon_id'] !== $cocon_id ) continue;

            $generated = $plan['articles_gen'] ?? array();
            foreach ( $plan['plan'] as $cat ) {
                foreach ( $cat['articles'] ?? array() as $art ) {
                    $tid = (int) ( $art['topic_id'] ?? 0 );
                    if ( $tid <= 0 ) continue;

                    // Check both formats:
                    // Format A (ajax_cocon_create_draft): articles_gen[topic_id] = {post_id, title, date}
                    // Format B (cron_mark_topic_generated): articles_gen[] = topic_id
                    if ( array_key_exists( $tid, $generated ) ) continue;   // Format A
                    if ( in_array( $tid, $generated, true ) ) continue;     // Format B

                    // Safety: also check if WP post already exists for this topic
                    $existing = get_posts( array(
                        'post_type'      => 'post',
                        'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
                        'posts_per_page' => 1,
                        'fields'         => 'ids',
                        'meta_query'     => array(
                            array( 'key' => '_hts_cocon_topic_id', 'value' => $tid ),
                        ),
                    ) );
                    if ( ! empty( $existing ) ) continue;

                    // Anti-doublon: skip topics that recently failed (1h cooldown)
                    if ( get_transient( 'hts_topic_failed_' . $tid ) ) {
 self::cron_add_log( 'skip', 'Topic #' . $tid . ' en cooldown (échec récent)', array( 'keyword' => $art['keyword'] ?? '' ) );
                        continue;
                    }

                    // Anti-doublon: skip if a Run Now job is currently in-flight for this topic
                    $active_job = get_option( 'hts_cron_active_job', null );
                    if ( $active_job && isset( $active_job['target']['topic_id'] ) && (int) $active_job['target']['topic_id'] === $tid ) {
 self::cron_add_log( 'skip', 'Topic #' . $tid . ' déjà en cours de génération' );
                        continue;
                    }

                    $keyword = $art['keyword'] ?? $art['title'] ?? '';

                    // ── Duplicate detection: exact keyword match across ALL posts ──
                    $dup = self::cocon_detect_duplicate( $keyword );
                    if ( $dup['is_duplicate'] ) {
 self::cron_add_log( 'skip', 'Doublon détecté: "' . $keyword . '" → ' . $dup['reason'], array(
                            'keyword'     => $keyword,
                            'match_id'    => $dup['post_id'],
                            'match_title' => $dup['title'],
                            'match_type'  => $dup['type'],
                        ) );
                        continue;
                    }

                    return array(
                        'cocon_id' => (int) $plan['cocon_id'],
                        'topic_id' => $tid,
                        'keyword'  => $keyword,
                    );
                }
            }
        }
        return null;
    }

    /**
     * Detect if a keyword already has a corresponding article on the site.
     *
     * Checks:
     * 1. Exact keyword match via _hts_api_keyword post meta
     * 2. Exact keyword match via Yoast / RankMath focus keyword
     * 3. Fuzzy title similarity > 80%
     *
     * @param string $keyword
     * @return array { is_duplicate, post_id, title, reason, type }
     */
    private static function cocon_detect_duplicate( $keyword ) {
        $keyword_low = mb_strtolower( trim( $keyword ) );
        if ( empty( $keyword_low ) ) {
            return array( 'is_duplicate' => false );
        }

        // ── 1. Check _hts_api_keyword (our own meta) ──
        $by_meta = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => array( array(
                'key'     => '_hts_api_keyword',
                'value'   => $keyword_low,
                'compare' => '=',
            ) ),
        ) );
        if ( ! empty( $by_meta ) ) {
            return array(
                'is_duplicate' => true,
                'post_id'      => $by_meta[0],
                'title'        => get_the_title( $by_meta[0] ),
                'reason'       => 'Keyword exact (meta _hts_api_keyword) → post #' . $by_meta[0],
                'type'         => 'keyword_exact',
            );
        }

        // ── 2. Check Yoast / RankMath focus keyword ──
        $seo_meta_keys = array( '_yoast_wpseo_focuskw', 'rank_math_focus_keyword' );
        foreach ( $seo_meta_keys as $mk ) {
            $by_seo = get_posts( array(
                'post_type'      => 'post',
                'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'meta_query'     => array( array(
                    'key'     => $mk,
                    'value'   => $keyword_low,
                    'compare' => '=',
                ) ),
            ) );
            if ( ! empty( $by_seo ) ) {
                return array(
                    'is_duplicate' => true,
                    'post_id'      => $by_seo[0],
                    'title'        => get_the_title( $by_seo[0] ),
                    'reason'       => 'Keyword exact (' . $mk . ') → post #' . $by_seo[0],
                    'type'         => 'seo_keyword',
                );
            }
        }

        // ── 3. Fuzzy title match (> 80% similarity) ──
        // Only check recent posts (last 500) to avoid performance issues
        $recent = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );

        foreach ( $recent as $pid ) {
            $title_low = mb_strtolower( get_the_title( $pid ) );
            similar_text( $keyword_low, $title_low, $percent );
            if ( $percent > 80 ) {
                return array(
                    'is_duplicate' => true,
                    'post_id'      => $pid,
                    'title'        => get_the_title( $pid ),
                    'reason'       => 'Titre similaire (' . round( $percent ) . '%) → post #' . $pid,
                    'type'         => 'fuzzy_title',
                );
            }
        }

        return array( 'is_duplicate' => false );
    }

    /**
     * Public wrapper for duplicate detection (used in UI templates).
     * Uses transient cache to avoid repeated DB queries on plan display.
     */
    public static function cocon_detect_duplicate_ui( $keyword ) {
        $cache_key = 'hts_dup_' . md5( mb_strtolower( trim( $keyword ) ) );
        $cached    = get_transient( $cache_key );
        if ( $cached !== false ) return $cached;

        $result = self::cocon_detect_duplicate( $keyword );
        set_transient( $cache_key, $result, 300 ); // cache 5 min
        return $result;
    }

    /** BG cron: create simple draft (fast, no images — those are added on next manual edit) */
    private function cron_create_simple_draft( $article, $target, $job_id, $post_status = 'draft' ) {
        $content_html = $article['content_html'] ?? '';
        $keyword      = $article['keyword'] ?? $target['keyword'] ?? '';

        // Strip wrappers
        if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $content_html, $bm ) ) {
            $content_html = $bm[1];
        }

        // Title
        $wp_title = '';
        if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/si', $content_html, $h1m ) ) {
            $wp_title = wp_strip_all_tags( $h1m[1] );
        }
        if ( empty( $wp_title ) ) $wp_title = wp_strip_all_tags( $article['title'] ?? 'Article' );

        // Simple slug
        $wp_slug = self::cocon_generate_short_slug( $keyword, $article['slug'] ?? '' );

        // Clean HTML
        $wp_content = $content_html;
        $wp_content = preg_replace( '/<meta[^>]*>/i', '', $wp_content )         ?? $wp_content;
        $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content ) ?? $wp_content;
        $wp_content = preg_replace( '/<title>.*?<\/title>/si', '', $wp_content ) ?? $wp_content;
        $wp_content = preg_replace( '/\nSTOP\n.*$/s', '', $wp_content )          ?? $wp_content;
        $wp_content = preg_replace( '/<!--.*?-->/s', '', $wp_content )           ?? $wp_content;
        $wp_content = trim( $wp_content );
        if ( empty( $wp_content ) ) $wp_content = $content_html;

        // Fix ugly permalinks (?p=XXX) → real URLs, strip links to unpublished pages
        if ( class_exists( 'HTS_Cocon_Commander' ) ) {
            $wp_content = HTS_Cocon_Commander::fix_ugly_permalinks( $wp_content );
        }

        // ── v18: Disperse dense link blocks ──
        // SaaS sometimes stacks 5-6 sibling links in a single <ul>.
        // Keep max 2 links per <ul>, redistribute the rest into following paragraphs.
        $wp_content = self::disperse_dense_link_blocks( $wp_content );

        // Trash old drafts for same topic (prevents slug -2)
        $cocon_id_cron = $target['cocon_id'] ?? 0;
        $topic_id_cron = $target['topic_id'] ?? 0;
        if ( $cocon_id_cron > 0 && $topic_id_cron > 0 ) {
            $old_drafts = get_posts( array(
                'post_type'   => 'post',
                'post_status' => array( 'draft', 'pending' ),
                'numberposts' => 5,
                'fields'      => 'ids',
                'meta_query'  => array(
                    'relation' => 'AND',
                    array( 'key' => '_hts_cocon_id',       'value' => $cocon_id_cron ),
                    array( 'key' => '_hts_cocon_topic_id', 'value' => $topic_id_cron ),
                ),
            ) );
            foreach ( $old_drafts as $old_id ) {
                wp_trash_post( $old_id );
            }
        }

        // Unique slug check
        $desired_slug_cron = sanitize_title( $wp_slug );
        $slug_taken = get_posts( array(
            'post_type' => 'post', 'post_status' => array( 'publish', 'future', 'private' ),
            'name' => $desired_slug_cron, 'numberposts' => 1, 'fields' => 'ids',
        ) );
        if ( ! empty( $slug_taken ) ) {
            $desired_slug_cron .= '-' . substr( md5( $keyword . $cocon_id_cron ), 0, 4 );
        }

        // Create post
        $default_author = (int) get_option( 'hts_default_author', 0 );
        // Sprint 6.2d: clean internal link attributes
        $wp_content = self::fix_internal_link_attrs( $wp_content );
        $post_args = array(
            'post_title'   => $wp_title,
            'post_name'    => $desired_slug_cron,
            'post_content' => $wp_content,
            'post_status'  => $post_status,
            'post_type'    => 'post',
            'meta_input'   => array(
                '_hts_api_generated'  => 1,
                '_hts_api_keyword'    => $keyword,
                '_hts_cocon_id'       => $target['cocon_id'],
                '_hts_cocon_topic_id' => $target['topic_id'],
                '_hts_cocon_job_id'   => $job_id,
                '_hts_cron_generated' => 1,
            ),
        );
        if ( $default_author > 0 ) $post_args['post_author'] = $default_author;
        $post_id = wp_insert_post( $post_args );

        if ( is_wp_error( $post_id ) ) {
            return array( 'success' => false, 'message' => $post_id->get_error_message() );
        }

        // ── Audit Trail: log article creation ──
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log_article_created( $post_id, $wp_title, $keyword, array(
                'job_id'      => $job_id,
                'post_status' => $post_status,
                'cocon_id'    => $target['cocon_id'] ?? 0,
            ) );
        }

        // Basic SEO metas
        $meta_title = $article['meta_title'] ?? $wp_title;
        $meta_desc  = $article['meta_description'] ?? '';
        self::cocon_apply_seo_metas( $post_id, array(
            'metatitle' => self::cocon_truncate_meta( $meta_title, 60 ),
            'metadescription' => self::cocon_truncate_meta( $meta_desc, 155 ),
            'keyword' => $keyword,
        ) );

        // Categories — Sprint Robustesse: same priority as manual path
        // Priority 1: pillar's category, Priority 2: fuzzy match, Priority 3: cocon keyword
        $cat_id_cron = 0;
        $cocon_id_for_cat = $target['cocon_id'] ?? 0;
        if ( $cocon_id_for_cat ) {
            // Find pillar
            $plans_for_cat = get_option( 'hts_cocon_plans', array() );
            $plan_for_cat = $plans_for_cat[ $cocon_id_for_cat ] ?? null;
            if ( $plan_for_cat ) {
                $pillar_pid = hts_url_to_postid( $plan_for_cat['pillar_url'] ?? '' );
                if ( $pillar_pid ) {
                    $pc = wp_get_post_categories( $pillar_pid );
                    $pc = array_filter( $pc, function( $c ) { return (int) $c !== 1; } );
                    if ( ! empty( $pc ) ) $cat_id_cron = (int) array_values( $pc )[0];
                }
            }
        }
        if ( ! $cat_id_cron && ! empty( $article['category'] ) ) {
            $cat_id_cron = self::cocon_ensure_category( $article['category'] );
        }
        if ( ! $cat_id_cron && ! empty( $keyword ) ) {
            $cat_id_cron = get_cat_ID( $keyword );
        }
        if ( $cat_id_cron && ! is_wp_error( $cat_id_cron ) ) {
            wp_set_post_categories( $post_id, array( (int) $cat_id_cron ) );
        }

        // ── 9b. Keyword stuffing detection (log only, no rewrite) ──
        $stuffing = self::cocon_check_keyword_stuffing( $wp_content, $keyword, $post_id );
        if ( $stuffing['flagged'] ) {
            update_post_meta( $post_id, '_hts_keyword_stuffing', $stuffing );
 self::cron_add_log( 'info', 'Keyword stuffing: ' . $stuffing['density'] . '% [' . $keyword . ']', array( 'keyword' => $keyword ) );
        }

        // ── 10. Generate AI images + set featured + in-content images ──
        $image_agent_on = ! class_exists( 'HTS_Workflow_Engine' ) || HTS_Workflow_Engine::is_agent_enabled( 'image' );
        if ( $image_agent_on ) {
            $img_cfg_cron = self::get_image_settings();
            $provider_label = ( $img_cfg_cron['image_provider'] ?? 'openai' ) === 'flux' ? 'Flux' : 'GPT-image';
 self::cron_add_log( 'info', 'Génération images ' . $provider_label . '...', array( 'keyword' => $keyword ) );
            // Note: cocon_generate_article_images() handles wp_update_post internally
            $images_result = self::cocon_generate_article_images( $post_id, $wp_title, $keyword, $wp_content );
        } else {
 self::cron_add_log( 'info', 'Images IA : génération désactivée (agent image inactif)', array( 'keyword' => $keyword ) );
            $images_result = array( 'count' => 0, 'images' => array(), 'content' => $wp_content );
        }

        // ── Audit Trail: log images ──
        if ( class_exists( 'HTS_Audit_Trail' ) && ( $images_result['count'] ?? 0 ) > 0 ) {
            $img_details = array_map( function( $img ) {
                return array( 'type' => $img['type'] ?? '', 'alt' => $img['alt_text'] ?? '', 'url' => $img['url'] ?? '' );
            }, $images_result['images'] ?? array() );
            HTS_Audit_Trail::log_images( $post_id, $images_result['count'], $img_details );
        }

        // ── 11. Schemas: handled by plugin's frontend module (not injected into content) ──
        $schemas_detected = array();

        // Note: wp_update_post already done inside cocon_generate_article_images()

 self::cron_add_log( 'info', 'Images: ' . ( $images_result['count'] ?? 0 ), array( 'keyword' => $keyword ) );

        // ── 13. Register node in cocon_data BEFORE cross-interlink (so sync_cocon_data_after_interlink finds it) ──
        $cocon_id_val = $target['cocon_id'] ?? '';
        if ( ! empty( $cocon_id_val ) ) {
            $cron_opt_key = self::resolve_cocon_data_option_key();
            $cocon_data = get_option( $cron_opt_key, array() );
            if ( ! empty( $cocon_data['nodes'] ) && ! isset( $cocon_data['nodes'][ $post_id ] ) ) {
                // Find the cluster name from the cocon_id
                $cluster_name = '';
                foreach ( $cocon_data['clusters'] ?? array() as $cname => $cl ) {
                    if ( ! empty( $cl['pillar_id'] ) ) {
                        $pillar_cocon_id = get_post_meta( $cl['pillar_id'], '_hts_cocon_id', true );
                        if ( $pillar_cocon_id === $cocon_id_val ) {
                            $cluster_name = $cname;
                            break;
                        }
                    }
                    // Also check if any page in the cluster has this cocon_id
                    foreach ( $cl['pages'] ?? array() as $cpid ) {
                        if ( get_post_meta( $cpid, '_hts_cocon_id', true ) === $cocon_id_val ) {
                            $cluster_name = $cname;
                            break 2;
                        }
                    }
                }

                if ( ! empty( $cluster_name ) ) {
                    $cocon_data['nodes'][ $post_id ] = array(
                        'id'         => $post_id,
                        'title'      => $wp_title,
                        'url'        => get_permalink( $post_id ),
                        'cluster'    => $cluster_name,
                        'is_pillar'  => false,
                        'is_orphan'  => true,
                        'incoming'   => array(),
                        'outgoing'   => array(),
                        'in_count'   => 0,
                        'out_count'  => 0,
                        'in_links'   => 0,
                        'out_links'  => 0,
                        'keywords'   => array( $keyword ),
                        'categories' => array(),
                    );
                    if ( isset( $cocon_data['clusters'][ $cluster_name ]['pages'] ) ) {
                        if ( ! in_array( $post_id, $cocon_data['clusters'][ $cluster_name ]['pages'] ) ) {
                            $cocon_data['clusters'][ $cluster_name ]['pages'][] = $post_id;
                        }
                    }
                    update_option( $cron_opt_key, $cocon_data, false );
                    update_post_meta( $post_id, '_hts_cocon_id', $cluster_name );
                }
            }
        }

        // ── 14. Cross-cocon interlinking — deferred to separate cron (Sprint 6.2d) ──
        if ( ! wp_next_scheduled( 'hts_deferred_cross_interlink', array( $post_id ) ) ) {
            wp_schedule_single_event( time() + 30, 'hts_deferred_cross_interlink', array( $post_id ) );
        }
        $cross_links = array( 'outbound' => 0, 'inbound' => 0 );

        return array( 'success' => true, 'post_id' => $post_id, 'title' => $wp_title, 'images' => $images_result['count'] ?? 0, 'cross_links' => 0 );
    }

    /** Mark topic as generated in plan (same format as ajax_cocon_create_draft) */
    private function cron_mark_topic_generated( $cocon_id, $topic_id, $post_id = 0, $title = '' ) {
        $plans = self::get_cocon_plans();
        foreach ( $plans as $i => $p ) {
            if ( (int) $p['cocon_id'] === (int) $cocon_id ) {
                if ( ! isset( $plans[ $i ]['articles_gen'] ) ) $plans[ $i ]['articles_gen'] = array();
                $plans[ $i ]['articles_gen'][ (int) $topic_id ] = array(
                    'post_id' => $post_id,
                    'title'   => $title,
                    'date'    => current_time( 'mysql' ),
                );
                break;
            }
        }
        update_option( 'hts_cocon_plans', $plans, false );
    }


    /** AJAX: Auto-detect brand colors from site CSS (custom properties + theme) */
    public function ajax_detect_brand_colors() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $colors = array();

        // 1. Try theme.json (FSE themes: Twenty Twenty-Four, etc.)
        $theme_json_path = get_template_directory() . '/theme.json';
        if ( file_exists( $theme_json_path ) ) {
            $theme_json = json_decode( file_get_contents( $theme_json_path ), true );
            $palette = $theme_json['settings']['color']['palette'] ?? array();
            foreach ( $palette as $c ) {
                $slug = strtolower( $c['slug'] ?? '' );
                if ( strpos( $slug, 'primary' ) !== false || strpos( $slug, 'base' ) !== false ) {
                    $colors['primary_color'] = $c['color'];
                }
                if ( strpos( $slug, 'secondary' ) !== false || strpos( $slug, 'accent' ) !== false ) {
                    $colors['secondary_color'] = $c['color'];
                }
                if ( strpos( $slug, 'tertiary' ) !== false || strpos( $slug, 'contrast' ) !== false ) {
                    $colors['accent_color'] = $c['color'];
                }
            }
        }

        // 2. Try Customizer settings (classic themes)
        $customizer_keys = array(
            'primary_color'   => array( 'primary_color', 'primary-color', 'theme_color', 'brand_color', 'accent_color' ),
            'secondary_color' => array( 'secondary_color', 'secondary-color', 'link_color' ),
        );
        foreach ( $customizer_keys as $target => $keys ) {
            if ( ! empty( $colors[ $target ] ) ) continue;
            foreach ( $keys as $k ) {
                $val = get_theme_mod( $k, '' );
                if ( ! empty( $val ) && preg_match( '/^#[a-fA-F0-9]{3,8}$/', $val ) ) {
                    $colors[ $target ] = $val;
                    break;
                }
            }
        }

        // 3. Try Elementor global colors
        if ( defined( 'ELEMENTOR_VERSION' ) ) {
            $kit_id = get_option( 'elementor_active_kit', 0 );
            if ( $kit_id ) {
                $kit_settings = get_post_meta( $kit_id, '_elementor_page_settings', true );
                $system_colors = $kit_settings['system_colors'] ?? array();
                foreach ( $system_colors as $sc ) {
                    $id = $sc['_id'] ?? '';
                    if ( $id === 'primary' && ! empty( $sc['color'] ) )   $colors['primary_color']   = $sc['color'];
                    if ( $id === 'secondary' && ! empty( $sc['color'] ) ) $colors['secondary_color'] = $sc['color'];
                    if ( $id === 'accent' && ! empty( $sc['color'] ) )    $colors['accent_color']    = $sc['color'];
                }
            }
        }

        // 4. Try site icon / custom logo for logo_url
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $colors['logo_url'] = wp_get_attachment_url( $custom_logo_id );
        }

        // 5. Detect active theme style
        $theme = wp_get_theme();
        $theme_name = strtolower( $theme->get( 'Name' ) );
        if ( strpos( $theme_name, 'astra' ) !== false || strpos( $theme_name, 'generatepress' ) !== false ) {
            $colors['style'] = 'modern';
        } elseif ( strpos( $theme_name, 'divi' ) !== false ) {
            $colors['style'] = 'corporate';
        } else {
            $colors['style'] = 'modern';
        }

        $colors['brand_name'] = get_bloginfo( 'name' );

        wp_send_json_success( array(
            'detected' => $colors,
 'message' => ! empty( $colors['primary_color'] ) ? 'Couleurs détectées ' : 'Aucune couleur auto-détectée — configurez manuellement.',
        ) );
    }

    /** AJAX: Delete a saved cocon plan */
    public function ajax_cocon_delete_plan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $cocon_id = (int) ( $_POST['cocon_id'] ?? 0 );
        $plans = self::get_cocon_plans();
        $plans = array_values( array_filter( $plans, function( $p ) use ( $cocon_id ) {
            return (int) $p['cocon_id'] !== $cocon_id;
        } ) );
        update_option( 'hts_cocon_plans', $plans, false );

 self::cocon_log( 'plan_deleted', 'Plan supprimé', array( 'cocon_id' => $cocon_id ) );
        wp_send_json_success( array( 'message' => 'Plan supprimé' ) );
    }

    /** AJAX: Get cocon generation logs */
    public function ajax_cocon_get_logs() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        wp_send_json_success( array( 'logs' => self::get_cocon_logs() ) );
    }

    /* ── Cocon Logging System ── */

    /**
     * Log a cocon-related event (smart: skips duplicate poll phases)
     */
    public static function cocon_log( $type, $message, $data = array() ) {
        $logs = get_option( 'hts_cocon_logs', array() );

        // For poll_article: only log if phase CHANGED from last entry
        if ( $type === 'poll_article' ) {
            $last = end( $logs );
            if ( $last && $last['type'] === 'poll_article'
                && isset( $last['data']['job_id'] ) && $last['data']['job_id'] === ( $data['job_id'] ?? '' )
                && isset( $last['data']['phase'] ) && $last['data']['phase'] === ( $data['phase'] ?? '' )
            ) {
                return; // Same phase, skip
            }
        }

        $logs[] = array(
            'time'    => current_time( 'mysql' ),
            'type'    => $type,
            'message' => $message,
            'data'    => $data,
        );
        // Keep last 200 entries
        if ( count( $logs ) > 200 ) $logs = array_slice( $logs, -200 );
        update_option( 'hts_cocon_logs', $logs, false );

        // Also feed important events to the dashboard activity log
        $dashboard_types = array(
            'plan_queued'    => 'success',
            'plan_ready'     => 'success',
            'article_queued' => 'success',
            'article_ready'  => 'success',
            'article_error'  => 'error',
            'draft_created'  => 'success',
            'ai_metas'       => 'info',
            'ai_metas_error' => 'error',
            'image_created'  => 'success',
            'image_convert'  => 'info',
            'image_error'    => 'error',
            'links_fixed'    => 'info',
            'schema_detected'=> 'info',
            'plan_deleted'   => 'info',
        );
        if ( isset( $dashboard_types[ $type ] ) && function_exists( 'hts_add_log' ) ) {
            $dash_msg = 'Cocon: ' . $message;
            if ( ! empty( $data['title'] ) ) $dash_msg .= ' — "' . $data['title'] . '"';
            if ( ! empty( $data['keyword'] ) ) $dash_msg .= ' [' . $data['keyword'] . ']';
            hts_add_log( $dash_msg, $dashboard_types[ $type ], 'cocon' );
        }
    }

    /**
     * Get cocon logs
     */
    public static function get_cocon_logs() {
        return get_option( 'hts_cocon_logs', array() );
    }

    /* ═══════════════════════════════════════════════════════════
     *  BROUILLONS — AJAX HANDLERS
     * ═══════════════════════════════════════════════════════════ */

    /** Get checklist data for a single draft */
    public function ajax_draft_checklist() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error();

        wp_send_json_success( self::get_draft_checklist( $post_id ) );
    }

    /** Publish a draft immediately */
    public function ajax_draft_publish() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'draft' ) {
            wp_send_json_error( array( 'message' => 'Brouillon introuvable' ) );
        }

        wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );

        // ── Audit Trail ──
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log_article_published( $post_id, array(
                'source' => 'manual_publish',
                'url'    => get_permalink( $post_id ),
            ) );
        }

        wp_send_json_success( array(
            'message' => 'Publié !',
            'url'     => get_permalink( $post_id ),
        ) );
    }

    /** Schedule a draft for future publication */
    public function ajax_draft_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id  = (int) ( $_POST['post_id'] ?? 0 );
        $datetime = sanitize_text_field( $_POST['datetime'] ?? '' );
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'draft', 'future' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Brouillon introuvable' ) );
        }
        if ( ! $datetime ) {
            wp_send_json_error( array( 'message' => 'Date requise' ) );
        }

        // Convert to WP format
        $ts = strtotime( $datetime );
        if ( ! $ts || $ts < time() ) {
            wp_send_json_error( array( 'message' => 'La date doit être dans le futur' ) );
        }

        wp_update_post( array(
            'ID'            => $post_id,
            'post_status'   => 'future',
            'post_date'     => date( 'Y-m-d H:i:s', $ts ),
            'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $ts ),
        ) );

        wp_send_json_success( array(
            'message' => 'Planifié pour le ' . date_i18n( 'j M Y à H:i', $ts ),
        ) );
    }

    /** Delete a draft */
    public function ajax_draft_delete() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'draft' ) {
            wp_send_json_error( array( 'message' => 'Brouillon introuvable' ) );
        }

        wp_trash_post( $post_id );
        wp_send_json_success( array( 'message' => 'Mis à la corbeille' ) );
    }

    /* ═══════════════════════════════════════════════════════════════
     *  PUBLISHING STRATEGY — Rythme intelligent (v2.5.1)
     * ═══════════════════════════════════════════════════════════════ */

    /** Get saved publishing strategy or defaults */
    public static function get_publishing_strategy() {
        $defaults = array(
            'posts_per_week' => 3,
            'days'           => array( 1, 3, 5 ), // Mon, Wed, Fri (1=Mon, 7=Sun)
            'hour'           => 9,
            'minute'         => 0,
            'min_gap_hours'  => 4, // Min gap between posts same day
            'max_per_day'    => 1, // Max articles par jour
        );
        $saved = get_option( 'hts_pub_strategy', array() );
        return wp_parse_args( $saved, $defaults );
    }

    /** Calculate next N available publication slots based on strategy */
    public static function get_next_available_slots( $count = 10, $exclude_datetimes = array() ) {
        $strategy    = self::get_publishing_strategy();
        $days        = $strategy['days'];
        $hour        = (int) $strategy['hour'];
        $minute      = (int) $strategy['minute'];
        $max_per_day = max( 1, (int) $strategy['max_per_day'] );
        $gap_hours   = max( 1, (int) $strategy['min_gap_hours'] );

        if ( empty( $days ) ) {
            $days = array( 1, 2, 3, 4, 5 ); // Default to weekdays
        }

        // Get already scheduled posts (future status)
        $scheduled = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'future',
            'posts_per_page' => 200,
            'orderby'        => 'date',
            'order'          => 'ASC',
        ) );
        $taken_dates = array();
        foreach ( $scheduled as $sp ) {
            $taken_dates[] = get_post_time( 'Y-m-d', false, $sp );
        }
        // Also exclude datetimes from concurrent operations
        foreach ( $exclude_datetimes as $edt ) {
            $taken_dates[] = substr( $edt, 0, 10 ); // Y-m-d part
        }
        $taken_counts = array_count_values( $taken_dates );

        $slots  = array();
        $cursor = new \DateTime( 'now', wp_timezone() );
        // If today's publication time has passed, start from tomorrow
        $now_hour = (int) $cursor->format( 'G' );
        if ( $now_hour >= $hour ) {
            $cursor->modify( '+1 day' );
        }

        $max_iterations = 120; // Safety: don't loop forever
        $i = 0;
        while ( count( $slots ) < $count && $i < $max_iterations ) {
            $dow = (int) $cursor->format( 'N' ); // 1=Mon, 7=Sun
            if ( in_array( $dow, $days, true ) ) {
                $date_key = $cursor->format( 'Y-m-d' );
                $posts_this_day = $taken_counts[ $date_key ] ?? 0;
                // Respect max_per_day
                if ( $posts_this_day < $max_per_day ) {
                    $slot_hour   = $hour + ( $posts_this_day * $gap_hours );
                    $slot_minute = $posts_this_day === 0 ? $minute : 0;
                    $slot = clone $cursor;
                    $slot->setTime( $slot_hour, $slot_minute, 0 );
                    // Only future slots
                    $now = new \DateTime( 'now', wp_timezone() );
                    if ( $slot > $now ) {
                        $slots[] = array(
                            'datetime'  => $slot->format( 'Y-m-d H:i:s' ),
                            'date_nice' => wp_date( 'l j F Y', $slot->getTimestamp() ),
                            'time_nice' => wp_date( 'H:i', $slot->getTimestamp() ),
                            'day_name'  => wp_date( 'D j M', $slot->getTimestamp() ),
                            'timestamp' => $slot->getTimestamp(),
                        );
                        $taken_counts[ $date_key ] = $posts_this_day + 1;
                    }
                }
            }
            $cursor->modify( '+1 day' );
            $i++;
        }
        return $slots;
    }

    /** AJAX: Save publishing strategy */
    public function ajax_save_pub_strategy() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $strategy = array(
            'posts_per_week' => max( 1, min( 14, (int) ( $_POST['posts_per_week'] ?? 3 ) ) ),
            'days'           => array_map( 'intval', (array) ( $_POST['days'] ?? array( 1, 3, 5 ) ) ),
            'hour'           => max( 0, min( 23, (int) ( $_POST['hour'] ?? 9 ) ) ),
            'minute'         => max( 0, min( 59, (int) ( $_POST['minute'] ?? 0 ) ) ),
            'min_gap_hours'  => max( 1, min( 12, (int) ( $_POST['min_gap_hours'] ?? 4 ) ) ),
            'max_per_day'    => max( 1, min( 5, (int) ( $_POST['max_per_day'] ?? 1 ) ) ),
        );
        // Filter valid days (1-7)
        $strategy['days'] = array_filter( $strategy['days'], function( $d ) { return $d >= 1 && $d <= 7; } );
        $strategy['days'] = array_values( $strategy['days'] );

        update_option( 'hts_pub_strategy', $strategy );

        // Return next slots preview
        $slots = self::get_next_available_slots( 5 );
        wp_send_json_success( array(
            'message' => 'Stratégie sauvegardée',
            'strategy' => $strategy,
            'next_slots' => $slots,
        ) );
    }

    /** AJAX: Auto-schedule a single draft to next available slot */
    public function ajax_draft_auto_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'draft', 'future' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Brouillon introuvable' ) );
        }

        $slots = self::get_next_available_slots( 1 );
        if ( empty( $slots ) ) {
            wp_send_json_error( array( 'message' => 'Aucun créneau disponible dans les 4 prochains mois' ) );
        }

        $slot = $slots[0];
        $ts   = $slot['timestamp'];

        wp_update_post( array(
            'ID'            => $post_id,
            'post_status'   => 'future',
            'post_date'     => date( 'Y-m-d H:i:s', $ts ),
            'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $ts ),
        ) );

        wp_send_json_success( array(
            'message'  => 'Planifié pour le ' . $slot['date_nice'] . ' à ' . $slot['time_nice'],
            'datetime' => $slot['datetime'],
            'day_nice' => $slot['day_name'],
            'post_id'  => $post_id,
        ) );
    }

    /** AJAX: Batch auto-schedule multiple drafts */
    public function ajax_draft_batch_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_ids = array_map( 'intval', (array) ( $_POST['post_ids'] ?? array() ) );
        $post_ids = array_filter( $post_ids );
        if ( empty( $post_ids ) ) {
            wp_send_json_error( array( 'message' => 'Aucun brouillon sélectionné' ) );
        }

        // Sort by priority score DESC to schedule most important first
        $scored = array();
        foreach ( $post_ids as $pid ) {
            $post = get_post( $pid );
            if ( ! $post || $post->post_status !== 'draft' ) continue;
            $pr = self::get_draft_priority( $pid );
            $scored[] = array( 'id' => $pid, 'score' => $pr['score'] );
        }
        usort( $scored, function( $a, $b ) { return $b['score'] - $a['score']; } );

        $slots = self::get_next_available_slots( count( $scored ) );
        $results = array();

        foreach ( $scored as $idx => $item ) {
            if ( ! isset( $slots[ $idx ] ) ) break;
            $slot = $slots[ $idx ];
            $ts   = $slot['timestamp'];

            wp_update_post( array(
                'ID'            => $item['id'],
                'post_status'   => 'future',
                'post_date'     => date( 'Y-m-d H:i:s', $ts ),
                'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $ts ),
            ) );

            $results[] = array(
                'post_id'  => $item['id'],
                'datetime' => $slot['datetime'],
                'day_nice' => $slot['day_name'],
                'title'    => get_the_title( $item['id'] ),
            );
        }

        wp_send_json_success( array(
            'message'   => count( $results ) . ' article(s) programmé(s)',
            'scheduled' => $results,
        ) );
    }

    /** AJAX: Cancel a scheduled post — revert future → draft */
    public function ajax_draft_unschedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'future' ) {
            wp_send_json_error( array( 'message' => 'Article planifié introuvable' ) );
        }

        wp_update_post( array(
            'ID'          => $post_id,
            'post_status' => 'draft',
        ) );

        wp_send_json_success( array(
            'message' => 'Programmation annulée — redevenu brouillon',
            'post_id' => $post_id,
        ) );
    }

    /** AJAX: Reschedule a post to a new date (drag & drop calendar) */
    public function ajax_draft_reschedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $new_date = sanitize_text_field( $_POST['new_date'] ?? '' ); // Y-m-d
        $post = get_post( $post_id );

        if ( ! $post || ! in_array( $post->post_status, array( 'future', 'draft' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Article introuvable' ) );
        }
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $new_date ) ) {
            wp_send_json_error( array( 'message' => 'Date invalide' ) );
        }

        // Keep the same time, just change the date
        $strategy = self::get_publishing_strategy();
        $hour   = str_pad( (int) $strategy['hour'], 2, '0', STR_PAD_LEFT );
        $minute = str_pad( (int) $strategy['minute'], 2, '0', STR_PAD_LEFT );
        $datetime = $new_date . ' ' . $hour . ':' . $minute . ':00';
        $ts = strtotime( $datetime );

        if ( ! $ts ) {
            wp_send_json_error( array( 'message' => 'Date invalide' ) );
        }

        $new_status = $ts > time() ? 'future' : 'publish';

        wp_update_post( array(
            'ID'            => $post_id,
            'post_status'   => $new_status,
            'post_date'     => date( 'Y-m-d H:i:s', $ts ),
            'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $ts ),
        ) );

        wp_send_json_success( array(
            'message' => 'Déplacé au ' . date_i18n( 'j M Y à H:i', $ts ),
            'post_id' => $post_id,
        ) );
    }

    /** Static: Build checklist for a draft post */
    public static function get_draft_checklist( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array();

        $content = $post->post_content;

        // ── Meta title ──
        $meta_title = get_post_meta( $post_id, '_hts_meta_title', true );
        if ( empty( $meta_title ) ) {
            // Fallback: check competitor meta (may exist if migration not yet done)
            if ( defined( 'WPSEO_VERSION' ) ) {
                $meta_title = get_post_meta( $post_id, '_yoast_wpseo_title', true );
            } elseif ( class_exists( 'RankMath' ) ) {
                $meta_title = get_post_meta( $post_id, 'rank_math_title', true );
            }
        }
        $has_meta_title = ! empty( trim( $meta_title ) );

        // ── Meta description ──
        $meta_desc = get_post_meta( $post_id, '_hts_meta_description', true );
        if ( empty( $meta_desc ) ) {
            if ( defined( 'WPSEO_VERSION' ) ) {
                $meta_desc = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );
            } elseif ( class_exists( 'RankMath' ) ) {
                $meta_desc = get_post_meta( $post_id, 'rank_math_description', true );
            }
        }
        $has_meta_desc = ! empty( trim( $meta_desc ) );

        // ── Word count ──
        $text = wp_strip_all_tags( $content );
        $word_count = hts_word_count( $text );
        if ( $word_count < 50 ) {
            $word_count = count( preg_split( '/\s+/', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );
        }

        // ── Images ──
        preg_match_all( '/<img[^>]+>/i', $content, $img_matches );
        $image_count = count( $img_matches[0] );
        $has_thumbnail = has_post_thumbnail( $post_id );

        // ── Internal links ──
        $site_host = wp_parse_url( site_url(), PHP_URL_HOST );
        preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $content, $link_matches );
        $internal_links = 0;
        $external_links = 0;
        foreach ( $link_matches[1] as $href ) {
            if ( strpos( $href, '#' ) === 0 ) continue;
            $host = wp_parse_url( $href, PHP_URL_HOST );
            if ( ! $host || $host === $site_host ) {
                $internal_links++;
            } else {
                $external_links++;
            }
        }

        // ── Headings structure ──
        preg_match_all( '/<h([2-4])[^>]*>/i', $content, $h_matches );
        $heading_count = count( $h_matches[0] );
        $has_h2 = in_array( '2', $h_matches[1] );

        // ── Slug ──
        $slug = $post->post_name;
        $slug_ok = ! empty( $slug ) && strlen( $slug ) >= 3 && strlen( $slug ) <= 75;
        if ( preg_match( '/^\d+$/', $slug ) ) $slug_ok = false;

        // ── GEO Score ──
        $geo_score = (int) get_post_meta( $post_id, '_hts_geo_score', true );

        // ── Image flag ──
        $image_missing = ( $image_count === 0 && ! $has_thumbnail );

        // ── Build checklist ──
        $checks = array(
            array(
                'key'   => 'meta_title',
                'label' => 'Meta title',
                'ok'    => $has_meta_title,
                'value' => $has_meta_title ? mb_substr( $meta_title, 0, 60 ) : '',
                'tip'   => $has_meta_title ? '' : 'Aucun meta title défini',
            ),
            array(
                'key'   => 'meta_desc',
                'label' => 'Meta description',
                'ok'    => $has_meta_desc,
                'value' => $has_meta_desc ? mb_substr( $meta_desc, 0, 80 ) . '...' : '',
                'tip'   => $has_meta_desc ? '' : 'Aucune meta description définie',
            ),
            array(
                'key'   => 'word_count',
                'label' => 'Longueur (' . number_format( $word_count ) . ' mots)',
                'ok'    => $word_count >= 800,
                'value' => $word_count,
                'tip'   => $word_count < 800 ? 'Minimum 800 mots recommandé' : '',
            ),
            array(
                'key'   => 'images',
                'label' => 'Images (' . $image_count . ' dans le contenu)',
                'ok'    => ! $image_missing,
                'value' => $image_count,
 'tip' => $image_missing ? 'Aucune image — impact SEO & GEO' : '',
            ),
            array(
                'key'   => 'featured_img',
                'label' => 'Image à la une',
                'ok'    => $has_thumbnail,
                'value' => $has_thumbnail ? get_the_post_thumbnail_url( $post_id, 'thumbnail' ) : '',
                'tip'   => $has_thumbnail ? '' : 'Pas d\'image à la une',
            ),
            array(
                'key'   => 'internal_links',
                'label' => 'Liens internes (' . $internal_links . ')',
                'ok'    => $internal_links >= 1,
                'value' => $internal_links,
                'tip'   => $internal_links < 1 ? 'Aucun lien interne' : '',
            ),
            array(
                'key'   => 'headings',
                'label' => 'Structure H2/H3 (' . $heading_count . ' titres)',
                'ok'    => $has_h2 && $heading_count >= 3,
                'value' => $heading_count,
                'tip'   => ! $has_h2 ? 'Aucun H2 détecté' : ( $heading_count < 3 ? 'Peu de sous-titres' : '' ),
            ),
            array(
                'key'   => 'slug',
                'label' => 'Slug',
                'ok'    => $slug_ok,
                'value' => $slug,
                'tip'   => $slug_ok ? '' : 'Slug trop court, trop long ou auto-généré',
            ),
        );

        $passed = count( array_filter( $checks, function( $c ) { return $c['ok']; } ) );
        $total  = count( $checks );
        $score  = $total > 0 ? round( ( $passed / $total ) * 100 ) : 0;

        return array(
            'checks'         => $checks,
            'score'          => $score,
            'passed'         => $passed,
            'total'          => $total,
            'geo_score'      => $geo_score,
            'word_count'     => $word_count,
            'image_count'    => $image_count,
            'image_missing'  => $image_missing,
            'internal_links' => $internal_links,
            'external_links' => $external_links,
            'heading_count'  => $heading_count,
            'has_thumbnail'  => $has_thumbnail,
            'meta_title'     => $meta_title,
            'meta_desc'      => $meta_desc,
            'slug'           => $slug,
            'cross_links_out' => (int) get_post_meta( $post_id, '_hts_cross_links_out', true ),
            'cross_links_in'  => (int) get_post_meta( $post_id, '_hts_cross_links_in', true ),
        );
    }

    /**
     * Calcule le score de priorité composite d'un brouillon (0-100)
     * 
     * 4 dimensions :
     * - Urgence stratégique (30%) : orphelin cocon, cluster prioritaire
     * - Complétude (25%) : checklist score
     * - Potentiel SEO (25%) : impressions GSC, position dans cocon
     * - Fraîcheur draft (20%) : ancienneté du brouillon
     *
     * @since 2.5.0
     */
    public static function get_draft_priority( $post_id, $checklist = null ) {
        $post = get_post( $post_id );
 if ( ! $post ) return array( 'score' => 0, 'label' => 'unknown', 'icon' => '', 'components' => array() );

        if ( ! $checklist ) {
            $checklist = self::get_draft_checklist( $post_id );
        }

        $components = array();

        // ── 1. Urgence stratégique (30%) ──
        $strategic = 0;

        // Est-ce lié à un cocon ?
        $cocon_id = get_post_meta( $post_id, '_hts_api_cocon_id', true );
        if ( $cocon_id ) $strategic += 30; // Fait partie d'une stratégie cocon

        // Est-ce généré par l'API HTS ?
        $is_api = (bool) get_post_meta( $post_id, '_hts_api_generated', true );
        if ( $is_api ) $strategic += 25; // Généré = priorisé

        // A-t-il un mot-clé ciblé ?
        $keyword = get_post_meta( $post_id, '_hts_api_keyword', true );
        if ( ! $keyword && defined( 'WPSEO_VERSION' ) ) {
            $keyword = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
        }
        if ( ! $keyword && class_exists( 'RankMath' ) ) {
            $keyword = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        }
        if ( $keyword ) $strategic += 20;

        // Catégorie assignée (vs non classé)
        $cats = wp_get_post_categories( $post_id );
        $has_category = ! empty( $cats ) && ! ( count( $cats ) === 1 && $cats[0] == 1 ); // 1 = Uncategorized
        if ( $has_category ) $strategic += 15;

        // Image manquante = urgence
        if ( $checklist['image_missing'] ?? false ) $strategic += 10;

        $strategic = min( 100, $strategic );
        $components['strategic'] = $strategic;

        // ── 2. Complétude (25%) ──
        $completude = $checklist['score'] ?? 0;
        $components['completude'] = $completude;

        // ── 3. Potentiel SEO (25%) ──
        $potential = 0;

        // GEO Score (si disponible)
        $geo = $checklist['geo_score'] ?? 0;
        if ( $geo > 0 ) $potential += min( 40, $geo * 0.6 );

        // Longueur contenu (plus c'est long, plus c'est investi)
        $wc = $checklist['word_count'] ?? 0;
        if ( $wc >= 2000 ) $potential += 30;
        elseif ( $wc >= 1200 ) $potential += 20;
        elseif ( $wc >= 800 ) $potential += 10;

        // Liens internes (maillage = potentiel)
        $il = $checklist['internal_links'] ?? 0;
        if ( $il >= 3 ) $potential += 20;
        elseif ( $il >= 1 ) $potential += 10;

        // Keyword present
        if ( $keyword ) $potential += 10;

        $potential = min( 100, $potential );
        $components['potential'] = $potential;

        // ── 4. Fraîcheur du draft (20%) ──
        $age_days = ( time() - strtotime( $post->post_date ) ) / DAY_IN_SECONDS;
        if ( $age_days <= 3 ) $freshness = 100;       // Très récent
        elseif ( $age_days <= 7 ) $freshness = 80;     // Cette semaine
        elseif ( $age_days <= 14 ) $freshness = 60;    // 2 semaines
        elseif ( $age_days <= 30 ) $freshness = 40;    // Ce mois
        else $freshness = max( 10, 100 - (int) $age_days ); // Vieux = urgence basse mais non nul

        $components['freshness'] = $freshness;
        $components['age_days'] = round( $age_days );

        // ── Score composite ──
        $score = round(
            $strategic * 0.30 +
            $completude * 0.25 +
            $potential * 0.25 +
            $freshness * 0.20
        );

        // ── Label ──
        if ( $score >= 70 ) {
 $label = 'high'; $icon = ''; $text = 'Prioritaire';
        } elseif ( $score >= 40 ) {
 $label = 'medium'; $icon = ''; $text = 'À traiter';
        } else {
 $label = 'low'; $icon = ''; $text = 'En attente';
        }

        return array(
            'score'      => $score,
            'label'      => $label,
            'icon'       => $icon,
            'text'       => $text,
            'components' => $components,
        );
    }

    /**
     * Récupère les données du calendrier éditorial
     * Posts publiés + planifiés + brouillons pour un mois donné
     *
     * @since 2.5.0
     */
    public static function get_calendar_data( $year, $month ) {
        $start = sprintf( '%04d-%02d-01 00:00:00', $year, $month );
        $end   = date( 'Y-m-t 23:59:59', strtotime( $start ) );

        $posts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => array( 'publish', 'future', 'draft' ),
            'posts_per_page' => 200,
            'date_query'     => array(
                array(
                    'after'     => $start,
                    'before'    => $end,
                    'inclusive' => true,
                ),
            ),
            'orderby' => 'date',
            'order'   => 'ASC',
        ) );

        // Also get drafts without date constraint (they sit in limbo)
        $drafts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'draft',
            'posts_per_page' => 50,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ) );

        $events = array();
        $seen = array();

        foreach ( array_merge( $posts, $drafts ) as $p ) {
            if ( isset( $seen[ $p->ID ] ) ) continue;
            $seen[ $p->ID ] = true;

            $is_api = (bool) get_post_meta( $p->ID, '_hts_api_generated', true );
            $keyword = get_post_meta( $p->ID, '_hts_api_keyword', true );

            $events[] = array(
                'id'       => $p->ID,
                'title'    => $p->post_title ?: '(Sans titre)',
                'date'     => $p->post_date,
                'day'      => (int) date( 'j', strtotime( $p->post_date ) ),
                'month'    => (int) date( 'n', strtotime( $p->post_date ) ),
                'status'   => $p->post_status,
                'type'     => $p->post_type,
                'is_api'   => $is_api,
                'keyword'  => $keyword ?: '',
                'edit_url' => get_edit_post_link( $p->ID, 'raw' ),
                'view_url' => $p->post_status === 'publish' ? get_permalink( $p->ID ) : '',
            );
        }

        return $events;
    }

    /** Get the active API base URL (preprod or prod) */
    public static function get_api_base_url() {
        return get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
    }
}
