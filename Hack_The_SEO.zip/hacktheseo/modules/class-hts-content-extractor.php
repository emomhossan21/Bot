<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Content Extractor — Universal content extraction for all major page builders.
 *
 * Detects and extracts clean text + images from:
 * - Standard WordPress (Gutenberg / Classic Editor)
 * - Elementor (_elementor_data JSON)
 * - Divi Builder ([et_pb_*] shortcodes)
 * - WPBakery / Visual Composer ([vc_*] shortcodes)
 * - Beaver Builder (_fl_builder_data serialized)
 * - WooCommerce (post_content + post_excerpt + product tabs)
 * - Oxygen Builder (ct_builder_shortcodes)
 * - Bricks Builder (_bricks_page_content_2 JSON)
 * - Brizy (_brizy_post)
 *
 * @package HackTheSEO
 * @since   3.5.1
 */

class HTS_Content_Extractor {

    /**
     * Detected builder for the last extraction.
     *
     * @var string
     */
    private static $last_builder = 'standard';

    /**
     * In-memory cache for the current PHP request.
     *
     * @var array [ post_id => [ 'content' => string, 'builder' => string ] ]
     */
    private static $cache = array();

    /**
     * Transient cache TTL (1 hour).
     */
    const CACHE_TTL = HOUR_IN_SECONDS;

    /**
     * Register hooks for cache invalidation.
     */
    public static function init_hooks() {
        add_action( 'save_post',        array( __CLASS__, 'invalidate_cache' ) );
        add_action( 'delete_post',      array( __CLASS__, 'invalidate_cache' ) );
        add_action( 'wp_trash_post',    array( __CLASS__, 'invalidate_cache' ) );
        // Elementor-specific save hook
        add_action( 'elementor/editor/after_save', array( __CLASS__, 'invalidate_cache' ) );
    }

    /**
     * Invalidate cache for a post.
     *
     * @param int $post_id
     */
    public static function invalidate_cache( $post_id ) {
        unset( self::$cache[ $post_id ] );
        delete_transient( 'hts_cx_' . $post_id );
    }

    /**
     * Get the detected builder for the last extraction.
     *
     * @return string
     */
    public static function get_detected_builder() {
        return self::$last_builder;
    }

    /**
     * Extract clean content (HTML with text) from a post, regardless of page builder.
     *
     * @param int $post_id
     * @return string Clean HTML content
     */
    public static function get_content( $post_id ) {
        // ── 1. In-memory cache (same PHP request) ──
        if ( isset( self::$cache[ $post_id ] ) ) {
            self::$last_builder = self::$cache[ $post_id ]['builder'];
            return self::$cache[ $post_id ]['content'];
        }

        // ── 2. Transient cache (cross-request, 1h TTL) ──
        $transient = get_transient( 'hts_cx_' . $post_id );
        if ( $transient !== false && is_array( $transient ) ) {
            self::$last_builder = $transient['builder'];
            self::$cache[ $post_id ] = $transient;
            return $transient['content'];
        }

        $post = get_post( $post_id );
        if ( ! $post ) return '';

        $content = $post->post_content;
        self::$last_builder = 'standard';

        // ── 1. Elementor ──
        if ( self::is_elementor( $post_id ) ) {
            $elementor_content = self::extract_elementor( $post_id );
            if ( $elementor_content ) {
                self::$last_builder = 'elementor';
                $content = $elementor_content;
            }
        }

        // ── 2. Divi Builder ──
        elseif ( self::is_divi( $content ) ) {
            self::$last_builder = 'divi';
            $content = self::extract_divi( $content );
        }

        // ── 3. WPBakery / Visual Composer ──
        elseif ( self::is_wpbakery( $content ) ) {
            self::$last_builder = 'wpbakery';
            $content = self::extract_wpbakery( $content );
        }

        // ── 4. Beaver Builder ──
        elseif ( self::is_beaver( $post_id ) ) {
            $beaver_content = self::extract_beaver( $post_id );
            if ( $beaver_content ) {
                self::$last_builder = 'beaver';
                $content = $beaver_content;
            }
        }

        // ── 5. Oxygen Builder ──
        elseif ( self::is_oxygen( $post_id ) ) {
            $oxygen_content = self::extract_oxygen( $post_id );
            if ( $oxygen_content ) {
                self::$last_builder = 'oxygen';
                $content = $oxygen_content;
            }
        }

        // ── 6. Bricks Builder ──
        elseif ( self::is_bricks( $post_id ) ) {
            $bricks_content = self::extract_bricks( $post_id );
            if ( $bricks_content ) {
                self::$last_builder = 'bricks';
                $content = $bricks_content;
            }
        }

        // ── 7. Brizy ──
        elseif ( self::is_brizy( $post_id ) ) {
            $brizy_content = self::extract_brizy( $post_id );
            if ( $brizy_content ) {
                self::$last_builder = 'brizy';
                $content = $brizy_content;
            }
        }

        // ── 8. Standard Gutenberg: strip block comments ──
        elseif ( preg_match( '/<!-- wp:/', $content ) ) {
            self::$last_builder = 'gutenberg';
            // Gutenberg stores clean HTML with comments — just strip comments
            $content = preg_replace( '/<!--\s*\/?wp:[^>]*-->/s', '', $content );
        }

        // ── 8b. Fallback: process remaining shortcodes ──
        // If no builder was detected but content contains shortcodes, render them via do_shortcode().
        // This handles custom shortcodes from themes/plugins not covered by the builder chain.
        elseif ( preg_match( '/\[[a-zA-Z_][a-zA-Z0-9_]*[\s\]]/', $content ) && function_exists( 'do_shortcode' ) ) {
            self::$last_builder = 'shortcode_fallback';
            $content = do_shortcode( $content );
        }

        // ── 9. WooCommerce: append short description ──
        if ( $post->post_type === 'product' ) {
            self::$last_builder .= '+woo';
            if ( $post->post_excerpt ) {
                $content = $post->post_excerpt . "\n\n" . $content;
            }
            // Also get WooCommerce product attributes/tabs content
            $content .= self::extract_woo_extra( $post_id );
        }

        // Final cleanup: normalize whitespace, remove empty tags
        $content = preg_replace( '/\n{3,}/', "\n\n", $content );
        $content = preg_replace( '/<(p|div|span)\s*>\s*<\/\1>/i', '', $content );
        $content = trim( $content );

        // ── Store in cache ──
        $cache_entry = array( 'content' => $content, 'builder' => self::$last_builder );
        self::$cache[ $post_id ] = $cache_entry;
        set_transient( 'hts_cx_' . $post_id, $cache_entry, self::CACHE_TTL );

        return $content;
    }

    /**
     * Extract all images from a post, regardless of page builder.
     * Returns array of img tags (HTML strings).
     *
     * @param int    $post_id
     * @param string $content Already extracted content (optional)
     * @return array  Array of <img> tag strings
     */
    public static function get_images( $post_id, $content = '' ) {
        if ( ! $content ) {
            $content = self::get_content( $post_id );
        }

        $images = array();

        // Standard: images from content
        preg_match_all( '/<img[^>]+>/i', $content, $matches );
        $images = $matches[0] ?? array();

        // Elementor: images from _elementor_data
        if ( self::is_elementor( $post_id ) ) {
            $extra = self::extract_elementor_images( $post_id );
            $images = array_merge( $images, $extra );
        }

        // Beaver Builder: images from _fl_builder_data
        if ( self::is_beaver( $post_id ) ) {
            $extra = self::extract_beaver_images( $post_id );
            $images = array_merge( $images, $extra );
        }

        // ── Resolve lazy-loaded images (data-src → src) ──
        $images = array_map( array( __CLASS__, 'resolve_lazy_src' ), $images );

        // ── Filter out decorative SVGs (icons, logos, separators) ──
        $images = array_filter( $images, function( $img ) {
            return ! self::is_decorative_svg( $img );
        } );

        // Deduplicate by src
        $seen_srcs = array();
        $unique = array();
        foreach ( $images as $img ) {
            if ( preg_match( '/src\s*=\s*["\']([^"\']+)["\']/', $img, $m ) ) {
                $src_key = strtolower( basename( $m[1] ) );
                // Strip size suffix for dedup
                $src_key = preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', $src_key );
                if ( isset( $seen_srcs[ $src_key ] ) ) continue;
                $seen_srcs[ $src_key ] = true;
            }
            $unique[] = $img;
        }

        return $unique;
    }

    /* ══════════════════════════════════════════════
     *  DETECTION METHODS
     * ══════════════════════════════════════════════ */

    public static function is_elementor( $post_id ) {
        return get_post_meta( $post_id, '_elementor_edit_mode', true ) === 'builder';
    }

    public static function is_divi( $content ) {
        return (bool) preg_match( '/\[et_pb_/', $content );
    }

    public static function is_wpbakery( $content ) {
        return (bool) preg_match( '/\[vc_/', $content );
    }

    public static function is_beaver( $post_id ) {
        return (bool) get_post_meta( $post_id, '_fl_builder_enabled', true );
    }

    public static function is_oxygen( $post_id ) {
        return (bool) get_post_meta( $post_id, 'ct_builder_shortcodes', true );
    }

    public static function is_bricks( $post_id ) {
        return (bool) get_post_meta( $post_id, '_bricks_page_content_2', true );
    }

    public static function is_brizy( $post_id ) {
        return (bool) get_post_meta( $post_id, 'brizy_post_uid', true );
    }

    /* ══════════════════════════════════════════════
     *  ELEMENTOR
     * ══════════════════════════════════════════════ */

    /**
     * Extract text content from Elementor JSON data.
     * Elementor stores content in _elementor_data as JSON.
     * Text is in widgets with widgetType "text-editor", "heading", "icon-box", etc.
     * Content is in settings.editor, settings.title, settings.description_text.
     */
    private static function extract_elementor( $post_id ) {
        $data = get_post_meta( $post_id, '_elementor_data', true );
        if ( ! $data ) return '';

        if ( is_string( $data ) ) {
            $data = json_decode( $data, true );
        }
        if ( ! is_array( $data ) ) return '';

        $parts = array();
        self::walk_elementor( $data, $parts );

        return implode( "\n\n", $parts );
    }

    /**
     * Recursively walk Elementor JSON structure.
     */
    private static function walk_elementor( $elements, &$parts ) {
        foreach ( $elements as $el ) {
            // Extract text from known widget types
            if ( isset( $el['widgetType'] ) ) {
                // Skip navigation widgets — they pollute meta descriptions
                $skip_widgets = array( 'nav-menu', 'navigation-menu', 'mega-menu', 'menu-anchor', 'sitemap' );
                if ( in_array( $el['widgetType'], $skip_widgets, true ) ) {
                    continue;
                }

                $settings = $el['settings'] ?? array();

                switch ( $el['widgetType'] ) {
                    case 'text-editor':
                        if ( ! empty( $settings['editor'] ) ) {
                            $parts[] = $settings['editor'];
                        }
                        break;

                    case 'heading':
                        if ( ! empty( $settings['title'] ) ) {
                            $tag = $settings['header_size'] ?? 'h2';
                            $parts[] = '<' . $tag . '>' . $settings['title'] . '</' . $tag . '>';
                        }
                        break;

                    case 'icon-box':
                    case 'image-box':
                    case 'call-to-action':
                        if ( ! empty( $settings['title_text'] ) ) {
                            $parts[] = '<h3>' . $settings['title_text'] . '</h3>';
                        }
                        if ( ! empty( $settings['description_text'] ) ) {
                            $parts[] = '<p>' . $settings['description_text'] . '</p>';
                        }
                        break;

                    case 'accordion':
                    case 'toggle':
                    case 'faq':
                        // Output as <details><summary> for FAQ schema auto-detection
                        // Elementor Pro FAQ widget uses faq_title/faq_content; accordion uses tab_title/tab_content
                        foreach ( $settings['tabs'] ?? array() as $tab ) {
                            $title   = $tab['tab_title'] ?? ( $tab['faq_title'] ?? '' );
                            $content_text = $tab['tab_content'] ?? ( $tab['faq_content'] ?? '' );
                            if ( $title && $content_text ) {
                                $parts[] = '<details><summary>' . $title . '</summary>' . $content_text . '</details>';
                            } elseif ( $title ) {
                                $parts[] = '<h3>' . $title . '</h3>';
                            }
                        }
                        break;

                    case 'tabs':
                        foreach ( $settings['tabs'] ?? array() as $tab ) {
                            if ( ! empty( $tab['tab_title'] ) ) {
                                $parts[] = '<h3>' . $tab['tab_title'] . '</h3>';
                            }
                            if ( ! empty( $tab['tab_content'] ) ) {
                                $parts[] = $tab['tab_content'];
                            }
                        }
                        break;

                    case 'image':
                        if ( ! empty( $settings['image']['url'] ) ) {
                            $alt = $settings['image']['alt'] ?? '';
                            $id  = $settings['image']['id'] ?? 0;
                            $cls = $id ? ' class="wp-image-' . $id . '"' : '';
                            $parts[] = '<img src="' . esc_url( $settings['image']['url'] ) . '" alt="' . esc_attr( $alt ) . '"' . $cls . ' />';
                        }
                        break;

                    case 'testimonial':
                        if ( ! empty( $settings['testimonial_content'] ) ) {
                            $parts[] = '<blockquote>' . $settings['testimonial_content'] . '</blockquote>';
                        }
                        break;

                    case 'video':
                        // Elementor video widget — extract URL for VideoObject schema detection
                        $video_url = $settings['youtube_url'] ?? ( $settings['vimeo_url'] ?? ( $settings['hosted_url']['url'] ?? '' ) );
                        if ( $video_url ) {
                            if ( strpos( $video_url, 'youtube' ) !== false || strpos( $video_url, 'youtu.be' ) !== false ) {
                                $parts[] = '<iframe src="' . esc_url( $video_url ) . '"></iframe>';
                            } elseif ( strpos( $video_url, 'vimeo' ) !== false ) {
                                $parts[] = '<iframe src="' . esc_url( $video_url ) . '"></iframe>';
                            } else {
                                $parts[] = '<video src="' . esc_url( $video_url ) . '"></video>';
                            }
                        }
                        break;

                    case 'star-rating':
                        // Extract rating for Review schema detection
                        $rating_val = $settings['rating']['size'] ?? ( $settings['rating_scale'] ?? '' );
                        if ( $rating_val ) {
                            $parts[] = '<span class="hts-rating">Note : ' . esc_html( $rating_val ) . '/5</span>';
                        }
                        break;

                    case 'shortcode':
                        // Process shortcodes inside Elementor
                        if ( ! empty( $settings['shortcode'] ) && function_exists( 'do_shortcode' ) ) {
                            $sc_output = do_shortcode( $settings['shortcode'] );
                            if ( mb_strlen( strip_tags( $sc_output ) ) > 10 ) {
                                $parts[] = $sc_output;
                            }
                        }
                        break;

                    case 'price-table':
                    case 'price-list':
                        if ( ! empty( $settings['heading'] ) ) {
                            $parts[] = '<h3>' . $settings['heading'] . '</h3>';
                        }
                        if ( ! empty( $settings['sub_heading'] ) ) {
                            $parts[] = '<p>' . $settings['sub_heading'] . '</p>';
                        }
                        break;

                    case 'icon-list':
                        // Elementor icon list → <ul> for ItemList schema detection
                        $list_items = '';
                        foreach ( $settings['icon_list'] ?? array() as $li ) {
                            $li_text = $li['text'] ?? '';
                            if ( $li_text ) $list_items .= '<li>' . $li_text . '</li>';
                        }
                        if ( $list_items ) $parts[] = '<ul>' . $list_items . '</ul>';
                        break;

                    case 'nested-accordion':
                        // Elementor 3.x nested accordion
                        foreach ( $settings['items'] ?? array() as $item ) {
                            $title   = $item['item_title'] ?? ( $item['title'] ?? '' );
                            $content_html = $item['item_content'] ?? ( $item['content'] ?? '' );
                            if ( $title && $content_html ) {
                                $parts[] = '<details><summary>' . $title . '</summary>' . $content_html . '</details>';
                            }
                        }
                        break;

                    default:
                        // Try generic content fields
                        foreach ( array( 'editor', 'title', 'content', 'description', 'description_text' ) as $field ) {
                            if ( ! empty( $settings[ $field ] ) && is_string( $settings[ $field ] ) && mb_strlen( $settings[ $field ] ) > 10 ) {
                                $parts[] = $settings[ $field ];
                            }
                        }
                        // Catch-all for addon accordions (Essential Addons, JetElements, PowerPack, etc.)
                        // These store items as arrays with title/content variations
                        foreach ( array( 'tabs', 'items', 'accordions', 'faq_list', 'toggle_items', 'eael_adv_accordion_list' ) as $items_key ) {
                            if ( ! empty( $settings[ $items_key ] ) && is_array( $settings[ $items_key ] ) ) {
                                foreach ( $settings[ $items_key ] as $item ) {
                                    if ( ! is_array( $item ) ) continue;
                                    // Try common title/content key patterns
                                    $item_title = '';
                                    foreach ( array( 'tab_title', 'faq_title', 'title', 'accordion_title', 'item_title', 'eael_adv_accordion_tab_title', 'question' ) as $tk ) {
                                        if ( ! empty( $item[ $tk ] ) ) { $item_title = $item[ $tk ]; break; }
                                    }
                                    $item_body = '';
                                    foreach ( array( 'tab_content', 'faq_content', 'content', 'accordion_content', 'item_content', 'eael_adv_accordion_tab_content', 'answer' ) as $ck ) {
                                        if ( ! empty( $item[ $ck ] ) ) { $item_body = $item[ $ck ]; break; }
                                    }
                                    if ( $item_title && $item_body ) {
                                        $parts[] = '<details><summary>' . $item_title . '</summary>' . $item_body . '</details>';
                                    } elseif ( $item_title ) {
                                        $parts[] = '<h3>' . $item_title . '</h3>';
                                    }
                                }
                            }
                        }
                        break;
                }
            }

            // Recurse into children
            if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
                self::walk_elementor( $el['elements'], $parts );
            }
        }
    }

    /**
     * Extract image tags from Elementor data.
     */
    private static function extract_elementor_images( $post_id ) {
        $data = get_post_meta( $post_id, '_elementor_data', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) return array();

        $images = array();
        self::walk_elementor_images( $data, $images );
        return $images;
    }

    private static function walk_elementor_images( $elements, &$images ) {
        foreach ( $elements as $el ) {
            if ( isset( $el['widgetType'] ) && $el['widgetType'] === 'image' ) {
                $s = $el['settings'] ?? array();
                if ( ! empty( $s['image']['url'] ) ) {
                    $alt = $s['image']['alt'] ?? '';
                    $id  = $s['image']['id'] ?? 0;
                    $cls = $id ? ' class="wp-image-' . $id . '"' : '';
                    $images[] = '<img src="' . esc_url( $s['image']['url'] ) . '" alt="' . esc_attr( $alt ) . '"' . $cls . ' />';
                }
            }
            // Background images on sections/columns
            if ( isset( $el['settings']['background_image']['url'] ) && ! empty( $el['settings']['background_image']['url'] ) ) {
                $url = $el['settings']['background_image']['url'];
                $alt = $el['settings']['background_image']['alt'] ?? '';
                $id  = $el['settings']['background_image']['id'] ?? 0;
                $cls = $id ? ' class="wp-image-' . $id . '"' : '';
                $images[] = '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '"' . $cls . ' />';
            }
            if ( ! empty( $el['elements'] ) ) {
                self::walk_elementor_images( $el['elements'], $images );
            }
        }
    }

    /* ══════════════════════════════════════════════
     *  DIVI
     * ══════════════════════════════════════════════ */

    /**
     * Extract content from Divi shortcodes.
     * Text is inside [et_pb_text]...[/et_pb_text].
     * Headings in [et_pb_text] with admin_label, images in [et_pb_image].
     * Strategy: extract content from text modules, strip all other shortcodes.
     */
    private static function extract_divi( $content ) {
        $parts = array();

        // Extract content from et_pb_text modules (main text content)
        if ( preg_match_all( '/\[et_pb_text[^\]]*\](.*?)\[\/et_pb_text\]/s', $content, $matches ) ) {
            foreach ( $matches[1] as $text_content ) {
                $clean = self::strip_shortcodes_keep_content( $text_content );
                if ( trim( strip_tags( $clean ) ) ) {
                    $parts[] = $clean;
                }
            }
        }

        // Extract image modules
        if ( preg_match_all( '/\[et_pb_image[^\]]*\]/', $content, $img_matches ) ) {
            foreach ( $img_matches[0] as $img_shortcode ) {
                if ( preg_match( '/src="([^"]+)"/', $img_shortcode, $src_m ) ) {
                    $alt = '';
                    if ( preg_match( '/alt="([^"]*)"/', $img_shortcode, $alt_m ) ) $alt = $alt_m[1];
                    $parts[] = '<img src="' . esc_url( $src_m[1] ) . '" alt="' . esc_attr( $alt ) . '" />';
                }
            }
        }

        // Extract headings
        if ( preg_match_all( '/\[et_pb_heading[^\]]*\](.*?)\[\/et_pb_heading\]/s', $content, $h_matches ) ) {
            foreach ( $h_matches[1] as $heading ) {
                $parts[] = '<h2>' . wp_strip_all_tags( $heading ) . '</h2>';
            }
        }

        // Extract blurb titles and content
        if ( preg_match_all( '/\[et_pb_blurb[^\]]*title="([^"]*)"[^\]]*\](.*?)\[\/et_pb_blurb\]/s', $content, $blurb_matches, PREG_SET_ORDER ) ) {
            foreach ( $blurb_matches as $blurb ) {
                $parts[] = '<h3>' . $blurb[1] . '</h3>';
                $clean = self::strip_shortcodes_keep_content( $blurb[2] );
                if ( trim( strip_tags( $clean ) ) ) $parts[] = $clean;
            }
        }

        // Extract toggle/accordion modules (FAQ pattern) → <details><summary>
        if ( preg_match_all( '/\[et_pb_(?:toggle|accordion_item)[^\]]*title="([^"]*)"[^\]]*\](.*?)\[\/et_pb_(?:toggle|accordion_item)\]/s', $content, $toggle_matches, PREG_SET_ORDER ) ) {
            foreach ( $toggle_matches as $tg ) {
                $clean = self::strip_shortcodes_keep_content( $tg[2] );
                $parts[] = '<details><summary>' . $tg[1] . '</summary>' . $clean . '</details>';
            }
        }

        // Extract video modules
        if ( preg_match_all( '/\[et_pb_video[^\]]*src="([^"]*)"[^\]]*\]/s', $content, $vid_matches ) ) {
            foreach ( $vid_matches[1] as $vid_url ) {
                if ( $vid_url ) $parts[] = '<iframe src="' . esc_url( $vid_url ) . '"></iframe>';
            }
        }

        // Fallback: if we got nothing, strip all Divi shortcodes and return what's left
        if ( empty( $parts ) ) {
            return self::strip_shortcodes_keep_content( $content );
        }

        return implode( "\n\n", $parts );
    }

    /* ══════════════════════════════════════════════
     *  WPBAKERY / VISUAL COMPOSER
     * ══════════════════════════════════════════════ */

    /**
     * Extract content from WPBakery shortcodes.
     * Text is inside [vc_column_text]...[/vc_column_text].
     * Images in [vc_single_image].
     */
    private static function extract_wpbakery( $content ) {
        $parts = array();

        // Extract vc_column_text (main content blocks)
        if ( preg_match_all( '/\[vc_column_text[^\]]*\](.*?)\[\/vc_column_text\]/s', $content, $matches ) ) {
            foreach ( $matches[1] as $text ) {
                $clean = self::strip_shortcodes_keep_content( $text );
                if ( trim( strip_tags( $clean ) ) ) {
                    $parts[] = $clean;
                }
            }
        }

        // Extract vc_custom_heading
        if ( preg_match_all( '/\[vc_custom_heading[^\]]*text="([^"]*)"[^\]]*\]/', $content, $h_matches ) ) {
            foreach ( $h_matches[1] as $heading ) {
                $parts[] = '<h2>' . $heading . '</h2>';
            }
        }

        // Extract vc_single_image
        if ( preg_match_all( '/\[vc_single_image[^\]]*image="(\d+)"[^\]]*\]/', $content, $img_matches ) ) {
            foreach ( $img_matches[1] as $attach_id ) {
                $url = wp_get_attachment_url( (int) $attach_id );
                $alt = get_post_meta( (int) $attach_id, '_wp_attachment_image_alt', true );
                if ( $url ) {
                    $parts[] = '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . $attach_id . '" />';
                }
            }
        }

        // Extract vc_raw_html (base64 encoded)
        if ( preg_match_all( '/\[vc_raw_html[^\]]*\](.*?)\[\/vc_raw_html\]/s', $content, $raw_matches ) ) {
            foreach ( $raw_matches[1] as $raw ) {
                $decoded = base64_decode( $raw );
                if ( $decoded && mb_strlen( strip_tags( $decoded ) ) > 20 ) {
                    $parts[] = $decoded;
                }
            }
        }

        // Extract vc_tta_accordion / vc_tta_toggle sections (FAQ pattern) → <details><summary>
        if ( preg_match_all( '/\[vc_tta_section[^\]]*title="([^"]*)"[^\]]*\](.*?)\[\/vc_tta_section\]/s', $content, $acc_matches, PREG_SET_ORDER ) ) {
            foreach ( $acc_matches as $acc ) {
                $clean = self::strip_shortcodes_keep_content( $acc[2] );
                if ( trim( strip_tags( $clean ) ) ) {
                    $parts[] = '<details><summary>' . $acc[1] . '</summary>' . $clean . '</details>';
                }
            }
        }

        // Extract vc_video
        if ( preg_match_all( '/\[vc_video[^\]]*link="([^"]*)"[^\]]*\]/', $content, $vid_matches ) ) {
            foreach ( $vid_matches[1] as $vid_url ) {
                if ( $vid_url ) $parts[] = '<iframe src="' . esc_url( $vid_url ) . '"></iframe>';
            }
        }

        // Fallback
        if ( empty( $parts ) ) {
            return self::strip_shortcodes_keep_content( $content );
        }

        return implode( "\n\n", $parts );
    }

    /* ══════════════════════════════════════════════
     *  BEAVER BUILDER
     * ══════════════════════════════════════════════ */

    /**
     * Beaver Builder stores data in _fl_builder_data (serialized array).
     * Modules of type "rich-text" have settings->text with HTML.
     * Also "heading" type with settings->heading.
     */
    private static function extract_beaver( $post_id ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) return '';

        $parts = array();
        foreach ( $data as $node ) {
            if ( ! isset( $node->type ) ) continue;
            $settings = $node->settings ?? new \stdClass();

            if ( $node->type === 'module' ) {
                $module_type = $settings->type ?? '';

                // Rich text / text-editor
                if ( isset( $settings->text ) && mb_strlen( $settings->text ) > 10 ) {
                    $parts[] = $settings->text;
                }
                // Heading
                if ( isset( $settings->heading ) && $settings->heading ) {
                    $tag = $settings->tag ?? 'h2';
                    $parts[] = '<' . $tag . '>' . $settings->heading . '</' . $tag . '>';
                }
                // HTML module
                if ( isset( $settings->html ) && mb_strlen( strip_tags( $settings->html ) ) > 20 ) {
                    $parts[] = $settings->html;
                }
                // Photo module
                if ( isset( $settings->photo_src ) && $settings->photo_src ) {
                    $alt = $settings->alt ?? '';
                    $parts[] = '<img src="' . esc_url( $settings->photo_src ) . '" alt="' . esc_attr( $alt ) . '" />';
                }
                // Accordion module (FAQ pattern) → <details><summary>
                if ( isset( $settings->items ) && is_array( $settings->items ) ) {
                    foreach ( $settings->items as $item ) {
                        $item_label   = $item->label ?? '';
                        $item_content = $item->content ?? '';
                        if ( $item_label && $item_content ) {
                            $parts[] = '<details><summary>' . $item_label . '</summary>' . $item_content . '</details>';
                        }
                    }
                }
                // Video module
                if ( isset( $settings->video_url ) && $settings->video_url ) {
                    $parts[] = '<iframe src="' . esc_url( $settings->video_url ) . '"></iframe>';
                }
                if ( isset( $settings->embed_code ) && $settings->embed_code ) {
                    $parts[] = $settings->embed_code;
                }
            }
        }

        return implode( "\n\n", $parts );
    }

    /**
     * Extract images from Beaver Builder data.
     */
    private static function extract_beaver_images( $post_id ) {
        $data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( ! is_array( $data ) ) return array();

        $images = array();
        foreach ( $data as $node ) {
            if ( ! isset( $node->type ) || $node->type !== 'module' ) continue;
            $settings = $node->settings ?? new \stdClass();
            if ( isset( $settings->photo_src ) && $settings->photo_src ) {
                $alt = $settings->alt ?? '';
                $images[] = '<img src="' . esc_url( $settings->photo_src ) . '" alt="' . esc_attr( $alt ) . '" />';
            }
        }
        return $images;
    }

    /* ══════════════════════════════════════════════
     *  OXYGEN BUILDER
     * ══════════════════════════════════════════════ */

    /**
     * Oxygen stores shortcodes in ct_builder_shortcodes post meta.
     * Uses [ct_text_block] and [ct_headline] shortcodes.
     */
    private static function extract_oxygen( $post_id ) {
        $shortcodes = get_post_meta( $post_id, 'ct_builder_shortcodes', true );
        if ( ! $shortcodes ) return '';

        $parts = array();

        // Text blocks
        if ( preg_match_all( '/\[ct_text_block[^\]]*\](.*?)\[\/ct_text_block\]/s', $shortcodes, $matches ) ) {
            foreach ( $matches[1] as $text ) {
                if ( trim( strip_tags( $text ) ) ) $parts[] = $text;
            }
        }

        // Headlines
        if ( preg_match_all( '/\[ct_headline[^\]]*tag="([^"]*)"[^\]]*\](.*?)\[\/ct_headline\]/s', $shortcodes, $h_matches, PREG_SET_ORDER ) ) {
            foreach ( $h_matches as $h ) {
                $tag = $h[1] ?: 'h2';
                $parts[] = '<' . $tag . '>' . wp_strip_all_tags( $h[2] ) . '</' . $tag . '>';
            }
        }

        // Rich text
        if ( preg_match_all( '/\[oxy_rich_text[^\]]*content_id="([^"]*)"[^\]]*\]/', $shortcodes, $rt_matches ) ) {
            foreach ( $rt_matches[1] as $content_id ) {
                $ct = get_post_meta( $post_id, 'ct_content_' . $content_id, true );
                if ( $ct && mb_strlen( strip_tags( $ct ) ) > 10 ) $parts[] = $ct;
            }
        }

        // Accordion/toggle items (FAQ pattern) → <details><summary>
        if ( preg_match_all( '/\[oxy_toggle[^\]]*heading="([^"]*)"[^\]]*\](.*?)\[\/oxy_toggle\]/s', $shortcodes, $tg_matches, PREG_SET_ORDER ) ) {
            foreach ( $tg_matches as $tg ) {
                $clean = self::strip_shortcodes_keep_content( $tg[2] );
                if ( trim( strip_tags( $clean ) ) ) {
                    $parts[] = '<details><summary>' . $tg[1] . '</summary>' . $clean . '</details>';
                }
            }
        }

        // Video embeds
        if ( preg_match_all( '/\[ct_video[^\]]*src="([^"]*)"[^\]]*\]/', $shortcodes, $vid_matches ) ) {
            foreach ( $vid_matches[1] as $vid_url ) {
                if ( $vid_url ) $parts[] = '<iframe src="' . esc_url( $vid_url ) . '"></iframe>';
            }
        }

        if ( empty( $parts ) ) {
            return self::strip_shortcodes_keep_content( $shortcodes );
        }

        return implode( "\n\n", $parts );
    }

    /* ══════════════════════════════════════════════
     *  BRICKS BUILDER
     * ══════════════════════════════════════════════ */

    /**
     * Bricks stores content as JSON in _bricks_page_content_2.
     * Elements have "name" (e.g., "text-basic", "heading") and "settings.text".
     */
    private static function extract_bricks( $post_id ) {
        $data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( is_string( $data ) ) $data = json_decode( $data, true );
        if ( ! is_array( $data ) ) return '';

        $parts = array();
        foreach ( $data as $el ) {
            $name     = $el['name'] ?? '';
            $settings = $el['settings'] ?? array();

            if ( in_array( $name, array( 'text-basic', 'text', 'rich-text' ), true ) ) {
                if ( ! empty( $settings['text'] ) ) $parts[] = $settings['text'];
            } elseif ( $name === 'heading' ) {
                $tag = $settings['tag'] ?? 'h2';
                if ( ! empty( $settings['text'] ) ) $parts[] = '<' . $tag . '>' . $settings['text'] . '</' . $tag . '>';
            } elseif ( $name === 'image' ) {
                if ( ! empty( $settings['image']['url'] ) ) {
                    $alt = $settings['image']['alt'] ?? '';
                    $parts[] = '<img src="' . esc_url( $settings['image']['url'] ) . '" alt="' . esc_attr( $alt ) . '" />';
                }
            } elseif ( in_array( $name, array( 'accordion', 'accordion-nested' ), true ) ) {
                // Bricks accordion (FAQ pattern) → <details><summary>
                foreach ( $settings['items'] ?? array() as $item ) {
                    $item_title   = $item['title'] ?? '';
                    $item_content = $item['content'] ?? '';
                    if ( $item_title && $item_content ) {
                        $parts[] = '<details><summary>' . $item_title . '</summary>' . $item_content . '</details>';
                    }
                }
            } elseif ( $name === 'video' ) {
                // Bricks video element
                $vid_url = $settings['video_url'] ?? ( $settings['url'] ?? '' );
                if ( $vid_url ) $parts[] = '<iframe src="' . esc_url( $vid_url ) . '"></iframe>';
            } elseif ( $name === 'list' ) {
                // Bricks list element → <ol>/<ul> for HowTo/ItemList detection
                $list_tag = ( $settings['type'] ?? 'ul' ) === 'ol' ? 'ol' : 'ul';
                $items_html = '<' . $list_tag . '>';
                foreach ( $settings['items'] ?? array() as $li ) {
                    $li_text = $li['content'] ?? ( $li['text'] ?? '' );
                    if ( $li_text ) $items_html .= '<li>' . $li_text . '</li>';
                }
                $items_html .= '</' . $list_tag . '>';
                $parts[] = $items_html;
            }
        }

        return implode( "\n\n", $parts );
    }

    /* ══════════════════════════════════════════════
     *  BRIZY
     * ══════════════════════════════════════════════ */

    /**
     * Brizy compiles HTML and stores it. Best to get the compiled output.
     */
    private static function extract_brizy( $post_id ) {
        // Brizy stores compiled HTML
        $compiled = get_post_meta( $post_id, 'brizy_post_compiled_html', true );
        if ( $compiled ) return $compiled;

        // Fallback to _brizy_post which contains editor data
        $brizy = get_post_meta( $post_id, '_brizy_post', true );
        if ( is_string( $brizy ) ) {
            $data = json_decode( $brizy, true );
            if ( isset( $data['compiled_html'] ) ) return $data['compiled_html'];
            if ( isset( $data['editor_html'] ) ) return $data['editor_html'];
        }

        return '';
    }

    /* ══════════════════════════════════════════════
     *  WOOCOMMERCE
     * ══════════════════════════════════════════════ */

    /**
     * Extract extra WooCommerce content: product attributes, custom tabs.
     */
    private static function extract_woo_extra( $post_id ) {
        $extra = '';

        // Product attributes
        if ( function_exists( 'wc_get_product' ) ) {
            $product = wc_get_product( $post_id );
            if ( $product ) {
                $attrs = $product->get_attributes();
                foreach ( $attrs as $attr ) {
                    if ( is_a( $attr, 'WC_Product_Attribute' ) ) {
                        $name  = wc_attribute_label( $attr->get_name() );
                        $value = $attr->is_taxonomy()
                            ? implode( ', ', wc_get_product_terms( $post_id, $attr->get_name(), array( 'fields' => 'names' ) ) )
                            : implode( ', ', $attr->get_options() );
                        $extra .= "\n<p><strong>" . esc_html( $name ) . ':</strong> ' . esc_html( $value ) . '</p>';
                    }
                }
            }
        }

        return $extra;
    }

    /* ══════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════ */

    /**
     * Resolve lazy-loaded image src attributes.
     * Many lazy-load plugins use data-src, data-lazy-src, data-original instead of src.
     * This normalizes <img> tags so src always contains the real URL.
     *
     * @param string $img_tag  Single <img> HTML tag
     * @return string  Normalized <img> tag with real src
     */
    public static function resolve_lazy_src( $img_tag ) {
        // If src is already a real URL (not placeholder/data:), return as-is
        if ( preg_match( '/\bsrc\s*=\s*["\']([^"\']+)["\']/', $img_tag, $m ) ) {
            $current_src = $m[1];
            if ( $current_src && strpos( $current_src, 'data:' ) !== 0 && ! preg_match( '/placeholder|blank|spacer|grey|lazy/i', basename( $current_src ) ) ) {
                return $img_tag;
            }
        }

        // Try lazy-load attributes in order of priority
        $lazy_attrs = array( 'data-src', 'data-lazy-src', 'data-original', 'data-srcset' );
        foreach ( $lazy_attrs as $attr ) {
            if ( preg_match( '/\b' . preg_quote( $attr, '/' ) . '\s*=\s*["\']([^"\']+)["\']/', $img_tag, $lm ) ) {
                $real_src = $lm[1];
                if ( ! $real_src || strpos( $real_src, 'data:' ) === 0 ) continue;

                // For data-srcset, take the first URL
                if ( $attr === 'data-srcset' ) {
                    $real_src = preg_replace( '/\s+\d+[wx].*$/', '', trim( $real_src ) );
                    $real_src = explode( ',', $real_src )[0];
                    $real_src = trim( preg_replace( '/\s+\d+[wx]$/', '', $real_src ) );
                }

                // Replace or add src
                if ( preg_match( '/\bsrc\s*=\s*["\'][^"\']*["\']/', $img_tag ) ) {
                    $img_tag = preg_replace( '/\bsrc\s*=\s*["\'][^"\']*["\']/', 'src="' . esc_attr( $real_src ) . '"', $img_tag, 1 );
                } else {
                    $img_tag = str_replace( '<img', '<img src="' . esc_attr( $real_src ) . '"', $img_tag );
                }
                return $img_tag;
            }
        }

        return $img_tag;
    }

    /**
     * Check if an <img> tag is a decorative SVG (icon, logo, separator, etc.).
     * These should be excluded from SEO alt text scoring.
     *
     * @param string $img_tag  Single <img> HTML tag
     * @return bool
     */
    public static function is_decorative_svg( $img_tag ) {
        // Check if src ends in .svg
        if ( ! preg_match( '/src\s*=\s*["\']([^"\']+\.svg)["\']/', $img_tag ) ) {
            return false;
        }

        // SVGs with role="presentation" or aria-hidden="true" are decorative
        if ( preg_match( '/role\s*=\s*["\']presentation["\']/i', $img_tag ) ) return true;
        if ( preg_match( '/aria-hidden\s*=\s*["\']true["\']/i', $img_tag ) ) return true;

        // SVGs with common decorative class names
        if ( preg_match( '/class\s*=\s*["\'][^"\']*\b(icon|logo|separator|divider|decoration|ornament|arrow|chevron|spinner|loader)\b/i', $img_tag ) ) {
            return true;
        }

        // SVGs with very small dimensions (icons)
        if ( preg_match( '/width\s*=\s*["\']?(\d+)/', $img_tag, $wm ) && (int) $wm[1] <= 48 ) return true;
        if ( preg_match( '/height\s*=\s*["\']?(\d+)/', $img_tag, $hm ) && (int) $hm[1] <= 48 ) return true;

        // Basename heuristic: icon-*, logo-*, arrow-*, separator-*, etc.
        if ( preg_match( '/src\s*=\s*["\']([^"\']+)["\']/', $img_tag, $sm ) ) {
            $filename = strtolower( basename( $sm[1] ) );
            if ( preg_match( '/^(icon|logo|arrow|chevron|separator|divider|spinner|loader|bullet|check|close|menu|hamburger|search|social|facebook|twitter|linkedin|instagram|youtube|pinterest|tiktok)/', $filename ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Strip all shortcodes but keep their inner content.
     * [shortcode attr="val"]Content[/shortcode] → Content
     * [shortcode attr="val"] → (removed)
     */
    private static function strip_shortcodes_keep_content( $content ) {
        // First strip closing + opening pairs: [tag ...]content[/tag] → content
        $content = preg_replace( '/\[\/?[a-zA-Z_][a-zA-Z0-9_]*[^\]]*\]/', '', $content );
        return $content;
    }

    /**
     * Get a report of the content extraction for debugging.
     *
     * @param int $post_id
     * @return array { builder, word_count, img_count, has_content }
     */
    public static function diagnose( $post_id ) {
        $content   = self::get_content( $post_id );
        $text      = wp_strip_all_tags( $content );
        $images    = self::get_images( $post_id, $content );
        $word_count = hts_word_count( $text );

        return array(
            'builder'     => self::$last_builder,
            'word_count'  => $word_count,
            'img_count'   => count( $images ),
            'has_content' => $word_count > 50,
            'text_preview'=> mb_substr( $text, 0, 200 ),
        );
    }
}
