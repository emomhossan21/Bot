<?php
/**
 * HTS Design System — PHP Component Library (v5.7)
 *
 * Source of truth: hts-design-system-storybook-v5__7_.jsx
 * Convention: all methods return HTML strings. Caller uses echo.
 * Call HTS_DS::css() once in admin_head to enqueue tokens.
 *
 * @package HackTheSEO
 * @since 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class HTS_DS {

	/* ═══════════════════════════════════════════
	   CSS ENQUEUE (call once in admin_head)
	   ═══════════════════════════════════════════ */
	public static function css() {
		$css_url = plugins_url( 'admin/css/hts-ds-tokens.css', dirname( __FILE__, 2 ) . '/hack-the-seo-light.php' );
		// Fallback: compute from plugin dir
		if ( defined( 'HTS__PLUGIN_URL' ) ) {
			$css_url = HTS__PLUGIN_URL . 'admin/css/hts-ds-tokens.css';
		}
		wp_enqueue_style( 'hts-ds-tokens', $css_url, array(), '5.7' );
	}


	/* ═══════════════════════════════════════════
	   PAGE-LEVEL
	   ═══════════════════════════════════════════ */

	/**
	 * Page wrapper
	 * @param string $content Inner HTML
	 * @param bool   $wide    Use --wide (1100px) or default (800px)
	 */
	public static function page_open( $wide = false ) {
		$class = 'hts-ds-page' . ( $wide ? ' hts-ds-page--wide' : '' );
		return '<div class="' . $class . '">';
	}

	public static function page_close() {
		ob_start();
		self::toast_modal_helpers();
		$helpers = ob_get_clean();
		return $helpers . '</div>';
	}

	/**
	 * Hero dark gradient
	 * @param string $title Main title
	 * @param string $sub   Subtitle
	 * @param string $extra Extra HTML (KPIs, buttons…)
	 */
	public static function hero( $title, $sub = '', $extra = '' ) {
		$h  = '<div class="hts-hero">';
		$h .= '<h1 class="hts-hero__title">' . esc_html( $title ) . '</h1>';
		if ( $sub ) {
			$h .= '<p class="hts-hero__sub">' . esc_html( $sub ) . '</p>';
		}
		if ( $extra ) {
			$h .= $extra;
		}
		$h .= '</div>';
		return $h;
	}

	/**
	 * System info footer
	 */
	public static function footer() {
		$version = defined( 'HTS__VERSION' ) ? HTS__VERSION : '?.?.?';
		return '<div class="hts-ds-footer">'
			. '<strong>Hack The SEO</strong> v' . esc_html( $version )
			. ' &middot; WordPress ' . esc_html( get_bloginfo( 'version' ) )
			. ' &middot; PHP ' . esc_html( PHP_VERSION )
			. ' &middot; ' . esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) )
			. '</div>';
	}


	/* ═══════════════════════════════════════════
	   ATOMS
	   ═══════════════════════════════════════════ */

	/**
	 * A02 — Badge (outline only — 1.5px solid, never filled)
	 * @param string $text
	 * @param string $variant default|success|caution|danger|accent|info|geo
	 * @param bool   $dot     Show dot inside
	 */
	public static function badge( $text, $variant = 'default', $dot = false ) {
		$class = 'hts-ds-badge';
		if ( $variant !== 'default' ) {
			$class .= ' hts-ds-badge--' . esc_attr( $variant );
		}
		$d = $dot ? '<span class="hts-ds-badge__dot"></span>' : '';
		return '<span class="' . $class . '">' . $d . esc_html( $text ) . '</span>';
	}

	/**
	 * A03 — Button
	 * @param string $text
	 * @param string $variant default|primary|geo|success|danger|dark|ghost|outline
	 * @param string $size    sm|md|lg
	 * @param array  $attrs   Extra HTML attributes [key => value]
	 * @param string $icon    SVG HTML string to prepend
	 */
	public static function button( $text, $variant = 'default', $size = 'md', $attrs = array(), $icon = '' ) {
		$class = 'hts-ds-btn';
		if ( $variant !== 'default' ) {
			$class .= ' hts-ds-btn--' . esc_attr( $variant );
		}
		if ( $size !== 'md' ) {
			$class .= ' hts-ds-btn--' . esc_attr( $size );
		}
		if ( isset( $attrs['class'] ) ) {
			$class .= ' ' . esc_attr( $attrs['class'] );
			unset( $attrs['class'] );
		}
		$attr_str = '';
		foreach ( $attrs as $k => $v ) {
			$attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
		return '<button class="' . $class . '"' . $attr_str . '>' . $icon . esc_html( $text ) . '</button>';
	}

	/**
	 * A04 — Score Ring (SVG)
	 * @param int $value   0-100
	 * @param int $size    Diameter in px
	 * @param int $stroke  Stroke width
	 */
	public static function ring( $value, $size = 44, $stroke = 3 ) {
		$value  = max( 0, min( 100, (int) $value ) );
		$r      = ( $size - $stroke ) / 2;
		$ci     = 2 * M_PI * $r;
		$off    = $ci * ( 1 - $value / 100 );
		$half   = $size / 2;
		$fz     = round( $size * 0.32 );

		if ( $value >= 75 ) { $col = 'var(--hts-success)'; }
		elseif ( $value >= 50 ) { $col = 'var(--hts-caution)'; }
		else { $col = 'var(--hts-danger)'; }

		return '<svg width="' . $size . '" height="' . $size . '" style="transform:rotate(-90deg);flex-shrink:0">'
			. '<circle cx="' . $half . '" cy="' . $half . '" r="' . $r . '" fill="none" stroke="var(--hts-border-sub)" stroke-width="' . $stroke . '"/>'
			. '<circle cx="' . $half . '" cy="' . $half . '" r="' . $r . '" fill="none" stroke="' . $col . '" stroke-width="' . $stroke . '"'
			. ' stroke-dasharray="' . round( $ci, 2 ) . '" stroke-dashoffset="' . round( $off, 2 ) . '" stroke-linecap="round"/>'
			. '<text x="' . $half . '" y="' . $half . '" text-anchor="middle" dominant-baseline="central"'
			. ' style="transform:rotate(90deg);transform-origin:center;font-size:' . $fz . 'px;font-weight:700;fill:var(--hts-text);font-family:var(--hts-font)">' . $value . '</text>'
			. '</svg>';
	}

	/**
	 * A05 — Progress Bar
	 */
	public static function progress( $value, $color = '', $height = 4 ) {
		$value = max( 0, min( 100, (float) $value ) );
		$c = $color ?: 'var(--hts-accent)';
		return '<div class="hts-ds-progress" style="height:' . (int) $height . 'px">'
			. '<div class="hts-ds-progress__bar" style="width:' . $value . '%;background:' . esc_attr( $c ) . '"></div>'
			. '</div>';
	}

	/**
	 * A07 — Trend Indicator
	 */
	public static function trend( $value, $suffix = '%', $invert = false ) {
		if ( (float) $value === 0.0 ) {
			return '<span style="font-size:11px;color:var(--hts-text-3)">—</span>';
		}
		$positive = $invert ? ( $value < 0 ) : ( $value > 0 );
		$col = $positive ? 'var(--hts-success)' : 'var(--hts-danger)';
		$sign = $value > 0 ? '+' : '';
		return '<span style="font-size:11px;font-weight:600;color:' . $col . '">' . $sign . $value . esc_html( $suffix ) . '</span>';
	}

	/**
	 * A08 — Toggle Switch
	 * @param bool   $on
	 * @param string $name   Input name for form submission
	 * @param string $id     Unique ID
	 * @param array  $data   data-* attributes
	 */
	public static function toggle( $on = true, $name = '', $id = '', $data = array() ) {
		$class = 'hts-ds-toggle' . ( $on ? ' hts-ds-toggle--on' : '' );
		$data_str = '';
		foreach ( $data as $k => $v ) {
			$data_str .= ' data-' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
		$id_attr = $id ? ' id="' . esc_attr( $id ) . '"' : '';
		return '<div class="' . $class . '"' . $id_attr . $data_str . '>'
			. '<div class="hts-ds-toggle__knob"></div>'
			. ( $name ? '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . ( $on ? '1' : '0' ) . '">' : '' )
			. '</div>';
	}

	/**
	 * A09 — Status Dot
	 * @param string $status ok|warn|fail
	 * @param int    $size   px
	 */
	public static function dot( $status = 'ok', $size = 8 ) {
		$map = array( 'ok' => 'ok', 'warn' => 'warn', 'fail' => 'fail', 'success' => 'ok', 'caution' => 'warn', 'danger' => 'fail' );
		$s = $map[ $status ] ?? 'ok';
		$style = $size !== 8 ? ' style="width:' . (int) $size . 'px;height:' . (int) $size . 'px"' : '';
		return '<span class="hts-ds-dot hts-ds-dot--' . $s . '"' . $style . '></span>';
	}

	/**
	 * A13 — Icon (Lucide SVG)
	 * Returns inline SVG. color accepts CSS var or hex.
	 */
	public static function icon( $name, $size = 16, $color = 'var(--hts-text-3)', $sw = '1.7' ) {
		$paths = self::icon_paths();
		$path = $paths[ $name ] ?? '<circle cx="12" cy="12" r="9" stroke-dasharray="4 3"/>';
		return '<svg width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" '
			. 'stroke="' . esc_attr( $color ) . '" stroke-width="' . esc_attr( $sw ) . '" stroke-linecap="round" stroke-linejoin="round" '
			. 'style="flex-shrink:0">' . $path . '</svg>';
	}

	/**
	 * A15 — Checkbox
	 */
	public static function checkbox( $on = true, $name = '', $data = array() ) {
		$class = 'hts-ds-checkbox' . ( $on ? ' hts-ds-checkbox--on' : '' );
		$check_svg = $on ? '<svg width="14" height="14" viewBox="0 0 24 24"><polyline points="20,6 9,17 4,12" stroke="#fff" stroke-width="3" fill="none"/></svg>' : '';
		$data_str = '';
		foreach ( $data as $k => $v ) {
			$data_str .= ' data-' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
		return '<div class="' . $class . '"' . $data_str . '>' . $check_svg
			. ( $name ? '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . ( $on ? '1' : '0' ) . '">' : '' )
			. '</div>';
	}

	/**
	 * A16 — Card wrapper
	 * @param string $content Inner HTML
	 * @param string $class   Additional CSS classes
	 * @param string $style   Inline style override
	 */
	public static function card( $content, $class = '', $style = '' ) {
		$cls = 'hts-ds-card' . ( $class ? ' ' . esc_attr( $class ) : '' );
		$st = $style ? ' style="' . esc_attr( $style ) . '"' : '';
		return '<div class="' . $cls . '"' . $st . '>' . $content . '</div>';
	}

	/**
	 * A17 — Input
	 */
	public static function input( $attrs = array() ) {
		$defaults = array(
			'type' => 'text', 'class' => '', 'style' => '', 'id' => '',
			'name' => '', 'value' => '', 'placeholder' => '',
		);
		$a = array_merge( $defaults, $attrs );
		$class = 'hts-ds-input' . ( $a['class'] ? ' ' . esc_attr( $a['class'] ) : '' );
		$html = '<input type="' . esc_attr( $a['type'] ) . '" class="' . $class . '"';
		if ( $a['id'] )          $html .= ' id="' . esc_attr( $a['id'] ) . '"';
		if ( $a['name'] )        $html .= ' name="' . esc_attr( $a['name'] ) . '"';
		if ( $a['value'] !== '' ) $html .= ' value="' . esc_attr( $a['value'] ) . '"';
		if ( $a['placeholder'] ) $html .= ' placeholder="' . esc_attr( $a['placeholder'] ) . '"';
		if ( $a['style'] )       $html .= ' style="' . esc_attr( $a['style'] ) . '"';
		// Pass through extra attrs
		foreach ( $a as $k => $v ) {
			if ( ! isset( $defaults[ $k ] ) && strpos( $k, 'data-' ) === 0 ) {
				$html .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
			}
		}
		$html .= '>';
		return $html;
	}

	/**
	 * A17b — Select
	 */
	public static function select( $options, $selected = '', $attrs = array() ) {
		$class = 'hts-ds-select' . ( ! empty( $attrs['class'] ) ? ' ' . esc_attr( $attrs['class'] ) : '' );
		$html = '<select class="' . $class . '"';
		if ( ! empty( $attrs['id'] ) )    $html .= ' id="' . esc_attr( $attrs['id'] ) . '"';
		if ( ! empty( $attrs['name'] ) )  $html .= ' name="' . esc_attr( $attrs['name'] ) . '"';
		if ( ! empty( $attrs['style'] ) ) $html .= ' style="' . esc_attr( $attrs['style'] ) . '"';
		foreach ( $attrs as $k => $v ) {
			if ( strpos( $k, 'data-' ) === 0 ) {
				$html .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
			}
		}
		$html .= '>';
		foreach ( $options as $val => $label ) {
			$sel = ( (string) $val === (string) $selected ) ? ' selected' : '';
			$html .= '<option value="' . esc_attr( $val ) . '"' . $sel . '>' . esc_html( $label ) . '</option>';
		}
		$html .= '</select>';
		return $html;
	}

	/**
	 * A18 — Empty State
	 */
	public static function empty_state( $title = 'Rien ici', $desc = '', $cta = '', $cta_attrs = array() ) {
		$h = '<div class="hts-ds-empty">';
		$h .= '<div style="margin-bottom:12px;opacity:.3">' . self::icon( 'inbox', 40 ) . '</div>';
		$h .= '<div class="hts-ds-empty__title">' . esc_html( $title ) . '</div>';
		if ( $desc ) {
			$h .= '<div class="hts-ds-empty__desc">' . esc_html( $desc ) . '</div>';
		}
		if ( $cta ) {
			$h .= self::button( $cta, 'primary', 'md', $cta_attrs );
		}
		$h .= '</div>';
		return $h;
	}


	/**
	 * Pro Wall — Blur overlay with upgrade CTA.
	 * Wraps $content in a blurred container with an upgrade card on top.
	 *
	 * Usage: echo HTS_DS::pro_wall( $html_content, 'Groupes de contenus' );
	 *        OR: echo HTS_DS::pro_wall( '', 'Inbox', true ); // empty preview mode
	 */
	/**
	 * @param string|array $content_or_opts  HTML content to blur, OR options array
	 * @param string       $feature_label    (legacy) Feature description
	 * @param bool         $empty_preview    Show fake blurred content
	 * @param string       $upgrade_url      Override upgrade URL
	 *
	 * Options array keys: title, desc, button, subtitle, url, preview
	 */
	public static function pro_wall( $content_or_opts = '', $feature_label = '', $empty_preview = false, $upgrade_url = '' ) {
		// Support options array as first argument
		if ( is_array( $content_or_opts ) ) {
			$opts = $content_or_opts;
			$title         = $opts['title']    ?? 'Fonctionnalité Pro';
			$desc          = $opts['desc']     ?? '';
			$button        = $opts['button']   ?? 'Débloquer';
			$subtitle      = $opts['subtitle'] ?? '';
			$upgrade_url   = $opts['url']      ?? admin_url( 'admin.php?page=hts-api-settings&stab=plans' );
			$empty_preview = $opts['preview']  ?? true;
			$content       = '';
		} else {
			$content = $content_or_opts;
			$title   = 'Fonctionnalité Pro';
			$desc    = $feature_label ? ( esc_html( $feature_label ) . ' est disponible avec un abonnement Hack The SEO.' ) : '';
			$button  = 'Voir les offres';
			$subtitle = 'A partir de 99\u20ac/mois';
			if ( empty( $upgrade_url ) ) {
				$upgrade_url = admin_url( 'admin.php?page=hts-api-settings&stab=plans' );
			}
		}

		$h = '<div class="hts-ds-pro-wall">';
		if ( $empty_preview ) {
			$h .= '<div class="hts-ds-pro-wall__blur">';
			$h .= '<div style="padding:24px 20px">';
			// Realistic fake content cards (like real dashboard data)
			$h .= '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:20px">';
			for ( $k = 0; $k < 3; $k++ ) {
				$h .= '<div style="background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:12px;padding:16px">';
				$h .= '<div style="background:var(--hts-border);border-radius:4px;height:10px;width:50%;margin-bottom:8px"></div>';
				$h .= '<div style="background:var(--hts-text);border-radius:4px;height:22px;width:40%;margin-bottom:4px;opacity:.15"></div>';
				$h .= '<div style="background:var(--hts-success);border-radius:4px;height:8px;width:30%;opacity:.3"></div>';
				$h .= '</div>';
			}
			$h .= '</div>';
			for ( $i = 0; $i < 5; $i++ ) {
				$h .= '<div style="background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:12px;padding:16px 20px;margin-bottom:10px;display:flex;align-items:center;gap:14px">';
				$h .= '<div style="width:10px;height:10px;border-radius:50%;background:' . ( $i % 3 === 0 ? 'var(--hts-danger)' : ( $i % 3 === 1 ? 'var(--hts-caution)' : 'var(--hts-success)' ) ) . ';flex-shrink:0;opacity:.5"></div>';
				$h .= '<div style="flex:1"><div style="background:var(--hts-border);border-radius:4px;height:12px;width:' . rand( 50, 85 ) . '%;margin-bottom:6px"></div>';
				$h .= '<div style="background:var(--hts-border-sub);border-radius:4px;height:9px;width:' . rand( 30, 65 ) . '%"></div></div>';
				$h .= '<div style="background:var(--hts-border);border-radius:6px;height:28px;width:60px;opacity:.5"></div>';
				$h .= '</div>';
			}
			$h .= '</div></div>';
		} elseif ( ! empty( $content ) ) {
			$h .= '<div class="hts-ds-pro-wall__blur">' . $content . '</div>';
		}
		$h .= '<div class="hts-ds-pro-wall__overlay">';
		$h .= '<div class="hts-ds-pro-wall__card">';
		$h .= '<div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;margin:0 auto 16px">' . self::icon( 'zap', 28, '#fff' ) . '</div>';
		$h .= '<div style="font-size:20px;font-weight:800;color:var(--hts-text);margin-bottom:8px">' . esc_html( $title ) . '</div>';
		if ( $desc ) {
			$h .= '<div style="font-size:14px;color:var(--hts-text-2);line-height:1.6;margin-bottom:20px;max-width:340px;margin-left:auto;margin-right:auto">' . esc_html( $desc ) . '</div>';
		}
		$h .= '<a href="' . esc_url( $upgrade_url ) . '" target="_blank" rel="noopener" '
			. 'style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:10px;'
			. 'background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;'
			. 'text-decoration:none;box-shadow:0 4px 14px rgba(99,102,241,.3);transition:all .2s">'
			. self::icon( 'zap', 16, '#fff' ) . ' ' . esc_html( $button ) . '</a>';
		if ( $subtitle ) {
			$h .= '<div style="margin-top:12px;font-size:11px;color:var(--hts-text-3)">' . esc_html( $subtitle ) . '</div>';
		}
		$h .= '</div></div></div>';

		// Inline CSS (only once per page)
		static $css_done = false;
		if ( ! $css_done ) {
			$css_done = true;
			$h .= '<style>
.hts-ds-pro-wall{position:relative;min-height:400px}
.hts-ds-pro-wall__blur{filter:blur(6px);-webkit-filter:blur(6px);pointer-events:none;user-select:none;opacity:.7}
.hts-ds-pro-wall__overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:10;background:rgba(255,255,255,.4);backdrop-filter:blur(2px)}
.hts-ds-pro-wall__card{text-align:center;padding:48px;border-radius:20px;background:#fff;box-shadow:0 8px 40px rgba(0,0,0,.1),0 0 0 1px rgba(0,0,0,.04);max-width:440px;width:90%}
@media(prefers-color-scheme:dark){.hts-ds-pro-wall__overlay{background:rgba(17,24,39,.5)}.hts-ds-pro-wall__card{background:var(--hts-bg,#1a1f36)}}
</style>';
		}
		return $h;
	}

	/**
	 * Pro Badge — Small inline "PRO" label for menus and buttons.
	 */
	public static function pro_badge( $style = '' ) {
		return '<span style="display:inline-flex;align-items:center;padding:1px 6px;border-radius:4px;'
			. 'background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;font-size:9px;font-weight:700;'
			. 'letter-spacing:.04em;margin-left:6px;vertical-align:middle;line-height:1.4;' . $style . '">PRO</span>';
	}

	public static function ultra_badge( $style = '' ) {
		return '<span style="display:inline-flex;align-items:center;padding:1px 6px;border-radius:4px;'
			. 'background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;font-size:9px;font-weight:700;'
			. 'letter-spacing:.04em;margin-left:6px;vertical-align:middle;line-height:1.4;' . $style . '">ULTRA</span>';
	}

	/* ═══════════════════════════════════════════
	   MOLECULES
	   ═══════════════════════════════════════════ */

	/**
	 * M07 — Tab Bar (segmented control)
	 * @param array  $tabs   [ ['id' => 'x', 'label' => 'X', 'badge' => 0, 'icon' => ''], ... ]
	 * @param string $active Current tab ID
	 * @param string $base_url URL pattern with %s for tab id
	 */
	public static function tab_bar( $tabs, $active, $base_url = '' ) {
		$h = '<div class="hts-ds-tabs">';
		foreach ( $tabs as $t ) {
			$is_active = $t['id'] === $active;
			$cls = 'hts-ds-tabs__item' . ( $is_active ? ' hts-ds-tabs__item--active' : '' );

			if ( $base_url ) {
				$url = sprintf( $base_url, $t['id'] );
				$h .= '<a href="' . esc_url( $url ) . '" class="' . $cls . '" style="text-decoration:none">';
			} else {
				$h .= '<button class="' . $cls . '" data-tab="' . esc_attr( $t['id'] ) . '">';
			}

			if ( ! empty( $t['icon'] ) ) {
				$h .= self::icon( $t['icon'], 13, $is_active ? 'var(--hts-text)' : 'rgba(60,60,67,.35)', '1.8' );
			}
			$h .= esc_html( $t['label'] );
			if ( ! empty( $t['badge'] ) && $t['badge'] > 0 ) {
				$h .= '<span style="min-width:18px;height:18px;border-radius:9px;padding:0 5px;background:var(--hts-danger);color:#fff;font-size:11px;font-weight:700;display:inline-flex;align-items:center;justify-content:center">' . (int) $t['badge'] . '</span>';
			}

			$h .= $base_url ? '</a>' : '</button>';
		}
		$h .= '</div>';
		return $h;
	}

	/**
	 * M09 — Connection Status
	 */
	public static function connection_status( $label, $connected = true ) {
		$col = $connected ? 'var(--hts-success)' : 'var(--hts-text-3)';
		return '<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:500;border:1.5px solid ' . $col . ';color:' . $col . '">'
			. self::dot( $connected ? 'ok' : 'fail', 6 )
			. esc_html( $label )
			. '</div>';
	}

	/**
	 * M10 — Alert (outline only, no fill)
	 */
	public static function alert( $content, $variant = 'warning' ) {
		$colors = array( 'success' => 'var(--hts-success)', 'warning' => 'var(--hts-caution)', 'danger' => 'var(--hts-danger)', 'info' => 'var(--hts-info)' );
		$col = $colors[ $variant ] ?? $colors['warning'];
		return '<div style="display:flex;align-items:flex-start;gap:10px;padding:12px 16px;border-radius:var(--hts-radius-sm);border:1.5px solid ' . $col . ';background:transparent;color:' . $col . ';font-size:13px">'
			. self::icon( 'alert', 18, $col )
			. '<div style="flex:1">' . $content . '</div>'
			. '</div>';
	}


	/* ═══════════════════════════════════════════
	   LAYOUT HELPERS (Settings-oriented)
	   ═══════════════════════════════════════════ */

	/**
	 * Section Title + optional description
	 */
	public static function section_title( $title, $desc = '' ) {
		$h = '<div class="hts-ds-section-title">' . esc_html( $title ) . '</div>';
		if ( $desc ) {
			$h .= '<div class="hts-ds-section-desc">' . esc_html( $desc ) . '</div>';
		}
		return $h;
	}

	/**
	 * Setting Row (label left, control right)
	 * @param string $label
	 * @param string $desc
	 * @param string $control  HTML of the right side
	 * @param bool   $last     No bottom border
	 * @param string $icon     Lucide icon name (optional)
	 */
	public static function row( $label, $desc = '', $control = '', $last = false, $icon = '' ) {
		$cls = 'hts-ds-row' . ( $last ? ' hts-ds-row--last' : '' );
		$h = '<div class="' . $cls . '">';
		$h .= '<div class="hts-ds-row__left">';
		if ( $icon ) {
			$h .= '<div style="display:flex;gap:10px;align-items:flex-start">';
			$h .= self::icon( $icon, 18, 'var(--hts-text-3)' );
			$h .= '<div>';
		}
		$h .= '<div class="hts-ds-row__label">' . esc_html( $label ) . '</div>';
		if ( $desc ) {
			$h .= '<div class="hts-ds-row__desc">' . esc_html( $desc ) . '</div>';
		}
		if ( $icon ) {
			$h .= '</div></div>';
		}
		$h .= '</div>';
		$h .= '<div class="hts-ds-row__right">' . $control . '</div>';
		$h .= '</div>';
		return $h;
	}

	/**
	 * Info Box
	 */
	public static function info_box( $content, $variant = 'default' ) {
		$cls = 'hts-ds-info' . ( $variant !== 'default' ? ' hts-ds-info--' . esc_attr( $variant ) : '' );
		return '<div class="' . $cls . '">' . $content . '</div>';
	}

	/**
	 * Code inline
	 */
	public static function code( $text ) {
		return '<code class="hts-ds-code">' . esc_html( $text ) . '</code>';
	}

	/**
	 * Card with header + body
	 */
	public static function card_section( $title, $body, $desc = '', $header_right = '' ) {
		$h = '<div class="hts-ds-card">';
		$h .= '<div class="hts-ds-card__header">';
		$h .= '<div>';
		$h .= '<div class="hts-ds-section-title" style="margin-bottom:0">' . esc_html( $title ) . '</div>';
		if ( $desc ) {
			$h .= '<div style="font-size:12px;color:var(--hts-text-3);margin-top:2px">' . esc_html( $desc ) . '</div>';
		}
		$h .= '</div>';
		if ( $header_right ) {
			$h .= '<div>' . $header_right . '</div>';
		}
		$h .= '</div>';
		$h .= '<div class="hts-ds-card__body">' . $body . '</div>';
		$h .= '</div>';
		return $h;
	}

	/**
	 * Table
	 * @param array $headers ['Label', 'Count', ...]
	 * @param array $rows    [['cell1', 'cell2'], ...]
	 * @param array $aligns  ['left', 'center', 'right'] per column
	 */
	public static function table( $headers, $rows, $aligns = array() ) {
		$h = '<table class="hts-ds-table"><thead><tr>';
		foreach ( $headers as $i => $hdr ) {
			$align = $aligns[ $i ] ?? 'left';
			$h .= '<th style="text-align:' . $align . '">' . esc_html( $hdr ) . '</th>';
		}
		$h .= '</tr></thead><tbody>';
		foreach ( $rows as $row ) {
			$h .= '<tr>';
			foreach ( $row as $i => $cell ) {
				$align = $aligns[ $i ] ?? 'left';
				$h .= '<td style="text-align:' . $align . '">' . $cell . '</td>'; // cell may contain HTML
			}
			$h .= '</tr>';
		}
		$h .= '</tbody></table>';
		return $h;
	}


	/* ═══════════════════════════════════════════
	   ICON PATHS (Lucide SVG — subset used in plugin)
	   ═══════════════════════════════════════════ */
	private static function icon_paths() {
		return array(
			'zap'     => '<polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/>',
			'shield'  => '<path d="M12 2l8 4v5c0 5.25-3.5 9.74-8 11-4.5-1.26-8-5.75-8-11V6l8-4z"/>',
			'check'   => '<polyline points="20,6 9,17 4,12" stroke-width="2.2"/>',
			'x'       => '<path d="M18 6L6 18M6 6l12 12"/>',
			'alert'   => '<path d="m21.73 18-8-14a2 2 0 00-3.48 0l-8 14A2 2 0 004 21h16a2 2 0 001.73-3Z"/><path d="M12 9v4M12 17h.01" stroke-width="1.8"/>',
			'chart'   => '<line x1="18" y1="20" x2="18" y2="10" stroke-width="2"/><line x1="12" y1="20" x2="12" y2="4" stroke-width="2"/><line x1="6" y1="20" x2="6" y2="14" stroke-width="2"/>',
			'trending'=> '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18" stroke-width="2"/><polyline points="17 6 23 6 23 12" stroke-width="2"/>',
			'bot'     => '<rect x="3" y="4" width="18" height="14" rx="3"/><circle cx="9" cy="11" r="1.5" fill="currentColor"/><circle cx="15" cy="11" r="1.5" fill="currentColor"/><line x1="12" y1="1" x2="12" y2="4"/>',
			'link'    => '<path d="M10 14a3.5 3.5 0 005 0l3-3a3.5 3.5 0 00-5-5l-.5.5"/><path d="M14 10a3.5 3.5 0 00-5 0l-3 3a3.5 3.5 0 005 5l.5-.5"/>',
			'star'    => '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" stroke-width="1.5"/>',
			'gear'    => '<circle cx="12" cy="12" r="3"/><path d="M12 1v2m0 18v2m-9-11h2m18 0h2" stroke-width="1.5"/>',
			'eye'     => '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" stroke-width="1.5"/><circle cx="12" cy="12" r="3" stroke-width="1.5"/>',
			'globe'   => '<circle cx="12" cy="12" r="10" stroke-width="1.5"/><line x1="2" x2="22" y1="12" y2="12" stroke-width="1.5"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z" stroke-width="1.5"/>',
			'inbox'   => '<polyline points="22,12 16,12 14,15 10,15 8,12 2,12"/><path d="M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z"/>',
			'plus'    => '<line x1="12" y1="5" x2="12" y2="19" stroke-width="2"/><line x1="5" y1="12" x2="19" y2="12" stroke-width="2"/>',
			'search'  => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
			'trash'   => '<polyline points="3,6 5,6 21,6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>',
			'send'    => '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
			'message' => '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>',
			'key'     => '<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
			'bell'    => '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
			'server'  => '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>',
			'clock'   => '<circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/>',
			'mail'    => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
			'file'    => '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>',
			'book'    => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
			'download'=> '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/>',
			'upload'  => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/>',
			'sliders' => '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
			'refresh' => '<path d="M1 4v6h6M23 20v-6h-6"/><path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15"/>',
			'target'  => '<circle cx="12" cy="12" r="9" stroke-width="1.5"/><circle cx="12" cy="12" r="5" stroke-width="1.5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/>',
			'compass' => '<circle cx="12" cy="12" r="9"/><polygon points="16.24,7.76 14.12,14.12 7.76,16.24 9.88,9.88" fill="currentColor" opacity="0.7"/>',
			'edit'    => '<path d="M4 20h16M4 20V16L14.586 5.414a2 2 0 012.828 0L19.586 7.586a2 2 0 010 2.828L9 20"/>',
			'info'    => '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
			'lightbulb'=> '<path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z"/>',
			// Chevrons
			'chevron-down'  => '<polyline points="6,9 12,15 18,9"/>',
			'chevron-right' => '<polyline points="9,18 15,12 9,6"/>',
			'chevron-left'  => '<polyline points="15,18 9,12 15,6"/>',
		);
	}

	/**
	 * Phase 6.29-6.30: Output global toast + modal JS/CSS helpers.
	 * Call once per page via <?php HTS_DS::toast_modal_helpers(); ?>
	 * Provides window._htsToast(msg,type) and window._htsConfirm(title,msg,ok,cls)
	 */
	public static function toast_modal_helpers() {
		static $done = false;
		if ( $done ) return;
		$done = true;
		echo '<style>';
		echo '.hts-g-toast{position:fixed;bottom:20px;right:20px;padding:12px 20px;background:var(--hts-text);color:#fff;border-radius:10px;font-size:13px;font-weight:600;z-index:99999;opacity:0;transform:translateY(10px);transition:all .3s;pointer-events:none;font-family:var(--hts-font);max-width:360px}';
		echo '.hts-g-toast.show{opacity:1;transform:translateY(0)}.hts-g-toast.success{background:var(--hts-success)}.hts-g-toast.error{background:var(--hts-danger)}';
		echo '</style>';
		echo '<script>';
		echo 'window._htsToast=function(m,t){var e=document.getElementById("hts-g-toast");if(!e){e=document.createElement("div");e.id="hts-g-toast";document.body.appendChild(e)}e.className="hts-g-toast"+(t?" "+t:"")+" show";e.textContent=m;clearTimeout(e._t);e._t=setTimeout(function(){e.className="hts-g-toast"},3000)};';
		echo 'window._htsConfirm=function(title,msg,okL,cls){return new Promise(function(res){var o=document.createElement("div");o.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99998;display:flex;align-items:center;justify-content:center";var d=document.createElement("div");d.style.cssText="background:var(--hts-bg,#fff);border-radius:14px;padding:28px 32px;max-width:420px;width:90%;box-shadow:0 8px 30px rgba(0,0,0,.15);font-family:var(--hts-font)";';
		echo 'd.innerHTML=\'<div style="font-size:16px;font-weight:700;margin-bottom:8px">\'+title+\'</div><div style="font-size:13px;color:var(--hts-text-2);margin-bottom:20px;line-height:1.5">\'+msg+\'</div><div style="display:flex;gap:8px;justify-content:flex-end"><button class="hc">Annuler</button><button class="ho">\'+((okL)||"Confirmer")+\'</button></div>\';';
		echo 'var bC=d.querySelector(".hc"),bO=d.querySelector(".ho");';
		echo 'bC.style.cssText="padding:8px 16px;border-radius:8px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:13px;font-weight:600;cursor:pointer;color:var(--hts-text-2)";';
		echo 'bO.style.cssText="padding:8px 16px;border-radius:8px;border:none;background:"+(cls==="danger"?"var(--hts-danger)":"var(--hts-accent)")+";color:#fff;font-size:13px;font-weight:700;cursor:pointer";';
		echo 'o.appendChild(d);document.body.appendChild(o);function cl(v){o.remove();res(v)}o.addEventListener("click",function(e){if(e.target===o)cl(false)});bC.addEventListener("click",function(){cl(false)});bO.addEventListener("click",function(){cl(true)})})};';
		echo '</script>';
	}
}
