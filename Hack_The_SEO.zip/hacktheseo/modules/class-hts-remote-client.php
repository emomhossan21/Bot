<?php
/**
 * HTS Remote Client — API bridge for SaaS migration
 *
 * Provides a thin wrapper around wp_remote_post() to call the Laravel backend.
 * Used by migration hooks in modules when their corresponding feature flag is true.
 *
 * Feature flags (defined in hack-the-seo-light.php or wp-config.php):
 *   HTS_REMOTE_SCORING   → class-hts-cocon.php
 *   HTS_REMOTE_LINKING   → class-hts-internal-linking.php
 *   HTS_REMOTE_DECISIONS → class-hts-decision-engine.php
 *   HTS_REMOTE_STRATEGY  → class-hts-strategy-engine.php
 *   HTS_REMOTE_WORKFLOW  → class-hts-workflow-engine.php
 *
 * @package HackTheSEO
 * @since   2.6.0
 */

if ( ! defined( 'WPINC' ) ) die;

class HTS_Remote_Client {

    /**
     * Base URL for the Laravel API.
     * Override via HTS_REMOTE_API_URL constant in wp-config.php.
     */
    private static $base_url = 'https://app.hacktheseo.com/api/v1';

    /**
     * Request timeout in seconds.
     */
    private static $timeout = 15;

    /**
     * Circuit breaker: consecutive failure count.
     */
    private static $circuit_failures = 0;

    /**
     * Circuit breaker: timestamp until which the circuit stays open.
     */
    private static $circuit_open_until = 0;

    /**
     * Maximum retry attempts per call.
     */
    private static $max_retries = 3;

    /**
     * Make a POST request to the remote API.
     *
     * Includes retry with exponential backoff (200ms/400ms/800ms)
     * and circuit breaker (5 consecutive failures = 5 min cooldown).
     *
     * @param  string $endpoint  API endpoint path (e.g. 'cocon/score').
     * @param  array  $data      Payload to send as JSON.
     * @param  string $method    HTTP method: 'POST' or 'GET'. Default 'POST'.
     * @return array             Decoded response or error array.
     */
    public static function call( $endpoint, $data = array(), $method = 'POST', $options = array() ) {
        // P7 FIX: Persistent circuit breaker via transient (survives across requests)
        $circuit = get_transient( 'hts_circuit_breaker' );
        if ( ! is_array( $circuit ) ) {
            $circuit = array( 'failures' => 0, 'open_until' => 0, 'successes' => 0 );
        }
        if ( ! isset( $circuit['successes'] ) ) {
            $circuit['successes'] = 0;
        }
        if ( $circuit['failures'] >= 5 && time() < $circuit['open_until'] ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote API circuit breaker open, skipping call to ' . $endpoint, 'warning', 'remote-client' );
            }
            return array( 'success' => false, 'error' => 'Circuit breaker open — too many consecutive failures' );
        }

        // Priority: wp-config constant > DB option (env selector) > hardcoded default
        if ( defined( 'HTS_REMOTE_API_URL' ) ) {
            $base = HTS_REMOTE_API_URL;
        } else {
            $db_env = get_option( 'hts_api_base_url', '' );
            if ( $db_env ) {
                $base = rtrim( $db_env, '/' );
                if ( strpos( $base, '/api/v1' ) === false ) {
                    $base .= '/api/v1';
                }
            } else {
                $base = self::$base_url;
            }
        }
        $api_key = get_option( 'hts_api_key', '' );
        $url     = $base . '/' . ltrim( $endpoint, '/' );

        // P8 FIX: Add plugin version header for compatibility tracking
        $version = defined( 'HTS__VERSION' ) ? HTS__VERSION : '0.0.0';

        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'X-HTS-Version' => $version,
        );

        // P5 FIX: Allow reduced timeout/retries for sync operations
        $call_timeout = isset( $options['timeout'] ) ? (int) $options['timeout'] : self::$timeout;
        $call_retries = isset( $options['retries'] ) ? (int) $options['retries'] : self::$max_retries;

        $last_error = 'Unknown error';

        for ( $attempt = 1; $attempt <= $call_retries; $attempt++ ) {
            if ( strtoupper( $method ) === 'GET' ) {
                $response = wp_remote_get( $url, array(
                    'timeout' => $call_timeout,
                    'headers' => $headers,
                ) );
            } else {
                $response = wp_remote_post( $url, array(
                    'timeout' => $call_timeout,
                    'headers' => $headers,
                    'body'    => wp_json_encode( $data ),
                ) );
            }

            if ( is_wp_error( $response ) ) {
                $last_error = $response->get_error_message();
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Remote API error (attempt ' . $attempt . '/' . self::$max_retries . '): ' . $last_error, 'error', 'remote-client' );
                }
                if ( $attempt < self::$max_retries ) {
                    usleep( 200000 * pow( 2, $attempt - 1 ) ); // 200ms, 400ms, 800ms
                }
                continue;
            }

            $code = wp_remote_retrieve_response_code( $response );
            $body = json_decode( wp_remote_retrieve_body( $response ), true );

            if ( $code >= 500 ) {
                $last_error = isset( $body['message'] ) ? $body['message'] : 'HTTP ' . $code;
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Remote API HTTP ' . $code . ' (attempt ' . $attempt . '/' . self::$max_retries . '): ' . $last_error, 'error', 'remote-client' );
                }
                if ( $attempt < self::$max_retries ) {
                    usleep( 200000 * pow( 2, $attempt - 1 ) );
                }
                continue;
            }

            if ( $code >= 400 ) {
                $msg = isset( $body['message'] ) ? $body['message'] : 'HTTP ' . $code;
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Remote API HTTP ' . $code . ': ' . $msg, 'error', 'remote-client' );
                }
                // Client errors (4xx) are not retried — count as success for circuit breaker (server responded)
                $circuit['successes'] = ( $circuit['successes'] ?? 0 ) + 1;
                if ( $circuit['successes'] >= 3 ) {
                    $circuit['failures']  = 0;
                    $circuit['successes'] = 0;
                }
                set_transient( 'hts_circuit_breaker', $circuit, 600 );
                return array( 'success' => false, 'error' => $msg );
            }

            // Success — only reset circuit breaker after 3 consecutive successes
            $circuit['successes'] = ( $circuit['successes'] ?? 0 ) + 1;
            if ( $circuit['successes'] >= 3 ) {
                $circuit['failures']  = 0;
                $circuit['successes'] = 0;
            }
            set_transient( 'hts_circuit_breaker', $circuit, 600 );
            return $body ? $body : array( 'success' => false, 'error' => 'Invalid response' );
        }

        // All retries exhausted — update persistent circuit breaker
        $circuit['failures'] = $circuit['failures'] + 1;
        if ( $circuit['failures'] >= 5 ) {
            $circuit['open_until'] = time() + 300;
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote API circuit breaker OPEN — 5 consecutive failures, cooldown 5 min', 'error', 'remote-client' );
            }
        }
        set_transient( 'hts_circuit_breaker', $circuit, 600 );

        return array( 'success' => false, 'error' => $last_error );
    }

    /**
     * Make a GET request to the remote API.
     *
     * @param  string $endpoint  API endpoint path (e.g. 'sync/status').
     * @param  array  $data      Query parameters (unused for GET body, reserved for future use).
     * @return array             Decoded response or error array.
     */
    public static function get( $endpoint, $data = array() ) {
        return self::call( $endpoint, $data, 'GET' );
    }

    /**
     * Check if the remote API is configured (API key present).
     *
     * @return bool
     */
    public static function is_available() {
        return ! empty( get_option( 'hts_api_key', '' ) );
    }

    /**
     * Check if any remote feature flag is active.
     *
     * @return bool
     */
    public static function has_active_flags() {
        return ( defined( 'HTS_REMOTE_SCORING' ) && HTS_REMOTE_SCORING )
            || ( defined( 'HTS_REMOTE_LINKING' ) && HTS_REMOTE_LINKING )
            || ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS )
            || ( defined( 'HTS_REMOTE_STRATEGY' ) && HTS_REMOTE_STRATEGY )
            || ( defined( 'HTS_REMOTE_WORKFLOW' ) && HTS_REMOTE_WORKFLOW );
    }
}
