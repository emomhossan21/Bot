<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Admin partial — API Costs Dashboard
 *
 * Affiche la consommation IA mensuelle par module.
 * Admin-only — PAS visible par les clients.
 *
 * @package Hack_The_SEO_Light
 * @since   2.5.15
 */

$month_key = wp_date( 'Y-m' );
$month_label = wp_date( 'F Y' );

// ── Compteurs Maillage ──
$linking_calls      = (int) get_option( 'hts_linking_calls_' . $month_key, 0 );
$linking_cache_hits = (int) get_option( 'hts_linking_cache_hits_' . $month_key, 0 );
$linking_tokens     = (int) get_option( 'hts_linking_tokens_' . $month_key, 0 );
$linking_tokens_anthropic = (int) get_option( 'hts_linking_tokens_anthropic_' . $month_key, 0 );
$linking_tokens_openai    = (int) get_option( 'hts_linking_tokens_openai_' . $month_key, 0 );

// ── Compteurs Coach ──
$coach_calls  = (int) get_option( 'hts_coach_calls_' . $month_key, 0 );
$coach_tokens = (int) get_option( 'hts_coach_tokens_' . $month_key, 0 );
$coach_tokens_anthropic = (int) get_option( 'hts_coach_tokens_anthropic_' . $month_key, 0 );
$coach_tokens_openai    = (int) get_option( 'hts_coach_tokens_openai_' . $month_key, 0 );
// Coach a son propre usage tracker
$coach_usage = get_option( 'hts_coach_usage', array() );
if ( is_array( $coach_usage ) && ( $coach_usage['month'] ?? '' ) === $month_key ) {
    $coach_requests = (int) ( $coach_usage['requests'] ?? 0 );
} else {
    $coach_requests = $coach_calls;
}

// ── Compteurs Metas ──
$metas_calls   = (int) get_option( 'hts_metas_calls_' . $month_key, 0 );
$metas_skipped = (int) get_option( 'hts_metas_skipped_' . $month_key, 0 );
$metas_tokens  = (int) get_option( 'hts_metas_tokens_' . $month_key, 0 );
$metas_tokens_anthropic = (int) get_option( 'hts_metas_tokens_anthropic_' . $month_key, 0 );
$metas_tokens_openai    = (int) get_option( 'hts_metas_tokens_openai_' . $month_key, 0 );

// ── Calcul coût estimé par provider ──
// Haiku 4.5 : $0.80/M input, $4.00/M output (ratio 30/70)
// GPT-4o-mini : $0.15/M input, $0.60/M output (ratio 30/70)
// GPT-4.1-mini : $0.40/M input, $1.60/M output (ratio 30/70)
// OpenAI Coach = mix 4o-mini et 4.1-mini, on moyenne à 4o-mini pour simplifier

$anthropic_cost_per_token = ( 0.3 * 0.80 + 0.7 * 4.00 ) / 1000000; // ~$3.04/M
$openai_cost_per_token    = ( 0.3 * 0.15 + 0.7 * 0.60 ) / 1000000; // ~$0.465/M

$linking_cost = $linking_tokens_anthropic * $anthropic_cost_per_token + $linking_tokens_openai * $openai_cost_per_token;
$coach_cost   = $coach_tokens_anthropic * $anthropic_cost_per_token + $coach_tokens_openai * $openai_cost_per_token;
$metas_cost   = $metas_tokens_anthropic * $anthropic_cost_per_token + $metas_tokens_openai * $openai_cost_per_token;

$cost_estimate = $linking_cost + $coach_cost + $metas_cost;
$total_tokens = $linking_tokens + $coach_tokens + $metas_tokens;

$budget_limit = 15.00; // $15/mois cible
$budget_pct   = $budget_limit > 0 ? min( 100, round( $cost_estimate / $budget_limit * 100 ) ) : 0;

// ── Gains cache ──
$linking_total_ops = $linking_calls + $linking_cache_hits;
$linking_cache_pct = $linking_total_ops > 0 ? round( $linking_cache_hits / $linking_total_ops * 100 ) : 0;

$metas_total_ops = $metas_calls + $metas_skipped;
$metas_skip_pct  = $metas_total_ops > 0 ? round( $metas_skipped / $metas_total_ops * 100 ) : 0;
?>

<!-- ═══════════════════════════════════════════════════
     API COSTS DASHBOARD — Admin only
     ═══════════════════════════════════════════════════ -->
<div style="margin-top:32px;">
    <h2 style="font-size:18px;font-weight:700;margin-bottom:16px;color:var(--hts-text, #1a1a2e);">
        Consommation API — <?php echo esc_html( $month_label ); ?>
    </h2>

    <!-- Budget global -->
    <div style="background:#fff;border:1px solid var(--hts-border, #e2e8f0);border-radius:12px;padding:20px;margin-bottom:20px;">
        <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:12px;">
            <span style="font-size:14px;font-weight:600;color:var(--hts-text, #1a1a2e);">Budget estimé</span>
            <span style="font-size:22px;font-weight:700;color:<?php echo $budget_pct > 80 ? '#ef4444' : ( $budget_pct > 50 ? '#f59e0b' : '#10b981' ); ?>;">
                $<?php echo number_format( $cost_estimate, 2 ); ?> <span style="font-size:13px;font-weight:400;color:var(--hts-text-3, #94a3b8);">/ $<?php echo number_format( $budget_limit, 2 ); ?></span>
            </span>
        </div>
        <div style="background:var(--hts-bg-2, #f1f5f9);border-radius:6px;height:8px;overflow:hidden;">
            <div style="height:100%;border-radius:6px;width:<?php echo $budget_pct; ?>%;background:<?php echo $budget_pct > 80 ? '#ef4444' : ( $budget_pct > 50 ? '#f59e0b' : '#10b981' ); ?>;transition:width .3s;"></div>
        </div>
        <div style="font-size:12px;color:var(--hts-text-3, #94a3b8);margin-top:6px;">
            <?php echo number_format( $total_tokens ); ?> tokens utilisés ce mois
        </div>
    </div>

    <!-- 3 cartes modules -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;">

        <!-- Maillage -->
        <div style="background:#fff;border:1px solid var(--hts-border, #e2e8f0);border-radius:12px;padding:20px;">
            <div style="font-size:13px;font-weight:600;color:var(--hts-text, #1a1a2e);margin-bottom:16px;">Maillage ancres IA</div>
            <div style="display:flex;flex-direction:column;gap:8px;font-size:13px;color:var(--hts-text-2, #64748b);">
                <div style="display:flex;justify-content:space-between;">
                    <span>Appels IA</span>
                    <span style="font-weight:600;color:var(--hts-text, #1a1a2e);"><?php echo $linking_calls; ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span>Cache hits</span>
                    <span style="font-weight:600;color:#10b981;"><?php echo $linking_cache_hits; ?> (<?php echo $linking_cache_pct; ?>%)</span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span>Tokens</span>
                    <span style="font-weight:600;color:var(--hts-text, #1a1a2e);"><?php echo number_format( $linking_tokens ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--hts-text-3, #94a3b8);">
                    <span>└ Anthropic</span>
                    <span><?php echo number_format( $linking_tokens_anthropic ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--hts-text-3, #94a3b8);">
                    <span>└ OpenAI</span>
                    <span><?php echo number_format( $linking_tokens_openai ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;border-top:1px solid var(--hts-border, #e2e8f0);padding-top:8px;margin-top:4px;">
                    <span style="font-weight:600;">Coût estimé</span>
                    <span style="font-weight:700;color:var(--hts-accent, #6366f1);">$<?php echo number_format( $linking_cost, 2 ); ?></span>
                </div>
            </div>
        </div>

        <!-- Coach SEO -->
        <div style="background:#fff;border:1px solid var(--hts-border, #e2e8f0);border-radius:12px;padding:20px;">
            <div style="font-size:13px;font-weight:600;color:var(--hts-text, #1a1a2e);margin-bottom:16px;">Coach SEO</div>
            <div style="display:flex;flex-direction:column;gap:8px;font-size:13px;color:var(--hts-text-2, #64748b);">
                <div style="display:flex;justify-content:space-between;">
                    <span>Messages</span>
                    <span style="font-weight:600;color:var(--hts-text, #1a1a2e);"><?php echo $coach_requests; ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span>Tokens</span>
                    <span style="font-weight:600;color:var(--hts-text, #1a1a2e);"><?php echo number_format( $coach_tokens ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--hts-text-3, #94a3b8);">
                    <span>└ Anthropic</span>
                    <span><?php echo number_format( $coach_tokens_anthropic ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--hts-text-3, #94a3b8);">
                    <span>└ OpenAI</span>
                    <span><?php echo number_format( $coach_tokens_openai ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;border-top:1px solid var(--hts-border, #e2e8f0);padding-top:8px;margin-top:4px;">
                    <span style="font-weight:600;">Coût estimé</span>
                    <span style="font-weight:700;color:var(--hts-accent, #6366f1);">$<?php echo number_format( $coach_cost, 2 ); ?></span>
                </div>
            </div>
        </div>

        <!-- AI Metas -->
        <div style="background:#fff;border:1px solid var(--hts-border, #e2e8f0);border-radius:12px;padding:20px;">
            <div style="font-size:13px;font-weight:600;color:var(--hts-text, #1a1a2e);margin-bottom:16px;">AI Metas</div>
            <div style="display:flex;flex-direction:column;gap:8px;font-size:13px;color:var(--hts-text-2, #64748b);">
                <div style="display:flex;justify-content:space-between;">
                    <span>Générations</span>
                    <span style="font-weight:600;color:var(--hts-text, #1a1a2e);"><?php echo $metas_calls; ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span>Skipped (cache)</span>
                    <span style="font-weight:600;color:#10b981;"><?php echo $metas_skipped; ?> (<?php echo $metas_skip_pct; ?>%)</span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span>Tokens</span>
                    <span style="font-weight:600;color:var(--hts-text, #1a1a2e);"><?php echo number_format( $metas_tokens ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--hts-text-3, #94a3b8);">
                    <span>└ Anthropic</span>
                    <span><?php echo number_format( $metas_tokens_anthropic ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--hts-text-3, #94a3b8);">
                    <span>└ OpenAI</span>
                    <span><?php echo number_format( $metas_tokens_openai ); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;border-top:1px solid var(--hts-border, #e2e8f0);padding-top:8px;margin-top:4px;">
                    <span style="font-weight:600;">Coût estimé</span>
                    <span style="font-weight:700;color:var(--hts-accent, #6366f1);">$<?php echo number_format( $metas_cost, 2 ); ?></span>
                </div>
            </div>
        </div>

    </div>

    <p style="font-size:11px;color:var(--hts-text-3, #94a3b8);margin-top:12px;">
        Estimation basée sur les tarifs Haiku 4.5 ($0.80/M input, $4.00/M output, ratio 30/70).
        Les compteurs se réinitialisent chaque mois.
    </p>
</div>
