<?php
defined( 'ABSPATH' ) || exit;
/**
 * Content Refresh — Détecte les articles obsolètes et propose la réécriture.
 *
 * Scan → propose dans Inbox (Workflow Engine) → request_rewrite via API HTS.
 * JAMAIS de réécriture locale — toujours via app.hacktheseo.
 *
 * @since 1.32.0 (porté et adapté du Full v2.9.3)
 * @package HackTheSEO
 */

class HTS_Content_Refresh {

    const MIN_AGE_DAYS        = 180;  // 6 mois minimum (fallback)
    const MAX_CLICKS_30D      = 5;    // Moins de 5 clics = obsolète (fallback)
    const OPT_STALE_CACHE     = 'hts_stale_articles_cache';

    /**
     * Récupère min_age_days depuis les agent settings (fresh) avec fallback.
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_min_age_days() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $settings = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'fresh' );
            if ( isset( $settings['min_age_days'] ) ) {
                return max( 30, (int) $settings['min_age_days'] );
            }
        }
        return self::MIN_AGE_DAYS;
    }

    /**
     * Récupère max_clicks depuis les agent settings (fresh) avec fallback.
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_max_clicks() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $settings = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'fresh' );
            if ( isset( $settings['max_clicks'] ) ) {
                return max( 0, (int) $settings['max_clicks'] );
            }
        }
        return self::MAX_CLICKS_30D;
    }

    public function init() {
        add_action( 'wp_ajax_hts_refresh_scan',    array( $this, 'ajax_scan' ) );
        add_action( 'wp_ajax_hts_refresh_request',  array( $this, 'ajax_request_rewrite' ) );
        add_action( 'wp_ajax_hts_refresh_apply',    array( $this, 'ajax_apply' ) );
        add_action( 'wp_ajax_hts_refresh_dismiss',  array( $this, 'ajax_dismiss' ) );

        // Cron hebdo : scan automatique
        add_action( 'hts_refresh_weekly_scan', array( $this, 'cron_scan' ) );
        if ( ! wp_next_scheduled( 'hts_refresh_weekly_scan' ) ) {
            wp_schedule_event( time() + 7200, 'weekly', 'hts_refresh_weekly_scan' );
        }

        // Hook Workflow dispatch pour exécuter les content_refresh
        add_filter( 'hts_workflow_dispatch', array( $this, 'handle_workflow_dispatch' ), 10, 5 );
    }

    /* ═══════════════════════════════════════════════
     *  SCAN ARTICLES OBSOLÈTES
     * ═══════════════════════════════════════════════ */

    /**
     * Trouver les articles obsolètes.
     *
     * @return array Articles stale avec leurs stats
     */
    public function scan_stale_articles() {
        global $wpdb;

        /**
         * Filter: minimum article age (days) before it's considered stale.
         *
         * @since 1.31.0
         * @param int $days Default minimum age in days.
         */
        $min_age  = (int) apply_filters( 'hts_refresh_min_age_days', self::get_min_age_days() );

        /**
         * Filter: maximum clicks threshold for stale detection.
         *
         * @since 1.31.0
         * @param int $clicks Default max clicks in 30 days.
         */
        $max_clk  = (int) apply_filters( 'hts_refresh_max_clicks', self::get_max_clicks() );
        $cutoff   = gmdate( 'Y-m-d', strtotime( "-{$min_age} days" ) );

        $results = $wpdb->get_results( $wpdb->prepare( "
            SELECT
                p.ID, p.post_title, p.post_name, p.post_date, p.post_modified,
                DATEDIFF( NOW(), p.post_modified ) AS days_since_modified,
                COALESCE( gc.meta_value, 0 ) AS gsc_clicks,
                COALESCE( geo.meta_value, 0 ) AS geo_score
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} gc  ON p.ID = gc.post_id  AND gc.meta_key = '_hts_gsc_clicks_30d'
            LEFT JOIN {$wpdb->postmeta} geo ON p.ID = geo.post_id AND geo.meta_key = '_hts_geo_score'
            WHERE p.post_type = 'post'
              AND p.post_status = 'publish'
              AND p.post_modified < %s
              AND COALESCE( gc.meta_value, 0 ) + 0 <= %d
            ORDER BY COALESCE( geo.meta_value, 100 ) + 0 ASC, p.post_modified ASC
            LIMIT 50
        ", $cutoff, $max_clk ), ARRAY_A );

        $dismissed = get_option( 'hts_refresh_dismissed', array() );
        $stale = array();

        foreach ( $results as $r ) {
            $pid = (int) $r['ID'];
            if ( in_array( $pid, $dismissed, true ) ) continue;

            // Garde-fou trafic (ne pas toucher les pages performantes)
            if ( class_exists( 'HTS_Workflow_Engine' ) && ! HTS_Workflow_Engine::check_traffic_threshold( $pid ) ) {
                continue;
            }

            $keyword = $this->find_keyword( $r );

            $stale[] = array(
                'post_id'         => $pid,
                'title'           => $r['post_title'],
                'slug'            => $r['post_name'],
                'modified'        => $r['post_modified'],
                'age_days'        => (int) $r['days_since_modified'],
                'gsc_clicks'      => (int) $r['gsc_clicks'],
                'geo_score'       => (int) $r['geo_score'],
                'keyword'         => $keyword,
                'edit_url'        => get_edit_post_link( $pid, 'raw' ),
            );
        }

        // S18 FIX: Filter by current language
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $cr_lang = HTS_Language::get_current_lang();
            if ( $cr_lang ) {
                $cr_lang_args = array(
                    'post_type' => array( 'post', 'page' ), 'post_status' => 'publish',
                    'posts_per_page' => -1, 'fields' => 'ids', 'suppress_filters' => false,
                );
                $cr_lang_args = HTS_Language::filter_query_args( $cr_lang_args, $cr_lang );
                $cr_post_ids = get_posts( $cr_lang_args );
                if ( ! empty( $cr_post_ids ) ) {
                    $stale = array_filter( $stale, function( $item ) use ( $cr_post_ids ) {
                        $pid = is_object( $item ) ? $item->ID : ( is_array( $item ) ? ( $item['post_id'] ?? $item['ID'] ?? 0 ) : 0 );
                        return in_array( (int) $pid, $cr_post_ids, true );
                    } );
                    $stale = array_values( $stale );
                }
            }
        }

        // Cache
        update_option( self::OPT_STALE_CACHE, $stale, false );

        return $stale;
    }

    /**
     * Proposer les articles stale dans le Workflow Engine.
     */
    public function propose_stale_to_inbox( $stale_articles ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;

        $count = 0;
        foreach ( $stale_articles as $article ) {
            $priority = ( $article['geo_score'] < 30 ) ? 'high' : 'medium';
            $action_id = HTS_Workflow_Engine::propose(
                'fresh',
                'content_refresh',
                $article['post_id'],
                array(
                    'reason'    => 'Non modifié depuis ' . $article['age_days'] . ' jours, ' . $article['gsc_clicks'] . ' clics/30j',
                    'geo_score' => $article['geo_score'],
                    'keyword'   => $article['keyword'],
                    'suggestion'=> 'Réécriture complète recommandée',
                ),
                $priority
            );
            if ( $action_id ) $count++;
        }

        return $count;
    }

    /* ═══════════════════════════════════════════════
     *  REQUEST REWRITE VIA API HTS
     * ═══════════════════════════════════════════════ */

    /**
     * Get the language of a post (for API calls).
     * Priority: post meta > Polylang/WPML > site setting > 'fr'.
     *
     * @since 2.5.9
     * @param int $post_id
     * @return string Language code (e.g. 'fr', 'en').
     */
    private static function get_post_lang( $post_id ) {
        // 1. Post-level override
        $lang = get_post_meta( $post_id, '_hts_content_lang', true );
        if ( $lang ) return $lang;

        // 2. Polylang/WPML detection
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $lang = HTS_Language::get_post_language( $post_id );
            if ( $lang ) return $lang;
        }

        // 3. Site setting fallback
        return get_option( 'hts_language', 'fr' );
    }

    /**
     * Envoyer un article à l'API HTS pour réécriture.
     * Retourne un job_id pour polling.
     *
     * @param int $post_id
     * @return array { job_id } ou { error }
     */
    public function request_rewrite( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'error' => 'Article introuvable.' );

        $api_key  = get_option( 'hts_api_key', '' );
        $base_url = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );

        if ( empty( $api_key ) ) {
            return array( 'error' => 'Clé API Hack The SEO non configurée.' );
        }

        $keyword = $this->find_keyword( array(
            'ID' => $post_id, 'post_title' => $post->post_title,
        ) );

        $body = array(
            'site_url' => site_url(),
            'article'  => array(
                'keyword' => $keyword,
                'title'   => $post->post_title,
            ),
            'language'      => self::get_post_lang( $post_id ),
            'auto_validate' => true,
        );

        // Contexte cocon si disponible
        $cocon_id = get_post_meta( $post_id, '_hts_cocon_id', true );
        if ( $cocon_id ) {
            $body['cocon_id'] = $cocon_id;
        }

        $url = rtrim( $base_url, '/' ) . '/api/v1/cocon/generate-article';

        $response = wp_remote_post( $url, array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'X-API-KEY'    => $api_key,
            ),
            'body' => wp_json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) {
            $err = $response->get_error_message();
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Refresh ERROR : ' . $err, 'error', 'refresh' );
            }
            return array( 'error' => 'Connexion API échouée : ' . $err );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 || empty( $data['job_id'] ) ) {
            $msg = $data['message'] ?? $data['error'] ?? 'Réponse API invalide (code ' . $code . ')';
            return array( 'error' => $msg );
        }

        // Stocker le job pour polling
        update_post_meta( $post_id, '_hts_refresh_job_id', sanitize_text_field( $data['job_id'] ) );
        update_post_meta( $post_id, '_hts_refresh_requested_at', current_time( 'mysql' ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Refresh demandé : post #' . $post_id . ' job=' . $data['job_id'], 'info', 'refresh' );
        }

        return array( 'job_id' => $data['job_id'], 'post_id' => $post_id );
    }

    /**
     * Appliquer une réécriture (content reçu de l'API).
     * Preserve : slug, featured image, post meta.
     *
     * @param int    $post_id
     * @param string $new_content HTML
     * @param string $new_title   Optionnel
     * @return bool
     */
    public function apply_rewrite( $post_id, $new_content, $new_title = '' ) {
        $post = get_post( $post_id );
        if ( ! $post ) return false;

        // ── Post-level lock: prevent concurrent modifications ──
        if ( class_exists( 'HTS_Content_Writer' ) && ! HTS_Content_Writer::acquire_post_lock( $post_id, 30 ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Refresh bloqué : post #' . $post_id . ' en cours de modification', 'info', 'refresh' );
            }
            return false;
        }

        // Backup via Content Writer si disponible
        if ( class_exists( 'HTS_Content_Writer' ) ) {
            HTS_Content_Writer::backup( $post_id );
        }

        // Audit Trail
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log( 'content_refresh', array(
                'post_id'         => $post_id,
                'snapshot_before' => mb_substr( $post->post_content, 0, 500 ),
            ) );
        }

        $update = array(
            'ID'           => $post_id,
            'post_content' => wp_kses_post( $new_content ),
        );
        if ( ! empty( $new_title ) ) {
            $update['post_title'] = sanitize_text_field( $new_title );
        }

        $result = wp_update_post( $update );

        // Release lock
        if ( class_exists( 'HTS_Content_Writer' ) ) {
            HTS_Content_Writer::release_post_lock( $post_id );
        }

        if ( is_wp_error( $result ) ) return false;

        // Marquer comme rafraîchi
        update_post_meta( $post_id, '_hts_refreshed_at', current_time( 'mysql' ) );
        delete_post_meta( $post_id, '_hts_refresh_job_id' );

        // Recalculer le GEO Score
        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $geo = new HTS_Geo_Score();
            $geo->calculate( $post_id, true );
        }

        // Pipeline enrichissement (images, schemas, cross-links)
        if ( class_exists( 'HTS_Article_Pipeline' ) ) {
            $keyword = $this->find_keyword( array( 'ID' => $post_id, 'post_title' => get_the_title( $post_id ) ) );
            HTS_Article_Pipeline::enrich_draft( $post_id, get_the_title( $post_id ), $keyword, $new_content );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Refresh appliqué : post #' . $post_id, 'success', 'refresh' );
        }

        return true;
    }

    /* ═══════════════════════════════════════════════
     *  WORKFLOW DISPATCH HANDLER
     * ═══════════════════════════════════════════════ */

    /**
     * Handler pour le dispatch Workflow Engine.
     */
    public function handle_workflow_dispatch( $result, $agent, $type, $post_id, $data ) {
        if ( $agent !== 'fresh' || $type !== 'content_refresh' ) return $result;

        $rewrite_result = $this->request_rewrite( $post_id );
        return ! isset( $rewrite_result['error'] );
    }

    /* ═══════════════════════════════════════════════
     *  CRON
     * ═══════════════════════════════════════════════ */

    public function cron_scan() {
        try {
        $stale = $this->scan_stale_articles();
        if ( ! empty( $stale ) ) {
            $proposed = $this->propose_stale_to_inbox( $stale );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Refresh cron : ' . count( $stale ) . ' articles obsolètes, ' . $proposed . ' proposés', 'info', 'refresh' );
            }
        }
        } catch ( \Throwable $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Refresh cron CRASH: ' . $e->getMessage() . ' L' . $e->getLine(), 'error', 'refresh' );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  AJAX HANDLERS
     * ═══════════════════════════════════════════════ */

    public function ajax_scan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $stale = $this->scan_stale_articles();
        $proposed = $this->propose_stale_to_inbox( $stale );

        wp_send_json_success( array(
            'stale'    => $stale,
            'count'    => count( $stale ),
            'proposed' => $proposed,
        ) );
    }

    public function ajax_request_rewrite() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'Post ID manquant' );

        $result = $this->request_rewrite( $post_id );
        if ( isset( $result['error'] ) ) {
            wp_send_json_error( array( 'message' => $result['error'] ) );
        }

        wp_send_json_success( $result );
    }

    public function ajax_apply() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        $content = wp_kses_post( $_POST['content'] ?? '' );

        if ( ! $post_id || empty( $content ) ) wp_send_json_error( 'Paramètres manquants' );

        $ok = $this->apply_rewrite( $post_id, $content );
        if ( $ok ) {
            wp_send_json_success( array( 'post_id' => $post_id ) );
        } else {
            wp_send_json_error( 'Échec de la mise à jour' );
        }
    }

    public function ajax_dismiss() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'Post ID manquant' );

        $dismissed = get_option( 'hts_refresh_dismissed', array() );
        if ( ! in_array( $post_id, $dismissed, true ) ) {
            $dismissed[] = $post_id;
            update_option( 'hts_refresh_dismissed', $dismissed, false );
        }

        wp_send_json_success();
    }

    /* ═══════════════════════════════════════════════
     *  HELPERS
     * ═══════════════════════════════════════════════ */

    private function find_keyword( $row ) {
        $pid = $row['ID'] ?? 0;
        if ( $pid ) {
            $kw = get_post_meta( $pid, '_hts_api_keyword', true );
            if ( $kw ) return $kw;
            $kw = get_post_meta( $pid, '_yoast_wpseo_focuskw', true );
            if ( $kw ) return $kw;
            $kw = get_post_meta( $pid, 'rank_math_focus_keyword', true );
            if ( $kw ) return $kw;
        }
        return $row['post_title'] ?? '';
    }

    /* ═══════════════════════════════════════════════
     *  COACH INTEGRATION STUBS — Sprint 5.1
     * ═══════════════════════════════════════════════ */

    /**
     * Refresh content for a post.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_id: int, sections?: array, add_faq?: bool }
     * @return bool
     */
    public static function refresh_from_coach( $params ) {
        $post_id = isset( $params['post_id'] ) ? (int) $params['post_id'] : 0;
        if ( $post_id <= 0 || ! get_post( $post_id ) ) return false;

        $instance = new self();
        if ( method_exists( $instance, 'request_rewrite' ) ) {
            $result = $instance->request_rewrite( $post_id );
            return ! isset( $result['error'] );
        }

        return false;
    }

    /**
     * Add FAQ section to a post.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_id: int, questions?: array }
     * @return bool
     */
    public static function add_faq_from_coach( $params ) {
        $post_id = isset( $params['post_id'] ) ? (int) $params['post_id'] : 0;
        $post    = get_post( $post_id );
        if ( ! $post ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach FAQ: post #{$post_id} introuvable", 'error', 'coach' );
            }
            return false;
        }

        // ── 1. Récupérer les infos du post ──
        $title   = $post->post_title;
        $content = wp_strip_all_tags( $post->post_content );
        $keyword = get_post_meta( $post_id, '_hts_api_keyword', true )
                   ?: get_post_meta( $post_id, '_hts_focus_keyword', true );
        // Sprint 5.3: Fallback to title if no keyword
        if ( empty( $keyword ) ) {
            $keyword = $title;
        }
        $excerpt = mb_substr( $content, 0, 1500 );

        // ── 2. Vérifier qu'une FAQ n'existe pas déjà ──
        if ( preg_match( '/<h[23][^>]*>[^<]*(?:FAQ|Questions?\s+fr[ée]quentes?|Foire\s+aux\s+questions)/ui', $post->post_content ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach FAQ: post #{$post_id} a déjà une section FAQ — ignoré", 'info', 'coach' );
            }
            return array( 'skipped' => true, 'reason' => 'FAQ déjà présente sur cet article.' );
        }

        // ── 3. Déterminer le provider AI ──
        $anthropic_key = hts_get_anthropic_key();
        $openai_key    = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : '';
        $provider      = '';

        if ( ! empty( $anthropic_key ) && strlen( $anthropic_key ) >= 20 ) {
            $provider = 'anthropic';
        } elseif ( ! empty( $openai_key ) ) {
            $provider = 'openai';
        } else {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach FAQ: aucune clé API AI configurée — impossible de générer", 'error', 'coach' );
            }
            return false;
        }

        // ── 4. Questions pré-fournies par le Coach ? ──
        $pre_questions = array();
        if ( ! empty( $params['questions'] ) && is_array( $params['questions'] ) ) {
            $pre_questions = array_map( 'sanitize_text_field', $params['questions'] );
        }

        // ── 5. Prompt LLM ──
        $q_hint = '';
        if ( ! empty( $pre_questions ) ) {
            $q_hint = "\nQuestions suggérées (utilise-les si pertinentes, sinon propose mieux) :\n- " . implode( "\n- ", $pre_questions );
        }

        $prompt = "Tu es un expert SEO français. Génère exactement 5 questions/réponses FAQ pour cet article.

Titre : {$title}
Mot-clé cible : {$keyword}
Extrait du contenu : {$excerpt}{$q_hint}

RÈGLES :
- Questions naturelles que les utilisateurs poseraient à un moteur IA (Google, ChatGPT, Perplexity)
- Réponses de 2-3 phrases, factuelles, utiles
- Inclure le mot-clé ou un synonyme dans au moins 3 questions
- Chaque réponse doit commencer par une phrase directe (pas de \"Oui,\" ou \"Non,\")
- PAS de numérotation dans les questions

Réponds UNIQUEMENT en JSON valide, sans markdown, sans backticks :
[{\"question\":\"...\",\"answer\":\"...\"}]";

        $system_msg = 'Tu réponds UNIQUEMENT en JSON valide. Pas de markdown, pas de backticks, pas de commentaire.';

        // ── 6. Appel LLM ──
        try {
            $text = '';
            $tokens_used = 0;

            if ( $provider === 'anthropic' ) {
                $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
                    'timeout' => 60,
                    'headers' => array(
                        'x-api-key'         => $anthropic_key,
                        'anthropic-version'  => '2023-06-01',
                        'Content-Type'       => 'application/json',
                    ),
                    'body' => wp_json_encode( array(
                        'model'      => 'claude-haiku-4-5-20251001',
                        'max_tokens' => 1500,
                        'system'     => $system_msg,
                        'messages'   => array(
                            array( 'role' => 'user', 'content' => $prompt ),
                        ),
                    ) ),
                ) );

                if ( is_wp_error( $response ) ) {
                    throw new \Exception( 'Erreur API Anthropic : ' . $response->get_error_message() );
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = json_decode( wp_remote_retrieve_body( $response ), true );

                if ( $code !== 200 ) {
                    $err = $body['error']['message'] ?? 'HTTP ' . $code;
                    throw new \Exception( 'Anthropic erreur : ' . $err );
                }

                $text        = $body['content'][0]['text'] ?? '';
                $tokens_used = (int) ( ( $body['usage']['input_tokens'] ?? 0 ) + ( $body['usage']['output_tokens'] ?? 0 ) );

            } else {
                $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
                    'timeout' => 60,
                    'headers' => array(
                        'Authorization' => 'Bearer ' . $openai_key,
                        'Content-Type'  => 'application/json',
                    ),
                    'body' => wp_json_encode( array(
                        'model'       => 'gpt-4o-mini',
                        'messages'    => array(
                            array( 'role' => 'system', 'content' => $system_msg ),
                            array( 'role' => 'user', 'content' => $prompt ),
                        ),
                        'temperature' => 0.3,
                        'max_tokens'  => 1500,
                    ) ),
                ) );

                if ( is_wp_error( $response ) ) {
                    throw new \Exception( 'Erreur API OpenAI : ' . $response->get_error_message() );
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = json_decode( wp_remote_retrieve_body( $response ), true );

                if ( $code !== 200 ) {
                    $err = $body['error']['message'] ?? 'HTTP ' . $code;
                    throw new \Exception( 'OpenAI erreur : ' . $err );
                }

                $text        = $body['choices'][0]['message']['content'] ?? '';
                $tokens_used = (int) ( $body['usage']['total_tokens'] ?? 0 );
            }

            // ── 7. Parser le JSON ──
            $text = trim( $text );
            // Nettoyage backticks au cas où
            $text = preg_replace( '/^```(?:json)?\s*/i', '', $text );
            $text = preg_replace( '/\s*```$/', '', $text );

            $faqs = json_decode( $text, true );
            if ( ! is_array( $faqs ) || count( $faqs ) < 2 ) {
                throw new \Exception( 'Réponse LLM non parsable ou insuffisante : ' . mb_substr( $text, 0, 200 ) );
            }

            // ── 8. Construire le bloc HTML FAQ ──
            // Format H3 questions → auto-détecté par class-hts-schema-markup.php pour FAQPage schema
            $faq_html  = "\n\n<!-- hts-faq -->\n";
            $faq_html .= '<div class="hts-faq-section" style="margin-top:60px;margin-bottom:40px;">' . "\n";
            $faq_html .= '<h2>Questions fréquentes</h2>' . "\n";

            $count = 0;
            foreach ( $faqs as $faq ) {
                if ( empty( $faq['question'] ) || empty( $faq['answer'] ) ) continue;
                $q = sanitize_text_field( $faq['question'] );
                $a = wp_kses_post( $faq['answer'] );
                // S'assurer que la question finit par ?
                if ( mb_substr( trim( $q ), -1 ) !== '?' ) $q .= ' ?';
                // Collapsible : chaque Q&A dans un <details> pour un rendu propre
                $faq_html .= '<details style="margin-bottom:8px;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;">' . "\n";
                $faq_html .= '<summary style="padding:14px 18px;font-weight:600;font-size:1.05em;cursor:pointer;background:#f9fafb;list-style:none;display:flex;justify-content:space-between;align-items:center;">' . esc_html( $q ) . '<span style="font-size:1.2em;transition:transform .2s;">+</span></summary>' . "\n";
                $faq_html .= '<div style="padding:12px 18px 16px;line-height:1.7;color:#374151;">' . $a . '</div>' . "\n";
                $faq_html .= '</details>' . "\n";
                $count++;
                if ( $count >= 5 ) break;
            }
            $faq_html .= "</div>\n<!-- /hts-faq -->\n";

            if ( $count < 2 ) {
                throw new \Exception( 'Moins de 2 Q&A valides générées' );
            }

            // ── 9. Appendre au contenu du post (builder-aware via Content Writer) ──
            // Content_Writer::append_html_block() gère : Elementor, Beaver, Bricks, Gutenberg, Classic, Divi, WPBakery
            if ( class_exists( 'HTS_Content_Writer' ) && method_exists( 'HTS_Content_Writer', 'append_html_block' ) ) {
                $writer_result = HTS_Content_Writer::append_html_block( $post_id, $faq_html );
                $builder_used  = $writer_result['builder'] ?? 'unknown';

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf( 'Coach FAQ: builder="%s" pour post #%d — %s', $builder_used, $post_id, $writer_result['message'] ?? '' ), 'info', 'coach' );
                }

                if ( ! empty( $writer_result['success'] ) ) {
                    // OK — Content Writer a géré l'insertion
                } else {
                    throw new \Exception( 'Content Writer: ' . ( $writer_result['message'] ?? 'Échec insertion FAQ' ) );
                }
            } else {
                // Fallback sans Content Writer (ne devrait pas arriver)
                $new_content = $post->post_content . $faq_html;
                $update_result = wp_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ), true );
                if ( is_wp_error( $update_result ) ) {
                    throw new \Exception( 'wp_update_post erreur : ' . $update_result->get_error_message() );
                }
            }

            // ── 10. Mettre à jour les metas ──
            delete_post_meta( $post_id, '_hts_needs_faq' );
            update_post_meta( $post_id, '_hts_faq_added', current_time( 'Y-m-d H:i:s' ) );
            update_post_meta( $post_id, '_hts_faq_source', 'coach' );
            update_post_meta( $post_id, '_hts_faq_count', $count );

            // Incrémenter le compteur de tokens Coach
            $month_key = 'hts_coach_tokens_' . wp_date( 'Y_m' );
            $current   = (int) get_option( $month_key, 0 );
            update_option( $month_key, $current + $tokens_used );

            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( 'Coach FAQ : %d Q&A ajoutées à "%s" (#%d) — %d tokens', $count, $title, $post_id, $tokens_used ),
                    'info',
                    'coach'
                );
            }

            return true;

        } catch ( \Throwable $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Coach FAQ erreur : ' . $e->getMessage(), 'error', 'coach' );
            }
            return false;
        }
    }

    /**
     * GEO optimize a post for AI engines.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { post_id: int, add_schema?: bool, add_faq?: bool, restructure?: bool }
     * @return bool
     */
    public static function geo_optimize_from_coach( $params ) {
        $post_id = isset( $params['post_id'] ) ? (int) $params['post_id'] : 0;
        if ( $post_id <= 0 || ! get_post( $post_id ) ) return false;

        // Recalculate GEO score if available
        if ( class_exists( 'HTS_Geo_Score' ) && method_exists( 'HTS_Geo_Score', 'calculate' ) ) {
            $geo = new \HTS_Geo_Score();
            $geo->calculate( $post_id, true );
        }

        // Sprint 5.3: Delegate FAQ to real generator instead of dead flag
        if ( ! empty( $params['add_faq'] ) ) {
            self::add_faq_from_coach( array( 'post_id' => $post_id ) );
        }

        // Flag for content refresh (GEO-focused)
        update_post_meta( $post_id, '_hts_needs_geo_optimize', 1 );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Coach: geo_optimize_from_coach pour post #{$post_id}", 'info', 'coach' );
        }

        return true;
    }
}
