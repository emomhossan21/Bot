<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Global Score — Score composite pour Light
 *
 * Combine le score SEO Panel existant (meta+contenu+SERP+lisibilité+GEO)
 * avec un score technique par article pour obtenir un score global unique.
 *
 * Formule : (seo_panel × 0.75) + (technique × 0.25)
 *
 * Score technique (6 checks normalisés à 100) :
 *   1. Mot-clé principal défini
 *   2. Schema JSON-LD configuré
 *   3. Canonical URL propre
 *   4. Pas de noindex accidentel
 *   5. Image mise en avant présente
 *   6. Liens entrants internes (pas orphelin)
 *
 * Features :
 *   - Auto-recompute quand le score SEO Panel change
 *   - Dashboard distribution + pires articles + batch
 *   - ROI timeline : snapshot hebdomadaire
 *   - "Analyser tout le site" batch AJAX
 *
 * @since 1.12.0
 */

class HTS_Global_Score {

    const META_GLOBAL       = '_hts_global_score';
    const META_GLOBAL_DETAIL = '_hts_global_score_detail';
    const META_GLOBAL_DATE  = '_hts_global_score_date';

    /* Weights — Phase 2: meta 25% + onpage 30% + panel 25% + tech 20% */
    const W_PANEL  = 0.25;
    const W_TECH   = 0.20;
    const W_META   = 0.25;
    const W_ONPAGE = 0.30;

    public function init() {
        // AJAX
        add_action( 'wp_ajax_hts_global_score_get',       array( $this, 'ajax_get_score' ) );
        add_action( 'wp_ajax_hts_global_score_bulk',      array( $this, 'ajax_bulk_score' ) );
        add_action( 'wp_ajax_hts_global_score_worst',     array( $this, 'ajax_get_worst' ) );
        add_action( 'wp_ajax_hts_global_score_batch_fix', array( $this, 'ajax_batch_fix' ) );
        add_action( 'wp_ajax_hts_global_score_dashboard', array( $this, 'ajax_dashboard' ) );

        // Auto-recompute when SEO Panel score changes
        add_action( 'updated_post_meta', array( $this, 'on_meta_updated' ), 10, 4 );
        add_action( 'added_post_meta',   array( $this, 'on_meta_updated' ), 10, 4 );

        // Weekly snapshot cron for ROI timeline
        add_action( 'hts_global_score_weekly_snapshot', array( $this, 'snapshot_scores' ) );
        if ( ! wp_next_scheduled( 'hts_global_score_weekly_snapshot' ) ) {
            wp_schedule_event( time(), 'weekly', 'hts_global_score_weekly_snapshot' );
        }
    }

    /* ──────────────────────────────────────────────
     *  AUTO-RECOMPUTE on SEO Panel score change
     * ────────────────────────────────────────────── */

    public function on_meta_updated( $meta_id, $post_id, $meta_key, $meta_value ) {
        if ( $meta_key !== '_hts_combined_score' ) return;

        // Debounce: once per request per post
        static $computed = array();
        if ( isset( $computed[ $post_id ] ) ) return;
        $computed[ $post_id ] = true;

        $this->compute_and_save( $post_id );
    }

    /* ──────────────────────────────────────────────
     *  CORE: Compute Global Score
     * ────────────────────────────────────────────── */

    /**
     * Compute global composite score for a single post.
     *
     * @param int  $post_id
     * @param bool $force  Force recompute sub-scores
     * @return array
     */
    public function compute( $post_id, $force = false ) {
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'publish', 'draft', 'future' ), true ) ) {
            return $this->empty_result();
        }

        // ── SEO Panel score (already covers meta+contenu+SERP+lisibilité+GEO) ──
        $panel_score = (int) get_post_meta( $post_id, '_hts_combined_score', true );

        // If no panel score exists or force recompute, run SEO Panel checks
        if ( $force || $panel_score === 0 ) {
            if ( class_exists( 'HTS_SEO_Panel' ) ) {
                $panel = new HTS_SEO_Panel();
                $result = $panel->run_checks( $post_id );
                $panel_score = (int) ( $result['score'] ?? 0 );
                update_post_meta( $post_id, '_hts_combined_score', $panel_score );
            }
        }

        // ── Technical Score ──
        $tech = $this->compute_technical( $post_id, $post );

        // ── Meta Score (Phase 1 — if module active) ──
        $meta_score = 0;
        $has_meta_score = false;
        if ( class_exists( 'HTS_Meta_Score' ) ) {
            $ms = new HTS_Meta_Score();
            $ms_result = $ms->compute( $post_id, true );
            $meta_score = (int) ( $ms_result['score'] ?? 0 );
            $has_meta_score = true;
        }

        // ── On-Page Score (Phase 2 — if module active) ──
        $onpage_score = 0;
        $has_onpage_score = false;
        if ( class_exists( 'HTS_On_Page_Score' ) ) {
            $ops = new HTS_On_Page_Score();
            $ops_result = $ops->compute( $post_id, true );
            $onpage_score = (int) ( $ops_result['score'] ?? 0 );
            $has_onpage_score = true;
        }

        // ── Cocon Health Bonus (Phase 2b — optional, ±5 pts max) ──
        $cocon_bonus = 0;
        $has_cocon = false;
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon_data = \HTS_Cocon::get_cached_cocon_data( class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '' );
            if ( ! empty( $cocon_data ) && is_array( $cocon_data ) ) {
                foreach ( $cocon_data as $cluster ) {
                    if ( empty( $cluster['pages'] ) ) continue;
                    foreach ( $cluster['pages'] as $page ) {
                        if ( (int) ( $page['post_id'] ?? 0 ) === (int) $post_id ) {
                            $has_cocon = true;
                            $role = $page['role'] ?? 'orpheline';
                            // Bonus: pilier +5, fille +3, satellite +1, orpheline -2
                            $role_bonus = array( 'pilier' => 5, 'fille' => 3, 'satellite' => 1, 'orpheline' => -2 );
                            $cocon_bonus = $role_bonus[ $role ] ?? 0;
                            break 2;
                        }
                    }
                }
            }
        }

        // ── Composite ──
        if ( $has_meta_score && $has_onpage_score ) {
            // Phase 2: meta 25% + onpage 30% + panel 25% + tech 20%
            $composite = round(
                ( $meta_score    * self::W_META ) +
                ( $onpage_score  * self::W_ONPAGE ) +
                ( $panel_score   * self::W_PANEL ) +
                ( $tech['score'] * self::W_TECH )
            );
        } elseif ( $has_meta_score ) {
            // Phase 1 fallback: meta 30% + panel 50% + tech 20%
            $composite = round(
                ( $meta_score    * 0.30 ) +
                ( $panel_score   * 0.50 ) +
                ( $tech['score'] * 0.20 )
            );
        } else {
            // Pre-Phase 1 fallback: panel 75% + tech 25%
            $composite = round(
                ( $panel_score   * 0.75 ) +
                ( $tech['score'] * 0.25 )
            );
        }
        $composite = max( 0, min( 100, $composite ) );

        // Apply cocon bonus (Phase 2b)
        if ( $has_cocon ) {
            $composite = max( 0, min( 100, $composite + $cocon_bonus ) );
        }

        return array(
            'score'         => $composite,
            'panel_score'   => $panel_score,
            'meta_score'    => $meta_score,
            'onpage_score'  => $onpage_score,
            'tech_score'    => $tech['score'],
            'tech_detail'   => $tech['checks'],
            'cocon_bonus'   => $cocon_bonus,
            'pending_actions' => class_exists( 'HTS_Decision_Engine' ) ? count( HTS_Decision_Engine::get_prioritized_actions( $post_id ) ) : 0,
            'grade'         => self::grade( $composite ),
            'weights'       => ( $has_meta_score && $has_onpage_score )
                ? array( 'meta' => self::W_META, 'onpage' => self::W_ONPAGE, 'panel' => self::W_PANEL, 'tech' => self::W_TECH )
                : ( $has_meta_score
                    ? array( 'meta' => 0.30, 'panel' => 0.50, 'tech' => 0.20 )
                    : array( 'panel' => 0.75, 'tech' => 0.25 )
                ),
        );
    }

    /**
     * Compute and save to post meta.
     */
    public function compute_and_save( $post_id, $force = false ) {
        try {
            $result = $this->compute( $post_id, $force );
        } catch ( \Throwable $e ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                hts_debug_log( '[Global Score] compute() crash post #' . $post_id . ' : ' . $e->getMessage() );
            }
            $result = $this->empty_result();
        }
        update_post_meta( $post_id, self::META_GLOBAL, $result['score'] );
        update_post_meta( $post_id, self::META_GLOBAL_DETAIL, wp_json_encode( array(
            'panel_score'  => $result['panel_score'],
            'meta_score'   => $result['meta_score'] ?? 0,
            'onpage_score' => $result['onpage_score'] ?? 0,
            'tech_score'   => $result['tech_score'],
            'grade'        => $result['grade'],
        ) ) );
        update_post_meta( $post_id, self::META_GLOBAL_DATE, time() );
        return $result;
    }

    private function empty_result() {
        return array( 'score' => 0, 'panel_score' => 0, 'tech_score' => 0, 'tech_detail' => array(), 'grade' => 'D' );
    }

    /* ──────────────────────────────────────────────
     *  TECHNICAL SCORE (per article, 6 checks)
     * ────────────────────────────────────────────── */

    private function compute_technical( $post_id, $post = null ) {
        if ( ! $post ) $post = get_post( $post_id );
        $checks = array();
        $total  = 0;
        $max    = 0;

        // 1. Focus keyword set (0 or 15)
        $kw = trim( get_post_meta( $post_id, '_hts_focus_keyword', true ) );
        $pts = $kw ? 15 : 0;
        $checks[] = array(
            'id'     => 'focus_keyword',
            'label'  => 'Mot-clé principal',
            'status' => $kw ? 'ok' : 'fail',
            'text'   => $kw
                ? 'Mot-clé défini : ' . esc_html( $kw )
                : 'Aucun mot-clé principal — indispensable pour le SEO',
            'points' => $pts,
            'max'    => 15,
        );
        $total += $pts;
        $max   += 15;

        // 2. Schema JSON-LD configured (0 or 15)
        $schema_type = get_post_meta( $post_id, '_hts_schema_type', true );
        $has_schema  = ! empty( $schema_type ) && $schema_type !== 'none';
        $pts = $has_schema ? 15 : 0;
        $checks[] = array(
            'id'     => 'schema',
            'label'  => 'Schema JSON-LD',
            'status' => $has_schema ? 'ok' : 'warn',
            'text'   => $has_schema
                ? 'Schema configuré : ' . esc_html( $schema_type )
                : 'Pas de schema JSON-LD — aide Google à comprendre le contenu',
            'points' => $pts,
            'max'    => 15,
        );
        $total += $pts;
        $max   += 15;

        // 3. Canonical clean (20 pts)
        $custom_canonical = get_post_meta( $post_id, '_hts_canonical_url', true );
        $canonical_text   = 'Canonical URL propre';
        if ( $custom_canonical ) {
            $permalink = get_permalink( $post_id );
            if ( untrailingslashit( $custom_canonical ) === untrailingslashit( $permalink ) ) {
                $canonical_text = 'Canonical auto-référencé (inutile mais pas nuisible)';
            } else {
                $canonical_text = 'Canonical personnalisé vers ' . esc_html( wp_parse_url( $custom_canonical, PHP_URL_PATH ) ?: $custom_canonical );
            }
        }
        $pts = 20; // Canonical is always "OK" unless missing entirely — handled by the plugin
        $checks[] = array(
            'id'     => 'canonical',
            'label'  => 'URL canonique',
            'status' => 'ok',
            'text'   => $canonical_text,
            'points' => $pts,
            'max'    => 20,
        );
        $total += $pts;
        $max   += 20;

        // 4. Not accidentally noindexed (0 or 20)
        $robots_meta = get_post_meta( $post_id, '_hts_robots_meta', true );
        $is_noindex  = $robots_meta && stripos( $robots_meta, 'noindex' ) !== false;
        $accidental  = $is_noindex && $post->post_status === 'publish';
        $pts = $accidental ? 0 : 20;
        $checks[] = array(
            'id'     => 'indexation',
            'label'  => 'Indexation',
            'status' => $accidental ? 'fail' : 'ok',
            'text'   => $accidental
                ? 'Article publié mais marqué noindex — Google ne l\'indexera pas !'
                : ( $is_noindex ? 'Noindex volontaire (brouillon/page utilitaire)' : 'Indexable par Google' ),
            'points' => $pts,
            'max'    => 20,
        );
        $total += $pts;
        $max   += 20;

        // 5. Featured image present (0 or 15)
        $has_thumb = has_post_thumbnail( $post_id );
        $pts = $has_thumb ? 15 : 0;
        $checks[] = array(
            'id'     => 'featured_image',
            'label'  => 'Image mise en avant',
            'status' => $has_thumb ? 'ok' : 'warn',
            'text'   => $has_thumb
                ? 'Image mise en avant définie'
                : 'Pas d\'image mise en avant — important pour les réseaux sociaux et Google',
            'points' => $pts,
            'max'    => 15,
        );
        $total += $pts;
        $max   += 15;

        // 6. Inbound internal links (0-15)
        global $wpdb;
        $url_path = wp_parse_url( get_permalink( $post_id ), PHP_URL_PATH );
        $inbound  = 0;
        if ( $url_path ) {
            $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
            $inbound = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT ID) FROM {$wpdb->posts}
                 WHERE post_status = 'publish'
                   AND post_type {$pt_in}
                   AND ID != %d
                   AND post_content LIKE %s",
                $post_id,
                '%' . $wpdb->esc_like( $url_path ) . '%'
            ) );
        }
        if ( $inbound >= 3 ) {
            $pts = 15; $status = 'ok';
            $text = $inbound . ' pages pointent vers cet article — bon maillage';
        } elseif ( $inbound >= 1 ) {
            $pts = 10; $status = 'warn';
            $text = $inbound . ' page(s) pointe(nt) vers cet article — essayez d\'en ajouter';
        } else {
            $pts = 0; $status = 'fail';
            $text = 'Aucun lien interne entrant — article orphelin, invisible pour Google';
        }
        $checks[] = array(
            'id'     => 'inbound_links',
            'label'  => 'Liens entrants internes',
            'status' => $status,
            'text'   => $text,
            'points' => $pts,
            'max'    => 15,
        );
        $total += $pts;
        $max   += 15;

        // Normalize to 0-100
        $score = $max > 0 ? round( $total / $max * 100 ) : 0;

        return array( 'score' => $score, 'checks' => $checks );
    }

    /* ──────────────────────────────────────────────
     *  WORST ARTICLES
     * ────────────────────────────────────────────── */

    public function get_worst_articles( $limit = 20 ) {
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        global $wpdb;

        // S18 FIX: Build SQL language clause
        $gs_lang_clause = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $gs_lang = HTS_Language::get_current_lang();
            if ( $gs_lang ) {
                $lang_args = array(
                    'post_type' => array( 'post', 'page' ), 'post_status' => 'publish',
                    'posts_per_page' => -1, 'fields' => 'ids', 'suppress_filters' => false,
                );
                $lang_args = HTS_Language::filter_query_args( $lang_args, $gs_lang );
                $gs_post_ids = get_posts( $lang_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $gs_post_objects = array_map( 'get_post', $gs_post_ids );
                    $gs_post_objects = array_values( HTS_Language::filter_posts_by_lang( $gs_post_objects, $gs_lang ) );
                    $gs_post_ids = wp_list_pluck( $gs_post_objects, 'ID' );
                }
                if ( ! empty( $gs_post_ids ) ) {
                    $ids_str = implode( ',', array_map( 'intval', $gs_post_ids ) );
                    $gs_lang_clause = " AND p.ID IN ({$ids_str})";
                }
            }
        }

        // Posts with lowest global score
        $scored_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT pm.post_id
             FROM {$wpdb->postmeta} pm
             JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = %s
               AND p.post_status = 'publish'
               AND p.post_type {$pt_in}
               {$gs_lang_clause}
             ORDER BY CAST(pm.meta_value AS UNSIGNED) ASC
             LIMIT %d",
            self::META_GLOBAL,
            $limit
        ) );

        // Also include unscored posts (worst by definition)
        $remaining = $limit - count( $scored_ids );
        if ( $remaining > 0 ) {
            $exclude = ! empty( $scored_ids ) ? implode( ',', array_map( 'intval', $scored_ids ) ) : '0';
            $unscored_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p
                 LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = %s
                 WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
                   AND pm.meta_id IS NULL AND p.ID NOT IN ({$exclude})
                   {$gs_lang_clause}
                 LIMIT %d",
                self::META_GLOBAL,
                $remaining
            ) );
            $scored_ids = array_merge( $unscored_ids, $scored_ids ); // Unscored first
        }

        $results = array();
        foreach ( array_slice( $scored_ids, 0, $limit ) as $pid ) {
            $pid = (int) $pid;
            $detail_raw = get_post_meta( $pid, self::META_GLOBAL_DETAIL, true );
            $detail     = $detail_raw ? json_decode( $detail_raw, true ) : array();
            $score      = (int) get_post_meta( $pid, self::META_GLOBAL, true );

            $results[] = array(
                'post_id'     => $pid,
                'title'       => get_the_title( $pid ),
                'url'         => get_permalink( $pid ),
                'edit_url'    => get_edit_post_link( $pid, 'raw' ),
                'score'       => $score,
                'panel_score' => (int) ( $detail['panel_score'] ?? 0 ),
                'tech_score'  => (int) ( $detail['tech_score'] ?? 0 ),
                'grade'       => $detail['grade'] ?? self::grade( $score ),
                'scored_at'   => (int) get_post_meta( $pid, self::META_GLOBAL_DATE, true ),
            );
        }

        return $results;
    }

    /* ──────────────────────────────────────────────
     *  DISTRIBUTION STATS
     * ────────────────────────────────────────────── */

    public function get_distribution() {
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";

        $total = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}"
        );

        $mk = self::META_GLOBAL;

        $scored = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT pm.post_id)
             FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = %s AND p.post_status = 'publish' AND p.post_type {$pt_in}",
            $mk
        ) );

        $brackets = array( 'excellent' => 0, 'bon' => 0, 'moyen' => 0, 'faible' => 0 );

        if ( $scored > 0 ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT CAST(pm.meta_value AS UNSIGNED) AS s
                 FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key = %s AND p.post_status = 'publish' AND p.post_type {$pt_in}",
                $mk
            ) );
            foreach ( $rows as $r ) {
                $s = (int) $r->s;
                if ( $s >= 80 )      $brackets['excellent']++;
                elseif ( $s >= 60 )  $brackets['bon']++;
                elseif ( $s >= 40 )  $brackets['moyen']++;
                else                 $brackets['faible']++;
            }
        }

        $avg = 0;
        if ( $scored > 0 ) {
            $avg = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ROUND(AVG(CAST(pm.meta_value AS UNSIGNED)))
                 FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key = %s AND p.post_status = 'publish' AND p.post_type {$pt_in}",
                $mk
            ) );
        }

        return array(
            'total'    => $total,
            'scored'   => $scored,
            'unscored' => $total - $scored,
            'average'  => $avg,
            'grade'    => self::grade( $avg ),
            'brackets' => $brackets,
        );
    }

    /**
     * Weekly snapshot for ROI timeline.
     */
    public function snapshot_scores() {
        $dist = $this->get_distribution();
        $history = get_option( 'hts_global_score_history', array() );
        $history[] = array(
            'date'     => current_time( 'Y-m-d' ),
            'average'  => $dist['average'],
            'scored'   => $dist['scored'],
            'brackets' => $dist['brackets'],
        );
        // Keep last 52 weeks
        if ( count( $history ) > 52 ) {
            $history = array_slice( $history, -52 );
        }
        update_option( 'hts_global_score_history', $history, false );
        return $dist;
    }

    /* ──────────────────────────────────────────────
     *  AJAX HANDLERS
     * ────────────────────────────────────────────── */

    public function ajax_get_score() {
        check_ajax_referer( 'hts_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Accès refusé' );
        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'ID manquant' );

        $result = $this->compute_and_save( $post_id, true );
        wp_send_json_success( $result );
    }

    public function ajax_bulk_score() {
        check_ajax_referer( 'hts_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Accès refusé' );

        $pt_in      = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $batch_size = min( 20, max( 1, (int) ( $_POST['batch_size'] ?? 10 ) ) );
        $offset     = max( 0, (int) ( $_POST['offset'] ?? 0 ) );

        global $wpdb;

        // Total published posts
        $total = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}"
        );

        // Get a batch by offset
        $batch_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type {$pt_in}
             ORDER BY ID ASC LIMIT %d OFFSET %d",
            $batch_size,
            $offset
        ) );

        $results = array();
        foreach ( $batch_ids as $pid ) {
            try {
                $r = $this->compute_and_save( (int) $pid, true );
                $results[] = array(
                    'post_id' => (int) $pid,
                    'title'   => get_the_title( $pid ),
                    'score'   => $r['score'],
                    'grade'   => $r['grade'],
                );
            } catch ( \Throwable $e ) {
                // Skip l'article fautif, log en debug, continue le batch
                if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                    hts_debug_log( '[Global Score] Erreur batch post #' . $pid . ' : ' . $e->getMessage() );
                }
                $results[] = array(
                    'post_id' => (int) $pid,
                    'title'   => get_the_title( $pid ),
                    'score'   => 0,
                    'grade'   => 'D',
                    'error'   => true,
                );
            }
        }

        $processed = $offset + count( $batch_ids );

        wp_send_json_success( array(
            'results'   => $results,
            'processed' => $processed,
            'total'     => $total,
            'done'      => $processed >= $total,
        ) );
    }

    public function ajax_get_worst() {
        check_ajax_referer( 'hts_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Accès refusé' );

        $limit = min( 50, max( 5, (int) ( $_POST['limit'] ?? 20 ) ) );
        $worst = $this->get_worst_articles( $limit );

        wp_send_json_success( array(
            'articles' => $worst,
            'count'    => count( $worst ),
        ) );
    }

    public function ajax_batch_fix() {
        check_ajax_referer( 'hts_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Accès refusé' );

        $post_id  = (int) ( $_POST['post_id'] ?? 0 );
        $fix_type = sanitize_text_field( $_POST['fix_type'] ?? '' );

        if ( ! $post_id || ! $fix_type ) wp_send_json_error( 'Paramètres manquants' );

        $result = array( 'post_id' => $post_id, 'fix_type' => $fix_type, 'status' => 'skipped' );

        try {
            switch ( $fix_type ) {
                case 'rescore_all':
                    $r = $this->compute_and_save( $post_id, true );
                    $result['status'] = 'success';
                    $result['score']  = $r['score'];
                    $result['global_score'] = $r['score'];
                    break;

                case 'rescore_panel':
                    if ( class_exists( 'HTS_SEO_Panel' ) ) {
                        $panel = new HTS_SEO_Panel();
                        $a = $panel->run_checks( $post_id );
                        update_post_meta( $post_id, '_hts_combined_score', (int) $a['score'] );
                        // Global will auto-recompute via on_meta_updated hook
                        $result['status'] = 'success';
                        $result['score']  = $a['score'];
                    }
                    break;

                default:
                    $result['status'] = 'unknown_fix_type';
            }
        } catch ( \Throwable $e ) {
            $result['status'] = 'error';
            $result['error']  = $e->getMessage();
        }

        // Return fresh global score
        if ( $result['status'] === 'success' && ! isset( $result['global_score'] ) ) {
            $g = $this->compute_and_save( $post_id, false );
            $result['global_score'] = $g['score'];
        }

        wp_send_json_success( $result );
    }

    public function ajax_dashboard() {
        check_ajax_referer( 'hts_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Accès refusé' );

        $dist    = $this->get_distribution();
        $history = get_option( 'hts_global_score_history', array() );
        $worst   = $this->get_worst_articles( 5 );

        wp_send_json_success( array(
            'distribution' => $dist,
            'history'      => $history,
            'worst_5'      => $worst,
        ) );
    }

    /* ──────────────────────────────────────────────
     *  HELPERS
     * ────────────────────────────────────────────── */

    public static function grade( $score ) {
        if ( $score >= 80 ) return 'A';
        if ( $score >= 60 ) return 'B';
        if ( $score >= 40 ) return 'C';
        return 'D';
    }

    public static function grade_label( $grade ) {
        $labels = array( 'A' => 'Excellent', 'B' => 'Bon', 'C' => 'À améliorer', 'D' => 'Critique' );
        return $labels[ $grade ] ?? 'Non évalué';
    }

    public static function grade_color( $grade ) {
        $colors = array( 'A' => '#22c55e', 'B' => '#3b82f6', 'C' => '#f59e0b', 'D' => '#ef4444' );
        return $colors[ $grade ] ?? '#94a3b8';
    }

    /**
     * Get pending count for badge in Cockpit nav.
     */
    public static function get_articles_to_fix_count() {
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT pm.post_id)
             FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = %s AND CAST(pm.meta_value AS UNSIGNED) < 50
               AND p.post_status = 'publish' AND p.post_type {$pt_in}",
            self::META_GLOBAL
        ) );
    }
}
