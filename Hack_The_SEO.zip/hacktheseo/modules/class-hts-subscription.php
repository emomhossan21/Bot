<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Subscription — 3-Tier Feature Gating (v2.7.0)
 *
 * Free (tier 0) = SEO technique + scoring + coach 5Q/mois
 * Pro  (tier 1) = + cocons analyse + rapports + coach illimité
 * Ultra (tier 2) = + rédaction IA + maillage IA + inbox + auto-write + tout
 *
 * Plans WP : free, wp_pro (99€), wp_ultra (249€)
 * Plans SaaS (non-WP) : growth_plus, pro_plus → tier 0 côté plugin
 * Plans legacy : legacy_69 → tier 1, legacy_dfy → tier 2
 *
 * @package Hack_The_SEO_Light
 * @since   1.2.0
 * @updated 2.7.0 — Refonte 3 tiers Free/Pro/Ultra
 */

class HTS_Subscription {

    const OPT_STATUS     = 'hts_subscription_status';
    const OPT_DATA       = 'hts_subscription_data';
    const OPT_CHECKED_AT = 'hts_subscription_checked_at';
    const CHECK_INTERVAL = DAY_IN_SECONDS;

    /* ── Tier constants ── */
    const TIER_FREE  = 0;
    const TIER_PRO   = 1;
    const TIER_ULTRA = 2;

    public function init() {
        add_action( 'admin_init', [ $this, 'maybe_check_subscription' ] );
        add_action( 'admin_notices', [ $this, 'maybe_show_notice' ] );
        add_action( 'wp_ajax_hts_refresh_subscription', [ $this, 'ajax_refresh' ] );

        // Cron daily check — runs at ~3am server time
        add_action( 'hts_subscription_daily_check', [ __CLASS__, 'cron_check' ] );
        if ( ! wp_next_scheduled( 'hts_subscription_daily_check' ) ) {
            $tomorrow_3am = strtotime( 'tomorrow 03:00' );
            wp_schedule_event( $tomorrow_3am, 'daily', 'hts_subscription_daily_check' );
        }
    }

    public static function cron_check() {
        $api_key = self::api_key();
        if ( empty( $api_key ) ) return;
        $result = self::check_now( $api_key );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'Subscription cron: status=%s tier=%d plan=%s',
                $result['status'] ?? 'unknown', self::get_plan_tier(), $result['data']['plan'] ?? 'n/a'
            ), 'info', 'subscription' );
        }
    }

    /* ══════════════════════════════════════════════
     *  TIER & PLAN HELPERS
     * ══════════════════════════════════════════════ */

    /**
     * Get plan tier: 0=Free, 1=Pro, 2=Ultra.
     * Reads from stored option (set by validate-key/subscription-status).
     * Falls back to slug mapping if option not set.
     */
    public static function get_plan_tier() {
        // Bypass: force Ultra when HTS_UNLOCK_ALL is defined
        if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) return self::TIER_ULTRA;

        // Direct tier from SaaS (set by store_plan_data)
        $stored_tier = get_option( 'hts_api_tier', null );
        if ( $stored_tier !== null && $stored_tier !== '' ) {
            return (int) $stored_tier;
        }

        // Fallback: map slug to tier
        $slug = self::get_plan_slug();
        $tiers = array(
            // Plans WP (nouveaux)
            'free'        => self::TIER_FREE,
            'wp_pro'      => self::TIER_PRO,
            'wp_ultra'    => self::TIER_ULTRA,
            // Plans SaaS existants → tier 0 côté plugin (tous les slugs possibles)
            'growth_plus' => self::TIER_FREE,
            'pro_plus'    => self::TIER_FREE,
            'starter'     => self::TIER_FREE,
            'growth'      => self::TIER_FREE,
            'agency'      => self::TIER_FREE,
            // Plans legacy
            'legacy_69'   => self::TIER_PRO,
            'legacy_dfy'  => self::TIER_ULTRA,
        );
        if ( isset( $tiers[ $slug ] ) ) return $tiers[ $slug ];

        // Fuzzy match for custom slugs
        if ( preg_match( '/ultra|wp_ultra|dfy/i', $slug ) ) return self::TIER_ULTRA;
        if ( preg_match( '/wp_pro|pro_wp/i', $slug ) ) return self::TIER_PRO;

        // Any non-free, non-SaaS slug = unknown, default free
        return self::TIER_FREE;
    }

    public static function get_plan_slug() {
        if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) return 'wp_ultra';
        // First check stored plan from validate-key
        $stored = get_option( 'hts_api_plan', '' );
        if ( ! empty( $stored ) ) return sanitize_key( $stored );

        // Fallback to subscription data
        $data = self::get_data();
        $slug = $data['plan']['slug'] ?? ( $data['plan'] ?? '' );
        if ( is_array( $slug ) ) $slug = $slug['slug'] ?? '';
        return ! empty( $slug ) && is_string( $slug ) ? sanitize_key( $slug ) : 'free';
    }

    /** Tier >= 1 (Pro or Ultra) */
    public static function is_pro() {
        return self::get_plan_tier() >= self::TIER_PRO;
    }

    /** Tier >= 2 (Ultra only) */
    public static function is_ultra() {
        return self::get_plan_tier() >= self::TIER_ULTRA;
    }

    /** Has any active subscription */
    public static function is_active() {
        if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) return true;
        return get_option( self::OPT_STATUS ) === 'active';
    }

    /** Legacy compat */
    public static function is_paid() {
        return self::is_pro();
    }

    /* ══════════════════════════════════════════════
     *  FEATURE GATING — can($feature) + require_tier()
     * ══════════════════════════════════════════════ */

    /**
     * Check if current plan can access a feature.
     *
     * @param string $feature Feature slug
     * @return bool
     */
    public static function can( $feature ) {
        // Bypass: define('HTS_UNLOCK_ALL', true) in wp-config.php
        if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) return true;

        // Grace: unknown status (never checked) → full access
        $status = self::get_status();
        if ( $status === 'unknown' ) return true;

        // Expired/inactive → force tier 0
        $tier = self::is_active() ? self::get_plan_tier() : self::TIER_FREE;

        $gates = array(
            // FREE (tier 0) — always accessible
            'seo_modules'      => 0, 'gsc_proxy'        => 0, 'global_score'     => 0,
            'health_check'     => 0, 'llmstxt'          => 0, 'migration_wizard' => 0,
            'coach_chat'       => 0, 'support_chat'     => 0, 'receive_articles' => 0,
            'redirections'     => 0, 'redirect_ai'      => 0, 'cannibalization'  => 0, 'content_refresh'  => 0,

            // PRO (tier >= 1)
            'cocon_analyze'    => 1, 'cocon_plans'      => 1, 'cocon_export'     => 1,
            'coach_unlimited'  => 1, 'coach_reports'    => 1, 'coach_memory'     => 1,
            'coach_analytics'  => 1, 'inbox_view'       => 1, 'planning'         => 1,

            // ULTRA (tier >= 2)
            'cocon_write'      => 2, 'cocon_apply_links'=> 2, 'cocon_import'     => 2,
            'maillage_ia'      => 2, 'standalone'       => 2, 'auto_write'       => 2,
            'inbox_actions'    => 2, 'agent_mode'       => 2, 'rapport_hebdo'    => 2,
            'pdf_brandable'    => 2, 'embeddings'       => 2, 'cannibal_merge'   => 2,
            'strategy_engine'  => 2, 'decision_engine'  => 2, 'feedback_loop'    => 2,
            'audit_trail'      => 2,
        );

        $min = $gates[ $feature ] ?? 2; // unknown features default to Ultra
        return $tier >= $min;
    }

    public static function is_locked( $feature ) {
        return ! self::can( $feature );
    }

    /**
     * AJAX guard helper — call at the top of any gated endpoint.
     * Sends wp_send_json_error and DIES if tier insufficient.
     *
     * @param int $min_tier Minimum tier required (1=Pro, 2=Ultra)
     */
    public static function require_tier( $min_tier ) {
        if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) return;
        if ( self::get_status() === 'unknown' ) return; // grace period

        $tier = self::is_active() ? self::get_plan_tier() : self::TIER_FREE;
        if ( $tier >= $min_tier ) return;

        $plans = array(
            1 => array( 'name' => 'Pro',   'price' => '99',  'benefit' => 'Analysez votre site, créez votre stratégie de contenu et posez toutes vos questions au Coach SEO.' ),
            2 => array( 'name' => 'Ultra', 'price' => '249', 'benefit' => 'Rédigez vos articles automatiquement, créez des liens entre vos pages et laissez l\'IA piloter votre SEO.' ),
        );
        $p = $plans[ $min_tier ] ?? $plans[2];

        wp_send_json_error( array(
            'locked'      => true,
            'required'    => strtolower( $p['name'] ),
            'current_tier'=> $tier,
            'message'     => $p['benefit'],
            'upgrade_url' => 'https://hacktheseo.com/pricing',
        ) );
    }

    /* ══════════════════════════════════════════════
     *  DATA STORAGE
     * ══════════════════════════════════════════════ */

    public static function get_data() {
        $data = get_option( self::OPT_DATA, [] );
        return is_array( $data ) ? $data : [];
    }

    public static function get_status() {
        if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) return 'active';
        return get_option( self::OPT_STATUS, 'unknown' );
    }

    /**
     * Store enriched plan data from SaaS validate-key / subscription-status.
     */
    public static function store_plan_data( $body ) {
        if ( ! is_array( $body ) ) return;
        if ( isset( $body['plan'] ) )                  update_option( 'hts_api_plan', sanitize_key( $body['plan'] ), false );
        if ( isset( $body['tier'] ) )                   update_option( 'hts_api_tier', intval( $body['tier'] ), false );
        if ( isset( $body['features'] ) )               update_option( 'hts_api_features', $body['features'], false );
        if ( isset( $body['article_quota_plugin'] ) )   update_option( 'hts_api_article_quota_plugin', intval( $body['article_quota_plugin'] ), false );
        if ( isset( $body['articles_used_plugin'] ) )   update_option( 'hts_api_articles_used_plugin', intval( $body['articles_used_plugin'] ), false );
        if ( isset( $body['article_quota_saas'] ) )     update_option( 'hts_api_article_quota_saas', intval( $body['article_quota_saas'] ), false );
        if ( isset( $body['articles_used_saas'] ) )     update_option( 'hts_api_articles_used_saas', intval( $body['articles_used_saas'] ), false );
        if ( isset( $body['max_languages'] ) )          update_option( 'hts_api_max_languages', intval( $body['max_languages'] ), false );

        // ── Clés IA fournies par le SaaS (Pro/Ultra) ──
        if ( ! empty( $body['ai_openai_key'] ) ) {
            update_option( 'hts_openai_api_key', sanitize_text_field( $body['ai_openai_key'] ), false );
        }
        if ( ! empty( $body['ai_anthropic_key'] ) ) {
            update_option( 'hts_coach_api_key', sanitize_text_field( $body['ai_anthropic_key'] ), false );
        }
    }

    private static function api_base() {
        return rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' );
    }

    private static function api_key() {
        return get_option( 'hts_api_key', '' );
    }

    /* ══════════════════════════════════════════════
     *  LAZY CHECK + API CALL
     * ══════════════════════════════════════════════ */

    public function maybe_check_subscription() {
        if ( ! isset( $_GET['page'] ) ) return;
        $hts_pages = array(
            'hts-light-dashboard', 'hts-seo-settings', 'hts-api-settings', 'hts-upgrade',
            'hts-cocon-commander', 'hts-planning', 'hts-cannibalization',
        );
        if ( ! in_array( $_GET['page'], $hts_pages, true ) ) return;
        $api_key = self::api_key();
        if ( empty( $api_key ) ) return;
        $last_check = (int) get_option( self::OPT_CHECKED_AT, 0 );
        if ( ( time() - $last_check ) < self::CHECK_INTERVAL ) return;
        self::check_now( $api_key );
    }

    public static function check_now( $api_key = '' ) {
        if ( empty( $api_key ) ) $api_key = self::api_key();
        if ( empty( $api_key ) ) return array( 'success' => false, 'status' => 'unknown', 'data' => array() );

        $url = self::api_base() . '/api/subscription/status';
        $response = wp_remote_get( $url, array(
            'timeout' => 10,
            'headers' => array( 'Accept' => 'application/json', 'x-api-key' => $api_key ),
        ) );

        if ( is_wp_error( $response ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Subscription check: ' . $response->get_error_message(), 'warning', 'subscription' );
            }
            update_option( self::OPT_CHECKED_AT, time(), false );
            return array( 'success' => false, 'status' => self::get_status(), 'data' => array() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 200 && is_array( $body ) ) {
            $status = ! empty( $body['active'] ) ? 'active' : ( $body['status'] ?? 'inactive' );
            $old    = get_option( self::OPT_STATUS );

            update_option( self::OPT_STATUS, $status, false );
            update_option( self::OPT_DATA, $body, false );
            update_option( self::OPT_CHECKED_AT, time(), false );

            // Store enriched tier data if SaaS provides it
            self::store_plan_data( $body );

            if ( $old && $old !== $status ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Abonnement : $old → $status (tier " . self::get_plan_tier() . ')', $status === 'active' ? 'success' : 'warning', 'subscription' );
                }
            }

            return array( 'success' => true, 'status' => $status, 'data' => $body );
        }

        if ( $code === 401 || $code === 403 ) {
            update_option( self::OPT_STATUS, 'inactive', false );
            update_option( self::OPT_DATA, $body ?: array(), false );
            update_option( self::OPT_CHECKED_AT, time(), false );
            return array( 'success' => false, 'status' => 'inactive', 'data' => $body ?: array() );
        }

        update_option( self::OPT_CHECKED_AT, time(), false );
        return array( 'success' => false, 'status' => self::get_status(), 'data' => array() );
    }

    /* ── Admin notice ── */

    public function maybe_show_notice() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( empty( self::api_key() ) ) return;
        $status = self::get_status();
        if ( $status === 'expired' ) {
            echo '<div class="notice notice-warning is-dismissible"><p>';
            echo '<strong>Hack The SEO</strong> — Abonnement expiré. ';
            echo '<a href="' . esc_url( self::api_base() . '/billing' ) . '" target="_blank">Renouveler →</a>';
            echo '</p></div>';
        }
    }

    /* ── AJAX refresh ── */

    public function ajax_refresh() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ) );

        $result = self::check_now();
        if ( $result['success'] ) {
            $plan  = $result['data']['plan'] ?? '';
            $label = $result['status'] === 'active' ? 'Actif' : ucfirst( $result['status'] );
            wp_send_json_success( array(
                'message' => sprintf( 'Abonnement %s%s (tier %d)', $label, $plan ? " ($plan)" : '', self::get_plan_tier() ),
                'status'  => $result['status'],
                'tier'    => self::get_plan_tier(),
                'data'    => $result['data'],
            ) );
        }

        wp_send_json_error( array(
            'message' => 'Impossible de vérifier. Vérifiez votre clé API.',
            'status'  => $result['status'],
        ) );
    }

    /* ── Reset ── */

    public static function reset() {
        delete_option( self::OPT_STATUS );
        delete_option( self::OPT_DATA );
        delete_option( self::OPT_CHECKED_AT );
        delete_option( 'hts_api_plan' );
        delete_option( 'hts_api_tier' );
        delete_option( 'hts_api_features' );
        delete_option( 'hts_api_article_quota_plugin' );
        delete_option( 'hts_api_articles_used_plugin' );
        delete_option( 'hts_api_max_languages' );
    }
}
