<?php
defined( 'ABSPATH' ) || exit;
/**
 * Module : Content Freshness
 *
 * Score de fraîcheur 0-100 par article.
 * 100 = modifié aujourd'hui, 0 = modifié il y a > 12 mois.
 * Colonne admin "Fraîcheur" dans la liste des posts.
 *
 * @since 1.32.0 (porté du Full v2.2.0)
 * @package HackTheSEO
 */

class HTS_Freshness {

    public function init() {
        add_filter( 'manage_posts_columns', array( $this, 'add_column' ) );
        add_action( 'manage_posts_custom_column', array( $this, 'render_column' ), 10, 2 );
        add_filter( 'manage_edit-post_sortable_columns', array( $this, 'sortable_column' ) );
        add_action( 'admin_head', array( $this, 'column_css' ) );
    }

    /**
     * Calcule le score de fraîcheur (0-100).
     *
     * @param int $post_id
     * @return int Score 0-100
     */
    public static function get_score( $post_id ) {
        $modified = get_post_modified_time( 'U', false, $post_id );
        if ( ! $modified ) return 0;

        $days_old = ( time() - $modified ) / DAY_IN_SECONDS;

        // 0 jours = 100, 365 jours = 0, linéaire
        return (int) round( max( 0, min( 100, 100 - ( $days_old / 365 * 100 ) ) ) );
    }

    /**
     * Nombre de jours depuis la dernière modification.
     */
    public static function get_days_since_modified( $post_id ) {
        $modified = get_post_modified_time( 'U', false, $post_id );
        if ( ! $modified ) return 9999;
        return (int) round( ( time() - $modified ) / DAY_IN_SECONDS );
    }

    /**
     * Badge couleur selon le score.
     */
    public static function get_badge( $score ) {
        if ( $score >= 70 ) {
            return array( 'label' => 'Frais', 'color' => '#059669', 'bg' => '#ecfdf5' );
        } elseif ( $score >= 40 ) {
            return array( 'label' => 'À revoir', 'color' => '#d97706', 'bg' => '#fffbeb' );
        } else {
            return array( 'label' => 'Obsolète', 'color' => '#dc2626', 'bg' => '#fef2f2' );
        }
    }

    /* ═══ COLONNES ADMIN ═══ */

    public function add_column( $columns ) {
        $columns['hts_freshness'] = 'Fraîcheur';
        return $columns;
    }

    public function render_column( $column, $post_id ) {
        if ( $column !== 'hts_freshness' ) return;

        $score = self::get_score( $post_id );
        $badge = self::get_badge( $score );
        $modified = get_the_modified_date( 'd/m/Y', $post_id );

        printf(
            '<span class="hts-freshness-pill" style="background:%s;color:%s;" title="Modifié le %s">%s</span>',
            esc_attr( $badge['bg'] ),
            esc_attr( $badge['color'] ),
            esc_attr( $modified ),
            esc_html( $score . '% — ' . $badge['label'] )
        );
    }

    public function sortable_column( $columns ) {
        $columns['hts_freshness'] = 'modified';
        return $columns;
    }

    public function column_css() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->id !== 'edit-post' ) return;
        echo '<style>
        .hts-freshness-pill { display:inline-block; padding:3px 10px; border-radius:12px; font-size:12px; font-weight:600; white-space:nowrap; }
        .column-hts_freshness { width:120px; }
        </style>';
    }
}
