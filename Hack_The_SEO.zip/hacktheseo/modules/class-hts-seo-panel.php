<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS SEO Panel v4 — Unified Editor Experience
 *
 * THE SINGLE VISIBLE SCORE for editors and admin columns.
 * Premium metabox replacing meta-tags, robots, canonical metaboxes.
 * Self-contained 21-check scoring engine (no dependency on Meta Score / On-Page Score).
 *
 * Meta Score = backend-only (feeds Orchestrator).
 * On-Page Score = deprecated (kept for history/backward compat).
 * SEO Panel = the one score users see in the editor + posts list column.
 *
 * Scoring weights:
 *   SEO de base      (5 checks) → 35% of score
 *   Contenu          (5 checks) → 25% of score
 *   Meta & SERP      (3 checks) → 15% of score
 *   Citabilité GEO   (6 checks) → 20% of score   ← v1.7.0 (+freshness)
 *   Lisibilité       (2 checks) → 5% of score
 *   Hidden penalty: over-optimization (negative only, not displayed as check)
 *
 * @since 4.0.0
 */

class HTS_SEO_Panel {

    const NONCE = 'hts_seo_panel_nonce';

    public function init() {
        add_action( 'add_meta_boxes', array( $this, 'register' ), 5 );
        add_action( 'save_post',      array( $this, 'save' ), 10, 2 );
        add_action( 'add_meta_boxes', array( $this, 'remove_old_metaboxes' ), 99 );
        add_action( 'wp_ajax_hts_panel_score', array( $this, 'ajax_score' ) );
        // Lightweight status widget in Gutenberg sidebar (Article panel)
        add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_gutenberg_status' ) );

        // Admin columns
        add_filter( 'manage_posts_columns',       array( $this, 'add_columns' ) );
        add_filter( 'manage_pages_columns',        array( $this, 'add_columns' ) );
        add_action( 'manage_posts_custom_column',  array( $this, 'render_column' ), 10, 2 );
        add_action( 'manage_pages_custom_column',  array( $this, 'render_column' ), 10, 2 );
        add_filter( 'manage_edit-post_sortable_columns',  array( $this, 'sortable_columns' ) );
        add_filter( 'manage_edit-page_sortable_columns',  array( $this, 'sortable_columns' ) );
        add_action( 'pre_get_posts', array( $this, 'sort_by_score' ) );
        add_action( 'admin_head',    array( $this, 'column_css' ) );

        // Score filter dropdown in post list
        add_action( 'restrict_manage_posts', array( $this, 'score_filter_dropdown' ) );
    }

    public function register() {
        foreach ( get_post_types( array( 'public' => true ), 'names' ) as $pt ) {
            if ( $pt === 'attachment' ) continue;
            add_meta_box( 'hts-seo-panel', 'Hack The SEO', array( $this, 'render' ), $pt, 'normal', 'high' );
            // Sidebar summary for Classic Editor (hidden in Gutenberg via CSS)
            add_meta_box( 'hts-seo-summary', 'Hack The SEO', array( $this, 'render_summary' ), $pt, 'side', 'high' );
        }
    }

    public function remove_old_metaboxes() {
        foreach ( get_post_types( array( 'public' => true ), 'names' ) as $pt ) {
            remove_meta_box( 'hts-meta-tags', $pt, 'normal' );
            remove_meta_box( 'hts-robots-meta', $pt, 'side' );
            remove_meta_box( 'hts_canonical_metabox', $pt, 'side' );
        }
    }

    /**
     * Enqueue the lightweight Gutenberg status widget (PluginPostStatusInfo).
     * Shows score + keyword in the "Article" sidebar panel.
     */
    public function enqueue_gutenberg_status() {
        global $post;
        if ( ! $post ) return;
        if ( get_option( 'hts_module_meta_tags', '1' ) !== '1' ) return;
        if ( ! $this->is_block_editor_active( $post ) ) return;

        wp_enqueue_script(
            'hts-gutenberg-status',
            HTS__PLUGIN_URL . 'admin/js/hts-gutenberg-status.js',
            array( 'wp-plugins', 'wp-element', 'wp-dom-ready' ),
            HTS__VERSION,
            true
        );
        wp_localize_script( 'hts-gutenberg-status', 'htsSidebar', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'hts_panel_score' ),
            'postId'  => $post->ID,
        ) );
    }

    /* ══════════════════════════════════════════════════════════════════
     *  21-CHECK SCORING ENGINE
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Run all 21 checks + hidden penalties.
     *
     * @param int   $post_id
     * @param array $overrides Optional live field values (kw, title, desc, slug) for real-time analysis without saving.
     * @return array {
     *   score: int 0-100,
     *   groups: array { key => { label, weight, checks: array{ id, status, text, points, max } } },
     *   penalty: int (negative points from over-optimization)
     * }
     */
    public function run_checks( $post_id, $overrides = array() ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'score' => 0, 'groups' => array(), 'penalty' => 0 );

        // Use overrides if provided (live AJAX), otherwise read from DB
        if ( isset( $overrides['kw'] ) ) {
            $kw = mb_strtolower( trim( $overrides['kw'] ) );
        } else {
            $kw = trim( get_post_meta( $post_id, '_hts_focus_keyword', true ) );
            if ( ! $kw ) $kw = trim( get_post_meta( $post_id, '_hts_api_keyword', true ) );
            if ( ! $kw ) $kw = trim( get_post_meta( $post_id, 'rank_math_focus_keyword', true ) );
            if ( ! $kw ) $kw = trim( get_post_meta( $post_id, '_yoast_wpseo_focuskw', true ) );
            if ( ! $kw ) $kw = trim( get_post_meta( $post_id, '_hts_gsc_top_query', true ) );
            $kw = mb_strtolower( $kw );
        }
        $title      = isset( $overrides['title'] )      ? $overrides['title']                          : get_post_meta( $post_id, '_hts_meta_title', true );
        $desc       = isset( $overrides['desc'] )       ? $overrides['desc']                           : get_post_meta( $post_id, '_hts_meta_description', true );
        $slug       = isset( $overrides['slug'] )       ? sanitize_title( $overrides['slug'] )         : $post->post_name;
        $post_title = isset( $overrides['post_title'] ) ? $overrides['post_title']                     : $post->post_title;
        $pt         = $post->post_type;

        // Get rendered content: live override or from DB/Content Extractor
        if ( isset( $overrides['content'] ) && $overrides['content'] !== '' ) {
            // Live content from editor (Gutenberg sends serialized blocks, Classic sends HTML)
            $content = $overrides['content'];
            // Process blocks & shortcodes — same as the saved path
            $content = do_shortcode( $content );
            if ( function_exists( 'do_blocks' ) ) {
                $content = do_blocks( $content );
            }
            // Only wpautop if content doesn't already have block-level HTML
            // (Gutenberg output already has <p> tags; wpautop would double-wrap)
            if ( stripos( $content, '<p' ) === false && stripos( $content, '<div' ) === false ) {
                $content = wpautop( $content );
            }
        } else {
            if ( class_exists( 'HTS_Content_Extractor' ) ) {
                $content = HTS_Content_Extractor::get_content( $post_id );
                if ( ! $content ) {
                    $content = $post->post_content;
                }
            } else {
                $content = $post->post_content;
            }
            $content = do_shortcode( $content );
            if ( function_exists( 'do_blocks' ) ) {
                $content = do_blocks( $content );
            }
            $content = wpautop( $content );
        }

        // Strip any remaining Gutenberg block comments before text analysis
        $content = preg_replace( '/<!--\s*\/?wp:[^>]*-->/s', '', $content );

        $text        = wp_strip_all_tags( $content );
        $text_lower  = mb_strtolower( $text );
        $words       = hts_word_count( $text );
        $site_name   = get_bloginfo( 'name' );
        $sep         = get_option( 'hts_title_separator', '—' );

        // Resolve effective title/desc (use live post_title, not DB)
        $eff_title = $title ?: ( $post_title . ' ' . $sep . ' ' . $site_name );
        $eff_desc  = $desc ?: wp_trim_words( $text, 25, '…' );

        // Parse headings from content
        preg_match_all( '/<h([1-6])[^>]*>(.*?)<\/h\1>/si', $content, $h_matches, PREG_SET_ORDER );
        $headings = array();
        $has_explicit_h1 = false;
        foreach ( $h_matches as $m ) {
            if ( (int) $m[1] === 1 ) $has_explicit_h1 = true;
            $headings[] = array( 'level' => (int) $m[1], 'text' => mb_strtolower( wp_strip_all_tags( $m[2] ) ) );
        }

        // WordPress renders the post title as H1 via the theme template.
        // If no explicit <h1> is found in post_content, inject the post title as virtual H1.
        // This is the standard behavior for Classic Editor, Gutenberg, and most themes.
        // Page builders (Elementor, Divi) that include their own H1 in content are already covered above.
        if ( ! $has_explicit_h1 && $post_title ) {
            array_unshift( $headings, array(
                'level' => 1,
                'text'  => mb_strtolower( $post_title ),
            ) );
        }

        // Parse images
        preg_match_all( '/<img[^>]+>/si', $content, $img_matches );
        $images = $img_matches[0] ?? array();
        $images_with_alt = 0;
        $images_with_kw_alt = 0;
        foreach ( $images as $img ) {
            if ( preg_match( '/alt=["\']([^"\']+)["\']/i', $img, $alt_m ) ) {
                $images_with_alt++;
                if ( $kw && stripos( $alt_m[1], $kw ) !== false ) $images_with_kw_alt++;
            }
        }

        // Parse links
        preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>/si', $content, $link_matches );
        $home = home_url();
        $internal_links = 0;
        $external_links = 0;
        foreach ( $link_matches[1] ?? array() as $href ) {
            if ( strpos( $href, $home ) === 0 || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                $internal_links++;
            } elseif ( strpos( $href, 'http' ) === 0 ) {
                $external_links++;
            }
        }

        // First 100 words
        $first_words = implode( ' ', array_slice( explode( ' ', $text_lower ), 0, 100 ) );

        // ── Groups & Checks ──
        $groups = array();

        // ═══ GROUP 1: SEO DE BASE (35%) ═══
        $g1 = array( 'label' => 'SEO de base', 'weight' => 35, 'checks' => array() );

        // 1. Keyword in title
        if ( ! $kw ) {
            $g1['checks'][] = array( 'id' => 'kw_title', 'status' => 'warn', 'text' => 'Aucun mot-clé principal défini', 'points' => 3, 'max' => 10, 'fix' => 'Définissez votre mot-clé principal dans le champ ci-dessus. Choisissez le terme que vos visiteurs tapent sur Google.' );
        } else {
            $kw_in_title = stripos( mb_strtolower( $eff_title ), $kw ) !== false;
            $kw_starts_title = stripos( mb_strtolower( $eff_title ), $kw ) === 0 || stripos( mb_strtolower( $eff_title ), $kw ) <= 3;
            if ( $kw_starts_title ) {
                $g1['checks'][] = array( 'id' => 'kw_title', 'status' => 'ok', 'text' => 'Mot-clé en début de title SEO — excellent', 'points' => 10, 'max' => 10 );
            } elseif ( $kw_in_title ) {
                $g1['checks'][] = array( 'id' => 'kw_title', 'status' => 'warn', 'text' => 'Mot-clé présent dans le title SEO mais pas en début', 'points' => 6, 'max' => 10, 'fix' => 'Déplacez votre mot-clé en début de title. Google accorde plus de poids aux premiers mots. Exemple : « ' . esc_html( $kw ) . ' : votre guide complet ».' );
            } else {
                $g1['checks'][] = array( 'id' => 'kw_title', 'status' => 'fail', 'text' => 'Mot-clé absent du title SEO', 'points' => 0, 'max' => 10, 'fix' => 'Placez votre mot-clé en début de title. Exemple : au lieu de « Notre guide complet », écrivez « ' . esc_html( $kw ) . ' : guide complet 2026 ».' );
            }
        }

        // 2. Keyword in meta desc
        if ( $kw ) {
            $kw_in_desc = stripos( mb_strtolower( $eff_desc ), $kw ) !== false;
            $g1['checks'][] = $kw_in_desc
                ? array( 'id' => 'kw_desc', 'status' => 'ok', 'text' => 'Mot-clé présent dans la meta description', 'points' => 10, 'max' => 10 )
                : array( 'id' => 'kw_desc', 'status' => 'fail', 'text' => 'Mot-clé absent de la meta description', 'points' => 0, 'max' => 10, 'fix' => 'Intégrez naturellement votre mot-clé dans la meta description. Elle apparaît sous le titre dans Google.' );
        } else {
            $g1['checks'][] = array( 'id' => 'kw_desc', 'status' => 'warn', 'text' => 'Pas de mot-clé — meta description non vérifiable', 'points' => 3, 'max' => 10, 'fix' => 'Définissez d\'abord un mot-clé principal pour que cette vérification fonctionne.' );
        }

        // 3. Keyword in H1
        $h1s = array_filter( $headings, function( $h ) { return $h['level'] === 1; } );
        if ( $kw && ! empty( $h1s ) ) {
            $kw_in_h1 = false;
            foreach ( $h1s as $h1 ) { if ( stripos( $h1['text'], $kw ) !== false ) { $kw_in_h1 = true; break; } }
            $g1['checks'][] = $kw_in_h1
                ? array( 'id' => 'kw_h1', 'status' => 'ok', 'text' => 'Mot-clé présent dans le H1', 'points' => 10, 'max' => 10 )
                : array( 'id' => 'kw_h1', 'status' => 'fail', 'text' => 'Mot-clé absent du H1', 'points' => 0, 'max' => 10, 'fix' => 'Le titre principal de la page (H1) doit contenir votre mot-clé. Modifiez le titre de l\'article.' );
        } elseif ( empty( $h1s ) ) {
            $g1['checks'][] = array( 'id' => 'kw_h1', 'status' => 'fail', 'text' => 'Aucun H1 trouvé sur la page', 'points' => 0, 'max' => 10, 'fix' => 'Chaque page doit avoir un titre principal (H1). Vérifiez les réglages de votre thème ou ajoutez un H1 manuellement.' );
        } else {
            $g1['checks'][] = array( 'id' => 'kw_h1', 'status' => 'warn', 'text' => 'Aucun mot-clé — H1 non vérifiable', 'points' => 3, 'max' => 10, 'fix' => 'Définissez d\'abord un mot-clé principal pour que cette vérification fonctionne.' );
        }

        // 4. Keyword in URL
        $is_front = ( (int) get_option( 'page_on_front' ) === $post_id && get_option( 'show_on_front' ) === 'page' );
        if ( $is_front ) {
            // Front page URL is just "/" — slug is irrelevant, give full points
            $g1['checks'][] = array( 'id' => 'kw_url', 'status' => 'ok', 'text' => 'Page d\'accueil — URL racine du site', 'points' => 10, 'max' => 10 );
        } elseif ( $kw ) {
            $slug_clean = str_replace( '-', ' ', $slug );
            // Normalize accents: WordPress strips accents in slugs, so compare without them
            $kw_words = explode( ' ', function_exists( 'remove_accents' ) ? remove_accents( $kw ) : $kw );
            $found_words = 0;
            foreach ( $kw_words as $w ) { if ( $w !== '' && stripos( $slug_clean, $w ) !== false ) $found_words++; }
            $coverage = count( $kw_words ) > 0 ? $found_words / count( $kw_words ) : 0;

            if ( $coverage >= 0.8 ) {
                $g1['checks'][] = array( 'id' => 'kw_url', 'status' => 'ok', 'text' => 'Mot-clé reflété dans l\'URL', 'points' => 10, 'max' => 10 );
            } elseif ( $coverage >= 0.4 ) {
                $g1['checks'][] = array( 'id' => 'kw_url', 'status' => 'warn', 'text' => 'URL partiellement optimisée pour le mot-clé', 'points' => 5, 'max' => 10, 'fix' => 'Idéalement, l\'URL devrait contenir tous les mots de votre mot-clé, séparés par des tirets.' );
            } else {
                $g1['checks'][] = array( 'id' => 'kw_url', 'status' => 'fail', 'text' => 'Mot-clé absent de l\'URL', 'points' => 0, 'max' => 10, 'fix' => 'Modifiez le permalien pour inclure votre mot-clé. Attention : si la page est déjà en ligne, créez une redirection 301 depuis l\'ancienne URL.' );
            }
        } else {
            $g1['checks'][] = array( 'id' => 'kw_url', 'status' => 'warn', 'text' => 'Pas de mot-clé — URL non vérifiable', 'points' => 3, 'max' => 10, 'fix' => 'Définissez d\'abord un mot-clé principal pour que cette vérification fonctionne.' );
        }

        // 5. Keyword in first 100 words
        if ( $kw ) {
            $kw_in_intro = stripos( $first_words, $kw ) !== false;
            $g1['checks'][] = $kw_in_intro
                ? array( 'id' => 'kw_intro', 'status' => 'ok', 'text' => 'Mot-clé présent dans l\'introduction', 'points' => 10, 'max' => 10 )
                : array( 'id' => 'kw_intro', 'status' => 'warn', 'text' => 'Mot-clé absent des 100 premiers mots', 'points' => 3, 'max' => 10, 'fix' => 'Mentionnez votre mot-clé dès les premières phrases. Google et les IA accordent plus d\'importance au début du texte.' );
        } else {
            $g1['checks'][] = array( 'id' => 'kw_intro', 'status' => 'warn', 'text' => 'Pas de mot-clé — introduction non vérifiable', 'points' => 3, 'max' => 10, 'fix' => 'Définissez d\'abord un mot-clé principal pour que cette vérification fonctionne.' );
        }
        $groups['seo_base'] = $g1;

        // ═══ GROUP 2: CONTENU (25%) ═══
        $g2 = array( 'label' => 'Contenu', 'weight' => 25, 'checks' => array() );

        // 6. Content length
        $min_words = $pt === 'page' ? 300 : 800;
        if ( $words >= $min_words ) {
            $g2['checks'][] = array( 'id' => 'length', 'status' => 'ok', 'text' => number_format( $words, 0, ',', ' ' ) . ' mots — longueur suffisante', 'points' => 10, 'max' => 10 );
        } elseif ( $words >= $min_words * 0.5 ) {
            $g2['checks'][] = array( 'id' => 'length', 'status' => 'warn', 'text' => number_format( $words, 0, ',', ' ' ) . ' mots — contenu un peu court (recommandé : ' . $min_words . '+)', 'points' => 5, 'max' => 10, 'fix' => 'Développez votre contenu : ajoutez des exemples, une FAQ, ou des conseils pratiques pour étoffer l\'article.' );
        } else {
            $g2['checks'][] = array( 'id' => 'length', 'status' => 'fail', 'text' => number_format( $words, 0, ',', ' ' ) . ' mots — contenu trop court (min. ' . $min_words . ')', 'points' => 1, 'max' => 10, 'fix' => 'Ce contenu est trop court pour bien se positionner. Visez au moins ' . $min_words . ' mots en ajoutant des sections utiles pour le lecteur.' );
        }

        // 7. Keyword in at least 1 subheading
        if ( $kw ) {
            $sub_headings = array_filter( $headings, function( $h ) { return $h['level'] >= 2; } );
            $kw_in_sub = false;
            foreach ( $sub_headings as $sh ) { if ( stripos( $sh['text'], $kw ) !== false ) { $kw_in_sub = true; break; } }
            $g2['checks'][] = $kw_in_sub
                ? array( 'id' => 'kw_sub', 'status' => 'ok', 'text' => 'Mot-clé présent dans un sous-titre H2/H3', 'points' => 10, 'max' => 10 )
                : array( 'id' => 'kw_sub', 'status' => 'warn', 'text' => 'Mot-clé absent des sous-titres (H2/H3)', 'points' => 3, 'max' => 10, 'fix' => 'Ajoutez votre mot-clé dans au moins un sous-titre H2. Ça aide Google à comprendre le sujet principal.' );
        } else {
            $g2['checks'][] = array( 'id' => 'kw_sub', 'status' => 'warn', 'text' => 'Pas de mot-clé — sous-titres non vérifiables', 'points' => 3, 'max' => 10, 'fix' => 'Définissez d\'abord un mot-clé principal pour que cette vérification fonctionne.' );
        }

        // 8. Images with relevant alt
        $img_count = count( $images );
        if ( $img_count === 0 ) {
            $g2['checks'][] = array( 'id' => 'images', 'status' => 'warn', 'text' => 'Aucune image — ajoutez des visuels', 'points' => 2, 'max' => 10, 'fix' => 'Ajoutez au moins une image pertinente avec un texte alternatif décrivant l\'image. Les visuels améliorent l\'engagement.' );
        } elseif ( $images_with_alt < $img_count ) {
            $missing = $img_count - $images_with_alt;
            $g2['checks'][] = array( 'id' => 'images', 'status' => 'warn', 'text' => $missing . ' image(s) sans attribut alt sur ' . $img_count, 'points' => 5, 'max' => 10, 'fix' => 'Cliquez sur chaque image et remplissez le champ « Texte alternatif ». Décrivez ce que montre l\'image en quelques mots.' );
        } else {
            $g2['checks'][] = array( 'id' => 'images', 'status' => 'ok', 'text' => $img_count . ' image(s) avec alt text', 'points' => 10, 'max' => 10 );
        }

        // 9. Internal links — scales with content length (best practice 2026: 1 link per 500 words)
        $ideal_links = max( 2, (int) floor( $words / 500 ) );
        if ( $internal_links >= $ideal_links ) {
            $g2['checks'][] = array( 'id' => 'int_links', 'status' => 'ok', 'text' => $internal_links . ' lien(s) interne(s) — bon maillage (recommandé : ' . $ideal_links . '+ pour ' . number_format( $words, 0, ',', ' ' ) . ' mots)', 'points' => 10, 'max' => 10 );
        } elseif ( $internal_links >= max( 1, (int) floor( $ideal_links * 0.5 ) ) ) {
            $g2['checks'][] = array( 'id' => 'int_links', 'status' => 'warn', 'text' => $internal_links . ' lien(s) interne(s) — insuffisant pour ' . number_format( $words, 0, ',', ' ' ) . ' mots (idéal : ' . $ideal_links . '+)', 'points' => 5, 'max' => 10, 'fix' => 'Ajoutez ' . ( $ideal_links - $internal_links ) . ' lien(s) interne(s) de plus. Règle : 1 lien pertinent tous les 500 mots environ.' );
        } elseif ( $internal_links >= 1 ) {
            $g2['checks'][] = array( 'id' => 'int_links', 'status' => 'warn', 'text' => '1 seul lien interne — essayez d\'en ajouter ' . ( $ideal_links - 1 ) . ' de plus', 'points' => 3, 'max' => 10, 'fix' => 'Ajoutez des liens vers d\'autres articles de votre site sur des sujets proches. Visez ' . $ideal_links . ' liens pour un article de cette longueur.' );
        } else {
            $g2['checks'][] = array( 'id' => 'int_links', 'status' => 'fail', 'text' => 'Aucun lien interne — isolé du reste du site', 'points' => 0, 'max' => 10, 'fix' => 'Cet article est isolé : Google le trouvera difficilement. Ajoutez au moins ' . $ideal_links . ' liens vers d\'autres pages de votre site.' );
        }

        // 10. External links
        if ( $external_links >= 1 ) {
            $g2['checks'][] = array( 'id' => 'ext_links', 'status' => 'ok', 'text' => $external_links . ' lien(s) externe(s) — crédibilise le contenu', 'points' => 10, 'max' => 10 );
        } else {
            $g2['checks'][] = array( 'id' => 'ext_links', 'status' => 'warn', 'text' => 'Aucun lien externe — citez vos sources', 'points' => 3, 'max' => 10, 'fix' => 'Citez au moins une source fiable (étude, site officiel, article de référence). Ça renforce votre crédibilité auprès de Google et des IA.' );
        }
        $groups['content'] = $g2;

        // ═══ GROUP 3: META & SERP (15%) ═══
        $g3 = array( 'label' => 'Meta & SERP', 'weight' => 15, 'checks' => array() );

        // 11. Title length
        $title_len = mb_strlen( $eff_title );
        if ( $title_len >= 30 && $title_len <= 60 ) {
            $g3['checks'][] = array( 'id' => 'title_len', 'status' => 'ok', 'text' => 'Title : ' . $title_len . ' caractères — longueur idéale', 'points' => 10, 'max' => 10 );
        } elseif ( $title_len > 60 && $title_len <= 70 ) {
            $g3['checks'][] = array( 'id' => 'title_len', 'status' => 'warn', 'text' => 'Title : ' . $title_len . ' car. — risque de troncature Google (max 60)', 'points' => 6, 'max' => 10, 'fix' => 'Raccourcissez votre title à 60 caractères max pour qu\'il s\'affiche entièrement dans Google.' );
        } elseif ( $title_len < 30 ) {
            $g3['checks'][] = array( 'id' => 'title_len', 'status' => 'warn', 'text' => 'Title : ' . $title_len . ' car. — trop court (min. 30)', 'points' => 4, 'max' => 10, 'fix' => 'Enrichissez votre title : ajoutez un qualificatif, l\'année, ou un bénéfice. Visez 30-60 caractères.' );
        } else {
            $g3['checks'][] = array( 'id' => 'title_len', 'status' => 'fail', 'text' => 'Title : ' . $title_len . ' car. — sera tronqué dans les SERP', 'points' => 2, 'max' => 10, 'fix' => 'Votre title sera coupé dans Google. Réécrivez-le en 60 caractères max en gardant le mot-clé au début.' );
        }

        // 12. Description length
        $desc_len = mb_strlen( $eff_desc );
        if ( $desc_len >= 120 && $desc_len <= 155 ) {
            $g3['checks'][] = array( 'id' => 'desc_len', 'status' => 'ok', 'text' => 'Description : ' . $desc_len . ' car. — longueur optimale', 'points' => 10, 'max' => 10 );
        } elseif ( $desc_len >= 80 && $desc_len < 120 ) {
            $g3['checks'][] = array( 'id' => 'desc_len', 'status' => 'warn', 'text' => 'Description : ' . $desc_len . ' car. — un peu courte (idéal : 120-155)', 'points' => 6, 'max' => 10, 'fix' => 'Allongez votre description à 120-155 caractères. Ajoutez un bénéfice ou un appel à l\'action pour inciter au clic.' );
        } elseif ( $desc_len > 155 && $desc_len <= 170 ) {
            $g3['checks'][] = array( 'id' => 'desc_len', 'status' => 'warn', 'text' => 'Description : ' . $desc_len . ' car. — risque de troncature', 'points' => 6, 'max' => 10, 'fix' => 'Raccourcissez votre description à 155 caractères max pour qu\'elle s\'affiche entièrement dans Google.' );
        } else {
            $status = $desc_len === 0 ? 'fail' : 'warn';
            $text = $desc_len === 0 ? 'Aucune meta description définie' : 'Description : ' . $desc_len . ' car. — hors plage recommandée';
            $fix = $desc_len === 0
                ? 'Rédigez une meta description de 120-155 caractères qui résume la page et donne envie de cliquer.'
                : 'Ajustez la longueur de votre description entre 120 et 155 caractères pour un affichage optimal dans Google.';
            $g3['checks'][] = array( 'id' => 'desc_len', 'status' => $status, 'text' => $text, 'points' => $desc_len === 0 ? 0 : 3, 'max' => 10, 'fix' => $fix );
        }

        // 13. Uniqueness
        global $wpdb;
        $dupe_title = 0;
        $dupe_pages_html = '';
        if ( $eff_title ) {
            $dupe_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_hts_meta_title' AND meta_value = %s AND post_id != %d",
                $eff_title, $post_id
            ) );
            $dupe_title = count( $dupe_ids );
            if ( $dupe_title > 0 ) {
                $dupe_links = array();
                foreach ( array_slice( $dupe_ids, 0, 5 ) as $did ) {
                    $dtitle = get_the_title( $did );
                    if ( ! $dtitle ) $dtitle = '#' . $did;
                    $dupe_links[] = '<a href="' . esc_url( get_edit_post_link( $did ) ) . '" target="_blank" style="color:var(--c-accent);text-decoration:underline;">' . esc_html( mb_strimwidth( $dtitle, 0, 40, '…' ) ) . '</a>';
                }
                $dupe_pages_html = ' → ' . implode( ', ', $dupe_links );
                if ( $dupe_title > 5 ) $dupe_pages_html .= ' (+' . ( $dupe_title - 5 ) . ' autres)';
            }
        }
        if ( $dupe_title === 0 ) {
            $g3['checks'][] = array( 'id' => 'unique', 'status' => 'ok', 'text' => 'Title unique — pas de duplicata détecté', 'points' => 10, 'max' => 10 );
        } else {
            $dupe_names = array();
            foreach ( array_slice( $dupe_ids, 0, 5 ) as $did ) {
                $dn = get_the_title( $did );
                $dupe_names[] = $dn ? mb_strimwidth( $dn, 0, 40, '…' ) : '#' . $did;
            }
            $dupe_text = 'Title dupliqué sur ' . $dupe_title . ' autre(s) page(s) : ' . implode( ', ', $dupe_names );
            $g3['checks'][] = array( 'id' => 'unique', 'status' => 'fail', 'text' => $dupe_text, 'points' => 0, 'max' => 10, 'fix' => 'Chaque page doit avoir un title unique. Modifiez-le pour le différencier des autres pages de votre site.', 'details_html' => $dupe_pages_html );
        }
        $groups['meta'] = $g3;

        // ═══ GROUP 4: LISIBILITÉ (5%) ═══
        $g4 = array( 'label' => 'Lisibilité', 'weight' => 5, 'checks' => array() );

        // 14. Paragraph length (use HTML content, not stripped text, to properly detect paragraph boundaries)
        preg_match_all( '/<p[^>]*>(.*?)<\/p>/si', $content, $p_matches );
        $para_texts = array();
        foreach ( $p_matches[1] as $p_html ) {
            $p_clean = trim( wp_strip_all_tags( $p_html ) );
            if ( hts_word_count( $p_clean ) > 5 ) {
                $para_texts[] = $p_clean;
            }
        }
        // Fallback: if no <p> tags found (plain text), split on double newlines
        if ( empty( $para_texts ) ) {
            $raw_paras = preg_split( '/\n\s*\n/', $text );
            foreach ( $raw_paras as $rp ) {
                $rp = trim( $rp );
                if ( hts_word_count( $rp ) > 5 ) {
                    $para_texts[] = $rp;
                }
            }
        }
        $long_paragraphs = 0;
        $long_para_details = array();
        foreach ( $para_texts as $i => $p ) {
            $wc = hts_word_count( $p );
            if ( $wc > 150 ) {
                $long_paragraphs++;
                $excerpt = mb_strimwidth( $p, 0, 80, '…' );
                $long_para_details[] = '¶' . ( $i + 1 ) . ' — ' . $wc . ' mots : « ' . $excerpt . ' »';
            }
        }

        if ( $long_paragraphs === 0 ) {
            $g4['checks'][] = array( 'id' => 'paragraphs', 'status' => 'ok', 'text' => 'Paragraphes de taille raisonnable', 'points' => 10, 'max' => 10 );
        } elseif ( $long_paragraphs <= 2 ) {
            $g4['checks'][] = array( 'id' => 'paragraphs', 'status' => 'warn', 'text' => $long_paragraphs . ' paragraphe(s) trop long(s) (>150 mots) — divisez-les', 'points' => 5, 'max' => 10, 'details' => $long_para_details, 'fix' => 'Découpez les longs paragraphes en blocs de 3-4 phrases. Les lecteurs et les IA préfèrent les textes aérés.' );
        } else {
            $g4['checks'][] = array( 'id' => 'paragraphs', 'status' => 'fail', 'text' => $long_paragraphs . ' paragraphes trop longs — découpez votre contenu', 'points' => 1, 'max' => 10, 'details' => $long_para_details, 'fix' => 'Trop de blocs de texte massifs. Découpez chaque paragraphe en 3-4 phrases max et ajoutez des sous-titres entre les sections.' );
        }

        // 15. Heading hierarchy
        $h1_count = count( array_filter( $headings, function( $h ) { return $h['level'] === 1; } ) );
        $has_h2 = ! empty( array_filter( $headings, function( $h ) { return $h['level'] === 2; } ) );
        $has_skip = false;
        $prev_level = 1;
        foreach ( $headings as $h ) {
            if ( $h['level'] > $prev_level + 1 ) { $has_skip = true; break; }
            $prev_level = $h['level'];
        }

        if ( $h1_count === 1 && $has_h2 && ! $has_skip ) {
            $g4['checks'][] = array( 'id' => 'hierarchy', 'status' => 'ok', 'text' => 'Structure Hn correcte — H1 unique, hiérarchie logique', 'points' => 10, 'max' => 10 );
        } elseif ( $h1_count > 1 ) {
            $g4['checks'][] = array( 'id' => 'hierarchy', 'status' => 'fail', 'text' => $h1_count . ' balises H1 — il ne doit y en avoir qu\'une', 'points' => 2, 'max' => 10, 'fix' => 'Il ne doit y avoir qu\'un seul H1 par page (le titre principal). Transformez les H1 en trop en H2.' );
        } elseif ( $has_skip ) {
            $g4['checks'][] = array( 'id' => 'hierarchy', 'status' => 'warn', 'text' => 'Saut de niveau dans les sous-titres', 'points' => 5, 'max' => 10, 'fix' => 'Vos sous-titres sautent un niveau (par exemple H2 puis H4 sans H3). Remettez-les dans l\'ordre.' );
        } elseif ( ! $has_h2 && $words > 300 ) {
            $g4['checks'][] = array( 'id' => 'hierarchy', 'status' => 'warn', 'text' => 'Aucun sous-titre — structurez votre contenu', 'points' => 4, 'max' => 10, 'fix' => 'Ajoutez des sous-titres pour organiser votre contenu. Un sous-titre tous les 200-300 mots.' );
        } else {
            $g4['checks'][] = array( 'id' => 'hierarchy', 'status' => 'ok', 'text' => 'Structure correcte', 'points' => 8, 'max' => 10 );
        }
        $groups['readability'] = $g4;

        // ═══ GROUP 5: CITABILITÉ GEO (20%) — v1.6.0 ═══
        // Mesure la capacité du contenu à être cité par les moteurs IA (ChatGPT, Perplexity, Gemini…)
        $g5 = array( 'label' => 'Citabilité GEO', 'weight' => 20, 'checks' => array() );

        // 16. Réponse directe en introduction (100 premiers mots)
        // Vérifie que l'intro contient au moins une phrase affirmative (pas uniquement des questions)
        // et qu'elle ne commence pas par du remplissage ("Dans cet article, nous allons...")
        $intro_sentences = preg_split( '/(?<=[.!?…])\s+/', trim( $first_words ), -1, PREG_SPLIT_NO_EMPTY );
        $has_direct_answer = false;
        $filler_patterns = '/^(dans cet article|dans ce guide|bienvenue|introduction|nous allons|on va voir|vous (allez|êtes)|in this article|welcome)/iu';
        foreach ( $intro_sentences as $sentence ) {
            $s = trim( $sentence );
            if ( mb_strlen( $s ) < 20 ) continue; // trop court pour être une vraie phrase
            // Exclure les questions et le remplissage
            $is_question = mb_substr( rtrim( $s ), -1 ) === '?' || preg_match( '/^(comment|pourquoi|quand|o[uù]|qui|quel|est-ce|what|how|why|when|where|who)\b/iu', $s );
            $is_filler   = preg_match( $filler_patterns, $s );
            if ( ! $is_question && ! $is_filler ) {
                $has_direct_answer = true;
                break;
            }
        }
        if ( $has_direct_answer ) {
            $g5['checks'][] = array( 'id' => 'geo_intro', 'status' => 'ok', 'text' => 'Réponse directe détectée en introduction', 'points' => 10, 'max' => 10 );
        } elseif ( $words < 50 ) {
            $g5['checks'][] = array( 'id' => 'geo_intro', 'status' => 'warn', 'text' => 'Contenu trop court pour évaluer l\'introduction', 'points' => 5, 'max' => 10, 'fix' => 'Étoffez votre contenu. Une bonne introduction commence par répondre directement à la question du lecteur.' );
        } else {
            $g5['checks'][] = array( 'id' => 'geo_intro', 'status' => 'fail', 'text' => 'Pas de réponse directe en introduction', 'points' => 0, 'max' => 10, 'fix' => 'Commencez par une phrase qui répond à la question du lecteur. Les IA citent souvent les premières lignes d\'un article.' );
        }

        // 17. Listes ou tableaux (structuration citable)
        $has_list  = preg_match( '/<(ul|ol)\b/i', $content );
        $has_table = preg_match( '/<table\b/i', $content );
        $list_count = preg_match_all( '/<(ul|ol)\b/i', $content );
        $table_count = preg_match_all( '/<table\b/i', $content );
        $struct_count = $list_count + $table_count;

        if ( $struct_count >= 2 ) {
            $g5['checks'][] = array( 'id' => 'geo_lists', 'status' => 'ok', 'text' => $struct_count . ' élément(s) structuré(s) (listes/tableaux) — excellent pour les IA', 'points' => 10, 'max' => 10 );
        } elseif ( $struct_count === 1 ) {
            $g5['checks'][] = array( 'id' => 'geo_lists', 'status' => 'ok', 'text' => '1 élément structuré détecté (liste ou tableau)', 'points' => 7, 'max' => 10 );
        } else {
            $g5['checks'][] = array( 'id' => 'geo_lists', 'status' => 'fail', 'text' => 'Aucune liste ni tableau détecté', 'points' => 0, 'max' => 10, 'fix' => 'Ajoutez une liste à puces ou un tableau comparatif. Les IA adorent citer des contenus structurés.' );
        }

        // 18. Données chiffrées (chiffres, statistiques, dates)
        // Cherche des patterns de données : nombres avec unités, pourcentages, dates, montants
        $num_patterns = preg_match_all( '/\b\d[\d\s,.]*(%|€|\$|£|ans?|mois|jours?|heures?|kg|km|m²|millions?|milliards?|k)\b/iu', $text, $num_m );
        $num_standalone = preg_match_all( '/\b\d{2,}\b/', $text, $num_s ); // nombres de 2+ chiffres
        $num_count = min( $num_patterns + intval( $num_standalone / 3 ), 20 ); // pondéré, cap à 20

        if ( $num_count >= 3 ) {
            $g5['checks'][] = array( 'id' => 'geo_data', 'status' => 'ok', 'text' => 'Données chiffrées présentes — renforce la crédibilité', 'points' => 10, 'max' => 10 );
        } elseif ( $num_count >= 1 ) {
            $g5['checks'][] = array( 'id' => 'geo_data', 'status' => 'warn', 'text' => 'Peu de données chiffrées — ajoutez des statistiques', 'points' => 5, 'max' => 10, 'fix' => 'Ajoutez des chiffres concrets : pourcentages, dates, montants. Ça renforce la crédibilité pour Google et les IA.' );
        } else {
            $g5['checks'][] = array( 'id' => 'geo_data', 'status' => 'fail', 'text' => 'Aucune donnée chiffrée détectée', 'points' => 0, 'max' => 10, 'fix' => 'Ajoutez des chiffres ou des dates. Exemples : « +35% en 2025 », « en 3 étapes », « à partir de 29€ ».' );
        }

        // 19. Sources externes (réutilise $external_links déjà calculé)
        if ( $external_links >= 2 ) {
            $g5['checks'][] = array( 'id' => 'geo_sources', 'status' => 'ok', 'text' => $external_links . ' source(s) externe(s) citée(s) — crédible pour les IA', 'points' => 10, 'max' => 10 );
        } elseif ( $external_links === 1 ) {
            $g5['checks'][] = array( 'id' => 'geo_sources', 'status' => 'warn', 'text' => '1 seule source externe — ajoutez-en une deuxième', 'points' => 5, 'max' => 10, 'fix' => 'Ajoutez un deuxième lien vers une source fiable (étude, site officiel). Deux sources minimum renforcent votre crédibilité.' );
        } else {
            $g5['checks'][] = array( 'id' => 'geo_sources', 'status' => 'fail', 'text' => 'Aucune source externe citée', 'points' => 0, 'max' => 10, 'fix' => 'Citez au moins une source fiable. Les IA et Google valorisent le contenu sourcé et vérifiable.' );
        }

        // 20. FAQ, définitions ou blocs Q&A
        $has_faq_schema = preg_match( '/FAQPage/i', $content );
        $has_faq_heading = preg_match( '/<h[2-4][^>]*>.*?(FAQ|foire aux questions|questions fréquentes|questions? \/ réponses?)/i', $content );
        $has_definition = preg_match( '/<(dfn|abbr|dl)\b/i', $content );
        // Détection pattern "Qu'est-ce que" / "Définition :" dans les headings
        $has_def_heading = preg_match( '/<h[2-4][^>]*>.*?(qu\x{0027}est-ce que|définition|c\x{0027}est quoi)/iu', $content );
        // Compter les patterns Q&A (heading avec "?" suivi d'un paragraphe)
        $qa_count = preg_match_all( '/<h[2-4][^>]*>[^<]*\?[^<]*<\/h[2-4]>/i', $content );

        $faq_score = 0;
        if ( $has_faq_schema || $has_faq_heading ) $faq_score += 5;
        if ( $has_definition || $has_def_heading ) $faq_score += 3;
        if ( $qa_count >= 3 ) $faq_score += 5;
        elseif ( $qa_count >= 1 ) $faq_score += 2;

        if ( $faq_score >= 5 ) {
            $g5['checks'][] = array( 'id' => 'geo_faq', 'status' => 'ok', 'text' => 'FAQ ou définitions détectées — format idéal pour les IA', 'points' => 10, 'max' => 10 );
        } elseif ( $faq_score >= 2 ) {
            $g5['checks'][] = array( 'id' => 'geo_faq', 'status' => 'warn', 'text' => 'Quelques éléments Q&A détectés — ajoutez une section FAQ', 'points' => 5, 'max' => 10, 'fix' => 'Ajoutez 2-3 questions fréquentes avec des réponses courtes. C\'est le format le plus cité par les IA.' );
        } else {
            $g5['checks'][] = array( 'id' => 'geo_faq', 'status' => 'fail', 'text' => 'Pas de FAQ ni définition détectée', 'points' => 0, 'max' => 10, 'fix' => 'Ajoutez une section « Questions fréquentes » avec 2-3 questions et réponses courtes. C\'est le format préféré des IA.' );
        }

        // 21. Freshness — contenu mis à jour récemment
        // Les IA et Google favorisent les contenus frais. > 12 mois sans mise à jour = périmé.
        $modified_ts = get_post_modified_time( 'U', false, $post );
        $months_since = ( time() - $modified_ts ) / ( 30 * DAY_IN_SECONDS );
        if ( $months_since <= 6 ) {
            $g5['checks'][] = array( 'id' => 'geo_freshness', 'status' => 'ok', 'text' => 'Contenu mis à jour récemment — signal de fraîcheur', 'points' => 10, 'max' => 10 );
        } elseif ( $months_since <= 12 ) {
            $g5['checks'][] = array( 'id' => 'geo_freshness', 'status' => 'warn', 'text' => 'Dernière mise à jour il y a plus de 6 mois', 'points' => 5, 'max' => 10, 'fix' => 'Actualisez cet article : vérifiez les chiffres, ajoutez des informations récentes. Google et les IA préfèrent les contenus frais.' );
        } else {
            $fresh_months = round( $months_since );
            $g5['checks'][] = array( 'id' => 'geo_freshness', 'status' => 'fail', 'text' => 'Contenu périmé — pas de mise à jour depuis ' . $fresh_months . ' mois', 'points' => 0, 'max' => 10, 'fix' => 'Cet article n\'a pas été modifié depuis plus d\'un an. Mettez-le à jour avec des données actuelles pour améliorer sa visibilité.' );
        }

        $groups['geo'] = $g5;

        // Réordonner les groupes pour l'affichage : SEO base > Contenu > GEO > Meta > Lisibilité
        $groups = array(
            'seo_base'    => $groups['seo_base'],
            'content'     => $groups['content'],
            'geo'         => $groups['geo'],
            'meta'        => $groups['meta'],
            'readability' => $groups['readability'],
        );

        // ═══ HIDDEN PENALTY: Over-optimization ═══
        // Best practice 2026: Google Helpful Content Update penalizes keyword stuffing above 2.5%
        $penalty = 0;
        if ( $kw && $words > 0 ) {
            $kw_count = mb_substr_count( $text_lower, $kw );
            $density  = ( $kw_count * hts_word_count( $kw ) ) / $words * 100;
            if ( $density > 2.5 ) {
                $penalty = min( 15, round( ( $density - 2.5 ) * 6 ) ); // up to -15
            }
        }

        // ═══ COMPUTE SCORE ═══
        $weighted_total = 0;
        $weighted_max   = 0;
        foreach ( $groups as $g ) {
            $group_pts = array_sum( array_column( $g['checks'], 'points' ) );
            $group_max = array_sum( array_column( $g['checks'], 'max' ) );
            $group_pct = $group_max > 0 ? $group_pts / $group_max : 0;
            $weighted_total += $group_pct * $g['weight'];
            $weighted_max   += $g['weight'];
        }

        $score = $weighted_max > 0 ? round( ( $weighted_total / $weighted_max ) * 100 ) : 0;
        $score = max( 0, $score - $penalty );

        // Debug metadata for diagnostic panel
        $debug = array(
            'words'           => $words,
            'content_bytes'   => strlen( $content ),
            'text_bytes'      => strlen( $text ),
            'headings'        => count( $headings ),
            'h1_count'        => count( array_filter( $headings, function( $h ) { return $h['level'] === 1; } ) ),
            'images'          => count( $images ),
            'internal_links'  => $internal_links,
            'external_links'  => $external_links,
            'kw'              => $kw,
            'has_overrides'   => ! empty( $overrides ),
            'content_source'  => ! empty( $overrides ) ? 'live_editor' : ( class_exists( 'HTS_Content_Extractor' ) ? 'content_extractor' : 'post_content' ),
            'content_preview' => mb_strimwidth( $text, 0, 200, '…' ),
        );

        return array( 'score' => $score, 'groups' => $groups, 'penalty' => $penalty, 'debug' => $debug );
    }

    /* ══════════════════════════════════════════════════════════════════
     *  RENDER
     * ══════════════════════════════════════════════════════════════════ */

    public function render( $post ) {
        // ── Cockpit guard: if core module is OFF, show disabled message ──
        if ( get_option( 'hts_module_meta_tags', '1' ) !== '1' ) {
            echo '<div style="padding:20px;text-align:center;color:#64748b;font-size:13px;">';
 echo '<p style="font-size:16px;margin-bottom:8px;"> Module Meta Tags désactivé</p>';
            echo '<p>Réactivez-le dans <a href="' . esc_url( admin_url( 'admin.php?page=hts-cockpit' ) ) . '">Cockpit SEO</a> pour utiliser le panneau SEO.</p>';
            echo '</div>';
            return;
        }

        // ── Builder detection: show helpful banner ──
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            HTS_Content_Extractor::get_content( $post->ID ); // triggers detection
            $builder = HTS_Content_Extractor::get_detected_builder();
            $builder_names = array(
                'elementor' => 'Elementor',
                'divi'      => 'Divi',
                'wpbakery'  => 'WPBakery',
                'beaver'    => 'Beaver Builder',
                'oxygen'    => 'Oxygen',
                'bricks'    => 'Bricks',
                'brizy'     => 'Brizy',
            );
            // Also match "elementor+woo" etc.
            $base_builder = explode( '+', $builder )[0];
            if ( isset( $builder_names[ $base_builder ] ) ) {
                $name = $builder_names[ $base_builder ];
                echo '<div style="padding:10px 14px;margin:0 0 1px;background:#eff6ff;border-bottom:1px solid #bfdbfe;font-size:12px;color:#1e40af;line-height:1.5;">';
                echo '<strong>' . esc_html( $name ) . ' d&eacute;tect&eacute;</strong> &mdash; ';
                echo 'L&#39;analyse SEO se base sur le contenu sauvegard&eacute;. ';
                echo '&Eacute;ditez dans ' . esc_html( $name ) . ', sauvegardez, puis revenez ici pour voir le score actualis&eacute;. ';
                echo 'Les meta (title, description, schema) sont modifiables ci-dessous.';
                echo '</div>';
            }
        }

        // ── Freshness alert: article not updated for > 12 months ──
        $modified_ts = get_post_modified_time( 'U', false, $post );
        if ( $modified_ts && $post->post_status === 'publish' ) {
            $months_since = ( time() - $modified_ts ) / ( 30 * DAY_IN_SECONDS );
            if ( $months_since > 12 ) {
                $m = round( $months_since );
                echo '<div style="padding:10px 14px;margin:0 0 1px;background:#fef2f2;border-bottom:1px solid #fecaca;font-size:12px;color:#991b1b;line-height:1.5;display:flex;align-items:center;gap:8px;">';
                if ( class_exists( 'HTS_Icons' ) ) { HTS_Icons::render( 'alert-triangle', 'hts-icon--sm hts-icon--danger' ); }
                echo '<span><strong>Contenu p&eacute;rim&eacute;</strong> &mdash; Derni&egrave;re mise &agrave; jour il y a ' . esc_html( $m ) . ' mois. ';
                echo 'Actualisez les informations pour am&eacute;liorer votre visibilit&eacute; sur Google et les IA.</span>';
                echo '</div>';
            }
        }

        wp_nonce_field( self::NONCE, '_hts_seo_panel_nonce' );
        $d = $this->get_post_data( $post );
        $analysis = $this->run_checks( $post->ID );
        $score = $analysis['score'];
        $is_front_page = ( (int) get_option( 'page_on_front' ) === $post->ID && get_option( 'show_on_front' ) === 'page' );
        ?>

        <style>
        /* ─── HTS Panel ─── */
        #hts-seo-panel { border-color: #dfe3e8; }
        #hts-seo-panel .postbox-header,
        #hts-seo-panel .postbox-header h2,
        #hts-seo-panel h2.hndle { background: #f8f9fb !important; color: #1a1f36 !important; border-bottom: 1px solid #ebeef2 !important; font-size: 13px !important; }
        #hts-seo-panel .inside { padding: 0 !important; margin: 0 !important; }

        .hp { --c-bg:#fff; --c-surface:#f8f9fb; --c-border:#ebeef2; --c-border2:#dfe3e8; --c-text:#1a1f36; --c-text2:#5e6687; --c-text3:#9da5b4; --c-ok:#16a34a; --c-ok-bg:#f0fdf4; --c-warn:#d97706; --c-warn-bg:#fffbeb; --c-fail:#dc2626; --c-fail-bg:#fef2f2; --c-blue:#2563eb; --c-blue-bg:#eff6ff; --c-accent:#6366f1; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: var(--c-text); line-height: 1.5; }
        .hp *, .hp *::before { box-sizing: border-box; }

        /* ─ Score strip ─ */
        .hp-strip { display:flex; align-items:center; gap:16px; padding:16px 20px; background:var(--c-surface); border-bottom:1px solid var(--c-border); }
        .hp-ring { position:relative; width:48px; height:48px; flex-shrink:0; }
        .hp-ring svg { width:48px; height:48px; transform:rotate(-90deg); }
        .hp-ring .track { fill:none; stroke:#e5e7eb; stroke-width:4; }
        .hp-ring .bar { fill:none; stroke-width:4; stroke-linecap:round; transition:stroke-dashoffset .6s ease; }
        .hp-ring .num { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:700; }
        .hp-strip-info { flex:1; min-width:0; }
        .hp-strip-info strong { font-size:14px; display:block; }
        .hp-strip-info small { color:var(--c-text3); font-size:12px; }
        .hp-kw { display:inline-block; background:var(--c-blue-bg); color:var(--c-blue); font-size:11px; font-weight:600; padding:3px 10px; border-radius:20px; white-space:nowrap; }
        .hp-btn { background:var(--c-bg); border:1px solid var(--c-border2); color:var(--c-text2); padding:6px 14px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer; transition:all .15s; }
        .hp-btn:hover { border-color:var(--c-accent); color:var(--c-accent); }

        /* ─ Tabs ─ */
        .hp-tabs { display:flex; border-bottom:1px solid var(--c-border); background:var(--c-bg); }
        .hp-tab { flex:1; padding:11px 8px; text-align:center; font-size:12.5px; font-weight:600; color:var(--c-text3); cursor:pointer; border-bottom:2px solid transparent; transition:color .15s, border-color .15s; position:relative; user-select:none; }
        .hp-tab:hover { color:var(--c-text2); }
        .hp-tab.on { color:var(--c-accent); border-bottom-color:var(--c-accent); }
        .hp-tab .ct { position:absolute; top:4px; right:calc(50% - 32px); min-width:16px; height:16px; background:var(--c-fail); color:#fff; font-size:9px; font-weight:700; border-radius:8px; display:flex; align-items:center; justify-content:center; padding:0 4px; }

        /* ─ Panels ─ */
        .hp-pane { display:none; padding:20px; }
        .hp-pane.on { display:block; }

        /* ─ Fields ─ */
        .hp-f { margin-bottom:16px; }
        .hp-f label { display:block; font-size:11.5px; font-weight:700; color:var(--c-text2); text-transform:uppercase; letter-spacing:.4px; margin-bottom:5px; }
        .hp-f input[type="text"], .hp-f textarea, .hp-f select { width:100%; padding:9px 12px; border:1px solid var(--c-border2); border-radius:6px; font-size:13.5px; color:var(--c-text); background:var(--c-bg); transition:border-color .15s, box-shadow .15s; font-family:inherit; }
        .hp-f input:focus, .hp-f textarea:focus, .hp-f select:focus { outline:none; border-color:var(--c-accent); box-shadow:0 0 0 3px rgba(99,102,241,.1); }
        .hp-f textarea { height:56px; resize:vertical; }
        .hp-f .sub { display:flex; justify-content:space-between; margin-top:3px; font-size:11px; color:var(--c-text3); }
        .hp-f .sub .over { color:var(--c-fail); font-weight:600; }
        .hp-f .sub code { background:var(--c-surface); padding:1px 4px; border-radius:3px; font-size:10px; }
        .hp-hint { font-size:11px; color:var(--c-text3); margin-top:3px; }

        /* ─ SERP ─ */
        .hp-serp { background:#fff; border:1px solid #dadce0; border-radius:8px; padding:14px 16px; margin-top:10px; transition:max-width .2s; }
        .hp-serp .su { font-size:12px; color:#202124; display:flex; align-items:center; gap:6px; }
        .hp-serp .su .ico { width:16px; height:16px; border-radius:50%; background:#f1f3f4; display:flex; align-items:center; justify-content:center; font-size:9px; }
        .hp-serp .st { font-size:18px; color:#1a0dab; margin:3px 0; line-height:1.25; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .hp-serp .st:hover { text-decoration:underline; cursor:pointer; }
        .hp-serp .sd { font-size:13px; color:#4d5156; line-height:1.45; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
        .hp-serp .sd b { font-weight:700; color:#1a1f36; }
        .hp-serp-bar { display:flex; gap:4px; margin-top:8px; }
        .hp-serp-bar button { padding:3px 10px; font-size:10.5px; border:1px solid var(--c-border2); background:var(--c-bg); color:var(--c-text3); border-radius:4px; cursor:pointer; font-weight:600; }
        .hp-serp-bar button.on { border-color:var(--c-accent); color:var(--c-accent); background:rgba(99,102,241,.04); }

        /* ─ Analysis groups ─ */
        .hp-grp { margin-bottom:12px; border:1px solid var(--c-border); border-radius:8px; overflow:hidden; }
        .hp-grp-head { display:flex; align-items:center; justify-content:space-between; padding:10px 14px; background:var(--c-surface); cursor:pointer; user-select:none; }
        .hp-grp-head span:first-child { font-size:13px; font-weight:600; }
        .hp-grp-badge { font-size:10.5px; font-weight:700; padding:2px 9px; border-radius:10px; }
        .hp-grp-badge.ok { background:var(--c-ok-bg); color:var(--c-ok); }
        .hp-grp-badge.warn { background:var(--c-warn-bg); color:var(--c-warn); }
        .hp-grp-badge.fail { background:var(--c-fail-bg); color:var(--c-fail); }
        .hp-grp-body { border-top:1px solid var(--c-border); }
        .hp-chk { display:flex; align-items:flex-start; flex-wrap:wrap; gap:10px; padding:9px 14px; font-size:13px; color:var(--c-text2); border-bottom:1px solid var(--c-border); }
        .hp-chk:last-child { border-bottom:none; }
        .hp-dot { flex-shrink:0; width:7px; height:7px; border-radius:50%; margin-top:6px; }
        .hp-dot.ok { background:var(--c-ok); }
        .hp-dot.warn { background:var(--c-warn); }
        .hp-dot.fail { background:var(--c-fail); }
        .hp-chk-details { flex-wrap:wrap; }
        .hp-detail-toggle { cursor:pointer; color:var(--c-primary); font-size:11px; text-decoration:none; margin-left:4px; transition:transform .15s; display:inline-block; }
        .hp-chk-details.open .hp-detail-toggle { transform:rotate(90deg); }
        .hp-detail-list { display:none; width:100%; margin:6px 0 0 17px; }
        .hp-chk-details.open .hp-detail-list { display:block; }
        .hp-chk-advice { display:none; width:100%; margin:4px 0 2px 17px; padding:6px 10px; font-size:12px; color:var(--c-text3); line-height:1.4; background:var(--c-surface); border-radius:4px; border-left:2px solid var(--c-primary); }
        .hp-chk-fix.show-fix .hp-chk-advice { display:block; }
        .hp-fix-toggle { cursor:pointer; color:var(--c-primary); font-size:12px; text-decoration:none; margin-left:4px; opacity:.7; transition:opacity .15s; }
        .hp-fix-toggle:hover { opacity:1; }
        .hp-dbg-card { background:var(--c-surface); border-radius:6px; padding:8px 10px; text-align:center; }
        .hp-dbg-card small { display:block; font-size:10px; color:var(--c-text3); text-transform:uppercase; letter-spacing:.3px; margin-bottom:2px; }
        .hp-dbg-card strong { display:block; font-size:15px; color:var(--c-text); }
        .hp-detail-item { font-size:11.5px; color:var(--c-text3); padding:3px 0; border-left:2px solid var(--c-warn); padding-left:10px; margin-bottom:3px; line-height:1.4; }

        /* ─ Penalty ─ */
        .hp-penalty { margin-top:12px; padding:10px 14px; background:var(--c-fail-bg); border:1px solid rgba(220,38,38,.15); border-radius:8px; font-size:12px; color:var(--c-fail); }

        /* ─ Toggle ─ */
        .hp-tgl { display:flex; align-items:center; gap:10px; padding:10px 12px; border:1px solid var(--c-border2); border-radius:6px; margin-bottom:8px; cursor:pointer; transition:border-color .15s; }
        .hp-tgl:hover { border-color:var(--c-accent); }
        .hp-tgl input { accent-color:var(--c-accent); width:15px; height:15px; }
        .hp-tgl .t { font-size:13px; font-weight:600; color:var(--c-text); }
        .hp-tgl .d { font-size:11px; color:var(--c-text3); margin-top:1px; }

        /* ─ Image picker ─ */
        .hp-img { display:flex; align-items:center; gap:12px; padding:12px; border:1px dashed var(--c-border2); border-radius:6px; cursor:pointer; transition:border-color .15s; }
        .hp-img:hover { border-color:var(--c-accent); }
        .hp-img img { width:52px; height:52px; object-fit:cover; border-radius:4px; }
        .hp-img .ph { width:52px; height:52px; background:var(--c-surface); border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--c-text3); font-size:18px; }

        /* ─ Top fixes ─ */
        .hp-fixes { padding:8px 20px 10px; background:var(--c-bg); border-bottom:1px solid var(--c-border); }
        .hp-fix { display:flex; align-items:center; gap:8px; font-size:12px; color:var(--c-text2); padding:3px 0; }
        .hp-fix-dot { width:6px; height:6px; border-radius:50%; flex-shrink:0; }
        .hp-fix.fail .hp-fix-dot { background:var(--c-fail); }
        .hp-fix.warn .hp-fix-dot { background:var(--c-warn); }
        </style>

        <div class="hp" id="hp" data-pid="<?php echo (int) $post->ID; ?>">

            <!-- Score strip -->
            <div class="hp-strip">
                <div class="hp-ring" id="hp-ring">
                    <svg viewBox="0 0 48 48">
                        <circle class="track" cx="24" cy="24" r="19"/>
                        <circle class="bar" id="hp-bar" cx="24" cy="24" r="19"
                                stroke-dasharray="119.4" stroke-dashoffset="<?php echo esc_attr( round( 119.4 - ( 119.4 * $score / 100 ), 1 ) ); ?>"
                                stroke="<?php echo esc_attr( $this->color( $score ) ); ?>"/>
                    </svg>
                    <div class="num" id="hp-num" style="color:<?php echo esc_attr( $this->color( $score ) ); ?>"><?php echo (int) $score; ?></div>
                </div>
                <div class="hp-strip-info">
                    <strong id="hp-label" style="color:<?php echo esc_attr( $this->color( $score ) ); ?>"><?php echo esc_html( $this->label( $score ) ); ?></strong>
                    <small>21 critères · <?php echo $analysis['penalty'] > 0 ? 'pénalité sur-optimisation -' . (int) $analysis['penalty'] : 'aucune pénalité'; ?></small>
                </div>
                <?php if ( $d['focus_kw'] ) : ?><span class="hp-kw"><?php echo esc_html( $d['focus_kw'] ); ?></span><?php endif; ?>
                <span id="hp-ia-badge" style="display:none;background:#eff6ff;color:#2563eb;font-size:9px;font-weight:700;padding:2px 8px;border-radius:8px;white-space:nowrap;"></span>
            </div>

            <!-- Top fixes -->
            <?php $fixes = $this->top_fixes( $analysis, 3 ); if ( ! empty( $fixes ) ) : ?>
            <div class="hp-fixes" id="hp-fixes">
                <?php foreach ( $fixes as $f ) : ?>
                <?php $allowed_check_tags = array('a' => array('href' => true, 'target' => true, 'style' => true)); ?>
                <div class="hp-fix <?php echo esc_attr( $f['status'] ); ?>"><span class="hp-fix-dot"></span><?php echo wp_kses( $f['text'], $allowed_check_tags ); ?></div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- IA badge auto-load -->
            <script>
            (function(){
                var fd = new FormData();
                fd.append('action','hts_impact_data');
                fd.append('nonce','<?php echo wp_create_nonce("hts_panel_score"); ?>');
                fd.append('post_id',<?php echo (int)$post->ID; ?>);
                fetch('<?php echo esc_url( admin_url("admin-ajax.php") ); ?>',{method:'POST',body:fd})
                    .then(function(r){return r.json()})
                    .then(function(r){
                        if(!r.success)return;
                        var b=document.getElementById('hp-ia-badge');
                        if(!b)return;
                        var ai=r.data.ai_visits_30d||0;
                        var total=r.data.total_visits_30d||0;
                        if(total>0){
                            b.textContent=ai>0?ai+' visite'+(ai>1?'s':'')+' IA':total+' visite'+(total>1?'s':'');
                            b.style.display='inline-block';
                            if(ai>0){b.style.background='#eff6ff';b.style.color='#2563eb';}
                            else{b.style.background='var(--c-surface,#f3f4f6)';b.style.color='var(--c-text3,#9da5b4)';}
                        }
                    }).catch(function(){});
            })();
            </script>

            <!-- Tabs -->
            <div class="hp-tabs">
                <div class="hp-tab on" data-t="seo">SEO</div>
                <div class="hp-tab" data-t="analyse">Analyse<?php
                    $ic = $this->issue_count( $analysis );
                    if ( $ic > 0 ) echo '<span class="ct">' . (int) $ic . '</span>';
                ?></div>
                <div class="hp-tab" data-t="social">Social</div>
                <div class="hp-tab" data-t="advanced">Avancé</div>
                <div class="hp-tab" data-t="impact">Impact</div>
                <div class="hp-tab" data-t="gsc">GSC</div>
                <?php if ( current_user_can( 'manage_options' ) ) : ?>
                <div class="hp-tab" data-t="debug" style="color:var(--c-text3);">🔧</div>
                <?php endif; ?>
            </div>

            <!-- ── SEO ── -->
            <div class="hp-pane on" data-p="seo">
                <div class="hp-f">
                    <label>Mot-clé principal<?php
                    $kw_source = get_post_meta( $post->ID, '_hts_focus_keyword_source', true );
                    if ( $kw_source === 'gsc_auto' ) {
                        echo '<span style="font-size:10px;color:var(--c-accent,#6366f1);margin-left:8px;font-weight:400;">Suggéré depuis Google Search Console</span>';
                    }
                    ?></label>
                    <input type="text" name="hts_focus_keyword" id="hp-kw" value="<?php echo esc_attr( $d['focus_kw'] ); ?>" placeholder="Ex: seo wordpress plugin" oninput="hpUpd()">
                </div>
                <div class="hp-f">
                    <label>Meta Title</label>
                    <input type="text" name="hts_meta_title" id="hp-tt" value="<?php echo esc_attr( $d['meta_title'] ); ?>" placeholder="<?php echo esc_attr( $d['preview_title'] ); ?>" oninput="hpUpd()">
                    <div class="sub"><span id="hp-ttc"><?php echo mb_strlen( $d['preview_title'] ); ?>/60</span><span><code>%title%</code> <code>%sep%</code> <code>%sitename%</code></span></div>
                </div>
                <div class="hp-f">
                    <label>Meta Description</label>
                    <textarea name="hts_meta_description" id="hp-ds" placeholder="<?php echo esc_attr( $d['preview_desc'] ); ?>" oninput="hpUpd()"><?php echo esc_textarea( $d['meta_desc'] ); ?></textarea>
                    <div class="sub"><span id="hp-dsc"><?php echo mb_strlen( $d['preview_desc'] ); ?>/155</span></div>
                </div>
                <div class="hp-f">
                    <label>Langue du contenu</label>
                    <?php
                    $post_lang = get_post_meta( $post->ID, '_hts_content_lang', true );
                    if ( ! $post_lang && class_exists( 'HTS_Language' ) ) {
                        $post_lang = HTS_Language::get_post_language( $post->ID );
                    }
                    if ( ! $post_lang ) {
                        $post_lang = substr( get_locale(), 0, 2 );
                    }
                    $lang_options = array(
                        'fr' => 'Français', 'en' => 'English', 'es' => 'Español', 'de' => 'Deutsch',
                        'it' => 'Italiano', 'pt' => 'Português', 'nl' => 'Nederlands', 'ja' => '日本語',
                        'zh' => '中文', 'ar' => 'العربية', 'ru' => 'Русский', 'ko' => '한국어',
                        'pl' => 'Polski', 'sv' => 'Svenska', 'tr' => 'Türkçe',
                    );
                    ?>
                    <select name="hts_content_lang" id="hp-lang" style="width:100%;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">
                        <?php foreach ( $lang_options as $code => $label ) : ?>
                            <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $post_lang, $code ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="sub">Langue utilisée pour la génération IA des meta tags</div>
                </div>
                <div class="hp-f">
                    <label>Adresse (URL)</label>
                    <?php if ( $is_front_page ) : ?>
                        <div style="display:flex;align-items:center;gap:6px;">
                            <span style="font-size:12px;color:var(--c-text3);white-space:nowrap;"><?php echo esc_html( trailingslashit( home_url() ) ); ?></span>
                            <input type="hidden" name="hts_slug" id="hp-slug" value="<?php echo esc_attr( $post->post_name ); ?>">
                        </div>
                        <div class="hp-hint">Page d'accueil — l'URL est fixée par WordPress.</div>
                    <?php else : ?>
                        <div style="display:flex;align-items:center;gap:6px;">
                            <span style="font-size:12px;color:var(--c-text3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;"><?php echo esc_html( trailingslashit( home_url() ) ); ?></span>
                            <input type="text" name="hts_slug" id="hp-slug" value="<?php echo esc_attr( $post->post_name ); ?>" placeholder="<?php echo esc_attr( sanitize_title( $post->post_title ) ); ?>" oninput="hpUpd()" style="flex:1;">
                        </div>
                        <div class="hp-hint">Court et descriptif. Incluez votre mot-clé principal.</div>
                    <?php endif; ?>
                </div>
                <label class="hp-tgl">
                    <input type="checkbox" name="hts_pillar" value="1" <?php checked( $d['pillar'], '1' ); ?>>
                    <div><div class="t">Contenu pilier</div><div class="d">Page essentielle du cocon sémantique</div></div>
                </label>
                <div class="hp-serp" id="hp-serp">
                    <div class="su"><span class="ico">G</span><span id="hp-su"><?php echo esc_html( str_replace( array( 'https://', 'http://', 'www.' ), '', trailingslashit( home_url() ) ) ); ?><?php if ( ! $is_front_page ) : ?><span id="hp-su-slug"><?php echo esc_html( $post->post_name ); ?></span><?php endif; ?></span></div>
                    <div class="st" id="hp-st"><?php echo esc_html( $d['preview_title'] ); ?></div>
                    <div class="sd" id="hp-sd"><?php echo esc_html( $d['preview_desc'] ); ?></div>
                </div>
                <div class="hp-serp-bar">
                    <button type="button" class="on" onclick="hpSerpMode('100%',this)">Desktop</button>
                    <button type="button" onclick="hpSerpMode('360px',this)">Mobile</button>
                </div>
            </div>

            <!-- ── Analyse ── -->
            <div class="hp-pane" data-p="analyse">
                <div id="hp-analysis"><?php $this->render_analysis( $analysis ); ?></div>

                <?php if ( class_exists( 'HTS_Meta_Score' ) ) : ?>
                <!-- ── Score Meta IA ── -->
                <div class="hp-grp" id="hp-meta-score-section" style="margin-top:16px;">
                    <div class="hp-grp-head" onclick="this.nextElementSibling.classList.toggle('hp-grp-hide')">
                        <span>Score Meta IA</span>
                        <span class="hp-grp-badge" id="hp-ms-badge" style="background:var(--c-surface);color:var(--c-text3);">—</span>
                    </div>
                    <div class="hp-grp-body" id="hp-ms-body" style="padding:14px;">
                        <div id="hp-ms-criteria" style="margin-bottom:12px;font-size:12px;color:var(--c-text2);">
                            <div style="text-align:center;padding:10px;color:var(--c-text3);">Chargement...</div>
                        </div>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <?php
                            $has_api = ! empty( hts_get_openai_key() ) || ! empty( hts_get_anthropic_key() ) || ! empty( hts_get_api_key() );
                            if ( $has_api ) : ?>
                            <button type="button" class="hp-btn" id="hp-ms-gen-btn" onclick="hpMsGenerate()" style="background:var(--c-accent);color:#fff;border-color:var(--c-accent);">
                                ✨ Générer les metas IA
                            </button>
                            <?php else : ?>
                            <div style="font-size:11px;color:var(--c-warn);padding:6px 0;">
                                Clé API OpenAI requise pour la génération IA.
                                <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-settings' ) ); ?>" style="color:var(--c-accent);">Configurer</a>
                            </div>
                            <?php endif; ?>
                            <button type="button" class="hp-btn" id="hp-ms-rollback-btn" onclick="hpMsRollback()" style="display:none;">
                                ↩️ Restaurer
                            </button>
                        </div>
                        <!-- AI variants container (filled by JS) -->
                        <div id="hp-ms-variants" style="display:none;margin-top:14px;"></div>
                    </div>
                </div>
                <style>
                    .hp-grp-hide { display:none !important; }
                    .hp-ms-crit { display:flex; align-items:center; gap:8px; padding:4px 0; border-bottom:1px solid var(--c-border); }
                    .hp-ms-crit:last-child { border-bottom:none; }
                    .hp-ms-crit-bar { width:60px; height:6px; background:var(--c-surface); border-radius:3px; overflow:hidden; flex-shrink:0; }
                    .hp-ms-crit-bar > div { height:100%; border-radius:3px; transition:width .3s; }
                    .hp-ms-var { border:1px solid var(--c-border); border-radius:8px; padding:12px; margin-bottom:10px; }
                    .hp-ms-var:hover { border-color:var(--c-accent); }
                    .hp-ms-var-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:6px; }
                    .hp-ms-var-score { font-size:12px; font-weight:700; padding:2px 8px; border-radius:10px; }
                </style>
                <script>
                (function(){
                    var postId = <?php echo (int) $post->ID; ?>;
                    var nonce = '<?php echo wp_create_nonce( 'hts_admin_nonce' ); ?>';

                    function hpMsPost(action, data) {
                        data.action = action;
                        data.nonce = nonce;
                        return fetch(ajaxurl, {
                            method: 'POST',
                            headers: {'Content-Type':'application/x-www-form-urlencoded'},
                            body: new URLSearchParams(data)
                        }).then(function(r){ return r.json(); });
                    }

                    // Load score on init
                    hpMsPost('hts_meta_score_get', {post_id:postId}).then(function(res){
                        if (!res.success) return;
                        hpMsRenderScore(res.data);
                    });

                    function hpMsRenderScore(d) {
                        var badge = document.getElementById('hp-ms-badge');
                        var color = d.score>=80?'var(--c-ok)':d.score>=60?'var(--c-blue)':d.score>=40?'var(--c-warn)':'var(--c-fail)';
                        var bgColor = d.score>=80?'var(--c-ok-bg)':d.score>=60?'var(--c-blue-bg)':d.score>=40?'var(--c-warn-bg)':'var(--c-fail-bg)';
                        badge.textContent = d.score + '/100 (' + d.grade + ')';
                        badge.style.background = bgColor;
                        badge.style.color = color;

                        var html = '';
                        if (d.criteria && d.criteria.length) {
                            d.criteria.forEach(function(c){
                                var pct = c.max > 0 ? Math.round(c.score/c.max*100) : 0;
                                var barColor = pct>=70?'var(--c-ok)':pct>=40?'var(--c-warn)':'var(--c-fail)';
                                html += '<div class="hp-ms-crit">'
                                    + '<div style="flex:1;min-width:0;">'
                                    + '<div style="font-weight:600;font-size:11.5px;">' + c.label + ' <span style="color:var(--c-text3);font-weight:400;">(' + c.score + '/' + c.max + ')</span></div>'
                                    + '<div style="font-size:11px;color:var(--c-text3);margin-top:1px;">' + c.detail + '</div>'
                                    + '</div>'
                                    + '<div class="hp-ms-crit-bar"><div style="width:'+pct+'%;background:'+barColor+';"></div></div>'
                                    + '</div>';
                            });
                        }
                        document.getElementById('hp-ms-criteria').innerHTML = html || '<div style="color:var(--c-text3);">Aucun critère</div>';

                        // Show rollback button if snapshot exists
                        var rb = document.getElementById('hp-ms-rollback-btn');
                        if (rb) rb.style.display = 'none'; // Will be shown after apply
                    }

                    window.hpMsGenerate = function() {
                        var btn = document.getElementById('hp-ms-gen-btn');
                        btn.disabled = true;
                        btn.textContent = '\u23F3 Génération en cours...';

                        hpMsPost('hts_meta_score_generate', {post_id:postId}).then(function(res){
                            btn.disabled = false;
                            btn.innerHTML = '\u2728 Générer les metas IA';

                            if (!res.success) {
                                alert(res.data && res.data.error ? res.data.error : 'Erreur');
                                return;
                            }

                            var d = res.data;
                            var container = document.getElementById('hp-ms-variants');
                            container.style.display = 'block';

                            var html = '<div style="font-size:11px;color:var(--c-text3);margin-bottom:10px;">Actuel : <strong>' + d.current.score + '/100</strong> — Choisissez une variante :</div>';

                            d.variants.forEach(function(v, i){
                                var scoreColor = v.score>=80?'var(--c-ok)':v.score>=60?'var(--c-blue)':v.score>=40?'var(--c-warn)':'var(--c-fail)';
                                var scoreBg = v.score>=80?'var(--c-ok-bg)':v.score>=60?'var(--c-blue-bg)':v.score>=40?'var(--c-warn-bg)':'var(--c-fail-bg)';
                                var delta = v.score - d.current.score;
                                var deltaHtml = delta > 0 ? '<span style="color:var(--c-ok);font-size:10px;margin-left:4px;">\u2191+'+delta+'</span>' : delta < 0 ? '<span style="color:var(--c-fail);font-size:10px;margin-left:4px;">\u2193'+delta+'</span>' : '';

                                html += '<div class="hp-ms-var">'
                                    + '<div class="hp-ms-var-head">'
                                    + '<span style="font-size:11px;color:var(--c-text3);">' + (v.strategy||'Variante '+(i+1)) + '</span>'
                                    + '<span class="hp-ms-var-score" style="background:'+scoreBg+';color:'+scoreColor+';">' + v.score + deltaHtml + '</span>'
                                    + '</div>'
                                    + '<div style="font-size:13px;font-weight:600;margin-bottom:4px;">' + hpMsEsc(v.title) + '</div>'
                                    + '<div style="font-size:12px;color:var(--c-text2);margin-bottom:8px;">' + hpMsEsc(v.description) + '</div>'
                                    + '<button type="button" class="hp-btn" onclick="hpMsApply('+JSON.stringify(v.title).replace(/'/g,"\\'")+','+JSON.stringify(v.description).replace(/'/g,"\\'")+',this)" style="font-size:11px;">Appliquer cette variante</button>'
                                    + '</div>';
                            });

                            container.innerHTML = html;
                        });
                    };

                    window.hpMsApply = function(title, desc, btn) {
                        if (!confirm('Appliquer cette meta ?\n\nTitle : ' + title + '\nDescription : ' + desc)) return;
                        btn.disabled = true;
                        btn.textContent = 'Application...';

                        hpMsPost('hts_meta_score_apply', {post_id:postId, title:title, description:desc}).then(function(res){
                            if (!res.success) {
                                btn.disabled = false;
                                btn.textContent = 'Appliquer cette variante';
                                alert(res.data && res.data.error ? res.data.error : 'Erreur');
                                return;
                            }

                            // Update display
                            hpMsRenderScore(res.data.score);
                            btn.textContent = '\u2705 Appliqué !';
                            btn.style.background = 'var(--c-ok-bg)';
                            btn.style.color = 'var(--c-ok)';
                            btn.style.borderColor = 'var(--c-ok)';

                            // Show rollback
                            var rb = document.getElementById('hp-ms-rollback-btn');
                            if (rb) rb.style.display = 'inline-block';

                            // Update the SEO tab fields
                            var ttField = document.getElementById('hp-tt');
                            var dsField = document.getElementById('hp-ds');
                            if (ttField) ttField.value = title;
                            if (dsField) dsField.value = desc;
                            if (typeof hpUpd === 'function') hpUpd();
                        });
                    };

                    window.hpMsRollback = function() {
                        if (!confirm('Restaurer les metas précédentes ?')) return;
                        var btn = document.getElementById('hp-ms-rollback-btn');
                        btn.disabled = true;
                        btn.textContent = 'Restauration...';

                        hpMsPost('hts_meta_score_rollback', {post_id:postId}).then(function(res){
                            btn.disabled = false;
                            btn.textContent = '\u21A9\uFE0F Restaurer';
                            if (!res.success) {
                                alert(res.data && res.data.error ? res.data.error : 'Erreur');
                                return;
                            }
                            hpMsRenderScore(res.data.score);
                            btn.style.display = 'none';
                            document.getElementById('hp-ms-variants').style.display = 'none';

                            // Update the SEO tab fields
                            var ttField = document.getElementById('hp-tt');
                            var dsField = document.getElementById('hp-ds');
                            if (ttField && res.data.score.title) ttField.value = res.data.score.title;
                            if (dsField && res.data.score.description) dsField.value = res.data.score.description;
                            if (typeof hpUpd === 'function') hpUpd();
                        });
                    };

                    function hpMsEsc(s) {
                        var d = document.createElement('div');
                        d.textContent = s || '';
                        return d.innerHTML;
                    }
                })();
                </script>
                <?php endif; ?>

                <?php if ( class_exists( 'HTS_On_Page_Score' ) ) : ?>
                <!-- ── Score Contenu (Phase 2) ── -->
                <div class="hp-grp" id="hp-onpage-section" style="margin-top:16px;">
                    <div class="hp-grp-head" onclick="this.nextElementSibling.classList.toggle('hp-grp-hide')">
                        <span>Score Contenu</span>
                        <span class="hp-grp-badge" id="hp-op-badge" style="background:var(--c-surface);color:var(--c-text3);">—</span>
                    </div>
                    <div class="hp-grp-body" id="hp-op-body" style="padding:14px;">
                        <div id="hp-op-criteria" style="margin-bottom:12px;font-size:12px;color:var(--c-text2);"><div style="text-align:center;padding:10px;color:var(--c-text3);">Chargement...</div></div>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button type="button" class="hp-btn" id="hp-op-gen-btn" onclick="hpOpGenerate()" style="background:var(--c-accent);color:#fff;border-color:var(--c-accent);">Analyser le contenu</button>
                        </div>
                        <div id="hp-op-suggestions" style="display:none;margin-top:14px;"></div>
                    </div>
                </div>
                <script>
                (function(){
                    var opId = <?php echo (int) $post->ID; ?>;
                    var opN = '<?php echo wp_create_nonce( 'hts_admin_nonce' ); ?>';
                    function opP(a,d){d.action=a;d.nonce=opN;return fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(d)}).then(function(r){return r.json();});}
                    opP('hts_onpage_score_get',{post_id:opId}).then(function(r){if(r.success)opS(r.data);});
                    function opS(d){var b=document.getElementById('hp-op-badge');var cl=d.score>=80?'var(--c-ok)':d.score>=60?'var(--c-blue)':d.score>=40?'var(--c-warn)':'var(--c-fail)';b.textContent=d.score+'/100 ('+d.grade+')';b.style.background=(d.score>=80?'var(--c-ok-bg)':d.score>=60?'var(--c-blue-bg)':d.score>=40?'var(--c-warn-bg)':'var(--c-fail-bg)');b.style.color=cl;var h='';(d.criteria||[]).forEach(function(c){var p=c.max>0?Math.round(c.score/c.max*100):0;var bc=p>=70?'var(--c-ok)':p>=40?'var(--c-warn)':'var(--c-fail)';h+='<div class="hp-ms-crit"><div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:11.5px;">'+c.label+' <span style="color:var(--c-text3);font-weight:400;">('+c.score+'/'+c.max+')</span></div><div style="font-size:11px;color:var(--c-text3);margin-top:1px;">'+c.detail+'</div></div><div class="hp-ms-crit-bar"><div style="width:'+p+'%;background:'+bc+';"></div></div></div>';});document.getElementById('hp-op-criteria').innerHTML=h||'Aucun';}
                    window.hpOpGenerate=function(){var btn=document.getElementById('hp-op-gen-btn');btn.disabled=true;btn.textContent='\u23F3 Analyse...';opP('hts_onpage_generate',{post_id:opId}).then(function(r){btn.disabled=false;btn.textContent='\uD83D\uDD0D Analyser le contenu';if(!r.success)return;opSugs(r.data.suggestions||[]);if(r.data.current)opS(r.data.current);}).catch(function(){btn.disabled=false;btn.textContent='\uD83D\uDD0D Analyser le contenu';});};
                    function opSugs(s){var c=document.getElementById('hp-op-suggestions');if(!s.length){c.style.display='none';return;}c.style.display='block';var h='<div style="font-size:12px;font-weight:700;margin-bottom:8px;">Suggestions ('+s.length+')</div>';s.forEach(function(sg,i){var ia=sg.auto&&(sg.type==='img_alt'||sg.type==='internal_link'||sg.type==='heading_insert');h+='<div style="border:1px solid var(--c-border);border-radius:6px;padding:10px;margin-bottom:8px;font-size:12px;"><div style="margin-bottom:4px;">'+(sg.suggestion||'')+'</div>';if(sg.reason)h+='<div style="font-size:11px;color:var(--c-text3);margin-bottom:6px;">'+sg.reason+'</div>';if(ia)h+='<button type="button" class="hp-btn" style="font-size:11px;padding:3px 10px;" onclick="hpOpApply('+i+',this)">\u2705 Appliquer</button>';h+='</div>';});c.innerHTML=h;c._s=s;}
                    window.hpOpApply=function(i,btn){var s=document.getElementById('hp-op-suggestions')._s[i];if(!s)return;btn.disabled=true;btn.textContent='\u23F3...';var d={post_id:opId,type:s.type,suggestion:s.suggestion||'',current:s.current||''};if(s.src)d.src=s.src;if(s.img_tag)d.img_tag=s.img_tag;if(s.is_featured)d.is_featured=1;if(s.attachment_id)d.attachment_id=s.attachment_id;if(s.anchor_text)d.anchor_text=s.anchor_text;if(s.target_url)d.target_url=s.target_url;if(s.target_title)d.target_title=s.target_title;if(s.heading_level)d.heading_level=s.heading_level;if(s.insert_before)d.insert_before=s.insert_before;opP('hts_onpage_apply',d).then(function(r){if(r.success){btn.textContent='\u2713 OK';btn.style.background='var(--c-ok-bg)';btn.style.color='var(--c-ok)';if(r.data&&r.data.score)opS(r.data.score);}else{btn.disabled=false;btn.textContent='\u2705 Appliquer';alert((r.data&&r.data.message)||'Erreur');}}).catch(function(){btn.disabled=false;btn.textContent='\u2705 Appliquer';});};
                })();
                </script>
                <?php endif; ?>

                <!-- ── Maillage Interne (Phase 2b) ── -->
                <?php if ( class_exists( 'HTS_Internal_Linking' ) && class_exists( 'HTS_Cocon' ) ) : ?>
                <div class="hp-grp" id="hp-linking-section" style="margin-top:16px;">
                    <div class="hp-grp-head" onclick="this.nextElementSibling.classList.toggle('hp-grp-hide')">
                        <span>🔗 Maillage Interne</span>
                        <span class="hp-grp-badge" id="hp-lnk-badge" style="background:var(--c-surface);color:var(--c-text3);">—</span>
                    </div>
                    <div class="hp-grp-body" id="hp-lnk-body" style="padding:14px;">
                        <div id="hp-lnk-info" style="font-size:12px;color:var(--c-text2);margin-bottom:12px;">
                            <div style="text-align:center;padding:10px;color:var(--c-text3);">Chargement...</div>
                        </div>
                    </div>
                </div>
                <script>
                (function(){
                    var coconData = <?php
                        $cocon_data_panel = class_exists( 'HTS_Cocon' ) ? \HTS_Cocon::get_cached_cocon_data( class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '' ) : get_option( 'hts_cocon_data', array() );
                        $panel_role  = '';
                        $panel_cluster = '';
                        $panel_cluster_label = '';
                        if ( is_array( $cocon_data_panel ) ) {
                            foreach ( $cocon_data_panel as $cname => $cdata ) {
                                if ( empty( $cdata['pages'] ) ) continue;
                                foreach ( $cdata['pages'] as $pg ) {
                                    if ( (int) ( $pg['post_id'] ?? 0 ) === (int) $post->ID ) {
                                        $panel_role  = $pg['role'] ?? 'orpheline';
                                        $panel_cluster = $cname;
                                        $panel_cluster_label = $cdata['label'] ?? $cname;
                                        break 2;
                                    }
                                }
                            }
                        }
                        echo wp_json_encode( array(
                            'role'     => $panel_role,
                            'cluster'  => $panel_cluster,
                            'label'    => $panel_cluster_label,
                            'has_data' => ! empty( $cocon_data_panel ),
                        ) );
                    ?>;
                    var info = document.getElementById('hp-lnk-info');
                    var badge = document.getElementById('hp-lnk-badge');
                    if (!coconData.has_data) {
                        info.innerHTML = '<div style="color:var(--c-text3);font-size:11.5px;">Aucune analyse de cocon disponible. Lancez l\'analyse depuis le Cockpit pour activer les suggestions de maillage.</div>';
                        badge.textContent = 'Pas de donn\u00e9es';
                    } else if (!coconData.role) {
                        info.innerHTML = '<div style="color:var(--c-warn);font-size:11.5px;">\u26A0 Cette page n\'appartient \u00e0 aucun cluster.</div>';
                        badge.textContent = 'Orpheline';
                        badge.style.background = 'var(--c-warn-bg)';
                        badge.style.color = 'var(--c-warn)';
                    } else {
                        var ri = {pilier:'\uD83D\uDC51',fille:'\uD83D\uDCC4',satellite:'\uD83D\uDEF0\uFE0F',orpheline:'\uD83D\uDC7B'};
                        var rc = {pilier:'var(--c-ok)',fille:'var(--c-blue)',satellite:'var(--c-text3)',orpheline:'var(--c-warn)'};
                        var ic = ri[coconData.role]||'\uD83D\uDCC4';
                        var cl = rc[coconData.role]||'var(--c-text2)';
                        badge.textContent = ic + ' ' + coconData.role.charAt(0).toUpperCase() + coconData.role.slice(1);
                        badge.style.color = cl;
                        info.innerHTML = '<div style="font-size:12px;"><strong>Cluster :</strong> ' + (coconData.label||coconData.cluster) +
                            ' &mdash; <strong>R\u00f4le :</strong> <span style="color:'+cl+'">' + ic + ' ' + coconData.role + '</span></div>' +
                            '<div style="margin-top:8px;font-size:11.5px;color:var(--c-text3);">Suggestions de maillage disponibles dans le Cockpit &gt; Cocon S\u00e9mantique.</div>';
                    }
                })();
                </script>
                <?php endif; ?>

                <!-- ── Actions Prioritaires (Phase 3 — Decision Engine) ── -->
                <?php if ( class_exists( 'HTS_Decision_Engine' ) ) :
                    $post_actions_p3 = HTS_Decision_Engine::get_prioritized_actions( $post->ID );
                ?>
                <?php if ( ! empty( $post_actions_p3 ) ) : ?>
                <div class="hp-grp" id="hp-actions-section" style="margin-top:16px;">
                    <div class="hp-grp-head" onclick="this.nextElementSibling.classList.toggle('hp-grp-hide')">
                        <span>Actions recommandées</span>
                        <span class="hp-grp-badge" style="background:var(--c-blue-bg);color:var(--c-blue);"><?php echo count( $post_actions_p3 ); ?></span>
                    </div>
                    <div class="hp-grp-body" style="padding:14px;">
                        <?php foreach ( $post_actions_p3 as $pa3 ) : ?>
                        <div style="margin-bottom:12px;padding:10px 12px;background:var(--c-surface);border-radius:8px;border-left:3px solid var(--c-blue);">
                            <div style="font-size:12.5px;font-weight:600;color:var(--c-text1);margin-bottom:4px;">
                                <?php echo esc_html( $pa3['title'] ); ?>
                            </div>
                            <div style="font-size:11.5px;color:var(--c-text2);margin-bottom:6px;">
                                <?php echo esc_html( $pa3['why'] ?? $pa3['description'] ); ?>
                            </div>
                            <?php if ( ! empty( $pa3['how'] ) ) : ?>
                            <div style="font-size:11px;color:var(--c-text3);">
                                💡 <?php echo esc_html( $pa3['how'] ); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>

                <!-- ── Historique des modifications (Phase 3 — Audit Trail) ── -->
                <?php if ( class_exists( 'HTS_Audit_Trail' ) ) :
                    $post_history_p3 = HTS_Audit_Trail::get_post_history( $post->ID, 5 );
                ?>
                <?php if ( ! empty( $post_history_p3 ) ) : ?>
                <div class="hp-grp" id="hp-audit-section" style="margin-top:16px;">
                    <div class="hp-grp-head" onclick="this.nextElementSibling.classList.toggle('hp-grp-hide')">
                        <span>📋 Historique des modifications</span>
                        <span class="hp-grp-badge" style="background:var(--c-surface);color:var(--c-text3);"><?php echo count( $post_history_p3 ); ?></span>
                    </div>
                    <div class="hp-grp-body hp-grp-hide" style="padding:14px;">
                        <?php foreach ( $post_history_p3 as $ph3 ) : ?>
                        <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--c-border);font-size:11.5px;">
                            <span style="color:var(--c-text1);">
                                <?php echo esc_html( $ph3['label'] ); ?>
                                <?php if ( ! empty( $ph3['anchor_text'] ) ) : ?>
                                 — <span style="color:var(--c-text3);"><?php echo esc_html( mb_substr( $ph3['anchor_text'], 0, 40 ) ); ?></span>
                                <?php endif; ?>
                            </span>
                            <span style="color:var(--c-text3);font-size:10.5px;"><?php echo esc_html( $ph3['created_at'] ); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- ── Social ── -->
            <div class="hp-pane" data-p="social">
                <p class="hp-hint" style="margin:0 0 14px;">Personnalisez l'apparence sur les réseaux. Vide = hérité des meta SEO.</p>
                <div class="hp-f"><label>OG Title</label><input type="text" name="hts_og_title" value="<?php echo esc_attr( $d['og_title'] ); ?>" placeholder="<?php echo esc_attr( $d['preview_title'] ); ?>"></div>
                <div class="hp-f"><label>OG Description</label><textarea name="hts_og_description" placeholder="<?php echo esc_attr( $d['preview_desc'] ); ?>"><?php echo esc_textarea( $d['og_desc'] ); ?></textarea></div>
                <div class="hp-f">
                    <label>OG Image</label>
                    <div class="hp-img" onclick="hpPick('hts_og_image','hp-ogi')">
                        <?php echo $d['og_image'] ? '<img src="' . esc_url( $d['og_image'] ) . '" id="hp-ogi">' : '<div class="ph" id="hp-ogi">+</div>'; ?>
                        <div><div style="font-size:12.5px;font-weight:600;">Choisir une image</div><div style="font-size:11px;color:var(--c-text3);">1200 × 630 px recommandé</div></div>
                    </div>
                    <input type="hidden" name="hts_og_image" id="hts_og_image" value="<?php echo esc_url( $d['og_image'] ); ?>">
                </div>
                <hr style="border:none;border-top:1px solid var(--c-border);margin:18px 0;">
                <div class="hp-f"><label>Twitter Title</label><input type="text" name="hts_twitter_title" value="<?php echo esc_attr( $d['tw_title'] ); ?>" placeholder="Hérité du OG title"></div>
                <div class="hp-f"><label>Twitter Description</label><textarea name="hts_twitter_description" placeholder="Hérité du OG description"><?php echo esc_textarea( $d['tw_desc'] ); ?></textarea></div>
            </div>

            <!-- ── Avancé ── -->
            <div class="hp-pane" data-p="advanced">
                <div class="hp-f"><label>Robots Meta</label>
                    <label class="hp-tgl"><input type="checkbox" name="hts_noindex" value="1" <?php checked( strpos( $d['robots'], 'noindex' ) !== false ); ?>><div><div class="t">Noindex</div><div class="d">Ne pas indexer cette page</div></div></label>
                    <label class="hp-tgl"><input type="checkbox" name="hts_nofollow" value="1" <?php checked( strpos( $d['robots'], 'nofollow' ) !== false ); ?>><div><div class="t">Nofollow</div><div class="d">Ne pas suivre les liens</div></div></label>
                </div>
                <div class="hp-f"><label>Canonical URL</label><input type="text" name="hts_canonical_url" value="<?php echo esc_url( $d['canonical'] ); ?>" placeholder="<?php echo esc_url( get_permalink( $post ) ); ?>"><div class="hp-hint">Vide = URL par défaut. À remplir uniquement pour contenu dupliqué.</div></div>
                <div class="hp-f"><label>Type de Schema</label>
                    <select name="hts_schema_type"><?php
                        $st = get_post_meta( $post->ID, '_hts_schema_type', true ) ?: 'auto';
                        foreach ( $this->schema_types() as $v => $l ) {
                            echo '<option value="' . esc_attr( $v ) . '"' . selected( $st, $v, false ) . '>' . esc_html( $l ) . '</option>';
                        } ?></select>
                </div>
            </div>

            <!-- ── Impact ── -->
            <div class="hp-pane" data-p="impact">
                <div id="hp-impact" style="min-height:120px;">
                    <div style="text-align:center;padding:30px 0;color:var(--c-text3);font-size:12px;">
                        <span class="hp-spinner"></span> Chargement des données...
                    </div>
                </div>
                <script>
                (function(){
                    var loaded = false;
                    function loadImpact() {
                        if ( loaded ) return;
                        loaded = true;
                        var fd = new FormData();
                        fd.append('action', 'hts_impact_data');
                        fd.append('nonce', '<?php echo wp_create_nonce( "hts_panel_score" ); ?>');
                        fd.append('post_id', <?php echo (int) $post->ID; ?>);
                        fetch('<?php echo esc_url( admin_url( "admin-ajax.php" ) ); ?>', { method: 'POST', body: fd })
                            .then(function(r){ return r.json(); })
                            .then(function(r){
                                if ( ! r.success ) { document.getElementById('hp-impact').innerHTML = '<div style="color:var(--c-text3);font-size:12px;padding:20px 0;text-align:center;">Données indisponibles</div>'; return; }
                                var d = r.data;
                                var html = '';
                                // Stats cards
                                html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">';
                                html += '<div class="hp-dbg-card"><small>Visites IA (30j)</small><strong>' + d.ai_visits_30d + '</strong></div>';
                                html += '<div class="hp-dbg-card"><small>Visites totales (30j)</small><strong>' + d.total_visits_30d + '</strong></div>';
                                html += '<div class="hp-dbg-card"><small>Temps moyen actif</small><strong>' + formatTime(d.avg_active_time) + '</strong></div>';
                                html += '<div class="hp-dbg-card"><small>Scroll moyen</small><strong>' + d.avg_scroll_depth + '%</strong></div>';
                                html += '</div>';
                                // AI sources breakdown
                                if ( d.ai_sources && Object.keys(d.ai_sources).length > 0 ) {
                                    html += '<div style="margin-bottom:14px;">';
                                    html += '<label style="display:block;font-size:11px;font-weight:700;color:var(--c-text2);text-transform:uppercase;letter-spacing:.3px;margin-bottom:6px;">Sources IA (30 derniers jours)</label>';
                                    var srcLabels = { chatgpt: 'ChatGPT', perplexity: 'Perplexity', claude: 'Claude', gemini: 'Gemini', copilot: 'Copilot', you: 'You.com', phind: 'Phind' };
                                    var srcColors = { chatgpt: '#10a37f', perplexity: '#20b8cd', claude: '#d97706', gemini: '#4285f4', copilot: '#7c3aed', you: '#f97316', phind: '#16a34a' };
                                    for ( var src in d.ai_sources ) {
                                        var label = srcLabels[src] || src;
                                        var color = srcColors[src] || '#6366f1';
                                        html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">';
                                        html += '<span style="width:8px;height:8px;border-radius:50%;background:' + color + ';flex-shrink:0;"></span>';
                                        html += '<span style="font-size:12px;color:var(--c-text2);flex:1;">' + label + '</span>';
                                        html += '<span style="font-size:12px;font-weight:600;color:var(--c-text);">' + d.ai_sources[src] + '</span>';
                                        html += '</div>';
                                    }
                                    html += '</div>';
                                }
                                // Scans robots (IA + SEO)
                                var cr = d.crawls || {};
                                html += '<div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--c-border);">';
                                html += '<label style="display:block;font-size:11px;font-weight:700;color:var(--c-text2);text-transform:uppercase;letter-spacing:.3px;margin-bottom:8px;">Activit\u00e9 robots sur cette page</label>';
                                html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px;">';
                                html += '<div class="hp-dbg-card"><small>Scans (30j)</small><strong>' + (cr.last_30d||0) + '</strong></div>';
                                html += '<div class="hp-dbg-card"><small>Scans total</small><strong>' + (cr.total||0) + '</strong></div>';
                                var avgMs = cr.avg_ms || 0;
                                var msColor = avgMs < 500 ? '#16a34a' : (avgMs < 1500 ? '#f59e0b' : '#dc2626');
                                html += '<div class="hp-dbg-card"><small>R\u00e9ponse moy.</small><strong style="color:' + msColor + ';">' + (avgMs > 0 ? avgMs + 'ms' : '\u2014') + '</strong></div>';
                                html += '</div>';
                                // Category split
                                var catAi = (cr.cat_totals && cr.cat_totals.ai) || 0;
                                var catSeo = (cr.cat_totals && cr.cat_totals.seo) || 0;
                                if ( catAi > 0 || catSeo > 0 ) {
                                    var catTotal = catAi + catSeo;
                                    var aiPct = catTotal > 0 ? Math.round(catAi / catTotal * 100) : 0;
                                    html += '<div style="display:flex;justify-content:space-between;font-size:10px;font-weight:600;margin-bottom:4px;">';
                                    html += '<span style="color:#7c3aed;">IA : ' + catAi + '</span>';
                                    html += '<span style="color:#ea4335;">SEO : ' + catSeo + '</span>';
                                    html += '</div>';
                                    html += '<div style="height:6px;background:var(--c-border);border-radius:3px;overflow:hidden;display:flex;margin-bottom:8px;">';
                                    html += '<div style="height:100%;width:' + aiPct + '%;background:linear-gradient(90deg,#7c3aed,#a78bfa);"></div>';
                                    html += '<div style="height:100%;width:' + (100 - aiPct) + '%;background:linear-gradient(90deg,#ea4335,#f87171);"></div>';
                                    html += '</div>';
                                }
                                if ( cr.last_crawl ) {
                                    var ago = cr.last_crawl.substring(0,10);
                                    html += '<div style="font-size:11px;color:var(--c-text3);margin-bottom:6px;">Dernier scan : ' + ago + '</div>';
                                }
                                if ( cr.bot_sources && Object.keys(cr.bot_sources).length > 0 ) {
                                    var botLabels = { chatgpt:'ChatGPT', perplexity:'Perplexity', claude:'Claude', gemini:'Gemini', copilot:'Copilot', cohere:'Cohere', meta:'Meta AI', apple:'Apple', common:'Autres IA', googlebot:'Googlebot', bingbot:'Bingbot', yandex:'Yandex', baidu:'Baidu', duckduckgo:'DuckDuckGo', semrush:'SEMrush', ahrefs:'Ahrefs', moz:'Moz', screaming:'Screaming Frog' };
                                    var botColors = { chatgpt:'#10a37f', perplexity:'#20b8cd', claude:'#d97706', gemini:'#4285f4', copilot:'#7c3aed', googlebot:'#ea4335', bingbot:'#00809d', yandex:'#fc0', semrush:'#ff642d', ahrefs:'#1a56db' };
                                    for ( var bot in cr.bot_sources ) {
                                        var bl = botLabels[bot] || bot;
                                        var bc = botColors[bot] || 'var(--c-accent)';
                                        // Support both old format (number) and new format (object with count)
                                        var cnt = typeof cr.bot_sources[bot] === 'object' ? cr.bot_sources[bot].count : cr.bot_sources[bot];
                                        html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:3px;">';
                                        html += '<span style="width:6px;height:6px;border-radius:50%;background:' + bc + ';flex-shrink:0;"></span>';
                                        html += '<span style="font-size:11px;color:var(--c-text2);flex:1;">' + bl + '</span>';
                                        html += '<span style="font-size:11px;font-weight:600;color:var(--c-text);">' + cnt + '</span>';
                                        html += '</div>';
                                    }
                                }
                                if ( (cr.total||0) === 0 ) {
                                    html += '<div style="font-size:11px;color:var(--c-text3);">Aucun scan enregistr\u00e9 sur cet article.</div>';
                                }
                                html += '</div>';

                                // All-time summary
                                html += '<div style="padding:10px 12px;margin-top:14px;background:var(--c-surface);border-radius:6px;font-size:11px;color:var(--c-text3);">';
                                html += 'Total : ' + d.total_visits + ' visite' + (d.total_visits > 1 ? 's' : '') + ' dont ' + d.ai_visits + ' depuis une IA';
                                html += ' \u00b7 ' + (cr.total||0) + ' scan' + ((cr.total||0) > 1 ? 's' : '') + ' robots';
                                html += '</div>';
                                if ( d.total_visits === 0 && (cr.total||0) === 0 ) {
                                    html = '<div style="text-align:center;padding:30px 0;">';
                                    html += '<div style="margin-bottom:8px;"><?php echo str_replace( "'", "\\'", HTS_Icons::get( "activity", "hts-icon--xl hts-icon--muted" ) ); ?></div>';
                                    html += '<div style="font-size:13px;font-weight:600;color:var(--c-text2);margin-bottom:4px;">Aucune activité enregistrée</div>';
                                    html += '<div style="font-size:11px;color:var(--c-text3);">Les visites et scans IA apparaîtront ici automatiquement.</div>';
                                    html += '</div>';
                                }
                                document.getElementById('hp-impact').innerHTML = html;
                            })
                            .catch(function(){ document.getElementById('hp-impact').innerHTML = '<div style="color:var(--c-text3);font-size:12px;padding:20px 0;text-align:center;">Erreur de chargement</div>'; });
                    }
                    function formatTime(s) {
                        if ( s < 60 ) return s + 's';
                        var m = Math.floor(s / 60);
                        var sec = s % 60;
                        return m + 'min ' + (sec > 0 ? sec + 's' : '');
                    }
                    // Lazy load: only when tab is clicked
                    document.addEventListener('click', function(e) {
                        if ( e.target.closest && e.target.closest('.hp-tab[data-t="impact"]') ) loadImpact();
                    });
                })();
                </script>
            </div>

            <!-- ── GSC (Search Console per-article) ── -->
            <div class="hp-pane" data-p="gsc">
                <div id="hp-gsc" style="min-height:120px;">
                    <?php
                    $gsc_panel_connected = false;
                    if ( class_exists( 'HTS_GSC_Connect' ) && get_option( 'hts_module_gsc', '1' ) === '1' ) {
                        $gsc_panel = new HTS_GSC_Connect();
                        $gsc_panel_connected = $gsc_panel->is_connected() && $gsc_panel->has_data();
                    }
                    if ( ! $gsc_panel_connected ) : ?>
                    <div style="text-align:center;padding:30px 0;">
                        <div style="margin-bottom:8px;"><?php HTS_Icons::render( 'trending-up', 'hts-icon--xl hts-icon--muted' ); ?></div>
                        <div style="font-size:13px;font-weight:600;color:var(--c-text2);margin-bottom:4px;">Search Console non connect&eacute;</div>
                        <div style="font-size:11px;color:var(--c-text3);margin-bottom:12px;">Connectez GSC pour voir les clics, impressions et position de cet article.</div>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-seo-settings' ) ); ?>" style="font-size:11px;color:var(--c-accent);text-decoration:none;font-weight:600;">Connecter Search Console →</a>
                    </div>
                    <?php else : ?>
                    <div style="text-align:center;padding:30px 0;color:var(--c-text3);font-size:12px;">
                        <span class="hp-spinner"></span> Chargement des donn&eacute;es GSC...
                    </div>
                    <?php endif; ?>
                </div>
                <?php if ( $gsc_panel_connected ) : ?>
                <script>
                (function(){
                    var loaded = false;
                    function loadGSC() {
                        if ( loaded ) return;
                        loaded = true;
                        var fd = new FormData();
                        fd.append('action', 'hts_gsc_panel_data');
                        fd.append('nonce', '<?php echo wp_create_nonce( "hts_panel_score" ); ?>');
                        fd.append('post_id', <?php echo (int) $post->ID; ?>);
                        fetch('<?php echo esc_url( admin_url( "admin-ajax.php" ) ); ?>', { method: 'POST', body: fd })
                            .then(function(r){ return r.json(); })
                            .then(function(r){
                                if ( ! r.success || ! r.data ) { document.getElementById('hp-gsc').innerHTML = '<div style="color:var(--c-text3);font-size:12px;padding:20px 0;text-align:center;">Pas de donn\u00e9es GSC pour cet article</div>'; return; }
                                var d = r.data;
                                var html = '';
                                // KPI cards
                                html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">';
                                html += '<div class="hp-dbg-card"><small>Clics (30j)</small><strong style="color:#2563eb;">' + d.clicks + '</strong></div>';
                                html += '<div class="hp-dbg-card"><small>Impressions</small><strong>' + d.impressions + '</strong></div>';
                                var posCol = d.avg_position <= 10 ? '#16a34a' : (d.avg_position <= 20 ? '#d97706' : '#dc2626');
                                html += '<div class="hp-dbg-card"><small>Position moy.</small><strong style="color:' + posCol + ';">' + d.avg_position + '</strong></div>';
                                html += '<div class="hp-dbg-card"><small>CTR</small><strong>' + d.avg_ctr + '%</strong></div>';
                                html += '</div>';
                                // Daily sparkline
                                if ( d.daily && d.daily.length > 0 ) {
                                    var maxC = Math.max.apply(null, d.daily.map(function(x){ return x.clicks || 0; }));
                                    maxC = Math.max(maxC, 1);
                                    html += '<label style="display:block;font-size:11px;font-weight:700;color:var(--c-text2);text-transform:uppercase;letter-spacing:.3px;margin-bottom:6px;">Clics par jour</label>';
                                    html += '<div style="display:flex;align-items:flex-end;gap:1px;height:50px;margin-bottom:10px;">';
                                    d.daily.forEach(function(dd) {
                                        var h = Math.round((dd.clicks || 0) / maxC * 100);
                                        html += '<div style="flex:1;background:var(--c-accent);border-radius:1px 1px 0 0;height:' + h + '%;opacity:0.7;" title="' + dd.fetch_date + ' : ' + (dd.clicks||0) + ' clics"></div>';
                                    });
                                    html += '</div>';
                                }
                                // Advice based on data
                                if ( d.clicks === 0 && d.impressions > 0 ) {
                                    html += '<div style="padding:10px 12px;background:#fef3c7;border-radius:6px;font-size:11px;color:#92400e;border-left:3px solid #f59e0b;">';
                                    html += '<strong>' + d.impressions + ' impressions mais 0 clic</strong> \u2014 le title et la meta description ne donnent pas envie de cliquer. Am\u00e9liorez-les !';
                                    html += '</div>';
                                } else if ( d.avg_position > 20 ) {
                                    html += '<div style="padding:10px 12px;background:#fef2f2;border-radius:6px;font-size:11px;color:#991b1b;border-left:3px solid #ef4444;">';
                                    html += '<strong>Position ' + d.avg_position + '</strong> \u2014 cette page est loin dans les r\u00e9sultats. Renforcez le contenu et le maillage interne.';
                                    html += '</div>';
                                } else if ( d.avg_position > 10 && d.avg_position <= 20 ) {
                                    html += '<div style="padding:10px 12px;background:#fffbeb;border-radius:6px;font-size:11px;color:#92400e;border-left:3px solid #f59e0b;">';
                                    html += '<strong>Position ' + d.avg_position + '</strong> \u2014 presque en page 1 ! Un petit effort sur le contenu pourrait suffire.';
                                    html += '</div>';
                                } else if ( d.clicks > 0 ) {
                                    html += '<div style="padding:10px 12px;background:#f0fdf4;border-radius:6px;font-size:11px;color:#166534;border-left:3px solid #16a34a;">';
                                    html += '<strong>Position ' + d.avg_position + '</strong> \u2014 page bien positionn\u00e9e avec ' + d.clicks + ' clic' + (d.clicks > 1 ? 's' : '') + ' !';
                                    html += '</div>';
                                }
                                if ( d.clicks === 0 && d.impressions === 0 ) {
                                    html = '<div style="text-align:center;padding:30px 0;">';
                                    html += '<div style="font-size:13px;font-weight:600;color:var(--c-text2);margin-bottom:4px;">Pas de donn\u00e9es GSC</div>';
                                    html += '<div style="font-size:11px;color:var(--c-text3);">Cet article n\'appara\u00eet pas encore dans Google Search Console.</div>';
                                    html += '</div>';
                                }
                                document.getElementById('hp-gsc').innerHTML = html;
                            })
                            .catch(function(){ document.getElementById('hp-gsc').innerHTML = '<div style="color:var(--c-text3);font-size:12px;padding:20px 0;text-align:center;">Erreur de chargement</div>'; });
                    }
                    document.addEventListener('click', function(e) {
                        if ( e.target.closest && e.target.closest('.hp-tab[data-t="gsc"]') ) loadGSC();
                    });
                })();
                </script>
                <?php endif; ?>
            </div>

            <?php if ( current_user_can( 'manage_options' ) ) : ?>
            <!-- ── Diagnostic ── -->
            <div class="hp-pane" data-p="debug">
                <div style="padding:2px 0 10px;">
                    <button type="button" id="hp-dbg-refresh" style="background:var(--c-primary);color:#fff;border:none;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">🔄 Forcer l'analyse</button>
                    <button type="button" id="hp-dbg-clear" style="background:var(--c-border);color:var(--c-text);border:none;padding:7px 14px;border-radius:6px;font-size:12px;cursor:pointer;margin-left:6px;">Effacer le log</button>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
                    <div class="hp-dbg-card" id="hp-dbg-words"><small>Mots</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-source"><small>Source</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-content"><small>Contenu (bytes)</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-headings"><small>Titres Hn</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-kw"><small>Mot-clé</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-score"><small>Score</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-links"><small>Liens int/ext</small><strong>—</strong></div>
                    <div class="hp-dbg-card" id="hp-dbg-images"><small>Images</small><strong>—</strong></div>
                </div>
                <div style="margin-bottom:8px;">
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--c-text2);text-transform:uppercase;letter-spacing:.3px;margin-bottom:4px;">Éditeur détecté</label>
                    <div id="hp-dbg-editor" style="font-size:12px;color:var(--c-text3);padding:6px 10px;background:var(--c-surface);border-radius:6px;">—</div>
                </div>
                <div style="margin-bottom:8px;">
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--c-text2);text-transform:uppercase;letter-spacing:.3px;margin-bottom:4px;">Contenu capturé (extrait)</label>
                    <div id="hp-dbg-preview" style="font-size:11px;color:var(--c-text3);padding:6px 10px;background:var(--c-surface);border-radius:6px;max-height:80px;overflow:auto;word-break:break-all;font-family:monospace;">—</div>
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--c-text2);text-transform:uppercase;letter-spacing:.3px;margin-bottom:4px;">Log temps réel</label>
                    <div id="hp-dbg-log" style="font-size:11px;color:var(--c-text3);padding:6px 10px;background:#1a1a2e;color:#a0e0a0;border-radius:6px;max-height:200px;overflow:auto;font-family:monospace;white-space:pre-wrap;line-height:1.5;"></div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <script>
        (function(){
        var AJ='<?php echo esc_url( admin_url( "admin-ajax.php" ) ); ?>',NC='<?php echo wp_create_nonce( "hts_panel_score" ); ?>',PID=<?php echo (int)$post->ID; ?>,
            SN=<?php echo wp_json_encode( get_bloginfo('name') ); ?>,SP=<?php echo wp_json_encode( get_option('hts_title_separator','—') ); ?>,
            PT=<?php echo wp_json_encode( $post->post_title ); ?>;

        var _hpTimer=null, _hpReq=null;

        /* Tabs */
        document.querySelectorAll('.hp-tab').forEach(function(t){t.addEventListener('click',function(){
            document.querySelectorAll('.hp-tab').forEach(function(x){x.classList.remove('on')});
            document.querySelectorAll('.hp-pane').forEach(function(x){x.classList.remove('on')});
            t.classList.add('on');
            var p=document.querySelector('.hp-pane[data-p="'+t.dataset.t+'"]');if(p)p.classList.add('on');
        })});

        /* \u2550 GET LIVE VALUES FROM ALL EDITOR FIELDS \u2550 */

        /* Detect actual editor: Gutenberg has .block-editor-page on body
           Classic Editor has #post form + #postdivrich and no block editor */
        var _hpIsGutenberg=(function(){
            if(document.body.classList.contains('block-editor-page'))return true;
            if(document.querySelector('.block-editor'))return true;
            if(document.querySelector('.edit-post-layout'))return true;
            if(document.querySelector('.editor-visual-editor'))return true;
            if(document.getElementById('post')&&document.getElementById('postdivrich'))return false;
            /* Do NOT call wp.data.select here — Gutenberg plugin registry crashes if called too early */
            return false;
        })();

        /* Flag: set to true once we confirm core/editor store is ready */
        var _gbStoreReady=false;
        function hpCheckStore(){
            if(_gbStoreReady)return true;
            try{
                var s=wp.data.select('core/editor');
                if(s&&s.getEditedPostAttribute&&typeof s.getEditedPostAttribute('title')==='string'){
                    _gbStoreReady=true;return true;
                }
            }catch(e){}
            return false;
        }

        function hpGetPostTitle(){
            if(_hpIsGutenberg&&_gbStoreReady){
                try{var t=wp.data.select('core/editor').getEditedPostAttribute('title');if(typeof t==='string')return t;}catch(e){}
            }
            var el=document.getElementById('title');
            return el?el.value:PT;
        }

        function hpGetContent(){
            if(_hpIsGutenberg&&_gbStoreReady){
                try{var b=wp.data.select('core/editor').getEditedPostContent();if(typeof b==='string'&&b.length>0)return b;}catch(e){}
            }
            if(typeof tinymce!=='undefined'){var ed=tinymce.get('content');if(ed&&!ed.isHidden())return ed.getContent();}
            var ta=document.getElementById('content');
            return ta?ta.value:'';
        }

        /* \u2550 SERP PREVIEW (instant) \u2550 */
        window.hpUpd=function(){
            PT=hpGetPostTitle();
            var tt=document.getElementById('hp-tt'),ds=document.getElementById('hp-ds'),kw=document.getElementById('hp-kw'),sl=document.getElementById('hp-slug');
            var title=tt.value||tt.placeholder, desc=ds.value||ds.placeholder, k=kw.value;
            title=title.replace(/%title%/g,PT).replace(/%sep%/g,SP).replace(/%sitename%/g,SN).replace(/%focuskw%/g,k);
            document.getElementById('hp-st').textContent=title;
            var sd=document.getElementById('hp-sd');sd.textContent=desc;
            if(k){var re=new RegExp('('+k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi');sd.innerHTML=sd.textContent.replace(re,'<b>$1</b>');}
            hpCtr('hp-ttc',title.length,60);hpCtr('hp-dsc',(ds.value||desc).length,155);
            var slugEl=document.getElementById('hp-su-slug');
            if(slugEl&&sl)slugEl.textContent=sl.value||sl.placeholder;
            hpDebounceRefresh();
        };
        function hpCtr(id,n,mx){var e=document.getElementById(id);if(!e)return;e.innerHTML=(n>mx?'<span class="over">'+n+'</span>':n)+'/'+mx;}

        /* \u2550 DEBOUNCED AUTO-REFRESH \u2550 */
        function hpDebounceRefresh(){
            if(_hpTimer)clearTimeout(_hpTimer);
            _hpTimer=setTimeout(function(){hpDbg('\u23f1 Debounce termin\u00e9 \u2192 refresh');hpRefreshLive();},800);
        }

        function hpRefreshLive(){
            var kw=document.getElementById('hp-kw'),tt=document.getElementById('hp-tt'),ds=document.getElementById('hp-ds'),sl=document.getElementById('hp-slug');
            var fd=new FormData();
            fd.append('action','hts_panel_score');fd.append('nonce',NC);fd.append('post_id',PID);
            fd.append('live_kw',kw?kw.value:'');
            fd.append('live_title',tt?tt.value:'');
            fd.append('live_desc',ds?ds.value:'');
            fd.append('live_slug',sl?sl.value:'');
            fd.append('live_post_title',hpGetPostTitle());
            fd.append('live_content',hpGetContent());
            hpDoRefresh(fd);
        }

        window.hpRefresh=function(){
            var fd=new FormData();fd.append('action','hts_panel_score');fd.append('nonce',NC);fd.append('post_id',PID);
            hpDoRefresh(fd);
        };

        /* ═ DEBUG HELPERS ═ */
        var _hpDbgLog=document.getElementById('hp-dbg-log');
        var _hpDbgN=0;
        function hpDbg(msg){
            if(!_hpDbgLog)return;
            _hpDbgN++;
            var ts=new Date().toLocaleTimeString();
            _hpDbgLog.innerHTML+='<span style="color:#666;">'+ts+'</span> '+msg+'\n';
            _hpDbgLog.scrollTop=_hpDbgLog.scrollHeight;
        }
        function hpDbgSet(id,val){var el=document.getElementById(id);if(el){el.querySelector('strong').textContent=val;}}

        function hpDetectEditor(){
            if(_hpIsGutenberg) return 'Gutenberg';
            if(typeof tinymce!=='undefined'&&tinymce.get('content')){
                return tinymce.get('content').isHidden()?'Classic (HTML)':'Classic (Visual)';
            }
            if(document.getElementById('content'))return 'Classic (textarea)';
            return 'Inconnu';
        }

        function hpDoRefresh(fd){
            if(_hpReq)try{_hpReq.abort();}catch(e){}
            var ring=document.getElementById('hp-ring');ring.style.opacity='.5';

            /* Debug: log what we're sending */
            var contentLen=0;
            try{var c=hpGetContent();contentLen=c?c.length:0;}catch(e){}
            hpDbg('→ AJAX envoyé | contenu: <span style="color:#ff0;">'+contentLen+'</span> chars | kw: '+(document.getElementById('hp-kw')?document.getElementById('hp-kw').value:'(vide)'));

            /* Show content preview in debug */
            var previewEl=document.getElementById('hp-dbg-preview');
            if(previewEl){try{var raw=hpGetContent();previewEl.textContent=raw?raw.substring(0,300):'(vide)';}catch(e){previewEl.textContent='Erreur: '+e.message;}}

            _hpReq=new XMLHttpRequest();
            _hpReq.open('POST',AJ,true);
            _hpReq.onload=function(){
                ring.style.opacity='1';
                try{var r=JSON.parse(_hpReq.responseText);if(!r.success){hpDbg('<span style="color:#f55;">✗ AJAX erreur: '+JSON.stringify(r)+'</span>');return;}var d=r.data;
                    document.getElementById('hp-bar').setAttribute('stroke-dashoffset',(119.4-119.4*d.score/100).toFixed(1));
                    document.getElementById('hp-bar').setAttribute('stroke',d.color);
                    document.getElementById('hp-num').textContent=d.score;document.getElementById('hp-num').style.color=d.color;
                    document.getElementById('hp-label').textContent=d.label;document.getElementById('hp-label').style.color=d.color;
                    document.getElementById('hp-analysis').innerHTML=d.html;
                    var fx=document.getElementById('hp-fixes');if(fx){if(d.fixes){fx.innerHTML=d.fixes;fx.classList.remove('hts-hidden')}else{fx.classList.add('hts-hidden')}}
                    var ct=document.querySelector('.hp-tab[data-t="analyse"] .ct');
                    if(d.issues>0){if(ct){ct.textContent=d.issues}else{document.querySelector('.hp-tab[data-t="analyse"]').insertAdjacentHTML('beforeend','<span class="ct">'+d.issues+'</span>')}}
                    else if(ct){ct.remove();}

                    /* Debug: update cards with server response */
                    if(d.debug){
                        var db=d.debug;
                        hpDbgSet('hp-dbg-words',db.words);
                        hpDbgSet('hp-dbg-source',db.content_source);
                        hpDbgSet('hp-dbg-content',db.content_bytes+' / '+db.text_bytes);
                        hpDbgSet('hp-dbg-headings',db.headings+' (H1:'+db.h1_count+')');
                        hpDbgSet('hp-dbg-kw',db.kw||'(vide)');
                        hpDbgSet('hp-dbg-score',d.score+'/100');
                        hpDbgSet('hp-dbg-links',db.internal_links+' / '+db.external_links);
                        hpDbgSet('hp-dbg-images',db.images);
                        hpDbg('← Score: <span style="color:#0f0;">'+d.score+'</span> | Mots: <span style="color:#ff0;">'+db.words+'</span> | Hn: '+db.headings+' | Source: '+db.content_source);
                    }
                    /* Notify sidebar (if active) */
                    try{document.dispatchEvent(new CustomEvent('hts:score-updated',{detail:d}));}catch(e){}
                }catch(e){hpDbg('<span style="color:#f55;">✗ Parse erreur: '+e.message+'</span>');}
            };
            _hpReq.onerror=function(){ring.style.opacity='1';hpDbg('<span style="color:#f55;">✗ Réseau erreur</span>');};
            _hpReq.send(fd);
        }

        /* \u2550 LISTEN TO ALL WP EDITOR CHANGES \u2550 */

        var _wpTitle=document.getElementById('title');
        if(_wpTitle){_wpTitle.addEventListener('input',function(){PT=_wpTitle.value;hpUpd();});}

        /* ── Robust TinyMCE binding (retry + tab-switch + polling) ── */

        /* Simple djb2 hash — shared by Classic & Gutenberg change detection */
        function hpHash(s){var h=5381;for(var i=0;i<s.length;i++){h=((h<<5)+h)+s.charCodeAt(i);h=h&h;}return h;}

        var _mceBound=false,_mceRetries=0;

        function hpBindTinyMCE(){
            if(typeof tinymce==='undefined')return false;
            var ed=tinymce.get('content');
            if(!ed||!ed.initialized){return false;}
            if(_mceBound&&ed._hpBound)return true;
            ed.on('input keyup change NodeChange',function(){hpDbg('MCE: changement d\u00e9tect\u00e9');hpDebounceRefresh();});
            ed.on('paste undo redo SetContent',function(){setTimeout(hpDebounceRefresh,100);});
            ed._hpBound=true;_mceBound=true;
            hpDbg('\u2705 TinyMCE bind OK (tentative '+_mceRetries+')');
            return true;
        }

        /* Method 1: WordPress fires this jQuery event reliably after TinyMCE init */
        if(typeof jQuery!=='undefined'){
            jQuery(document).on('tinymce-editor-init',function(ev,ed){
                if(ed&&ed.id==='content'){hpDbg('WP event tinymce-editor-init');hpBindTinyMCE();}
            });
        }

        /* Method 2: TinyMCE native AddEditor hook */
        if(typeof tinymce!=='undefined'){
            if(tinymce.get('content')&&tinymce.get('content').initialized){hpBindTinyMCE();}
            tinymce.on('AddEditor',function(e){
                if(e.editor&&e.editor.id==='content'){
                    e.editor.on('init',function(){hpDbg('MCE AddEditor>init');hpBindTinyMCE();});
                }
            });
        }

        /* Method 3: Retry every 500ms for up to 15s (covers slow page loads) */
        var _mceRetryTimer=setInterval(function(){
            _mceRetries++;
            if(hpBindTinyMCE()||_mceRetries>=30){
                clearInterval(_mceRetryTimer);
                if(!_mceBound)hpDbg('\u26a0\ufe0f TinyMCE bind \u00e9chou\u00e9 apr\u00e8s '+_mceRetries+' tentatives — polling actif');
            }
        },500);

        /* Method 4: Visual/HTML tab switch — re-bind when editor is recreated */
        var _wpTabs=document.querySelectorAll('#content-tmce, #content-html');
        _wpTabs.forEach(function(tab){
            tab.addEventListener('click',function(){
                _mceBound=false;
                setTimeout(function(){hpBindTinyMCE();hpDbg('Tab switch \u2192 re-bind');},300);
            });
        });

        /* Textarea fallback (HTML tab in Classic Editor) */
        var _wpContent=document.getElementById('content');
        if(_wpContent){_wpContent.addEventListener('input',function(){hpDbg('Textarea: changement d\u00e9tect\u00e9');hpDebounceRefresh();});}

        /* ── Polling safety net: check content hash every 2s ── */
        var _pollPrev='';
        setInterval(function(){
            if(_hpIsGutenberg)return; /* Gutenberg has its own wp.data.subscribe */
            try{
                var c=hpGetContent();
                var sig=(c?c.length:'0')+'|'+((typeof hpHash==='function'&&c)?hpHash(c):'x');
                if(sig!==_pollPrev&&_pollPrev!==''){
                    hpDbg('Poll: changement d\u00e9tect\u00e9 ('+sig.split('|')[0]+' chars)');
                    hpDebounceRefresh();
                }
                _pollPrev=sig;
            }catch(e){}
        },2000);

        if(_hpIsGutenberg&&typeof wp!=='undefined'&&wp.data&&wp.data.subscribe){
            var _gbPrev='',_gbThrottle=0,_gbTrailing=null;
            function hpGbCheck(){
                if(!hpCheckStore())return; /* Store not ready yet */
                try{
                    var s=wp.data.select('core/editor');
                    var t=s.getEditedPostAttribute('title')||'';
                    var c=s.getEditedPostContent()||'';
                    var sig=t+'|'+hpHash(c);
                    if(sig!==_gbPrev){_gbPrev=sig;PT=t;hpDbg('GB: changement d\u00e9tect\u00e9 (titre+hash)');hpDebounceRefresh();}
                }catch(e){}
            }
            /* Defer subscribe — Gutenberg plugin registry needs time to initialize all stores */
            setTimeout(function(){
                try{
                    wp.data.subscribe(function(){
                        var now=Date.now();
                        if(now-_gbThrottle<500){
                            if(!_gbTrailing){_gbTrailing=setTimeout(function(){_gbTrailing=null;hpGbCheck();},600);}
                            return;
                        }
                        _gbThrottle=now;
                        if(_gbTrailing){clearTimeout(_gbTrailing);_gbTrailing=null;}
                        hpGbCheck();
                    });
                    hpDbg('GB: wp.data.subscribe actif');
                }catch(e){hpDbg('\u26a0\ufe0f GB: wp.data.subscribe \u00e9chou\u00e9 — polling actif');}
            },3000);
        }

        /* ═ SLUG SYNC: HTS panel ↔ WP native slug ═ */
        var _hpSlug=document.getElementById('hp-slug');
        if(_hpSlug){
            /* When our slug field changes → push to WP native slug */
            _hpSlug.addEventListener('input',function(){
                var val=_hpSlug.value;
                /* Classic Editor: update #editable-post-name-full if visible */
                var wpSlugDisplay=document.getElementById('editable-post-name-full');
                if(wpSlugDisplay) wpSlugDisplay.textContent=val;
                /* Gutenberg: update slug in block editor store */
                if(_hpIsGutenberg&&_gbStoreReady&&typeof wp!=='undefined'&&wp.data&&wp.data.dispatch){
                    try{wp.data.dispatch('core/editor').editPost({slug:val});}catch(e){}
                }
            });
            /* Classic Editor: observe WP native slug changes → update our field */
            var wpSlugBox=document.getElementById('edit-slug-box');
            if(wpSlugBox){
                var _slugObs=new MutationObserver(function(){
                    var wpSlugEl=document.getElementById('editable-post-name-full');
                    if(wpSlugEl&&wpSlugEl.textContent!==_hpSlug.value){
                        _hpSlug.value=wpSlugEl.textContent;
                        hpUpd();
                    }
                });
                _slugObs.observe(wpSlugBox,{childList:true,subtree:true,characterData:true});
            }
        }

        /* \u2550 UI HELPERS \u2550 */
        window.hpSerpMode=function(w,b){
            document.querySelectorAll('.hp-serp-bar button').forEach(function(x){x.classList.remove('on')});b.classList.add('on');
            document.getElementById('hp-serp').style.maxWidth=w;
        };

        window.hpPick=function(iid,pid){
            if(typeof wp==='undefined'||!wp.media)return;
            var f=wp.media({title:'Image',multiple:false,library:{type:'image'}});
            f.on('select',function(){var a=f.state().get('selection').first().toJSON();
                document.getElementById(iid).value=a.url;
                var p=document.getElementById(pid);
                if(p.tagName==='IMG'){p.src=a.url}else{p.outerHTML='<img src="'+a.url+'" id="'+pid+'" style="width:52px;height:52px;object-fit:cover;border-radius:4px;">';}
            });f.open();
        };

        document.addEventListener('click',function(e){var h=e.target.closest('.hp-grp-head');if(!h)return;var b=h.nextElementSibling;if(b)b.style.display=b.style.display==='none'?'':'none';});

        /* ═ DEBUG INIT ═ */
        var _dbgRefBtn=document.getElementById('hp-dbg-refresh');
        if(_dbgRefBtn){
            _dbgRefBtn.addEventListener('click',function(){
                hpDbg('── Force refresh déclenché ──');
                hpRefreshLive();
            });
        }
        var _dbgClrBtn=document.getElementById('hp-dbg-clear');
        if(_dbgClrBtn){
            _dbgClrBtn.addEventListener('click',function(){
                if(_hpDbgLog)_hpDbgLog.innerHTML='';_hpDbgN=0;
            });
        }
        /* Detect editor type */
        setTimeout(function(){
            var edEl=document.getElementById('hp-dbg-editor');
            if(edEl)edEl.textContent=hpDetectEditor();
            hpDbg('Panel initialisé | Éditeur: '+hpDetectEditor()+' | Gutenberg: '+_hpIsGutenberg+' | Post ID: '+PID);
        },500);

        hpUpd();
        /* In Gutenberg, the store needs time to initialize — delay first AJAX */
        if(_hpIsGutenberg){
            setTimeout(function(){hpDbg('GB: premier refresh retardé');hpRefreshLive();},1500);
        }
        })();
        </script>
        <?php
    }

    /* ══════════════════════════════════════════════
     *  SIDEBAR SUMMARY (Classic Editor)
     *  Hidden in Gutenberg via CSS — the Gutenberg
     *  widget (PluginPostStatusInfo) takes over.
     * ══════════════════════════════════════════════ */

    public function render_summary( $post ) {
        $analysis = $this->run_checks( $post->ID );
        $score    = $analysis['score'];
        $kw       = get_post_meta( $post->ID, '_hts_focus_keyword', true );
        $text     = get_post_meta( $post->ID, '_hts_content_text', true );
        if ( ! $text && class_exists( 'HTS_Content_Extractor' ) ) {
            $raw  = HTS_Content_Extractor::get_content( $post->ID );
            $text = $raw ? wp_strip_all_tags( $raw ) : '';
        }
        $words = $text ? hts_word_count( $text ) : 0;

        // Collect top 3 issues (fail first, then warn)
        $issues = array();
        foreach ( $analysis['groups'] as $g ) {
            foreach ( $g['checks'] as $c ) {
                if ( $c['status'] === 'fail' || $c['status'] === 'warn' ) {
                    $issues[] = $c;
                }
            }
        }
        usort( $issues, function( $a, $b ) {
            if ( $a['status'] === $b['status'] ) return 0;
            return $a['status'] === 'fail' ? -1 : 1;
        });
        $issues = array_slice( $issues, 0, 3 );

        // Score color
        if ( $score >= 80 ) { $color = '#16a34a'; }
        elseif ( $score >= 50 ) { $color = '#d97706'; }
        else { $color = '#dc2626'; }

        // SVG ring
        $circumference = 87.96; // 2 * PI * 14
        $offset = $circumference - ( $circumference * $score / 100 );
        ?>
        <style>
            /* Hide sidebar summary in Gutenberg — the PluginPostStatusInfo widget is used instead */
            body.block-editor-page #hts-seo-summary { display:none !important; }
            .hts-summary-wrap { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; }
            .hts-summary-top { display:flex; align-items:center; gap:12px; margin-bottom:12px; }
            .hts-summary-ring { position:relative; width:48px; height:48px; flex-shrink:0; }
            .hts-summary-ring svg { transform:rotate(-90deg); }
            .hts-summary-num { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:700; }
            .hts-summary-info { flex:1; min-width:0; }
            .hts-summary-kw { display:inline-block; background:#eff6ff; color:#2563eb; padding:1px 8px; border-radius:10px; font-size:11px; font-weight:600; max-width:100%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
            .hts-summary-words { font-size:11px; color:#6b7280; margin-top:2px; }
            .hts-summary-issues { margin:0; padding:0; list-style:none; }
            .hts-summary-issues li { display:flex; align-items:flex-start; gap:8px; padding:5px 0; font-size:12px; color:#374151; border-top:1px solid #f3f4f6; }
            .hts-summary-issues li:first-child { border-top:none; }
            .hts-summary-dot { width:6px; height:6px; border-radius:50%; flex-shrink:0; margin-top:5px; }
            .hts-summary-dot.fail { background:#dc2626; }
            .hts-summary-dot.warn { background:#d97706; }
            .hts-summary-link { display:block; text-align:center; margin-top:10px; font-size:12px; color:#2563eb; text-decoration:none; }
            .hts-summary-link:hover { text-decoration:underline; }
        </style>
        <div class="hts-summary-wrap">
            <div class="hts-summary-top">
                <div class="hts-summary-ring">
                    <svg width="48" height="48">
                        <circle cx="24" cy="24" r="19" fill="none" stroke="#e5e7eb" stroke-width="3.5"/>
                        <circle cx="24" cy="24" r="19" fill="none" stroke="<?php echo esc_attr( $color ); ?>" stroke-width="3.5" stroke-linecap="round"
                            stroke-dasharray="<?php echo esc_attr( 2 * M_PI * 19 ); ?>"
                            stroke-dashoffset="<?php echo esc_attr( ( 2 * M_PI * 19 ) - ( 2 * M_PI * 19 * $score / 100 ) ); ?>"/>
                    </svg>
                    <div class="hts-summary-num" style="color:<?php echo esc_attr( $color ); ?>"><?php echo (int) $score; ?></div>
                </div>
                <div class="hts-summary-info">
                    <?php if ( $kw ) : ?>
                        <span class="hts-summary-kw"><?php echo esc_html( $kw ); ?></span>
                    <?php endif; ?>
                    <?php if ( $words ) : ?>
                        <div class="hts-summary-words"><?php echo number_format( $words, 0, ',', ' ' ); ?> mots</div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ( ! empty( $issues ) ) : ?>
                <ul class="hts-summary-issues">
                    <?php foreach ( $issues as $issue ) : ?>
                        <li>
                            <span class="hts-summary-dot <?php echo esc_attr( $issue['status'] ); ?>"></span>
                            <span><?php echo esc_html( $issue['text'] ); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <a href="#hts-seo-panel" class="hts-summary-link">↓ Voir le panneau complet</a>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════════
     *  RENDER ANALYSIS HTML
     * ══════════════════════════════════════════════ */

    public function render_analysis( $analysis ) {
        foreach ( $analysis['groups'] as $g ) {
            $ok = 0; $warn = 0; $fail = 0;
            foreach ( $g['checks'] as $c ) {
                if ( $c['status'] === 'ok' ) $ok++;
                elseif ( $c['status'] === 'warn' ) $warn++;
                elseif ( $c['status'] === 'fail' ) $fail++;
            }

            if ( $fail > 0 ) { $bc = 'fail'; $bt = $fail . ' erreur' . ( $fail > 1 ? 's' : '' ); }
            elseif ( $warn > 0 ) { $bc = 'warn'; $bt = $warn . ' à améliorer'; }
            else { $bc = 'ok'; $bt = 'Tout est bon'; }

            echo '<div class="hp-grp">';
            echo '<div class="hp-grp-head"><span>' . esc_html( $g['label'] ) . ' <small style="color:var(--c-text3);font-weight:400;">(' . $g['weight'] . '%)</small></span><span class="hp-grp-badge ' . $bc . '">' . esc_html( $bt ) . '</span></div>';
            echo '<div class="hp-grp-body">';
            foreach ( $g['checks'] as $c ) {
                $has_details = ! empty( $c['details'] );
                $has_fix     = ! empty( $c['fix'] ) && $c['status'] !== 'ok';
                $chk_classes = 'hp-chk';
                if ( $has_details ) $chk_classes .= ' hp-chk-details';
                if ( $has_fix )     $chk_classes .= ' hp-chk-fix';
                echo '<div class="' . esc_attr( $chk_classes ) . '">';
                echo '<span class="hp-dot ' . esc_attr( $c['status'] ) . '"></span>';
                $allowed_check_tags = array('a' => array('href' => true, 'target' => true, 'style' => true));
                echo '<span class="hp-chk-text">' . wp_kses( $c['text'], $allowed_check_tags );
                if ( $has_fix ) {
                    echo ' <a class="hp-fix-toggle" onclick="this.closest(\'.hp-chk-fix\').classList.toggle(\'show-fix\')" title="Comment corriger ?">ⓘ</a>';
                }
                if ( $has_details ) {
                    echo ' <a class="hp-detail-toggle" onclick="this.closest(\'.hp-chk-details\').classList.toggle(\'open\')" title="Voir les détails">▸</a>';
                }
                echo '</span>';
                if ( $has_fix ) {
                    echo '<div class="hp-chk-advice">→ ' . esc_html( $c['fix'] ) . '</div>';
                }
                if ( $has_details ) {
                    echo '<div class="hp-detail-list">';
                    foreach ( $c['details'] as $detail ) {
                        echo '<div class="hp-detail-item">' . esc_html( $detail ) . '</div>';
                    }
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div></div>';
        }

        if ( $analysis['penalty'] > 0 ) {
            echo '<div class="hp-penalty">Sur-optimisation détectée — pénalité de ' . (int) $analysis['penalty'] . ' points. Réduisez la répétition du mot-clé.</div>';
        }
    }

    /* ══════════════════════════════════════════════
     *  SAVE
     * ══════════════════════════════════════════════ */

    public function save( $post_id, $post ) {
        if ( ! isset( $_POST['_hts_seo_panel_nonce'] ) || ! wp_verify_nonce( $_POST['_hts_seo_panel_nonce'], self::NONCE ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;

        $this->sm( $post_id, '_hts_focus_keyword', sanitize_text_field( $_POST['hts_focus_keyword'] ?? '' ) );
        $this->sm( $post_id, '_hts_meta_title', sanitize_text_field( $_POST['hts_meta_title'] ?? '' ) );
        $this->sm( $post_id, '_hts_meta_description', sanitize_textarea_field( $_POST['hts_meta_description'] ?? '' ) );
        if ( isset( $_POST['hts_content_lang'] ) ) {
            $allowed_langs = array( 'fr','en','es','de','it','pt','nl','ja','zh','ar','ru','ko','pl','sv','tr' );
            $lang = sanitize_text_field( $_POST['hts_content_lang'] );
            if ( in_array( $lang, $allowed_langs, true ) ) {
                $this->sm( $post_id, '_hts_content_lang', $lang );
            }
        }
        $this->sm( $post_id, '_hts_pillar', ! empty( $_POST['hts_pillar'] ) ? '1' : '' );
        $this->sm( $post_id, '_hts_og_title', sanitize_text_field( $_POST['hts_og_title'] ?? '' ) );
        $this->sm( $post_id, '_hts_og_description', sanitize_textarea_field( $_POST['hts_og_description'] ?? '' ) );
        $this->sm( $post_id, '_hts_og_image', esc_url_raw( $_POST['hts_og_image'] ?? '' ) );
        $this->sm( $post_id, '_hts_twitter_title', sanitize_text_field( $_POST['hts_twitter_title'] ?? '' ) );
        $this->sm( $post_id, '_hts_twitter_description', sanitize_textarea_field( $_POST['hts_twitter_description'] ?? '' ) );

        $robots = array();
        if ( ! empty( $_POST['hts_noindex'] ) ) $robots[] = 'noindex';
        if ( ! empty( $_POST['hts_nofollow'] ) ) $robots[] = 'nofollow';
        $this->sm( $post_id, '_hts_robots_meta', ! empty( $robots ) ? $robots : '' );
        $this->sm( $post_id, '_hts_canonical_url', esc_url_raw( $_POST['hts_canonical_url'] ?? '' ) );

        // Schema type: only save if explicitly submitted (avoid overwriting Schema Pro metabox in Gutenberg)
        if ( isset( $_POST['hts_schema_type'] ) && $_POST['hts_schema_type'] !== '' ) {
            $this->sm( $post_id, '_hts_schema_type', sanitize_text_field( $_POST['hts_schema_type'] ) );
        }

        // Slug: update post_name if user edited it in the SEO panel (skip front page)
        $is_front = ( (int) get_option( 'page_on_front' ) === $post_id && get_option( 'show_on_front' ) === 'page' );
        if ( ! empty( $_POST['hts_slug'] ) && ! $is_front ) {
            $new_slug = sanitize_title( $_POST['hts_slug'] );
            if ( $new_slug && $new_slug !== $post->post_name ) {
                // Use wp_unique_post_slug to avoid collisions
                $new_slug = wp_unique_post_slug( $new_slug, $post_id, $post->post_status, $post->post_type, $post->post_parent );
                global $wpdb;
                $wpdb->update( $wpdb->posts, array( 'post_name' => $new_slug ), array( 'ID' => $post_id ) );
                clean_post_cache( $post_id );
            }
        }

        // Compute & cache score for admin columns
        $a = $this->run_checks( $post_id );
        update_post_meta( $post_id, '_hts_combined_score', (int) $a['score'] );
    }

    private function sm( $id, $key, $val ) {
        if ( $val && $val !== 'auto' ) update_post_meta( $id, $key, $val );
        else delete_post_meta( $id, $key );
    }

    /* ══════════════════════════════════════════════
     *  AJAX
     * ══════════════════════════════════════════════ */

    public function ajax_score() {
        check_ajax_referer( 'hts_panel_score', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error();
        $pid = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $pid ) wp_send_json_error();

        // Live overrides from the editor (don't save to DB — that happens on post save)
        $overrides = array();
        if ( isset( $_POST['live_kw'] ) )         $overrides['kw']         = sanitize_text_field( $_POST['live_kw'] );
        if ( isset( $_POST['live_title'] ) )      $overrides['title']      = sanitize_text_field( $_POST['live_title'] );
        if ( isset( $_POST['live_desc'] ) )       $overrides['desc']       = sanitize_textarea_field( $_POST['live_desc'] );
        if ( isset( $_POST['live_slug'] ) )       $overrides['slug']       = sanitize_title( $_POST['live_slug'] );
        if ( isset( $_POST['live_post_title'] ) ) $overrides['post_title'] = sanitize_text_field( $_POST['live_post_title'] );
        if ( isset( $_POST['live_content'] ) )    $overrides['content']    = wp_kses_post( $_POST['live_content'] );

        $a = $this->run_checks( $pid, $overrides );

        // Only persist score to DB if no overrides (= manual "Analyser" click or post save)
        if ( empty( $overrides ) ) {
            update_post_meta( $pid, '_hts_combined_score', (int) $a['score'] );
        }

        ob_start(); $this->render_analysis( $a ); $html = ob_get_clean();

        wp_send_json_success( array(
            'score'     => $a['score'],
            'color'     => $this->color( $a['score'] ),
            'label'     => $this->label( $a['score'] ),
            'issues'    => $this->issue_count( $a ),
            'html'      => $html,
            'fixes'     => $this->render_fixes_html( $a ),
            'groups'    => isset( $a['groups'] ) ? $a['groups'] : array(),
            'top_fixes' => $this->top_fixes( $a, 3 ),
            'debug'     => isset( $a['debug'] ) ? array_merge( $a['debug'], array( 'penalty' => $a['penalty'] ?? 0 ) ) : array(),
        ) );
    }

    /* ══════════════════════════════════════════════
     *  ADMIN COLUMNS
     * ══════════════════════════════════════════════ */

    public function add_columns( $cols ) {
        $new = array();
        foreach ( $cols as $k => $v ) {
            $new[ $k ] = $v;
            if ( $k === 'title' ) { $new['hts_score'] = 'SEO'; $new['hts_kw'] = 'Mot-clé'; $new['hts_meta_title'] = 'Meta Title'; $new['hts_meta_desc'] = 'Meta Desc.'; }
        }
        return $new;
    }

    public function render_column( $col, $pid ) {
        if ( $col === 'hts_score' ) {
            $s = (int) get_post_meta( $pid, '_hts_combined_score', true );
            echo $s > 0
                ? '<span style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;font-size:11px;font-weight:700;color:#fff;background:' . esc_attr( $this->color( $s ) ) . '">' . $s . '</span>'
                : '<span style="color:#bbb">—</span>';
            /* Freshness badge masqué — trop anxiogène pour les clients, à réintroduire avec seuil plus intelligent
            $modified_ts = get_post_modified_time( 'U', false, $pid );
            if ( $modified_ts && ( time() - $modified_ts ) > ( 365 * DAY_IN_SECONDS ) ) {
                $months = round( ( time() - $modified_ts ) / ( 30 * DAY_IN_SECONDS ) );
                echo '<br><span title="Pas mis à jour depuis ' . esc_attr( $months ) . ' mois" style="...">Périmé</span>';
            }
            */
            // Scans IA badge (batched query, cached per request)
            $scans = $this->get_column_crawl_count( $pid );
            if ( $scans > 0 ) {
                echo '<br><span title="' . esc_attr( $scans ) . ' scan(s) robots ce mois" style="display:inline-block;margin-top:3px;background:#eff6ff;color:#2563eb;font-size:9px;font-weight:700;padding:2px 6px;border-radius:8px;line-height:1.3;">' . $scans . ' scan' . ( $scans > 1 ? 's' : '' ) . '</span>';
            }
        }
        if ( $col === 'hts_kw' ) {
            $kw = get_post_meta( $pid, '_hts_focus_keyword', true );
            echo $kw
                ? '<span style="background:#eff6ff;color:#2563eb;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600">' . esc_html( $kw ) . '</span>'
                : '<span style="color:#ccc">—</span>';
        }
        if ( $col === 'hts_meta_title' ) {
            $mt = get_post_meta( $pid, '_hts_meta_title', true );
            echo $mt ? '<span style="font-size:11px;color:#64748b">' . esc_html( mb_strimwidth( $mt, 0, 50, '…' ) ) . '</span>' : '<span style="color:#ccc">—</span>';
        }
        if ( $col === 'hts_meta_desc' ) {
            $md = get_post_meta( $pid, '_hts_meta_description', true );
            echo $md ? '<span style="font-size:11px;color:#64748b">' . esc_html( mb_strimwidth( $md, 0, 60, '…' ) ) . '</span>' : '<span style="color:#ccc">—</span>';
        }
    }

    /**
     * Get crawl count for a post in the last 30 days (batched, cached per request).
     */
    private function get_column_crawl_count( $pid ) {
        static $crawl_cache = null;
        if ( $crawl_cache === null ) {
            $crawl_cache = array();
            global $wpdb;
            $ct = $wpdb->prefix . 'hts_crawls';
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$ct}'" ) === $ct ) {
                $d30 = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT post_id, COUNT(*) AS cnt FROM {$ct}
                     WHERE crawled_at > %s GROUP BY post_id",
                    $d30
                ) );
                foreach ( $rows as $r ) { $crawl_cache[ (int) $r->post_id ] = (int) $r->cnt; }
            }
        }
        return $crawl_cache[ $pid ] ?? 0;
    }

    public function sortable_columns( $c ) { $c['hts_score'] = 'hts_score'; return $c; }

    public function sort_by_score( $q ) {
        if ( ! is_admin() || ! $q->is_main_query() ) return;
        if ( $q->get( 'orderby' ) === 'hts_score' ) { $q->set( 'meta_key', '_hts_combined_score' ); $q->set( 'orderby', 'meta_value_num' ); }

        // Score filter
        $filter = $_GET['hts_score_filter'] ?? '';
        if ( $filter && in_array( $filter, array( 'low', 'mid', 'high', 'none' ), true ) ) {
            $mq = $q->get( 'meta_query' ) ?: array();
            if ( $filter === 'none' ) {
                $mq[] = array( 'key' => '_hts_combined_score', 'compare' => 'NOT EXISTS' );
            } elseif ( $filter === 'low' ) {
                $mq[] = array( 'key' => '_hts_combined_score', 'value' => 50, 'compare' => '<', 'type' => 'NUMERIC' );
            } elseif ( $filter === 'mid' ) {
                $mq[] = array( 'key' => '_hts_combined_score', 'value' => array( 50, 79 ), 'compare' => 'BETWEEN', 'type' => 'NUMERIC' );
            } elseif ( $filter === 'high' ) {
                $mq[] = array( 'key' => '_hts_combined_score', 'value' => 80, 'compare' => '>=', 'type' => 'NUMERIC' );
            }
            $q->set( 'meta_query', $mq );
        }
    }

    public function score_filter_dropdown( $post_type ) {
        if ( ! in_array( $post_type, get_post_types( array( 'public' => true ), 'names' ), true ) ) return;
        $current = $_GET['hts_score_filter'] ?? '';
        ?>
        <select name="hts_score_filter" style="max-width:160px;">
            <option value="">Score SEO</option>
            <option value="high" <?php selected( $current, 'high' ); ?>>Score ≥ 80</option>
            <option value="mid" <?php selected( $current, 'mid' ); ?>>Score 50–79</option>
            <option value="low" <?php selected( $current, 'low' ); ?>>Score &lt; 50</option>
            <option value="none" <?php selected( $current, 'none' ); ?>>Sans score</option>
        </select>
        <?php
    }

    public function column_css() {
        $s = get_current_screen(); if ( ! $s || $s->base !== 'edit' ) return;
        echo '<style>.column-hts_score{width:50px;text-align:center}.column-hts_kw{width:140px}</style>';
    }

    /* ══════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════ */

    private function get_post_data( $post ) {
        $mt = class_exists( 'HTS_Meta_Tags' ) ? new HTS_Meta_Tags() : null;
        $title = get_post_meta( $post->ID, '_hts_meta_title', true );
        $desc  = get_post_meta( $post->ID, '_hts_meta_description', true );
        $sep   = get_option( 'hts_title_separator', '—' );

        $pt = $title;
        if ( ! $pt && $mt ) $pt = $mt->get_meta_title( $post->ID );
        if ( ! $pt ) $pt = $post->post_title . ' ' . $sep . ' ' . get_bloginfo( 'name' );

        $pd = $desc;
        if ( ! $pd && $mt ) $pd = $mt->get_meta_description( $post->ID );
        if ( ! $pd ) $pd = wp_trim_words( wp_strip_all_tags( $post->post_content ), 25, '…' );

        return array(
            'meta_title' => $title, 'meta_desc' => $desc, 'preview_title' => $pt, 'preview_desc' => $pd,
            'focus_kw' => get_post_meta( $post->ID, '_hts_focus_keyword', true )
                ?: get_post_meta( $post->ID, '_hts_api_keyword', true )
                ?: get_post_meta( $post->ID, 'rank_math_focus_keyword', true )
                ?: get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true )
                ?: get_post_meta( $post->ID, '_hts_gsc_top_query', true ),
            'pillar' => get_post_meta( $post->ID, '_hts_pillar', true ),
            'robots' => $this->get_robots_string( $post->ID ),
            'canonical' => get_post_meta( $post->ID, '_hts_canonical_url', true ),
            'og_title' => get_post_meta( $post->ID, '_hts_og_title', true ),
            'og_desc' => get_post_meta( $post->ID, '_hts_og_description', true ),
            'og_image' => get_post_meta( $post->ID, '_hts_og_image', true ),
            'tw_title' => get_post_meta( $post->ID, '_hts_twitter_title', true ),
            'tw_desc' => get_post_meta( $post->ID, '_hts_twitter_description', true ),
        );
    }

    private function get_robots_string( $post_id ) {
        $val = get_post_meta( $post_id, '_hts_robots_meta', true );
        if ( is_array( $val ) ) return implode( ',', $val );
        if ( is_string( $val ) ) return $val;
        return '';
    }

    /**
     * Check if the block editor is active for this post.
     * Returns false if Classic Editor plugin forces classic mode.
     */
    private function is_block_editor_active( $post ) {
        // Classic Editor plugin: ?classic-editor in URL
        if ( isset( $_GET['classic-editor'] ) || isset( $_GET['classic-editor__forget'] ) ) return false;

        // Classic Editor plugin option: "replace" = always classic
        if ( get_option( 'classic-editor-replace', 'no-replace' ) === 'replace' ) return false;

        // WP 5.0+ native check
        if ( $post && function_exists( 'use_block_editor_for_post' ) ) {
            return use_block_editor_for_post( $post );
        }

        // Screen check (may not be available at enqueue time)
        $screen = get_current_screen();
        if ( $screen && method_exists( $screen, 'is_block_editor' ) ) {
            return $screen->is_block_editor();
        }

        return true;
    }

    private function issue_count( $a ) {
        $c = 0;
        foreach ( $a['groups'] as $g ) { foreach ( $g['checks'] as $ch ) { if ( $ch['status'] !== 'ok' ) $c++; } }
        return $c;
    }

    /**
     * Get the N most impactful failing checks (fail first, then warn, sorted by lost points).
     */
    private function top_fixes( $a, $n = 3 ) {
        $items = array();
        // Weight multiplier per group
        $weights = array( 'seo_base' => 5, 'content' => 3, 'geo' => 2, 'meta' => 1.5, 'readability' => 0.5 );
        foreach ( $a['groups'] as $gk => $g ) {
            $w = $weights[ $gk ] ?? 1;
            foreach ( $g['checks'] as $c ) {
                if ( $c['status'] === 'ok' ) continue;
                $lost = ( $c['max'] - $c['points'] ) * $w;
                $items[] = array( 'status' => $c['status'], 'text' => $c['text'], 'fix' => isset( $c['fix'] ) ? $c['fix'] : '', 'lost' => $lost );
            }
        }
        // Sort: fail first, then by lost points desc
        usort( $items, function( $a, $b ) {
            if ( $a['status'] !== $b['status'] ) return $a['status'] === 'fail' ? -1 : 1;
            return $b['lost'] - $a['lost'];
        });
        return array_slice( $items, 0, $n );
    }

    private function render_fixes_html( $a ) {
        $fixes = $this->top_fixes( $a, 3 );
        if ( empty( $fixes ) ) return '';
        $html = '';
        foreach ( $fixes as $f ) {
            $allowed_check_tags = array('a' => array('href' => true, 'target' => true, 'style' => true));
            $html .= '<div class="hp-fix ' . esc_attr( $f['status'] ) . '"><span class="hp-fix-dot"></span>' . wp_kses( $f['text'], $allowed_check_tags ) . '</div>';
        }
        return $html;
    }

    private function color( $s ) { return $s >= 80 ? '#16a34a' : ( $s >= 50 ? '#d97706' : '#dc2626' ); }

    private function label( $s ) {
        if ( $s >= 80 ) return 'Excellent';
        if ( $s >= 60 ) return 'Bon — quelques améliorations possibles';
        if ( $s >= 40 ) return 'Moyen — optimisation recommandée';
        return 'Faible — action requise';
    }

    private function short_url( $u ) {
        $u = str_replace( array( 'https://', 'http://', 'www.' ), '', $u );
        return strlen( $u ) > 55 ? substr( $u, 0, 52 ) . '...' : $u;
    }

    private function schema_types() {
        return array(
            'auto' => 'Auto-détection (recommandé)', 'Article' => 'Article', 'BlogPosting' => 'BlogPosting',
            'NewsArticle' => 'NewsArticle', 'WebPage' => 'WebPage', 'FAQPage' => 'FAQPage',
            'HowTo' => 'HowTo / Tutoriel', 'Product' => 'Produit', 'Recipe' => 'Recette',
            'Event' => 'Évènement', 'JobPosting' => 'Offre d\'emploi', 'Course' => 'Cours / Formation',
            'Book' => 'Livre', 'Person' => 'Personne', 'Service' => 'Service',
            'SoftwareApplication' => 'Logiciel', 'Restaurant' => 'Restaurant',
            'LocalBusiness' => 'Commerce local', 'MusicGroup' => 'Musique', 'VideoObject' => 'Vidéo',
        );
    }
}
