<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Audit Trail — Phase 3 (Light)
 *
 * Logs every content modification (metas, links, images, content) with
 * before/after snapshots, optional GSC data at action time, and rollback capability.
 *
 * Ported from Full v4.0.0, adapted for Light:
 * - All Full-only dependencies (Feedback Loop, Content Doctor, Engagement Tracker)
 *   are guarded by class_exists() — graceful degradation.
 * - No images_generated / DALL-E logging (Full only).
 * - Seed test data simplified (no GSC dependency required).
 *
 * Table: {prefix}_hts_actions
 * Purge: 90 days via daily cron
 *
 * @since 1.15.0
 */

class HTS_Audit_Trail {

    const TABLE_SUFFIX   = 'hts_actions';
    const PURGE_DAYS     = 90;
    const TABLE_VERSION  = 3;

    /* ──────────────────────────────────────────────
     *  INIT
     * ────────────────────────────────────────────── */

    public function init() {
        // Auto-create/migrate table if needed
        add_action( 'admin_init', array( __CLASS__, 'maybe_create_table' ) );

        // AJAX endpoints
        add_action( 'wp_ajax_hts_audit_get_log',    array( $this, 'ajax_get_log' ) );
        add_action( 'wp_ajax_hts_audit_rollback',    array( $this, 'ajax_rollback' ) );
        add_action( 'wp_ajax_hts_audit_get_diff',    array( $this, 'ajax_get_diff' ) );
        add_action( 'wp_ajax_hts_audit_get_stats',   array( $this, 'ajax_get_stats' ) );
        add_action( 'wp_ajax_hts_audit_test_write',  array( $this, 'ajax_test_write' ) );

        // Daily purge cron
        add_action( 'hts_audit_purge_cron', array( $this, 'purge_old_entries' ) );
        if ( ! wp_next_scheduled( 'hts_audit_purge_cron' ) ) {
            wp_schedule_event( time(), 'daily', 'hts_audit_purge_cron' );
        }

        // Native WP publish tracking (covers manual publish from WP editor)
        add_action( 'transition_post_status', array( $this, 'on_post_publish' ), 10, 3 );
    }

    /**
     * Track native WP draft→publish transitions.
     */
    public function on_post_publish( $new_status, $old_status, $post ) {
        if ( $new_status !== 'publish' || $old_status === 'publish' ) return;
        if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) return;

        // Avoid double-logging when publish comes from our own AJAX
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            $action = $_POST['action'] ?? '';
            if ( in_array( $action, array( 'hts_draft_publish', 'hts_api_publish' ), true ) ) return;
        }

        self::log_article_published( $post->ID, array(
            'source'     => 'wp_native',
            'old_status' => $old_status,
            'url'        => get_permalink( $post->ID ),
        ) );
    }

    /* ──────────────────────────────────────────────
     *  TABLE MANAGEMENT
     * ────────────────────────────────────────────── */

    /**
     * Auto-create table if it doesn't exist. Also ensures columns are up to date.
     */
    public static function maybe_create_table() {
        $version_key     = 'hts_audit_table_version';
        $stored_version  = (int) get_option( $version_key, 0 );

        if ( $stored_version >= self::TABLE_VERSION ) return;

        global $wpdb;
        $table  = $wpdb->prefix . self::TABLE_SUFFIX;
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );

        if ( ! $exists ) {
            self::create_table();
        } else {
            // Ensure all columns exist (migration)
            $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$table}" );
            if ( ! in_array( 'impact_7d', $cols, true ) ) {
                $wpdb->query( "ALTER TABLE {$table} ADD COLUMN impact_7d TEXT NULL AFTER gsc_data" );
            }
            if ( ! in_array( 'impact_30d', $cols, true ) ) {
                $wpdb->query( "ALTER TABLE {$table} ADD COLUMN impact_30d TEXT NULL AFTER impact_7d" );
            }
            if ( ! in_array( 'extra', $cols, true ) ) {
                $wpdb->query( "ALTER TABLE {$table} ADD COLUMN extra TEXT NULL AFTER user_id" );
            }
        }

        update_option( $version_key, self::TABLE_VERSION, false );
    }

    /**
     * Create the hts_actions table.
     */
    public static function create_table() {
        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE_SUFFIX;
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id              BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            action_type     VARCHAR(50)  NOT NULL DEFAULT '',
            post_id         BIGINT(20)   UNSIGNED NOT NULL DEFAULT 0,
            target_id       BIGINT(20)   UNSIGNED NOT NULL DEFAULT 0,
            anchor_text     VARCHAR(500) NOT NULL DEFAULT '',
            direction       VARCHAR(20)  NOT NULL DEFAULT '',
            snapshot_before LONGTEXT     NULL,
            snapshot_after  LONGTEXT     NULL,
            gsc_data        TEXT         NULL,
            impact_7d       TEXT         NULL,
            impact_30d      TEXT         NULL,
            user_id         BIGINT(20)   UNSIGNED NOT NULL DEFAULT 0,
            extra           TEXT         NULL,
            created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_post      (post_id),
            INDEX idx_type      (action_type),
            INDEX idx_created   (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /* ──────────────────────────────────────────────
     *  LOGGING METHODS
     * ────────────────────────────────────────────── */

    /**
     * Generic log entry.
     *
     * @param string $action_type  The action type identifier.
     * @param array  $data         Log data (post_id, target_id, anchor_text, direction, snapshots, etc.).
     * @return int|false           Insert ID or false on failure.
     */
    public static function log( $action_type, $data = array() ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // Auto-create/migrate table on first call per request
        static $table_ready = false;
        if ( ! $table_ready ) {
            $table_ready = true;
            $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
            if ( ! $exists ) {
                self::create_table();
            }
        }

        $row = array(
            'action_type'     => sanitize_text_field( $action_type ),
            'post_id'         => absint( $data['post_id'] ?? 0 ),
            'target_id'       => absint( $data['target_id'] ?? 0 ),
            'anchor_text'     => mb_substr( sanitize_text_field( $data['anchor_text'] ?? '' ), 0, 500 ),
            'direction'       => sanitize_text_field( $data['direction'] ?? '' ),
            'snapshot_before' => $data['snapshot_before'] ?? null,
            'snapshot_after'  => $data['snapshot_after'] ?? null,
            'gsc_data'        => isset( $data['gsc_data'] ) ? wp_json_encode( $data['gsc_data'] ) : null,
            'impact_7d'       => null,
            'impact_30d'      => null,
            'user_id'         => get_current_user_id(),
            'extra'           => isset( $data['extra'] ) ? wp_json_encode( $data['extra'] ) : null,
            'created_at'      => current_time( 'mysql' ),
        );
        $formats = array( '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' );

        $result = $wpdb->insert( $table, $row, $formats );

        // Fallback: minimal insert if full insert failed (schema migration edge case)
        if ( $result === false ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Audit Trail insert failed: ' . $wpdb->last_error . ' | action=' . $action_type, 'warning', 'audit' );
            }
            $minimal = array(
                'action_type'     => $row['action_type'],
                'post_id'         => $row['post_id'],
                'target_id'       => $row['target_id'],
                'anchor_text'     => $row['anchor_text'],
                'direction'       => $row['direction'],
                'snapshot_before' => $row['snapshot_before'],
                'snapshot_after'  => $row['snapshot_after'],
                'user_id'         => $row['user_id'],
                'created_at'      => $row['created_at'],
            );
            $result = $wpdb->insert( $table, $minimal, array( '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s' ) );
            if ( $result === false ) {
                if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                    hts_debug_log( '[Audit Trail] Minimal insert also failed: ' . $wpdb->last_error );
                }
            }
        }

        return $wpdb->insert_id;
    }

    /**
     * Log a link insertion (outbound or inbound).
     */
    public static function log_link( $post_id, $target_id, $anchor, $direction, $content_before, $content_after, $gsc_data = array() ) {
        $insert_id = self::log( 'link_' . $direction, array(
            'post_id'         => $post_id,
            'target_id'       => $target_id,
            'anchor_text'     => $anchor,
            'direction'       => $direction,
            'snapshot_before' => $content_before,
            'snapshot_after'  => $content_after,
            'gsc_data'        => $gsc_data,
        ) );

        // Sprint Robustesse v2: store TARGET's GSC baseline for smart attribution
        // The feedback loop will compare this to target's GSC later to measure link impact
        if ( $insert_id && $target_id > 0 ) {
            $target_gsc = self::get_gsc_snapshot( $target_id );
            if ( $target_gsc ) {
                update_post_meta( $target_id, '_hts_gsc_at_link_' . $insert_id, $target_gsc );
            }
        }

        return $insert_id;
    }

    /**
     * Log a link removal.
     */
    public static function log_link_removed( $post_id, $target_url, $content_before, $content_after ) {
        return self::log( 'link_removed', array(
            'post_id'         => $post_id,
            'anchor_text'     => $target_url,
            'direction'       => 'removed',
            'snapshot_before' => $content_before,
            'snapshot_after'  => $content_after,
        ) );
    }

    /**
     * v2.4.16: Get all target_ids that HTS has applied links to from a given source.
     * This is the "memory" — even if the link was later removed from post_content
     * (e.g. user saved in Gutenberg), we still know HTS applied it.
     *
     * @param int $source_id  The source post ID.
     * @return array  Array of arrays: [ ['target_id' => int, 'anchor' => string, 'date' => string], ... ]
     */
    public static function get_applied_targets( $source_id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( ! $exists ) return array();

        // Get the most recent link application per source→target pair
        // action_type = 'link_outbound' from Cocon bulk apply
        // action_type = 'link_manual' from Inbox/Workflow execute via Internal Linking
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT target_id, anchor_text, created_at
             FROM {$table}
             WHERE post_id = %d
               AND action_type IN ('link_outbound', 'link_manual')
               AND target_id > 0
             ORDER BY created_at DESC",
            $source_id
        ), ARRAY_A );

        if ( ! $rows ) return array();

        // Deduplicate: keep most recent per target_id
        $seen = array();
        $result = array();
        foreach ( $rows as $row ) {
            $tid = (int) $row['target_id'];
            if ( isset( $seen[ $tid ] ) ) continue;
            $seen[ $tid ] = true;
            $result[] = array(
                'target_id' => $tid,
                'anchor'    => $row['anchor_text'],
                'date'      => $row['created_at'],
            );
        }

        return $result;
    }

    /**
     * Log an article creation.
     */
    public static function log_article_created( $post_id, $title, $keyword, $extra = array() ) {
        return self::log( 'article_created', array(
            'post_id'     => $post_id,
            'anchor_text' => mb_substr( $title, 0, 500 ),
            'direction'   => 'created',
            'extra'       => array_merge( array(
                'keyword' => $keyword,
                'title'   => $title,
            ), $extra ),
        ) );
    }

    /**
     * Log an article publication (draft → publish).
     */
    public static function log_article_published( $post_id, $extra = array() ) {
        $gsc = self::get_gsc_snapshot( $post_id );
        return self::log( 'article_published', array(
            'post_id'     => $post_id,
            'anchor_text' => mb_substr( get_the_title( $post_id ), 0, 500 ),
            'direction'   => 'published',
            'gsc_data'    => $gsc,
            'extra'       => $extra,
        ) );
    }

    /**
     * Log a generic content modification (meta change, schema injection, etc.).
     */
    public static function log_content_modified( $post_id, $modification_type, $content_before, $content_after, $extra = array() ) {
        return self::log( 'content_modified', array(
            'post_id'         => $post_id,
            'anchor_text'     => $modification_type,
            'direction'       => 'modified',
            'snapshot_before' => $content_before,
            'snapshot_after'  => $content_after,
            'gsc_data'        => self::get_gsc_snapshot( $post_id ),
            'extra'           => $extra,
        ) );
    }

    /* ──────────────────────────────────────────────
     *  ROLLBACK
     * ────────────────────────────────────────────── */

    /**
     * Rollback a specific action by restoring snapshot_before.
     *
     * @param int $action_id  ID in hts_actions table.
     * @return array           { success, message }
     */
    public static function rollback( $action_id ) {
        global $wpdb;
        $table  = $wpdb->prefix . self::TABLE_SUFFIX;
        $action = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $action_id ), ARRAY_A );

        if ( ! $action ) {
            return array( 'success' => false, 'message' => 'Action introuvable.' );
        }

        if ( empty( $action['snapshot_before'] ) ) {
            return array( 'success' => false, 'message' => 'Pas de snapshot disponible pour le rollback.' );
        }

        $post_id = absint( $action['post_id'] );
        $post    = get_post( $post_id );
        if ( ! $post ) {
            return array( 'success' => false, 'message' => 'Article #' . $post_id . ' introuvable.' );
        }

        // Save current content as "before rollback"
        $current_content = $post->post_content;

        // Restore
        $result = wp_update_post( array(
            'ID'           => $post_id,
            'post_content' => $action['snapshot_before'],
        ) );

        if ( is_wp_error( $result ) ) {
            return array( 'success' => false, 'message' => $result->get_error_message() );
        }

        // Log the rollback itself
        self::log( 'rollback', array(
            'post_id'         => $post_id,
            'target_id'       => $action_id,
            'snapshot_before' => $current_content,
            'snapshot_after'  => $action['snapshot_before'],
            'extra'           => array( 'original_action_id' => $action_id, 'original_type' => $action['action_type'] ),
        ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( '↩️ Rollback action #' . $action_id . ' sur article #' . $post_id, 'info', 'audit' );
        }

        return array( 'success' => true, 'message' => 'Contenu restauré pour l\'article #' . $post_id . '.' );
    }

    /* ──────────────────────────────────────────────
     *  QUERIES
     * ────────────────────────────────────────────── */

    /**
     * Get action log with filters.
     */
    public static function get_actions( $args = array() ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // Check table exists
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            return array( 'items' => array(), 'total' => 0 );
        }

        $defaults = array(
            'per_page'    => 20,
            'page'        => 1,
            'action_type' => '',
            'post_id'     => 0,
            'search'      => '',
            'order'       => 'DESC',
        );
        $args = wp_parse_args( $args, $defaults );

        $where  = array( '1=1' );
        $values = array();

        if ( ! empty( $args['action_type'] ) ) {
            $where[]  = 'action_type = %s';
            $values[] = $args['action_type'];
        }
        if ( $args['post_id'] > 0 ) {
            $where[]  = '(post_id = %d OR target_id = %d)';
            $values[] = $args['post_id'];
            $values[] = $args['post_id'];
        }
        if ( ! empty( $args['search'] ) ) {
            $where[]  = 'anchor_text LIKE %s';
            $values[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
        }

        $where_sql = implode( ' AND ', $where );
        $order     = $args['order'] === 'ASC' ? 'ASC' : 'DESC';
        $offset    = max( 0, ( $args['page'] - 1 ) * $args['per_page'] );

        // Total count
        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        $total     = empty( $values )
            ? (int) $wpdb->get_var( $count_sql )
            : (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) );

        // Items
        $query      = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY created_at {$order} LIMIT %d OFFSET %d";
        $all_values = array_merge( $values, array( $args['per_page'], $offset ) );
        $items      = $wpdb->get_results( $wpdb->prepare( $query, $all_values ), ARRAY_A );

        // Enrich with post titles
        foreach ( $items as &$item ) {
            $item['post_title']     = $item['post_id'] ? get_the_title( $item['post_id'] ) : '';
            $item['target_title']   = $item['target_id'] ? get_the_title( $item['target_id'] ) : '';
            $item['edit_url']       = $item['post_id'] ? get_edit_post_link( $item['post_id'], 'raw' ) : '';
            $item['has_snapshot']   = ! empty( $item['snapshot_before'] );
            $item['gsc_data']       = $item['gsc_data'] ? json_decode( $item['gsc_data'], true ) : null;
            $item['extra']          = $item['extra'] ? json_decode( $item['extra'], true ) : null;
            $item['impact_7d']      = $item['impact_7d'] ? json_decode( $item['impact_7d'], true ) : null;
            $item['impact_30d']     = $item['impact_30d'] ? json_decode( $item['impact_30d'], true ) : null;
            $best_impact            = $item['impact_30d'] ?? $item['impact_7d'];
            $item['impact_verdict'] = $best_impact ? ( $best_impact['verdict'] ?? null ) : null;
            // Don't send full snapshots in list — too heavy
            unset( $item['snapshot_before'], $item['snapshot_after'] );
        }

        return array( 'items' => $items, 'total' => $total );
    }

    /**
     * Aggregate stats for the dashboard header.
     */
    public static function get_stats() {
        // Request-level cache
        static $cached = null;
        if ( $cached !== null ) return $cached;

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        $empty = array( 'total' => 0, 'links_out' => 0, 'links_in' => 0, 'articles' => 0, 'published' => 0, 'content_mods' => 0, 'rollbacks' => 0, 'last_7d' => 0 );

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            $cached = $empty;
            return $cached;
        }

        // Single query with conditional counts (8 queries → 1)
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total,
                    SUM(action_type = 'link_outbound') AS links_out,
                    SUM(action_type = 'link_inbound') AS links_in,
                    SUM(action_type = 'article_created') AS articles,
                    SUM(action_type = 'article_published') AS published,
                    SUM(action_type = 'content_modified') AS content_mods,
                    SUM(action_type = 'rollback') AS rollbacks,
                    SUM(created_at >= %s) AS last_7d
             FROM {$table}",
            wp_date( 'Y-m-d H:i:s', strtotime( '-7 days' ) )
        ), ARRAY_A );

        $cached = array(
            'total'        => (int) ( $row['total'] ?? 0 ),
            'links_out'    => (int) ( $row['links_out'] ?? 0 ),
            'links_in'     => (int) ( $row['links_in'] ?? 0 ),
            'articles'     => (int) ( $row['articles'] ?? 0 ),
            'published'    => (int) ( $row['published'] ?? 0 ),
            'content_mods' => (int) ( $row['content_mods'] ?? 0 ),
            'rollbacks'    => (int) ( $row['rollbacks'] ?? 0 ),
            'last_7d'      => (int) ( $row['last_7d'] ?? 0 ),
        );
        return $cached;
    }

    /**
     * Get actions for a specific post (for SEO Panel integration).
     *
     * @param int $post_id
     * @param int $limit
     * @return array
     */
    public static function get_post_history( $post_id, $limit = 10 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            return array();
        }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, action_type, anchor_text, direction, created_at, user_id,
                    (snapshot_before IS NOT NULL AND snapshot_before != '') as has_snapshot
             FROM {$table}
             WHERE post_id = %d
             ORDER BY created_at DESC
             LIMIT %d",
            $post_id, $limit
        ), ARRAY_A );

        foreach ( $rows as &$r ) {
            $r['label'] = self::action_label( $r['action_type'] );
        }

        return $rows;
    }

    /* ──────────────────────────────────────────────
     *  AJAX HANDLERS
     * ────────────────────────────────────────────── */

    public function ajax_get_log() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $result = self::get_actions( array(
            'per_page'    => absint( $_POST['per_page'] ?? 20 ),
            'page'        => absint( $_POST['page'] ?? 1 ),
            'action_type' => sanitize_text_field( $_POST['action_type'] ?? '' ),
            'post_id'     => absint( $_POST['post_id'] ?? 0 ),
            'search'      => sanitize_text_field( $_POST['search'] ?? '' ),
        ) );

        wp_send_json_success( $result );
    }

    public function ajax_rollback() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $action_id = absint( $_POST['action_id'] ?? 0 );
        if ( ! $action_id ) wp_send_json_error( 'ID action manquant.' );

        $result = self::rollback( $action_id );
        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    public function ajax_get_diff() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        global $wpdb;
        $table     = $wpdb->prefix . self::TABLE_SUFFIX;
        $action_id = absint( $_POST['action_id'] ?? 0 );

        $action = $wpdb->get_row( $wpdb->prepare(
            "SELECT snapshot_before, snapshot_after, action_type, post_id, anchor_text, created_at FROM {$table} WHERE id = %d",
            $action_id
        ), ARRAY_A );

        if ( ! $action ) wp_send_json_error( 'Action introuvable.' );

        wp_send_json_success( array(
            'before'      => $action['snapshot_before'] ?? '',
            'after'       => $action['snapshot_after'] ?? '',
            'action_type' => $action['action_type'],
            'post_id'     => $action['post_id'],
            'post_title'  => get_the_title( $action['post_id'] ),
            'anchor_text' => $action['anchor_text'],
            'created_at'  => $action['created_at'],
        ) );
    }

    public function ajax_get_stats() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        wp_send_json_success( self::get_stats() );
    }

    /**
     * Diagnostic: test write to audit trail table.
     */
    public function ajax_test_write() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // Check table exists
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( ! $exists ) {
            self::create_table();
            $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        }

        // Get columns
        $cols = $exists ? $wpdb->get_col( "SHOW COLUMNS FROM {$table}" ) : array();

        // Try a test insert
        $id = self::log( 'test_diagnostic', array(
            'post_id'     => 0,
            'anchor_text' => 'Test write ' . current_time( 'H:i:s' ),
            'direction'   => 'test',
            'extra'       => array( 'source' => 'diagnostic' ),
        ) );

        // Count total rows
        $count = $exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) : 0;

        // Clean up test entry
        if ( $id ) {
            $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
        }

        wp_send_json_success( array(
            'table_exists' => (bool) $exists,
            'columns'      => $cols,
            'test_insert'  => $id ? 'OK (id=' . $id . ')' : 'FAILED: ' . $wpdb->last_error,
            'total_rows'   => $count,
            'last_error'   => $wpdb->last_error,
        ) );
    }

    /* ──────────────────────────────────────────────
     *  PURGE (cron daily)
     * ────────────────────────────────────────────── */

    public function purge_old_entries() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return;

        $deleted = $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE created_at < %s",
            wp_date( 'Y-m-d H:i:s', strtotime( '-' . self::PURGE_DAYS . ' days' ) )
        ) );

        if ( $deleted > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Audit Trail: ' . $deleted . ' entrées purgées (>' . self::PURGE_DAYS . 'j)', 'info', 'audit' );
        }
    }

    /* ──────────────────────────────────────────────
     *  HELPERS
     * ────────────────────────────────────────────── */

    /**
     * Grab current GSC data for a post (if available).
     */
    public static function get_gsc_snapshot( $post_id ) {
        $clicks      = (int) get_post_meta( $post_id, '_hts_gsc_clicks', true );
        $impressions = (int) get_post_meta( $post_id, '_hts_gsc_impressions', true );
        $position    = (float) get_post_meta( $post_id, '_hts_gsc_position', true );

        // Always return data — even zero-traffic pages need a baseline for feedback loop
        return array(
            'clicks'      => $clicks,
            'impressions' => $impressions,
            'position'    => $position,
            'captured_at' => current_time( 'mysql' ),
        );
    }

    /**
     * Label for display — simplified for Light (no DALL-E / images_generated).
     */
    public static function action_label( $type ) {
        $labels = array(
            'link_outbound'     => '🔗 Lien sortant',
            'link_inbound'      => '🔗 Lien entrant',
            'link_manual'       => '🔗 Lien manuel',
            'link_removed'      => 'Lien supprimé',
            'article_created'   => 'Article créé',
            'article_published' => 'Article publié',
            'content_modified'  => '✏️ Contenu modifié',
            'rollback'          => '↩️ Rollback',
            'meta_auto_pilot'   => '🤖 Meta auto-pilot',
            'meta_rollback'     => '↩️ Rollback meta',
            'test_diagnostic'   => '🧪 Test diagnostic',
        );
        return $labels[ $type ] ?? $type;
    }
}
