<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * HTS Analytics — S5 v4 Rewrite (maquette-fidèle)
 * Design System v5.7 — 0 emoji, 0 hex (sauf brand), 100% tokens
 * Source de vérité : hts-analytics-s5-v4.jsx
 * @since 2.6.0
 */
if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Accès refusé' );
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}

// ── Data (30 days server-side, no AJAX on first load) ──
$tracker = new HTS_Impact_Tracker();
$data    = $tracker->get_analytics_data( 30 );

$engagement   = $data['engagement'];
$ai_total     = $data['ai_total'];
$ai_trend     = $data['ai_trend'];
$ai_sources   = $data['ai_sources'];
$top_articles = $data['top_articles'];
$top_engaged  = $data['top_engaged'];
$daily        = $data['daily'];
$stale_posts  = $data['stale_posts'];
$crawl        = $data['crawl'];
$gsc_data     = $data['gsc'];
$crawl_insights = $tracker->get_crawl_insights();

// ── Pad daily to exactly 30 days (fill missing days with 0) ──
$padded = array();
for ( $i = 29; $i >= 0; $i-- ) {
	$key = gmdate( 'Y-m-d', strtotime( "-{$i} days" ) );
	$padded[ $key ] = array( 'day' => $key, 'total' => 0, 'ai' => 0 );
}
if ( ! empty( $daily ) ) {
	foreach ( $daily as $dd ) {
		if ( isset( $padded[ $dd['day'] ] ) ) {
			$padded[ $dd['day'] ] = $dd;
		}
	}
}
$daily = array_values( $padded );
$data['daily'] = $daily; // update for JSON seed

// ── Merge GSC daily clicks into chart data ──
if ( ! empty( $gsc_data['daily'] ) ) {
	$gsc_map = array();
	foreach ( $gsc_data['daily'] as $gd ) {
		$gd = is_object( $gd ) ? (array) $gd : $gd;
		$date_key = $gd['fetch_date'] ?? ( $gd['date'] ?? '' );
		if ( $date_key ) $gsc_map[ $date_key ] = (int) ( $gd['clicks'] ?? 0 );
	}
	foreach ( $daily as &$dd ) {
		$dd['gsc_clicks'] = $gsc_map[ $dd['day'] ] ?? 0;
	}
	unset( $dd );
} else {
	foreach ( $daily as &$dd ) {
		$dd['gsc_clicks'] = 0;
	}
	unset( $dd );
}

// ── Workflow stats for Hero KPI #4 "Actions positives" ──
$wf_stats = array( 'approved' => 0, 'done' => 0, 'executing' => 0, 'rejected' => 0, 'dismissed' => 0, 'failed' => 0 );
if ( class_exists( 'HTS_Workflow_Engine' ) ) {
	$wf_raw = HTS_Workflow_Engine::get_stats( 30 );
	$wf_stats = array_merge( $wf_stats, $wf_raw );
}
$wf_positive = ( $wf_stats['approved'] ?? 0 ) + ( $wf_stats['done'] ?? 0 ) + ( $wf_stats['executing'] ?? 0 );
$wf_measured = $wf_positive + ( $wf_stats['rejected'] ?? 0 ) + ( $wf_stats['dismissed'] ?? 0 ) + ( $wf_stats['failed'] ?? 0 );
$wf_rate = $wf_measured > 0 ? round( $wf_positive / $wf_measured * 100 ) : 0;

// GSC fallback
$gsc_connected = ( $gsc_data !== null );
if ( ! $gsc_connected ) {
	$gsc_data = array( 'clicks' => 0, 'impressions' => 0, 'avg_position' => 0, 'avg_ctr' => 0, 'clicks_trend' => 0, 'position_trend' => 0, 'top_pages' => array() );
}

// Brand colors (intentional hex — brand identity)
$src_colors = array(
	'chatgpt'    => '#10A37F',
	'claude'     => '#D97757',
	'perplexity' => '#20B8CD',
	'meta_ai'    => '#0866FF',
	'meta'       => '#0866FF',
	'gemini'     => '#4285F4',
	'copilot'    => '#7C3AED',
	'you'        => '#F97316',
	'phind'      => '#16A34A',
);

// ── Phase 4B: Shared helpers (ai_brands, logos, sparklines, fmt_time) ──
include_once __DIR__ . '/_helpers.php';

// ── Pre-compute data for chart sparklines ──
$gsc_spark = array();
if ( ! empty( $gsc_data['daily'] ) ) {
	// Use real GSC daily clicks for Google sparkline
	foreach ( $gsc_data['daily'] as $gd ) {
		$gd = is_object( $gd ) ? (array) $gd : $gd;
		$gsc_spark[] = (int) ( $gd['clicks'] ?? 0 );
	}
} elseif ( ! empty( $daily ) ) {
	// Fallback: total visits (non-AI portion)
	$gsc_spark = array_map( function( $d ) { return max( 0, $d['total'] - $d['ai'] ); }, $daily );
}
$ai_spark  = ! empty( $daily ) ? array_column( $daily, 'ai' ) : array();

// ── Robots data pre-compute ──
$ai_bots_data = $seo_bots_data = array();
if ( ! empty( $crawl['bot_sources'] ) ) {
	foreach ( $crawl['bot_sources'] as $slug => $info ) {
		$cat = $info['category'] ?? HTS_Impact_Tracker::bot_category( $slug );
		if ( $cat === 'seo' ) { $seo_bots_data[ $slug ] = $info; }
		else { $ai_bots_data[ $slug ] = $info; }
	}
}
$all_bots = array_merge( $ai_bots_data, $seo_bots_data );
$max_bot = ! empty( $all_bots ) ? max( array_column( $all_bots, 'count' ) ) : 1;
$cat_ai  = $crawl['cat_totals']['ai'] ?? 0;
$cat_seo = $crawl['cat_totals']['seo'] ?? 0;
$cat_total = $cat_ai + $cat_seo;

// Position trend formatting
$pos_trend_val = $gsc_data['position_trend'] ?? 0;
?>

<?php echo HTS_DS::page_open( true ); ?>

<!-- Loading overlay -->
<div id="hts-ana-loading" style="position:fixed;inset:0;z-index:99999;background:rgba(255,255,255,.6);display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s">
	<div style="background:var(--hts-bg);padding:16px 24px;border-radius:var(--hts-radius);box-shadow:var(--hts-shadow-lg);font-size:13px;font-weight:600;color:var(--hts-text)">Chargement&hellip;</div>
</div>
<style>#hts-ana-loading.visible{opacity:1;pointer-events:auto}</style>

<!-- ═══ S1 — HERO ═══ -->
<div style="background:linear-gradient(135deg,#1D1D1F 0%,#2D2D30 60%,#1D1D1F 100%);border-radius:28px;padding:32px 36px;margin-bottom:20px;position:relative;overflow:hidden">
	<div style="position:absolute;top:-40px;right:-40px;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(45,127,249,.08) 0%,transparent 70%);pointer-events:none"></div>
	<div style="position:relative;z-index:1">
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
			<?php echo HTS_DS::icon( 'chart', 16, 'rgba(255,255,255,.4)' ); ?>
			<span style="font-size:11px;font-weight:600;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em">Performance de votre site</span>
		</div>
		<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:16px">
			<?php
			$hero_kpis = array(
				array(
					'label' => 'Visites Google',
					'value' => number_format( $gsc_data['clicks'] ?? 0, 0, ',', ' ' ),
					'trend' => isset( $gsc_data['clicks_trend'] ) && $gsc_data['clicks_trend'] != 0 ? ( $gsc_data['clicks_trend'] > 0 ? '+' : '' ) . round( $gsc_data['clicks_trend'] ) . '%' : '',
					'sub'   => 'clics ce mois',
				),
				array(
					'label' => 'Visites IA',
					'value' => number_format( $ai_total ?? 0, 0, ',', ' ' ),
					'trend' => $ai_trend > 0 ? '+' . round( $ai_trend ) . '%' : '',
					'sub'   => 'depuis ChatGPT, Claude...',
				),
				array(
					'label' => 'Position moyenne',
					'value' => isset( $gsc_data['avg_position'] ) && $gsc_data['avg_position'] > 0 ? round( $gsc_data['avg_position'], 1 ) : '—',
					'trend' => $pos_trend_val != 0 ? ( $pos_trend_val > 0 ? '+' : '' ) . round( $pos_trend_val, 1 ) : '',
					'sub'   => $pos_trend_val < 0 ? 'en amélioration' : '',
				),
				array(
					'label' => 'Actions positives',
					'value' => $wf_rate . '%',
					'trend' => $wf_positive > 0 ? '+' . $wf_positive : '',
					'sub'   => $wf_measured > 0 ? 'sur ' . $wf_measured . ' mesurées' : '',
				),
			);
			foreach ( $hero_kpis as $k ) : ?>
			<div class="hts-ana-hero-kpi" style="padding:16px 18px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06)">
				<div style="font-size:10px;font-weight:600;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px"><?php echo esc_html( $k['label'] ); ?></div>
				<div style="display:flex;align-items:baseline;gap:8px">
					<span class="hts-ana-hero-val" style="font-size:26px;font-weight:800;color:#fff;letter-spacing:-.03em"><?php echo $k['value']; ?></span>
					<span class="hts-ana-hero-trend" style="font-size:12px;font-weight:700;color:var(--hts-success);<?php echo $k['trend'] ? '' : 'display:none'; ?>"><?php echo esc_html( $k['trend'] ); ?></span>
				</div>
				<?php if ( $k['sub'] ) : ?>
				<div style="font-size:11px;color:rgba(255,255,255,.3);margin-top:4px"><?php echo esc_html( $k['sub'] ); ?></div>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>

<!-- ═══ S2 — TOOLBAR ═══ -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px">
	<div style="display:inline-flex;gap:1px;padding:2px;background:rgba(120,120,128,.06);border-radius:8px">
		<?php
		$periods = array( '15' => '15j', '30' => '30j', '90' => '90j', '365' => '12m' );
		foreach ( $periods as $days => $label ) :
			$active = ( $days === '30' );
		?>
		<button class="hts-ana-period-btn" data-days="<?php echo esc_attr( $days ); ?>" style="padding:6px 14px;border-radius:7px;border:none;background:<?php echo $active ? 'var(--hts-pill-bg)' : 'transparent'; ?>;box-shadow:<?php echo $active ? 'var(--hts-pill-shadow)' : 'none'; ?>;color:<?php echo $active ? 'var(--hts-text)' : 'rgba(60,60,67,.4)'; ?>;font-size:12px;font-weight:<?php echo $active ? '600' : '500'; ?>;cursor:pointer;font-family:var(--hts-font)"><?php echo esc_html( $label ); ?></button>
		<?php endforeach; ?>
	</div>
	<div style="display:flex;gap:8px">
		<?php /* Bouton IA masqué — handler non implémenté
		<button style="display:flex;align-items:center;gap:5px;padding:7px 14px;border-radius:var(--hts-radius-sm);border:none;background:linear-gradient(135deg,var(--hts-geo),var(--hts-accent));color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon( 'zap', 13, '#fff' ); ?> Analyser avec l&#039;IA</button>
		*/ ?>
		<!-- CSV + PDF : désactivés pour l'instant
		<button id="hts-ana-export-csv" style="display:flex;align-items:center;gap:5px;padding:7px 14px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon( 'download', 13, 'var(--hts-text-3)' ); ?> CSV</button>
		-->
	</div>
</div>

<!-- ═══ S3 — INTERACTIVE CHART ═══ -->
<div class="hts-ds-card" style="padding:22px 24px;margin-bottom:20px">
	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
		<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Trafic — <span id="hts-chart-period-label">30j</span></span>
		<div style="display:flex;gap:12px">
			<button id="hts-toggle-google" style="display:flex;align-items:center;gap:5px;padding:4px 10px;border-radius:6px;border:none;background:var(--hts-accent-bg);cursor:pointer;font-family:var(--hts-font);font-size:11px;font-weight:600;color:var(--hts-accent);transition:all .15s">
				<?php echo hts_google_g( 12 ); ?> Google
			</button>
			<button id="hts-toggle-ia" style="display:flex;align-items:center;gap:5px;padding:4px 10px;border-radius:6px;border:none;background:var(--hts-geo-soft);cursor:pointer;font-family:var(--hts-font);font-size:11px;font-weight:600;color:var(--hts-geo);transition:all .15s">
				<?php echo HTS_DS::icon( 'bot', 12, 'var(--hts-geo)' ); ?> IA
			</button>
		</div>
	</div>
	<div style="position:relative;height:146px">
		<div id="hts-ana-chart-bars" style="display:flex;gap:<?php echo count( $daily ) > 12 ? 2 : 6; ?>px;height:100%;position:relative">
			<?php if ( ! empty( $daily ) ) :
				$has_gsc_daily = ! empty( $daily[0]['gsc_clicks'] ) || array_sum( array_column( $daily, 'gsc_clicks' ) ) > 0;
				$max_google = $has_gsc_daily ? max( 1, max( array_column( $daily, 'gsc_clicks' ) ) ) : max( 1, max( array_column( $daily, 'total' ) ) );
				$max_ai = max( 1, max( array_column( $daily, 'ai' ) ) );
				$max_day = max( $max_google, $max_ai );
				$bar_count = count( $daily );
				foreach ( $daily as $i => $dd ) :
					$google_val = $has_gsc_daily ? (int) ( $dd['gsc_clicks'] ?? 0 ) : max( 0, $dd['total'] - $dd['ai'] );
					$google_h = max( 2, round( $google_val / $max_day * 114 ) );
					$ai_h     = max( 1, round( $dd['ai'] / $max_day * 114 ) );
					$day_label = gmdate( 'j', strtotime( $dd['day'] ) );
			?>
			<div class="hts-ana-bar" style="flex:1;position:relative;cursor:pointer" data-day="<?php echo esc_attr( $dd['day'] ); ?>" data-total="<?php echo (int) $dd['total']; ?>" data-ai="<?php echo (int) $dd['ai']; ?>" data-google="<?php echo $google_val; ?>">
				<div class="hts-bar-google" style="position:absolute;bottom:16px;left:0;right:0;height:<?php echo $google_h + $ai_h; ?>px;background:var(--hts-accent);opacity:.18;border-radius:3px 3px 0 0"></div>
				<div class="hts-bar-ia" style="position:absolute;bottom:16px;left:0;right:0;height:<?php echo $ai_h; ?>px;background:var(--hts-geo);opacity:.75;border-radius:0"></div>
				<div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:<?php echo $bar_count > 12 ? 7 : 10; ?>px;color:var(--hts-faint);line-height:1"><?php echo $day_label; ?></div>
			</div>
			<?php endforeach; else : ?>
			<div style="text-align:center;width:100%;padding:40px 0;font-size:12px;color:var(--hts-text-3)">Les données apparaîtront dès les premières visites.</div>
			<?php endif; ?>
		</div>
	</div>
</div>

<!-- ═══ S4 — SEO + GEO ═══ -->
<div id="hts-ana-s4" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">

	<!-- Card Google -->
	<div class="hts-ds-card" style="padding:22px 24px 0;display:flex;flex-direction:column;overflow:hidden">
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">
			<?php echo hts_google_g( 20 ); ?>
			<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Google</span>
			<?php if ( $gsc_connected ) : ?>
			<span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:6px;background:var(--hts-success-bg);color:var(--hts-success)">GSC connecté</span>
			<?php endif; ?>
		</div>
		<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
			<?php
			$gsc_kpis = array(
				array( 'l' => 'Clics', 'v' => number_format( $gsc_data['clicks'] ?? 0, 0, ',', ' ' ), 'c' => 'var(--hts-accent)' ),
				array( 'l' => 'Impressions', 'v' => number_format( $gsc_data['impressions'] ?? 0, 0, ',', ' ' ), 'c' => 'var(--hts-text)' ),
				array( 'l' => 'Position moy.', 'v' => $gsc_data['avg_position'] > 0 ? round( $gsc_data['avg_position'], 1 ) : '—', 'c' => 'var(--hts-success)' ),
				array( 'l' => 'CTR moyen', 'v' => ( $gsc_data['avg_ctr'] ?? 0 ) . '%', 'c' => 'var(--hts-text)' ),
			);
			foreach ( $gsc_kpis as $m ) : ?>
			<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:var(--hts-surface)">
				<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px"><?php echo esc_html( $m['l'] ); ?></div>
				<div style="font-size:20px;font-weight:800;color:<?php echo $m['c']; ?>;letter-spacing:-.03em"><?php echo $m['v']; ?></div>
			</div>
			<?php endforeach; ?>
		</div>
		<div style="flex:1"></div>
		<?php echo hts_bleed_spark( $gsc_spark, 'var(--hts-accent)', 50 ); ?>
	</div>

	<!-- Card Visibilité IA -->
	<div class="hts-ds-card" style="padding:22px 24px 0;background:linear-gradient(180deg,var(--hts-geo-soft),var(--hts-bg));border:1px solid var(--hts-geo-border);display:flex;flex-direction:column;overflow:hidden">
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">
			<?php echo HTS_DS::icon( 'bot', 18, 'var(--hts-geo)' ); ?>
			<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Visibilité IA</span>
			<?php if ( $ai_trend > 0 ) : ?>
			<span style="font-size:12px;font-weight:700;color:var(--hts-success)">+<?php echo round( $ai_trend ); ?>%</span>
			<?php endif; ?>
		</div>
		<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
			<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:rgba(255,255,255,.7)">
				<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">Visites IA</div>
				<div style="font-size:20px;font-weight:800;color:var(--hts-geo);letter-spacing:-.03em"><?php echo number_format( $ai_total, 0, ',', ' ' ); ?></div>
			</div>
			<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:rgba(255,255,255,.7)">
				<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">Articles cités</div>
				<div style="font-size:20px;font-weight:800;color:var(--hts-success);letter-spacing:-.03em"><?php echo count( $top_articles ); ?></div>
			</div>
		</div>
		<!-- Sources with AILogo -->
		<?php if ( ! empty( $ai_sources ) ) :
			$max_src = $ai_sources[0]['count'] ?? 1;
			$max_src = max( $max_src, 1 );
			foreach ( $ai_sources as $si => $sr ) :
				$slug = $sr['source'];
				$color = $src_colors[ $slug ] ?? 'var(--hts-geo)';
				$pct = round( $sr['count'] / $max_src * 100 );
		?>
		<div style="display:flex;align-items:center;gap:8px;padding:7px 0;<?php echo $si > 0 ? 'border-top:1px solid var(--hts-geo-border)' : ''; ?>">
			<?php echo hts_ai_logo( $slug, 18 ); ?>
			<div style="flex:1;height:5px;border-radius:3px;background:rgba(255,255,255,.5);overflow:hidden">
				<div style="width:<?php echo $pct; ?>%;height:100%;border-radius:3px;background:<?php echo $color; ?>"></div>
			</div>
			<span style="font-size:11px;font-weight:700;color:var(--hts-text);min-width:30px;text-align:right"><?php echo (int) $sr['count']; ?></span>
		</div>
		<?php endforeach; endif; ?>
		<div style="flex:1"></div>
		<?php echo hts_bleed_spark( $ai_spark, 'var(--hts-geo)', 50 ); ?>
	</div>
</div>

<!-- ═══ S5 — INSIGHTS ═══ -->
<div id="hts-ana-s5">
<?php if ( ! empty( $crawl_insights ) ) : ?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
	<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Insights</span>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px">
	<?php
	$insight_map = array(
		'warning' => array( 'gradient' => 'linear-gradient(135deg,var(--hts-caution-bg),var(--hts-bg))', 'border' => 'rgba(245,158,11,.2)', 'iconC' => 'var(--hts-caution)' ),
		'info'    => array( 'gradient' => 'linear-gradient(135deg,var(--hts-accent-bg),var(--hts-bg))', 'border' => 'rgba(45,127,249,.2)', 'iconC' => 'var(--hts-accent)' ),
		'error'   => array( 'gradient' => 'linear-gradient(135deg,var(--hts-danger-bg),var(--hts-bg))', 'border' => 'rgba(239,68,68,.2)', 'iconC' => 'var(--hts-danger)' ),
		'success' => array( 'gradient' => 'linear-gradient(135deg,var(--hts-success-bg),var(--hts-bg))', 'border' => 'rgba(0,210,106,.2)', 'iconC' => 'var(--hts-success)' ),
	);
	foreach ( array_slice( $crawl_insights, 0, 4 ) as $ci ) :
		$im = $insight_map[ $ci['type'] ] ?? $insight_map['info'];
	$item_count = count( $ci['posts'] ?? $ci['pages'] ?? array() );
	?>
	<div class="hts-ds-card" style="padding:16px 20px;background:<?php echo $im['gradient']; ?>;border:1px solid <?php echo $im['border']; ?>">
		<div style="display:flex;align-items:flex-start;gap:12px">
			<div style="width:32px;height:32px;border-radius:8px;background:var(--hts-bg);border:1px solid <?php echo $im['border']; ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0">
				<?php echo HTS_DS::icon( $ci['icon'] ?? 'alert', 14, $im['iconC'] ); ?>
			</div>
			<div style="flex:1;min-width:0">
				<div style="font-size:13px;font-weight:700;color:var(--hts-text)"><?php echo wp_kses_post( $ci['title'] ); ?></div>
				<div style="font-size:11px;color:var(--hts-text-2);margin-top:2px;line-height:1.5"><?php echo wp_kses_post( $ci['desc'] ); ?></div>
			</div>
			<div style="text-align:center;flex-shrink:0">
				<div style="font-size:18px;font-weight:800;color:<?php echo $im['iconC']; ?>"><?php echo $item_count; ?></div>
				<div style="font-size:8px;color:var(--hts-text-3);font-weight:600;text-transform:uppercase">pages</div>
			</div>
		</div>
	</div>
	<?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<!-- ═══ S6 — TOP PAGES ═══ -->
<div id="hts-ana-s6" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">

	<!-- Top pages Google -->
	<div class="hts-ds-card" style="padding:22px 24px">
		<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Top pages Google</span>
			<button class="hts-tout-voir-btn" data-section="top-google" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>
		</div>
		<?php if ( ! empty( $gsc_data['top_pages'] ) ) :
			foreach ( array_slice( $gsc_data['top_pages'], 0, 5 ) as $i => $gp ) : ?>
		<div style="display:flex;align-items:center;gap:10px;height:44px;<?php echo $i > 0 ? 'border-top:1px solid var(--hts-border-sub)' : ''; ?>">
			<span style="width:20px;height:20px;border-radius:6px;background:var(--hts-accent-bg);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:var(--hts-accent);flex-shrink:0"><?php echo $i + 1; ?></span>
			<?php if ( ! empty( $gp['post_id'] ) ) : ?>
			<a href="<?php echo esc_url( get_edit_post_link( $gp['post_id'] ) ); ?>" style="flex:1;font-size:12px;font-weight:500;color:var(--hts-text);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( mb_strimwidth( $gp['title'], 0, 45, '…' ) ); ?></a>
			<?php else : ?>
			<span style="flex:1;font-size:12px;color:var(--hts-text-3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( mb_strimwidth( $gp['url'] ?? '', 0, 45, '…' ) ); ?></span>
			<?php endif; ?>
			<span style="font-size:11px;font-weight:700;color:var(--hts-accent);min-width:30px;text-align:right"><?php echo (int) $gp['clicks']; ?></span>
			<span style="font-size:10px;color:var(--hts-text-3);min-width:50px;text-align:right">pos <?php echo esc_html( $gp['position'] ); ?></span>
		</div>
		<?php endforeach;
		else : ?>
		<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)">
			<?php if ( ! $gsc_connected ) : ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-seo-settings' ) ); ?>" style="color:var(--hts-accent);text-decoration:none;font-weight:600">Connecter Search Console</a>
			<?php else : ?>
			Pas encore assez de données
			<?php endif; ?>
		</div>
		<?php endif; ?>
	</div>

	<!-- Top pages IA -->
	<div class="hts-ds-card" style="padding:22px 24px;background:linear-gradient(180deg,var(--hts-geo-soft),var(--hts-bg));border:1px solid var(--hts-geo-border)">
		<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Top pages citées par les IA</span>
			<button class="hts-tout-voir-btn" data-section="top-ia" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>
		</div>
		<?php if ( ! empty( $top_articles ) ) :
			foreach ( array_slice( $top_articles, 0, 5 ) as $i => $art ) : ?>
		<div style="display:flex;align-items:center;gap:10px;height:44px;<?php echo $i > 0 ? 'border-top:1px solid var(--hts-geo-border)' : ''; ?>">
			<span style="width:20px;height:20px;border-radius:6px;background:rgba(99,102,241,.15);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:var(--hts-geo);flex-shrink:0"><?php echo $i + 1; ?></span>
			<div style="flex:1;min-width:0">
				<a href="<?php echo esc_url( get_edit_post_link( $art['post_id'] ) ); ?>" style="font-size:12px;font-weight:500;color:var(--hts-text);text-decoration:none;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( mb_strimwidth( $art['title'], 0, 40, '…' ) ); ?></a>
				<div style="font-size:9px;color:var(--hts-text-3)"><?php echo esc_html( $art['sources'] ?? '' ); ?></div>
			</div>
			<span style="font-size:11px;font-weight:700;color:var(--hts-geo);min-width:30px;text-align:right"><?php echo (int) $art['ai_visits']; ?></span>
		</div>
		<?php endforeach;
		else : ?>
		<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)">Aucune citation IA détectée</div>
		<?php endif; ?>
	</div>
</div>

<!-- ═══ S7 — ROBOTS + FRESHNESS ═══ -->
<div id="hts-ana-s7" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">

	<!-- Activité robots -->
	<div class="hts-ds-card" style="padding:22px 24px">
		<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Activité robots</span>
			<?php if ( $cat_total > 0 ) : ?>
			<span style="font-size:11px;font-weight:700;color:var(--hts-accent)"><?php echo number_format( $cat_total, 0, ',', ' ' ); ?> scans</span>
			<?php endif; ?>
		</div>
		<?php if ( $cat_total > 0 ) : ?>
		<div style="display:flex;justify-content:space-between;font-size:11px;font-weight:600;margin-bottom:6px">
			<span style="color:var(--hts-geo)">Robots IA : <?php echo number_format( $cat_ai, 0, ',', ' ' ); ?></span>
			<span style="color:var(--hts-danger)">Moteurs : <?php echo number_format( $cat_seo, 0, ',', ' ' ); ?></span>
		</div>
		<div style="height:8px;border-radius:4px;overflow:hidden;display:flex;margin-bottom:12px">
			<?php $ai_pct = $cat_total > 0 ? round( $cat_ai / $cat_total * 100 ) : 50; ?>
			<div style="width:<?php echo $ai_pct; ?>%;height:100%;background:linear-gradient(90deg,var(--hts-geo),#A78BFA)"></div>
			<div style="width:<?php echo 100 - $ai_pct; ?>%;height:100%;background:linear-gradient(90deg,#EA4335,#F87171)"></div>
		</div>
		<?php endif; ?>
		<!-- Top 3 bots (IA prioritaire, complété par SEO si besoin) -->
		<?php
		$top3_ai = array_slice( $ai_bots_data, 0, 3 );
		if ( count( $top3_ai ) < 3 ) {
			$top3_ai = array_merge( $top3_ai, array_slice( $seo_bots_data, 0, 3 - count( $top3_ai ) ) );
		}
		foreach ( $top3_ai as $slug => $info ) :
			$cat = $info['category'] ?? HTS_Impact_Tracker::bot_category( $slug );
			$color = $info['color'] ?? HTS_Impact_Tracker::source_color( $slug );
			$pct = round( ( $info['count'] ?? 0 ) / max( $max_bot, 1 ) * 100 );
		?>
		<div style="display:flex;align-items:center;gap:8px;padding:6px 0;<?php echo $slug !== array_key_first( $top3_ai ) ? 'border-top:1px solid var(--hts-border-sub)' : ''; ?>">
			<?php if ( $cat === 'ai' || $cat === 'ia' ) : ?>
				<?php echo hts_ai_logo( $slug, 16 ); ?>
			<?php else : ?>
				<div style="width:16px;height:16px;border-radius:50%;background:<?php echo $color; ?>20;display:flex;align-items:center;justify-content:center"><div style="width:8px;height:8px;border-radius:50%;background:<?php echo $color; ?>"></div></div>
			<?php endif; ?>
			<span style="font-size:11px;font-weight:600;color:var(--hts-text);flex:1"><?php echo esc_html( $info['label'] ?? HTS_Impact_Tracker::source_label( $slug ) ); ?></span>
			<div style="width:60px;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:<?php echo $pct; ?>%;height:100%;border-radius:2px;background:<?php echo $color; ?>"></div></div>
			<span style="font-size:11px;font-weight:700;color:var(--hts-text);min-width:30px;text-align:right"><?php echo (int) $info['count']; ?></span>
		</div>
		<?php endforeach; ?>
		<!-- Toggle all robots -->
		<button id="hts-robots-toggle" data-label-closed="Voir les <?php echo count( $all_bots ); ?> robots" style="display:flex;align-items:center;gap:4px;margin-top:10px;padding:6px 12px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);width:100%;justify-content:center">
			Voir les <?php echo count( $all_bots ); ?> robots <?php echo HTS_DS::icon( 'chevron-down', 12, 'var(--hts-text-3)' ); ?>
		</button>
		<div id="hts-robots-detail" style="display:none;margin-top:12px">
			<?php
			$top3_slugs = array_keys( $top3_ai );
			foreach ( array( 'ia' => $ai_bots_data, 'seo' => $seo_bots_data ) as $cat => $bots_list ) :
				// Filter out bots already shown in top 3
				$remaining = array();
				foreach ( $bots_list as $slug => $info ) {
					if ( ! in_array( $slug, $top3_slugs, true ) ) {
						$remaining[ $slug ] = $info;
					}
				}
				if ( empty( $remaining ) ) continue;
			?>
			<div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px"><?php echo $cat === 'ia' ? 'Robots IA' : 'Moteurs de recherche'; ?></div>
			<?php foreach ( $remaining as $slug => $info ) :
				$color = $info['color'] ?? HTS_Impact_Tracker::source_color( $slug );
				$pct = round( ( $info['count'] ?? 0 ) / max( $max_bot, 1 ) * 100 );
			?>
			<div style="display:flex;align-items:center;gap:8px;padding:5px 0">
				<?php if ( $cat === 'ia' ) : ?>
					<?php echo hts_ai_logo( $slug, 14 ); ?>
				<?php else : ?>
					<div style="width:14px;height:14px;border-radius:50%;background:<?php echo $color; ?>20;display:flex;align-items:center;justify-content:center"><div style="width:6px;height:6px;border-radius:50%;background:<?php echo $color; ?>"></div></div>
				<?php endif; ?>
				<span style="font-size:11px;font-weight:600;color:var(--hts-text);min-width:70px"><?php echo esc_html( $info['label'] ?? HTS_Impact_Tracker::source_label( $slug ) ); ?></span>
				<div style="flex:1;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:<?php echo $pct; ?>%;height:100%;border-radius:2px;background:<?php echo $color; ?>"></div></div>
				<span style="font-size:10px;font-weight:700;color:var(--hts-text-2);min-width:36px;text-align:right"><?php echo (int) $info['count']; ?></span>
			</div>
			<?php endforeach; endforeach; ?>
		</div>
	</div>

	<!-- Contenu à rafraîchir -->
	<div class="hts-ds-card" style="padding:22px 24px">
		<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Contenu à rafraîchir</span>
			<?php if ( count( $stale_posts ) > 0 ) : ?>
			<button class="hts-tout-voir-btn" data-section="freshness" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>
			<?php endif; ?>
		</div>
		<?php if ( ! empty( $stale_posts ) ) :
			foreach ( $stale_posts as $i => $sp ) :
				$extra = $i >= 4 ? ' hts-fresh-extra' : '';
		?>
		<div class="<?php echo trim( $extra ); ?>" style="display:<?php echo $i >= 4 ? 'none' : 'flex'; ?>;align-items:center;gap:10px;padding:8px 0;<?php echo $i > 0 ? 'border-top:1px solid var(--hts-border-sub)' : ''; ?>">
			<span style="font-size:9px;font-weight:700;padding:3px 8px;border-radius:6px;background:var(--hts-danger-bg);color:var(--hts-danger);flex-shrink:0"><?php echo (int) $sp['months_ago']; ?> mois</span>
			<a href="<?php echo esc_url( $sp['edit_url'] ?? '#' ); ?>" style="flex:1;font-size:12px;color:var(--hts-text);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( mb_strimwidth( $sp['title'], 0, 45, '…' ) ); ?></a>
			<span style="font-size:10px;color:var(--hts-text-3)"><?php echo (int) ( $sp['clicks'] ?? 0 ); ?> clics/mois</span>
			<a href="<?php echo esc_url( $sp['edit_url'] ?? '#' ); ?>" style="font-size:11px;font-weight:600;color:var(--hts-accent);text-decoration:none;flex-shrink:0">Mettre à jour</a>
		</div>
		<?php endforeach;
		else : ?>
		<div style="text-align:center;padding:30px 0">
			<?php echo HTS_DS::icon( 'check', 32, 'var(--hts-success)' ); ?>
			<div style="font-size:13px;font-weight:600;color:var(--hts-success);margin-top:10px">Tous vos articles sont à jour</div>
		</div>
		<?php endif; ?>
	</div>
</div>

<!-- ═══ S8 — ENGAGEMENT TABLE ═══ -->
<div id="hts-ana-s8" class="hts-ds-card" style="padding:22px 24px">
	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
		<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Top articles par engagement</span>
		<button class="hts-tout-voir-btn" data-section="engagement" style="font-size:12px;font-weight:600;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-family:var(--hts-font)">Tout voir</button>
	</div>
	<?php if ( ! empty( $top_engaged ) ) : ?>
	<table style="width:100%;border-collapse:collapse;font-size:12px">
		<thead><tr style="border-bottom:2px solid var(--hts-border)">
			<th style="text-align:left;padding:8px 10px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">Article</th>
			<th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">Visites</th>
			<th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">IA</th>
			<th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">Temps</th>
			<th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase">Scroll</th>
		</tr></thead>
		<tbody>
		<?php foreach ( array_slice( $top_engaged, 0, 5 ) as $row ) :
			$sc = $row['avg_scroll'] >= 70 ? 'var(--hts-success)' : ( $row['avg_scroll'] >= 40 ? 'var(--hts-caution)' : 'var(--hts-danger)' );
		?>
		<tr style="border-bottom:1px solid var(--hts-border-sub)">
			<td style="padding:10px">
				<a href="<?php echo esc_url( get_edit_post_link( $row['post_id'] ?? 0 ) ); ?>" style="color:var(--hts-text);text-decoration:none;font-weight:500"><?php echo esc_html( mb_strimwidth( $row['title'], 0, 40, '…' ) ); ?></a>
			</td>
			<td style="text-align:center;padding:10px;font-weight:600"><?php echo (int) $row['visits']; ?></td>
			<td style="text-align:center;padding:10px">
				<?php if ( (int) $row['ai_visits'] > 0 ) : ?>
				<span style="background:var(--hts-geo-soft);color:var(--hts-geo);padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700"><?php echo (int) $row['ai_visits']; ?></span>
				<?php else : ?>
				<span style="color:var(--hts-text-3)">—</span>
				<?php endif; ?>
			</td>
			<td style="text-align:center;padding:10px;font-weight:600;color:var(--hts-success)"><?php echo hts_fmt_time( $row['avg_time'] ); ?></td>
			<td style="text-align:center;padding:10px">
				<div style="display:flex;align-items:center;gap:4px;justify-content:center">
					<div style="width:40px;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:<?php echo (int) $row['avg_scroll']; ?>%;height:100%;border-radius:2px;background:<?php echo $sc; ?>"></div></div>
					<span style="font-size:10px;font-weight:600;color:<?php echo $sc; ?>"><?php echo (int) $row['avg_scroll']; ?>%</span>
				</div>
			</td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php else : ?>
	<div style="text-align:center;padding:30px 0;font-size:12px;color:var(--hts-text-3)">Pas encore assez de données</div>
	<?php endif; ?>
</div>

<!-- ═══ S9 — TOUT VOIR MODAL ═══ -->
<div id="hts-modal-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);display:none;align-items:center;justify-content:center;z-index:1000">
	<div id="hts-modal-content" style="width:700px;max-height:80vh;background:var(--hts-bg);border-radius:20px;box-shadow:0 24px 80px rgba(0,0,0,.2);overflow:hidden;display:flex;flex-direction:column">
		<div style="display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid var(--hts-border-sub)">
			<span id="hts-modal-title" style="font-size:16px;font-weight:800;color:var(--hts-text)"></span>
			<div style="display:flex;gap:6px">
				<button style="display:flex;align-items:center;gap:4px;padding:6px 14px;border-radius:var(--hts-radius-sm);border:none;background:linear-gradient(135deg,var(--hts-geo),var(--hts-accent));font-size:11px;font-weight:600;color:#fff;cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon( 'zap', 11, '#fff' ); ?> Analyser</button>
				<button id="hts-modal-export-csv" style="padding:6px 14px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Export CSV</button>
				<button id="hts-modal-close" onclick="document.getElementById('hts-modal-overlay').style.display='none'" style="width:32px;height:32px;border-radius:8px;border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="var(--hts-text-3)" stroke-width="2"/></svg>
				</button>
			</div>
		</div>
		<div style="padding:14px 24px;border-bottom:1px solid var(--hts-border-sub)">
			<div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border:1.5px solid var(--hts-border);border-radius:var(--hts-radius-sm);background:var(--hts-bg)">
				<?php echo HTS_DS::icon( 'search', 14, 'var(--hts-text-3)' ); ?>
				<input id="hts-modal-filter" type="text" placeholder="Filtrer les résultats..." style="flex:1;border:none;outline:none;font-size:13px;font-family:var(--hts-font);color:var(--hts-text);background:transparent">
			</div>
		</div>
		<div id="hts-modal-body" style="flex:1;overflow:auto;padding:0 24px"></div>
		<div id="hts-modal-footer" style="display:flex;align-items:center;justify-content:space-between;padding:12px 24px;border-top:1px solid var(--hts-border-sub)">
			<div id="hts-modal-perpage-wrap" style="font-size:12px;color:var(--hts-text-3)">Afficher
				<select id="hts-modal-perpage" style="padding:4px 24px 4px 8px;border-radius:6px;border:1px solid var(--hts-border);font-size:12px;font-family:var(--hts-font);appearance:auto;-webkit-appearance:menulist"><option value="25">25</option><option value="50">50</option></select>
			</div>
			<span id="hts-modal-page-info" style="font-size:12px;color:var(--hts-text-3)"></span>
			<div id="hts-modal-nav" style="display:flex;gap:6px">
				<button id="hts-modal-prev" style="padding:6px 14px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-3);cursor:pointer;font-family:var(--hts-font)">Pr&eacute;c&eacute;dent</button>
				<button id="hts-modal-next" style="padding:6px 14px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-accent);background:var(--hts-accent-bg);font-size:12px;font-weight:600;color:var(--hts-accent);cursor:pointer;font-family:var(--hts-font)">Suivant</button>
			</div>
		</div>
	</div>
</div>

<!-- Seed JS cache + interactions -->
<script>
/* Seed initial data for hts-analytics.js cache */
window.htsAnalyticsInitial = <?php echo wp_json_encode( $data ); ?>;

/* Google/IA toggle buttons — persists across period changes */
(function(){
	var showGoogle = true, showIA = true;
	function update(){
		document.querySelectorAll('.hts-bar-google').forEach(function(el){ el.style.display = showGoogle ? '' : 'none'; });
		document.querySelectorAll('.hts-bar-ia').forEach(function(el){ el.style.display = showIA ? '' : 'none'; });
		var gBtn = document.getElementById('hts-toggle-google');
		var iBtn = document.getElementById('hts-toggle-ia');
		if (gBtn) {
			gBtn.style.background = showGoogle ? 'var(--hts-accent-bg)' : 'var(--hts-border-sub)';
			gBtn.style.color = showGoogle ? 'var(--hts-accent)' : 'var(--hts-faint)';
		}
		if (iBtn) {
			iBtn.style.background = showIA ? 'var(--hts-geo-soft)' : 'var(--hts-border-sub)';
			iBtn.style.color = showIA ? 'var(--hts-geo)' : 'var(--hts-faint)';
		}
	}
	/* Expose update() so hts-analytics.js can re-apply toggle state after chart re-render */
	window._htsBarToggleUpdate = update;
	document.addEventListener('click', function(e) {
		if (e.target.closest && e.target.closest('#hts-toggle-google')) { showGoogle = !showGoogle; update(); }
		if (e.target.closest && e.target.closest('#hts-toggle-ia')) { showIA = !showIA; update(); }
	});
})();

/* Robots toggle — delegated (works for initial PHP + AJAX re-render) */
(function(){
	var open = false;
	document.addEventListener('click', function(e) {
		var togBtn = e.target.closest ? e.target.closest('#hts-robots-toggle') : null;
		if (!togBtn) return;
		var detail = document.getElementById('hts-robots-detail');
		if (!detail) return;
		open = !open;
		detail.style.display = open ? 'block' : 'none';
		togBtn.innerHTML = open ? 'Masquer' : (togBtn.dataset.labelClosed || 'Voir les robots');
		/* Sync freshness extra rows with robots open/close */
		document.querySelectorAll('.hts-fresh-extra').forEach(function(el) {
			el.style.display = open ? 'flex' : 'none';
		});
	});
})();

/* Tout voir modal — delegated, calls hts-analytics.js openModal */
(function(){
	document.addEventListener('click', function(e) {
		var btn = e.target.closest ? e.target.closest('.hts-tout-voir-btn') : null;
		if (btn) {
			if (typeof window._htsOpenModal === 'function') {
				window._htsOpenModal(btn.dataset.section || '');
			} else {
				/* Fallback: just open empty modal */
				var overlay = document.getElementById('hts-modal-overlay');
				var title = document.getElementById('hts-modal-title');
				if (overlay && title) {
					title.textContent = btn.dataset.section || 'D\u00e9tails';
					overlay.style.display = 'flex';
				}
			}
			return;
		}
		var overlay = document.getElementById('hts-modal-overlay');
		if (e.target === overlay) { overlay.style.display = 'none'; }
		if (e.target.closest && e.target.closest('#hts-modal-close')) {
			var ov = document.getElementById('hts-modal-overlay');
			if (ov) ov.style.display = 'none';
		}
	});
})();
</script>

<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>
