<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Meta Score — Smart Meta Optimization Engine (Light)
 *
 * Scores meta titles & descriptions (0-100), generates AI variants,
 * allows apply/rollback with preview before/after.
 *
 * Adapted from Full v3.3.1 → Light Phase 1.
 * 6 scoring criteria (no embeddings, no GSC required):
 *   1. Title length           (15)  — 50-60 chars optimal
 *   2. Description length     (15)  — 120-160 chars optimal
 *   3. Keyword in title       (20)  — present + front-loaded
 *   4. Keyword in description (15)  — present naturally
 *   5. Semantic alignment     (20)  — word overlap fallback (no embeddings)
 *   6. Quality signals        (15)  — power words, CTA, no stuffing, numbers
 *
 * Total weight = 100 (already normalized)
 *
 * @since 1.13.0
 */

class HTS_Meta_Score {

    const VERSION       = '1.0.0';
    const HISTORY_META  = '_hts_meta_score_history';
    const SCORE_META    = '_hts_meta_score';
    const SCORE_DETAIL  = '_hts_meta_score_detail';
    const GENERATED     = '_hts_meta_generated';
    const SNAPSHOT_META = '_hts_meta_score_snapshot';

    /**
     * Longueur cible pour le titre SEO (depuis agent settings 'meta').
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_title_max_length() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'meta' );
            if ( isset( $s['title_max_length'] ) ) {
                return max( 30, min( 80, (int) $s['title_max_length'] ) );
            }
        }
        return 60;
    }

    /**
     * Longueur cible pour la meta description (depuis agent settings 'meta').
     *
     * @since 2.4.3
     * @return int
     */
    public static function get_desc_max_length() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $s = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'meta' );
            if ( isset( $s['desc_max_length'] ) ) {
                return max( 80, min( 200, (int) $s['desc_max_length'] ) );
            }
        }
        return 155;
    }

    /* ═══════════════════════════════════════════════════
     *  POWER WORDS — trigger emotion / click (FR + EN)
     * ═══════════════════════════════════════════════════ */

    private static $power_words = array(
        // FR
        'ultime', 'guide', 'complet', 'meilleur', 'gratuit', 'exclusif', 'secret',
        'découvrez', 'comment', 'pourquoi', 'astuce', 'conseil', 'essentiel',
        'incontournable', 'efficace', 'rapide', 'facile', 'simple', 'top',
        'erreur', 'éviter', 'comparatif', 'avis', 'test',
        'nouveau', 'tendance', 'résultat', 'prouvé', 'optimiser', 'booster',
        'augmenter', 'améliorer', 'transformer', 'maîtriser',
        // EN
        'ultimate', 'guide', 'complete', 'best', 'free', 'exclusive', 'secret',
        'discover', 'how', 'why', 'tips', 'essential', 'effective', 'fast',
        'easy', 'simple', 'top', 'step-by-step', 'mistake', 'avoid',
        'comparison', 'review', 'new', 'proven', 'optimize', 'boost', 'increase',
    );

    private static $cta_words = array(
        // FR
        'découvrez', 'apprenez', 'téléchargez', 'essayez', 'commencez',
        'obtenez', 'profitez', 'réservez', 'contactez', 'inscrivez',
        'cliquez', 'consultez', 'explorez', 'lisez', 'trouvez',
        // EN
        'discover', 'learn', 'download', 'try', 'start', 'get',
        'book', 'contact', 'sign up', 'click', 'explore', 'read', 'find',
    );

    /* ═══════════════════════════════════════════════════
     *  INIT
     * ═══════════════════════════════════════════════════ */

    public function init() {
        // Score on save
        add_action( 'save_post', array( $this, 'on_save_post' ), 30, 2 );

        // AJAX
        add_action( 'wp_ajax_hts_meta_score_get',      array( $this, 'ajax_get_score' ) );
        add_action( 'wp_ajax_hts_meta_score_generate',  array( $this, 'ajax_generate' ) );
        add_action( 'wp_ajax_hts_meta_score_apply',     array( $this, 'ajax_apply' ) );
        add_action( 'wp_ajax_hts_meta_score_rollback',  array( $this, 'ajax_rollback' ) );

        // Session K : Cron hebdo — scan des meta et proposition Inbox
        add_action( 'hts_meta_score_weekly_scan', array( $this, 'cron_scan_meta' ) );
        if ( ! wp_next_scheduled( 'hts_meta_score_weekly_scan' ) ) {
            wp_schedule_event( time() + 3600, 'weekly', 'hts_meta_score_weekly_scan' );
        }

        // Session K : Hook Workflow dispatch pour exécuter les meta
        add_filter( 'hts_workflow_dispatch', array( $this, 'handle_workflow_dispatch' ), 10, 5 );
    }

    /* ═══════════════════════════════════════════════════
     *  1. SCORING ENGINE (0-100)
     * ═══════════════════════════════════════════════════ */

    /**
     * Compute meta score. Public API used by Global Score, Test Suite, etc.
     *
     * @param int  $post_id
     * @param bool $use_cache
     * @return array { score, grade, criteria[], title, description, keyword }
     */
    public function compute( $post_id, $use_cache = false ) {
        // Alias for compat
        return $this->score_post( $post_id, $use_cache );
    }

    /**
     * Score a post's meta tags.
     *
     * @param int  $post_id
     * @param bool $use_cache
     * @return array
     */
    public function score_post( $post_id, $use_cache = false ) {
        if ( $use_cache ) {
            $cached = get_post_meta( $post_id, self::SCORE_DETAIL, true );
            if ( ! empty( $cached ) && is_array( $cached ) ) {
                $age = time() - ( $cached['scored_at'] ?? 0 );
                if ( $age < DAY_IN_SECONDS ) return $cached;
            }
        }

        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'publish', 'draft', 'future' ), true ) ) {
            return array( 'score' => 0, 'grade' => 'N/A', 'criteria' => array() );
        }

        $title   = $this->get_effective_title( $post_id );
        $desc    = $this->get_effective_desc( $post_id );
        $keyword = $this->get_focus_keyword( $post_id );
        $content = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content = wp_strip_all_tags( HTS_Content_Extractor::get_content( $post_id ) );
        }

        $criteria = array();

        // ── 1. Title length (weight 15) ──
        $criteria[] = $this->score_title_length( $title );

        // ── 2. Description length (weight 15) ──
        $criteria[] = $this->score_desc_length( $desc );

        // ── 3. Keyword in title (weight 20) ──
        $criteria[] = $this->score_keyword_in_title( $title, $keyword );

        // ── 4. Keyword in desc (weight 15) ──
        $criteria[] = $this->score_keyword_in_desc( $desc, $keyword );

        // ── 5. Semantic alignment (weight 20) ──
        $criteria[] = $this->score_semantic_fallback( $title, $desc, $content, $post_id );

        // ── 6. Quality signals (weight 15) ──
        $criteria[] = $this->score_quality_signals( $title, $desc, $keyword );

        // Sum and normalize
        $raw_total = 0;
        $max_total = 0;
        foreach ( $criteria as $c ) {
            $raw_total += $c['score'];
            $max_total += $c['max'];
        }
        $total = $max_total > 0 ? round( $raw_total / $max_total * 100 ) : 0;

        $result = array(
            'score'       => $total,
            'grade'       => $this->grade( $total ),
            'criteria'    => $criteria,
            'title'       => $title,
            'description' => $desc,
            'keyword'     => $keyword,
            'scored_at'   => time(),
            'post_id'     => $post_id,
        );

        // Cache
        update_post_meta( $post_id, self::SCORE_META, $total );
        update_post_meta( $post_id, self::SCORE_DETAIL, $result );

        return $result;
    }

    /* ─── Individual criteria ─── */

    /**
     * 1. Title length — uses configurable target from agent settings.
     */
    private function score_title_length( $title ) {
        $len = mb_strlen( $title );
        $target = self::get_title_max_length();
        $optimal_min = max( 30, $target - 10 ); // ex: 50 si target=60
        $ok_min      = max( 25, $target - 20 ); // ex: 40
        $ok_max      = $target + 5;              // ex: 65
        $wide_min    = max( 20, $target - 30 );  // ex: 30
        $wide_max    = $target + 10;             // ex: 70

        if ( $len >= $optimal_min && $len <= $target ) {
            $score = 15; $detail = $len . ' car. — Optimal ✓';
        } elseif ( $len >= $ok_min && $len <= $ok_max ) {
            $score = 11; $detail = $len . ' car. — Bon, visez ' . $optimal_min . '-' . $target;
        } elseif ( $len >= $wide_min && $len <= $wide_max ) {
            $score = 6; $detail = $len . ' car. — ' . ( $len < $optimal_min ? 'Trop court' : 'Risque de troncature' );
        } elseif ( $len > 0 ) {
            $score = 3; $detail = $len . ' car. — ' . ( $len < $wide_min ? 'Beaucoup trop court' : 'Sera tronqué par Google' );
        } else {
            $score = 0; $detail = 'Aucun meta title défini';
        }

        return array(
            'id' => 'title_length', 'label' => 'Longueur du titre', 'weight' => 15,
            'score' => $score, 'max' => 15, 'detail' => $detail,
        );
    }

    /**
     * 2. Description length — uses configurable target from agent settings.
     */
    private function score_desc_length( $desc ) {
        $len = mb_strlen( $desc );
        $target = self::get_desc_max_length();
        $optimal_min = max( 50, $target - 35 ); // ex: 120 si target=155
        $ok_min      = max( 40, $target - 55 ); // ex: 100
        $ok_max      = $target + 15;             // ex: 170
        $wide_min    = max( 30, $target - 105 ); // ex: 50
        $wide_max    = $target + 45;             // ex: 200

        if ( $len >= $optimal_min && $len <= $target + 5 ) {
            $score = 15; $detail = $len . ' car. — Optimal ✓';
        } elseif ( $len >= $ok_min && $len <= $ok_max ) {
            $score = 11; $detail = $len . ' car. — Bon, visez ' . $optimal_min . '-' . ( $target + 5 );
        } elseif ( $len >= $wide_min && $len <= $wide_max ) {
            $score = 6; $detail = $len . ' car. — ' . ( $len < $optimal_min ? 'Trop court, exploitez l\'espace' : 'Risque de troncature' );
        } elseif ( $len > 0 ) {
            $score = 3; $detail = $len . ' car. — Sous-optimal';
        } else {
            $score = 0; $detail = 'Aucune meta description — Google générera la sienne';
        }

        return array(
            'id' => 'desc_length', 'label' => 'Longueur de la description', 'weight' => 15,
            'score' => $score, 'max' => 15, 'detail' => $detail,
        );
    }

    /**
     * 3. Keyword in title — present + front-loaded
     */
    private function score_keyword_in_title( $title, $keyword ) {
        if ( ! $keyword ) {
            return array(
                'id' => 'kw_title', 'label' => 'Mot-clé dans le titre', 'weight' => 20,
                'score' => 7, 'max' => 20, 'detail' => 'Aucun mot-clé focus défini — score neutre',
            );
        }

        $title_lower = mb_strtolower( $title );
        $kw_lower    = mb_strtolower( $keyword );
        $pos = mb_strpos( $title_lower, $kw_lower );

        if ( $pos === false ) {
            // Partial match
            $kw_parts = explode( ' ', $kw_lower );
            $partial  = 0;
            foreach ( $kw_parts as $part ) {
                if ( mb_strlen( $part ) > 3 && mb_strpos( $title_lower, $part ) !== false ) {
                    $partial++;
                }
            }
            $ratio = count( $kw_parts ) > 0 ? $partial / count( $kw_parts ) : 0;

            if ( $ratio >= 0.5 ) {
                return array(
                    'id' => 'kw_title', 'label' => 'Mot-clé dans le titre', 'weight' => 20,
                    'score' => 9, 'max' => 20,
                    'detail' => 'Mot-clé partiellement présent (' . $partial . '/' . count( $kw_parts ) . ' termes)',
                );
            }
            return array(
                'id' => 'kw_title', 'label' => 'Mot-clé dans le titre', 'weight' => 20,
                'score' => 0, 'max' => 20,
                'detail' => 'Mot-clé « ' . $keyword . ' » absent du titre',
            );
        }

        // Present — check position
        if ( $pos <= 5 ) {
            return array(
                'id' => 'kw_title', 'label' => 'Mot-clé dans le titre', 'weight' => 20,
                'score' => 20, 'max' => 20,
                'detail' => '✓ Front-loaded (position ' . $pos . ') — Idéal',
            );
        } elseif ( $pos <= 30 ) {
            return array(
                'id' => 'kw_title', 'label' => 'Mot-clé dans le titre', 'weight' => 20,
                'score' => 16, 'max' => 20,
                'detail' => '✓ Présent (position ' . $pos . ') — Idéalement dans les 5 premiers caractères',
            );
        }
        return array(
            'id' => 'kw_title', 'label' => 'Mot-clé dans le titre', 'weight' => 20,
            'score' => 11, 'max' => 20,
            'detail' => '✓ Présent mais trop loin (position ' . $pos . ') — Front-loadez le',
        );
    }

    /**
     * 4. Keyword in description — naturally present
     */
    private function score_keyword_in_desc( $desc, $keyword ) {
        if ( ! $keyword ) {
            return array(
                'id' => 'kw_desc', 'label' => 'Mot-clé dans la description', 'weight' => 15,
                'score' => 5, 'max' => 15, 'detail' => 'Aucun mot-clé focus défini',
            );
        }

        if ( ! $desc ) {
            return array(
                'id' => 'kw_desc', 'label' => 'Mot-clé dans la description', 'weight' => 15,
                'score' => 0, 'max' => 15, 'detail' => 'Pas de meta description',
            );
        }

        $desc_lower = mb_strtolower( $desc );
        $kw_lower   = mb_strtolower( $keyword );
        $count      = mb_substr_count( $desc_lower, $kw_lower );

        // Keyword stuffing
        if ( $count > 2 ) {
            return array(
                'id' => 'kw_desc', 'label' => 'Mot-clé dans la description', 'weight' => 15,
                'score' => 5, 'max' => 15,
                'detail' => 'Keyword stuffing (' . $count . 'x) — Max 1-2 occurrences',
            );
        }

        if ( $count >= 1 ) {
            return array(
                'id' => 'kw_desc', 'label' => 'Mot-clé dans la description', 'weight' => 15,
                'score' => 15, 'max' => 15,
                'detail' => '✓ Présent naturellement (' . $count . 'x)',
            );
        }

        // Partial match
        $kw_parts = explode( ' ', $kw_lower );
        $found = 0;
        foreach ( $kw_parts as $part ) {
            if ( mb_strlen( $part ) > 3 && mb_strpos( $desc_lower, $part ) !== false ) $found++;
        }
        if ( $found > 0 && count( $kw_parts ) > 0 ) {
            $ratio = round( $found / count( $kw_parts ) * 100 );
            return array(
                'id' => 'kw_desc', 'label' => 'Mot-clé dans la description', 'weight' => 15,
                'score' => min( 10, round( 10 * $found / count( $kw_parts ) ) ), 'max' => 15,
                'detail' => 'Partiel : ' . $found . '/' . count( $kw_parts ) . ' termes (' . $ratio . '%)',
            );
        }

        return array(
            'id' => 'kw_desc', 'label' => 'Mot-clé dans la description', 'weight' => 15,
            'score' => 0, 'max' => 15,
            'detail' => 'Mot-clé « ' . $keyword . ' » absent de la description',
        );
    }

    /**
     * 5. Semantic alignment — cosine similarity (embeddings) or word overlap (fallback)
     */
    private function score_semantic_fallback( $title, $desc, $content, $post_id = 0 ) {
        if ( ! $content || ( ! $title && ! $desc ) ) {
            return array(
                'id' => 'semantic', 'label' => 'Alignement sémantique', 'weight' => 20,
                'score' => 5, 'max' => 20,
                'detail' => 'Contenu insuffisant pour l\'analyse sémantique — score neutre',
            );
        }

        // ── Phase 2b upgrade: cosine similarity via embeddings ──
        if ( $post_id && class_exists( 'HTS_Embeddings' ) ) {
            $emb = new HTS_Embeddings();
            // Check if this post has an embedding AND cocon data exists
            $cocon_data = class_exists( 'HTS_Cocon' ) ? \HTS_Cocon::get_cached_cocon_data( class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '' ) : get_option( 'hts_cocon_data', array() );
            if ( ! empty( $cocon_data ) && is_array( $cocon_data ) ) {
                // Find this post's cluster and avg similarity
                foreach ( $cocon_data as $cluster ) {
                    if ( empty( $cluster['pages'] ) ) continue;
                    foreach ( $cluster['pages'] as $page ) {
                        if ( (int) ( $page['post_id'] ?? 0 ) === (int) $post_id ) {
                            $avg_sim = (float) ( $page['avg_similarity'] ?? 0 );
                            if ( $avg_sim > 0 ) {
                                // Map similarity [0.20..0.80] → score [0..20]
                                $normalized = max( 0, min( 1, ( $avg_sim - 0.20 ) / 0.60 ) );
                                $score = round( $normalized * 20 );
                                if ( $avg_sim >= 0.60 ) {
                                    $detail = 'Excellent — similarité cosine ' . round( $avg_sim, 2 ) . ' avec le cluster (via embeddings)';
                                } elseif ( $avg_sim >= 0.40 ) {
                                    $detail = 'Bon — similarité cosine ' . round( $avg_sim, 2 ) . ' (via embeddings)';
                                } else {
                                    $detail = 'Faible — similarité cosine ' . round( $avg_sim, 2 ) . '. Article peu aligné avec son cluster';
                                }
                                return array(
                                    'id' => 'semantic', 'label' => 'Alignement sémantique', 'weight' => 20,
                                    'score' => min( 20, $score ), 'max' => 20, 'detail' => $detail,
                                    'method' => 'cosine',
                                );
                            }
                            break 2;
                        }
                    }
                }
            }
        }

        // ── Fallback: word overlap (pre-embeddings) ──
        $meta_words = array_unique( explode( ' ', mb_strtolower( $title . ' ' . $desc ) ) );
        $meta_words = array_filter( $meta_words, function( $w ) { return mb_strlen( $w ) > 3; } );

        $content_lower = mb_strtolower( mb_substr( $content, 0, 5000 ) );
        $found = 0;
        foreach ( $meta_words as $word ) {
            if ( mb_strpos( $content_lower, $word ) !== false ) $found++;
        }
        $total_words = count( $meta_words );
        $ratio = $total_words > 0 ? $found / $total_words : 0;
        $score = round( $ratio * 20 );

        if ( $ratio >= 0.8 ) {
            $detail = 'Excellent — ' . round( $ratio * 100 ) . '% des termes meta trouvés dans le contenu';
        } elseif ( $ratio >= 0.5 ) {
            $detail = 'Bon — ' . round( $ratio * 100 ) . '% des termes alignés';
        } else {
            $detail = 'Faible — ' . round( $ratio * 100 ) . '% seulement. Meta et contenu divergent';
        }

        return array(
            'id' => 'semantic', 'label' => 'Alignement sémantique', 'weight' => 20,
            'score' => min( 20, $score ), 'max' => 20, 'detail' => $detail,
            'method' => 'word_overlap',
        );
    }

    /**
     * 6. Quality signals — power words, CTA, no stuffing, format
     */
    private function score_quality_signals( $title, $desc, $keyword ) {
        $score   = 0;
        $signals = array();

        $title_lower = mb_strtolower( $title );
        $desc_lower  = mb_strtolower( $desc );
        $combined    = $title_lower . ' ' . $desc_lower;

        // Power words (max 4 pts)
        $pw_found = 0;
        foreach ( self::$power_words as $pw ) {
            if ( mb_strpos( $combined, $pw ) !== false ) $pw_found++;
        }
        if ( $pw_found >= 2 ) {
            $score += 4; $signals[] = $pw_found . ' power words';
        } elseif ( $pw_found === 1 ) {
            $score += 2; $signals[] = '1 power word';
        }

        // CTA in description (max 4 pts)
        if ( $desc ) {
            $cta_found = false;
            foreach ( self::$cta_words as $cta ) {
                if ( mb_strpos( $desc_lower, $cta ) !== false ) {
                    $cta_found = true;
                    break;
                }
            }
            if ( $cta_found ) {
                $score += 4; $signals[] = 'CTA détecté';
            }
        }

        // Number in title (boosts CTR) (max 3 pts)
        if ( preg_match( '/\d+/', $title ) ) {
            $score += 3; $signals[] = 'Nombre dans le titre';
        }

        // No keyword stuffing (max 4 pts penalty)
        if ( $keyword ) {
            $kw_lower = mb_strtolower( $keyword );
            $kw_count = mb_substr_count( $title_lower, $kw_lower );
            if ( $kw_count > 1 ) {
                $score -= 3; $signals[] = 'Keyword stuffing titre (' . $kw_count . 'x)';
            } else {
                $score += 4; $signals[] = 'Pas de stuffing';
            }
        } else {
            $score += 2;
        }

        $score = max( 0, min( 15, $score ) );
        $detail = empty( $signals ) ? 'Aucun signal de qualité détecté' : implode( ' · ', $signals );

        return array(
            'id' => 'quality', 'label' => 'Signaux de qualité', 'weight' => 15,
            'score' => $score, 'max' => 15, 'detail' => $detail,
        );
    }

    /**
     * v2.5.13: Penalize fake numbers in title and description.
     *
     * Detects patterns like "7 steps", "5 conseils", "10 strategies" and checks
     * if the number matches the actual H2 count. For non-listicle articles,
     * ANY number + action-word pattern is penalized.
     *
     * @since 2.5.13
     */
    private function score_number_accuracy( $post_id, $title, $desc ) {
        $score  = 10; // Start with full score, deduct for violations
        $detail = 'Nombres cohérents';

        // Get real H2 count
        $full_content = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $full_content = HTS_Content_Extractor::get_content( $post_id );
        } else {
            $p = get_post( $post_id );
            $full_content = $p ? $p->post_content : '';
        }
        $h2_count = preg_match_all( '/<h2[\s>]/i', $full_content );

        // Detect listicle (50%+ H2 look like list items)
        $list_patterns = 0;
        if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $full_content, $h2m ) ) {
            foreach ( $h2m[1] as $h ) {
                $h = trim( wp_strip_all_tags( $h ) );
                if ( preg_match( '/^\d+[\.\)\s]|^(tip|step|conseil|étape|astuce|strateg|method|way|reason|benefit)/i', $h ) ) {
                    $list_patterns++;
                }
            }
        }
        $is_listicle = ( $h2_count > 0 && $list_patterns >= ( $h2_count * 0.5 ) );

        // Pattern: number + action word (in title or description)
        $number_pattern = '/\b(\d{1,2})\s+(step|steps|tip|tips|conseil|conseils|étape|étapes|astuce|astuces|strateg|method|methods|méthode|méthodes|way|ways|reason|reasons|raison|raisons|clé|clés|key|keys|technique|techniques|essential|powerful|incontournable|best|meilleur|top|format|formats|point|points|secret|secrets|rule|rules|règle|règles)\b/i';

        $combined = $title . ' ' . $desc;
        if ( preg_match_all( $number_pattern, $combined, $matches ) ) {
            foreach ( $matches[1] as $found_number ) {
                $num = (int) $found_number;
                if ( $is_listicle ) {
                    // Listicle: number must match H2 count (excluding FAQ)
                    $real_count = $h2_count;
                    if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $full_content, $faq_check ) ) {
                        foreach ( $faq_check[1] as $fh ) {
                            if ( preg_match( '/^FAQ|^Questions?\s/i', trim( wp_strip_all_tags( $fh ) ) ) ) $real_count--;
                        }
                    }
                    if ( $num !== $real_count ) {
                        $score = 0;
                        $detail = 'Faux nombre : "' . $num . '" utilisé mais l\'article a ' . $real_count . ' sections';
                        break;
                    }
                } else {
                    // Non-listicle: ANY number + action word is suspicious
                    $score = 0;
                    $detail = 'Nombre inventé : "' . $num . ' ' . $matches[2][0] . '" — cet article n\'est pas une liste';
                    break;
                }
            }
        }

        return array(
            'id' => 'number_accuracy', 'label' => 'Exactitude des nombres', 'weight' => 10,
            'score' => $score, 'max' => 10, 'detail' => $detail,
        );
    }

    /* ═══════════════════════════════════════════════════
     *  2. AI META GENERATION — 3 variants scored
     * ═══════════════════════════════════════════════════ */

    /**
     * Generate 3 meta title + description variants.
     *
     * @param int $post_id
     * @return array { variants, tokens_used, current } or { error }
     */
    public function generate_variants( $post_id, $skip_rate_limit = false ) {
        // Toujours utiliser GPT-4o-mini pour les meta tags (coût optimal)
        $openai_key = hts_get_openai_key();

        if ( empty( $openai_key ) ) {
            // Fallback sur Anthropic si pas de clé OpenAI
            $anthropic_key = hts_get_anthropic_key();
            if ( empty( $anthropic_key ) || strlen( $anthropic_key ) < 20 ) {
                return array( 'error' => 'Aucune clé API configurée. Ajoutez votre clé OpenAI dans Hack The SEO > Réglages.' );
            }
            $use_anthropic = true;
        } else {
            $use_anthropic = false;
        }

        // Rate limit: 1 gen per post per hour (skip for inbox preview)
        if ( ! $skip_rate_limit ) {
            $last_gen = (int) get_post_meta( $post_id, '_hts_meta_gen_ts', true );
            if ( $last_gen && ( time() - $last_gen ) < HOUR_IN_SECONDS ) {
                $wait = ceil( ( HOUR_IN_SECONDS - ( time() - $last_gen ) ) / 60 );
                return array( 'error' => 'Limite : 1 generation par heure. Reessayez dans ' . $wait . ' min.' );
            }
        }

        $post = get_post( $post_id );
        if ( ! $post ) return array( 'error' => 'Article introuvable' );

        // ── OPTIM 3.1 : Cache intelligent — skip IA si pas de changement significatif ──
        $content_raw_for_hash = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content_raw_for_hash = wp_strip_all_tags( HTS_Content_Extractor::get_content( $post_id ) );
        } else {
            $content_raw_for_hash = wp_strip_all_tags( $post->post_content );
        }
        // Hash des 4000 premiers chars (ce que l'IA reçoit) + titre + keyword focus
        $keyword_for_hash = $this->get_focus_keyword( $post_id );
        $meta_content_hash = md5( mb_substr( $content_raw_for_hash, 0, 4000 ) . '|' . $post->post_title . '|' . $keyword_for_hash );
        $meta_stored_hash  = get_post_meta( $post_id, '_hts_meta_content_hash', true );

        // Word count check — changement < 10% = pas significatif
        $meta_current_wc = str_word_count( $content_raw_for_hash );
        $meta_stored_wc  = (int) get_post_meta( $post_id, '_hts_meta_word_count', true );
        $meta_wc_changed = ( $meta_stored_wc > 0 && abs( $meta_current_wc - $meta_stored_wc ) / max( 1, $meta_stored_wc ) > 0.10 );

        if ( $meta_stored_hash === $meta_content_hash && ! $meta_wc_changed ) {
            // Contenu inchangé — vérifier si on a déjà des variants stockées
            $cached_variants = get_post_meta( $post_id, '_hts_meta_variants', true );
            if ( ! empty( $cached_variants ) ) {
                if ( function_exists( 'hts_debug_log' ) ) {
                    hts_debug_log( '[Meta] Cache hit (content unchanged) for post #' . $post_id );
                }
                $sk_key = 'hts_metas_skipped_' . wp_date( 'Y-m' );
                update_option( $sk_key, (int) get_option( $sk_key, 0 ) + 1, false );
                return array(
                    'variants'    => $cached_variants,
                    'tokens_used' => 0,
                    'cached'      => true,
                    'current'     => array(
                        'title'       => $this->get_effective_title( $post_id ),
                        'description' => $this->get_effective_desc( $post_id ),
                        'score'       => $this->score_post( $post_id )['score'],
                    ),
                );
            }
        }

        $keyword = $this->get_focus_keyword( $post_id );
        $content = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content = wp_strip_all_tags( HTS_Content_Extractor::get_content( $post_id ) );
        }
        $content = mb_substr( $content, 0, 4000 );

        $cats = implode( ', ', wp_get_post_categories( $post_id, array( 'fields' => 'names' ) ) );
        $current_title = $this->get_effective_title( $post_id );
        $current_desc  = $this->get_effective_desc( $post_id );

        $prompt = $this->build_generation_prompt( $post->post_title, $keyword, $content, $cats, $current_title, $current_desc, $post_id );

        // Détection de la langue pour le system prompt
        $lang_code = get_post_meta( $post_id, '_hts_content_lang', true );
        if ( ! $lang_code && class_exists( 'HTS_Language' ) ) {
            $lang_code = HTS_Language::get_post_language( $post_id );
        }
        if ( ! $lang_code ) {
            $lang_code = substr( get_locale(), 0, 2 );
        }
        $lang_names = array(
            'fr' => 'français', 'en' => 'anglais', 'es' => 'espagnol', 'de' => 'allemand',
            'it' => 'italien', 'pt' => 'portugais', 'nl' => 'néerlandais', 'ja' => 'japonais',
            'zh' => 'chinois', 'ar' => 'arabe', 'ru' => 'russe', 'ko' => 'coréen',
            'pl' => 'polonais', 'sv' => 'suédois', 'tr' => 'turc',
        );
        $lang_label = $lang_names[ $lang_code ] ?? $lang_code;

        $system_msg = 'Tu es un expert SEO senior. Tu génères des meta tags en ' . $lang_label . ' UNIQUEMENT. Tu maîtrises le comptage de caractères. Tu réponds UNIQUEMENT en JSON valide, sans markdown ni backticks. IMPORTANT : chaque mot du title et de la description DOIT être en ' . $lang_label . ', même si le contenu de l\'article est dans une autre langue.';

        if ( $use_anthropic ) {
            // ── Anthropic API (Claude Haiku 4.5) ──
            $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
                'timeout' => 45,
                'headers' => array(
                    'x-api-key'         => $anthropic_key,
                    'anthropic-version'  => '2023-06-01',
                    'Content-Type'       => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'      => 'claude-haiku-4-5-20251001',
                    'max_tokens' => 1200,
                    'system'     => $system_msg,
                    'messages'   => array(
                        array( 'role' => 'user', 'content' => $prompt ),
                    ),
                ) ),
            ) );

            if ( is_wp_error( $response ) ) {
                return array( 'error' => 'Erreur API Anthropic : ' . $response->get_error_message() );
            }

            $http_code = wp_remote_retrieve_response_code( $response );
            if ( $http_code !== 200 ) {
                return array( 'error' => 'Anthropic HTTP ' . $http_code );
            }

            $data   = json_decode( wp_remote_retrieve_body( $response ), true );
            $tokens = (int) ( ( $data['usage']['input_tokens'] ?? 0 ) + ( $data['usage']['output_tokens'] ?? 0 ) );
            $text   = $data['content'][0]['text'] ?? '';
        } else {
            // ── Fallback OpenAI (GPT-4o-mini) ──
            $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
                'timeout' => 45,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $openai_key,
                    'Content-Type'  => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'       => 'gpt-4o-mini',
                    'messages'    => array(
                        array( 'role' => 'system', 'content' => $system_msg ),
                        array( 'role' => 'user', 'content' => $prompt ),
                    ),
                    'temperature' => 0.8,
                    'max_tokens'  => 1200,
                ) ),
            ) );

            if ( is_wp_error( $response ) ) {
                return array( 'error' => 'Erreur API OpenAI : ' . $response->get_error_message() );
            }

            $http_code = wp_remote_retrieve_response_code( $response );
            if ( $http_code !== 200 ) {
                return array( 'error' => 'OpenAI HTTP ' . $http_code );
            }

            $data   = json_decode( wp_remote_retrieve_body( $response ), true );
            $tokens = (int) ( $data['usage']['total_tokens'] ?? 0 );
            $text   = $data['choices'][0]['message']['content'] ?? '';
        }

        // Track usage
        if ( $tokens > 0 ) {
            $usage = get_option( 'hts_ai_usage', array() );
            $mk = wp_date( 'Y-m' );
            $usage[ $mk ] = ( (int) ( $usage[ $mk ] ?? 0 ) ) + $tokens;
            update_option( 'hts_ai_usage', $usage, false );

            // ── Sprint 2 : Compteurs granulaires pour page de coûts ──
            $m_calls_key  = 'hts_metas_calls_' . $mk;
            $m_tokens_key = 'hts_metas_tokens_' . $mk;
            update_option( $m_calls_key, (int) get_option( $m_calls_key, 0 ) + 1, false );
            update_option( $m_tokens_key, (int) get_option( $m_tokens_key, 0 ) + $tokens, false );

            // Ventilation par provider
            $meta_prov = $use_anthropic ? 'anthropic' : 'openai';
            $m_prov_key = 'hts_metas_tokens_' . $meta_prov . '_' . $mk;
            update_option( $m_prov_key, (int) get_option( $m_prov_key, 0 ) + $tokens, false );
        }

        // Record gen timestamp
        update_post_meta( $post_id, '_hts_meta_gen_ts', time() );

        // ── OPTIM 3.1 : Stocker le content hash + word count pour le cache ──
        update_post_meta( $post_id, '_hts_meta_content_hash', $meta_content_hash );
        update_post_meta( $post_id, '_hts_meta_word_count', $meta_current_wc );

        $text = preg_replace( '/^```json\s*|```$/m', '', trim( $text ) );
        $variants_raw = json_decode( $text, true );

        if ( ! is_array( $variants_raw ) || empty( $variants_raw['variants'] ) ) {
            return array( 'error' => 'Réponse IA invalide — réessayez', 'raw' => $text );
        }

        // Score each variant + post-traitement qualité (Session L)
        $variants = array();
        $desc_max = 155;
        $title_min = 50;
        $title_max = 60;

        foreach ( $variants_raw['variants'] as $v ) {
            $t = sanitize_text_field( $v['title'] ?? '' );
            $d = sanitize_textarea_field( $v['description'] ?? '' );
            if ( ! $t ) continue;

            // ── Post-traitement : tronquer descriptions trop longues ──
            if ( mb_strlen( $d ) > $desc_max ) {
                // Couper proprement au dernier espace avant la limite
                $d_cut = mb_substr( $d, 0, $desc_max - 1 );
                $last_space = mb_strrpos( $d_cut, ' ' );
                $last_dot = mb_strrpos( $d_cut, '.' );
                // Préférer couper à la dernière phrase complète
                if ( $last_dot && $last_dot > $desc_max - 40 ) {
                    $d = mb_substr( $d, 0, $last_dot + 1 );
                } elseif ( $last_space ) {
                    $d = mb_substr( $d, 0, $last_space ) . '.';
                }
            }

            $score_result = $this->score_variant( $post_id, $t, $d, $keyword );

            // ── Post-traitement : malus pour title hors-spec ──
            $title_len = mb_strlen( $t );
            if ( $title_len < $title_min || $title_len > $title_max ) {
                $score_result['score'] = max( 0, $score_result['score'] - 10 );
            }

            $variants[] = array(
                'title'       => $t,
                'description' => $d,
                'strategy'    => $v['strategy'] ?? '',
                'score'       => $score_result['score'],
                'grade'       => $score_result['grade'],
                'criteria'    => $score_result['criteria'],
            );
        }

        // Sort by score desc
        usort( $variants, function( $a, $b ) { return $b['score'] <=> $a['score']; } );

        $current_score = $this->score_post( $post_id );

        // ── OPTIM 3.1 : Stocker les variants pour le cache ──
        update_post_meta( $post_id, '_hts_meta_variants', $variants );

        return array(
            'variants'    => $variants,
            'tokens_used' => $tokens,
            'current'     => array(
                'title'       => $current_title,
                'description' => $current_desc,
                'score'       => $current_score['score'],
            ),
        );
    }

    /**
     * Score a variant without saving
     */
    private function score_variant( $post_id, $title, $desc, $keyword ) {
        $content = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content = wp_strip_all_tags( HTS_Content_Extractor::get_content( $post_id ) );
        }

        $criteria = array();
        $criteria[] = $this->score_title_length( $title );
        $criteria[] = $this->score_desc_length( $desc );
        $criteria[] = $this->score_keyword_in_title( $title, $keyword );
        $criteria[] = $this->score_keyword_in_desc( $desc, $keyword );
        $criteria[] = $this->score_semantic_fallback( $title, $desc, $content, $post_id );
        $criteria[] = $this->score_quality_signals( $title, $desc, $keyword );

        // v2.5.13: Penalize fake numbers in title AND description
        $criteria[] = $this->score_number_accuracy( $post_id, $title, $desc );

        $raw = 0; $max = 0;
        foreach ( $criteria as $c ) { $raw += $c['score']; $max += $c['max']; }
        $total = $max > 0 ? round( $raw / $max * 100 ) : 0;

        return array( 'score' => $total, 'grade' => $this->grade( $total ), 'criteria' => $criteria );
    }

    /**
     * Build the generation prompt.
     *
     * @since 2.4.7 — language detection + improved instructions
     * @param string $post_title
     * @param string $keyword
     * @param string $content
     * @param string $cats
     * @param string $current_title
     * @param string $current_desc
     * @param int    $post_id  (optional) For language detection
     * @return string
     */
    private function build_generation_prompt( $post_title, $keyword, $content, $cats, $current_title, $current_desc, $post_id = 0 ) {
        // ── Détection de la langue ──
        // Priorité : réglage manuel > plugin multilingue > locale site
        $lang_code = '';
        if ( $post_id > 0 ) {
            $lang_code = get_post_meta( $post_id, '_hts_content_lang', true );
        }
        if ( ! $lang_code && $post_id > 0 && class_exists( 'HTS_Language' ) ) {
            $lang_code = HTS_Language::get_post_language( $post_id );
        }
        if ( ! $lang_code ) {
            $lang_code = substr( get_locale(), 0, 2 );
        }
        $lang_names = array(
            'fr' => 'français', 'en' => 'anglais', 'es' => 'espagnol', 'de' => 'allemand',
            'it' => 'italien', 'pt' => 'portugais', 'nl' => 'néerlandais', 'ja' => 'japonais',
            'zh' => 'chinois', 'ar' => 'arabe', 'ru' => 'russe', 'ko' => 'coréen',
            'pl' => 'polonais', 'sv' => 'suédois', 'tr' => 'turc',
        );
        $lang_label = $lang_names[ $lang_code ] ?? $lang_code;

        // ── Power words adaptés à la langue ──
        $power_words_map = array(
            'fr' => 'ultime, guide, meilleur, découvrez, top, essentiel, complet, secret, prouvé, efficace, incontournable, pratique',
            'en' => 'ultimate, guide, best, discover, top, essential, complete, secret, proven, powerful, must-read, practical',
            'es' => 'definitivo, guía, mejor, descubre, top, esencial, completo, secreto, probado, eficaz',
            'de' => 'ultimativ, Leitfaden, beste, entdecken, Top, wesentlich, komplett, Geheimnis, bewährt, praktisch',
        );
        $power_words = $power_words_map[ $lang_code ] ?? $power_words_map['en'];

        $cta_map = array(
            'fr' => 'découvrez, apprenez, lisez, explorez, consultez notre guide',
            'en' => 'discover, learn, read, explore, check our guide',
            'es' => 'descubre, aprende, lee, explora, consulta nuestra guía',
            'de' => 'entdecken Sie, erfahren Sie, lesen Sie, erkunden Sie',
        );
        $cta_words = $cta_map[ $lang_code ] ?? $cta_map['en'];

        $content_excerpt = mb_substr( $content, 0, 2000 );

        // v2.5.12: Extract H2 structure from content for accurate title generation
        // This prevents the AI from inventing numbers like "7 steps" when the article has only 3
        $h2_structure = '';
        $post_obj = get_post( $post_id );
        $full_content = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $full_content = HTS_Content_Extractor::get_content( $post_id );
        } else {
            $full_content = $post_obj ? $post_obj->post_content : '';
        }
        if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $full_content, $h2_matches ) ) {
            $h2_titles = array_map( 'wp_strip_all_tags', $h2_matches[1] );
            $h2_count = count( $h2_titles );
            $h2_list = '';
            foreach ( $h2_titles as $i => $h2t ) {
                $h2_list .= ( $i + 1 ) . '. ' . trim( $h2t ) . "\n";
            }

            // Detect if article is list-type (H2 titles that look like steps/tips/items)
            $list_patterns = 0;
            $list_keywords = array( 'step', 'tip', 'conseil', 'étape', 'astuce', 'method', 'méthode', 'way', 'reason', 'raison', 'strategy', 'stratégie', 'benefit', 'avantage', '#', 'rule', 'règle' );
            foreach ( $h2_titles as $h2t ) {
                $h2_lower = mb_strtolower( $h2t );
                // Check if H2 starts with a number or matches list patterns
                if ( preg_match( '/^\d+[\.\)\s]/', trim( $h2t ) ) ) {
                    $list_patterns++;
                } else {
                    foreach ( $list_keywords as $lk ) {
                        if ( mb_strpos( $h2_lower, $lk ) !== false ) { $list_patterns++; break; }
                    }
                }
            }

            $is_list_article = ( $list_patterns >= ( $h2_count * 0.5 ) ); // 50%+ H2 look like list items

            // v2.5.12: Deep content analysis — count actionable items beyond H2
            // Scan H3s and <li> items for real countable elements (tips, steps, strategies)
            $h3_count = 0;
            $h3_list_str = '';
            if ( preg_match_all( '/<h3[^>]*>(.*?)<\/h3>/si', $full_content, $h3_matches ) ) {
                $h3_titles = array_map( function( $h ) { return trim( wp_strip_all_tags( $h ) ); }, $h3_matches[1] );
                $h3_count = count( $h3_titles );
                // Check if H3s look like actionable items
                $h3_actionable = 0;
                foreach ( $h3_titles as $h3t ) {
                    if ( preg_match( '/^\d+[\.\)\s]|^(tip|step|conseil|étape|astuce|strateg)/i', $h3t ) ) {
                        $h3_actionable++;
                    }
                }
                if ( $h3_actionable >= 3 ) {
                    $h3_sample = array_slice( $h3_titles, 0, 10 );
                    $h3_list_str = "\nSous-sections H3 ({$h3_count} dont {$h3_actionable} qui ressemblent à des items actionnables) :\n- " . implode( "\n- ", $h3_sample ) . "\n";
                }
            }

            // Count numbered list items in content
            $li_count = preg_match_all( '/<li[^>]*>/i', $full_content );

            // Build the best number suggestion
            $suggested_number = '';
            if ( $is_list_article ) {
                // Exclude FAQ H2 from count
                $real_list_h2 = $h2_count;
                foreach ( $h2_titles as $h2t ) {
                    if ( preg_match( '/^FAQ|^Questions?\s/i', trim( $h2t ) ) ) $real_list_h2--;
                }
                $suggested_number = (string) $real_list_h2;
            }

            if ( $is_list_article ) {
                $h2_structure = "\n═══ STRUCTURE RÉELLE DE L'ARTICLE ({$h2_count} sections) ═══\n{$h2_list}{$h3_list_str}IMPORTANT : Cet article EST structuré comme une liste. Si tu utilises un nombre dans le title OU la description, utilise EXACTEMENT {$suggested_number} (sections hors FAQ). NE JAMAIS inventer un autre nombre.\n";
            } else {
                // Not a listicle — but check if H3s or content has countable items
                $countable_hint = '';
                if ( ! empty( $h3_list_str ) ) {
                    $countable_hint = $h3_list_str . "Tu peux utiliser le nombre de sous-sections actionnables ({$h3_actionable}) si c'est pertinent pour le title.\n";
                } elseif ( $li_count >= 5 ) {
                    $countable_hint = "L'article contient {$li_count} éléments de liste (<li>). Tu peux mentionner ce nombre si pertinent.\n";
                }
                $h2_structure = "\n═══ STRUCTURE RÉELLE DE L'ARTICLE ({$h2_count} sections thématiques) ═══\n{$h2_list}{$countable_hint}ATTENTION : Les sections H2 sont des thèmes différents, PAS une liste de conseils/étapes numérotées. NE PAS écrire \"{$h2_count} tips\" ou \"{$h2_count} steps\" ni dans le title NI dans la description. INTERDIT d'inventer un nombre (\"7 powerful steps\", \"5 essential methods\", \"10 conseils\") dans le title OU la description. Privilégie des formulations descriptives SANS nombre, SAUF si un nombre réel et vérifiable du contenu est disponible ci-dessus.\n";
            }
        } else {
            $h2_structure = "\n═══ STRUCTURE ═══\nL'article n'a pas de sous-titres H2 clairement définis. NE PAS inventer de nombre dans le title NI dans la description.\n";
        }

        // ── Instruction mot-clé adaptée ──
        if ( $keyword ) {
            $kw_instruction = "Mot-clé focus : \"{$keyword}\"\nCe mot-clé DOIT apparaître dans les 5 premiers mots du title ET 1 fois naturellement dans la description.";
        } else {
            $kw_instruction = "AUCUN mot-clé défini. Tu DOIS :\n1. Lire attentivement l'extrait du contenu ci-dessous\n2. Identifier le SUJET PRINCIPAL en 2-3 mots (ex: \"préparation mentale retraite\", \"accompagnement prolongé\", \"course automobile\")\n3. Utiliser ce sujet comme mot-clé dans les premiers mots du title\n4. Mentionner ce sujet 1 fois dans la description";
        }

        $site_name = get_bloginfo( 'name' );

        // ── Exemples calibrés par langue pour le comptage ──
        $examples_map = array(
            'fr' => "EXEMPLES DE TITRES PARFAITS (50-58 caractères) :\n- \"Préparation mentale retraite : 7 étapes essentielles\" (54 car.) ✅\n- \"Guide complet accompagnement prolongé de 2 mois en 2025\" (57 car.) ✅\n- \"Course automobile : 5 formats et règles à connaître\" (52 car.) ✅\n- \"Psilocybine : effets immédiats sur le cerveau\" (47 car.) TROP COURT\n- \"Test push\" (9 car.) BEAUCOUP TROP COURT\n\nEXEMPLES DE DESCRIPTIONS PARFAITES (135-150 caractères) :\n- \"Découvrez les 7 étapes clés pour préparer votre esprit avant une retraite. Conseils pratiques, exercices et erreurs à éviter. Lisez le guide.\" (143 car.) ✅\n- \"Tout savoir sur le programme en 8 semaines.\" (44 car.) TROP COURT\n- \"Ce guide ultra complet présente absolument toutes les informations dont vous avez besoin pour comprendre en profondeur le sujet complexe et fascinant de la préparation mentale.\" (178 car.) TROP LONG",
            'en' => "PERFECT TITLE EXAMPLES (50-58 characters):\n- \"Car Racing Explained: 7 Formats and Rules to Know\" (51 ch.) ✅\n- \"Complete 2-Month Integration Guide: 8-Week Framework\" (54 ch.) ✅\n- \"Mental prep\" (11 ch.) WAY TOO SHORT\n\nPERFECT DESCRIPTION EXAMPLES (135-150 characters):\n- \"Learn the 7 key steps to prepare your mind before a retreat. Practical tips, exercises, and mistakes to avoid. Read the full guide.\" (142 ch.) ✅",
        );
        $examples = $examples_map[ $lang_code ] ?? $examples_map['fr'];

        return <<<PROMPT
MISSION : Générer 3 variantes de meta title + meta description pour maximiser le CTR Google.

═══ ARTICLE ═══
Titre WordPress : {$post_title}
{$kw_instruction}
Catégories : {$cats}
Langue : {$lang_label} — TOUT doit être rédigé en {$lang_label}. AUCUN mot en anglais ni autre langue. Si le contenu est en anglais, TRADUIS le sujet en {$lang_label}.

Extrait du contenu (lis-le attentivement pour comprendre le sujet réel) :
---
{$content_excerpt}
---
{$h2_structure}
═══ RÈGLES TITLE (STRICTES) ═══
• Longueur OBLIGATOIRE : entre 50 et 58 caractères. VÉRIFIE en comptant chaque caractère.
  - Moins de 50 → INTERDIT, ajoute des mots descriptifs
  - Plus de 60 → INTERDIT, raccourcis
• Commence par le sujet/mot-clé principal (front-loading)
• NOMBRES : Si tu utilises un nombre dans le title (ex: "7 étapes", "5 conseils"), ce nombre DOIT correspondre EXACTEMENT au nombre de sections H2 listées ci-dessus. NE JAMAIS inventer un nombre. Si l'article a 4 H2, écris "4 étapes", pas "7 étapes". Si tu n'es pas sûr du nombre exact, N'UTILISE PAS de nombre.
• Inclus 1 power word : {$power_words}
• PAS de nom du site "{$site_name}" (ajouté automatiquement)
• Le title doit refléter le VRAI contenu, pas un titre clickbait générique

═══ RÈGLES DESCRIPTION (STRICTES) ═══
• Longueur OBLIGATOIRE : entre 135 et 150 caractères. PAS PLUS de 150. VÉRIFIE en comptant.
  - Moins de 130 → INTERDIT, développe
  - Plus de 150 → INTERDIT, Google tronquera. Raccourcis.
  - OBJECTIF : viser exactement 140-148 caractères
• DOIT être SPÉCIFIQUE : mentionne des éléments concrets du contenu (chiffres, étapes, bénéfices réels tirés de l'article)
• INTERDIT les descriptions vagues comme "Découvrez tout sur X" ou "Guide complet sur X"
• Termine par un CTA court : {$cta_words}
• 1 seule phrase ou 2 phrases courtes maximum
• Comme pour le title : tout nombre mentionné doit correspondre à la réalité du contenu. INTERDIT d'inventer des nombres. Si l'article n'est PAS une liste numérotée (voir STRUCTURE ci-dessus), NE PAS écrire "X steps", "X methods", "X conseils", "X stratégies" etc. dans la description. Préfère des formulations sans nombre comme "les clés pour", "comment optimiser", "guide pratique".

{$examples}

═══ STRATÉGIES (1 différente par variante) ═══
Variante 1 : Bénéfice concret + données chiffrées tirées du contenu RÉEL
Variante 2 : Question/curiosité qui cible un problème du lecteur
Variante 3 : Format guide pratique (utiliser le nombre EXACT de H2 si pertinent, sinon ne pas mettre de nombre)

═══ VÉRIFICATION FINALE ═══
Avant de répondre, pour CHAQUE variante :
1. Compte les caractères du title → doit être entre 50 et 58
2. Compte les caractères de la description → doit être entre 135 et 150
3. Vérifie que le sujet principal est dans les 5 premiers mots du title
4. Vérifie que la description mentionne un élément SPÉCIFIQUE du contenu
5. Vérifie que la description se termine par un CTA
6. Si un nombre est utilisé dans le title OU la description (ex: "7 conseils", "5 steps"), VÉRIFIE qu'il correspond au nombre RÉEL de sections listées dans STRUCTURE ci-dessus. Si l'article n'est PAS un listicle, SUPPRIME le nombre et reformule sans.

Réponds UNIQUEMENT avec ce JSON :
{
  "variants": [
    { "title": "...", "description": "...", "strategy": "..." },
    { "title": "...", "description": "...", "strategy": "..." },
    { "title": "...", "description": "...", "strategy": "..." }
  ]
}
PROMPT;
    }

    /* ═══════════════════════════════════════════════════
     *  3. APPLY / ROLLBACK
     * ═══════════════════════════════════════════════════ */

    /**
     * On save_post: detect meta change, log to history
     */
    public function on_save_post( $post_id, $post ) {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;
        if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) return;

        // Re-score silently
        $this->score_post( $post_id );
    }

    /* ═══════════════════════════════════════════════════
     *  4. AJAX ENDPOINTS
     * ═══════════════════════════════════════════════════ */

    public function ajax_get_score() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'post_id requis' );
        wp_send_json_success( $this->score_post( $post_id ) );
    }

    public function ajax_generate() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'post_id requis' );

        $result = $this->generate_variants( $post_id );
        if ( isset( $result['error'] ) ) {
            wp_send_json_error( $result );
        }
        wp_send_json_success( $result );
    }

    public function ajax_apply() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        $title   = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
        $desc    = sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) );
        if ( ! $post_id ) wp_send_json_error( 'post_id requis' );

        // Snapshot before
        $old_title = $this->get_effective_title( $post_id );
        $old_desc  = $this->get_effective_desc( $post_id );
        $old_score = (int) get_post_meta( $post_id, self::SCORE_META, true );

        // Save snapshot for rollback
        update_post_meta( $post_id, self::SNAPSHOT_META, array(
            'title'      => $old_title,
            'description'=> $old_desc,
            'score'      => $old_score,
            'saved_at'   => current_time( 'mysql' ),
        ) );

        // Apply
        if ( $title ) update_post_meta( $post_id, '_hts_meta_title', $title );
        if ( $desc )  update_post_meta( $post_id, '_hts_meta_description', $desc );

        // Re-score
        $score = $this->score_post( $post_id );

        // Log history
        $history = get_post_meta( $post_id, self::HISTORY_META, true );
        if ( ! is_array( $history ) ) $history = array();
        $history[] = array(
            'title'      => $title,
            'description'=> $desc,
            'old_title'  => $old_title,
            'old_desc'   => $old_desc,
            'score'      => $score['score'],
            'old_score'  => $old_score,
            'source'     => 'ai_generated',
            'changed_at' => current_time( 'mysql' ),
        );
        $history = array_slice( $history, -20 );
        update_post_meta( $post_id, self::HISTORY_META, $history );

        // Notify Global Score
        if ( class_exists( 'HTS_Global_Score' ) ) {
            $gs = new HTS_Global_Score();
            $gs->compute_and_save( $post_id, true );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                '🤖 Meta IA appliquée: « ' . get_the_title( $post_id ) . ' » — Score ' . $old_score . ' → ' . $score['score'] . '/100',
                'success', 'meta_score'
            );
        }

        wp_send_json_success( array(
            'message'   => 'Meta appliquée — score ' . $score['score'] . '/100',
            'score'     => $score,
            'old_score' => $old_score,
        ) );
    }

    public function ajax_rollback() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission refusée' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'post_id requis' );

        $snapshot = get_post_meta( $post_id, self::SNAPSHOT_META, true );
        if ( ! is_array( $snapshot ) || empty( $snapshot['title'] ) ) {
            wp_send_json_error( array( 'error' => 'Aucun snapshot à restaurer' ) );
        }

        // Restore
        update_post_meta( $post_id, '_hts_meta_title', $snapshot['title'] );
        if ( ! empty( $snapshot['description'] ) ) {
            update_post_meta( $post_id, '_hts_meta_description', $snapshot['description'] );
        } else {
            delete_post_meta( $post_id, '_hts_meta_description' );
        }

        // Clean snapshot
        delete_post_meta( $post_id, self::SNAPSHOT_META );

        // Re-score
        $score = $this->score_post( $post_id );

        // Notify Global Score
        if ( class_exists( 'HTS_Global_Score' ) ) {
            $gs = new HTS_Global_Score();
            $gs->compute_and_save( $post_id, true );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                '↩️ Meta Rollback: « ' . get_the_title( $post_id ) . ' » — Score restauré ' . $score['score'] . '/100',
                'info', 'meta_score'
            );
        }

        wp_send_json_success( array(
            'message' => 'Metas restaurées — score ' . $score['score'] . '/100',
            'score'   => $score,
        ) );
    }

    /* ═══════════════════════════════════════════════════
     *  HELPERS
     * ═══════════════════════════════════════════════════ */

    private function get_effective_title( $post_id ) {
        if ( class_exists( 'HTS_Meta_Tags' ) ) {
            $mt = new HTS_Meta_Tags();
            if ( method_exists( $mt, 'get_meta_title' ) ) {
                $t = $mt->get_meta_title( $post_id );
                if ( $t ) return $t;
            }
        }
        $title = get_post_meta( $post_id, '_hts_meta_title', true );
        return $title ?: get_the_title( $post_id );
    }

    private function get_effective_desc( $post_id ) {
        if ( class_exists( 'HTS_Meta_Tags' ) ) {
            $mt = new HTS_Meta_Tags();
            if ( method_exists( $mt, 'get_meta_description' ) ) {
                $d = $mt->get_meta_description( $post_id );
                if ( $d ) return $d;
            }
        }
        return get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
    }

    public function get_focus_keyword( $post_id ) {
        $kw = get_post_meta( $post_id, '_hts_focus_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, '_hts_api_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        if ( ! $kw ) $kw = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
        if ( $kw ) return $kw;

        // GSC top query
        $gsc_query = get_post_meta( $post_id, '_hts_gsc_top_query', true );
        if ( $gsc_query ) return $gsc_query;

        // Fallback: extract from title
        $title = get_the_title( $post_id );
        if ( ! $title ) return '';

        $stops = function_exists( 'hts_get_stopwords' ) ? hts_get_stopwords() : array();

        $clean = mb_strtolower( preg_replace( '/[^\p{L}\p{N}\s]/u', ' ', $title ) );
        $words = array_filter( explode( ' ', $clean ), function( $w ) use ( $stops ) {
            return mb_strlen( $w ) > 2 && ! in_array( $w, $stops, true );
        } );

        $kw_words = array_slice( array_values( $words ), 0, min( 4, max( 2, count( $words ) ) ) );
        return implode( ' ', $kw_words );
    }

    private function grade( $score ) {
        if ( $score >= 80 ) return 'A';
        if ( $score >= 60 ) return 'B';
        if ( $score >= 40 ) return 'C';
        return 'D';
    }

    /**
     * Get worst scored posts (public API for Decision Engine)
     */
    public function get_worst_scored( $limit = 10 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT pm.post_id, pm.meta_value as score, p.post_title
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key = %s
             AND p.post_status = 'publish'
             AND CAST(pm.meta_value AS UNSIGNED) < 50
             ORDER BY CAST(pm.meta_value AS UNSIGNED) ASC
             LIMIT %d",
            self::SCORE_META, $limit
        ), ARRAY_A );
    }

    /* ═══════════════════════════════════════════════════
     *  SESSION K — PROPOSITIONS INBOX
     * ═══════════════════════════════════════════════════ */

    /**
     * Cron : scanner tous les articles et proposer les meta à corriger.
     *
     * @since 2.4.7
     */
    public function cron_scan_meta() {
        try {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return;
        if ( ! HTS_Workflow_Engine::is_agent_enabled( 'meta' ) ) return;

        // ── Session M : Scan intelligent avec priorisation par score ──
        // Récupérer posts ET pages publiés
        $post_ids = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'orderby'        => 'modified',
            'order'          => 'ASC',
        ) );

        if ( empty( $post_ids ) ) return;

        // Scorer chaque page et trier par score croissant (les pires en premier)
        $scored = array();
        foreach ( $post_ids as $pid ) {
            // Pré-filtrer : cooldown
            $cooldown_ok = HTS_Workflow_Engine::check_cooldown( 'meta', $pid );
            if ( $cooldown_ok !== true ) continue;

            // Pré-filtrer : conflit cross-agent
            $conflict_ok = HTS_Workflow_Engine::check_cross_agent_conflict( 'meta', $pid );
            if ( $conflict_ok !== true ) continue;

            // Pré-filtrer : blacklist et trafic
            if ( ! HTS_Workflow_Engine::check_blacklist( $pid ) ) continue;
            if ( ! HTS_Workflow_Engine::check_traffic_threshold( $pid ) ) continue;

            $result = $this->score_post( $pid, true );
            $score  = (int) ( $result['score'] ?? 100 );
            if ( $score < 60 ) {
                $scored[] = array( 'pid' => $pid, 'score' => $score );
            }
        }

        // Trier par score croissant (les pages les plus problématiques en premier)
        usort( $scored, function( $a, $b ) { return $a['score'] - $b['score']; } );

        // Limiter au max_meta_per_week restant
        $settings = HTS_Workflow_Engine::get_agent_settings_with_defaults( 'meta' );
        $max_week = (int) ( $settings['max_meta_per_week'] ?? 10 );

        $count = 0;
        foreach ( $scored as $item ) {
            if ( $count >= $max_week ) break;

            $proposed = $this->propose_inbox_actions( $item['pid'] );
            $count += $proposed;
        }

        if ( function_exists( 'hts_add_log' ) ) {
            $total_eligible = count( $scored );
            hts_add_log( "Meta Score cron : {$count} proposition(s) créée(s) sur {$total_eligible} pages éligibles", 'info', 'meta-score' );
        }
        } catch ( \Throwable $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Meta Score cron CRASH: ' . $e->getMessage() . ' L' . $e->getLine(), 'error', 'meta-score' );
            }
        }
    }

    /**
     * Proposer des actions Inbox pour un article (meta title + meta desc).
     *
     * Scanne les critères, identifie les problèmes, crée des actions pending
     * avec un "why" non-expert et des données chiffrées.
     *
     * @since 2.4.7
     * @param int $post_id
     * @return int Nombre de propositions créées
     */
    public function propose_inbox_actions( $post_id ) {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;

        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return 0;

        // Scorer l\'article
        $result = $this->score_post( $post_id, true );
        if ( empty( $result['criteria'] ) ) return 0;

        $title   = $result['title'] ?? '';
        $desc    = $result['description'] ?? '';
        $keyword = $result['keyword'] ?? '';
        $score   = (int) ( $result['score'] ?? 100 );

        // Seuil : on ne propose que si le score est < 60
        if ( $score >= 60 ) return 0;

        $count = 0;
        $title_len = mb_strlen( $title );
        $desc_len  = mb_strlen( $desc );
        $title_target = self::get_title_max_length();
        $desc_target  = self::get_desc_max_length();

        // ── Problèmes sur le titre ──
        $title_issues = array();
        foreach ( $result['criteria'] as $c ) {
            if ( in_array( $c['id'] ?? '', array( 'title_length', 'kw_title', 'quality_signals' ), true ) ) {
                if ( ( $c['score'] ?? 0 ) < ( $c['max'] ?? 1 ) * 0.7 ) {
                    $title_issues[] = $c;
                }
            }
        }

        if ( ! empty( $title_issues ) ) {
            $why = $this->build_meta_why( 'title', $title_len, $title_target, $keyword, $title, $title_issues );
            $priority = $title_len === 0 ? 'high' : ( $title_len < 25 ? 'high' : 'medium' );

            $action_id = HTS_Workflow_Engine::propose(
                'meta',
                'add_meta_title',
                $post_id,
                array(
                    'reason'       => $why,
                    'suggestion'   => 'Hack The SEO va générer un titre optimisé',
                    'meta_score'   => $score,
                    'title_length' => $title_len,
                    'title_target' => $title_target,
                    'keyword'      => $keyword,
                    'issues'       => array_map( function( $c ) {
                        return $c['id'] . ': ' . ( $c['detail'] ?? '' );
                    }, $title_issues ),
                ),
                $priority
            );
            if ( $action_id ) $count++;
        }

        // ── Problèmes sur la description ──
        $desc_issues = array();
        foreach ( $result['criteria'] as $c ) {
            if ( in_array( $c['id'] ?? '', array( 'desc_length', 'kw_desc', 'quality_signals' ), true ) ) {
                if ( ( $c['score'] ?? 0 ) < ( $c['max'] ?? 1 ) * 0.7 ) {
                    $desc_issues[] = $c;
                }
            }
        }

        if ( ! empty( $desc_issues ) ) {
            $why = $this->build_meta_why( 'desc', $desc_len, $desc_target, $keyword, $desc, $desc_issues );
            $priority = $desc_len === 0 ? 'high' : 'medium';

            $action_id = HTS_Workflow_Engine::propose(
                'meta',
                'add_meta_desc',
                $post_id,
                array(
                    'reason'      => $why,
                    'suggestion'  => 'Hack The SEO va générer une description optimisée',
                    'meta_score'  => $score,
                    'desc_length' => $desc_len,
                    'desc_target' => $desc_target,
                    'keyword'     => $keyword,
                    'issues'      => array_map( function( $c ) {
                        return $c['id'] . ': ' . ( $c['detail'] ?? '' );
                    }, $desc_issues ),
                ),
                $priority
            );
            if ( $action_id ) $count++;
        }

        return $count;
    }

    /**
     * Construire le message "pourquoi" non-expert avec données chiffrées.
     *
     * @since 2.4.7
     * @param string $field   'title' ou 'desc'
     * @param int    $length  Longueur actuelle
     * @param int    $target  Longueur cible
     * @param string $keyword Mot-clé
     * @param string $value   Valeur actuelle
     * @param array  $issues  Critères échoués
     * @return string
     */
    private function build_meta_why( $field, $length, $target, $keyword, $value, $issues ) {
        $parts = array();

        if ( $field === 'title' ) {
            if ( $length === 0 ) {
                $parts[] = 'Aucun titre SEO défini — Google génère automatiquement un titre qui n\'est pas optimisé';
            } elseif ( $length < 30 ) {
                $parts[] = 'Titre trop court (' . $length . ' caractères, minimum recommandé : 30)';
            } elseif ( $length > $target + 10 ) {
                $parts[] = 'Titre trop long (' . $length . ' car.) — Google le tronquera après ~' . $target . ' caractères';
            }

            if ( $keyword && mb_stripos( $value, $keyword ) === false ) {
                $parts[] = 'Le mot-clé principal "' . $keyword . '" est absent du titre';
            }
        } else {
            if ( $length === 0 ) {
                $parts[] = 'Aucune meta description — Google utilise un extrait aléatoire de votre page';
            } elseif ( $length < 80 ) {
                $parts[] = 'Description trop courte (' . $length . ' car., minimum recommandé : 80)';
            } elseif ( $length > $target + 20 ) {
                $parts[] = 'Description trop longue (' . $length . ' car.) — sera tronquée après ~' . $target . ' caractères';
            }

            if ( $keyword && mb_stripos( $value, $keyword ) === false ) {
                $parts[] = 'Le mot-clé principal "' . $keyword . '" est absent de la description';
            }
        }

        if ( empty( $parts ) ) {
            $parts[] = 'Score meta insuffisant — des optimisations sont possibles';
        }

        return implode( '. ', $parts ) . '.';
    }

    /**
     * Handle Workflow dispatch pour les actions meta (fallback si le WF intégré ne gère pas).
     *
     * @since 2.4.7
     * @param bool|null $result
     * @param string    $agent
     * @param string    $type
     * @param int       $post_id
     * @param array     $data
     * @return bool|null
     */
    public function handle_workflow_dispatch( $result, $agent, $type, $post_id, $data ) {
        // Ne pas interférer si déjà traité ou si pas notre agent
        if ( $result !== null ) return $result;
        if ( $agent !== 'meta' ) return null;

        // Les types add_meta_title et add_meta_desc sont déjà gérés par le WF intégré
        // Ce hook sert de filet de sécurité
        return null;
    }
}
