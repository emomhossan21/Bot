<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Compatibility Layer v4.0 — Detector & Alert Only
 *
 * Philosophy v4.0 (breaking change from v3.x):
 *   HTS is the SOLE SEO plugin. After migration, the competitor MUST be deactivated.
 *   This class only DETECTS competing plugins and WARNS the admin.
 *   No more feature-by-feature filter neutralization.
 *
 * Migration Wizard handles:
 *   1. Import ALL data (meta, robots, canonical, OG, redirections, global settings)
 *   2. Guide user to deactivate the competitor
 *
 * v3.x (removed): should_hts_handle(), apply(), $feature_registry filters
 * v4.0 (current): detect(), warn, conflict report for dashboard
 *
 * @since 3.2.1
 * @updated 4.0.0
 */

class HTS_Compat {

    const OPTION = 'hts_compat_settings';

    /**
     * Feature labels for dashboard display.
     */
    private static $features = array(
        'sitemaps'    => 'Sitemaps XML',
        'redirects'   => 'Redirections 301/302',
        'robots_meta' => 'Robots Meta (noindex/nofollow)',
        'canonical'   => 'Canonical URLs',
        'schema'      => 'Schema / JSON-LD',
        'meta_title'  => 'Meta Title & Description',
        'opengraph'   => 'Open Graph / Social',
    );

    /* ═══════════════════════════════════════
     *  DETECTION
     * ═══════════════════════════════════════ */

    public static function detect() {
        static $cache = null;
        if ( $cache !== null && did_action( 'plugins_loaded' ) ) return $cache;

        $found = array();
        if ( class_exists( 'RankMath' ) || function_exists( 'rank_math' ) )           $found['rank_math'] = 'Rank Math';
        if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Frontend' ) )          $found['yoast']     = 'Yoast SEO';
        if ( function_exists( 'aioseo' ) || class_exists( 'AIOSEO\\Plugin\\AIOSEO' ) ) $found['aioseo']    = 'All in One SEO';
        if ( function_exists( 'seopress_init' ) || defined( 'SEOPRESS_VERSION' ) )     $found['seopress']  = 'SEOPress';
        if ( function_exists( 'the_seo_framework' ) )                                  $found['tsf']       = 'The SEO Framework';

        if ( did_action( 'plugins_loaded' ) ) {
            $cache = $found;
        }
        return $found;
    }

    public static function has_competing_plugin() {
        return ! empty( self::detect() );
    }

    public static function get_competing_name() {
        $detected = self::detect();
        return ! empty( $detected ) ? implode( ', ', $detected ) : '';
    }

    /**
     * Get the plugin file path for deactivation.
     */
    public static function get_plugin_files() {
        // Static map: slug → possible plugin files (including Pro variants)
        $candidates = array(
            'rank_math' => array(
                'seo-by-rank-math/rank-math.php',
                'seo-by-rank-math-pro/rank-math-pro.php',
            ),
            'yoast' => array(
                'wordpress-seo/wp-seo.php',
                'wordpress-seo-premium/wp-seo-premium.php',
            ),
            'aioseo' => array(
                'all-in-one-seo-pack/all_in_one_seo_pack.php',
                'all-in-one-seo-pack-pro/all_in_one_seo_pack_pro.php',
            ),
            'seopress' => array(
                'wp-seopress/seopress.php',
                'wp-seopress-pro/seopress-pro.php',
            ),
            'tsf' => array(
                'autodescription/autodescription.php',
            ),
        );

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $detected = self::detect();
        $files = array();
        foreach ( $detected as $slug => $name ) {
            if ( ! isset( $candidates[ $slug ] ) ) continue;
            // Find all active plugin files for this slug (free + pro)
            $active_files = array();
            foreach ( $candidates[ $slug ] as $candidate ) {
                if ( is_plugin_active( $candidate ) ) {
                    $active_files[] = $candidate;
                }
            }
            if ( ! empty( $active_files ) ) {
                $files[ $slug ] = array(
                    'name'  => $name,
                    'file'  => $active_files[0],
                    'files' => $active_files,
                );
            } else {
                // Fallback: scan active plugins for folder name match
                $search_terms = array(
                    'rank_math' => 'rank-math',
                    'yoast'     => 'wordpress-seo',
                    'aioseo'    => 'all-in-one-seo',
                    'seopress'  => 'seopress',
                    'tsf'       => 'autodescription',
                );
                if ( isset( $search_terms[ $slug ] ) ) {
                    $active_plugins = get_option( 'active_plugins', array() );
                    foreach ( $active_plugins as $p ) {
                        if ( strpos( $p, $search_terms[ $slug ] ) !== false ) {
                            $active_files[] = $p;
                        }
                    }
                    if ( ! empty( $active_files ) ) {
                        $files[ $slug ] = array(
                            'name'  => $name,
                            'file'  => $active_files[0],
                            'files' => $active_files,
                        );
                    }
                }
            }
        }
        return $files;
    }

    /* ═══════════════════════════════════════
     *  ADMIN WARNING — Competitor still active
     * ═══════════════════════════════════════ */

    public static function maybe_warn_competitor_active() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! self::has_competing_plugin() ) return;

        // Don't warn on the migration wizard page itself
        $screen = get_current_screen();
        if ( $screen && strpos( $screen->id, 'hts-migration' ) !== false ) return;
        if ( $screen && strpos( $screen->id, 'hts-onboarding' ) !== false ) return;

        // Check if migration was completed
        $migration_state = get_option( 'hts_migration_state', 'not_started' );

        $competitor = self::get_competing_name();

        if ( $migration_state === 'completed' ) {
            // Migration done but competitor still active → urgent warning
            echo '<div class="notice notice-error">';
 echo '<p><strong> Hack The SEO</strong> — ';
            echo esc_html( $competitor ) . ' est toujours actif ! ';
            echo 'La migration est terminée, vous devez <strong>désactiver ' . esc_html( $competitor ) . '</strong> ';
            echo 'pour éviter les conflits SEO (meta en double, schema dupliqué, canonical en conflit). ';
            echo '<a href="' . esc_url( admin_url( 'plugins.php' ) ) . '"><strong>Aller aux plugins →</strong></a>';
            echo '</p></div>';
        }
        // Note: if migration not started, the Migration Wizard's own notice handles the prompt
    }

    /* ═══════════════════════════════════════
     *  CONFLICT REPORT (for dashboard)
     * ═══════════════════════════════════════ */

    public static function get_conflict_report() {
        $detected = self::detect();

        if ( empty( $detected ) ) {
            return array(
                'status'    => 'ok',
                'message'   => 'Aucun autre plugin SEO détecté. Hack The SEO gère tout.',
                'plugins'   => array(),
                'features'  => array(),
                'progress'  => 100,
            );
        }

        $migration_state = get_option( 'hts_migration_state', 'not_started' );
        $features = array();

        foreach ( self::$features as $key => $label ) {
            $features[] = array(
                'feature'       => $label,
                'handled_by'    => 'Hack The SEO',
                'hts_handles'   => true,
                'module_exists' => true,
 'icon' => '',
            );
        }

        if ( $migration_state === 'completed' ) {
            return array(
                'status'    => 'conflict',
                'message'   => sprintf(
 ' %s est toujours actif ! Désactivez-le pour éviter les conflits. La migration HTS est terminée.',
                    implode( ', ', $detected )
                ),
                'plugins'   => $detected,
                'features'  => $features,
                'progress'  => 100,
            );
        }

        return array(
            'status'    => 'needs_migration',
            'message'   => sprintf(
                '%s détecté — Lancez le Migration Wizard pour importer vos données et désactiver %s.',
                implode( ', ', $detected ),
                implode( ', ', $detected )
            ),
            'plugins'   => $detected,
            'features'  => $features,
            'progress'  => 0,
        );
    }

    /* ═══════════════════════════════════════
     *  SETTINGS (legacy — kept for backward compat)
     * ═══════════════════════════════════════ */

    public static function get_settings() {
        return get_option( self::OPTION, array() );
    }
}
