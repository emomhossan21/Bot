<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Advanced Sitemaps v1.0
 *
 * FEATURES:
 *   - Sitemap Index → links to all sub-sitemaps
 *   - Sitemap par cocon sémantique (1 XML per cluster — unique feature)
 *   - Post-type sitemaps (post, page, custom CPTs)
 *   - Image Sitemap (featured + in-content images)
 *   - HTML Sitemap shortcode [hts_sitemap]
 *   - Exclusion intelligente : noindex, canonical→autre page, flagged pages
 *   - Ping Google + Bing + IndexNow on publish/update
 *   - Disable WP Core Sitemaps
 *   - Dashboard with stats & warnings
 *
 * ARCHITECTURE:
 *   Virtual XML files via rewrite rules (no physical files).
 *   Content generated on-the-fly with transient caching (1h).
 *   Invalidated on post save/delete/status change.
 *
 * NAMING:
 *   /sitemap.xml           → Sitemap Index
 *   /sitemap-post.xml      → Posts sitemap
 *   /sitemap-page.xml      → Pages sitemap
 *   /sitemap-cocon-{slug}.xml → Per-cluster sitemap
 *   /sitemap-images.xml    → Image sitemap
 *
 * @since 3.2.0
 */

class HTS_Sitemap {

    /* ══════════════════════════════════════════════
     *  CONSTANTS & OPTIONS
     * ══════════════════════════════════════════════ */

    const OPTION_SETTINGS   = 'hts_sitemap_settings';
    const OPTION_STATS      = 'hts_sitemap_stats';
    const TRANSIENT_PREFIX  = 'hts_sitemap_';
    const CACHE_TTL         = 3600; // 1 hour

    /**
     * Known SEO plugins that generate their own sitemaps.
     * Format: 'slug' => array( 'name', 'class_or_function', 'sitemap_disable_filter_or_action' )
     */
    private static $competing_plugins = array(
        'rank-math' => array(
            'name'     => 'Rank Math',
            'detect'   => 'RankMath\\Sitemap\\Sitemap',   // Class exists check
            'detect_fn' => 'rank_math',                    // Function exists fallback
            'disable'  => 'rank_math/sitemap/enable',      // Filter to disable their sitemap
        ),
        'yoast' => array(
            'name'     => 'Yoast SEO',
            'detect'   => 'WPSEO_Sitemaps',
            'detect_fn' => 'wpseo_init',
            'disable'  => 'wpseo_enable_xml_sitemap',
        ),
        'aioseo' => array(
            'name'     => 'All in One SEO',
            'detect'   => 'AIOSEO\\Plugin\\Common\\Sitemap\\Sitemap',
            'detect_fn' => 'aioseo',
            'disable'  => 'aioseo_sitemap_enabled',
        ),
        'seopress' => array(
            'name'     => 'SEOPress',
            'detect'   => 'JEREMIEL\\SeoPress',
            'detect_fn' => 'seopress_init',
            'disable'  => 'seopress_xml_sitemap_enable',
        ),
        'xml-sitemap-generator' => array(
            'name'     => 'Google XML Sitemaps',
            'detect'   => 'GoogleSitemapGenerator',
            'detect_fn' => '',
            'disable'  => '',
        ),
    );

    /**
     * Detect competing sitemap plugins.
     * Returns array of detected plugin info, or empty array.
     */
    public static function detect_competing_plugins() {
        $found = array();
        foreach ( self::$competing_plugins as $slug => $info ) {
            $detected = false;
            if ( ! empty( $info['detect'] ) && class_exists( $info['detect'] ) ) {
                $detected = true;
            }
            if ( ! $detected && ! empty( $info['detect_fn'] ) && function_exists( $info['detect_fn'] ) ) {
                $detected = true;
            }
            if ( $detected ) {
                $found[ $slug ] = $info;
            }
        }
        return $found;
    }

    /**
     * Disable competing plugins' sitemaps (when HTS sitemaps are enabled).
     * Called during init if auto-disable is ON.
     */
    public static function disable_competing_sitemaps() {
        static $already_run = false;
        if ( $already_run ) return array();
        $already_run = true;

        $competitors = self::detect_competing_plugins();
        foreach ( $competitors as $slug => $info ) {

            // ═══ RANK MATH — disable sitemap output only ═══
            if ( $slug === 'rank-math' ) {
                add_filter( 'rank_math/sitemap/enable', '__return_false', 999 );
                add_filter( 'rank_math/sitemap/content', '__return_empty_string', 999 );
                add_filter( 'rank_math/sitemap/index', '__return_empty_string', 999 );
                // Note: 301 redirect for /sitemap_index.xml handled by maybe_serve_sitemap_early()
 hts_add_log( 'Sitemap Rank Math désactivé au profit de HTS', 'info', 'sitemap' );
            }

            // ═══ YOAST — disable sitemap output only ═══
            elseif ( $slug === 'yoast' ) {
                add_filter( 'wpseo_enable_xml_sitemap', '__return_false', 999 );
                add_filter( 'wpseo_allow_xml_sitemap_ping', '__return_false', 999 );
                add_filter( 'wpseo_sitemap_index', '__return_empty_string', 999 );
 hts_add_log( 'Sitemap Yoast désactivé au profit de HTS', 'info', 'sitemap' );
            }

            // ═══ AIOSEO ═══
            elseif ( $slug === 'aioseo' ) {
                add_filter( 'aioseo_sitemap_enabled', '__return_false', 999 );
 hts_add_log( 'Sitemap AIOSEO désactivé au profit de HTS', 'info', 'sitemap' );
            }

            // ═══ SEOPress ═══
            elseif ( $slug === 'seopress' ) {
                add_filter( 'seopress_xml_sitemap_enable', '__return_false', 999 );
 hts_add_log( 'Sitemap SEOPress désactivé au profit de HTS', 'info', 'sitemap' );
            }
        }
        return $competitors;
    }

    /**
     * Default settings.
     *
     * BEST PRACTICES 2025:
     *   - Google ignores <changefreq> and <priority> → disabled by default
     *   - <lastmod> is the ONLY tag Google actively uses → must be accurate
     *   - Smaller sitemaps (1000 URLs) = faster processing by crawlers
     *   - HTML sitemap dilutes link equity → disabled by default
     *   - Exclude redirected pages from sitemaps (200 OK only)
     *   - Sitemap = weak canonical signal → must align with canonical module
     */
    private static function defaults() {
        return array(
            'enabled'               => true,
            'disable_wp_sitemaps'   => true,
            'cocon_sitemaps'        => ( ! defined( 'HTS__IS_LIGHT' ) || ! HTS__IS_LIGHT ) && class_exists( 'HTS_Cocon' ),
            'image_sitemap'         => true,
            'news_sitemap'          => false,   // Google News sitemap (last 48h articles)
            'news_publication_name' => '',       // Publication name for Google News
            'news_language'         => 'fr',     // Publication language
            'news_post_types'       => array( 'post' ), // Post types eligible for News
            'video_sitemap'         => true,     // Video sitemap from detected embeds
            'taxonomy_sitemap'      => true,     // Taxonomy sitemap (categories, tags, custom taxonomies)
            'html_sitemap'          => false,  // Disabled: dilutes link equity from footer
            'ping_google'           => true,
            'ping_bing'             => true,
            'indexnow_enabled'      => false,
            'indexnow_key'          => '',
            'indexnow_batch'        => true,   // Send batch URLs on cocon regeneration
            'post_types'            => array( 'post', 'page' ),
            'exclude_noindex'       => true,
            'exclude_canonical_other' => true,
            'exclude_redirected'    => true,    // Exclude pages with active 301/302
            'disable_competing'     => true,    // Auto-disable Rank Math/Yoast/AIOSEO sitemaps
            'include_legacy_tags'   => false,   // <changefreq> + <priority> — Google ignores them
            'gzip_enabled'          => false,   // OFF by default: let server handle (mod_deflate/nginx). Manual gzip can cause double-compress → page blanche
            'changefreq_pillar'     => 'weekly',
            'changefreq_support'    => 'monthly',
            'changefreq_page'       => 'monthly',
            'priority_pillar'       => '1.0',
            'priority_support'      => '0.8',
            'priority_page'         => '0.5',
            'max_urls_per_sitemap'  => 1000,   // Smaller = faster crawler processing
        );
    }

    public static function get_settings() {
        $s = wp_parse_args( get_option( self::OPTION_SETTINGS, array() ), self::defaults() );
        // Runtime guard: cocon sitemaps require HTS_Cocon class (Full only)
        if ( $s['cocon_sitemaps'] && ! class_exists( 'HTS_Cocon' ) ) {
            $s['cocon_sitemaps'] = false;
        }
        // Auto-include WooCommerce product type when WC is active
        if ( class_exists( 'WooCommerce' ) && is_array( $s['post_types'] ) && ! in_array( 'product', $s['post_types'], true ) ) {
            $s['post_types'][] = 'product';
        }
        return $s;
    }

    /* ══════════════════════════════════════════════
     *  INIT — Hooks
     * ══════════════════════════════════════════════ */

    public function init() {
        // ── Cockpit guard: if module is OFF, no sitemap ──
        if ( get_option( 'hts_module_sitemap', '1' ) !== '1' ) return;

        $settings = self::get_settings();

        // ═══ FIRST: Disable competing sitemaps AS EARLY AS POSSIBLE ═══
        // Must run before Rank Math/Yoast init (they hook at init priority 10+)
        if ( $settings['enabled'] && ! empty( $settings['disable_competing'] ) ) {
            // Immediate filter registration (before any init hook fires)
            self::disable_competing_sitemaps();
            // Also hook at plugins_loaded for maximum coverage
            add_action( 'plugins_loaded', array( __CLASS__, 'disable_competing_sitemaps' ), 1 );
            // And again at init priority 0 (before Rank Math's priority 10)
            add_action( 'init', array( __CLASS__, 'disable_competing_sitemaps' ), 0 );
        }

        // Rewrite rules for virtual sitemaps
        add_action( 'init',              array( $this, 'register_rewrites' ) );
        add_filter( 'query_vars',        array( $this, 'register_query_vars' ) );
        add_action( 'template_redirect', array( $this, 'render_sitemap' ) );

        // Check if rewrite rules need flushing (set by version upgrade or first activation)
        add_action( 'init',              array( __CLASS__, 'maybe_flush_rules' ), 9999 );

        // Fallback: catch sitemap URLs even without flushed rewrite rules
        add_action( 'parse_request',     array( $this, 'fallback_parse_request' ), 1 );

        // ULTRA-EARLY intercept: serve sitemap directly from init (bypasses Rank Math, Yoast, etc.)
        add_action( 'init',              array( $this, 'maybe_serve_sitemap_early' ), 1 );

        // Auto-flush rewrite rules on first activation of sitemap module
        if ( $settings['enabled'] && ! get_option( 'hts_sitemap_rules_installed' ) ) {
            update_option( 'hts_sitemap_flush_needed', true );
            update_option( 'hts_sitemap_rules_installed', true );
        }

        // Disable WP core sitemaps
        if ( $settings['disable_wp_sitemaps'] ) {
            add_filter( 'wp_sitemaps_enabled', '__return_false' );
        }

        // Exclude sitemaps from WP Rocket cache
        add_filter( 'rocket_cache_reject_uri', array( $this, 'wp_rocket_exclude_sitemaps' ) );

        // Cache invalidation on content changes
        add_action( 'save_post',         array( $this, 'invalidate_cache' ), 20, 2 );
        add_action( 'delete_post',       array( $this, 'invalidate_all_cache' ) );
        add_action( 'transition_post_status', array( $this, 'on_status_change' ), 10, 3 );

        // Ping on publish
        add_action( 'publish_post',      array( $this, 'ping_engines' ), 99 );
        add_action( 'publish_page',      array( $this, 'ping_engines' ), 99 );

        // HTML sitemap shortcode
        if ( $settings['html_sitemap'] ) {
            add_shortcode( 'hts_sitemap', array( $this, 'shortcode_html_sitemap' ) );
        }

        // ═══ WP-Cron: auto-refresh sitemaps ═══
        // Register custom cron interval FIRST (needed before wp_schedule_event)
        add_filter( 'cron_schedules', array( $this, 'register_cron_interval' ) );
        add_action( 'hts_sitemap_cron', array( $this, 'cron_refresh' ) );
        if ( $settings['enabled'] && ! wp_next_scheduled( 'hts_sitemap_cron' ) ) {
            wp_schedule_event( time(), 'hts_every_6h', 'hts_sitemap_cron' );
        }

        // AJAX endpoints
        add_action( 'wp_ajax_hts_sitemap_get_data',      array( $this, 'ajax_get_data' ) );
        add_action( 'wp_ajax_hts_sitemap_save_settings',  array( $this, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_hts_sitemap_regenerate',     array( $this, 'ajax_regenerate' ) );
        add_action( 'wp_ajax_hts_sitemap_ping',           array( $this, 'ajax_ping' ) );
        add_action( 'wp_ajax_hts_sitemap_gsc_status',     array( $this, 'ajax_gsc_status' ) );
        add_action( 'wp_ajax_hts_sitemap_gsc_submit',     array( $this, 'ajax_gsc_submit' ) );
        add_action( 'wp_ajax_hts_sitemap_gsc_save_creds', array( $this, 'ajax_gsc_save_creds' ) );

        // Append sitemap URL to robots.txt (priority 999 = run AFTER Rank Math/Yoast/AIOSEO)
        add_filter( 'robots_txt', array( $this, 'add_to_robots_txt' ), 999, 2 );

 hts_add_log( 'Sitemaps Avancés initialisé', 'info', 'sitemap' );
    }

    /* ══════════════════════════════════════════════
     *  WP-CRON: Auto-refresh sitemaps
     * ══════════════════════════════════════════════ */

    /**
     * Register custom cron interval: every 6 hours.
     */
    public function register_cron_interval( $schedules ) {
        $schedules['hts_every_6h'] = array(
            'interval' => 6 * HOUR_IN_SECONDS,
            'display'  => __( 'Every 6 hours (HTS Sitemaps)', 'hts' ),
        );
        return $schedules;
    }

    /**
     * Cron callback: regenerate all stale sitemaps + ping engines + submit to GSC.
     * Runs every 6 hours automatically.
     */
    public function cron_refresh() {
        $lock_key = 'hts_lock_sitemap_refresh';
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, 120 );

        try {
            $settings = self::get_settings();
            if ( ! $settings['enabled'] ) {
                delete_transient( $lock_key );
                return;
            }

     hts_add_log( 'Cron sitemap — début régénération automatique', 'info', 'sitemap' );

            // 1) Invalidate all transient caches → forces regeneration on next serve
            $this->invalidate_all_cache();

            // 2) Pre-warm: generate each sitemap to populate cache
            $this->generate_index();
            $max = (int) $settings['max_urls_per_sitemap'];
            foreach ( $settings['post_types'] as $pt ) {
                $total = $this->count_published_posts( $pt );
                $pages = max( 1, ceil( $total / $max ) );
                for ( $p = 1; $p <= $pages; $p++ ) {
                    $this->generate_posttype_sitemap( $pt, $p );
                }
            }
            if ( $settings['cocon_sitemaps'] ) {
                $clusters = $this->get_cocon_clusters();
                foreach ( $clusters as $name => $cl ) {
                    if ( $name === 'Non classé' ) continue;
                    $slug = sanitize_title( $name );
                    $this->generate_cocon_sitemap( $slug );
                }
            }
            if ( $settings['image_sitemap'] ) {
                $this->generate_image_sitemap();
            }

            // 3) Update last generated timestamp
            $stats = get_option( self::OPTION_STATS, array() );
            $stats['last_generated'] = current_time( 'Y-m-d H:i:s' );
            $stats['cron_last_run']  = current_time( 'Y-m-d H:i:s' );
            update_option( self::OPTION_STATS, $stats, false );

            // 4) Ping search engines
            $this->ping_engines();

            // 5) Submit to GSC if credentials configured
            $this->gsc_submit_sitemap();

     hts_add_log( 'Cron sitemap — terminé. Prochain run dans 6h.', 'success', 'sitemap' );
            delete_transient( $lock_key );
        } catch ( \Throwable $e ) {
            delete_transient( $lock_key );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'cron', 'sitemap_cron_refresh error: ' . $e->getMessage() );
            }
        }
    }

    /**
     * Unschedule cron when plugin is deactivated.
     */
    public static function deactivate_cron() {
        $timestamp = wp_next_scheduled( 'hts_sitemap_cron' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'hts_sitemap_cron' );
        }
        delete_option( 'hts_sitemap_rules_installed' );
    }

    /* ══════════════════════════════════════════════
     *  REWRITE RULES
     * ══════════════════════════════════════════════ */

    public function register_rewrites() {
        // sitemap.xml → index (with or without trailing slash)
        add_rewrite_rule( '^sitemap\.xml/?$', 'index.php?hts_sitemap=index', 'top' );
        // sitemap-post.xml, sitemap-page.xml, etc.
        add_rewrite_rule( '^sitemap-([a-z0-9_-]+)\.xml/?$', 'index.php?hts_sitemap=$matches[1]', 'top' );
    }

    public function register_query_vars( $vars ) {
        $vars[] = 'hts_sitemap';
        return $vars;
    }

    /**
     * Check if rules need flushing (run once after activation).
     */
    public static function maybe_flush_rules() {
        if ( get_option( 'hts_sitemap_flush_needed' ) ) {
            // Hard flush: rebuilds rules + writes .htaccess
            // Safe here because register_rewrites() already ran at init (default priority)
            flush_rewrite_rules( false );
            delete_option( 'hts_sitemap_flush_needed' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Rewrite rules flushed (sitemap + permalinks)', 'info', 'sitemap' );
            }
        }
    }

    /**
     * Direct fallback: catch sitemap URLs even if rewrite rules aren't flushed.
     * Hooks into parse_request to detect /sitemap.xml or /sitemap-*.xml before WP 404s.
     */
    public function fallback_parse_request( $wp ) {
        $path = trim( $_SERVER['REQUEST_URI'] ?? '', '/' );
        // Remove query string
        $path = strtok( $path, '?' );
        // Handle subdirectory installs
        $home_path = trim( parse_url( home_url(), PHP_URL_PATH ) ?: '', '/' );
        if ( $home_path && strpos( $path, $home_path ) === 0 ) {
            $path = substr( $path, strlen( $home_path ) + 1 );
        }
        $path = trim( $path, '/' );

        if ( $path === 'sitemap.xml' ) {
            $wp->query_vars['hts_sitemap'] = 'index';
        } elseif ( preg_match( '/^sitemap-([a-z0-9_-]+)\.xml$/', $path, $m ) ) {
            $wp->query_vars['hts_sitemap'] = $m[1];
        }
    }

    /**
     * ULTRA-EARLY sitemap intercept — runs at init priority 1.
     * Serves sitemap XML directly BEFORE WordPress routing, Rank Math, Yoast, etc.
     * This guarantees /sitemap.xml works even if:
     *   - Rewrite rules aren't flushed
     *   - Another plugin intercepts the URL
     *   - Server has weird routing
     */
    public function maybe_serve_sitemap_early() {
        $uri  = $_SERVER['REQUEST_URI'] ?? '';
        $path = trim( strtok( $uri, '?' ), '/' );

        // Handle subdirectory installs
        $home_path = trim( parse_url( home_url(), PHP_URL_PATH ) ?: '', '/' );
        if ( $home_path && strpos( $path, $home_path ) === 0 ) {
            $path = trim( substr( $path, strlen( $home_path ) ), '/' );
        }

        // Match sitemap URLs
        $type = null;
        if ( $path === 'sitemap.xml' ) {
            $type = 'index';
        } elseif ( preg_match( '/^sitemap-([a-z0-9_-]+)\.xml$/', $path, $m ) ) {
            $type = $m[1];
        }

        // ═══ Redirect competing sitemap URLs → HTS sitemap ═══
        // Runs BEFORE Rank Math/Yoast can serve their sitemap
        if ( ! $type ) {
            $settings = self::get_settings();
            if ( $settings['enabled'] && ! empty( $settings['disable_competing'] ) ) {
                $competing_paths = array(
                    'sitemap_index.xml',        // Rank Math + Yoast
                    'wp-sitemap.xml',            // WP Core
                    'aioseo-sitemap.xml',        // AIOSEO
                    'sitemap-seopress.xml',      // SEOPress
                );
                foreach ( $competing_paths as $cp ) {
                    if ( $path === $cp || $path === $cp . '/' ) {
                        header( 'X-HTS-Redirect: competing-sitemap', true );
                        header( 'Location: ' . home_url( '/sitemap.xml' ), true, 301 );
                        exit;
                    }
                }
                // Also catch Rank Math sub-sitemaps: post-sitemap.xml, page-sitemap.xml
                if ( preg_match( '/^(post|page|category|tag|attachment)-sitemap\d*\.xml$/', $path ) ) {
                    header( 'X-HTS-Redirect: competing-sub-sitemap', true );
                    header( 'Location: ' . home_url( '/sitemap.xml' ), true, 301 );
                    exit;
                }
            }
            return;
        }

        $settings = self::get_settings();
        if ( ! $settings['enabled'] ) return;

        // Generate XML
        $cache_key = self::TRANSIENT_PREFIX . sanitize_key( $type );
        $xml = get_transient( $cache_key );

        if ( false === $xml ) {
            if ( $type === 'index' ) {
                $xml = $this->generate_index();
            } elseif ( $type === 'images' ) {
                $xml = $this->generate_image_sitemap();
            } elseif ( $type === 'news' ) {
                $xml = $this->generate_news_sitemap();
            } elseif ( $type === 'video' ) {
                $xml = $this->generate_video_sitemap();
            } elseif ( strpos( $type, 'cocon-' ) === 0 ) {
                $xml = $this->generate_cocon_sitemap( substr( $type, 6 ) );
            } elseif ( strpos( $type, 'tax-' ) === 0 ) {
                $xml = $this->generate_taxonomy_sitemap( substr( $type, 4 ) );
            } elseif ( in_array( $type, $settings['post_types'], true ) ) {
                $xml = $this->generate_posttype_sitemap( $type, 1 );
            } else {
                // Check for paginated post-type: "post-2", "page-3", etc.
                $pt_page = self::parse_paginated_type( $type, $settings['post_types'] );
                if ( $pt_page ) {
                    $xml = $this->generate_posttype_sitemap( $pt_page['type'], $pt_page['page'] );
                } else {
                    return; // Unknown type — let WP handle
                }
            }
            if ( $xml ) {
                set_transient( $cache_key, $xml, self::CACHE_TTL );
            }
        }

        if ( empty( $xml ) ) return;

        // Record stats
        $this->record_serve( $type );

        // Kill ALL output buffers
        while ( ob_get_level() ) {
            ob_end_clean();
        }

        // Bypass WP Rocket / cache plugins
        if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
        if ( ! defined( 'DONOTMINIFY' ) )    define( 'DONOTMINIFY', true );

        // Serve raw XML — NO Content-Length (Apache mod_deflate changes actual size)
        http_response_code( 200 );
        header( 'Content-Type: application/xml; charset=UTF-8' );
        header( 'X-Robots-Tag: noindex, follow' );
        header( 'Cache-Control: no-cache, must-revalidate' );
        header( 'X-HTS-Sitemap: ' . $type );
        echo $xml;
        exit;
    }

    /**
     * Exclude sitemap URLs from WP Rocket cache.
     */
    public function wp_rocket_exclude_sitemaps( $uris ) {
        $uris[] = '/sitemap\.xml';
        $uris[] = '/sitemap-([a-z0-9_-]+)\.xml';
        return $uris;
    }

    /* ══════════════════════════════════════════════
     *  RENDER SITEMAP (template_redirect)
     * ══════════════════════════════════════════════ */

    public function render_sitemap() {
        $type = get_query_var( 'hts_sitemap' );
        if ( empty( $type ) ) return;

        $settings = self::get_settings();
        if ( ! $settings['enabled'] ) {
            status_header( 404 );
            exit;
        }

        // Debug header (visible in DevTools → Network → Response Headers)
        header( 'X-HTS-Sitemap: type=' . $type );

        // Serve from cache or generate
        $cache_key = self::TRANSIENT_PREFIX . sanitize_key( $type );
        $xml = get_transient( $cache_key );

        if ( false === $xml ) {
            if ( $type === 'index' ) {
                $xml = $this->generate_index();
            } elseif ( $type === 'images' ) {
                $xml = $this->generate_image_sitemap();
            } elseif ( $type === 'news' ) {
                $xml = $this->generate_news_sitemap();
            } elseif ( $type === 'video' ) {
                $xml = $this->generate_video_sitemap();
            } elseif ( strpos( $type, 'cocon-' ) === 0 ) {
                $slug = substr( $type, 6 );
                $xml = $this->generate_cocon_sitemap( $slug );
            } elseif ( strpos( $type, 'tax-' ) === 0 ) {
                $xml = $this->generate_taxonomy_sitemap( substr( $type, 4 ) );
            } elseif ( in_array( $type, $settings['post_types'], true ) ) {
                $xml = $this->generate_posttype_sitemap( $type, 1 );
            } else {
                // Check for paginated post-type: "post-2", "page-3", etc.
                $pt_page = self::parse_paginated_type( $type, $settings['post_types'] );
                if ( $pt_page ) {
                    $xml = $this->generate_posttype_sitemap( $pt_page['type'], $pt_page['page'] );
                } else {
                    status_header( 404 );
                    header( 'X-HTS-Sitemap: 404-unknown-type' );
                    exit;
                }
            }

            if ( $xml ) {
                set_transient( $cache_key, $xml, self::CACHE_TTL );
            }
        }

        if ( empty( $xml ) ) {
            status_header( 404 );
            header( 'X-HTS-Sitemap: 404-empty-xml' );
            exit;
        }

        // Update stats
        $this->record_serve( $type );

        // Clean ALL output buffers (themes, plugins, etc. that may interfere)
        while ( ob_get_level() ) {
            ob_end_clean();
        }

        // Bypass WP Rocket / cache plugins
        if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
        if ( ! defined( 'DONOTMINIFY' ) )    define( 'DONOTMINIFY', true );

        status_header( 200 );
        header( 'Content-Type: application/xml; charset=UTF-8' );
        header( 'X-Robots-Tag: noindex, follow' );
        header( 'Cache-Control: no-cache, must-revalidate' );
        header( 'X-HTS-Sitemap-Size: ' . strlen( $xml ) );

        // Gzip compression — only if server is NOT already compressing AND our manual gzip is on
        $server_already_gzips = (
            ini_get( 'zlib.output_compression' )
            || in_array( 'ob_gzhandler', (array) ob_list_handlers(), true )
        );

        if ( $settings['gzip_enabled']
             && ! $server_already_gzips
             && ! empty( $_SERVER['HTTP_ACCEPT_ENCODING'] )
             && strpos( $_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip' ) !== false
             && function_exists( 'gzencode' ) ) {
            $compressed = gzencode( $xml, 6 );
            if ( $compressed !== false ) {
                header( 'Content-Encoding: gzip' );
                header( 'Content-Length: ' . strlen( $compressed ) );
                echo $compressed;
            } else {
                echo $xml;
            }
        } else {
            // No Content-Length — Apache mod_deflate may change actual size
            echo $xml;
        }
        exit;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: SITEMAP INDEX
     * ══════════════════════════════════════════════ */

    /**
     * Count published posts for a post type — bypasses Polylang language filter.
     * Polylang hooks wp_count_posts() and filters by current language.
     * Direct SQL ensures we count ALL languages for sitemap generation.
     */
    private function count_published_posts( $post_type ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish'",
            $post_type
        ) );
    }

    private function generate_index() {
        $settings = self::get_settings();
        $entries  = array();
        $max      = (int) $settings['max_urls_per_sitemap'];

        // Post-type sitemaps — with pagination for large sites
        foreach ( $settings['post_types'] as $pt ) {
            $total = $this->count_published_posts( $pt );
            $pages = max( 1, ceil( $total / $max ) );
            $latest = $this->get_latest_modified( $pt );

            for ( $p = 1; $p <= $pages; $p++ ) {
                $suffix = $p === 1 ? $pt : $pt . '-' . $p;
                $entries[] = array(
                    'loc'     => home_url( '/sitemap-' . $suffix . '.xml' ),
                    'lastmod' => $latest,
                );
            }
        }

        // Cocon sitemaps
        if ( $settings['cocon_sitemaps'] ) {
            $clusters = $this->get_cocon_clusters();
            foreach ( $clusters as $name => $cl ) {
                if ( $name === 'Non classé' ) continue;
                $slug = sanitize_title( $name );
                $entries[] = array(
                    'loc'     => home_url( '/sitemap-cocon-' . $slug . '.xml' ),
                    'lastmod' => $this->get_cluster_latest_modified( $cl ),
                );
            }
        }

        // Taxonomy sitemaps
        if ( ! empty( $settings['taxonomy_sitemap'] ) ) {
            $taxonomies = get_taxonomies( array( 'public' => true, 'show_ui' => true ), 'objects' );
            unset( $taxonomies['post_format'] );
            foreach ( $taxonomies as $tax_slug => $tax_obj ) {
                $term_count = wp_count_terms( array( 'taxonomy' => $tax_slug, 'hide_empty' => true ) );
                if ( is_wp_error( $term_count ) || (int) $term_count < 1 ) continue;
                $entries[] = array(
                    'loc'     => home_url( '/sitemap-tax-' . $tax_slug . '.xml' ),
                    'lastmod' => current_time( 'c' ),
                );
            }
        }

        // Image sitemap
        if ( $settings['image_sitemap'] ) {
            $entries[] = array(
                'loc'     => home_url( '/sitemap-images.xml' ),
                'lastmod' => $this->get_latest_modified( 'post' ),
            );
        }

        // News sitemap (Google News — last 48h)
        if ( ! empty( $settings['news_sitemap'] ) ) {
            $entries[] = array(
                'loc'     => home_url( '/sitemap-news.xml' ),
                'lastmod' => current_time( 'c' ),
            );
        }

        // Video sitemap
        if ( ! empty( $settings['video_sitemap'] ) ) {
            $entries[] = array(
                'loc'     => home_url( '/sitemap-video.xml' ),
                'lastmod' => $this->get_latest_modified( 'post' ),
            );
        }

        // Build XML
        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xsl  = $this->get_xsl_url( 'index' );
        if ( $xsl ) {
            $xml .= '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl ) . '"?>' . "\n";
        }
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach ( $entries as $e ) {
            $xml .= "  <sitemap>\n";
            $xml .= '    <loc>' . esc_url( $e['loc'] ) . "</loc>\n";
            if ( $e['lastmod'] ) {
                $xml .= '    <lastmod>' . esc_html( $e['lastmod'] ) . "</lastmod>\n";
            }
            $xml .= "  </sitemap>\n";
        }

        $xml .= '</sitemapindex>';

        // Update stats
        $this->update_stats( 'index', count( $entries ), 0 );

 hts_add_log( 'Sitemap index généré — ' . count( $entries ) . ' sous-sitemaps', 'success', 'sitemap' );

        return $xml;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: POST-TYPE SITEMAP
     * ══════════════════════════════════════════════ */

    private function generate_posttype_sitemap( $post_type, $page = 1 ) {
        $settings = self::get_settings();
        $max      = (int) $settings['max_urls_per_sitemap'];
        $offset   = ( $page - 1 ) * $max;
        $urls     = $this->get_eligible_urls( $post_type, $max, $offset );

        // Count how many were deduped to cocon sitemaps
        $cocon_dedup = 0;
        if ( $settings['cocon_sitemaps'] ) {
            $cocon_ids = $this->get_cocon_page_ids();
            $all_posts = get_posts( array(
                'post_type' => $post_type, 'post_status' => 'publish',
                'posts_per_page' => $settings['max_urls_per_sitemap'],
                'fields' => 'ids', 'lang' => '',
            ) );
            foreach ( $all_posts as $pid ) {
                if ( ! empty( $cocon_ids[ $pid ] ) ) $cocon_dedup++;
            }
        }

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xsl  = $this->get_xsl_url( 'urlset' );
        if ( $xsl ) {
            $xml .= '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl ) . '"?>' . "\n";
        }
        $xml .= $this->get_urlset_open() . "\n";

        $count = 0;
        foreach ( $urls as $u ) {
            if ( $count >= $settings['max_urls_per_sitemap'] ) break;
            $xml .= $this->build_url_entry( $u );
            $count++;
        }

        $xml .= '</urlset>';

        $this->update_stats( 'pt_' . $post_type, $count, $cocon_dedup );
        $dedup_note = $cocon_dedup > 0 ? ' (' . $cocon_dedup . ' dans sitemaps cocon)' : '';
 hts_add_log( 'Sitemap ' . $post_type . ' — ' . $count . 'URLs' . $dedup_note, 'success', 'sitemap' );

        return $xml;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: COCON SITEMAP (per cluster)
     * ══════════════════════════════════════════════ */

    private function generate_cocon_sitemap( $slug ) {
        $settings = self::get_settings();
        if ( ! $settings['cocon_sitemaps'] ) return '';

        $clusters = $this->get_cocon_clusters();
        $nodes    = $this->get_cocon_nodes();

        // Find cluster by slug
        $found_name = null;
        $found_cl   = null;
        foreach ( $clusters as $name => $cl ) {
            if ( sanitize_title( $name ) === $slug ) {
                $found_name = $name;
                $found_cl   = $cl;
                break;
            }
        }

        if ( ! $found_cl || empty( $found_cl['pages'] ) ) {
 hts_add_log( 'Sitemap cocon "' . $slug . '" — cluster introuvable ou vide', 'warning', 'sitemap' );
            return '';
        }

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xsl  = $this->get_xsl_url( 'urlset' );
        if ( $xsl ) {
            $xml .= '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl ) . '"?>' . "\n";
        }
        $xml .= $this->get_urlset_open() . "\n";
        $xml .= '<!-- Cocon Sémantique: ' . esc_html( $found_name ) . ' -->' . "\n";

        $count    = 0;
        $excluded = 0;

        // Pillar first
        $pillar_id = $found_cl['pillar_id'] ?? null;
        $ordered   = array();
        if ( $pillar_id && in_array( $pillar_id, $found_cl['pages'] ) ) {
            $ordered[] = $pillar_id;
        }
        foreach ( $found_cl['pages'] as $pid ) {
            if ( $pid !== $pillar_id ) $ordered[] = $pid;
        }

        foreach ( $ordered as $pid ) {
            $node = $nodes[ $pid ] ?? null;
            if ( ! $node ) continue;

            // Check exclusions
            if ( $this->is_excluded( $pid, $settings ) ) {
                $excluded++;
                continue;
            }

            $role = $node['role'] ?? 'fille';
            $is_pillar = ( $role === 'pilier' );

            $xml .= "  <url>\n";
            $xml .= '    <loc>' . esc_url( $node['url'] ?? get_permalink( $pid ) ) . "</loc>\n";
            $xml .= '    <lastmod>' . esc_html( get_post_modified_time( 'Y-m-d\TH:i:sP', true, $pid ) ) . "</lastmod>\n";
            if ( $settings['include_legacy_tags'] ) {
                $xml .= '    <changefreq>' . ( $is_pillar ? $settings['changefreq_pillar'] : $settings['changefreq_support'] ) . "</changefreq>\n";
                $xml .= '    <priority>' . ( $is_pillar ? $settings['priority_pillar'] : $settings['priority_support'] ) . "</priority>\n";
            }
            $xml .= "  </url>\n";
            $count++;
        }

        $xml .= '</urlset>';

        $this->update_stats( 'cocon_' . $slug, $count, $excluded );
 hts_add_log( 'Sitemap cocon "' . $found_name . '" — ' . $count . 'URLs (' . $excluded . ' exclues)', 'success', 'sitemap' );

        return $xml;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: TAXONOMY SITEMAP
     * ══════════════════════════════════════════════ */

    private function generate_taxonomy_sitemap( $taxonomy ) {
        // Validate taxonomy exists and is public
        $tax_obj = get_taxonomy( $taxonomy );
        if ( ! $tax_obj || ! $tax_obj->public ) return '';

        $terms = get_terms( array(
            'taxonomy'   => $taxonomy,
            'hide_empty' => true,
            'number'     => 1000, // Safety limit
        ) );

        if ( is_wp_error( $terms ) || empty( $terms ) ) return '';

        $settings = self::get_settings();
        $global_robots = get_option( 'hts_robots_global', array() );
        $urls = array();

        // If entire taxonomy is noindex, skip all terms
        if ( isset( $global_robots[ $taxonomy ] ) && is_array( $global_robots[ $taxonomy ] ) && in_array( 'noindex', $global_robots[ $taxonomy ], true ) ) {
            return '';
        }

        foreach ( $terms as $term ) {
            $link = get_term_link( $term );
            if ( is_wp_error( $link ) ) continue;

            // Get latest post in this term for lastmod
            $latest_post = get_posts( array(
                'tax_query'      => array( array( 'taxonomy' => $taxonomy, 'terms' => $term->term_id ) ),
                'posts_per_page' => 1,
                'orderby'        => 'modified',
                'order'          => 'DESC',
                'post_status'    => 'publish',
                'fields'         => 'ids',
                'lang'           => '',
            ) );

            $lastmod = '';
            if ( ! empty( $latest_post ) ) {
                $lastmod = get_post_modified_time( 'c', true, $latest_post[0] );
            }

            $entry = array(
                'loc'     => $link,
                'lastmod' => $lastmod,
            );

            if ( $settings['include_legacy_tags'] ) {
                $entry['changefreq'] = 'weekly';
                $entry['priority']   = '0.4';
            }

            $urls[] = $entry;
        }

        if ( empty( $urls ) ) return '';

        // Build XML
        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xsl  = $this->get_xsl_url( 'standard' );
        if ( $xsl ) {
            $xml .= '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl ) . '"?>' . "\n";
        }
        $xml .= $this->get_urlset_open() . "\n";

        foreach ( $urls as $u ) {
            $xml .= $this->build_url_entry( $u );
        }

        $xml .= '</urlset>';

        // Update stats
        $this->update_stats( 'tax-' . $taxonomy, count( $urls ), 0 );

        $tax_label = $tax_obj->label ?: $taxonomy;
        hts_add_log( 'Sitemap taxonomie "' . $tax_label . '" — ' . count( $urls ) . ' termes', 'success', 'sitemap' );

        return $xml;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: IMAGE SITEMAP
     * ══════════════════════════════════════════════ */

    private function generate_image_sitemap() {
        $settings = self::get_settings();

        $posts = get_posts( array(
            'post_type'      => $settings['post_types'],
            'post_status'    => 'publish',
            'posts_per_page' => $settings['max_urls_per_sitemap'],
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'lang'           => '',
        ) );

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
        $xml .= '        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

        $count       = 0;
        $img_count   = 0;
        $no_img      = 0;

        foreach ( $posts as $p ) {
            if ( $this->is_excluded( $p->ID, $settings ) ) continue;

            $images = $this->get_post_images( $p->ID );
            if ( empty( $images ) ) {
                $no_img++;
                continue;
            }

            $xml .= "  <url>\n";
            $xml .= '    <loc>' . esc_url( get_permalink( $p->ID ) ) . "</loc>\n";

            foreach ( $images as $img ) {
                $xml .= "    <image:image>\n";
                $xml .= '      <image:loc>' . esc_url( $img['url'] ) . "</image:loc>\n";
                if ( ! empty( $img['title'] ) ) {
                    $xml .= '      <image:title>' . $this->xml_escape( $img['title'] ) . "</image:title>\n";
                }
                if ( ! empty( $img['alt'] ) ) {
                    $xml .= '      <image:caption>' . $this->xml_escape( $img['alt'] ) . "</image:caption>\n";
                }
                $xml .= "    </image:image>\n";
                $img_count++;
            }

            $xml .= "  </url>\n";
            $count++;
        }

        $xml .= '</urlset>';

        $this->update_stats( 'images', $count, 0, array( 'total_images' => $img_count, 'pages_no_image' => $no_img ) );
 hts_add_log( 'Image sitemap — ' . $count . ' pages, ' . $img_count . ' images (' . $no_img . ' pages sans image)', 'success', 'sitemap' );

        return $xml;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: NEWS SITEMAP (Google News — last 48h)
     * ══════════════════════════════════════════════ */

    private function generate_news_sitemap() {
        $settings = self::get_settings();
        if ( empty( $settings['news_sitemap'] ) ) return '';

        $pub_name = $settings['news_publication_name'] ?: get_bloginfo( 'name' );
        $pub_lang = $settings['news_language'] ?: substr( get_locale(), 0, 2 );
        $pts      = $settings['news_post_types'] ?: array( 'post' );

        // Google News: only articles published in the last 48 hours
        $posts = get_posts( array(
            'post_type'      => $pts,
            'post_status'    => 'publish',
            'posts_per_page' => 1000,
            'date_query'     => array( array( 'after' => '48 hours ago' ) ),
            'orderby'        => 'date',
            'order'          => 'DESC',
            'lang'           => '',
        ) );

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
        $xml .= '        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">' . "\n";

        $count = 0;
        foreach ( $posts as $p ) {
            if ( $this->is_excluded( $p->ID, $settings ) ) continue;

            $xml .= "  <url>\n";
            $xml .= '    <loc>' . esc_url( get_permalink( $p->ID ) ) . "</loc>\n";
            $xml .= "    <news:news>\n";
            $xml .= "      <news:publication>\n";
            $xml .= '        <news:name>' . $this->xml_escape( $pub_name ) . "</news:name>\n";
            $xml .= '        <news:language>' . esc_html( $pub_lang ) . "</news:language>\n";
            $xml .= "      </news:publication>\n";
            $xml .= '      <news:publication_date>' . esc_html( get_the_date( 'c', $p ) ) . "</news:publication_date>\n";
            $xml .= '      <news:title>' . $this->xml_escape( get_the_title( $p ) ) . "</news:title>\n";
            $xml .= "    </news:news>\n";
            $xml .= "  </url>\n";
            $count++;
        }

        $xml .= '</urlset>';

        $this->update_stats( 'news', $count, 0 );
        hts_add_log( 'News sitemap — ' . $count . ' articles (dernières 48h)', 'success', 'sitemap' );

        return $xml;
    }

    /* ══════════════════════════════════════════════
     *  GENERATE: VIDEO SITEMAP
     * ══════════════════════════════════════════════ */

    private function generate_video_sitemap() {
        $settings = self::get_settings();
        if ( empty( $settings['video_sitemap'] ) ) return '';

        $posts = get_posts( array(
            'post_type'      => $settings['post_types'],
            'post_status'    => 'publish',
            'posts_per_page' => $settings['max_urls_per_sitemap'],
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'lang'           => '',
        ) );

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
        $xml .= '        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">' . "\n";

        $count = 0;
        foreach ( $posts as $p ) {
            if ( $this->is_excluded( $p->ID, $settings ) ) continue;

            // Extract video embeds from content
            $content = HTS_Content_Extractor::get_content( $p->ID );
            if ( ! $content ) continue;

            $videos = $this->extract_videos( $content );
            if ( empty( $videos ) ) continue;

            foreach ( $videos as $video ) {
                $xml .= "  <url>\n";
                $xml .= '    <loc>' . esc_url( get_permalink( $p->ID ) ) . "</loc>\n";
                $xml .= "    <video:video>\n";
                $xml .= '      <video:title>' . $this->xml_escape( get_the_title( $p ) ) . "</video:title>\n";
                $desc = get_the_excerpt( $p ) ?: wp_trim_words( wp_strip_all_tags( $content ), 25, '…' );
                $xml .= '      <video:description>' . $this->xml_escape( $desc ) . "</video:description>\n";
                if ( ! empty( $video['thumbnail'] ) ) {
                    $xml .= '      <video:thumbnail_loc>' . esc_url( $video['thumbnail'] ) . "</video:thumbnail_loc>\n";
                } elseif ( has_post_thumbnail( $p->ID ) ) {
                    $xml .= '      <video:thumbnail_loc>' . esc_url( get_the_post_thumbnail_url( $p->ID, 'medium' ) ) . "</video:thumbnail_loc>\n";
                }
                if ( ! empty( $video['url'] ) ) {
                    $xml .= '      <video:content_loc>' . esc_url( $video['url'] ) . "</video:content_loc>\n";
                }
                if ( ! empty( $video['embed'] ) ) {
                    $xml .= '      <video:player_loc>' . esc_url( $video['embed'] ) . "</video:player_loc>\n";
                }
                $xml .= '      <video:publication_date>' . esc_html( get_the_date( 'c', $p ) ) . "</video:publication_date>\n";
                $xml .= "    </video:video>\n";
                $xml .= "  </url>\n";
                $count++;
            }
        }

        $xml .= '</urlset>';

        $this->update_stats( 'video', $count, 0 );
        hts_add_log( 'Video sitemap — ' . $count . ' vidéos détectées', 'success', 'sitemap' );

        return $xml;
    }

    /**
     * Extract video embeds (YouTube, Vimeo, etc.) from post content.
     */
    private function extract_videos( $content ) {
        $videos = array();

        // YouTube: iframe embeds + oembed URLs
        $yt_patterns = array(
            '/<iframe[^>]+src=["\'](?:https?:)?\/\/(?:www\.)?youtube\.com\/embed\/([a-zA-Z0-9_-]+)[^"\']*["\'][^>]*>/i',
            '/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/i',
        );
        foreach ( $yt_patterns as $pattern ) {
            if ( preg_match_all( $pattern, $content, $matches ) ) {
                foreach ( $matches[1] as $vid_id ) {
                    $videos[] = array(
                        'url'       => 'https://www.youtube.com/watch?v=' . $vid_id,
                        'embed'     => 'https://www.youtube.com/embed/' . $vid_id,
                        'thumbnail' => 'https://img.youtube.com/vi/' . $vid_id . '/hqdefault.jpg',
                    );
                }
            }
        }

        // Vimeo
        if ( preg_match_all( '/<iframe[^>]+src=["\'](?:https?:)?\/\/player\.vimeo\.com\/video\/(\d+)[^"\']*["\'][^>]*>/i', $content, $matches ) ) {
            foreach ( $matches[1] as $vid_id ) {
                $videos[] = array(
                    'url'       => 'https://vimeo.com/' . $vid_id,
                    'embed'     => 'https://player.vimeo.com/video/' . $vid_id,
                    'thumbnail' => '',
                );
            }
        }

        // Deduplicate by URL
        $seen = array();
        $unique = array();
        foreach ( $videos as $v ) {
            $key = $v['url'] ?: $v['embed'];
            if ( ! isset( $seen[ $key ] ) ) {
                $seen[ $key ] = true;
                $unique[] = $v;
            }
        }

        return $unique;
    }

    /**
     * Get eligible URLs for a post type (excludes noindex, canonical-other, etc.)
     * When cocon_sitemaps is ON, pages already in a cocon cluster are EXCLUDED
     * from post-type sitemaps → they only appear in sitemap-cocon-{slug}.xml.
     * This guarantees 0 doublons across the entire sitemap index.
     */
    private function get_eligible_urls( $post_type, $limit = 0, $offset = 0 ) {
        $settings = self::get_settings();
        $max = $limit > 0 ? $limit : (int) $settings['max_urls_per_sitemap'];

        $posts = get_posts( array(
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => $max + 50, // Fetch extra to compensate for exclusions
            'offset'         => $offset,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'lang'           => '',
        ) );

        $urls  = array();
        $nodes = $this->get_cocon_nodes();

        // Dedup: if cocon sitemaps enabled, skip pages already in a cluster
        $cocon_ids = $settings['cocon_sitemaps'] ? $this->get_cocon_page_ids() : array();

        foreach ( $posts as $p ) {
            if ( count( $urls ) >= $max ) break;
            if ( $this->is_excluded( $p->ID, $settings ) ) continue;

            // Skip pages in a cocon cluster — they go in sitemap-cocon-{slug}.xml
            if ( ! empty( $cocon_ids[ $p->ID ] ) ) continue;

            $node = $nodes[ $p->ID ] ?? null;
            $role = $node['role'] ?? '';

            $urls[] = array(
                'loc'        => get_permalink( $p->ID ),
                'lastmod'    => get_post_modified_time( 'Y-m-d\TH:i:sP', true, $p->ID ),
                'changefreq' => $role === 'pilier' ? $settings['changefreq_pillar'] : $settings['changefreq_page'],
                'priority'   => $role === 'pilier' ? $settings['priority_pillar'] : $settings['priority_page'],
            );
        }

        return $urls;
    }

    /**
     * Build a single <url> entry.
     */
    private function build_url_entry( $u ) {
        $settings = self::get_settings();
        $xml  = "  <url>\n";
        $xml .= '    <loc>' . esc_url( $u['loc'] ) . "</loc>\n";

        // Hreflang alternates for multilingual sites
        if ( ! empty( $u['post_id'] ) && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $alternates = $this->get_hreflang_alternates( (int) $u['post_id'] );
            foreach ( $alternates as $lang => $url ) {
                $xml .= '    <xhtml:link rel="alternate" hreflang="' . esc_attr( $lang ) . '" href="' . esc_url( $url ) . '" />' . "\n";
            }
        }

        if ( ! empty( $u['lastmod'] ) ) {
            $xml .= '    <lastmod>' . esc_html( $u['lastmod'] ) . "</lastmod>\n";
        }
        if ( $settings['include_legacy_tags'] ) {
            $xml .= '    <changefreq>' . esc_html( $u['changefreq'] ) . "</changefreq>\n";
            $xml .= '    <priority>' . esc_html( $u['priority'] ) . "</priority>\n";
        }
        $xml .= "  </url>\n";
        return $xml;
    }

    /**
     * Get the urlset opening tag with xhtml namespace if multilingual.
     */
    private function get_urlset_open() {
        $xml = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $xml .= ' xmlns:xhtml="http://www.w3.org/1999/xhtml"';
        }
        $xml .= '>';
        return $xml;
    }

    /**
     * Get hreflang alternate URLs for a post (WPML, Polylang).
     *
     * @param int $post_id
     * @return array  e.g. [ 'fr' => 'https://...', 'en' => 'https://...', 'x-default' => '...' ]
     */
    private function get_hreflang_alternates( $post_id ) {
        if ( ! class_exists( 'HTS_Language' ) ) return array();

        $alternates = array();
        $method = HTS_Language::detect_method();

        if ( $method === 'wpml' ) {
            $post_type = get_post_type( $post_id );
            $trid = apply_filters( 'wpml_element_trid', null, $post_id, 'post_' . $post_type );
            if ( $trid ) {
                $translations = apply_filters( 'wpml_get_element_translations', null, $trid, 'post_' . $post_type );
                if ( is_array( $translations ) ) {
                    foreach ( $translations as $t ) {
                        if ( ! empty( $t->element_id ) && get_post_status( $t->element_id ) === 'publish' ) {
                            $alternates[ $t->language_code ] = get_permalink( $t->element_id );
                        }
                    }
                }
            }
        } elseif ( $method === 'polylang' && function_exists( 'pll_get_post_translations' ) ) {
            $translations = pll_get_post_translations( $post_id );
            if ( is_array( $translations ) ) {
                foreach ( $translations as $lang => $tid ) {
                    if ( $tid && get_post_status( $tid ) === 'publish' ) {
                        $alternates[ $lang ] = get_permalink( $tid );
                    }
                }
            }
        }

        // x-default = site default language
        if ( count( $alternates ) >= 2 ) {
            $default_lang = HTS_Language::get_site_default_lang();
            if ( isset( $alternates[ $default_lang ] ) ) {
                $alternates['x-default'] = $alternates[ $default_lang ];
            }
        }

        return $alternates;
    }

    /* ══════════════════════════════════════════════
     *  EXCLUSION LOGIC
     * ══════════════════════════════════════════════ */

    /**
     * Check if a post should be excluded from sitemaps.
     *
     * EXCLUSION RULES (best practices 2025):
     *   1. noindex pages (per-page or global rule)
     *   2. Canonical pointing to another URL (sitemap = canonical signal)
     *   3. Active redirect from this URL (only 200 OK in sitemaps)
     *   4. Draft, private, password-protected
     */
    private function is_excluded( $post_id, $settings = null ) {
        if ( ! $settings ) $settings = self::get_settings();

        // 1) noindex check
        if ( $settings['exclude_noindex'] ) {
            // Per-page robots meta — normalize: can be array ['noindex'] OR string "noindex,nofollow"
            $robots = get_post_meta( $post_id, '_hts_robots_meta', true );
            if ( self::robots_has_noindex( $robots ) ) {
                return true;
            }
            // Also check global noindex rules: stored as ['post' => ['noindex', ...], 'page' => [...]]
            $global = get_option( 'hts_robots_global', array() );
            $post   = get_post( $post_id );
            if ( $post && isset( $global[ $post->post_type ] ) ) {
                $g_rules = $global[ $post->post_type ];
                if ( is_array( $g_rules ) && in_array( 'noindex', $g_rules, true ) ) {
                    return true;
                }
            }
            // Also check via HTS_Robots::is_noindex() for maximum safety
            if ( class_exists( 'HTS_Robots' ) && HTS_Robots::is_noindex( $post_id ) ) {
                return true;
            }
        }

        // 2) canonical pointing elsewhere
        if ( $settings['exclude_canonical_other'] ) {
            $canon = get_post_meta( $post_id, '_hts_canonical_url', true );
            if ( $canon && ! empty( $canon ) ) {
                $self_url = get_permalink( $post_id );
                if ( untrailingslashit( $canon ) !== untrailingslashit( $self_url ) ) {
                    return true;
                }
            }
        }

        // 3) Active redirect from this URL → should NOT be in sitemap
        if ( ! empty( $settings['exclude_redirected'] ) && class_exists( 'HTS_Redirects' ) ) {
            global $wpdb;
            $table = $wpdb->prefix . 'hts_redirects';
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {
                $post_url  = get_permalink( $post_id );
                $post_path = wp_parse_url( $post_url, PHP_URL_PATH );
                $post_path = rtrim( $post_path, '/' );
                // Check if source_url matches (stored as relative path without leading slash usually)
                $found = $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE enabled = 1 AND is_regex = 0 AND ( source_url = %s OR source_url = %s OR source_url = %s )",
                    $post_path,
                    ltrim( $post_path, '/' ),
                    $post_path . '/'
                ) );
                if ( $found > 0 ) return true;
            }
        }

        // 4) Draft, private, password-protected
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return true;
        if ( ! empty( $post->post_password ) ) return true;

        return false;
    }

    /**
     * Check if robots meta value contains 'noindex'.
     * Handles ALL storage formats:
     *   - Array (from Robots metabox):  ['noindex', 'nofollow']
     *   - String (from Migration/Panel): "noindex,nofollow" or "noindex"
     *   - Serialized (legacy):           a:1:{i:0;s:7:"noindex";}
     *
     * @param mixed $robots  The raw meta value from get_post_meta()
     * @return bool
     */
    private static function robots_has_noindex( $robots ) {
        if ( empty( $robots ) ) return false;
        // Array format (Robots metabox)
        if ( is_array( $robots ) ) {
            return in_array( 'noindex', $robots, true );
        }
        // String format (Migration Wizard / SEO Panel)
        if ( is_string( $robots ) ) {
            // Check comma-separated: "noindex,nofollow"
            $parts = array_map( 'trim', explode( ',', $robots ) );
            return in_array( 'noindex', $parts, true );
        }
        return false;
    }

    /**
     * Parse a paginated sitemap type slug like "post-2" → post type "post", page 2.
     * Returns null if not a valid paginated type.
     *
     * @param string $type       The slug from URL (e.g. "post-2", "product-3")
     * @param array  $post_types Allowed post types
     * @return array|null        ['type' => 'post', 'page' => 2] or null
     */
    private static function parse_paginated_type( $type, $post_types ) {
        // Match pattern: {post_type}-{page_number}
        if ( preg_match( '/^(.+)-(\d+)$/', $type, $m ) ) {
            $pt   = $m[1];
            $page = (int) $m[2];
            if ( $page >= 2 && in_array( $pt, $post_types, true ) ) {
                return array( 'type' => $pt, 'page' => $page );
            }
        }
        return null;
    }

    /* ══════════════════════════════════════════════
     *  HELPERS: XML-safe text escaping
     * ══════════════════════════════════════════════ */

    /**
     * Escape text for XML output.
     * esc_html() uses htmlspecialchars(double_encode=false) which leaves HTML
     * entities like &rsquo; &ndash; &eacute; untouched — invalid in XML.
     * This method decodes ALL HTML entities to UTF-8 first, then escapes
     * only the 5 XML-safe characters: & < > " '
     *
     * @param string $text
     * @return string XML-safe text
     */
    private function xml_escape( $text ) {
        if ( ! $text ) return '';
        // 1. Decode all HTML entities to UTF-8 characters
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        // 2. Escape for XML (only &, <, >, ", ')
        return htmlspecialchars( $text, ENT_XML1 | ENT_QUOTES, 'UTF-8', true );
    }

    /* ══════════════════════════════════════════════
     *  HELPERS: Image extraction
     * ══════════════════════════════════════════════ */

    /**
     * Get all images for a post (featured + in-content).
     */
    private function get_post_images( $post_id ) {
        $images = array();
        $seen   = array();

        // Featured image
        $thumb_id = get_post_thumbnail_id( $post_id );
        if ( $thumb_id ) {
            $url = wp_get_attachment_image_url( $thumb_id, 'full' );
            if ( $url ) {
                $images[] = array(
                    'url'   => $url,
                    'title' => get_the_title( $thumb_id ),
                    'alt'   => get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ),
                );
                $seen[ $url ] = true;
            }
        }

        // In-content images (via Content Extractor for page builder compatibility)
        $extracted_content = HTS_Content_Extractor::get_content( $post_id );
        if ( $extracted_content && preg_match_all( '/<img[^>]+>/i', $extracted_content, $matches ) ) {
            foreach ( $matches[0] as $img_tag ) {
                $src = '';
                if ( preg_match( '/src=["\']([^"\']+)/i', $img_tag, $m ) ) {
                    $src = $m[1];
                }
                if ( ! $src || isset( $seen[ $src ] ) ) continue;
                // Only include images from same domain
                $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
                $img_host  = wp_parse_url( $src, PHP_URL_HOST );
                if ( $img_host && $img_host !== $site_host ) continue;

                $alt = '';
                if ( preg_match( '/alt=["\']([^"\']*)/i', $img_tag, $m ) ) {
                    $alt = $m[1];
                }
                $title = '';
                if ( preg_match( '/title=["\']([^"\']*)/i', $img_tag, $m ) ) {
                    $title = $m[1];
                }

                $images[] = array( 'url' => $src, 'title' => $title, 'alt' => $alt );
                $seen[ $src ] = true;

                if ( count( $images ) >= 50 ) break; // Cap per page
            }
        }

        return $images;
    }

    /* ══════════════════════════════════════════════
     *  HELPERS: Cocon data access
     * ══════════════════════════════════════════════ */

    private function get_cocon_data() {
        $lang = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $lang = HTS_Language::get_current_lang();
        }
        $key = $lang ? 'hts_cocon_data_' . $lang : 'hts_cocon_data';
        return get_option( $key, array() );
    }

    private function get_cocon_clusters() {
        $data = $this->get_cocon_data();
        return $data['clusters'] ?? array();
    }

    private function get_cocon_nodes() {
        $data = $this->get_cocon_data();
        return $data['nodes'] ?? array();
    }

    /**
     * Get all post IDs that belong to a named cocon cluster (excluding "Non classé").
     * Used to deduplicate: these pages go ONLY in cocon sitemaps, not in post-type sitemaps.
     */
    private function get_cocon_page_ids() {
        $clusters = $this->get_cocon_clusters();
        $ids = array();
        foreach ( $clusters as $name => $cl ) {
            if ( $name === 'Non classé' ) continue;
            if ( empty( $cl['pages'] ) ) continue;
            foreach ( $cl['pages'] as $pid ) {
                $ids[ $pid ] = true;
            }
        }
        return $ids;
    }

    /* ══════════════════════════════════════════════
     *  HELPERS: Dates
     * ══════════════════════════════════════════════ */

    private function get_latest_modified( $post_type ) {
        global $wpdb;
        $date = $wpdb->get_var( $wpdb->prepare(
            "SELECT post_modified_gmt FROM $wpdb->posts 
             WHERE post_type = %s AND post_status = 'publish' 
             ORDER BY post_modified_gmt DESC LIMIT 1",
            $post_type
        ) );
        return $date ? gmdate( 'Y-m-d\TH:i:s+00:00', strtotime( $date ) ) : null;
    }

    private function get_cluster_latest_modified( $cl ) {
        if ( empty( $cl['pages'] ) ) return null;
        $latest = 0;
        foreach ( $cl['pages'] as $pid ) {
            $mod = get_post_modified_time( 'U', true, $pid );
            if ( $mod > $latest ) $latest = $mod;
        }
        return $latest ? gmdate( 'Y-m-d\TH:i:s+00:00', $latest ) : null;
    }

    /* ══════════════════════════════════════════════
     *  XSL STYLESHEET (inline)
     * ══════════════════════════════════════════════ */

    private function get_xsl_url( $type ) {
        // Build URL from plugin root: hack-the-seo/public/xsl/
        $plugin_root_url = plugin_dir_url( dirname( __FILE__ ) );
        if ( $type === 'index' ) {
            return $plugin_root_url . 'public/xsl/sitemap-index.xsl';
        }
        return $plugin_root_url . 'public/xsl/sitemap.xsl';
    }

    /* ══════════════════════════════════════════════
     *  STATS & TRACKING
     * ══════════════════════════════════════════════ */

    private function update_stats( $key, $url_count, $excluded, $extra = array() ) {
        $stats = get_option( self::OPTION_STATS, array() );
        $stats[ $key ] = array_merge( array(
            'urls'      => $url_count,
            'excluded'  => $excluded,
            'generated' => current_time( 'Y-m-d H:i:s' ),
        ), $extra );
        $stats['last_generated'] = current_time( 'Y-m-d H:i:s' );
        update_option( self::OPTION_STATS, $stats, false );
    }

    private function record_serve( $type ) {
        $stats = get_option( self::OPTION_STATS, array() );
        if ( ! isset( $stats['serves'] ) ) $stats['serves'] = array();
        $today = current_time( 'Y-m-d' );
        if ( ! isset( $stats['serves'][ $today ] ) ) $stats['serves'][ $today ] = 0;
        $stats['serves'][ $today ]++;
        // Keep last 30 days
        $stats['serves'] = array_slice( $stats['serves'], -30, 30, true );
        $stats['last_served']     = current_time( 'Y-m-d H:i:s' );
        $stats['last_served_type'] = $type;
        update_option( self::OPTION_STATS, $stats, false );
    }

    /* ══════════════════════════════════════════════
     *  CACHE INVALIDATION
     * ══════════════════════════════════════════════ */

    public function invalidate_cache( $post_id, $post = null ) {
        if ( ! $post ) $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return;
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;

        // Delete all sitemap transients
        $this->invalidate_all_cache();

 hts_add_log( 'Cache sitemap invalidé (post #' . $post_id . ')', 'info', 'sitemap' );
    }

    public function invalidate_all_cache() {
        global $wpdb;
        $wpdb->query(
            "DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_hts_sitemap_%' OR option_name LIKE '_transient_timeout_hts_sitemap_%'"
        );
    }

    public function on_status_change( $new, $old, $post ) {
        if ( $new !== $old && ( $new === 'publish' || $old === 'publish' ) ) {
            $this->invalidate_all_cache();
        }
    }

    /* ══════════════════════════════════════════════
     *  PING ENGINES
     * ══════════════════════════════════════════════ */

    public function ping_engines( $post_id = 0 ) {
        $settings   = self::get_settings();
        $sitemap_url = home_url( '/sitemap.xml' );
        $results    = array();

        // Google (sitemap ping)
        if ( $settings['ping_google'] ) {
            $resp = wp_remote_get( 'https://www.google.com/ping?sitemap=' . urlencode( $sitemap_url ), array( 'timeout' => 5, 'blocking' => false ) );
            $results['google'] = ! is_wp_error( $resp );
        }

        // Bing (sitemap ping)
        if ( $settings['ping_bing'] ) {
            $resp = wp_remote_get( 'https://www.bing.com/ping?sitemap=' . urlencode( $sitemap_url ), array( 'timeout' => 5, 'blocking' => false ) );
            $results['bing'] = ! is_wp_error( $resp );
        }

        // IndexNow — batch mode: send all recently modified URLs (last 24h)
        if ( $settings['indexnow_enabled'] && ! empty( $settings['indexnow_key'] ) ) {
            $url_list = array();

            // Single post published
            if ( $post_id ) {
                $url = get_permalink( $post_id );
                if ( $url ) $url_list[] = $url;
            }

            // Batch mode: also include recently modified posts (last 24h)
            if ( ! empty( $settings['indexnow_batch'] ) ) {
                $recent = get_posts( array(
                    'post_type'      => $settings['post_types'],
                    'post_status'    => 'publish',
                    'posts_per_page' => 100,
                    'date_query'     => array( array(
                        'column' => 'post_modified_gmt',
                        'after'  => '24 hours ago',
                    ) ),
                    'lang'           => '',
                ) );
                foreach ( $recent as $rp ) {
                    $rurl = get_permalink( $rp->ID );
                    if ( $rurl && ! in_array( $rurl, $url_list, true ) ) {
                        $url_list[] = $rurl;
                    }
                }
            }

            if ( ! empty( $url_list ) ) {
                $payload = array(
                    'host'    => wp_parse_url( home_url(), PHP_URL_HOST ),
                    'key'     => $settings['indexnow_key'],
                    'urlList' => array_values( array_slice( $url_list, 0, 10000 ) ), // IndexNow max 10k
                );
                $resp = wp_remote_post( 'https://api.indexnow.org/indexnow', array(
                    'timeout'  => 10,
                    'blocking' => false,
                    'headers'  => array( 'Content-Type' => 'application/json' ),
                    'body'     => wp_json_encode( $payload ),
                ) );
                $results['indexnow'] = ! is_wp_error( $resp );
                $results['indexnow_urls'] = count( $url_list );
            }
        }

        if ( ! empty( $results ) ) {
            $engines = implode( ', ', array_keys( array_filter( $results, function( $v ) { return $v === true; } ) ) );
            $inow_note = isset( $results['indexnow_urls'] ) ? ' (' . $results['indexnow_urls'] . ' URLs IndexNow)' : '';
 hts_add_log( 'Ping envoyé : ' . ( $engines ?: 'aucun' ) . $inow_note, 'info', 'sitemap' );
        }

        // Save last ping
        $stats = get_option( self::OPTION_STATS, array() );
        $stats['last_ping']    = current_time( 'Y-m-d H:i:s' );
        $stats['ping_results'] = $results;
        update_option( self::OPTION_STATS, $stats, false );

        return $results;
    }

    /* ══════════════════════════════════════════════
     *  GOOGLE SEARCH CONSOLE API INTEGRATION
     *
     *  Auth method: Service Account JSON key
     *  API: Google Webmasters v3 (Search Console)
     *  Endpoints:
     *    PUT  /sites/{siteUrl}/sitemaps/{feedpath}  → Submit
     *    GET  /sites/{siteUrl}/sitemaps/{feedpath}  → Status
     *    GET  /sites/{siteUrl}/sitemaps              → List all
     *
     *  Requires: Service Account email added as
     *  "Owner" in GSC property settings.
     * ══════════════════════════════════════════════ */

    const OPTION_GSC = 'hts_sitemap_gsc';

    /**
     * Get GSC credentials (Service Account).
     */
    private static function get_gsc_creds() {
        return wp_parse_args( get_option( self::OPTION_GSC, array() ), array(
            'enabled'       => false,
            'client_email'  => '',
            'private_key'   => '',
            'site_url'      => '',  // e.g. https://example.com/
            'auto_submit'   => true,
            'last_submit'   => '',
            'last_status'   => array(),
        ) );
    }

    /**
     * Generate a JWT access token from Service Account credentials.
     * Google OAuth2 for Service Accounts: sign JWT with RS256, exchange for access_token.
     */
    private function gsc_get_access_token() {
        $creds = self::get_gsc_creds();
        if ( empty( $creds['client_email'] ) || empty( $creds['private_key'] ) ) return false;

        $now = time();
        $header  = self::base64url_encode( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
        $payload = self::base64url_encode( wp_json_encode( array(
            'iss'   => $creds['client_email'],
            'scope' => 'https://www.googleapis.com/auth/webmasters',
            'aud'   => 'https://oauth2.googleapis.com/token',
            'iat'   => $now,
            'exp'   => $now + 3600,
        ) ) );

        $signature_input = $header . '.' . $payload;
        $private_key = openssl_pkey_get_private( $creds['private_key'] );
        if ( ! $private_key ) {
 hts_add_log( 'GSC: Clé privée invalide', 'error', 'sitemap' );
            return false;
        }

        $signed = '';
        if ( ! openssl_sign( $signature_input, $signed, $private_key, OPENSSL_ALGO_SHA256 ) ) {
 hts_add_log( 'GSC: Échec signature JWT', 'error', 'sitemap' );
            return false;
        }

        $jwt = $signature_input . '.' . self::base64url_encode( $signed );

        // Exchange JWT for access token
        $resp = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'timeout' => 15,
            'body'    => array(
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion'  => $jwt,
            ),
        ) );

        if ( is_wp_error( $resp ) ) {
 hts_add_log( 'GSC: Erreur OAuth — ' . $resp->get_error_message(), 'error', 'sitemap' );
            return false;
        }

        $http_code = wp_remote_retrieve_response_code( $resp );
        if ( $http_code < 200 || $http_code >= 300 ) {
            hts_add_log( 'GSC: OAuth HTTP ' . $http_code, 'error', 'sitemap' );
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            hts_add_log( 'GSC: Réponse OAuth JSON invalide — ' . json_last_error_msg(), 'error', 'sitemap' );
            return false;
        }
        if ( empty( $body['access_token'] ) ) {
            $err = $body['error_description'] ?? $body['error'] ?? 'unknown';
 hts_add_log( 'GSC: Token refusé — ' . $err, 'error', 'sitemap' );
            return false;
        }

        return $body['access_token'];
    }

    private static function base64url_encode( $data ) {
        return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
    }

    /**
     * Submit sitemap to GSC via API.
     */
    public function gsc_submit_sitemap() {
        $creds = self::get_gsc_creds();
        if ( ! $creds['enabled'] || empty( $creds['site_url'] ) ) return false;

        $token = $this->gsc_get_access_token();
        if ( ! $token ) return false;

        $site_url    = rtrim( $creds['site_url'], '/' ) . '/';
        $sitemap_url = home_url( '/sitemap.xml' );

        // PUT /webmasters/v3/sites/{siteUrl}/sitemaps/{feedpath}
        $api_url = sprintf(
            'https://www.googleapis.com/webmasters/v3/sites/%s/sitemaps/%s',
            urlencode( $site_url ),
            urlencode( $sitemap_url )
        );

        $resp = wp_remote_request( $api_url, array(
            'method'  => 'PUT',
            'timeout' => 15,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
        ) );

        $code = wp_remote_retrieve_response_code( $resp );
        $ok   = ! is_wp_error( $resp ) && $code >= 200 && $code < 300;

        // Save status
        $gsc = get_option( self::OPTION_GSC, array() );
        $gsc['last_submit'] = current_time( 'Y-m-d H:i:s' );
        $gsc['last_submit_ok'] = $ok;
        update_option( self::OPTION_GSC, $gsc, false );

        hts_add_log(
 $ok ? 'GSC: Sitemap soumis avec succès' : 'GSC: Échec soumission (HTTP ' . $code . ')',
            $ok ? 'success' : 'error',
            'sitemap'
        );

        return $ok;
    }

    /**
     * Get sitemap status from GSC (submitted vs indexed counts).
     */
    public function gsc_get_status() {
        $creds = self::get_gsc_creds();
        if ( ! $creds['enabled'] || empty( $creds['site_url'] ) ) return false;

        $token = $this->gsc_get_access_token();
        if ( ! $token ) return false;

        $site_url    = rtrim( $creds['site_url'], '/' ) . '/';
        $sitemap_url = home_url( '/sitemap.xml' );

        // GET /webmasters/v3/sites/{siteUrl}/sitemaps/{feedpath}
        $api_url = sprintf(
            'https://www.googleapis.com/webmasters/v3/sites/%s/sitemaps/%s',
            urlencode( $site_url ),
            urlencode( $sitemap_url )
        );

        $resp = wp_remote_get( $api_url, array(
            'timeout' => 15,
            'headers' => array( 'Authorization' => 'Bearer ' . $token ),
        ) );

        if ( is_wp_error( $resp ) ) return false;

        $data = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( empty( $data['path'] ) ) return false;

        $status = array(
            'path'           => $data['path'],
            'last_submitted' => $data['lastSubmitted'] ?? '',
            'last_downloaded' => $data['lastDownloaded'] ?? '',
            'is_pending'     => $data['isPending'] ?? false,
            'errors'         => $data['errors'] ?? 0,
            'warnings'       => $data['warnings'] ?? 0,
            'contents'       => array(),
        );

        $total_submitted = 0;
        $total_indexed   = 0;
        if ( ! empty( $data['contents'] ) ) {
            foreach ( $data['contents'] as $c ) {
                $status['contents'][] = array(
                    'type'      => $c['type'] ?? '',
                    'submitted' => (int) ( $c['submitted'] ?? 0 ),
                    'indexed'   => (int) ( $c['indexed'] ?? 0 ),
                );
                $total_submitted += (int) ( $c['submitted'] ?? 0 );
                $total_indexed   += (int) ( $c['indexed'] ?? 0 );
            }
        }
        $status['total_submitted'] = $total_submitted;
        $status['total_indexed']   = $total_indexed;
        $status['index_ratio']     = $total_submitted > 0 ? round( $total_indexed / $total_submitted * 100, 1 ) : 0;

        // Cache status
        $gsc = get_option( self::OPTION_GSC, array() );
        $gsc['last_status']      = $status;
        $gsc['last_status_date'] = current_time( 'Y-m-d H:i:s' );
        update_option( self::OPTION_GSC, $gsc, false );

        return $status;
    }

    /* ═══ GSC AJAX Handlers ═══ */

    public function ajax_gsc_save_creds() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        $gsc = self::get_gsc_creds();
        $gsc['enabled']      = ! empty( $_POST['gsc_enabled'] );
        $gsc['site_url']     = esc_url_raw( $_POST['gsc_site_url'] ?? '' );
        $gsc['auto_submit']  = ! empty( $_POST['gsc_auto_submit'] );

        // Handle JSON key upload (contains client_email + private_key)
        if ( ! empty( $_POST['gsc_json_key'] ) ) {
            $key_data = json_decode( stripslashes( $_POST['gsc_json_key'] ), true );
            if ( ! empty( $key_data['client_email'] ) && ! empty( $key_data['private_key'] ) ) {
                $gsc['client_email'] = sanitize_email( $key_data['client_email'] );
                $gsc['private_key']  = $key_data['private_key']; // RSA key, keep as-is
 hts_add_log( 'GSC: Service Account configuré — ' . $gsc['client_email'], 'success', 'sitemap' );
            } else {
                wp_send_json_error( 'JSON invalide — doit contenir client_email et private_key' );
                return;
            }
        }

        update_option( self::OPTION_GSC, $gsc, false );
        wp_send_json_success( array( 'msg' => 'Credentials GSC sauvegardées', 'email' => $gsc['client_email'] ) );
    }

    public function ajax_gsc_submit() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        $ok = $this->gsc_submit_sitemap();
        if ( $ok ) {
            wp_send_json_success( array( 'msg' => 'Sitemap soumis à GSC' ) );
        } else {
            wp_send_json_error( 'Échec soumission GSC — vérifiez les credentials et les permissions.' );
        }
    }

    public function ajax_gsc_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        $status = $this->gsc_get_status();
        if ( $status ) {
            wp_send_json_success( $status );
        } else {
            // Return cached status if API fails
            $gsc = self::get_gsc_creds();
            if ( ! empty( $gsc['last_status'] ) ) {
                wp_send_json_success( array_merge( $gsc['last_status'], array( 'cached' => true ) ) );
            } else {
                wp_send_json_error( 'GSC non configuré ou erreur API' );
            }
        }
    }

    /* ══════════════════════════════════════════════
     *  ROBOTS.TXT
     * ══════════════════════════════════════════════ */

    public function add_to_robots_txt( $output, $public ) {
        if ( '0' === (string) $public ) return $output;
        $settings = self::get_settings();
        if ( ! $settings['enabled'] ) return $output;

        // Remove competing sitemap lines (Rank Math, Yoast, AIOSEO, etc.)
        if ( ! empty( $settings['disable_competing'] ) ) {
            // Target specific competing sitemap index formats — NOT our /sitemap.xml
            $competing_patterns = array(
                'sitemap_index.xml',       // Rank Math + Yoast index
                'aioseo-sitemap.xml',      // AIOSEO
                'sitemaps.xml',            // SEOPress
                'sitemap-seopress.xml',    // SEOPress alt
                'wp-sitemap.xml',          // WP Core (already disabled but cleanup)
            );
            $lines = explode( "\n", $output );
            $cleaned = array();
            foreach ( $lines as $line ) {
                $skip = false;
                if ( stripos( $line, 'Sitemap:' ) !== false ) {
                    foreach ( $competing_patterns as $pattern ) {
                        if ( stripos( $line, $pattern ) !== false ) {
                            $skip = true;
                            break;
                        }
                    }
                }
                if ( ! $skip ) $cleaned[] = $line;
            }
            $output = implode( "\n", $cleaned );
        }

        // Add HTS sitemap line (unique)
        $sitemap_line = 'Sitemap: ' . home_url( '/sitemap.xml' );
        if ( strpos( $output, $sitemap_line ) === false ) {
            $output .= "\n" . $sitemap_line . "\n";
        }
        return $output;
    }

    /* ══════════════════════════════════════════════
     *  HTML SITEMAP SHORTCODE [hts_sitemap]
     * ══════════════════════════════════════════════ */

    public function shortcode_html_sitemap( $atts ) {
        $atts = shortcode_atts( array(
            'show_cocon'  => 'yes',
            'show_dates'  => 'no',
            'max'         => 500,
        ), $atts );

        $settings = self::get_settings();
        $clusters = $settings['cocon_sitemaps'] && $atts['show_cocon'] === 'yes' ? $this->get_cocon_clusters() : array();
        $nodes    = $this->get_cocon_nodes();

        $html = '<div class="hts-html-sitemap">';

        // Cocon-organized section
        if ( ! empty( $clusters ) ) {
            $shown_ids = array();
            foreach ( $clusters as $name => $cl ) {
                if ( $name === 'Non classé' ) continue;
                if ( empty( $cl['pages'] ) ) continue;

                $html .= '<div class="hts-sitemap-cluster">';
                $html .= '<h3>' . esc_html( $name ) . '</h3>';
                $html .= '<ul>';

                // Pillar first
                $pillar_id = $cl['pillar_id'] ?? null;
                $ordered = array();
                if ( $pillar_id && in_array( $pillar_id, $cl['pages'] ) ) {
                    $ordered[] = $pillar_id;
                }
                foreach ( $cl['pages'] as $pid ) {
                    if ( $pid !== $pillar_id ) $ordered[] = $pid;
                }

                foreach ( $ordered as $pid ) {
                    if ( $this->is_excluded( $pid, $settings ) ) continue;
                    $title = get_the_title( $pid );
                    $url   = get_permalink( $pid );
                    $role  = $nodes[ $pid ]['role'] ?? '';
 $badge = $role === 'pilier' ? ' <strong></strong>' : '';
                    $date  = $atts['show_dates'] === 'yes' ? ' <small>(' . get_the_modified_date( 'Y-m-d', $pid ) . ')</small>' : '';
                    $html .= '<li><a href="' . esc_url( $url ) . '">' . esc_html( $title ) . $badge . '</a>' . $date . '</li>';
                    $shown_ids[ $pid ] = true;
                }

                $html .= '</ul></div>';
            }

            // Remaining pages (not in any cluster)
            $remaining = get_posts( array(
                'post_type'      => $settings['post_types'],
                'post_status'    => 'publish',
                'posts_per_page' => (int) $atts['max'],
                'post__not_in'   => array_keys( $shown_ids ),
                'orderby'        => 'title',
                'order'          => 'ASC',
                'lang'           => '',
            ) );

            if ( ! empty( $remaining ) ) {
                $html .= '<div class="hts-sitemap-cluster">';
                $html .= '<h3>Autres pages</h3><ul>';
                foreach ( $remaining as $p ) {
                    if ( $this->is_excluded( $p->ID, $settings ) ) continue;
                    $html .= '<li><a href="' . esc_url( get_permalink( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a></li>';
                }
                $html .= '</ul></div>';
            }
        } else {
            // Flat list by post type
            foreach ( $settings['post_types'] as $pt ) {
                $pt_obj = get_post_type_object( $pt );
                $label  = $pt_obj ? $pt_obj->labels->name : ucfirst( $pt );
                $posts  = get_posts( array(
                    'post_type'      => $pt,
                    'post_status'    => 'publish',
                    'posts_per_page' => (int) $atts['max'],
                    'orderby'        => 'title',
                    'order'          => 'ASC',
                    'lang'           => '',
                ) );
                if ( empty( $posts ) ) continue;

                $html .= '<div class="hts-sitemap-cluster">';
                $html .= '<h3>' . esc_html( $label ) . '</h3><ul>';
                foreach ( $posts as $p ) {
                    if ( $this->is_excluded( $p->ID, $settings ) ) continue;
                    $html .= '<li><a href="' . esc_url( get_permalink( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a></li>';
                }
                $html .= '</ul></div>';
            }
        }

        $html .= '</div>';

        // Basic CSS
        $html .= '<style>
            .hts-html-sitemap { max-width: 900px; }
            .hts-sitemap-cluster { margin-bottom: 24px; }
            .hts-sitemap-cluster h3 { font-size: 18px; margin-bottom: 8px; border-bottom: 2px solid #e2e8f0; padding-bottom: 4px; }
            .hts-sitemap-cluster ul { list-style: none; padding: 0; columns: 2; column-gap: 32px; }
            .hts-sitemap-cluster li { padding: 4px 0; break-inside: avoid; }
            .hts-sitemap-cluster a { text-decoration: none; color: #2563eb; }
            .hts-sitemap-cluster a:hover { text-decoration: underline; }
            @media (max-width: 600px) { .hts-sitemap-cluster ul { columns: 1; } }
        </style>';

        return $html;
    }

    /* ══════════════════════════════════════════════
     *  AJAX: Get Dashboard Data
     * ══════════════════════════════════════════════ */

    public function ajax_get_data() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        $settings = self::get_settings();
        $stats    = get_option( self::OPTION_STATS, array() );
        $clusters = $settings['cocon_sitemaps'] ? $this->get_cocon_clusters() : array();

        // Build sitemap list with stats
        $sitemaps = array();

        // Post-type sitemaps
        foreach ( $settings['post_types'] as $pt ) {
            $key = 'pt_' . $pt;
            $sitemaps[] = array(
                'name'      => ucfirst( $pt ),
                'url'       => home_url( '/sitemap-' . $pt . '.xml' ),
                'type'      => 'post_type',
                'urls'      => $stats[ $key ]['urls'] ?? '—',
                'excluded'  => $stats[ $key ]['excluded'] ?? 0,
                'generated' => $stats[ $key ]['generated'] ?? null,
            );
        }

        // Cocon sitemaps
        if ( $settings['cocon_sitemaps'] ) {
            foreach ( $clusters as $name => $cl ) {
                if ( $name === 'Non classé' ) continue;
                $slug = sanitize_title( $name );
                $key  = 'cocon_' . $slug;
                $sitemaps[] = array(
 'name' => ' ' . $name,
                    'url'       => home_url( '/sitemap-cocon-' . $slug . '.xml' ),
                    'type'      => 'cocon',
                    'urls'      => $stats[ $key ]['urls'] ?? '—',
                    'excluded'  => $stats[ $key ]['excluded'] ?? 0,
                    'generated' => $stats[ $key ]['generated'] ?? null,
                    'pillar_id' => $cl['pillar_id'] ?? null,
                    'pages'     => count( $cl['pages'] ?? array() ),
                );
            }
        }

        // Image sitemap
        if ( $settings['image_sitemap'] ) {
            $sitemaps[] = array(
 'name' => 'Images',
                'url'       => home_url( '/sitemap-images.xml' ),
                'type'      => 'images',
                'urls'      => $stats['images']['urls'] ?? '—',
                'images'    => $stats['images']['total_images'] ?? 0,
                'no_image'  => $stats['images']['pages_no_image'] ?? 0,
                'generated' => $stats['images']['generated'] ?? null,
            );
        }

        // Warnings
        $warnings = array();
        if ( empty( $clusters ) && $settings['cocon_sitemaps'] ) {
            $warnings[] = array( 'type' => 'info', 'msg' => 'Lancez une analyse Cocon Sémantique pour générer les sitemaps par cluster.' );
        }
        $last_gen = $stats['last_generated'] ?? null;
        if ( $last_gen && strtotime( $last_gen ) < strtotime( '-7 days' ) ) {
            $warnings[] = array( 'type' => 'warning', 'msg' => 'Sitemaps non régénérés depuis plus de 7 jours. Cliquez "Régénérer" pour mettre à jour.' );
        }
        $no_img = $stats['images']['pages_no_image'] ?? 0;
        if ( $no_img > 5 ) {
            $warnings[] = array( 'type' => 'warning', 'msg' => $no_img . ' pages publiées sans aucune image — pensez à ajouter des visuels.' );
        }

        // Stale lastmod warning: pages active but not modified in 6+ months
        $stale_6m = 0;
        $stale_check = get_posts( array(
            'post_type' => $settings['post_types'], 'post_status' => 'publish',
            'posts_per_page' => -1, 'fields' => 'ids', 'lang' => '',
            'date_query' => array( array( 'column' => 'post_modified_gmt', 'before' => '6 months ago' ) ),
        ) );
        $stale_6m = count( $stale_check );
        if ( $stale_6m > 10 ) {
            $warnings[] = array( 'type' => 'info', 'msg' => $stale_6m . ' pages ont un lastmod > 6 mois. Google utilise lastmod pour prioriser le crawl — pensez à rafraîchir le contenu.' );
        }

        // HTML sitemap equity warning
        if ( ! empty( $settings['html_sitemap'] ) ) {
 $warnings[] = array( 'type' => 'info', 'msg' => 'HTML Sitemap activé — attention, un lien en footer dilue le link equity de chaque page. Désactivez si peu visité.' );
        }

        // Legacy tags info
        if ( ! empty( $settings['include_legacy_tags'] ) ) {
            $warnings[] = array( 'type' => 'info', 'msg' => 'Tags &lt;changefreq&gt; et &lt;priority&gt; activés (mode legacy). Google les ignore officiellement — seul &lt;lastmod&gt; est utilisé.' );
        }

        // Competing plugin detection
        $competitors = self::detect_competing_plugins();
        if ( ! empty( $competitors ) ) {
            $names = array_map( function( $c ) { return $c['name']; }, $competitors );
            $names_str = implode( ', ', $names );
            if ( ! empty( $settings['disable_competing'] ) ) {
 $warnings[] = array( 'type' => 'info', 'msg' => 'Plugin(s) SEO détecté(s) : <strong>' . $names_str . '</strong> — leurs sitemaps sont automatiquement désactivés au profit de HTS.' );
            } else {
 $warnings[] = array( 'type' => 'warning', 'msg' => ' <strong>CONFLIT</strong> : ' . $names_str . ' génère aussi des sitemaps. Risque de doublons dans Google. Activez "Désactiver sitemaps concurrents" dans les paramètres ou désactivez le module sitemap de ' . $names_str . '.' );
            }
        }

        // Total URLs
        $total_urls = 0;
        foreach ( $stats as $k => $v ) {
            if ( is_array( $v ) && isset( $v['urls'] ) && is_numeric( $v['urls'] ) ) {
                $total_urls += $v['urls'];
            }
        }

        wp_send_json_success( array(
            'settings'       => $settings,
            'stats'          => $stats,
            'sitemaps'       => $sitemaps,
            'warnings'       => $warnings,
            'total_urls'     => $total_urls,
            'total_sitemaps' => count( $sitemaps ),
            'index_url'      => home_url( '/sitemap.xml' ),
            'last_ping'      => $stats['last_ping'] ?? null,
            'ping_results'   => $stats['ping_results'] ?? array(),
        ) );
    }

    /* ══════════════════════════════════════════════
     *  AJAX: Save Settings
     * ══════════════════════════════════════════════ */

    public function ajax_save_settings() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        $new = array(
            'enabled'                 => ! empty( $_POST['enabled'] ),
            'disable_wp_sitemaps'     => ! empty( $_POST['disable_wp_sitemaps'] ),
            'cocon_sitemaps'          => ! empty( $_POST['cocon_sitemaps'] ),
            'image_sitemap'           => ! empty( $_POST['image_sitemap'] ),
            'taxonomy_sitemap'        => ! empty( $_POST['taxonomy_sitemap'] ),
            'html_sitemap'            => ! empty( $_POST['html_sitemap'] ),
            'ping_google'             => ! empty( $_POST['ping_google'] ),
            'ping_bing'               => ! empty( $_POST['ping_bing'] ),
            'indexnow_enabled'        => ! empty( $_POST['indexnow_enabled'] ),
            'indexnow_key'            => sanitize_text_field( $_POST['indexnow_key'] ?? '' ),
            'indexnow_batch'          => ! empty( $_POST['indexnow_batch'] ),
            'exclude_noindex'         => ! empty( $_POST['exclude_noindex'] ),
            'exclude_canonical_other' => ! empty( $_POST['exclude_canonical_other'] ),
            'exclude_redirected'      => ! empty( $_POST['exclude_redirected'] ),
            'disable_competing'       => ! empty( $_POST['disable_competing'] ),
            'include_legacy_tags'     => ! empty( $_POST['include_legacy_tags'] ),
            'gzip_enabled'            => ! empty( $_POST['gzip_enabled'] ),
            'changefreq_pillar'       => sanitize_text_field( $_POST['changefreq_pillar'] ?? 'weekly' ),
            'changefreq_support'      => sanitize_text_field( $_POST['changefreq_support'] ?? 'monthly' ),
            'changefreq_page'         => sanitize_text_field( $_POST['changefreq_page'] ?? 'monthly' ),
            'priority_pillar'         => sanitize_text_field( $_POST['priority_pillar'] ?? '1.0' ),
            'priority_support'        => sanitize_text_field( $_POST['priority_support'] ?? '0.8' ),
            'priority_page'           => sanitize_text_field( $_POST['priority_page'] ?? '0.5' ),
            'max_urls_per_sitemap'    => max( 100, min( 50000, intval( $_POST['max_urls_per_sitemap'] ?? 1000 ) ) ),
        );

        // Post types — sanitize
        $raw_pts = isset( $_POST['post_types'] ) ? (array) $_POST['post_types'] : array( 'post', 'page' );
        $new['post_types'] = array_map( 'sanitize_key', $raw_pts );

        update_option( self::OPTION_SETTINGS, $new );

        // Flush rewrite rules immediately
        flush_rewrite_rules( false );

        // Invalidate cache
        $this->invalidate_all_cache();

 hts_add_log( 'Paramètres sitemap sauvegardés', 'success', 'sitemap' );
        wp_send_json_success( array( 'saved' => true ) );
    }

    /* ══════════════════════════════════════════════
     *  AJAX: Regenerate All Sitemaps
     * ══════════════════════════════════════════════ */

    public function ajax_regenerate() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        // Clear all caches
        $this->invalidate_all_cache();

        $settings = self::get_settings();
        $generated = array();

        // Generate index
        $xml = $this->generate_index();
        if ( $xml ) {
            set_transient( self::TRANSIENT_PREFIX . 'index', $xml, self::CACHE_TTL );
            $generated[] = 'index';
        }

        // Generate post-type sitemaps
        foreach ( $settings['post_types'] as $pt ) {
            $xml = $this->generate_posttype_sitemap( $pt );
            if ( $xml ) {
                set_transient( self::TRANSIENT_PREFIX . $pt, $xml, self::CACHE_TTL );
                $generated[] = $pt;
            }
        }

        // Generate cocon sitemaps
        if ( $settings['cocon_sitemaps'] ) {
            $clusters = $this->get_cocon_clusters();
            foreach ( $clusters as $name => $cl ) {
                if ( $name === 'Non classé' ) continue;
                $slug = sanitize_title( $name );
                $xml  = $this->generate_cocon_sitemap( $slug );
                if ( $xml ) {
                    set_transient( self::TRANSIENT_PREFIX . 'cocon-' . $slug, $xml, self::CACHE_TTL );
                    $generated[] = 'cocon-' . $slug;
                }
            }
        }

        // Generate image sitemap
        if ( $settings['image_sitemap'] ) {
            $xml = $this->generate_image_sitemap();
            if ( $xml ) {
                set_transient( self::TRANSIENT_PREFIX . 'images', $xml, self::CACHE_TTL );
                $generated[] = 'images';
            }
        }

        // Generate news sitemap
        if ( ! empty( $settings['news_sitemap'] ) ) {
            $xml = $this->generate_news_sitemap();
            if ( $xml ) {
                set_transient( self::TRANSIENT_PREFIX . 'news', $xml, self::CACHE_TTL );
                $generated[] = 'news';
            }
        }

        // Generate video sitemap
        if ( ! empty( $settings['video_sitemap'] ) ) {
            $xml = $this->generate_video_sitemap();
            if ( $xml ) {
                set_transient( self::TRANSIENT_PREFIX . 'video', $xml, self::CACHE_TTL );
                $generated[] = 'video';
            }
        }

        // Flush rewrite rules
        flush_rewrite_rules( false );

 hts_add_log( 'Régénération complète — ' . count( $generated ) . ' sitemaps', 'success', 'sitemap' );
        wp_send_json_success( array( 'regenerated' => $generated, 'count' => count( $generated ) ) );
    }

    /* ══════════════════════════════════════════════
     *  AJAX: Manual Ping
     * ══════════════════════════════════════════════ */

    public function ajax_ping() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden' );

        $results = $this->ping_engines( 0 );
        wp_send_json_success( array( 'ping_results' => $results ) );
    }

    /* ══════════════════════════════════════════════
     *  STATIC HELPERS (for orchestrator / dashboard)
     * ══════════════════════════════════════════════ */

    /**
     * Get total URL count across all sitemaps.
     */
    public static function get_total_urls() {
        $stats = get_option( self::OPTION_STATS, array() );
        $total = 0;
        foreach ( $stats as $k => $v ) {
            if ( is_array( $v ) && isset( $v['urls'] ) && is_numeric( $v['urls'] ) ) {
                $total += (int) $v['urls'];
            }
        }
        return $total;
    }

    /**
     * Get last generation time.
     */
    public static function get_last_generated() {
        $stats = get_option( self::OPTION_STATS, array() );
        return $stats['last_generated'] ?? null;
    }

    /**
     * Check if sitemaps are stale (> 7 days).
     */
    public static function is_stale() {
        $last = self::get_last_generated();
        if ( ! $last ) return true;
        return strtotime( $last ) < strtotime( '-7 days' );
    }

    /**
     * Get warning count (for nav badge).
     */
    public static function get_warning_count() {
        $count = 0;
        if ( self::is_stale() ) $count++;
        $stats = get_option( self::OPTION_STATS, array() );
        $no_img = $stats['images']['pages_no_image'] ?? 0;
        if ( $no_img > 5 ) $count++;
        return $count;
    }
}
