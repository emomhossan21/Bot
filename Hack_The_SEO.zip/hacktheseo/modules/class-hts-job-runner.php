<?php
/**
 * HTS Job Runner — Batch processing for limited servers.
 *
 * Splits any heavy operation into steps of max 20 seconds.
 * Compatible with shared hosting (max_execution_time = 30s).
 *
 * @package HackTheSEO
 * @since   2.8.0
 */

if ( ! defined( 'WPINC' ) ) die;

class HTS_Job_Runner {

    const OPTION_PREFIX = 'hts_job_';
    const MAX_STEP_TIME = 20;
    const TTL           = 3600;

    /**
     * Create a new job.
     *
     * @param string $type   Job type (cocon_analyze, money_discover, inbox_scan, etc.)
     * @param array  $params Job parameters.
     * @param int    $total  Total items to process.
     * @return array
     */
    public static function create( $type, $params = array(), $total = 0 ) {
        $job_id = 'hts_' . $type . '_' . substr( md5( uniqid( '', true ) ), 0, 8 );

        $job = array(
            'job_id'     => $job_id,
            'type'       => $type,
            'status'     => 'running',
            'params'     => $params,
            'total'      => $total,
            'processed'  => 0,
            'step'       => 0,
            'result'     => array(),
            'errors'     => array(),
            'created_at' => time(),
            'updated_at' => time(),
        );

        update_option( self::OPTION_PREFIX . $job_id, $job, false );
        return $job;
    }

    /**
     * Load an existing job.
     *
     * @param string $job_id
     * @return array|null
     */
    public static function load( $job_id ) {
        $job = get_option( self::OPTION_PREFIX . $job_id );
        if ( ! $job || ! is_array( $job ) ) return null;

        if ( ( time() - $job['created_at'] ) > self::TTL ) {
            self::delete( $job_id );
            return null;
        }

        return $job;
    }

    /**
     * Update a job.
     *
     * @param string $job_id
     * @param array  $data
     * @return array|false
     */
    public static function update( $job_id, $data ) {
        $job = self::load( $job_id );
        if ( ! $job ) return false;

        $job = array_merge( $job, $data );
        $job['updated_at'] = time();
        update_option( self::OPTION_PREFIX . $job_id, $job, false );
        return $job;
    }

    /**
     * Mark a job as complete.
     *
     * @param string $job_id
     * @param array  $result
     * @return array|false
     */
    public static function complete( $job_id, $result = array() ) {
        return self::update( $job_id, array(
            'status' => 'done',
            'result' => $result,
        ) );
    }

    /**
     * Mark a job as failed.
     *
     * @param string $job_id
     * @param string $error
     * @return array|false
     */
    public static function fail( $job_id, $error = '' ) {
        $job = self::load( $job_id );
        return self::update( $job_id, array(
            'status' => 'failed',
            'errors' => array_merge( $job['errors'] ?? array(), array( $error ) ),
        ) );
    }

    /**
     * Delete a job (cleanup).
     *
     * @param string $job_id
     */
    public static function delete( $job_id ) {
        delete_option( self::OPTION_PREFIX . $job_id );
    }

    /**
     * Check if we still have time in the current step.
     *
     * @param float $start microtime(true) from step start.
     * @return bool
     */
    public static function has_time( $start ) {
        return ( microtime( true ) - $start ) < self::MAX_STEP_TIME;
    }

    /**
     * Calculate progress percentage.
     *
     * @param array $job
     * @return int
     */
    public static function progress_pct( $job ) {
        if ( ! $job || $job['total'] <= 0 ) return 0;
        return min( 100, round( $job['processed'] / $job['total'] * 100 ) );
    }

    /**
     * Clean up expired jobs. Called by cron.
     *
     * @return int Number of deleted jobs.
     */
    public static function cleanup() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'hts_job_hts_%'"
        );
        $deleted = 0;
        foreach ( $rows as $row ) {
            $job = get_option( $row->option_name );
            if ( $job && isset( $job['created_at'] ) && ( time() - $job['created_at'] ) > self::TTL ) {
                delete_option( $row->option_name );
                $deleted++;
            }
        }
        return $deleted;
    }
}
