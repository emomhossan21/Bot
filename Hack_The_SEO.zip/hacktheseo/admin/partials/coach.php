<?php
/**
 * Hack The SEO — Coach SEO (S13-B v3 — DS v5.7)
 *
 * MAQUETTE-DRIVEN layout:
 *  - Chat = full width (no permanent sidebar grid column)
 *  - Right panel = opens dynamically when Coach sends charts/plans/tables
 *  - Sidebar info = drawer overlay (scores, memory, GSC) — not in grid
 *
 * Cockpit JS compatibility:
 *  - All 48 critical IDs preserved
 *  - All CSS classes preserved (coach-wrap, coach-layout, coach-msg, etc.)
 *  - Sidebar toggle patched via setTimeout(0) to override cockpit functions
 *    after they're defined (cockpit script runs after this include)
 *
 * @since 2.6.0
 *
 * S19 UX REFONTE (2026-03-16):
 *  - Topbar simplifie : menu hamburger, supprime Profil/X/Sessions, Stats cache debug
 *  - Resizer : grip dots radial-gradient visible, zone 12px, feedback visuel drag
 *  - Rapport : summary callout geo, icones SVG sections, commentary cards, KPI hover+help
 *  - Tables : overflow-x:auto + max-width:220px + text-overflow:ellipsis
 *  - data-ask : auto-send coachSend() au clic (pas besoin de cliquer envoyer)
 *  - Discussion : #htsReportThread cache (pas de duplication chat)
 *  - Boutons hover : 11px, fond geo, "Demander au Coach"
 */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}

// ── Data ──
if ( ! isset( $nonce ) )           $nonce           = wp_create_nonce( 'hts_admin_nonce' );
if ( ! isset( $has_key ) ) {
    $has_key = class_exists( 'HTS_Coach' ) ? ! empty( HTS_Coach::get_api_key() ) : false;
    if ( ! $has_key ) {
        $has_key = ! empty( function_exists( 'hts_get_api_key' ) ? hts_get_api_key() : '' ); // SaaS key = coach via proxy
    }
}
if ( ! isset( $usage ) )           $usage           = class_exists( 'HTS_Coach' ) ? HTS_Coach::get_usage() : array( 'tokens_in' => 0, 'tokens_out' => 0, 'requests' => 0 );
if ( ! isset( $budget ) )          $budget          = class_exists( 'HTS_Coach' ) ? HTS_Coach::get_monthly_budget() : 100000;
if ( ! isset( $url_session_id ) )  $url_session_id  = 0;
if ( ! isset( $ssr_messages ) )    $ssr_messages    = array();
if ( ! isset( $ssr_plans ) )       $ssr_plans       = array();
if ( ! isset( $ssr_seo_plans ) )   $ssr_seo_plans   = array();
if ( ! isset( $ssr_actions ) )     $ssr_actions     = array();
if ( ! isset( $ssr_skipped ) )     $ssr_skipped     = array();
if ( ! isset( $ssr_debug ) )       $ssr_debug       = '';

$coach_total = ( $usage['tokens_in'] ?? 0 ) + ( $usage['tokens_out'] ?? 0 );
$coach_pct   = $budget > 0 ? min( 100, round( $coach_total / $budget * 100 ) ) : 0;
$base_url    = admin_url( 'admin.php?page=hts-light-dashboard' );

$gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
$gsc_nonce     = wp_create_nonce( 'hts_gsc_admin' );
$gsc_queries   = get_option( 'hts_gsc_queries', array() );
$gsc_pages     = get_option( 'hts_gsc_pages', array() );
$gsc_meta      = get_option( 'hts_gsc_import_meta', array() );
$has_csv       = ! empty( $gsc_queries ) || ! empty( $gsc_pages );
$site_icon_url = get_site_icon_url( 28 );
?>

<script src="<?php echo esc_url( HTS__PLUGIN_URL . 'admin/js/chart.min.js' ); ?>"></script>
<script src="<?php echo esc_url( HTS__PLUGIN_URL . 'admin/js/marked.min.js' ); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dompurify/3.0.6/purify.min.js"></script>
<script>window._htsFavicon = <?php echo wp_json_encode( $site_icon_url ? $site_icon_url : '' ); ?>;</script>

<style>
/* ═══ Dark Mode tokens ═══ */
[data-hts-theme="dark"]{--hts-bg:#141417;--hts-surface:#1C1C20;--hts-elevated:#222228;--hts-text:#F0F0F5;--hts-text-2:#9CA3AF;--hts-text-3:#6B7280;--hts-faint:#3A3A42;--hts-border:#2D2D35;--hts-border-sub:#222228;--hts-accent-bg:rgba(45,127,249,.12);--hts-geo-soft:rgba(99,102,241,.08);--hts-geo-border:rgba(99,102,241,.2);--hts-geo-text:#A5B4FC;--hts-gray-50:#18181C;--hts-gray-100:#1E1E24;--hts-gray-200:#2A2A32;--hts-shadow:0 1px 3px rgba(0,0,0,.3),0 1px 2px rgba(0,0,0,.2);--hts-shadow-md:0 4px 6px -1px rgba(0,0,0,.35),0 2px 4px -2px rgba(0,0,0,.25);--hts-pill-bg:rgba(255,255,255,.08);--hts-success-bg:rgba(0,210,106,.1);--hts-danger-bg:rgba(255,77,106,.1);--hts-caution-bg:rgba(255,149,0,.1);--hts-info-bg:rgba(0,194,255,.1)}
[data-hts-theme="dark"] .hts-icon-sun{display:block}[data-hts-theme="dark"] .hts-icon-moon{display:none}
:root:not([data-hts-theme="dark"]) .hts-icon-sun{display:none}:root:not([data-hts-theme="dark"]) .hts-icon-moon{display:block}

/* ═══ Token bridge ═══ */
:root {
	--coach-primary:var(--hts-geo);--coach-primary-light:var(--hts-geo-soft);
	--coach-primary-dark:var(--hts-accent);--coach-accent:var(--hts-geo);
	--coach-bg:var(--hts-bg);--coach-surface:var(--hts-bg);
	--coach-text:var(--hts-text);--coach-text-muted:var(--hts-text-2);
	--coach-border:var(--hts-border);--coach-radius:var(--hts-radius);
}

/* WP reset — Coach takes over the full screen */
#wpbody-content{padding-bottom:0!important;overflow:hidden!important}
.wrap{margin:0!important;padding:0!important}
#wpcontent{overflow:hidden}

/* ── Wrap: ALWAYS fullscreen above WP admin bar ── */
.coach-wrap{position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:100000;font-family:var(--hts-font,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif);background:var(--hts-bg,#fff);display:flex;flex-direction:column;overflow:hidden;box-sizing:border-box;margin:0!important;padding:0!important;contain:layout style}
/* coach-fullscreen class is now a no-op since we're always fullscreen */
.coach-fullscreen{}

/* ── Top bar — refined with DS tokens ── */
.hts-coach-topbar{display:flex;align-items:center;justify-content:space-between;padding:var(--hts-sp-3) var(--hts-sp-6);background:var(--hts-bg);border-bottom:1px solid var(--hts-border);flex-shrink:0;position:relative}
.coach-header{display:none}

/* ── Layout: SPLIT SCREEN (sidebar left + chat center + panel right) ── */
.coach-layout{display:flex;flex-direction:row;flex:1;min-height:0;position:relative;overflow:hidden;contain:layout}
.coach-layout.coach-sidebar-collapsed{}

/* ── History Sidebar (left) ── */
.coach-history{width:0;min-width:0;overflow:hidden;background:var(--hts-bg,#fff);border-right:1px solid var(--hts-border);display:flex;flex-direction:column;flex-shrink:0;transition:width .15s var(--hts-ease-out),min-width .15s var(--hts-ease-out);will-change:width;contain:layout style}
.coach-history.open{width:280px;min-width:280px}
.coach-history-header{padding:14px 16px;border-bottom:1px solid var(--hts-border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.coach-history-header span{font-size:12px;font-weight:700;color:var(--hts-text);text-transform:uppercase;letter-spacing:.3px}
.coach-history-new{padding:5px 12px;border:1px solid var(--hts-border);border-radius:6px;background:var(--hts-bg,#fff);font-size:11px;font-weight:600;color:var(--hts-geo);cursor:pointer;transition:all .15s}
.coach-history-new:hover{background:var(--hts-geo);color:#fff;border-color:var(--hts-geo)}
.coach-history-body{flex:1;overflow-y:auto;padding:8px}
.coach-history-item{display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:8px;font-size:12px;color:var(--hts-text-2);cursor:pointer;transition:background .12s;line-height:1.3}
.coach-history-item:hover{background:var(--hts-border-sub,#f8fafc)}
.coach-history-item.active{background:var(--hts-geo-soft,rgba(99,102,241,.06));color:var(--hts-geo);font-weight:600}
.coach-history-date{font-size:9px;color:var(--hts-text-3);margin-left:auto;white-space:nowrap}
@media(max-width:768px){.coach-history.open{position:absolute;z-index:10;top:0;left:0;bottom:0;width:280px;box-shadow:8px 0 24px rgba(0,0,0,.1)}}

/* ── Chat (center — shrinks when panel opens) ── */
.coach-chat{display:flex;flex-direction:column;background:var(--hts-bg);overflow:hidden;min-width:320px;flex:1;transition:flex .15s var(--hts-ease-out)}
.coach-messages{flex:1;overflow-y:auto;padding:var(--hts-sp-8) var(--hts-sp-6);display:flex;flex-direction:column;gap:4px;scroll-behavior:smooth;min-height:0;max-width:720px;width:100%;margin:0 auto;box-sizing:border-box;contain:layout;-webkit-overflow-scrolling:touch}

/* ════ MESSAGES — Linear/Claude.ai style: NO bubbles, clean prose ════ */
.coach-msg{display:flex;gap:var(--hts-sp-3);max-width:100%;animation:coach-fade-in .15s var(--hts-ease-out);min-width:0;padding:var(--hts-sp-4) 0}
.coach-msg.user{padding:var(--hts-sp-3) 0;justify-content:flex-end}

/* Avatar — site favicon for user, zap for assistant */
.coach-msg-avatar{width:28px;height:28px;border-radius:var(--hts-radius-sm);display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;margin-top:1px;overflow:hidden}
.coach-msg.assistant .coach-msg-avatar{background:var(--hts-gray-800);color:#fff}
.coach-msg.user .coach-msg-avatar{background:var(--hts-surface);border:1px solid var(--hts-border)}
.coach-msg-avatar img{width:100%;height:100%;object-fit:cover;border-radius:var(--hts-radius-sm)}

/* Message content — no bubble border, just typography */
.coach-msg-bubble{font-size:14.5px;line-height:1.75;color:var(--hts-text);overflow-wrap:break-word;word-break:break-word;min-width:0;flex:1;letter-spacing:-.01em}
.coach-msg.assistant .coach-msg-bubble{background:transparent}
.coach-msg.user .coach-msg-bubble{background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:var(--hts-radius);padding:var(--hts-sp-3) var(--hts-sp-4);color:var(--hts-text);font-size:13.5px;flex:none;max-width:80%}

/* Message typography — generous spacing, bold hierarchy */
.coach-msg-bubble h1,.coach-msg-bubble h2,.coach-msg-bubble h3{font-size:15px;font-weight:700;margin:var(--hts-sp-5) 0 var(--hts-sp-2);color:var(--hts-text);letter-spacing:-.02em}
.coach-msg-bubble h1:first-child,.coach-msg-bubble h2:first-child,.coach-msg-bubble h3:first-child{margin-top:0}
.coach-msg-bubble p{margin:0 0 var(--hts-sp-3)}.coach-msg-bubble p:last-child{margin-bottom:0}
.coach-msg-bubble ul,.coach-msg-bubble ol{margin:var(--hts-sp-2) 0 var(--hts-sp-3);padding-left:var(--hts-sp-5)}
.coach-msg-bubble li{margin-bottom:var(--hts-sp-2);line-height:1.65}
.coach-msg-bubble strong{font-weight:700;color:var(--hts-text)}
.coach-msg-bubble em{color:var(--hts-text-2)}
.coach-msg-bubble code{background:var(--hts-border-sub);padding:2px 6px;border-radius:var(--hts-radius-xs);font-size:12px;font-family:var(--hts-mono)}
.coach-msg-bubble pre{background:var(--hts-gray-800);color:var(--hts-gray-200);padding:var(--hts-sp-4);border-radius:var(--hts-radius-sm);overflow-x:auto;font-size:12px;line-height:1.5;margin:var(--hts-sp-3) 0}
.coach-msg-bubble pre code{background:none;padding:0;color:inherit;font-size:inherit}
.coach-msg-bubble blockquote{border-left:2px solid var(--hts-geo);padding:var(--hts-sp-2) var(--hts-sp-3);margin:var(--hts-sp-3) 0;color:var(--hts-text-2);background:var(--hts-surface);border-radius:0 var(--hts-radius-xs) var(--hts-radius-xs) 0}
.coach-msg-bubble a{color:var(--hts-geo);font-weight:600;text-decoration:none;transition:opacity var(--hts-dur-fast)}
.coach-msg-bubble a:hover{opacity:.8}

/* Tables in messages — compact, clickable */
.coach-msg-bubble table{width:100%;border-collapse:separate;border-spacing:0;margin:var(--hts-sp-3) 0;font-size:12px;border:1px solid var(--hts-border);border-radius:var(--hts-radius-sm);overflow:hidden;cursor:pointer;transition:box-shadow var(--hts-dur-fast) var(--hts-ease-out)}
.coach-msg-bubble table:hover{box-shadow:0 0 0 2px var(--hts-geo-border)}
.coach-msg-bubble table th{background:var(--hts-surface);color:var(--hts-text-2);font-weight:600;text-align:left;padding:var(--hts-sp-2) var(--hts-sp-3);border-bottom:1px solid var(--hts-border);font-size:10px;text-transform:uppercase;letter-spacing:.3px}
.coach-msg-bubble table td{padding:var(--hts-sp-2) var(--hts-sp-3);border-bottom:1px solid var(--hts-border-sub);color:var(--hts-text)}
.coach-msg-bubble table tr:last-child td{border-bottom:none}
.coach-msg-bubble table tr:hover td{background:var(--hts-geo-soft)}

/* ── Charts (inline — DS card) ── */
.coach-chart-wrap{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius);padding:var(--hts-sp-5);margin-top:var(--hts-sp-3);max-width:440px;box-shadow:var(--hts-shadow);position:relative;cursor:pointer;transition:box-shadow var(--hts-dur-fast) var(--hts-ease-out)}
.coach-chart-wrap:hover{box-shadow:var(--hts-shadow-md)}
.coach-chart-wrap::before{content:'';position:absolute;top:var(--hts-sp-2);left:var(--hts-sp-2);width:22px;height:22px;border-radius:var(--hts-radius-xs);background:var(--hts-geo);opacity:0;transition:opacity var(--hts-dur-normal);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2'%3E%3Cpath d='M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:center}
.coach-chart-wrap:hover::before{opacity:.85}
.coach-chart-title{font-size:12px;font-weight:600;color:var(--hts-text-2);margin-bottom:var(--hts-sp-3);text-align:center;text-transform:uppercase;letter-spacing:.3px}
.coach-chart-export{position:absolute;top:var(--hts-sp-2);right:var(--hts-sp-2);width:28px;height:28px;border-radius:var(--hts-radius-xs);border:none;cursor:pointer;background:var(--hts-surface);color:var(--hts-text-3);font-size:14px;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity var(--hts-dur-normal)}
.coach-chart-wrap:hover .coach-chart-export{opacity:1}
.coach-chart-export:hover{background:var(--hts-geo);color:#fff}

/* Provider/actions/typing — minimal */
.coach-provider-badge{display:inline-flex;align-items:center;gap:4px;margin-top:var(--hts-sp-2);font-size:10px;font-weight:600;padding:2px var(--hts-sp-2);border-radius:var(--hts-radius-pill);opacity:.6}
.coach-provider-badge.haiku{background:var(--hts-geo-soft);color:var(--hts-geo-text)}
.coach-provider-badge.openai{background:var(--hts-success-bg);color:#059669}
.coach-provider-badge.sonnet{background:var(--hts-geo-soft);color:var(--hts-geo-text)}
.coach-provider-dot{width:5px;height:5px;border-radius:50%;display:inline-block}
.coach-actions-banner{margin-top:var(--hts-sp-3);padding:var(--hts-sp-3) var(--hts-sp-4);background:var(--hts-geo-soft);border:1px solid var(--hts-geo-border);border-radius:var(--hts-radius-sm);font-size:12px;color:var(--hts-geo-text);display:flex;align-items:center;gap:var(--hts-sp-2)}

/* Thinking indicator — shimmer wave like Claude */
.coach-typing{display:flex;gap:var(--hts-sp-3);align-self:flex-start;padding:var(--hts-sp-4) 0}
.coach-typing-dots{display:flex;align-items:center;gap:6px;padding:12px 20px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:var(--hts-radius);position:relative;overflow:hidden}
.coach-typing-dots::after{content:'';position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(99,102,241,.06),transparent);animation:coach-shimmer 1.5s ease infinite}
@keyframes coach-shimmer{to{left:100%}}
.coach-typing-dot{width:5px;height:5px;background:var(--hts-text-3);border-radius:50%;animation:coach-wave .8s var(--hts-ease-spring) infinite alternate}
.coach-typing-dot:nth-child(2){animation-delay:.1s}
.coach-typing-dot:nth-child(3){animation-delay:.2s}
@keyframes coach-wave{to{transform:translateY(-3px);opacity:.3}}
@keyframes coach-fade-in{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.coach-stream-cursor{display:inline;color:var(--hts-geo);animation:coach-cursor-blink .8s step-end infinite}
.coach-stream-cursor::after{content:'\2588';font-size:12px}
@keyframes coach-cursor-blink{0%,100%{opacity:1}50%{opacity:0}}

/* Memory */
.coach-memory-section{margin-bottom:0}
.coach-memory-header{display:flex;align-items:center;justify-content:space-between;cursor:pointer;font-size:12px;font-weight:600;color:var(--hts-text);padding:2px 0;user-select:none}
.coach-memory-header:hover{color:var(--hts-geo)}
.coach-memory-chevron{font-size:10px;color:var(--hts-text-3);transition:transform .2s}
.coach-memory-body{margin-top:8px}
.coach-memory-area-group{margin-bottom:8px}
.coach-memory-area-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--hts-geo);margin-bottom:4px;padding-bottom:3px;border-bottom:1px solid var(--hts-border)}
.coach-memory-fact{display:flex;align-items:flex-start;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--hts-border-sub,#f1f5f9);gap:4px}
.coach-memory-fact:last-child{border-bottom:none}
.coach-memory-fact-text{flex:1;min-width:0;cursor:pointer;padding:2px 4px;border-radius:3px;transition:background .15s}
.coach-memory-fact-text:hover{background:var(--hts-border-sub,#f1f5f9)}
.coach-memory-fact-actions{display:flex;gap:2px;flex-shrink:0}
.coach-memory-fact-btn{font-size:10px;background:none;border:none;cursor:pointer;padding:2px 4px;border-radius:3px;transition:background .15s}
.coach-memory-fact-btn:hover{background:var(--hts-border-sub,#f1f5f9)}
.coach-memory-fact-btn.delete{color:var(--hts-danger)}
.coach-memory-fact-btn.edit{color:var(--hts-geo)}
.coach-memory-fact-input{width:100%;padding:4px 6px;border:1px solid var(--hts-geo);border-radius:4px;font-size:11px;outline:none;background:#fff}
.coach-profile-field{display:flex;align-items:flex-start;gap:4px;margin-bottom:4px}
.coach-profile-label{font-size:11px;font-weight:600;color:var(--hts-text);white-space:nowrap;min-width:70px}
.coach-profile-value{font-size:11px;color:var(--hts-text-2);cursor:pointer;padding:1px 4px;border-radius:3px;flex:1;min-width:0;word-break:break-word;transition:background .15s}
.coach-profile-value:hover{background:var(--hts-border-sub,#f1f5f9)}
.coach-profile-value:empty::after{content:'Cliquer pour d\00e9finir';color:var(--hts-text-3);font-style:italic}
.coach-profile-input{width:100%;padding:3px 6px;border:1px solid var(--hts-geo);border-radius:4px;font-size:11px;outline:none}
.coach-memory-source-badge{font-size:9px;padding:1px 4px;border-radius:3px;font-weight:600}
.coach-memory-source-badge.extracted{background:var(--hts-geo-soft);color:var(--hts-geo)}
.coach-memory-source-badge.manual{background:#dcfce7;color:#15803d}

/* ── Input — frosted glass bottom bar ── */
.coach-input-area{padding:var(--hts-sp-4) var(--hts-sp-6);border-top:1px solid var(--hts-border);background:var(--hts-bg);flex-shrink:0;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}
.coach-input-row{display:flex;gap:var(--hts-sp-3);align-items:flex-end;max-width:720px;margin:0 auto}
.coach-input{flex:1;resize:none;border:1.5px solid var(--hts-border);border-radius:var(--hts-radius-lg);padding:var(--hts-sp-3) var(--hts-sp-4);font-size:14px;font-family:var(--hts-font);line-height:1.5;min-height:24px;max-height:200px;outline:none;transition:border-color var(--hts-dur-fast) var(--hts-ease-out),box-shadow var(--hts-dur-fast) var(--hts-ease-out);background:var(--hts-bg);overflow-y:auto;color:var(--hts-text)}
.coach-input:focus{border-color:var(--hts-geo);box-shadow:0 0 0 3px var(--hts-geo-soft)}
.coach-input::placeholder{color:var(--hts-text-3)}
.coach-send-btn{width:40px;height:40px;border-radius:var(--hts-radius);border:none;cursor:pointer;background:var(--hts-gray-800);color:#fff;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all var(--hts-dur-fast) var(--hts-ease-spring);flex-shrink:0}
.coach-send-btn:hover{background:var(--hts-geo);transform:scale(1.05)}
.coach-send-btn:active{transform:scale(.92)}
.coach-send-btn:disabled{opacity:.3;cursor:not-allowed}

/* ── Suggestions — pills with DS tokens ── */
.coach-suggestions{display:flex;flex-wrap:wrap;gap:var(--hts-sp-2);padding:0 var(--hts-sp-6) var(--hts-sp-3);flex-shrink:0;max-width:720px;margin:0 auto;width:100%;box-sizing:border-box}
.coach-pill{padding:var(--hts-sp-2) var(--hts-sp-3);background:var(--hts-bg);color:var(--hts-text-2);border:1px solid var(--hts-border);border-radius:var(--hts-radius-pill);font-size:12px;font-weight:500;cursor:pointer;transition:all var(--hts-dur-fast) var(--hts-ease-out);white-space:nowrap;line-height:1.3}
.coach-pill:hover{color:var(--hts-geo-text);border-color:var(--hts-geo-border);background:var(--hts-geo-soft);transform:translateY(-1px)}

/* Welcome — DS v5.7, clean and premium */
.coach-welcome-loading{color:var(--hts-text-3);font-size:13px}
.coach-welcome-alerts{margin-top:var(--hts-sp-5);display:flex;flex-direction:column;gap:var(--hts-sp-2)}
.coach-welcome-alert{display:flex;align-items:center;gap:var(--hts-sp-3);padding:var(--hts-sp-3) var(--hts-sp-4);border-radius:var(--hts-radius-sm);font-size:13px;line-height:1.55;background:var(--hts-bg);border:1px solid var(--hts-border);color:var(--hts-text);animation:coachAlertSlide var(--hts-dur-medium) var(--hts-ease-out) both;cursor:default}
.coach-welcome-alert:nth-child(1){animation-delay:.1s}
.coach-welcome-alert:nth-child(2){animation-delay:.2s}
.coach-welcome-alert:nth-child(3){animation-delay:.3s}
@keyframes coachAlertSlide{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.coach-welcome-alert:hover{border-color:var(--hts-geo-border);background:var(--hts-surface)}
.coach-welcome-alert.critical{border-left:3px solid var(--hts-danger)}
.coach-welcome-alert.warning{border-left:3px solid var(--hts-caution)}
.coach-welcome-alert.positive{border-left:3px solid var(--hts-success)}
.coach-welcome-alert.info{border-left:3px solid var(--hts-geo)}
.coach-welcome-alert-icon{font-size:15px;flex-shrink:0;opacity:.7}
.coach-welcome-alert-text{flex:1;font-size:13px;color:var(--hts-text)}
.coach-welcome-nudge{display:inline-flex;align-items:center;gap:var(--hts-sp-2);margin-top:var(--hts-sp-4);padding:var(--hts-sp-2) var(--hts-sp-5);border-radius:var(--hts-radius-sm);background:var(--hts-gray-800);color:#fff;font-size:13px;font-weight:600;cursor:pointer;border:none;transition:all var(--hts-dur-fast) var(--hts-ease-spring);animation:coachAlertSlide var(--hts-dur-medium) var(--hts-ease-out) .4s both}
.coach-welcome-nudge:hover{background:var(--hts-geo);transform:translateY(-1px);box-shadow:var(--hts-shadow-md)}
.coach-welcome-nudge-arrow{font-size:14px}
.coach-welcome-suggestions{display:flex;flex-wrap:wrap;gap:var(--hts-sp-2);margin-top:var(--hts-sp-4);animation:coachAlertSlide var(--hts-dur-medium) var(--hts-ease-out) .5s both}
.coach-welcome-suggestion-btn{padding:var(--hts-sp-2) var(--hts-sp-4);border-radius:var(--hts-radius-pill);font-size:12.5px;font-weight:500;background:var(--hts-bg);border:1px solid var(--hts-border);color:var(--hts-text);cursor:pointer;transition:all var(--hts-dur-fast) var(--hts-ease-out);white-space:nowrap;line-height:1.3}
.coach-welcome-suggestion-btn:first-child{background:var(--hts-gray-800);color:#fff;border-color:var(--hts-gray-800);font-weight:600}
.coach-welcome-suggestion-btn:hover{background:var(--hts-geo);color:#fff;border-color:var(--hts-geo);transform:translateY(-1px);box-shadow:var(--hts-shadow)}
.coach-welcome-suggestion-btn:first-child:hover{background:var(--hts-geo)}
.hts-tab-badge-coach{background:var(--hts-geo)!important;animation:htsBadgePulse 2s ease-in-out infinite}
@keyframes htsBadgePulse{0%,100%{opacity:1}50%{opacity:.6}}

/* ═══ SIDEBAR DRAWER (always overlay, never grid) ═══ */
.coach-sidebar{position:fixed;right:0;top:49px;bottom:0;width:340px;z-index:100001;background:var(--hts-bg,#fff);border-left:1px solid var(--hts-border);box-shadow:-8px 0 32px rgba(0,0,0,.1);overflow-y:auto;padding:20px;transform:translateX(100%);transition:transform .15s var(--hts-ease-out);will-change:transform;contain:layout style}
.coach-sidebar.hts-sidebar-open{transform:translateX(0)}
.coach-sidebar-section{margin-bottom:20px}
.coach-sidebar-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--hts-text-2);margin-bottom:10px}
.coach-stat-card{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:10px;padding:12px 14px;margin-bottom:8px}
.coach-stat-label{font-size:11px;color:var(--hts-text-2);font-weight:500}
.coach-stat-value{font-size:20px;font-weight:800;color:var(--hts-text);margin-top:2px}
.coach-stat-sub{font-size:11px;color:var(--hts-text-2);margin-top:2px}
.coach-usage-bar{height:6px;background:var(--hts-border);border-radius:3px;margin-top:8px;overflow:hidden}
.coach-usage-fill{height:100%;border-radius:3px;transition:width .3s}
.coach-gallery-item{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:6px;cursor:pointer;transition:background .15s;border-bottom:1px solid var(--hts-border-sub,#f1f5f9)}
.coach-gallery-item:hover{background:var(--hts-geo-soft)}
.coach-gallery-item:last-child{border-bottom:none}
.coach-gallery-icon{width:28px;height:28px;border-radius:6px;background:var(--hts-geo-soft);color:var(--hts-geo);display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0}
.coach-gallery-info{flex:1;min-width:0}
.coach-gallery-title{font-size:11px;font-weight:600;color:var(--hts-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.coach-gallery-date{font-size:10px;color:var(--hts-text-3)}
.coach-config-panel{background:#fffbeb;border:1px solid #fcd34d;border-radius:var(--hts-radius);padding:16px;margin-bottom:20px}
.coach-config-panel input[type="password"],.coach-config-panel input[type="text"]{width:100%;padding:8px 10px;border:1px solid var(--hts-border);border-radius:6px;font-size:12px;margin-top:4px;font-family:monospace}
.coach-config-btn{margin-top:8px;padding:6px 14px;font-size:11px;font-weight:600;border:none;border-radius:6px;cursor:pointer;background:var(--hts-geo);color:#fff}

/* Overlay */
.coach-overlay{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.4);z-index:100000;backdrop-filter:blur(2px)}
.coach-overlay.active{display:block}
/* Safety: cockpit JS may add .coach-sidebar-open before our setTimeout override */
.coach-sidebar-open .coach-sidebar{transform:translateX(0)}

/* ═══ SESSIONS DROPDOWN ═══ */
.hts-sessions-dropdown{position:absolute;top:100%;right:16px;width:340px;max-height:420px;background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius);box-shadow:0 12px 40px rgba(0,0,0,.12);z-index:10002;display:none;flex-direction:column;overflow:hidden}
.hts-sessions-dropdown.open{display:flex}
.hts-sessions-dropdown-header{padding:12px 16px;border-bottom:1px solid var(--hts-border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.hts-sessions-dropdown-header span{font-size:13px;font-weight:700;color:var(--hts-text)}
.hts-sessions-dropdown-body{flex:1;overflow-y:auto;padding:6px}
.hts-sessions-dropdown-body:empty::after{content:'Chargement\2026';display:block;text-align:center;padding:20px;color:var(--hts-text-3);font-size:12px}
.hts-session-row{display:flex;align-items:flex-start;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;transition:background .12s;border-left:3px solid transparent}
.hts-session-row:hover{background:var(--hts-geo-soft,rgba(99,102,241,.04))}
.hts-session-row.active{border-left-color:var(--hts-geo);background:var(--hts-geo-soft,rgba(99,102,241,.04))}
.hts-session-row-icon{width:28px;height:28px;border-radius:8px;background:var(--hts-border-sub,#f1f5f9);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:12px;color:var(--hts-text-3)}
.hts-session-row.active .hts-session-row-icon{background:var(--hts-geo);color:#fff}
.hts-session-row-info{flex:1;min-width:0}
.hts-session-row-title{font-size:12px;font-weight:600;color:var(--hts-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hts-session-row-meta{font-size:10px;color:var(--hts-text-3);margin-top:1px;display:flex;gap:8px}

/* ═══ SPLIT PANEL (right side — flex sibling of chat) ═══ */
.hts-coach-artifact{width:0;min-width:0;overflow:hidden;background:var(--hts-bg,#fff);border-left:none;display:none;flex-direction:column;transition:width .15s var(--hts-ease-out),min-width .15s var(--hts-ease-out);flex-shrink:0;will-change:width}
.hts-coach-artifact.hts-artifact-open{width:50%;min-width:400px;display:flex;border-left:1px solid var(--hts-border)}
@media(max-width:900px){.hts-coach-artifact.hts-artifact-open{width:100%;min-width:0;position:absolute;top:0;right:0;bottom:0;z-index:10}}
#hts-report-dropdown{display:none}#hts-report-dropdown.hts-dd-open{display:block}

/* Resizer */
.hts-coach-artifact-resizer{position:absolute;left:-6px;top:0;bottom:0;width:12px;cursor:col-resize;z-index:2}
.hts-coach-artifact-resizer::after{content:'';position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:4px;height:24px;background-image:radial-gradient(circle,var(--hts-text-3) 1px,transparent 1px);background-size:4px 6px;opacity:.5;transition:all .2s}
.hts-coach-artifact-resizer:hover::after{opacity:1;background-image:radial-gradient(circle,var(--hts-geo) 1px,transparent 1px);height:36px}
.hts-coach-artifact-resizer.dragging::after{opacity:1;background-image:radial-gradient(circle,var(--hts-geo) 1.5px,transparent 1.5px);height:48px}
.hts-coach-artifact-resizer:hover,.hts-coach-artifact-resizer.dragging{background:rgba(99,102,241,.04)}
.hts-coach-artifact:not(.hts-artifact-open) .hts-coach-artifact-resizer{display:none}

/* Header */
.hts-coach-artifact-header{display:flex;align-items:center;justify-content:space-between;padding:10px 16px;border-bottom:1px solid var(--hts-border);flex-shrink:0;background:var(--hts-bg)}
.hts-artifact-header-left{display:flex;align-items:center;gap:8px;min-width:0}
.hts-artifact-header-left span:first-of-type{font-size:14px;font-weight:700;color:var(--hts-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hts-artifact-type-badge{font-size:9px;font-weight:700;padding:2px 8px;border-radius:4px;text-transform:uppercase;letter-spacing:.3px;white-space:nowrap}
.hts-artifact-type-badge[data-type="chart"]{background:var(--hts-geo-soft);color:var(--hts-geo)}
.hts-artifact-type-badge[data-type="table"]{background:#ecfdf5;color:#059669}
.hts-artifact-type-badge[data-type="seo"]{background:#fef3c7;color:#92400e}
.hts-artifact-type-badge[data-type="plan"]{background:#ede9fe;color:#6d28d9}
.hts-artifact-type-badge[data-type="report"]{background:linear-gradient(135deg,rgba(99,102,241,.1),rgba(139,92,246,.1));color:var(--hts-geo);font-weight:800}
.hts-artifact-header-actions{display:flex;align-items:center;gap:6px;flex-shrink:0}
.hts-artifact-action-btn{background:none;border:1px solid var(--hts-border);border-radius:6px;padding:5px 10px;font-size:11px;font-weight:600;color:var(--hts-text-2);cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:4px;white-space:nowrap}
.hts-artifact-action-btn:hover{background:var(--hts-geo-soft);color:var(--hts-geo);border-color:var(--hts-geo)}
.hts-artifact-action-btn svg{flex-shrink:0}

/* Toolbar (between header and body) */
.hts-artifact-toolbar{display:none;padding:8px 16px;border-bottom:1px solid var(--hts-border-sub,#f1f5f9);flex-shrink:0;gap:8px;align-items:center}
.hts-artifact-toolbar.visible{display:flex}
.hts-artifact-search{flex:1;max-width:280px;padding:6px 10px 6px 32px;border:1px solid var(--hts-border);border-radius:6px;font-size:12px;outline:none;background:var(--hts-bg) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cline x1='21' y1='21' x2='16.65' y2='16.65'/%3E%3C/svg%3E") 10px center no-repeat;transition:border-color .15s}
.hts-artifact-search:focus{border-color:var(--hts-geo)}
.hts-artifact-search::placeholder{color:var(--hts-text-3)}
.hts-artifact-row-count{font-size:11px;color:var(--hts-text-3);font-weight:500;white-space:nowrap}

/* Body */
.hts-coach-artifact-body{flex:1;overflow-y:auto;padding:24px;scroll-behavior:smooth}

/* ── Click-to-ask: interactive elements in panel ── */
.hts-coach-artifact-body [data-ask]{cursor:pointer;position:relative;transition:background .12s}
.hts-coach-artifact-body [data-ask]:hover{background:var(--hts-geo-soft,rgba(99,102,241,.06))!important}
.hts-coach-artifact-body [data-ask]::after{content:'\2709  Demander au Coach';position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:11px;font-weight:600;color:#fff;background:var(--hts-geo);padding:4px 12px;border-radius:6px;border:none;opacity:0;transition:opacity .15s;pointer-events:none;white-space:nowrap;box-shadow:0 2px 6px rgba(99,102,241,.3)}
.hts-coach-artifact-body [data-ask]:hover::after{opacity:1}
/* Summary items clickable */
.hts-chart-summary-item[data-ask]{cursor:pointer}
.hts-chart-summary-item[data-ask]:hover{background:var(--hts-geo-soft,rgba(99,102,241,.06))}

/* ── Panel Charts ── */
.hts-coach-artifact-body .coach-chart-wrap{max-width:100%;cursor:default;box-shadow:none;border:none;padding:0;background:transparent;margin:0}
.hts-coach-artifact-body .coach-chart-wrap:hover{box-shadow:none}
.hts-coach-artifact-body .coach-chart-wrap .coach-chart-export{display:none}
.hts-coach-artifact-body .coach-chart-wrap::before{display:none}
.hts-coach-artifact-body .coach-chart-title{font-size:16px;margin-bottom:20px;letter-spacing:-.3px}
.hts-coach-artifact-body canvas{width:100%!important;max-height:420px}

/* ════ REPORT DASHBOARD — Agency-premium DS v5.7 ════ */
.hts-report{font-family:var(--hts-font);color:var(--hts-text);padding:0}
.hts-report-header{margin-bottom:var(--hts-sp-5);padding-bottom:var(--hts-sp-4);border-bottom:1px solid var(--hts-border);display:flex;align-items:flex-start;gap:var(--hts-sp-4)}
.hts-report-title{font-size:22px;font-weight:800;color:var(--hts-text);letter-spacing:-.03em;margin:0 0 2px}
.hts-report-subtitle{font-size:11px;color:var(--hts-text-3);font-weight:400}
.hts-report-summary{font-size:13px;line-height:1.65;color:var(--hts-text-2);margin-top:var(--hts-sp-3);padding:16px;background:var(--hts-geo-soft,rgba(99,102,241,.06));border-radius:8px;border-left:3px solid var(--hts-geo)}

/* KPI Grid — connected cells, DS card */
.hts-report-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:1px;margin-bottom:var(--hts-sp-6);border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden;background:var(--hts-border);box-shadow:var(--hts-shadow)}
.hts-kpi{padding:var(--hts-sp-4);background:var(--hts-bg);cursor:pointer;transition:background var(--hts-dur-fast) var(--hts-ease-out)}
.hts-kpi:hover{background:var(--hts-surface)}
.hts-kpi-label{font-size:10px;font-weight:600;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:var(--hts-sp-2)}
.hts-kpi-row{display:flex;align-items:baseline;gap:4px;flex-wrap:wrap}
.hts-kpi-value{font-size:26px;font-weight:800;color:var(--hts-text);letter-spacing:-.04em;line-height:1;font-variant-numeric:tabular-nums}
.hts-kpi-unit{font-size:11px;color:var(--hts-text-3);font-weight:400}
.hts-kpi-delta{font-size:10px;font-weight:700;margin-left:auto;padding:1px 6px;border-radius:var(--hts-radius-xs)}
.hts-kpi-delta.up{color:var(--hts-success);background:var(--hts-success-bg)}
.hts-kpi-delta.down{color:var(--hts-danger);background:var(--hts-danger-bg)}
.hts-kpi-delta.neutral{color:var(--hts-text-3)}

/* Report Sections — bigger titles */
.hts-report-section{margin-bottom:var(--hts-sp-8)}
.hts-report-section-title{font-size:14px;font-weight:700;color:var(--hts-text);margin-bottom:var(--hts-sp-3);letter-spacing:-.02em;display:flex;align-items:center;gap:var(--hts-sp-2)}
.hts-kpi{cursor:pointer;transition:transform .12s,box-shadow .12s}
.hts-kpi:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.08)}

/* Section Commentary (Haiku expert text) */
.hts-report-commentary{font-size:13px;line-height:1.65;color:var(--hts-text-2);margin-bottom:var(--hts-sp-4,16px);padding:14px 18px;background:var(--hts-surface);border-radius:var(--hts-radius-sm,8px);border-left:3px solid var(--hts-geo,#6366f1)}
.hts-report-commentary p.hts-comm-p{margin:0 0 8px;font-size:13px;line-height:1.65}
.hts-report-commentary p.hts-comm-p:last-child{margin-bottom:0}
.hts-report-commentary strong{color:var(--hts-text);font-weight:700}
.hts-report-commentary ul.hts-comm-list{margin:6px 0 8px 0;padding-left:18px;list-style:none}
.hts-report-commentary ul.hts-comm-list li{position:relative;padding-left:14px;margin-bottom:4px;font-size:12.5px;line-height:1.55}
.hts-report-commentary ul.hts-comm-list li::before{content:'';position:absolute;left:0;top:7px;width:5px;height:5px;border-radius:50%;background:var(--hts-geo,#6366f1)}
.hts-kpi-delta-label{display:block;font-size:9px;color:var(--hts-text-3);font-weight:400;margin-top:1px}
.hts-kpi-yoy{display:block;font-size:10px;color:var(--hts-text-3);font-weight:500;margin-top:2px;opacity:.7}

/* Recommendations (priority actions) */
.hts-report-recs{display:flex;flex-direction:column;gap:1px;border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden;background:var(--hts-border);box-shadow:var(--hts-shadow)}
.hts-rec{padding:var(--hts-sp-4);background:var(--hts-bg);cursor:pointer;transition:background var(--hts-dur-fast) var(--hts-ease-out)}
.hts-rec:hover{background:var(--hts-surface)}
.hts-rec-header{display:flex;align-items:center;gap:var(--hts-sp-3)}
.hts-rec-priority{width:24px;height:24px;border-radius:50%;background:var(--hts-gray-800);color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.hts-rec-title{font-size:13px;font-weight:600;color:var(--hts-text);flex:1}
.hts-rec-meta{font-size:10px;color:var(--hts-text-3);white-space:nowrap;display:flex;gap:var(--hts-sp-2);align-items:center}
.hts-rec-detail{font-size:12px;line-height:1.55;color:var(--hts-text-2);padding-left:36px;margin-top:var(--hts-sp-1)}

/* Report Charts — DS card frame */
.hts-report-chart{padding:var(--hts-sp-5);border:1px solid var(--hts-border);border-radius:var(--hts-radius);background:var(--hts-bg);margin-bottom:var(--hts-sp-3);box-shadow:var(--hts-shadow)}
.hts-report-chart canvas{width:100%!important;max-height:280px}

/* Report Tables — DS table */
.hts-report-table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;margin-bottom:4px;border-radius:var(--hts-radius);border:1px solid var(--hts-border);box-shadow:var(--hts-shadow)}
.hts-report-table{width:100%;border-collapse:separate;border-spacing:0;font-size:12px;min-width:480px}
.hts-report-table th{background:var(--hts-surface);color:var(--hts-text-2);font-weight:600;text-align:left;padding:10px var(--hts-sp-3);border-bottom:1px solid var(--hts-border);font-size:10px;text-transform:uppercase;letter-spacing:.4px}
.hts-report-table td{padding:10px var(--hts-sp-3);border-bottom:1px solid var(--hts-border-sub);color:var(--hts-text);font-size:12.5px;line-height:1.4;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hts-report-table tr:last-child td{border-bottom:none}
.hts-report-table tbody tr:nth-child(even) td{background:var(--hts-surface,#fafafa)}
.hts-report-table tr:hover td{background:var(--hts-geo-soft,rgba(99,102,241,.04))}
.hts-report-table tr[data-ask]{cursor:pointer}
.hts-report-table tr[data-ask]:hover td{background:var(--hts-geo-soft)}

/* Insights — connected list with severity */
.hts-report-insights{display:flex;flex-direction:column;gap:1px;border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden;background:var(--hts-border);box-shadow:var(--hts-shadow)}
.hts-insight{display:flex;align-items:flex-start;gap:var(--hts-sp-3);padding:var(--hts-sp-3) var(--hts-sp-4);font-size:12.5px;line-height:1.55;background:var(--hts-bg);cursor:pointer;transition:background var(--hts-dur-fast) var(--hts-ease-out)}
.hts-insight:hover{background:var(--hts-surface)}

/* Diagnostic badges — DS badge style */
.hts-diag-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:var(--hts-radius-pill);font-size:10px;font-weight:600;white-space:nowrap;border:1px solid transparent}
.hts-diag-critical{background:var(--hts-danger-bg);color:var(--hts-danger);border-color:rgba(255,77,106,.15)}
.hts-diag-warn{background:var(--hts-caution-bg);color:#b45309;border-color:rgba(255,149,0,.15)}
.hts-diag-ok{background:var(--hts-success-bg);color:#059669;border-color:rgba(0,210,106,.15)}
.hts-diag-neutral{background:var(--hts-surface);color:var(--hts-text-3)}
.hts-insight-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;margin-top:5px}
.hts-insight.critical .hts-insight-dot{background:var(--hts-danger)}
.hts-insight.high .hts-insight-dot{background:var(--hts-caution)}
.hts-insight.medium .hts-insight-dot{background:var(--hts-geo)}
.hts-insight.low .hts-insight-dot{background:var(--hts-text-3)}
.hts-insight.positive .hts-insight-dot{background:var(--hts-success)}
.hts-insight-text{flex:1;color:var(--hts-text)}

/* Discussion Thread */
.hts-report-thread{margin-top:var(--hts-sp-6);padding-top:var(--hts-sp-5);border-top:1px solid var(--hts-border)}
.hts-report-thread-title{font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:var(--hts-sp-3)}
.hts-report-answer{padding:var(--hts-sp-4);border-radius:var(--hts-radius-sm);background:var(--hts-surface);border:1px solid var(--hts-border);margin-bottom:var(--hts-sp-2)}
.hts-report-answer-q{font-size:11px;font-weight:600;color:var(--hts-geo-text);margin-bottom:var(--hts-sp-2);padding-bottom:var(--hts-sp-2);border-bottom:1px solid var(--hts-border)}
.hts-report-answer-body{font-size:13px;line-height:1.6;color:var(--hts-text)}
.hts-report-answer-body p{margin:0 0 var(--hts-sp-2)}.hts-report-answer-body p:last-child{margin-bottom:0}
.hts-report-answer-body ul,.hts-report-answer-body ol{margin:var(--hts-sp-1) 0 var(--hts-sp-2) var(--hts-sp-4);padding:0}
.hts-report-answer-body li{margin-bottom:3px}
.hts-report-answer-body strong{font-weight:600;color:var(--hts-text)}
.hts-report-answer-body code{font-size:11px;font-family:var(--hts-mono);background:var(--hts-border-sub);padding:1px 4px;border-radius:var(--hts-radius-xs)}

/* Chart summary bar */
.hts-chart-summary{display:flex;gap:0;margin-top:var(--hts-sp-5);border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden;box-shadow:var(--hts-shadow)}
.hts-chart-summary-item{flex:1;padding:var(--hts-sp-3) var(--hts-sp-4);text-align:center;border-right:1px solid var(--hts-border);transition:background var(--hts-dur-fast);cursor:pointer}
.hts-chart-summary-item:last-child{border-right:none}
.hts-chart-summary-item:hover{background:var(--hts-geo-soft)}
.hts-chart-summary-label{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--hts-text-3);margin-bottom:2px}
.hts-chart-summary-value{font-size:18px;font-weight:800;color:var(--hts-text);font-variant-numeric:tabular-nums}

/* ── Panel Tables ── */
.hts-coach-artifact-body table{width:100%;border-collapse:separate;border-spacing:0;margin:0;font-size:13px;border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden}
.hts-coach-artifact-body table thead{background:var(--hts-border-sub,#f8fafc)}
.hts-coach-artifact-body table th{padding:10px 14px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--hts-text-2);text-align:left;border-bottom:2px solid var(--hts-border);white-space:nowrap;cursor:pointer;user-select:none;transition:color .15s}
.hts-coach-artifact-body table th:hover{color:var(--hts-geo)}
.hts-coach-artifact-body table th.hts-sort-asc::after{content:' \2191';color:var(--hts-geo)}
.hts-coach-artifact-body table th.hts-sort-desc::after{content:' \2193';color:var(--hts-geo)}
.hts-coach-artifact-body table td{padding:9px 14px;border-bottom:1px solid var(--hts-border-sub,#f1f5f9);color:var(--hts-text);font-size:13px;transition:background .1s}
.hts-coach-artifact-body table tr:nth-child(even) td{background:rgba(0,0,0,.015)}
.hts-coach-artifact-body table tr:hover td{background:var(--hts-geo-soft,rgba(99,102,241,.04))}
.hts-coach-artifact-body table tr:last-child td{border-bottom:none}
.hts-coach-artifact-body table tr.hts-row-hidden{display:none}

/* ── Panel SEO Plan (DS v5.7 — Apple 2026) ── */
.hts-seo-plan{font-family:var(--hts-font);color:var(--hts-text);border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden;background:var(--hts-bg);box-shadow:var(--hts-shadow);margin-top:12px}
.hts-seo-plan-header{padding:20px 24px;border-bottom:1px solid var(--hts-border);background:var(--hts-surface)}
.hts-seo-plan-title{font-size:18px;font-weight:800;color:var(--hts-text);letter-spacing:-.03em;margin:0 0 4px;display:flex;align-items:center;gap:10px}
.hts-seo-plan-objective{font-size:12px;color:var(--hts-text-2);line-height:1.5;padding:var(--hts-sp-2) var(--hts-sp-3);background:var(--hts-bg);border-radius:var(--hts-radius-sm);border-left:3px solid var(--hts-geo);margin-top:var(--hts-sp-3)}
.hts-seo-plan-phases{padding:var(--hts-sp-4) var(--hts-sp-5);display:flex;flex-direction:column;gap:var(--hts-sp-5)}
.hts-seo-plan-phase{padding-left:var(--hts-sp-4);border-left:2px solid var(--hts-geo)}
.hts-seo-plan-phase:nth-child(1){border-left-color:var(--hts-caution)}
.hts-seo-plan-phase:nth-child(3){border-left-color:var(--hts-success)}
.hts-seo-plan-phase-head{display:flex;align-items:center;gap:var(--hts-sp-2);margin-bottom:var(--hts-sp-3)}
.hts-seo-plan-phase-icon{font-size:16px}
.hts-seo-plan-phase-name{font-size:13px;font-weight:700;color:var(--hts-text);letter-spacing:-.02em}
.hts-seo-plan-phase-time{font-size:10px;font-weight:600;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.3px;margin-left:auto}
.hts-seo-plan-action{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius-sm);padding:var(--hts-sp-3);margin-bottom:var(--hts-sp-2);transition:box-shadow var(--hts-dur-fast)}
.hts-seo-plan-action:hover{box-shadow:var(--hts-shadow)}
.hts-seo-plan-action-head{display:flex;align-items:center;gap:var(--hts-sp-2);margin-bottom:var(--hts-sp-2)}
.hts-seo-plan-action-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.hts-seo-plan-action-dot.critical{background:var(--hts-danger)}
.hts-seo-plan-action-dot.high{background:var(--hts-caution)}
.hts-seo-plan-action-dot.medium{background:var(--hts-geo)}
.hts-seo-plan-action-dot.low{background:var(--hts-text-3)}
.hts-seo-plan-action-title{font-size:12px;font-weight:600;color:var(--hts-text);flex:1;overflow:hidden;text-overflow:ellipsis}
.hts-seo-plan-badge{font-size:9px;padding:2px 8px;border-radius:var(--hts-radius-pill);font-weight:600;white-space:nowrap;border:1px solid transparent}
.hts-seo-plan-badge.critical{background:var(--hts-danger-bg);color:var(--hts-danger);border-color:rgba(255,77,106,.15)}
.hts-seo-plan-badge.high{background:var(--hts-caution-bg);color:#b45309;border-color:rgba(255,149,0,.15)}
.hts-seo-plan-badge.medium{background:var(--hts-geo-soft);color:var(--hts-geo)}
.hts-seo-plan-badge.low{background:var(--hts-surface);color:var(--hts-text-3)}
.hts-seo-plan-action-desc{font-size:12px;color:var(--hts-text-2);line-height:1.5;margin-bottom:var(--hts-sp-2)}
.hts-seo-plan-action-meta{display:flex;flex-wrap:wrap;gap:var(--hts-sp-2);font-size:11px}
.hts-seo-plan-action-meta span{color:var(--hts-text-3)}
.hts-seo-plan-action-meta .value{font-weight:600;color:var(--hts-text-2)}
.hts-seo-plan-action-meta .target{font-weight:600;color:var(--hts-success)}
.hts-seo-plan-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));gap:1px;border-top:1px solid var(--hts-border);background:var(--hts-border);overflow:hidden}
.hts-seo-plan-kpi{text-align:center;padding:var(--hts-sp-3) var(--hts-sp-3);background:var(--hts-surface)}
.hts-seo-plan-kpi-value{font-size:16px;font-weight:800;color:var(--hts-text);font-variant-numeric:tabular-nums}
.hts-seo-plan-kpi-label{font-size:10px;color:var(--hts-text-3);font-weight:500;margin-top:2px}
.hts-seo-plan-cta{padding:var(--hts-sp-3) var(--hts-sp-5);text-align:center;background:var(--hts-bg)}
.hts-seo-plan-cta-btn{display:inline-flex;align-items:center;gap:var(--hts-sp-2);padding:10px 28px;background:var(--hts-geo);color:#fff;border-radius:var(--hts-radius);font-size:13px;font-weight:700;border:none;cursor:pointer;transition:all var(--hts-dur-fast);box-shadow:0 1px 3px rgba(99,102,241,.3)}
.hts-seo-plan-cta-btn:hover{background:var(--hts-geo-text);box-shadow:0 4px 12px rgba(99,102,241,.3);transform:translateY(-1px)}

/* ── Panel Execution Plan ── */
.hts-coach-artifact-body .coach-plan-card{margin:0!important;border-radius:var(--hts-radius)!important}
.hts-coach-artifact-body .coach-plan-step{margin-bottom:4px}

/* Responsive */
@keyframes htsPulse{0%,100%{opacity:1}50%{opacity:.4}}
@media(max-width:768px){
	.hts-coach-topbar{padding:8px 12px}
	.hts-coach-topbar-label{display:none}
	.coach-messages{padding:16px 12px}
	.coach-msg{max-width:95%}
	.coach-input-area{padding:10px 12px}
	.coach-input{min-height:44px;font-size:15px;max-height:160px}
	.coach-suggestions{padding:0 12px 12px}
	.coach-pill{padding:6px 10px;font-size:12px}
	.coach-sidebar{width:100%!important}
	.coach-history.open{position:absolute;z-index:11;top:0;left:0;bottom:0;width:85%!important;min-width:0!important;max-width:300px;box-shadow:8px 0 32px rgba(0,0,0,.15)}
}
</style>

<!-- ═══ HTML ═══ -->
<?php
// Freemium counter
$_coach_is_free = class_exists( 'HTS_Subscription' ) && ! HTS_Subscription::can( 'coach_unlimited' );
$_coach_can_report = ! class_exists( 'HTS_Subscription' ) || HTS_Subscription::can( 'coach_reports' );
$_coach_usage = array( 'used' => 0, 'limit' => 5 );
if ( $_coach_is_free && class_exists( 'HTS_Coach' ) && method_exists( 'HTS_Coach', 'get_freemium_usage' ) ) {
    $_coach_usage = HTS_Coach::get_freemium_usage();
}
$_coach_remaining = max( 0, ( $_coach_usage['limit'] ?? 5 ) - ( $_coach_usage['used'] ?? 0 ) );
$_coach_upgrade_url = rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' ) . '/user/pricing/plans';
?>
<div class="coach-wrap">
<?php if ( $_coach_is_free ) : ?>
<div style="padding:8px 16px;background:<?php echo $_coach_remaining > 0 ? 'linear-gradient(90deg,#eef2ff,#faf5ff)' : '#fef2f2'; ?>;border-bottom:1px solid <?php echo $_coach_remaining > 0 ? '#c7d2fe' : '#fecaca'; ?>;display:flex;align-items:center;justify-content:center;gap:12px;flex-shrink:0;z-index:10">
    <?php if ( $_coach_remaining > 0 ) : ?>
        <span style="font-size:12px;color:#4338ca;font-weight:600"><?php echo (int) $_coach_remaining; ?>/<?php echo (int) $_coach_usage['limit']; ?> questions restantes ce mois</span>
        <a href="<?php echo esc_url( $_coach_upgrade_url ); ?>" target="_blank" style="font-size:11px;color:#6366f1;font-weight:700;text-decoration:none">Passer à Pro pour un accès illimité →</a>
    <?php else : ?>
        <span style="font-size:12px;color:#991b1b;font-weight:600">Quota mensuel atteint (<?php echo (int) $_coach_usage['limit']; ?>/<?php echo (int) $_coach_usage['limit']; ?>)</span>
        <a href="<?php echo esc_url( $_coach_upgrade_url ); ?>" target="_blank" style="font-size:11px;padding:4px 12px;border-radius:6px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-weight:700;text-decoration:none">Débloquer le Coach illimité</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- TOP BAR -->
<div class="hts-coach-topbar">
	<div style="display:flex;align-items:center;gap:12px">
		<button type="button" onclick="htsCToggleHistory()" class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px;padding:5px 8px" title="Historique des conversations" aria-label="Historique des conversations"><?php echo HTS_DS::icon( 'message-square', 16, 'var(--hts-text-2)' ); ?></button>
		<a href="<?php echo esc_url( $base_url ); ?>" style="display:flex;align-items:center;gap:4px;font-size:12px;font-weight:600;color:var(--hts-text-2);text-decoration:none">
			<?php echo HTS_DS::icon( 'chevron-left', 14, 'var(--hts-text-3)' ); ?> Tableau de bord
		</a>
		<div style="width:1px;height:16px;background:var(--hts-border)"></div>
		<div style="display:flex;align-items:center;gap:8px">
			<div style="width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,var(--hts-accent),var(--hts-geo));display:flex;align-items:center;justify-content:center"><?php echo HTS_DS::icon( 'zap', 14, '#fff' ); ?></div>
			<span style="font-size:15px;font-weight:700;color:var(--hts-text)">Coach SEO</span>
			<?php if ( ! $has_key ) echo HTS_DS::badge( 'Clé manquante', 'danger' ); ?>
		</div>
	</div>
	<div style="display:flex;align-items:center;gap:12px">
		<?php /* ── Jauge tokens masquée — consommation gérée en back, pas visible client ──
		<div style="display:flex;align-items:center;gap:8px">
			<span style="font-size:10px;font-weight:600;color:var(--hts-text-3)"><?php echo number_format( $coach_total ); ?> tokens</span>
			<div style="width:80px;height:4px;border-radius:2px;background:var(--hts-border-sub);overflow:hidden"><div style="width:<?php echo $coach_pct; ?>%;height:100%;border-radius:2px;background:<?php echo $coach_pct > 80 ? 'var(--hts-danger)' : 'var(--hts-success)'; ?>"></div></div>
			<span style="font-size:10px;font-weight:600;color:<?php echo $coach_pct > 80 ? 'var(--hts-danger)' : 'var(--hts-success)'; ?>"><?php echo $coach_pct; ?>%</span>
		</div>
		*/ ?>
		<?php if ( isset( $_GET['debug'] ) && $_GET['debug'] === '1' ) : ?>
		<button type="button" class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px" onclick="coachToggleAnalytics()" id="btnCoachAnalytics"><?php echo HTS_DS::icon( 'bar-chart-2', 12, 'var(--hts-text-2)' ); ?> <span class="hts-coach-topbar-label">Stats</span></button>
		<?php endif; ?>
		<?php if ( current_user_can( 'manage_options' ) ) : ?>
		<div style="position:relative;display:inline-block" id="hts-report-dropdown-wrap">
		<button type="button" class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px" onclick="htsToggleReportDD(event)"><?php echo HTS_DS::icon( 'file-text', 12, 'var(--hts-text-2)' ); ?> <span class="hts-coach-topbar-label">Rapport</span> <?php echo HTS_DS::icon( 'chevron-down', 10, 'var(--hts-text-3)' ); ?></button>
		<div id="hts-report-dropdown" style="position:fixed;background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:12px;box-shadow:0 10px 25px rgba(0,0,0,.15);min-width:240px;z-index:999999;padding:6px 0">
			<div style="padding:6px 12px;font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.05em">Rapports</div>
			<?php $_pro_lock = ! $_coach_can_report ? '<span style="margin-left:auto;padding:1px 6px;border-radius:4px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:9px;font-weight:700">PRO</span>' : ''; ?>
			<button onclick="htsGenerateReport('full','Diagnostic SEO Complet');document.getElementById('hts-report-dropdown').classList.remove('hts-dd-open')" style="display:flex;align-items:center;gap:8px;width:100%;padding:8px 12px;border:none;background:none;font-size:12px;font-weight:500;color:var(--hts-text);cursor:pointer;font-family:var(--hts-font);text-align:left" onmouseover="this.style.background='var(--hts-surface)'" onmouseout="this.style.background='none'"><?php echo HTS_DS::icon( 'activity', 14, 'var(--hts-geo)' ); ?> Diagnostic complet<?php echo $_pro_lock; ?></button>
			<button onclick="htsGenerateReport('linking','Rapport Maillage Interne');document.getElementById('hts-report-dropdown').classList.remove('hts-dd-open')" style="display:flex;align-items:center;gap:8px;width:100%;padding:8px 12px;border:none;background:none;font-size:12px;font-weight:500;color:var(--hts-text);cursor:pointer;font-family:var(--hts-font);text-align:left" onmouseover="this.style.background='var(--hts-surface)'" onmouseout="this.style.background='none'"><?php echo HTS_DS::icon( 'link', 14, 'var(--hts-text-2)' ); ?> Maillage interne<?php echo $_pro_lock; ?></button>
			<button onclick="htsGenerateReport('content','Rapport Contenu & IA');document.getElementById('hts-report-dropdown').classList.remove('hts-dd-open')" style="display:flex;align-items:center;gap:8px;width:100%;padding:8px 12px;border:none;background:none;font-size:12px;font-weight:500;color:var(--hts-text);cursor:pointer;font-family:var(--hts-font);text-align:left" onmouseover="this.style.background='var(--hts-surface)'" onmouseout="this.style.background='none'"><?php echo HTS_DS::icon( 'file-text', 14, 'var(--hts-text-2)' ); ?> Contenu & IA<?php echo $_pro_lock; ?></button>
			<button onclick="htsGenerateReport('performance','Rapport Performance SEO');document.getElementById('hts-report-dropdown').classList.remove('hts-dd-open')" style="display:flex;align-items:center;gap:8px;width:100%;padding:8px 12px;border:none;background:none;font-size:12px;font-weight:500;color:var(--hts-text);cursor:pointer;font-family:var(--hts-font);text-align:left" onmouseover="this.style.background='var(--hts-surface)'" onmouseout="this.style.background='none'"><?php echo HTS_DS::icon( 'trending-up', 14, 'var(--hts-text-2)' ); ?> Performance GSC<?php echo $_pro_lock; ?></button>
			<button onclick="htsGenerateReport('audit','Audit Technique');document.getElementById('hts-report-dropdown').classList.remove('hts-dd-open')" style="display:flex;align-items:center;gap:8px;width:100%;padding:8px 12px;border:none;background:none;font-size:12px;font-weight:500;color:var(--hts-text);cursor:pointer;font-family:var(--hts-font);text-align:left" onmouseover="this.style.background='var(--hts-surface)'" onmouseout="this.style.background='none'"><?php echo HTS_DS::icon( 'shield', 14, 'var(--hts-text-2)' ); ?> Audit technique<?php echo $_pro_lock; ?></button>
		</div>
		</div>
		<?php endif; ?>
		<button type="button" class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px;padding:5px 8px" onclick="htsToggleTheme()" title="Mode sombre"><svg class="hts-icon-sun" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg><svg class="hts-icon-moon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg></button>
		<button type="button" class="hts-ds-btn hts-ds-btn--primary hts-ds-btn--sm" style="font-size:11px" onclick="coachNewSession()"><?php echo HTS_DS::icon( 'plus', 12, '#fff' ); ?> Nouveau</button>
	</div>
<!-- NONCE HOLDER (sessions dropdown kept hidden for data-nonce attribute) -->
<div class="hts-sessions-dropdown" id="htsCSessionsDropdown" data-nonce="<?php echo esc_attr( $nonce ); ?>" style="display:none!important">
	<div class="hts-sessions-dropdown-header">
		<span><?php echo HTS_DS::icon( 'clock', 14, 'var(--hts-text-2)' ); ?> Conversations</span>
		<button type="button" onclick="coachNewSession();htsCCloseSessions()" class="hts-ds-btn hts-ds-btn--primary hts-ds-btn--sm" style="font-size:10px"><?php echo HTS_DS::icon( 'plus', 10, '#fff' ); ?> Nouvelle</button>
	</div>
	<div class="hts-sessions-dropdown-body" id="htsCSessionsBody"></div>
</div>
</div>

<!-- LAYOUT (chat only) -->
<div class="coach-layout">
<!-- HISTORY SIDEBAR (left) -->
<div class="coach-history" id="coachHistoryPanel">
	<div class="coach-history-header">
		<span>Conversations</span>
		<button type="button" class="coach-history-new" onclick="coachNewSession();htsCCloseHistory()"><?php echo HTS_DS::icon( 'plus', 10, 'currentColor' ); ?> Nouveau</button>
	</div>
	<div class="coach-history-body" id="coachHistoryBody">
		<div style="padding:20px;text-align:center;color:var(--hts-text-3);font-size:11px;">Chargement...</div>
	</div>
</div>
	<div class="coach-chat">
		<div id="coachBackToCurrentBar" style="display:none;padding:8px 14px;background:var(--hts-geo-soft);border-bottom:1px solid var(--hts-border);align-items:center;gap:8px;justify-content:space-between;flex-shrink:0;">
			<span style="font-size:11px;color:var(--hts-geo);font-weight:600;"><?php echo HTS_DS::icon( 'folder-open', 13, 'var(--hts-geo)' ); ?> Vous consultez une conversation passée</span>
			<button type="button" onclick="coachBackToCurrent()" class="hts-ds-btn hts-ds-btn--primary hts-ds-btn--sm" style="font-size:11px"><?php echo HTS_DS::icon( 'arrow-left', 11, '#fff' ); ?> Revenir</button>
		</div>
		<!-- SSR Debug: <?php echo wp_json_encode( $ssr_debug ); ?> -->
		<div class="coach-messages" id="coachMessages">
			<?php if ( ! empty( $ssr_messages ) ) : ?>
				<?php foreach ( $ssr_messages as $idx => $msg ) :
					$role = esc_attr( $msg['role'] );
					$content = $msg['content'];
					if ( $role === 'assistant' && class_exists( 'HTS_Coach' ) ) {
						$content = HTS_Coach::clean_response( $content );
					}
				?>
				<div class="coach-msg <?php echo esc_attr( $role ); ?>">
					<div class="coach-msg-avatar<?php echo $role === 'user' ? ' user' : ''; ?>"><?php
						if ( $role === 'assistant' ) {
							echo HTS_DS::icon( 'zap', 14, '#fff' );
						} elseif ( $site_icon_url ) {
							echo '<img src="' . esc_url( $site_icon_url ) . '" alt="" width="28" height="28">';
						} else {
							echo HTS_DS::icon( 'user', 14, 'var(--hts-text-3)' );
						}
					?></div>
					<div class="coach-msg-bubble"><?php echo esc_html( $content ); ?></div>
				</div>
				<?php if ( isset( $ssr_plans[ $idx ] ) ) : ?><div class="coach-ssr-plan" data-plan="<?php echo esc_attr( wp_json_encode( $ssr_plans[ $idx ] ) ); ?>"></div><?php endif; ?>
				<?php if ( isset( $ssr_actions[ $idx ] ) ) : ?><div class="coach-ssr-actions" data-actions="<?php echo esc_attr( wp_json_encode( $ssr_actions[ $idx ] ) ); ?>"></div><?php endif; ?>
				<?php if ( isset( $ssr_seo_plans[ $idx ] ) ) : ?><div class="coach-ssr-seo-plan" data-seo-plan="<?php echo esc_attr( wp_json_encode( $ssr_seo_plans[ $idx ] ) ); ?>"></div><?php endif; ?>
				<?php if ( isset( $ssr_skipped[ $idx ] ) ) : ?><div class="coach-ssr-skipped" data-skipped="<?php echo esc_attr( wp_json_encode( $ssr_skipped[ $idx ] ) ); ?>"></div><?php endif; ?>
				<?php endforeach; ?>
			<?php else : ?>
			<div class="coach-msg assistant" id="coachWelcomeMsg">
				<div class="coach-msg-avatar"><?php echo HTS_DS::icon( 'zap', 14, '#fff' ); ?></div>
				<div class="coach-msg-bubble" id="coachWelcomeBubble"><span class="coach-welcome-loading">Chargement...</span></div>
			</div>
			<?php endif; ?>
		</div>
		<!-- Suggestions supprimées v2.6.3 — les rapports sont dans le dropdown header, les questions dans le welcome -->
		<div class="coach-input-area">
			<?php if ( ! $has_key ) : ?>
			<div style="padding:14px 18px;background:#fffbeb;border:1px solid #fcd34d;border-radius:var(--hts-radius);margin-bottom:12px;font-size:13px;color:#92400e;display:flex;align-items:center;gap:8px">
				<?php echo HTS_DS::icon( 'alert-triangle', 14, '#92400e' ); ?>
				<span><strong>Clé API requise</strong> — <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-api' ) ); ?>" style="color:var(--hts-geo);font-weight:700;">Configurer</a></span>
			</div>
			<?php endif; ?>
			<div class="coach-input-row">
				<textarea class="coach-input" id="coachInput" rows="1" placeholder="Posez votre question au Coach SEO..."
					onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();coachSend()}"
					oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,200)+'px'"
					<?php echo $has_key ? '' : 'disabled'; ?>></textarea>
				<button type="button" class="coach-send-btn" id="coachSendBtn" onclick="coachSend()" <?php echo $has_key ? '' : 'disabled'; ?>><?php echo HTS_DS::icon( 'send', 18, '#fff' ); ?></button>
			</div>
		</div>
	</div>
<!-- SPLIT PANEL (right side of layout) -->
<div class="hts-coach-artifact" id="coachArtifactPanel">
	<div class="hts-coach-artifact-resizer" id="coachArtifactResizer"></div>
	<div class="hts-coach-artifact-header">
		<div class="hts-artifact-header-left">
			<?php echo HTS_DS::icon( 'layout', 14, 'var(--hts-geo)' ); ?>
			<span id="coachArtifactTitle">Visualisation</span>
			<span class="hts-artifact-type-badge" id="coachArtifactBadge" data-type="chart"></span>
		</div>
		<div class="hts-artifact-header-actions">
			<button type="button" class="hts-artifact-action-btn" id="coachArtifactExport" style="display:none" title="Exporter">
				<?php echo HTS_DS::icon( 'download', 12, 'currentColor' ); ?> <span>Exporter</span>
			</button>
			<button type="button" onclick="coachCloseArtifact()" class="hts-artifact-action-btn">
				<?php echo HTS_DS::icon( 'x', 12, 'currentColor' ); ?> Fermer
			</button>
		</div>
	</div>
	<div class="hts-artifact-toolbar" id="coachArtifactToolbar">
		<input type="text" class="hts-artifact-search" id="coachArtifactSearch" placeholder="Filtrer les lignes...">
		<span class="hts-artifact-row-count" id="coachArtifactRowCount"></span>
	</div>
	<div class="hts-coach-artifact-body" id="coachArtifactBody"></div>
</div>
</div><!-- /layout -->

<!-- TOAST -->
<div id="coachToast" style="display:none;position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(20px);z-index:100001;min-width:340px;max-width:480px;background:var(--hts-bg);border-radius:var(--hts-radius);box-shadow:0 12px 40px rgba(0,0,0,.18);border-left:4px solid var(--hts-success);padding:14px 18px;transition:opacity .3s,transform .3s;opacity:0;">
	<div style="display:flex;align-items:flex-start;gap:10px;">
		<span id="coachToastIcon" style="font-size:18px;"><?php echo HTS_DS::icon( 'check-circle', 18, 'var(--hts-success)' ); ?></span>
		<div style="flex:1;"><div id="coachToastTitle" style="font-size:13px;font-weight:700;color:var(--hts-text);"></div><div id="coachToastMsg" style="font-size:12px;color:var(--hts-text-2);margin-top:3px;"></div><a id="coachToastLink" href="#" target="_blank" style="display:none;font-size:11px;color:var(--hts-geo);font-weight:600;margin-top:4px;text-decoration:none;"><?php echo HTS_DS::icon( 'inbox', 11, 'var(--hts-geo)' ); ?> Voir dans l&#x27;Inbox</a></div>
		<button type="button" onclick="coachHideToast()" style="border:none;background:transparent;cursor:pointer;color:var(--hts-text-3);padding:0;"><?php echo HTS_DS::icon( 'x', 14, 'var(--hts-text-3)' ); ?></button>
	</div>
</div>

<!-- SIDEBAR DRAWER (outside layout) -->
<div class="coach-sidebar" id="coachSidebar">
	<div style="display:flex;justify-content:flex-end;padding:0 0 8px;" id="coachSidebarCloseRow">
		<button type="button" onclick="coachCloseSidebar()" style="background:none;border:none;cursor:pointer;padding:4px;color:var(--hts-text-3);"><?php echo HTS_DS::icon( 'x', 16, 'var(--hts-text-3)' ); ?></button>
	</div>
	<div class="coach-sidebar-section"><div class="coach-sidebar-title">Mes analyses</div><div id="coachArtifactsGallery" style="font-size:12px;color:var(--hts-text-3);">Chargement...</div></div>
	<div class="coach-sidebar-section">
		<div class="coach-sidebar-title">Scores du site</div>
		<div class="coach-stat-card"><div class="coach-stat-label">Score SEO global</div><div class="coach-stat-value" id="coachScoreGlobal">&mdash;</div><div class="coach-stat-sub">Moyenne de tous vos articles</div></div>
		<div class="coach-stat-card"><div class="coach-stat-label">Score GEO (visibilité IA)</div><div class="coach-stat-value" id="coachScoreGeo">&mdash;</div><div class="coach-stat-sub">Prêt pour ChatGPT, Perplexity...</div></div>
		<div class="coach-stat-card"><div class="coach-stat-label">Actions en attente</div><div class="coach-stat-value" id="coachPending">&mdash;</div><div class="coach-stat-sub">Propositions dans votre Inbox</div></div>
	</div>
	<div class="coach-sidebar-section"><div class="coach-sidebar-title">Pages à améliorer</div><div id="coachWorstPages" style="font-size:12px;color:var(--hts-text-2);">Chargement...</div></div>
	<div class="coach-sidebar-section">
		<div class="coach-sidebar-title">Utilisation ce mois</div>
		<div class="coach-stat-card">
			<div style="display:flex;justify-content:space-between;align-items:center;"><span class="coach-stat-label">Tokens total</span><span id="coachTokensUsed" style="font-size:13px;font-weight:700;color:var(--hts-text);">&mdash;</span></div>
			<div class="coach-usage-bar"><div class="coach-usage-fill" id="coachUsageBar" style="width:0%;background:var(--hts-geo);"></div></div>
			<div style="display:flex;justify-content:space-between;margin-top:4px;"><span id="coachRequests" style="font-size:10px;color:var(--hts-text-3);">&mdash; requêtes</span><span id="coachBudgetLabel" style="font-size:10px;color:var(--hts-text-3);">&mdash; budget</span></div>
		</div>
		<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-top:6px;">
			<div class="coach-stat-card" style="padding:8px 10px;"><div style="display:flex;align-items:center;gap:4px;"><?php echo HTS_DS::dot( 'ok', 7 ); ?><span class="coach-stat-label" style="font-size:9px;">4o-mini</span></div><div id="coachTokensT1" style="font-size:14px;font-weight:800;color:var(--hts-success);margin-top:2px;">0</div><div id="coachReqT1" style="font-size:9px;color:var(--hts-text-3);">0 req.</div></div>
			<div class="coach-stat-card" style="padding:8px 10px;"><div style="display:flex;align-items:center;gap:4px;"><?php echo HTS_DS::dot( 'info', 7 ); ?><span class="coach-stat-label" style="font-size:9px;">4.1-mini</span></div><div id="coachTokensT2" style="font-size:14px;font-weight:800;color:var(--hts-info,#0ea5e9);margin-top:2px;">0</div><div id="coachReqT2" style="font-size:9px;color:var(--hts-text-3);">0 req.</div></div>
			<div class="coach-stat-card" style="padding:8px 10px;"><div style="display:flex;align-items:center;gap:4px;"><?php echo HTS_DS::dot( 'warn', 7 ); ?><span class="coach-stat-label" style="font-size:9px;">Haiku</span></div><div id="coachTokensT3" style="font-size:14px;font-weight:800;color:var(--hts-geo);margin-top:2px;">0</div><div id="coachReqT3" style="font-size:9px;color:var(--hts-text-3);">0 req.</div></div>
		</div>
	</div>
	<div class="coach-sidebar-section">
		<div class="coach-sidebar-title">Search Console</div>
		<?php if ( $gsc_connected ) : ?>
			<?php
				$gsc_obj = new HTS_GSC_Connect();
				$gsc_m = get_option( 'hts_gsc_meta', array() );
				$snaps = get_option( 'hts_gsc_snapshots', array() );
				$snap_count = is_array( $snaps ) ? count( $snaps ) : 0;
				$last_snap = $snap_count > 0 ? end( $snaps ) : null;
			?>
			<div class="coach-stat-card">
				<div style="font-size:12px;color:var(--hts-success);font-weight:600;margin-bottom:6px;"><?php echo HTS_DS::icon( 'check-circle', 12, 'var(--hts-success)' ); ?> Connectée en direct</div>
				<?php if ( ! empty( $gsc_m['last_fetch'] ) ) : ?><div style="font-size:10px;color:var(--hts-text-3);">Dernière sync : <?php echo esc_html( wp_date( 'j M H:i', strtotime( $gsc_m['last_fetch'] ) ) ); ?></div><?php endif; ?>
				<div style="font-size:10px;color:var(--hts-text-3);margin-top:2px;"><?php echo $snap_count; ?> snapshots<?php if ( $last_snap ) echo ' (jusqu\'au ' . esc_html( $last_snap['date'] ?? '' ) . ')'; ?></div>
				<button type="button" onclick="htsCGscSync(this)" class="hts-ds-btn hts-ds-btn--sm" style="font-size:10px;margin-top:6px;width:100%"><?php echo HTS_DS::icon( 'refresh-cw', 11, 'var(--hts-text-2)' ); ?> Resync GSC (30j + snapshots 90j)</button>
			</div>
		<?php elseif ( $has_csv ) : ?>
			<div class="coach-stat-card">
				<div style="font-size:12px;color:var(--hts-success);font-weight:600;margin-bottom:4px;"><?php echo HTS_DS::icon( 'check-circle', 12, 'var(--hts-success)' ); ?> Données importées</div>
				<?php if ( ! empty( $gsc_queries ) ) : ?><div style="font-size:11px;color:var(--hts-text-2);"><?php echo count( $gsc_queries ); ?> requêtes</div><?php endif; ?>
				<?php if ( ! empty( $gsc_pages ) ) : ?><div style="font-size:11px;color:var(--hts-text-2);"><?php echo count( $gsc_pages ); ?> pages</div><?php endif; ?>
				<?php if ( ! empty( $gsc_meta['date'] ) ) : ?><div style="font-size:10px;color:var(--hts-text-3);margin-top:4px;">Importé le <?php echo esc_html( wp_date( 'j M Y H:i', strtotime( $gsc_meta['date'] ) ) ); ?></div><?php endif; ?>
				<div style="margin-top:6px;display:flex;gap:8px;">
					<label class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px;cursor:pointer;"><?php echo HTS_DS::icon( 'upload', 11, 'var(--hts-text-2)' ); ?> Ajouter<input type="file" accept=".csv,.tsv" onchange="coachUploadGsc(this)" style="display:none;"></label>
					<button type="button" onclick="coachDeleteGsc()" style="font-size:11px;color:var(--hts-danger);background:none;border:none;cursor:pointer;padding:0;text-decoration:underline;">Tout supprimer</button>
				</div>
			</div>
		<?php else : ?>
			<div class="coach-stat-card">
				<div style="font-size:12px;color:var(--hts-text-2);margin-bottom:6px;">Importez vos données GSC pour des conseils plus précis.</div>
				<label class="hts-ds-btn hts-ds-btn--primary hts-ds-btn--sm" style="font-size:11px;cursor:pointer;"><?php echo HTS_DS::icon( 'upload', 11, '#fff' ); ?> Importer un CSV<input type="file" accept=".csv,.tsv" onchange="coachUploadGsc(this)" style="display:none;"></label>
				<div style="font-size:10px;color:var(--hts-text-3);margin-top:6px;"><a href="https://search.google.com/search-console" target="_blank" style="color:var(--hts-geo);">Search Console</a> &rarr; Performances &rarr; Exporter</div>
			</div>
		<?php endif; ?>
	</div>
	<div class="coach-sidebar-section">
		<div class="coach-sidebar-title" style="display:flex;align-items:center;justify-content:space-between;"><span>Mémoire du Coach</span><span id="coachMemoryTotal" style="font-size:10px;color:var(--hts-text-2);font-weight:400;">&mdash;</span></div>
		<div class="coach-stat-card coach-memory-section" id="coachProfileSection">
			<div class="coach-memory-header" onclick="coachToggleSection('Profile')"><span><?php echo HTS_DS::icon( 'building', 13, 'var(--hts-text-2)' ); ?> Profil du site</span><span class="coach-memory-chevron" id="coachChevronProfile">&#x203A;</span></div>
			<div class="coach-memory-body" id="coachBodyProfile" style="display:none;"><div id="coachSiteProfile" style="font-size:11px;color:var(--hts-text-2);">Chargement...</div></div>
		</div>
		<div class="coach-stat-card coach-memory-section" style="margin-top:6px;">
			<div class="coach-memory-header" onclick="coachToggleSection('Facts')"><span><?php echo HTS_DS::icon( 'brain', 13, 'var(--hts-text-2)' ); ?> Faits mémorisés</span><div style="display:flex;align-items:center;gap:6px;"><span id="coachMemoryCount" style="font-size:10px;color:var(--hts-text-2);">&mdash;</span><span class="coach-memory-chevron" id="coachChevronFacts">&#x25BE;</span></div></div>
			<div class="coach-memory-body" id="coachBodyFacts">
				<div id="coachMemoryFacts" style="font-size:11px;color:var(--hts-text-2);max-height:250px;overflow-y:auto;">Chargement...</div>
				<button type="button" onclick="coachAddFactForm()" id="coachAddFactBtn" style="width:100%;margin-top:8px;padding:6px;font-size:11px;font-weight:600;border:1px dashed var(--hts-border);border-radius:6px;background:var(--hts-bg);color:var(--hts-geo);cursor:pointer;"><?php echo HTS_DS::icon( 'plus', 11, 'var(--hts-geo)' ); ?> Ajouter un fait</button>
				<div id="coachAddFactFormWrap" style="display:none;margin-top:8px;padding:10px;border:1px solid var(--hts-border);border-radius:8px;background:var(--hts-bg);">
					<input type="text" id="coachNewFactContent" placeholder="Ex: Le site cible les professionnels de santé" style="width:100%;padding:6px 8px;border:1px solid var(--hts-border);border-radius:4px;font-size:11px;margin-bottom:6px;box-sizing:border-box;">
					<div style="display:flex;gap:4px;margin-bottom:6px;">
						<select id="coachNewFactArea" style="flex:1;padding:4px;border:1px solid var(--hts-border);border-radius:4px;font-size:10px;"><option value="general">Général</option><option value="seo">SEO</option><option value="business">Business</option><option value="content">Contenu</option><option value="technical">Technique</option><option value="preferences">Préférences</option></select>
						<input type="text" id="coachNewFactCategory" placeholder="Catégorie (optionnel)" style="flex:1;padding:4px 6px;border:1px solid var(--hts-border);border-radius:4px;font-size:10px;">
					</div>
					<div style="display:flex;gap:4px;">
						<button type="button" onclick="coachSaveFact()" class="hts-ds-btn hts-ds-btn--primary hts-ds-btn--sm" style="flex:1;font-size:11px;">Enregistrer</button>
						<button type="button" onclick="document.getElementById('coachAddFactFormWrap').style.display='none'" class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px;">Annuler</button>
					</div>
				</div>
			</div>
		</div>
		<div class="coach-stat-card coach-memory-section" style="margin-top:6px;">
			<div class="coach-memory-header" onclick="coachToggleSection('Sessions')"><span><?php echo HTS_DS::icon( 'list', 13, 'var(--hts-text-2)' ); ?> Sessions</span><div style="display:flex;align-items:center;gap:6px;"><span id="coachSessionCount" style="font-size:10px;color:var(--hts-text-2);">&mdash;</span><span class="coach-memory-chevron" id="coachChevronSessions">&#x203A;</span></div></div>
			<div class="coach-memory-body" id="coachBodySessions" style="display:none;"><div id="coachSessionsList" style="font-size:11px;color:var(--hts-text-2);max-height:200px;overflow-y:auto;">Chargement...</div></div>
		</div>
		<button type="button" onclick="coachClearHistory()" style="width:100%;margin-top:8px;padding:8px;font-size:11px;font-weight:600;border:1px solid var(--hts-border);border-radius:6px;background:var(--hts-bg);color:var(--hts-text-2);cursor:pointer;"><?php echo HTS_DS::icon( 'trash-2', 11, 'var(--hts-text-3)' ); ?> Effacer l&#x27;historique</button>
	</div>
</div>

<!-- OVERLAY -->
<div class="coach-overlay" id="coachOverlay" onclick="coachCloseSidebar()"></div>

<!-- ANALYTICS PANEL -->
<div id="coachAnalyticsPanel" style="display:none;position:absolute;top:0;left:0;right:0;bottom:0;z-index:100;background:var(--hts-bg);overflow-y:auto;padding:24px;">
	<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
		<h2 style="margin:0;font-size:18px;font-weight:700;color:var(--hts-text);display:flex;align-items:center;gap:8px"><?php echo HTS_DS::icon( 'bar-chart-2', 18, 'var(--hts-geo)' ); ?> Analytics Coach SEO</h2>
		<div style="display:flex;gap:8px;align-items:center;">
			<select id="coachAnalyticsPeriod" onchange="loadCoachAnalytics()" style="padding:6px 12px;border:1px solid var(--hts-border);border-radius:8px;font-size:12px;background:var(--hts-bg);"><option value="7d">7 jours</option><option value="30d" selected>30 jours</option><option value="90d">90 jours</option><option value="all">Tout</option></select>
			<button type="button" onclick="coachToggleAnalytics()" class="hts-ds-btn hts-ds-btn--sm" style="font-size:12px;"><?php echo HTS_DS::icon( 'x', 12, 'var(--hts-text-2)' ); ?> Fermer</button>
		</div>
	</div>
	<div id="coachAnalyticsContent" style="font-size:13px;color:var(--hts-text);"><p style="color:var(--hts-text-3);text-align:center;padding:40px;">Chargement des analytics...</p></div>
</div>

</div><!-- /wrap -->

<script>
window._htsCoachCanReport = <?php echo $_coach_can_report ? 'true' : 'false'; ?>;
/* Rapport direct 100% PHP (0 token LLM) */
function htsGenerateReport(type, label) {
	if (typeof window._htsCoachCanReport !== 'undefined' && !window._htsCoachCanReport) {
		var ov=document.createElement('div');ov.id='hts-locked-overlay';
		ov.style.cssText='position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center';
		ov.innerHTML='<div style="background:#fff;border-radius:20px;padding:40px;max-width:420px;width:90%;text-align:center;box-shadow:0 8px 40px rgba(0,0,0,.15)">'
			+'<div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;margin:0 auto 16px"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg></div>'
			+'<div style="font-size:18px;font-weight:700;margin-bottom:8px">Analysez votre site en d\u00e9tail</div>'
			+'<div style="font-size:14px;color:#64748b;line-height:1.6;margin-bottom:20px">Les rapports automatiques analysent votre maillage, contenu, performance et technique. Identifiez exactement ce qui freine votre r\u00e9f\u00e9rencement.</div>'
			+'<a href="https://hacktheseo.com/pricing" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;text-decoration:none">D\u00e9bloquer \u2014 99\u20ac/mois</a>'
			+'<div style="margin-top:8px;font-size:11px;color:#94a3b8">Plan Pro \u00b7 5 rapports \u00b7 Coach SEO illimit\u00e9</div>'
			+'<div style="margin-top:12px"><button onclick="this.closest(\'#hts-locked-overlay\').remove()" style="border:none;background:none;color:#94a3b8;font-size:13px;cursor:pointer">Fermer</button></div>'
			+'</div>';
		document.body.appendChild(ov);
		ov.addEventListener('click',function(e){if(e.target===ov)ov.remove()});
		document.getElementById('hts-report-dropdown').classList.remove('hts-dd-open');
		return;
	}
	var panel = document.getElementById('coachArtifactPanel');
	var abody = document.getElementById('coachArtifactBody');
	var titleEl = document.getElementById('coachArtifactTitle');
	var badgeEl = document.getElementById('coachArtifactBadge');
	if (panel && abody) {
		panel.classList.add('hts-artifact-open'); panel.style.display = 'flex';
		if (titleEl) titleEl.textContent = label || 'Rapport en cours...';
		if (badgeEl) { badgeEl.setAttribute('data-type','report'); badgeEl.textContent = 'RAPPORT'; badgeEl.style.display = 'inline'; }
		abody.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:200px;gap:16px"><div style="width:32px;height:32px;border:3px solid var(--hts-border);border-top-color:var(--hts-geo);border-radius:50%;animation:hts-spin .6s linear infinite"></div><div style="font-size:13px;color:var(--hts-text-2);font-weight:500">Calcul du rapport...</div></div>';
	}
	var sessNonce = document.getElementById('htsCSessionsDropdown') ? document.getElementById('htsCSessionsDropdown').getAttribute('data-nonce') : '';
	fetch(ajaxurl, {
		method: 'POST',
		headers: {'Content-Type':'application/x-www-form-urlencoded'},
		body: 'action=hts_coach_generate_report_direct&nonce=' + encodeURIComponent(sessNonce) + '&report_type=' + encodeURIComponent(type) + '&period_days=30'
	}).then(function(r){return r.json()}).then(function(d){
		if (!d.success || !d.data || !d.data.report) {
			if (abody) abody.innerHTML = '<div style="padding:40px;text-align:center;color:var(--hts-danger);font-size:13px">Erreur de g\u00e9n\u00e9ration du rapport.</div>';
			return;
		}
		var report = d.data.report;
		if (typeof renderReport === 'function') renderReport(report);
		if (titleEl) titleEl.textContent = report.title || label || 'Rapport';
		/* Résumé PHP dans le chat (0 token LLM) */
		var summary = report.summary || '';
		if (summary) {
			var msgsEl = document.getElementById('coachMessages');
			if (msgsEl) {
				var wrapper = document.createElement('div');
				wrapper.className = 'coach-msg assistant';
				if (report._report_db_id) wrapper.setAttribute('data-report-id', report._report_db_id);
				wrapper.innerHTML = '<div class="coach-msg-avatar" style="background:linear-gradient(135deg,var(--hts-accent),var(--hts-geo))"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8"><polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/></svg></div>'
					+ '<div class="coach-msg-bubble">' + (typeof _fmtComm==='function'?_fmtComm(summary):summary.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\n/g,'<br>'))
					+ '<div style="margin-top:12px"><button class="hts-ds-btn hts-ds-btn--sm" style="font-size:11px;gap:4px" onclick="htsLoadSavedReport('+(report._report_db_id||0)+')">'
					+ '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> Voir le rapport</button></div></div>';
				msgsEl.appendChild(wrapper);
				msgsEl.scrollTop = msgsEl.scrollHeight;
			}
		}
		/* Persister en sessionStorage */
		try { sessionStorage.setItem('hts_last_report', JSON.stringify(report)); } catch(e) {}
	}).catch(function(){
		if (abody) abody.innerHTML = '<div style="padding:40px;text-align:center;color:var(--hts-danger);font-size:13px">Erreur r\u00e9seau.</div>';
	});
}
function htsLoadSavedReport(reportId) {
	var sessNonce = document.getElementById('htsCSessionsDropdown') ? document.getElementById('htsCSessionsDropdown').getAttribute('data-nonce') : '';
	fetch(ajaxurl, {
		method: 'POST',
		headers: {'Content-Type':'application/x-www-form-urlencoded'},
		body: 'action=hts_coach_load_report&nonce=' + encodeURIComponent(sessNonce) + '&report_id=' + reportId
	}).then(function(r){return r.json()}).then(function(d){
		if (d.success && d.data && d.data.report && typeof renderReport === 'function') {
			var panel = document.getElementById('coachArtifactPanel');
			if (panel) { panel.classList.add('hts-artifact-open'); panel.style.display = 'flex'; }
			renderReport(d.data.report);
		}
	});
}
/* Dark mode toggle + persistence */
function htsToggleTheme(){var r=document.documentElement,c=r.getAttribute('data-hts-theme')||'light',n=c==='light'?'dark':'light';r.setAttribute('data-hts-theme',n);localStorage.setItem('hts-theme',n)}
(function(){var s=localStorage.getItem('hts-theme');if(s)document.documentElement.setAttribute('data-hts-theme',s)})();
/* Dropdown rapport — position:fixed pour échapper au overflow:hidden parent */
function htsToggleReportDD(e){
	e.stopPropagation();
	var dd=document.getElementById('hts-report-dropdown');
	if(!dd)return;
	if(dd.classList.contains('hts-dd-open')){dd.classList.remove('hts-dd-open');return}
	var btn=e.currentTarget;
	var rect=btn.getBoundingClientRect();
	dd.style.top=(rect.bottom+6)+'px';
	dd.style.right=(window.innerWidth-rect.right)+'px';
	dd.style.left='auto';
	dd.classList.add('hts-dd-open');
}
/* Intercepter les messages rapport AVANT envoi au LLM (0 token) */
function htsInterceptReportMsg(msg) {
	if (!msg || typeof msg !== 'string') return false;
	var m = msg.toLowerCase().trim();
	/* Ne pas intercepter les résumés internes (report_summary) */
	if (m.indexOf('report_summary') !== -1 || m.indexOf('report_json') !== -1) return false;
	var patterns = [
		{ re: /\b(diagnostic|diagno)\b.*\b(complet|seo|site|global)\b/i, type: 'full', label: 'Diagnostic SEO Complet' },
		{ re: /\b(rapport|report|analyse|bilan)\b.*\b(complet|full|global|seo)\b/i, type: 'full', label: 'Diagnostic SEO Complet' },
		{ re: /\b(rapport|analyse|bilan)\b.*\b(maillage|liens?\s*internes?|linking|orphelin)/i, type: 'linking', label: 'Rapport Maillage Interne' },
		{ re: /\b(rapport|analyse|bilan)\b.*\b(contenu|content|article|ia|geo)\b/i, type: 'content', label: 'Rapport Contenu & IA' },
		{ re: /\b(rapport|analyse|bilan)\b.*\b(perf|trafic|traffic|gsc|search\s*console|clic|impression|ctr)\b/i, type: 'performance', label: 'Rapport Performance SEO' },
		{ re: /\b(rapport|analyse|bilan)\b.*\b(audit|technique|sant|health|erreur)\b/i, type: 'audit', label: 'Audit Technique' },
		{ re: /\bfais\b.*\b(diagnostic|audit)\b/i, type: 'full', label: 'Diagnostic SEO Complet' },
		{ re: /\blance\b.*\b(diagnostic|audit|rapport)\b/i, type: 'full', label: 'Diagnostic SEO Complet' },
	];
	for (var i = 0; i < patterns.length; i++) {
		if (patterns[i].re.test(msg)) {
			htsGenerateReport(patterns[i].type, patterns[i].label);
			return true;
		}
	}
	return false;
}
/* Fallback coachAsk — avec interception rapport */
if (typeof window.coachAsk !== 'function') {
	window.coachAsk = function(msg) {
		if (htsInterceptReportMsg(msg)) return;
		var input = document.getElementById('coachInput');
		if (input) { input.value = msg; input.dispatchEvent(new Event('input', { bubbles: true })); }
		var btn = document.querySelector('.coach-send-btn, .hts-coach-send-btn, button[type="submit"]');
		if (btn) setTimeout(function(){ btn.click(); }, 100);
	};
} else {
	/* Wrapper coachAsk existant avec interception */
	var _origCoachAsk = window.coachAsk;
	window.coachAsk = function(msg) {
		if (htsInterceptReportMsg(msg)) return;
		_origCoachAsk(msg);
	};
}
(function(){
	var panel    = document.getElementById('coachArtifactPanel');
	var abody    = document.getElementById('coachArtifactBody');
	var titleEl  = document.getElementById('coachArtifactTitle');
	var badgeEl  = document.getElementById('coachArtifactBadge');
	var exportEl = document.getElementById('coachArtifactExport');
	var toolbar  = document.getElementById('coachArtifactToolbar');
	var searchEl = document.getElementById('coachArtifactSearch');
	var rowCount = document.getElementById('coachArtifactRowCount');
	var resizer  = document.getElementById('coachArtifactResizer');
	var sidebar  = document.getElementById('coachSidebar');
	var overlay  = document.getElementById('coachOverlay');
	var isDragging = false;
	var currentType = '';

	var TYPES = {
		chart: 'Graphique', plan: 'Plan d\u0027exécution',
		seo: 'Plan SEO', table: 'Tableau', actions: 'Actions'
	};

	/* ═══ OPEN ═══ */
	window.coachOpenArtifact = function(contentEl, title, type) {
		if (!panel || !abody) return;
		currentType = type = type || 'chart';
		abody.innerHTML = '';

		/* Extract Chart.js configs BEFORE cloning (canvas content lost on clone) */
		var chartConfigs = [];
		if (type === 'chart' && contentEl && contentEl.querySelectorAll) {
			var origCanvases = contentEl.querySelectorAll('canvas');
			for (var ci = 0; ci < origCanvases.length; ci++) {
				var inst = (typeof Chart !== 'undefined') ? Chart.getChart(origCanvases[ci]) : null;
				if (inst) {
					chartConfigs.push({
						idx: ci,
						type: inst.config.type,
						data: JSON.parse(JSON.stringify(inst.data)),
						options: JSON.parse(JSON.stringify(inst.config.options || {}))
					});
				}
			}
		}

		if (typeof contentEl === 'string') {
			abody.innerHTML = '';
			var ifr = document.createElement('iframe');
			ifr.sandbox = 'allow-same-origin';
			ifr.style.cssText = 'width:100%;border:none;min-height:200px;';
			abody.appendChild(ifr);
			var doc = ifr.contentDocument || ifr.contentWindow.document;
			doc.open();
			doc.write('<!DOCTYPE html><html><head><style>body{font-family:inherit;margin:16px;color:#1e293b;}</style></head><body>' + contentEl + '</body></html>');
			doc.close();
			ifr.style.height = doc.body.scrollHeight + 'px';
		} else if (contentEl && contentEl.cloneNode) {
			var clone = contentEl.cloneNode(true);
			abody.appendChild(clone);
			enhance(clone, type, chartConfigs);
		}

		/* Header */
		if (titleEl) titleEl.textContent = title || 'Visualisation';
		if (badgeEl) { badgeEl.textContent = TYPES[type] || 'Graphique'; badgeEl.setAttribute('data-type', type); }

		/* Toolbar: visible for tables only */
		if (toolbar) { toolbar.classList.toggle('visible', type === 'table'); }
		if (searchEl) searchEl.value = '';

		/* Export button */
		setupExport(type);

		/* Open with animation */
		panel.classList.add('hts-artifact-open');
		abody.scrollTop = 0;
	};

	/* ═══ CLOSE ═══ */
	window.coachCloseArtifact = function() {
		if (!panel) return;
		panel.classList.remove('hts-artifact-open');
		panel.style.removeProperty('width');
		panel.style.removeProperty('min-width');
	};

	/* ═══ EXPORT BUTTON ═══ */
	function setupExport(type) {
		if (!exportEl) return;
		exportEl.style.display = (type === 'chart' || type === 'table') ? '' : 'none';
		exportEl.querySelector('span').textContent = type === 'chart' ? 'PNG' : 'CSV';
		exportEl.onclick = function() {
			if (type === 'chart') exportPNG();
			if (type === 'table') exportCSV();
		};
	}

	function exportPNG() {
		var c = abody.querySelector('canvas');
		if (!c) return;
		var link = document.createElement('a');
		link.download = (titleEl ? titleEl.textContent : 'chart').replace(/[^a-zA-Z0-9\s-]/g, '').replace(/\s+/g, '_') + '.png';
		link.href = c.toDataURL('image/png');
		link.click();
	}

	function exportCSV() {
		var table = abody.querySelector('table');
		if (!table) return;
		var csv = [];
		var trs = table.querySelectorAll('tr');
		for (var i = 0; i < trs.length; i++) {
			if (trs[i].classList.contains('hts-row-hidden')) continue;
			var cells = trs[i].querySelectorAll('th,td');
			var row = [];
			for (var j = 0; j < cells.length; j++) {
				var val = cells[j].textContent.trim().replace(/"/g, '""');
				row.push('"' + val + '"');
			}
			csv.push(row.join(';'));
		}
		var blob = new Blob(['\uFEFF' + csv.join('\n')], { type: 'text/csv;charset=utf-8' });
		var link = document.createElement('a');
		link.download = (titleEl ? titleEl.textContent : 'data').replace(/[^a-zA-Z0-9\s-]/g, '').replace(/\s+/g, '_') + '.csv';
		link.href = URL.createObjectURL(blob);
		link.click();
		setTimeout(function() { URL.revokeObjectURL(link.href); }, 3000);
	}

	/* ═══ ENHANCE CLONED CONTENT ═══ */
	function enhance(clone, type, chartConfigs) {
		clone.style.maxWidth = '100%';
		clone.style.cursor = 'default';
		clone.style.margin = '0';

		if (type === 'chart') enhanceChart(clone, chartConfigs || []);
		else if (type === 'table') enhanceTables(clone);
		else if (type === 'seo') enhanceSEOPlan(clone);
		else if (type === 'plan') enhancePlan(clone);

		/* Always enhance nested tables */
		if (type !== 'table') {
			var tbls = clone.querySelectorAll('table');
			for (var i = 0; i < tbls.length; i++) enhanceOneTable(tbls[i]);
		}
	}

	/* ── CHART: re-render from pre-extracted configs ── */
	function enhanceChart(el, configs) {
		el.style.padding = '0'; el.style.border = 'none';
		el.style.boxShadow = 'none'; el.style.background = 'transparent';
		var exp = el.querySelector('.coach-chart-export');
		if (exp) exp.style.display = 'none';

		var clonedCanvases = el.querySelectorAll('canvas');
		for (var i = 0; i < configs.length; i++) {
			var cfg = configs[i];
			var target = clonedCanvases[cfg.idx];
			if (!target) continue;

			var fresh = document.createElement('canvas');
			fresh.style.width = '100%';
			fresh.style.maxHeight = '420px';
			target.parentNode.replaceChild(fresh, target);

			var opts = cfg.options;
			opts.responsive = true;
			opts.maintainAspectRatio = true;
			opts.animation = { duration: 500, easing: 'easeOutQuart' };
			try {
				new Chart(fresh, { type: cfg.type, data: cfg.data, options: opts });
			} catch(e) {}

			/* Summary bar under chart */
			buildChartSummary(el, cfg.data, cfg.type);
		}

		/* Fallback: no configs extracted (Chart.js not loaded yet?) — show message */
		if (configs.length === 0 && clonedCanvases.length > 0) {
			var note = document.createElement('div');
			note.style.cssText = 'text-align:center;padding:20px;color:var(--hts-text-3);font-size:12px;';
			note.textContent = 'Graphique en cours de chargement\u2026';
			el.appendChild(note);
		}
	}

	function buildChartSummary(container, chartData, chartType) {
		if (!chartData || !chartData.datasets || !chartData.datasets[0]) return;
		var data = chartData.datasets[0].data;
		var labels = chartData.labels || [];
		if (!data || data.length < 2) return;

		var sum = 0, max = -Infinity, min = Infinity, maxIdx = 0, minIdx = 0;
		for (var i = 0; i < data.length; i++) {
			var v = parseFloat(data[i]) || 0;
			sum += v;
			if (v > max) { max = v; maxIdx = i; }
			if (v < min) { min = v; minIdx = i; }
		}
		var avg = Math.round(sum / data.length);

		var bar = document.createElement('div');
		bar.className = 'hts-chart-summary';
		if (chartType === 'doughnut') {
			bar.innerHTML = '<div class="hts-chart-summary-item"><div class="hts-chart-summary-label">Total</div><div class="hts-chart-summary-value">' + Math.round(sum) + '</div></div>'
				+ '<div class="hts-chart-summary-item" data-ask="Détaille la part ' + esc(labels[maxIdx] || '') + '"><div class="hts-chart-summary-label">Plus grand</div><div class="hts-chart-summary-value">' + esc(labels[maxIdx] || '') + '</div></div>'
				+ '<div class="hts-chart-summary-item"><div class="hts-chart-summary-label">Parts</div><div class="hts-chart-summary-value">' + data.length + '</div></div>';
		} else if (chartType === 'radar') {
			bar.innerHTML = '<div class="hts-chart-summary-item"><div class="hts-chart-summary-label">Moyenne</div><div class="hts-chart-summary-value">' + avg + '/100</div></div>'
				+ '<div class="hts-chart-summary-item" data-ask="Quels sont les points forts de mon score ' + esc(labels[maxIdx] || '') + ' ?"><div class="hts-chart-summary-label">Meilleur</div><div class="hts-chart-summary-value">' + esc(labels[maxIdx] || '') + ' (' + Math.round(max) + ')</div></div>'
				+ '<div class="hts-chart-summary-item" data-ask="Comment améliorer mon score ' + esc(labels[minIdx] || '') + ' ?"><div class="hts-chart-summary-label">Plus faible</div><div class="hts-chart-summary-value">' + esc(labels[minIdx] || '') + ' (' + Math.round(min) + ')</div></div>';
		} else {
			bar.innerHTML = '<div class="hts-chart-summary-item"><div class="hts-chart-summary-label">Moyenne</div><div class="hts-chart-summary-value">' + avg + '</div></div>'
				+ '<div class="hts-chart-summary-item" data-ask="Pourquoi ' + esc(labels[maxIdx] || '') + ' a le score le plus haut ?"><div class="hts-chart-summary-label">Max</div><div class="hts-chart-summary-value">' + esc(labels[maxIdx] || '') + ' (' + Math.round(max) + ')</div></div>'
				+ '<div class="hts-chart-summary-item" data-ask="Comment améliorer ' + esc(labels[minIdx] || '') + ' ?"><div class="hts-chart-summary-label">Min</div><div class="hts-chart-summary-value">' + esc(labels[minIdx] || '') + ' (' + Math.round(min) + ')</div></div>';
		}
		container.appendChild(bar);
	}

	function esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

	/**
	 * Format commentary: decode entities, support bold + bullets.
	 */
	window._fmtComm = _fmtComm; /* expose pour htsGenerateReport (hors IIFE) */
	function _fmtComm(s){
		if(!s)return '';
		// Decode HTML entities
		var d=document.createElement('textarea');d.innerHTML=s;s=d.value;
		// Re-escape
		s=esc(s);
		// **bold** → <strong>
		s=s.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
		// Lines starting with - or • → list
		var lines=s.split(/\n/),inList=false,out='';
		for(var i=0;i<lines.length;i++){
			var line=lines[i].trim();
			if(!line)continue;
			var isBullet=/^[•\-–]\s/.test(line);
			if(isBullet){
				if(!inList){out+='<ul class="hts-comm-list">';inList=true}
				out+='<li>'+line.replace(/^[•\-–]\s*/,'')+'</li>';
			}else{
				if(inList){out+='</ul>';inList=false}
				out+='<p class="hts-comm-p">'+line+'</p>';
			}
		}
		if(inList)out+='</ul>';
		return out;
	}

	/* ── TABLES ── */
	function enhanceTables(el) {
		/* Strip bubble wrapper styles if the clone is a .coach-msg-bubble */
		if (el.classList && el.classList.contains('coach-msg-bubble')) {
			el.style.padding = '0';
			el.style.border = 'none';
			el.style.borderRadius = '0';
			el.style.background = 'transparent';
		}
		var tables = el.querySelectorAll('table');
		for (var i = 0; i < tables.length; i++) enhanceOneTable(tables[i]);
		updateRowCount();
	}

	function enhanceOneTable(table) {
		if (!table || table.getAttribute('data-enhanced')) return;
		table.setAttribute('data-enhanced', '1');

		var ths = table.querySelectorAll('th');
		var tbody = table.querySelector('tbody') || table;
		var rows = [];
		var trs = tbody.querySelectorAll('tr');
		for (var i = 0; i < trs.length; i++) {
			if (trs[i].querySelector('th')) continue;
			rows.push(trs[i]);
		}

		/* Numeric auto-detect + right-align */
		for (var ci = 0; ci < ths.length; ci++) {
			var isNum = true;
			for (var ri = 0; ri < Math.min(rows.length, 5); ri++) {
				var cell = rows[ri] && rows[ri].cells[ci];
				if (!cell) continue;
				var val = cell.textContent.trim().replace(/[\s,%€$+\-]/g, '');
				if (val && isNaN(parseFloat(val))) { isNum = false; break; }
			}
			if (isNum && rows.length > 0) {
				ths[ci].style.textAlign = 'right';
				for (var ri = 0; ri < rows.length; ri++) {
					if (rows[ri].cells[ci]) {
						rows[ri].cells[ci].style.textAlign = 'right';
						rows[ri].cells[ci].style.fontVariantNumeric = 'tabular-nums';
						rows[ri].cells[ci].style.fontWeight = '600';
					}
				}
			}
		}

		/* Sortable */
		for (var ci = 0; ci < ths.length; ci++) {
			(function(col, th) {
				th.addEventListener('click', function() {
					var asc = !th.classList.contains('hts-sort-asc');
					for (var k = 0; k < ths.length; k++) ths[k].classList.remove('hts-sort-asc', 'hts-sort-desc');
					th.classList.add(asc ? 'hts-sort-asc' : 'hts-sort-desc');
					rows.sort(function(a, b) {
						var va = (a.cells[col] ? a.cells[col].textContent.trim() : '');
						var vb = (b.cells[col] ? b.cells[col].textContent.trim() : '');
						var na = parseFloat(va.replace(/[\s,%€$]/g, ''));
						var nb = parseFloat(vb.replace(/[\s,%€$]/g, ''));
						if (!isNaN(na) && !isNaN(nb)) return asc ? na - nb : nb - na;
						return asc ? va.localeCompare(vb, 'fr') : vb.localeCompare(va, 'fr');
					});
					for (var r = 0; r < rows.length; r++) tbody.appendChild(rows[r]);
				});
			})(ci, ths[ci]);
		}

		/* Add data-ask on rows: first cell = subject of the question */
		for (var ri = 0; ri < rows.length; ri++) {
			var firstCell = rows[ri].cells[0];
			if (firstCell) {
				var subject = firstCell.textContent.trim();
				if (subject.length > 3 && subject.length < 100) {
					rows[ri].setAttribute('data-ask', 'Analyse la page ' + subject);
				}
			}
		}
	}

	/* Search filter for tables */
	if (searchEl) {
		searchEl.addEventListener('input', function() {
			var q = this.value.toLowerCase();
			var table = abody.querySelector('table');
			if (!table) return;
			var tbody = table.querySelector('tbody') || table;
			var trs = tbody.querySelectorAll('tr');
			for (var i = 0; i < trs.length; i++) {
				if (trs[i].querySelector('th')) continue;
				var text = trs[i].textContent.toLowerCase();
				trs[i].classList.toggle('hts-row-hidden', q && text.indexOf(q) === -1);
			}
			updateRowCount();
		});
	}

	function updateRowCount() {
		if (!rowCount) return;
		var table = abody.querySelector('table');
		if (!table) { rowCount.textContent = ''; return; }
		var tbody = table.querySelector('tbody') || table;
		var trs = tbody.querySelectorAll('tr');
		var total = 0, visible = 0;
		for (var i = 0; i < trs.length; i++) {
			if (trs[i].querySelector('th')) continue;
			total++;
			if (!trs[i].classList.contains('hts-row-hidden')) visible++;
		}
		rowCount.textContent = visible === total ? total + ' lignes' : visible + ' / ' + total + ' lignes';
	}

	/* ── SEO Plan ── */
	function enhanceSEOPlan(el) {
		el.style.maxWidth = '100%'; el.style.margin = '0';
		reattachButtons(el);
		/* Add data-ask on plan action items */
		var actions = el.querySelectorAll('[style*="border-radius:8px"][style*="padding:12px"]');
		for (var i = 0; i < actions.length; i++) {
			var title = actions[i].querySelector('[style*="font-weight:600"]');
			if (title) {
				actions[i].setAttribute('data-ask', 'Détaille l\u0027action : ' + title.textContent.trim());
			}
		}
	}

	/* ── Exec Plan ── */
	function enhancePlan(el) {
		el.style.maxWidth = '100%'; el.style.margin = '0';
		reattachButtons(el, '.coach-plan-card');
		/* Add data-ask on plan steps */
		var steps = el.querySelectorAll('.coach-plan-step');
		for (var i = 0; i < steps.length; i++) {
			var label = steps[i].querySelector('[style*="font-weight:600"]');
			if (label) {
				steps[i].setAttribute('data-ask', 'Explique l\u0027étape : ' + label.textContent.trim());
			}
		}
	}

	/* ═══ REPORT DASHBOARD RENDERER ═══ */
	var currentReport = null; // persist for follow-up questions

	/* S19 UX: Section icon mapper */
	function sectionIcon(title) {
		var t = (title || '').toLowerCase();
		var svgs = {
			'performance':  '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
			'gsc':          '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
			'requete':      '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
			'quick':        '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
			'impact':       '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
			'activit':      '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
			'opportunit':   '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
			'point':        '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="9" y1="18" x2="15" y2="18"/><line x1="10" y1="22" x2="14" y2="22"/><path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/></svg>',
			'visibilit':    '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
		};
		for (var key in svgs) { if (t.indexOf(key) !== -1) return svgs[key] + ' '; }
		return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg> ';
	}

	window.renderReport = renderReport; /* expose pour htsGenerateReport (hors IIFE) */
	function renderReport(report) {
		if (!report || !report.title) return;
		currentReport = report;
		var html = '<div class="hts-report" id="htsReportContent">';

		/* Header with PDF export */
		var reportDate = report.generated_at ? new Date(report.generated_at).toLocaleDateString('fr-FR', {day:'numeric',month:'long',year:'numeric'}) : new Date().toLocaleDateString('fr-FR', {day:'numeric',month:'long',year:'numeric'});
		html += '<div class="hts-report-header"><div style="flex:1"><div class="hts-report-title">' + esc(report.title) + '</div>';
		html += '<div class="hts-report-subtitle">Généré par Coach SEO — ' + reportDate + '</div></div>';
		html += '<button type="button" onclick="htsExportPDF()" class="hts-ds-btn hts-ds-btn--sm" style="flex-shrink:0;gap:4px" title="Télécharger en PDF">PDF</button>';
		html += '</div>';
		if (report.summary) {
			html += '<div class="hts-report-summary">' + _fmtComm(report.summary) + '</div>';
		}

		/* KPIs */
		if (report.kpis && report.kpis.length) {
			html += '<div class="hts-report-kpis">';
			for (var i = 0; i < report.kpis.length; i++) {
				var k = report.kpis[i];
				html += '<div class="hts-kpi" data-ask="Explique mon ' + esc(k.label) + ' et comment l\'améliorer">';
				html += '<div class="hts-kpi-label">' + esc(k.label) + '</div>';
				html += '<div class="hts-kpi-row"><span class="hts-kpi-value">' + esc(k.value) + '</span>';
				if (k.unit) html += '<span class="hts-kpi-unit">' + esc(k.unit) + '</span>';
				if (k.delta && k.delta.length > 0) {
					html += '<span class="hts-kpi-delta ' + (k.trend || 'neutral') + '">' + (k.trend === 'up' ? '\u2191' : k.trend === 'down' ? '\u2193' : '') + ' ' + esc(k.delta) + '</span>';
				}
				if (k.delta_label) html += '<span class="hts-kpi-delta-label">' + esc(k.delta_label) + '</span>';
				if (k.delta_yoy) {
					html += '<span class="hts-kpi-yoy">' + esc(k.delta_yoy);
					if (k.delta_yoy_label) html += ' ' + esc(k.delta_yoy_label);
					html += '</span>';
				}
				html += '</div></div>';
			}
			html += '</div>';
		}

		/* ═══ RECOMMENDATIONS ═══ */
		if (report.recommendations && report.recommendations.length) {
			html += '<div class="hts-report-section"><div class="hts-report-section-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> Actions prioritaires cette semaine</div>';
			html += '<div class="hts-report-recs">';
			for (var ri2 = 0; ri2 < report.recommendations.length; ri2++) {
				var rec = report.recommendations[ri2];
				html += '<div class="hts-rec" data-ask="Détaille l\'action : ' + esc(rec.action) + ' et comment la mettre en place concrètement">';
				html += '<div class="hts-rec-header"><span class="hts-rec-priority">' + (ri2 + 1) + '</span><span class="hts-rec-title">' + esc(rec.action) + '</span>';
				html += '<span class="hts-rec-meta">' + esc(rec.effort || '') + (rec.impact ? ' · Impact ' + esc(rec.impact) : '') + '</span></div>';
				if (rec.detail) html += '<div class="hts-rec-detail">' + esc(rec.detail) + '</div>';
				html += '</div>';
			}
			html += '</div></div>';
		}

		/* ═══ CHARTS ═══ */
		if (report.charts && report.charts.length) {
			for (var ci = 0; ci < report.charts.length; ci++) {
				var ch = report.charts[ci];
				html += '<div class="hts-report-section"><div class="hts-report-section-title">' + sectionIcon(ch.title) + esc(ch.title || 'Graphique') + '</div>';
				if (ch.type === 'radar' && report.section_geo) {
					html += '<div class="hts-report-commentary">' + esc(report.section_geo) + '</div>';
					report._geoShown = true;
				}
				html += '<div class="hts-report-chart"><canvas id="hts-report-chart-' + ci + '"></canvas></div>';
				var chartComm = ch.commentary || '';
				if (chartComm) html += '<div class="hts-report-commentary">' + _fmtComm(chartComm) + '</div>';
				html += '</div>';
			}
		}

		/* Section GEO standalone (if not shown above radar) */
		if (report.section_geo && !report._geoShown) {
			html += '<div class="hts-report-section"><div class="hts-report-section-title">' + sectionIcon('visibilite') + 'Visibilité IA (GEO)</div>';
			html += '<div class="hts-report-commentary">' + esc(report.section_geo) + '</div></div>';
		}

		/* ═══ TABLES WITH COMMENTARY ═══ */
		if (report.tables && report.tables.length) {
			for (var ti = 0; ti < report.tables.length; ti++) {
				var t = report.tables[ti];
				html += '<div class="hts-report-section">';
				if (t.title) html += '<div class="hts-report-section-title">' + sectionIcon(t.title) + esc(t.title) + '</div>';
				var isPerf2 = t.title && t.title.match(/performance/i);
				var isOpp2 = t.title && t.title.match(/opportunit/i);
				var isAct2 = t.title && t.title.match(/activit/i);
				var isGsc2 = t.title && t.title.match(/requetes/i);
				var isQw2 = t.title && t.title.match(/quick win/i);
				var isImpact2 = t.title && t.title.match(/impact/i);
				/* Match section commentary to table */
				var commentary = '';
				if (isPerf2 && report.section_performance) commentary = report.section_performance;
				else if (isGsc2 && report.section_gsc) commentary = report.section_gsc;
				else if (isQw2 && report.section_quickwins) commentary = report.section_quickwins;
				else if (isImpact2 && report.section_impact) commentary = report.section_impact;
				else if (isAct2 && report.section_activity) commentary = report.section_activity;
				else if (isOpp2 && report.section_opportunities) commentary = report.section_opportunities;
				/* v2.6.3: t.commentary a priorité sur section_* legacy */
				if (commentary && !t.commentary) html += '<div class="hts-report-commentary">' + _fmtComm(commentary) + '</div>';
				html += '<div class="hts-report-table-wrap"><table class="hts-report-table"><thead><tr>';
				for (var hi = 0; hi < t.headers.length; hi++) {
					html += '<th>' + esc(t.headers[hi]) + '</th>';
				}
				html += '</tr></thead><tbody>';
				for (var ri = 0; ri < t.rows.length; ri++) {
					var row = t.rows[ri];
					var askText = '';
					if (isPerf2 && row[0]) askText = 'Analyse la page ' + row[0] + ' et donne-moi un plan d\'action concret';
					else if (isGsc2 && row[0]) askText = 'Analyse la requête "' + row[0] + '" : quelles pages optimiser pour cette requête ?';
					else if (isQw2 && row[0]) askText = 'Comment faire passer "' + row[0] + '" de la position ' + (row[1]||'') + ' en page 1 ?';
					else if (isImpact2 && row[1]) askText = 'Détaille l\'impact de l\'action "' + row[0] + '" sur "' + row[1] + '"';
					else if (isOpp2 && row[1]) askText = 'Comment mettre en place : ' + row[0] + ' pour ' + row[1] + ' ?';
					html += '<tr' + (askText ? ' data-ask="' + esc(askText) + '"' : '') + '>';
					for (var ci2 = 0; ci2 < row.length; ci2++) {
						var cellVal = row[ci2] || '';
						var isLastCol = (ci2 === row.length - 1);
						var isDiagCol = isLastCol && t.headers && t.headers[ci2] === 'Diagnostic';
						if (isDiagCol && cellVal) {
							var diagClass = 'hts-diag-neutral';
							if (cellVal.match(/critique|orpheline|0 lien/i)) diagClass = 'hts-diag-critical';
							else if (cellVal.match(/faible|page 2|pas de meta/i)) diagClass = 'hts-diag-warn';
							else if (cellVal.match(/excellen|correcte/i)) diagClass = 'hts-diag-ok';
							html += '<td><span class="hts-diag-badge ' + diagClass + '">' + esc(cellVal) + '</span></td>';
						} else {
							html += '<td>' + esc(cellVal) + '</td>';
						}
					}
					html += '</tr>';
				}
				html += '</tbody></table></div>';
				var tableComm = t.commentary || '';
				if (tableComm) html += '<div class="hts-report-commentary">' + _fmtComm(tableComm) + '</div>';
				html += '</div>';
			}
		}

		/* ═══ INSIGHTS ═══ */
		if (report.insights && report.insights.length) {
			html += '<div class="hts-report-section"><div class="hts-report-section-title">' + sectionIcon('points') + 'Points clés</div>';
			html += '<div class="hts-report-insights">';
			for (var ii = 0; ii < report.insights.length; ii++) {
				var ins = report.insights[ii];
				html += '<div class="hts-insight ' + (ins.level || 'medium') + '" data-ask="Explique en détail : ' + esc(ins.text).substring(0, 50) + '... Que dois-je faire concrètement ?">';
				html += '<span class="hts-insight-dot"></span>';
				html += '<span class="hts-insight-text">' + esc(ins.text) + '</span></div>';
			}
			html += '</div></div>';
		} else {
			html += '<div class="hts-report-section"><div class="hts-report-section-title">' + sectionIcon('points') + 'Points clés</div>';
			html += '<div style="padding:20px;text-align:center;color:var(--hts-text-3);font-size:12px;border:1px dashed var(--hts-border);border-radius:8px;">Clique sur Rapport dans la barre pour générer les insights expert</div></div>';
		}

		/* Thread */
		html += '<div class="hts-report-thread" id="htsReportThread" style="display:none">';
		html += '<div class="hts-report-thread-title">Discussion</div></div>';
		html += '</div>';

		if (abody) abody.innerHTML = html;
		if (titleEl) titleEl.textContent = report.title;
		if (badgeEl) { badgeEl.setAttribute('data-type', 'report'); badgeEl.textContent = 'RAPPORT'; }
		if (panel) panel.classList.add('hts-artifact-open');

		/* Chart.js */
		if (report.charts && typeof Chart !== 'undefined') {
			setTimeout(function() {
				for (var ci3 = 0; ci3 < report.charts.length; ci3++) {
					var ch2 = report.charts[ci3];
					var cvs = document.getElementById('hts-report-chart-' + ci3);
					if (!cvs) continue;
					var colors = ['rgba(99,102,241,.7)','rgba(16,185,129,.7)','rgba(245,158,11,.7)','rgba(239,68,68,.7)','rgba(139,92,246,.7)','rgba(14,165,233,.7)','rgba(236,72,153,.7)','rgba(168,162,158,.7)'];
					var bgColors = ['rgba(99,102,241,.15)','rgba(16,185,129,.15)','rgba(245,158,11,.15)','rgba(239,68,68,.15)','rgba(139,92,246,.15)','rgba(14,165,233,.15)','rgba(236,72,153,.15)','rgba(168,162,158,.15)'];
					while (colors.length < ch2.data.length) { colors = colors.concat(colors); bgColors = bgColors.concat(bgColors); }
					var cfg2 = { type: ch2.type === 'horizontalBar' ? 'bar' : ch2.type, data: { labels: ch2.labels, datasets: [{ label: ch2.title || 'Score', data: ch2.data, backgroundColor: ch2.type === 'radar' ? 'rgba(99,102,241,.15)' : bgColors.slice(0, ch2.data.length), borderColor: ch2.type === 'radar' ? 'rgba(99,102,241,.8)' : colors.slice(0, ch2.data.length), borderWidth: ch2.type === 'radar' ? 2 : 1, pointBackgroundColor: 'rgba(99,102,241,1)', pointRadius: ch2.type === 'radar' ? 4 : 0, fill: ch2.type === 'radar' }] }, options: { responsive: true, maintainAspectRatio: true, indexAxis: ch2.type === 'horizontalBar' ? 'y' : 'x', plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(15,23,42,.9)', titleFont: { size: 12 }, bodyFont: { size: 11 }, padding: 10, cornerRadius: 6 } }, animation: { duration: 600, easing: 'easeOutCubic' } } };
					if (ch2.type === 'radar') { cfg2.options.scales = { r: { beginAtZero: true, max: 100, ticks: { stepSize: 20, font: { size: 11 }, backdropColor: 'transparent' }, grid: { color: 'rgba(0,0,0,.06)' }, angleLines: { color: 'rgba(0,0,0,.06)' }, pointLabels: { font: { size: 13, weight: '600' }, color: '#6B7280' } } }; }
					else if (ch2.type === 'bar') { cfg2.options.scales = { x: { grid: { display: false }, ticks: { font: { size: 13, weight: '500' }, maxRotation: 45 } }, y: { grid: { color: 'rgba(0,0,0,.04)' }, ticks: { font: { size: 12 } }, beginAtZero: true } }; cfg2.data.datasets[0].borderRadius = 4; cfg2.data.datasets[0].maxBarThickness = 40; }
					else if (ch2.type === 'doughnut') { cfg2.options.cutout = '65%'; cfg2.options.plugins.legend = { display: true, position: 'bottom', labels: { font: { size: 13, weight: '500' }, padding: 16, usePointStyle: true, pointStyle: 'circle' } }; cfg2.data.datasets[0].backgroundColor = ['rgba(5,150,105,.7)','rgba(245,158,11,.7)','rgba(220,38,38,.7)']; cfg2.data.datasets[0].borderColor = ['rgba(5,150,105,1)','rgba(245,158,11,1)','rgba(220,38,38,1)']; cfg2.data.datasets[0].borderWidth = 2; }
					else if (ch2.type === 'line') {
						/* Dual-axis line: Clicks (left) + Impressions (right) */
						cfg2.data.datasets = [
							{ label: 'Clics', data: ch2.data, borderColor: 'rgba(99,102,241,.9)', backgroundColor: 'rgba(99,102,241,.08)', borderWidth: 2.5, pointRadius: 3, pointBackgroundColor: 'rgba(99,102,241,1)', fill: true, tension: .35, yAxisID: 'y' },
							{ label: 'Impressions', data: ch2.data2 || [], borderColor: 'rgba(16,185,129,.7)', backgroundColor: 'transparent', borderWidth: 1.5, pointRadius: 0, borderDash: [4, 3], tension: .35, yAxisID: 'y1' }
						];
						cfg2.options.plugins.legend = { display: true, position: 'top', align: 'end', labels: { font: { size: 10 }, padding: 12, usePointStyle: true, pointStyle: 'circle' } };
						cfg2.options.scales = {
							x: { grid: { display: false }, ticks: { font: { size: 9 }, maxRotation: 0, maxTicksLimit: 10 } },
							y: { position: 'left', grid: { color: 'rgba(0,0,0,.04)' }, ticks: { font: { size: 10 } }, beginAtZero: true, title: { display: true, text: 'Clics', font: { size: 10, weight: '600' }, color: '#6366F1' } },
							y1: { position: 'right', grid: { drawOnChartArea: false }, ticks: { font: { size: 10 } }, beginAtZero: true, title: { display: true, text: 'Impressions', font: { size: 10, weight: '600' }, color: '#10B981' } }
						};
					}
					try { new Chart(cvs, cfg2); } catch(e) {}
				}
			}, 180);
		}
		if (exportEl) exportEl.style.display = 'none';
		if (toolbar) toolbar.classList.remove('visible');
	}

	/* ═══ PDF EXPORT — html2canvas + jsPDF avec slicing multi-page (méthode S17 éprouvée) ═══ */
	window.htsExportPDF = function() {
		var el = document.getElementById('htsReportContent');
		if (!el) { el = document.querySelector('.hts-coach-artifact-body'); }
		if (!el) return;
		var btn = document.querySelector('[onclick*="htsExportPDF"]');
		if (btn) { btn.disabled = true; btn.textContent = 'Export...'; }

		function doExport() {
			html2canvas(el, {
				scale: 2, useCORS: true, backgroundColor: '#ffffff',
				logging: false, windowWidth: 800
			}).then(function(canvas) {
				var imgData = canvas.toDataURL('image/png');
				var pdf = new jspdf.jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' });
				var pdfW = pdf.internal.pageSize.getWidth();
				var pdfH = pdf.internal.pageSize.getHeight();
				var imgW = pdfW - 20;
				var imgH = (canvas.height * imgW) / canvas.width;
				var y = 10;
				/* Multi-page: slice canvas si plus grand qu'une page */
				if (imgH <= pdfH - 20) {
					pdf.addImage(imgData, 'PNG', 10, y, imgW, imgH);
				} else {
					var pageH = pdfH - 20;
					var srcH = (pageH / imgW) * canvas.width;
					var pages = Math.ceil(canvas.height / srcH);
					for (var p = 0; p < pages; p++) {
						if (p > 0) pdf.addPage();
						var sliceCanvas = document.createElement('canvas');
						sliceCanvas.width = canvas.width;
						sliceCanvas.height = Math.min(srcH, canvas.height - p * srcH);
						var ctx = sliceCanvas.getContext('2d');
						ctx.drawImage(canvas, 0, p * srcH, canvas.width, sliceCanvas.height, 0, 0, canvas.width, sliceCanvas.height);
						var sliceH = (sliceCanvas.height * imgW) / sliceCanvas.width;
						pdf.addImage(sliceCanvas.toDataURL('image/png'), 'PNG', 10, 10, imgW, sliceH);
					}
				}
				var titleEl = el.querySelector('.hts-report-title') || el.querySelector('h2');
				var reportTitle = titleEl ? titleEl.textContent.trim() : 'Rapport-SEO';
				pdf.save(reportTitle.replace(/[^a-zA-Z0-9\u00c0-\u00ff\s-]/g, '').replace(/\s+/g, '_') + '.pdf');
				if (btn) { btn.disabled = false; btn.textContent = 'PDF'; }
			}).catch(function(e) {
				console.error('PDF export error:', e);
				if (btn) { btn.disabled = false; btn.textContent = 'PDF'; }
			});
		}

		/* Charger les libs à la demande */
		if (typeof html2canvas !== 'undefined' && typeof jspdf !== 'undefined') { doExport(); return; }
		var s1 = document.createElement('script');
		s1.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
		s1.onload = function() {
			var s2 = document.createElement('script');
			s2.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
			s2.onload = function() { setTimeout(doExport, 100); };
			document.head.appendChild(s2);
		};
		document.head.appendChild(s1);
	};


	/* Inject a follow-up answer INTO the current report panel */
	var _reportPendingQuestion = null;
	window.coachInjectReportAnswer = function(question, answer) {
		/* S19 UX: Discussion thread hidden — chat IS the discussion, no duplication */
		/* var thread = document.getElementById('htsReportThread');
		if (!thread) return;
		thread.style.display = 'block';
		var block = document.createElement('div');
		block.className = 'hts-report-answer';
		block.innerHTML = '<div class="hts-report-answer-q">' + esc(question) + '</div>'
			+ '<div class="hts-report-answer-body">' + answer + '</div>';
		thread.appendChild(block);
		block.scrollIntoView({ behavior: 'smooth', block: 'end' }); */
		_reportPendingQuestion = null;
	};

	/* ═══ CLICK-TO-ASK: click data-ask element → pre-fill chat input ═══ */
	if (abody) {
		abody.addEventListener('click', function(e) {
			var askEl = e.target.closest('[data-ask]');
			if (!askEl) return;
			var question = askEl.getAttribute('data-ask');
			if (!question) return;
			/* Intercepter les data-ask rapport (0 token) */
			if (typeof htsInterceptReportMsg === 'function' && htsInterceptReportMsg(question)) { e.preventDefault(); e.stopPropagation(); return; }
			var input = document.getElementById('coachInput');
			if (input) {
				input.value = question;
				input.style.height = 'auto';
				input.style.height = Math.min(input.scrollHeight, 200) + 'px';
				input.dispatchEvent(new Event('input', { bubbles: true }));
				/* BUG 4 FIX: Auto-send when clicking a report row */
				if (currentReport) {
					_reportPendingQuestion = question;
				}
				/* Send automatically — no need to click the send button */
				setTimeout(function() { coachSend(); }, 50);
			}
		});
	}

	/* Watch for new assistant messages — if we have a pending report question, inject the answer */
	(function() {
		var msgs = document.getElementById('coachMessages');
		if (!msgs) return;

		new MutationObserver(function() {
			/* Limit DOM size: remove oldest messages when exceeding 100 bubbles */
			var allBubbles = msgs.querySelectorAll('.coach-bubble, .coach-msg');
			if (allBubbles.length > 100) {
				allBubbles[0].parentElement ? allBubbles[0].parentElement.remove() : allBubbles[0].remove();
			}

			var assistantMsgs = msgs.querySelectorAll('.coach-msg.assistant');
			if (!_reportPendingQuestion) return;

			/* New assistant message detected — get the latest */
			var latest = assistantMsgs[assistantMsgs.length - 1];
			if (!latest) return;
			/* Skip if we already processed this one */
			if (latest.getAttribute('data-report-injected')) return;
			var bubble = latest.querySelector('.coach-msg-bubble');
			if (!bubble) return;

			/* Wait for streaming to finish (cursor gone) */
			var checkDone = setInterval(function() {
				var cursor = bubble.querySelector('.coach-stream-cursor');
				if (cursor) return; /* Still streaming */
				clearInterval(checkDone);

				/* Mark as processed to avoid re-injection */
				latest.setAttribute('data-report-injected', '1');
				var answerHtml = bubble.innerHTML || '';
				/* Strip any remaining cursor spans */
				answerHtml = answerHtml.replace(/<span class="coach-stream-cursor"><\/span>/g, '');
				window.coachInjectReportAnswer(_reportPendingQuestion, answerHtml);
			}, 500);

			/* Safety: stop checking after 30s */
			setTimeout(function() { clearInterval(checkDone); _reportPendingQuestion = null; }, 30000);
		}).observe(msgs, { childList: true, subtree: true });
	})();

	function reattachButtons(el, scope) {
		var container = document.querySelector(scope || '.coach-chat');
		if (!container) return;
		var btns = el.querySelectorAll('button');
		for (var i = 0; i < btns.length; i++) {
			var text = btns[i].textContent.trim();
			var origBtns = container.querySelectorAll('button');
			for (var j = 0; j < origBtns.length; j++) {
				if (origBtns[j].textContent.trim() === text && origBtns[j].onclick) {
					btns[i].onclick = origBtns[j].onclick;
					break;
				}
			}
		}
		/* Also re-attach links with onmouseenter/onmouseleave */
		var links = el.querySelectorAll('a[style]');
		var origLinks = container.querySelectorAll('a[style]');
		for (var i = 0; i < links.length; i++) {
			for (var j = 0; j < origLinks.length; j++) {
				if (origLinks[j].textContent.trim() === links[i].textContent.trim()) {
					if (origLinks[j].onmouseenter) links[i].onmouseenter = origLinks[j].onmouseenter;
					if (origLinks[j].onmouseleave) links[i].onmouseleave = origLinks[j].onmouseleave;
					break;
				}
			}
		}
	}

	/* ═══ RESIZER (drag to resize panel width in flex layout) ═══ */
	if (resizer) {
		resizer.addEventListener('mousedown', function(e) {
			e.preventDefault(); isDragging = true;
			resizer.classList.add('dragging');
			document.body.style.cursor = 'col-resize';
			document.body.style.userSelect = 'none';
		});
		document.addEventListener('mousemove', function(e) {
			if (!isDragging || !panel || !panel.parentNode) return;
			var layoutRect = panel.parentNode.getBoundingClientRect();
			var w = layoutRect.right - e.clientX;
			if (w < 360) w = 360;
			if (w > layoutRect.width * 0.75) w = Math.floor(layoutRect.width * 0.75);
			panel.style.width = w + 'px';
			panel.style.minWidth = w + 'px';
		});
		document.addEventListener('mouseup', function() {
			if (!isDragging) return;
			isDragging = false;
			resizer.classList.remove('dragging');
			document.body.style.cursor = '';
			document.body.style.userSelect = '';
		});
	}

	/* ═══ CLICK HANDLERS ═══ */
	document.addEventListener('click', function(e) {
		/* Close report dropdown on outside click */
		var dd = document.getElementById('hts-report-dropdown');
		if (dd && dd.classList.contains('hts-dd-open') && !e.target.closest('#hts-report-dropdown-wrap') && !e.target.closest('#hts-report-dropdown')) {
			dd.classList.remove('hts-dd-open');
		}
		if (e.target.closest('.hts-coach-artifact')) return;
		if (e.target.closest('.coach-chart-export')) return;
		if (e.target.closest('button') || e.target.closest('a') || e.target.closest('select') || e.target.closest('input')) return;
		/* Chart */
		var cw = e.target.closest('.coach-chart-wrap');
		if (cw) { window.coachOpenArtifact(cw, (cw.querySelector('.coach-chart-title') || {}).textContent || 'Graphique', 'chart'); return; }
		/* Exec plan */
		var pc = e.target.closest('.coach-plan-card');
		if (pc) { window.coachOpenArtifact(pc, 'Plan d\u0027exécution', 'plan'); return; }
		/* Table in bubble (click on td/th/table) */
		var tbl = e.target.closest('table');
		if (tbl) {
			var bbl = tbl.closest('.coach-msg-bubble');
			if (bbl && tbl.rows && tbl.rows.length >= 2) {
				window.coachOpenArtifact(bbl, 'Tableau de données', 'table');
				return;
			}
		}
		/* SEO plan (detect DS class) */
		var seoPlanEl = e.target.closest('.hts-seo-plan');
		if (seoPlanEl) {
			window.coachOpenArtifact(seoPlanEl, 'Plan SEO', 'seo');
		}
	});

	/* Escape */
	document.addEventListener('keydown', function(e) {
		if (e.key === 'Escape') {
			if (panel && panel.classList.contains('hts-artifact-open')) { window.coachCloseArtifact(); return; }
			if (sidebar && sidebar.classList.contains('hts-sidebar-open')) { window.coachCloseSidebar(); }
		}
	});

	/* ═══ AUTO-OPEN (charts, plans, SEO plans — NOT tables: noisy during streaming) ═══ */
	var autoOpenTimer = null;
	function detectRichContent(node) {
		if (!node || node.nodeType !== 1) return null;
		/* Report card (hidden div with data-report JSON) — ALWAYS auto-open */
		var reportCard = node.querySelector ? node.querySelector('.coach-report-card') : null;
		if (!reportCard && node.classList && node.classList.contains('coach-report-card')) reportCard = node;
		if (reportCard) {
			try {
				var rData = JSON.parse(reportCard.getAttribute('data-report'));
				if (rData && rData.title) return { el: reportCard, title: rData.title, type: 'report', data: rData };
			} catch(e) {}
		}
		/* SEO plan — auto-open (structured content) */
		var seoPlanNode = node.querySelector ? node.querySelector('.hts-seo-plan') : null;
		if (!seoPlanNode && node.classList && node.classList.contains('hts-seo-plan')) seoPlanNode = node;
		if (seoPlanNode) {
			return { el: seoPlanNode, title: 'Plan SEO', type: 'seo' };
		}
		/* Charts and tables: do NOT auto-open. User clicks to expand. */
		return null;
	}

	var msgs = document.getElementById('coachMessages');
	if (msgs && typeof MutationObserver !== 'undefined') {
		new MutationObserver(function(muts) {
			for (var i = 0; i < muts.length; i++) {
				var added = muts[i].addedNodes;
				for (var j = 0; j < added.length; j++) {
					var hit = detectRichContent(added[j]);
					if (hit) {
						/* Debounce: if multiple triggers in quick succession (SSR hydration), only open the last */
						/* Report takes PRIORITY: if report found, ignore subsequent chart/plan triggers */
						if (autoOpenTimer) clearTimeout(autoOpenTimer);
						(function(h) {
							autoOpenTimer = setTimeout(function() {
								autoOpenTimer = null;
								if (h.type === 'report' && h.data) {
									renderReport(h.data);
									window._reportAutoOpened = true;
								} else if (!window._reportAutoOpened) {
									window.coachOpenArtifact(h.el, h.title, h.type);
								}
								/* Reset flag after 1s (allow future auto-opens) */
								setTimeout(function() { window._reportAutoOpened = false; }, 1000);
							}, 400);
						})(hit);
						return;
					}
				}
			}
		}).observe(msgs, { childList: true, subtree: true });
	}

	/* ═══ HISTORY SIDEBAR (left panel) ═══ */
	var histPanel = document.getElementById('coachHistoryPanel');
	var histBody = document.getElementById('coachHistoryBody');
	var sessNonce = document.getElementById('htsCSessionsDropdown') ? document.getElementById('htsCSessionsDropdown').getAttribute('data-nonce') : '<?php echo esc_attr( $nonce ); ?>';
	var histLoaded = false;

	window.htsCToggleHistory = function() {
		if (!histPanel) return;
		var isOpen = histPanel.classList.contains('open');
		if (isOpen) {
			histPanel.classList.remove('open');
		} else {
			histPanel.classList.add('open');
			if (!histLoaded) { htsCLoadHistory(); histLoaded = true; }
		}
	};
	window.htsCCloseHistory = function() {
		if (histPanel) histPanel.classList.remove('open');
	};

	/* Keep old function names for compatibility */
	window.htsCToggleSessions = window.htsCToggleHistory;
	window.htsCCloseSessions = window.htsCCloseHistory;

	/* Close history on outside click (mobile) */
	document.addEventListener('click', function(e) {
		if (histPanel && histPanel.classList.contains('open')) {
			if (!e.target.closest('.coach-history') && !e.target.closest('[onclick*="htsCToggleHistory"]') && !e.target.closest('#hts-coach-ds-sessions-btn')) {
				histPanel.classList.remove('open');
			}
		}
	});

	function htsCLoadHistory() {
		if (!histBody) return;
		histBody.innerHTML = '<div style="padding:20px;text-align:center;color:var(--hts-text-3);font-size:11px;">Chargement...</div>';
		fetch(ajaxurl, {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: 'action=hts_coach_sessions&nonce=' + sessNonce + '&limit=30'
		})
		.then(function(r) { return r.json(); })
		.then(function(d) {
			if (!d.success || !d.data.sessions || !d.data.sessions.length) {
				histBody.innerHTML = '<div style="padding:24px;text-align:center;color:var(--hts-text-3);font-size:11px;">Aucune conversation</div>';
				return;
			}
			var html = '';
			d.data.sessions.forEach(function(s) {
				var preview = s.preview || '';
				var topics = (s.topics && s.topics.length) ? s.topics.join(', ') : '';
				var text = preview || topics || 'Conversation';
				if (text.length > 45) text = text.substring(0, 45) + '\u2026';
				var date = s.session_start ? new Date(s.session_start).toLocaleDateString('fr-FR', {day:'numeric', month:'short'}) : '';
				var isActive = s.is_active || false;
				html += '<div class="coach-history-item' + (isActive ? ' active' : '') + '" onclick="coachLoadSession(' + s.id + ');htsCCloseHistory()">';
				html += '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + htsCEsc(text) + '</span>';
				html += '<span class="coach-history-date">' + date + '</span>';
				html += '</div>';
			});
			histBody.innerHTML = html;
		})
		.catch(function() {
			histBody.innerHTML = '<div style="padding:24px;text-align:center;color:var(--hts-text-3);font-size:11px;">Erreur</div>';
		});
	}

	function htsCEsc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

	/* ═══ SIDEBAR DRAWER ═══ */
	setTimeout(function() {
		window.coachToggleSidebar = function() {
			if (!sidebar) return;
			if (sidebar.classList.contains('hts-sidebar-open')) {
				sidebar.classList.remove('hts-sidebar-open');
				if (overlay) overlay.classList.remove('active');
			} else {
				sidebar.classList.add('hts-sidebar-open');
				if (overlay) overlay.classList.add('active');
				document.getElementById('coachSidebarCloseRow').style.display = 'flex';
			}
		};
		window.coachCloseSidebar = function() {
			if (sidebar) sidebar.classList.remove('hts-sidebar-open');
			if (overlay) overlay.classList.remove('active');
		};
	}, 0);

	/* ═══ FIX: decode \u0027 in cockpit-generated pills/suggestions ═══ */
	function fixUnicodeEscapes(container) {
		if (!container) return;
		var els = container.querySelectorAll('.coach-pill,.coach-welcome-suggestion-btn');
		for (var i = 0; i < els.length; i++) {
			var t = els[i].textContent;
			if (t.indexOf('\\u') !== -1) {
				els[i].textContent = t.replace(/\\u([0-9a-fA-F]{4})/g, function(m, g) {
					return String.fromCharCode(parseInt(g, 16));
				});
			}
		}
	}
	/* Watch suggestions + welcome for cockpit JS updates */
	var sugC = document.getElementById('coachSuggestions');
	var welC = document.getElementById('coachWelcomeBubble');
	if (typeof MutationObserver !== 'undefined') {
		var uniObs = new MutationObserver(function() {
			fixUnicodeEscapes(sugC);
			fixUnicodeEscapes(welC);
		});
		if (sugC) uniObs.observe(sugC, { childList: true, subtree: true });
		if (welC) uniObs.observe(welC, { childList: true, subtree: true });
	}

	/* ═══ GSC RESYNC FROM COACH ═══ */
	window.htsCGscSync = function(btn) {
		if (btn) { btn.disabled = true; btn.textContent = 'Sync en cours...'; }
		fetch(ajaxurl, {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: 'action=hts_gsc_fetch_now&nonce=<?php echo esc_attr( $gsc_nonce ); ?>'
		})
		.then(function(r) { return r.json(); })
		.then(function(d) {
			if (d.success) {
				if (btn) btn.innerHTML = '\u2714 ' + esc(d.data.message || 'OK');
				/* Refresh the page after 2s to show updated data everywhere */
				setTimeout(function() { location.reload(); }, 2000);
			} else {
				if (btn) { btn.disabled = false; btn.textContent = 'Erreur: ' + (d.data.message || 'inconnue'); }
			}
		})
		.catch(function() {
			if (btn) { btn.disabled = false; btn.textContent = 'Erreur réseau'; }
		});
	};

	/* ═══ WEEKLY REPORT AUTO-LOAD ═══ */
	/* Manual generation (admin button) — re-shows if already loaded */
	window.htsCGenReport = function(btn) {
		/* v2.6.3: redirige vers le nouveau flow 100% PHP */
		htsGenerateReport('full', 'Diagnostic SEO Complet');
		return;
		/* === LEGACY CODE BELOW (kept for reference, never executed) === */
		if (currentReport && currentReport.title && panel && !panel.classList.contains('hts-artifact-open')) {
			renderReport(currentReport);
			return;
		}
		if (btn) { btn.disabled = true; btn.textContent = 'Génération...'; }
		if (abody && panel) {
			abody.innerHTML = '<div class="hts-report" style="padding:20px">'
				+ '<div style="height:22px;width:60%;background:var(--hts-border);border-radius:4px;margin-bottom:24px;animation:htsPulse 1.2s ease infinite"></div>'
				+ '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:24px">'
				+ '<div style="height:70px;background:var(--hts-border-sub,#f1f5f9);border-radius:8px;animation:htsPulse 1.2s ease infinite .1s"></div>'
				+ '<div style="height:70px;background:var(--hts-border-sub,#f1f5f9);border-radius:8px;animation:htsPulse 1.2s ease infinite .2s"></div>'
				+ '<div style="height:70px;background:var(--hts-border-sub,#f1f5f9);border-radius:8px;animation:htsPulse 1.2s ease infinite .3s"></div>'
				+ '</div>'
				+ '<div style="height:200px;background:var(--hts-border-sub,#f1f5f9);border-radius:8px;margin-bottom:24px;animation:htsPulse 1.2s ease infinite .4s"></div>'
				+ '<div style="height:120px;background:var(--hts-border-sub,#f1f5f9);border-radius:8px;animation:htsPulse 1.2s ease infinite .5s"></div>'
				+ '</div>';
			if (titleEl) titleEl.textContent = 'Génération du rapport...';
			if (badgeEl) { badgeEl.textContent = 'EN COURS'; }
			panel.classList.add('hts-artifact-open');
		}
		fetch(ajaxurl, {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: 'action=hts_coach_generate_report&nonce=' + sessNonce
		})
		.then(function(r) { return r.json(); })
		.then(function(d) {
			if (btn) { btn.disabled = false; btn.innerHTML = '\u2714 Rapport'; }
			if (d.success && d.data.report) {
				currentReport = d.data.report;
				renderReport(d.data.report);
				/* Restore button after 3s */
				setTimeout(function() { if (btn) btn.innerHTML = '<?php echo HTS_DS::icon( "file-text", 12, "var(--hts-text-2)" ); ?> <span class="hts-coach-topbar-label">Rapport</span>'; }, 3000);
			} else {
				if (btn) btn.textContent = 'Erreur';
				/* Clear loading skeleton */
				if (abody) abody.innerHTML = '<div style="padding:40px;text-align:center;color:var(--hts-text-3)"><div style="font-size:14px;margin-bottom:8px">Impossible de générer le rapport</div><div style="font-size:12px">Vérifiez que des pages sont analysées et que la clé API est configurée.</div></div>';
				if (titleEl) titleEl.textContent = 'Erreur';
				if (badgeEl) badgeEl.textContent = '';
				setTimeout(function() { if (btn) { btn.innerHTML = '<?php echo HTS_DS::icon( "file-text", 12, "var(--hts-text-2)" ); ?> <span class="hts-coach-topbar-label">Rapport</span>'; btn.disabled = false; } }, 3000);
			}
		})
		.catch(function() {
			if (btn) { btn.disabled = false; btn.textContent = 'Erreur'; }
			if (abody) abody.innerHTML = '<div style="padding:40px;text-align:center;color:var(--hts-text-3);font-size:13px">Erreur réseau. Réessayez.</div>';
		});
	};

	(function loadWeeklyReport() {
		setTimeout(function() {
			fetch(ajaxurl, {
				method: 'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				body: 'action=hts_coach_weekly_report&nonce=' + sessNonce
			})
			.then(function(r) { return r.json(); })
			.then(function(d) {
				if (d.success && d.data.has_report && d.data.report) {
					/* Store for follow-up questions */
					currentReport = d.data.report;
					/* Show a discrete indicator in topbar */
					var sessBtn = document.getElementById('hts-coach-ds-sessions-btn');
					if (sessBtn) {
						var dot = document.createElement('span');
						dot.style.cssText = 'width:6px;height:6px;border-radius:50%;background:var(--hts-geo);display:inline-block;margin-left:4px;';
						dot.title = 'Rapport hebdo disponible';
						sessBtn.parentNode.insertBefore(dot, sessBtn.nextSibling);
					}
					/* Add a clickable banner after welcome message */
					var msgs = document.getElementById('coachMessages');
					if (msgs) {
						var banner = document.createElement('div');
						banner.style.cssText = 'padding:12px 16px;border:1px solid var(--hts-border);border-radius:10px;cursor:pointer;display:flex;align-items:center;gap:10px;transition:border-color .15s;margin-bottom:8px;max-width:760px;width:100%;box-sizing:border-box;align-self:center;';
						banner.onmouseenter = function() { banner.style.borderColor = 'var(--hts-geo)'; };
						banner.onmouseleave = function() { banner.style.borderColor = 'var(--hts-border)'; };
						banner.innerHTML = '<span style="font-size:11px;font-weight:700;color:var(--hts-geo);text-transform:uppercase;letter-spacing:.3px;">Rapport hebdo</span>'
							+ '<span style="font-size:12px;color:var(--hts-text-2);flex:1;">' + htsCEsc(d.data.report.title || 'Rapport SEO') + '</span>'
							+ '<span style="font-size:10px;color:var(--hts-text-3);">' + (d.data.generated_at ? new Date(d.data.generated_at).toLocaleDateString('fr-FR', {day:'numeric',month:'short'}) : '') + '</span>';
						banner.onclick = function() { renderReport(d.data.report); };
						/* Insert after welcome message if exists, otherwise at top */
						var welcome = document.getElementById('coachWelcomeMsg');
						if (welcome && welcome.nextSibling) {
							msgs.insertBefore(banner, welcome.nextSibling);
						} else {
							msgs.appendChild(banner);
						}
					}
				}
			})
			.catch(function() { /* silently fail */ });
		}, 800); /* Page settled */
	})();

	/* FIX 5: Restaurer le dernier rapport au chargement (sessionStorage ou SSR) */
	(function() {
		var saved = sessionStorage.getItem('hts_last_report');
		if (saved) {
			try {
				var r = JSON.parse(saved);
				var p = document.getElementById('coachArtifactPanel');
				if (p && typeof renderReport === 'function') {
					setTimeout(function() {
						p.classList.add('hts-artifact-open'); p.style.display = 'flex';
						renderReport(r);
					}, 600);
				}
			} catch(e) {}
		}
	})();
})();
</script>
<?php
/**
 * INTEGRATION in class-hts-cockpit.php render_coach_page():
 *
 * Replace from: <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/...
 * Through:      </div><!-- /wrap -->
 * With:         include HTS__PLUGIN_DIR . 'admin/partials/coach.php';
 *
 * Keep the <script>(function(){...})();</script> block AFTER the include.
 */
?>
