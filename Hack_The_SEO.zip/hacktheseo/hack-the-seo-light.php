<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Hack The SEO
 * Plugin URI:        https://hacktheseo.com/
 * Description:       SEO complet pour WordPress — Meta Tags, Schema JSON-LD, Sitemap XML, Redirections, Breadcrumbs, Scoring, Cocons Sémantiques, Maillage Interne IA, Actions Prioritaires, Suivi d'impact.
 * Version:           2.8.0
 * Author:            Hack The SEO
 * Author URI:        https://hacktheseo.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       hack-the-seo-light
 * Domain Path:       /languages
 * Requires PHP:      7.4
 * Requires at least: 5.9
 */

if ( ! defined( 'WPINC' ) ) die;

/* PHP 7.4 polyfills for PHP 8.0+ string functions */
if ( ! function_exists( 'str_ends_with' ) ) {
    function str_ends_with( $haystack, $needle ) {
        if ( '' === $needle ) return true;
        return substr( $haystack, -strlen( $needle ) ) === $needle;
    }
}
if ( ! function_exists( 'str_starts_with' ) ) {
    function str_starts_with( $haystack, $needle ) {
        return 0 === strncmp( $haystack, $needle, strlen( $needle ) );
    }
}
if ( ! function_exists( 'str_contains' ) ) {
    function str_contains( $haystack, $needle ) {
        return '' === $needle || false !== strpos( $haystack, $needle );
    }
}

/* =========================================================================
 * COMPAT CHECKS
 * ====================================================================== */

if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
    add_action( 'admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>Hack The SEO</strong> requiert PHP 7.4+. Version actuelle : ' . esc_html( PHP_VERSION ) . '</p></div>';
    } );
    return;
}

if ( version_compare( get_bloginfo( 'version' ), '5.9', '<' ) ) {
    add_action( 'admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>Hack The SEO</strong> requiert WordPress 5.9+. Version actuelle : ' . esc_html( get_bloginfo( 'version' ) ) . '</p></div>';
    } );
    return;
}

/* =========================================================================
 * CONFLICT DETECTION — Prevent Full + Light running simultaneously
 * ====================================================================== */

if ( defined( 'HTS__PLUGIN_DIR' ) ) {
    add_action( 'admin_notices', function() {
        echo '<div class="notice notice-warning"><p><strong>Hack The SEO</strong> et <strong>Hack The SEO Full</strong> sont tous les deux actifs. ';
        echo 'Désactivez l\'un des deux pour éviter les conflits.</p></div>';
    } );
    return;
}

/* =========================================================================
 * CONSTANTS
 * ====================================================================== */

define( 'HTS__VERSION',         '2.8.0' );
define( 'HTS__PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );

/**
 * Minimum capability to SEE the HTS admin pages.
 * 'edit_posts' = Editor and above. Override in wp-config.php if needed.
 */
if ( ! defined( 'HTS_VIEW_CAPABILITY' ) ) {
    define( 'HTS_VIEW_CAPABILITY', 'edit_posts' );
}
if ( ! defined( 'HTS__PATH' ) ) {
    define( 'HTS__PATH', HTS__PLUGIN_DIR );
}
define( 'HTS__PLUGIN_URL',      plugin_dir_url( __FILE__ ) );
define( 'HTS__PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'HTS__IS_LIGHT',        true );

// Asset suffix: use .min.js/.min.css in production, unminified in debug mode
define( 'HTS__MIN', ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min' );

// Bot response time measurement — as early as possible.
if ( ! defined( 'HTS_REQUEST_START' ) ) {
    define( 'HTS_REQUEST_START', $_SERVER['REQUEST_TIME_FLOAT'] ?? microtime( true ) );
}

// Feature flags for progressive SaaS migration (Phase 3A)
// Set to true in wp-config.php to delegate computation to Laravel API
if ( ! defined( 'HTS_REMOTE_SCORING' ) )    define( 'HTS_REMOTE_SCORING', false );
if ( ! defined( 'HTS_REMOTE_LINKING' ) )     define( 'HTS_REMOTE_LINKING', false );
if ( ! defined( 'HTS_REMOTE_DECISIONS' ) )   define( 'HTS_REMOTE_DECISIONS', false );
if ( ! defined( 'HTS_REMOTE_STRATEGY' ) )    define( 'HTS_REMOTE_STRATEGY', false );
if ( ! defined( 'HTS_REMOTE_WORKFLOW' ) )    define( 'HTS_REMOTE_WORKFLOW', false );

/* =========================================================================
 * ACTIVATION / DEACTIVATION
 * ====================================================================== */

register_activation_hook( __FILE__, function() {
    update_option( 'hts_light_version', HTS__VERSION, false );
    update_option( 'hts_light_activated', time(), false );

    // Ensure basic options exist
    if ( ! get_option( 'hts_title_separator' ) ) update_option( 'hts_title_separator', '—', false );
    if ( ! get_option( 'hts_home_title' ) )      update_option( 'hts_home_title', get_bloginfo( 'name' ), false );

    // Force sitemap rules re-flush on next page load (DEFERRED — safer than flushing now)
    update_option( 'hts_sitemap_flush_needed', true );
    delete_option( 'hts_sitemap_rules_installed' );

    // Clean stale canonical conflicts from previous migrations
    delete_option( 'hts_canonical_conflicts' );

    // Initialize circuit breaker for Health Check
    if ( get_option( 'hts_circuit_breaker' ) === false ) {
        update_option( 'hts_circuit_breaker', array(), false );
    }

    // Flag for immediate sitemap generation on first load
    update_option( 'hts_sitemap_first_run', true, false );

    // Flag for batch SEO score pre-computation
    update_option( 'hts_scores_first_run', true, false );

    // Clear stale migration state if onboarding was never completed
    if ( ! get_option( 'hts_onboarding_done' ) && get_option( 'hts_migration_state' ) === 'completed' ) {
        delete_option( 'hts_migration_state' );
    }

    // ═══ AUTO-CONFIGURE: Smart defaults based on site language ═══
    hts_auto_configure_defaults();

    // DON'T flush_rewrite_rules() here — our init hooks haven't registered yet.

    // Onboarding redirect on first install
    if ( ! get_option( 'hts_onboarding_done' ) ) {
        set_transient( 'hts_onboarding_redirect', true, 60 );
    }
} );

/**
 * ══════════════════════════════════════════════════════════════════
 *  v2.6.0: Spread weekly crons across the week (one-time migration)
 *
 *  Previously all weekly crons ran on Monday, causing server overload
 *  on shared hosting. Now spread: Mon→Strategy, Tue→Meta, Wed→Linking,
 *  Thu→Refresh, Fri→Decision+Scores, Sat→Inbox+Impact, Sun→Notifications.
 * ══════════════════════════════════════════════════════════════════
 */
add_action( 'admin_init', function() {
    if ( get_option( 'hts_cron_spread_v260' ) ) return;

    $tz   = wp_timezone();
    $base = new \DateTimeImmutable( 'next monday 03:00', $tz );

    $spread = array(
        // Monday 03:00 — Strategy decides first
        'hts_strategy_weekly'            => $base->getTimestamp(),
        // Tuesday 03:00 — Meta score scan
        'hts_meta_score_weekly_scan'     => $base->modify( '+1 day' )->getTimestamp(),
        // Wednesday 03:00 — Linking scan
        'hts_linking_weekly_scan'        => $base->modify( '+2 days' )->getTimestamp(),
        // Thursday 03:00 — Content refresh
        'hts_refresh_weekly_scan'        => $base->modify( '+3 days' )->getTimestamp(),
        // Friday 03:00 — Decision engine + global score
        'hts_decision_engine_weekly'     => $base->modify( '+4 days' )->getTimestamp(),
        'hts_global_score_weekly_snapshot' => $base->modify( '+4 days 00:30' )->getTimestamp(),
        // Saturday 03:00 — Inbox + Impact cleanup + Coach report
        'hts_inbox_weekly_scan'          => $base->modify( '+5 days' )->getTimestamp(),
        'hts_impact_cleanup'             => $base->modify( '+5 days 00:30' )->getTimestamp(),
        'hts_coach_weekly_report_cron'   => $base->modify( '+5 days 01:00' )->getTimestamp(),
        // Sunday 03:00 — Notifications + purge
        'hts_coach_weekly_purge'         => $base->modify( '+6 days' )->getTimestamp(),
    );

    foreach ( $spread as $hook => $ts ) {
        $existing = wp_next_scheduled( $hook );
        if ( $existing ) {
            wp_unschedule_event( $existing, $hook );
        }
        wp_schedule_event( $ts, 'weekly', $hook );
    }

    update_option( 'hts_cron_spread_v260', true, false );

    if ( function_exists( 'hts_add_log' ) ) {
        hts_add_log( 'v2.6.0: crons hebdo étalés lun→dim pour réduire la charge serveur', 'success', 'system' );
    }
} );

/**
 * ══════════════════════════════════════════════════════════════════
 *  AUTO-CONFIGURE: Smart defaults based on site locale
 * ══════════════════════════════════════════════════════════════════
 *
 * Detects site language and configures:
 *  - Content generation language (cocons, maillage, metas)
 *  - hreflang tags
 *  - Image generation (captions, alt text language)
 *  - Agent modes (conservative defaults for non-FR sites)
 *  - Connector phrases language
 *
 * FR sites = full features (cocons + content generation + maillage)
 * EN/other sites = visualization + analysis mode (no auto-content generation)
 *
 * Safe to call multiple times — only sets values if not already configured.
 */
function hts_auto_configure_defaults() {
    $locale   = get_locale(); // fr_FR, en_US, de_DE, es_ES...
    $lang     = strtolower( substr( $locale, 0, 2 ) );

    // ── 1. Store detected language ──
    if ( ! get_option( 'hts_site_language' ) ) {
        update_option( 'hts_site_language', $lang, false );
    }

    // ── 2. Content mode: FR = full (generate + publish), other = view only ──
    if ( ! get_option( 'hts_content_mode' ) ) {
        // FR: cocons generate content in French
        // EN: cocons generate content in English
        // Other: visualization/analysis only by default (can be overridden)
        $content_langs = array( 'fr', 'en', 'es', 'de', 'it', 'pt', 'nl', 'ja', 'zh', 'ar', 'ru', 'ko', 'pl', 'sv', 'tr' );
        $mode = in_array( $lang, $content_langs ) ? 'full' : 'view_only';
        update_option( 'hts_content_mode', $mode, false );
    }

    // ── 3. Default hreflang (based on full locale) ──
    if ( ! get_option( 'hts_default_hreflang' ) ) {
        $hreflang_map = array(
            'fr_FR' => 'fr-FR', 'fr_BE' => 'fr-BE', 'fr_CA' => 'fr-CA', 'fr_CH' => 'fr-CH',
            'en_US' => 'en-US', 'en_GB' => 'en-GB', 'en_AU' => 'en-AU', 'en_CA' => 'en-CA',
            'es_ES' => 'es-ES', 'es_MX' => 'es-MX', 'es_AR' => 'es-AR',
            'de_DE' => 'de-DE', 'de_AT' => 'de-AT', 'de_CH' => 'de-CH',
            'it_IT' => 'it-IT', 'pt_BR' => 'pt-BR', 'pt_PT' => 'pt-PT',
            'nl_NL' => 'nl-NL', 'nl_BE' => 'nl-BE',
        );
        $hreflang = $hreflang_map[ $locale ] ?? $lang;
        update_option( 'hts_default_hreflang', $hreflang, false );
    }

    // ── 4. Image settings (smart defaults) ──
    if ( ! get_option( 'hts_image_settings' ) ) {
        update_option( 'hts_image_settings', array(
            'featured_enabled'      => true,
            'featured_style'        => 'photo_realistic',
            'featured_quality'      => 'medium',
            'featured_text_overlay' => 'none',
            'incontent_enabled'     => true,
            'incontent_count'       => 1,
            'incontent_position'    => 'after_h2_p',
            'incontent_quality'     => 'medium',
            'incontent_types'       => array( 'schema_diagram', 'photo' ),
            'extra_instructions'    => '',
        ), false );
    }

    // ── 5. Brand identity defaults ──
    if ( ! get_option( 'hts_brand_identity' ) ) {
        update_option( 'hts_brand_identity', array(
            'primary_color'   => '#2563eb',
            'secondary_color' => '#f59e0b',
            'accent_color'    => '#10b981',
            'style'           => 'modern',
            'font_style'      => 'sans-serif',
            'logo_url'        => '',
            'brand_name'      => get_bloginfo( 'name' ),
        ), false );
    }

    // ── 6. Schedule defaults (conservative: disabled) ──
    if ( ! get_option( 'hts_schedule_settings' ) ) {
        update_option( 'hts_schedule_settings', array(
            'enabled'         => false,
            'frequency'       => 'hts_3xweek',
            'post_status'     => 'draft',
            'source'          => 'both',
            'active_cocon_id' => 0,
            'max_per_run'     => 1,
        ), false );
    }

    // ── 7. OpenAI monthly budget ──
    if ( ! get_option( 'hts_openai_monthly_limit' ) ) {
        update_option( 'hts_openai_monthly_limit', 1000000, false ); // 1M tokens/month
    }
    // Sprint 6.2d: bump old 500K default to 1M
    if ( (int) get_option( 'hts_openai_monthly_limit' ) <= 500000 ) {
        update_option( 'hts_openai_monthly_limit', 1000000, false );
    }

    // ── 8. Cross-cocon interlinking (on by default) ──
    if ( get_option( 'hts_cross_interlink_enabled' ) === false ) {
        update_option( 'hts_cross_interlink_enabled', '1', false );
    }
}

register_deactivation_hook( __FILE__, function() {
    flush_rewrite_rules( false );

    // Clean up ALL HTS cron hooks — exhaustive list to prevent orphan crons
    $hts_cron_hooks = array(
        // Single events (first-run / onboarding)
        'hts_sitemap_first_generation',
        'hts_batch_score_compute',
        // Recurring — Embeddings
        'hts_embeddings_index',
        'hts_embeddings_smart_cron',
        // Recurring — Phase 3 (Audit, Decision, Strategy)
        'hts_audit_purge_cron',
        'hts_decision_engine_weekly',
        'hts_strategy_weekly',
        // Recurring — Phase 4 (Feedback, GSC, Impact)
        'hts_gsc_daily_fetch',
        'hts_impact_cleanup',
        // Recurring — Phase 5 (Health, Auto-Write, Refresh, GEO)
        'hts_health_cron',
        'hts_auto_write_weekly',
        'hts_auto_schedule_check',
        'hts_refresh_weekly_scan',
        'hts_geo_score_cron_scan',
        'hts_global_score_weekly_snapshot',
        // Recurring — Phase 6+ (Coach, Workflow, Sitemap, Redirects)
        'hts_coach_monthly_reset',
        'hts_coach_weekly_purge',
        'hts_workflow_daily_cleanup',
        'hts_sitemap_cron',
        'hts_redirects_cleanup',
        // Recurring — Phase 7+ (Inbox, Linking, Meta, Auto-Drip, Deferred)
        'hts_inbox_weekly_scan',
        'hts_inbox_purge_stale',
        'hts_linking_weekly_scan',
        'hts_weekly_interlink_maintenance',
        'hts_meta_score_weekly_scan',
        'hts_auto_drip',
        'hts_batch_linking_drip',
        'hts_deferred_images', 'hts_deferred_cross_interlink', 'hts_batch_cleanup_internal_links',
        'hts_impact_measure',
        'hts_poll_pending_jobs',
        // Recurring — Cocon Commander, Notifications
        'hts_cocon_recover_abandoned_jobs',
        'hts_deferred_sibling_links',
        'hts_weekly_digest',
    );
    foreach ( $hts_cron_hooks as $hook ) {
        wp_clear_scheduled_hook( $hook );
    }

    // Clean up first-run options
    delete_option( 'hts_sitemap_first_run' );
    delete_option( 'hts_scores_first_run' );
    delete_option( 'hts_batch_score_offset' );
});

/* =========================================================================
 * VERSION UPGRADE — re-flush rewrite rules when plugin is updated
 * (activation hook does NOT fire on auto-updates or manual overwrites)
 * ====================================================================== */

add_action( 'plugins_loaded', function() {
    // ── i18n: load translations from /languages/ directory ──
    load_plugin_textdomain( 'hack-the-seo-light', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

    $stored = get_option( 'hts_light_version', '' );
    if ( $stored !== HTS__VERSION ) {
        update_option( 'hts_light_version', HTS__VERSION, false );
        // Force sitemap rewrite re-flush
        update_option( 'hts_sitemap_flush_needed', true );
        delete_option( 'hts_sitemap_rules_installed' );
        // Re-schedule health cron (may have failed on first install due to timing)
        $ts = wp_next_scheduled( 'hts_health_cron' );
        if ( $ts ) wp_unschedule_event( $ts, 'hts_health_cron' );

        // Sprint 6.2d: bump OpenAI budget from old 500K default to 1M
        $current_limit = (int) get_option( 'hts_openai_monthly_limit', 0 );
        if ( $current_limit > 0 && $current_limit <= 500000 ) {
            update_option( 'hts_openai_monthly_limit', 1000000, false );
        }

        // Sprint 6.2d: schedule one-time batch cleanup of internal link attributes
        if ( ! wp_next_scheduled( 'hts_batch_cleanup_internal_links' ) ) {
            wp_schedule_single_event( time() + 60, 'hts_batch_cleanup_internal_links' );
        }

        // Sprint Robustesse: purge Content Extractor cache on update
        // Schema detection depends on fresh extraction (accordion→details/summary, video, etc.)
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_hts_cx_%' OR option_name LIKE '_transient_timeout_hts_cx_%'"
        );

        // Sprint Robustesse: dedup existing feedback alerts (fix historical duplicates)
        $existing_alerts = get_option( 'hts_feedback_alerts', array() );
        if ( ! empty( $existing_alerts ) ) {
            $seen = array();
            $deduped = array();
            foreach ( $existing_alerts as $a ) {
                $key = ( $a['post_id'] ?? 0 ) . '_' . ( $a['window'] ?? '' );
                if ( ! isset( $seen[ $key ] ) ) {
                    $seen[ $key ] = true;
                    $deduped[] = $a;
                }
            }
            if ( count( $deduped ) < count( $existing_alerts ) ) {
                update_option( 'hts_feedback_alerts', $deduped, false );
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Hack The SEO mis à jour : ' . $stored . ' → ' . HTS__VERSION . ' — rewrite rules flush programmé', 'info', 'core' );
        }
    }
}, 5 );

/* =========================================================================
 * COMPAT CONSTANT — seo-settings.php expects HTS_SYNCHRONISE_ARTICLES_VERSION
 * ====================================================================== */

if ( ! defined( 'HTS_SYNCHRONISE_ARTICLES_VERSION' ) ) {
    define( 'HTS_SYNCHRONISE_ARTICLES_VERSION', HTS__VERSION );
}

/* =========================================================================
 * ADMIN — Simplified menu (3 pages only)
 * ====================================================================== */

add_action( 'admin_menu', function() {
    $td = 'hack-the-seo-light'; // text domain shorthand

    // Main menu
    add_menu_page(
        'Hack The SEO',
        'Hack The SEO',
        HTS_VIEW_CAPABILITY,
        'hts-light-dashboard',
        'hts_light_render_dashboard',
        'dashicons-chart-area',
        30
    );

    // Tableau de bord (first submenu replaces parent)
    $inbox_badge = '';
    if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
        $inbox_stats = HTS_Workflow_Engine::get_stats();
        $inbox_pending = (int) ( $inbox_stats['pending'] ?? 0 );
        if ( $inbox_pending > 0 ) {
            $inbox_badge = ' <span class="awaiting-mod" style="background:#6366f1;">' . $inbox_pending . '</span>';
        }
    }
    // Sprint 3.3: Coach alert badge in main menu
    $coach_menu_badge = '';
    if ( class_exists( 'HTS_Coach' ) ) {
        $coach_alerts = HTS_Coach::get_alert_count();
        if ( $coach_alerts > 0 ) {
            $coach_menu_badge = ' <span class="awaiting-mod" style="background:#ef4444;">' . $coach_alerts . '</span>';
        }
    }
    add_submenu_page(
        'hts-light-dashboard',
        __( 'Tableau de bord', $td ),
        __( 'Tableau de bord', $td ) . $inbox_badge . $coach_menu_badge,
        HTS_VIEW_CAPABILITY,
        'hts-light-dashboard'
    );

    // Settings
    add_submenu_page(
        'hts-light-dashboard',
        __( 'Réglages SEO', $td ),
        __( 'Réglages', $td ),
        HTS_VIEW_CAPABILITY,
        'hts-seo-settings',
        'hts_light_render_settings'
    );

    // Redirections
    $redir_badge = '';
    if ( class_exists( 'HTS_Redirects' ) ) {
        $pending_404 = HTS_Redirects::get_pending_count();
        if ( $pending_404 > 0 ) {
            $display_404 = $pending_404 > 99 ? '99+' : $pending_404;
            $redir_badge = ' <span class="awaiting-mod" style="background:#ef4444;">' . $display_404 . '</span>';
        }
    }
    add_submenu_page(
        'hts-light-dashboard',
        __( 'Redirections', $td ),
        __( 'Redirections', $td ) . $redir_badge,
        HTS_VIEW_CAPABILITY,
        'hts-redirections',
        'hts_light_render_redirections'
    );

    // Analytics
    add_submenu_page(
        'hts-light-dashboard',
        'Analytics',
        'Analytics',
        HTS_VIEW_CAPABILITY,
        'hts-analytics',
        'hts_light_render_analytics'
    );

    // Suivi d'impact — supprimé Sprint 6.3e (intégré dans Inbox > Historique & Impact)

    // Cocon Commander
    if ( class_exists( 'HTS_Cocon_Commander' ) ) {
        $cc_badge = '';
        $cc_temp = new HTS_Cocon_Commander();
        $cc_plans = $cc_temp->get_plans();
        $cc_pending = 0;
        foreach ( $cc_plans as $pp ) {
            $ps = $cc_temp->get_plan_stats( $pp['cocon_id'] ?? '' );
            $cc_pending += $ps['to_generate'] ?? 0;
        }
        if ( $cc_pending > 0 ) {
            $cc_badge = ' <span class="awaiting-mod" style="background:#6366f1;">' . $cc_pending . '</span>';
        }
        $_ultra_tag = ( class_exists( 'HTS_Subscription' ) && ! HTS_Subscription::is_ultra() ) ? ' <span style="background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:3px;margin-left:4px;vertical-align:middle">ULTRA</span>' : '';
        add_submenu_page(
            'hts-light-dashboard',
            'Groupes de contenus',
            'Groupes de contenus' . $cc_badge . $_ultra_tag,
            HTS_VIEW_CAPABILITY,
            'hts-cocon-commander',
            'hts_light_render_cocon_commander'
        );

        // Phase 6b — Calendrier Éditorial (supprimé Sprint 6.3e — intégré dans Cocon Commander)

        // Phase 6c — Cannibalisation
        // v2.5.13: Page Planification dédiée
        add_submenu_page(
            'hts-light-dashboard',
            'Planification',
            'Planification' . $_ultra_tag,
            HTS_VIEW_CAPABILITY,
            'hts-planning',
            'hts_light_render_planning'
        );

        add_submenu_page(
            'hts-light-dashboard',
            __( 'Pages en concurrence', $td ),
            __( 'Pages en concurrence', $td ),
            HTS_VIEW_CAPABILITY,
            'hts-cannibalization',
            'hts_light_render_cannibalization'
        );
    }
}, 9 );

// Read-only banner for non-admin users (editors)
add_action( 'admin_notices', function() {
    $page = $_GET['page'] ?? '';
    if ( strpos( $page, 'hts-' ) !== 0 && $page !== 'hts-light-dashboard' ) return;
    if ( current_user_can( 'manage_options' ) ) return;
    echo '<div class="notice" style="background:#FEF3C7;border:1px solid #F59E0B;border-left:4px solid #F59E0B;border-radius:4px;padding:8px 16px;margin:15px 0;font-size:13px;color:#92400E;">';
    echo '<strong>Mode lecture seule</strong> — Vous pouvez consulter les données SEO mais les actions sont réservées à l\'administrateur du site.';
    echo '</div>';
} );

// S12: Fusion réglages — masquer l'ancien "Réglages", renommer "Paramètres" → "Réglages"
add_action( 'admin_menu', function() {
    global $submenu;
    // Masquer l'ancien menu "Réglages" (la page reste accessible par URL → redirect JS)
    remove_submenu_page( 'hts-light-dashboard', 'hts-seo-settings' );
    // Renommer "Paramètres" → "Réglages" dans le menu
    if ( ! empty( $submenu['hts-light-dashboard'] ) ) {
        foreach ( $submenu['hts-light-dashboard'] as &$item ) {
            if ( isset( $item[2] ) && $item[2] === 'hts-api-settings' ) {
                $item[0] = __( 'Réglages', 'hack-the-seo-light' );
                $item[3] = __( 'Réglages', 'hack-the-seo-light' );
                break;
            }
        }
        unset( $item );
    }
}, 999 );

// Upgrade link — temporarily disabled
// add_action( 'admin_menu', function() {
//     add_submenu_page(
//         'hts-light-dashboard',
//         'Passer à Hack The SEO Full',
//         '<span style="color:#f59e0b;">Passer à Full</span>',
//         'manage_options',
//         'hts-upgrade',
//         'hts_light_render_upgrade'
//     );
// }, 99 );

function hts_light_render_dashboard() {
    if ( class_exists( 'HTS_Cockpit' ) ) {
        $cockpit = new HTS_Cockpit();
        $cockpit->render();
    }
}

function hts_light_render_redirections() {
    include HTS__PLUGIN_DIR . 'admin/partials/redirections.php';
}

function hts_light_render_analytics() {
    include HTS__PLUGIN_DIR . 'admin/partials/analytics.php';
}

function hts_light_render_cocon_commander() {
    // Free (tier 0) = blur wall. Pro (tier 1) + Ultra (tier 2) = full page (buttons gated inside partial)
    if ( class_exists( 'HTS_Subscription' ) && HTS_Subscription::is_locked( 'cocon_analyze' ) ) {
        echo HTS_DS::page_open();
        echo HTS_DS::hero( 'Groupes de contenus', 'Organisez vos articles en cocons sémantiques' );
        echo HTS_DS::pro_wall( array(
            'title'    => 'Organisez votre stratégie de contenu',
            'desc'     => 'Découvrez comment vos articles sont connectés entre eux, identifiez les contenus manquants et créez un plan d\'articles qui booste votre référencement.',
            'button'   => 'Voir les offres à partir de 99€/mois',
            'subtitle' => 'Coach SEO illimité · Rapports automatiques · Cocons IA',
        ) );
        echo HTS_DS::page_close();
        return;
    }
    include HTS__PLUGIN_DIR . 'admin/partials/cocon-commander.php';
}

function hts_light_render_editorial_calendar() {
    echo '<div class="hts-wrap">';
    echo '<div class="hts-header">';
    echo '<div class="hts-header-left">';
    echo '<div class="hts-header-logo"><img src="' . esc_url( plugins_url( 'admin/assets/icons/icon-admin.svg', __FILE__ ) ) . '" alt="Hack The SEO"></div>';
    echo '<div><h1 style="color:#fff;font-size:22px;font-weight:700;margin:0;">Calendrier Éditorial</h1>';
    echo '<p style="color:rgba(255,255,255,.8);font-size:13px;margin-top:2px;">Planifiez la publication de vos articles cocon</p></div>';
    echo '</div></div>';
    include HTS__PLUGIN_DIR . 'admin/partials/editorial-calendar.php';
    echo '</div>';
}

function hts_light_render_cannibalization() {
    include HTS__PLUGIN_DIR . 'admin/partials/cannibalization.php';
}

function hts_light_render_planning() {
    // Pro (tier 1) can see planning. Free = blur wall.
    if ( class_exists( 'HTS_Subscription' ) && HTS_Subscription::is_locked( 'planning' ) ) {
        echo HTS_DS::page_open();
        echo HTS_DS::hero( 'Planification', 'Planifiez la publication de vos articles' );
        echo HTS_DS::pro_wall( array(
            'title'    => 'Publiez au bon moment',
            'desc'     => 'Planifiez la publication de vos articles pour maintenir un rythme régulier. Google récompense les sites qui publient de manière constante.',
            'button'   => 'Voir les offres à partir de 99€/mois',
            'subtitle' => 'Calendrier éditorial · Publication programmée',
        ) );
        echo HTS_DS::page_close();
        return;
    }
    include HTS__PLUGIN_DIR . 'admin/partials/planning.php';
}

function hts_light_render_settings() {
    // S12: Unified settings — redirect to hts-api-settings&stab=seo
    // Headers already sent by WP admin chrome → JS redirect
    $url = admin_url( 'admin.php?page=hts-api-settings&stab=agents' );
    echo '<script>window.location.replace(' . wp_json_encode( $url ) . ');</script>';
    echo '<p style="padding:40px;text-align:center;color:#64748B;">Redirection vers les réglages unifiés&hellip;</p>';
}

// hts_light_render_upgrade() — removed: menu commented out, page orphaned (Phase 2B cleanup)

/* =========================================================================
 * ADMIN — Plugin action links
 * ====================================================================== */

/* ── Custom cron intervals ── */
add_filter( 'cron_schedules', function( $schedules ) {
    if ( ! isset( $schedules['hts_six_hours'] ) ) {
        $schedules['hts_six_hours'] = array(
            'interval' => 6 * HOUR_IN_SECONDS,
            'display'  => 'Toutes les 6 heures',
        );
    }
    if ( ! isset( $schedules['hts_fifteen_minutes'] ) ) {
        $schedules['hts_fifteen_minutes'] = array(
            'interval' => 15 * MINUTE_IN_SECONDS,
            'display'  => 'Toutes les 15 minutes',
        );
    }
    if ( ! isset( $schedules['hts_two_minutes'] ) ) {
        $schedules['hts_two_minutes'] = array(
            'interval' => 2 * MINUTE_IN_SECONDS,
            'display'  => 'Toutes les 2 minutes',
        );
    }
    if ( ! isset( $schedules['hts_weekly'] ) ) {
        $schedules['hts_weekly'] = array(
            'interval' => WEEK_IN_SECONDS,
            'display'  => 'Hebdomadaire (HTS)',
        );
    }
    return $schedules;
} );

/* ── Weekly auto-maintenance: interlinking health check ── */
add_action( 'hts_weekly_interlink_maintenance', function() {
    if ( ! class_exists( 'HTS_Synchronise_Articles_Admin' ) ) return;
    HTS_Synchronise_Articles_Admin::cron_weekly_interlink_maintenance();
} );

/* ── Sprint 6.2d: One-time batch cleanup of noopener/noreferrer on internal links ── */
add_action( 'hts_batch_cleanup_internal_links', function() {
    if ( ! class_exists( 'HTS_Synchronise_Articles_Admin' ) || ! method_exists( 'HTS_Synchronise_Articles_Admin', 'fix_internal_link_attrs' ) ) return;

    global $wpdb;
    $site_host = parse_url( get_site_url(), PHP_URL_HOST );
    if ( ! $site_host ) return;

    // Find all published posts/pages that contain noopener + internal host in same <a> tag
    $pattern = '%' . $wpdb->esc_like( $site_host ) . '%noopener%';
    $pattern2 = '%noopener%' . $wpdb->esc_like( $site_host ) . '%';

    $posts = $wpdb->get_col( $wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts}
         WHERE post_status IN ('publish','draft','future','pending')
           AND post_type IN ('post','page')
           AND ( post_content LIKE %s OR post_content LIKE %s )
         LIMIT 500",
        $pattern, $pattern2
    ) );

    $cleaned = 0;
    foreach ( $posts as $pid ) {
        $post = get_post( $pid );
        if ( ! $post ) continue;

        $new_content = HTS_Synchronise_Articles_Admin::fix_internal_link_attrs( $post->post_content );
        if ( $new_content !== $post->post_content ) {
            wp_update_post( array( 'ID' => $pid, 'post_content' => $new_content ) );
            $cleaned++;
        }
        clean_post_cache( $pid );
    }

    if ( function_exists( 'hts_add_log' ) ) {
        hts_add_log(
            sprintf( 'Batch cleanup liens internes : %d article(s) nettoyé(s) sur %d scanné(s)', $cleaned, count( $posts ) ),
            'info', 'core'
        );
    }

    // Don't re-schedule
    update_option( 'hts_batch_cleanup_done', current_time( 'Y-m-d H:i:s' ), false );
} );

// Schedule on plugin load if not already scheduled
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'hts_weekly_interlink_maintenance' ) ) {
        wp_schedule_event( time() + HOUR_IN_SECONDS, 'hts_weekly', 'hts_weekly_interlink_maintenance' );
    }
}, 20 );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function( $links ) {
    array_unshift( $links,
        '<a href="' . admin_url( 'admin.php?page=hts-light-dashboard' ) . '">Tableau de bord</a>',
        '<a href="' . admin_url( 'admin.php?page=hts-api-settings' ) . '">Réglages</a>'
    );
    // $links[] = '<a href="' . admin_url( 'admin.php?page=hts-upgrade' ) . '" style="color:#f59e0b;font-weight:600;">Passer à Full ↗</a>';
    return $links;
} );

/* =========================================================================
 * ADMIN — Enqueue scripts/styles + AJAX nonce
 * ====================================================================== */

add_action( 'admin_enqueue_scripts', function( $hook ) {
    // Only load HTS assets on HTS admin pages + post editor
    $hts_pages = array(
        'toplevel_page_hts-light-dashboard',
        'hack-the-seo_page_hts-seo-settings',
        'hack-the-seo_page_hts-redirections',
        'hack-the-seo_page_hts-analytics',
        'hack-the-seo_page_hts-cocon-commander',
        'hack-the-seo_page_hts-cannibalization',
        'hack-the-seo_page_hts-planning',
    );
    $is_hts_page = in_array( $hook, $hts_pages, true )
        || in_array( $hook, array( 'post.php', 'post-new.php' ), true );

    if ( ! $is_hts_page ) return;

    // Admin CSS
    if ( file_exists( HTS__PLUGIN_DIR . 'admin/css/hts-cockpit.css' ) ) {
        wp_enqueue_style( 'hts-cockpit', HTS__PLUGIN_URL . 'admin/css/hts-cockpit.css', array(), HTS__VERSION );
    }

    // Job Poller JS (batch processing)
    if ( file_exists( HTS__PLUGIN_DIR . 'admin/js/hts-job-poller.js' ) ) {
        wp_enqueue_script( 'hts-job-poller', HTS__PLUGIN_URL . 'admin/js/hts-job-poller.js', array(), HTS__VERSION, true );
    }

    // AJAX nonce for HTS admin pages
    wp_localize_script( 'jquery', 'htsAdmin', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'hts_admin_nonce' ),
    ) );
} );

/* =========================================================================
 * ONBOARDING — Redirect to wizard on first install
 * ====================================================================== */

// Redirect to onboarding on first admin load after activation
add_action( 'admin_init', function() {
    // Auto-configure on plugin upgrade (new version detected)
    $stored_version = get_option( 'hts_light_version', '0' );
    if ( version_compare( $stored_version, HTS__VERSION, '<' ) ) {
        update_option( 'hts_light_version', HTS__VERSION, false );
        if ( function_exists( 'hts_auto_configure_defaults' ) ) {
            hts_auto_configure_defaults();
        }
    }

    if ( ! get_transient( 'hts_onboarding_redirect' ) ) return;
    delete_transient( 'hts_onboarding_redirect' );
    if ( get_option( 'hts_onboarding_done' ) ) return;
    if ( wp_doing_ajax() || ! is_admin() ) return;
    if ( isset( $_GET['activate-multi'] ) ) return;
    wp_safe_redirect( admin_url( 'admin.php?page=hts-onboarding' ) );
    exit;
} );

// Register hidden onboarding page (no parent = not in menu)
add_action( 'admin_menu', function() {
    add_submenu_page(
        '', // Hidden — not in sidebar
        'Configuration Hack The SEO',
        'Configuration',
        'manage_options',
        'hts-onboarding',
        'hts_light_render_onboarding'
    );
}, 5 );

function hts_light_render_onboarding() {
    include HTS__PLUGIN_DIR . 'admin/partials/onboarding.php';
}

/**
 * Get OpenAI API key — supports wp-config.php constant + database option.
 */
function hts_get_openai_key() {
    if ( defined( 'HTS_OPENAI_API_KEY' ) && HTS_OPENAI_API_KEY ) {
        return HTS_OPENAI_API_KEY;
    }
    return get_option( 'hts_openai_api_key', '' );
}

/**
 * Get Anthropic API key — supports wp-config.php constant + database option.
 * Centralizes key retrieval so all modules use the same source.
 */
function hts_get_anthropic_key() {
    if ( defined( 'HTS_ANTHROPIC_API_KEY' ) && HTS_ANTHROPIC_API_KEY ) {
        return HTS_ANTHROPIC_API_KEY;
    }
    return get_option( 'hts_coach_api_key', '' );
}

/**
 * Get HTS SaaS API key — supports wp-config.php constant + database option.
 */
function hts_get_api_key() {
    if ( defined( 'HTS_API_KEY' ) && HTS_API_KEY ) {
        return HTS_API_KEY;
    }
    return get_option( 'hts_api_key', '' );
}

/**
 * Resolve a URL to a post ID with WooCommerce product fallback.
 *
 * WordPress core url_to_postid() fails on some WooCommerce product URLs
 * (custom permalinks, shop base, translated slugs). This helper adds a
 * slug-based DB lookup as a fallback.
 *
 * @param  string $url Full URL or path.
 * @return int         Post ID or 0.
 */
function hts_url_to_postid( $url ) {
    $post_id = url_to_postid( $url );
    if ( $post_id ) return $post_id;

    // Retry without trailing slash
    $post_id = url_to_postid( rtrim( $url, '/' ) );
    if ( $post_id ) return $post_id;

    // Fallback: extract slug from URL and query DB (catches WC products + CPTs)
    $path = wp_parse_url( $url, PHP_URL_PATH );
    if ( ! $path ) return 0;

    $slug = basename( untrailingslashit( $path ) );
    if ( ! $slug || $slug === '/' ) return 0;

    global $wpdb;
    $post_types = array( 'post', 'page' );
    if ( class_exists( 'WooCommerce' ) ) {
        $post_types[] = 'product';
    }
    $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
    $args         = array_merge( array( $slug ), $post_types );

    $found = $wpdb->get_var( $wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type IN ($placeholders) AND post_status = 'publish' LIMIT 1",
        ...$args
    ) );

    return $found ? (int) $found : 0;
}

// AJAX: Save API key from onboarding
add_action( 'wp_ajax_hts_save_api_key', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    $key = sanitize_text_field( $_POST['api_key'] ?? '' );
    if ( $key ) {
        update_option( 'hts_api_key', $key );
    }
    wp_send_json_success();
} );

// AJAX: Save OpenAI API key
add_action( 'wp_ajax_hts_save_openai_key', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Permission denied' ) );

    if ( defined( 'HTS_OPENAI_API_KEY' ) ) {
        wp_send_json_error( array( 'message' => 'La cle OpenAI est definie dans wp-config.php et ne peut pas etre modifiee ici.' ) );
    }

    $key = sanitize_text_field( wp_unslash( $_POST['openai_key'] ?? '' ) );
    update_option( 'hts_openai_api_key', $key, false );
    wp_send_json_success( array( 'saved' => true ) );
} );

// AJAX: Save agent config (toggle ON/OFF + mode review/auto)
add_action( 'wp_ajax_hts_save_agent_config', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    if ( ! class_exists( 'HTS_Workflow_Engine' ) ) wp_send_json_error( 'Workflow Engine non chargé' );

    $agent   = sanitize_key( $_POST['agent'] ?? '' );
    $enabled = isset( $_POST['enabled'] ) ? (int) $_POST['enabled'] : null;
    $mode    = isset( $_POST['mode'] ) ? sanitize_key( $_POST['mode'] ) : null;

    if ( ! $agent ) wp_send_json_error( 'Agent manquant' );

    // Session H: Capture old values for change log
    $old_vals = HTS_Workflow_Engine::get_agent_settings_with_defaults( $agent );

    // Settings JSON (P1 Session D — réglages par agent)
    $settings = null;
    if ( isset( $_POST['settings'] ) ) {
        $raw = stripslashes( $_POST['settings'] );
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            // Sanitize each value against schema
            $schema = HTS_Workflow_Engine::get_agent_settings_schema();
            $fields = $schema[ $agent ] ?? array();
            $clean  = array();
            foreach ( $fields as $field ) {
                $key = $field['key'];
                if ( ! array_key_exists( $key, $decoded ) ) continue;
                $val = $decoded[ $key ];
                switch ( $field['type'] ) {
                    case 'number':
                        $val = is_numeric( $val ) ? ( strpos( (string) $val, '.' ) !== false ? (float) $val : (int) $val ) : $field['default'];
                        if ( isset( $field['min'] ) ) $val = max( $field['min'], $val );
                        if ( isset( $field['max'] ) ) $val = min( $field['max'], $val );
                        break;
                    case 'select':
                        $allowed = array_keys( $field['options'] ?? array() );
                        if ( ! in_array( (string) $val, $allowed, true ) ) $val = $field['default'];
                        break;
                    case 'toggle':
                        $val = (bool) $val;
                        break;
                    case 'password':
                        $val = sanitize_text_field( $val );
                        break;
                    case 'textarea':
                        $val = mb_substr( sanitize_textarea_field( $val ), 0, 500 );
                        break;
                    default:
                        $val = sanitize_text_field( $val );
                }
                $clean[ $key ] = $val;
            }
            $settings = $clean;
        }
    }

    HTS_Workflow_Engine::update_agent_config( $agent, $enabled, $mode, $settings );

    // ── Sync image agent settings → hts_image_settings (source of truth for image generation) ──
    if ( $agent === 'image' && $settings !== null && is_array( $settings ) ) {
        $img_opts = get_option( 'hts_image_settings', array() );
        // Map agent settings keys to hts_image_settings keys (same names)
        $sync_keys = array(
            'image_provider', 'openai_model', 'flux_model', 'flux_api_key', 'pexels_api_key',
            'featured_enabled', 'featured_source', 'featured_style', 'featured_quality',
            'featured_text_overlay', 'incontent_enabled', 'incontent_count', 'incontent_quality',
            'incontent_types', 'incontent_position', 'extra_instructions',
        );
        // Password fields: keep existing value if new value is empty (prevents accidental wipe)
        $password_keys = array( 'flux_api_key', 'pexels_api_key' );
        foreach ( $sync_keys as $sk ) {
            if ( array_key_exists( $sk, $settings ) ) {
                // Don't overwrite a saved password with empty string
                if ( in_array( $sk, $password_keys, true ) && empty( $settings[ $sk ] ) && ! empty( $img_opts[ $sk ] ) ) {
                    // Also update settings array so it gets saved back to agent table with the value
                    $settings[ $sk ] = $img_opts[ $sk ];
                    continue;
                }
                $img_opts[ $sk ] = $settings[ $sk ];
            }
        }
        update_option( 'hts_image_settings', $img_opts, false );

        // Also re-save agent settings with preserved password values
        HTS_Workflow_Engine::update_agent_config( $agent, null, null, $settings );
    }

    // ── Session H : Log agent settings changes for audit ──
    $changes = array();
    if ( $enabled !== null ) $changes[] = 'enabled → ' . ( $enabled ? 'oui' : 'non' );
    if ( $mode !== null )    $changes[] = 'mode → ' . $mode;
    if ( $settings !== null && is_array( $settings ) ) {
        foreach ( $settings as $sk => $sv ) {
            if ( isset( $old_vals[ $sk ] ) && $old_vals[ $sk ] !== $sv ) {
                $changes[] = $sk . ' : ' . wp_json_encode( $old_vals[ $sk ] ) . ' → ' . wp_json_encode( $sv );
            } elseif ( ! isset( $old_vals[ $sk ] ) ) {
                $changes[] = $sk . ' → ' . wp_json_encode( $sv );
            }
        }
    }
    if ( ! empty( $changes ) ) {
        $log = get_option( 'hts_agent_settings_log', array() );
        $log[] = array(
            'date'    => gmdate( 'c' ),
            'user'    => wp_get_current_user()->user_login,
            'agent'   => $agent,
            'changes' => $changes,
        );
        // Keep last 200 entries
        if ( count( $log ) > 200 ) $log = array_slice( $log, -200 );
        update_option( 'hts_agent_settings_log', $log, false );
    }

    wp_send_json_success( array( 'agent' => $agent ) );
} );

// ═══ AJAX: Export agent settings (Session G) ═══
add_action( 'wp_ajax_hts_export_agent_settings', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    if ( ! class_exists( 'HTS_Workflow_Engine' ) ) wp_send_json_error( 'Workflow Engine non chargé' );

    $schema = HTS_Workflow_Engine::get_agent_settings_schema();
    $export = array( '_hts_agent_export' => true, '_version' => HTS__VERSION, '_date' => gmdate( 'c' ), 'agents' => array() );
    foreach ( $schema as $agent_key => $fields ) {
        $vals = HTS_Workflow_Engine::get_agent_settings_with_defaults( $agent_key );
        $export['agents'][ $agent_key ] = $vals;
    }
    wp_send_json_success( $export );
} );

// ═══ AJAX: Import agent settings (Session G) ═══
add_action( 'wp_ajax_hts_import_agent_settings', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    if ( ! class_exists( 'HTS_Workflow_Engine' ) ) wp_send_json_error( 'Workflow Engine non chargé' );

    $raw = stripslashes( $_POST['payload'] ?? '' );
    $payload = json_decode( $raw, true );
    if ( ! is_array( $payload ) || empty( $payload['_hts_agent_export'] ) ) {
        wp_send_json_error( 'Format invalide' );
    }

    $agents = $payload['agents'] ?? array();
    $schema = HTS_Workflow_Engine::get_agent_settings_schema();
    $imported = 0;

    foreach ( $agents as $agent_key => $settings ) {
        if ( ! isset( $schema[ $agent_key ] ) ) continue;
        if ( ! is_array( $settings ) ) continue;

        // Sanitize against schema
        $fields = $schema[ $agent_key ];
        $clean  = array();
        foreach ( $fields as $field ) {
            $key = $field['key'];
            if ( ! array_key_exists( $key, $settings ) ) continue;
            $val = $settings[ $key ];
            switch ( $field['type'] ) {
                case 'number':
                    $val = is_numeric( $val ) ? ( strpos( (string) $val, '.' ) !== false ? (float) $val : (int) $val ) : $field['default'];
                    if ( isset( $field['min'] ) ) $val = max( $field['min'], $val );
                    if ( isset( $field['max'] ) ) $val = min( $field['max'], $val );
                    break;
                case 'select':
                    $allowed = array_keys( $field['options'] ?? array() );
                    if ( ! in_array( (string) $val, $allowed, true ) ) $val = $field['default'];
                    break;
                case 'toggle':
                    $val = (bool) $val;
                    break;
                default:
                    $val = sanitize_text_field( $val );
            }
            $clean[ $key ] = $val;
        }

        if ( ! empty( $clean ) ) {
            HTS_Workflow_Engine::update_agent_config( $agent_key, null, null, $clean );
            $imported++;
        }
    }

    wp_send_json_success( array( 'imported' => $imported ) );
} );

// ═══ AJAX: Agent settings change history (Session H) ═══
add_action( 'wp_ajax_hts_agent_settings_history', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    $log   = get_option( 'hts_agent_settings_log', array() );
    $agent = isset( $_POST['agent'] ) ? sanitize_key( $_POST['agent'] ) : '';

    // Filter by agent if specified
    if ( $agent ) {
        $log = array_values( array_filter( $log, function( $e ) use ( $agent ) {
            return ( $e['agent'] ?? '' ) === $agent;
        } ) );
    }

    // Return last 50 entries, newest first
    $log = array_reverse( array_slice( $log, -50 ) );

    wp_send_json_success( array( 'history' => $log ) );
} );

// ═══ AJAX: Save notification settings (Session H — unified settings) ═══
add_action( 'wp_ajax_hts_save_notif_settings', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    $enabled = sanitize_text_field( $_POST['enabled'] ?? '1' );
    $email   = sanitize_email( $_POST['email'] ?? '' );
    $freq    = sanitize_key( $_POST['frequency'] ?? 'weekly' );
    if ( ! in_array( $freq, array( 'daily', 'weekly', 'biweekly', 'monthly' ), true ) ) $freq = 'weekly';

    $sections = array();
    foreach ( array( 'wins', 'alerts', 'kpis', 'gsc' ) as $s ) {
        $sections[ $s ] = ( $_POST[ 'section_' . $s ] ?? '1' ) === '1' ? '1' : '0';
    }

    update_option( 'hts_digest_enabled', $enabled );
    if ( $email ) update_option( 'hts_notif_email', $email );
    update_option( 'hts_notif_settings', array( 'frequency' => $freq, 'sections' => $sections ), false );

    wp_send_json_success( array( 'saved' => true ) );
} );

// AJAX: Save guardrails (max actions, budget, traffic threshold, coach budget, + P4 Session D)
add_action( 'wp_ajax_hts_save_guardrails', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    $max_actions  = max( 1, min( 100, (int) ( $_POST['max_actions'] ?? 10 ) ) );
    $max_budget   = max( 1, min( 1000, (float) ( $_POST['max_budget'] ?? 50 ) ) );
    $traffic_thr  = max( 0, min( 10000, (int) ( $_POST['traffic_thr'] ?? 100 ) ) );
    $coach_budget = max( 1000, min( 500000, (int) ( $_POST['coach_budget'] ?? 100000 ) ) );

    // P4 — Nouveaux garde-fous
    $max_rewrites = max( 0, min( 50, (int) ( $_POST['max_rewrites'] ?? 2 ) ) );
    $auto_hours_start = max( 0, min( 23, (int) ( $_POST['auto_hours_start'] ?? 0 ) ) );
    $auto_hours_end   = max( 0, min( 23, (int) ( $_POST['auto_hours_end'] ?? 23 ) ) );

    // Blacklist de pages (IDs)
    $blacklist_raw = sanitize_text_field( $_POST['blacklist_pages'] ?? '' );
    $blacklist_ids = array_values( array_unique( array_filter( array_map( 'absint', explode( ',', $blacklist_raw ) ) ) ) );

    update_option( 'hts_workflow_max_actions_per_week', $max_actions );
    update_option( 'hts_workflow_max_budget_month', $max_budget );
    update_option( 'hts_workflow_traffic_threshold', $traffic_thr );
    update_option( 'hts_workflow_max_rewrites_per_week', $max_rewrites );
    update_option( 'hts_workflow_auto_hours_start', $auto_hours_start );
    update_option( 'hts_workflow_auto_hours_end', $auto_hours_end );
    update_option( 'hts_workflow_blacklist_pages', $blacklist_ids );

    if ( class_exists( 'HTS_Coach' ) && method_exists( 'HTS_Coach', 'set_monthly_budget' ) ) {
        HTS_Coach::set_monthly_budget( $coach_budget );
    } else {
        update_option( 'hts_coach_monthly_budget', $coach_budget );
    }

    wp_send_json_success();
} );

// AJAX: Finish onboarding — save all settings
add_action( 'wp_ajax_hts_onboarding_finish', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    // Save separator
    $sep = sanitize_text_field( $_POST['separator'] ?? '—' );
    $allowed_seps = array( '—', '|', '-', '·', '»' );
    if ( in_array( $sep, $allowed_seps, true ) ) {
        update_option( 'hts_title_separator', $sep );
    }

    // Save module toggles
    $modules_json = stripslashes( $_POST['modules'] ?? '{}' );
    $modules = json_decode( $modules_json, true );
    if ( is_array( $modules ) ) {
        $module_map = array(
            'meta_tags' => 'hts_module_meta_tags',
            'schema'    => 'hts_module_schema',
            'sitemap'   => 'hts_module_sitemap',
            'redirects' => 'hts_module_redirects',
            'canonical' => 'hts_module_canonical',
        );
        foreach ( $module_map as $key => $option ) {
            if ( isset( $modules[ $key ] ) ) {
                update_option( $option, $modules[ $key ] ? '1' : '0' );
            }
        }
    }

    // Mark onboarding as done
    update_option( 'hts_onboarding_done', time() );
    // Force sitemap flush after onboarding
    update_option( 'hts_sitemap_flush_needed', true );

    hts_add_log( 'Onboarding terminé — Hack The SEO configuré', 'success', 'system' );
    wp_send_json_success();
} );

// AJAX: Mark onboarding v2 (first wins) as complete
add_action( 'wp_ajax_hts_onboarding_v2_done', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    update_option( 'hts_onboarding_v2_done', time() );
    hts_add_log( 'Onboarding v2 terminé — Premières victoires SEO complétées', 'success', 'system' );
    wp_send_json_success();
} );

// AJAX: Get worst articles for onboarding (wrapper with admin nonce)
add_action( 'wp_ajax_hts_onboarding_save_agents', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    $agents_raw = isset( $_POST['agents'] ) ? sanitize_text_field( wp_unslash( $_POST['agents'] ) ) : '{}';
    $agents = json_decode( $agents_raw, true );
    if ( ! is_array( $agents ) ) $agents = array();

    // Save each agent enabled/disabled state
    $orch = get_option( 'hts_orchestrator_settings', array() );
    if ( ! isset( $orch['agents'] ) || ! is_array( $orch['agents'] ) ) {
        $orch['agents'] = array();
    }
    foreach ( $agents as $agent_key => $enabled ) {
        $agent_key = sanitize_key( $agent_key );
        if ( ! isset( $orch['agents'][ $agent_key ] ) || ! is_array( $orch['agents'][ $agent_key ] ) ) {
            $orch['agents'][ $agent_key ] = array();
        }
        $orch['agents'][ $agent_key ]['enabled'] = (bool) $enabled;
    }
    update_option( 'hts_orchestrator_settings', $orch );

    hts_add_log( 'Onboarding : configuration des agents enregistrée', 'info', 'system' );
    wp_send_json_success();
} );

// AJAX: Get worst articles for onboarding (wrapper with admin nonce)
add_action( 'wp_ajax_hts_onboarding_worst', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    if ( ! class_exists( 'HTS_Global_Score' ) ) {
        wp_send_json_error( 'Module Global Score non disponible' );
    }

    $gs = new HTS_Global_Score();
    $worst = $gs->get_worst_articles( 5 );
    wp_send_json_success( array(
        'articles' => $worst,
        'count'    => count( $worst ),
    ) );
} );

// AJAX: Regen sitemap for onboarding pipeline
add_action( 'wp_ajax_hts_onboarding_regen_sitemap', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    if ( class_exists( 'HTS_Sitemap' ) ) {
        $sitemap = new HTS_Sitemap();
        if ( method_exists( $sitemap, 'regenerate' ) ) {
            $sitemap->regenerate();
        }
    }
    wp_send_json_success( array( 'message' => 'Sitemap régénéré' ) );
} );

// AJAX: Flush rewrites for onboarding pipeline
add_action( 'wp_ajax_hts_onboarding_flush_rewrites', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    flush_rewrite_rules( false );
    wp_send_json_success( array( 'message' => 'Permaliens mis à jour' ) );
} );

// AJAX: Health check for onboarding pipeline
add_action( 'wp_ajax_hts_onboarding_health_check', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

    if ( ! class_exists( 'HTS_Health_Check' ) ) {
        wp_send_json_success( array( 'percent' => '—', 'message' => 'Module indisponible' ) );
    }

    $hc = new HTS_Health_Check();
    if ( method_exists( $hc, 'run_all_tests' ) ) {
        $results = $hc->run_all_tests();
        $total   = count( $results );
        $passed  = 0;
        foreach ( $results as $r ) {
            if ( ! empty( $r['passed'] ) || ( isset( $r['status'] ) && $r['status'] === 'pass' ) ) {
                $passed++;
            }
        }
        $percent = $total > 0 ? round( ( $passed / $total ) * 100 ) : 0;
        wp_send_json_success( array( 'percent' => $percent, 'total' => $total, 'passed' => $passed ) );
    }

    wp_send_json_success( array( 'percent' => '—' ) );
} );

// v2.5.14: AJAX — Save monthly publication goal
add_action( 'wp_ajax_hts_save_monthly_goal', function() {
    check_ajax_referer( 'hts_admin_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
    $goal = isset( $_POST['goal'] ) ? absint( $_POST['goal'] ) : 0;
    if ( $goal < 1 || $goal > 100 ) wp_send_json_error( 'Valeur entre 1 et 100' );
    update_option( 'hts_monthly_goal', $goal, false );
    wp_send_json_success( array( 'goal' => $goal ) );
} );

/* =========================================================================
 * ADMIN — Branding footer on HTS pages
 * ====================================================================== */

/* Admin footer text removed — was overlapping page content */
add_action( 'admin_head', function() {
    if ( ! isset( $_GET['page'] ) ) return;
    $hts_pages = array( 'hts-light-dashboard', 'hts-seo-settings', 'hts-api-settings', 'hts-redirections', 'hts-analytics', 'hts-onboarding', 'hts-upgrade', 'hts-cocon-commander', 'hts-cannibalization', 'hts-planning' );
    if ( in_array( $_GET['page'], $hts_pages, true ) ) {
        echo '<style>#wpfooter{display:none !important;}</style>';
        if ( class_exists( 'HTS_DS' ) ) { HTS_DS::css(); }
    }
} );

/* =========================================================================
 * HELPER FUNCTIONS — Required by modules
 * ====================================================================== */

/**
 * Get the list of post types eligible for SEO features.
 *
 * Merges sitemap settings (user-chosen) with a fallback of all public
 * post types (minus attachment).  Cached per request.
 *
 * @param bool $names_only  Return slugs only (true) or WP_Post_Type objects (false).
 * @return array
 */
if ( ! function_exists( 'hts_get_seo_post_types' ) ) {
    function hts_get_seo_post_types( $names_only = true ) {
        static $cache_names = null, $cache_objects = null;

        if ( $names_only && $cache_names !== null ) return $cache_names;
        if ( ! $names_only && $cache_objects !== null ) return $cache_objects;

        // Start with sitemap settings if available (user has explicitly chosen)
        $sm_types = array();
        if ( class_exists( 'HTS_Sitemap' ) ) {
            $sm = HTS_Sitemap::get_settings();
            if ( ! empty( $sm['post_types'] ) && is_array( $sm['post_types'] ) ) {
                $sm_types = $sm['post_types'];
            }
        }

        // All public post types (minus attachment)
        $all_pts = get_post_types( array( 'public' => true ), 'objects' );
        unset( $all_pts['attachment'] );

        // If no sitemap config, use all public types; otherwise intersect
        if ( empty( $sm_types ) ) {
            $sm_types = array_keys( $all_pts );
        } else {
            // Always include post/page even if somehow removed, plus configured CPTs
            $sm_types = array_unique( array_merge( array( 'post', 'page' ), $sm_types ) );
            // Validate they actually exist
            $sm_types = array_intersect( $sm_types, array_keys( $all_pts ) );
        }

        $sm_types = array_values( $sm_types );

        $cache_names   = $sm_types;
        $cache_objects = array();
        foreach ( $sm_types as $slug ) {
            if ( isset( $all_pts[ $slug ] ) ) {
                $cache_objects[ $slug ] = $all_pts[ $slug ];
            }
        }

        return $names_only ? $cache_names : $cache_objects;
    }
}

/**
 * Build an SQL IN(...) clause for the SEO post types.
 * Returns e.g. "IN ('post','page','product')"
 *
 * @return string
 */
if ( ! function_exists( 'hts_sql_post_types_in' ) ) {
    function hts_sql_post_types_in() {
        global $wpdb;
        $types = hts_get_seo_post_types();
        // Safety: never produce an empty IN() — fallback to post,page
        if ( empty( $types ) ) {
            $types = array( 'post', 'page' );
        }
        $escaped = array_map( function( $t ) use ( $wpdb ) {
            return $wpdb->prepare( '%s', $t );
        }, $types );
        return 'IN (' . implode( ',', $escaped ) . ')';
    }
}

if ( ! function_exists( 'hts_add_log' ) ) {
    function hts_add_log( $message, $type = 'info', $source = 'sync' ) {
        $logs = get_option( 'hts_activity_logs' );
        if ( ! is_array( $logs ) ) $logs = array();

        array_unshift( $logs, array(
            'message' => sanitize_text_field( $message ),
            'type'    => $type,
            'source'  => $source,
            'time'    => current_time( 'Y-m-d H:i:s' ),
        ) );

        $logs = array_slice( $logs, 0, 200 );
        update_option( 'hts_activity_logs', $logs );

        // Sprint 5.3: miroir vers debug.log (error/warn toujours, info/debug seulement pour coach/workflow)
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $log_to_file = in_array( $type, array( 'error', 'warn' ), true )
                || in_array( $source, array( 'coach', 'workflow', 'inbox' ), true );
            if ( $log_to_file ) {
                error_log( sprintf( '[HTS][%s][%s] %s', strtoupper( $type ), $source, $message ) );
            }
        }
    }
}

if ( ! function_exists( 'hts_get_logs' ) ) {
    function hts_get_logs( $limit = 20 ) {
        $logs = get_option( 'hts_activity_logs' );
        if ( ! is_array( $logs ) ) return array();
        return array_slice( $logs, 0, $limit );
    }
}

if ( ! function_exists( 'hts_debug_log' ) ) {
    /**
     * Centralized debug logger — only writes to debug.log when WP_DEBUG is active.
     *
     * @param string $message Log message.
     * @param string $source  Module source identifier (e.g. 'coach', 'cocon', 'workflow').
     */
    function hts_debug_log( $message, $source = 'hts' ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( sprintf( '[HTS][%s] %s', $source, $message ) );
        }
    }
}

if ( ! function_exists( 'hts_word_count' ) ) {
    /**
     * Locale-aware word count — handles French accented characters correctly.
     *
     * str_word_count() without the 3rd parameter treats accented chars (é, è, ç, etc.)
     * as word boundaries, causing undercounting on French/multilingual content.
     *
     * @since 2.5.9
     * @param string $text Text to count words in (should be plain text, not HTML).
     * @return int Word count.
     */
    function hts_word_count( $text ) {
        if ( empty( $text ) ) return 0;
        return str_word_count( $text, 0, 'àâäéèêëïîôùûüÿçœæÀÂÄÉÈÊËÏÎÔÙÛÜŸÇŒÆ' );
    }
}

if ( ! function_exists( 'hts_acquire_lock' ) ) {
    /**
     * Atomic lock via wp_options — works reliably with any object cache.
     *
     * Unlike transients (stored in Redis/Memcached on cached sites, with
     * unreliable TTL enforcement), wp_options with autoload=no always hits
     * the database, making the lock reliable across all hosting setups.
     *
     * @since 2.5.9
     * @param string $lock_name Lock identifier (e.g. 'hts_plans_write_lock').
     * @param int    $ttl       Max lock duration in seconds (safety net). Default 10.
     * @param int    $retries   Max retries before giving up. Default 10.
     * @param int    $wait_ms   Milliseconds between retries. Default 150.
     * @return bool True if lock acquired, false if timeout.
     */
    function hts_acquire_lock( $lock_name, $ttl = 10, $retries = 10, $wait_ms = 150 ) {
        $option_key = '_hts_lock_' . $lock_name;
        for ( $i = 0; $i <= $retries; $i++ ) {
            $current = get_option( $option_key );
            // Lock is free or expired
            if ( ! $current || ( microtime( true ) - (float) $current ) > $ttl ) {
                update_option( $option_key, microtime( true ), false ); // autoload = no
                return true;
            }
            if ( $i < $retries ) {
                usleep( $wait_ms * 1000 );
            }
        }
        return false;
    }
}

if ( ! function_exists( 'hts_release_lock' ) ) {
    /**
     * Release a lock acquired with hts_acquire_lock().
     *
     * @since 2.5.9
     * @param string $lock_name Lock identifier.
     */
    function hts_release_lock( $lock_name ) {
        delete_option( '_hts_lock_' . $lock_name );
    }
}

if ( ! function_exists( 'hts_get_stopwords' ) ) {
    /**
     * Get stopwords for a language (or all if no lang specified).
     * Used by cannibalization, meta-score, anchor extraction.
     *
     * @since 2.5.9
     * @param string $lang 2-letter code (fr, en, de, es, it, pt, nl). Empty = all merged.
     * @return array Flat array of stopwords.
     */
    function hts_get_stopwords( $lang = '' ) {
        $all = array(
            'fr' => array( 'le','la','les','de','du','des','un','une','et','en','à','au','aux','pour','par','sur','dans','avec','que','qui','ce','cette','ces','son','sa','ses','mon','ma','mes','nous','vous','ils','elles','on','est','sont','être','avoir','comment','pourquoi','quel','quelle','quels','quelles','tout','tous','très','ne','pas','ni','dont','où','ou','se' ),
            'en' => array( 'the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','is','are','was','were','be','been','being','have','has','had','do','does','did','will','would','could','should','may','might','can','this','that','these','those','it','its','how','what','why','which','who','you','my','your','we','our','if','no','not' ),
            'de' => array( 'der','die','das','ein','eine','einer','eines','und','oder','aber','in','im','an','am','auf','für','von','zu','mit','bei','nach','über','unter','vor','aus','um','als','wie','wenn','dass','den','dem','des','sich','ist','sind','war','hat','wird','kann','muss','soll','auch','nicht','noch','nur','sehr','schon' ),
            'es' => array( 'el','la','los','las','un','una','unos','unas','y','o','de','del','en','a','al','por','para','con','sin','que','como','más','pero','su','sus','se','es','son','está','son','ha','hay','fue','ser','estar','este','esta','estos','estas','ese','esa','todo','no','muy','también','ya' ),
            'it' => array( 'il','lo','la','i','gli','le','un','una','uno','e','o','di','del','della','dei','delle','in','a','al','alla','per','con','su','da','che','come','non','più','ma','anche','suo','sua','suoi','sue','si','è','sono','ha','questo','questa','questi','queste','tutto','molto','già' ),
            'pt' => array( 'o','a','os','as','um','uma','uns','umas','e','ou','de','do','da','dos','das','em','no','na','nos','nas','por','para','com','sem','que','como','mais','mas','seu','sua','seus','suas','se','é','são','está','foi','ser','estar','este','esta','estes','estas','todo','não','muito','também','já' ),
            'nl' => array( 'de','het','een','en','of','van','in','op','aan','met','voor','door','uit','bij','om','als','maar','ook','nog','wel','niet','zijn','is','was','wordt','heeft','kan','moet','zal','deze','dit','die','dat','ze','hij','zij','we','je','uw','meer','veel','zeer' ),
        );

        if ( $lang && isset( $all[ $lang ] ) ) {
            return $all[ $lang ];
        }

        // No lang or unknown lang: merge all
        $merged = array();
        foreach ( $all as $words ) {
            $merged = array_merge( $merged, $words );
        }
        return array_unique( $merged );
    }
}

if ( ! function_exists( 'hts_get_bad_end_words' ) ) {
    /**
     * Words that should NOT appear at the end of an anchor text.
     * Used by anchor extraction to avoid truncated anchors like "guide de".
     *
     * @since 2.5.9
     * @param string $lang 2-letter code. Empty = all merged.
     * @return array Flipped array for fast isset() lookup.
     */
    function hts_get_bad_end_words( $lang = '' ) {
        $all = array(
            'fr' => array( 'le','la','les','un','une','des','du','de','d','l','et','en','à','a','au','aux','ce','cette','ces','se','sa','son','ses','sur','sous','dans','par','pour','avec','sans','ou','où','qui','que','dont','ne','pas','ni','vous','nous','ils','elles','on','est','sont' ),
            'en' => array( 'the','a','an','and','or','of','in','on','at','to','for','by','with','from','is','are','it','its','this','that','but','not','as','be' ),
            'de' => array( 'der','die','das','ein','eine','und','oder','in','im','an','am','auf','für','von','zu','mit','bei','nach','über','unter','vor','aus','um','als','wie','ist','sind','nicht' ),
            'es' => array( 'el','la','los','las','un','una','y','o','de','del','en','a','al','por','para','con','que','como','no','es','su','sus' ),
            'it' => array( 'il','lo','la','i','gli','le','un','una','e','o','di','del','della','in','a','per','con','che','non','è','su' ),
            'pt' => array( 'o','a','os','as','um','uma','e','ou','de','do','da','em','no','na','por','para','com','que','não','é','se' ),
            'nl' => array( 'de','het','een','en','of','van','in','op','aan','met','voor','door','uit','bij','om','als','niet','is' ),
        );

        if ( $lang && isset( $all[ $lang ] ) ) {
            return array_flip( $all[ $lang ] );
        }

        $merged = array();
        foreach ( $all as $words ) {
            $merged = array_merge( $merged, $words );
        }
        return array_flip( array_unique( $merged ) );
    }
}

/* =========================================================================
 * LOAD MODULES — Deferred to plugins_loaded for safety
 * ====================================================================== */

add_action( 'plugins_loaded', function() {

    // ── Shared helpers (always needed) ──
    require_once HTS__PLUGIN_DIR . 'includes/class-hts-language.php';
    require_once HTS__PLUGIN_DIR . 'includes/class-hts-icons.php';
    require_once HTS__PLUGIN_DIR . 'modules/class-hts-compat.php';
    require_once HTS__PLUGIN_DIR . 'modules/class-hts-content-extractor.php';

    // ══════════════════════════════════════════════════════════════════════
    // FRONTEND-SAFE MODULES — loaded on EVERY request (visitor + admin)
    // These have wp_head / the_content / template_redirect / init hooks
    // ══════════════════════════════════════════════════════════════════════
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-meta-tags.php';       if ( file_exists( $f ) ) { require_once $f; } // wp_head — meta, og:tags
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-schema-markup.php';   if ( file_exists( $f ) ) { require_once $f; } // wp_head — JSON-LD
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-canonical.php';       if ( file_exists( $f ) ) { require_once $f; } // wp_head — canonical URL
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-redirects.php';       if ( file_exists( $f ) ) { require_once $f; } // template_redirect — 301/302
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-robots.php';          if ( file_exists( $f ) ) { require_once $f; } // wp_head — robots meta
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-breadcrumbs.php';     if ( file_exists( $f ) ) { require_once $f; } // the_content — breadcrumbs
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-sitemap.php';         if ( file_exists( $f ) ) { require_once $f; } // init — rewrite rules sitemap
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-toc.php';             if ( file_exists( $f ) ) { require_once $f; } // the_content — table of contents
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-impact-tracker.php';  if ( file_exists( $f ) ) { require_once $f; } // wp_footer — JS tracking
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-llmstxt.php';         if ( file_exists( $f ) ) { require_once $f; } // init — serves llms.txt
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-indexnow.php';        if ( file_exists( $f ) ) { require_once $f; } // init — serves IndexNow key
    $f = HTS__PLUGIN_DIR . 'modules/class-hts-api-receiver.php';  if ( file_exists( $f ) ) { require_once $f; } // REST API — must be outside admin gate
    // Init API Receiver early so REST routes are registered on /wp-json/ requests
    if ( class_exists( 'HTS_API_Receiver' ) ) { ( new HTS_API_Receiver() )->init(); }

    // ══════════════════════════════════════════════════════════════════════
    // ADMIN / AJAX / CRON ONLY — not loaded on frontend visitor pages
    // Saves ~3.7 MB of PHP parsing per frontend page load (−87%)
    // ══════════════════════════════════════════════════════════════════════
    if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-remote-client.php';        if ( file_exists( $f ) ) { require_once $f; } // Phase 3B: SaaS migration bridge
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';       if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-cockpit.php';             if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-coach.php';               if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-job-runner.php';          if ( file_exists( $f ) ) { require_once $f; }
        // Cleanup expired jobs on health cron
        add_action( 'hts_health_cron', function() { if ( class_exists( 'HTS_Job_Runner' ) ) HTS_Job_Runner::cleanup(); } );
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-cocon.php';               if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-cocon-commander.php';     if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-workflow-engine.php';     if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-test-suite.php';          if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-seo-panel.php';           if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-internal-linking.php';    if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-auto-write.php';          if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-migration-wizard.php';    if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-diagnostic.php';          if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-health-check.php';        if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-gsc-connect.php';         if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-notifications.php';       if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-global-score.php';        if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-meta-score.php';          if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-on-page-score.php';       if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-content-writer.php';      if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-embeddings.php';          if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-freshness.php';           if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-geo-score.php';           if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-content-refresh.php';     if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-cannibalization-merge.php'; if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-article-pipeline.php';    if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-standalone-article.php';  if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-cannibalization.php';     if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-audit-trail.php';         if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-decision-engine.php';     if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-feedback-loop.php';       if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-strategy-engine.php';     if ( file_exists( $f ) ) { require_once $f; }
        // class-hts-api-receiver.php loaded above (outside admin gate) for REST API support
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-subscription.php';        if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-updater.php';             if ( file_exists( $f ) ) { require_once $f; }
        $f = HTS__PLUGIN_DIR . 'modules/class-hts-support-docs.php';        if ( file_exists( $f ) ) { require_once $f; } // Help center + chat widget
        require_once HTS__PLUGIN_DIR . 'admin/class-hts-synchronise-articles-admin.php';
    } // end admin/ajax/cron gate

    // ── Compat: detect competitors + admin warning ──
    add_action( 'admin_notices', array( 'HTS_Compat', 'maybe_warn_competitor_active' ) );

    // ══════════════════════════════════════════════════════════════════════
    // INITIALIZE FRONTEND-SAFE MODULES (always)
    // ══════════════════════════════════════════════════════════════════════
    ( new HTS_Schema_Markup() )->init();
    ( new HTS_Table_Of_Contents() )->init();
    ( new HTS_Meta_Tags() )->init();
    ( new HTS_Redirects() )->init();
    ( new HTS_Robots() )->init();
    ( new HTS_Breadcrumbs() )->init();
    new HTS_Canonical(); // __construct calls init() internally
    ( new HTS_Sitemap() )->init();
    ( new HTS_LLMs_Txt() )->init();
    ( new HTS_IndexNow() )->init();
    ( new HTS_Impact_Tracker() )->init();

    // ── P1A: Immediate sitemap generation on first activation ──
    if ( get_option( 'hts_sitemap_first_run' ) ) {
        delete_option( 'hts_sitemap_first_run' );
        if ( ! wp_next_scheduled( 'hts_sitemap_first_generation' ) ) {
            wp_schedule_single_event( time(), 'hts_sitemap_first_generation' );
        }
    }
    add_action( 'hts_sitemap_first_generation', function() {
        $sitemap = new HTS_Sitemap();
        $sitemap->init();
        $sitemap->cron_refresh();
        hts_add_log( 'Sitemap — première génération automatique effectuée', 'success', 'sitemap' );
    } );

    // ── Notice if DISABLE_WP_CRON is active ──
    if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
        add_action( 'admin_notices', function() {
            if ( ! current_user_can( 'manage_options' ) ) return;
            $screen = get_current_screen();
            if ( ! $screen || strpos( $screen->id, 'hts' ) === false ) return;
            echo '<div class="notice notice-warning"><p>';
            echo '<strong>Hack The SEO :</strong> <code>DISABLE_WP_CRON</code> est activé sur ce site. ';
            echo 'Les sitemaps ne se régénéreront pas automatiquement. ';
            echo 'Ajoutez un cron système : <code>*/30 * * * * wget -q -O - ' . esc_url( site_url( '/wp-cron.php?doing_wp_cron' ) ) . ' > /dev/null 2>&1</code>';
            echo '</p></div>';
        } );
    }

    // ── Webmaster verification codes (frontend wp_head) ──
    add_action( 'wp_head', function() {
        if ( is_admin() ) return;
        $wm = get_option( 'hts_webmaster_verification', array() );
        if ( ! empty( $wm['google'] ) )    echo '<meta name="google-site-verification" content="' . esc_attr( $wm['google'] ) . '">' . "\n";
        if ( ! empty( $wm['bing'] ) )      echo '<meta name="msvalidate.01" content="' . esc_attr( $wm['bing'] ) . '">' . "\n";
        if ( ! empty( $wm['pinterest'] ) ) echo '<meta name="p:domain_verify" content="' . esc_attr( $wm['pinterest'] ) . '">' . "\n";
        if ( ! empty( $wm['yandex'] ) )    echo '<meta name="yandex-verification" content="' . esc_attr( $wm['yandex'] ) . '">' . "\n";
    }, 1 );

    // ── OG default image fallback (frontend) ──
    add_filter( 'hts_og_image', function( $image, $post_id ) {
        if ( $image ) return $image;
        $default = get_option( 'hts_og_default_image', '' );
        return $default ?: $image;
    }, 10, 2 );

    // ══════════════════════════════════════════════════════════════════════
    // INITIALIZE ADMIN / AJAX / CRON MODULES
    // ══════════════════════════════════════════════════════════════════════
    if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {

        ( new HTS_Migration_Wizard() )->init();
        ( new HTS_SEO_Panel() )->init();
        ( new HTS_Cockpit() )->init();
        ( new HTS_Global_Score() )->init();
        ( new HTS_Meta_Score() )->init();
        ( new HTS_On_Page_Score() )->init();
        ( new HTS_Embeddings() )->init();
        ( new HTS_Cocon() )->init();
        ( new HTS_Cocon_Commander() )->init();
        ( new HTS_Standalone_Article() )->init();
        ( new HTS_Internal_Linking() )->init();
        ( new HTS_Audit_Trail() )->init();
        ( new HTS_Decision_Engine() )->init();
        ( new HTS_Feedback_Loop() )->init();
        ( new HTS_Strategy_Engine() )->init();
        new HTS_Workflow_Engine(); // __construct registers AJAX hooks
        HTS_Workflow_Engine::ensure_tables();
        ( new HTS_Freshness() )->init();
        ( new HTS_Geo_Score() )->init();
        ( new HTS_Content_Refresh() )->init();
        ( new HTS_Cannibalization_Merge() )->init();
        ( new HTS_Auto_Write() )->init();
        ( new HTS_Coach() )->init();
        // HTS_API_Receiver init moved outside admin gate (REST routes need to register on /wp-json/ requests)
        ( new HTS_Subscription() )->init();
        ( new HTS_Updater() )->init();
        ( new HTS_Diagnostic() )->init();
        ( new HTS_Health_Check() )->init();
        ( new HTS_GSC_Connect() )->init();
        ( new HTS_Notifications() )->init();
        ( new HTS_Test_Suite() )->init();

        // ── Cannibalization init ──
        $hts_cannibalization = new HTS_Cannibalization();
        $hts_cannibalization->init();

// ── Rollback redirections cannibalization ──
add_action( 'wp_ajax_hts_cannibal_rollback', function() {
	check_ajax_referer( 'hts_admin_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
	$history_idx = isset( $_POST['history_idx'] ) ? (int) $_POST['history_idx'] : -1;
	$hist = get_option( 'hts_cannibal_history', array() );
	if ( ! is_array( $hist ) || ! isset( $hist[ $history_idx ] ) ) {
		wp_send_json_error( 'Entrée introuvable.' );
	}
	$entry = $hist[ $history_idx ];
	if ( ! empty( $entry['rollbacked'] ) ) {
		wp_send_json_error( 'Déjà annulé.' );
	}

	// 1. Supprimer les redirections 301
	$rule_ids = isset( $entry['rule_ids'] ) ? $entry['rule_ids'] : array();
	$deleted = 0;
	if ( ! empty( $rule_ids ) ) {
		global $wpdb;
		$table = $wpdb->prefix . 'hts_redirect_rules';
		foreach ( $rule_ids as $rid ) {
			if ( $wpdb->delete( $table, array( 'id' => (int) $rid ) ) ) $deleted++;
		}
	}

	// 2. Remettre les paires en actif
	$pillar_id = isset( $entry['pillar_id'] ) ? (int) $entry['pillar_id'] : 0;
	$targets   = isset( $entry['targets'] ) ? array_map( 'intval', $entry['targets'] ) : array();
	if ( $pillar_id && ! empty( $targets ) && class_exists( 'HTS_Cannibalization' ) ) {
		$cannibal = new HTS_Cannibalization();
		$pairs_data = $cannibal->get_pairs();
		$pairs = isset( $pairs_data['pairs'] ) ? $pairs_data['pairs'] : array();
		$changed = false;
		foreach ( $pairs as &$pair ) {
			$a = (int) ( isset( $pair['post_a'] ) ? $pair['post_a'] : 0 );
			$b = (int) ( isset( $pair['post_b'] ) ? $pair['post_b'] : 0 );
			if ( ( in_array( $a, $targets, true ) && $b === $pillar_id ) || ( in_array( $b, $targets, true ) && $a === $pillar_id ) ) {
				$pair['status'] = 'active';
				if ( isset( $pair['action_taken'] ) ) unset( $pair['action_taken'] );
				$changed = true;
			}
		}
		unset( $pair );
		if ( $changed ) {
			$pairs_data['pairs'] = $pairs;
			update_option( 'hts_cannibal_pairs', $pairs_data, false );
		}
	}

	// 3. Marquer dans l'historique
	$hist[ $history_idx ]['rollbacked'] = true;
	update_option( 'hts_cannibal_history', $hist, false );

	// 4. Supprimer l'option groups pour forcer un rescan propre
	// Le JS déclenchera automatiquement un scan après le reload
	delete_option( 'hts_cannibal_groups' );

	if ( function_exists( 'hts_add_log' ) ) {
		hts_add_log( sprintf( 'Rollback : %d redirection(s) supprimée(s) (pilier #%d)', $deleted, $pillar_id ), 'warning', 'cannibalization' );
	}
	wp_send_json_success( array( 'deleted' => $deleted, 'needs_rescan' => true ) );
} );

// ── Change pillar (added S11 — handler inline, avoids modifying modules/) ──
add_action( 'wp_ajax_hts_cannibal_change_pillar', function() {
	check_ajax_referer( 'hts_admin_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
	$group_id      = sanitize_text_field( isset( $_POST['group_id'] ) ? $_POST['group_id'] : '' );
	$new_pillar_id = absint( isset( $_POST['new_pillar_id'] ) ? $_POST['new_pillar_id'] : 0 );
	if ( empty( $group_id ) || ! $new_pillar_id ) wp_send_json_error( 'Paramètres manquants.' );
	$post = get_post( $new_pillar_id );
	if ( ! $post ) wp_send_json_error( 'Page introuvable.' );
	$groups_data = get_option( 'hts_cannibal_groups', array( 'groups' => array() ) );
	$groups = isset( $groups_data['groups'] ) ? $groups_data['groups'] : array();
	$found = false;
	foreach ( $groups as &$group ) {
		if ( ! isset( $group['id'] ) || $group['id'] !== $group_id ) continue;
		$page_ids = array_column( isset( $group['pages'] ) ? $group['pages'] : array(), 'post_id' );
		if ( ! in_array( $new_pillar_id, array_map( 'intval', $page_ids ), true ) ) {
			wp_send_json_error( 'Cette page ne fait pas partie du groupe.' );
		}
		$group['pillar_id']    = $new_pillar_id;
		$group['pillar_title'] = get_the_title( $new_pillar_id );
		$found = true;
		break;
	}
	unset( $group );
	if ( ! $found ) wp_send_json_error( 'Groupe introuvable.' );
	$groups_data['groups'] = $groups;
	update_option( 'hts_cannibal_groups', $groups_data, false );
	if ( function_exists( 'hts_add_log' ) ) {
		hts_add_log( sprintf( 'Pilier du groupe "%s" changé → #%d (%s)', $group_id, $new_pillar_id, get_the_title( $new_pillar_id ) ), 'info', 'cannibalization' );
	}
	wp_send_json_success( array( 'group_id' => $group_id, 'new_pillar_id' => $new_pillar_id, 'pillar_title' => get_the_title( $new_pillar_id ) ) );
} );

// ── S11: Force fallback immédiat pour redirect/merge si agent cannibalization désactivé ──
// Le module utilise HTS_Workflow_Engine::propose() qui échoue silencieusement si l'agent
// n'est pas activé. Ce hook intercepte AVANT le handler du module (priorité 9 < 10 par défaut)
// et exécute les redirections directement si le workflow n'est pas disponible ou l'agent désactivé.
add_action( 'wp_ajax_hts_cannibal_group_action', function() {
	// S11: Exécution directe pour TOUTES les actions cannibalization.
	// Les gardes du Workflow Engine (traffic threshold, cooldown, cross-agent conflict)
	// ne sont pas pertinents ici — l'utilisateur a cliqué "Rediriger" et confirmé.
	// wp_send_json() appelle wp_die() → le handler du module ne s'exécute jamais.

	check_ajax_referer( 'hts_admin_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

	$group_id    = sanitize_text_field( isset( $_POST['group_id'] ) ? $_POST['group_id'] : '' );
	$action_type = sanitize_text_field( isset( $_POST['action_type'] ) ? $_POST['action_type'] : '' );
	$pillar_id   = absint( isset( $_POST['pillar_id'] ) ? $_POST['pillar_id'] : 0 );
	$selected    = isset( $_POST['selected_ids'] ) ? array_map( 'absint', (array) $_POST['selected_ids'] ) : array();

	if ( empty( $group_id ) || empty( $action_type ) ) wp_send_json_error( 'Paramètres manquants.' );

	// Charger le groupe
	$groups_data = get_option( 'hts_cannibal_groups', array( 'groups' => array() ) );
	$groups = isset( $groups_data['groups'] ) ? $groups_data['groups'] : array();
	$group = null;
	foreach ( $groups as $g ) {
		if ( isset( $g['id'] ) && $g['id'] === $group_id ) { $group = $g; break; }
	}
	if ( ! $group ) wp_send_json_error( 'Groupe introuvable.' );

	if ( ! $pillar_id ) {
		$pillar_id = isset( $group['pillar_id'] ) ? (int) $group['pillar_id'] : 0;
	}
	$page_ids = array_column( isset( $group['pages'] ) ? $group['pages'] : array(), 'post_id' );
	$targets = ! empty( $selected ) ? $selected : array_map( 'intval', $page_ids );
	$targets = array_diff( $targets, array( $pillar_id ) );

	$results = array( 'processed' => 0, 'errors' => 0, 'mode' => 'immediate', 'error_reasons' => array(), 'rule_ids' => array() );

	if ( $action_type === 'redirect_all' ) {
		if ( ! $pillar_id ) wp_send_json_error( 'Aucune page pilier sélectionnée.' );
		if ( ! class_exists( 'HTS_Redirects' ) ) {
			$results['errors'] = count( $targets );
			$results['error_reasons'][] = 'Le module de redirections n\'est pas disponible. Vérifiez que le plugin est bien à jour.';
			wp_send_json_success( $results );
		}
		$redir = new HTS_Redirects();
		if ( ! method_exists( $redir, 'add_redirect_rule' ) ) {
			$results['errors'] = count( $targets );
			$results['error_reasons'][] = 'La fonction de redirection est indisponible. Mettez à jour le plugin.';
			wp_send_json_success( $results );
		}
		$pillar_url = get_permalink( $pillar_id );
		if ( ! $pillar_url ) {
			$results['errors'] = count( $targets );
			$results['error_reasons'][] = 'La page pilier n\'a pas d\'URL valide. Vérifiez qu\'elle est bien publiée.';
			wp_send_json_success( $results );
		}
		foreach ( $targets as $loser_id ) {
			$loser_url = get_permalink( $loser_id );
			if ( ! $loser_url ) {
				$results['errors']++;
				$results['error_reasons'][] = 'La page #' . $loser_id . ' n\'a pas d\'URL (supprimée ou en corbeille).';
				continue;
			}
			$from = wp_make_link_relative( $loser_url );
			$rule_id = $redir->add_redirect_rule( $from, $pillar_url, 301, 'cannibalization', 'Concurrence : ' . ( isset( $group['keyword'] ) ? $group['keyword'] : '' ) );
			if ( $rule_id ) {
				$results['processed']++;
				$results['rule_ids'][] = (int) $rule_id;
			} else {
				$results['errors']++;
				$results['error_reasons'][] = 'Redirection bloquée pour ' . $from . ' (chemin critique ou auto-redirection).';
			}
		}

		// Stocker les rule_ids pour rollback (option transitoire 24h)
		if ( ! empty( $results['rule_ids'] ) ) {
			$rollback_key = 'hts_cannibal_rollback_' . $group_id;
			update_option( $rollback_key, array(
				'rule_ids'   => $results['rule_ids'],
				'pillar_id'  => $pillar_id,
				'group_id'   => $group_id,
				'keyword'    => isset( $group['keyword'] ) ? $group['keyword'] : '',
				'created_at' => current_time( 'Y-m-d H:i:s' ),
				'targets'    => array_values( $targets ),
			), false );
		}
		// Mettre à jour les paires
		$cannibal = new HTS_Cannibalization();
		$pairs_data = $cannibal->get_pairs();
		$pairs = isset( $pairs_data['pairs'] ) ? $pairs_data['pairs'] : array();
		foreach ( $pairs as &$pair ) {
			$a = (int) $pair['post_a'];
			$b = (int) $pair['post_b'];
			if ( ( in_array( $a, $targets, true ) && $b === $pillar_id ) || ( in_array( $b, $targets, true ) && $a === $pillar_id ) ) {
				$pair['status'] = 'redirected';
				$pair['action_taken'] = array( 'type' => 'redirect', 'winner' => $pillar_id, 'date' => current_time( 'Y-m-d H:i:s' ), 'via' => 'direct_fallback' );
			}
		}
		unset( $pair );
		$pairs_data['pairs'] = $pairs;
		update_option( 'hts_cannibal_pairs', $pairs_data, false );

		if ( function_exists( 'hts_add_log' ) ) {
			hts_add_log( sprintf( 'Groupe "%s" : %d redirection(s) directe(s) vers #%d (%s) [agent désactivé → fallback]', isset( $group['keyword'] ) ? $group['keyword'] : $group_id, $results['processed'], $pillar_id, get_the_title( $pillar_id ) ), 'success', 'cannibalization' );
		}

	} elseif ( $action_type === 'merge_all' ) {
		if ( ! $pillar_id ) wp_send_json_error( 'Aucune page pilier sélectionnée.' );
		$results['processed'] = count( $targets );
		// Mettre à jour les paires en merge_pending
		$cannibal = new HTS_Cannibalization();
		$pairs_data = $cannibal->get_pairs();
		$pairs = isset( $pairs_data['pairs'] ) ? $pairs_data['pairs'] : array();
		foreach ( $pairs as &$pair ) {
			$a = (int) $pair['post_a'];
			$b = (int) $pair['post_b'];
			if ( ( in_array( $a, $targets, true ) && $b === $pillar_id ) || ( in_array( $b, $targets, true ) && $a === $pillar_id ) ) {
				$pair['status'] = 'merge_pending';
			}
		}
		unset( $pair );
		$pairs_data['pairs'] = $pairs;
		update_option( 'hts_cannibal_pairs', $pairs_data, false );

	} elseif ( $action_type === 'dismiss_group' ) {
		$cannibal = new HTS_Cannibalization();
		$pairs_data = $cannibal->get_pairs();
		$pairs = isset( $pairs_data['pairs'] ) ? $pairs_data['pairs'] : array();
		foreach ( $pairs as &$pair ) {
			$a = (int) $pair['post_a'];
			$b = (int) $pair['post_b'];
			if ( in_array( $a, array_map( 'intval', $page_ids ), true ) && in_array( $b, array_map( 'intval', $page_ids ), true ) ) {
				$pair['status'] = 'dismissed';
			}
		}
		unset( $pair );
		$pairs_data['pairs'] = $pairs;
		update_option( 'hts_cannibal_pairs', $pairs_data, false );
		$results['processed'] = count( $page_ids );
	}

	// ── Historique persistant (visible dans la page) ──
	if ( $results['processed'] > 0 ) {
		$hist = get_option( 'hts_cannibal_history', array() );
		if ( ! is_array( $hist ) ) $hist = array();
		array_unshift( $hist, array(
			'date'          => current_time( 'd/m/Y H:i' ),
			'action'        => $action_type,
			'group_id'      => $group_id,
			'keyword'       => isset( $group['keyword'] ) ? $group['keyword'] : '',
			'pillar_id'     => $pillar_id,
			'pillar_title'  => get_the_title( $pillar_id ),
			'targets'       => array_values( $targets ),
			'rule_ids'      => isset( $results['rule_ids'] ) ? $results['rule_ids'] : array(),
			'rollbacked'    => false,
		) );
		$hist = array_slice( $hist, 0, 20 );
		update_option( 'hts_cannibal_history', $hist, false );
	}

	// Rebuild groupes
	$cannibal = new HTS_Cannibalization();
	$all_pairs = $cannibal->get_pairs();
	$new_groups = $cannibal->build_groups( isset( $all_pairs['pairs'] ) ? $all_pairs['pairs'] : array() );
	$rebuilt = array(
		'groups'       => $new_groups,
		'total_groups' => count( $new_groups ),
		'total_pages'  => array_sum( array_column( $new_groups, 'page_count' ) ),
		'scanned_at'   => current_time( 'Y-m-d H:i:s' ),
	);
	update_option( 'hts_cannibal_groups', $rebuilt, false );

	wp_send_json_success( $results );
}, 9 ); // Priorité 9 = AVANT le handler du module (priorité 10 par défaut)

        // ── P1B: Batch pre-compute SEO scores ──
        add_action( 'hts_batch_score_compute', 'hts_batch_score_run' );

        // Trigger on first activation
        if ( get_option( 'hts_scores_first_run' ) ) {
            delete_option( 'hts_scores_first_run' );
            if ( ! wp_next_scheduled( 'hts_batch_score_compute' ) ) {
                wp_schedule_single_event( time() + 30, 'hts_batch_score_compute' ); // 30s delay = after sitemap
            }
        }

        // AJAX: manual trigger from Cockpit
        add_action( 'wp_ajax_hts_batch_score_trigger', function() {
            check_ajax_referer( 'hts_admin_nonce', 'nonce' );
            if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions' );
            delete_option( 'hts_batch_score_offset' );
            $ts = wp_next_scheduled( 'hts_batch_score_compute' );
            if ( $ts ) wp_unschedule_event( $ts, 'hts_batch_score_compute' );
            wp_schedule_single_event( time(), 'hts_batch_score_compute' );
            wp_send_json_success( array( 'message' => 'Calcul des scores lancé en arrière-plan' ) );
        } );

        // AJAX: progress check
        add_action( 'wp_ajax_hts_batch_score_status', function() {
            check_ajax_referer( 'hts_admin_nonce', 'nonce' );
            $progress = get_option( 'hts_batch_score_progress', array() );
            wp_send_json_success( $progress );
        } );

        // ── Admin class (AJAX handlers for settings save) ──
        $GLOBALS['hts_admin'] = new Hts_Synchronise_Articles_Admin( 'hack-the-seo-light', HTS__VERSION );
        $GLOBALS['hts_admin']->init();

        // ── Enqueue wp.media on settings page for media picker ──
        add_action( 'admin_enqueue_scripts', function( $hook ) {
            if ( isset( $_GET['page'] ) && $_GET['page'] === 'hts-seo-settings' ) {
                wp_enqueue_media();
            }
        } );

        // ── Enqueue hts-analytics.js on Analytics page ──
        add_action( 'admin_enqueue_scripts', function( $hook ) {
            if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'hts-analytics' ) return;
            wp_enqueue_script(
                'hts-analytics',
                HTS__PLUGIN_URL . 'admin/js/hts-analytics.js',
                array( 'jquery' ),
                HTS__VERSION,
                true
            );
            wp_localize_script( 'hts-analytics', 'htsAnalytics', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'hts_analytics_nonce' ),
            ) );
        } );

        // ── AJAX: Analytics period data ──
        add_action( 'wp_ajax_hts_analytics_data', function() {
            check_ajax_referer( 'hts_analytics_nonce', 'nonce' );
            if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );
            $days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
            $allowed = array( 15, 30, 90, 365 );
            if ( ! in_array( $days, $allowed, true ) ) $days = 30;
            $tracker = new HTS_Impact_Tracker();
            $data = $tracker->get_analytics_data( $days );
            // Ajouter les stats workflow filtrées par période
            if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                $wf = HTS_Workflow_Engine::get_stats( $days );
                $wf_positive = ( $wf['approved'] ?? 0 ) + ( $wf['done'] ?? 0 ) + ( $wf['executing'] ?? 0 );
                $wf_measured = $wf_positive + ( $wf['rejected'] ?? 0 ) + ( $wf['dismissed'] ?? 0 ) + ( $wf['failed'] ?? 0 );
                $data['wf_rate']     = $wf_measured > 0 ? round( $wf_positive / $wf_measured * 100 ) : 0;
                $data['wf_positive'] = $wf_positive;
                $data['wf_measured'] = $wf_measured;
            }
            wp_send_json_success( $data );
        } );

        // ── AJAX: GSC data for SEO Panel per-article tab ──
        add_action( 'wp_ajax_hts_gsc_panel_data', function() {
            check_ajax_referer( 'hts_panel_score', 'nonce' );
            if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'forbidden' );
            $post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
            if ( ! $post_id ) wp_send_json_error( 'missing_post_id' );
            if ( ! class_exists( 'HTS_GSC_Connect' ) || get_option( 'hts_module_gsc', '1' ) !== '1' ) {
                wp_send_json_error( 'gsc_disabled' );
            }
            $gsc = new HTS_GSC_Connect();
            if ( ! $gsc->is_connected() || ! $gsc->has_data() ) {
                wp_send_json_error( 'gsc_not_connected' );
            }
            wp_send_json_success( $gsc->get_post_data( $post_id, 30 ) );
        } );

    } // end admin/ajax/cron init gate

}, 5 );

/* =========================================================================
 * P1B: BATCH SEO SCORE PRE-COMPUTATION
 * Processes 20 posts per cron run, chains until all done.
 * ====================================================================== */

function hts_batch_score_run() {
    if ( ! class_exists( 'HTS_SEO_Panel' ) ) return;

    $batch_size = 20;

    global $wpdb;
    $pt_in = hts_sql_post_types_in();

    $total_unscored = (int) $wpdb->get_var(
        "SELECT COUNT(*)
         FROM {$wpdb->posts} p
         LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_combined_score'
         WHERE p.post_status = 'publish'
         AND p.post_type {$pt_in}
         AND pm.meta_id IS NULL"
    );

    $total_all = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts}
         WHERE post_status = 'publish' AND post_type {$pt_in}"
    );

    if ( $total_unscored === 0 ) {
        delete_option( 'hts_batch_score_offset' );
        update_option( 'hts_batch_score_progress', array(
            'status'    => 'done',
            'total'     => $total_all,
            'scored'    => $total_all,
            'completed' => current_time( 'Y-m-d H:i:s' ),
        ), false );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Batch scores — terminé : $total_all articles notés", 'success', 'seo-panel' );
        }
        return;
    }

    $post_ids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT p.ID
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_combined_score'
             WHERE p.post_status = 'publish'
             AND p.post_type {$pt_in}
             AND pm.meta_id IS NULL
             LIMIT %d",
            $batch_size
        )
    );

    if ( empty( $post_ids ) ) {
        delete_option( 'hts_batch_score_offset' );
        return;
    }

    $panel = new HTS_SEO_Panel();
    $scored = 0;

    foreach ( $post_ids as $pid ) {
        $result = $panel->run_checks( (int) $pid );
        update_post_meta( (int) $pid, '_hts_combined_score', (int) $result['score'] );
        $scored++;
    }

    $total_scored = $total_all - $total_unscored + $scored;
    update_option( 'hts_batch_score_progress', array(
        'status'  => 'running',
        'total'   => $total_all,
        'scored'  => $total_scored,
        'batch'   => $scored,
        'updated' => current_time( 'Y-m-d H:i:s' ),
    ), false );

    if ( function_exists( 'hts_add_log' ) ) {
        hts_add_log( "Batch scores — lot traité : $scored articles ($total_scored/$total_all)", 'info', 'seo-panel' );
    }

    // Chain: schedule next batch in 10 seconds
    if ( ! wp_next_scheduled( 'hts_batch_score_compute' ) ) {
        wp_schedule_single_event( time() + 10, 'hts_batch_score_compute' );
    }
}

/* diagnostic-prep AJAX handlers removed in v2.6.3-prod */
