=== Hack The SEO ===
Contributors: hacktheseo
Tags: seo, schema, sitemap, meta tags, breadcrumbs, redirects, open graph, canonical, robots, migration
Requires at least: 5.9
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 2.8.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

SEO complet pour WordPress — Meta Tags, Schema JSON-LD, Sitemap XML, Redirections, Breadcrumbs, Scoring GEO, Coach IA, Workflows automatisés.

== Description ==

**Hack The SEO** est un plugin SEO complet et intelligent. Scoring GEO 2026, workflows automatisés, maillage IA, Coach SEO connecté aux vraies données de votre site.

= 13 modules SEO essentiels =

* **Meta Tags** — Title, Description, Open Graph, Twitter Cards avec aperçu SERP en temps réel
* **Schema JSON-LD** — Auto-détection Article, FAQ, HowTo, Video, Speakable, BreadcrumbList
* **Sitemap XML** — Dynamique, conforme aux standards, support multi post-types
* **Redirections** — 301, 302, 307, 410 avec interface complète et import/export
* **Robots Meta** — Noindex/nofollow par page avec suggestions intelligentes
* **Canonical URL** — Anti-cannibalisation avec détection de conflits 4 couches
* **Fil d'Ariane** — Breadcrumbs avec support cocon sémantique et Schema BreadcrumbList
* **Table des matières** — Générée automatiquement depuis vos titres H2-H4
* **SEO Panel** — Score SEO en temps réel dans l'éditeur (20 critères)
* **Cockpit** — Dashboard santé, toggles modules, self-test intégré
* **Migration** — Import depuis Rank Math, Yoast, SEOPress en 1 clic
* **Compatibilité** — Coexiste avec les plugins SEO existants pendant la transition

= Pourquoi Hack The SEO ? =

* **Gratuit et complet** — Tout ce que Rank Math Free fait, Hack The SEO le fait
* **Ultra léger** — 142 KB, 13 modules, chargement instantané
* **Zéro tracking** — Aucune donnée envoyée nulle part
* **Migration transparente** — Importez vos meta titles/descriptions depuis RM, Yoast, SEOPress
* **Prêt pour évoluer** — Passez à Hack The SEO Full pour l'IA et l'automatisation sans perdre vos données

= Hack The SEO Full — La version premium =

Débloquez l'intelligence artificielle et l'automatisation complète :

* Schema Pro — 6 types manuels (Product, Event, Recipe, LocalBusiness, Course, JobPosting)
* Rédaction IA et maillage sémantique
* Cocon sémantique automatisé
* Google Search Console intégrée
* Orchestrateur autonome (pipeline PLAN→APPLY→VERIFY)
* Instant Indexing (Google Indexing API)
* WooCommerce SEO
* Et 22 modules supplémentaires

[Découvrir Hack The SEO Full →](https://hacktheseo.com/)

== Installation ==

1. Téléchargez le fichier ZIP
2. Allez dans Extensions → Ajouter → Téléverser
3. Activez le plugin
4. Accédez à Hack The SEO → Cockpit dans votre menu admin

**Migration depuis un autre plugin SEO :**
Hack The SEO détecte automatiquement Rank Math, Yoast et SEOPress. Utilisez le wizard de migration accessible depuis le Cockpit.

== Frequently Asked Questions ==

= Puis-je utiliser Hack The SEO avec Rank Math / Yoast installé ? =

Oui. Hack The SEO inclut un module de compatibilité qui évite les conflits. Vous pouvez migrer progressivement via le wizard intégré.

= Mes données seront-elles conservées si je passe à Hack The SEO Full ? =

Oui, à 100%. Hack The SEO et sa version Full utilisent les mêmes clés meta. Il suffit de désactiver la version gratuite et d'activer Full — toutes vos données sont instantanément disponibles.

= Est-ce que Hack The SEO envoie des données à un serveur externe ? =

Non. Zéro appel API, zéro webhook, zéro tracking. Tout est traité localement.

= Quelle est la différence avec Rank Math Free ? =

Hack The SEO offre un scoring moderne sur 20 critères, une détection de cannibalisation 4 couches, un schema JSON-LD complet avec auto-détection FAQ/HowTo, et une migration transparente. Le tout dans un plugin ultra léger (142 KB vs 5+ MB).

== Screenshots ==

1. Cockpit — Vue d'ensemble santé SEO
2. SEO Panel — Score en temps réel dans l'éditeur
3. Schema JSON-LD — Auto-détection Article + FAQ
4. Migration Wizard — Import depuis Rank Math

== Changelog ==

= 2.4.12 =
* Protection zone intro : max 1 lien interne avant la première H2 (best practice SEO)
* Si un lien pilier existe déjà dans l'intro, les nouveaux liens sont redirigés après la première H2
* Si l'ancre n'existe qu'en intro et que la zone est saturée, le lien est bloqué (pas injecté)
* Protection heading ajoutée à apply_single_link (bulk) : jamais de lien dans H1-H6
* Protection appliquée à tous les chemins d'injection : do_apply_link (5 stratégies), apply_single_link (bulk), paragraph_inject, tolerant_inject
* Helpers ajoutés : count_intro_links(), is_intro_saturated()
* Logs informatifs quand un lien est bloqué pour cause de zone intro saturée ou heading

= 2.4.6 =
* Preview & Rollback Visible — Session J
* Diff engine : aperçu structuré avant/après pour chaque type d'action
* Preview inline dans l'Inbox : bouton "Voir" pour afficher le diff sans quitter la page
* Preview avant rollback : modal avec diff inversé montrant ce qui sera restauré
* Snapshot "before" capturé au moment de la proposition (pour un diff précis)
* Bouton rollback visible dans l'historique avec preview obligatoire
* Vocabulaire non-expert pour chaque champ (Titre SEO, Description pour Google, etc.)
* Chaque diff accompagné d'un "Pourquoi ce changement"
* 18+ assertions gate tests Session J

= 2.4.5 =
* Cockpit : extraction 3 sections (Feature Status, Semantic, Diagnostic) — render() passe de ~2400 à ~1360 lignes
* Alertes automatiques : détection agents peu efficaces (< 30% réussite sur 10+ actions) avec email admin
* Onboarding : nouvelle étape de configuration des agents + guide auto-formation avec tooltips
* Tests : +24 assertions gate Session I (extraction, alertes, onboarding, TODO audit)
* Nettoyage : audit TODO/FIXME — 1 seul restant (intentionnel)

= 2.2.0 =
* Sécurité : guard `defined('ABSPATH') || exit;` ajouté sur les 45 fichiers modules et admin
* Sécurité : escaping WordPress (esc_attr/esc_html) sur tous les select du Schema Markup
* Refactoring : fusion des 2 register_activation_hook en un seul (onboarding + init)
* Qualité : préparation WordPress.org — audit sanitize/escape renforcé

= 2.1.1 =
* Production : réactivation de l'onboarding wizard (redirect première installation)
* Sécurité : audit complet — 14 crons orphelins corrigés à la désactivation (18 hooks nettoyés)
* Sécurité : 13 fichiers index.php ajoutés (silence is golden) dans tous les sous-dossiers
* Sécurité : 8 guards ABSPATH ajoutés sur les partials admin
* Performance : optimisation requêtes cocon (no_found_rows + cache désactivé)
* Fix : intervalle cron dédoublonné (hts_6h → hts_every_6h partagé Sitemap/Health)
* Fix : 7 faux positifs corrigés dans la test suite
* Nouveau test #21 : vérification complétude nettoyage crons à la désactivation
* Uninstall : 6 hooks manquants ajoutés au nettoyage
* 659+ assertions, 0 fail, 6 warns (conditions normales site test)

= 2.1.0 =
* Nouveau : Coach SEO freemium — 5 questions gratuites par mois sans clé API (code prêt, activation après déploiement API SaaS)
* Nouveau : Dispatch Coach → Workflow — les recommandations du Coach créent des actions exécutables dans l\u0027Inbox
* 7 types d\u0027actions Coach : meta title, meta desc, FAQ, liens internes, content refresh, optimisation GEO, suppression page
* Dédoublonnage automatique (pas de doublon si action pending identique existe)
* Priorité dynamique des actions Coach (low/medium/high/critical)
* Nouveau : Inbox améliorée — labels non-expert, titres d\u0027articles, dates relatives, action "Ignorer"
* Nouveau : Exécution manuelle des actions depuis l\u0027Inbox (approve + execute en 1 clic)
* Nouveau : Batch dismiss dans l\u0027Inbox
* Sécurité : delete_page = corbeille uniquement (jamais de suppression définitive) + audit trail
* 37 assertions de test ajoutées (515 total)

= 2.0.0 =
* 🚀 Release majeure — SEO + GEO + Workflows + Coach IA
* Phase 1 : Pipeline de création d\u0027articles unifié (images, metas IA, schemas, maillage)
* Phase 2 : Workflow Engine + Inbox — backbone pour tous les agents SEO automatisés
* Phase 3 : GEO Score (12 critères pondérés 2026), Content Refresh, Freshness
* Phase 4 : Anti-cannibalisation avec merge IA + check pré-écriture systématique
* Phase 5 : Auto-Write (calendrier éditorial, génération anticipée, publication conditionnelle)
* Phase 6 : Coach SEO — IA connectée aux vrais scores du site (Claude Haiku, ~$0.009/question)
* Phase 7 : Audit sécurité complet, uninstall propre, régression 466+ assertions
* 45 modules, 66 000+ lignes PHP
* Nouveau : Connexion Google Search Console (API native + import CSV)
* Nouveau : Scoring combiné SEO + GEO avec recommandations non-expert
* Nouveau : Maillage cross-cocon intelligent avec TF-IDF
* Nouveau : Notifications par email (digest hebdo avec insights GSC)
* Amélioration : Compatibilité PHP 7.4-8.2, WordPress 6.x, Polylang, Elementor, Divi
* Sécurité : 238 handlers AJAX avec nonce + capability, 0 nopriv (sauf tracker visiteurs)

= 1.5.0 =
* Réglages : mode Simplifié/Expert sauvegardé instantanément
* Réglages : bouton Enregistrer ajouté en haut de page
* Réglages : réception des articles (statut par défaut) déplacé ici
* Polish UI : cohérence visuelle entre toutes les pages admin
* Branding : dernières occurrences « HTS » remplacées par « Hack The SEO »

= 1.4.9 =
* Support complet des Custom Post Types et taxonomies
* WooCommerce : Schema Product et OG enrichis automatiques
* Sitemap : sous-sitemaps par taxonomie

= 1.4.8 =
* Widget statut SEO dans la sidebar Gutenberg

= 1.4.7 =
* Compatibilité TinyMCE et PHP 8
* Bannière page builders (Elementor, Divi, WPBakery)

= 1.4.6 =
* Fix analyse temps réel et Diagnostic

= 1.4.5 =
* Détection H1, slug, paragraphes et auto-refresh du score

= 1.4.4 =
* Fix tableau des redirections vide
* Rebranding complet HTS → Hack The SEO

= 1.0.0 =
* Version initiale — 13 modules SEO extraits de Hack The SEO Full

== Upgrade Notice ==

= 2.1.0 =
Le Coach SEO est maintenant accessible gratuitement (5 questions/mois). Aucune clé API requise pour commencer.

= 2.0.0 =
Mise à jour majeure : GEO Score, Coach IA, Workflows automatisés, Anti-cannibalisation, Content Refresh. Sauvegardez votre base avant mise à jour.

= 1.0.0 =
Première version stable. Remplace votre plugin SEO gratuit actuel sans perte de données.
