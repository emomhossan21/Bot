<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Cockpit — Module status dashboard
 *
 * Simple ON/OFF view of all SEO modules with health status.
 * Detects conflicts, missing config, and active competitors.
 *
 * @since 4.0.0
 */

class HTS_Cockpit {

    /** Transient key for heavy cockpit stats (5 min TTL) */
    const CACHE_KEY = 'hts_cockpit_stats';
    const CACHE_TTL = 300; // 5 minutes

    public function init() {
        add_action( 'admin_menu', array( $this, 'register_page' ), 15 );
        add_action( 'wp_ajax_hts_cockpit_toggle', array( $this, 'ajax_toggle' ) );
        add_action( 'wp_ajax_hts_cockpit_kill_switch', array( $this, 'ajax_kill_switch' ) );
        add_action( 'wp_ajax_hts_cockpit_self_test', array( $this, 'ajax_self_test' ) );
        add_action( 'wp_ajax_hts_cockpit_flush_rewrites', array( $this, 'ajax_flush_rewrites' ) );
        add_action( 'wp_ajax_hts_dismiss_gsc_notice', array( $this, 'ajax_dismiss_gsc_notice' ) );
        add_action( 'wp_ajax_hts_bulk_score', array( $this, 'ajax_bulk_score' ) );
        add_action( 'wp_ajax_hts_audit_history_faceted', array( $this, 'ajax_audit_history_faceted' ) );
        add_action( 'wp_ajax_hts_geo_readiness', array( $this, 'ajax_geo_readiness' ) );

        // Invalidate cockpit cache on content changes
        add_action( 'save_post', array( $this, 'invalidate_cache' ) );

        // Sprint 4.9: Floating coach widget — DISABLED: replaced by HTS_Support_Docs widget (v2.7.0)
        // add_action( 'admin_footer', array( $this, 'render_floating_coach' ) );
        add_action( 'deleted_post', array( $this, 'invalidate_cache' ) );
        add_action( 'update_option_hts_module_meta_tags', array( $this, 'invalidate_cache' ) );
        add_action( 'update_option_hts_module_sitemap', array( $this, 'invalidate_cache' ) );
        add_action( 'update_option_hts_module_schema', array( $this, 'invalidate_cache' ) );
    }

    /**
     * Invalidate cockpit stats cache.
     */
    public function invalidate_cache() {
        delete_transient( self::CACHE_KEY );
    }

    /**
     * Get cached cockpit heavy stats (score distribution + meta coverage).
     * @return array
     */
    private function get_cached_stats() {
        // S18 FIX: Language-aware cache key
        $cache_key = self::CACHE_KEY;
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $ck_cur = HTS_Language::get_current_lang();
            if ( $ck_cur ) {
                $cache_key = self::CACHE_KEY . '_' . $ck_cur;
            }
        }
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";

        // S18 FIX: Build SQL language clause for cockpit KPIs
        $ck_lang_clause = '';
        $ck_lang_meta_clause = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $ck_lang = HTS_Language::get_current_lang();
            if ( $ck_lang ) {
                $ck_lang_args = array(
                    'post_type' => array( 'post', 'page' ), 'post_status' => 'publish',
                    'posts_per_page' => 500, 'fields' => 'ids', 'suppress_filters' => false,
                );
                $ck_lang_args = HTS_Language::filter_query_args( $ck_lang_args, $ck_lang );
                $ck_post_ids = get_posts( $ck_lang_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $ck_post_objects = array_map( 'get_post', $ck_post_ids );
                    $ck_post_objects = array_values( HTS_Language::filter_posts_by_lang( $ck_post_objects, $ck_lang ) );
                    $ck_post_ids = wp_list_pluck( $ck_post_objects, 'ID' );
                }
                if ( ! empty( $ck_post_ids ) ) {
                    $ck_ids_str = implode( ',', array_map( 'intval', $ck_post_ids ) );
                    $ck_lang_clause = " AND p.ID IN ({$ck_ids_str})";
                    $ck_lang_meta_clause = " AND post_id IN ({$ck_ids_str})";
                }
            }
        }

        // 1. Score SEO/GEO distribution
        $score_rows = $wpdb->get_results( "
            SELECT pm.meta_value AS score
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.meta_key = '_hts_combined_score'
            AND p.post_status = 'publish'
            AND p.post_type {$pt_in}
            {$ck_lang_clause}
        " );

        $score_count = count( $score_rows );
        $score_sum = 0;
        $score_green = 0;
        $score_orange = 0;
        $score_red = 0;
        foreach ( $score_rows as $sr ) {
            $sv = (int) $sr->score;
            $score_sum += $sv;
            if ( $sv >= 80 ) $score_green++;
            elseif ( $sv >= 50 ) $score_orange++;
            else $score_red++;
        }
        $score_avg = $score_count > 0 ? round( $score_sum / $score_count ) : 0;

        // 2. Meta tag coverage
        $mt_total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type {$pt_in}" . str_replace( 'p.ID', 'ID', $ck_lang_clause ) );
        $mt_covered = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_meta_title' AND meta_value != ''{$ck_lang_meta_clause}" );

        // 3. Coverage stats (bottom section)
        $total_posts = $mt_total;
        $with_title  = $mt_covered;
        $with_desc   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_meta_description' AND meta_value != ''{$ck_lang_meta_clause}" );
        $with_score  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_combined_score'{$ck_lang_meta_clause}" );
        $with_kw     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_focus_keyword' AND meta_value != ''{$ck_lang_meta_clause}" );

        // 4. Top 5 pages prioritaires — les plus bas scores parmi les publiés (v2.4.1)
        $top5_rows = $wpdb->get_results( "
            SELECT p.ID, p.post_title, pm.meta_value AS score,
                   COALESCE(geo.meta_value, '0') AS geo_score
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            LEFT JOIN {$wpdb->postmeta} geo ON geo.post_id = p.ID AND geo.meta_key = '_hts_geo_score'
            WHERE pm.meta_key = '_hts_combined_score'
            AND p.post_status = 'publish'
            AND p.post_type {$pt_in}
            {$ck_lang_clause}
            ORDER BY CAST(pm.meta_value AS UNSIGNED) ASC
            LIMIT 5
        " );
        $top5 = array();
        foreach ( $top5_rows as $row ) {
            $top5[] = array(
                'id'        => (int) $row->ID,
                'title'     => $row->post_title,
                'score'     => (int) $row->score,
                'geo_score' => (int) $row->geo_score,
            );
        }

        // 5. Tendance score — dernières semaines depuis l'historique (v2.4.1)
        $score_history = get_option( 'hts_global_score_history', array() );
        $trend_data    = array();
        $trend_delta   = 0;
        if ( ! empty( $score_history ) ) {
            $recent = array_slice( $score_history, -8 ); // 8 dernières semaines max
            foreach ( $recent as $snap ) {
                $trend_data[] = array(
                    'date'    => $snap['date'] ?? '',
                    'average' => (int) ( $snap['average'] ?? 0 ),
                );
            }
            if ( count( $recent ) >= 2 ) {
                $first = (int) ( $recent[0]['average'] ?? 0 );
                $last  = (int) ( end( $recent )['average'] ?? 0 );
                $trend_delta = $last - $first;
            }
        }

        $stats = array(
            'score_avg'     => $score_avg,
            'score_count'   => $score_count,
            'score_green'   => $score_green,
            'score_orange'  => $score_orange,
            'score_red'     => $score_red,
            'mt_total'      => $mt_total,
            'mt_covered'    => $mt_covered,
            'mt_pct'        => $mt_total > 0 ? round( $mt_covered / $mt_total * 100 ) : 0,
            'total_posts'   => $total_posts,
            'with_title'    => $with_title,
            'with_desc'     => $with_desc,
            'with_score'    => $with_score,
            'with_kw'       => $with_kw,
            'top5'          => $top5,
            'trend_data'    => $trend_data,
            'trend_delta'   => $trend_delta,
        );

        set_transient( $cache_key, $stats, self::CACHE_TTL );
        return $stats;
    }

    /**
     * Public aggregated stats for dashboard partial.
     * Maps get_cached_stats() + AI/GSC data into the format expected by admin/partials/dashboard.php.
     *
     * @since 2.6.0
     * @return array
     */
    public function get_heavy_stats() {
        $ck = $this->get_cached_stats();

        $stats = array(
            'avg_score'       => (int) ( $ck['score_avg'] ?? 0 ),
            'total_articles'  => (int) ( $ck['score_count'] ?? $ck['total_posts'] ?? 0 ),
            'score_good'      => (int) ( $ck['score_green'] ?? 0 ),
            'score_mid'       => (int) ( $ck['score_orange'] ?? 0 ),
            'score_bad'       => (int) ( $ck['score_red'] ?? 0 ),
            'ai_visits_30d'   => 0,
            'ai_visits_trend' => 0,
            'ai_bots'         => array(),
            'gsc'             => array(),
            'recent_actions'  => array(),
        );

        // AI visits from Impact Tracker
        if ( class_exists( 'HTS_Impact_Tracker' ) && get_option( 'hts_module_impact_tracker', '1' ) === '1'
             && method_exists( 'HTS_Impact_Tracker', 'get_analytics_data' ) ) {
            $tracker   = new HTS_Impact_Tracker();
            $analytics = $tracker->get_analytics_data( 30 );
            if ( is_array( $analytics ) ) {
                $stats['ai_visits_30d']   = (int) ( $analytics['ai_total'] ?? 0 );
                $stats['ai_visits_trend'] = (float) ( $analytics['ai_trend'] ?? 0 );

                // AI bots breakdown from ai_sources
                $ai_labels = array(
                    'chatgpt'    => 'ChatGPT',
                    'claude'     => 'Claude',
                    'perplexity' => 'Perplexity',
                    'gemini'     => 'Gemini',
                    'copilot'    => 'Copilot',
                    'meta'       => 'Meta AI',
                    'you'        => 'You.com',
                );
                $bots = array();
                if ( ! empty( $analytics['ai_sources'] ) && is_array( $analytics['ai_sources'] ) ) {
                    foreach ( $analytics['ai_sources'] as $src ) {
                        $slug  = $src['source'] ?? '';
                        $count = (int) ( $src['count'] ?? 0 );
                        if ( $slug && $count > 0 ) {
                            $bots[] = array(
                                'slug'  => $slug,
                                'label' => $ai_labels[ $slug ] ?? ucfirst( $slug ),
                                'count' => $count,
                            );
                        }
                    }
                }
                // Fallback: if no source breakdown, use total as single entry
                if ( empty( $bots ) && $stats['ai_visits_30d'] > 0 ) {
                    $bots[] = array( 'slug' => 'ai', 'label' => 'IA', 'count' => $stats['ai_visits_30d'] );
                }
                $stats['ai_bots'] = $bots;
            }
        }

        // GSC data
        if ( class_exists( 'HTS_GSC_Connect' ) && get_option( 'hts_module_gsc', '1' ) === '1' ) {
            $gsc = new HTS_GSC_Connect();
            if ( $gsc->is_connected() && $gsc->has_data() ) {
                $gsc_30 = $gsc->get_site_data( 30 );
                if ( is_array( $gsc_30 ) ) {
                    $stats['gsc'] = array(
                        'clicks_30d'   => (int) ( $gsc_30['clicks'] ?? 0 ),
                        'clicks_trend' => (float) ( $gsc_30['clicks_trend'] ?? 0 ),
                    );
                }
            }
        }

        // Recent workflow actions
        if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
            global $wpdb;
            $wf_table = $wpdb->prefix . 'hts_workflow_actions';
            $rows = $wpdb->get_results(
                "SELECT a.agent, a.type, a.status, a.resolved_at, p.post_title
                 FROM {$wf_table} a
                 LEFT JOIN {$wpdb->posts} p ON a.post_id = p.ID
                 WHERE a.status IN ('done','failed')
                 ORDER BY a.resolved_at DESC
                 LIMIT 10"
            );
            $agent_labels = HTS_Workflow_Engine::get_agent_labels();
            foreach ( $rows as $r ) {
                $stats['recent_actions'][] = array(
                    'agent'  => $agent_labels[ $r->agent ] ?? ucfirst( $r->agent ),
                    'type'   => $r->type,
                    'status' => $r->status,
                    'title'  => $r->post_title ?? '',
                    'time'   => $r->resolved_at,
                );
            }
        }

        return $stats;
    }

    /**
     * Generate inline SVG sparkline (Session H).
     *
     * @param array  $values Numeric values array.
     * @param string $color  Stroke color.
     * @param int    $w      Width in px.
     * @param int    $h      Height in px.
     * @return string SVG markup.
     */
    private function render_sparkline( $values, $color = '#6366f1', $w = 120, $h = 32 ) {
        if ( empty( $values ) || count( $values ) < 2 ) return '';

        $min_v = min( $values );
        $max_v = max( $values );
        $range = $max_v - $min_v;
        if ( $range == 0 ) $range = 1;
        $pad = 2;
        $n = count( $values );

        $points = array();
        for ( $i = 0; $i < $n; $i++ ) {
            $x = $pad + ( $i / ( $n - 1 ) ) * ( $w - 2 * $pad );
            $y = $pad + ( 1 - ( $values[ $i ] - $min_v ) / $range ) * ( $h - 2 * $pad );
            $points[] = round( $x, 1 ) . ',' . round( $y, 1 );
        }
        $polyline = implode( ' ', $points );

        // Gradient fill beneath the line
        $fill_points = $points;
        $fill_points[] = round( $w - $pad, 1 ) . ',' . ( $h - $pad );
        $fill_points[] = round( $pad, 1 ) . ',' . ( $h - $pad );
        $fill_poly = implode( ' ', $fill_points );

        $id = 'hts-spark-' . wp_rand( 1000, 9999 );

        return '<svg width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '" style="display:block;margin-top:6px;">'
            . '<defs><linearGradient id="' . $id . '" x1="0" y1="0" x2="0" y2="1">'
            . '<stop offset="0%" stop-color="' . esc_attr( $color ) . '" stop-opacity="0.2"/>'
            . '<stop offset="100%" stop-color="' . esc_attr( $color ) . '" stop-opacity="0.02"/>'
            . '</linearGradient></defs>'
            . '<polygon points="' . esc_attr( $fill_poly ) . '" fill="url(#' . $id . ')"/>'
            . '<polyline points="' . esc_attr( $polyline ) . '" fill="none" stroke="' . esc_attr( $color ) . '" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>'
            . '</svg>';
    }

    public function register_page() {
        // Light mode already registers Cockpit via main file menu
        if ( defined( 'HTS__IS_LIGHT' ) && HTS__IS_LIGHT ) {
            return;
        }

        // Count pending recommendations for badge (Full only)
        $badge = '';
        $recs = get_option( 'hts_orchestrator_recs', array() );
        if ( is_array( $recs ) ) {
            $pending = count( array_filter( $recs, function( $r ) {
                return ( $r['status'] ?? '' ) === 'pending';
            }));
            if ( $pending > 0 ) {
                $badge = ' <span class="awaiting-mod" style="background:#6366f1;">' . $pending . '</span>';
            }
        }

        add_submenu_page(
            'hts-synchronise-articles',
            'Cockpit SEO',
            'Cockpit SEO' . $badge,
            defined( 'HTS_VIEW_CAPABILITY' ) ? HTS_VIEW_CAPABILITY : 'manage_options',
            'hts-cockpit',
            array( $this, 'render' )
        );
    }

    /* ══════════════════════════════════════════════
     *  MODULE DEFINITIONS
     * ══════════════════════════════════════════════ */

    private function get_modules() {
        // premium: false = available to all, true = requires paid plan
        // min_tier: 0 = free, 1 = starter, 2 = growth, 3 = agency (only checked when premium = true)
        $modules = array(
            'meta_tags' => array(
                'label'   => 'Meta Tags',
                'desc'    => 'Title, description, OG, Twitter — injection dans le <head>',
                'option'  => 'hts_module_meta_tags',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_meta_tags' ),
                'settings' => 'hts-seo-settings',
            ),
            'robots' => array(
                'label'   => 'Robots Meta',
                'desc'    => 'Noindex / nofollow par page + règles globales',
                'option'  => 'hts_module_robots',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_robots' ),
                'settings' => 'hts-seo-settings',
            ),
            'canonical' => array(
                'label'   => 'Canonical URLs',
                'desc'    => 'Injection <link rel="canonical"> anti-duplication',
                'option'  => 'hts_module_canonical',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_canonical' ),
                'settings' => 'hts-seo-settings',
            ),
            'schema' => array(
                'label'   => 'Schema Markup',
                'desc'    => 'JSON-LD : Article, FAQ, HowTo, Video, Organization, Speakable',
                'option'  => 'hts_module_schema',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_schema' ),
                'settings' => 'hts-seo-settings',
            ),
            'sitemap' => array(
                'label'   => 'Sitemap XML',
                'desc'    => 'Génération et soumission du sitemap',
                'option'  => 'hts_module_sitemap',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_sitemap' ),
                'settings' => 'hts-seo-settings',
            ),
            'redirects' => array(
                'label'   => 'Redirections',
                'desc'    => 'Redirections 301/302 + monitoring 404',
                'option'  => 'hts_module_redirects',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_redirects' ),
                'settings' => 'hts-redirections',
            ),
            'breadcrumbs' => array(
                'label'   => 'Breadcrumbs',
                'desc'    => 'Fil d\'Ariane cocon-aware',
                'option'  => 'hts_module_breadcrumbs',
                'default' => false,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_ok' ),
            ),
            'toc' => array(
                'label'   => 'Table des matières',
                'desc'    => 'Sommaire automatique H2/H3 dans les articles',
                'option'  => 'hts_module_toc',
                'default' => false,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_ok' ),
            ),
            'impact_tracker' => array(
                'label'   => 'Impact Tracker',
                'desc'    => 'Visites IA (ChatGPT, Perplexity, Claude…) + engagement',
                'option'  => 'hts_module_impact_tracker',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_impact_tracker' ),
            ),
            'gsc' => array(
                'label'   => 'Google Search Console',
                'desc'    => 'Clics, impressions, CTR et position depuis Google',
                'option'  => 'hts_module_gsc',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_gsc' ),
            ),
            'notifications' => array(
                'label'   => 'Rapport hebdomadaire',
                'desc'    => 'Email digest chaque lundi avec les KPI et alertes',
                'option'  => 'hts_module_notifications',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_notifications' ),
            ),
        );

        // Full-only modules shown as locked in Light
        if ( ! defined( 'HTS__IS_LIGHT' ) || ! HTS__IS_LIGHT ) {
            $modules['internal_linking'] = array(
                'label'   => 'Internal Linking',
                'desc'    => 'Suggestions de liens internes par IA',
                'option'  => 'hts_module_internal_linking',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_ok' ),
            );
            $modules['image_seo'] = array(
                'label'   => 'Image SEO',
                'desc'    => 'Alt text automatique sur les images',
                'option'  => 'hts_module_image_seo',
                'default' => true,
                'premium' => false,
                'min_tier' => 0,
                'check'   => array( $this, 'check_ok' ),
            );
        }

        return $modules;
    }

    /* ══════════════════════════════════════════════
     *  STATUS CHECKS
     * ══════════════════════════════════════════════ */

    private function check_meta_tags() {
        $sep = get_option( 'hts_title_separator' );
        if ( ! $sep ) return array( 'status' => 'warn', 'msg' => 'Séparateur de titre non configuré' );
        return array( 'status' => 'ok', 'msg' => 'Séparateur : ' . $sep );
    }

    private function check_robots() {
        global $wpdb;
        $noindex_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_robots_meta' AND meta_value LIKE '%noindex%'"
        );
        return array( 'status' => 'ok', 'msg' => $noindex_count . ' page(s) en noindex' );
    }

    private function check_canonical() {
        global $wpdb;
        $custom_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_canonical_url' AND meta_value != ''"
        );
        return array( 'status' => 'ok', 'msg' => $custom_count > 0 ? $custom_count . ' canonical(s) custom' : 'Auto sur toutes les pages' );
    }

    private function check_schema() {
        if ( class_exists( 'HTS_Schema_Markup' ) ) {
            $sm = new HTS_Schema_Markup();
            if ( method_exists( $sm, 'get_schema_stats' ) ) {
                $stats = $sm->get_schema_stats();
                $total = ( $stats['faq_count'] ?? 0 ) + ( $stats['howto_count'] ?? 0 );
                return array( 'status' => 'ok', 'msg' => 'Article auto + ' . $total . ' FAQ/HowTo détectés' );
            }
        }
        return array( 'status' => 'ok', 'msg' => 'Actif — Article + auto-détection' );
    }

    private function check_sitemap() {
        $sitemap_url = home_url( '/sitemap.xml' );
        $response = wp_remote_head( $sitemap_url, array( 'timeout' => 3, 'sslverify' => false ) );
        if ( is_wp_error( $response ) ) {
            return array( 'status' => 'warn', 'msg' => 'Sitemap inaccessible' );
        }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code === 200 ) return array( 'status' => 'ok', 'msg' => 'Accessible — HTTP 200' );
        return array( 'status' => 'warn', 'msg' => 'HTTP ' . $code );
    }

    private function check_redirects() {
        if ( class_exists( 'HTS_Redirects' ) ) {
            global $wpdb;
            $table = $wpdb->prefix . 'hts_redirects';
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
                $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
                return array( 'status' => 'ok', 'msg' => $count . ' redirection(s) active(s)' );
            }
        }
        return array( 'status' => 'ok', 'msg' => 'Module actif' );
    }

    private function check_ok() {
        return array( 'status' => 'ok', 'msg' => 'Actif' );
    }

    private function check_impact_tracker() {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_visits';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
            $d30 = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
            $count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE visited_at > %s", $d30 ) );
            $ai    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE is_ai = 1 AND visited_at > %s", $d30 ) );
            return array( 'status' => 'ok', 'msg' => $count . ' visite(s) ce mois dont ' . $ai . ' IA' );
        }
        return array( 'status' => 'ok', 'msg' => 'En attente de données' );
    }

    private function check_gsc() {
        if ( class_exists( 'HTS_GSC_Connect' ) ) {
            $gsc = new HTS_GSC_Connect();
            if ( $gsc->is_connected() ) {
                $stats = $gsc->get_dashboard_stats();
                if ( $stats['has_data'] ) {
                    return array( 'status' => 'ok', 'msg' => (int) $stats['clicks'] . ' clics / ' . (int) $stats['impressions'] . ' impressions (30j)' );
                }
                return array( 'status' => 'ok', 'msg' => 'Connect&eacute;, en attente de donn&eacute;es' );
            }
        }
        return array( 'status' => 'warning', 'msg' => 'Non connect&eacute; &mdash; allez dans R&eacute;glages SEO' );
    }

    private function check_notifications() {
        $enabled = get_option( 'hts_module_notifications', '1' ) === '1';
        if ( ! $enabled ) {
            return array( 'status' => 'warning', 'msg' => 'D&eacute;sactiv&eacute;' );
        }
        $last = get_option( 'hts_digest_last_sent', 0 );
        if ( $last ) {
            $ago = human_time_diff( $last, time() );
            return array( 'status' => 'ok', 'msg' => 'Dernier envoi il y a ' . $ago );
        }
        return array( 'status' => 'ok', 'msg' => 'Actif &mdash; prochain envoi lundi' );
    }

    /* ══════════════════════════════════════════════
     *  CONFLICT DETECTION
     * ══════════════════════════════════════════════ */

    private function detect_conflicts() {
        $conflicts = array();
        $competitors = array(
            'seo-by-rank-math/rank-math.php'  => 'Rank Math',
            'wordpress-seo/wp-seo.php'        => 'Yoast SEO',
            'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'All in One SEO',
            'wp-seopress/seopress.php'        => 'SEOPress',
        );

        $active_plugins = (array) get_option( 'active_plugins', array() );
        foreach ( $competitors as $file => $name ) {
            if ( in_array( $file, $active_plugins, true ) ) {
                $conflicts[] = array( 'type' => 'competitor', 'name' => $name, 'msg' => $name . ' est encore actif — risque de conflit sur les meta tags, canonical et schema.' );
            }
        }

        // Check for duplicate canonical
        if ( class_exists( 'HTS_Compat' ) ) {
            $compat = new HTS_Compat();
            if ( method_exists( $compat, 'get_detected_plugin' ) ) {
                $detected = $compat->get_detected_plugin();
                if ( $detected && ! in_array( $detected, array_values( $conflicts ), true ) ) {
                    $conflicts[] = array( 'type' => 'competitor', 'name' => $detected, 'msg' => $detected . ' détecté (peut être inactif mais des données résiduelles existent).' );
                }
            }
        }

        return $conflicts;
    }

    /**
     * Check if a module is locked behind a premium plan.
     * Returns true if the module requires a higher plan tier than the user has.
     * Currently all modules have premium=false, so this always returns false.
     * Ready for future feature gating.
     */
    private function is_module_locked( $mod ) {
        if ( empty( $mod['premium'] ) ) return false;
        if ( ! class_exists( 'HTS_Subscription' ) ) return false;
        return HTS_Subscription::get_plan_tier() < ( $mod['min_tier'] ?? 1 );
    }

    /* ══════════════════════════════════════════════
     *  AJAX TOGGLE
     * ══════════════════════════════════════════════ */

    public function ajax_toggle() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $module = sanitize_key( $_POST['module'] ?? '' );
        $state  = (int) ( $_POST['state'] ?? 1 );
        $modules = $this->get_modules();

        if ( ! isset( $modules[ $module ] ) ) wp_send_json_error( 'unknown module' );

        // Premium gate: block activation if module is locked (future use)
        if ( $state && $this->is_module_locked( $modules[ $module ] ) ) {
            $plan_needed = $modules[ $module ]['min_tier'] ?? 1;
            $plan_names = array( 1 => 'Starter', 2 => 'Growth', 3 => 'Agency' );
            wp_send_json_error( array(
                'locked'  => true,
                'message' => 'Cette fonctionnalité nécessite un abonnement ' . ( $plan_names[ $plan_needed ] ?? 'payant' ) . '.',
            ) );
        }

        update_option( $modules[ $module ]['option'], $state ? 1 : 0 );
        $this->invalidate_cache();
        wp_send_json_success( array( 'module' => $module, 'state' => $state ) );
    }

    /**
     * AJAX: Kill switch — stop all autonomy immediately.
     */
    public function ajax_kill_switch() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        // Disable orchestrator auto mode
        $orch_settings = get_option( 'hts_orchestrator_settings', array() );
        $orch_settings['auto_mode'] = false;
        update_option( 'hts_orchestrator_settings', $orch_settings );

        // Clear all HTS crons
        $crons_to_clear = array(
            'hts_orchestrator_weekly', 'hts_health_cron', 'hts_embeddings_cron',
            'hts_embeddings_smart_cron', 'hts_sitemap_cron', 'hts_refresh_run_linking',
        );
        foreach ( $crons_to_clear as $hook ) {
            $ts = wp_next_scheduled( $hook );
            if ( $ts ) wp_unschedule_event( $ts, $hook );
        }

        // Log
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'KILL SWITCH activé — autonomie stoppée, crons désactivés', 'warning', 'cockpit' );
        }

        wp_send_json_success( array( 'message' => 'Autonomie stoppée. Tous les crons désactivés.' ) );
    }

    /**
     * AJAX: Self-test — run Health Check and return results.
     */
    public function ajax_self_test() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $results = array();

        if ( class_exists( 'HTS_Health_Check' ) ) {
            $hc = new HTS_Health_Check();
            $record = $hc->run_all();
            // run_all() returns { timestamp, results: { key => {status, message, name, group} }, summary: {ok, warn, fail, total} }
            $test_results = $record['results'] ?? array();
            foreach ( $test_results as $key => $r ) {
                $results[] = array(
                    'key'     => $r['name'] ?? $key,
                    'status'  => $r['status'] ?? 'fail',
                    'message' => $r['message'] ?? '',
                );
            }
            $summary = $record['summary'] ?? array();
            $ok    = $summary['ok'] ?? 0;
            $total = $summary['total'] ?? count( $results );
        } else {
            // ── Light-specific self-tests ──
            $results = $this->run_light_self_tests();
            $ok    = count( array_filter( $results, function( $r ) { return $r['status'] === 'ok'; } ) );
            $total = count( $results );
        }

        wp_send_json_success( array( 'results' => $results, 'ok' => $ok, 'total' => $total ) );
    }

    /**
     * AJAX: Flush rewrite rules + force sitemap re-registration.
     */
    public function ajax_flush_rewrites() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        // Re-register sitemap rewrite rules before flushing
        if ( class_exists( 'HTS_Sitemap' ) ) {
            $sm = new HTS_Sitemap();
            $sm->register_rewrites();
        }

        flush_rewrite_rules( false );
        delete_option( 'hts_sitemap_flush_needed' );

        if ( function_exists( 'hts_add_log' ) ) {
 hts_add_log( 'Rewrite rules flush manuel depuis le Cockpit', 'info', 'cockpit' );
        }

        wp_send_json_success( array( 'message' => 'Rewrite rules réinitialisées.' ) );
    }

    public function ajax_dismiss_gsc_notice() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        update_option( 'hts_gsc_sitemap_notice_dismissed', true );
        wp_send_json_success();
    }

    /**
     * Bulk compute SEO scores for posts missing _hts_combined_score.
     * Processes 10 posts per call — the JS loops until done.
     */
    public function ajax_bulk_score() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        if ( ! class_exists( 'HTS_SEO_Panel' ) ) {
            wp_send_json_error( array( 'message' => 'SEO Panel non chargé' ) );
        }

        global $wpdb;
        $pt_in = hts_sql_post_types_in();
        $batch  = 10;

        // Get posts without a score
        $post_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_combined_score'
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND pm.meta_id IS NULL
             LIMIT %d",
            $batch
        ) );

        if ( empty( $post_ids ) ) {
            wp_send_json_success( array( 'done' => true, 'processed' => 0, 'remaining' => 0 ) );
        }

        $panel = new HTS_SEO_Panel();
        $processed = 0;
        foreach ( $post_ids as $pid ) {
            $a = $panel->run_checks( (int) $pid );
            update_post_meta( (int) $pid, '_hts_combined_score', (int) $a['score'] );
            $processed++;
        }

        // Count remaining
        $remaining = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_combined_score'
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in} AND pm.meta_id IS NULL"
        );

        // Clear stats cache when scan is complete
        if ( $remaining === 0 ) {
            delete_transient( 'hts_cockpit_stats' );
            // Multilingual: clear per-language transients
            if ( class_exists( 'HTS_Language' ) && method_exists( 'HTS_Language', 'get_all_langs' ) ) {
                foreach ( HTS_Language::get_all_langs() as $lang_code ) {
                    delete_transient( 'hts_cockpit_stats_' . $lang_code );
                }
            }
            // Common language codes fallback
            foreach ( array( 'fr', 'en', 'es', 'de', 'it', 'pt', 'nl' ) as $lc ) {
                delete_transient( 'hts_cockpit_stats_' . $lc );
            }
        }

        wp_send_json_success( array(
            'done'      => $remaining === 0,
            'processed' => $processed,
            'remaining' => $remaining,
        ) );
    }

    /* =========================================================================
     * PHASE 6e — HISTORIQUE FACETTES (Audit Trail filtrable)
     * ====================================================================== */

    /**
     * AJAX: Faceted audit history with filters (module, type, date range, cocon).
     */
    public function ajax_audit_history_faceted() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            wp_send_json_success( array( 'items' => array(), 'total' => 0, 'facets' => array() ) );
        }

        // Filters
        $filter_module = sanitize_text_field( $_POST['filter_module'] ?? '' );
        $filter_type   = sanitize_text_field( $_POST['filter_type'] ?? '' );
        $filter_date   = sanitize_text_field( $_POST['filter_date'] ?? '' ); // 'today', '7d', '30d', 'all'
        $filter_cocon  = sanitize_text_field( $_POST['filter_cocon'] ?? '' );
        $page          = max( 1, (int) ( $_POST['page'] ?? 1 ) );
        $per_page      = 20;

        $where  = array( '1=1' );
        $values = array();

        // Module-to-action-type mapping
        $module_type_map = array(
            'meta'      => array( 'meta_title', 'meta_description' ),
            'schema'    => array( 'schema' ),
            'canonical' => array( 'canonical' ),
            'redirect'  => array( 'redirect' ),
            'linking'   => array( 'link_outbound', 'link_manual', 'link_removed', 'internal_link', 'link_sibling', 'link_cross_out', 'link_cross_in' ),
            'content'   => array( 'content_write', 'content_modified' ),
            'cocon'     => array( 'article_created', 'article_published', 'link_sibling', 'link_cross_out', 'link_cross_in' ),
        );

        if ( $filter_module && isset( $module_type_map[ $filter_module ] ) ) {
            $types = $module_type_map[ $filter_module ];
            $placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
            $where[] = "action_type IN ($placeholders)";
            $values = array_merge( $values, $types );
        }

        if ( $filter_type ) {
            $where[] = 'action_type = %s';
            $values[] = $filter_type;
        }

        // Date filter
        if ( $filter_date === 'today' ) {
            $where[] = 'DATE(created_at) = CURDATE()';
        } elseif ( $filter_date === '7d' ) {
            $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        } elseif ( $filter_date === '30d' ) {
            $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        }

        // Cocon filter — filter by post_id belonging to a specific cocon
        if ( $filter_cocon ) {
            $cocon_post_ids = $this->get_cocon_post_ids( $filter_cocon );
            if ( ! empty( $cocon_post_ids ) ) {
                $id_in = implode( ',', array_map( 'intval', $cocon_post_ids ) );
                $where[] = "post_id IN ($id_in)";
            }
        }

        $where_sql = implode( ' AND ', $where );

        // phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
        $total = (int) $wpdb->get_var(
            empty( $values )
                ? "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}"
                : $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $values )
        );

        $offset = ( $page - 1 ) * $per_page;
        $query_values = array_merge( $values, array( $per_page, $offset ) );
        $items = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, action_type, post_id, target_id, anchor_text, created_at
                 FROM {$table}
                 WHERE {$where_sql}
                 ORDER BY created_at DESC
                 LIMIT %d OFFSET %d",
                $query_values
            ),
            ARRAY_A
        );
        // phpcs:enable

        // Enrich with post titles and link target info
        foreach ( $items as &$item ) {
            $item['post_title'] = get_the_title( $item['post_id'] ) ?: '(#' . $item['post_id'] . ')';
            $item['type_label'] = class_exists( 'HTS_Audit_Trail' )
                ? HTS_Audit_Trail::action_label( $item['action_type'] )
                : $item['action_type'];
            $item['time_ago']   = human_time_diff( strtotime( $item['created_at'] ) );

            // v2.4.17: For linking actions, extract target info from target_id column
            $tid = (int) ( $item['target_id'] ?? 0 );
            if ( in_array( $item['action_type'], array( 'link_outbound', 'link_manual', 'link_removed' ), true ) && $tid > 0 ) {
                $item['target_title'] = get_the_title( $tid ) ?: '';
                $item['target_url']   = get_permalink( $tid ) ?: '';
            }
        }
        unset( $item );

        // Build facets (available filter counts)
        $facets = array(
            'types'   => $wpdb->get_results( "SELECT action_type, COUNT(*) as cnt FROM {$table} GROUP BY action_type ORDER BY cnt DESC", ARRAY_A ),
            'modules' => array_keys( $module_type_map ),
        );

        wp_send_json_success( array(
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'pages'    => ceil( $total / $per_page ),
            'facets'   => $facets,
        ) );
    }

    /**
     * Get post IDs belonging to a cocon cluster.
     */
    private function get_cocon_post_ids( $cluster_label ) {
        $clusters = get_option( 'hts_cocon_clusters', array() );
        foreach ( $clusters as $cl ) {
            if ( ( $cl['label'] ?? '' ) === $cluster_label || ( $cl['name'] ?? '' ) === $cluster_label ) {
                return array_column( $cl['posts'] ?? array(), 'ID' );
            }
        }
        return array();
    }

    /* =========================================================================
     * PHASE 6e — SCORE GEO-READINESS
     * ====================================================================== */

    /**
     * AJAX: Compute GEO-readiness score for a post or batch.
     */
    public function ajax_geo_readiness() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $post_id = (int) ( $_POST['post_id'] ?? 0 );

        if ( $post_id ) {
            $result = $this->compute_geo_readiness( $post_id );
            wp_send_json_success( $result );
        }

        // Batch mode: top 10 worst GEO scores
        $ids = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'fields'         => 'ids',
        ) );

        $results = array();
        foreach ( $ids as $pid ) {
            $results[] = $this->compute_geo_readiness( $pid );
        }

        // Sort by score ascending (worst first)
        usort( $results, function( $a, $b ) { return $a['score'] - $b['score']; } );

        $avg = count( $results ) > 0
            ? round( array_sum( array_column( $results, 'score' ) ) / count( $results ) )
            : 0;

        wp_send_json_success( array(
            'posts'   => array_slice( $results, 0, 10 ),
            'average' => $avg,
            'total'   => count( $results ),
        ) );
    }

    /**
     * Compute GEO-readiness score (0-100) for a single post.
     *
     * Criteria:
     *  - geo_has_lists:          Content has <ul>/<ol> lists (15 pts)
     *  - geo_has_faq:            Has FAQ structured data or FAQ-like section (15 pts)
     *  - geo_short_paragraphs:   Average paragraph < 150 words (15 pts)
     *  - geo_question_headings:  H2/H3 phrased as questions (15 pts)
     *  - geo_has_data:           Contains numbers/statistics/data (10 pts)
     *  - geo_internal_links:     Has 3+ internal links (10 pts)
     *  - geo_content_length:     800+ words (10 pts)
     *  - geo_freshness:          Updated within 6 months (10 pts)
     *
     * @param int $post_id
     * @return array  score (0-100), criteria details, recommendations
     */
    public function compute_geo_readiness( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return array( 'post_id' => $post_id, 'score' => 0, 'criteria' => array(), 'recommendations' => array() );
        }

        $content = class_exists( 'HTS_Content_Extractor' )
            ? HTS_Content_Extractor::get_content( $post_id )
            : $post->post_content;
        $text    = wp_strip_all_tags( $content );
        $words   = hts_word_count( $text );
        $title   = $post->post_title;

        $criteria = array();
        $recs     = array();

        // 1. Lists presence (15 pts)
        $has_lists = preg_match( '/<(ul|ol)\b/i', $content );
        $criteria['geo_has_lists'] = array(
            'label'  => 'Listes (ul/ol)',
            'score'  => $has_lists ? 15 : 0,
            'max'    => 15,
            'detail' => $has_lists ? 'Contient des listes structurées' : 'Aucune liste trouvée',
        );
        if ( ! $has_lists ) {
            $recs[] = 'Ajoutez des listes à puces ou numérotées pour structurer les informations clés. Les moteurs IA adorent les listes.';
        }

        // 2. FAQ section or schema (15 pts)
        $has_faq_schema = (bool) get_post_meta( $post_id, '_hts_schema_faq', true );
        $has_faq_section = (bool) preg_match( '/<h[23][^>]*>\s*(FAQ|Questions?\s+fréquentes?|Foire\s+aux\s+questions?)/i', $content );
        $has_faq_qmark = false;
        if ( preg_match_all( '/<h[23][^>]*>([^<]+\?)<\/h[23]>/i', $content, $qm ) ) {
            $has_faq_qmark = count( $qm[0] ) >= 3;
        }
        $faq_pts = ( $has_faq_schema || $has_faq_section ) ? 15 : ( $has_faq_qmark ? 10 : 0 );
        $criteria['geo_has_faq'] = array(
            'label'  => 'Section FAQ / Questions',
            'score'  => $faq_pts,
            'max'    => 15,
            'detail' => $has_faq_schema ? 'Schema FAQPage détecté' : ( $has_faq_section ? 'Section FAQ présente' : ( $has_faq_qmark ? 'Questions dans les titres' : 'Pas de FAQ' ) ),
        );
        if ( $faq_pts < 15 ) {
            $recs[] = 'Ajoutez une section FAQ avec des questions fréquentes et activez le schema FAQPage.';
        }

        // 3. Short paragraphs (15 pts)
        $paragraphs = preg_split( '/<\/p>|<br\s*\/?>\s*<br\s*\/?>|\n\n/i', $content );
        $para_words = array();
        foreach ( $paragraphs as $p ) {
            $p_text = trim( wp_strip_all_tags( $p ) );
            if ( mb_strlen( $p_text ) > 10 ) {
                $para_words[] = hts_word_count( $p_text );
            }
        }
        $avg_para = count( $para_words ) > 0 ? array_sum( $para_words ) / count( $para_words ) : 0;
        $short_pts = $avg_para <= 80 ? 15 : ( $avg_para <= 150 ? 10 : ( $avg_para <= 250 ? 5 : 0 ) );
        $criteria['geo_short_paragraphs'] = array(
            'label'  => 'Paragraphes courts',
            'score'  => $short_pts,
            'max'    => 15,
            'detail' => round( $avg_para ) . ' mots/paragraphe en moyenne',
        );
        if ( $short_pts < 15 ) {
            $recs[] = 'Découpez vos paragraphes en blocs plus courts (idéalement moins de 80 mots). Les IA extraient mieux les réponses concises.';
        }

        // 4. Question headings (15 pts)
        preg_match_all( '/<h[23][^>]*>([^<]+)<\/h[23]>/i', $content, $headings );
        $total_h23 = count( $headings[1] ?? array() );
        $question_h = 0;
        foreach ( ( $headings[1] ?? array() ) as $h ) {
            if ( preg_match( '/\?\s*$|^(comment|pourquoi|quand|combien|quel|quelle|quels|quelles|est-ce que|what|how|why|when|where|which|who|can|do|does|is|are)\b/i', trim( $h ) ) ) {
                $question_h++;
            }
        }
        $q_ratio = $total_h23 > 0 ? $question_h / $total_h23 : 0;
        $q_pts = $question_h >= 3 ? 15 : ( $question_h >= 2 ? 10 : ( $question_h >= 1 ? 5 : 0 ) );
        $criteria['geo_question_headings'] = array(
            'label'  => 'Titres en questions (H2/H3)',
            'score'  => $q_pts,
            'max'    => 15,
            'detail' => $question_h . '/' . $total_h23 . ' titres formulés en questions',
        );
        if ( $q_pts < 15 ) {
            $recs[] = 'Reformulez au moins 3 sous-titres H2/H3 en questions ("Comment...", "Pourquoi...", "Quand..."). Cela augmente vos chances d\'apparaître dans les réponses IA.';
        }

        // 5. Data / numbers (10 pts)
        $numbers = preg_match_all( '/\b\d{1,3}([.,]\d{3})*([.,]\d+)?(\s*(%|€|\$|millions?|milliards?|ans?|jours?|heures?|kg|km|m²|m³))\b/i', $text );
        $data_pts = $numbers >= 5 ? 10 : ( $numbers >= 2 ? 7 : ( $numbers >= 1 ? 3 : 0 ) );
        $criteria['geo_has_data'] = array(
            'label'  => 'Données chiffrées',
            'score'  => $data_pts,
            'max'    => 10,
            'detail' => $numbers . ' données chiffrées détectées',
        );
        if ( $data_pts < 10 ) {
            $recs[] = 'Enrichissez votre contenu avec des données chiffrées (statistiques, pourcentages, dates). Les IA citent plus facilement les contenus factuels.';
        }

        // 6. Internal links (10 pts)
        $internal_links = 0;
        $home = home_url();
        if ( preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\']/', $content, $links ) ) {
            foreach ( $links[1] as $href ) {
                if ( strpos( $href, $home ) !== false || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 ) ) {
                    $internal_links++;
                }
            }
        }
        $link_pts = $internal_links >= 5 ? 10 : ( $internal_links >= 3 ? 7 : ( $internal_links >= 1 ? 3 : 0 ) );
        $criteria['geo_internal_links'] = array(
            'label'  => 'Liens internes',
            'score'  => $link_pts,
            'max'    => 10,
            'detail' => $internal_links . ' liens internes',
        );
        if ( $link_pts < 10 ) {
            $recs[] = 'Ajoutez au moins 5 liens internes vers des pages pertinentes de votre site.';
        }

        // 7. Content length (10 pts)
        $len_pts = $words >= 1500 ? 10 : ( $words >= 800 ? 7 : ( $words >= 400 ? 4 : 0 ) );
        $criteria['geo_content_length'] = array(
            'label'  => 'Longueur du contenu',
            'score'  => $len_pts,
            'max'    => 10,
            'detail' => $words . ' mots',
        );
        if ( $len_pts < 10 ) {
            $recs[] = 'Visez au moins 1 500 mots pour un contenu approfondi que les moteurs IA peuvent utiliser comme source fiable.';
        }

        // 8. Freshness (10 pts)
        $modified = strtotime( $post->post_modified );
        $months_ago = ( time() - $modified ) / ( 30 * DAY_IN_SECONDS );
        $fresh_pts = $months_ago <= 3 ? 10 : ( $months_ago <= 6 ? 7 : ( $months_ago <= 12 ? 4 : 0 ) );
        $criteria['geo_freshness'] = array(
            'label'  => 'Fraîcheur du contenu',
            'score'  => $fresh_pts,
            'max'    => 10,
            'detail' => 'Dernière mise à jour il y a ' . round( $months_ago ) . ' mois',
        );
        if ( $fresh_pts < 10 ) {
            $recs[] = 'Mettez à jour cet article pour signaler sa fraîcheur aux moteurs. Les IA privilégient le contenu récent.';
        }

        $total_score = 0;
        foreach ( $criteria as $c ) $total_score += $c['score'];

        // Compute grade
        $grade = 'F';
        if ( $total_score >= 90 ) $grade = 'A';
        elseif ( $total_score >= 75 ) $grade = 'B';
        elseif ( $total_score >= 55 ) $grade = 'C';
        elseif ( $total_score >= 35 ) $grade = 'D';

        // Save meta for quick reference
        update_post_meta( $post_id, '_hts_geo_readiness', $total_score );

        return array(
            'post_id'         => $post_id,
            'title'           => $title,
            'score'           => $total_score,
            'grade'           => $grade,
            'criteria'        => $criteria,
            'recommendations' => $recs,
            'geo_readiness_score' => $total_score,
        );
    }
    private function get_breaker_state( $module_key ) {
        if ( class_exists( 'HTS_Health_Check' ) ) {
            // Map cockpit module keys to health check test keys
            $map = array(
                'meta_tags' => 'meta_tags', 'robots' => 'robots_meta', 'canonical' => 'canonical',
                'schema' => 'schema_jsonld', 'sitemap' => 'sitemap_xml', 'redirects' => 'redirects',
                'meta_score' => 'meta_score', 'onpage_score' => 'onpage_score',
                'embeddings' => 'embeddings', 'content_extractor' => 'content_extractor',
            );
            $test_key = $map[ $module_key ] ?? '';
            if ( $test_key ) {
                return HTS_Health_Check::get_breaker_status( $test_key );
            }
        }
        return 'ok';
    }

    /**
     * Light-specific self-tests (when HTS_Health_Check is not available).
     * Covers the essentials: sitemap, meta tags, canonical, schema, competitors.
     */
    private function run_light_self_tests() {
        $results = array();

        // 1. Sitemap accessibility (P0 — most critical)
        $sitemap_url = home_url( '/sitemap.xml' );
        $response = wp_remote_get( $sitemap_url, array(
            'timeout'   => 5,
            'sslverify' => false,
            'headers'   => array( 'Accept' => 'application/xml, text/xml, */*' ),
        ) );
        if ( is_wp_error( $response ) ) {
            $results[] = array( 'key' => 'Sitemap XML', 'status' => 'fail', 'message' => 'Inaccessible : ' . $response->get_error_message() );
        } else {
            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            if ( $code !== 200 ) {
                $results[] = array( 'key' => 'Sitemap XML', 'status' => 'fail', 'message' => 'HTTP ' . $code . ' — attendu 200' );
            } elseif ( strpos( $body, '<sitemapindex' ) === false && strpos( $body, '<urlset' ) === false ) {
                $results[] = array( 'key' => 'Sitemap XML', 'status' => 'fail', 'message' => 'HTTP 200 mais pas de XML valide (page blanche ou HTML renvoyé)' );
            } else {
                $results[] = array( 'key' => 'Sitemap XML', 'status' => 'ok', 'message' => 'Accessible — HTTP 200, XML valide' );
            }
        }

        // 2. Meta Tags module
        if ( get_option( 'hts_module_meta_tags', '1' ) === '1' ) {
            $sep = get_option( 'hts_title_separator' );
            $results[] = array( 'key' => 'Meta Tags', 'status' => $sep ? 'ok' : 'warn', 'message' => $sep ? 'Actif — séparateur : ' . $sep : 'Séparateur de titre non configuré' );
        } else {
            $results[] = array( 'key' => 'Meta Tags', 'status' => 'warn', 'message' => 'Module désactivé' );
        }

        // 3. Canonical
        if ( get_option( 'hts_module_canonical', '1' ) === '1' ) {
            $results[] = array( 'key' => 'Canonical', 'status' => 'ok', 'message' => 'Actif — self-referencing' );
        } else {
            $results[] = array( 'key' => 'Canonical', 'status' => 'warn', 'message' => 'Désactivé — WP utilise son canonical natif' );
        }

        // 4. Schema
        if ( get_option( 'hts_module_schema', '1' ) === '1' ) {
            $results[] = array( 'key' => 'Schema JSON-LD', 'status' => 'ok', 'message' => 'Actif — auto-détection Article/FAQ/HowTo' );
        } else {
            $results[] = array( 'key' => 'Schema JSON-LD', 'status' => 'warn', 'message' => 'Module désactivé' );
        }

        // 5. Redirections
        if ( get_option( 'hts_module_redirects', '1' ) === '1' ) {
            global $wpdb;
            $table = $wpdb->prefix . 'hts_redirects';
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
                $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
                $results[] = array( 'key' => 'Redirections', 'status' => 'ok', 'message' => $count . ' redirection(s) active(s)' );
            } else {
                $results[] = array( 'key' => 'Redirections', 'status' => 'warn', 'message' => 'Table non créée — module en attente' );
            }
        }

        // 6. No competitor plugin conflict
        $conflicts = $this->detect_conflicts();
        if ( empty( $conflicts ) ) {
            $results[] = array( 'key' => 'Conflits SEO', 'status' => 'ok', 'message' => 'Aucun autre plugin SEO actif' );
        } else {
            $names = array_map( function( $c ) { return $c['name']; }, $conflicts );
            $results[] = array( 'key' => 'Conflits SEO', 'status' => 'warn', 'message' => 'Autre(s) plugin(s) SEO actif(s) : ' . implode( ', ', $names ) );
        }

        // 7. Robots.txt accessible
        $robots_url = home_url( '/robots.txt' );
        $robots_resp = wp_remote_head( $robots_url, array( 'timeout' => 3, 'sslverify' => false ) );
        if ( ! is_wp_error( $robots_resp ) && wp_remote_retrieve_response_code( $robots_resp ) === 200 ) {
            $results[] = array( 'key' => 'Robots.txt', 'status' => 'ok', 'message' => 'Accessible — HTTP 200' );
        } else {
            $results[] = array( 'key' => 'Robots.txt', 'status' => 'warn', 'message' => 'Non accessible' );
        }

        // 8. Permalink structure (sitemaps need pretty permalinks)
        $structure = get_option( 'permalink_structure' );
        if ( ! empty( $structure ) ) {
            $results[] = array( 'key' => 'Permaliens', 'status' => 'ok', 'message' => 'Structure : ' . $structure );
        } else {
            $results[] = array( 'key' => 'Permaliens', 'status' => 'fail', 'message' => 'Permaliens "simples" — le sitemap XML nécessite des permaliens personnalisés' );
        }

        // 9. IndexNow
        if ( get_option( 'hts_indexnow_enabled', '0' ) === '1' ) {
            $inow_stats = class_exists( 'HTS_IndexNow' ) ? HTS_IndexNow::get_stats() : array( 'total' => 0 );
            $results[] = array( 'key' => 'IndexNow', 'status' => 'ok', 'message' => 'Actif — ' . (int) $inow_stats['total'] . ' ping(s) envoyé(s)' );
        } else {
            $results[] = array( 'key' => 'IndexNow', 'status' => 'warn', 'message' => 'Désactivé — activable dans Réglages SEO' );
        }

        // 10. llms.txt
        if ( get_option( 'hts_llmstxt_enabled', '1' ) === '1' ) {
            $llms_resp = wp_remote_head( home_url( '/llms.txt' ), array( 'timeout' => 3, 'sslverify' => false ) );
            if ( ! is_wp_error( $llms_resp ) && wp_remote_retrieve_response_code( $llms_resp ) === 200 ) {
                $results[] = array( 'key' => 'llms.txt', 'status' => 'ok', 'message' => 'Actif et accessible — HTTP 200' );
            } else {
                // Loopback HTTP often blocked by hosting — try functional check instead
                if ( class_exists( 'HTS_LLMs_Txt' ) ) {
                    $llms = new HTS_LLMs_Txt();
                    $content = $llms->get_content();
                    if ( ! empty( $content ) && strpos( $content, '#' ) !== false ) {
                        $results[] = array( 'key' => 'llms.txt', 'status' => 'ok', 'message' => 'Actif — contenu généré (' . strlen( $content ) . ' caractères). Vérifiez ' . home_url( '/llms.txt' ) . ' dans votre navigateur.' );
                    } else {
                        $results[] = array( 'key' => 'llms.txt', 'status' => 'warn', 'message' => 'Activé mais contenu vide — vérifiez manuellement ' . home_url( '/llms.txt' ) );
                    }
                } else {
                    $results[] = array( 'key' => 'llms.txt', 'status' => 'warn', 'message' => 'Module chargé mais HTTP loopback bloqué — vérifiez ' . home_url( '/llms.txt' ) );
                }
            }
        } else {
            $results[] = array( 'key' => 'llms.txt', 'status' => 'warn', 'message' => 'Désactivé — activable dans Réglages SEO' );
        }

        return $results;
    }

    /* ══════════════════════════════════════════════
     *  RENDER
     * ══════════════════════════════════════════════ */

    public function render() {
        // P2 #28: Warn if DISABLE_WP_CRON is active and crons haven't run in 48h
        if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
            $last_run = (int) get_option( 'hts_last_cron_run', 0 );
            if ( $last_run > 0 && ( time() - $last_run ) > 48 * 3600 ) {
                echo '<div class="notice notice-warning"><p><strong>HTS :</strong> Les tâches planifiées n\'ont pas été exécutées depuis plus de 48h. Vérifiez que votre cron système est configuré (<code>wp-cron.php</code>).</p></div>';
            }
        }

        // Route to diagnostic if ?tab=diag
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'diag' ) {
            if ( class_exists( 'HTS_Diagnostic' ) ) {
                $diag = new HTS_Diagnostic();
                $diag->render_page();
                return;
            }
        }

        // Route to test suite if ?tab=test-suite
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'test-suite' ) {
            if ( class_exists( 'HTS_Test_Suite' ) ) {
                $ts = new HTS_Test_Suite();
                $ts->render_page();
                return;
            }
        }

        // Route to global score → redirect to settings Santé
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'global-score' ) {
            echo '<script>window.location.replace(' . wp_json_encode( admin_url( 'admin.php?page=hts-api-settings&stab=health' ) ) . ');</script>';
            return;
        }

        // Route to health check → redirect to settings Santé
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'health' ) {
            echo '<script>window.location.replace(' . wp_json_encode( admin_url( 'admin.php?page=hts-api-settings&stab=health' ) ) . ');</script>';
            return;
        }

        // Route to Coach SEO if ?tab=coach
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'coach' ) {
            $this->render_coach_page();
            return;
        }

        // Route to Inbox if ?tab=inbox (v2.3.0)
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'inbox' ) {
            $this->render_inbox_page();
            return;
        }

        // Sprint 6.3e: Impact tab removed — redirect to Inbox (Historique & Impact)
        if ( isset( $_GET['tab'] ) && $_GET['tab'] === 'impact' ) {
            $this->render_inbox_page();
            return;
        }

        // ═══ S13: DS v5.7 Dashboard — replace legacy dashboard with partial ═══
        // No ?tab parameter = default dashboard view
        if ( ! isset( $_GET['tab'] ) || $_GET['tab'] === '' ) {
            $partial = HTS__PLUGIN_DIR . 'admin/partials/dashboard.php';
            if ( file_exists( $partial ) ) {
                // Prepare variables expected by the partial
                $nonce       = wp_create_nonce( 'hts_cockpit' );
                $base_url    = admin_url( 'admin.php?page=hts-light-dashboard' );
                $inbox_count = 0;
                if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
                    $wf_stats    = HTS_Workflow_Engine::get_stats();
                    $inbox_count = (int) ( $wf_stats['pending'] ?? 0 );
                }
                include $partial;
                return; // ← Phase 2D: confirmed dead code below — legacy fallback never executes while dashboard.php exists
            }
        }

        // ══════════════════════════════════════════════════════════════════
        // LEGACY FALLBACK DASHBOARD (dead code — kept for safety)
        // This block only runs if admin/partials/dashboard.php is missing.
        // ══════════════════════════════════════════════════════════════════
        $modules   = $this->get_modules();
        $conflicts = $this->detect_conflicts();
        $nonce     = wp_create_nonce( 'hts_cockpit' );
        $orch_settings = get_option( 'hts_orchestrator_settings', array() );
        $auto_mode = ! empty( $orch_settings['auto_mode'] );

        // Inbox badge count (v2.3.0)
        $inbox_count = 0;
        if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
            $wf_stats = HTS_Workflow_Engine::get_stats();
            $inbox_count = (int) ( $wf_stats['pending'] ?? 0 );
        }
        $base_url = admin_url( 'admin.php?page=hts-light-dashboard' );
        ?>
        <div class="hts-wrap">

        <!-- HEADER -->
        <div class="hts-header">
            <div class="hts-header-left">
                <div class="hts-header-logo">
                    <img src="<?php echo esc_url( plugins_url( '../admin/assets/icons/icon-admin.svg', __FILE__ ) ); ?>" alt="Hack The SEO">
                </div>
                <div>
                    <h1 style="color:#fff;font-size:22px;font-weight:700;margin:0;line-height:1.2;">Tableau de bord SEO <span style="color:rgba(255,255,255,.7);font-size:13px;font-weight:400;">v<?php echo esc_html( HTS__VERSION ); ?></span></h1>
                    <p style="color:rgba(255,255,255,.8);font-size:13px;margin-top:2px;">
                        Vue d'ensemble de la santé SEO de votre site
                    </p>
                </div>
            </div>
        </div>

        <?php if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) :
            $available_langs = HTS_Language::get_available_languages();
            $current_lang    = HTS_Language::get_current_lang();
        ?>
        <div style="display:flex;align-items:center;gap:8px;margin:12px 0 4px;padding:0 4px;">
            <span style="font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.5px;">Langue :</span>
            <?php foreach ( $available_langs as $code => $name ) : ?>
            <a href="<?php echo esc_url( add_query_arg( 'lang', $code ) ); ?>"
               style="font-size:12px;padding:4px 12px;border-radius:6px;text-decoration:none;border:1px solid <?php echo esc_attr( $code ) === $current_lang ? '#6366f1' : '#e5e7eb'; ?>;background:<?php echo esc_attr( $code ) === $current_lang ? '#eef2ff' : '#fff'; ?>;font-weight:<?php echo esc_html( $code ) === $current_lang ? '600' : '400'; ?>;color:<?php echo esc_attr( $code ) === $current_lang ? '#6366f1' : '#64748b'; ?>;">
                <?php echo esc_html( strtoupper( $code ) ); ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- ═══ NAV ONGLETS (v2.3.0) ═══ -->
        <div class="hts-cockpit-tabs">
            <a href="<?php echo esc_url( $base_url ); ?>" class="hts-cockpit-tab active">Dashboard</a>
            <a href="<?php echo esc_url( $base_url . '&tab=inbox' ); ?>" class="hts-cockpit-tab">Inbox<?php if ( $inbox_count > 0 ) : ?> <span class="hts-tab-badge"><?php echo (int) $inbox_count; ?></span><?php endif; ?></a>
            <a href="<?php echo esc_url( $base_url . '&tab=coach' ); ?>" class="hts-cockpit-tab">🤖 Coach SEO<?php
                $coach_alert_n = class_exists( 'HTS_Coach' ) ? HTS_Coach::get_alert_count() : 0;
                if ( $coach_alert_n > 0 ) : ?> <span class="hts-tab-badge hts-tab-badge-coach"><?php echo (int) $coach_alert_n; ?></span><?php endif;
            ?></a>
            <a href="<?php echo esc_url( $base_url . '&tab=health' ); ?>" class="hts-cockpit-tab">🏥 Santé</a>
        </div>

        <style>
        /* ── Nav onglets (v2.3.0) ── */
        .hts-cockpit-tabs { display:flex; gap:4px; margin:16px 0 20px; padding:4px; background:#f1f5f9; border-radius:10px; }
        .hts-cockpit-tab { display:flex; align-items:center; gap:6px; padding:10px 18px; font-size:13px; font-weight:600; color:#64748b; text-decoration:none; border-radius:8px; transition:all .15s; white-space:nowrap; }
        .hts-cockpit-tab:hover { color:#4f46e5; background:rgba(99,102,241,.06); }
        .hts-cockpit-tab.active { color:#4f46e5; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,.08); }
        .hts-tab-badge { display:inline-flex; align-items:center; justify-content:center; min-width:20px; height:20px; padding:0 6px; font-size:11px; font-weight:700; color:#fff; background:#ef4444; border-radius:10px; }
        .hts-cockpit-tab.active .hts-tab-badge { background:#4f46e5; }
        .hc { max-width:100%; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }
        .hc-alert { padding:12px 16px; border-radius:8px; margin-bottom:16px; font-size:13px; display:flex; align-items:flex-start; gap:10px; }
        .hc-alert.fail { background:#fef2f2; border:1px solid rgba(220,38,38,.15); color:#991b1b; }
        .hc-alert.ok { background:#f0fdf4; border:1px solid rgba(22,163,74,.15); color:#166534; }
        .hc-row { display:flex; align-items:center; gap:16px; padding:14px 18px; background:#fff; border:1px solid #e5e7eb; border-radius:8px; margin-bottom:8px; transition:border-color .15s; }
        .hc-row:hover { border-color:#6366f1; }
        .hc-toggle { position:relative; width:40px; height:22px; flex-shrink:0; }
        .hc-toggle input { opacity:0; width:0; height:0; position:absolute; pointer-events:none; }
        .hc-toggle .slider { position:absolute; inset:0; background:#d1d5db; border-radius:11px; cursor:pointer; transition:background .2s; }
        .hc-toggle .slider::after { content:''; position:absolute; width:16px; height:16px; background:#fff; border-radius:50%; top:3px; left:3px; transition:transform .2s; }
        .hc-toggle input:checked + .slider { background:#6366f1; }
        .hc-toggle input:checked + .slider::after { transform:translateX(18px); }
        .hc-info { flex:1; min-width:0; }
        .hc-info .name { font-size:13.5px; font-weight:600; color:#1a1f36; }
        .hc-info .desc { font-size:11.5px; color:#9da5b4; margin-top:1px; }
        .hc-status { font-size:11px; font-weight:600; padding:3px 10px; border-radius:10px; white-space:nowrap; }
        .hc-status.ok { background:#f0fdf4; color:#16a34a; }
        .hc-status.warn { background:#fffbeb; color:#d97706; }
        .hc-status.fail { background:#fef2f2; color:#dc2626; }
        .hc-status.off { background:#f3f4f6; color:#9da5b4; }
        .hc-status.degraded { background:#fff7ed; color:#c2410c; }
        .hc-section { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:#9da5b4; margin:20px 0 8px; }
        /* Session I — Tooltip aide contextuelle */
        .hts-help-tip { display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:#e5e7eb;color:#64748b;font-size:10px;font-weight:700;cursor:help;position:relative;margin-left:6px;vertical-align:middle;line-height:1;font-style:normal;transition:background .15s; }
        .hts-help-tip:hover { background:#6366f1;color:#fff; }
        .hts-help-tip .hts-help-bubble { display:none;position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);width:280px;padding:12px 14px;background:#1e293b;color:#f1f5f9;border-radius:8px;font-size:12px;font-weight:400;text-transform:none;letter-spacing:0;line-height:1.5;box-shadow:0 4px 16px rgba(0,0,0,.2);z-index:100;pointer-events:none; }
        .hts-help-tip .hts-help-bubble::after { content:'';position:absolute;top:100%;left:50%;transform:translateX(-50%);border:6px solid transparent;border-top-color:#1e293b; }
        .hts-help-tip:hover .hts-help-bubble { display:block; }
        .hc-killbox { background:#fff; border:2px solid #fecaca; border-radius:10px; padding:16px 20px; margin-bottom:20px; display:flex; align-items:center; justify-content:space-between; }
        .hc-killbox.safe { border-color:#bbf7d0; }
        .hc-test-result { padding:6px 12px; font-size:12px; border-radius:6px; margin:3px 0; display:flex; align-items:center; gap:8px; }
        .hc-test-result.ok { background:#f0fdf4; color:#166534; }
        .hc-test-result.fail { background:#fef2f2; color:#991b1b; }
        .hc-test-result.warn { background:#fffbeb; color:#92400e; }
        /* ── Loading states (Phase 5c) ── */
        @keyframes hts-spin { to { transform: rotate(360deg); } }
        @keyframes hts-pulse { 0%,100% { opacity:1; } 50% { opacity:.5; } }
        .hts-loading { position:relative; pointer-events:none; opacity:.7; }
        .hts-loading::after {
            content:''; position:absolute; right:8px; top:50%; width:14px; height:14px;
            margin-top:-7px; border:2px solid rgba(99,102,241,.3); border-top-color:#6366f1;
            border-radius:50%; animation:hts-spin .6s linear infinite;
        }
        .hts-btn-loading { pointer-events:none; opacity:.7; }
        .hts-pulse { animation:hts-pulse 1.5s ease-in-out infinite; }
        /* ── Skeleton loaders (Session G) ── */
        @keyframes htsSkelPulse { 0%,100% { opacity:1; } 50% { opacity:.4; } }
        .hts-lazy-section .hts-lazy-content { opacity:0; transition:opacity .3s ease; }
        .hts-lazy-section.hts-lazy-visible .hts-lazy-content { display:block !important; opacity:1; }
        .hts-lazy-section.hts-lazy-visible .hts-skeleton-loader { display:none; }
        </style>
        <script>
        /* S12: htsBtn helper — button loading state manager */
        function htsBtn(btn, loading, loadingText) {
            if (!btn) return;
            if (loading) {
                btn.dataset.origText = btn.textContent;
                btn.disabled = true;
                btn.textContent = loadingText || 'Chargement...';
            } else {
                btn.disabled = false;
                btn.textContent = btn.dataset.origText || 'OK';
            }
        }
        (function(){
            if (!('IntersectionObserver' in window)) {
                document.querySelectorAll('.hts-lazy-section').forEach(function(s){ s.classList.add('hts-lazy-visible'); });
                return;
            }
            var observer = new IntersectionObserver(function(entries){
                entries.forEach(function(entry){
                    if (entry.isIntersecting) {
                        entry.target.classList.add('hts-lazy-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { rootMargin: '200px' });
            document.querySelectorAll('.hts-lazy-section').forEach(function(s){ observer.observe(s); });
        })();
        </script>

        <div class="hc">

        <!-- ═══ KILL SWITCH (Full only) ═══ -->
        <?php if ( ! defined( 'HTS__IS_LIGHT' ) || ! HTS__IS_LIGHT ) : ?>
        <div class="hc-killbox <?php echo $auto_mode ? '' : 'safe'; ?>">
            <div>
                <div style="font-size:14px;font-weight:700;color:<?php echo $auto_mode ? '#dc2626' : '#166534'; ?>;">
 <?php echo $auto_mode ? 'Autonomie ACTIVE' : 'Autonomie désactivée'; ?>
                </div>
                <div class="hts-fs-sm hts-text-secondary hts-mt-1">
                    <?php echo $auto_mode
                        ? 'L\'Orchestrator peut exécuter des actions automatiquement.'
                        : 'Le système propose uniquement, aucune action automatique.'; ?>
                </div>
            </div>
            <button type="button" onclick="hcKillSwitch()" id="hc-kill-btn"
                style="padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;border:2px solid #dc2626;background:<?php echo $auto_mode ? '#dc2626' : '#fff'; ?>;color:<?php echo $auto_mode ? '#fff' : '#dc2626'; ?>;">
 STOPPER L'AUTONOMIE
            </button>
        </div>
        <?php endif; ?>

        <!-- ═══ CONFLICTS ═══ -->
        <?php if ( ! empty( $conflicts ) ) : ?>
            <?php foreach ( $conflicts as $c ) : ?>
                <div class="hc-alert fail">
                    <?php HTS_Icons::render("alert-triangle","hts-icon--lg hts-icon--danger"); ?>
                    <div><strong><?php echo esc_html( $c['name'] ); ?></strong> détecté — <?php echo esc_html( $c['msg'] ); ?>
                    <br><strong>Action recommandée :</strong> Désactiver ce plugin et ne garder que Hack The SEO pour éviter les conflits SEO.
                    <br><a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>" style="font-weight:600;">Gérer les extensions →</a>
                    <?php if ( class_exists( 'HTS_Migration_Wizard' ) ) : ?>
                    <?php if ( get_option( 'hts_migration_state' ) === 'completed' ) : ?>
                     | <span style="color:#d97706;">Données migrées — désactivez <?php echo esc_html( $c['name'] ); ?> pour éviter les doublons</span>
                    <?php else : ?>
                     | <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-migration-wizard' ) ); ?>">Migrer les données →</a>
                    <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php
        // ═══ GSC SITEMAP NOTICE — show after migration when competitor is gone ═══
        $migration_done = get_option( 'hts_migration_state' ) === 'completed';
        $gsc_notice_dismissed = get_option( 'hts_gsc_sitemap_notice_dismissed', false );
        if ( $migration_done && empty( $conflicts ) && ! $gsc_notice_dismissed ) : ?>
            <div class="hc-alert" style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:14px 18px;margin-bottom:12px;display:flex;align-items:flex-start;gap:12px;">
                
                <div style="flex:1;">
                    <strong style="color:#92400e;">Mettez à jour votre sitemap dans Google Search Console</strong>
                    <p style="font-size:13px;color:#a16207;margin:6px 0 10px;">
                        Votre ancien plugin SEO utilisait un sitemap différent. Allez dans
                        <strong>Google Search Console → Sitemaps</strong>, supprimez l'ancien et ajoutez :
                    </p>
                    <code style="display:inline-block;padding:6px 14px;background:#fef3c7;border:1px solid #fde68a;border-radius:4px;font-size:13px;font-weight:600;color:#92400e;user-select:all;"><?php echo esc_url( home_url( '/sitemap.xml' ) ); ?></code>
                    <div style="margin-top:10px;display:flex;gap:10px;align-items:center;">
                        <a href="https://search.google.com/search-console/sitemaps" target="_blank"
                           style="padding:6px 14px;background:#f59e0b;color:#fff;border-radius:5px;font-size:12px;font-weight:600;text-decoration:none;">
                            Ouvrir Google Search Console →
                        </a>
                        <button onclick="fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=hts_dismiss_gsc_notice&nonce=<?php echo wp_create_nonce('hts_cockpit'); ?>'}).then(()=>this.closest('.hc-alert').remove())"
                                style="background:none;border:none;color:#a16207;font-size:12px;cursor:pointer;text-decoration:underline;">
                            C'est fait, masquer
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- ═══ RÉSUMÉ HEBDO (Session I) ═══ -->
        <?php
        // Pre-load cached stats (used by summary + feature cards)
        $ck_stats     = $this->get_cached_stats();
        $score_count  = $ck_stats['score_count'];
        $score_avg    = $ck_stats['score_avg'];
        $savg_color = $score_avg >= 80 ? '#16a34a' : ( $score_avg >= 50 ? '#d97706' : '#dc2626' );

        // Compute weekly summary from workflow stats
        $weekly_summary = array( 'actions_done' => 0, 'actions_pending' => 0, 'score_delta' => 0 );
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $wf_stats_w = HTS_Workflow_Engine::get_stats();
            $weekly_summary['actions_done']    = (int) ( $wf_stats_w['done'] ?? 0 );
            $weekly_summary['actions_pending'] = (int) ( $wf_stats_w['pending'] ?? 0 );
        }
        $weekly_summary['score_delta'] = $ck_stats['trend_delta'] ?? 0;
        $ws_delta = $weekly_summary['score_delta'];
        $ws_delta_color = $ws_delta > 0 ? '#16a34a' : ( $ws_delta < 0 ? '#dc2626' : '#64748b' );
        $ws_delta_icon = $ws_delta > 0 ? '📈' : ( $ws_delta < 0 ? '📉' : '➡️' );
        $ws_done = $weekly_summary['actions_done'];
        $ws_pending = $weekly_summary['actions_pending'];
        ?>
        <div style="background:linear-gradient(135deg,#eef2ff 0%,#faf5ff 100%);border:1px solid #c7d2fe;border-radius:12px;padding:20px 24px;margin-bottom:16px;">
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                <span style="font-size:20px;">🎯</span>
                <div>
                    <div style="font-size:15px;font-weight:700;color:#1a1f36;">Résumé de votre site</div>
                    <div style="font-size:11px;color:#64748b;">Vue rapide de l'état de votre SEO</div>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;">
                <div style="background:#fff;border-radius:8px;padding:12px 14px;text-align:center;">
                    <div style="font-size:22px;font-weight:800;color:<?php echo esc_attr( $ws_delta_color ); ?>;"><?php echo esc_html( $ws_delta_icon ); ?> <?php echo (int) $ws_delta > 0 ? '+' . $ws_delta : $ws_delta; ?></div>
                    <div style="font-size:11px;color:#94a3b8;margin-top:2px;">Évolution score</div>
                </div>
                <div style="background:#fff;border-radius:8px;padding:12px 14px;text-align:center;">
                    <div style="font-size:22px;font-weight:800;color:#16a34a;"><?php echo (int) $ws_done; ?></div>
                    <div style="font-size:11px;color:#94a3b8;margin-top:2px;">Actions appliquées</div>
                </div>
                <div style="background:#fff;border-radius:8px;padding:12px 14px;text-align:center;">
                    <div style="font-size:22px;font-weight:800;color:#6366f1;">📋 <?php echo (int) $ws_pending; ?></div>
                    <div style="font-size:11px;color:#94a3b8;margin-top:2px;">En attente</div>
                </div>
                <div style="background:#fff;border-radius:8px;padding:12px 14px;text-align:center;">
                    <div style="font-size:22px;font-weight:800;color:<?php echo esc_attr( $savg_color ) ?? '#6366f1'; ?>;"><?php echo (int) ( $ck_stats['score_avg'] ?? 0 ); ?>/100</div>
                    <div style="font-size:11px;color:#94a3b8;margin-top:2px;">Score moyen</div>
                </div>
            </div>
            <?php if ( $ws_pending > 0 ) : ?>
            <div style="margin-top:12px;text-align:center;">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>"
                   style="display:inline-flex;align-items:center;gap:6px;padding:8px 20px;background:#6366f1;color:#fff;border-radius:8px;font-size:12px;font-weight:700;text-decoration:none;box-shadow:0 2px 8px rgba(99,102,241,.2);">
                    Traiter les <?php echo (int) $ws_pending; ?> proposition<?php echo $ws_pending > 1 ? 's' : ''; ?> →
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- ═══ SANTÉ DU PLUGIN (Phase 5b) ═══ -->
        <?php
        $health_available = class_exists( 'HTS_Health_Check' );
        $health_summary   = $health_available ? HTS_Health_Check::get_cockpit_summary() : null;
        $health_score     = $health_summary ? $health_summary['score'] : null;
        $health_last_run  = $health_summary ? $health_summary['last_run'] : null;
        $health_next_cron = $health_summary ? $health_summary['next_cron'] : null;
        $health_disabled  = $health_summary ? $health_summary['disabled_count'] : 0;
        $health_ok        = $health_summary ? $health_summary['ok'] : 0;
        $health_warn      = $health_summary ? $health_summary['warn'] : 0;
        $health_fail      = $health_summary ? $health_summary['fail'] : 0;
        $health_total     = $health_summary ? $health_summary['total'] : 0;

        // Score color
        if ( $health_score === null ) {
            $score_color = '#94a3b8'; $score_bg = '#f1f5f9'; $score_label = 'Pas encore analysé';
        } elseif ( $health_score >= 80 ) {
            $score_color = '#16a34a'; $score_bg = '#f0fdf4'; $score_label = 'Bon état';
        } elseif ( $health_score >= 50 ) {
            $score_color = '#d97706'; $score_bg = '#fffbeb'; $score_label = 'Attention requise';
        } else {
            $score_color = '#dc2626'; $score_bg = '#fef2f2'; $score_label = 'Problèmes détectés';
        }

        // Group labels
        $group_labels = $health_available ? HTS_Health_Check::get_group_labels() : array();
        $group_icons  = array( 'infrastructure' => '', 'seo_technique' => '', 'intelligence' => '' );

        // Per-group summary from saved results
        $health_results  = get_option( 'hts_health_results', array() );
        $per_group = array();
        if ( ! empty( $health_results['results'] ) && $health_available ) {
            foreach ( HTS_Health_Check::get_tests() as $tkey => $tdef ) {
                $g = $tdef['group'];
                if ( ! isset( $per_group[ $g ] ) ) $per_group[ $g ] = array( 'ok' => 0, 'warn' => 0, 'fail' => 0, 'total' => 0 );
                $per_group[ $g ]['total']++;
                $st = $health_results['results'][ $tkey ]['status'] ?? 'unknown';
                if ( $st === 'ok' ) $per_group[ $g ]['ok']++;
                elseif ( $st === 'warn' ) $per_group[ $g ]['warn']++;
                elseif ( $st === 'fail' ) $per_group[ $g ]['fail']++;
            }
        }
        ?>

        <!-- ═══ INBOX RÉSUMÉ (v2.3.0) ═══ -->
        <?php
        $inbox_cards_preview = array();
        if ( $inbox_count > 0 && class_exists( 'HTS_Workflow_Engine' ) ) {
            $inbox_cards_preview = HTS_Workflow_Engine::get_inbox_cards();
        }
        if ( $inbox_count > 0 && ! empty( $inbox_cards_preview ) ) :
            $agent_icons_dash = array(
                'coach' => '', 'fresh' => '', 'geo_score' => '', 'meta' => '',
                'linking' => '', 'cannib' => '', 'strategy' => '', 'auto_write' => '', 'monitoring' => '',
            );
        ?>
        <div class="hc-section hts-mt-4">Propositions en attente (<?php echo (int) $inbox_count; ?>)</div>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden;margin-bottom:20px;">
            <?php foreach ( array_slice( $inbox_cards_preview, 0, 3 ) as $icp ) :
                $icp_icon = $agent_icons_dash[ $icp['agent'] ] ?? '📋';
            ?>
            <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid #f3f4f6;">
                <span style="font-size:16px;"><?php echo esc_attr( $icp_icon ); ?></span>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:13px;font-weight:600;color:#1a1f36;"><?php echo esc_html( $icp['agent_label'] ); ?></div>
                    <div style="font-size:11px;color:#94a3b8;"><?php echo (int) $icp['count']; ?> <?php echo esc_html( $icp['type_label'] ); ?></div>
                </div>
                <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:6px;color:#fff;background:<?php echo esc_attr( $icp['priority_max'] ) === 'critical' ? '#dc2626' : ( $icp['priority_max'] === 'high' ? '#d97706' : '#6366f1' ); ?>;">
                    <?php echo esc_html( $icp['priority_max'] ); ?>
                </span>
            </div>
            <?php endforeach; ?>
            <div style="padding:12px 16px;text-align:center;">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>"
                   style="font-size:13px;font-weight:600;color:#6366f1;text-decoration:none;">
                    Voir toutes les propositions →
                </a>
            </div>
        </div>
        <?php else : ?>
        <!-- CTA Analyser mon site quand Inbox vide -->
        <div class="hc-section hts-mt-4">Inbox — Propositions des agents <i class="hts-help-tip">?<span class="hts-help-bubble">Vos agents IA analysent votre site et proposent des actions ici. Vous gardez le contrôle : chaque proposition peut être approuvée, ignorée ou rejetée.</span></i></div>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:24px;margin-bottom:20px;text-align:center;">
            <div style="font-size:14px;font-weight:600;color:#1a1f36;margin-bottom:6px;">Aucune proposition pour le moment</div>
            <div style="font-size:12px;color:#94a3b8;margin-bottom:16px;">Lancez une analyse pour détecter les opportunités SEO sur votre site.</div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>"
               style="display:inline-flex;align-items:center;gap:8px;padding:10px 20px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border-radius:8px;font-size:13px;font-weight:700;text-decoration:none;box-shadow:0 2px 12px rgba(79,70,229,.2);">
                Analyser mon site
            </a>
        </div>
        <?php endif; ?>

        <?php
        // ═══ ALERT: Inefficient agents (Session I) ═══
        $ineff_alerts = get_option( 'hts_agent_inefficiency_alerts', array() );
        if ( ! empty( $ineff_alerts ) ) : ?>
        <div style="background:linear-gradient(135deg,#fef2f2 0%,#fff7ed 100%);border:1px solid #fca5a5;border-radius:10px;padding:16px 20px;margin-bottom:16px;">
            <div style="display:flex;align-items:flex-start;gap:10px;">
                <span style="font-size:18px;">⚠️</span>
                <div style="flex:1;">
                    <div style="font-size:13px;font-weight:700;color:#991b1b;">Agent<?php echo count( $ineff_alerts ) > 1 ? 's' : ''; ?> peu efficace<?php echo count( $ineff_alerts ) > 1 ? 's' : ''; ?> détecté<?php echo count( $ineff_alerts ) > 1 ? 's' : ''; ?></div>
                    <div style="font-size:12px;color:#7c2d12;margin-top:4px;">
                        <?php foreach ( $ineff_alerts as $ineff ) : ?>
                        <div style="margin-bottom:4px;">
                            <strong><?php echo esc_html( $ineff['agent'] ); ?></strong> — taux de réussite de <?php echo (int) $ineff['success_rate']; ?>% sur <?php echo (int) $ineff['count']; ?> actions mesurées.
                            <span style="color:#94a3b8;font-size:11px;">Nous recommandons de le désactiver ou reconfigurer.</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-settings&tab=agents' ) ); ?>"
                       style="display:inline-block;margin-top:8px;padding:5px 14px;border-radius:6px;font-size:11px;font-weight:600;background:#dc2626;color:#fff;text-decoration:none;">
                        Configurer les agents →
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- S12: Impact A/B Testing migre vers Analytics -->
        <!-- S12: Agent Settings Widget migre vers settings-unified.php agents tab -->
        <div class="hc-section hts-mt-4">Coach SEO — Votre assistant IA personnel <i class="hts-help-tip">?<span class="hts-help-bubble">Le Coach analyse votre site et génère des recommandations personnalisées. Il crée des propositions directement dans votre Inbox pour action rapide.</span></i></div>
        <div style="background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%);border-radius:12px;padding:24px 28px;display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;box-shadow:0 4px 24px rgba(79,70,229,.2);">
            <div>
                <div style="font-size:16px;font-weight:700;color:#fff;margin-bottom:4px;">Posez vos questions SEO au Coach</div>
                <div style="font-size:13px;color:rgba(255,255,255,.85);max-width:480px;">Il analyse vos vrais scores, vos pages et votre trafic pour vous donner des conseils personnalisés avec des graphiques.</div>
            </div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=coach' ) ); ?>"
               style="padding:12px 24px;background:#fff;color:#4f46e5;border-radius:8px;font-weight:700;font-size:13px;text-decoration:none;white-space:nowrap;box-shadow:0 2px 8px rgba(0,0,0,.1);transition:transform .15s;">
                Ouvrir le Coach
            </a>
        </div>

        <!-- S12: Sante detaillee migre vers health.php -->
        <!-- S12: Health Check JS migre vers health.php -->
        <?php $this->render_section_cannibalization(); ?>

        <?php $this->render_section_control_center(); ?>


        <?php $this->render_section_semantic(); ?>
        <!-- ═══ LAZY-LOAD WRAPPER: Cannibalization + Strategy (Session G) ═══ -->
        <div class="hts-lazy-section" data-lazy="cannib-strategy">
        <div class="hts-skeleton-loader" style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px 24px;margin-bottom:12px;">
            <div style="height:12px;width:160px;background:#e5e7eb;border-radius:4px;margin-bottom:14px;animation:htsSkelPulse 1.5s infinite;"></div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;">
                <div style="height:56px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;"></div>
                <div style="height:56px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;animation-delay:.15s;"></div>
                <div style="height:56px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;animation-delay:.3s;"></div>
                <div style="height:56px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;animation-delay:.45s;"></div>
            </div>
        </div>
        <div class="hts-lazy-content" style="display:none;">

        <?php
        // ══════ Phase 6c: CANNIBALIZATION ══════
        $cannibal_data = null;
        if ( class_exists( 'HTS_Cannibalization' ) ) {
            $cannibal_data = ( new HTS_Cannibalization() )->get_pairs();
        }
        if ( $cannibal_data && ! empty( $cannibal_data['scanned_at'] ) ) :
            $cb_total    = $cannibal_data['total'] ?? 0;
            $cb_critical = $cannibal_data['critical'] ?? 0;
            $cb_warning  = $cannibal_data['warning'] ?? 0;
            $cb_resolved = count( array_filter( $cannibal_data['pairs'] ?? array(), function( $p ) {
                return in_array( $p['status'] ?? '', array( 'dismissed', 'redirected', 'merge_pending' ), true );
            } ) );
        ?>
        <div class="hc-section">Cannibalisation</div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px;">
            <div style="text-align:center;padding:10px;background:#f8fafc;border-radius:8px;">
                <div style="font-size:20px;font-weight:800;color:#1a1f36;"><?php echo (int) $cb_total; ?></div>
                <div style="font-size:9px;color:#64748b;text-transform:uppercase;font-weight:600;">Paires</div>
            </div>
            <div style="text-align:center;padding:10px;background:<?php echo (int) $cb_critical > 0 ? '#fef2f2' : '#f0fdf4'; ?>;border-radius:8px;">
                <div style="font-size:20px;font-weight:800;color:<?php echo (int) $cb_critical > 0 ? '#dc2626' : '#10b981'; ?>;"><?php echo (int) $cb_critical; ?></div>
                <div style="font-size:9px;color:#64748b;text-transform:uppercase;font-weight:600;">Critiques</div>
            </div>
            <div style="text-align:center;padding:10px;background:#f8fafc;border-radius:8px;">
                <div style="font-size:20px;font-weight:800;color:#f59e0b;"><?php echo (int) $cb_warning; ?></div>
                <div style="font-size:9px;color:#64748b;text-transform:uppercase;font-weight:600;">Attention</div>
            </div>
            <div style="text-align:center;padding:10px;background:#f8fafc;border-radius:8px;">
                <div style="font-size:20px;font-weight:800;color:#10b981;"><?php echo (int) $cb_resolved; ?></div>
                <div style="font-size:9px;color:#64748b;text-transform:uppercase;font-weight:600;">Résolues</div>
            </div>
        </div>
        <?php if ( $cb_critical > 0 ) : ?>
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;margin-bottom:10px;font-size:12px;color:#991b1b;">
            ⚠ <?php echo (int) $cb_critical; ?> paire(s) critique(s) — des pages se font concurrence sur les mêmes mots-clés.
        </div>
        <?php endif; ?>
        <div style="font-size:10px;color:#94a3b8;margin-bottom:6px;">Dernier scan : <?php echo esc_html( $cannibal_data['scanned_at'] ); ?></div>
        <div style="margin-top:6px;">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-cannibalization' ) ); ?>"
               style="font-size:11px;color:#6366f1;font-weight:600;text-decoration:none;">
                Voir les détails →
            </a>
        </div>
        <?php endif; /* Cannibalization section */ ?>

        <?php
        // ══════ Phase 4b: STRATEGY ENGINE — Patterns + Plan mensuel ══════
        $strategy_summary = null;
        if ( class_exists( 'HTS_Strategy_Engine' ) ) {
            $strategy_summary = HTS_Strategy_Engine::get_summary();
        }
        if ( $strategy_summary ) :
        ?>
        <div class="hc-section">Strategie — Apprentissage</div>

        <?php if ( ! $strategy_summary['mining_ready'] ) : ?>
        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:12px 16px;margin-bottom:16px;">
            <div style="font-size:12px;font-weight:600;color:#92400e;">En attente de données</div>
            <div style="font-size:11px;color:#a16207;margin-top:4px;">
                Le moteur de stratégie nécessite au moins <?php echo HTS_Strategy_Engine::MIN_ACTIONS_MINING; ?> actions mesurées par GSC pour identifier les patterns gagnants.
                Continuez à optimiser vos articles, le plugin apprend en arrière-plan.
            </div>
        </div>
        <?php else : ?>

        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;">
            <div style="background:#f0fdf4;border-radius:8px;padding:10px 14px;text-align:center;">
                <div style="font-size:20px;font-weight:700;color:#166534;"><?php echo (int) $strategy_summary['fiable']; ?></div>
                <div style="font-size:10px;color:#166534;">Fiables</div>
            </div>
            <div style="background:#fefce8;border-radius:8px;padding:10px 14px;text-align:center;">
                <div style="font-size:20px;font-weight:700;color:#a16207;"><?php echo (int) $strategy_summary['mitige']; ?></div>
                <div style="font-size:10px;color:#a16207;">Mitigés</div>
            </div>
            <div style="background:#fef2f2;border-radius:8px;padding:10px 14px;text-align:center;">
                <div style="font-size:20px;font-weight:700;color:#dc2626;"><?php echo (int) $strategy_summary['inefficace']; ?></div>
                <div style="font-size:10px;color:#dc2626;">Inefficaces</div>
            </div>
            <div style="background:#f8fafc;border-radius:8px;padding:10px 14px;text-align:center;">
                <div style="font-size:20px;font-weight:700;color:#64748b;"><?php echo (int) $strategy_summary['observation']; ?></div>
                <div style="font-size:10px;color:#64748b;">En observation</div>
            </div>
        </div>

        <?php if ( $strategy_summary['best_pattern'] ) :
            $bp = $strategy_summary['best_pattern'];
        ?>
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;margin-bottom:12px;">
            <div style="font-size:11px;font-weight:600;color:#1d4ed8;">Meilleur pattern</div>
            <div style="font-size:12px;color:#1a1f36;margin-top:4px;">
                <strong><?php echo esc_html( $bp['action'] ); ?></strong> sur <?php echo esc_html( $bp['profile'] ); ?>
                — <?php echo (int) $bp['confidence']; ?>% de réussite (<?php echo (int) $bp['sample']; ?> tests)
            </div>
        </div>
        <?php endif; ?>

        <?php if ( $strategy_summary['plan_items'] > 0 ) : ?>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <div>
                    <div style="font-size:12px;font-weight:600;color:#1a1f36;">Plan mensuel</div>
                    <div style="font-size:11px;color:#64748b;margin-top:2px;">
                        <?php echo (int) $strategy_summary['plan_items']; ?> actions planifiées ·
                        <?php echo (int) $strategy_summary['plan_weeks_done']; ?>/4 semaines validées
                    </div>
                </div>
                <div style="display:flex;gap:4px;">
                    <?php for ( $wn = 1; $wn <= 4; $wn++ ) :
                        $done = $wn <= $strategy_summary['plan_weeks_done'];
                    ?>
                    <div style="width:20px;height:20px;border-radius:50%;background:<?php echo (int) $done ? '#16a34a' : '#e5e7eb'; ?>;display:flex;align-items:center;justify-content:center;font-size:9px;color:<?php echo (int) $done ? '#fff' : '#64748b'; ?>;font-weight:700;">
                        <?php echo (int) $done ? '✓' : $wn; ?>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div style="text-align:right;margin-bottom:16px;">
            <button onclick="htsRunMining(this)" style="font-size:11px;color:#6366f1;background:none;border:1px solid #e0e7ff;border-radius:6px;padding:4px 10px;cursor:pointer;font-weight:600;">
                Recalculer les patterns
            </button>
        </div>

        <?php endif; /* mining_ready */ ?>
        <?php endif; /* strategy_summary */ ?>
        </div><!-- /.hts-lazy-content -->
        </div><!-- /.hts-lazy-section[cannib-strategy] -->

        <!-- S12: GEO Readiness migre vers Analytics -->

        <!-- S12: Historique Facettes migre vers Audit Trail / health.php -->

        <!-- S12: GSC Insights migre vers Analytics -->

        <!-- S12: Modules SEO + Coverage migres vers Agents cards + health.php -->
        </div><!-- .hc -->
        </div><!-- .hts-wrap -->
        <?php
    }

    /* ══════════════════════════════════════════════════════════════════
     *  COACH SEO PAGE (?tab=coach) — Phase 6 ⭐
     * ══════════════════════════════════════════════════════════════════ */


    /* S12: Migre vers admin/partials/health.php */
    // render_section_operational_check() — removed: empty dead code (Phase 2C)
    /**
     * Section: Cannibalization conflicts (Session I — extracted).
     */
    private function render_section_cannibalization() {
        ?>
        <!-- ═══ CANNIBALIZATION CONFLICTS ═══ -->
        <?php
        $conflicts_data = class_exists( 'HTS_Cannibalization' ) ? get_option( 'hts_cannib_results', array() ) : array();
        $pending_conflicts = array();
        if ( is_array( $conflicts_data ) ) {
            foreach ( $conflicts_data as $c ) {
                if ( ( $c['status'] ?? '' ) !== 'resolved' && ( $c['status'] ?? '' ) !== 'dismissed' ) {
                    $pending_conflicts[] = $c;
                }
            }
        }
        if ( ! empty( $pending_conflicts ) ) : ?>
        <div class="hc-section hts-mt-4">Pages en conflit (<?php echo count( $pending_conflicts ); ?>) <span style="font-size:11px;font-weight:400;color:#9da5b4;">— Google hésite entre ces pages, corrigez pour améliorer votre référencement</span></div>
        <div id="hts-cannib-panel" style="display:flex;flex-direction:column;gap:12px;">
            <?php foreach ( $pending_conflicts as $c ) :
                $pk    = esc_attr( $c['pair_key'] ?? '' );
                $pa    = (int)( $c['page_a'] ?? 0 );
                $pb    = (int)( $c['page_b'] ?? 0 );
                $ta    = esc_html( $c['title_a'] ?? "ID $pa" );
                $tb    = esc_html( $c['title_b'] ?? "ID $pb" );
                $risk  = $c['risk'] ?? 'medium';
                $layer = $c['layer_label'] ?? $c['layer'] ?? '';
                $score = isset( $c['score'] ) ? (int) $c['score'] . '%' : '';
                $sug   = $c['suggestion'] ?? array();
                $sug_action  = $sug['action'] ?? 'review';
                $sug_winner  = (int)( $sug['winner_id'] ?? 0 );
                $sug_loser   = (int)( $sug['loser_id'] ?? 0 );
                $sug_reason  = esc_html( $sug['reason'] ?? '' );
                $risk_colors = array( 'critical' => '#dc2626', 'high' => '#ea580c', 'medium' => '#d97706', 'opportunity' => '#0891b2' );
                $risk_color  = $risk_colors[ $risk ] ?? '#d97706';
                $risk_labels = array( 'critical' => 'Urgent', 'high' => 'Important', 'medium' => 'À vérifier', 'opportunity' => 'Suggestion' );
                $risk_label  = $risk_labels[ $risk ] ?? ucfirst( $risk );
                $action_labels = array( 'canonical' => 'Rediriger Google vers la bonne page', 'redirect' => 'Rediriger les visiteurs', 'merge' => 'Fusionner les 2 pages', 'review' => 'A corriger manuellement', 'differentiate' => 'Modifier le contenu' );
                $action_label  = $action_labels[ $sug_action ] ?? $sug_action;
                // Client-friendly explanation per suggestion type
                $action_explain = array(
                    'canonical'     => 'Google voit 2 pages similaires et ne sait pas laquelle afficher. En cliquant ci-dessous, la page "perdante" dira à Google de préférer la "gagnante".',
                    'redirect'      => 'Les 2 pages sont des doublons. La moins performante sera redirigée vers la meilleure pour concentrer le trafic.',
                    'merge'         => 'Les 2 pages traitent du même sujet mais sont trop courtes. Fusionnez-les en une seule page complète.',
                    'review'        => 'Ces 2 pages ont le même titre mais des contenus différents. Ouvrez-les et renommez celle qui a un titre incorrect.',
                    'differentiate' => 'Ces 2 pages se ressemblent un peu. Modifiez les titres et contenus pour que chacune traite un angle unique.',
                );
                $sug_explain = $action_explain[ $sug_action ] ?? $sug_reason;
            ?>
            <div class="hts-cannib-card" id="cannib-<?php echo esc_html( $pk ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:16px 18px;">
                <!-- Header: risk + layer -->
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                    <span style="font-size:11px;font-weight:700;color:<?php echo esc_attr( $risk_color ); ?>;background:<?php echo esc_attr( $risk_color ); ?>18;padding:2px 8px;border-radius:10px;text-transform:uppercase;">
                        <?php echo esc_html( $risk_label ); ?>
                    </span>
                </div>
                <!-- Pages A vs B -->
                <div style="display:flex;gap:12px;align-items:stretch;margin-bottom:12px;">
                    <div style="flex:1;background:#f8fafc;border-radius:6px;padding:10px 12px;">
                        <div style="font-size:10px;color:#9da5b4;margin-bottom:2px;">Page A</div>
                        <a href="<?php echo esc_url( get_permalink( $pa ) ); ?>" target="_blank" style="font-size:12.5px;font-weight:600;color:#1a1f36;text-decoration:none;" title="Voir la page">
                            <?php echo esc_html( mb_strimwidth( $ta, 0, 55, '…' ) ); ?>
                        </a>
                        <div style="font-size:10px;color:#b0b8c4;margin-top:2px;">
                            <a href="<?php echo esc_url( get_edit_post_link( $pa ) ); ?>" style="color:#6366f1;text-decoration:none;">Éditer</a>
                        </div>
                    </div>
                    <div style="display:flex;align-items:center;font-size:11px;font-weight:700;color:#d97706;background:#fef3c7;border-radius:50%;width:28px;height:28px;justify-content:center;">VS</div>
                    <div style="flex:1;background:#f8fafc;border-radius:6px;padding:10px 12px;">
                        <div style="font-size:10px;color:#9da5b4;margin-bottom:2px;">Page B</div>
                        <a href="<?php echo esc_url( get_permalink( $pb ) ); ?>" target="_blank" style="font-size:12.5px;font-weight:600;color:#1a1f36;text-decoration:none;" title="Voir la page">
                            <?php echo esc_html( mb_strimwidth( $tb, 0, 55, '…' ) ); ?>
                        </a>
                        <div style="font-size:10px;color:#b0b8c4;margin-top:2px;">
                            <a href="<?php echo esc_url( get_edit_post_link( $pb ) ); ?>" style="color:#6366f1;text-decoration:none;">Éditer</a>
                        </div>
                    </div>
                </div>
                <!-- Suggestion -->
                <div style="background:#fefce8;border:1px solid #fde68a;border-radius:6px;padding:8px 12px;margin-bottom:12px;">
                    <div style="font-size:11px;font-weight:600;color:#92400e;"><?php echo esc_attr( $action_label ); ?></div>
                    <div style="font-size:11px;color:#78716c;margin-top:4px;line-height:1.5;"><?php echo esc_html( $sug_explain ); ?></div>
                    <?php if ( $sug_winner && $sug_loser ) : ?>
                    <div style="font-size:10.5px;color:#78716c;margin-top:6px;padding-top:6px;border-top:1px solid #fde68a;">
                        Page à garder : <strong><?php echo esc_html( get_the_title( $sug_winner ) ); ?></strong><br>
                        Page secondaire : <?php echo esc_html( get_the_title( $sug_loser ) ); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <!-- Action buttons -->
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <?php if ( in_array( $sug_action, array( 'canonical', 'redirect', 'merge' ) ) && $sug_winner && $sug_loser ) : ?>
                    <button type="button" onclick="htsCannibResolve('<?php echo esc_js( $pk ); ?>',<?php echo (int) $sug_winner; ?>,<?php echo (int) $sug_loser; ?>,'<?php echo esc_js( $sug_action ); ?>')" class="hts-btn hts-btn--primary" style="font-size:11px;padding:5px 12px;">
                        Corriger automatiquement
                    </button>
                    <button type="button" onclick="htsCannibResolve('<?php echo esc_js( $pk ); ?>',<?php echo (int) $sug_loser; ?>,<?php echo (int) $sug_winner; ?>,'<?php echo esc_js( $sug_action ); ?>')" class="hts-btn" style="font-size:11px;padding:5px 12px;background:#fff;border:1px solid #e5e7eb;color:#5e6687;" title="Inverser : garder l'autre page">
                        🔄 Inverser le choix
                    </button>
                    <?php endif; ?>
                    <button type="button" onclick="htsCannibDismiss('<?php echo esc_js( $pk ); ?>')" class="hts-btn" style="font-size:11px;padding:5px 12px;background:#fff;border:1px solid #e5e7eb;color:#9da5b4;">
                        ✕ Ce n'est pas un problème
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <script>
        function htsCannibResolve(pk, winner, loser, action) {
            var msgs = {
                'canonical': 'La page secondaire indiquera à Google de préférer la page principale.',
                'redirect': 'Les visiteurs de la page secondaire seront redirigés vers la page principale.',
                'merge': 'La page secondaire sera redirigée. Pensez à fusionner manuellement le contenu.'
            };
            if (!confirm('Corriger ce conflit ?\n\n' + (msgs[action] || 'Action : ' + action) + '\n\nContinuer ?')) return;
            var btn = event.target; htsBtn(btn, true, 'Correction...');
            jQuery.post(ajaxurl, {
                action: 'hts_canonical_resolve',
                nonce: (typeof htsAdmin !== 'undefined' ? htsAdmin.nonce : ''),
                pair_key: pk, winner_id: winner, loser_id: loser, resolve_action: action
            }, function(r) {
                if (r.success) {
                    var card = document.getElementById('cannib-' + pk);
                    if (card) { card.style.opacity = '0.4'; card.innerHTML = '<div style="padding:12px;color:#16a34a;font-weight:600;">Résolu (' + action + ')</div>'; }
                } else {
                    alert('Erreur : ' + (r.data || 'inconnue')); btn.disabled = false; btn.textContent = 'Réessayer';
                }
            }).fail(function() { alert('Erreur réseau'); btn.disabled = false; });
        }
        function htsCannibDismiss(pk) {
            if (!confirm('Masquer cette alerte ? Vous pourrez la restaurer depuis les réglages Canonical.')) return;
            jQuery.post(ajaxurl, {
                action: 'hts_canonical_dismiss',
                nonce: (typeof htsAdmin !== 'undefined' ? htsAdmin.nonce : ''),
                pair_key: pk
            }, function(r) {
                if (r.success) {
                    var card = document.getElementById('cannib-' + pk);
                    if (card) card.remove();
                    // If no more cards, hide section
                    var panel = document.getElementById('hts-cannib-panel');
                    if (panel && panel.children.length === 0) panel.previousElementSibling.remove();
                }
            });
        }
        </script>
        <?php endif; ?>
        <?php
    }

    /**
     * Section: Centre de contrôle Full only (Session I — extracted).
     */
    private function render_section_control_center() {
        ?>
        <!-- ═══ CENTRE DE CONTRÔLE: Feed + Inbox (Full only) ═══ -->
        <?php if ( ! defined( 'HTS__IS_LIGHT' ) || ! HTS__IS_LIGHT ) :
        // Get pending recommendations
        $recs = get_option( 'hts_orchestrator_recs', array() );
        $pending_recs = is_array( $recs ) ? array_filter( $recs, function( $r ) {
            return ( $r['status'] ?? '' ) === 'pending';
        }) : array();

        // Get recent audit trail actions
        $recent_actions = array();
        global $wpdb;
        $audit_table = $wpdb->prefix . 'hts_actions';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $audit_table ) ) === $audit_table ) {
            $recent_actions = $wpdb->get_results(
                $wpdb->prepare( "SELECT id, action_type, post_id, anchor_text, created_at FROM {$audit_table} ORDER BY created_at DESC LIMIT %d", 8 ),
                ARRAY_A
            );
        }
        ?>

        <?php if ( ! empty( $pending_recs ) ) : ?>
        <div class="hc-section">Actions en attente (<?php echo count( $pending_recs ); ?>)</div>
        <?php foreach ( $pending_recs as $rec ) :
            $rec_id = esc_attr( $rec['id'] ?? '' );
            $priority = (int) ( $rec['priority'] ?? 50 );
            $confidence = (int) ( $rec['confidence'] ?? 50 );
            $badge_color = $priority >= 80 ? '#dc2626' : ( $priority >= 60 ? '#d97706' : '#6366f1' );
            $rec_type = $rec['type'] ?? '';
            $action_data = $rec['action_data'] ?? array();

            // DRYRUN diff data
            $has_diff = false;
            $diff_rows = array();

            if ( in_array( $rec_type, array( 'optimize_meta', 'rollback_meta' ), true ) ) {
                $cur_t = $action_data['current_title'] ?? '';
                $cur_d = $action_data['current_desc'] ?? '';

                if ( $rec_type === 'optimize_meta' ) {
                    $has_diff = ( $cur_t !== '' || $cur_d !== '' );
                    if ( $cur_t !== '' ) {
                        $diff_rows[] = array(
                            'label'  => 'Title',
                            'before' => $cur_t,
 'after' => 'Variante IA (générée à l\'approbation)',
                            'is_preview' => true,
                        );
                    }
                    if ( $cur_d !== '' ) {
                        $diff_rows[] = array(
                            'label'  => 'Description',
                            'before' => $cur_d,
 'after' => 'Variante IA (générée à l\'approbation)',
                            'is_preview' => true,
                        );
                    } elseif ( $cur_t !== '' ) {
                        $diff_rows[] = array(
                            'label'  => 'Description',
                            'before' => '(vide)',
 'after' => 'Variante IA (générée à l\'approbation)',
                            'is_preview' => true,
                        );
                    }
                } elseif ( $rec_type === 'rollback_meta' ) {
                    $rb_t = $action_data['rollback_title'] ?? '';
                    $rb_d = $action_data['rollback_desc'] ?? '';
                    $has_diff = ( $rb_t !== '' || $rb_d !== '' );
                    if ( $cur_t !== '' || $rb_t !== '' ) {
                        $diff_rows[] = array(
                            'label'  => 'Title',
                            'before' => $cur_t ?: '(vide)',
                            'after'  => $rb_t ?: '(vide)',
                        );
                    }
                    if ( $cur_d !== '' || $rb_d !== '' ) {
                        $diff_rows[] = array(
                            'label'  => 'Description',
                            'before' => $cur_d ?: '(vide)',
                            'after'  => $rb_d ?: '(vide)',
                        );
                    }
                }
            } elseif ( $rec_type === 'investigate' && ! empty( $action_data['current_title'] ) ) {
                // Show current meta for investigation context
                $has_diff = true;
                $diff_rows[] = array(
                    'label'  => 'Title actuel',
                    'before' => $action_data['current_title'],
                    'after'  => null,
                );
                if ( ! empty( $action_data['current_desc'] ) ) {
                    $diff_rows[] = array(
                        'label'  => 'Description actuelle',
                        'before' => $action_data['current_desc'],
                        'after'  => null,
                    );
                }
            }
        ?>
            <div class="hc-rec-card" id="rec-<?php echo (int) $rec_id; ?>" class="hts-api-card hts-mb-2">
                <div class="hts-flex hts-items-start hts-gap-3">
                    <span style="font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;background:<?php echo esc_attr( $badge_color ); ?>;color:#fff;white-space:nowrap;">
                        P<?php echo esc_html( $priority ); ?>
                    </span>
                    <div class="hts-flex-1">
                        <div class="hts-fw-600 hts-text-primary"><?php echo esc_html( $rec['title'] ?? '' ); ?></div>
                        <div class="hts-fs-sm hts-text-secondary hts-mt-1"><?php echo esc_html( $rec['description'] ?? '' ); ?></div>
                        <?php if ( ! empty( $rec['impact_est'] ) ) : ?>
 <div style="font-size:11px;color:#16a34a;margin-top:4px;"> <?php echo esc_html( $rec['impact_est'] ); ?></div>
                        <?php endif; ?>
                        <div style="font-size:10px;color:#9da5b4;margin-top:4px;">Confiance : <?php echo (int) $confidence; ?>%</div>

                        <?php if ( $has_diff && ! empty( $diff_rows ) ) : ?>
                        <div class="hts-mt-2">
 <button onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'block':'none';this.textContent=this.nextElementSibling.style.display==='none'?'Aperçu DRYRUN':'▼ Aperçu DRYRUN';"
 style="font-size:11px;color:#6366f1;background:none;border:none;cursor:pointer;padding:0;font-weight:600;">Aperçu DRYRUN</button>
                            <div style="display:none;margin-top:6px;border:1px solid #e5e7eb;border-radius:6px;overflow:hidden;font-size:11.5px;">
                                <?php foreach ( $diff_rows as $dr ) : ?>
                                <div style="padding:8px 10px;border-bottom:1px solid #f1f5f9;">
                                    <div style="font-weight:600;color:#475569;margin-bottom:4px;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;"><?php echo esc_html( $dr['label'] ); ?></div>
                                    <?php if ( isset( $dr['after'] ) ) : ?>
                                        <div style="background:#fef2f2;color:#991b1b;padding:4px 8px;border-radius:4px;margin-bottom:3px;word-break:break-word;">
                                            <span style="font-weight:700;color:#dc2626;">−</span> <?php echo esc_html( $dr['before'] ); ?>
                                        </div>
                                        <div style="background:<?php echo ! empty( $dr['is_preview'] ) ? '#f5f3ff' : '#f0fdf4'; ?>;color:<?php echo ! empty( $dr['is_preview'] ) ? '#5b21b6' : '#166534'; ?>;padding:4px 8px;border-radius:4px;word-break:break-word;">
                                            <span style="font-weight:700;color:<?php echo ! empty( $dr['is_preview'] ) ? '#7c3aed' : '#16a34a'; ?>;">+</span> <?php echo esc_html( $dr['after'] ); ?>
                                        </div>
                                    <?php else : ?>
                                        <div style="background:#f8fafc;color:#475569;padding:4px 8px;border-radius:4px;word-break:break-word;">
                                            <?php echo esc_html( $dr['before'] ); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="hts-flex hts-gap-1" style="flex-shrink:0;">
                        <button onclick="hcRecAction('<?php echo (int) $rec_id; ?>','execute')" title="Approuver"
 style="padding:4px 10px;border-radius:5px;border:1px solid #16a34a;background:#f0fdf4;color:#16a34a;font-size:11px;font-weight:600;cursor:pointer;">Appliquer</button>
                        <button onclick="hcRecAction('<?php echo (int) $rec_id; ?>','dismiss')" title="Ignorer"
 style="padding:4px 10px;border-radius:5px;border:1px solid #d1d5db;background:#fff;color:#64748b;font-size:11px;cursor:pointer;">×</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        <?php endif; ?>

        <?php if ( ! empty( $recent_actions ) ) : ?>
        <div class="hc-section"><?php echo empty( $pending_recs ) ? 'Activité récente' : 'Dernières actions'; ?></div>
        <div class="hts-api-card" style="overflow:hidden;">
        <?php foreach ( $recent_actions as $i => $act ) :
            $type_icons = array(
 'meta_title' => HTS_Icons::get('edit','hts-icon--sm'), 'meta_description' => HTS_Icons::get('file-text','hts-icon--sm'), 'schema' => HTS_Icons::get('code-2','hts-icon--sm'),
 'canonical' => HTS_Icons::get('link-2','hts-icon--sm'), 'redirect' => '↗', 'noindex' => HTS_Icons::get('ban','hts-icon--sm'),
 'internal_link' => HTS_Icons::get('link-2','hts-icon--sm'), 'content_write' => HTS_Icons::get('edit','hts-icon--sm'), 'rollback' => '↩',
            );
 $icon = $type_icons[ $act['action_type'] ] ?? '';
            $title = get_the_title( $act['post_id'] );
            $time = human_time_diff( strtotime( $act['created_at'] ) ) . ' ago';
        ?>
            <div style="display:flex;align-items:center;gap:10px;padding:10px 16px;<?php echo (int) $i < count( $recent_actions ) - 1 ? 'border-bottom:1px solid #f3f4f6;' : ''; ?>font-size:12.5px;">
                <span class="hts-fs-md"><?php echo esc_attr( $icon ); ?></span>
                <span style="flex:1;color:#1a1f36;"><?php echo esc_html( $act['action_type'] ); ?><?php echo $title ? ' — <span class="hts-text-secondary">' . esc_html( wp_trim_words( $title, 6 ) ) . '</span>' : ''; ?></span>
                <span class="hts-fs-xs hts-text-muted" style="white-space:nowrap;"><?php echo esc_html( $time ); ?></span>
            </div>
        <?php endforeach; ?>
        </div>
        <?php elseif ( empty( $pending_recs ) ) : ?>
        <div class="hc-section">Centre de contrôle</div>
        <div class="hts-api-card hts-text-center hts-text-muted hts-p-5">
            Aucune activité récente. L'Orchestrateur s'exécute chaque semaine et génère des recommandations ici.
        </div>
        <?php endif; ?>

        <?php
        // ── Couche 4: MEASURE — Mini-résumé Impact (détail complet dans tab Impact) ──
        $impact = null;
        if ( class_exists( 'HTS_Feedback_Loop' ) ) {
            $impact = HTS_Feedback_Loop::compute_impact_summary( 30 );
        }
        $fb_alerts = array();
        if ( class_exists( 'HTS_Feedback_Loop' ) ) {
            $fb_alerts = HTS_Feedback_Loop::get_active_alerts();
        }
        $critical_alerts = array_filter( $fb_alerts, function( $a ) { return ( $a['severity'] ?? '' ) === 'critical'; } );
        $canary = get_option( 'hts_orchestrator_canary', array() );
        $canary_watching = count( array_filter( $canary, function( $c ) { return ( $c['status'] ?? '' ) === 'watching'; } ) );
        $canary_degraded = count( array_filter( $canary, function( $c ) { return ( $c['status'] ?? '' ) === 'degraded'; } ) );

        $has_impact_data = ( $impact && $impact['total'] > 0 ) || ! empty( $fb_alerts ) || ! empty( $canary );
        if ( $has_impact_data ) :
            $impact_url = admin_url( 'admin.php?page=hts-light-dashboard&tab=impact' );
        ?>
        <div class="hc-section" style="display:flex;align-items:center;justify-content:space-between;">
            Suivi d'impact
            <a href="<?php echo esc_url( $impact_url ); ?>" style="font-size:11px;font-weight:600;color:#6366f1;text-decoration:none;text-transform:none;letter-spacing:0;">Voir tout →</a>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <?php if ( $impact && $impact['total'] > 0 ) : ?>
            <div style="flex:1;min-width:120px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;text-align:center;">
                <div style="display:flex;justify-content:center;gap:12px;">
                    <span style="font-size:16px;font-weight:700;color:#166534;"><?php echo (int) $impact['positive']; ?> ✓</span>
                    <span style="font-size:16px;font-weight:700;color:<?php echo (int) $impact['negative'] > 0 ? '#dc2626' : '#64748b'; ?>;"><?php echo (int) $impact['negative']; ?> ✗</span>
                </div>
                <div style="font-size:10px;color:#64748b;margin-top:2px;"><?php echo (int) $impact['total']; ?> actions mesurées (30j)</div>
            </div>
            <?php endif; ?>
            <?php if ( ! empty( $critical_alerts ) ) : ?>
            <a href="<?php echo esc_url( $impact_url ); ?>" style="flex:1;min-width:120px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;text-align:center;text-decoration:none;">
                <div style="font-size:16px;font-weight:700;color:#dc2626;"><?php echo count( $critical_alerts ); ?> ⚠️</div>
                <div style="font-size:10px;color:#dc2626;">Alerte(s) à traiter</div>
            </a>
            <?php endif; ?>
            <?php if ( $canary_watching > 0 || $canary_degraded > 0 ) : ?>
            <div style="flex:1;min-width:120px;background:<?php echo $canary_degraded > 0 ? '#fef2f2' : '#eff6ff'; ?>;border:1px solid <?php echo $canary_degraded > 0 ? '#fecaca' : '#bfdbfe'; ?>;border-radius:8px;padding:10px 14px;text-align:center;">
                <div style="font-size:16px;font-weight:700;color:<?php echo $canary_degraded > 0 ? '#dc2626' : '#1d4ed8'; ?>;"><?php echo $canary_watching; ?> 👁️</div>
                <div style="font-size:10px;color:#64748b;">Canary en observation<?php echo $canary_degraded > 0 ? ' · ' . $canary_degraded . ' dégradé(s)' : ''; ?></div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; /* end Full-only: Orchestrator + MEASURE + Canary */ ?>
        <?php
    }


    /* ══════════════════════════════════════════════════════════════════
     *  IMPACT PAGE (?tab=impact) — v2.5.0
     *  Regroupe : Impact summary, Feedback Alerts, Canary watchlist
     * ══════════════════════════════════════════════════════════════════ */

    private function render_impact_page() {
        $this->render_tab_nav( 'impact' );
        ?>
        <div style="max-width:800px;margin:0 auto;">

        <h2 style="font-size:18px;font-weight:700;color:#1a1f36;margin:24px 0 6px;">Suivi d'impact</h2>
        <p style="font-size:12px;color:#64748b;margin:0 0 20px;">
            Chaque action de vos agents IA est mesurée automatiquement à 7 et 30 jours.
            Vous voyez ici si les modifications améliorent réellement votre référencement.
        </p>

        <?php
        // ── Sprint Robustesse v2: Page-centric Impact Report (AJAX lazy-loaded) ──
        ?>

        <div id="hts-alerts" class="hc-section">Impact des actions</div>
        <div id="hts-impact-v2" style="min-height:80px;">
            <div style="text-align:center;padding:20px;color:#94a3b8;">
                <div style="font-size:12px;">Chargement du rapport d\u2019impact\u2026</div>
            </div>
        </div>
        <script>
        (function(){
            var box = document.getElementById('hts-impact-v2');
            var nonce = typeof htsAdmin !== 'undefined' ? htsAdmin.nonce : '';
            var fd = new FormData();
            fd.append('action', 'hts_feedback_page_report');
            fd.append('nonce', nonce);
            fd.append('days', 30);
            fetch(ajaxurl, { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(resp){
                if (!resp.success || !resp.data) { box.innerHTML = '<div style="text-align:center;padding:20px;color:#94a3b8;font-size:12px;">Aucune donn\u00e9e d\u2019impact.</div>'; return; }
                var d = resp.data, pages = d.pages || [], trend = d.site_trend || {};
                var cnt = { pos:0, neg:0, neut:0, algo:0 };
                pages.forEach(function(p){
                    if (p.aggregate_verdict==='positive') cnt.pos++;
                    else if (p.aggregate_verdict==='negative') cnt.neg++;
                    else if (p.aggregate_verdict==='algo_neutral') cnt.algo++;
                    else cnt.neut++;
                });
                var h = '';
                h += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px;">';
                h += kpi(cnt.pos,'\uD83D\uDFE2 Positif','#f0fdf4','#166534');
                h += kpi(cnt.neut,'\uD83D\uDFE1 Neutre','#fefce8','#854d0e');
                h += kpi(cnt.neg,'\uD83D\uDD34 \u00C0 revoir','#fef2f2','#dc2626');
                h += kpi(cnt.algo,'\uD83D\uDD04 Algo','#eef2ff','#4338ca');
                h += '</div>';
                if (trend.is_algo_update) h += '<div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:11px;color:#4338ca;">\uD83D\uDD04 <strong>Mise \u00e0 jour algo d\u00e9tect\u00e9e</strong> \u2014 '+Math.abs(trend.avg_position_delta||0).toFixed(1)+' positions en moyenne sur '+(trend.pct_affected||0)+'% des pages.</div>';
                if (!pages.length) { h += '<div style="text-align:center;padding:20px;color:#94a3b8;font-size:12px;">R\u00e9sultats apr\u00e8s la prochaine synchro GSC.</div>'; box.innerHTML = h; return; }
                h += '<div style="display:flex;flex-direction:column;gap:10px;">';
                pages.slice(0,20).forEach(function(pg){
                    var vc = vcol(pg.aggregate_verdict), rec = pg.recommendation;
                    h += '<div style="background:'+vc[0]+';border:1px solid '+vc[1]+';border-radius:10px;padding:14px 16px;">';
                    h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><div style="display:flex;align-items:center;gap:6px;"><span>'+vc[2]+'</span><a href="'+(pg.edit_url||'#')+'" style="font-size:13px;font-weight:600;color:#1a1f36;text-decoration:none;">'+e(tr(pg.title,55))+'</a></div><div style="font-size:11px;color:#64748b;">'+pg.action_count+' action'+(pg.action_count>1?'s':'')+'</div></div>';
                    var m = '';
                    if (pg.position>0) m += '<span>Pos : <strong>'+pg.position.toFixed(1)+'</strong></span> ';
                    if (pg.clicks>0) m += '<span>Clics : <strong>'+pg.clicks+'</strong></span> ';
                    if (m) h += '<div style="display:flex;gap:14px;font-size:11px;color:#64748b;padding-left:24px;margin-bottom:8px;">'+m+'</div>';
                    h += '<div style="padding-left:24px;margin-bottom:6px;">';
                    (pg.actions||[]).slice(0,5).forEach(function(a){
                        var dd = a.adj_pos_delta||a.pos_delta||0, ds = dd?'pos '+(dd>0?'+':'')+dd.toFixed(1):'';
                        if (a.clk_delta) ds += (ds?' \u00b7 ':'')+(a.clk_delta>0?'+':'')+a.clk_delta+' clics';
                        h += '<div style="display:flex;justify-content:space-between;font-size:11px;padding:3px 0;border-bottom:1px solid '+vc[1]+';"><div style="display:flex;align-items:center;gap:4px;"><span style="font-size:10px;">'+(a.icon||'\uD83D\uDFE1')+'</span><span style="color:#374151;">'+e(a.label||'')+'</span>';
                        if (a.source_title) h += ' <span style="color:#9ca3af;">\u2190 '+e(tr(a.source_title,25))+'</span>';
                        if (a.is_algo) h += ' <span style="background:#eef2ff;color:#4338ca;font-size:9px;padding:1px 5px;border-radius:3px;">algo</span>';
                        h += '</div><div style="display:flex;gap:6px;">';
                        if (ds) h += '<span style="color:'+(a.color||'#64748b')+';font-weight:600;font-size:10px;">'+e(ds)+'</span>';
                        h += '<span style="color:#9ca3af;font-size:10px;">J+'+(a.days_ago||0)+'</span></div></div>';
                    });
                    if (pg.action_count>5) h += '<div style="font-size:10px;color:#9ca3af;padding-top:3px;">+ '+(pg.action_count-5)+' autre(s)</div>';
                    h += '</div>';
                    if (rec && pg.aggregate_verdict==='negative') {
                        h += '<div style="background:#fff;border:1px solid '+vc[1]+';border-radius:8px;padding:10px 14px;margin-top:6px;">';
                        h += '<div style="font-size:11px;font-weight:700;color:#1a1f36;margin-bottom:5px;">\uD83D\uDCA1 Recommandation</div>';
                        h += '<div style="font-size:11px;color:#374151;margin-bottom:6px;">'+e(rec.reason)+'</div>';
                        (rec.steps||[]).forEach(function(st,si){
                            h += '<div style="display:flex;align-items:flex-start;gap:6px;margin-bottom:4px;"><span style="background:#6366f1;color:#fff;font-size:9px;font-weight:700;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">'+(si+1)+'</span><div><div style="font-size:11px;font-weight:600;color:#1a1f36;">'+e(st.label)+'</div><div style="font-size:10px;color:#64748b;">'+e(st.desc)+'</div>';
                            if (st.primary && st.action==='rollback') h += '<button type="button" onclick="htsImpactRollback('+st.action_id+','+pg.post_id+',this)" style="margin-top:4px;padding:5px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid #dc2626;background:#fef2f2;color:#dc2626;">\u21A9 Appliquer</button>';
                            h += '</div></div>';
                        });
                        h += '</div>';
                    }
                    h += '</div>';
                });
                h += '</div>';
                box.innerHTML = h;
            })
            .catch(function(){ box.innerHTML = '<div style="text-align:center;padding:20px;color:#ef4444;font-size:12px;">Erreur. <button onclick="location.reload()" style="color:#6366f1;border:none;background:none;cursor:pointer;text-decoration:underline;">R\u00e9essayer</button></div>'; });
            function kpi(n,l,bg,c){ return '<div style="background:'+bg+';border-radius:8px;padding:10px;text-align:center;"><div style="font-size:20px;font-weight:700;color:'+c+';">'+n+'</div><div style="font-size:10px;color:'+c+';">'+l+'</div></div>'; }
            function vcol(v){ var m={negative:['#fef2f2','#fecaca','\uD83D\uDD34'],positive:['#f0fdf4','#bbf7d0','\uD83D\uDFE2'],algo_neutral:['#eef2ff','#c7d2fe','\uD83D\uDD04'],neutral:['#fefce8','#fde68a','\uD83D\uDFE1']}; return m[v]||m.neutral; }
            function e(s){ if(!s) return ''; var d=document.createElement('div'); d.appendChild(document.createTextNode(s)); return d.innerHTML; }
            function tr(s,n){ return s&&s.length>n?s.substring(0,n)+'\u2026':(s||''); }
            window.htsImpactRollback = function(aid,pid,btn){
                if (!confirm('Restaurer le contenu pr\u00e9c\u00e9dent ?')) return;
                btn.disabled=true; btn.textContent='\u21A9 Restauration\u2026';
                var fd=new FormData(); fd.append('action','hts_inbox_rollback'); fd.append('nonce',nonce); fd.append('action_id',aid);
                fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(r){
                    if(r.success){btn.textContent='\u2705 Restaur\u00e9';btn.style.borderColor='#16a34a';btn.style.color='#16a34a';btn.style.background='#f0fdf4';}
                    else{alert(r.data||'Erreur');btn.disabled=false;btn.textContent='\u21A9 R\u00e9essayer';}
                }).catch(function(){btn.disabled=false;btn.textContent='\u21A9 R\u00e9essayer';});
            };
        })();
        </script>

        <?php
        // ── Section 3: Canary Watchlist ──
        $canary = get_option( 'hts_orchestrator_canary', array() );
        $canary_active   = array_filter( $canary, function( $c ) { return ( $c['status'] ?? '' ) === 'watching'; } );
        $canary_degraded = array_filter( $canary, function( $c ) { return ( $c['status'] ?? '' ) === 'degraded'; } );
        $canary_improved = array_filter( $canary, function( $c ) { return ( $c['status'] ?? '' ) === 'improved'; } );
        ?>
        <div class="hc-section">Canary — Surveillance meta (<?php echo count( $canary ); ?>)<?php if ( empty( $canary ) ) : ?> <span style="font-weight:400;color:#9da5b4;">— Aucune page surveillée</span><?php endif; ?></div>
        <?php if ( ! empty( $canary ) ) : ?>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px;">
            <div style="background:#f0fdf4;border-radius:8px;padding:12px 14px;text-align:center;">
                <div style="font-size:22px;font-weight:700;color:#166534;"><?php echo count( $canary_improved ); ?></div>
                <div style="font-size:11px;color:#166534;">Améliorées</div>
            </div>
            <div style="background:#eff6ff;border-radius:8px;padding:12px 14px;text-align:center;">
                <div style="font-size:22px;font-weight:700;color:#1d4ed8;"><?php echo count( $canary_active ); ?></div>
                <div style="font-size:11px;color:#1d4ed8;">En observation</div>
            </div>
            <div style="background:<?php echo count( $canary_degraded ) > 0 ? '#fef2f2' : '#f8fafc'; ?>;border-radius:8px;padding:12px 14px;text-align:center;">
                <div style="font-size:22px;font-weight:700;color:<?php echo count( $canary_degraded ) > 0 ? '#dc2626' : '#64748b'; ?>;"><?php echo count( $canary_degraded ); ?></div>
                <div style="font-size:11px;color:<?php echo count( $canary_degraded ) > 0 ? '#dc2626' : '#64748b'; ?>;">Dégradées</div>
            </div>
        </div>
        <?php
        // Combine all canary entries sorted by status priority: degraded > watching > improved
        $all_canary = array();
        foreach ( $canary as $c_pid => $c_entry ) {
            $c_entry['_pid'] = $c_pid;
            $all_canary[] = $c_entry;
        }
        usort( $all_canary, function( $a, $b ) {
            $order = array( 'degraded' => 0, 'watching' => 1, 'improved' => 2 );
            return ( $order[ $a['status'] ?? 'watching' ] ?? 1 ) - ( $order[ $b['status'] ?? 'watching' ] ?? 1 );
        });
        ?>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;margin-bottom:20px;">
            <?php foreach ( array_slice( $all_canary, 0, 15 ) as $c_entry ) :
                $c_pid   = $c_entry['_pid'];
                $c_title = get_the_title( $c_pid );
                $c_status = $c_entry['status'] ?? 'watching';
                $c_days  = 0;
                if ( ! empty( $c_entry['applied_at'] ) ) {
                    try {
                        $c_days = round( ( time() - ( new \DateTimeImmutable( $c_entry['applied_at'], wp_timezone() ) )->getTimestamp() ) / DAY_IN_SECONDS );
                    } catch ( \Exception $e ) { $c_days = 0; }
                }
                $c_pos   = $c_entry['gsc_at_apply']['position'] ?? 0;
                $status_icons  = array( 'degraded' => '🔴', 'watching' => '👁️', 'improved' => '✅' );
                $status_labels = array( 'degraded' => 'Dégradée', 'watching' => 'En observation', 'improved' => 'Améliorée' );
            ?>
            <div style="display:flex;align-items:center;gap:10px;padding:8px 14px;border-bottom:1px solid #f3f4f6;font-size:12px;">
                <span style="font-size:12px;"><?php echo esc_html( $status_icons[ $c_status ] ?? '👁️' ); ?></span>
                <span style="flex:1;color:#1a1f36;"><?php echo esc_html( wp_trim_words( $c_title, 6 ) ); ?></span>
                <span style="color:#64748b;font-size:10px;"><?php echo esc_html( $status_labels[ $c_status ] ?? '' ); ?></span>
                <span style="color:#64748b;font-size:11px;min-width:80px;text-align:right;">Pos <?php echo round( (float) $c_pos, 1 ); ?> · <?php echo (int) $c_days; ?>j</span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        </div><!-- /max-width container -->
        <?php
    }


    /* S12: Migre vers Agents cards dans settings-unified.php */
    // render_section_feature_status() — removed: empty dead code (Phase 2C)

    /**
     * Section: render_section_semantic (Session I — extracted from render).
     */
    private function render_section_semantic() {
        // ══════ Phase 2b: EMBEDDINGS + COCON SÉMANTIQUE ══════
        $emb_stats = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb_stats = HTS_Embeddings::get_stats();
        }
        $cocon_stats = null;
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon_obj = new HTS_Cocon();
            $cocon_stats = $cocon_obj->get_quick_stats();
        }
        if ( $emb_stats ) :
            $emb_pct = (int) ( $emb_stats['coverage'] ?? 0 );
            $emb_bar_color = $emb_pct >= 80 ? '#16a34a' : ( $emb_pct >= 40 ? '#d97706' : '#dc2626' );
        ?>
        <!-- ═══ LAZY-LOAD WRAPPER: Semantic (Session G) ═══ -->
        <div class="hts-lazy-section" data-lazy="semantic">
        <div class="hts-skeleton-loader" style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px 24px;margin-bottom:12px;">
            <div style="height:12px;width:200px;background:#e5e7eb;border-radius:4px;margin-bottom:14px;animation:htsSkelPulse 1.5s infinite;"></div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
                <div style="height:48px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;"></div>
                <div style="height:48px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;animation-delay:.2s;"></div>
                <div style="height:48px;background:#f3f4f6;border-radius:6px;animation:htsSkelPulse 1.5s infinite;animation-delay:.4s;"></div>
            </div>
        </div>
        <div class="hts-lazy-content" style="display:none;">
        <div class="hc-section">Semantique — Embeddings & Cocon</div>

        <!-- Embeddings status -->
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px 18px;margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                <div style="font-size:12px;font-weight:600;color:#1a1f36;">
                    Indexation sémantique
                </div>
                <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:<?php echo (int) $emb_pct >= 80 ? '#f0fdf4' : ( $emb_pct > 0 ? '#fffbeb' : '#fef2f2' ); ?>;color:<?php echo esc_attr( $emb_bar_color ); ?>;font-weight:600;">
                    <?php echo (int) $emb_pct; ?>%
                </span>
            </div>

            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:10px;">
                <div style="text-align:center;">
                    <div style="font-size:18px;font-weight:700;color:#1a1f36;"><?php echo (int) $emb_stats['indexed']; ?></div>
                    <div style="font-size:10px;color:#64748b;">Indexés</div>
                </div>
                <div style="text-align:center;">
                    <div style="font-size:18px;font-weight:700;color:<?php echo ( $emb_stats['pending'] ?? 0 ) > 0 ? '#d97706' : '#64748b'; ?>;"><?php echo (int) ( $emb_stats['pending'] ?? 0 ); ?></div>
                    <div style="font-size:10px;color:#64748b;">En attente</div>
                </div>
                <div style="text-align:center;">
                    <div style="font-size:18px;font-weight:700;color:#6366f1;"><?php echo (int) ( $emb_stats['money_pages'] ?? 0 ); ?></div>
                    <div style="font-size:10px;color:#64748b;">Money Pages</div>
                </div>
            </div>

            <!-- Progress bar -->
            <div style="background:#f1f5f9;border-radius:4px;height:6px;overflow:hidden;margin-bottom:10px;">
                <div style="background:<?php echo esc_attr( $emb_bar_color ); ?>;height:100%;width:<?php echo (int) $emb_pct; ?>%;border-radius:4px;transition:width .5s;"></div>
            </div>

            <?php if ( ( $emb_stats['pending'] ?? 0 ) > 0 ) : ?>
            <div style="display:flex;gap:8px;align-items:center;">
                <button id="hts-btn-embed-index" onclick="htsEmbedIndex(this)"
                    style="font-size:11px;color:#fff;background:#6366f1;border:none;border-radius:6px;padding:6px 14px;cursor:pointer;font-weight:600;">
                    Indexer maintenant (<?php echo (int) $emb_stats['pending']; ?> articles)
                </button>
                <span id="hts-embed-progress" style="font-size:10px;color:#64748b;"></span>
            </div>
            <?php elseif ( $emb_pct >= 100 ) : ?>
            <div style="font-size:11px;color:#16a34a;font-weight:600;">Tous les articles sont indexés</div>
            <?php endif; ?>

            <?php if ( $emb_stats['mode'] === 'onboarding' && $emb_pct === 0 ) : ?>
            <div style="margin-top:8px;font-size:11px;color:#a16207;background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:8px 12px;">
                L'indexation sémantique permet au plugin de comprendre le contenu de chaque article et de proposer un maillage interne intelligent.
                Cliquez sur "Indexer maintenant" pour démarrer — le processus prend environ 1 seconde par article.
            </div>
            <?php endif; ?>
        </div>

        <!-- Cocon status -->
        <?php if ( $cocon_stats && ! empty( $cocon_stats['analyzed'] ) && $cocon_stats['analyzed'] === true ) :
            $cs = $cocon_stats['stats'] ?? array();
            $clusters = $cocon_stats['clusters'] ?? array();
            $missing = $cocon_stats['missing_clusters'] ?? array();
            $flagged = $cocon_stats['flagged_pages'] ?? array();
        ?>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px 18px;margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <div style="font-size:12px;font-weight:600;color:#1a1f36;">Cocon sémantique</div>
                <span style="font-size:10px;color:#64748b;">
                    Dernière analyse : <?php
                        $last_a = (int) ( $cocon_stats['last'] ?? 0 );
                        echo $last_a > 0 ? human_time_diff( $last_a ) . ' ago' : 'jamais';
                    ?>
                </span>
            </div>

            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;">
                <div style="background:#f8fafc;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:#1a1f36;"><?php echo (int) ( $cs['total_pages'] ?? 0 ); ?></div>
                    <div style="font-size:9px;color:#64748b;">Pages</div>
                </div>
                <div style="background:#f0fdf4;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:#166534;"><?php echo count( $clusters ); ?></div>
                    <div style="font-size:9px;color:#64748b;">Clusters</div>
                </div>
                <div style="background:#eff6ff;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:#1d4ed8;"><?php echo (int) ( $cs['total_links'] ?? 0 ); ?></div>
                    <div style="font-size:9px;color:#64748b;">Liens internes</div>
                </div>
                <div style="background:<?php echo ( $cs['orphans'] ?? 0 ) > 0 ? '#fef2f2' : '#f8fafc'; ?>;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:<?php echo ( $cs['orphans'] ?? 0 ) > 0 ? '#dc2626' : '#64748b'; ?>;"><?php echo (int) ( $cs['orphans'] ?? 0 ); ?></div>
                    <div style="font-size:9px;color:#64748b;">Orphelins</div>
                </div>
            </div>

            <?php if ( ! empty( $clusters ) ) : ?>
            <div style="margin-bottom:10px;">
                <button onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'block':'none';this.textContent=this.nextElementSibling.style.display==='none'?'Détail clusters ('+<?php echo count( $clusters ); ?>+')':'▼ Clusters ('+<?php echo count( $clusters ); ?>+')';"
                    style="font-size:11px;color:#6366f1;background:none;border:none;cursor:pointer;padding:0;font-weight:600;">
                    Détail clusters (<?php echo count( $clusters ); ?>)
                </button>
                <div style="display:none;margin-top:8px;">
                    <?php foreach ( $clusters as $cl ) :
                        $d_color = ( $cl['density'] ?? 0 ) >= 50 ? '#16a34a' : ( ( $cl['density'] ?? 0 ) >= 20 ? '#d97706' : '#dc2626' );
                    ?>
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #f3f4f6;font-size:11px;">
                        <div style="display:flex;align-items:center;gap:6px;">
                            <span style="font-weight:600;color:#1a1f36;"><?php echo esc_html( $cl['name'] ?? '?' ); ?></span>
                            <span style="color:#64748b;"><?php echo (int) ( $cl['page_count'] ?? 0 ); ?> pages</span>
                        </div>
                        <div style="display:flex;gap:10px;">
                            <?php if ( ( $cl['orphan_count'] ?? $cl['orphans'] ?? 0 ) > 0 ) : ?>
                            <span style="color:#dc2626;font-weight:600;"><?php echo (int) ( $cl['orphan_count'] ?? $cl['orphans'] ?? 0 ); ?> orphelins</span>
                            <?php endif; ?>
                            <span style="color:<?php echo esc_attr( $d_color ); ?>;font-weight:600;"><?php echo (int) ( $cl['density'] ?? 0 ); ?>% densité</span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( ! empty( $missing ) ) : ?>
            <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:8px 12px;margin-bottom:10px;">
                <div style="font-size:11px;font-weight:600;color:#92400e;margin-bottom:4px;">Clusters manquants détectés</div>
                <?php foreach ( array_slice( $missing, 0, 3 ) as $mc ) : ?>
                <div style="font-size:11px;color:#a16207;">• <?php echo esc_html( is_array( $mc ) ? ( $mc['name'] ?? $mc['topic'] ?? '' ) : $mc ); ?></div>
                <?php endforeach; ?>
                <?php if ( count( $missing ) > 3 ) : ?>
                <div style="font-size:10px;color:#a16207;margin-top:2px;">+ <?php echo count( $missing ) - 3; ?> autre(s)</div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div style="display:flex;gap:8px;">
                <button onclick="htsCoconAnalyze(this)" style="font-size:11px;color:#6366f1;background:none;border:1px solid #e0e7ff;border-radius:6px;padding:4px 10px;cursor:pointer;font-weight:600;">
                    Relancer l'analyse
                </button>
            </div>
        </div>

        <?php else : ?>
        <!-- Cocon: pas encore analysé -->
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px 18px;margin-bottom:12px;">
            <div style="font-size:12px;font-weight:600;color:#1a1f36;margin-bottom:8px;">Cocon sémantique</div>

            <?php if ( $emb_pct < 50 ) : ?>
            <div style="font-size:11px;color:#a16207;background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:8px 12px;">
                L'analyse du cocon nécessite que les embeddings soient indexés (au moins 50%).
                Lancez d'abord l'indexation sémantique ci-dessus.
            </div>
            <?php else : ?>
            <div style="font-size:11px;color:#64748b;margin-bottom:10px;">
                L'analyse du cocon identifie les clusters thématiques de votre site, détecte les articles orphelins,
                et propose un maillage interne intelligent basé sur la proximité sémantique.
            </div>
            <button onclick="htsCoconAnalyze(this)" style="font-size:11px;color:#fff;background:#6366f1;border:none;border-radius:6px;padding:6px 14px;cursor:pointer;font-weight:600;">
                Lancer l'analyse du cocon
            </button>
            <span id="hts-cocon-progress" style="font-size:10px;color:#64748b;margin-left:8px;"></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php endif; /* $emb_stats */ ?>
        </div><!-- /.hts-lazy-content -->
        </div><!-- /.hts-lazy-section[semantic] -->

        <?php
        // ══════ Phase 6a UI: COCON COMMANDER ══════
        if ( class_exists( 'HTS_Cocon_Commander' ) ) :
            $cc = new HTS_Cocon_Commander();
            $cc_plans = $cc->get_plans();
            $cc_count = count( $cc_plans );
            $cc_total_articles = 0;
            $cc_received = 0;
            $cc_to_generate = 0;
            foreach ( $cc_plans as $pid => $pp ) {
                $pstats = $cc->get_plan_stats( $pid );
                $cc_total_articles += $pstats['total'] ?? 0;
                $cc_received += $pstats['received'] ?? 0;
                $cc_to_generate += $pstats['to_generate'] ?? 0;
            }
        ?>
        <div class="hc-section">Cocon Commander — Plans d'articles</div>

        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px 18px;margin-bottom:12px;">
            <?php if ( $cc_count === 0 ) : ?>
            <div style="font-size:12px;color:#64748b;">
                Aucun plan de cocon reçu pour le moment. Les plans d'articles seront envoyés automatiquement depuis votre espace Hack The SEO.
            </div>
            <?php else : ?>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;">
                <div style="background:#f8fafc;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:#1a1f36;"><?php echo (int) $cc_count; ?></div>
                    <div style="font-size:9px;color:#64748b;">Plans</div>
                </div>
                <div style="background:#eff6ff;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:#3b82f6;"><?php echo (int) $cc_total_articles; ?></div>
                    <div style="font-size:9px;color:#64748b;">Articles</div>
                </div>
                <div style="background:#f0fdf4;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:#16a34a;"><?php echo (int) $cc_received; ?></div>
                    <div style="font-size:9px;color:#64748b;">Reçus</div>
                </div>
                <div style="background:<?php echo (int) $cc_to_generate > 0 ? '#eff6ff' : '#f8fafc'; ?>;border-radius:6px;padding:8px;text-align:center;">
                    <div style="font-size:16px;font-weight:700;color:<?php echo (int) $cc_to_generate > 0 ? '#6366f1' : '#64748b'; ?>;"><?php echo (int) $cc_to_generate; ?></div>
                    <div style="font-size:9px;color:#64748b;">À générer</div>
                </div>
            </div>

            <?php
            // Show progress bar
            $cc_pct = $cc_total_articles > 0 ? round( ( $cc_received / $cc_total_articles ) * 100 ) : 0;
            ?>
            <div style="background:#f1f5f9;border-radius:4px;height:6px;overflow:hidden;margin-bottom:10px;">
                <div style="background:<?php echo (int) $cc_pct >= 80 ? '#16a34a' : ( $cc_pct > 0 ? '#6366f1' : '#e5e7eb' ); ?>;height:100%;width:<?php echo (int) $cc_pct; ?>%;border-radius:4px;transition:width .5s;"></div>
            </div>

            <!-- Quick plan summary -->
            <?php foreach ( $cc_plans as $pid => $pp ) :
                $pstats = $cc->get_plan_stats( $pid );
            ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #f3f4f6;font-size:11px;">
                <div style="display:flex;align-items:center;gap:6px;">
                    
                    <span style="font-weight:600;color:#1a1f36;"><?php echo esc_html( $pp['pillar_title'] ?: $pid ); ?></span>
                    <span style="color:#64748b;"><?php echo (int) ( $pstats['total'] ?? 0 ); ?> articles</span>
                </div>
                <div style="display:flex;gap:8px;">
                    <?php if ( ( $pstats['to_generate'] ?? 0 ) > 0 ) : ?>
                    <span style="color:#3b82f6;font-weight:600;"><?php echo (int) $pstats['to_generate']; ?> à générer</span>
                    <?php endif; ?>
                    <?php if ( ( $pstats['received'] ?? 0 ) > 0 ) : ?>
                    <span style="color:#16a34a;font-weight:600;"><?php echo (int) $pstats['received']; ?> reçu(s)</span>
                    <?php endif; ?>
                    <?php if ( ( $pstats['duplicate'] ?? 0 ) > 0 ) : ?>
                    <span style="color:#dc2626;font-weight:600;"><?php echo (int) $pstats['duplicate']; ?> doublons</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <div style="margin-top:10px;">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-cocon-commander' ) ); ?>"
                   style="font-size:11px;color:#6366f1;font-weight:600;text-decoration:none;">
                    Gérer les plans →
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; /* HTS_Cocon_Commander */ ?>

        <?php
        // ══════ Phase 6b: CALENDRIER ÉDITORIAL ══════
        if ( class_exists( 'HTS_Cocon_Commander' ) ) :
            $cal_cc = new HTS_Cocon_Commander();
            $cal_plans = $cal_cc->get_plans();
            $cal_scheduled = 0;
            $cal_unscheduled = 0;
            $cal_published = 0;
            $cal_next_date = null;

            foreach ( $cal_plans as $cal_plan ) {
                foreach ( $cal_plan['articles'] ?? array() as $cal_art ) {
                    if ( ! in_array( $cal_art['status'] ?? '', array( 'received', 'ready', 'scheduled' ), true ) ) continue;
                    $cal_pid = $cal_art['post_id'] ?? null;
                    if ( ! $cal_pid ) { $cal_unscheduled++; continue; }
                    $cal_post = get_post( $cal_pid );
                    if ( ! $cal_post ) { $cal_unscheduled++; continue; }
                    if ( $cal_post->post_status === 'publish' ) {
                        $cal_published++;
                    } elseif ( $cal_post->post_status === 'future' ) {
                        $cal_scheduled++;
                        if ( ! $cal_next_date || $cal_post->post_date < $cal_next_date ) {
                            $cal_next_date = $cal_post->post_date;
                        }
                    } else {
                        $cal_unscheduled++;
                    }
                }
            }
            $cal_total = $cal_scheduled + $cal_unscheduled + $cal_published;
        ?>
        <div class="hc-section">Calendrier Editorial</div>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:16px 20px;margin-bottom:16px;">
            <?php if ( $cal_total === 0 ) : ?>
                <div style="text-align:center;color:#94a3b8;font-size:12px;padding:12px 0;">
                    Aucun article à planifier pour le moment.
                </div>
            <?php else : ?>
                <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px;">
                    <div style="text-align:center;">
                        <div style="font-size:22px;font-weight:800;color:#1a1f36;"><?php echo (int) $cal_total; ?></div>
                        <div style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;">Total</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:22px;font-weight:800;color:#6366f1;"><?php echo (int) $cal_scheduled; ?></div>
                        <div style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;">Planifiés</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:22px;font-weight:800;color:#f59e0b;"><?php echo (int) $cal_unscheduled; ?></div>
                        <div style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;">À planifier</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:22px;font-weight:800;color:#10b981;"><?php echo (int) $cal_published; ?></div>
                        <div style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;">Publiés</div>
                    </div>
                </div>
                <?php if ( $cal_next_date ) : ?>
                    <div style="font-size:11px;color:#64748b;text-align:center;margin-bottom:8px;">
                        Prochaine publication : <strong><?php echo esc_html( date_i18n( 'j F Y à H:i', strtotime( $cal_next_date ) ) ); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if ( $cal_total > 0 ) :
                    $cal_pct = $cal_total > 0 ? round( $cal_published / $cal_total * 100 ) : 0;
                ?>
                    <div style="background:#f3f4f6;border-radius:8px;height:8px;overflow:hidden;">
                        <div style="background:linear-gradient(90deg,#10b981,#6366f1);height:100%;width:<?php echo (int) $cal_pct; ?>%;border-radius:8px;transition:width .3s;"></div>
                    </div>
                    <div style="font-size:10px;color:#94a3b8;text-align:center;margin-top:4px;"><?php echo (int) $cal_pct; ?>% publiés</div>
                <?php endif; ?>
            <?php endif; ?>

            <div style="margin-top:10px;">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-cocon-commander' ) ); ?>"
                   style="font-size:11px;color:#6366f1;font-weight:600;text-decoration:none;">
                    Ouvrir Cocon Commander →
                </a>
            </div>
        </div>
        <?php endif; /* Calendar section */ ?>
        <?php
    }

    /* S12: Migre vers admin/partials/health.php */
    // render_section_diagnostic() — removed: empty dead code (Phase 2C)
    private function render_coach_page() {
        $nonce = wp_create_nonce( 'hts_admin_nonce' );
        $has_key = ! empty( HTS_Coach::get_api_key() );
        $usage   = HTS_Coach::get_usage();
        $budget  = HTS_Coach::get_monthly_budget();
        // v4.0 fix : session_id from URL for persistence across page reloads
        $url_session_id = absint( $_GET['session'] ?? 0 );

        // ── Auto-detect : si pas de session dans l'URL, trouver la dernière session active (<30min) ──
        if ( ! $url_session_id ) {
            global $wpdb;
            $ses_table = $wpdb->prefix . 'hts_coach_sessions';
            $user_id   = get_current_user_id();
            static $coach_tables_checked = null;
            if ( $coach_tables_checked === null ) {
                $coach_tables_checked = array(
                    'ses' => (bool) ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $ses_table ) ) === $ses_table ),
                    'msg' => false,
                );
                if ( $coach_tables_checked['ses'] ) {
                    $msg_table_tmp = $wpdb->prefix . 'hts_coach_messages';
                    $coach_tables_checked['msg'] = (bool) ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $msg_table_tmp ) ) === $msg_table_tmp );
                }
            }
            $ses_ok = $coach_tables_checked['ses'];
            if ( $ses_ok ) {
                $msg_table = $wpdb->prefix . 'hts_coach_messages';
                $msg_ok = $coach_tables_checked['msg'];
                if ( $msg_ok ) {
                    // Chercher la dernière session ouverte avec des messages récents (< 30 min)
                    $timeout = 1800; // SESSION_TIMEOUT
                    $active = $wpdb->get_row( $wpdb->prepare(
                        "SELECT s.id, MAX(m.created_at) AS last_msg
                         FROM {$ses_table} s
                         INNER JOIN {$msg_table} m ON m.session_id = s.id
                         WHERE s.user_id = %d AND s.session_end IS NULL
                         GROUP BY s.id
                         HAVING TIMESTAMPDIFF(SECOND, MAX(m.created_at), NOW()) < %d
                         ORDER BY s.session_start DESC LIMIT 1",
                        $user_id, $timeout
                    ), ARRAY_A );
                    if ( $active ) {
                        $url_session_id = (int) $active['id'];
                    }
                }
            }
        }

        // ── Server-side : charger les messages de la session directement en PHP ──
        $ssr_messages = array();
        $ssr_plans    = array();
        $ssr_seo_plans = array(); // Sprint 5.4: structured SEO plans
        $ssr_actions  = array(); // Sprint 5.3: action cards SSR (AMÉL-2)
        $ssr_skipped  = array(); // Sprint 5.3: skipped action cards SSR
        if ( $url_session_id > 0 ) {
            global $wpdb;
            $msg_table = $wpdb->prefix . 'hts_coach_messages';
            $user_id   = get_current_user_id();
            // Vérifier que la table existe avant de requêter (reuse static cache)
            $table_ok = isset( $coach_tables_checked ) ? $coach_tables_checked['msg'] : (bool) ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $msg_table ) ) === $msg_table );
            if ( $table_ok ) {
                // Détecter les colonnes disponibles (actions_json peut ne pas exister) — cached
                static $coach_msg_columns = null;
                if ( $coach_msg_columns === null ) {
                    $coach_msg_columns = $wpdb->get_col( "SHOW COLUMNS FROM {$msg_table}", 0 );
                }
                $columns = $coach_msg_columns;
                $has_actions_col = in_array( 'actions_json', $columns, true );
                $has_chart_col   = in_array( 'chart_json', $columns, true );

                $allowed_cols = array( 'role', 'content', 'chart_json', 'actions_json' );
                $select_cols_arr = array( 'role', 'content' );
                if ( $has_chart_col )   $select_cols_arr[] = 'chart_json';
                if ( $has_actions_col ) $select_cols_arr[] = 'actions_json';
                $select_cols_arr = array_intersect( $select_cols_arr, $allowed_cols );
                $select_cols = implode( ', ', $select_cols_arr );

                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT {$select_cols}
                     FROM {$msg_table}
                     WHERE session_id = %d AND user_id = %d
                     ORDER BY created_at ASC LIMIT 200",
                    $url_session_id, $user_id
                ), ARRAY_A );

                if ( $rows ) {
                    $msg_idx = 0;
                    foreach ( $rows as $row ) {
                        if ( $row['role'] === 'system' ) continue;
                        $chart = null;
                        if ( $has_chart_col && ! empty( $row['chart_json'] ) ) {
                            $chart = json_decode( $row['chart_json'], true );
                        }
                        $plan = null;
                        $msg_actions = null;
                        if ( $has_actions_col && ! empty( $row['actions_json'] ) ) {
                            $raw_data = json_decode( $row['actions_json'], true );
                            if ( is_array( $raw_data ) ) {
                                // Sprint 5.3: new format {plan: ..., actions: ..., skipped: ...}
                                if ( isset( $raw_data['plan'] ) && ! empty( $raw_data['plan']['steps'] ) ) {
                                    $plan = $raw_data['plan'];
                                    $ssr_plans[ $msg_idx ] = $plan;
                                } elseif ( ! empty( $raw_data['steps'] ) ) {
                                    // Legacy format: direct plan object
                                    $plan = $raw_data;
                                    $ssr_plans[ $msg_idx ] = $plan;
                                }
                                if ( ! empty( $raw_data['actions'] ) && is_array( $raw_data['actions'] ) ) {
                                    $ssr_actions[ $msg_idx ] = $raw_data['actions'];
                                }
                                if ( ! empty( $raw_data['seo_plan'] ) && is_array( $raw_data['seo_plan'] ) && ! empty( $raw_data['seo_plan']['phases'] ) ) {
                                    $ssr_seo_plans[ $msg_idx ] = $raw_data['seo_plan'];
                                }
                                if ( ! empty( $raw_data['skipped'] ) && is_array( $raw_data['skipped'] ) ) {
                                    $ssr_skipped[ $msg_idx ] = $raw_data['skipped'];
                                }
                            }
                        }
                        $ssr_messages[] = array(
                            'role'    => $row['role'],
                            'content' => $row['content'],
                            'chart'   => $chart,
                        );
                        $msg_idx++;
                    }
                }
            } // end if $table_ok

            // Sprint 5.3: Enrich SSR action cards with live status
            if ( ! empty( $ssr_actions ) ) {
                $all_ssr_ids = array();
                foreach ( $ssr_actions as $acts ) {
                    foreach ( (array) $acts as $a ) {
                        if ( ! empty( $a['action_id'] ) ) $all_ssr_ids[] = (int) $a['action_id'];
                    }
                }
                if ( ! empty( $all_ssr_ids ) ) {
                    $ids_in  = implode( ',', array_unique( $all_ssr_ids ) );
                    $we_tbl  = $wpdb->prefix . 'hts_workflow_actions';
                    $ssr_sts = $wpdb->get_results( "SELECT id, status FROM {$we_tbl} WHERE id IN ({$ids_in})", OBJECT_K );
                    foreach ( $ssr_actions as &$acts ) {
                        foreach ( $acts as &$a ) {
                            $aid = (int) ( $a['action_id'] ?? 0 );
                            if ( $aid && isset( $ssr_sts[ $aid ] ) ) {
                                $a['live_status'] = $ssr_sts[ $aid ]->status;
                            }
                        }
                        unset( $a );
                    }
                    unset( $acts );
                }
            }
        } // end if $url_session_id
        // Debug SSR (visible en "Inspecter l'élément" → HTML comments)
        $ssr_debug = array(
            'url_session_id' => $url_session_id,
            'ssr_count'      => count( $ssr_messages ),
            'table_ok'       => isset( $table_ok ) ? $table_ok : 'N/A',
            'user_id'        => $user_id ?? get_current_user_id(),
        );
        ?>
        <?php include HTS__PLUGIN_DIR . 'admin/partials/coach.php'; ?>


        <script>
        (function(){
            var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
            var URL_SESSION_ID = <?php echo (int) $url_session_id; ?>;
            var chartInstances = {};
            var isLoading = false;
            var providerStats = { t1: { tokens: 0, requests: 0 }, t2: { tokens: 0, requests: 0 }, t3: { tokens: 0, requests: 0 } };

            // v4.0 fix : Update URL with session_id without page reload
            function updateUrlSession(sessionId) {
                if (!sessionId || sessionId <= 0) return;
                var url = new URL(window.location.href);
                url.searchParams.set('session', sessionId);
                window.history.replaceState({}, '', url.toString());
                URL_SESSION_ID = sessionId;
            }

            // ── Load sidebar data ──
            function loadContext() {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_context&nonce=' + NONCE
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (!d.success) return;
                    var ctx = d.data.context;
                    var usage = d.data.usage;
                    var budget = d.data.budget;

                    // Scores
                    var gs = document.getElementById('coachScoreGlobal');
                    var geo = document.getElementById('coachScoreGeo');
                    var pend = document.getElementById('coachPending');
                    if (gs) gs.textContent = ctx.global_score ? ctx.global_score + '/100' : 'Non calculé';
                    if (geo) geo.textContent = ctx.geo_score_avg ? ctx.geo_score_avg + '/100' : 'Non calculé';
                    if (pend) pend.textContent = ctx.pending_actions || '0';

                    // Color code scores
                    if (ctx.global_score) {
                        gs.style.color = ctx.global_score >= 70 ? '#16a34a' : (ctx.global_score >= 40 ? '#d97706' : '#dc2626');
                    }
                    if (ctx.geo_score_avg) {
                        geo.style.color = ctx.geo_score_avg >= 60 ? '#16a34a' : (ctx.geo_score_avg >= 30 ? '#d97706' : '#dc2626');
                    }

                    // Worst pages
                    var wp = document.getElementById('coachWorstPages');
                    if (wp && ctx.worst_pages && ctx.worst_pages.length) {
                        var html = '';
                        ctx.worst_pages.forEach(function(p) {
                            var col = p.score >= 70 ? '#16a34a' : (p.score >= 40 ? '#d97706' : '#dc2626');
                            html += '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f1f5f9;">';
                            html += '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:180px;" title="' + htsE(p.title) + '">' + htsE(p.title) + '</span>';
                            html += '<span style="font-weight:700;color:' + col + ';font-size:12px;flex-shrink:0;margin-left:8px;">' + p.score + '</span>';
                            html += '</div>';
                        });
                        wp.innerHTML = html;
                    } else if (wp) {
                        wp.textContent = 'Aucun score calculé';
                    }

                    // Usage
                    updateUsage(usage, budget);
                });
            }

            function updateUsage(usage, budget) {
                var total = (usage.tokens_in || 0) + (usage.tokens_out || 0);
                var pct = budget > 0 ? Math.min(100, Math.round(total / budget * 100)) : 0;
                var el = document.getElementById('coachTokensUsed');
                if (el) el.textContent = formatNum(total);
                var bar = document.getElementById('coachUsageBar');
                if (bar) {
                    bar.style.width = pct + '%';
                    bar.style.background = pct > 80 ? '#dc2626' : (pct > 50 ? '#d97706' : 'var(--coach-primary)');
                }
                var req = document.getElementById('coachRequests');
                if (req) req.textContent = (usage.requests || 0) + ' requête' + ((usage.requests || 0) > 1 ? 's' : '');
                var bl = document.getElementById('coachBudgetLabel');
                if (bl) bl.textContent = formatNum(budget) + ' budget';
            }

            function formatNum(n) {
                if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
                if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
                return n.toString();
            }

            function htsE(s) {
                var d = document.createElement('div');
                d.textContent = s;
                return d.innerHTML;
            }

            // Sprint 5.4: Decode HTML entities from WP post titles (e.g. &#8211; → –)
            function htsDecode(s) {
                if (!s) return '';
                var d = document.createElement('textarea');
                d.innerHTML = s;
                return d.value;
            }

            // ── Load history — Sprint 1.3: pass chart for re-render ──
            function loadHistory() {
                // If SSR already rendered messages, nothing to do
                if (hasSSR) return;

                // No session in URL → just show welcome (already in HTML)
                // The welcome proactif + suggestions will be loaded by loadStartupSuggestions()
            }

            // Shared function to load messages from a session
            function loadSessionMessages(sessionId, isPast) {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_session_messages&nonce=' + NONCE + '&session_id=' + sessionId
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (!d || !d.success || !d.data.messages || !d.data.messages.length) {
                        // Aucun message trouvé → afficher le welcome
                        if (!isPast) {
                            var welcomeEl = document.getElementById('coachWelcomeMsg');
                            if (welcomeEl) welcomeEl.style.display = '';
                            loadStartupSuggestions();
                        }
                        return;
                    }
                    var container = document.getElementById('coachMessages');

                    // Si c'est un reload (pas isPast), vider le container d'abord
                    if (!isPast && container) {
                        container.innerHTML = '';
                    }

                    // Header si conversation passée
                    if (isPast && d.data.session) {
                        var sess = d.data.session;
                        var topicsStr = (sess.topics && sess.topics.length) ? sess.topics.join(', ') : 'Conversation';
                        var dateStr = sess.session_start ? new Date(sess.session_start).toLocaleDateString('fr-FR', {day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}) : '';
                        var headerDiv = document.createElement('div');
                        headerDiv.style.cssText = 'text-align:center;padding:12px;color:#94a3b8;font-size:11px;border-bottom:1px solid #f1f5f9;margin-bottom:8px;';
                        headerDiv.innerHTML = '\uD83D\uDCC2 <strong>' + htsE(topicsStr) + '</strong><br>' + dateStr;
                        if (sess.summary_text) {
                            headerDiv.innerHTML += '<div style="margin-top:6px;font-style:italic;color:#64748b;">' + htsE(sess.summary_text) + '</div>';
                        }
                        container.appendChild(headerDiv);
                    }

                    d.data.messages.forEach(function(msg) {
                        if (msg.role === 'system') return;
                        var provInfo = null;
                        if (msg.role === 'assistant' && msg.model) {
                            provInfo = { provider: msg.provider || '', model: msg.model || '', tokens_in: parseInt(msg.tokens_in) || 0, tokens_out: parseInt(msg.tokens_out) || 0 };
                        }
                        addMessage(msg.role, msg.content, msg.chart || null, null, provInfo);

                        // Sprint 4.1 : re-render plan cards
                        if (msg.role === 'assistant' && msg.plan && msg.plan.steps && msg.plan.steps.length > 0) {
                            renderPlanAfterBubble(msg.plan, container);
                        }
                        // Sprint 5.3 AMÉL-2 : re-render action cards (green cards)
                        if (msg.role === 'assistant' && msg.actions && msg.actions.length > 0) {
                            // Check action status — mark already-applied actions
                            var restoredActions = msg.actions.map(function(act) {
                                // If action was already applied/rejected, show as done
                                return act;
                            });
                            renderActionsAfterBubble(restoredActions, container);
                        }
                        // Sprint 5.3: re-render skipped actions (greyed cards)
                        if (msg.role === 'assistant' && msg.skipped && msg.skipped.length > 0) {
                            var skipWrap = document.createElement('div');
                            skipWrap.style.cssText = 'margin-top:8px;display:flex;flex-direction:column;gap:4px;';
                            msg.skipped.forEach(function(s) {
                                var skipCard = document.createElement('div');
                                skipCard.style.cssText = 'background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px;opacity:.6;display:flex;align-items:center;gap:8px;';
                                var skipTitle = htsDecode(s.post_title || s.reason || s.type);
                                skipCard.innerHTML = '<span style="font-size:11px;color:#94a3b8;">\u23f8</span>' +
                                    '<span style="flex:1;font-size:12px;color:#64748b;">' + htsE(skipTitle) + '</span>' +
                                    '<span style="font-size:10px;padding:2px 6px;border-radius:4px;background:#fef3c7;color:#92400e;">' + htsE(s.skip_reason || 'D\u00e9j\u00e0 en attente') + '</span>';
                                skipWrap.appendChild(skipCard);
                            });
                            container.appendChild(skipWrap);
                        }
                    });
                    scrollToBottom();

                    // Masquer le welcome si on a des messages
                    var sug = document.getElementById('coachSuggestions');
                    if (sug && d.data.messages.length > 1) sug.style.display = 'none';
                });
            }

            // ── Send message ──
            window.coachSend = function() {
                var input = document.getElementById('coachInput');
                var q = (input.value || '').trim();
                if (!q || isLoading) return;
                coachAsk(q);
                input.value = '';
                input.style.height = 'auto';
            };

            // S14: clean structured JSON blocks from display (shared by streaming + finalizeMessage)
            function cleanForDisplay(text) {
                // Remove ```json { "goal":... } ``` blocks
                text = text.replace(/```(?:json)?\s*\n\s*\{[\s]*"(?:goal|steps|params|estimate|strategy|actions)"[\s]*:[\s\S]*?```/g, '');
                // Remove inline {"actions":[...]} blocks
                text = text.replace(/\{"actions"\s*:\s*\[[\s\S]*?\]\s*\}/g, '');
                // Remove ```chart/plan/seo_plan/report blocks
                text = text.replace(/```(?:chart|actions|plan|seo_plan|report)\s*\n[\s\S]*?```/g, '');
                // Clean multiple blank lines
                text = text.replace(/\n{3,}/g, '\n\n');
                return text.trim();
            }

            window.coachAsk = function(question) {
                if (isLoading) return;
                isLoading = true;

                // Hide suggestions
                var sug = document.getElementById('coachSuggestions');
                if (sug) sug.style.display = 'none';

                // Add user message
                addMessage('user', question);

                // Disable send
                var btn = document.getElementById('coachSendBtn');
                if (btn) btn.disabled = true;

                // ── Sprint 2.2 : Streaming SSE ──
                // Créer la bulle assistant vide immédiatement
                var container = document.getElementById('coachMessages');
                var msgDiv = document.createElement('div');
                msgDiv.className = 'coach-msg assistant';

                var avatar = document.createElement('div');
                avatar.className = 'coach-msg-avatar';
                avatar.textContent = '\uD83E\uDDE0';

                var bubble = document.createElement('div');
                bubble.className = 'coach-msg-bubble';
                bubble.innerHTML = '<span class="coach-stream-cursor"></span>';

                msgDiv.appendChild(avatar);
                msgDiv.appendChild(bubble);
                container.appendChild(msgDiv);
                scrollToBottom();

                var accumulated = '';
                var renderTimer = null;
                var streamActive = true;

                // Re-render markdown toutes les 50ms max (throttle — Sprint 4.4)
                function renderMarkdown() {
                    if (typeof marked !== 'undefined' && accumulated) {
                        var displayText = cleanForDisplay(accumulated);
                        bubble.innerHTML = DOMPurify.sanitize(marked.parse(displayText)) + (streamActive ? '<span class="coach-stream-cursor"></span>' : '');
                    } else {
                        bubble.textContent = accumulated + (streamActive ? ' ▍' : '');
                    }
                    scrollToBottom();
                }

                function scheduleRender() {
                    if (renderTimer) return;
                    renderTimer = setTimeout(function() {
                        renderTimer = null;
                        renderMarkdown();
                    }, 50);
                }

                // Fallback : si streaming échoue, utiliser l'ancien endpoint
                function fallbackAsk() {
                    bubble.innerHTML = '<span class="coach-stream-cursor"></span>';
                    accumulated = '';
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=hts_coach_ask&nonce=' + NONCE + '&question=' + encodeURIComponent(question) + '&session_id=' + (currentSessionId || 0)
                    })
                    .then(function(r){ return r.json(); })
                    .then(function(d){
                        streamActive = false;
                        isLoading = false;
                        if (btn) btn.disabled = false;

                        if (!d.success) {
                            bubble.innerHTML = '' + htsE(d.data && d.data.message ? d.data.message : 'Erreur inconnue');
                            return;
                        }

                        var data = d.data;
                        finalizeMessage(bubble, msgDiv, container, data);
                    })
                    .catch(function(err){
                        streamActive = false;
                        isLoading = false;
                        if (btn) btn.disabled = false;
                        bubble.innerHTML = 'Erreur de connexion : ' + htsE(err.message);
                    });
                }

                // Lancer le streaming SSE via fetch + ReadableStream
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_ask_stream&nonce=' + NONCE + '&question=' + encodeURIComponent(question) + '&session_id=' + (currentSessionId || 0)
                })
                .then(function(response) {
                    // Vérifier que le serveur a bien répondu en SSE
                    var ct = response.headers.get('content-type') || '';
                    if (!response.ok || ct.indexOf('text/event-stream') === -1) {
                        // Pas de SSE → fallback
                        fallbackAsk();
                        return;
                    }

                    var reader = response.body.getReader();
                    var decoder = new TextDecoder();
                    var sseBuffer = '';

                    function readChunk() {
                        reader.read().then(function(result) {
                            if (result.done) {
                                // S14 fix: Stream closed without event done → finalize with accumulated text
                                streamActive = false;
                                if (renderTimer) { clearTimeout(renderTimer); renderTimer = null; }
                                finalizeMessage(bubble, msgDiv, container, { text: accumulated, session_id: currentSessionId });
                                isLoading = false;
                                if (btn) btn.disabled = false;
                                return;
                            }

                            sseBuffer += decoder.decode(result.value, { stream: true });

                            // Parser les events SSE dans le buffer
                            var parts = sseBuffer.split('\n\n');
                            // Garder le dernier morceau incomplet
                            sseBuffer = parts.pop() || '';

                            for (var i = 0; i < parts.length; i++) {
                                var block = parts[i].trim();
                                if (!block) continue;

                                var eventType = '';
                                var dataStr = '';
                                var lines = block.split('\n');
                                for (var j = 0; j < lines.length; j++) {
                                    if (lines[j].indexOf('event: ') === 0) {
                                        eventType = lines[j].substring(7).trim();
                                    } else if (lines[j].indexOf('data: ') === 0) {
                                        dataStr += lines[j].substring(6);
                                    }
                                }

                                if (!dataStr) continue;

                                try {
                                    var payload = JSON.parse(dataStr);
                                } catch(e) {
                                    continue;
                                }

                                if (eventType === 'chunk' && payload.text) {
                                    accumulated += payload.text;
                                    scheduleRender();
                                }

                                if (eventType === 'done') {
                                    streamActive = false;
                                    if (renderTimer) { clearTimeout(renderTimer); renderTimer = null; }
                                    finalizeMessage(bubble, msgDiv, container, payload);
                                    isLoading = false;
                                    if (btn) btn.disabled = false;
                                    return; // Stop reading
                                }

                                if (eventType === 'error') {
                                    streamActive = false;
                                    if (renderTimer) { clearTimeout(renderTimer); renderTimer = null; }
                                    bubble.innerHTML = '' + htsE(payload.message || 'Erreur inconnue');
                                    isLoading = false;
                                    if (btn) btn.disabled = false;
                                    return;
                                }
                            }

                            // Continuer à lire
                            readChunk();
                        }).catch(function(err) {
                            streamActive = false;
                            isLoading = false;
                            if (btn) btn.disabled = false;
                            if (accumulated) {
                                // S14 fix: finalize properly so charts/reports render
                                if (renderTimer) { clearTimeout(renderTimer); renderTimer = null; }
                                finalizeMessage(bubble, msgDiv, container, { text: accumulated, session_id: currentSessionId });
                            } else {
                                bubble.innerHTML = 'Erreur de streaming : ' + htsE(err.message);
                            }
                        });
                    }

                    readChunk();
                })
                .catch(function(err) {
                    // Erreur réseau → fallback
                    fallbackAsk();
                });
            };

            /**
             * Finalise une bulle assistant après streaming ou fallback.
             * Re-render le markdown complet, ajoute chart/actions, met à jour les compteurs.
             */
            function finalizeMessage(bubble, msgDiv, container, data) {
                // v4.0 fix : update URL with session_id from the response
                if (data.session_id && data.session_id > 0) {
                    currentSessionId = data.session_id;
                    updateUrlSession(data.session_id);
                }

                // Render final du texte (clean)
                // S14: always clean client-side (for fallback path where server clean_response didn't run)
                var finalText = cleanForDisplay(data.text || '');
                if (typeof marked !== 'undefined' && finalText) {
                    bubble.innerHTML = DOMPurify.sanitize(marked.parse(finalText));
                } else {
                    bubble.textContent = finalText;
                }

                var providerInfo = { provider: data.provider || 'anthropic', model: data.model || '', tokens_in: data.tokens_in || 0, tokens_out: data.tokens_out || 0 };

                // Chart
                var chart = data.chart || null;
                if (chart && chart.type && chart.labels && chart.data) {
                    renderChartAfterBubble(chart, container);
                }

                // Actions
                var actions = data.actions || [];
                if (actions.length > 0) {
                    renderActionsAfterBubble(actions, container);
                }

                // Sprint 5.2: Show skipped actions (greyed out) for transparency
                var skipped = data.skipped_actions || [];
                if (skipped.length > 0) {
                    var skipWrap = document.createElement('div');
                    skipWrap.style.cssText = 'margin-top:8px;display:flex;flex-direction:column;gap:4px;';
                    skipped.forEach(function(s) {
                        var skipCard = document.createElement('div');
                        skipCard.style.cssText = 'background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px;opacity:.6;display:flex;align-items:center;gap:8px;';
                        var skipTitle = htsDecode(s.post_title || s.reason || s.type);
                        skipCard.innerHTML = '<span style="font-size:11px;color:#94a3b8;">\u23f8</span>' +
                            '<span style="flex:1;font-size:12px;color:#64748b;">' + htsE(skipTitle) + '</span>' +
                            '<span style="font-size:10px;padding:2px 6px;border-radius:4px;background:#fef3c7;color:#92400e;">' + htsE(s.skip_reason || 'D\u00e9j\u00e0 en attente') + '</span>';
                        skipWrap.appendChild(skipCard);
                    });
                    container.appendChild(skipWrap);
                }

                // Plan (Agent Mode — Sprint 4.1)
                var plan = data.plan || null;
                if (plan && plan.steps && plan.steps.length > 0) {
                    renderPlanAfterBubble(plan, container);
                }

                // SEO Plan (Sprint 5.4 — structured plan cards)
                var seoPlan = data.seo_plan || null;
                if (seoPlan && seoPlan.phases && seoPlan.phases.length > 0) {
                    renderSEOPlanAfterBubble(seoPlan, container);
                }

                // S13-B: Structured Report → rendered by coach.php panel
                var report = data.report || null;
                if (report && report.title) {
                    var reportEl = document.createElement('div');
                    reportEl.className = 'coach-report-card';
                    reportEl.setAttribute('data-report', JSON.stringify(report));
                    reportEl.style.display = 'none';
                    container.appendChild(reportEl);
                }

                // Track per-provider stats (3 tiers)
                var tokensUsed = (data.tokens_in || 0) + (data.tokens_out || 0);
                var mdl = providerInfo.model || '';
                if (mdl.indexOf('4.1-mini') !== -1) {
                    providerStats.t2.tokens += tokensUsed;
                    providerStats.t2.requests++;
                } else if (providerInfo.provider === 'openai') {
                    providerStats.t1.tokens += tokensUsed;
                    providerStats.t1.requests++;
                } else {
                    providerStats.t3.tokens += tokensUsed;
                    providerStats.t3.requests++;
                }
                updateProviderCounters();

                // Update usage
                if (data.usage) {
                    updateUsage(data.usage, <?php echo (int) $budget; ?>);
                }

                // Sprint 4.8 : Feedback buttons removed for streamed messages (UX pro — v2.6.3)

                scrollToBottom();
            }

            // ── Add message to chat ──
            function addMessage(role, text, chart, actions, providerInfo) {
                var container = document.getElementById('coachMessages');
                var msgDiv = document.createElement('div');
                msgDiv.className = 'coach-msg ' + role;

                var avatar = document.createElement('div');
                avatar.className = 'coach-msg-avatar';
                avatar.textContent = role === 'assistant' ? '\uD83E\uDDE0' : '\uD83D\uDC64';

                var bubble = document.createElement('div');
                bubble.className = 'coach-msg-bubble';

                if (role === 'assistant' && typeof marked !== 'undefined') {
                    bubble.innerHTML = DOMPurify.sanitize(marked.parse(cleanForDisplay(text || '')));
                } else {
                    bubble.textContent = text || '';
                }

                // Provider badge for assistant messages — v4.0: hidden by default (confusing for non-experts)
                // Visible only in debug/advanced mode
                if (false && role === 'assistant' && providerInfo && providerInfo.model) {
                    var badge = document.createElement('div');
                    var isOai = providerInfo.provider === 'openai';
                    var isSonnet = providerInfo.model.indexOf('sonnet') !== -1;
                    var is41mini = providerInfo.model.indexOf('4.1-mini') !== -1;
                    var cls, label, dotColor;
                    if (is41mini) {
                        cls = 'openai'; label = '4.1-mini'; dotColor = '#0ea5e9';
                    } else if (isOai) {
                        cls = 'openai'; label = '4o-mini'; dotColor = '#10b981';
                    } else if (isSonnet) {
                        cls = 'sonnet'; label = 'Sonnet'; dotColor = '#4f46e5';
                    } else {
                        cls = 'haiku'; label = 'Haiku'; dotColor = '#7c3aed';
                    }
                    var tokIn = providerInfo.tokens_in || 0;
                    var tokOut = providerInfo.tokens_out || 0;
                    var tokTotal = tokIn + tokOut;
                    var tokLabel = tokTotal > 0 ? ' · ' + formatNum(tokIn) + '→' + formatNum(tokOut) + ' (' + formatNum(tokTotal) + ')' : '';
                    badge.className = 'coach-provider-badge ' + cls;
                    badge.innerHTML = '<span class="coach-provider-dot" style="background:' + dotColor + ';"></span>' + label + tokLabel;
                    bubble.appendChild(badge);
                }

                msgDiv.appendChild(avatar);
                msgDiv.appendChild(bubble);

                // Sprint 4.8 : Feedback buttons removed (UX pro — v2.6.3)

                container.appendChild(msgDiv);

                // ── Render chart if present — Sprint 1.3: export PNG button ──
                if (chart && chart.type && chart.labels && chart.data) {
                    renderChartAfterBubble(chart, container);
                }

                // ── Actions : cartes cliquables dans le chat ──
                if (actions && actions.length > 0) {
                    renderActionsAfterBubble(actions, container, bubble);
                }

                scrollToBottom();
            }

            /**
             * Sprint 2.2 : Render chart block after a message bubble.
             * Extrait de addMessage pour réutilisation dans finalizeMessage.
             */
            function renderChartAfterBubble(chart, container) {
                var chartWrap = document.createElement('div');
                chartWrap.className = 'coach-chart-wrap';

                if (chart.title) {
                    var title = document.createElement('div');
                    title.className = 'coach-chart-title';
                    title.textContent = chart.title;
                    chartWrap.appendChild(title);
                }

                var exportBtn = document.createElement('button');
                exportBtn.type = 'button';
                exportBtn.className = 'coach-chart-export';
                exportBtn.title = 'Télécharger en PNG';
                exportBtn.textContent = '⬇';
                chartWrap.appendChild(exportBtn);

                var canvas = document.createElement('canvas');
                canvas.width = 380;
                canvas.height = chart.type === 'radar' ? 300 : 220;
                chartWrap.appendChild(canvas);

                exportBtn.onclick = function() {
                    var link = document.createElement('a');
                    link.download = (chart.title || 'chart').replace(/[^a-zA-Z0-9àâéèêëîïôûùüç\s-]/gi, '').replace(/\s+/g, '_') + '.png';
                    link.href = canvas.toDataURL('image/png');
                    link.click();
                };

                var chartMsg = document.createElement('div');
                chartMsg.className = 'coach-msg assistant';
                chartMsg.style.maxWidth = '460px';

                var chartAvatarSpacer = document.createElement('div');
                chartAvatarSpacer.style.width = '36px';
                chartAvatarSpacer.style.flexShrink = '0';

                chartMsg.appendChild(chartAvatarSpacer);
                chartMsg.appendChild(chartWrap);
                container.appendChild(chartMsg);

                setTimeout(function() { renderChart(canvas, chart); }, 50);
            }

            /**
             * Sprint 2.2 : Render actions cards after a message bubble.
             * Extrait de addMessage pour réutilisation dans finalizeMessage.
             * @param {Array} actions - Liste des actions.
             * @param {HTMLElement} container - Container des messages.
             * @param {HTMLElement} [targetBubble] - Bulle dans laquelle injecter (optionnel, sinon crée un nouveau bloc).
             */
            function renderActionsAfterBubble(actions, container, targetBubble) {
                var actionsWrap = document.createElement('div');
                actionsWrap.style.cssText = 'margin-top:12px;display:flex;flex-direction:column;gap:8px;';

                var actionsTitle = document.createElement('div');
                actionsTitle.style.cssText = 'font-size:12px;font-weight:700;color:#4338ca;margin-bottom:4px;';
                actionsTitle.textContent = '💡 ' + actions.length + ' action' + (actions.length > 1 ? 's' : '') + ' recommandée' + (actions.length > 1 ? 's' : '');
                actionsWrap.appendChild(actionsTitle);

                actions.forEach(function(act) {
                    var card = document.createElement('div');
                    // Sprint 5.4: softer card style — recommendation, not execution
                    var isDone = act.live_status && act.live_status !== 'pending' && act.live_status !== 'approved';
                    if (isDone) {
                        card.style.cssText = 'background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;opacity:.6;display:flex;align-items:center;gap:10px;';
                    } else {
                        card.style.cssText = 'background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px;transition:border-color .15s;';
                    }
                    card.setAttribute('data-action-id', act.action_id || '');

                    // Sprint 4.9 bugfix (Fix 5): improved card rendering with type badges
                    var typeLabels = {
                        add_internal_links: '🔗 Liens internes',
                        add_faq: '❓ Ajouter FAQ',
                        add_meta_title: '🏷️ Meta Title',
                        add_meta_desc: 'Meta Description',
                        content_refresh: '🔄 Rafraîchir contenu',
                        geo_optimize: '🤖 Optimiser GEO',
                        delete_page: '🗑️ Supprimer page',
                        coach_suggestion: '💡 Suggestion Coach',
                        // Sprint 5.1: new action types
                        fix_orphan_links: '🔗 Corriger orphelines',
                        schedule_publication: '📅 Programmer publication',
                        generate_article: '✍️ Générer article',
                        optimize_meta_both: '🏷️ Optimiser metas',
                        optimize_meta_title: '🏷️ Meta Title',
                        optimize_meta_desc: 'Meta Description',
                        create_cocon_articles: '🔗 Créer articles cocon',
                        bulk_optimize_metas: '🏷️ Metas en masse'
                    };
                    var cardBadge = typeLabels[act.action] || act.action || 'Action';
                    var cardTitle = act.post_title
                        ? htsDecode(act.post_title)
                        : (act.reason ? act.reason.substring(0, 80) : cardBadge);
                    var cardReason = act.post_title && act.reason ? act.reason : '';

                    var info = document.createElement('div');
                    info.style.cssText = 'flex:1;min-width:0;';
                    info.innerHTML =
                        '<div style="display:flex;gap:6px;align-items:center;">' +
                            '<span style="font-size:10px;padding:2px 6px;border-radius:4px;background:#eef2ff;color:#4338ca;font-weight:600;white-space:nowrap;">' + htsE(cardBadge) + '</span>' +
                        '</div>' +
                        '<div style="font-size:12px;font-weight:600;color:#1a1f36;margin-top:3px;overflow:hidden;text-overflow:ellipsis;">' + htsE(cardTitle) + '</div>' +
                        (cardReason ? '<div style="font-size:11px;color:#64748b;margin-top:2px;">' + htsE(cardReason) + '</div>' : '');
                    card.appendChild(info);

                    // Sprint 5.3: Show status label for already-processed actions
                    if (isDone) {
                        var statusLabel = document.createElement('span');
                        var statusMap = { done: 'Appliquée', failed: 'Échec', dismissed: '🚫 Ignorée', rejected: '🚫 Rejetée', blocked: '🛡️ Bloquée', executing: '⏳ En cours' };
                        statusLabel.textContent = statusMap[act.live_status] || act.live_status;
                        statusLabel.style.cssText = 'font-size:11px;font-weight:600;color:#64748b;white-space:nowrap;';
                        card.appendChild(statusLabel);
                    }

                    // Sprint 5.4: Coach = conseiller, Inbox = exécuteur.
                    // Plus de bouton "Appliquer" dans le chat — lien vers l'Inbox uniquement.
                    if (act.action_id && !isDone) {
                        var inboxCardLink = document.createElement('a');
                        inboxCardLink.href = <?php echo wp_json_encode( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>;
                        inboxCardLink.style.cssText = 'padding:6px 14px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid #6366f1;background:#eef2ff;color:#6366f1;white-space:nowrap;text-decoration:none;display:inline-flex;align-items:center;gap:4px;transition:background .15s,color .15s;';
                        inboxCardLink.textContent = 'Inbox \u2192';
                        inboxCardLink.title = 'Appliquer cette action dans l\x27Inbox avec aper\u00e7u et rollback';
                        inboxCardLink.onmouseenter = function() { this.style.background = '#6366f1'; this.style.color = '#fff'; };
                        inboxCardLink.onmouseleave = function() { this.style.background = '#eef2ff'; this.style.color = '#6366f1'; };
                        card.appendChild(inboxCardLink);
                    }

                    actionsWrap.appendChild(card);
                });

                var inboxLink = document.createElement('a');
                inboxLink.href = <?php echo wp_json_encode( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>;
                inboxLink.style.cssText = 'font-size:12px;font-weight:600;color:#fff;background:#6366f1;text-decoration:none;text-align:center;display:block;margin-top:8px;padding:8px 16px;border-radius:6px;transition:background .15s;';
                inboxLink.textContent = '✉️  Voir et appliquer dans l\x27Inbox';
                inboxLink.onmouseenter = function() { this.style.background = '#4f46e5'; };
                inboxLink.onmouseleave = function() { this.style.background = '#6366f1'; };
                actionsWrap.appendChild(inboxLink);

                // Insérer dans la bulle si fournie, sinon créer un nouveau bloc
                if (targetBubble) {
                    targetBubble.appendChild(actionsWrap);
                } else {
                    var actMsg = document.createElement('div');
                    actMsg.className = 'coach-msg assistant';
                    var actSpacer = document.createElement('div');
                    actSpacer.style.width = '36px';
                    actSpacer.style.flexShrink = '0';
                    var actBubble = document.createElement('div');
                    actBubble.className = 'coach-msg-bubble';
                    actBubble.appendChild(actionsWrap);
                    actMsg.appendChild(actSpacer);
                    actMsg.appendChild(actBubble);
                    container.appendChild(actMsg);
                }
            }

            /**
             * Sprint 5.4 : Render structured SEO Plan as a professional agency-style card.
             */
            function renderSEOPlanAfterBubble(seoPlan, container, insertBeforeEl) {
                if (!seoPlan || !seoPlan.phases || !seoPlan.phases.length) return;

                var priorityLabels = { critical: 'Critique', high: 'Haute', medium: 'Moyenne', low: 'Faible' };
                var inboxUrl = <?php echo wp_json_encode( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>;

                var wrap = document.createElement('div');
                wrap.className = 'hts-seo-plan';

                // ── Header (DS v5.7 — clean, no gradient) ──
                var header = document.createElement('div');
                header.className = 'hts-seo-plan-header';
                header.innerHTML =
                    '<div class="hts-seo-plan-title">' +
                        '<span>\uD83D\uDCCB</span>' +
                        htsE(seoPlan.title || 'Plan SEO') +
                    '</div>' +
                    (seoPlan.objective ? '<div class="hts-seo-plan-objective">\uD83C\uDFAF ' + htsE(seoPlan.objective) + '</div>' : '');
                wrap.appendChild(header);

                // ── Phases ──
                var phasesWrap = document.createElement('div');
                phasesWrap.className = 'hts-seo-plan-phases';

                seoPlan.phases.forEach(function(phase) {
                    var phaseEl = document.createElement('div');
                    phaseEl.className = 'hts-seo-plan-phase';

                    // Phase header
                    var phaseHeader = document.createElement('div');
                    phaseHeader.className = 'hts-seo-plan-phase-head';
                    phaseHeader.innerHTML =
                        '<span class="hts-seo-plan-phase-icon">' + htsE(phase.icon || '\uD83D\uDCCB') + '</span>' +
                        '<span class="hts-seo-plan-phase-name">' + htsE(phase.name) + '</span>' +
                        (phase.timeline ? '<span class="hts-seo-plan-phase-time">' + htsE(phase.timeline) + '</span>' : '');
                    phaseEl.appendChild(phaseHeader);

                    // Actions
                    phase.actions.forEach(function(act) {
                        var prio = act.priority || 'medium';
                        var pLabel = priorityLabels[prio] || prio;

                        var actEl = document.createElement('div');
                        actEl.className = 'hts-seo-plan-action';
                        actEl.innerHTML =
                            '<div class="hts-seo-plan-action-head">' +
                                '<span class="hts-seo-plan-action-dot ' + htsE(prio) + '"></span>' +
                                '<span class="hts-seo-plan-action-title">' + htsE(htsDecode(act.title)) + '</span>' +
                                '<span class="hts-seo-plan-badge ' + htsE(prio) + '">' + htsE(pLabel) + '</span>' +
                            '</div>' +
                            '<div class="hts-seo-plan-action-desc">' + htsE(act.task) + '</div>' +
                            '<div class="hts-seo-plan-action-meta">' +
                                (act.current ? '<span>Actuel</span> <span class="value">' + htsE(act.current) + '</span>' : '') +
                                (act.target ? '<span>\u2192</span> <span class="target">' + htsE(act.target) + '</span>' : '') +
                                (act.effort ? '<span>\u23F1</span> <span class="value">' + htsE(act.effort) + '</span>' : '') +
                            '</div>';
                        phaseEl.appendChild(actEl);
                    });

                    phasesWrap.appendChild(phaseEl);
                });
                wrap.appendChild(phasesWrap);

                // ── KPIs footer ──
                if (seoPlan.kpis && seoPlan.kpis.length > 0) {
                    var kpiBar = document.createElement('div');
                    kpiBar.className = 'hts-seo-plan-kpis';
                    seoPlan.kpis.forEach(function(kpi) {
                        kpiBar.innerHTML += '<div class="hts-seo-plan-kpi">' +
                            '<div class="hts-seo-plan-kpi-value">' + htsE(kpi.value) + '</div>' +
                            '<div class="hts-seo-plan-kpi-label">' + htsE(kpi.label) + '</div>' +
                        '</div>';
                    });
                    wrap.appendChild(kpiBar);
                }

                // ── CTA Inbox (DS button style) ──
                var ctaWrap = document.createElement('div');
                ctaWrap.className = 'hts-seo-plan-cta';
                var ctaBtn = document.createElement('button');
                ctaBtn.type = 'button';
                ctaBtn.className = 'hts-seo-plan-cta-btn';
                ctaBtn.textContent = '\u2709\uFE0F  Appliquer ce plan dans l\x27Inbox';
                ctaBtn.onclick = function() {
                    var btn = this;
                    btn.disabled = true;
                    btn.textContent = '\u23F3 Envoi en cours\u2026';
                    btn.style.opacity = '0.7';

                    var fd = new FormData();
                    fd.append('action', 'hts_coach_apply_seo_plan');
                    fd.append('nonce', NONCE);
                    fd.append('seo_plan', JSON.stringify(seoPlan));

                    fetch(ajaxurl, { method: 'POST', body: fd })
                        .then(function(r) { return r.json(); })
                        .then(function(res) {
                            if (res.success) {
                                btn.textContent = '\u2705 ' + res.data.message;
                                btn.style.background = 'var(--hts-success)';
                                btn.style.cursor = 'default';
                                var goLink = document.createElement('a');
                                goLink.href = inboxUrl;
                                goLink.style.cssText = 'display:inline-block;margin-top:8px;font-size:12px;color:var(--hts-geo);text-decoration:underline;';
                                goLink.textContent = 'Ouvrir l\x27Inbox \u2192';
                                btn.parentNode.appendChild(goLink);
                                if (res.data.manual && res.data.manual.length > 0) {
                                    var manualWrap = document.createElement('div');
                                    manualWrap.style.cssText = 'margin-top:12px;padding:12px 16px;background:var(--hts-caution-bg);border:1px solid var(--hts-caution);border-radius:var(--hts-radius-sm);';
                                    var manualTitle = document.createElement('div');
                                    manualTitle.style.cssText = 'font-size:12px;font-weight:700;color:var(--hts-text);margin-bottom:8px;';
                                    manualTitle.textContent = '\u270B ' + res.data.manual.length + ' action' + (res.data.manual.length > 1 ? 's' : '') + ' \u00e0 faire manuellement :';
                                    manualWrap.appendChild(manualTitle);
                                    res.data.manual.forEach(function(m) {
                                        var item = document.createElement('div');
                                        item.style.cssText = 'font-size:11px;color:var(--hts-text-2);padding:4px 0;border-bottom:1px solid var(--hts-border);';
                                        item.innerHTML = '<strong>' + htsE(m.title || m.type) + '</strong>' + (m.task ? ' \u2014 ' + htsE(m.task) : '');
                                        manualWrap.appendChild(item);
                                    });
                                    var manualNote = document.createElement('div');
                                    manualNote.style.cssText = 'font-size:10px;color:var(--hts-text-3);margin-top:6px;font-style:italic;';
                                    manualNote.textContent = 'Ces actions ne sont pas encore automatis\u00e9es. Appliquez-les manuellement dans l\x27\u00e9diteur WordPress.';
                                    manualWrap.appendChild(manualNote);
                                    btn.parentNode.appendChild(manualWrap);
                                }
                            } else {
                                btn.textContent = '\u274C ' + (res.data && res.data.message ? res.data.message : 'Erreur');
                                btn.style.background = 'var(--hts-danger)';
                                btn.disabled = false;
                                setTimeout(function() {
                                    btn.textContent = '\u2709\uFE0F  Appliquer ce plan dans l\x27Inbox';
                                    btn.style.background = '';
                                    btn.style.opacity = '1';
                                }, 3000);
                            }
                        })
                        .catch(function() {
                            btn.textContent = '\u274C Erreur r\u00e9seau';
                            btn.style.background = 'var(--hts-danger)';
                            btn.disabled = false;
                        });
                };
                ctaWrap.appendChild(ctaBtn);
                wrap.appendChild(ctaWrap);

                // ── Insert into DOM ──
                var planMsg = document.createElement('div');
                planMsg.className = 'coach-msg assistant';
                var planSpacer = document.createElement('div');
                planSpacer.style.width = '36px';
                planSpacer.style.flexShrink = '0';
                var planBubble = document.createElement('div');
                planBubble.className = 'coach-msg-bubble';
                planBubble.style.cssText = 'padding:0;background:transparent;border:none;max-width:100%;';
                planBubble.appendChild(wrap);
                planMsg.appendChild(planSpacer);
                planMsg.appendChild(planBubble);
                if (insertBeforeEl && insertBeforeEl.parentNode) {
                    insertBeforeEl.parentNode.insertBefore(planMsg, insertBeforeEl);
                } else {
                    container.appendChild(planMsg);
                }
            }

            /**
             * Sprint 4.1 : Render Agent Mode plan cards after a message bubble.
             * Shows the plan steps with Approve/Modify/Cancel buttons.
             */
            function renderPlanAfterBubble(plan, container, insertBeforeEl) {
                if (!plan || !plan.steps || !plan.steps.length) return;

                var planWrap = document.createElement('div');
                planWrap.className = 'coach-plan-card';
                planWrap.style.cssText = 'margin-top:12px;background:linear-gradient(135deg,#f5f3ff,#ede9fe);border:1px solid #c4b5fd;border-radius:12px;padding:16px;';

                // Header
                var header = document.createElement('div');
                header.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:12px;';
                header.innerHTML = '<span style="font-size:18px;">\uD83D\uDE80</span>' +
                    '<div><div style="font-size:13px;font-weight:700;color:#4c1d95;">Plan d\u0027exécution</div>' +
                    '<div style="font-size:11px;color:#6d28d9;">' + (plan.goal || '') + '</div></div>';
                planWrap.appendChild(header);

                // Steps
                var stepsWrap = document.createElement('div');
                stepsWrap.style.cssText = 'display:flex;flex-direction:column;gap:8px;';

                plan.steps.forEach(function(step, i) {
                    var stepEl = document.createElement('div');
                    var isReady = step.status === 'ready';
                    var isSent = step.status === 'sent';
                    var isDuplicate = step.status === 'duplicate';
                    var isError = step.status === 'error';
                    var isMerged = step.status === 'merged';
                    var isExecuted = isSent || isDuplicate || isError || isMerged;
                    var borderColor = (isSent || isMerged) ? '#16a34a' : isDuplicate ? '#f59e0b' : isError ? '#dc2626' : isReady ? '#a78bfa' : '#fbbf24';
                    var bgColor = (isSent || isMerged) ? '#f0fdf4' : isDuplicate ? '#fffbeb' : isError ? '#fef2f2' : '#fff';
                    stepEl.style.cssText = 'background:' + bgColor + ';border:1px solid ' + borderColor + ';border-radius:8px;padding:10px 14px;display:flex;align-items:flex-start;gap:10px;transition:all .15s;';
                    stepEl.className = 'coach-plan-step';
                    stepEl.setAttribute('data-step', step.step || (i + 1));

                    var num = document.createElement('div');
                    var numBg = (isSent || isMerged) ? '#16a34a' : isDuplicate ? '#f59e0b' : isError ? '#dc2626' : isReady ? '#7c3aed' : '#f59e0b';
                    num.style.cssText = 'width:24px;height:24px;border-radius:50%;background:' + numBg + ';color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;';
                    num.textContent = isExecuted ? '\u2713' : (step.step || (i + 1));
                    stepEl.appendChild(num);

                    var info = document.createElement('div');
                    info.style.cssText = 'flex:1;min-width:0;';
                    var labelHtml = '<div style="font-size:12px;font-weight:600;color:#1a1f36;">' + (step.label || step.action) + '</div>';
                    labelHtml += '<div style="font-size:11px;color:#64748b;margin-top:2px;">' + (step.description || '') + '</div>';
                    if (step.missing && step.missing.length > 0) {
                        labelHtml += '<div style="font-size:10px;color:#d97706;margin-top:4px;">\u26A0\uFE0F Param\u00e8tre' + (step.missing.length > 1 ? 's' : '') + ' manquant' + (step.missing.length > 1 ? 's' : '') + ' : ' + step.missing.join(', ') + '</div>';
                    }
                    info.innerHTML = labelHtml;
                    stepEl.appendChild(info);

                    // Per-step button + status dot
                    var stepBtnWrap = document.createElement('div');
                    stepBtnWrap.style.cssText = 'display:flex;align-items:center;gap:6px;flex-shrink:0;';

                    if (isExecuted) {
                        // Already executed — show status label
                        var statusLabel = document.createElement('span');
                        statusLabel.style.cssText = 'padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:default;border:1px solid ' + borderColor + ';white-space:nowrap;';
                        if (isSent) {
                            statusLabel.textContent = '\u2705 Envoy\u00e9';
                            statusLabel.style.background = '#dcfce7';
                            statusLabel.style.color = '#166534';
                        } else if (isMerged) {
                            statusLabel.textContent = '\u2705 Inclus \u00e9tape ' + (step.merged_with || '1');
                            statusLabel.style.background = '#dcfce7';
                            statusLabel.style.color = '#166534';
                            statusLabel.style.opacity = '0.7';
                        } else if (isDuplicate) {
                            statusLabel.textContent = '\u26A0 D\u00e9j\u00e0 en attente';
                            statusLabel.style.background = '#fef3c7';
                            statusLabel.style.color = '#92400e';
                        } else {
                            statusLabel.textContent = '\u274C Erreur';
                            statusLabel.style.background = '#fecaca';
                            statusLabel.style.color = '#991b1b';
                        }
                        stepBtnWrap.appendChild(statusLabel);
                    } else if (isReady) {
                        // Ready — show send button
                        var stepBtn = document.createElement('button');
                        stepBtn.type = 'button';
                        stepBtn.className = 'coach-step-send-btn';
                        stepBtn.style.cssText = 'padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid #a78bfa;background:#fff;color:#7c3aed;white-space:nowrap;transition:all .15s;';
                        stepBtn.textContent = '\u25B6 Envoyer dans l\x27Inbox';
                        stepBtn.onmouseenter = function() { this.style.background = '#f5f3ff'; };
                        stepBtn.onmouseleave = function() { this.style.background = '#fff'; };
                        (function(s, si, sel, sbtn) {
                            sbtn.onclick = function() {
                                if (sbtn.disabled) return;
                                sbtn.disabled = true;
                                sbtn.textContent = '\u23F3...';
                                sbtn.style.cursor = 'wait';
                                // Sprint 4.3 : Preview avant envoi dans l'Inbox
                                // On passe un onCancel callback pour rétablir le bouton si l'user ferme la modal
                                var resetBtn = function() {
                                    sbtn.disabled = false;
                                    sbtn.textContent = '\u25B6 Envoyer dans l\x27Inbox';
                                    sbtn.style.cursor = 'pointer';
                                };
                                coachPreviewStep(s, si, sel, resetBtn);
                            };
                        })(step, i, stepEl, stepBtn);
                        stepBtnWrap.appendChild(stepBtn);
                    }

                    var dot = document.createElement('span');
                    dot.className = 'coach-step-dot';
                    var dotColor = (isSent || isMerged) ? '#16a34a' : isDuplicate ? '#f59e0b' : isError ? '#dc2626' : '#22c55e';
                    dot.style.cssText = 'width:8px;height:8px;border-radius:50%;background:' + dotColor + ';flex-shrink:0;';
                    stepBtnWrap.appendChild(dot);

                    stepEl.appendChild(stepBtnWrap);

                    stepsWrap.appendChild(stepEl);
                });
                planWrap.appendChild(stepsWrap);

                // Estimate
                if (plan.estimate) {
                    var est = document.createElement('div');
                    est.style.cssText = 'font-size:11px;color:#6d28d9;margin-top:10px;text-align:right;';
                    est.textContent = '\u23F1 ' + plan.estimate;
                    planWrap.appendChild(est);
                }

                // Buttons : Approuver / Annuler — seulement si le plan n'est pas déjà exécuté
                var isExecuted = plan.status === 'executed';
                var btnRow = document.createElement('div');
                btnRow.style.cssText = 'display:flex;gap:8px;margin-top:12px;';

                if (isExecuted) {
                    var doneLabel = document.createElement('div');
                    doneLabel.style.cssText = 'flex:1;padding:8px 14px;border-radius:8px;font-size:12px;font-weight:700;text-align:center;background:#16a34a;color:#fff;cursor:default;';
                    doneLabel.textContent = '\u2705 Plan envoy\u00e9 dans l\x27Inbox';
                    btnRow.appendChild(doneLabel);
                } else {
                    var approveBtn = document.createElement('button');
                    approveBtn.type = 'button';
                    approveBtn.className = 'coach-plan-approve-btn';
                    approveBtn.style.cssText = 'flex:1;padding:8px 14px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;border:none;background:#7c3aed;color:#fff;transition:all .15s;';
                    approveBtn.textContent = '\u2705 Tout envoyer dans l\x27Inbox';
                    approveBtn.onmouseenter = function() { this.style.background = '#6d28d9'; };
                    approveBtn.onmouseleave = function() { this.style.background = '#7c3aed'; };
                    approveBtn.onclick = function() {
                        coachExecutePlan(plan, planWrap);
                    };
                    btnRow.appendChild(approveBtn);

                    var cancelBtn = document.createElement('button');
                    cancelBtn.type = 'button';
                    cancelBtn.style.cssText = 'padding:8px 14px;border-radius:8px;font-size:12px;cursor:pointer;border:1px solid #d1d5db;background:#fff;color:#64748b;';
                    cancelBtn.textContent = '\u274C';
                    cancelBtn.onclick = function() {
                        planWrap.style.transition = 'opacity .3s';
                        planWrap.style.opacity = '0';
                        setTimeout(function() { planWrap.remove(); }, 300);
                    };
                    btnRow.appendChild(cancelBtn);
                }

                planWrap.appendChild(btnRow);

                // Insérer comme nouveau bloc
                var planMsg = document.createElement('div');
                planMsg.className = 'coach-msg assistant';
                var planSpacer = document.createElement('div');
                planSpacer.style.width = '36px';
                planSpacer.style.flexShrink = '0';
                var planBubble = document.createElement('div');
                planBubble.className = 'coach-msg-bubble';
                planBubble.style.padding = '0';
                planBubble.style.background = 'transparent';
                planBubble.style.border = 'none';
                planBubble.appendChild(planWrap);
                planMsg.appendChild(planSpacer);
                planMsg.appendChild(planBubble);
                if (insertBeforeEl && insertBeforeEl.parentNode) {
                    insertBeforeEl.parentNode.insertBefore(planMsg, insertBeforeEl);
                } else {
                    container.appendChild(planMsg);
                }
            }

            /* ═══════════════════════════════════════════════
             *  SPRINT 4.2 — Preview + Execute functions
             * ═══════════════════════════════════════════════ */

            function safeUrl(u) { return (u && (u.indexOf('http') === 0 || u.charAt(0) === '/')) ? htsE(u) : '#'; }

            /**
             * Affiche une modal de preview pour une étape de plan.
             */
            function showStepPreview(stepData, stepIndex, onConfirm, onCancel) {
                var old = document.getElementById('coachPreviewModal');
                if (old) old.remove();

                var overlay = document.createElement('div');
                overlay.id = 'coachPreviewModal';
                overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:100000;display:flex;align-items:center;justify-content:center;';

                var modal = document.createElement('div');
                modal.style.cssText = 'background:#fff;border-radius:16px;padding:24px;max-width:520px;width:90%;max-height:80vh;overflow-y:auto;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);';

                // Header
                var headerHtml = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">' +
                    '<span style="font-size:24px;">\uD83D\uDD0D</span>' +
                    '<div><div style="font-size:15px;font-weight:700;color:#1a1f36;">' + (stepData.title || 'Aper\u00e7u') + '</div>' +
                    '<div style="font-size:12px;color:#64748b;">' + (stepData.target || '') + '</div></div></div>';
                modal.innerHTML = headerHtml;

                // Description
                if (stepData.description) {
                    modal.innerHTML += '<p style="font-size:13px;color:#374151;line-height:1.5;margin:0 0 16px;">' + htsE(stepData.description) + '</p>';
                }

                // Before/After diff
                if (stepData.before && stepData.after) {
                    var diffHtml = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">';
                    diffHtml += '<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px;">';
                    diffHtml += '<div style="font-size:11px;font-weight:600;color:#991b1b;margin-bottom:6px;">AVANT</div>';
                    for (var kb in stepData.before) {
                        if (stepData.before.hasOwnProperty(kb)) {
                            diffHtml += '<div style="font-size:12px;color:#7f1d1d;margin-bottom:4px;word-break:break-word;"><strong>' + kb.replace(/_/g, ' ') + '</strong> : ' + stepData.before[kb] + '</div>';
                        }
                    }
                    diffHtml += '</div>';
                    diffHtml += '<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px;">';
                    diffHtml += '<div style="font-size:11px;font-weight:600;color:#166534;margin-bottom:6px;">APR\u00c8S</div>';
                    for (var ka in stepData.after) {
                        if (stepData.after.hasOwnProperty(ka)) {
                            diffHtml += '<div style="font-size:12px;color:#14532d;margin-bottom:4px;word-break:break-word;"><strong>' + ka.replace(/_/g, ' ') + '</strong> : ' + stepData.after[ka] + '</div>';
                        }
                    }
                    diffHtml += '</div></div>';
                    modal.innerHTML += diffHtml;
                }

                // Warnings
                if (stepData.warnings && stepData.warnings.length > 0) {
                    var wHtml = '';
                    for (var wi = 0; wi < stepData.warnings.length; wi++) {
                        wHtml += '<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:10px;font-size:12px;color:#92400e;margin-bottom:8px;">\u26A0\uFE0F ' + stepData.warnings[wi] + '</div>';
                    }
                    modal.innerHTML += wHtml;
                }

                // Buttons
                var btnRow = document.createElement('div');
                btnRow.style.cssText = 'display:flex;gap:8px;margin-top:16px;';

                if (stepData.can_execute !== false) {
                    var confirmBtn = document.createElement('button');
                    confirmBtn.type = 'button';
                    confirmBtn.style.cssText = 'flex:1;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;border:none;background:#7c3aed;color:#fff;transition:all .15s;';
                    confirmBtn.textContent = '\u25B6 Envoyer dans l\x27Inbox';
                    confirmBtn.onmouseenter = function() { this.style.background = '#6d28d9'; };
                    confirmBtn.onmouseleave = function() { this.style.background = '#7c3aed'; };
                    confirmBtn.onclick = function() {
                        confirmBtn.disabled = true;
                        confirmBtn.textContent = '\u23F3 Envoi en cours...';
                        confirmBtn.style.cursor = 'wait';
                        onConfirm(function(success, message, resultData) {
                            if (success) {
                                var successHtml = '<div style="text-align:center;padding:20px;">' +
                                    '<div style="font-size:48px;margin-bottom:12px;">\u2705</div>' +
                                    '<div style="font-size:14px;font-weight:600;color:#166534;">' + (message || 'Envoy\u00e9 dans l\x27Inbox !') + '</div>';
                                if (stepData.edit_url || stepData.view_url) {
                                    successHtml += '<div style="display:flex;gap:12px;justify-content:center;margin-top:12px;">';
                                    if (stepData.edit_url) {
                                        successHtml += '<a href="' + safeUrl(stepData.edit_url) + '" target="_blank" style="font-size:12px;color:#7c3aed;text-decoration:underline;">\u270F\uFE0F Modifier la page</a>';
                                    }
                                    if (stepData.view_url) {
                                        successHtml += '<a href="' + safeUrl(stepData.view_url) + '" target="_blank" style="font-size:12px;color:#7c3aed;text-decoration:underline;">\uD83D\uDD17 Voir en live</a>';
                                    }
                                    successHtml += '</div>';
                                }
                                successHtml += '</div>';
                                modal.innerHTML = successHtml;
                                setTimeout(function() { overlay.remove(); }, 3000);
                            } else {
                                confirmBtn.disabled = false;
                                confirmBtn.textContent = '\u2705 Appliquer';
                                confirmBtn.style.cursor = 'pointer';
                                var errDiv = document.createElement('div');
                                errDiv.style.cssText = 'background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px;font-size:12px;color:#991b1b;margin-top:8px;';
                                errDiv.textContent = '\u274C ' + (message || 'Erreur');
                                btnRow.parentNode.insertBefore(errDiv, btnRow.nextSibling);
                            }
                        });
                    };
                    btnRow.appendChild(confirmBtn);
                } else {
                    var blockedBtn = document.createElement('button');
                    blockedBtn.type = 'button';
                    blockedBtn.disabled = true;
                    blockedBtn.style.cssText = 'flex:1;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:700;cursor:not-allowed;border:none;background:#d1d5db;color:#6b7280;';
                    blockedBtn.textContent = '\u26D4 Ex\u00e9cution bloqu\u00e9e';
                    btnRow.appendChild(blockedBtn);
                }

                var cancelBtn = document.createElement('button');
                cancelBtn.type = 'button';
                cancelBtn.style.cssText = 'padding:10px 16px;border-radius:8px;font-size:13px;cursor:pointer;border:1px solid #d1d5db;background:#fff;color:#64748b;transition:all .15s;';
                cancelBtn.textContent = 'Annuler';
                cancelBtn.onmouseenter = function() { this.style.background = '#f9fafb'; };
                cancelBtn.onmouseleave = function() { this.style.background = '#fff'; };
                cancelBtn.onclick = function() { overlay.remove(); if (typeof onCancel === 'function') onCancel(); };
                btnRow.appendChild(cancelBtn);

                modal.appendChild(btnRow);

                // Liens rapides : Modifier la page / Voir en live
                if (stepData.edit_url || stepData.view_url) {
                    var linksRow = document.createElement('div');
                    linksRow.style.cssText = 'display:flex;gap:12px;margin-top:12px;justify-content:center;';
                    if (stepData.edit_url) {
                        linksRow.innerHTML += '<a href="' + safeUrl(stepData.edit_url) + '" target="_blank" style="font-size:12px;color:#7c3aed;text-decoration:none;">\u270F\uFE0F Modifier la page</a>';
                    }
                    if (stepData.view_url) {
                        linksRow.innerHTML += '<a href="' + safeUrl(stepData.view_url) + '" target="_blank" style="font-size:12px;color:#7c3aed;text-decoration:none;">\uD83D\uDD17 Voir en live</a>';
                    }
                    modal.appendChild(linksRow);
                }

                overlay.appendChild(modal);
                overlay.onclick = function(e) { if (e.target === overlay) { overlay.remove(); if (typeof onCancel === 'function') onCancel(); } };
                document.body.appendChild(overlay);
            }

            /**
             * Appelle l'endpoint preview pour une étape, puis affiche la modal.
             */
            function coachPreviewStep(step, stepIndex, stepEl, onCancel) {
                var fd = new FormData();
                fd.append('action', 'hts_coach_preview_step');
                fd.append('nonce', '<?php echo esc_js( wp_create_nonce( "hts_admin_nonce" ) ); ?>');
                fd.append('session_id', currentSessionId || 0);
                fd.append('step_index', stepIndex);
                fd.append('step_action', step.action);

                if (step.params) {
                    for (var k in step.params) {
                        if (step.params.hasOwnProperty(k)) {
                            var v = step.params[k];
                            if (Array.isArray(v)) {
                                for (var ai = 0; ai < v.length; ai++) {
                                    fd.append('params[' + k + '][]', v[ai]);
                                }
                            } else {
                                fd.append('params[' + k + ']', v);
                            }
                        }
                    }
                }

                // Visual feedback
                var origOpacity = stepEl.style.opacity;
                stepEl.style.opacity = '0.6';

                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(r) { return r.json(); })
                    .then(function(json) {
                        stepEl.style.opacity = origOpacity || '1';
                        if (!json.success) {
                            if (typeof onCancel === 'function') onCancel();
                            alert(json.data ? json.data.message : 'Erreur lors du preview');
                            return;
                        }
                        showStepPreview(json.data, stepIndex, function(callback) {
                            coachExecuteStep(step, stepIndex, stepEl, callback);
                        }, onCancel);
                    })
                    .catch(function(err) {
                        stepEl.style.opacity = origOpacity || '1';
                        if (typeof onCancel === 'function') onCancel();
                        alert('Erreur r\u00e9seau : ' + err.message);
                    });
            }

            /**
             * Exécute une étape après confirmation dans la modal.
             */
            function coachExecuteStep(step, stepIndex, stepEl, callback) {
                var fd = new FormData();
                fd.append('action', 'hts_coach_execute_step');
                fd.append('nonce', '<?php echo esc_js( wp_create_nonce( "hts_admin_nonce" ) ); ?>');
                fd.append('session_id', currentSessionId || 0);
                fd.append('step_index', stepIndex);
                fd.append('step_action', step.action);

                if (step.params) {
                    for (var k in step.params) {
                        if (step.params.hasOwnProperty(k)) {
                            var v = step.params[k];
                            if (Array.isArray(v)) {
                                for (var ai = 0; ai < v.length; ai++) {
                                    fd.append('params[' + k + '][]', v[ai]);
                                }
                            } else {
                                fd.append('params[' + k + ']', v);
                            }
                        }
                    }
                }

                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(r) { return r.json(); })
                    .then(function(json) {
                        if (json.success) {
                            var status = json.data.status || 'proposed';
                            var isDuplicate = (status === 'duplicate');

                            // Update step card visuals
                            stepEl.style.borderColor = isDuplicate ? '#f59e0b' : '#16a34a';
                            stepEl.style.background = isDuplicate ? '#fffbeb' : '#f0fdf4';
                            stepEl.style.opacity = '1';
                            var numEl = stepEl.querySelector('div');
                            if (numEl && numEl.style.borderRadius === '50%') {
                                numEl.style.background = isDuplicate ? '#f59e0b' : '#16a34a';
                                numEl.textContent = '\u2713';
                            }
                            var stepBtns = stepEl.querySelectorAll('button.coach-step-send-btn');
                            for (var bi = 0; bi < stepBtns.length; bi++) {
                                stepBtns[bi].disabled = true;
                                if (isDuplicate) {
                                    stepBtns[bi].textContent = '\u26A0 D\u00e9j\u00e0 en attente';
                                    stepBtns[bi].style.background = '#fef3c7';
                                    stepBtns[bi].style.color = '#92400e';
                                    stepBtns[bi].style.borderColor = '#f59e0b';
                                } else {
                                    stepBtns[bi].textContent = '\u2705 Envoy\u00e9';
                                    stepBtns[bi].style.background = '#dcfce7';
                                    stepBtns[bi].style.color = '#166534';
                                    stepBtns[bi].style.borderColor = '#16a34a';
                                }
                                stepBtns[bi].style.cursor = 'default';
                            }
                            // Update dot
                            var dot = stepEl.querySelector('.coach-step-dot');
                            if (dot) dot.style.background = isDuplicate ? '#f59e0b' : '#16a34a';

                            callback(true, json.data.message);
                            // Sprint 4.3 : Toast feedback
                            var inboxUrl = json.data.inbox_url || '';
                            if (isDuplicate) {
                                coachShowToast('Déjà en attente', json.data.message || 'Cette action existe déjà dans l\x27Inbox.', inboxUrl, false);
                            } else {
                                coachShowToast('Envoyé dans l\x27Inbox', json.data.message || 'Action proposée.', inboxUrl, false);
                            }
                        } else {
                            callback(false, json.data ? json.data.message : 'Erreur');
                            // Sprint 4.3: Toast feedback for errors
                            coachShowToast('Erreur d\x27envoi', json.data ? json.data.message : 'Erreur inconnue', null, true);
                        }
                    })
                    .catch(function(err) {
                        callback(false, 'Erreur r\u00e9seau : ' + err.message);
                        coachShowToast('Erreur réseau', err.message, null, true);
                    });
            }

            /**
             * Exécute tout le plan (approuver et exécuter toutes les étapes ready).
             */
            function coachExecutePlan(plan, planWrap) {
                var approveBtn = planWrap.querySelector('.coach-plan-approve-btn');
                // Double-click guard
                if (approveBtn && approveBtn.dataset.executing === '1') return;


                var fd = new FormData();
                fd.append('action', 'hts_coach_execute_plan');
                fd.append('nonce', '<?php echo esc_js( wp_create_nonce( "hts_admin_nonce" ) ); ?>');
                fd.append('session_id', currentSessionId || 0);
                fd.append('plan', JSON.stringify(plan));

                if (approveBtn) {
                    approveBtn.disabled = true;
                    approveBtn.dataset.executing = '1';
                    approveBtn.textContent = '\u23F3 Ex\u00e9cution en cours...';
                    approveBtn.style.cursor = 'wait';
                }

                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(r) {
                        return r.json();
                    })
                    .then(function(json) {
                        if (json.success) {
                            var d = json.data;
                            var stepEls = planWrap.querySelectorAll('.coach-plan-step');
                            for (var ri = 0; ri < d.results.length; ri++) {
                                var res = d.results[ri];
                                var el = stepEls[res.step - 1];
                                if (!el) continue;
                                if (res.status === 'proposed') {
                                    el.style.borderColor = '#16a34a';
                                    el.style.background = '#f0fdf4';
                                    var numEl = el.querySelector('div');
                                    if (numEl && numEl.style.borderRadius === '50%') {
                                        numEl.style.background = '#16a34a';
                                        numEl.textContent = '\u2713';
                                    }
                                } else if (res.status === 'duplicate') {
                                    el.style.borderColor = '#f59e0b';
                                    el.style.background = '#fffbeb';
                                    var numEl = el.querySelector('div');
                                    if (numEl && numEl.style.borderRadius === '50%') {
                                        numEl.style.background = '#f59e0b';
                                        numEl.textContent = '\u2713';
                                    }
                                } else if (res.status === 'merged') {
                                    el.style.borderColor = '#16a34a';
                                    el.style.background = '#f0fdf4';
                                    el.style.opacity = '0.7';
                                    var numEl = el.querySelector('div');
                                    if (numEl && numEl.style.borderRadius === '50%') {
                                        numEl.style.background = '#16a34a';
                                        numEl.textContent = '\u2713';
                                    }
                                } else if (res.status === 'error') {
                                    el.style.borderColor = '#dc2626';
                                    el.style.background = '#fef2f2';
                                }
                                // Disable per-step buttons
                                var btns = el.querySelectorAll('button.coach-step-send-btn');
                                for (var bi = 0; bi < btns.length; bi++) {
                                    btns[bi].disabled = true;
                                    if (res.status === 'proposed') {
                                        btns[bi].textContent = '\u2705 Envoy\u00e9';
                                        btns[bi].style.borderColor = '#16a34a';
                                        btns[bi].style.color = '#166534';
                                        btns[bi].style.background = '#dcfce7';
                                    } else if (res.status === 'duplicate') {
                                        btns[bi].textContent = '\u26A0 D\u00e9j\u00e0 en attente';
                                        btns[bi].style.borderColor = '#f59e0b';
                                        btns[bi].style.color = '#92400e';
                                        btns[bi].style.background = '#fef3c7';
                                    } else if (res.status === 'merged') {
                                        btns[bi].textContent = '\u2705 Inclus \u00e9tape ' + (res.merged_with || '1');
                                        btns[bi].style.borderColor = '#16a34a';
                                        btns[bi].style.color = '#166534';
                                        btns[bi].style.background = '#dcfce7';
                                        btns[bi].style.opacity = '0.7';
                                    } else {
                                        btns[bi].textContent = '\u274C Erreur';
                                        btns[bi].style.borderColor = '#dc2626';
                                        btns[bi].style.color = '#991b1b';
                                        btns[bi].style.background = '#fecaca';
                                    }
                                    btns[bi].style.cursor = 'default';
                                }
                                // Update dot color
                                var dot = el.querySelector('.coach-step-dot');
                                if (dot) {
                                    if (res.status === 'proposed' || res.status === 'merged') dot.style.background = '#16a34a';
                                    else if (res.status === 'duplicate') dot.style.background = '#f59e0b';
                                    else dot.style.background = '#dc2626';
                                }
                            }
                            if (approveBtn) {
                                if (d.success > 0) {
                                    approveBtn.textContent = '\u2705 ' + d.message;
                                    approveBtn.style.background = '#16a34a';
                                    // Sprint 4.3 : Toast feedback for batch
                                    coachShowToast('Plan envoyé', d.message, '<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>', false);
                                } else {
                                    approveBtn.textContent = '\u26A0 ' + d.message;
                                    approveBtn.style.background = '#f59e0b';
                                    coachShowToast('Attention', d.message, '<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ) ); ?>', false);
                                }
                                approveBtn.style.cursor = 'default';
                            }
                        } else if (json.data && json.data.message === 'use_batch' && window.htsJobPoller) {
                            if (approveBtn) approveBtn.textContent = '\u23F3 Traitement par lots\u2026';
                            htsJobPoller.start({
                                initAction: json.data.batch_init, stepAction: json.data.batch_step,
                                nonce: '<?php echo esc_js( wp_create_nonce( "hts_admin_nonce" ) ); ?>',
                                params: { session_id: currentSessionId || 0, plan: JSON.stringify(plan) },
                                onProgress: function(d) { if (approveBtn) approveBtn.textContent = '\u23F3 ' + (d.message || 'En cours\u2026'); },
                                onComplete: function(d) { if (approveBtn) { approveBtn.textContent = '\u2705 Plan envoy\u00e9 !'; approveBtn.style.background = '#16a34a'; } coachShowToast('Plan envoy\u00e9', 'Les actions ont \u00e9t\u00e9 envoy\u00e9es dans l\u0027Inbox.', null, false); },
                                onError: function(m) { if (approveBtn) { approveBtn.disabled = false; approveBtn.textContent = '\u2705 Tout envoyer dans l\x27Inbox'; approveBtn.style.background = '#7c3aed'; } coachShowToast('Erreur', m, null, true); }
                            });
                        } else {
                            coachShowToast('Erreur d\x27envoi', (json.data && json.data.message) ? json.data.message : 'Erreur inconnue', null, true);
                            if (approveBtn) {
                                approveBtn.disabled = false;
                                approveBtn.dataset.executing = '0';
                                var errMsg = (json.data && json.data.message) ? json.data.message : 'Erreur inconnue';
                                approveBtn.textContent = '\u274C ' + errMsg;
                                approveBtn.style.background = '#dc2626';
                                approveBtn.style.cursor = 'pointer';
                                setTimeout(function() {
                                    approveBtn.textContent = '\u2705 Tout envoyer dans l\x27Inbox';
                                    approveBtn.style.background = '#7c3aed';
                                }, 5000);
                            }
                        }
                    })
                    .catch(function(err) {
                        coachShowToast('Erreur réseau', err.message, null, true);
                        if (approveBtn) {
                            approveBtn.disabled = false;
                            approveBtn.dataset.executing = '0';
                            approveBtn.textContent = '\u274C Erreur r\u00e9seau';
                            approveBtn.style.background = '#dc2626';
                            approveBtn.style.cursor = 'pointer';
                            setTimeout(function() {
                                approveBtn.textContent = '\u2705 Tout envoyer dans l\x27Inbox';
                                approveBtn.style.background = '#7c3aed';
                            }, 5000);
                        }
                    });
            }

            /* ═══════════════════════════════════════════════
             *  SPRINT 4.3 — Coach Toast (Inbox feedback)
             * ═══════════════════════════════════════════════ */

            window.coachShowToast = function(title, msg, link, isError) {
                var toast = document.getElementById('coachToast');
                if (!toast) return;
                document.getElementById('coachToastIcon').textContent = isError ? '\u274C' : '\u2705';
                document.getElementById('coachToastTitle').textContent = title;
                document.getElementById('coachToastMsg').textContent = msg;
                toast.style.borderLeftColor = isError ? '#dc2626' : '#16a34a';
                var linkEl = document.getElementById('coachToastLink');
                if (link) { linkEl.href = link; linkEl.style.display = 'inline'; } else { linkEl.style.display = 'none'; }
                toast.style.display = 'block';
                setTimeout(function() { toast.style.opacity = '1'; toast.style.transform = 'translateX(-50%) translateY(0)'; }, 10);
                clearTimeout(window._coachToastTimer);
                window._coachToastTimer = setTimeout(function(){ coachHideToast(); }, 6000);
            };
            window.coachHideToast = function() {
                var toast = document.getElementById('coachToast');
                if (!toast) return;
                toast.style.opacity = '0'; toast.style.transform = 'translateX(-50%) translateY(20px)';
                setTimeout(function(){ toast.style.display = 'none'; }, 300);
            };

            // ── Chart rendering ──
            function renderChart(canvas, chartData) {
                if (typeof Chart === 'undefined') return;

                var colors = {
                    primary: 'rgba(79,70,229,.85)',
                    primaryBg: 'rgba(79,70,229,.12)',
                    accent: 'rgba(124,58,237,.85)',
                    accentBg: 'rgba(124,58,237,.12)',
                    palette: [
                        'rgba(79,70,229,.8)', 'rgba(124,58,237,.8)', 'rgba(16,185,129,.8)',
                        'rgba(245,158,11,.8)', 'rgba(239,68,68,.8)', 'rgba(6,182,212,.8)',
                        'rgba(236,72,153,.8)', 'rgba(34,197,94,.8)'
                    ],
                    paletteBg: [
                        'rgba(79,70,229,.12)', 'rgba(124,58,237,.12)', 'rgba(16,185,129,.12)',
                        'rgba(245,158,11,.12)', 'rgba(239,68,68,.12)', 'rgba(6,182,212,.12)',
                        'rgba(236,72,153,.12)', 'rgba(34,197,94,.12)'
                    ]
                };

                var config = { type: chartData.type, data: {}, options: {} };

                if (chartData.type === 'radar') {
                    config.data = {
                        labels: chartData.labels,
                        datasets: [{
                            label: chartData.title || 'Score',
                            data: chartData.data,
                            backgroundColor: colors.primaryBg,
                            borderColor: colors.primary,
                            borderWidth: 2.5,
                            pointBackgroundColor: '#fff',
                            pointBorderColor: colors.primary,
                            pointBorderWidth: 2,
                            pointRadius: 5,
                            pointHoverRadius: 7
                        }]
                    };
                    if (chartData.data2) {
                        config.data.datasets.push({
                            label: 'Comparaison',
                            data: chartData.data2,
                            backgroundColor: colors.accentBg,
                            borderColor: colors.accent,
                            borderWidth: 2,
                            pointBackgroundColor: '#fff',
                            pointBorderColor: colors.accent,
                            pointBorderWidth: 2,
                            pointRadius: 4
                        });
                    }
                    config.options = {
                        scales: {
                            r: {
                                beginAtZero: true, max: 100,
                                grid: { color: 'rgba(0,0,0,.06)', circular: true },
                                angleLines: { color: 'rgba(0,0,0,.06)' },
                                ticks: { stepSize: 20, font: { size: 10 }, backdropColor: 'transparent', color: '#94a3b8' },
                                pointLabels: { font: { size: 11, weight: '600' }, color: '#334155' }
                            }
                        },
                        plugins: { legend: { display: !!chartData.data2, position: 'bottom', labels: { font: { size: 11 }, usePointStyle: true, padding: 16 } } }
                    };
                }
                else if (chartData.type === 'bar' || chartData.type === 'horizontalBar') {
                    var isHoriz = chartData.type === 'horizontalBar';
                    config.type = 'bar';
                    config.data = {
                        labels: chartData.labels,
                        datasets: [{
                            label: chartData.title || 'Score',
                            data: chartData.data,
                            backgroundColor: colors.palette.slice(0, chartData.data.length),
                            borderRadius: 8,
                            borderSkipped: false,
                            barThickness: isHoriz ? 24 : undefined,
                            maxBarThickness: 40
                        }]
                    };
                    config.options = {
                        indexAxis: isHoriz ? 'y' : 'x',
                        scales: {
                            x: { grid: { display: false }, ticks: { font: { size: 11, weight: '500' }, color: '#64748b' } },
                            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.04)' }, ticks: { font: { size: 11 }, color: '#64748b' } }
                        },
                        plugins: { legend: { display: false } }
                    };
                }
                else if (chartData.type === 'doughnut') {
                    config.data = {
                        labels: chartData.labels,
                        datasets: [{
                            data: chartData.data,
                            backgroundColor: colors.palette.slice(0, chartData.data.length),
                            borderWidth: 3,
                            borderColor: '#fff',
                            hoverOffset: 6
                        }]
                    };
                    config.options = {
                        cutout: '65%',
                        plugins: { legend: { position: 'bottom', labels: { font: { size: 11, weight: '500' }, padding: 14, usePointStyle: true, pointStyleWidth: 10 } } }
                    };
                }

                // Common options
                config.options.responsive = true;
                config.options.maintainAspectRatio = true;
                config.options.animation = { duration: 700, easing: 'easeOutQuart' };
                config.options.plugins = config.options.plugins || {};
                config.options.plugins.tooltip = {
                    backgroundColor: '#1e293b', titleFont: { size: 12, weight: '600' },
                    bodyFont: { size: 11 }, padding: 10, cornerRadius: 8, displayColors: true
                };

                new Chart(canvas.getContext('2d'), config);
            }

            // ── Typing indicator ──
            function showTyping() {
                var container = document.getElementById('coachMessages');
                var typing = document.createElement('div');
                typing.className = 'coach-typing';
                typing.id = 'coachTyping';
                typing.innerHTML = '<div class="coach-msg-avatar" style="background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;"></div><div class="coach-typing-dots"><div class="coach-typing-dot"></div><div class="coach-typing-dot"></div><div class="coach-typing-dot"></div></div>';
                container.appendChild(typing);
                scrollToBottom();
            }

            function hideTyping() {
                var t = document.getElementById('coachTyping');
                if (t) t.remove();
            }

            function scrollToBottom() {
                var c = document.getElementById('coachMessages');
                if (!c) return;
                // Sprint 4.4: smooth scroll during streaming, instant otherwise
                c.scrollTo({ top: c.scrollHeight, behavior: 'smooth' });
            }

            // ── Clear history ──
            window.coachClearHistory = function() {
                if (!confirm('Effacer tout l\'historique des conversations ?')) return;
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_clear&nonce=' + NONCE
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success) {
                        var msgs = document.getElementById('coachMessages');
                        msgs.innerHTML = '';
                        addMessage('assistant', 'Historique effacé. Posez-moi une nouvelle question !');
                        var sug = document.getElementById('coachSuggestions');
                        if (sug) sug.style.display = 'flex';
                    }
                });
            };

            // ── Upload GSC CSV ──
            window.coachUploadGsc = function(input) {
                if (!input.files || !input.files[0]) return;
                var fd = new FormData();
                fd.append('action', 'hts_coach_upload_gsc');
                fd.append('nonce', NONCE);
                fd.append('gsc_file', input.files[0]);

                addMessage('assistant', 'Import de **' + input.files[0].name + '** en cours...');

                fetch(ajaxurl, { method: 'POST', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success) {
                        var typeLabel = d.data.type === 'queries' ? 'requêtes' : 'pages';
                        addMessage('assistant', '**' + d.data.rows + ' ' + typeLabel + '** importées ! Vous pouvez importer un autre fichier (' + (d.data.type === 'queries' ? 'Pages' : 'Requêtes') + ') ou me poser vos questions.');
                        loadContext();
                    } else {
                        addMessage('assistant', '' + (d.data && d.data.message ? d.data.message : 'Erreur d\'import'));
                    }
                });
                input.value = '';
            };

            // ── Delete GSC CSV ──
            window.coachDeleteGsc = function() {
                if (!confirm('Supprimer les données CSV importées ?')) return;
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_delete_gsc&nonce=' + NONCE
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success) {
                        addMessage('assistant', 'Donnees CSV supprimees.');
                        loadContext();
                    }
                });
            };

            // ── Load dynamic startup suggestions + welcome proactif (Sprint 3.2) ──
            function loadStartupSuggestions() {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_startup&nonce=' + NONCE
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (!d.success) return;

                    // ── Sprint 3.2 : Render welcome proactif ──
                    var welcome = d.data.welcome;
                    var bubble = document.getElementById('coachWelcomeBubble');
                    if (bubble && welcome) {
                        var html = '';

                        // Greeting (supports **bold** markdown)
                        // Decode \u0027 and other unicode escapes that PHP may inject
                        function decodeUnicode(str) {
                            return str.replace(/\\u([0-9a-fA-F]{4})/g, function(m, g) {
                                return String.fromCharCode(parseInt(g, 16));
                            });
                        }
                        var greeting = htsE(decodeUnicode(welcome.greeting || '')).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n\n/g, '<br>');
                        html += '<div class="coach-welcome-greeting">' + greeting + '</div>';

                        // Alert cards
                        if (welcome.alerts && welcome.alerts.length > 0) {
                            html += '<div class="coach-welcome-alerts">';
                            welcome.alerts.forEach(function(alert) {
                                var sev = ['info','warning','success','error'].indexOf(alert.severity) !== -1 ? alert.severity : 'info';
                                html += '<div class="coach-welcome-alert ' + sev + '">';
                                html += '<span class="coach-welcome-alert-icon">' + htsE(alert.icon || '\u2139\uFE0F') + '</span>';
                                html += '<span class="coach-welcome-alert-text">' + htsE(decodeUnicode(alert.text || '')) + '</span>';
                                html += '</div>';
                            });
                            html += '</div>';
                        }

                        // Sprint 4.4: Multiple suggestion buttons (replaces single nudge)
                        var suggestions = welcome.suggestions || [];
                        if (!suggestions.length && welcome.nudge) {
                            suggestions = [decodeUnicode(welcome.nudge)];
                        }
                        if (suggestions.length > 0) {
                            html += '<div class="coach-welcome-suggestions">';
                            suggestions.forEach(function(s) {
                                var sText = htsE(decodeUnicode(s));
                                html += '<button type="button" class="coach-welcome-suggestion-btn" onclick="coachAsk(this.dataset.q);this.parentNode.remove();" data-q="' + sText.replace(/"/g, '&quot;') + '">';
                                html += sText;
                                html += '</button>';
                            });
                            html += '</div>';
                        }

                        bubble.innerHTML = html;
                    }

                    // ── Suggestions pills ──
                    if (!d.data.suggestions || !d.data.suggestions.length) return;
                    var container = document.getElementById('coachSuggestions');
                    if (!container) return;
                    container.innerHTML = '';
                    d.data.suggestions.forEach(function(s) {
                        var pill = document.createElement('div');
                        pill.className = 'coach-pill';
                        pill.textContent = (s.icon ? s.icon + ' ' : '') + s.text;
                        pill.onclick = function() { coachAsk(s.text); };
                        container.appendChild(pill);
                    });
                })
                .catch(function(){
                    // Fallback si le chargement échoue
                    var bubble = document.getElementById('coachWelcomeBubble');
                    if (bubble) {
                        bubble.innerHTML = '<strong>Bonjour ! Je suis votre Coach SEO.</strong><br>Posez-moi n\u0027importe quelle question sur votre référencement.';
                    }
                });

                // Sprint 4.4 : Dynamic placeholder rotation
                var coachPlaceholders = [
                    'Posez votre question SEO...',
                    'Ex: \u00ab Quels articles optimiser cette semaine ? \u00bb',
                    'Ex: \u00ab Crée la tâche FAQ pour ma page Assurance Vie \u00bb',
                    'Ex: \u00ab Quel est le score de mon cocon Immobilier ? \u00bb',
                    'Ex: \u00ab Optimise mes 5 pires metas \u00bb',
                    'Ex: \u00ab Fais-moi un plan d\u0027action SEO \u00bb'
                ];
                var coachInputEl = document.getElementById('coachInput');
                if (coachInputEl) {
                    coachInputEl.placeholder = coachPlaceholders[Math.floor(Math.random() * coachPlaceholders.length)];
                }
            }

            // ── Update per-provider sidebar counters ──
            function updateProviderCounters() {
                var t1 = document.getElementById('coachTokensT1');
                var t1r = document.getElementById('coachReqT1');
                var t2 = document.getElementById('coachTokensT2');
                var t2r = document.getElementById('coachReqT2');
                var t3 = document.getElementById('coachTokensT3');
                var t3r = document.getElementById('coachReqT3');
                if (t1) t1.textContent = formatNum(providerStats.t1.tokens);
                if (t1r) t1r.textContent = providerStats.t1.requests + ' req.';
                if (t2) t2.textContent = formatNum(providerStats.t2.tokens);
                if (t2r) t2r.textContent = providerStats.t2.requests + ' req.';
                if (t3) t3.textContent = formatNum(providerStats.t3.tokens);
                if (t3r) t3r.textContent = providerStats.t3.requests + ' req.';
            }

            // ═══ Sprint 1.4 : Fullscreen toggle ═══
            window.coachToggleFullscreen = function() {
                var wrap = document.querySelector('.coach-wrap');
                if (!wrap) return;
                wrap.classList.toggle('coach-fullscreen');
                // Escape to exit
                if (wrap.classList.contains('coach-fullscreen')) {
                    document.addEventListener('keydown', coachFullscreenEscape);
                } else {
                    document.removeEventListener('keydown', coachFullscreenEscape);
                }
            };
            function coachFullscreenEscape(e) {
                if (e.key === 'Escape') {
                    var wrap = document.querySelector('.coach-wrap');
                    if (wrap) wrap.classList.remove('coach-fullscreen');
                    document.removeEventListener('keydown', coachFullscreenEscape);
                }
            }

            // ═══ Sprint 1.4 : Sidebar toggle (desktop: collapse, tablet/mobile: drawer) ═══
            window.coachToggleSidebar = function() {
                var wrap = document.querySelector('.coach-wrap');
                var layout = document.querySelector('.coach-layout');
                var overlay = document.getElementById('coachOverlay');
                var closeRow = document.getElementById('coachSidebarCloseRow');
                var isNarrow = window.innerWidth <= 1200;

                if (isNarrow) {
                    // Drawer mode
                    var isOpen = wrap.classList.contains('coach-sidebar-open');
                    if (isOpen) {
                        coachCloseSidebar();
                    } else {
                        wrap.classList.add('coach-sidebar-open');
                        if (overlay) overlay.classList.add('active');
                        if (closeRow) closeRow.style.display = 'flex';
                    }
                } else {
                    // Desktop collapse/expand
                    layout.classList.toggle('coach-sidebar-collapsed');
                    var sidebar = document.getElementById('coachSidebar');
                    if (sidebar) {
                        sidebar.style.display = layout.classList.contains('coach-sidebar-collapsed') ? 'none' : '';
                    }
                }
            };

            window.coachCloseSidebar = function() {
                var wrap = document.querySelector('.coach-wrap');
                var overlay = document.getElementById('coachOverlay');
                var closeRow = document.getElementById('coachSidebarCloseRow');
                wrap.classList.remove('coach-sidebar-open');
                if (overlay) overlay.classList.remove('active');
                if (closeRow) closeRow.style.display = 'none';
            };

            // ═══ Sprint 4.8 : Analytics panel toggle + data loading ═══
            window.coachToggleAnalytics = function() {
                var panel = document.getElementById('coachAnalyticsPanel');
                if (!panel) return;
                var visible = panel.style.display !== 'none';
                panel.style.display = visible ? 'none' : 'block';
                if (!visible) loadCoachAnalytics();
            };

            window.loadCoachAnalytics = function() {
                var container = document.getElementById('coachAnalyticsContent');
                var period = document.getElementById('coachAnalyticsPeriod');
                if (!container) return;
                container.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:40px;">Chargement...</p>';

                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_analytics&nonce=' + NONCE + '&period=' + (period ? period.value : '30d')
                })
                .then(function(r){ return r.json(); })
                .then(function(resp) {
                    if (!resp.success || resp.data.empty) {
                        container.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:40px;">Aucune donnée analytics disponible. Les données s\u0027accumulent à chaque question posée au Coach.</p>';
                        return;
                    }
                    var d = resp.data;
                    var t = d.totals || {};
                    var satisfaction = d.satisfaction !== null ? d.satisfaction + '%' : '—';
                    var avgLatency = Math.round(t.avg_latency || 0);
                    var totalTokens = parseInt(t.total_tokens_in || 0) + parseInt(t.total_tokens_out || 0);
                    var costStr = d.estimated_cost ? ('$' + d.estimated_cost.toFixed(4)) : '$0';

                    // KPI cards
                    var html = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:24px;">';
                    var kpis = [
                        { label: 'Questions', value: t.total_requests || 0, icon: '💬' },
                        { label: 'Tokens', value: totalTokens.toLocaleString(), icon: '🔤' },
                        { label: 'Coût estimé', value: costStr, icon: '💰' },
                        { label: 'Latence moy.', value: avgLatency + 'ms', icon: '⚡' },
                        { label: 'Satisfaction', value: satisfaction, icon: '' },
                        { label: 'Graphiques', value: t.charts_generated || 0, icon: '📊' },
                        { label: 'Plans générés', value: t.plans_generated || 0, icon: '📋' },
                        { label: 'Erreurs', value: t.errors || 0, icon: '❌' },
                    ];
                    kpis.forEach(function(k){
                        html += '<div style="background:#fff;border:1px solid var(--coach-border);border-radius:10px;padding:14px 16px;">'
                            + '<div style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.5px;">' + k.icon + ' ' + k.label + '</div>'
                            + '<div style="font-size:22px;font-weight:700;color:var(--coach-text);margin-top:4px;">' + k.value + '</div>'
                            + '</div>';
                    });
                    html += '</div>';

                    // Intent breakdown
                    if (d.by_intent && d.by_intent.length > 0) {
                        html += '<div style="background:#fff;border:1px solid var(--coach-border);border-radius:10px;padding:16px;margin-bottom:16px;">';
                        html += '<h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Répartition par intent</h3>';
                        html += '<div style="display:flex;flex-wrap:wrap;gap:8px;">';
                        var intentColors = {simple:'#94a3b8',global:'#64748b',debug:'#f59e0b',memory:'#8b5cf6',plan:'#3b82f6',data_query:'#06b6d4',article:'#10b981',cluster:'#6366f1',gsc_analysis:'#ec4899',cannibalization:'#ef4444',action:'#f97316'};
                        d.by_intent.forEach(function(i){
                            var bg = intentColors[i.intent] || '#94a3b8';
                            html += '<div style="padding:6px 12px;border-radius:6px;background:' + bg + '15;border:1px solid ' + bg + '30;font-size:12px;">'
                                + '<span style="font-weight:600;color:' + bg + ';">' + i.intent + '</span>'
                                + ' <span style="color:#64748b;">' + i.cnt + 'x · ' + Math.round(i.avg_latency) + 'ms</span>'
                                + '</div>';
                        });
                        html += '</div></div>';
                    }

                    // Model breakdown
                    if (d.by_model && d.by_model.length > 0) {
                        html += '<div style="background:#fff;border:1px solid var(--coach-border);border-radius:10px;padding:16px;margin-bottom:16px;">';
                        html += '<h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Répartition par modèle</h3>';
                        html += '<table style="width:100%;font-size:12px;border-collapse:collapse;">';
                        html += '<tr style="border-bottom:1px solid #f1f5f9;"><th style="text-align:left;padding:6px 0;color:#94a3b8;font-weight:600;">Provider</th><th style="text-align:left;padding:6px 0;color:#94a3b8;font-weight:600;">Modèle</th><th style="text-align:right;padding:6px 0;color:#94a3b8;font-weight:600;">Requêtes</th><th style="text-align:right;padding:6px 0;color:#94a3b8;font-weight:600;">Tokens</th></tr>';
                        d.by_model.forEach(function(m){
                            html += '<tr style="border-bottom:1px solid #f8fafc;"><td style="padding:6px 0;">' + (m.provider || '?') + '</td><td style="padding:6px 0;font-family:monospace;font-size:11px;">' + (m.model || '?') + '</td><td style="text-align:right;padding:6px 0;">' + m.cnt + '</td><td style="text-align:right;padding:6px 0;">' + parseInt(m.total_tokens).toLocaleString() + '</td></tr>';
                        });
                        html += '</table></div>';
                    }

                    // Tools usage
                    if (d.tools_usage && Object.keys(d.tools_usage).length > 0) {
                        html += '<div style="background:#fff;border:1px solid var(--coach-border);border-radius:10px;padding:16px;margin-bottom:16px;">';
                        html += '<h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Outils utilisés (Dynamic Data Tools)</h3>';
                        html += '<div style="display:flex;flex-wrap:wrap;gap:8px;">';
                        Object.keys(d.tools_usage).forEach(function(tool){
                            html += '<div style="padding:6px 12px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;font-size:12px;">'
                                + '<span style="font-weight:600;color:#166534;">' + tool + '</span>'
                                + ' <span style="color:#64748b;">×' + d.tools_usage[tool] + '</span>'
                                + '</div>';
                        });
                        html += '</div></div>';
                    }

                    // Daily chart (using Chart.js already loaded)
                    if (d.daily && d.daily.length >= 1) {
                        html += '<div style="background:#fff;border:1px solid var(--coach-border);border-radius:10px;padding:16px;margin-bottom:16px;">';
                        html += '<h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Volume quotidien</h3>';
                        html += '<div style="position:relative;height:180px;"><canvas id="coachAnalyticsChart"></canvas></div>';
                        html += '</div>';
                    }

                    // Recent questions
                    if (d.top_questions && d.top_questions.length > 0) {
                        html += '<div style="background:#fff;border:1px solid var(--coach-border);border-radius:10px;padding:16px;margin-bottom:16px;">';
                        html += '<h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Questions récentes</h3>';
                        html += '<div style="max-height:300px;overflow-y:auto;">';
                        d.top_questions.forEach(function(q){
                            var fbIcon = q.feedback == 1 ? '+' : (q.feedback == -1 ? '-' : '');
                            var d2 = new Date(q.created_at);
                            var dateStr = d2.toLocaleDateString('fr-FR',{day:'numeric',month:'short'}) + ' ' + d2.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
                            html += '<div style="padding:6px 0;border-bottom:1px solid #f8fafc;display:flex;gap:8px;align-items:baseline;">'
                                + '<span style="font-size:10px;color:#94a3b8;white-space:nowrap;min-width:80px;">' + dateStr + '</span>'
                                + '<span style="font-size:10px;padding:2px 6px;border-radius:4px;background:#f1f5f9;color:#64748b;white-space:nowrap;">' + q.intent + '</span>'
                                + '<span style="font-size:12px;color:var(--coach-text);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + (q.question_preview || '—') + '</span>'
                                + '<span style="font-size:10px;color:#94a3b8;">' + q.latency_ms + 'ms</span>'
                                + (fbIcon ? '<span>' + fbIcon + '</span>' : '')
                                + '</div>';
                        });
                        html += '</div></div>';
                    }

                    container.innerHTML = html;

                    // Render daily chart if data available
                    if (d.daily && d.daily.length >= 1 && typeof Chart !== 'undefined') {
                        var ctx = document.getElementById('coachAnalyticsChart');
                        if (ctx) {
                            new Chart(ctx, {
                                type: 'bar',
                                data: {
                                    labels: d.daily.map(function(dd){ return dd.day.slice(5); }),
                                    datasets: [{
                                        label: 'Questions',
                                        data: d.daily.map(function(dd){ return dd.requests; }),
                                        backgroundColor: 'rgba(79,70,229,.6)',
                                        borderRadius: 4,
                                        maxBarThickness: 60,
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    plugins: { legend: { display: false } },
                                    scales: {
                                        y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { precision: 0, stepSize: 1 } },
                                        x: { grid: { display: false } }
                                    }
                                }
                            });
                        }
                    }
                })
                .catch(function(err){
                    container.innerHTML = '<p style="color:#ef4444;text-align:center;padding:40px;">Erreur : ' + err.message + '</p>';
                });
            };

            // ═══ Sprint 4.8 : Feedback (thumbs up/down) ═══
            window.sendCoachFeedback = function(value, activeBtn, otherBtn) {
                // Get current session_id from live state (not URL — may have changed)
                var sid = currentSessionId || URL_SESSION_ID || 0;
                if (!sid) return;

                activeBtn.dataset.active = '1';
                activeBtn.style.opacity = '1';
                activeBtn.style.background = value === 1 ? '#dcfce7' : '#fee2e2';
                activeBtn.style.borderColor = value === 1 ? '#86efac' : '#fca5a5';
                otherBtn.style.opacity = '.3';
                otherBtn.style.pointerEvents = 'none';
                activeBtn.style.pointerEvents = 'none';

                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_feedback&nonce=' + NONCE + '&session_id=' + sid + '&feedback=' + value
                }).catch(function(){});
            };

            // ═══ Sprint 1.3 : Load artifacts gallery ═══
            function loadArtifactsGallery() {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_artifacts&nonce=' + NONCE + '&limit=10'
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    var panel = document.getElementById('coachArtifactsGallery');
                    if (!panel) return;
                    if (!d.success || !d.data.artifacts || !d.data.artifacts.length) {
                        panel.textContent = 'Aucune analyse. Posez une question pour générer des graphiques.';
                        return;
                    }
                    var html = '';
                    d.data.artifacts.forEach(function(art) {
                        var icon = art.type === 'chart' ? '📊' : '📄';
                        var date = art.created_at ? new Date(art.created_at).toLocaleDateString('fr-FR', {day:'numeric', month:'short'}) : '';
                        html += '<div class="coach-gallery-item" onclick="coachShowArtifact(' + art.id + ')" data-artifact=\'' + JSON.stringify(art.chart || {}).replace(/'/g, '&#39;') + '\'>';
                        html += '<div class="coach-gallery-icon">' + icon + '</div>';
                        html += '<div class="coach-gallery-info">';
                        html += '<div class="coach-gallery-title">' + htsE(art.title || 'Analyse') + '</div>';
                        html += '<div class="coach-gallery-date">' + date + '</div>';
                        html += '</div></div>';
                    });
                    panel.innerHTML = html;
                })
                .catch(function(){
                    var panel = document.getElementById('coachArtifactsGallery');
                    if (panel) panel.textContent = 'Non disponible.';
                });
            }

            // ═══ Sprint 1.3 : Show artifact from gallery in chat ═══
            window.coachShowArtifact = function(artifactId) {
                // Find the gallery item and get chart data from data attribute
                var items = document.querySelectorAll('.coach-gallery-item');
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var chartStr = item.getAttribute('data-artifact');
                    if (!chartStr) continue;
                    try {
                        var chart = JSON.parse(chartStr);
                        if (chart && chart.type) {
                            addMessage('assistant', '*Analyse depuis la galerie :*', chart);
                            scrollToBottom();
                            // On mobile, close sidebar after selection
                            if (window.innerWidth <= 1200) coachCloseSidebar();
                            return;
                        }
                    } catch(e) {}
                }
            };

            // ── Boot ──
            loadContext();

            // v4.0 SSR : Hydrate server-rendered messages (markdown + plan cards)
            var ssrMessages = document.querySelectorAll('#coachMessages .coach-msg:not(#coachWelcomeMsg)');
            var hasSSR = ssrMessages.length > 0 && URL_SESSION_ID > 0;

            if (hasSSR) {
                // Render markdown in assistant bubbles
                if (typeof marked !== 'undefined') {
                    ssrMessages.forEach(function(el) {
                        if (el.classList.contains('assistant')) {
                            var bubble = el.querySelector('.coach-msg-bubble');
                            if (bubble && bubble.textContent.trim()) {
                                bubble.innerHTML = DOMPurify.sanitize(marked.parse(cleanForDisplay(bubble.textContent)));
                            }
                        }
                    });
                }
                // Hydrate plan cards
                var container = document.getElementById('coachMessages');
                document.querySelectorAll('.coach-ssr-plan').forEach(function(el) {
                    try {
                        var plan = JSON.parse(el.getAttribute('data-plan'));
                        if (plan && plan.steps && plan.steps.length > 0) {
                            renderPlanAfterBubble(plan, container, el);
                        }
                        el.remove();
                    } catch(e) {}
                });
                // Sprint 5.3: Hydrate action cards (AMÉL-2)
                document.querySelectorAll('.coach-ssr-actions').forEach(function(el) {
                    try {
                        var actions = JSON.parse(el.getAttribute('data-actions'));
                        if (actions && actions.length > 0) {
                            // Find the preceding bubble
                            var prevMsg = el.previousElementSibling;
                            var bubble = prevMsg ? prevMsg.querySelector('.coach-msg-bubble') : null;
                            renderActionsAfterBubble(actions, container, bubble);
                        }
                        el.remove();
                    } catch(e) {}
                });
                // Sprint 5.4: Hydrate SEO plan cards
                document.querySelectorAll('.coach-ssr-seo-plan').forEach(function(el) {
                    try {
                        var seoPlan = JSON.parse(el.getAttribute('data-seo-plan'));
                        if (seoPlan && seoPlan.phases && seoPlan.phases.length > 0) {
                            renderSEOPlanAfterBubble(seoPlan, container, el);
                        }
                        el.remove();
                    } catch(e) {}
                });
                // Sprint 5.3: Hydrate SSR skipped cards
                document.querySelectorAll('.coach-ssr-skipped').forEach(function(el) {
                    try {
                        var skippedList = JSON.parse(el.getAttribute('data-skipped'));
                        if (skippedList && skippedList.length > 0) {
                            var skipWrap = document.createElement('div');
                            skipWrap.style.cssText = 'margin-top:8px;display:flex;flex-direction:column;gap:4px;';
                            skippedList.forEach(function(s) {
                                var skipCard = document.createElement('div');
                                skipCard.style.cssText = 'background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px;opacity:.6;display:flex;align-items:center;gap:8px;';
                                var skipTitle = htsDecode(s.post_title || s.reason || s.type);
                                skipCard.innerHTML = '<span style="font-size:11px;color:#94a3b8;">\u23f8</span>' +
                                    '<span style="flex:1;font-size:12px;color:#64748b;">' + htsE(skipTitle) + '</span>' +
                                    '<span style="font-size:10px;padding:2px 6px;border-radius:4px;background:#fef3c7;color:#92400e;">' + htsE(s.skip_reason || 'D\u00e9j\u00e0 en attente') + '</span>';
                                skipWrap.appendChild(skipCard);
                            });
                            // Insert in place (before el) so cards appear after their message
                            el.parentNode.insertBefore(skipWrap, el);
                        }
                        el.remove();
                    } catch(e) {}
                });
                scrollToBottom();
            }

            if (!hasSSR) {
                if (URL_SESSION_ID > 0) {
                    // Session dans l'URL mais SSR vide → charger via AJAX (fallback)
                    // Retirer le welcome placeholder pour le remplacer par les messages AJAX
                    var welcomeEl = document.getElementById('coachWelcomeMsg');
                    if (welcomeEl) welcomeEl.style.display = 'none';
                    loadSessionMessages(URL_SESSION_ID, false);
                } else {
                    loadHistory();
                    loadStartupSuggestions();
                }
            } else {
                // SSR present: hide suggestions
                var sug = document.getElementById('coachSuggestions');
                if (sug) sug.style.display = 'none';
            }
            loadMemory();
            /* Defer non-critical sidebar data to idle (saves 3 AJAX on initial load) */
            var _idleCb = window.requestIdleCallback || function(fn) { setTimeout(fn, 2000); };
            _idleCb(function() { loadSessions(); });
            _idleCb(function() { loadSiteProfile(); });
            _idleCb(function() { loadArtifactsGallery(); });

            // Sprint 4.9: Prefill from ?question= URL param (floating widget redirect)
            var urlParams = new URLSearchParams(window.location.search);
            var prefillQ = urlParams.get('question');
            if (prefillQ && prefillQ.trim().length >= 3) {
                var inp = document.getElementById('coachInput');
                if (inp) {
                    inp.value = prefillQ.trim();
                    inp.style.height = 'auto';
                    inp.style.height = Math.min(inp.scrollHeight, 200) + 'px';
                    // Auto-send after a short delay to let history/context load
                    setTimeout(function() { coachSend(); }, 800);
                    // Clean URL to avoid re-send on refresh
                    urlParams.delete('question');
                    var qs = urlParams.toString();
                    var cleanUrl = window.location.pathname + (qs ? '?' + qs : '') + window.location.hash;
                    window.history.replaceState({}, '', cleanUrl);
                }
            }

            // ── Sprint 3.1 : Memory Dashboard — Toggle sections ──
            window.coachToggleSection = function(name) {
                var body = document.getElementById('coachBody' + name);
                var chev = document.getElementById('coachChevron' + name);
                if (!body) return;
                var isOpen = body.style.display !== 'none';
                body.style.display = isOpen ? 'none' : 'block';
                if (chev) chev.textContent = isOpen ? '▸' : '▾';
            };

            // ── Load memory facts — Sprint 3.1 : grouped by area with inline edit ──
            function loadMemory() {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_memory&nonce=' + NONCE
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    var panel = document.getElementById('coachMemoryFacts');
                    var count = document.getElementById('coachMemoryCount');
                    var total = document.getElementById('coachMemoryTotal');
                    if (!d.success || !d.data.facts || !d.data.facts.length) {
                        if (panel) panel.innerHTML = '<div style="color:#94a3b8;padding:4px 0;">Aucun fait mémorisé. Le Coach apprend au fil des conversations.</div>';
                        if (count) count.textContent = '0';
                        if (total) total.textContent = '0 fait';
                        return;
                    }

                    var facts = d.data.facts;
                    var n = facts.length;
                    if (count) count.textContent = n + ' fait' + (n > 1 ? 's' : '');
                    if (total) total.textContent = n + ' fait' + (n > 1 ? 's' : '');

                    // Grouper par area
                    var grouped = {};
                    facts.forEach(function(f) {
                        var area = f.area || 'general';
                        if (!grouped[area]) grouped[area] = [];
                        grouped[area].push(f);
                    });

                    var areaLabels = {
                        general: 'Général', seo: 'SEO', business: 'Business',
                        content: 'Contenu', technical: 'Technique', preferences: 'Préférences'
                    };

                    var html = '';
                    Object.keys(grouped).sort().forEach(function(area) {
                        var label = areaLabels[area] || area;
                        html += '<div class="coach-memory-area-group">';
                        html += '<div class="coach-memory-area-label">' + htsE(label) + ' (' + grouped[area].length + ')</div>';

                        grouped[area].forEach(function(f) {
                            var fid = f.id || f.memory_id || 0;
                            var src = f.source || 'extracted';
                            var srcBadge = '<span class="coach-memory-source-badge ' + src + '">' + (src === 'manual' ? 'Manuel' : 'Auto') + '</span>';
                            html += '<div class="coach-memory-fact" id="coachFact' + fid + '">';
                            html += '<div class="coach-memory-fact-text" onclick="coachEditFact(' + fid + ', this)" title="Cliquer pour modifier">';
                            html += htsE(f.content || f.fact_text || f.value || '') + ' ' + srcBadge;
                            html += '</div>';
                            html += '<div class="coach-memory-fact-actions">';
                            html += '<button type="button" class="coach-memory-fact-btn edit" onclick="coachEditFact(' + fid + ', this.parentNode.previousElementSibling)" title="Modifier">✏️</button>';
                            html += '<button type="button" class="coach-memory-fact-btn delete" onclick="coachDeleteMemory(' + fid + ', this)" title="Supprimer">✕</button>';
                            html += '</div></div>';
                        });

                        html += '</div>';
                    });

                    if (panel) panel.innerHTML = html;
                })
                .catch(function(){ 
                    var panel = document.getElementById('coachMemoryFacts');
                    if (panel) panel.textContent = 'Tables mémoire non initialisées.';
                });
            }

            // ── Sprint 3.1 : Inline edit fact ──
            window.coachEditFact = function(memoryId, textEl) {
                // Si déjà en édition, ne pas re-créer
                if (textEl.querySelector('.coach-memory-fact-input')) return;

                var currentText = textEl.textContent.replace(/\s*(Manuel|Auto)\s*$/, '').trim();
                var input = document.createElement('input');
                input.type = 'text';
                input.className = 'coach-memory-fact-input';
                input.value = currentText;

                textEl.innerHTML = '';
                textEl.appendChild(input);
                input.focus();
                input.select();

                function save() {
                    var newVal = input.value.trim();
                    if (!newVal || newVal.length < 3) {
                        loadMemory(); // revert
                        return;
                    }
                    if (newVal === currentText) {
                        loadMemory(); // no change
                        return;
                    }
                    input.disabled = true;
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=hts_coach_memory_update&nonce=' + NONCE + '&memory_id=' + memoryId + '&content=' + encodeURIComponent(newVal)
                    })
                    .then(function(r){ return r.json(); })
                    .then(function(d){ loadMemory(); });
                }

                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') { e.preventDefault(); save(); }
                    if (e.key === 'Escape') { loadMemory(); }
                });
                input.addEventListener('blur', save);
            };

            // ── Delete memory fact ──
            window.coachDeleteMemory = function(memoryId, btn) {
                if (!confirm('Supprimer ce fait mémorisé ?')) return;
                btn.disabled = true;
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_memory_delete&nonce=' + NONCE + '&memory_id=' + memoryId
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success) loadMemory();
                    else btn.disabled = false;
                });
            };

            // ── Sprint 3.1 : Add fact form ──
            window.coachAddFactForm = function() {
                var wrap = document.getElementById('coachAddFactFormWrap');
                wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
                if (wrap.style.display === 'block') {
                    document.getElementById('coachNewFactContent').focus();
                }
            };

            window.coachSaveFact = function() {
                var content  = document.getElementById('coachNewFactContent').value.trim();
                var area     = document.getElementById('coachNewFactArea').value;
                var category = document.getElementById('coachNewFactCategory').value.trim();

                if (!content || content.length < 3) {
                    alert('Le fait doit contenir au moins 3 caractères.');
                    return;
                }

                var body = 'action=hts_coach_memory_add&nonce=' + NONCE +
                    '&content=' + encodeURIComponent(content) +
                    '&area=' + encodeURIComponent(area);
                if (category) body += '&category=' + encodeURIComponent(category);

                fetch(ajaxurl, { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: body })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success) {
                        document.getElementById('coachNewFactContent').value = '';
                        document.getElementById('coachNewFactCategory').value = '';
                        document.getElementById('coachAddFactFormWrap').style.display = 'none';
                        loadMemory();
                    } else {
                        alert(d.data && d.data.message ? d.data.message : 'Erreur');
                    }
                });
            };

            // ── v4.0 : Current session tracking ──
            var currentSessionId = URL_SESSION_ID || 0;
            var viewingPastSession = false;

            // ── Load sessions ──
            function loadSessions() {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_sessions&nonce=' + NONCE + '&limit=20'
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    var panel = document.getElementById('coachSessionsList');
                    var count = document.getElementById('coachSessionCount');
                    if (!d.success || !d.data.sessions || !d.data.sessions.length) {
                        if (panel) panel.textContent = 'Aucune session.';
                        if (count) count.textContent = '0';
                        return;
                    }
                    if (d.data.active_id) currentSessionId = d.data.active_id;
                    if (count) count.textContent = d.data.sessions.length;
                    if (panel) {
                        var html = '';
                        // v4.0 : Bouton nouvelle conversation
                        html += '<button type="button" onclick="coachNewSession()" id="coachNewSessionBtn" style="width:100%;padding:6px 10px;margin-bottom:8px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid var(--coach-primary);background:var(--coach-primary);color:#fff;display:flex;align-items:center;gap:4px;justify-content:center;">';
                        html += '➕ Nouvelle conversation</button>';

                        d.data.sessions.forEach(function(s) {
                            var preview = s.preview || '';
                            var topics = (s.topics && s.topics.length) ? s.topics.join(', ') : '';
                            // Prefer preview (first user message) over topics
                            var displayText = preview || topics || 'conversation';
                            var date = s.session_start ? new Date(s.session_start).toLocaleDateString('fr-FR', {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}) : '';
                            var msgs = s.messages_count || 0;
                            var isActive = s.is_active || (parseInt(s.id) === currentSessionId);
                            var borderLeft = isActive ? 'border-left:3px solid var(--coach-primary);' : 'border-left:3px solid transparent;';
                            var bg = isActive ? 'background:rgba(99,102,241,0.06);' : '';

                            html += '<div class="coach-session-item" data-session-id="' + s.id + '" onclick="coachLoadSession(' + s.id + ')" ';
                            html += 'style="padding:6px 8px;margin-bottom:2px;border-radius:4px;cursor:pointer;' + borderLeft + bg + 'transition:background 0.15s;"';
                            html += ' onmouseenter="this.style.background=\'rgba(99,102,241,0.08)\'" onmouseleave="this.style.background=\'' + (isActive ? 'rgba(99,102,241,0.06)' : '') + '\'">';
                            html += '<div style="font-weight:' + (isActive ? '700' : '500') + ';color:var(--coach-text);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + htsE(displayText) + '">';
                            if (isActive) html += '● ';
                            if (s.has_plan) html += '\uD83D\uDE80 ';
                            html += htsE(displayText.length > 50 ? displayText.substring(0, 50) + '…' : displayText) + '</div>';
                            html += '<div style="color:#94a3b8;font-size:10px;">' + date + ' · ' + msgs + ' msg</div>';
                            html += '</div>';
                        });
                        panel.innerHTML = html;
                    }
                })
                .catch(function(){
                    var panel = document.getElementById('coachSessionsList');
                    if (panel) panel.textContent = 'Non disponible.';
                });
            }

            // ── v4.0 : Charger les messages d'une session passée ──
            window.coachLoadSession = function(sessionId) {
                if (parseInt(sessionId) === currentSessionId && !viewingPastSession) return;

                // Vider le chat
                var container = document.getElementById('coachMessages');
                if (container) container.innerHTML = '';

                currentSessionId = parseInt(sessionId);
                viewingPastSession = false; // On navigue vers cette session, elle devient la session courante

                // Update URL
                updateUrlSession(sessionId);

                // Activer l'input (plus de "lecture seule")
                var input = document.getElementById('coachInput');
                var sendBtn = document.getElementById('coachSendBtn');
                if (input) { input.disabled = false; input.placeholder = 'Posez votre question SEO...'; }
                if (sendBtn) sendBtn.disabled = false;

                var backBar = document.getElementById('coachBackToCurrentBar');
                if (backBar) backBar.style.display = 'none';

                // Charger les messages
                loadSessionMessages(sessionId, false);

                // Marquer la session active dans le sidebar
                document.querySelectorAll('.coach-session-item').forEach(function(el) {
                    var sid = el.getAttribute('data-session-id');
                    if (parseInt(sid) === parseInt(sessionId)) {
                        el.style.borderLeft = '3px solid var(--coach-primary)';
                        el.style.background = 'rgba(99,102,241,0.06)';
                    } else {
                        el.style.borderLeft = '3px solid transparent';
                        el.style.background = '';
                    }
                });
            };

            // ── v4.0 : Nouvelle conversation ──
            window.coachNewSession = function() {
                var btn = document.getElementById('coachNewSessionBtn');
                if (btn) { btn.disabled = true; btn.textContent = '...'; }

                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_new_session&nonce=' + NONCE
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success && d.data.session_id) {
                        currentSessionId = d.data.session_id;
                        viewingPastSession = false;

                        // v4.0 fix : update URL with new session
                        updateUrlSession(d.data.session_id);

                        // Sprint 3.2: restaurer le welcome proactif
                        var container = document.getElementById('coachMessages');
                        if (container) {
                            container.innerHTML = '<div class="coach-msg assistant" id="coachWelcomeMsg">'
                                + '<div class="coach-msg-avatar"></div>'
                                + '<div class="coach-msg-bubble" id="coachWelcomeBubble">'
                                + '<span class="coach-welcome-loading">Chargement...</span>'
                                + '</div></div>';
                        }

                        // Réactiver l'input
                        var input = document.getElementById('coachInput');
                        var sendBtn = document.getElementById('coachSendBtn');
                        if (input) { input.disabled = false; input.placeholder = 'Posez votre question SEO...'; }
                        if (sendBtn) sendBtn.disabled = false;

                        // Masquer la barre retour
                        var backBar = document.getElementById('coachBackToCurrentBar');
                        if (backBar) backBar.style.display = 'none';

                        // Show suggestions
                        var sug = document.getElementById('coachSuggestions');
                        if (sug) sug.style.display = '';

                        // Recharger les sessions dans le sidebar + welcome proactif
                        loadSessions();
                        loadStartupSuggestions();
                    }
                    if (btn) { btn.disabled = false; btn.textContent = '➕ Nouvelle conversation'; }
                })
                .catch(function(){
                    if (btn) { btn.disabled = false; btn.textContent = '➕ Nouvelle conversation'; }
                });
            };

            // ── v4.0 : Retour à la session active ──
            window.coachBackToCurrent = function() {
                viewingPastSession = false;
                var container = document.getElementById('coachMessages');
                if (container) {
                    // Sprint 3.2: recréer le placeholder welcome
                    container.innerHTML = '<div class="coach-msg assistant" id="coachWelcomeMsg">'
                        + '<div class="coach-msg-avatar"></div>'
                        + '<div class="coach-msg-bubble" id="coachWelcomeBubble">'
                        + '<span class="coach-welcome-loading">Chargement...</span>'
                        + '</div></div>';
                }

                var input = document.getElementById('coachInput');
                var sendBtn = document.getElementById('coachSendBtn');
                if (input) { input.disabled = false; input.placeholder = 'Posez votre question SEO...'; }
                if (sendBtn) sendBtn.disabled = false;

                var backBar = document.getElementById('coachBackToCurrentBar');
                if (backBar) backBar.style.display = 'none';

                // Show suggestions again
                var sug = document.getElementById('coachSuggestions');
                if (sug) sug.style.display = '';

                // Recharger l'historique de la session active + welcome proactif
                loadHistory();
                loadStartupSuggestions();
                loadSessions();
            };

            // ── Sprint 3.1 : Load site profile — inline editable fields ──
            var profileFields = ['niche', 'audience', 'tone', 'goals', 'strengths', 'weaknesses', 'competitors', 'theme'];
            var profileLabels = {
                niche: 'Niche', audience: 'Audience', tone: 'Ton', goals: 'Objectifs',
                strengths: 'Forces', weaknesses: 'Faiblesses', competitors: 'Concurrents', theme: 'Thème'
            };

            function loadSiteProfile() {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_site_profile&nonce=' + NONCE + '&method=GET'
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    var panel = document.getElementById('coachSiteProfile');
                    if (!panel) return;

                    var p = (d.success && d.data.profile) ? d.data.profile : {};
                    var html = '';

                    profileFields.forEach(function(key) {
                        var val = p[key] || '';
                        html += '<div class="coach-profile-field">';
                        html += '<span class="coach-profile-label">' + profileLabels[key] + '</span>';
                        html += '<span class="coach-profile-value" data-field="' + key + '" onclick="coachEditProfileField(this, \'' + key + '\')" title="Cliquer pour modifier">' + htsE(val) + '</span>';
                        html += '</div>';
                    });

                    html += '<div style="display:flex;gap:6px;margin-top:8px;">';
                    html += '<button type="button" onclick="coachGenerateProfile(this)" style="flex:1;padding:5px;font-size:10px;font-weight:600;color:var(--coach-primary);background:none;border:1px solid var(--coach-primary);border-radius:4px;cursor:pointer;">🤖 Auto-générer</button>';
                    html += '</div>';

                    panel.innerHTML = html;
                })
                .catch(function(){
                    var panel = document.getElementById('coachSiteProfile');
                    if (panel) panel.textContent = 'Non disponible.';
                });
            }

            // ── Sprint 3.1 : Inline edit profile field ──
            window.coachEditProfileField = function(el, field) {
                if (el.querySelector('.coach-profile-input')) return;

                var currentVal = el.textContent.trim();
                var input = document.createElement('input');
                input.type = 'text';
                input.className = 'coach-profile-input';
                input.value = currentVal;
                input.placeholder = profileLabels[field] || field;

                el.innerHTML = '';
                el.appendChild(input);
                input.focus();

                function save() {
                    var newVal = input.value.trim();
                    if (newVal === currentVal) {
                        loadSiteProfile();
                        return;
                    }
                    input.disabled = true;
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=hts_coach_site_profile&nonce=' + NONCE + '&method=POST&' + field + '=' + encodeURIComponent(newVal)
                    })
                    .then(function(r){ return r.json(); })
                    .then(function(d){ loadSiteProfile(); });
                }

                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') { e.preventDefault(); save(); }
                    if (e.key === 'Escape') { loadSiteProfile(); }
                });
                input.addEventListener('blur', save);
            };

            window.coachGenerateProfile = function(btn) {
                btn.disabled = true;
                btn.textContent = 'Génération...';
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_site_profile&nonce=' + NONCE + '&method=POST&auto_generate=1'
                })
                .then(function(r){ return r.json(); })
                .then(function(d){
                    loadSiteProfile();
                });
            };
        })();
        </script>
        <?php
    }

    /* S12: Migre vers admin/partials/health.php */
    // render_health_page() — removed: empty dead code (Phase 2C)

    /* S12: Migré vers admin/partials/health.php */
    // render_global_score_page() — removed: empty redirect dead code (Phase 2C)
    /* ══════════════════════════════════════════════════════════════════
     *  TAB NAVIGATION HELPER (v2.3.0)
     * ══════════════════════════════════════════════════════════════════ */

    private function render_tab_nav( $active = 'dashboard' ) {
        $base_url = admin_url( 'admin.php?page=hts-light-dashboard' );
        $inbox_count = 0;
        if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
            $s = HTS_Workflow_Engine::get_stats();
            $inbox_count = (int) ( $s['pending'] ?? 0 );
        }
        // Sprint 3.3: Coach notification badge from proactive alerts
        $coach_badge = 0;
        if ( class_exists( 'HTS_Coach' ) ) {
            $coach_badge = HTS_Coach::get_alert_count();
        }
        $tabs = array(
            'dashboard' => array( 'icon' => '', 'label' => 'Dashboard', 'url' => $base_url, 'badge' => 0 ),
            'inbox'     => array( 'icon' => '', 'label' => 'Inbox',     'url' => $base_url . '&tab=inbox', 'badge' => $inbox_count ),
            'coach'     => array( 'icon' => '', 'label' => 'Coach SEO', 'url' => $base_url . '&tab=coach', 'badge' => $coach_badge ),
            'health'    => array( 'icon' => '', 'label' => 'Santé',     'url' => $base_url . '&tab=health', 'badge' => 0 ),
        );
        ?>
        <div class="hts-cockpit-tabs">
        <?php foreach ( $tabs as $key => $tab ) : ?>
            <a href="<?php echo esc_url( $tab['url'] ); ?>" class="hts-cockpit-tab<?php echo esc_html( $key ) === $active ? ' active' : ''; ?>">
                <?php echo esc_html( $tab['icon'] ); ?> <?php echo esc_html( $tab['label'] ); ?><?php if ( $tab['badge'] > 0 ) : ?> <span class="hts-tab-badge<?php echo esc_attr( $key ) === 'coach' ? ' hts-tab-badge-coach' : ''; ?>"><?php echo (int) $tab['badge']; ?></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════════════════════════════
     *  INBOX PAGE (?tab=inbox) — v2.3.0 ⭐
     * ══════════════════════════════════════════════════════════════════ */

    private function render_inbox_page() {
        // Gate: Free = blur wall. Pro = preview (read-only). Ultra = full actions.
        if ( class_exists( 'HTS_Subscription' ) && HTS_Subscription::is_locked( 'inbox_view' ) ) {
            echo HTS_DS::page_open();
            echo HTS_DS::hero( 'Inbox', 'Vos actions SEO prioritaires' );
            echo HTS_DS::pro_wall( array(
                'title'    => 'Votre assistant SEO personnel',
                'desc'     => 'Recevez chaque semaine des recommandations personnalisées : titres à améliorer, liens à créer, contenus à mettre à jour. Appliquez en un clic.',
                'button'   => 'Débloquer — 99€/mois',
                'subtitle' => 'Plan Pro · Actions prioritaires · Suivi d\'impact',
            ) );
            echo HTS_DS::page_close();
            return;
        }
        // S14: delegate to standalone partial (same pattern as Dashboard S13)
        $partial = HTS__PLUGIN_DIR . 'admin/partials/inbox.php';
        if ( file_exists( $partial ) ) {
            include $partial;
            return;
        }
        echo '<p>Inbox partial introuvable.</p>';
    }

    /* ═══════════════════════════════════════════════════════════════
     *  SPRINT 4.9 — FLOATING COACH WIDGET
     *
     *  Chat bubble visible on every WP admin page (except the
     *  full Coach page).  Minimised by default.  Expands into a
     *  fixed-position 420 × 540 chat panel (resizable on desktop).
     *  Uses the same AJAX endpoints as the main Coach page.
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Render floating coach chat bubble + panel on all admin pages.
     * Skip rendering on the Coach page itself.
     *
     * @since 4.9
     */
    public function render_floating_coach() {
        // Don't render on the Coach page itself
        $page = sanitize_text_field( $_GET['page'] ?? '' );
        $tab  = sanitize_text_field( $_GET['tab'] ?? '' );
        if ( $page === 'hts-light-dashboard' && $tab === 'coach' ) {
            return;
        }

        // Check API key
        if ( ! class_exists( 'HTS_Coach' ) ) return;
        $has_key = ! empty( \HTS_Coach::get_api_key() ) || ! empty( \HTS_Coach::get_openai_api_key() );
        if ( ! $has_key ) return;

        $nonce     = wp_create_nonce( 'hts_admin_nonce' );
        $ajax_url  = admin_url( 'admin-ajax.php' );
        $coach_url = admin_url( 'admin.php?page=hts-light-dashboard&tab=coach' );
        ?>
        <!-- Sprint 4.9: Floating Coach — Support + Redirect -->
        <style id="hts-float-coach-css">
        .hts-float-bubble {
            position:fixed; bottom:28px; right:28px; z-index:99990;
            width:56px; height:56px; border-radius:50%;
            background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%);
            box-shadow:0 4px 20px rgba(79,70,229,.35); cursor:pointer;
            display:flex; align-items:center; justify-content:center;
            transition:transform .2s, box-shadow .2s; border:none;
        }
        .hts-float-bubble:hover { transform:scale(1.08); box-shadow:0 6px 28px rgba(79,70,229,.45); }
        .hts-float-bubble svg { width:26px; height:26px; fill:#fff; }
        .hts-float-bubble.hts-float-hidden { display:none; }

        .hts-float-panel {
            position:fixed; bottom:96px; right:28px; z-index:99991;
            width:380px; max-height:420px;
            background:#fff; border-radius:16px;
            box-shadow:0 12px 48px rgba(0,0,0,.18), 0 0 0 1px rgba(0,0,0,.06);
            display:none; flex-direction:column; overflow:hidden;
            font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        }
        .hts-float-panel.hts-float-open { display:flex; }
        @media (max-width:480px) {
            .hts-float-panel { width:calc(100vw - 16px); right:8px; bottom:80px; border-radius:12px; }
            .hts-float-bubble { bottom:16px; right:16px; width:50px; height:50px; }
        }

        .hts-float-header {
            background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%);
            padding:12px 16px; display:flex; align-items:center; justify-content:space-between; flex-shrink:0;
        }
        .hts-float-header-left { display:flex; align-items:center; gap:8px; }
        .hts-float-header-left span { font-size:18px; }
        .hts-float-header h3 { color:#fff; font-size:13px; font-weight:700; margin:0; }
        .hts-float-header-btn {
            width:26px; height:26px; border-radius:6px; border:none; cursor:pointer;
            background:rgba(255,255,255,.15); color:rgba(255,255,255,.9); font-size:12px;
            display:flex; align-items:center; justify-content:center;
        }
        .hts-float-header-btn:hover { background:rgba(255,255,255,.3); }

        .hts-float-body { padding:16px; display:flex; flex-direction:column; gap:10px; overflow-y:auto; max-height:300px; }
        .hts-float-msg { padding:10px 14px; border-radius:10px; font-size:13px; line-height:1.5; word-break:break-word; }
        .hts-float-msg.assistant { background:#f8fafc; border:1px solid #e2e8f0; color:#1e293b; }
        .hts-float-msg.user { background:linear-gradient(135deg,#4f46e5,#6366f1); color:#fff; align-self:flex-end; border-radius:10px 10px 4px 10px; max-width:85%; }
        .hts-float-msg.system { background:transparent; color:#94a3b8; font-size:11px; text-align:center; padding:4px; }
        .hts-float-redirect { display:inline-flex; align-items:center; gap:6px; margin-top:8px; padding:8px 14px; border-radius:8px; background:#4f46e5; color:#fff; text-decoration:none; font-size:12px; font-weight:600; transition:background .15s; }
        .hts-float-redirect:hover { background:#4338ca; color:#fff; }

        .hts-float-input-area { padding:10px 16px 14px; border-top:1px solid #e2e8f0; display:flex; gap:8px; align-items:flex-end; }
        .hts-float-input {
            flex:1; min-height:36px; max-height:80px; resize:none;
            border:1px solid #e2e8f0; border-radius:10px; padding:8px 12px;
            font-size:13px; font-family:inherit; line-height:1.4; outline:none;
        }
        .hts-float-input:focus { border-color:#4f46e5; }
        .hts-float-input::placeholder { color:#94a3b8; }
        .hts-float-send {
            width:34px; height:34px; border-radius:10px; border:none; cursor:pointer;
            background:#4f46e5; color:#fff; font-size:14px; flex-shrink:0;
            display:flex; align-items:center; justify-content:center;
        }
        .hts-float-send:hover { background:#4338ca; }
        </style>

        <!-- Bubble -->
        <button type="button" class="hts-float-bubble" id="htsFloatBubble" title="Coach SEO" onclick="htsFloatToggle()">
            <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.2L4 17.2V4h16v12z"/><path d="M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/></svg>
        </button>

        <!-- Panel -->
        <div class="hts-float-panel" id="htsFloatPanel">
            <div class="hts-float-header">
                <div class="hts-float-header-left">
                    <span>🤖</span>
                    <h3>Coach SEO</h3>
                </div>
                <button type="button" class="hts-float-header-btn" onclick="htsFloatToggle()" title="Fermer">✕</button>
            </div>
            <div class="hts-float-body" id="htsFloatBody">
                <div class="hts-float-msg system">Question rapide ? Je réponds ici.<br>Question complexe ? Je t&#39;envoie vers le Coach complet.</div>
            </div>
            <div class="hts-float-input-area">
                <textarea class="hts-float-input" id="htsFloatInput" placeholder="Ta question SEO..." rows="1"></textarea>
                <button type="button" class="hts-float-send" id="htsFloatSend" onclick="htsFloatAsk()">➤</button>
            </div>
        </div>

        <script>
        (function(){
            var NONCE     = <?php echo wp_json_encode( $nonce ); ?>;
            var AJAX_URL  = <?php echo wp_json_encode( $ajax_url ); ?>;
            var COACH_URL = <?php echo wp_json_encode( $coach_url ); ?>;
            var panel  = document.getElementById('htsFloatPanel');
            var bubble = document.getElementById('htsFloatBubble');
            var body   = document.getElementById('htsFloatBody');
            var input  = document.getElementById('htsFloatInput');
            var busy   = false;

            window.htsFloatToggle = function() {
                var open = panel.classList.toggle('hts-float-open');
                bubble.classList.toggle('hts-float-hidden', open);
                if (open) input.focus();
            };

            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); htsFloatAsk(); }
            });
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && panel.classList.contains('hts-float-open')) htsFloatToggle();
            });

            // Simple intent detection (JS-side) — mirrors PHP detect_intent light version
            function isSimpleQuestion(q) {
                q = q.toLowerCase().trim();
                // Complex keywords → redirect to full Coach
                var complexPatterns = [
                    /\bplan\b/, /\bplanning\b/, /\broadmap\b/, /\bstrat[eé]gie\b/,
                    /\banalyse\b/, /\baudit\b/, /\bscore\b/,
                    /\bstats\b/, /\bgsc\b/, /\bsearch console\b/, /\bclics\b/, /\bimpressions?\b/, /\bpositions?\b/,
                    /\bcocons?\b/, /\bcluster\b/, /\bmaillage\b/, /\bcannibal/, /\borpheline\b/,
                    /\boptimise/, /\bcorrige/, /\bgén[eè]re/, /\bcr[eé]{1,2}e?\b/, /\blance\b/,
                    /\bpublie/, /\br[eé]dige/, /\bprogramme\b/, /\bplanifie/, /\brafra[iî]chis/,
                    /\binbox\b/, /\bactions?\b/, /\bt[aâ]che/, /\btodo\b/,
                    /\bfais[\s-](?:moi|le)\b/,
                    /\bmeilleur(?:s|e)?\s+article/, /\bpire(?:s)?\s+article/, /\bmes\s+articles/, /\bmes\s+pages/,
                    /\bgraphique\b/, /\bradar\b/, /\bliste\s+des\b/
                ];
                for (var i = 0; i < complexPatterns.length; i++) {
                    if (complexPatterns[i].test(q)) return false;
                }
                return true;
            }

            function addMsg(text, role) {
                var div = document.createElement('div');
                div.className = 'hts-float-msg ' + role;
                if (role === 'user') {
                    div.textContent = text;
                } else {
                    div.innerHTML = text;
                }
                body.appendChild(div);
                body.scrollTop = body.scrollHeight;
                return div;
            }

            function addRedirect(question) {
                var div = document.createElement('div');
                div.className = 'hts-float-msg assistant';
                var url = COACH_URL + '&question=' + encodeURIComponent(question);
                div.innerHTML = 'Cette question nécessite une analyse complète.'
                    + '<br><a href="' + url + '" class="hts-float-redirect">Ouvrir dans le Coach complet →</a>';
                body.appendChild(div);
                body.scrollTop = body.scrollHeight;
            }

            window.htsFloatAsk = function() {
                var q = input.value.trim();
                if (!q || busy) return;

                addMsg(q, 'user');
                input.value = '';

                // Complex → redirect
                if (!isSimpleQuestion(q)) {
                    addRedirect(q);
                    return;
                }

                // Simple → answer inline via non-stream AJAX
                busy = true;
                var loading = addMsg('...', 'assistant');

                fetch(AJAX_URL, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hts_coach_ask&nonce=' + encodeURIComponent(NONCE)
                        + '&question=' + encodeURIComponent(q)
                        + '&post_id=0'
                })
                .then(function(r) { return r.json(); })
                .then(function(resp) {
                    busy = false;
                    if (resp.success && resp.data && resp.data.text) {
                        // Simple markdown: bold, italic, newlines
                        var t = resp.data.text;
                        var d = document.createElement('div'); d.textContent = t; t = d.innerHTML;
                        t = t.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
                        t = t.replace(/\*(.+?)\*/g, '<em>$1</em>');
                        t = t.replace(/\n/g, '<br>');
                        loading.innerHTML = t;
                    } else {
                        loading.innerHTML = '' + (resp.data && resp.data.message ? resp.data.message : 'Erreur. Réessaie.');
                    }
                    body.scrollTop = body.scrollHeight;
                })
                .catch(function() {
                    busy = false;
                    loading.innerHTML = 'Connexion perdue. Réessaie.';
                });
            };
        })();
        </script>
        <?php
    }
}
