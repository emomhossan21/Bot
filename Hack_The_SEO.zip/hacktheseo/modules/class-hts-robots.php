<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Robots Meta / Indexation Control v4
 *
 * PHILOSOPHY: Noindex is DANGEROUS. The module NEVER suggests noindex
 * on content pages. Only explicit utility pages get noindex.
 *
 * SUGGESTION LOGIC:
 * Content page thin → Réécrire (always)
 * Content page orphan → Intégrer au cocon (always)
 * Content page 0 clic → Optimiser metas (always)
 * Content page not GEO → Enrichir GEO (always)
 * Utility page (CGV, merci, panier...) → Noindex
 *
 * SAFETY:
 *   is_utility_page() = WHITELIST of slugs. Only these get noindex.
 *   is_protected()    = BLACKLIST. These can NEVER be noindexed even manually.
 *   inject_robots_meta() = FINAL NET. Strips noindex from protected at render.
 *
 * For the orchestrator: process ALL suggestions safely. No noindex
 * will ever be suggested on a content page.
 *
 * @since 3.0.0
 */

class HTS_Robots {

    const META_KEY         = '_hts_robots_meta';
    const OPTION_GLOBAL    = 'hts_robots_global';
    const OPTION_ROBOTSTXT = 'hts_robotstxt_custom';

    /**
     * Explicit utility slugs — the ONLY pages that can get noindex suggestion.
     * This is a closed whitelist. Nothing else gets noindex.
     */
    const UTILITY_SLUGS = array(
        // Legal
        'mentions-legales', 'politique-de-confidentialite', 'cgv', 'cgu',
        'legal-notice', 'privacy-policy', 'terms-and-conditions', 'terms-of-service',
        'cookie-policy', 'politique-cookies', 'rgpd', 'gdpr',
        // Transactional / functional
        'panier', 'cart', 'checkout', 'commande', 'order',
        'mon-compte', 'my-account', 'login', 'connexion', 'register', 'inscription',
        // Post-conversion
        'thank-you', 'merci', 'confirmation', 'remerciement',
        'confirmation-commande', 'order-confirmation',
        // System
        'wp-login', 'wp-admin', 'sitemap', 'feed',
        'sample-page', 'exemple-de-page', 'test',
    );

    public function init() {
        // ── Cockpit guard: if module is OFF, skip frontend injection ──
        if ( get_option( 'hts_module_robots', '1' ) !== '1' ) return;

        // HTS always handles robots meta (competitor must be deactivated via Migration Wizard)
        add_action( 'wp_head', array( $this, 'inject_robots_meta' ), 5 );

        // ── robots.txt virtual editor — intercepts WP's do_robots() output ──
        $custom = get_option( self::OPTION_ROBOTSTXT, '' );
        if ( ! empty( $custom ) ) {
            add_filter( 'robots_txt', array( $this, 'filter_robots_txt' ), 999, 2 );
        }

        // Metabox, AJAX, suggestions: always active (internal features, no frontend output)
        add_action( 'add_meta_boxes', array( $this, 'register_metabox' ) );
        add_action( 'save_post', array( $this, 'save_metabox' ), 10, 2 );
        add_action( 'init', array( $this, 'register_post_meta' ) );
        add_action( 'wp_ajax_hts_robots_save_global',  array( $this, 'ajax_save_global' ) );
        add_action( 'wp_ajax_hts_robots_get_data',     array( $this, 'ajax_get_data' ) );
        add_action( 'wp_ajax_hts_robots_batch_action', array( $this, 'ajax_batch_action' ) );
        add_action( 'wp_ajax_hts_robots_toggle_page',  array( $this, 'ajax_toggle_page' ) );
        add_action( 'wp_ajax_hts_robotstxt_preview',   array( $this, 'ajax_robotstxt_preview' ) );
        add_action( 'wp_ajax_hts_robotstxt_defaults',  array( $this, 'ajax_robotstxt_defaults' ) );
    }

    /* ══════════════════════════════════════════════
     *  is_utility_page() — Whitelist approach
     *  Returns slug match or false.
     *  ONLY these pages can receive a noindex suggestion.
     * ══════════════════════════════════════════════ */

    public static function is_utility_page( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return false;
        $slug = $post->post_name;
        foreach ( self::UTILITY_SLUGS as $pat ) {
            if ( $slug === $pat || strpos( $slug, $pat ) === 0 ) return $pat;
        }
        return false;
    }

    /* ══════════════════════════════════════════════
     *  is_protected() — Hard lock, checked at every write
     *  These pages can NEVER be noindexed, not even manually.
     * ══════════════════════════════════════════════ */

    public static function is_protected( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( false, '' );

        $pid = (int) $post_id;

        // Homepage
        if ( (int) get_option( 'page_on_front' ) === $pid )
            return array( true, 'Page d\'accueil' );

        // Blog page
        if ( (int) get_option( 'page_for_posts' ) === $pid )
            return array( true, 'Page de blog' );

        // WooCommerce pages
        if ( function_exists( 'wc_get_page_id' ) ) {
            $wc = array( 'shop'=>'Boutique','cart'=>'Panier','checkout'=>'Paiement','myaccount'=>'Mon compte' );
            foreach ( $wc as $k => $l ) {
                if ( (int) wc_get_page_id( $k ) === $pid ) return array( true, "WooCommerce ({$l})" );
            }
        }

        // Pages in menu
        foreach ( get_nav_menu_locations() as $loc => $mid ) {
            if ( ! $mid ) continue;
            $items = wp_get_nav_menu_items( $mid );
            if ( is_array( $items ) ) {
                foreach ( $items as $item ) {
                    if ( (int) $item->object_id === $pid ) return array( true, 'Dans le menu de navigation' );
                }
            }
        }

        // Parent pages
        if ( $post->post_type === 'page' ) {
            global $wpdb;
            $ch = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_parent=%d AND post_status='publish'", $pid
            ) );
            if ( $ch > 0 ) return array( true, "Page parent ({$ch} enfants)" );
        }

        // Structural slugs
        $struct = array( 'blog','articles','actualites','news','ressources','resources','services','produits','products','contact','a-propos','about','about-us','qui-sommes-nous','equipe','team','portfolio','projets','projects','formations','tarifs','pricing','faq','aide','help','support','categories','category' );
        if ( in_array( $post->post_name, $struct, true ) )
            return array( true, "Page structurelle (/{$post->post_name}/)" );

        // High traffic
        $clicks = (int) get_post_meta( $pid, '_hts_gsc_clicks', true );
        if ( $clicks >= 50 ) return array( true, "Fort trafic ({$clicks} clics)" );

        // Cocon pillar
        if ( class_exists( 'HTS_Cocon' ) ) {
            $data = ( new HTS_Cocon() )->get_cocon_data();
            foreach ( $data['clusters'] ?? array() as $cn => $cl ) {
                if ( (int) ( $cl['pillar_id'] ?? 0 ) === $pid ) return array( true, "Pilier cocon \"{$cn}\"" );
            }
        }

        return array( false, '' );
    }

    /* ══════════════════════════════════════════════
     *  wp_head — FINAL SAFETY NET
     * ══════════════════════════════════════════════ */

    public function inject_robots_meta() {
        if ( is_admin() ) return;

        // ── Archive global rules (category, tag, author, date, search, pagination) ──
        if ( ! is_singular() ) {
            $g = get_option( self::OPTION_GLOBAL, array() );
            $dirs = array();

            if ( is_category() && ! empty( $g['category'] ) )     $dirs = (array) $g['category'];
            elseif ( is_tag() && ! empty( $g['post_tag'] ) )      $dirs = (array) $g['post_tag'];
            elseif ( is_author() && ! empty( $g['author'] ) )     $dirs = (array) $g['author'];
            elseif ( is_date() && ! empty( $g['date'] ) )         $dirs = (array) $g['date'];
            elseif ( is_search() && ! empty( $g['search'] ) )     $dirs = (array) $g['search'];

            // Pagination (page/2+) — applies on top of other archive types
            if ( is_paged() && ! empty( $g['pagination'] ) ) {
                $dirs = array_unique( array_merge( $dirs, (array) $g['pagination'] ) );
            }

            if ( ! empty( $dirs ) ) {
                echo '<meta name="robots" content="' . esc_attr( implode( ', ', $dirs ) ) . '">' . "\n";
            }
            return;
        }

        // ── Singular posts/pages ──
        $post_id = get_the_ID();
        if ( ! $post_id ) return;

        $directives = $this->get_effective_robots( $post_id );

        // FINAL NET: strip noindex from protected
        list( $prot, ) = self::is_protected( $post_id );
        if ( $prot && in_array( 'noindex', $directives, true ) ) {
            $directives = array_diff( $directives, array( 'noindex' ) );
            // Auto-clean bad data (normalize to array format)
            $raw = get_post_meta( $post_id, self::META_KEY, true );
            $m = self::normalize_robots_meta( $raw );
            if ( in_array( 'noindex', $m, true ) ) {
                $m = array_values( array_diff( $m, array( 'noindex' ) ) );
                empty( $m ) ? delete_post_meta( $post_id, self::META_KEY ) : update_post_meta( $post_id, self::META_KEY, $m );
            }
        }

        if ( ! empty( $directives ) ) {
            // Preserve Google Discover eligibility: add max-image-preview:large
            // unless the page is noindex (no point advertising images on hidden pages)
            if ( ! in_array( 'noindex', $directives, true ) ) {
                $directives[] = 'max-image-preview:large';
            }
            // Disable WP 5.7+ wp_robots entirely — HTS handles all robots directives
            remove_all_filters( 'wp_robots' );
            add_filter( 'wp_robots', '__return_empty_array', 9999 );
            echo '<meta name="robots" content="' . esc_attr( implode( ', ', $directives ) ) . '">' . "\n";
        } else {
            // No HTS directives → still ensure max-image-preview:large for Discover
            // Let WP handle it, but remove any conflicting filters
            add_filter( 'wp_robots', function( $robots ) {
                $robots['max-image-preview'] = 'large';
                return $robots;
            }, 999 );
        }
    }

    public function get_effective_robots( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array();
        $pm = self::normalize_robots_meta( get_post_meta( $post_id, self::META_KEY, true ) );
        if ( ! empty( $pm ) ) return $pm;
        $g = get_option( self::OPTION_GLOBAL, array() );
        return ( isset( $g[ $post->post_type ] ) && is_array( $g[ $post->post_type ] ) ) ? $g[ $post->post_type ] : array();
    }

    public static function is_noindex( $post_id ) {
        $m = self::normalize_robots_meta( get_post_meta( $post_id, self::META_KEY, true ) );
        if ( in_array( 'noindex', $m, true ) ) return true;
        $g = get_option( self::OPTION_GLOBAL, array() );
        $pt = get_post_type( $post_id );
        return ( isset( $g[ $pt ] ) && is_array( $g[ $pt ] ) && in_array( 'noindex', $g[ $pt ], true ) );
    }

    /**
     * Normalize robots meta to a flat array of directives.
     * Handles ALL storage formats:
     *   - Array:  ['noindex', 'nofollow']          (from Robots metabox)
     *   - String: "noindex,nofollow" or "noindex"   (from Migration Wizard / SEO Panel)
     *   - Empty:  null, '', false, []               (no directives)
     *
     * @param mixed $raw  The raw meta value from get_post_meta()
     * @return array Flat array of directive strings
     */
    public static function normalize_robots_meta( $raw ) {
        if ( empty( $raw ) ) return array();
        if ( is_array( $raw ) ) return array_values( $raw );
        if ( is_string( $raw ) ) {
            return array_values( array_filter( array_map( 'trim', explode( ',', $raw ) ) ) );
        }
        return array();
    }

    public function register_post_meta() {
        foreach ( get_post_types( array( 'public' => true ) ) as $pt ) {
            register_post_meta( $pt, self::META_KEY, array(
                'type'=>'array','single'=>true,
                'show_in_rest'=>array('schema'=>array('type'=>'array','items'=>array('type'=>'string'))),
                'auth_callback'=>function(){ return current_user_can('edit_posts'); },
            ) );
        }
    }

    /* ══════════════════════════════════════════════
     *  METABOX — Shows protection status, blocks noindex
     * ══════════════════════════════════════════════ */

    public function register_metabox() {
        foreach ( get_post_types( array( 'public' => true ) ) as $pt ) {
 add_meta_box( 'hts-robots-meta', 'HTS — Indexation', array( $this, 'render_metabox' ), $pt, 'side', 'default' );
        }
    }

    public function render_metabox( $post ) {
        wp_nonce_field( 'hts_robots_save', 'hts_robots_nonce' );
        $current = self::normalize_robots_meta( get_post_meta( $post->ID, self::META_KEY, true ) );

        list( $prot, $preason ) = self::is_protected( $post->ID );
        if ( $prot ) {
            echo '<div style="background:rgba(5,150,105,0.08);border-left:3px solid #059669;padding:8px;margin-bottom:10px;font-size:12px;border-radius:4px;">';
 echo '<strong> Protégée</strong> — ' . esc_html( $preason ) . '<br><em class="hts-text-secondary">Noindex bloqué.</em></div>';
        }

        $suggestion = $this->get_page_suggestion( $post->ID );
        if ( $suggestion ) {
 $icons = array('rewrite'=>'','integrate_cocon'=>'','optimize_metas'=>'','enrich_geo'=>'','noindex'=>'');
            echo '<div style="border-left:3px solid '.esc_attr($suggestion['color']).';padding:8px;margin-bottom:10px;font-size:12px;border-radius:4px;background:rgba(0,0,0,0.02);">';
 echo '<strong>'.($icons[$suggestion['action']]??'').' '.esc_html($suggestion['action_label']).'</strong><br>'.esc_html($suggestion['reason']).'</div>';
        }

        $opts = array('noindex'=>'Ne pas indexer','nofollow'=>'Ne pas suivre','noarchive'=>'Pas de cache','noimageindex'=>'Pas d\'index images');
        foreach ( $opts as $val => $label ) {
            $dis = ($val==='noindex' && $prot) ? 'disabled' : '';
            $chk = (!$dis && in_array($val,$current,true)) ? 'checked' : '';
            echo '<label style="display:block;margin:4px 0;font-size:13px;'.($dis?'opacity:0.4;':'').'"><input type="checkbox" name="hts_robots[]" value="'.esc_attr($val).'" '.$chk.' '.$dis.'> '.esc_html($label).'</label>';
        }
    }

    public function save_metabox( $post_id, $post ) {
        if ( !isset($_POST['hts_robots_nonce']) || !wp_verify_nonce($_POST['hts_robots_nonce'],'hts_robots_save') ) return;
        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
        if ( !current_user_can('edit_post',$post_id) ) return;

        $robots = array_intersect( array_map('sanitize_text_field',(array)($_POST['hts_robots']??array())), array('noindex','nofollow','noarchive','noimageindex') );

        // HARD LOCK
        list($prot,) = self::is_protected($post_id);
        if ($prot) $robots = array_diff($robots, array('noindex'));

        !empty($robots) ? update_post_meta($post_id,self::META_KEY,array_values($robots)) : delete_post_meta($post_id,self::META_KEY);
    }

    /* ══════════════════════════════════════════════
     *  SUGGESTIONS — Noindex ONLY for utility whitelist
     *
     *  Content page → ALWAYS an improvement action
     *  Utility page → noindex
     *  That's it. No grey zone.
     * ══════════════════════════════════════════════ */

    public function get_page_suggestion( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return null;
        if ( self::is_noindex( $post_id ) ) return null;
        if ( class_exists('HTS_Embeddings') && HTS_Embeddings::is_noindex($post_id) ) return null;

        // ── Check if utility page → only case where noindex is suggested ──
        $utility_match = self::is_utility_page( $post_id );
        if ( $utility_match ) {
            // Even utility pages: don't suggest noindex if protected
            list($prot,) = self::is_protected( $post_id );
            if ( $prot ) return null; // skip entirely
            return array(
                'action'       => 'noindex',
                'action_label' => 'Noindex',
                'reason'       => "Page utilitaire ({$utility_match}). Pas de valeur SEO.",
                'source'       => 'utility',
                'priority'     => 3,
                'color'        => '#dc2626',
            );
        }

        // ══════════════════════════════════════
        //  FROM HERE: content pages ONLY
        //  → NEVER noindex, always improvement
        // ══════════════════════════════════════

        // Gather data
        $doctor = get_post_meta( $post_id, '_hts_doctor_result', true );
        $wc = is_array($doctor) ? (int)($doctor['word_count']??0) : 0;
        if (!$wc) $wc = hts_word_count( wp_strip_all_tags($post->post_content) );

        $gsc_clicks = (int) get_post_meta($post_id,'_hts_gsc_clicks',true);
        $gsc_impr   = (int) get_post_meta($post_id,'_hts_gsc_impressions',true);
        $gsc_ctr    = (float) get_post_meta($post_id,'_hts_gsc_ctr',true);
        $gsc_pos    = (float) get_post_meta($post_id,'_hts_gsc_position',true);

        $is_orphan = false; $in_cocon = false; $cluster_name = '';
        if ( class_exists('HTS_Cocon') ) {
            $data = (new HTS_Cocon())->get_cocon_data();
            if ( isset($data['nodes'][$post_id]) ) $is_orphan = (bool)($data['nodes'][$post_id]['is_orphan']??false);
            foreach ( $data['clusters']??array() as $cn=>$cl ) {
                if ( in_array((int)$post_id, array_map('intval',$cl['pages']??array()), true) ) {
                    $in_cocon = true; $cluster_name = $cn; break;
                }
            }
        }

        // ── Priority 1: THIN CONTENT → Réécrire ──
        if ( $wc > 0 && $wc < 300 ) {
            $r = "Contenu court ({$wc} mots)";
            if ( $gsc_impr > 0 ) $r .= ", {$gsc_impr} impressions GSC";
            if ( $in_cocon ) $r .= ", dans le cocon \"{$cluster_name}\"";
            $r .= " → Enrichir à 1500+ mots avec FAQ, données chiffrées, sources.";
            return array( 'action'=>'rewrite','action_label'=>'Réécrire / Enrichir','reason'=>$r,'source'=>'content_doctor','priority'=>9,'color'=>'#2563eb' );
        }

        // ── Priority 2: ORPHAN → Intégrer au cocon ──
        if ( $is_orphan ) {
            $r = "Page orpheline (0 lien interne entrant)";
            if ( $gsc_clicks > 0 ) $r .= " mais {$gsc_clicks} clics GSC";
            elseif ( $gsc_impr > 0 ) $r .= " mais {$gsc_impr} impressions";
            $r .= " → Créer des liens internes + rattacher à un cocon.";
            return array( 'action'=>'integrate_cocon','action_label'=>'Intégrer au cocon','reason'=>$r,'source'=>'cocon','priority'=>7,'color'=>'#7c3aed' );
        }

        // ── Priority 3: IMPRESSIONS + 0 CLICS → Metas ──
        if ( $gsc_impr > 30 && $gsc_clicks === 0 ) {
            return array( 'action'=>'optimize_metas','action_label'=>'Optimiser metas','reason'=>"{$gsc_impr} impressions, 0 clic → Réécrire Title/Description (pos. moy : ".round($gsc_pos,1).").",'source'=>'gsc','priority'=>8,'color'=>'#d97706' );
        }

        // ── Priority 4: LOW CTR → Metas ──
        if ( $gsc_impr > 100 && $gsc_ctr > 0 && $gsc_ctr < 0.02 ) {
            return array( 'action'=>'optimize_metas','action_label'=>'Optimiser metas','reason'=>"CTR faible (".round($gsc_ctr*100,1)."%) sur {$gsc_impr} impressions.",'source'=>'gsc','priority'=>6,'color'=>'#d97706' );
        }

        // ── Priority 5: NOT GEO-READY → Enrichir ──
        if ( $wc >= 300 && $wc < 1500 && $gsc_impr > 0 ) {
            $has_faq = (stripos($post->post_content,'faq')!==false || stripos($post->post_content,'question')!==false);
            $has_stats = (bool)preg_match('/\d+\s*%/',$post->post_content);
            if ( !$has_faq || !$has_stats || $wc < 1200 ) {
                $m = array();
                if ($wc<1500) $m[] = "{$wc}/1500+ mots";
                if (!$has_faq) $m[] = "pas de FAQ";
                if (!$has_stats) $m[] = "pas de données chiffrées";
                return array( 'action'=>'enrich_geo','action_label'=>'Enrichir GEO','reason'=>"Potentiel ({$gsc_impr} impr.) — ".implode(', ',$m).". Ajouter FAQ, stats, sources pour ChatGPT/Perplexity.",'source'=>'geo','priority'=>5,'color'=>'#059669' );
            }
        }

        // ── Priority 6: NOT IN COCON → Intégrer ──
        if ( !$in_cocon && $wc >= 300 && $post->post_type === 'post' ) {
            return array( 'action'=>'integrate_cocon','action_label'=>'Intégrer au cocon','reason'=>"Article de {$wc} mots hors cocon → Rattacher à un cluster pour la topical authority.",'source'=>'cocon','priority'=>4,'color'=>'#7c3aed' );
        }

        // No suggestion = page is fine
        return null;
    }

    public static function get_all_candidates() {
        global $wpdb;
        $inst = new self();
        $out = array();
        $pt_in = hts_sql_post_types_in();
        $posts = $wpdb->get_results(
            "SELECT ID, post_title, post_name, post_type FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in} ORDER BY ID DESC LIMIT 500", ARRAY_A
        );
        foreach ($posts as $p) {
            $s = $inst->get_page_suggestion((int)$p['ID']);
            if ($s) $out[] = array_merge($s, array('post_id'=>(int)$p['ID'],'title'=>$p['post_title'],'slug'=>$p['post_name'],'post_type'=>$p['post_type'],'edit_url'=>get_edit_post_link((int)$p['ID'],''),'permalink'=>get_permalink((int)$p['ID'])));
        }
        usort($out, function($a,$b){ return ($b['priority']??0)<=>($a['priority']??0); });
        return $out;
    }

    /* ── Stats ── */

    public static function get_crawl_budget_stats() {
        global $wpdb;
        $pt_in = hts_sql_post_types_in();
        $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in}");
        $rows = $wpdb->get_col($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s",self::META_KEY));
        $hts = 0; foreach ($rows as $v){ $a=maybe_unserialize($v); if(is_array($a)&&in_array('noindex',$a,true)) $hts++; }
        $other = 0;
        if (class_exists('HTS_Embeddings')){ foreach($wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_status='publish' AND post_type {$pt_in}") as $id){ if(HTS_Embeddings::is_noindex((int)$id)) $other++; } }
        $g = get_option(self::OPTION_GLOBAL,array()); $gn = 0;
        foreach ($g as $pt=>$d){ if(is_array($d)&&in_array('noindex',$d,true)) $gn+=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type=%s",$pt)); }
        $tn = $hts+$other+$gn;
        return array('total_pages'=>$total,'indexed'=>max(0,$total-$tn),'noindex_hts'=>$hts,'noindex_other'=>$other,'noindex_global'=>$gn,'total_noindex'=>$tn);
    }

    /* ══════════════════════════════════════════════
     *  AJAX — All enforce is_protected() on write
     * ══════════════════════════════════════════════ */

    public function ajax_save_global() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permission refusée');
        $rules=array(); $raw=$_POST['rules']??array();
        if (is_array($raw)){ $ok=array('noindex','nofollow','noarchive','noimageindex');
            foreach($raw as $pt=>$d){ $pt=sanitize_key($pt); if(is_array($d)){$c=array_intersect(array_map('sanitize_text_field',$d),$ok); if(!empty($c))$rules[$pt]=array_values($c);} } }
        update_option( self::OPTION_GLOBAL, $rules, false );
        hts_add_log('Règles robots mises à jour','success','robots');
        wp_send_json_success();
    }

    public function ajax_get_data() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permission refusée');
        wp_send_json_success(array('budget'=>self::get_crawl_budget_stats(),'candidates'=>self::get_all_candidates(),'global'=>get_option(self::OPTION_GLOBAL,array())));
    }

    public function ajax_batch_action() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permission refusée');
        $act = sanitize_text_field($_POST['sub_action']??'');
        $ids = array_map('intval',(array)($_POST['ids']??array()));
        if (empty($ids)) wp_send_json_error('Aucun ID');

        $count=0; $skipped=0;
        if ($act==='noindex') {
            foreach ($ids as $pid) {
                if ($pid<=0) continue;
                list($prot,) = self::is_protected($pid);
                if ($prot) { $skipped++; continue; }
                $c=self::normalize_robots_meta(get_post_meta($pid,self::META_KEY,true));
                if (!in_array('noindex',$c,true)){ $c[]='noindex'; update_post_meta($pid,self::META_KEY,$c); $count++; }
            }
 hts_add_log(" {$count} noindex".($skipped?" ({$skipped} protégée(s) ignorée(s))":''),'success','robots');
        } elseif ($act==='remove_noindex') {
            foreach ($ids as $pid) {
                if ($pid<=0) continue;
                $c=self::normalize_robots_meta(get_post_meta($pid,self::META_KEY,true));
                if(in_array('noindex',$c,true)){ $c=array_values(array_diff($c,array('noindex'))); empty($c)?delete_post_meta($pid,self::META_KEY):update_post_meta($pid,self::META_KEY,$c); $count++; }
            }
 hts_add_log(" {$count} ré-indexable(s)",'info','robots');
        }
        wp_send_json_success(array('count'=>$count,'skipped'=>$skipped));
    }

    public function ajax_toggle_page() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permission refusée');
        $pid=(int)($_POST['post_id']??0);
        if (!$pid) wp_send_json_error('ID requis');

        $c=self::normalize_robots_meta(get_post_meta($pid,self::META_KEY,true));

        if (in_array('noindex',$c,true)) {
            // Remove → always OK
            $c=array_diff($c,array('noindex'));
            empty($c)?delete_post_meta($pid,self::META_KEY):update_post_meta($pid,self::META_KEY,array_values($c));
            if (function_exists('hts_add_log')) {
 hts_add_log(sprintf('Noindex retire : "%s" (ID %d)', get_the_title($pid), $pid), 'info', 'robots');
            }
            wp_send_json_success(array('noindex'=>false));
        } else {
            // Add → check protection
            list($prot,$reason) = self::is_protected($pid);
 if ($prot) wp_send_json_error('Page protégée : '.$reason.'. Noindex impossible.');
            $c[]='noindex'; update_post_meta($pid,self::META_KEY,$c);
            if (function_exists('hts_add_log')) {
 hts_add_log(sprintf('Noindex applique : "%s" (ID %d)', get_the_title($pid), $pid), 'warning', 'robots');
            }
            wp_send_json_success(array('noindex'=>true));
        }
    }

    /* ══════════════════════════════════════════════
     *  ROBOTS.TXT EDITOR — Virtual file via filter
     * ══════════════════════════════════════════════ */

    /**
     * Filter WP's default robots.txt output with custom content.
     * Priority 999 to override any other plugin.
     */
    public function filter_robots_txt( $output, $public ) {
        $custom = get_option( self::OPTION_ROBOTSTXT, '' );
        if ( empty( $custom ) ) return $output;

        // If site is set to "Discourage search engines", force noindex warning
        if ( '0' === (string) $public ) {
 return "User-agent: *\nDisallow: /\n\n# WordPress est configuré pour décourager l'indexation (Réglages → Lecture).\n# Le contenu robots.txt personnalisé HTS est ignoré tant que ce réglage est actif.\n";
        }

        return $custom;
    }

    /**
     * Generate smart default robots.txt content.
     */
    public static function get_default_robotstxt() {
        $lines = array();
        $lines[] = '# robots.txt généré par Hack The SEO';
        $lines[] = '# ' . gmdate( 'Y-m-d H:i' ) . ' UTC';
        $lines[] = '';
        $lines[] = 'User-agent: *';
        $lines[] = 'Disallow: /wp-admin/';
        $lines[] = 'Allow: /wp-admin/admin-ajax.php';
        $lines[] = '';
        $lines[] = '# Bloquer les dossiers système';
        $lines[] = 'Disallow: /wp-includes/';
        $lines[] = 'Disallow: /wp-content/plugins/';
        $lines[] = 'Disallow: /wp-content/cache/';
        $lines[] = 'Disallow: /wp-json/';
        $lines[] = 'Disallow: /feed/';
        $lines[] = 'Disallow: /comments/feed/';
        $lines[] = 'Disallow: /trackback/';
        $lines[] = 'Disallow: /?s=';
        $lines[] = 'Disallow: /search/';
        $lines[] = '';
        $lines[] = '# Paramètres de requête inutiles';
        $lines[] = 'Disallow: /*?replytocom=';
        $lines[] = 'Disallow: /*?attachment_id=';
        $lines[] = '';

        // WooCommerce
        if ( class_exists( 'WooCommerce' ) ) {
            $lines[] = '# WooCommerce — Pages fonctionnelles';
            $lines[] = 'Disallow: /panier/';
            $lines[] = 'Disallow: /cart/';
            $lines[] = 'Disallow: /checkout/';
            $lines[] = 'Disallow: /mon-compte/';
            $lines[] = 'Disallow: /my-account/';
            $lines[] = '';
        }

        // AI crawlers — opt-in by default (user can restrict)
        $lines[] = '# Crawlers IA — autorisés par défaut';
        $lines[] = '# Décommentez pour bloquer des crawlers IA spécifiques :';
        $lines[] = '# User-agent: GPTBot';
        $lines[] = '# Disallow: /';
        $lines[] = '# User-agent: ChatGPT-User';
        $lines[] = '# Disallow: /';
        $lines[] = '# User-agent: Claude-Web';
        $lines[] = '# Disallow: /';
        $lines[] = '# User-agent: Google-Extended';
        $lines[] = '# Disallow: /';
        $lines[] = '# User-agent: CCBot';
        $lines[] = '# Disallow: /';
        $lines[] = '# User-agent: anthropic-ai';
        $lines[] = '# Disallow: /';
        $lines[] = '# User-agent: PerplexityBot';
        $lines[] = '# Disallow: /';
        $lines[] = '';

        // Sitemap auto-detect
        $sitemap_url = self::detect_sitemap_url();
        if ( $sitemap_url ) {
            $lines[] = '# Sitemap';
            $lines[] = 'Sitemap: ' . $sitemap_url;
            $lines[] = '';
        }

        // llms.txt reference if enabled
        if ( get_option( 'hts_llmstxt_enabled', '1' ) === '1' ) {
            $lines[] = '# llms.txt — Visibilité IA';
            $lines[] = '# ' . home_url( '/llms.txt' );
            $lines[] = '';
        }

        return implode( "\n", $lines );
    }

    /**
     * Auto-detect sitemap URL (HTS → Rank Math → Yoast → WP core).
     */
    public static function detect_sitemap_url() {
        // HTS sitemap
        if ( class_exists( 'HTS_Sitemap' ) ) {
            return home_url( '/sitemap.xml' );
        }
        // Rank Math
        if ( class_exists( 'RankMath' ) ) {
            return home_url( '/sitemap_index.xml' );
        }
        // Yoast
        if ( defined( 'WPSEO_VERSION' ) ) {
            return home_url( '/sitemap_index.xml' );
        }
        // WordPress core sitemap (5.5+)
        if ( function_exists( 'wp_get_sitemap_providers' ) ) {
            return home_url( '/wp-sitemap.xml' );
        }
        return '';
    }

    /**
     * Check for a physical robots.txt file in site root.
     */
    public static function has_physical_file() {
        $root = ABSPATH;
        return file_exists( $root . 'robots.txt' );
    }

    /**
     * Validate robots.txt content and return warnings.
     */
    public static function validate_robotstxt( $content ) {
        $warnings = array();
        $lines = explode( "\n", $content );

        $has_user_agent = false;
        $has_disallow_all = false;
        $current_ua = '';

        foreach ( $lines as $i => $line ) {
            $line = trim( $line );
            if ( $line === '' || strpos( $line, '#' ) === 0 ) continue;

            // Check User-agent
            if ( stripos( $line, 'user-agent:' ) === 0 ) {
                $ua = trim( substr( $line, 11 ) );
                $has_user_agent = true;
                $current_ua = $ua;
            }

            // Check Disallow: /
            if ( preg_match( '/^disallow:\s*\/\s*$/i', $line ) && $current_ua === '*' ) {
                $has_disallow_all = true;
            }
        }

        if ( $has_disallow_all ) {
            $warnings[] = array(
                'type'    => 'danger',
 'message' => ' <strong>Disallow: /</strong> détecté pour User-agent: * — Ceci bloque TOUS les moteurs de recherche ! Votre site ne sera plus indexé.',
            );
        }

        if ( ! $has_user_agent && ! empty( trim( $content ) ) ) {
            $warnings[] = array(
                'type'    => 'warning',
 'message' => 'Aucun <strong>User-agent</strong> détecté. Les directives sans User-agent seront ignorées par les crawlers.',
            );
        }

        // Check for common mistakes
        if ( stripos( $content, 'Disalow:' ) !== false || stripos( $content, 'Dissallow:' ) !== false ) {
            $warnings[] = array(
                'type'    => 'warning',
 'message' => 'Faute de frappe détectée : vérifiez l\'orthographe de <strong>Disallow</strong>.',
            );
        }

        return $warnings;
    }

    /**
     * AJAX: Preview current effective robots.txt.
     */
    public function ajax_robotstxt_preview() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $custom = get_option( self::OPTION_ROBOTSTXT, '' );
        $public = get_option( 'blog_public', '1' );

        if ( ! empty( $custom ) ) {
            $content = $this->filter_robots_txt( $custom, $public );
        } else {
            // Show WP default
            $content = "User-agent: *\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\n";
            if ( '0' === (string) $public ) {
                $content = "User-agent: *\nDisallow: /\n";
            }
        }

        $warnings = self::validate_robotstxt( $content );

        wp_send_json_success( array(
            'content'       => $content,
            'warnings'      => $warnings,
            'has_physical'  => self::has_physical_file(),
            'blog_public'   => $public,
            'url'           => home_url( '/robots.txt' ),
        ) );
    }

    /**
     * AJAX: Get smart defaults.
     */
    public function ajax_robotstxt_defaults() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        wp_send_json_success( array(
            'content'  => self::get_default_robotstxt(),
            'sitemap'  => self::detect_sitemap_url(),
        ) );
    }

    public static function get_suggestion_count() {
        $c=get_transient('hts_robots_suggestion_count');
        if (false!==$c) return (int)$c;
        $n=count(self::get_all_candidates());
        set_transient('hts_robots_suggestion_count',$n,600);
        return $n;
    }
}
