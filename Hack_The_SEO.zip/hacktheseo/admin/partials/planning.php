<?php
/**
 * HTS Planning Page — S8a DS v5.7
 * Calendar-first month view, drag & drop sidebar, auto-publish config
 * @since 2.6.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}

$commander = new HTS_Cocon_Commander();
$plans     = $commander->get_plans();
$ajax_url  = admin_url( 'admin-ajax.php' );
$nonce     = wp_create_nonce( 'hts_admin_nonce' );
$auto_cfg  = class_exists( 'HTS_Auto_Write' ) ? HTS_Auto_Write::get_auto_schedule_config() : array( 'enabled' => false );
$as_days   = $auto_cfg['days'] ?? array( 1, 2, 3, 4, 5 );
$as_time   = $auto_cfg['time'] ?? '09:00';
$tz        = wp_timezone();
$today     = new DateTimeImmutable( 'now', $tz );

global $wpdb;

// ─── Current month for navigation ───
$nav_month = isset( $_GET['hts_month'] ) ? sanitize_text_field( wp_unslash( $_GET['hts_month'] ) ) : $today->format( 'Y-m' );
// Validate YYYY-MM format strictly (month 01-12)
if ( ! preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $nav_month ) ) $nav_month = $today->format( 'Y-m' );
$nav_date = DateTimeImmutable::createFromFormat( 'Y-m-d', $nav_month . '-01', $tz );
if ( ! $nav_date ) $nav_date = $today;
$cal_start = $nav_date->modify( 'first day of this month' );
$cal_end   = $nav_date->modify( 'last day of this month' );
$prev_month = $cal_start->modify( '-1 month' )->format( 'Y-m' );
$next_month = $cal_start->modify( '+1 month' )->format( 'Y-m' );
$is_current_month = ( $cal_start->format( 'Y-m' ) === $today->format( 'Y-m' ) );
$month_fr = array( 1=>'Janvier',2=>'Février',3=>'Mars',4=>'Avril',5=>'Mai',6=>'Juin',7=>'Juillet',8=>'Août',9=>'Septembre',10=>'Octobre',11=>'Novembre',12=>'Décembre' );
$dl = array( 1 => 'Lun', 2 => 'Mar', 3 => 'Mer', 4 => 'Jeu', 5 => 'Ven', 6 => 'Sam', 7 => 'Dim' );

// ─── Queries ───
$sched_posts = $wpdb->get_results( $wpdb->prepare(
    "SELECT ID, post_title, post_date, post_status FROM {$wpdb->posts}
     WHERE post_status IN ('future','publish') AND post_type IN ('post','page')
       AND post_date BETWEEN %s AND %s ORDER BY post_date ASC",
    $cal_start->format( 'Y-m-d 00:00:00' ), $cal_end->format( 'Y-m-d 23:59:59' )
) );
$published_month = 0;
$scheduled_month = 0;
foreach ( $sched_posts as $sp ) {
    if ( $sp->post_status === 'publish' ) $published_month++;
    else $scheduled_month++;
}

// ─── Monthly goal ───
$monthly_goal = (int) get_option( 'hts_monthly_goal', 8 );
if ( $monthly_goal < 1 ) $monthly_goal = 8;
$goal_done = $published_month; // Only published count toward goal (scheduled = WIP)
$goal_pct = min( 100, round( ( $goal_done / max( 1, $monthly_goal ) ) * 100 ) );

// ─── GSC clicks this month (only if GSC connected) ───
$gsc_clicks_month = 0;
$gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
if ( $gsc_connected && $is_current_month ) {
    $pub_ids = array();
    foreach ( $sched_posts as $sp ) {
        if ( $sp->post_status === 'publish' ) $pub_ids[] = (int) $sp->ID;
    }
    if ( ! empty( $pub_ids ) ) {
        $id_list = implode( ',', $pub_ids );
        $gsc_clicks_month = (int) $wpdb->get_var(
            "SELECT COALESCE(SUM(CAST(meta_value AS UNSIGNED)),0) FROM {$wpdb->postmeta}
             WHERE meta_key='_hts_gsc_clicks' AND post_id IN ($id_list)"
        );
    }
}

// ─── 12-week regularity ───
$anchor = $today->modify( '-12 weeks' );
$twelve_weeks_ago = ( (int) $anchor->format( 'N' ) === 1 ) ? $anchor : $anchor->modify( 'last Monday' );
$week_data_raw = $wpdb->get_results( $wpdb->prepare(
    "SELECT YEARWEEK(post_date, 1) AS yw, COUNT(*) AS cnt
     FROM {$wpdb->posts}
     WHERE post_status = 'publish' AND post_type IN ('post','page')
       AND post_date >= %s AND post_date <= %s
     GROUP BY YEARWEEK(post_date, 1) ORDER BY yw ASC",
    $twelve_weeks_ago->format( 'Y-m-d 00:00:00' ), $today->format( 'Y-m-d 23:59:59' )
) );
$week_counts = array();
$week_labels = array();
$cursor = clone $twelve_weeks_ago;
for ( $w = 0; $w < 12; $w++ ) {
    $yw_key = sprintf( '%d%02d', (int) $cursor->format( 'o' ), (int) $cursor->format( 'W' ) );
    $week_counts[ $yw_key ] = 0;
    $week_labels[ $yw_key ] = $cursor->format( 'd/m' );
    $cursor = $cursor->modify( '+7 days' );
}
foreach ( $week_data_raw as $row ) {
    $db_key = (string) $row->yw;
    if ( isset( $week_counts[ $db_key ] ) ) $week_counts[ $db_key ] = (int) $row->cnt;
}
$wk_vals = array_values( $week_counts );
$wk_labels = array_values( $week_labels );
$wk_max = max( 1, max( $wk_vals ) );
$wk_total = array_sum( $wk_vals );
$wk_avg = round( $wk_total / 12, 1 );

// Regularity score (CV-based)
$wk_mean = $wk_total / 12;
$wk_var = 0;
foreach ( $wk_vals as $v ) $wk_var += pow( $v - $wk_mean, 2 );
$wk_var /= 12;
$wk_std = sqrt( $wk_var );
if ( $wk_total == 0 ) { $reg_score = 0; } else {
    $cv = $wk_std / max( $wk_mean, 0.001 );
    $reg_raw = max( 0, min( 1, 1 - ( $cv / 2 ) ) );
    $zw = count( array_filter( $wk_vals, function( $v ) { return $v === 0; } ) );
    $reg_score = (int) round( max( 0, min( 100, ( $reg_raw - min( 0.3, $zw * 0.06 ) ) * 100 ) ) );
}
$reg_color = $reg_score >= 70 ? 'var(--hts-success)' : ( $reg_score >= 40 ? 'var(--hts-caution)' : 'var(--hts-danger)' );

// Trend
$last4 = array_sum( array_slice( $wk_vals, 8, 4 ) ) / 4;
$prev4 = array_sum( array_slice( $wk_vals, 4, 4 ) ) / 4;
$trend = $last4 > $prev4 + 0.25 ? 'up' : ( $last4 < $prev4 - 0.25 ? 'down' : 'stable' );
$trend_icon = $trend === 'up' ? '↑' : ( $trend === 'down' ? '↓' : '→' );

// ─── Ready articles (sidebar) ───
$ready = array();
$ready_ids = array(); // track IDs to avoid duplicates
$truly_ready_count = 0; // articles validés ET avec image

// 1. Articles from Cocon Commander plans (received/ready)
foreach ( $plans as $cid => $cp ) {
    if ( empty( $cp['articles'] ) ) continue;
    foreach ( $cp['articles'] as $art ) {
        if ( ! in_array( $art['status'] ?? '', array( 'received', 'ready' ), true ) ) continue;
        $did = $art['post_id'] ?? 0;
        if ( ! $did ) continue;
        $p = get_post( $did );
        if ( ! $p || $p->post_status !== 'draft' ) continue;
        $has_img  = has_post_thumbnail( $did );
        $approved = (bool) get_post_meta( $did, '_hts_schedule_approved', true );
        $score    = (int) get_post_meta( $did, '_hts_global_score', true );
        $words    = function_exists( 'hts_word_count' ) ? hts_word_count( wp_strip_all_tags( $p->post_content ) ) : str_word_count( wp_strip_all_tags( $p->post_content ) );
        if ( $approved && $has_img && $words >= 100 ) $truly_ready_count++;
        $ready[] = array(
            'id'       => $did,
            'title'    => $p->post_title,
            'cocon'    => $cp['keyword'] ?? $cp['pillar_title'] ?? $cid,
            'approved' => $approved,
            'edit'     => get_edit_post_link( $did, 'raw' ),
            'img'      => $has_img ? ( get_the_post_thumbnail_url( $did, 'thumbnail' ) ?: '' ) : '',
            'has_img'  => $has_img,
            'score'    => $score,
            'words'    => $words,
        );
        $ready_ids[] = $did;
    }
}

// 2. Orphan HTS drafts — generated by SaaS (standalone or API push) but not in any cocon plan
$orphan_query = new WP_Query( array(
    'post_type'      => array( 'post', 'page' ),
    'post_status'    => 'draft',
    'posts_per_page' => 100,
    'meta_query'     => array(
        array( 'key' => '_hts_api_generated', 'value' => '1' ),
    ),
    'post__not_in'   => ! empty( $ready_ids ) ? $ready_ids : array( 0 ),
    'orderby'        => 'date',
    'order'          => 'DESC',
    'no_found_rows'  => true,
) );
if ( $orphan_query->have_posts() ) {
    foreach ( $orphan_query->posts as $op ) {
        if ( in_array( $op->ID, $ready_ids, true ) ) continue;
        $has_img  = has_post_thumbnail( $op->ID );
        $approved = (bool) get_post_meta( $op->ID, '_hts_schedule_approved', true );
        $score    = (int) get_post_meta( $op->ID, '_hts_global_score', true );
        $words    = function_exists( 'hts_word_count' ) ? hts_word_count( wp_strip_all_tags( $op->post_content ) ) : str_word_count( wp_strip_all_tags( $op->post_content ) );
        $kw_label = get_post_meta( $op->ID, '_hts_api_keyword', true )
                 ?: get_post_meta( $op->ID, '_hts_focus_keyword', true )
                 ?: '';
        if ( $approved && $has_img && $words >= 100 ) $truly_ready_count++;
        $ready[] = array(
            'id'       => $op->ID,
            'title'    => $op->post_title,
            'cocon'    => $kw_label ? $kw_label : 'Standalone',
            'approved' => $approved,
            'edit'     => get_edit_post_link( $op->ID, 'raw' ),
            'img'      => $has_img ? ( get_the_post_thumbnail_url( $op->ID, 'thumbnail' ) ?: '' ) : '',
            'has_img'  => $has_img,
            'score'    => $score,
            'words'    => $words,
        );
        $ready_ids[] = $op->ID;
    }
}
wp_reset_postdata();

$by_day = array();
foreach ( $sched_posts as $sp ) { $by_day[ substr( $sp->post_date, 0, 10 ) ][] = $sp; }

$n_ready = count( $ready );
$auto_on = ! empty( $auto_cfg['enabled'] );
$page_url = admin_url( 'admin.php?page=hts-planning' );

// ─── Agent mode for auto-pub safety info ───
$agent_mode = 'review';
if ( class_exists( 'HTS_Workflow_Engine' ) ) {
    $agents = HTS_Workflow_Engine::get_all_agents();
    $aw = $agents['auto_write'] ?? array();
    $agent_mode = $aw['mode'] ?? 'review';
}
$approved_count = (int) $wpdb->get_var(
    "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_hts_schedule_approved' AND meta_value='1'"
);
?>

<?php echo HTS_DS::page_open( true ); ?>
<?php echo HTS_DS::hero( 'Calendrier éditorial', 'Planifiez et suivez vos publications',
	'<div style="position:absolute;top:32px;right:36px;display:flex;gap:10px">'
	. '<div style="text-align:center;padding:8px 14px;border-radius:8px;background:rgba(255,255,255,.04)">'
	. '<div style="font-size:18px;font-weight:800;color:' . ( $ready ? 'var(--hts-caution)' : '#fff' ) . '">' . count( $ready ) . '</div>'
	. '<div style="font-size:9px;color:rgba(255,255,255,.35);font-weight:600;text-transform:uppercase">A planifier</div>'
	. '</div>'
	. '<div style="text-align:center;padding:8px 14px;border-radius:8px;background:rgba(255,255,255,.04)">'
	. '<div style="font-size:18px;font-weight:800;color:#fff">' . $goal_done . '/' . $monthly_goal . '</div>'
	. '<div style="font-size:9px;color:rgba(255,255,255,.35);font-weight:600;text-transform:uppercase">Ce mois</div>'
	. '</div>'
	. '</div>'
); ?>

<style>.hts-hero{position:relative}</style>

<div class="hts-plan">
<style>
:root{--hts-indigo:var(--hts-geo);--hts-indigo-hover:var(--hts-geo-hover,#4f46e5);--hts-green:var(--hts-success);--hts-orange:var(--hts-caution);--hts-blue:var(--hts-accent);--hts-red:var(--hts-danger);--hts-muted:var(--hts-text-3)}
.hts-plan{font-family:var(--hts-font,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif);color:var(--hts-text);max-width:100%}
.hts-plan *{box-sizing:border-box}

/* ─── TOP BAR: single row, goal-centered ─── */
.hp-strip{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius,12px);margin-bottom:16px;padding:18px 22px;display:flex;align-items:center;gap:20px;flex-wrap:wrap;box-shadow:0 1px 3px rgba(0,0,0,.06),0 1px 2px rgba(0,0,0,.04)}
.hp-strip .hs-goal{flex:1;min-width:220px}
.hp-strip .hs-goal-top{display:flex;align-items:baseline;gap:8px;margin-bottom:6px}
.hp-strip .hs-goal-num{font-size:24px;font-weight:800;line-height:1}
.hp-strip .hs-goal-of{font-size:14px;color:var(--hts-text);font-weight:500}
.hp-strip .hs-goal-msg{font-size:12px;color:var(--hts-text-2,#475569);margin-top:5px;line-height:1.4}
.hp-strip .hs-goal-msg strong{font-weight:700}
.hp-strip .hs-goal-edit{font-size:11px;color:var(--hts-indigo);cursor:pointer;margin-left:6px}
.hp-strip .hs-goal-edit:hover{text-decoration:underline}
@media(max-width:768px){.hp-strip{flex-direction:column;align-items:flex-start}}

/* ─── MAIN LAYOUT: calendar + sidebar ─── */
.hp-layout{display:grid;grid-template-columns:1fr 280px;gap:16px;align-items:start}
@media(max-width:900px){.hp-layout{grid-template-columns:1fr}}

/* ─── CALENDAR CARD ─── */
.hp-cal-card{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius,12px);overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06),0 1px 2px rgba(0,0,0,.04)}
.hp-cal-head{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--hts-border-sub,#f1f5f9)}
.hp-cal-head h3{font-size:15px;font-weight:700;margin:0}
.hp-cal-nav{display:flex;align-items:center;gap:4px}
.hp-cal-nav a{display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:6px;border:1px solid var(--hts-border);color:var(--hts-text-2,#475569);text-decoration:none;font-size:13px;transition:.15s;padding:0;background:none;box-shadow:none}
.hp-cal-nav a:hover{background:var(--hts-surface-hover,#f1f5f9);border-color:var(--hts-geo-light,#c7d2fe);color:var(--hts-indigo)}
.hp-cal-nav .today-btn{font-size:10px;font-weight:600;padding:4px 10px;width:auto;color:var(--hts-indigo);border-color:var(--hts-geo-light,#c7d2fe);background:var(--hts-geo-bg,#eef2ff)}

.hp-cal{padding:0}
.hp-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:0}
.hp-cal-grid .c-head{font-size:11px;font-weight:700;color:var(--hts-muted);text-align:center;padding:10px 0;border-bottom:1px solid var(--hts-border-sub,#f3f4f6);background:var(--hts-surface,#f9fafb)}
.hp-cal-grid .c-day{height:90px;border-right:1px solid var(--hts-border-sub,#f3f4f6);border-bottom:1px solid var(--hts-border-sub,#f3f4f6);padding:6px;font-size:9px;position:relative;overflow:hidden}
.hp-cal-grid .c-day:nth-child(7n){border-right:none}
.hp-cal-grid .c-day.other{opacity:.3;background:var(--hts-surface,#f9fafb)}
.hp-cal-grid .c-day.past{background:var(--hts-surface-hover,#f0f0f3)}
.hp-cal-grid .c-day.today{background:var(--hts-accent-bg,#ebf3ff)}
.hp-cal-grid .c-day.has-publish{background:var(--hts-success-bg,#f0fdf4)}
.hp-cal-grid .c-day.has-future{background:var(--hts-accent-bg,#eff6ff)}
.hp-cal-grid .c-day.today.has-publish{background:var(--hts-accent-bg,#ebf3ff);border-left:3px solid var(--hts-success)}
.hp-cal-grid .c-day.today.has-future{background:var(--hts-accent-bg,#ebf3ff);border-left:3px solid var(--hts-accent)}
.hp-cal-grid .c-day.drop-over{outline:2px dashed var(--hts-geo);outline-offset:-2px;background:var(--hts-geo-bg,#f5f3ff)}
.hp-cal-grid .c-day .c-num{font-weight:700;color:var(--hts-text-2,#475569);font-size:12px;margin-bottom:3px}
.hp-cal-grid .c-day.today .c-num{color:var(--hts-accent);font-weight:800}
.hp-cal-grid .c-day.past .c-num{color:var(--hts-text-3,#d2d2d7)}
.hp-cal-grid .c-day .c-post{border-radius:var(--hts-radius-xs,6px);padding:2px 6px;margin-bottom:2px;font-size:9px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer}
.hp-cal-grid .c-day .c-post.st-publish{background:var(--hts-success-bg,#f0fdf4);color:var(--hts-text)}
.hp-cal-grid .c-day .c-post.st-future{background:var(--hts-accent-bg,#eff6ff);color:var(--hts-text);position:relative}
.hp-cal-grid .c-day .c-post.temp{background:var(--hts-geo-bg,#eef2ff);color:var(--hts-text);animation:pulse-bg .8s ease-in-out}
.hp-cal-grid .c-day .c-post .c-time{color:var(--hts-text-3)}
.hp-cal-grid .c-day .c-post .c-unsched{display:none;position:absolute;right:2px;top:1px;font-size:10px;color:var(--hts-text-3);cursor:pointer;padding:0 2px;line-height:1}
.hp-cal-grid .c-day .c-post.st-future:hover .c-unsched{display:block}
.hp-cal-grid .c-day .c-post .c-unsched:hover{color:var(--hts-danger)}
.hp-cal-grid .c-day .c-auto-dot{position:absolute;top:4px;right:5px;width:4px;height:4px;border-radius:50%;background:var(--hts-geo-light,#c7d2fe)}
.hp-cal-grid .c-day .c-gsc{display:block;font-size:7px;color:var(--hts-text-3);margin-top:1px;font-weight:600}
@keyframes pulse-bg{0%{opacity:.4}50%{opacity:1}100%{opacity:1}}

/* ─── SIDEBAR: articles ─── */
.hp-side{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius,12px);overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06),0 1px 2px rgba(0,0,0,.04);display:flex;flex-direction:column;position:sticky;top:32px}
.hp-side-h{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;margin-bottom:0;flex-shrink:0}
.hp-side-h h3{font-size:14px;font-weight:700;margin:0}
.hp-side-h .s-count{font-weight:400;color:var(--hts-muted)}
.hp-side-scroll{flex:1;overflow-y:auto;overflow-x:hidden;min-height:0}
.hp-side-scroll::-webkit-scrollbar{width:4px}
.hp-side-scroll::-webkit-scrollbar-thumb{background:var(--hts-border);border-radius:2px}
.hp-side-foot{flex-shrink:0;padding:8px 16px;border-top:1px solid var(--hts-border-sub,#f3f4f6)}

.hp-row{display:flex;align-items:center;gap:8px;padding:8px 16px;border-bottom:1px solid var(--hts-border-sub,#f3f4f6);transition:background .1s;cursor:grab}
.hp-row:hover{background:var(--hts-surface-hover,#f8fafc)}
.hp-row:active{cursor:grabbing}
.hp-row .r-img{width:26px;height:26px;border-radius:var(--hts-radius-sm,8px);object-fit:cover;flex-shrink:0}
.hp-row .r-ph{width:26px;height:26px;border-radius:var(--hts-radius-sm,8px);flex-shrink:0;display:flex;align-items:center;justify-content:center;border:1.5px dashed var(--hts-caution)}
.hp-row.incomplete{opacity:.7;cursor:default}
.hp-row.incomplete:hover{background:var(--hts-caution-bg,#fffbeb)}
.hp-row .r-info{flex:1;min-width:0}
.hp-row .r-t{font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hp-row .r-t a{color:var(--hts-text);text-decoration:none;padding:0;background:none;box-shadow:none}.hp-row .r-t a:hover{color:var(--hts-indigo)}
.hp-row .r-m{font-size:10px;color:var(--hts-muted);display:flex;gap:4px;margin-top:2px;padding-left:34px}
.hp-row .r-m .warn{color:var(--hts-danger)}
.hp-row .r-act{display:flex;gap:2px;flex-shrink:0}

/* Buttons — DS-aligned */
.hb{font-size:9px;font-weight:600;padding:2px 6px;border-radius:4px;border:none;cursor:pointer;transition:.15s;font-family:var(--hts-font,inherit)}
.hb.pr{background:var(--hts-indigo);color:#fff}.hb.pr:hover{background:var(--hts-indigo-hover)}
.hb.ap{background:var(--hts-accent-bg,#dbeafe);color:var(--hts-accent)}
.hb.gh{background:none;color:var(--hts-muted);border:1px solid var(--hts-border)}.hb.gh:hover{background:var(--hts-surface-hover,#f1f5f9)}
.hb.rm{background:none;color:var(--hts-border);border:none;font-size:11px;padding:1px 3px}.hb.rm:hover{color:var(--hts-red)}
.hb:disabled{opacity:.4;cursor:not-allowed}

/* ─── EXPANDABLE DRAWER: 12-week chart ─── */
.hp-drawer{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius,12px);margin-top:16px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06),0 1px 2px rgba(0,0,0,.04)}
.hp-drawer-toggle{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;cursor:pointer;user-select:none;transition:background .15s}
.hp-drawer-toggle:hover{background:var(--hts-surface-hover,#f8fafc)}
.hp-drawer-toggle h4{font-size:14px;font-weight:700;margin:0}
.hp-drawer-toggle .dt-meta{font-size:12px;color:var(--hts-muted)}
.hp-drawer-toggle .dt-arrow{transition:transform .2s;font-size:12px;color:var(--hts-muted)}
.hp-drawer-body{display:none;padding:8px 22px 20px}
.hp-drawer.open .hp-drawer-body{display:block}
.hp-drawer.open .dt-arrow{transform:rotate(180deg)}

.hp-bars{display:flex;align-items:flex-end;gap:6px;height:100px;position:relative;padding-bottom:22px}
.hp-bars .hb-col{flex:1;position:relative;height:100%;display:flex;align-items:flex-end}
.hp-bars .hb-bar{width:100%;border-radius:4px 4px 0 0;background:var(--hts-accent-bg,#dbeafe);transition:background .15s;min-height:4px}
.hp-bars .hb-col:last-child .hb-bar{background:var(--hts-accent)}
.hp-bars .hb-col:hover .hb-bar{background:var(--hts-accent)}
.hp-bars .hb-lbl{position:absolute;bottom:-18px;left:50%;transform:translateX(-50%);font-size:8px;color:var(--hts-text-3,#d2d2d7);white-space:nowrap}
.hp-bars .hb-val{position:absolute;top:-14px;left:50%;transform:translateX(-50%);font-size:8px;font-weight:700;color:var(--hts-text-2,#475569);opacity:0;transition:opacity .15s}
.hp-bars .hb-col:hover .hb-val{opacity:1}
/* MA line — covers only the bars area, not the label space */
.hp-ma-line{position:absolute;bottom:22px;left:0;right:0;height:calc(100% - 22px);pointer-events:none}
.hp-ma-line svg{width:100%;height:100%;overflow:visible}
.hp-chart-footer{font-size:10px;color:var(--hts-muted);margin-top:12px;display:flex;justify-content:space-between}
.hp-chart-footer .hp-cf-val{font-size:11px;font-weight:600;color:var(--hts-accent)}

/* ─── Empty state ─── */
.hp-empty{text-align:center;padding:48px 20px}
.hp-empty h3{font-size:15px;font-weight:700;margin:0 0 6px}
.hp-empty p{font-size:11px;color:var(--hts-text-3);max-width:340px;margin:0 auto}
.hp-empty a{color:var(--hts-indigo);padding:0;background:none;box-shadow:none}

/* Toast: uses same cockpit pattern (inline styles on HTML element) */

/* Config panel */
.hp-cfg-panel{display:none;background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius,12px);margin-bottom:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06),0 1px 2px rgba(0,0,0,.04)}
.hp-cfg-inner{padding:20px 22px 32px;display:flex;gap:28px;align-items:flex-end;flex-wrap:wrap}
.hp-cfg-section{display:flex;flex-direction:column;gap:8px}
.hp-cfg-section .cfg-label{font-size:10px;font-weight:700;color:var(--hts-muted);text-transform:uppercase;letter-spacing:.5px}
/* Day buttons */
.hp-days{display:flex;gap:4px}
.hp-days .day-btn{width:36px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-2,#475569);cursor:pointer;transition:.15s;font-family:var(--hts-font,inherit)}
.hp-days .day-btn:hover{border-color:var(--hts-geo-light,#c7d2fe);background:var(--hts-geo-bg,#f5f3ff)}
.hp-days .day-btn.on{background:var(--hts-indigo);color:#fff;border-color:var(--hts-indigo)}
.hp-days .day-btn input{display:none}
/* Time + save row */
.hp-cfg-time{display:flex;align-items:center;gap:8px}
.hp-cfg-foot{padding:12px 20px;border-top:1px solid var(--hts-border-sub,#f1f5f9);display:flex;align-items:center;gap:8px}

</style>

<?php if ( !$n_ready && !count($sched_posts) ) : ?>
<?php echo HTS_DS::empty_state(
	'Rien à planifier',
	'Générez des articles dans les Groupes de contenus pour les retrouver ici.',
	'Groupes de contenus',
	array( 'onclick' => 'window.location.href=\'' . esc_js( admin_url('admin.php?page=hts-cocon-commander&tab=redaction') ) . '\'' )
); ?>
<?php else : ?>

<!-- ═══════ TOP STRIP: goal + context ═══════ -->
<div class="hp-strip">
    <div class="hs-goal">
        <div class="hs-goal-top">
            <span class="hs-goal-num" style="color:<?php echo $goal_pct >= 100 ? 'var(--hts-green)' : ( $goal_pct >= 50 ? 'var(--hts-blue)' : 'var(--hts-orange)' ); ?>"><?php echo $goal_done; ?></span>
            <span class="hs-goal-of">/ <?php echo $monthly_goal; ?> articles en <?php echo esc_html( mb_strtolower( $month_fr[ (int) $cal_start->format('n') ] ) ); ?></span>
            <button style="display:flex;align-items:center;gap:4px;font-size:12px;color:var(--hts-accent);background:none;border:none;cursor:pointer;font-weight:600;font-family:var(--hts-font,inherit);padding:0" onclick="var el=document.getElementById('hp-goal-edit');el.style.display=el.style.display==='flex'?'none':'flex'"><?php echo HTS_DS::icon( 'gear', 12, 'var(--hts-accent)' ); ?> Modifier</button>
        </div>
        <?php
            $goal_color = $goal_pct >= 100 ? 'var(--hts-success)' : ( $goal_pct >= 50 ? 'var(--hts-accent)' : 'var(--hts-caution)' );
            echo HTS_DS::progress( $goal_pct, $goal_color, 4 );
        ?>
        <div class="hs-goal-msg"><?php
            $remaining = $monthly_goal - $goal_done;
            $days_left = max( 0, (int) $cal_end->format('j') - (int) $today->format('j') );
            if ( $goal_pct >= 100 ) {
                echo '<strong style="color:var(--hts-green)">Objectif atteint !</strong> Continuez sur cette lancée.';
            } elseif ( $is_current_month ) {
                $parts = array();
                $parts[] = '<strong>' . $remaining . ' article' . ( $remaining > 1 ? 's' : '' ) . '</strong> restant' . ( $remaining > 1 ? 's' : '' );
                if ( $scheduled_month > 0 ) $parts[] = $scheduled_month . ' déjà planifié' . ( $scheduled_month > 1 ? 's' : '' );
                $parts[] = $days_left . ' jours restants';
                echo implode( ' · ', $parts );
            } else {
                echo $goal_done . ' publié' . ( $goal_done > 1 ? 's' : '' ) . ' ce mois';
            }
            // GSC traffic signal (only if connected and has data)
            if ( $gsc_connected && $gsc_clicks_month > 0 ) {
                echo ' · <span style="color:var(--hts-green)">' . number_format( $gsc_clicks_month ) . ' clics</span> depuis Google';
            }
        ?></div>
        <div id="hp-goal-edit" style="display:none;align-items:center;gap:6px;margin-top:6px">
            <?php echo HTS_DS::input( array( 'type' => 'number', 'id' => 'hp-goal-val', 'value' => $monthly_goal, 'style' => 'width:50px;text-align:center' ) ); ?>
            <?php echo HTS_DS::button( 'OK', 'geo', 'sm', array( 'onclick' => 'htsSaveGoal()' ) ); ?>
        </div>
    </div>

    <span style="cursor:pointer;display:inline-flex;align-items:center;gap:8px" onclick="var p=document.getElementById('hp-cfg'),b=this.querySelector('.hts-ds-btn');if(p.style.display==='block'){p.style.display='none';b.textContent='Configurer l\u0027auto-publication'}else{p.style.display='block';b.textContent='Fermer'}"><?php
        echo HTS_DS::button( 'Configurer l\'auto-publication', 'default', 'sm' );
        echo $auto_on
            ? HTS_DS::badge( 'Auto ON', 'success', true )
            : HTS_DS::badge( 'Auto OFF', 'danger' );
    ?></span>
</div>

<!-- Config panel (collapsed) -->
<div id="hp-cfg" class="hp-cfg-panel">
    <!-- Dismissible safety info (hidden once OK clicked, stored in localStorage) -->
    <div id="hp-cfg-info" style="display:none;padding:14px 20px;background:var(--hts-success-bg,#f0fdf4);border-bottom:1px solid var(--hts-success-light,#bbf7d0);font-size:12px;color:var(--hts-success-dark,#166534);line-height:1.5">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
            <div>
                <strong>Comment ça marche :</strong> seuls les articles que vous avez <strong>validés</strong> (bouton « Valider ») seront publiés automatiquement.
                Un article sans image à la une, avec moins de 100 mots, ou avec un score qualité insuffisant ne sera jamais publié.
            </div>
            <button onclick="document.getElementById('hp-cfg-info').style.display='none';try{localStorage.setItem('hts_auto_info_dismissed','1')}catch(e){}" style="border:none;background:none;cursor:pointer;color:var(--hts-success);font-size:16px;flex-shrink:0;padding:0;line-height:1">&#10005;</button>
        </div>
    </div>
    <script>try{if(!localStorage.getItem('hts_auto_info_dismissed')){document.getElementById('hp-cfg-info').style.display='block'}}catch(e){document.getElementById('hp-cfg-info').style.display='block'}</script>

    <!-- Safety checklist -->
    <div style="padding:12px 20px;border-bottom:1px solid var(--hts-border-sub,#f1f5f9);font-size:11px;color:var(--hts-text-2,#475569);display:flex;gap:16px;flex-wrap:wrap">
        <span><?php echo HTS_DS::icon( 'check', 12, 'var(--hts-success)' ); ?> Image obligatoire</span>
        <span><?php echo HTS_DS::icon( 'check', 12, 'var(--hts-success)' ); ?> Min. 100 mots</span>
        <span><?php echo HTS_DS::icon( 'check', 12, 'var(--hts-success)' ); ?> Qualité vérifiée</span>
        <span><?php echo HTS_DS::icon( 'check', 12, 'var(--hts-success)' ); ?> Limite hebdo</span>
        <?php if ( $truly_ready_count > 0 ) : ?>
        <span style="color:var(--hts-indigo);font-weight:600"><?php echo $truly_ready_count; ?> prêt<?php echo $truly_ready_count > 1 ? 's' : ''; ?> à publier</span>
        <?php elseif ( $approved_count > 0 ) : ?>
        <span style="color:var(--hts-orange);font-weight:600"><?php echo $approved_count; ?> validé<?php echo $approved_count > 1 ? 's' : ''; ?> mais incomplet<?php echo $approved_count > 1 ? 's' : ''; ?></span>
        <?php else : ?>
        <span style="color:var(--hts-muted)">Aucun article validé</span>
        <?php endif; ?>
    </div>

    <div class="hp-cfg-inner">
        <!-- Toggle auto -->
        <div class="hp-cfg-section">
            <div class="cfg-label">Auto-publication</div>
            <div style="display:flex;align-items:center;gap:8px">
                <?php if ( $agent_mode === 'auto' ) : ?>
                <span id="hts-auto-toggle-wrap" onclick="htsAutoToggle()" style="cursor:pointer"><?php echo HTS_DS::toggle( $auto_on, '', 'hts-auto-toggle' ); ?></span>
                <span style="font-size:13px;font-weight:600;color:<?php echo $auto_on ? 'var(--hts-green)' : 'var(--hts-muted)'; ?>"><?php echo $auto_on ? 'Activé' : 'Désactivé'; ?></span>
                <?php else : ?>
                <div style="display:flex;align-items:center;gap:8px;cursor:pointer" onclick="document.getElementById('hp-review-modal').style.display='flex'">
                    <span style="opacity:.5"><?php echo HTS_DS::toggle( false, '', 'hts-auto-toggle' ); ?></span>
                    <span style="font-size:13px;font-weight:600;color:var(--hts-orange)">Mode relecture actif</span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Days -->
        <div class="hp-cfg-section">
            <div class="cfg-label">Jours de publication</div>
            <div class="hp-days">
                <?php foreach($dl as $dv=>$dn): $day_on = in_array($dv, $as_days, false); ?>
                <button type="button" class="day-btn <?php echo $day_on ? 'on' : ''; ?>" onclick="this.classList.toggle('on');var c=this.querySelector('input');c.checked=!c.checked">
                    <input type="checkbox" class="hts-auto-day" value="<?php echo $dv; ?>" <?php checked($day_on); ?>>
                    <?php echo esc_html($dn); ?>
                </button>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Time -->
        <div class="hp-cfg-section">
            <div class="cfg-label">1er article à</div>
            <div class="hp-cfg-time">
                <?php
                $time_options = array();
                for ( $h = 6; $h <= 22; $h++ ) {
                    for ( $m = 0; $m < 60; $m += 30 ) {
                        $tv = sprintf( '%02d:%02d', $h, $m );
                        $time_options[ $tv ] = $tv;
                    }
                }
                echo HTS_DS::select( $time_options, $as_time, array( 'id' => 'hts-auto-time' ) );
                ?>
            </div>
        </div>

        <!-- Articles par jour -->
        <div class="hp-cfg-section" style="position:relative">
            <div class="cfg-label">Articles / jour</div>
            <?php
            $cur_mpd = (int) ( $auto_cfg['max_per_day'] ?? 1 );
            echo HTS_DS::select(
                array( '1' => '1', '2' => '2', '3' => '3' ),
                (string) $cur_mpd,
                array( 'id' => 'hts-auto-mpd' )
            );
            ?>
            <div id="hp-slots-preview" style="position:absolute;top:100%;left:0;white-space:nowrap;font-size:10px;color:var(--hts-text-3);margin-top:4px"></div>
        </div>

        <?php echo HTS_DS::button( 'Enregistrer', 'success', 'sm', array( 'onclick' => 'htsSaveCfg()' ) ); ?>
        <span id="hp-cfg-st" style="font-size:11px"></span>
    </div>
</div>

<!-- Review mode modal (blocks auto-pub when agent is in review mode) -->
<div id="hp-review-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.4);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
    <div style="background:#fff;border-radius:var(--hts-radius,12px);padding:32px;max-width:440px;width:90%;box-shadow:0 12px 40px rgba(0,0,0,.15);text-align:center">
        <div style="margin-bottom:16px"><?php echo HTS_DS::icon( 'shield', 48, 'var(--hts-caution)' ); ?></div>
        <div style="font-size:18px;font-weight:700;color:var(--hts-text);margin-bottom:8px">Agent en mode relecture</div>
        <div style="font-size:13px;color:var(--hts-text-2);line-height:1.6;max-width:340px;margin:0 auto 24px">
            L&#39;auto-publication nécessite que l&#39;agent soit en <strong>mode automatique</strong>.
            Actuellement, chaque article doit être approuvé manuellement avant publication.
        </div>
        <div style="display:flex;gap:8px;justify-content:center">
            <?php echo HTS_DS::button( 'Annuler', 'default', 'sm', array( 'onclick' => "document.getElementById('hp-review-modal').style.display='none'" ) ); ?>
            <a href="<?php echo admin_url('admin.php?page=hts-api-settings&stab=agents'); ?>" style="text-decoration:none;display:inline-block"><?php echo HTS_DS::button( 'Configurer l\'agent', 'geo', 'sm' ); ?></a>
        </div>
    </div>
</div>

<!-- ═══════ MAIN: Calendar + Articles Sidebar ═══════ -->
<?php
$_plan_can_schedule = ! class_exists( 'HTS_Subscription' ) || HTS_Subscription::can( 'auto_write' );
?>
<div class="hp-layout">
    <!-- CALENDAR -->
    <div class="hp-cal-card" style="<?php echo ! $_plan_can_schedule ? 'position:relative;' : ''; ?>">
    <?php if ( ! $_plan_can_schedule ) : ?>
    <div style="position:absolute;inset:0;z-index:10;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.6);backdrop-filter:blur(6px);border-radius:12px">
        <div style="text-align:center;padding:30px;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.1);max-width:340px">
            <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#6366f1);display:flex;align-items:center;justify-content:center;margin:0 auto 12px"><?php echo HTS_DS::icon( 'calendar', 24, '#fff' ); ?></div>
            <div style="font-size:16px;font-weight:700;color:var(--hts-text);margin-bottom:6px">Planifiez automatiquement</div>
            <div style="font-size:13px;color:var(--hts-text-2);line-height:1.5;margin-bottom:16px">Glissez vos articles sur le calendrier et laissez l'IA publier au meilleur moment.</div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-api-settings&stab=plans' ) ); ?>" style="display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:13px;font-weight:700;text-decoration:none"><?php echo HTS_DS::icon( 'zap', 14, '#fff' ); ?> Voir les offres à partir de 99€/mois</a>
        </div>
    </div>
    <?php endif; ?>
        <div class="hp-cal-head">
            <div class="hp-cal-nav">
                <a href="<?php echo esc_url( add_query_arg( 'hts_month', $prev_month, $page_url ) ); ?>" title="Mois précédent">‹</a>
                <?php if ( ! $is_current_month ) : ?>
                <a href="<?php echo esc_url( $page_url ); ?>" class="today-btn" title="Revenir à aujourd'hui">Aujourd'hui</a>
                <?php endif; ?>
                <a href="<?php echo esc_url( add_query_arg( 'hts_month', $next_month, $page_url ) ); ?>" title="Mois suivant">›</a>
            </div>
            <h3><?php echo esc_html( $month_fr[ (int) $cal_start->format('n') ] . ' ' . $cal_start->format('Y') ); ?></h3>
            <span style="font-size:9px;color:var(--hts-muted)">Glisser un article sur un jour</span>
        </div>
        <div class="hp-cal">
            <div class="hp-cal-grid">
                <?php foreach($dl as $day_label): ?><div class="c-head"><?php echo $day_label; ?></div><?php endforeach; ?>
                <?php
                $first_dow = (int) $cal_start->format( 'N' );
                $days_in   = (int) $cal_start->format( 't' );
                for ( $pad = 1; $pad < $first_dow; $pad++ ) {
                    $prev = $cal_start->modify( '-' . ( $first_dow - $pad ) . ' days' );
                    echo '<div class="c-day other"><span class="c-num">' . $prev->format('j') . '</span></div>';
                }
                for ( $d = 1; $d <= $days_in; $d++ ) {
                    $dt  = $cal_start->modify( '+' . ( $d - 1 ) . ' days' );
                    $dk  = $dt->format( 'Y-m-d' );
                    $cls = '';
                    $is_past = $dk < $today->format( 'Y-m-d' );
                    if ( $dk === $today->format( 'Y-m-d' ) ) $cls .= ' today';
                    if ( ! empty( $by_day[ $dk ] ) ) {
                        $has_pub = false; $has_fut = false;
                        foreach ( $by_day[ $dk ] as $_sp ) {
                            if ( $_sp->post_status === 'publish' ) $has_pub = true;
                            else $has_fut = true;
                        }
                        if ( $has_pub ) $cls .= ' has-publish';
                        elseif ( $has_fut ) $cls .= ' has-future';
                    }
                    if ( $is_past ) $cls .= ' past';
                    $dow_n = (int) $dt->format( 'N' );
                    $is_auto_day = $auto_on && in_array( $dow_n, $as_days, false );
                    echo '<div class="c-day' . $cls . '" data-date="' . esc_attr( $dk ) . '"';
                    if ( ! $is_past ) {
                        echo ' ondragover="event.preventDefault();this.classList.add(\'drop-over\')"';
                        echo ' ondragleave="this.classList.remove(\'drop-over\')"';
                        echo ' ondrop="this.classList.remove(\'drop-over\');htsDrop(event,this)"';
                    }
                    echo '>';
                    echo '<span class="c-num">' . $d . '</span>';
                    if ( $is_auto_day ) echo '<span class="c-auto-dot" title="Auto-pub"></span>';
                    if ( ! empty( $by_day[ $dk ] ) ) {
                        foreach ( $by_day[ $dk ] as $sp ) {
                            $st_cls = $sp->post_status === 'publish' ? 'st-publish' : 'st-future';
                            $edit_url = get_edit_post_link( $sp->ID, 'raw' );
                            // GSC clicks for published articles
                            $gsc_badge = '';
                            if ( $sp->post_status === 'publish' ) {
                                $clicks = (int) get_post_meta( $sp->ID, '_hts_gsc_clicks', true );
                                if ( $clicks > 0 ) {
                                    $gsc_badge = '<span class="c-gsc">' . $clicks . ' clic' . ( $clicks > 1 ? 's' : '' ) . '</span>';
                                }
                            }
                            echo '<div class="c-post ' . $st_cls . '" title="' . esc_attr( $sp->post_title ) . '" data-pid="' . (int) $sp->ID . '" data-href="' . esc_attr( $edit_url ) . '" data-title="' . esc_attr( $sp->post_title ) . '" data-date="' . esc_attr( $dk ) . '" onclick="htsCPostClick(event,this)" style="cursor:pointer">';
                            echo '<span class="c-time">' . esc_html( mysql2date( 'H:i', $sp->post_date, false ) ) . '</span> ' . esc_html( mb_substr( $sp->post_title, 0, 14 ) );
                            echo $gsc_badge;
                            if ( $sp->post_status === 'future' ) {
                                echo '<span class="c-unsched" onclick="event.stopPropagation();htsUnschedule(' . (int) $sp->ID . ',this.parentNode)" title="Modifier dans l&#39;éditeur">' . HTS_DS::icon( 'gear', 8, 'var(--hts-text-3)' ) . '</span>';
                            }
                            echo '</div>';
                        }
                    }
                    echo '</div>';
                }
                $last_dow = (int) $cal_end->format( 'N' );
                for ( $pad = $last_dow + 1; $pad <= 7; $pad++ ) {
                    $next = $cal_end->modify( '+' . ( $pad - $last_dow ) . ' days' );
                    echo '<div class="c-day other"><span class="c-num">' . $next->format('j') . '</span></div>';
                }
                ?>
            </div>
        </div>
    </div>

    <!-- SIDEBAR: Articles prêts -->
    <div class="hp-side">
        <div class="hp-side-h">
            <h3>À planifier <span class="s-count">(<?php echo $n_ready; ?>)</span></h3>
            <?php if($n_ready>1): echo HTS_DS::button( 'Tout valider', 'geo', 'sm', array( 'onclick' => 'htsValidateAll()' ) ); endif; ?>
        </div>
        <div class="hp-side-scroll">
        <?php if($n_ready): foreach($ready as $ra):
            $is_complete = $ra['has_img'] && $ra['words'] >= 100;
            $score_color = $ra['score'] >= 70 ? 'var(--hts-success)' : ( $ra['score'] >= 40 ? 'var(--hts-caution)' : 'var(--hts-danger)' );
        ?>
        <div class="hp-row<?php echo $is_complete ? '' : ' incomplete'; ?>" id="pr-<?php echo (int)$ra['id']; ?>" draggable="<?php echo $is_complete ? 'true' : 'false'; ?>" data-pid="<?php echo (int)$ra['id']; ?>" data-title="<?php echo esc_attr($ra['title']); ?>">
            <?php if($ra['img']): ?>
                <img class="r-img" src="<?php echo esc_url($ra['img']); ?>" alt="">
            <?php else: ?>
                <div class="r-ph" title="Image à la une manquante">
                    <?php echo HTS_DS::icon( 'alert', 11, 'var(--hts-caution)' ); ?>
                </div>
            <?php endif; ?>
            <div class="r-info">
                <div class="r-t"><a href="<?php echo esc_url($ra['edit']); ?>" target="_blank"><?php echo esc_html(mb_substr($ra['title'],0,36)); ?></a></div>
                <div class="r-m">
                    <?php if ( $ra['score'] > 0 ) : ?>
                    <span style="color:<?php echo $score_color; ?>;font-weight:700"><?php echo $ra['score']; ?></span>
                    <?php endif; ?>
                    <span><?php echo number_format($ra['words']); ?> mots</span>
                    <?php if( ! $ra['has_img'] ): ?>
                    <span class="warn">sans image</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="r-act">
                <?php if( ! $is_complete ): ?>
                <a href="<?php echo esc_url($ra['edit']); ?>" target="_blank" class="hb gh" style="font-size:8px;padding:2px 5px;color:var(--hts-caution);border-color:var(--hts-caution-light,#fde68a);background:none;box-shadow:none" title="Compléter cet article">Compléter</a>
                <?php elseif($ra['approved']): ?>
                <button class="hb ap" onclick="htsApprove(<?php echo (int)$ra['id']; ?>,0,this)">✓</button>
                <?php else: ?>
                <button class="hb gh" onclick="htsApprove(<?php echo (int)$ra['id']; ?>,1,this)">Valider</button>
                <?php endif; ?>
                <button class="hb rm" onclick="htsRemove(<?php echo (int)$ra['id']; ?>,this)">×</button>
            </div>
        </div>
        <?php endforeach; else: ?>
        <div style="text-align:center;padding:20px;color:var(--hts-muted);font-size:10px">Tous planifiés ✓</div>
        <?php endif; ?>
        </div>
        <div class="hp-side-foot">
            <a href="<?php echo admin_url('admin.php?page=hts-cocon-commander&tab=redaction'); ?>" style="display:block;width:100%;padding:10px;border-radius:var(--hts-radius-sm,8px);border:1.5px dashed var(--hts-border);background:transparent;font-size:12px;font-weight:600;color:var(--hts-text-3);text-decoration:none;text-align:center;box-shadow:none"><?php echo HTS_DS::icon( 'plus', 12, 'var(--hts-text-3)' ); ?> Ajouter des articles</a>
        </div>
    </div>
</div>

<!-- ═══════ EXPANDABLE: 12-week chart ═══════ -->
<div class="hp-drawer">
    <div class="hp-drawer-toggle" onclick="this.parentElement.classList.toggle('open')">
        <h4>Rythme de publication</h4>
        <span class="dt-meta"><?php echo $wk_avg; ?> articles/sem. · <span style="color:<?php echo $trend === 'up' ? 'var(--hts-success)' : ( $trend === 'down' ? 'var(--hts-danger)' : 'var(--hts-muted)' ); ?>"><?php echo $trend_icon; ?> <?php echo $trend === 'up' ? 'en hausse' : ( $trend === 'down' ? 'en baisse' : 'stable' ); ?></span></span>
        <span class="dt-arrow">▾</span>
    </div>
    <div class="hp-drawer-body">
        <div class="hp-bars" style="position:relative">
            <?php foreach ( $wk_vals as $i => $v ) :
                $h = $wk_max > 0 ? round( ( $v / $wk_max ) * 100 ) : 0;
            ?>
            <div class="hb-col">
                <div class="hb-val"><?php echo $v; ?></div>
                <div class="hb-bar" style="height:<?php echo max( 3, $h ); ?>%"></div>
                <div class="hb-lbl"><?php echo esc_html( $wk_labels[ $i ] ); ?></div>
            </div>
            <?php endforeach; ?>
            <div class="hp-ma-line">
                <svg viewBox="0 0 1200 640" preserveAspectRatio="none">
                    <polyline fill="none" stroke="<?php echo $reg_color; ?>" stroke-width="2.5" stroke-dasharray="5,3" opacity=".5" points="<?php
                        $wk_ma = array();
                        for ( $i = 0; $i < 12; $i++ ) {
                            $window = array_slice( $wk_vals, max( 0, $i - 3 ), min( 4, $i + 1 ) );
                            $wk_ma[] = count( $window ) ? array_sum( $window ) / count( $window ) : 0;
                        }
                        $pts = array();
                        foreach ( $wk_ma as $i => $ma ) {
                            $x = round( ( $i + 0.5 ) / 12 * 1200 );
                            $y = $wk_max > 0 ? round( 640 - ( $ma / $wk_max ) * 640 ) : 640;
                            $pts[] = "$x,$y";
                        }
                        echo implode( ' ', $pts );
                    ?>"/>
                </svg>
            </div>
        </div>
        <div class="hp-chart-footer">
            <span>12 dernières semaines</span>
            <span class="hp-cf-val"><?php echo $wk_avg; ?> articles/sem.</span>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Toast — same pattern as Cockpit/Inbox -->
<div id="hts-plan-toast" style="display:none;position:fixed;bottom:24px;right:24px;z-index:99998;min-width:280px;max-width:400px;background:#fff;border-radius:10px;box-shadow:0 8px 30px rgba(0,0,0,.15);border-left:4px solid var(--hts-success);padding:14px 18px;transition:opacity .3s,transform .3s;transform:translateY(20px);opacity:0;">
    <div style="display:flex;align-items:flex-start;gap:10px;">
        <span id="hts-plan-toast-icon" style="font-size:16px;line-height:1"><?php echo HTS_DS::icon( 'check', 16, 'var(--hts-success)' ); ?></span>
        <div style="flex:1;">
            <div id="hts-plan-toast-title" style="font-size:13px;font-weight:700;color:var(--hts-text);"></div>
            <div id="hts-plan-toast-msg" style="font-size:11px;color:var(--hts-text-3);margin-top:2px;"></div>
        </div>
        <button type="button" onclick="htsHideToast()" style="border:none;background:transparent;cursor:pointer;color:var(--hts-text-3);font-size:14px;">&#10005;</button>
    </div>
</div>

<!-- Time picker popup (appears after drop or click on scheduled article) -->
<div id="hts-time-popup" style="display:none;position:fixed;z-index:99997;background:#fff;border-radius:var(--hts-radius,12px);box-shadow:0 8px 30px rgba(0,0,0,.18);padding:20px 24px;min-width:300px;">
    <div style="font-size:14px;font-weight:700;color:var(--hts-text);margin-bottom:4px;" id="hts-tp-title"></div>
    <div style="font-size:11px;color:var(--hts-text-3);margin-bottom:16px;" id="hts-tp-date-label"></div>
    <div style="display:flex;gap:10px;align-items:center;margin-bottom:12px;">
        <label style="font-size:12px;font-weight:600;color:var(--hts-text-2,#475569);min-width:40px">Jour :</label>
        <input type="date" id="hts-tp-date" min="<?php echo $today->format('Y-m-d'); ?>" style="flex:1;padding:7px 10px;border:1px solid var(--hts-border,#e5e7eb);border-radius:var(--hts-radius-sm,8px);font-size:13px;font-family:var(--hts-font,inherit);color:var(--hts-text)">
    </div>
    <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;">
        <label style="font-size:12px;font-weight:600;color:var(--hts-text-2,#475569);min-width:40px">Heure :</label>
        <?php echo HTS_DS::select( $time_options, $as_time, array( 'id' => 'hts-tp-time', 'style' => 'flex:1' ) ); ?>
    </div>
    <div style="display:flex;gap:6px;justify-content:flex-end;">
        <?php echo HTS_DS::button( 'Annuler', 'default', 'sm', array( 'onclick' => 'htsCloseTimePicker()' ) ); ?>
        <?php echo HTS_DS::button( 'Planifier', 'geo', 'sm', array( 'id' => 'hts-tp-confirm', 'onclick' => 'htsConfirmSchedule()' ) ); ?>
    </div>
</div>
<div id="hts-tp-overlay" style="display:none;position:fixed;inset:0;z-index:99996;background:rgba(0,0,0,.4);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)" onclick="htsCloseTimePicker()"></div>
</div>

<script>
(function(){
// ─── Sync sidebar max-height with calendar ───
var _cal=document.querySelector('.hp-cal-card'),_side=document.querySelector('.hp-side');
if(_cal&&_side){_side.style.maxHeight=_cal.offsetHeight+'px'}

var A='<?php echo esc_js($ajax_url); ?>',N='<?php echo esc_js($nonce); ?>';
function P(a,d){var f=new FormData;f.append('action',a);f.append('nonce',N);Object.keys(d).forEach(function(k){var v=d[k];if(Array.isArray(v))v.forEach(function(i){f.append(k+'[]',i)});else f.append(k,v)});return fetch(A,{method:'POST',body:f}).then(function(r){return r.json()})}
// Toast — planning-specific (uses #hts-plan-toast to avoid conflict with cockpit/DS)
window.htsShowToast=function(title,msg,link,isError){
    var t=document.getElementById('hts-plan-toast');if(!t)return;
    t.style.borderLeftColor=isError?'var(--hts-danger)':'var(--hts-success)';
    document.getElementById('hts-plan-toast-title').textContent=title;
    document.getElementById('hts-plan-toast-msg').textContent=msg||'';
    t.style.display='block';
    setTimeout(function(){t.style.opacity='1';t.style.transform='translateY(0)';},10);
    clearTimeout(window._htsPlanToastTimer);
    window._htsPlanToastTimer=setTimeout(function(){htsHideToast()},5000);
};
window.htsHideToast=function(){
    var t=document.getElementById('hts-plan-toast');if(!t)return;
    t.style.opacity='0';t.style.transform='translateY(20px)';
    setTimeout(function(){t.style.display='none'},300);
};
function T(m,ok){htsShowToast(ok?'Succès':'Erreur',m,null,!ok)}

document.querySelectorAll('.hp-row[draggable="true"]').forEach(function(el){
    el.addEventListener('dragstart',function(e){e.dataTransfer.setData('text/plain',el.dataset.pid);el.style.opacity='.4'});
    el.addEventListener('dragend',function(){el.style.opacity='1'});
});

// ─── Time picker popup ───
var _tp={pid:0,date:'',day:null,row:null,title:'',sourceEl:null};

window.htsDrop=function(e,day){
    e.preventDefault();day.classList.remove('drop-over');
    var pid=parseInt(e.dataTransfer.getData('text/plain'),10),date=day.dataset.date;
    if(!pid||!date)return;
    var row=document.getElementById('pr-'+pid);
    _tp={pid:pid,date:date,day:day,row:row,title:row?row.dataset.title:'Article',sourceEl:null};
    htsOpenTimePicker(day);
};

function htsOpenTimePicker(anchor){
    var popup=document.getElementById('hts-time-popup'),ov=document.getElementById('hts-tp-overlay');
    document.getElementById('hts-tp-title').textContent=_tp.title.substring(0,50);
    document.getElementById('hts-tp-date-label').textContent=_tp.sourceEl?'Replanifier cet article':'Planifier sur le calendrier';
    document.getElementById('hts-tp-date').value=_tp.date;
    var sel=document.getElementById('hts-tp-time');
    sel.value='<?php echo esc_js($as_time); ?>';
    var r=anchor.getBoundingClientRect();
    popup.style.top=Math.min(r.bottom+4,window.innerHeight-280)+'px';
    popup.style.left=Math.min(r.left,window.innerWidth-320)+'px';
    popup.style.display='block';ov.style.display='block';
}
window.htsCloseTimePicker=function(){
    document.getElementById('hts-time-popup').style.display='none';
    document.getElementById('hts-tp-overlay').style.display='none';
    _tp={pid:0,date:'',day:null,row:null,title:'',sourceEl:null};
};
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&document.getElementById('hts-time-popup').style.display==='block')htsCloseTimePicker()});
window.addEventListener('scroll',function(){if(document.getElementById('hts-time-popup').style.display==='block')htsCloseTimePicker()},true);
window.htsConfirmSchedule=function(){
    var time=document.getElementById('hts-tp-time').value;
    var date=document.getElementById('hts-tp-date').value;
    if(!_tp.pid||!date){htsCloseTimePicker();return}
    var todayStr=new Date().toISOString().slice(0,10);
    if(date<todayStr){T('Impossible de planifier dans le pass\u00e9',false);return}
    var btn=document.getElementById('hts-tp-confirm');
    btn.disabled=true;btn.textContent='...';
    var dayChanged=(date!==_tp.date);
    var tmp=null;
    if(!dayChanged){tmp=document.createElement('div');tmp.className='c-post temp';tmp.textContent=time+' '+_tp.title.substring(0,14)+'\u2026';if(_tp.day)_tp.day.appendChild(tmp)}
    var pid=_tp.pid,row=_tp.row,title=_tp.title,day=_tp.day,srcEl=_tp.sourceEl||null;
    P('hts_calendar_schedule',{post_id:pid,date:date,time:time+':00'}).then(function(r){
        btn.disabled=false;btn.textContent='Planifier';
        if(r.success&&r.data&&r.data.verified){
            if(srcEl){srcEl.remove()}
            if(dayChanged){T('Planifi\u00e9 le '+date+' \u00e0 '+time,true);htsCloseTimePicker();setTimeout(function(){location.reload()},800);return}
            if(tmp){tmp.className='c-post st-future';tmp.textContent=time+' '+title.substring(0,14);tmp.dataset.pid=pid;tmp.dataset.title=title;tmp.dataset.date=date;tmp.dataset.href='<?php echo admin_url("post.php?action=edit&post="); ?>'+pid;tmp.setAttribute('onclick','htsCPostClick(event,this)');}
            if(day)day.classList.add('has-future');
            T('Planifi\u00e9 le '+date+' \u00e0 '+time,true);
            if(row){row.style.transition='all .3s';row.style.opacity='0';row.style.maxHeight='0';row.style.padding='0';row.style.overflow='hidden';setTimeout(function(){row.remove()},300)}
            htsCloseTimePicker();
        }else{if(tmp)tmp.remove();T(typeof r.data==='string'?r.data:'Erreur',false);htsCloseTimePicker()}
    }).catch(function(){if(tmp)tmp.remove();T('Erreur r\u00e9seau',false);btn.disabled=false;btn.textContent='Planifier';htsCloseTimePicker()});
};
window.htsApprove=function(pid,ap,btn){btn.disabled=true;P('hts_toggle_schedule_approval',{post_ids:[pid],approved:ap}).then(function(r){if(r.success){if(ap){btn.className='hb ap';btn.textContent='\u2713';btn.onclick=function(){htsApprove(pid,0,btn)};var d=r.data||{};if(d.scheduled&&d.scheduled.length){var s=d.scheduled[0];T('Planifi\u00e9 le '+s.date_fr,true);var row=document.getElementById('pr-'+pid);if(row){row.style.transition='all .3s';row.style.opacity='.4';setTimeout(function(){row.remove()},2000)}}else{T('Valid\u00e9 \u2014 sera planifi\u00e9 au prochain cr\u00e9neau',true)}}else{btn.className='hb gh';btn.textContent='Valider';btn.onclick=function(){htsApprove(pid,1,btn)};T('Retir\u00e9',true)}btn.disabled=false}else{btn.disabled=false;T('Erreur',false)}}).catch(function(){btn.disabled=false})};

window.htsValidateAll=function(){var rows=document.querySelectorAll('.hp-row:not(.incomplete)'),pids=[];rows.forEach(function(r){var b=r.querySelector('.hb.gh');if(b)pids.push(parseInt(r.dataset.pid,10))});if(!pids.length){T('Aucun article complet \u00e0 valider',false);return}P('hts_toggle_schedule_approval',{post_ids:pids,approved:1}).then(function(r){if(r.success){var d=r.data||{};var sc=d.scheduled?d.scheduled.length:0;rows.forEach(function(row){var b=row.querySelector('.hb.gh');if(b){b.className='hb ap';b.textContent='\u2713';var pid=parseInt(row.dataset.pid,10);b.onclick=function(){htsApprove(pid,0,b)}}});if(sc>0){T(sc+' planifi\u00e9(s) imm\u00e9diatement, '+(pids.length-sc)+' en attente',true);setTimeout(function(){location.reload()},1500)}else{T(pids.length+' valid\u00e9(s) \u2014 planification au prochain cr\u00e9neau',true)}}else T('Erreur',false)}).catch(function(){T('Erreur',false)})};

window.htsRemove=function(pid,btn){_htsConfirm('Retirer cet article ?','L\u0027article restera en brouillon mais sera retiré de la planification.','Retirer','danger').then(function(ok){if(!ok)return;btn.disabled=true;P('hts_toggle_schedule_approval',{post_ids:[pid],approved:0}).then(function(){var row=document.getElementById('pr-'+pid);if(row){row.style.transition='all .3s';row.style.opacity='0';row.style.maxHeight='0';row.style.padding='0';row.style.overflow='hidden';setTimeout(function(){row.remove()},300)}T('Retir\u00e9',true)}).catch(function(){btn.disabled=false})})};

window.htsAutoToggle=function(){var tgl=document.getElementById('hts-auto-toggle');if(tgl){tgl.classList.toggle('hts-ds-toggle--on')}htsSaveCfg();setTimeout(function(){location.reload()},800)};
window.htsSaveCfg=function(){var days=[];document.querySelectorAll('.hts-auto-day:checked').forEach(function(c){days.push(c.value)});var time=(document.getElementById('hts-auto-time')||{}).value||'09:00',mpd=(document.getElementById('hts-auto-mpd')||{}).value||'1',tgl=document.getElementById('hts-auto-toggle'),en=tgl&&tgl.classList.contains('hts-ds-toggle--on'),st=document.getElementById('hp-cfg-st');if(st){st.textContent='\u2026';st.style.color='var(--hts-indigo)'}P('hts_save_auto_schedule',{enabled:en?'1':'0',days:days.join(','),time:time,max_per_day:mpd,min_gap_hours:mpd>1?2:4}).then(function(r){if(r.success){if(st){st.textContent='OK';st.style.color='var(--hts-success)'}T('Sauvegard\u00e9',true)}else{if(st){st.textContent='Erreur';st.style.color='var(--hts-danger)'}}}).catch(function(){if(st){st.textContent='Erreur';st.style.color='var(--hts-danger)'}})}

window.htsSaveGoal=function(){var val=parseInt(document.getElementById('hp-goal-val').value,10);if(!val||val<1||val>100){T('Valeur entre 1 et 100',false);return}P('hts_save_monthly_goal',{goal:val}).then(function(r){if(r.success){T('Objectif mis \u00e0 jour',true);setTimeout(function(){location.reload()},600)}else T('Erreur',false)}).catch(function(){T('Erreur',false)})};

// ─── Auto-pub slots preview ───
function htsUpdateSlots(){
    var timeEl=document.getElementById('hts-auto-time'),mpdEl=document.getElementById('hts-auto-mpd'),prev=document.getElementById('hp-slots-preview');
    if(!timeEl||!mpdEl||!prev)return;
    var mpd=parseInt(mpdEl.value,10)||1,base=timeEl.value||'09:00';
    if(mpd<=1){prev.textContent='';return}
    var parts=base.split(':'),h=parseInt(parts[0],10),m=parseInt(parts[1],10);
    var maxH=22,available=maxH-h;
    if(available<(mpd-1)*2){prev.textContent='Heure trop tardive pour '+mpd+' articles. Choisissez une heure plus t\u00f4t.';prev.style.color='var(--hts-danger)';return}
    prev.style.color='var(--hts-text-3)';
    var gap=Math.max(2,Math.floor(available/(mpd-1)));
    var slots=[base],ch=h;
    for(var i=1;i<mpd;i++){ch+=gap;slots.push(String(ch).padStart(2,'0')+':'+String(m).padStart(2,'0'))}
    prev.textContent=slots.join(', ')+' (espacement '+gap+'h)';
}
var _atEl=document.getElementById('hts-auto-time'),_mpdEl=document.getElementById('hts-auto-mpd');
if(_atEl)_atEl.addEventListener('change',htsUpdateSlots);
if(_mpdEl)_mpdEl.addEventListener('change',htsUpdateSlots);
htsUpdateSlots();

// ─── Calendar post click: future → replan popup, publish → edit ───
window.htsCPostClick=function(e,el){
    if(el.classList.contains('st-publish')){window.open(el.dataset.href,'_blank');return}
    var pid=parseInt(el.dataset.pid,10),date=el.dataset.date,day=el.closest('.c-day');
    if(!pid||!date)return;
    _tp={pid:pid,date:date,day:day,row:null,title:el.dataset.title||'Article',sourceEl:el};
    htsOpenTimePicker(day);
};
// ─── Unschedule: opens WP editor where user can change status safely ───
// NOTE: a backend endpoint hts_calendar_unschedule (draft revert) is needed for inline unschedule
window.htsUnschedule=function(pid,postEl){
    var href=postEl.dataset?postEl.dataset.href:'';
    if(href){window.open(href,'_blank')}else{window.open('<?php echo admin_url("post.php?action=edit&post="); ?>'+pid,'_blank')}
};
})();
</script>
<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>
