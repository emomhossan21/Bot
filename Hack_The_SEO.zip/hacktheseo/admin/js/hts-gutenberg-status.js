/**
 * HTS SEO Status Widget — Gutenberg Post Status Info
 *
 * Lightweight widget in the sidebar "Article" panel showing:
 * - Score ring + label
 * - Focus keyword + word count
 * - Top 3 issues with fix advice (click to expand)
 * - "Voir le panneau SEO ↓" anchor link
 *
 * Uses PluginPostStatusInfo (stable API, no sidebar registration needed).
 * Zero build step — pure createElement.
 *
 * @since 1.6.0
 */
(function () {
    'use strict';

    if (typeof wp === 'undefined' || !wp.element || !wp.plugins) return;

    var el = wp.element.createElement;
    var useState = wp.element.useState;
    var useEffect = wp.element.useEffect;
    var registerPlugin = wp.plugins.registerPlugin;

    /* PluginPostStatusInfo: try wp.editor first (Gutenberg 16+), fallback wp.editPost */
    var _ed = (wp.editor || {});
    var _ep = (wp.editPost || {});
    var PluginPostStatusInfo = _ed.PluginPostStatusInfo || _ep.PluginPostStatusInfo;

    if (!PluginPostStatusInfo || !registerPlugin) return;

    var cfg = window.htsSidebar || {};

    function scoreColor(s) {
        if (s >= 80) return '#16a34a';
        if (s >= 50) return '#d97706';
        return '#dc2626';
    }
    function scoreLabel(s) {
        if (s >= 80) return 'Excellent';
        if (s >= 60) return 'Bon';
        if (s >= 40) return 'Moyen';
        return 'Faible';
    }
    function dotColor(status) {
        return status === 'fail' ? '#dc2626' : '#d97706';
    }

    /* Single issue row with expandable fix */
    function IssueRow(props) {
        var _s = useState(false);
        var open = _s[0], setOpen = _s[1];
        var item = props.item;

        return el('div', { style: { borderTop: '1px solid #f3f4f6', padding: '5px 0' } },
            el('div', {
                style: {
                    display: 'flex', alignItems: 'flex-start', gap: 6,
                    cursor: item.fix ? 'pointer' : 'default'
                },
                onClick: function () { if (item.fix) setOpen(!open); }
            },
                el('span', {
                    style: {
                        width: 6, height: 6, borderRadius: '50%',
                        background: dotColor(item.status),
                        flexShrink: 0, marginTop: 5
                    }
                }),
                el('span', {
                    style: { fontSize: 12, color: '#374151', flex: 1, lineHeight: '1.35' }
                }, item.text),
                item.fix ? el('span', {
                    style: {
                        fontSize: 11, color: '#2563eb', flexShrink: 0,
                        opacity: 0.6, transition: 'transform .15s',
                        transform: open ? 'rotate(90deg)' : 'none'
                    }
                }, '\u25b8') : null
            ),
            open && item.fix ? el('div', {
                style: {
                    fontSize: 11, color: '#6b7280', lineHeight: '1.4',
                    margin: '4px 0 2px 12px', padding: '4px 8px',
                    background: '#f9fafb', borderRadius: 4,
                    borderLeft: '2px solid #2563eb'
                }
            }, '\u2192 ' + item.fix) : null
        );
    }

    function HTSStatusWidget() {
        var _s = useState(null);
        var data = _s[0], setData = _s[1];

        /* Listen for score updates from metabox */
        useEffect(function () {
            function onUpdate(e) {
                if (e.detail) {
                    setData({
                        score: e.detail.score,
                        kw: e.detail.debug ? e.detail.debug.kw : '',
                        words: e.detail.debug ? e.detail.debug.words : 0,
                        issues: e.detail.issues,
                        top_fixes: e.detail.top_fixes || []
                    });
                }
            }
            document.addEventListener('hts:score-updated', onUpdate);

            /* Also try initial fetch */
            if (cfg.ajaxUrl && cfg.postId) {
                var fd = new FormData();
                fd.append('action', 'hts_panel_score');
                fd.append('nonce', cfg.nonce);
                fd.append('post_id', cfg.postId);
                var xhr = new XMLHttpRequest();
                xhr.open('POST', cfg.ajaxUrl, true);
                xhr.onload = function () {
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) {
                            setData({
                                score: r.data.score,
                                kw: r.data.debug ? r.data.debug.kw : '',
                                words: r.data.debug ? r.data.debug.words : 0,
                                issues: r.data.issues,
                                top_fixes: r.data.top_fixes || []
                            });
                        }
                    } catch (e) {}
                };
                xhr.send(fd);
            }

            return function () { document.removeEventListener('hts:score-updated', onUpdate); };
        }, []);

        var score = data ? data.score : null;
        var kw = data ? data.kw : '';
        var words = data ? data.words : 0;
        var issues = data ? data.issues : 0;
        var topFixes = data ? (data.top_fixes || []) : [];

        return el(PluginPostStatusInfo, { className: 'hts-status-widget' },
            /* Header row — clickable to scroll to panel */
            el('div', {
                style: {
                    display: 'flex', alignItems: 'center', gap: 12,
                    width: '100%', cursor: 'pointer'
                },
                onClick: function () {
                    var mb = document.getElementById('hts-seo-panel');
                    if (mb) mb.scrollIntoView({ behavior: 'smooth', block: 'start' });
                },
                title: 'Voir le panneau SEO complet'
            },
                /* Score ring */
                score !== null ? el('div', {
                    style: {
                        position: 'relative', width: 36, height: 36, flexShrink: 0
                    }
                },
                    el('svg', { width: 36, height: 36, style: { transform: 'rotate(-90deg)' } },
                        el('circle', { cx: 18, cy: 18, r: 14, fill: 'none', stroke: '#e5e7eb', strokeWidth: 3 }),
                        el('circle', {
                            cx: 18, cy: 18, r: 14, fill: 'none',
                            stroke: scoreColor(score), strokeWidth: 3, strokeLinecap: 'round',
                            strokeDasharray: 87.96,
                            strokeDashoffset: 87.96 - (87.96 * score / 100),
                            style: { transition: 'stroke-dashoffset 0.6s ease' }
                        })
                    ),
                    el('div', {
                        style: {
                            position: 'absolute', inset: 0,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: 11, fontWeight: 700, color: scoreColor(score)
                        }
                    }, score)
                ) : el('div', {
                    style: {
                        width: 36, height: 36, borderRadius: '50%',
                        background: '#f3f4f6', display: 'flex',
                        alignItems: 'center', justifyContent: 'center',
                        fontSize: 10, color: '#9ca3af'
                    }
                }, '...'),

                /* Info */
                el('div', { style: { flex: 1, minWidth: 0 } },
                    el('div', {
                        style: { fontSize: 13, fontWeight: 600, color: '#1a1f36', lineHeight: '1.3' }
                    }, 'Hack The SEO',
                        score !== null ? el('span', {
                            style: {
                                marginLeft: 6, fontSize: 11, fontWeight: 400,
                                color: scoreColor(score)
                            }
                        }, scoreLabel(score)) : null
                    ),
                    el('div', { style: { fontSize: 11, color: '#6b7280', marginTop: 1 } },
                        kw ? el('span', {
                            style: {
                                background: '#eff6ff', color: '#2563eb',
                                padding: '1px 6px', borderRadius: 8, fontSize: 10, fontWeight: 600
                            }
                        }, kw) : null,
                        words ? ' \u00b7 ' + words + ' mots' : '',
                        issues > 0 ? ' \u00b7 ' + issues + ' point' + (issues > 1 ? 's' : '') + ' \u00e0 am\u00e9liorer' : ''
                    )
                ),

                /* Arrow */
                el('span', {
                    style: { color: '#9ca3af', fontSize: 16, flexShrink: 0 }
                }, '\u2193')
            ),

            /* Top fixes list */
            topFixes.length > 0 ? el('div', {
                style: { width: '100%', marginTop: 6 }
            },
                topFixes.map(function (item, i) {
                    return el(IssueRow, { key: i, item: item });
                })
            ) : null
        );
    }

    /* Register — deferred via wp.domReady */
    function doRegister() {
        try {
            registerPlugin('hts-seo-status', {
                render: HTSStatusWidget
            });
        } catch (e) {
            console.warn('[HTS] Status widget registration failed:', e.message);
        }
    }

    if (wp.domReady) {
        wp.domReady(doRegister);
    } else {
        doRegister();
    }
})();
