<?php
/**
 * Hack The SEO — Dashboard (S1 v2 — DS v5.7)
 * Standalone partial — include from cockpit render() or directly.
 * 7 blocs: Hero ring+score, Google+IA cards, Actions, Groupes, Activité, Pipeline, Coach, Tech details
 *
 * Expected variables (set by caller):
 *   $modules, $nonce, $base_url, $inbox_count
 *   Or fetched here if not set.
 *
 * @since 2.6.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}

// ── Data (reuse cockpit data or fetch fresh) ──
global $wpdb;
$has_wf = class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist();
if ( ! isset( $nonce ) )     $nonce     = wp_create_nonce( 'hts_cockpit' );
if ( ! isset( $base_url ) )  $base_url  = admin_url( 'admin.php?page=hts-light-dashboard' );
if ( ! isset( $inbox_count ) ) {
	$inbox_count = 0;
	if ( $has_wf ) {
		$wf_stats    = HTS_Workflow_Engine::get_stats();
		$inbox_count = (int) ( $wf_stats['pending'] ?? 0 );
	}
}

// Auto-trigger first inbox scan if empty (new install)
if ( $inbox_count === 0 && $has_wf && ! get_transient( 'hts_first_scan_done' ) ) {
	if ( ! wp_next_scheduled( 'hts_inbox_first_scan' ) ) {
		wp_schedule_single_event( time() + 30, 'hts_inbox_first_scan' );
	}
	set_transient( 'hts_first_scan_done', 1, WEEK_IN_SECONDS );
}

// Score & stats via cockpit cache
$cockpit = class_exists( 'HTS_Cockpit' ) ? new HTS_Cockpit() : null;
$stats   = $cockpit ? $cockpit->get_heavy_stats() : array();


// Visibility score
$avg_score = (int) ( $stats['avg_score'] ?? 74 );
$total_articles = (int) ( $stats['total_articles'] ?? 0 );
$good = (int) ( $stats['score_good'] ?? 0 );
$mid  = (int) ( $stats['score_mid'] ?? 0 );
$bad  = (int) ( $stats['score_bad'] ?? 0 );

// First install detection: unscored posts
global $wpdb;
$_pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
$_unscored_count = (int) $wpdb->get_var(
    "SELECT COUNT(*) FROM {$wpdb->posts} p
     LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_combined_score'
     WHERE p.post_status = 'publish' AND p.post_type {$_pt_in} AND pm.meta_id IS NULL"
);
$_needs_initial_scan = $total_articles === 0 && $_unscored_count > 0;

// GSC & AI stats (via Impact Tracker for real data + sparklines)
$ana_data = array();
if ( class_exists( 'HTS_Impact_Tracker' ) ) {
	$tracker  = new HTS_Impact_Tracker();
	$ana_data = $tracker->get_analytics_data( 30 );
}
$ana_daily       = $ana_data['daily'] ?? array();
$ana_gsc         = $ana_data['gsc'] ?? null;
$ana_ai_total    = (int) ( $ana_data['ai_total'] ?? 0 );
$ana_ai_trend    = (float) ( $ana_data['ai_trend'] ?? 0 );
$ana_ai_sources  = $ana_data['ai_sources'] ?? array();
$ana_top_articles = $ana_data['top_articles'] ?? array();

// GSC fallback
$ana_gsc_connected = ( $ana_gsc !== null );
if ( ! $ana_gsc_connected ) {
	$ana_gsc = array( 'clicks' => 0, 'impressions' => 0, 'avg_position' => 0, 'avg_ctr' => 0 );
}

// Pad daily to 30 days
$padded = array();
for ( $i = 29; $i >= 0; $i-- ) {
	$key = gmdate( 'Y-m-d', strtotime( "-{$i} days" ) );
	$padded[ $key ] = array( 'day' => $key, 'total' => 0, 'ai' => 0 );
}
if ( ! empty( $ana_daily ) ) {
	foreach ( $ana_daily as $dd ) {
		if ( isset( $padded[ $dd['day'] ] ) ) {
			$padded[ $dd['day'] ] = $dd;
		}
	}
}
$ana_daily = array_values( $padded );
$gsc_spark = array();
if ( ! empty( $ana_gsc['daily'] ) ) {
	foreach ( $ana_gsc['daily'] as $gd ) {
		$gd = is_object( $gd ) ? (array) $gd : $gd;
		$gsc_spark[] = (int) ( $gd['clicks'] ?? 0 );
	}
} else {
	$gsc_spark = array_column( $ana_daily, 'total' );
}
$ai_spark  = array_column( $ana_daily, 'ai' );

// Inbox actions summary (lightweight aggregate — no per-action get_the_title)
$inbox_cards = array();
if ( $inbox_count > 0 && $has_wf ) {

	$wf_tbl = $wpdb->prefix . 'hts_workflow_actions';
	$rows = $wpdb->get_results(
		"SELECT type, agent, COUNT(*) AS cnt,
		        MAX(CASE WHEN priority = 'critical' THEN 4 WHEN priority = 'high' THEN 3 WHEN priority = 'medium' THEN 2 ELSE 1 END) AS prio_rank
		 FROM {$wf_tbl} WHERE status = 'pending'
		 GROUP BY type, agent
		 ORDER BY prio_rank DESC, cnt DESC"
	);
	if ( $rows ) {
		$al = HTS_Workflow_Engine::get_agent_labels();
		$tl = HTS_Workflow_Engine::get_action_labels();
		foreach ( $rows as $r ) {
			$prio_val = (int) $r->prio_rank;
			$inbox_cards[] = array(
				'type'         => $r->type,
				'agent'        => $r->agent,
				'agent_label'  => $al[ $r->agent ] ?? ucfirst( $r->agent ),
				'type_label'   => $tl[ $r->type ] ?? ucfirst( str_replace( '_', ' ', $r->type ) ),
				'count'        => (int) $r->cnt,
				'priority_max' => $prio_val >= 4 ? 'critical' : ( $prio_val >= 3 ? 'high' : ( $prio_val >= 2 ? 'medium' : 'low' ) ),
			);
		}
	}
}

// Agents status
$agents_active = 0;
if ( class_exists( 'HTS_Workflow_Engine' ) ) {
	$all_agents = HTS_Workflow_Engine::get_all_agents();
	foreach ( $all_agents as $a ) {
		if ( ! empty( $a['enabled'] ) ) $agents_active++;
	}
}

$is_positive = $avg_score >= 60;

// Health checks
$health_pct = 100;
if ( class_exists( 'HTS_Health_Check' ) ) {
	$health_summary = HTS_Health_Check::get_cockpit_summary();
	if ( $health_summary && isset( $health_summary['score'] ) ) {
		$health_pct = (int) $health_summary['score'];
	}
}

// ── Brand colors & logos (reused from analytics, guarded) ──
$src_colors = array(
	'chatgpt' => '#10A37F', 'claude' => '#D97757', 'perplexity' => '#20B8CD',
	'meta_ai' => '#0866FF', 'meta' => '#0866FF', 'gemini' => '#4285F4',
	'copilot' => '#7C3AED', 'you' => '#F97316', 'phind' => '#16A34A',
);
// ── Phase 4B: Shared helpers (ai_brands, logos, sparklines) ──
include_once __DIR__ . '/_helpers.php';
?>

<?php echo HTS_DS::page_open( true ); ?>

<style>
@keyframes htsPulse { 0%,100% { opacity:1 } 50% { opacity:.4 } }
@keyframes htsFadeIn { from { opacity:0; transform:translateY(6px) } to { opacity:1; transform:translateY(0) } }
@media(max-width:782px){
	.hts-ds-grid-3{grid-template-columns:1fr !important}
	.hts-dash-grid-2{grid-template-columns:1fr !important}
	#hts-dash-tech-body > div:first-child{grid-template-columns:repeat(2,1fr) !important}
	.hts-hero{flex-direction:column !important;text-align:center;padding:28px 20px 24px !important}
	.hts-hero > div:last-child{margin-top:16px}
	.hts-coach-chips{grid-template-columns:1fr !important}
}
</style>

<?php // ═══ BLOC 1 : Hero Banner — Score de visibilité ═══ ?>
<div class="hts-hero" style="display:flex;align-items:center;justify-content:space-between;position:relative;overflow:hidden;padding:36px 40px 32px">
	<div style="position:absolute;top:-40px;right:-20px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,<?php echo $is_positive ? 'rgba(0,210,106,.1)' : 'rgba(239,68,68,.1)'; ?> 0%,transparent 70%);pointer-events:none"></div>
	<div style="flex:1;z-index:1">
		<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
			<?php echo HTS_DS::dot( $is_positive ? 'ok' : 'fail', 8 ); ?>
			<span style="font-size:11px;font-weight:600;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:.08em">En ce moment</span>
		</div>
		<h1 class="hts-hero__title" style="font-size:34px;letter-spacing:-.04em;line-height:1.15">
			<?php echo $is_positive ? 'Votre site progresse.' : 'Votre site a besoin d&#039;attention.'; ?>
		</h1>
		<p class="hts-hero__sub" style="margin:10px 0 24px;line-height:1.6" id="hts-dash-sub">
			<?php echo $agents_active; ?> agents actifs. <?php echo $inbox_count; ?> actions en attente.
		</p>
		<div style="display:flex;gap:10px">
			<?php if ( $inbox_count > 0 ) : ?>
			<a href="<?php echo esc_url( $base_url . '&tab=inbox' ); ?>" style="display:flex;align-items:center;gap:8px;padding:11px 22px;border-radius:12px;border:none;background:#fff;color:var(--hts-text);font-size:13px;font-weight:700;text-decoration:none;font-family:var(--hts-font)">
				Voir mes <?php echo $inbox_count; ?> actions
			</a>
			<?php endif; ?>
			<a href="<?php echo esc_url( $base_url . '&tab=coach' ); ?>" style="display:flex;align-items:center;gap:8px;padding:11px 22px;border-radius:12px;border:none;background:var(--hts-geo);color:#fff;font-size:13px;font-weight:700;text-decoration:none;font-family:var(--hts-font)">
				<?php echo HTS_DS::icon( 'brain', 14, '#fff' ); ?> Coach IA
			</a>
		</div>
	</div>
	<div style="display:flex;flex-direction:column;align-items:center;gap:6px;z-index:1">
		<?php
		// Hero ring — white text for dark background (unlike DS ring which uses --hts-text)
		$hr_size = 96; $hr_sw = 6; $hr_r = ( $hr_size - $hr_sw ) / 2;
		$hr_ci = 2 * M_PI * $hr_r; $hr_off = $hr_ci * ( 1 - $avg_score / 100 );
		$hr_col = $avg_score >= 75 ? 'var(--hts-success)' : ( $avg_score >= 50 ? 'var(--hts-caution)' : 'var(--hts-danger)' );
		?>
		<svg width="<?php echo $hr_size; ?>" height="<?php echo $hr_size; ?>" style="transform:rotate(-90deg);flex-shrink:0">
			<circle cx="<?php echo $hr_size / 2; ?>" cy="<?php echo $hr_size / 2; ?>" r="<?php echo $hr_r; ?>" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="<?php echo $hr_sw; ?>"/>
			<circle cx="<?php echo $hr_size / 2; ?>" cy="<?php echo $hr_size / 2; ?>" r="<?php echo $hr_r; ?>" fill="none" stroke="<?php echo $hr_col; ?>" stroke-width="<?php echo $hr_sw; ?>" stroke-dasharray="<?php echo round( $hr_ci, 2 ); ?>" stroke-dashoffset="<?php echo round( $hr_off, 2 ); ?>" stroke-linecap="round"/>
			<text x="<?php echo $hr_size / 2; ?>" y="<?php echo $hr_size / 2; ?>" text-anchor="middle" dominant-baseline="central" style="transform:rotate(90deg);transform-origin:center;font-size:<?php echo round( $hr_size * 0.28 ); ?>px;font-weight:800;fill:#fff;font-family:var(--hts-font)"><?php echo $avg_score; ?></text>
		</svg>
		<span style="font-size:9px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.1em">Score de visibilité</span>
		<div style="display:flex;align-items:center;gap:8px;margin-top:6px">
			<span style="font-size:11px;color:rgba(255,255,255,.45)"><?php echo $total_articles; ?> articles</span>
			<span style="display:flex;align-items:center;gap:3px;font-size:10px;font-weight:700"><span style="width:5px;height:5px;border-radius:50%;background:var(--hts-success);display:inline-block"></span> <span style="color:rgba(255,255,255,.55)"><?php echo $good; ?></span></span>
			<span style="display:flex;align-items:center;gap:3px;font-size:10px;font-weight:700"><span style="width:5px;height:5px;border-radius:50%;background:var(--hts-caution);display:inline-block"></span> <span style="color:rgba(255,255,255,.55)"><?php echo $mid; ?></span></span>
			<span style="display:flex;align-items:center;gap:3px;font-size:10px;font-weight:700"><span style="width:5px;height:5px;border-radius:50%;background:var(--hts-danger);display:inline-block"></span> <span style="color:rgba(255,255,255,.55)"><?php echo $bad; ?></span></span>
		</div>
	</div>
</div>

<?php if ( $_needs_initial_scan ) : ?>
<!-- Initial scan banner -->
<div class="hts-ds-card" id="hts-initial-scan" style="margin-bottom:20px;padding:24px 28px;display:flex;align-items:center;gap:20px;border-left:4px solid var(--hts-geo)">
	<div style="width:48px;height:48px;border-radius:50%;background:var(--hts-geo-soft);display:flex;align-items:center;justify-content:center;flex-shrink:0">
		<?php echo HTS_DS::icon( 'zap', 24, 'var(--hts-geo)' ); ?>
	</div>
	<div style="flex:1">
		<div style="font-size:15px;font-weight:700;color:var(--hts-text);margin-bottom:4px" id="hts-scan-title">Bienvenue ! Vos <?php echo $_unscored_count; ?> pages n'ont pas encore été analysées.</div>
		<div style="font-size:13px;color:var(--hts-text-3);line-height:1.5" id="hts-scan-desc">L'analyse prend quelques secondes et permet de calculer votre score de visibilité SEO.</div>
		<div id="hts-scan-progress" style="display:none;margin-top:10px">
			<div style="height:6px;background:var(--hts-surface);border-radius:3px;overflow:hidden">
				<div id="hts-scan-bar" style="height:100%;width:0%;background:var(--hts-geo);border-radius:3px;transition:width .3s"></div>
			</div>
			<div style="font-size:11px;color:var(--hts-text-3);margin-top:4px" id="hts-scan-counter"></div>
		</div>
	</div>
	<button type="button" id="hts-scan-btn" onclick="htsDashBulkScore()" style="padding:10px 22px;border-radius:10px;border:none;background:var(--hts-geo);color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--hts-font);white-space:nowrap">
		<?php echo HTS_DS::icon( 'play', 14, '#fff' ); ?> Analyser mon site
	</button>
</div>
<?php endif; ?>

<?php // ═══ BLOC 2 : Google + Visibilité IA (style Analytics S4) ═══ ?>
<div class="hts-dash-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:20px 0 20px">

	<?php // Card Google ?>
	<div class="hts-ds-card" style="padding:22px 24px 0;display:flex;flex-direction:column;overflow:hidden">
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">
			<?php echo hts_google_g( 20 ); ?>
			<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Google</span>
			<?php if ( $ana_gsc_connected ) : ?>
			<span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:6px;background:var(--hts-success-bg);color:var(--hts-success)">GSC connecté</span>
			<?php endif; ?>
		</div>
		<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
			<?php
			$gsc_kpis = array(
				array( 'l' => 'Clics', 'v' => number_format( $ana_gsc['clicks'] ?? 0, 0, ',', ' ' ), 'c' => 'var(--hts-accent)' ),
				array( 'l' => 'Impressions', 'v' => number_format( $ana_gsc['impressions'] ?? 0, 0, ',', ' ' ), 'c' => 'var(--hts-text)' ),
				array( 'l' => 'Position moy.', 'v' => ( isset( $ana_gsc['avg_position'] ) && $ana_gsc['avg_position'] > 0 ) ? round( $ana_gsc['avg_position'], 1 ) : '—', 'c' => 'var(--hts-success)' ),
				array( 'l' => 'CTR moyen', 'v' => ( $ana_gsc['avg_ctr'] ?? 0 ) . '%', 'c' => 'var(--hts-text)' ),
			);
			foreach ( $gsc_kpis as $m ) : ?>
			<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:var(--hts-surface)">
				<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px"><?php echo esc_html( $m['l'] ); ?></div>
				<div style="font-size:20px;font-weight:800;color:<?php echo esc_attr( $m['c'] ); ?>;letter-spacing:-.03em"><?php echo esc_html( $m['v'] ); ?></div>
			</div>
			<?php endforeach; ?>
		</div>
		<div style="flex:1"></div>
		<?php echo hts_bleed_spark( $gsc_spark, 'var(--hts-accent)', 50 ); ?>
	</div>

	<?php // Card Visibilité IA ?>
	<div class="hts-ds-card" style="padding:22px 24px 0;background:linear-gradient(180deg,var(--hts-geo-soft),var(--hts-bg));border:1px solid var(--hts-geo-border);display:flex;flex-direction:column;overflow:hidden">
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">
			<?php echo HTS_DS::icon( 'bot', 18, 'var(--hts-geo)' ); ?>
			<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Visibilité IA</span>
			<?php if ( $ana_ai_trend > 0 ) : ?>
			<span style="font-size:12px;font-weight:700;color:var(--hts-success)">+<?php echo round( $ana_ai_trend ); ?>%</span>
			<?php endif; ?>
		</div>
		<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
			<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:rgba(255,255,255,.7)">
				<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">Visites IA</div>
				<div style="font-size:20px;font-weight:800;color:var(--hts-geo);letter-spacing:-.03em"><?php echo number_format( $ana_ai_total, 0, ',', ' ' ); ?></div>
			</div>
			<div style="padding:10px 12px;border-radius:var(--hts-radius-sm);background:rgba(255,255,255,.7)">
				<div style="font-size:10px;color:var(--hts-text-3);margin-bottom:2px">Articles cités</div>
				<div style="font-size:20px;font-weight:800;color:var(--hts-success);letter-spacing:-.03em"><?php echo count( $ana_top_articles ); ?></div>
			</div>
		</div>
		<?php if ( ! empty( $ana_ai_sources ) ) :
			$max_src = (int) ( $ana_ai_sources[0]['count'] ?? 1 );
			$max_src = max( $max_src, 1 );
			foreach ( array_slice( $ana_ai_sources, 0, 4 ) as $si => $sr ) :
				$slug  = $sr['source'];
				$color = $src_colors[ $slug ] ?? 'var(--hts-geo)';
				$pct   = round( $sr['count'] / $max_src * 100 );
		?>
		<div style="display:flex;align-items:center;gap:8px;padding:7px 0;<?php echo $si > 0 ? 'border-top:1px solid var(--hts-geo-border)' : ''; ?>">
			<?php echo hts_ai_logo( $slug, 18 ); ?>
			<div style="flex:1;height:5px;border-radius:3px;background:rgba(255,255,255,.5);overflow:hidden">
				<div style="width:<?php echo $pct; ?>%;height:100%;border-radius:3px;background:<?php echo $color; ?>"></div>
			</div>
			<span style="font-size:11px;font-weight:700;color:var(--hts-text);min-width:30px;text-align:right"><?php echo (int) $sr['count']; ?></span>
		</div>
		<?php endforeach; endif; ?>
		<div style="flex:1"></div>
		<?php echo hts_bleed_spark( $ai_spark, 'var(--hts-geo)', 50 ); ?>
	</div>
</div>


<?php // ═══ BLOC 3+4 : Actions + Groupes ═══ ?>
<div class="hts-dash-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px;align-items:stretch">
	<div class="hts-ds-card" style="padding:24px 26px;display:flex;flex-direction:column">
		<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">A faire</span>
			<a href="<?php echo esc_url( $base_url . '&tab=inbox' ); ?>" style="font-size:12px;font-weight:600;color:var(--hts-accent);text-decoration:none">Tout voir</a>
		</div>
		<?php if ( empty( $inbox_cards ) ) : ?>
			<div style="color:var(--hts-text-3);font-size:12px;padding:20px 0;text-align:center">Aucune action en attente.</div>
		<?php else : ?>
			<?php
			// CEO descriptions & gains per action type
			$ceo_meta = array(
				'geo_optimize'       => array( 'title' => 'pages à optimiser pour les IA', 'desc' => 'Les IA citent vos concurrents, pas encore vous.', 'cta' => 'Optimiser', 'filter' => 'geo_optimize' ),
				'add_faq'            => array( 'title' => 'FAQ à ajouter', 'desc' => 'Google et les IA cherchent des réponses directes sur vos pages.', 'cta' => 'Générer', 'filter' => 'add_faq' ),
				'enrich_thin_content'=> array( 'title' => 'contenus trop courts', 'desc' => 'Ces pages manquent de profondeur. Vos concurrents font mieux.', 'cta' => 'Enrichir', 'filter' => 'enrich_thin_content' ),
				'add_meta_title'     => array( 'title' => 'titres à améliorer', 'desc' => 'Pages bien placées, mais les titres n\'attirent pas assez de clics.', 'cta' => 'Approuver', 'filter' => 'add_meta_title' ),
				'add_meta_desc'      => array( 'title' => 'descriptions à réécrire', 'desc' => 'La description influence le taux de clic dans les résultats Google.', 'cta' => 'Approuver', 'filter' => 'add_meta_desc' ),
				'optimize_meta_both' => array( 'title' => 'balises à améliorer', 'desc' => 'Titre et description à optimiser pour plus de clics.', 'cta' => 'Approuver', 'filter' => 'optimize_meta_both' ),
				'add_internal_links' => array( 'title' => 'liens internes à créer', 'desc' => 'Des liens entre vos pages renforcent votre positionnement.', 'cta' => 'Valider', 'filter' => 'add_internal_links' ),
				'content_refresh'    => array( 'title' => 'pages perdent des visiteurs', 'desc' => 'Contenu trop ancien. Vos concurrents se mettent à jour.', 'cta' => 'Corriger', 'filter' => 'content_refresh' ),
				'fix_image_alt'      => array( 'title' => 'images sans texte alternatif', 'desc' => 'Google ne référence pas les images sans description.', 'cta' => 'Corriger', 'filter' => 'fix_image_alt' ),
				'add_featured_image' => array( 'title' => 'images manquantes', 'desc' => 'Une image de couverture améliore la visibilité dans les résultats.', 'cta' => 'Ajouter', 'filter' => 'add_featured_image' ),
				'article_write'      => array( 'title' => 'contenus prêts à publier', 'desc' => 'Vérifiés et optimisés, en attente de votre feu vert.', 'cta' => 'Publier', 'filter' => 'article_write' ),
				'generate_article'   => array( 'title' => 'articles générés', 'desc' => 'Rédigés par vos agents, en attente de validation.', 'cta' => 'Valider', 'filter' => 'generate_article' ),
				'optimize_meta_title'=> array( 'title' => 'titres à optimiser', 'desc' => 'Pages bien placées, mais les titres n\'attirent pas assez de clics.', 'cta' => 'Approuver', 'filter' => 'optimize_meta_title' ),
				'optimize_meta_desc' => array( 'title' => 'descriptions à optimiser', 'desc' => 'La description influence le taux de clic dans les résultats.', 'cta' => 'Approuver', 'filter' => 'optimize_meta_desc' ),
				'fix_orphan_links'   => array( 'title' => 'pages orphelines', 'desc' => 'Ces pages ne reçoivent aucun lien interne. Google les ignore.', 'cta' => 'Corriger', 'filter' => 'fix_orphan_links' ),
				'bulk_optimize_metas'=> array( 'title' => 'balises à optimiser en masse', 'desc' => 'Titres et descriptions à améliorer sur plusieurs pages.', 'cta' => 'Approuver', 'filter' => 'bulk_optimize_metas' ),
			);
			$default_ceo = array( 'title' => '', 'desc' => 'Optimisation recommandée par vos agents.', 'cta' => 'Voir', 'filter' => '' );

			$max_items = 4;
			foreach ( array_slice( $inbox_cards, 0, $max_items ) as $ic_idx => $ic ) :
				$type = $ic['type'] ?? '';
				$meta = $ceo_meta[ $type ] ?? $default_ceo;
				$count = (int) ( $ic['count'] ?? 0 );
				$pmax  = $ic['priority_max'] ?? 'medium';
				$urgency = $pmax === 'critical' ? 'danger' : ( $pmax === 'high' ? 'caution' : ( $pmax === 'low' ? 'success' : 'caution' ) );
				$dot_status = $pmax === 'critical' ? 'fail' : ( $pmax === 'high' ? 'warn' : ( $pmax === 'low' ? 'ok' : 'warn' ) );

				// CEO title
				$title_suffix = $meta['title'] ? $meta['title'] : mb_strtolower( $ic['type_label'] ?? $ic['agent_label'] ?? 'actions' );
				$title = $count . ' ' . $title_suffix;

				// Factual gain: complementary to title (not redundant)
				$gain = '';
				if ( $count > 0 ) {
					if ( in_array( $type, array( 'add_meta_title', 'add_meta_desc', 'optimize_meta_title', 'optimize_meta_desc', 'optimize_meta_both', 'bulk_optimize_metas' ), true ) ) {
						$gain = 'Plus de clics dans Google';
					} elseif ( in_array( $type, array( 'article_write', 'generate_article' ), true ) ) {
						$gain = '+' . $count . ' nouvelle' . ( $count > 1 ? 's' : '' ) . ' page' . ( $count > 1 ? 's' : '' );
					} elseif ( $type === 'add_internal_links' ) {
						$gain = $count . ' lien' . ( $count > 1 ? 's' : '' ) . ' à valider';
					} elseif ( in_array( $type, array( 'geo_optimize', 'add_faq' ), true ) ) {
						$gain = 'Visible par ChatGPT, Perplexity, Gemini';
					} elseif ( in_array( $type, array( 'content_refresh', 'enrich_thin_content' ), true ) ) {
						$gain = $count . ' page' . ( $count > 1 ? 's' : '' ) . ' à renforcer';
					} elseif ( in_array( $type, array( 'fix_orphan_links' ), true ) ) {
						$gain = $count . ' page' . ( $count > 1 ? 's' : '' ) . ' isolée' . ( $count > 1 ? 's' : '' );
					}
				}

				// Deep link: inbox with facet filter (must match facet pills, not action type)
				$inbox_url = $base_url . '&tab=inbox';
				$_type_to_facet = array(
					'add_meta_title' => 'meta', 'add_meta_desc' => 'meta', 'optimize_meta_title' => 'meta',
					'optimize_meta_desc' => 'meta', 'optimize_meta_both' => 'meta', 'bulk_optimize_metas' => 'meta',
					'add_internal_links' => 'liens', 'fix_orphan_links' => 'liens', 'redirect' => 'liens',
					'content_refresh' => 'contenu', 'enrich_thin_content' => 'contenu', 'add_faq' => 'contenu',
					'fix_image_alt' => 'contenu', 'add_featured_image' => 'contenu', 'differentiate' => 'contenu',
					'article_write' => 'contenu', 'generate_article' => 'contenu', 'create_cocon_articles' => 'contenu',
					'delete_page' => 'contenu', 'schedule_publication' => 'contenu', 'schedule_publish' => 'contenu',
					'geo_optimize' => 'ia', 'coach_suggestion' => 'ia',
				);
				$_facet = $_type_to_facet[ $type ] ?? '';
				if ( $_facet ) {
					$inbox_url .= '&inbox_filter=' . urlencode( $_facet );
				}
			?>
			<div style="display:flex;align-items:flex-start;gap:14px;padding:16px 0;min-height:90px;<?php echo $ic_idx > 0 ? 'border-top:1px solid var(--hts-border-sub);' : ''; ?>">
				<div style="width:28px;height:28px;border-radius:8px;background:var(--hts-<?php echo $urgency; ?>-bg);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:var(--hts-<?php echo $urgency; ?>);flex-shrink:0"><?php echo $ic_idx + 1; ?></div>
				<div style="flex:1;min-width:0">
					<div style="display:flex;align-items:center;gap:8px">
						<span style="font-size:14px;font-weight:700;color:var(--hts-text)"><?php echo esc_html( $title ); ?></span>
						<?php echo HTS_DS::dot( $dot_status ); ?>
					</div>
					<div style="font-size:12px;color:var(--hts-text-3);margin-top:3px;line-height:1.4"><?php echo esc_html( $meta['desc'] ); ?></div>
					<div style="font-size:12px;font-weight:700;color:var(--hts-accent);margin-top:6px;min-height:16px"><?php echo $gain ? esc_html( $gain ) : ''; ?></div>
				</div>
				<a href="<?php echo esc_url( $inbox_url ); ?>" style="padding:7px 16px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text);text-decoration:none;flex-shrink:0"><?php echo esc_html( $meta['cta'] ); ?></a>
			</div>
			<?php endforeach; ?>
		<?php endif; ?>
		<div style="flex:1"></div>
		<?php if ( $inbox_count > 0 ) : ?>
		<div style="padding-top:14px;margin-top:10px;border-top:1px solid var(--hts-border-sub);text-align:center">
			<a href="<?php echo esc_url( $base_url . '&tab=inbox' ); ?>" style="display:inline-flex;align-items:center;gap:6px;padding:9px 22px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text);text-decoration:none;font-family:var(--hts-font)">
				<?php echo HTS_DS::icon( 'inbox', 13, 'var(--hts-accent)' ); ?> Voir les <?php echo $inbox_count; ?> actions
			</a>
		</div>
		<?php endif; ?>
	</div>
	<div class="hts-ds-card" style="padding:24px 26px;display:flex;flex-direction:column">
		<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Groupes de contenus</span>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-cocon-commander' ) ); ?>" style="font-size:12px;font-weight:600;color:var(--hts-accent);text-decoration:none">Tout voir</a>
		</div>
		<?php
		// ── Load cocon data (Polylang-aware, same logic as class-hts-cocon.php) ──
		$cocon_raw = array();
		if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
			$cl = HTS_Language::get_current_lang();
			if ( $cl ) $cocon_raw = get_option( 'hts_cocon_data_' . $cl, array() );
		}
		if ( empty( $cocon_raw ) ) $cocon_raw = get_option( 'hts_cocon_data', array() );

		$clusters = ( is_array( $cocon_raw ) && ! empty( $cocon_raw['clusters'] ) ) ? $cocon_raw['clusters'] : array();
		// Filter out "Non classé" / "Navigation" utility clusters
		unset( $clusters['Non classé'], $clusters['Navigation'] );
		$cluster_count = count( $clusters );

		if ( $cluster_count === 0 ) : ?>
			<div style="color:var(--hts-text-3);font-size:12px;padding:20px 0;text-align:center">Aucun groupe de contenus pour l'instant.</div>
		<?php else :
			// ── Compute GSC + Tracker metrics per cluster ──
			global $wpdb;
			$gsc_table     = $wpdb->prefix . 'hts_gsc_data';
			$tracker_table = $wpdb->prefix . 'hts_visits';
			$wf_table      = $wpdb->prefix . 'hts_workflow_actions';
			$has_gsc       = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $gsc_table ) );
			$has_tracker   = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tracker_table ) );
			$cutoff_30     = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
			$cutoff_prev   = gmdate( 'Y-m-d', strtotime( '-60 days' ) );
			$cutoff_30_dt  = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );

			$cluster_stats = array();

			// ── Collect ALL post_ids across all clusters for batch queries ──
			$all_pids = array();
			$cluster_pid_map = array();
			foreach ( $clusters as $cname => $cdata ) {
				$pids = isset( $cdata['pages'] ) && is_array( $cdata['pages'] ) ? $cdata['pages'] : array();
				$pids = array_filter( array_map( 'intval', $pids ) );
				if ( empty( $pids ) ) continue;
				$cluster_pid_map[ $cname ] = $pids;
				$all_pids = array_merge( $all_pids, $pids );
			}
			$all_pids = array_unique( $all_pids );

			if ( empty( $all_pids ) ) : ?>
				<div style="color:var(--hts-text-3);font-size:12px;padding:20px 0;text-align:center"><?php echo $cluster_count; ?> groupes détectés. Lancez une analyse pour voir les détails.</div>
			<?php else :
				$all_in = implode( ',', $all_pids );

				// ── Batch 1: GSC clicks per post_id (current 30d + prev 30d) ──
				$gsc_cur  = array(); // post_id => clicks
				$gsc_prev = array();
				if ( $has_gsc ) {
					$rows = $wpdb->get_results(
						"SELECT post_id, SUM(clicks) AS c FROM {$gsc_table} WHERE post_id IN ({$all_in}) AND fetch_date >= '{$cutoff_30}' GROUP BY post_id"
					);
					foreach ( $rows as $r ) $gsc_cur[ (int) $r->post_id ] = (int) $r->c;

					$rows = $wpdb->get_results(
						"SELECT post_id, SUM(clicks) AS c FROM {$gsc_table} WHERE post_id IN ({$all_in}) AND fetch_date >= '{$cutoff_prev}' AND fetch_date < '{$cutoff_30}' GROUP BY post_id"
					);
					foreach ( $rows as $r ) $gsc_prev[ (int) $r->post_id ] = (int) $r->c;
				}

				// ── Batch 2: Tracker visits per post_id (total + AI, 30d) ──
				$trk_total = array();
				$trk_ai    = array();
				if ( $has_tracker ) {
					$rows = $wpdb->get_results(
						"SELECT post_id, COUNT(*) AS c, SUM(is_ai) AS ai FROM {$tracker_table} WHERE post_id IN ({$all_in}) AND visited_at >= '{$cutoff_30_dt}' GROUP BY post_id"
					);
					foreach ( $rows as $r ) {
						$trk_total[ (int) $r->post_id ] = (int) $r->c;
						$trk_ai[ (int) $r->post_id ]    = (int) $r->ai;
					}
				}

				// ── Batch 3: Scores per post_id ──
				$scores = array();
				$rows = $wpdb->get_results(
					"SELECT post_id, CAST(meta_value AS UNSIGNED) AS s FROM {$wpdb->postmeta}
					 WHERE meta_key = '_hts_combined_score' AND post_id IN ({$all_in}) AND meta_value > 0"
				);
				foreach ( $rows as $r ) $scores[ (int) $r->post_id ] = (int) $r->s;

				// ── Batch 4: Workflow actions count per post_id (30d) ──
				$wf_counts = array(); // post_id => count of done actions
				if ( $has_wf ) {
					$rows = $wpdb->get_results(
						"SELECT post_id, COUNT(*) AS cnt FROM {$wf_table}
						 WHERE post_id IN ({$all_in}) AND status = 'done' AND resolved_at >= '{$cutoff_30_dt}'
						 GROUP BY post_id"
					);
					foreach ( $rows as $r ) $wf_counts[ (int) $r->post_id ] = (int) $r->cnt;
				}

				// ── Aggregate per cluster from batch results ──
				foreach ( $cluster_pid_map as $cname => $pids ) {
					$clicks_30 = 0; $clicks_prev = 0; $visits = 0; $ai_vis = 0;
					$score_sum = 0; $score_n = 0; $actions_30 = 0;
					foreach ( $pids as $pid ) {
						$clicks_30   += $gsc_cur[ $pid ] ?? 0;
						$clicks_prev += $gsc_prev[ $pid ] ?? 0;
						$visits      += $trk_total[ $pid ] ?? 0;
						$ai_vis      += $trk_ai[ $pid ] ?? 0;
						$actions_30  += $wf_counts[ $pid ] ?? 0;
						if ( isset( $scores[ $pid ] ) ) { $score_sum += $scores[ $pid ]; $score_n++; }
					}

					$cluster_stats[] = array(
						'name'         => $cname,
						'pages'        => count( $pids ),
						'clicks_30'    => $clicks_30,
						'clicks_prev'  => $clicks_prev,
						'clicks_delta' => $clicks_prev > 0 ? $clicks_30 - $clicks_prev : 0,
						'visits_30'    => $visits,
						'ai_visits_30' => $ai_vis,
						'score_avg'    => $score_n > 0 ? (int) round( $score_sum / $score_n ) : 0,
						'actions_30'   => $actions_30,
					);
				}

			if ( empty( $cluster_stats ) ) : ?>
				<div style="color:var(--hts-text-3);font-size:12px;padding:20px 0;text-align:center"><?php echo $cluster_count; ?> groupes détectés. Lancez une analyse pour voir les détails.</div>
			<?php else :
				// Sort: clusters with most total activity (clicks + visits), then pages
				usort( $cluster_stats, function( $a, $b ) {
					$a_total = $a['clicks_30'] + $a['visits_30'];
					$b_total = $b['clicks_30'] + $b['visits_30'];
					if ( $a_total !== $b_total ) return $b_total - $a_total;
					return $b['pages'] - $a['pages'];
				} );

			// Show top 4
			foreach ( array_slice( $cluster_stats, 0, 4 ) as $ci => $cs ) :
				// Badge: clicks delta (factual from GSC)
				$badge_text = '';
				$badge_color = 'var(--hts-success)';
				$badge_bg    = 'var(--hts-success-bg)';
				$is_declining = false;
				if ( $cs['clicks_prev'] > 0 ) {
					if ( $cs['clicks_delta'] > 0 ) {
						$badge_text = '+' . $cs['clicks_delta'] . ' clics';
					} elseif ( $cs['clicks_delta'] < 0 ) {
						$badge_text  = $cs['clicks_delta'] . ' clics';
						$badge_color = 'var(--hts-danger)';
						$badge_bg    = 'var(--hts-danger-bg)';
						$is_declining = true;
					} else {
						$badge_text  = 'Stable';
						$badge_color = 'var(--hts-text-3)';
						$badge_bg    = 'var(--hts-surface)';
					}
				} elseif ( $cs['clicks_30'] > 0 ) {
					$badge_text = $cs['clicks_30'] . ' clics';
				} elseif ( $cs['ai_visits_30'] > 0 ) {
					$badge_text = $cs['ai_visits_30'] . ' visite' . ( $cs['ai_visits_30'] > 1 ? 's' : '' ) . ' IA';
					$badge_color = 'var(--hts-geo)';
					$badge_bg    = 'var(--hts-geo-soft)';
				}

				// Subtitle: pages + optimisations + visites IA
				$parts = array();
				$parts[] = $cs['pages'] . ' page' . ( $cs['pages'] > 1 ? 's' : '' );
				if ( $cs['actions_30'] > 0 ) $parts[] = $cs['actions_30'] . ' optimisation' . ( $cs['actions_30'] > 1 ? 's' : '' );
				if ( $cs['ai_visits_30'] > 0 ) $parts[] = $cs['ai_visits_30'] . ' visite' . ( $cs['ai_visits_30'] > 1 ? 's' : '' ) . ' IA';
				$sub_text = implode( ' · ', $parts );

				// Progress bar: score (always shown for consistent height)
				$bar_pct = $cs['score_avg'] > 0 ? min( 100, $cs['score_avg'] ) : 0;
				$bar_label_before = '0';
				$bar_label_after  = $cs['score_avg'] > 0 ? $cs['score_avg'] . '/100' : '—';
				$bar_gradient = 'linear-gradient(90deg,var(--hts-success),var(--hts-accent))';
				if ( $is_declining ) $bar_gradient = 'linear-gradient(90deg,var(--hts-danger),var(--hts-caution))';
				$bar_after_col = $cs['score_avg'] >= 75 ? 'var(--hts-success)' : ( $cs['score_avg'] >= 50 ? 'var(--hts-caution)' : 'var(--hts-danger)' );
				if ( $cs['score_avg'] === 0 ) $bar_after_col = 'var(--hts-text-3)';

				$cocon_url = admin_url( 'admin.php?page=hts-cocon-commander' );
			?>
			<div style="padding:16px 0;<?php echo $ci > 0 ? 'border-top:1px solid var(--hts-border-sub);' : ''; ?>">
				<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
					<a href="<?php echo esc_url( $cocon_url . '&open_cluster=' . urlencode( $cs['name'] ) ); ?>" style="font-size:14px;font-weight:700;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1;text-decoration:none" onmouseenter="this.style.color='var(--hts-accent)'" onmouseleave="this.style.color='var(--hts-text)'"><?php echo esc_html( $cs['name'] ); ?></a>
					<div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
						<?php if ( $badge_text ) : ?>
						<span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:6px;color:<?php echo $badge_color; ?>;background:<?php echo $badge_bg; ?>"><?php echo esc_html( $badge_text ); ?></span>
						<?php endif; ?>
						<?php if ( $is_declining ) : ?>
						<a href="<?php echo esc_url( $cocon_url ); ?>" style="font-size:10px;font-weight:700;padding:3px 10px;border-radius:6px;border:1px solid var(--hts-danger);color:var(--hts-danger);text-decoration:none">Analyser</a>
						<?php endif; ?>
					</div>
				</div>
				<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:10px"><?php echo esc_html( $sub_text ); ?></div>
				<div style="display:flex;align-items:center;gap:10px">
					<span style="font-size:12px;font-weight:600;color:var(--hts-text-3);min-width:14px;text-align:right"><?php echo esc_html( $bar_label_before ); ?></span>
					<div style="flex:1;height:6px;border-radius:3px;background:var(--hts-border-sub);overflow:hidden">
						<div style="height:100%;border-radius:3px;background:<?php echo $bar_gradient; ?>;width:<?php echo $bar_pct; ?>%"></div>
					</div>
					<span style="font-size:12px;font-weight:700;color:<?php echo $bar_after_col; ?>;min-width:40px;text-align:right"><?php echo esc_html( $bar_label_after ); ?></span>
				</div>
				<div style="font-size:10px;color:var(--hts-text-3);margin-top:4px;text-align:right">Mesuré sur 30 jours</div>
			</div>
			<?php endforeach; ?>
			<?php if ( $cluster_count > 4 ) : ?>
			<div style="flex:1"></div>
			<div style="padding-top:14px;margin-top:10px;border-top:1px solid var(--hts-border-sub);text-align:center">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-cocon-commander' ) ); ?>" style="display:inline-flex;align-items:center;gap:6px;padding:9px 22px;border-radius:10px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text);text-decoration:none;font-family:var(--hts-font)">
					<?php echo HTS_DS::icon( 'compass', 13, 'var(--hts-geo)' ); ?> Voir les <?php echo $cluster_count; ?> groupes
				</a>
			</div>
			<?php endif; ?>
			<?php endif; ?>
			<?php endif; ?>
			<?php endif; ?>
	</div>
</div>


<?php // ═══ BLOC 5+5b : Résultats mesurés + Activity feed ═══ ?>
<?php
// ── Left: Feedback Loop data ──
$agent_labels = array();
$fl_summary = null;
$fl_positive = array();
$fl_negative = array();
$fl_total = 0;
$fl_positive_count = 0;
$fl_neutral_count  = 0;
$fl_negative_count = 0;

if ( $has_wf ) {
	$agent_labels = HTS_Workflow_Engine::get_agent_labels();
}
if ( class_exists( 'HTS_Feedback_Loop' ) ) {
	$fl_summary = HTS_Feedback_Loop::compute_impact_summary( 30 );
}

$act_labels = array(
	'link_outbound' => 'Lien sortant', 'link_inbound' => 'Lien entrant', 'link_sibling' => 'Lien frère',
	'link_cross_out' => 'Lien cross-cocon', 'link_cross_in' => 'Lien reçu', 'link_manual' => 'Lien manuel',
	'link_to_money' => 'Lien money page', 'link_removed' => 'Lien supprimé',
	'meta_title' => 'Title modifié', 'meta_description' => 'Meta description', 'meta_auto_pilot' => 'Meta auto',
	'content_modified' => 'Contenu modifié', 'content_write' => 'Contenu réécrit',
	'article_created' => 'Article créé', 'article_published' => 'Article publié',
);

if ( $fl_summary && $fl_summary['total'] > 0 ) {
	$fl_total          = $fl_summary['total'];
	$fl_positive_count = $fl_summary['positive'];
	$fl_neutral_count  = $fl_summary['neutral'];
	$fl_negative_count = $fl_summary['negative'];

	$seen_pos = array();
	$seen_neg = array();
	foreach ( $fl_summary['actions'] ?? array() as $fa ) {
		$pid = (int) ( $fa['post_id'] ?? 0 );
		if ( $fa['verdict'] === 'positive' && count( $fl_positive ) < 2 && ! isset( $seen_pos[ $pid ] ) ) {
			$fl_positive[] = $fa; $seen_pos[ $pid ] = true;
		} elseif ( $fa['verdict'] === 'negative' && count( $fl_negative ) < 2 && ! isset( $seen_neg[ $pid ] ) ) {
			$fl_negative[] = $fa; $seen_neg[ $pid ] = true;
		}
	}
}
$reliability_pct = $fl_total > 0 ? round( $fl_positive_count / $fl_total * 100 ) : 0;
if ( $fl_total === 0 ) {
	$reliability_label = 'En apprentissage'; $reliability_col = 'var(--hts-text-3)';
} elseif ( $reliability_pct >= 70 ) {
	$reliability_label = 'Excellente'; $reliability_col = 'var(--hts-success)';
} elseif ( $reliability_pct >= 40 ) {
	$reliability_label = 'Bonne'; $reliability_col = 'var(--hts-accent)';
} else {
	$reliability_label = 'Modérée'; $reliability_col = 'var(--hts-caution)';
}

// hts_dash_reco() — now in _helpers.php



// ── Right: Activity feed — collect from all sources, JSON for JS animation ──
$_feed = array();
$_seed = (int) floor( time() / 600 ); // changes every 10 min
mt_srand( $_seed );

$_acols = array(
	'linking' => '#2D7FF9', 'meta' => '#00D26A', 'geo_score' => '#7C3AED',
	'fresh' => '#F59E0B', 'auto_write' => '#F59E0B', 'content_quality' => '#F59E0B',
	'coach' => '#2D7FF9', 'cannib' => '#EF4444', 'strategy' => '#6B7280',
	'image' => '#F59E0B', 'monitoring' => '#7C3AED',
);
$_blabs = array(
	'chatgpt' => 'ChatGPT', 'claude' => 'Claude', 'perplexity' => 'Perplexity',
	'meta_ai' => 'Meta AI', 'meta' => 'Meta AI', 'gemini' => 'Gemini',
	'copilot' => 'Copilot', 'you' => 'You.com', 'phind' => 'Phind',
	'googlebot' => 'Googlebot', 'bingbot' => 'Bingbot', 'semrush' => 'Semrush',
);

// S1: Workflow actions (8 max, rotated)
if ( $has_wf ) {
	$_wt = $wpdb->prefix . 'hts_workflow_actions';
	$_wo = mt_rand( 0, 30 );
	$_wr = $wpdb->get_results( $wpdb->prepare(
		"SELECT a.agent, a.type, a.post_id, a.created_at, p.post_title
		 FROM {$_wt} a LEFT JOIN {$wpdb->posts} p ON a.post_id = p.ID
		 WHERE a.status IN ('done','executing','approved','pending')
		 ORDER BY a.created_at DESC LIMIT 35 OFFSET %d", $_wo
	) );
	$_st = array();
	foreach ( $_wr as $r ) {
		if ( count( $_st ) >= 15 ) break;
		$t = $r->type;
		if ( isset( $_st[ $t ] ) && $_st[ $t ] >= 3 ) continue;
		$_st[ $t ] = ( $_st[ $t ] ?? 0 ) + 1;
		$pg = mb_strimwidth( $r->post_title ?? '', 0, 34, '...' );
		$dm = array(
			'add_internal_links' => 'Lien interne proposé → ' . $pg,
			'add_meta_title'     => 'Title SEO réécrit → ' . $pg,
			'add_meta_desc'      => 'Description optimisée → ' . $pg,
			'optimize_meta_title'=> 'Title optimisé → ' . $pg,
			'optimize_meta_desc' => 'Meta description → ' . $pg,
			'optimize_meta_both' => 'Metas optimisées → ' . $pg,
			'enrich_thin_content'=> 'Contenu enrichi → ' . $pg,
			'geo_optimize'       => 'Optimisé pour les IA → ' . $pg,
			'add_faq'            => 'FAQ générée → ' . $pg,
			'content_refresh'    => 'Contenu rafraîchi → ' . $pg,
			'add_featured_image' => 'Image IA ajoutée → ' . $pg,
			'fix_image_alt'      => 'ALT images corrigé → ' . $pg,
			'article_write'      => 'Article rédigé → ' . $pg,
			'generate_article'   => 'Article généré → ' . $pg,
			'fix_orphan_links'   => 'Page orpheline corrigée → ' . $pg,
			'bulk_optimize_metas'=> 'Metas optimisées en masse',
			'redirect'           => 'Redirection créée → ' . $pg,
			'differentiate'      => 'Contenu différencié → ' . $pg,
		);
		$_feed[] = array(
			'text'  => $dm[ $t ] ?? ( ( $agent_labels[ $r->agent ] ?? 'Agent' ) . ' → ' . $pg ),
			'agent' => $agent_labels[ $r->agent ] ?? ucfirst( $r->agent ),
			'color' => $_acols[ $r->agent ] ?? '#2D7FF9',
			'ts'    => $r->created_at,
		);
	}
}

// S2: AI crawls (5 max, rotated)
$_ct = $wpdb->prefix . 'hts_crawls';
$_hc = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $_ct ) );
if ( $_hc ) {
	$_co = mt_rand( 0, 15 );
	$_cr = $wpdb->get_results( $wpdb->prepare(
		"SELECT c.bot_source, c.crawled_at, p.post_title
		 FROM {$_ct} c LEFT JOIN {$wpdb->posts} p ON c.post_id = p.ID
		 WHERE c.bot_category = 'ai' AND c.crawled_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
		 ORDER BY c.crawled_at DESC LIMIT 20 OFFSET %d", $_co
	) );
	$_cb = array(); $_cc = 0;
	foreach ( $_cr as $c ) {
		if ( $_cc >= 10 ) break;
		$k = $c->bot_source . ':' . ( $c->post_title ?? '' );
		if ( isset( $_cb[ $k ] ) ) continue;
		$_cb[ $k ] = 1;
		$bn = $_blabs[ $c->bot_source ] ?? ucfirst( $c->bot_source );
		$pg = mb_strimwidth( $c->post_title ?? '', 0, 28, '...' );
		$_feed[] = array( 'text' => $bn . ' a exploré ' . $pg, 'agent' => 'Surveillance IA', 'color' => '#7C3AED', 'ts' => $c->crawled_at );
		$_cc++;
	}

	// S3: SEO crawls (3 max)
	$_sr = $wpdb->get_results(
		"SELECT c.bot_source, c.crawled_at, p.post_title
		 FROM {$_ct} c LEFT JOIN {$wpdb->posts} p ON c.post_id = p.ID
		 WHERE c.bot_category = 'seo' AND c.crawled_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
		 ORDER BY c.crawled_at DESC LIMIT 5"
	);
	foreach ( $_sr as $s ) {
		$bn = $_blabs[ $s->bot_source ] ?? ucfirst( $s->bot_source );
		$pg = mb_strimwidth( $s->post_title ?? '', 0, 28, '...' );
		$_feed[] = array( 'text' => $bn . ' a visité ' . $pg, 'agent' => 'Crawl SEO', 'color' => '#00D26A', 'ts' => $s->crawled_at );
	}
}

// S4: Feedback loop analyses (4 max, rotated)
if ( $fl_summary && ! empty( $fl_summary['actions'] ) ) {
	$_fo = mt_rand( 0, max( 0, count( $fl_summary['actions'] ) - 8 ) );
	$_fs = array_slice( $fl_summary['actions'], $_fo, 12 );
	$_fc = 0;
	foreach ( $_fs as $fa ) {
		if ( $_fc >= 8 ) break;
		$v = $fa['verdict'] ?? 'neutral';
		$vl = $v === 'positive' ? '↑ positif' : ( $v === 'negative' ? '↓ négatif' : '→ stable' );
		$pg = mb_strimwidth( $fa['post_title'] ?? '', 0, 26, '...' );
		$vc = $v === 'positive' ? '#00D26A' : ( $v === 'negative' ? '#EF4444' : '#F59E0B' );
		$_feed[] = array( 'text' => 'Impact mesuré : ' . $pg . ' ' . $vl, 'agent' => 'Feedback Loop', 'color' => $vc, 'ts' => $fa['created_at'] ?? '' );
		$_fc++;
	}
}

// S5: Score recalculations (3 max)
$_scr = $wpdb->get_results(
	"SELECT p.post_title, pm.meta_value FROM {$wpdb->postmeta} pm
	 JOIN {$wpdb->posts} p ON pm.post_id = p.ID
	 WHERE pm.meta_key = '_hts_combined_score' AND p.post_status = 'publish'
	 ORDER BY pm.meta_id DESC LIMIT 12 OFFSET " . mt_rand( 0, 10 )
);
$_sc2 = 0;
foreach ( $_scr as $sc ) {
	if ( $_sc2 >= 6 ) break;
	$sv = (int) $sc->meta_value;
	$pg = mb_strimwidth( $sc->post_title ?? '', 0, 26, '...' );
	$_feed[] = array( 'text' => 'Score calculé : ' . $pg . ' → ' . $sv . '/100', 'agent' => 'Analyse SEO', 'color' => $sv >= 70 ? '#00D26A' : ( $sv >= 40 ? '#F59E0B' : '#EF4444' ), 'ts' => '' );
	$_sc2++;
}

// S6: AI visits (2 max)
$_vt = $wpdb->prefix . 'hts_visits';
$_hv = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $_vt ) );
if ( $_hv ) {
	$_vr = $wpdb->get_results(
		"SELECT v.ai_source, v.visited_at, p.post_title FROM {$_vt} v
		 LEFT JOIN {$wpdb->posts} p ON v.post_id = p.ID
		 WHERE v.is_ai = 1 AND v.visited_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
		 ORDER BY v.visited_at DESC LIMIT 6"
	);
	foreach ( $_vr as $vr ) {
		$src = $_blabs[ $vr->ai_source ] ?? 'IA';
		$pg  = mb_strimwidth( $vr->post_title ?? '', 0, 26, '...' );
		$_feed[] = array( 'text' => 'Visite ' . $src . ' → ' . $pg, 'agent' => 'Trafic IA', 'color' => '#7C3AED', 'ts' => $vr->visited_at );
	}
}

// Sort by time DESC, take 50
usort( $_feed, function( $a, $b ) { return strcmp( $b['ts'] ?? '', $a['ts'] ?? '' ); } );
$_feed = array_slice( $_feed, 0, 50 );

// Compute relative times server-side
foreach ( $_feed as &$_fi ) {
	$t = '';
	if ( ! empty( $_fi['ts'] ) ) {
		$d = time() - strtotime( $_fi['ts'] );
		if ( $d < 0 ) $d = 0;
		if ( $d < 60 ) $t = "à l'instant";
		elseif ( $d < 3600 ) $t = 'il y a ' . max( 1, round( $d / 60 ) ) . ' min';
		elseif ( $d < 86400 ) $t = 'il y a ' . round( $d / 3600 ) . 'h';
		else $t = 'il y a ' . round( $d / 86400 ) . 'j';
	}
	$_fi['time'] = $t;
}
unset( $_fi );

$inbox_impact_url = esc_url( $base_url . '&tab=inbox&inbox_tab=history' );
?>
<div class="hts-dash-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
	<?php // ── Left: Résultats mesurés ── ?>
	<div class="hts-ds-card" style="padding:24px 26px;display:flex;flex-direction:column">
		<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Résultats mesurés</span>
			<?php if ( $fl_total > 0 ) : ?>
			<a href="<?php echo $inbox_impact_url; ?>" style="font-size:12px;font-weight:600;color:var(--hts-accent);text-decoration:none">Tout voir</a>
			<?php endif; ?>
		</div>

		<?php if ( $fl_total === 0 ) : ?>
			<?php echo HTS_DS::empty_state( 'Pas encore de résultats', "Les premiers résultats apparaîtront après 7 jours d'activité." ); ?>
		<?php else : ?>

			<?php // ── Summary line ── ?>
			<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px">
				<?php echo $fl_total; ?> mesurées · <span style="color:var(--hts-success);font-weight:600"><?php echo $fl_positive_count; ?> positive<?php echo $fl_positive_count > 1 ? 's' : ''; ?></span><?php if ( $fl_negative_count > 0 ) : ?> · <span style="color:var(--hts-danger);font-weight:600"><?php echo $fl_negative_count; ?> négative<?php echo $fl_negative_count > 1 ? 's' : ''; ?></span><?php endif; ?>
			</div>

			<?php
			// ── All items: 2 positives + 2 negatives, same layout, no encadré ──
			$all_items = array();
			foreach ( $fl_positive as $p ) { $p['_v'] = 'positive'; $all_items[] = $p; }
			foreach ( $fl_negative as $n ) { $n['_v'] = 'negative'; $all_items[] = $n; }
			foreach ( $all_items as $ai => $item ) :
				$is_neg  = ( $item['_v'] === 'negative' );
				$dot_st  = $is_neg ? 'fail' : 'ok';
				$i_type  = $act_labels[ $item['action_type'] ?? '' ] ?? ucfirst( str_replace( '_', ' ', $item['action_type'] ?? '' ) );
				$i_reco  = hts_dash_reco( $item['action_type'] ?? '', $item['_v'] );

				$i_badge = '';
				$i_badge_v = $is_neg ? 'danger' : 'success';
				if ( $is_neg ) {
					if ( ( $item['pos_delta'] ?? 0 ) > 0.5 ) { $i_badge = '-' . $item['pos_delta'] . ' pos.'; }
					elseif ( ( $item['clk_delta'] ?? 0 ) < -1 ) { $i_badge = $item['clk_delta'] . ' clics'; }
				} else {
					if ( ( $item['clk_delta'] ?? 0 ) > 0 ) { $i_badge = '+' . $item['clk_delta'] . ' clics'; }
					elseif ( ( $item['pos_delta'] ?? 0 ) < -0.5 ) { $i_badge = '+' . abs( $item['pos_delta'] ) . ' pos.'; }
				}

				$i_inbox_url = $is_neg ? esc_url( $base_url . '&tab=inbox&inbox_tab=history&page_id=' . ( $item['post_id'] ?? 0 ) ) : '';
			?>
			<div style="padding:10px 0;<?php echo $ai > 0 ? 'border-top:1px solid var(--hts-border-sub);' : ''; ?>">
				<div style="display:flex;align-items:center;gap:8px;margin-bottom:3px">
					<?php echo HTS_DS::dot( $dot_st ); ?>
					<span style="font-size:13px;font-weight:700;color:var(--hts-text);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0"><?php echo esc_html( mb_strimwidth( $item['post_title'] ?? '', 0, 40, '...' ) ); ?></span>
					<?php if ( $i_badge ) echo HTS_DS::badge( $i_badge, $i_badge_v ); ?>
				</div>
				<div style="font-size:11px;color:var(--hts-text-3);padding-left:16px"><?php echo esc_html( $i_type ); ?></div>
				<div style="font-size:11px;color:var(--hts-text-3);padding-left:16px;font-style:italic;margin-top:2px;line-height:1.3"><?php echo esc_html( $i_reco ); ?></div>
				<?php if ( $is_neg && $i_inbox_url ) : ?>
				<div style="padding-left:16px;margin-top:6px">
					<a href="<?php echo $i_inbox_url; ?>" style="display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:var(--hts-radius-sm);border:1.5px solid var(--hts-danger);font-size:11px;font-weight:700;color:var(--hts-danger);text-decoration:none">
						Examiner <?php echo HTS_DS::icon( 'chevron-right', 11, 'var(--hts-danger)' ); ?>
					</a>
				</div>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>

		<?php endif; ?>

		<?php // ── Reliability bar (enriched) ── ?>
		<?php if ( $fl_total > 0 ) : ?>
		<div style="margin-top:auto;padding-top:14px;border-top:1px solid var(--hts-border-sub)">
			<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
				<span style="font-size:11px;font-weight:600;color:var(--hts-text-3)">Fiabilité des actions</span>
				<span style="font-size:11px;font-weight:700;color:<?php echo $reliability_col; ?>"><?php echo esc_html( $reliability_label ); ?> (<?php echo $reliability_pct; ?>%)</span>
			</div>
			<?php echo HTS_DS::progress( $reliability_pct, $reliability_col, 5 ); ?>
			<div style="display:flex;gap:12px;margin-top:8px;font-size:10px;color:var(--hts-text-3)">
				<span><?php echo HTS_DS::dot( 'ok', 5 ); ?> <?php echo $fl_positive_count; ?> positives</span>
				<span><?php echo HTS_DS::dot( 'warn', 5 ); ?> <?php echo $fl_neutral_count; ?> stables</span>
				<span><?php echo HTS_DS::dot( 'fail', 5 ); ?> <?php echo $fl_negative_count; ?> à revoir</span>
			</div>
			<div style="font-size:10px;color:var(--hts-text-3);margin-top:4px;line-height:1.3"><?php echo $fl_total; ?> actions analysées sur 30 jours. L'outil apprend de chaque résultat.</div>
		</div>
		<?php endif; ?>
	</div>





	<?php // ── Right: Activités récentes — pré-rempli + push-down ── ?>
	<div class="hts-ds-card" style="padding:24px 26px;display:flex;flex-direction:column">
		<div style="margin-bottom:12px">
			<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--hts-text-3)">Activités récentes</span>
		</div>
		<?php if ( empty( $_feed ) ) : ?>
			<div style="color:var(--hts-text-3);font-size:12px;padding:20px 0;text-align:center"><?php echo $agents_active; ?> agents actifs.</div>
		<?php else : ?>
		<div id="hts-feed" style="flex:1;overflow:hidden">
			<?php // Pre-render first 10 items server-side
			$_pre = array_slice( $_feed, 0, 10 );
			foreach ( $_pre as $pi => $pa ) :
				$op = max( 0.12, 1 - ( $pi * 0.09 ) );
				$is_first = ( $pi === 0 );
			?>
			<div class="hts-fi" style="display:flex;gap:10px;padding:9px 0;opacity:<?php echo round( $op, 2 ); ?>;border-bottom:1px solid var(--hts-border-sub);transition:all .5s cubic-bezier(.4,0,.2,1)">
				<div style="flex-shrink:0;width:20px;display:flex;align-items:flex-start;justify-content:center;padding-top:4px">
					<div class="hts-fd" style="width:<?php echo $is_first ? '8' : '6'; ?>px;height:<?php echo $is_first ? '8' : '6'; ?>px;border-radius:50%;background:<?php echo $is_first ? esc_attr( $pa['color'] ) : '#00D26A'; ?>;box-shadow:<?php echo $is_first ? '0 0 6px ' . esc_attr( $pa['color'] ) : 'none'; ?>;<?php echo $is_first ? 'animation:htsPulse 2s ease-in-out infinite' : ''; ?>"></div>
				</div>
				<div style="min-width:0;flex:1">
					<div style="font-size:12px;font-weight:<?php echo $is_first ? '600' : '500'; ?>;color:<?php echo $is_first ? 'var(--hts-text)' : 'var(--hts-text-2)'; ?>;line-height:1.35"><?php echo esc_html( $pa['text'] ); ?></div>
					<div style="display:flex;align-items:center;gap:6px;margin-top:2px">
						<span style="font-size:10px;font-weight:600;color:<?php echo esc_attr( $pa['color'] ); ?>"><?php echo esc_html( $pa['agent'] ); ?></span>
						<span style="font-size:10px;color:var(--hts-text-3)"><?php echo esc_html( $pa['time'] ); ?></span>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
		<script>
		(function(){
			var data=<?php echo wp_json_encode( array_values( array_map( function( $f ) {
				return array( 't' => $f['text'], 'a' => $f['agent'], 'c' => $f['color'], 'h' => $f['time'] );
			}, $_feed ) ) ); ?>;
			if(!data||data.length<11)return;
			var wrap=document.getElementById('hts-feed');
			if(!wrap)return;
			var MAX=10,idx=10,total=data.length;

			function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

			function push(){
				var d=data[idx%total];
				var c=esc(d.c);
				var el=document.createElement('div');
				el.className='hts-fi';
				el.style.cssText='display:flex;gap:10px;padding:9px 0;opacity:0;transform:translateY(-10px);transition:all .5s cubic-bezier(.4,0,.2,1);border-bottom:1px solid var(--hts-border-sub)';
				el.innerHTML='<div style="flex-shrink:0;width:20px;display:flex;align-items:flex-start;justify-content:center;padding-top:4px">'
					+'<div class="hts-fd" style="width:8px;height:8px;border-radius:50%;background:'+c+';box-shadow:0 0 6px '+c+';animation:htsPulse 2s ease-in-out infinite"></div>'
					+'</div>'
					+'<div style="min-width:0;flex:1">'
					+'<div style="font-size:12px;font-weight:600;color:var(--hts-text);line-height:1.35">'+esc(d.t)+'</div>'
					+'<div style="display:flex;align-items:center;gap:6px;margin-top:2px">'
					+'<span style="font-size:10px;font-weight:600;color:'+c+'">'+esc(d.a)+'</span>'
					+'<span style="font-size:10px;color:var(--hts-text-3)">'+esc(d.h)+'</span>'
					+'</div></div>';

				wrap.insertBefore(el,wrap.firstChild);
				requestAnimationFrame(function(){requestAnimationFrame(function(){
					el.style.opacity='1';el.style.transform='translateY(0)';
				});});

				for(var j=1;j<wrap.children.length;j++){
					var ch=wrap.children[j];
					ch.style.opacity=String(Math.max(.12,1-(j*0.09)));
					var dot=ch.querySelector('.hts-fd');
					if(dot){dot.style.width='6px';dot.style.height='6px';dot.style.background='#00D26A';dot.style.boxShadow='none';dot.style.animation='none';}
					var tx=ch.children[1];
					if(tx&&tx.firstChild){tx.firstChild.style.fontWeight='500';tx.firstChild.style.color='var(--hts-text-2)';}
				}

				while(wrap.children.length>MAX)wrap.removeChild(wrap.lastChild);
				idx++;
				setTimeout(push,10000);
			}
			setTimeout(push,10000);
		})();
		</script>
		<?php endif; ?>
	</div>
</div>

<?php // ═══ BLOC 6 : Coach compact ═══ ?>
<div class="hts-ds-card" style="padding:24px 26px;margin-bottom:20px">
	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
		<div style="display:flex;align-items:center;gap:10px">
			<div style="width:32px;height:32px;border-radius:10px;background:linear-gradient(135deg,var(--hts-accent),var(--hts-geo));display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(45,127,249,.25)">
				<?php echo HTS_DS::icon( 'zap', 16, '#fff' ); ?>
			</div>
			<span style="font-size:15px;font-weight:700;color:var(--hts-text)">Votre expert</span>
		</div>
		<a href="<?php echo esc_url( $base_url . '&tab=coach' ); ?>" style="font-size:12px;font-weight:700;color:var(--hts-accent);text-decoration:none">Ouvrir</a>
	</div>
	<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:14px">Il connaît votre site. Posez-lui une question.</div>
	<div class="hts-coach-chips" style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:16px">
		<?php foreach ( array( 'Que dois-je faire en premier ?', 'Quelles IA visitent mon site ?', 'Montre-moi mes meilleurs résultats' ) as $chip ) : ?>
		<a href="<?php echo esc_url( $base_url . '&tab=coach&q=' . urlencode( $chip ) ); ?>" style="padding:10px 14px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:500;color:var(--hts-text);text-decoration:none;text-align:left;line-height:1.3"><?php echo esc_html( $chip ); ?></a>
		<?php endforeach; ?>
	</div>
</div>

<?php // ═══ BLOC 7 : Détails techniques (collapsible) ═══ ?>
<div class="hts-ds-card" style="overflow:hidden">
	<button onclick="var b=document.getElementById('hts-dash-tech-body');b.style.display=b.style.display==='none'?'block':'none'" style="width:100%;display:flex;align-items:center;justify-content:space-between;padding:16px 24px;border:none;background:none;cursor:pointer;font-family:var(--hts-font)">
		<div style="display:flex;align-items:center;gap:10px">
			<?php echo HTS_DS::icon( 'gear', 16, 'var(--hts-text-3)' ); ?>
			<span style="font-size:14px;font-weight:700;color:var(--hts-text)">Détails techniques</span>
		</div>
		<div style="display:flex;align-items:center;gap:10px">
			<span style="font-size:12px;font-weight:700;color:var(--hts-success);padding:3px 12px;border-radius:6px;background:var(--hts-success-bg)"><?php echo $health_pct; ?>% OK</span>
			<?php echo HTS_DS::icon( 'chevron-down', 16, 'var(--hts-text-3)' ); ?>
		</div>
	</button>
	<div id="hts-dash-tech-body" style="display:none;padding:0 24px 20px">
		<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:14px">
			<?php
			$gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
			$tech_items = array(
				array( 'label' => 'Santé plugin', 'value' => $health_pct . '%', 'status' => $health_pct >= 80 ? 'ok' : ( $health_pct >= 50 ? 'warn' : 'fail' ) ),
				array( 'label' => 'Agents actifs', 'value' => $agents_active . ' agents', 'status' => $agents_active > 0 ? 'ok' : 'warn' ),
				array( 'label' => 'Search Console', 'value' => $gsc_connected ? 'Connectée' : 'Non', 'status' => $gsc_connected ? 'ok' : 'warn' ),
				array( 'label' => 'Données enrichies', 'value' => 'Actif', 'status' => 'ok' ),
				array( 'label' => 'Redirections', 'value' => 'OK', 'status' => 'ok' ),
			);
			foreach ( $tech_items as $item ) : ?>
			<div style="padding:14px 16px;border-radius:var(--hts-radius-sm);background:var(--hts-surface);border:1px solid var(--hts-border-sub)">
				<div style="font-size:10px;font-weight:600;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px"><?php echo esc_html( $item['label'] ); ?></div>
				<div style="display:flex;align-items:center;gap:6px">
					<?php echo HTS_DS::dot( $item['status'] ); ?>
					<span style="font-size:14px;font-weight:700;color:var(--hts-text)"><?php echo esc_html( $item['value'] ); ?></span>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
		<div style="text-align:center">
			<a href="<?php echo esc_url( $base_url . '&tab=health' ); ?>" class="hts-ds-btn hts-ds-btn--sm" style="text-decoration:none">
				<?php echo HTS_DS::icon( 'eye', 13, 'var(--hts-text-2)' ); ?> Voir le diagnostic complet
			</a>
		</div>
	</div>
</div>

<?php if ( $_needs_initial_scan ) : ?>
<script>
(function(){
	var nonce='<?php echo esc_js( $nonce ); ?>';
	var total=<?php echo (int) $_unscored_count; ?>;
	var done=0;
	var running=false;

	window.htsDashBulkScore=function(){
		if(running)return;
		running=true;
		var btn=document.getElementById('hts-scan-btn');
		var prog=document.getElementById('hts-scan-progress');
		var bar=document.getElementById('hts-scan-bar');
		var counter=document.getElementById('hts-scan-counter');
		var title=document.getElementById('hts-scan-title');
		if(btn)btn.style.display='none';
		if(prog)prog.style.display='block';
		if(title)title.textContent='Analyse en cours...';

		function batch(){
			var fd=new FormData();
			fd.append('action','hts_bulk_score');
			fd.append('nonce',nonce);
			fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
				if(!r.success){if(title)title.textContent='Erreur — rechargez la page';running=false;return}
				var d=r.data;
				done+=d.processed||0;
				var pct=Math.min(100,Math.round(done/total*100));
				if(bar)bar.style.width=pct+'%';
				if(counter)counter.textContent=done+' / '+total+' pages analysées';
				if(d.done){
					if(title)title.textContent='Analyse terminée !';
					if(counter)counter.textContent=done+' pages analysées — rechargement...';
					if(bar)bar.style.width='100%';
					setTimeout(function(){location.reload()},1200);
				}else{
					setTimeout(batch,300);
				}
			}).catch(function(){
				if(title)title.textContent='Erreur réseau — rechargez la page';
				running=false;
			});
		}
		batch();
	};

	// Auto-trigger on first load
	document.addEventListener('DOMContentLoaded',function(){
		htsDashBulkScore();
	});
})();
</script>
<?php endif; ?>

<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>
