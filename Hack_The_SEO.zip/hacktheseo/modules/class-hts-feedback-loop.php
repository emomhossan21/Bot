<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Feedback Loop — Phase 4a (Light)
 *
 * Measures the SEO impact of every logged action by comparing
 * GSC metrics at action time vs after next GSC import.
 *
 * - Hooks into GSC import → runs comparison on all recent actions
 * - Computes impact_7d / impact_30d deltas
 * - Maintains confidence scores per action type
 * - Generates alerts for negative impacts (admin notice, not auto-rollback)
 * - Provides UI data for the Audit Trail impact column
 * - Enriches Decision Engine with confidence-based prioritization
 *
 * Ported from Full v4.0.0, adapted for Light:
 * - No auto-rollback (Light = user validates)
 * - No Content Doctor / Engagement Tracker dependencies
 * - UX non-expert: why + how in alert messages
 * - Labels in plain French (no technical jargon)
 *
 * @since 1.16.0
 * @depends HTS_Audit_Trail (Phase 3), HTS_GSC_Connect (Phase 1)
 */

class HTS_Feedback_Loop {

    const OPT_CONFIDENCE = 'hts_feedback_confidence';
    const OPT_ALERTS     = 'hts_feedback_alerts';

    /* ──────────────────────────────────────────────
     *  INIT
     * ────────────────────────────────────────────── */

    public function init() {
        // Hook BEFORE GSC import to snapshot current positions (for trend detection)
        add_action( 'hts_gsc_import_start', array( $this, 'snapshot_previous_positions' ) );

        // Hook AFTER GSC import to run impact comparison
        add_action( 'hts_gsc_import_complete', array( $this, 'on_gsc_import' ), 10, 1 );

        // AJAX
        add_action( 'wp_ajax_hts_feedback_get_impact',     array( $this, 'ajax_get_impact' ) );
        add_action( 'wp_ajax_hts_feedback_get_confidence',  array( $this, 'ajax_get_confidence' ) );
        add_action( 'wp_ajax_hts_feedback_get_alerts',      array( $this, 'ajax_get_alerts' ) );
        add_action( 'wp_ajax_hts_feedback_dismiss_alert',   array( $this, 'ajax_dismiss_alert' ) );
        add_action( 'wp_ajax_hts_feedback_get_summary',     array( $this, 'ajax_get_summary' ) );
        add_action( 'wp_ajax_hts_feedback_page_report',     array( $this, 'ajax_page_report' ) );

        // Admin notice for critical alerts (only on HTS pages)
        add_action( 'admin_notices', array( $this, 'admin_alert_notice' ) );
    }

    /* ──────────────────────────────────────────────
     *  MAIN: On GSC Import → Compare all recent actions
     * ────────────────────────────────────────────── */

    /**
     * Triggered after a GSC data import (cron or manual).
     * Loops through actions from the last 35 days and computes deltas.
     *
     * Sprint Robustesse v2: smart attribution
     * - Links: measure TARGET page (not source) — link juice goes to target
     * - Metas/content: measure the POST itself
     * - Site-wide trend detection to distinguish algo updates from action impact
     * - Contextual verdicts with explanation
     *
     * @param string $import_type 'pages' or 'queries'
     */
    public function on_gsc_import( $import_type = 'pages' ) {
        if ( $import_type !== 'pages' ) return;

        // FIX 4: sync hook (prio 5) already calls feedback/measure — skip to avoid double execution
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            return;
        }

        if ( ! class_exists( 'HTS_Audit_Trail' ) ) return;

        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return;

        // ── 1. Compute site-wide trend (algo detection) ──
        $site_trend = $this->compute_site_trend();

        // ── 2. Get all actions from last 35 days with gsc_data ──
        $actions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, action_type, post_id, target_id, gsc_data, created_at, impact_7d, impact_30d
             FROM {$table}
             WHERE gsc_data IS NOT NULL
               AND gsc_data != ''
               AND action_type NOT IN ('rollback', 'test_diagnostic')
               AND created_at >= %s
             ORDER BY created_at DESC",
            wp_date( 'Y-m-d H:i:s', strtotime( '-35 days' ) )
        ), ARRAY_A );

        if ( empty( $actions ) ) return;

        // S18 FIX: Filter by current language
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $fl_lang = HTS_Language::get_current_lang();
            if ( $fl_lang ) {
                $fl_lang_args = array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => 'publish',
                    'posts_per_page' => 500,
                    'fields'         => 'ids',
                    'suppress_filters' => false,
                );
                $fl_lang_args = HTS_Language::filter_query_args( $fl_lang_args, $fl_lang );
                $fl_post_ids = get_posts( $fl_lang_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $fl_post_objects = array_map( 'get_post', $fl_post_ids );
                    $fl_post_objects = array_values( HTS_Language::filter_posts_by_lang( $fl_post_objects, $fl_lang ) );
                    $fl_post_ids = wp_list_pluck( $fl_post_objects, 'ID' );
                }
                if ( ! empty( $fl_post_ids ) ) {
                    $actions = array_filter( $actions, function( $a ) use ( $fl_post_ids ) {
                        return in_array( (int) $a['post_id'], $fl_post_ids, true );
                    } );
                    $actions = array_values( $actions );
                }
            }
        }

        $updated_7d  = 0;
        $updated_30d = 0;
        $alerts      = array();
        $skipped_no_gsc      = 0;
        $skipped_no_current  = 0;
        $skipped_link_baseline = 0;

        foreach ( $actions as $action ) {
          try {
            $gsc_at_action = json_decode( $action['gsc_data'], true );
            if ( empty( $gsc_at_action ) ) { $skipped_no_gsc++; continue; }

            $post_id   = absint( $action['post_id'] );
            $target_id = absint( $action['target_id'] );
            $action_id = absint( $action['id'] );
            $action_type = $action['action_type'];
            $days_ago  = (int) ( ( time() - strtotime( $action['created_at'] ) ) / DAY_IN_SECONDS );

            // ── 3. Determine which page to measure based on action type ──
            $measure_id = $this->get_measurement_target( $action_type, $post_id, $target_id );

            // Get current GSC data for the measurement target
            $current = array(
                'clicks'      => (int) get_post_meta( $measure_id, '_hts_gsc_clicks', true ),
                'impressions' => (int) get_post_meta( $measure_id, '_hts_gsc_impressions', true ),
                'position'    => (float) get_post_meta( $measure_id, '_hts_gsc_position', true ),
            );

            // Skip if no current data
            if ( $current['clicks'] === 0 && $current['impressions'] === 0 && $current['position'] == 0 ) { $skipped_no_current++; continue; }

            // For links measuring target: use target's GSC at action time if stored, else use source's as proxy
            $baseline = $gsc_at_action;
            if ( $measure_id !== $post_id ) {
                // Measuring target — check if we stored target GSC
                $target_gsc_key = '_hts_gsc_at_link_' . $action_id;
                $stored_target_gsc = get_post_meta( $measure_id, $target_gsc_key, true );
                if ( $stored_target_gsc && is_array( $stored_target_gsc ) ) {
                    $baseline = $stored_target_gsc;
                } else {
                    // No stored target baseline — capture it NOW for future comparison
                    // This means we only have "current" for the first measurement
                    // Store current as baseline for the next cycle
                    update_post_meta( $measure_id, $target_gsc_key, $current );
                    $skipped_link_baseline++;
                    continue; // Skip this cycle — we'll measure on the next GSC import
                }
            }

            $delta = self::compute_delta( $baseline, $current );

            // ── 4. Enrich delta with context ──
            $delta['measured_page']    = $measure_id;
            $delta['measured_title']   = get_the_title( $measure_id );
            $delta['site_trend']       = $site_trend;
            $delta['action_type']      = $action_type;
            $delta['is_link']          = $this->is_link_action( $action_type );

            // Adjusted verdict: subtract site-wide trend
            $adjusted_delta = $delta['position_delta'] - $site_trend['avg_position_delta'];
            $delta['adjusted_position_delta'] = round( $adjusted_delta, 1 );

            // Smart verdict
            $delta['verdict'] = $this->compute_smart_verdict( $delta, $site_trend );
            $delta['context'] = $this->compute_context( $delta, $action, $site_trend );

            // ── 5. Store impact ──
            if ( $days_ago >= 5 && $days_ago <= 21 && empty( $action['impact_7d'] ) ) {
                $wpdb->update( $table,
                    array( 'impact_7d' => wp_json_encode( $delta ) ),
                    array( 'id' => $action_id ),
                    array( '%s' ), array( '%d' )
                );
                $updated_7d++;

                if ( $delta['verdict'] === 'negative' && $delta['adjusted_position_delta'] > 12 ) {
                    $alerts[] = self::create_alert( $action, $delta, '7d' );
                }
            }

            if ( $days_ago >= 20 && $days_ago <= 45 && empty( $action['impact_30d'] ) ) {
                $wpdb->update( $table,
                    array( 'impact_30d' => wp_json_encode( $delta ) ),
                    array( 'id' => $action_id ),
                    array( '%s' ), array( '%d' )
                );
                $updated_30d++;

                if ( $delta['verdict'] === 'negative' && $delta['adjusted_position_delta'] > 10 ) {
                    $alerts[] = self::create_alert( $action, $delta, '30d' );
                }
            }
          } catch ( \Throwable $e ) {
            // S13-B: One broken action must not kill the entire feedback loop
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Feedback Loop error on action #' . ( $action['id'] ?? '?' ) . ': ' . $e->getMessage(), 'error', 'feedback' );
            }
          }
        }

        // Update confidence scores
        $this->update_confidence_scores();

        // Store alerts (deduped by action_id + window)
        if ( ! empty( $alerts ) ) {
            $existing = get_option( self::OPT_ALERTS, array() );
            $existing_keys = array();
            foreach ( $existing as $ea ) {
                $ek = ( $ea['action_id'] ?? 0 ) . '_' . ( $ea['window'] ?? '' );
                $existing_keys[ $ek ] = true;
            }
            $new_alerts = array();
            foreach ( $alerts as $a ) {
                $ak = ( $a['action_id'] ?? 0 ) . '_' . ( $a['window'] ?? '' );
                if ( ! isset( $existing_keys[ $ak ] ) ) {
                    $new_alerts[] = $a;
                    $existing_keys[ $ak ] = true;
                }
            }
            if ( ! empty( $new_alerts ) ) {
                $merged = array_merge( $existing, $new_alerts );
                $merged = array_slice( $merged, -50 );
                update_option( self::OPT_ALERTS, $merged, false );
            }
        }

        if ( $updated_7d > 0 || $updated_30d > 0 ) {
            // Invalidate cached impact report
            delete_transient( 'hts_impact_report_30' );
            delete_transient( 'hts_impact_report_7' );

            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    'Feedback Loop v2 : ' . $updated_7d . ' impact(s) J+7, ' . $updated_30d . ' impact(s) J+30. '
                    . count( $alerts ) . ' alerte(s). Tendance site : '
                    . ( $site_trend['avg_position_delta'] > 0 ? '+' : '' ) . round( $site_trend['avg_position_delta'], 1 ),
                    'info', 'feedback'
                );
            }
        }

        // Diagnostic logging — skip counters
        if ( function_exists( 'hts_add_log' ) && ( $skipped_no_gsc > 0 || $skipped_no_current > 0 || $skipped_link_baseline > 0 ) ) {
            hts_add_log(
                'Feedback Loop: ' . $updated_7d . ' J+7, ' . $updated_30d . ' J+30. Skips: '
                . $skipped_no_gsc . ' no_gsc, ' . $skipped_no_current . ' no_current, '
                . $skipped_link_baseline . ' link_first_pass',
                'info', 'feedback'
            );
        }
    }

    /* ──────────────────────────────────────────────
     *  SMART ATTRIBUTION — Which page to measure
     * ────────────────────────────────────────────── */

    /**
     * Determine which page to measure GSC impact for a given action.
     * Links: measure the TARGET (that's where link juice goes).
     * Everything else: measure the POST itself.
     */
    private function get_measurement_target( $action_type, $post_id, $target_id ) {
        // Link actions where the TARGET benefits from the link
        $link_to_target = array(
            'link_outbound',      // A→B : measure B
            'link_sibling',       // A→B sibling: measure B
            'link_cross_out',     // A→B cross-cocon: measure B
            'link_manual',        // A→B manual: measure B
            'link_to_money',      // A→money: measure money page
            'add_internal_links', // S13-B: linking action → measure target
            'fix_orphan_links',   // S13-B: orphan rescue → measure the orphan (target)
        );

        // Link actions where the POST benefits
        $link_to_source = array(
            'link_inbound',   // B→A: measure A (receiving the link)
            'link_cross_in',  // B→A cross-cocon: measure A
        );

        if ( in_array( $action_type, $link_to_target, true ) && $target_id > 0 ) {
            return $target_id;
        }

        // All other actions: measure the post itself
        return $post_id;
    }

    private function is_link_action( $action_type ) {
        return strpos( $action_type, 'link_' ) === 0
            || $action_type === 'add_internal_links'
            || $action_type === 'fix_orphan_links';
    }

    /* ──────────────────────────────────────────────
     *  SITE-WIDE TREND — Algo detection
     * ────────────────────────────────────────────── */

    /**
     * Compute average position change across all tracked posts.
     * If the entire site moves, it's an algo update, not our action.
     *
     * @return array { avg_position_delta, tracked_posts, is_algo_update, direction }
     */
    public function compute_site_trend() {
        global $wpdb;

        // Get all posts with both current GSC and a recent position snapshot
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $rows = $wpdb->get_results(
            "SELECT p.ID,
                    CAST(pm_pos.meta_value AS DECIMAL(10,2)) as current_pos,
                    CAST(pm_prev.meta_value AS DECIMAL(10,2)) as prev_pos
             FROM {$wpdb->posts} p
             JOIN {$wpdb->postmeta} pm_pos ON p.ID = pm_pos.post_id AND pm_pos.meta_key = '_hts_gsc_position'
             LEFT JOIN {$wpdb->postmeta} pm_prev ON p.ID = pm_prev.post_id AND pm_prev.meta_key = '_hts_gsc_position_prev'
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
             AND CAST(pm_pos.meta_value AS DECIMAL(10,2)) > 0",
            ARRAY_A
        );

        if ( empty( $rows ) || count( $rows ) < 3 ) {
            return array(
                'avg_position_delta' => 0.0,
                'tracked_posts'      => 0,
                'is_algo_update'     => false,
                'direction'          => 'stable',
            );
        }

        // S18 FIX: Filter by current language
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $fl_trend_lang = HTS_Language::get_current_lang();
            if ( $fl_trend_lang ) {
                $fl_trend_args = array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => 'publish',
                    'posts_per_page' => 500,
                    'fields'         => 'ids',
                    'suppress_filters' => false,
                );
                $fl_trend_args = HTS_Language::filter_query_args( $fl_trend_args, $fl_trend_lang );
                $fl_trend_ids = get_posts( $fl_trend_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $fl_trend_objects = array_map( 'get_post', $fl_trend_ids );
                    $fl_trend_objects = array_values( HTS_Language::filter_posts_by_lang( $fl_trend_objects, $fl_trend_lang ) );
                    $fl_trend_ids = wp_list_pluck( $fl_trend_objects, 'ID' );
                }
                if ( ! empty( $fl_trend_ids ) ) {
                    $rows = array_filter( $rows, function( $r ) use ( $fl_trend_ids ) {
                        return in_array( (int) $r['ID'], $fl_trend_ids, true );
                    } );
                    $rows = array_values( $rows );
                }
                if ( count( $rows ) < 3 ) {
                    return array(
                        'avg_position_delta' => 0.0,
                        'tracked_posts'      => 0,
                        'is_algo_update'     => false,
                        'direction'          => 'stable',
                    );
                }
            }
        }

        // Compute average delta
        $deltas = array();
        foreach ( $rows as $r ) {
            $current = (float) $r['current_pos'];
            $prev    = (float) ( $r['prev_pos'] ?: 0 );
            // S13-B: Skip posts where prev is 0 or null (first import, no previous snapshot)
            // Otherwise delta = current - 0 = +15 → false "algo update" detection
            if ( $prev <= 0 || $current <= 0 ) continue;
            $deltas[] = $current - $prev;
        }

        if ( empty( $deltas ) ) {
            return array(
                'avg_position_delta' => 0.0,
                'tracked_posts'      => count( $rows ),
                'is_algo_update'     => false,
                'direction'          => 'stable',
            );
        }

        $avg = array_sum( $deltas ) / count( $deltas );

        // If 70%+ of posts moved in the same direction by 2+ positions → algo update
        $same_dir_count = 0;
        $dir = $avg > 0 ? 'worse' : 'better';
        foreach ( $deltas as $d ) {
            if ( $avg > 0 && $d > 1 ) $same_dir_count++;
            if ( $avg < 0 && $d < -1 ) $same_dir_count++;
        }
        $is_algo = ( $same_dir_count / count( $deltas ) ) >= 0.7 && abs( $avg ) >= 2;

        return array(
            'avg_position_delta' => round( $avg, 1 ),
            'tracked_posts'      => count( $rows ),
            'is_algo_update'     => $is_algo,
            'direction'          => abs( $avg ) < 1 ? 'stable' : $dir,
            'pct_affected'       => round( $same_dir_count / count( $deltas ) * 100 ),
        );
    }

    /**
     * Store previous position for trend computation.
     * Called before GSC data is updated.
     */
    public function snapshot_previous_positions() {
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $posts = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as pos
             FROM {$wpdb->posts} p
             JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_gsc_position'
             WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
             AND CAST(pm.meta_value AS DECIMAL(10,2)) > 0",
            ARRAY_A
        );
        // S18 FIX: Filter by current language
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $fl_snap_lang = HTS_Language::get_current_lang();
            if ( $fl_snap_lang ) {
                $fl_snap_args = array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => 'publish',
                    'posts_per_page' => 500,
                    'fields'         => 'ids',
                    'suppress_filters' => false,
                );
                $fl_snap_args = HTS_Language::filter_query_args( $fl_snap_args, $fl_snap_lang );
                $fl_snap_ids = get_posts( $fl_snap_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $fl_snap_objects = array_map( 'get_post', $fl_snap_ids );
                    $fl_snap_objects = array_values( HTS_Language::filter_posts_by_lang( $fl_snap_objects, $fl_snap_lang ) );
                    $fl_snap_ids = wp_list_pluck( $fl_snap_objects, 'ID' );
                }
                if ( ! empty( $fl_snap_ids ) ) {
                    $posts = array_filter( $posts, function( $p ) use ( $fl_snap_ids ) {
                        return in_array( (int) $p['ID'], $fl_snap_ids, true );
                    } );
                    $posts = array_values( $posts );
                }
            }
        }

        foreach ( $posts as $p ) {
            update_post_meta( $p['ID'], '_hts_gsc_position_prev', $p['pos'] );
        }
    }

    /* ──────────────────────────────────────────────
     *  SMART VERDICT — Context-aware evaluation
     * ────────────────────────────────────────────── */

    /**
     * Compute a smart verdict considering site-wide trends.
     */
    private function compute_smart_verdict( $delta, $site_trend ) {
        $pos_delta  = $delta['position_delta'];
        $adj_delta  = $delta['adjusted_position_delta'];
        $clk_delta  = $delta['clicks_delta'];
        $clk_pct    = $delta['clicks_pct'] ?? 0;
        $ctr_delta  = $delta['ctr_delta'] ?? 0;
        $is_algo    = $site_trend['is_algo_update'];
        $impr_before = (int) ( $delta['impressions_before'] ?? 0 );
        $impr_after  = (int) ( $delta['impressions_after'] ?? 0 );
        $clk_before  = (int) ( $delta['clicks_before'] ?? 0 );

        // ══════════════════════════════════════════════════════════════════
        // Best-practice SEO 2026 — Statistical significance thresholds
        //
        // Google's position is an AVERAGE of where a page appeared across
        // all queries. With < 200 impressions, swings of ±10 positions
        // are normal noise. CTR needs 500+ impressions to be meaningful.
        //
        // Industry reference: Google's own documentation states position
        // data is "not a reliable metric for individual pages with low
        // impression counts." (Search Console Help, 2025)
        // ══════════════════════════════════════════════════════════════════

        // Gate 1: Both periods must have data (no "new page appeared" false signals)
        if ( $impr_before < 50 || $impr_after < 50 ) {
            return 'neutral'; // Not enough data in BOTH periods
        }

        // Gate 2: For position-based verdicts, need significant impressions
        $pos_reliable = ( $impr_before >= 200 && $impr_after >= 200 );

        // Gate 3: For CTR-based verdicts, need even more impressions
        $ctr_reliable = ( $impr_before >= 500 && $impr_after >= 500 );

        // If algo update and page moved with the trend → not our doing
        if ( $is_algo && abs( $adj_delta ) < 5 ) {
            return 'algo_neutral';
        }

        // ── Positive: page improved significantly ──
        $is_positive = false;
        // Position improved by 5+ (adjusted) with reliable data
        if ( $pos_reliable && $adj_delta <= -5 ) $is_positive = true;
        // Clicks grew by 15+ with meaningful baseline
        if ( $clk_delta >= 15 && $clk_before >= 10 ) $is_positive = true;
        // Clicks grew 40%+ with solid baseline (avoids 1→2 = +100%)
        if ( $clk_pct >= 40 && $clk_before >= 20 ) $is_positive = true;
        // CTR improved 1.5%+ with reliable impression count
        if ( $ctr_reliable && $ctr_delta >= 1.5 ) $is_positive = true;

        if ( $is_positive ) return 'positive';

        // ── Negative: page degraded significantly ──
        // Thresholds are ASYMMETRIC — harder to declare negative than positive
        // (conservative approach: don't alarm client unless clear degradation)
        $is_negative = false;
        // Position dropped by 8+ (adjusted) with reliable data
        if ( $pos_reliable && $adj_delta >= 8 ) $is_negative = true;
        // Clicks dropped by 15+ with meaningful baseline
        if ( $clk_delta <= -15 && $clk_before >= 20 ) $is_negative = true;
        // Clicks dropped 50%+ with solid baseline
        if ( $clk_pct <= -50 && $clk_before >= 25 ) $is_negative = true;
        // CTR dropped 2%+ with reliable impression count
        if ( $ctr_reliable && $ctr_delta <= -2.0 ) $is_negative = true;

        if ( $is_negative ) return 'negative';

        return 'neutral';
    }

    /**
     * Generate a human-readable context explanation.
     */
    private function compute_context( $delta, $action, $site_trend ) {
        $parts = array();
        $action_type = $action['action_type'];
        $measure_id  = $delta['measured_page'];
        $adj_delta   = $delta['adjusted_position_delta'];

        // Action type label
        $type_labels = array(
            'link_outbound'     => 'Lien sortant ajouté',
            'link_inbound'      => 'Lien entrant reçu',
            'link_sibling'      => 'Lien frère (cocon)',
            'link_cross_out'    => 'Lien cross-cocon sortant',
            'link_cross_in'     => 'Lien cross-cocon entrant',
            'link_manual'       => 'Lien ajouté manuellement',
            'link_to_money'     => 'Lien vers page business',
            'link_removed'      => 'Lien supprimé',
            'meta_title'        => 'Title modifié',
            'meta_description'  => 'Meta description modifiée',
            'meta_auto_pilot'   => 'Meta optimisée (auto)',
            'optimize_meta_both'  => 'Title + Description optimisés',
            'optimize_meta_title' => 'Title optimisé',
            'optimize_meta_desc'  => 'Description optimisée',
            'add_meta_title'    => 'Title SEO généré',
            'add_meta_desc'     => 'Description SEO générée',
            'content_modified'  => 'Contenu modifié',
            'content_write'     => 'Contenu réécrit',
            'content_refresh'   => 'Contenu rafraîchi',
            'enrich_thin_content' => 'Contenu enrichi',
            'article_created'   => 'Article créé',
            'article_published' => 'Article publié',
            'add_faq'           => 'FAQ structurée ajoutée',
            'add_internal_links' => 'Liens internes ajoutés',
            'geo_optimize'      => 'Optimisation visibilité IA',
            'fix_orphan_links'  => 'Page orpheline corrigée',
            'fix_image_alt'     => 'Alt texte images corrigé',
            'generate_article'  => 'Article généré par IA',
            'schedule_publication' => 'Publication planifiée',
            'coach_suggestion'  => 'Suggestion Coach SEO',
            'delete_page'       => 'Page supprimée',
        );
        $parts[] = $type_labels[ $action_type ] ?? $action_type;

        // What was measured
        if ( $delta['is_link'] && $measure_id != $action['post_id'] ) {
            $parts[] = 'Impact mesuré sur la cible : « ' . mb_substr( $delta['measured_title'], 0, 40 ) . ' »';
        }

        // Site trend context
        if ( $site_trend['is_algo_update'] ) {
            $dir_label = $site_trend['direction'] === 'worse' ? 'baisse' : 'hausse';
            $parts[] = 'Tendance site : ' . $dir_label . ' générale de ' . abs( $site_trend['avg_position_delta'] ) . ' positions (' . $site_trend['pct_affected'] . '% des pages) — probable mise à jour algo';
        } elseif ( abs( $site_trend['avg_position_delta'] ) >= 1 ) {
            $parts[] = 'Tendance site : ' . ( $site_trend['avg_position_delta'] > 0 ? '+' : '' ) . $site_trend['avg_position_delta'] . ' positions en moyenne';
        }

        // Seasonal detection (simple: check if title contains seasonal keywords)
        $title = mb_strtolower( get_the_title( $action['post_id'] ) );
        $seasonal_words = array( 'black friday', 'noël', 'christmas', 'soldes', 'été', 'summer', 'hiver', 'winter', 'rentrée', 'saint-valentin', 'valentine', 'halloween', 'pâques', 'easter' );
        foreach ( $seasonal_words as $sw ) {
            if ( mb_strpos( $title, $sw ) !== false ) {
                $parts[] = 'Contenu saisonnier détecté — les variations de position peuvent être normales';
                break;
            }
        }

        return implode( '. ', $parts ) . '.';
    }

    /* ──────────────────────────────────────────────
     *  DELTA CALCULATION
     * ────────────────────────────────────────────── */

    /**
     * Compute the delta between GSC at action time and current GSC.
     *
     * Convention:
     * - position_delta > 0 = WORSE (position number went up)
     * - position_delta < 0 = BETTER (position number went down)
     * - clicks_delta > 0 = MORE clicks (good)
     * - impressions_delta > 0 = MORE impressions (good)
     */
    public static function compute_delta( $at_action, $current ) {
        $pos_before = (float) ( $at_action['position'] ?? 0 );
        $pos_after  = (float) ( $current['position'] ?? 0 );

        $clicks_before = (int) ( $at_action['clicks'] ?? 0 );
        $clicks_after  = (int) ( $current['clicks'] ?? 0 );

        $impr_before = (int) ( $at_action['impressions'] ?? 0 );
        $impr_after  = (int) ( $current['impressions'] ?? 0 );

        // Position delta: positive = worse (went from 5 to 8 = +3 = bad)
        $position_delta = $pos_after - $pos_before;

        // Clicks delta: positive = better
        $clicks_delta = $clicks_after - $clicks_before;

        // Impressions delta: positive = better
        $impressions_delta = $impr_after - $impr_before;

        // S13-B: CTR delta (computed from clicks/impressions)
        $ctr_before = $impr_before > 0 ? round( $clicks_before / $impr_before * 100, 2 ) : 0;
        $ctr_after  = $impr_after > 0 ? round( $clicks_after / $impr_after * 100, 2 ) : 0;
        $ctr_delta  = round( $ctr_after - $ctr_before, 2 );

        // S13-B: Percentage changes for better comparison across different traffic levels
        $clicks_pct = $clicks_before > 0 ? round( ( $clicks_delta / $clicks_before ) * 100, 1 ) : ( $clicks_after > 0 ? 100 : 0 );
        $impr_pct   = $impr_before > 0 ? round( ( $impressions_delta / $impr_before ) * 100, 1 ) : ( $impr_after > 0 ? 100 : 0 );

        // Raw verdict (pre-adjustment) — used as fallback when smart verdict not yet computed
        // Best-practice 2026: require both periods to have meaningful data
        $verdict = 'neutral';
        $has_data = ( $impr_before >= 200 && $impr_after >= 200 );
        if ( $has_data ) {
            if ( $position_delta <= -5 || ( $clicks_delta >= 15 && $clicks_before >= 10 ) || ( $clicks_pct >= 40 && $clicks_before >= 20 ) ) {
                $verdict = 'positive';
            } elseif ( $position_delta >= 8 || ( $clicks_delta <= -15 && $clicks_before >= 20 ) || ( $clicks_pct <= -50 && $clicks_before >= 25 ) ) {
                $verdict = 'negative';
            }
        }

        return array(
            'position_before'    => round( $pos_before, 1 ),
            'position_after'     => round( $pos_after, 1 ),
            'position_delta'     => round( $position_delta, 1 ),
            'clicks_before'      => $clicks_before,
            'clicks_after'       => $clicks_after,
            'clicks_delta'       => $clicks_delta,
            'clicks_pct'         => $clicks_pct,
            'impressions_before' => $impr_before,
            'impressions_after'  => $impr_after,
            'impressions_delta'  => $impressions_delta,
            'impressions_pct'    => $impr_pct,
            'ctr_before'         => $ctr_before,
            'ctr_after'          => $ctr_after,
            'ctr_delta'          => $ctr_delta,
            'verdict'            => $verdict,
            'computed_at'        => current_time( 'mysql' ),
        );
    }

    /**
     * Get verdict label, icon and color for display.
     */
    public static function verdict_display( $verdict ) {
        $map = array(
            'positive'     => array( 'icon' => '🟢', 'label' => 'Positif',     'color' => '#16a34a' ),
            'neutral'      => array( 'icon' => '🟡', 'label' => 'Neutre',      'color' => '#ca8a04' ),
            'negative'     => array( 'icon' => '🔴', 'label' => 'Négatif',     'color' => '#dc2626' ),
            'algo_neutral' => array( 'icon' => '🔄', 'label' => 'Algo Google', 'color' => '#6366f1' ),
        );
        return $map[ $verdict ] ?? $map['neutral'];
    }

    /**
     * Human-readable verdict explanation (UX non-expert).
     */
    public static function verdict_explanation( $verdict, $delta ) {
        switch ( $verdict ) {
            case 'positive':
                $parts = array();
                if ( ( $delta['position_delta'] ?? 0 ) <= -2 ) {
                    $parts[] = 'votre page a gagné ' . abs( round( $delta['position_delta'], 1 ) ) . ' places dans Google';
                }
                if ( ( $delta['clicks_delta'] ?? 0 ) > 5 ) {
                    $parts[] = 'vous avez reçu ' . $delta['clicks_delta'] . ' clics supplémentaires';
                    if ( ! empty( $delta['clicks_pct'] ) && $delta['clicks_pct'] > 20 ) {
                        $parts[ count( $parts ) - 1 ] .= ' (+' . $delta['clicks_pct'] . '%)';
                    }
                }
                if ( ( $delta['ctr_delta'] ?? 0 ) > 0.5 ) {
                    $parts[] = 'le taux de clic a augmenté de ' . $delta['ctr_delta'] . ' points';
                }
                return ! empty( $parts ) ? implode( ' et ', $parts ) . '.' : 'Les métriques se sont améliorées.';

            case 'negative':
                $parts = array();
                if ( ( $delta['position_delta'] ?? 0 ) >= 3 ) {
                    $parts[] = 'votre page a perdu ' . round( $delta['position_delta'], 1 ) . ' places dans Google';
                }
                if ( ( $delta['clicks_delta'] ?? 0 ) < -5 ) {
                    $parts[] = 'vous avez perdu ' . abs( $delta['clicks_delta'] ) . ' clics';
                    if ( ! empty( $delta['clicks_pct'] ) && $delta['clicks_pct'] < -20 ) {
                        $parts[ count( $parts ) - 1 ] .= ' (' . $delta['clicks_pct'] . '%)';
                    }
                }
                if ( ( $delta['ctr_delta'] ?? 0 ) < -0.5 ) {
                    $parts[] = 'le taux de clic a baissé de ' . abs( $delta['ctr_delta'] ) . ' points';
                }
                $msg = ! empty( $parts ) ? implode( ' et ', $parts ) . '.' : 'Les métriques se sont dégradées.';
                $msg .= ' Vous pouvez annuler cette modification si nécessaire.';
                return $msg;

            case 'algo_neutral':
                $trend = $delta['site_trend'] ?? array();
                $dir = ( $trend['direction'] ?? '' ) === 'worse' ? 'baisse' : 'hausse';
                return 'Variation liée à une mise à jour Google (' . $dir . ' générale du site). Pas d\'action nécessaire.';

            default:
                return 'Pas de changement significatif détecté. Les variations sont dans la normale.';
        }
    }

    /* ──────────────────────────────────────────────
     *  CONFIDENCE SCORES
     * ────────────────────────────────────────────── */

    /**
     * Recalculate confidence scores from all measured actions.
     * Confidence = % of positive outcomes for each action type.
     */
    public function update_confidence_scores() {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';

        $types = array(
            'link_outbound', 'link_inbound', 'link_manual',
            'link_sibling', 'link_cross_out', 'link_cross_in',
            'link_to_money', 'link_removed',
            'article_published', 'article_created', 'content_modified',
            'meta_auto_pilot', 'meta_title', 'meta_description',
            'optimize_meta_both', 'optimize_meta_title', 'optimize_meta_desc',
            'add_meta_title', 'add_meta_desc',
            'add_faq', 'add_internal_links', 'geo_optimize',
            'fix_orphan_links', 'fix_image_alt',
            'generate_article', 'schedule_publication',
            'enrich_thin_content', 'content_refresh',
            'coach_suggestion',
        );
        $scores = array();

        foreach ( $types as $type ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT impact_7d, impact_30d FROM {$table}
                 WHERE action_type = %s AND (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)",
                $type
            ), ARRAY_A );

            $total    = count( $rows );
            $positive = 0;
            $neutral  = 0;
            $negative = 0;

            foreach ( $rows as $row ) {
                // Prefer 30d if available, else 7d
                $impact = ! empty( $row['impact_30d'] ) ? json_decode( $row['impact_30d'], true ) : json_decode( $row['impact_7d'], true );
                if ( empty( $impact ) ) continue;

                $verdict = $impact['verdict'] ?? 'neutral';
                if ( $verdict === 'positive' ) $positive++;
                elseif ( $verdict === 'negative' ) $negative++;
                else $neutral++;
            }

            $confidence = $total > 0 ? round( ( $positive / $total ) * 100, 0 ) : 0;

            $scores[ $type ] = array(
                'total'      => $total,
                'positive'   => $positive,
                'neutral'    => $neutral,
                'negative'   => $negative,
                'confidence' => $confidence,
            );
        }

        update_option( self::OPT_CONFIDENCE, $scores, false );
        return $scores;
    }

    /**
     * Get current confidence scores.
     */
    public static function get_confidence() {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'feedback/confidence', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data'] ) ) {
                return is_array( $result['data'] ) ? $result['data'] : array();
            }
        }
        return get_option( self::OPT_CONFIDENCE, array() );
    }

    /**
     * Get confidence for a specific action type (used by Decision Engine).
     *
     * @param string $action_type
     * @return int 0-100 confidence percentage, or -1 if no data
     */
    public static function get_type_confidence( $action_type ) {
        $scores = self::get_confidence();
        if ( empty( $scores[ $action_type ] ) ) return -1;
        if ( $scores[ $action_type ]['total'] < 3 ) return -1; // Not enough data
        return (int) $scores[ $action_type ]['confidence'];
    }

    /* ──────────────────────────────────────────────
     *  ALERTS
     * ────────────────────────────────────────────── */

    private static function create_alert( $action, $delta, $window ) {
        $post_title = get_the_title( $action['post_id'] );
        $window_label = $window === '7d' ? '7 jours' : '30 jours';
        $action_type = $action['action_type'];
        $is_link = strpos( $action_type, 'link_' ) === 0;
        $is_algo = ! empty( $delta['site_trend']['is_algo_update'] );
        $context = $delta['context'] ?? '';

        // Determine what was measured
        $measured_page = $delta['measured_page'] ?? $action['post_id'];
        $measured_title = $delta['measured_title'] ?? $post_title;
        $adj_delta = $delta['adjusted_position_delta'] ?? $delta['position_delta'];

        // Can we rollback this action?
        $rollback_types = array(
            'link_outbound', 'link_inbound', 'link_sibling', 'link_cross_out', 'link_cross_in',
            'link_manual', 'link_to_money',
            'meta_title', 'meta_description', 'meta_auto_pilot',
            'content_modified', 'content_write',
        );
        $can_rollback = in_array( $action_type, $rollback_types, true );

        // Smart explanation
        if ( $is_algo ) {
            $why = sprintf(
                '« %s » a reculé de %.1f positions en %s. Cependant, %d%% des pages du site ont subi un recul similaire — c\'est probablement une mise à jour d\'algorithme Google, pas cette action.',
                $measured_title,
                abs( $delta['position_delta'] ),
                $window_label,
                $delta['site_trend']['pct_affected'] ?? 0
            );
            $how = 'Aucune action requise — attendez que l\'algorithme se stabilise. Si la position ne revient pas en 2 semaines, réévaluez.';
            $can_rollback = false; // Don't suggest rollback for algo updates
        } else {
            $why = sprintf(
                '« %s » a reculé de %.1f positions (corrigé de la tendance site : %.1f) en %s.',
                $measured_title,
                abs( $adj_delta ),
                $delta['site_trend']['avg_position_delta'] ?? 0,
                $window_label
            );
            if ( $is_link ) {
                $source_title = mb_substr( $post_title, 0, 40 );
                $how = $can_rollback
                    ? 'Ce lien depuis « ' . $source_title . ' » peut être la cause. Utilisez le bouton « Annuler » pour supprimer le lien et restaurer le contenu précédent.'
                    : 'Vérifiez l\'article pour identifier d\'autres causes possibles (contenu dupliqué, cannibalisation).';
            } else {
                $how = $can_rollback
                    ? 'Vous pouvez annuler cette modification pour restaurer le contenu précédent.'
                    : 'Vérifiez la Google Search Console pour plus de contexte.';
            }
        }

        return array(
            'id'           => 'alert_' . $action['id'] . '_' . $window,
            'action_id'    => (int) $action['id'],
            'action_type'  => $action_type,
            'post_id'      => (int) $action['post_id'],
            'post_title'   => $post_title,
            'measured_page' => $measured_page,
            'measured_title' => $measured_title,
            'window'       => $window,
            'delta'        => $delta,
            'severity'     => $is_algo ? 'info' : ( abs( $adj_delta ) >= 5 ? 'critical' : 'warning' ),
            'can_rollback' => $can_rollback,
            'is_algo'      => $is_algo,
            'why'          => $why,
            'how'          => $how,
            'context'      => $context,
            'dismissed'    => false,
            'created_at'   => current_time( 'mysql' ),
        );
    }

    /**
     * Get active (non-dismissed) alerts.
     */
    public static function get_active_alerts() {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'feedback/alerts', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data'] ) ) {
                return is_array( $result['data'] ) ? $result['data'] : array();
            }
        }
        $alerts = get_option( self::OPT_ALERTS, array() );
        return array_values( array_filter( $alerts, function( $a ) {
            return empty( $a['dismissed'] );
        } ) );
    }

    /**
     * Admin notice for critical alerts (HTS pages only).
     */
    public function admin_alert_notice() {
        if ( ! isset( $_GET['page'] ) || strpos( $_GET['page'], 'hts' ) === false ) return;

        $active = self::get_active_alerts();
        $critical = array_filter( $active, function( $a ) { return ( $a['severity'] ?? '' ) === 'critical'; } );

        if ( empty( $critical ) ) return;

        $count = count( $critical );
        echo '<div class="notice notice-warning is-dismissible"><p>';
        echo '<strong>Hack The SEO — Suivi d\'impact</strong> : ';
        echo esc_html( $count ) . ' action(s) avec un impact négatif détecté. ';
        echo 'Des pages ont perdu des positions dans Google après modification. ';
        echo '<a href="' . esc_url( admin_url( 'admin.php?page=hts-light-dashboard&tab=impact' ) ) . '">Voir les détails</a>';
        echo '</p></div>';
    }

    /* ──────────────────────────────────────────────
     *  IMPACT SUMMARY (for Cockpit dashboard)
     * ────────────────────────────────────────────── */

    /**
     * Compute an impact summary for the last N days.
     * Returns counts of positive/neutral/negative + net position/clicks.
     *
     * @param int $days Number of days to look back.
     * @return array|null Summary or null if no data.
     */
    public static function compute_impact_summary( $days = 30 ) {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'feedback/summary', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
                'days' => $days,
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data'] ) ) {
                return $result['data'];
            }
        }
        // Request-level cache — avoid computing 3 times per cockpit load
        static $cache = array();
        if ( isset( $cache[ $days ] ) ) return $cache[ $days ];

        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return null;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, action_type, post_id, anchor_text, impact_7d, impact_30d, created_at
             FROM {$table}
             WHERE (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)
               AND created_at >= %s
             ORDER BY created_at DESC",
            wp_date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) )
        ), ARRAY_A );

        if ( empty( $rows ) ) return null;

        $positive = 0;
        $neutral  = 0;
        $negative = 0;
        $algo     = 0;
        $net_position = 0.0;
        $net_clicks   = 0;
        $actions  = array();

        foreach ( $rows as $row ) {
            // Prefer 30d data if available
            $impact = ! empty( $row['impact_30d'] ) ? json_decode( $row['impact_30d'], true ) : json_decode( $row['impact_7d'], true );
            if ( empty( $impact ) ) continue;

            $verdict = $impact['verdict'] ?? 'neutral';
            if ( $verdict === 'positive' ) $positive++;
            elseif ( $verdict === 'negative' ) $negative++;
            elseif ( $verdict === 'algo_neutral' ) $algo++;
            else $neutral++;

            $net_position += (float) ( $impact['position_delta'] ?? 0 );
            $net_clicks   += (int) ( $impact['clicks_delta'] ?? 0 );

            $vd = self::verdict_display( $verdict );
            $actions[] = array(
                'id'          => (int) $row['id'],
                'action_type' => $row['action_type'],
                'post_id'     => (int) $row['post_id'],
                'post_title'  => get_the_title( $row['post_id'] ),
                'anchor'      => $row['anchor_text'],
                'verdict'     => $verdict,
                'icon'        => $vd['icon'],
                'color'       => $vd['color'],
                'pos_delta'   => round( (float) ( $impact['position_delta'] ?? 0 ), 1 ),
                'clk_delta'   => (int) ( $impact['clicks_delta'] ?? 0 ),
                'created_at'  => $row['created_at'],
            );
        }

        $total = $positive + $neutral + $negative + $algo;

        $result = array(
            'total'        => $total,
            'positive'     => $positive,
            'neutral'      => $neutral,
            'negative'     => $negative,
            'algo'         => $algo,
            'net_position' => round( $net_position, 1 ),
            'net_clicks'   => $net_clicks,
            'actions'      => $actions,
        );
        $cache[ $days ] = $result;
        return $result;
    }

    /* ──────────────────────────────────────────────
     *  PAGE-CENTRIC IMPACT REPORT
     *  Groups all actions by affected page, computes aggregate impact
     * ────────────────────────────────────────────── */

    /**
     * Get a page-centric impact report.
     * Groups actions by the page they affected (using smart attribution).
     *
     * Returns array of pages sorted by severity:
     * [
     *   {
     *     post_id, title, url,
     *     position_before, position_after, position_delta,
     *     clicks_before, clicks_after, clicks_delta,
     *     actions: [ { id, type, label, anchor, source_title, verdict, pos_delta, date } ],
     *     visits: { total, ai, avg_time, avg_scroll },
     *     verdict, context, can_rollback
     *   }
     * ]
     */
    public static function get_page_impact_report( $days = 30 ) {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) return array();

        // Get all actions with impact data
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, action_type, post_id, target_id, anchor_text, impact_7d, impact_30d, created_at
             FROM {$table}
             WHERE (impact_7d IS NOT NULL OR impact_30d IS NOT NULL)
               AND created_at >= %s
             ORDER BY created_at DESC",
            wp_date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) )
        ), ARRAY_A );

        if ( empty( $rows ) ) return array();

        // Group by measured page
        $pages = array();
        $type_labels = array(
            'link_outbound'     => 'Lien sortant',
            'link_inbound'      => 'Lien entrant',
            'link_sibling'      => 'Lien frère',
            'link_cross_out'    => 'Lien cross-cocon',
            'link_cross_in'     => 'Lien cross-cocon reçu',
            'link_manual'       => 'Lien manuel',
            'link_to_money'     => 'Lien money page',
            'link_removed'      => 'Lien supprimé',
            'meta_title'        => 'Title modifié',
            'meta_description'  => 'Meta description',
            'meta_auto_pilot'   => 'Meta auto-pilot',
            'optimize_meta_both'  => 'Title + Description',
            'optimize_meta_title' => 'Title optimisé',
            'optimize_meta_desc'  => 'Description optimisée',
            'add_meta_title'    => 'Title SEO généré',
            'add_meta_desc'     => 'Description générée',
            'content_modified'  => 'Contenu modifié',
            'content_write'     => 'Contenu réécrit',
            'content_refresh'   => 'Contenu rafraîchi',
            'enrich_thin_content' => 'Contenu enrichi',
            'article_created'   => 'Article créé',
            'article_published' => 'Article publié',
            'add_faq'           => 'FAQ ajoutée',
            'add_internal_links' => 'Liens internes',
            'geo_optimize'      => 'Optimisation GEO',
            'fix_orphan_links'  => 'Orpheline corrigée',
            'fix_image_alt'     => 'Alt images',
            'generate_article'  => 'Article IA',
            'schedule_publication' => 'Publication planifiée',
            'coach_suggestion'  => 'Suggestion Coach',
            'delete_page'       => 'Suppression',
        );

        foreach ( $rows as $row ) {
            $impact = ! empty( $row['impact_30d'] ) ? json_decode( $row['impact_30d'], true ) : json_decode( $row['impact_7d'], true );
            if ( empty( $impact ) ) continue;

            $measured_page = $impact['measured_page'] ?? $row['post_id'];
            $pid = (int) $measured_page;

            if ( ! isset( $pages[ $pid ] ) ) {
                $pages[ $pid ] = array(
                    'post_id'  => $pid,
                    'title'    => get_the_title( $pid ),
                    'url'      => get_permalink( $pid ),
                    'edit_url' => get_edit_post_link( $pid, 'raw' ),
                    'actions'  => array(),
                    'verdicts' => array(),
                    // GSC current
                    'position' => (float) get_post_meta( $pid, '_hts_gsc_position', true ),
                    'clicks'   => (int) get_post_meta( $pid, '_hts_gsc_clicks', true ),
                    'impressions' => (int) get_post_meta( $pid, '_hts_gsc_impressions', true ),
                );
            }

            $verdict = $impact['verdict'] ?? 'neutral';
            $vd = self::verdict_display( $verdict );
            $is_link = strpos( $row['action_type'], 'link_' ) === 0;
            $source_title = $is_link ? mb_substr( get_the_title( $row['post_id'] ), 0, 50 ) : '';

            $pages[ $pid ]['actions'][] = array(
                'id'           => (int) $row['id'],
                'type'         => $row['action_type'],
                'label'        => $type_labels[ $row['action_type'] ] ?? $row['action_type'],
                'anchor'       => $row['anchor_text'],
                'source_id'    => (int) $row['post_id'],
                'source_title' => $source_title,
                'verdict'      => $verdict,
                'icon'         => $vd['icon'],
                'color'        => $vd['color'],
                'pos_delta'    => round( (float) ( $impact['position_delta'] ?? 0 ), 1 ),
                'adj_pos_delta' => round( (float) ( $impact['adjusted_position_delta'] ?? $impact['position_delta'] ?? 0 ), 1 ),
                'clk_delta'    => (int) ( $impact['clicks_delta'] ?? 0 ),
                'context'      => $impact['context'] ?? '',
                'is_algo'      => ! empty( $impact['site_trend']['is_algo_update'] ),
                'days_ago'     => (int) ( ( time() - strtotime( $row['created_at'] ) ) / DAY_IN_SECONDS ),
                'created_at'   => $row['created_at'],
                'can_rollback' => true, // All measured actions have snapshots
            );

            $pages[ $pid ]['verdicts'][] = $verdict;
        }

        // Visit data: only add lightweight counts (no per-page SQL queries)
        // Full stats loaded on demand via separate AJAX call
        foreach ( $pages as $pid => &$page ) {
            $page['visits'] = array(
                'total' => 0, 'ai' => 0,
                'avg_time' => 0, 'avg_scroll' => 0,
            );
        }
        unset( $page );

        // Compute aggregate verdict per page
        foreach ( $pages as $pid => &$page ) {
            $neg = count( array_filter( $page['verdicts'], function( $v ) { return $v === 'negative'; } ) );
            $pos = count( array_filter( $page['verdicts'], function( $v ) { return $v === 'positive'; } ) );
            $algo = count( array_filter( $page['verdicts'], function( $v ) { return $v === 'algo_neutral'; } ) );

            if ( $neg > $pos && $neg > $algo ) {
                $page['aggregate_verdict'] = 'negative';
                $page['aggregate_label']   = 'Impact négatif détecté';
            } elseif ( $pos > $neg ) {
                $page['aggregate_verdict'] = 'positive';
                $page['aggregate_label']   = 'Impact positif';
            } elseif ( $algo > $neg && $algo > $pos ) {
                $page['aggregate_verdict'] = 'algo_neutral';
                $page['aggregate_label']   = '🔄 Variation liée à Google';
            } else {
                $page['aggregate_verdict'] = 'neutral';
                $page['aggregate_label']   = 'Impact neutre';
            }

            $page['action_count'] = count( $page['actions'] );
            unset( $page['verdicts'] );
        }
        unset( $page );

        // Sort: negative first, then neutral, then positive
        $order = array( 'negative' => 0, 'neutral' => 1, 'algo_neutral' => 2, 'positive' => 3 );
        uasort( $pages, function( $a, $b ) use ( $order ) {
            $oa = $order[ $a['aggregate_verdict'] ] ?? 1;
            $ob = $order[ $b['aggregate_verdict'] ] ?? 1;
            return $oa - $ob;
        } );

        // ── Compute smart recommendation for negative pages ──
        foreach ( $pages as &$page ) {
            $page['recommendation'] = null;
            if ( $page['aggregate_verdict'] === 'negative' && ! empty( $page['actions'] ) ) {
                $page['recommendation'] = self::compute_recommendation( $page );
            }
        }
        unset( $page );

        return array_values( $pages );
    }

    /* ──────────────────────────────────────────────
     *  RECOMMENDATION ENGINE
     *
     *  For each page with negative impact, determine:
     *  - Which SINGLE action is most likely the cause
     *  - What the client should do (sequential plan)
     *  - Why we think it's this action (reasoning)
     *
     *  Rules:
     *  1. Temporal proximity: action closest to when the drop started
     *  2. Risk ranking: content_rewrite > meta_title > meta_desc > links
     *  3. Change magnitude: bigger change = more suspicious
     *  4. No action from us: drop = algo/external, not our fault
     * ────────────────────────────────────────────── */

    /**
     * Compute ONE actionable recommendation for a page in decline.
     *
     * @param array $page Page data from get_page_impact_report().
     * @return array { suspect_action_id, suspect_type, reason, steps[], severity }
     */
    private static function compute_recommendation( $page ) {
        $actions = $page['actions'];

        // Risk weight per action type: higher = more likely to cause a drop
        $risk_weights = array(
            'content_write'       => 10,   // Full rewrite — highest risk
            'content_modified'    => 9,    // Partial content change
            'content_refresh'     => 9,    // Refreshed content
            'enrich_thin_content' => 8,    // Content enrichment
            'meta_title'          => 8,    // Title is a major ranking factor
            'meta_auto_pilot'     => 8,
            'optimize_meta_both'  => 8,
            'optimize_meta_title' => 8,
            'add_meta_title'      => 7,    // New title from scratch = slightly less risk
            'link_removed'        => 7,    // Removing a good link can hurt
            'delete_page'         => 6,    // Page deletion = redirect needed
            'meta_description'    => 3,    // Description rarely affects ranking
            'optimize_meta_desc'  => 3,
            'add_meta_desc'       => 3,
            'geo_optimize'        => 4,    // FAQ/structured data changes
            'add_faq'             => 3,    // Adding FAQ = generally safe
            'fix_image_alt'       => 1,    // Alt text = very low risk
            'add_internal_links'  => 2,    // Adding links = generally positive
            'fix_orphan_links'    => 2,
            'link_outbound'       => 2,    // Adding outbound links = low risk
            'link_sibling'        => 2,
            'link_cross_out'      => 2,
            'link_cross_in'       => 1,
            'link_inbound'        => 1,    // Receiving links = very low risk
            'link_manual'         => 2,
            'link_to_money'       => 2,
            'article_created'     => 0,    // Creating articles doesn't hurt existing pages
            'article_published'   => 0,
            'generate_article'    => 0,
            'schedule_publication' => 0,
            'coach_suggestion'    => 1,    // Generic coach suggestions = low risk
        );

        // Filter to only non-algo actions
        $suspects = array_filter( $actions, function( $a ) {
            return ! ( $a['is_algo'] ?? false ) && ( $a['verdict'] ?? '' ) === 'negative';
        } );

        // If no negative actions, check all actions (the page is negative but individual actions might be neutral)
        if ( empty( $suspects ) ) {
            $suspects = array_filter( $actions, function( $a ) {
                return ! ( $a['is_algo'] ?? false );
            } );
        }

        if ( empty( $suspects ) ) {
            return array(
                'suspect_action_id' => null,
                'suspect_type'      => null,
                'reason'            => 'Aucune action Hack The SEO n\'est responsable de cette baisse. C\'est probablement une mise à jour de l\'algorithme Google ou un changement chez vos concurrents.',
                'severity'          => 'info',
                'steps'             => array(
                    array( 'label' => 'Attendre', 'desc' => 'Les mises à jour Google se stabilisent généralement en 2-3 semaines.', 'action' => null ),
                    array( 'label' => 'Vérifier', 'desc' => 'Si la baisse persiste après 3 semaines, analysez les concurrents qui ont gagné des positions.', 'action' => null ),
                ),
            );
        }

        // Score each suspect: risk_weight × temporal_proximity
        $scored = array();
        foreach ( $suspects as $s ) {
            $days_ago = $s['days_ago'] ?? 30;
            $risk     = $risk_weights[ $s['type'] ] ?? 3;

            // Temporal score: more recent = more suspicious (inverse decay)
            // 1 day ago = ×10, 7 days ago = ×5, 30 days ago = ×1
            $temporal = max( 1, 11 - min( 10, $days_ago ) );

            // Magnitude: position delta weight
            $magnitude = min( 5, abs( $s['adj_pos_delta'] ?? $s['pos_delta'] ?? 0 ) );

            $score = $risk * $temporal + $magnitude;

            $scored[] = array(
                'action'   => $s,
                'score'    => $score,
                'risk'     => $risk,
                'temporal' => $temporal,
            );
        }

        // Sort by score descending
        usort( $scored, function( $a, $b ) { return $b['score'] - $a['score']; } );

        $prime = $scored[0];
        $suspect = $prime['action'];

        // Build reasoning
        $reason_parts = array();
        $type_names = array(
            'content_write'       => 'La réécriture du contenu',
            'content_modified'    => 'La modification du contenu',
            'content_refresh'     => 'Le rafraîchissement du contenu',
            'enrich_thin_content' => 'L\'enrichissement du contenu',
            'meta_title'          => 'Le changement de meta title',
            'meta_auto_pilot'     => 'L\'optimisation automatique du titre',
            'optimize_meta_both'  => 'L\'optimisation title + description',
            'optimize_meta_title' => 'L\'optimisation du titre',
            'optimize_meta_desc'  => 'L\'optimisation de la description',
            'add_meta_title'      => 'La génération du titre SEO',
            'add_meta_desc'       => 'La génération de la meta description',
            'meta_description'    => 'Le changement de meta description',
            'link_removed'        => 'La suppression d\'un lien',
            'link_outbound'       => 'L\'ajout d\'un lien sortant',
            'link_sibling'        => 'Le lien frère ajouté',
            'link_cross_out'      => 'Le lien cross-cocon',
            'link_manual'         => 'Le lien ajouté manuellement',
            'add_faq'             => 'L\'ajout de la FAQ structurée',
            'add_internal_links'  => 'L\'ajout de liens internes',
            'geo_optimize'        => 'L\'optimisation visibilité IA',
            'fix_orphan_links'    => 'La correction de la page orpheline',
            'fix_image_alt'       => 'La correction des alt textes',
            'delete_page'         => 'La suppression de la page',
        );

        $action_name = $type_names[ $suspect['type'] ] ?? 'L\'action « ' . ( $suspect['label'] ?? $suspect['type'] ) . ' »';

        // Why this action?
        if ( $prime['risk'] >= 8 ) {
            $reason_parts[] = $action_name . ' est un changement à haut risque SEO';
        }
        if ( $prime['temporal'] >= 7 ) {
            $reason_parts[] = 'elle a été effectuée il y a seulement ' . $suspect['days_ago'] . ' jour(s), ce qui correspond au début de la baisse';
        } elseif ( $prime['temporal'] >= 4 ) {
            $reason_parts[] = 'le timing correspond à la baisse observée';
        }
        if ( count( $scored ) > 1 && $scored[1]['score'] < $prime['score'] * 0.5 ) {
            $reason_parts[] = 'les autres actions sur cette page ont un risque beaucoup plus faible';
        }

        $reason = ! empty( $reason_parts )
            ? implode( '. ', $reason_parts ) . '.'
            : $action_name . ' est l\'action la plus récente sur cette page et correspond au timing de la baisse.';

        // Build sequential steps
        $can_rollback = $suspect['can_rollback'] ?? false;
        $steps = array();

        if ( $can_rollback ) {
            $steps[] = array(
                'label'     => 'Annuler cette action',
                'desc'      => 'Restaurer le contenu précédent de l\'article.',
                'action'    => 'rollback',
                'action_id' => $suspect['id'],
                'post_id'   => $page['post_id'],
                'primary'   => true,
            );
            $steps[] = array(
                'label'  => 'Observer pendant 7 jours',
                'desc'   => 'Après l\'annulation, attendez 7 jours pour que Google réévalue la page.',
                'action' => null,
            );
        }

        // If there are other actions, add step 3
        if ( count( $scored ) > 1 ) {
            $next = $scored[1]['action'];
            $next_name = $type_names[ $next['type'] ] ?? $next['label'] ?? $next['type'];
            $steps[] = array(
                'label'     => 'Si toujours en baisse',
                'desc'      => 'Nous vous proposerons d\'examiner : ' . $next_name . '.',
                'action'    => 'next_suspect',
                'action_id' => $next['id'],
            );
        }

        if ( ! $can_rollback ) {
            $steps[] = array(
                'label'  => 'Vérifier manuellement',
                'desc'   => 'Cette action ne peut pas être annulée automatiquement. Vérifiez l\'article dans l\'éditeur.',
                'action' => 'edit',
                'url'    => $page['edit_url'] ?? '',
            );
        }

        // Severity
        $adj = abs( $suspect['adj_pos_delta'] ?? $suspect['pos_delta'] ?? 0 );
        $severity = $adj >= 5 ? 'critical' : ( $adj >= 3 ? 'warning' : 'info' );

        return array(
            'suspect_action_id' => $suspect['id'],
            'suspect_type'      => $suspect['type'],
            'suspect_label'     => $suspect['label'] ?? $suspect['type'],
            'suspect_source'    => $suspect['source_title'] ?? '',
            'suspect_anchor'    => $suspect['anchor'] ?? '',
            'suspect_days_ago'  => $suspect['days_ago'] ?? 0,
            'reason'            => $reason,
            'severity'          => $severity,
            'steps'             => $steps,
            'alternatives'      => count( $scored ) - 1,
            'score'             => $prime['score'],
        );
    }

    /* ──────────────────────────────────────────────
     *  ENRICH AUDIT TRAIL ITEMS
     * ────────────────────────────────────────────── */

    /**
     * Enrich audit actions with impact data for the UI.
     * Called by the audit trail when returning items.
     *
     * @param array $items Audit trail items.
     * @return array Enriched items with impact_display.
     */
    public static function enrich_audit_items( $items ) {
        foreach ( $items as &$item ) {
            $item['impact_7d_data']  = null;
            $item['impact_30d_data'] = null;
            $item['impact_verdict']  = null;
            $item['impact_explanation'] = null;

            if ( ! empty( $item['id'] ) ) {
                global $wpdb;
                $table = $wpdb->prefix . 'hts_actions';
                $raw = $wpdb->get_row( $wpdb->prepare(
                    "SELECT impact_7d, impact_30d FROM {$table} WHERE id = %d",
                    $item['id']
                ), ARRAY_A );

                if ( $raw ) {
                    $item['impact_7d_data']  = $raw['impact_7d'] ? json_decode( $raw['impact_7d'], true ) : null;
                    $item['impact_30d_data'] = $raw['impact_30d'] ? json_decode( $raw['impact_30d'], true ) : null;

                    // Best available verdict
                    $best = $item['impact_30d_data'] ?? $item['impact_7d_data'];
                    if ( $best ) {
                        $item['impact_verdict'] = $best['verdict'] ?? 'neutral';
                        $item['impact_explanation'] = self::verdict_explanation(
                            $item['impact_verdict'],
                            $best
                        );
                    }
                }
            }
        }
        return $items;
    }

    /* ──────────────────────────────────────────────
     *  AJAX HANDLERS
     * ────────────────────────────────────────────── */

    public function ajax_get_impact() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'feedback/impact', array(
                'lang'      => $lang,
                'action_id' => absint( isset( $_POST['action_id'] ) ? $_POST['action_id'] : 0 ),
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote feedback/impact failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $action_id = absint( $_POST['action_id'] ?? 0 );
        if ( ! $action_id ) wp_send_json_error( 'ID manquant.' );

        global $wpdb;
        $table = $wpdb->prefix . 'hts_actions';
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT impact_7d, impact_30d, gsc_data, post_id FROM {$table} WHERE id = %d",
            $action_id
        ), ARRAY_A );

        if ( ! $row ) wp_send_json_error( 'Action introuvable.' );

        $current_gsc = array(
            'clicks'      => (int) get_post_meta( $row['post_id'], '_hts_gsc_clicks', true ),
            'impressions' => (int) get_post_meta( $row['post_id'], '_hts_gsc_impressions', true ),
            'position'    => (float) get_post_meta( $row['post_id'], '_hts_gsc_position', true ),
        );

        $impact_7d  = $row['impact_7d'] ? json_decode( $row['impact_7d'], true ) : null;
        $impact_30d = $row['impact_30d'] ? json_decode( $row['impact_30d'], true ) : null;
        $best       = $impact_30d ?? $impact_7d;

        wp_send_json_success( array(
            'impact_7d'     => $impact_7d,
            'impact_30d'    => $impact_30d,
            'gsc_at_action' => $row['gsc_data'] ? json_decode( $row['gsc_data'], true ) : null,
            'gsc_current'   => $current_gsc,
            'verdict'       => $best ? ( $best['verdict'] ?? 'neutral' ) : null,
            'explanation'   => $best ? self::verdict_explanation( $best['verdict'] ?? 'neutral', $best ) : null,
        ) );
    }

    public function ajax_get_confidence() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'feedback/confidence', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote feedback/confidence failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $scores = self::get_confidence();

        // Add human-readable labels
        $labels = array(
            'link_outbound'     => 'Liens sortants',
            'link_inbound'      => 'Liens entrants',
            'link_sibling'      => 'Liens frères (cocon)',
            'link_cross_out'    => 'Liens cross-cocon sortants',
            'link_cross_in'     => 'Liens cross-cocon entrants',
            'link_manual'       => 'Liens manuels',
            'article_published' => 'Publications',
            'content_modified'  => 'Modifications contenu',
            'meta_auto_pilot'   => 'Metas auto-pilot',
        );

        $enriched = array();
        foreach ( $scores as $type => $data ) {
            $data['label'] = $labels[ $type ] ?? $type;
            $data['status'] = 'observation';
            if ( $data['total'] >= 5 ) {
                $data['status'] = $data['confidence'] >= 60 ? 'fiable' : ( $data['confidence'] >= 30 ? 'mitige' : 'inefficace' );
            }
            $enriched[ $type ] = $data;
        }

        wp_send_json_success( $enriched );
    }

    public function ajax_get_alerts() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'feedback/alerts', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote feedback/alerts failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $active = self::get_active_alerts();

        wp_send_json_success( array(
            'alerts' => $active,
            'total'  => count( $active ),
        ) );
    }

    public function ajax_dismiss_alert() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'feedback/dismiss-alert', array(
                'lang'      => $lang,
                'action_id' => sanitize_text_field( isset( $_POST['alert_id'] ) ? $_POST['alert_id'] : '' ),
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // P4 FIX: No fallback for write operations — return error instead
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote feedback/dismiss-alert failed, no fallback (write op)', 'warning', 'remote' );
            }
            wp_send_json_error( array( 'message' => 'Le service est temporairement indisponible. Réessayez dans quelques minutes.' ) );
        }

        // ── LOCAL MODE ──
        $alert_id = sanitize_text_field( $_POST['alert_id'] ?? '' );
        if ( empty( $alert_id ) ) wp_send_json_error( 'ID alerte manquant.' );

        $alerts = get_option( self::OPT_ALERTS, array() );
        foreach ( $alerts as &$a ) {
            if ( ( $a['id'] ?? '' ) === $alert_id ) {
                $a['dismissed'] = true;
            }
        }
        update_option( self::OPT_ALERTS, $alerts, false );

        wp_send_json_success( array( 'message' => 'Alerte masquée.' ) );
    }

    /**
     * Get a full summary for the Cockpit dashboard (AJAX).
     */
    public function ajax_get_summary() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'feedback/summary', array(
                'lang' => $lang,
                'days' => absint( isset( $_POST['days'] ) ? $_POST['days'] : 30 ),
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote feedback/summary failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $days    = absint( $_POST['days'] ?? 30 );
        $summary = self::compute_impact_summary( $days );
        $alerts  = self::get_active_alerts();
        $conf    = self::get_confidence();

        wp_send_json_success( array(
            'summary'    => $summary,
            'alerts'     => $alerts,
            'confidence' => $conf,
        ) );
    }

    /**
     * AJAX: Get page-centric impact report.
     */
    public function ajax_page_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'feedback/page-report', array(
                'lang'    => $lang,
                'post_id' => absint( isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0 ),
                'days'    => absint( isset( $_POST['days'] ) ? $_POST['days'] : 30 ),
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote feedback/page-report failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $days = absint( $_POST['days'] ?? 30 );

        // ── Cache: 10 min TTL — avoid recalculating on every page load ──
        $cache_key = 'hts_impact_report_' . $days;
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            wp_send_json_success( $cached );
        }

        $pages = self::get_page_impact_report( $days );
        $site_trend = $this->compute_site_trend();
        $alerts = self::get_active_alerts();

        $result = array(
            'pages'       => $pages,
            'site_trend'  => $site_trend,
            'alerts'      => $alerts,
            'total_pages' => count( $pages ),
        );

        set_transient( $cache_key, $result, 10 * MINUTE_IN_SECONDS );

        wp_send_json_success( $result );
    }

    /* ──────────────────────────────────────────────
     *  S13-B: REUSABLE ACTION TYPE LABELS
     *  Used by Coach report, Audit Trail, Inbox cards.
     * ────────────────────────────────────────────── */

    /**
     * Translate action type key to human-readable French label.
     * Single source of truth for all UI that displays action types.
     *
     * @param string $type Action type key.
     * @return string Human-readable label.
     */
    public static function translate_action_type( $type ) {
        static $labels = null;
        if ( $labels === null ) {
            $labels = array(
                'link_outbound'       => 'Lien sortant',
                'link_inbound'        => 'Lien entrant',
                'link_sibling'        => 'Lien frère (cocon)',
                'link_cross_out'      => 'Lien cross-cocon',
                'link_cross_in'       => 'Lien cross-cocon reçu',
                'link_manual'         => 'Lien manuel',
                'link_to_money'       => 'Lien money page',
                'link_removed'        => 'Lien supprimé',
                'meta_title'          => 'Title modifié',
                'meta_description'    => 'Description modifiée',
                'meta_auto_pilot'     => 'Meta auto-pilot',
                'optimize_meta_both'  => 'Title + Description',
                'optimize_meta_title' => 'Title optimisé',
                'optimize_meta_desc'  => 'Description optimisée',
                'add_meta_title'      => 'Title SEO généré',
                'add_meta_desc'       => 'Description générée',
                'content_modified'    => 'Contenu modifié',
                'content_write'       => 'Contenu réécrit',
                'content_refresh'     => 'Contenu rafraîchi',
                'enrich_thin_content' => 'Contenu enrichi',
                'article_created'     => 'Article créé',
                'article_published'   => 'Article publié',
                'add_faq'             => 'FAQ ajoutée',
                'add_internal_links'  => 'Liens internes',
                'geo_optimize'        => 'Optimisation GEO',
                'fix_orphan_links'    => 'Orpheline corrigée',
                'fix_image_alt'       => 'Alt images',
                'generate_article'    => 'Article IA',
                'schedule_publication' => 'Publication planifiée',
                'coach_suggestion'    => 'Suggestion Coach',
                'delete_page'         => 'Suppression',
                'rollback'            => 'Annulation',
                'meta_rollback'       => 'Annulation meta',
                'test_diagnostic'     => 'Test diagnostic',
            );
        }
        return $labels[ $type ] ?? $type;
    }
}
