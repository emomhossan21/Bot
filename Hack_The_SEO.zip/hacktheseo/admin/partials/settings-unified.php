<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Hack The SEO — Réglages (S12 — DS v5.7)
 * 6 onglets : Agents · Connexions · Protection · Réglages SEO · Notifications · Santé
 * Uses HTS_DS::*() + hts-ds-tokens.css
 * @since 2.6.0
 */
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}
$nonce       = wp_create_nonce( 'hts_admin_nonce' );
$current_env = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
$agents        = class_exists( 'HTS_Workflow_Engine' ) ? HTS_Workflow_Engine::get_all_agents() : array();
$agent_labels  = class_exists( 'HTS_Workflow_Engine' ) ? HTS_Workflow_Engine::get_agent_labels() : array();
$agent_schema  = class_exists( 'HTS_Workflow_Engine' ) ? HTS_Workflow_Engine::get_agent_settings_schema() : array();
if ( isset( $agents['image'] ) ) {
	$img_cfg = class_exists( 'Hts_Synchronise_Articles_Admin' ) && method_exists( 'Hts_Synchronise_Articles_Admin', 'get_image_settings' ) ? Hts_Synchronise_Articles_Admin::get_image_settings() : get_option( 'hts_image_settings', array() );
	$img_saved = $agents['image']['settings'] ?? array();
	foreach ( array( 'image_provider','openai_model','flux_model','flux_api_key','pexels_api_key','featured_enabled','featured_source','featured_style','featured_quality','featured_text_overlay','incontent_enabled','incontent_count','incontent_quality','extra_instructions' ) as $sk ) {
		if ( ! isset( $img_saved[ $sk ] ) && isset( $img_cfg[ $sk ] ) ) $img_saved[ $sk ] = $img_cfg[ $sk ];
	}
	$agents['image']['settings'] = $img_saved;
}
$coach_key    = get_option( 'hts_coach_api_key', '' );
$coach_usage  = class_exists( 'HTS_Coach' ) ? HTS_Coach::get_usage() : array( 'tokens_in' => 0, 'tokens_out' => 0 );
$coach_budget = class_exists( 'HTS_Coach' ) ? HTS_Coach::get_monthly_budget() : 100000;
$coach_total  = ( $coach_usage['tokens_in'] ?? 0 ) + ( $coach_usage['tokens_out'] ?? 0 );
$coach_pct    = $coach_budget > 0 ? min( 100, round( $coach_total / $coach_budget * 100 ) ) : 0;
$gf_max_budget       = (float) get_option( 'hts_workflow_max_budget_month', 30 );
$gf_traffic_thr      = (int) get_option( 'hts_workflow_traffic_threshold', 100 );
$gf_auto_hours_start = (int) get_option( 'hts_workflow_auto_hours_start', 0 );
$gf_auto_hours_end   = (int) get_option( 'hts_workflow_auto_hours_end', 23 );
$gf_blacklist_pages  = get_option( 'hts_workflow_blacklist_pages', array() );
$gf_blacklist_str    = is_array( $gf_blacklist_pages ) ? implode( ', ', $gf_blacklist_pages ) : '';
$openai_key  = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : get_option( 'hts_openai_api_key', '' );
$gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
$gsc_property  = get_option( 'hts_gsc_property', '' );
$active_tab = sanitize_key( $_GET['stab'] ?? 'connexions' );
if ( ! in_array( $active_tab, array( 'agents','connexions','guardrails','seo','notifications','health','plans' ), true ) ) $active_tab = 'agents';
$agent_descriptions = array(
	'strategy'        => 'Votre directeur SEO personnel. Chaque semaine, il analyse vos résultats et vous dit exactement quoi faire pour progresser',
	'meta'            => 'Réécrit vos titres et descriptions Google avec l\'IA pour attirer plus de clics. Résultats visibles en quelques jours',
	'linking'         => 'Tisse un maillage intelligent entre vos articles. Google comprend mieux votre site, vos visiteurs restent plus longtemps',
	'geo_score'       => 'Votre passeport pour ChatGPT, Perplexity et Google AI. Rendez vos pages citables par les moteurs de demain',
	'coach'           => 'Posez n\'importe quelle question sur votre site. Il a accès à vos vrais chiffres et vous répond comme un expert',
	'auto_write'      => 'Commandez un article le matin, retrouvez-le rédigé et illustré le soir. Votre machine à contenu tourne seule',
	'image'           => 'Fini les banques d\'images. Chaque article reçoit des illustrations uniques créées par l\'IA en quelques secondes',
	'content_quality' => 'Détecte les pages incomplètes et vous montre exactement quoi ajouter pour les rendre performantes',
	'fresh'           => 'Vos anciens articles perdent en pertinence. Cet agent les repère et demande une mise à jour avant que Google ne les oublie',
	'cannib'          => 'Quand deux de vos pages se battent pour la même requête, vous perdez les deux. Cet agent trouve la solution',
	'monitoring'      => 'Sachez en temps réel quand ChatGPT ou Perplexity cite votre site. Mesurez votre visibilité IA chaque semaine',
);
?>
<?php echo HTS_DS::page_open(); ?>
<?php echo HTS_DS::hero( 'Réglages', 'Configurez vos agents, connexions et limites' ); ?>
<?php $tab_url = admin_url( 'admin.php?page=hts-api-settings&stab=%s' );
echo HTS_DS::tab_bar( array(
	array( 'id'=>'agents','label'=>'Agents','icon'=>'bot','badge'=>0 ),
	array( 'id'=>'connexions','label'=>'Connexions','icon'=>'key','badge'=>0 ),
	array( 'id'=>'guardrails','label'=>'Protection','icon'=>'shield','badge'=>0 ),
	array( 'id'=>'seo','label'=>'Réglages SEO','icon'=>'settings','badge'=>0 ),
	array( 'id'=>'notifications','label'=>'Notifications','icon'=>'bell','badge'=>0 ),
	array( 'id'=>'health','label'=>'Santé','icon'=>'check','badge'=>0 ),
	array( 'id'=>'plans','label'=>'Plans & Tarifs','icon'=>'zap','badge'=>0 ),
), $active_tab, $tab_url ); ?>
<div style="margin-top:24px"></div>

<?php if ( $active_tab === 'connexions' ) : ?>
<div class="hts-ds-grid-3" style="margin-bottom:20px">
<?php foreach ( array(
	array( 'l'=>'Dernière synchro','v'=>($last_sync&&$last_sync!=='Jamais'?date_i18n('j M Y H:i',strtotime($last_sync)):'—'),'c'=>'var(--hts-accent)' ),
	array( 'l'=>'Articles reçus','v'=>intval($articles_count),'c'=>'var(--hts-success)' ),
	array( 'l'=>'Push API reçus','v'=>intval($total_received),'c'=>'var(--hts-geo)' ),
) as $m ) : ?>
<div style="padding:16px 20px;background:var(--hts-bg);border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border-sub)">
	<div style="font-size:11px;color:var(--hts-text-3);margin-bottom:4px"><?php echo esc_html($m['l']); ?></div>
	<div style="font-size:20px;font-weight:700;color:<?php echo $m['c']; ?>"><?php echo esc_html($m['v']); ?></div>
</div>
<?php endforeach; ?>
</div>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Clé API Hack The SEO','Connectez le plugin à votre espace Hack The SEO'); ?>
	<div id="hts-api-alert"></div>
	<form id="hts-api-form" style="display:flex;gap:10px;align-items:flex-end">
		<div style="flex:1"><?php echo HTS_DS::input(array('type'=>'password','id'=>'hts-api-key','name'=>'api_key','value'=>esc_attr($api_key),'placeholder'=>'Collez votre clé API','style'=>'width:100%;font-family:var(--hts-mono);font-size:12px')); ?></div>
		<?php echo HTS_DS::button('Enregistrer','primary','md',array('type'=>'submit','id'=>'hts-api-save')); ?>
	</form>
	<?php if ($api_key): ?>
	<div style="margin-top:10px"><?php echo HTS_DS::dot('ok'); ?> <span style="font-size:12px;color:var(--hts-success);font-weight:500">Connecté</span></div>
	<?php if ( class_exists( 'HTS_Subscription' ) ) :
		$sub_status_u = HTS_Subscription::get_status();
		$sub_data_u   = HTS_Subscription::get_data();
		$sub_plan     = $sub_data_u['plan'] ?? '';
		$sub_plan_name = is_array( $sub_plan ) ? ( $sub_plan['name'] ?? ucfirst( $sub_plan['slug'] ?? 'Free' ) ) : ucfirst( $sub_plan ?: 'Free' );
		// Article quotas — SaaS is the ONLY source of truth
		// article_quota_saas = total monthly quota, articles_used_saas = used this month
		$sub_limit = (int) ( $sub_data_u['article_quota_saas'] ?? $sub_data_u['article_quota_plugin'] ?? 0 );
		$sub_used  = (int) ( $sub_data_u['articles_used_saas'] ?? $sub_data_u['usage']['articles_this_month'] ?? 0 );
		if ( $sub_limit === 0 ) {
			// Fallback to legacy fields
			$sub_limit = $sub_data_u['features']['max_articles_month'] ?? $sub_data_u['articles_limit'] ?? '?';
			$sub_used  = $sub_data_u['usage']['articles'] ?? $sub_data_u['articles_used'] ?? 0;
		}
		$sub_remaining = $sub_limit !== '?' ? max( 0, (int) $sub_limit - (int) $sub_used ) : '?';
		$sub_expires   = $sub_data_u['expires_at'] ?? $sub_data_u['active_until'] ?? '';
	?>
	<div style="margin-top:12px;padding:12px 16px;background:var(--hts-surface);border:1px solid var(--hts-border-sub);border-radius:var(--hts-radius-sm)">
		<?php if ( $sub_status_u === 'active' ) : ?>
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
			<?php echo HTS_DS::dot('ok'); ?>
			<span style="font-size:13px;font-weight:600;color:var(--hts-success)">Abonnement actif — <?php echo esc_html( $sub_plan_name ); ?></span>
			<?php if ( $sub_expires ) : ?>
			<span style="font-size:11px;color:var(--hts-text-3);margin-left:auto">exp. <?php echo esc_html( date_i18n( 'j M Y', strtotime( $sub_expires ) ) ); ?></span>
			<?php endif; ?>
		</div>
		<div style="font-size:12px;color:var(--hts-text-2)">Articles : <strong><?php echo esc_html( $sub_remaining ); ?></strong> restants <?php if ( $sub_used !== '?' && $sub_limit !== '?' ) : ?>(<?php echo esc_html( $sub_used ); ?> / <?php echo esc_html( $sub_limit ); ?>)<?php endif; ?></div>
		<?php elseif ( $sub_status_u === 'expired' ) : ?>
		<div style="display:flex;align-items:center;gap:8px">
			<?php echo HTS_DS::dot('warn'); ?>
			<span style="font-size:13px;color:var(--hts-caution)">Abonnement expiré</span>
			<a href="<?php echo esc_url( $current_env . '/billing' ); ?>" target="_blank" style="font-size:12px;color:var(--hts-accent);margin-left:auto">Renouveler</a>
		</div>
		<?php elseif ( in_array( $sub_status_u, array( 'cancelled', 'inactive' ), true ) ) : ?>
		<div style="display:flex;align-items:center;gap:8px">
			<?php echo HTS_DS::dot('error'); ?>
			<span style="font-size:13px;color:var(--hts-danger)">Abonnement inactif</span>
		</div>
		<?php else : ?>
		<div style="display:flex;align-items:center;gap:8px">
			<span style="font-size:12px;color:var(--hts-text-3)">Abonnement non vérifié — cliquez "Vérifier" ci-dessus</span>
		</div>
		<?php endif; ?>
	</div>
	<?php endif; ?>
	<?php endif; ?>
</div></div>
<?php if ( defined( 'HTS_SHOW_API_KEYS' ) && HTS_SHOW_API_KEYS ) : ?>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Coach SEO — Clé Anthropic','Clé API pour le Coach IA (facultatif — fallback OpenAI)'); ?>
	<div id="hts-coach-key-alert"></div>
	<div style="display:flex;gap:10px;align-items:center">
		<?php echo HTS_DS::input(array('type'=>'password','id'=>'hts-coach-api-key','value'=>esc_attr($coach_key),'placeholder'=>'sk-ant-...','style'=>'flex:1;max-width:400px;font-family:var(--hts-mono);font-size:12px')); ?>
		<?php echo HTS_DS::button('Enregistrer','default','sm',array('type'=>'button','id'=>'hts-coach-key-save')); ?>
	</div>
	<?php if ($coach_key): ?>
	<div style="margin-top:12px"><?php echo HTS_DS::row('Tokens utilisés ce mois',number_format($coach_total).' / '.number_format($coach_budget),'<div style="display:flex;align-items:center;gap:10px;width:180px">'.HTS_DS::progress($coach_pct,$coach_pct>80?'var(--hts-danger)':'var(--hts-success)',6).'<span style="font-size:11px;font-weight:600;color:'.($coach_pct>80?'var(--hts-danger)':'var(--hts-success)').'">'.$coach_pct.'%</span></div>',true); ?></div>
	<?php else: ?><div style="margin-top:8px"><?php echo HTS_DS::dot('warn'); ?> <span style="font-size:12px;color:var(--hts-caution)">Pas de clé — le Coach utilise OpenAI en fallback</span></div><?php endif; ?>
</div></div>
<?php endif; /* HTS_SHOW_API_KEYS — Anthropic */ ?>
<?php if ( defined( 'HTS_SHOW_API_KEYS' ) && HTS_SHOW_API_KEYS ) : ?>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('OpenAI — Embeddings et IA','Utilisé pour les embeddings, les suggestions de metas et le fallback Coach'); ?>
	<div id="hts-openai-alert"></div>
	<div style="display:flex;gap:10px;align-items:center">
		<?php echo HTS_DS::input(array('type'=>'password','id'=>'hts-openai-key','value'=>esc_attr($openai_key),'placeholder'=>'sk-...','style'=>'flex:1;max-width:400px;font-family:var(--hts-mono);font-size:12px')); ?>
		<?php echo HTS_DS::button('Enregistrer','default','sm',array('type'=>'button','id'=>'hts-openai-key-save')); ?>
	</div>
	<?php if ($openai_key): ?><div style="margin-top:8px"><?php echo HTS_DS::dot('ok'); ?> <span style="font-size:12px;color:var(--hts-success)">Clé active</span></div><?php endif; ?>
</div></div>
<?php endif; /* HTS_SHOW_API_KEYS — OpenAI */ ?>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php
	$gsc_status_full = array( 'connected' => false, 'has_keys' => false, 'site_url' => '', 'email' => '', 'last_fetch' => null, 'proxy_mode' => false );
	if ( class_exists( 'HTS_GSC_Connect' ) ) {
		$gsc_obj_full    = new HTS_GSC_Connect();
		$gsc_status_full = $gsc_obj_full->get_connection_status();
	}
	$gsc_nonce_u = wp_create_nonce( 'hts_gsc_admin' );
	$gsc_proxy_u = ! empty( $gsc_status_full['proxy_mode'] );
	?>
	<?php echo HTS_DS::section_title('Google Search Console','Vos données de trafic Google : clics, impressions, positions'); ?>

	<?php if ( $gsc_status_full['connected'] ) : ?>
	<!-- CONNECTED -->
	<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:var(--hts-geo-soft);border:1px solid var(--hts-border-sub);border-radius:var(--hts-radius-sm);margin-bottom:12px">
		<?php echo HTS_DS::dot('ok'); ?>
		<div style="flex:1">
			<div style="font-size:13px;font-weight:600;color:var(--hts-success)">Connecté à Google Search Console</div>
			<?php if ( $gsc_status_full['email'] ) : ?><div style="font-size:11px;color:var(--hts-text-3)"><?php echo esc_html( $gsc_status_full['email'] ); ?></div><?php endif; ?>
			<?php if ( $gsc_status_full['site_url'] ) : ?><div style="font-size:11px;color:var(--hts-text-3)">Site : <?php echo esc_html( $gsc_status_full['site_url'] ); ?></div><?php endif; ?>
			<?php if ( $gsc_status_full['last_fetch'] ) : ?><div style="font-size:10px;color:var(--hts-text-3);margin-top:2px">Dernière synchro : <?php echo esc_html( $gsc_status_full['last_fetch'] ); ?></div><?php endif; ?>
		</div>
		<?php echo HTS_DS::button('Synchroniser','default','sm',array('type'=>'button','onclick'=>'htsGscFetchNow()','id'=>'hts-gsc-fetch-btn')); ?>
		<?php echo HTS_DS::button('Déconnecter','ghost','sm',array('type'=>'button','onclick'=>'htsGscDisconnect()','style'=>'color:var(--hts-danger)')); ?>
	</div>
	<?php if ( empty( $gsc_status_full['site_url'] ) ) : ?>
	<div style="padding:12px 16px;background:var(--hts-surface);border:1px solid var(--hts-border-sub);border-radius:var(--hts-radius-sm);margin-bottom:12px">
		<div style="font-size:12px;font-weight:600;color:var(--hts-caution);margin-bottom:6px">Sélectionnez votre site</div>
		<div style="font-size:11px;color:var(--hts-text-3);margin-bottom:8px">Choisissez le site vérifié dans Search Console qui correspond à ce WordPress.</div>
		<?php echo HTS_DS::button('Charger la liste des sites','default','sm',array('type'=>'button','onclick'=>'htsGscListSites()','id'=>'hts-gsc-list-btn')); ?>
		<div id="hts-gsc-sites-list" style="margin-top:8px"></div>
	</div>
	<?php endif; ?>

	<?php else : ?>
	<!-- NOT CONNECTED -->
	<?php if ( $gsc_proxy_u ) : ?>
	<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:12px;line-height:1.6">
		Connectez votre compte Google Search Console en un clic pour voir vos clics, impressions, CTR et position moyenne directement dans Hack The SEO.
	</div>
	<div style="display:flex;gap:8px;align-items:center">
		<button type="button" onclick="htsGscProxyConnect()" id="hts-gsc-connect-btn" style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;font-size:13px;font-weight:600;color:var(--hts-text)">
			<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A10.96 10.96 0 001 12c0 1.77.42 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
			Connecter Google Search Console
		</button>
		<span id="hts-gsc-status-msg" style="font-size:11px;color:var(--hts-text-3)"></span>
	</div>
	<?php else : ?>
	<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:12px;line-height:1.6">
		Connectez Google Search Console pour voir vos clics, impressions, CTR et position moyenne.
	</div>
	<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
		<div>
			<label style="font-size:11px;font-weight:600;color:var(--hts-text-2);display:block;margin-bottom:4px">Client ID</label>
			<?php echo HTS_DS::input(array('type'=>'text','id'=>'hts-gsc-client-id','value'=>esc_attr(get_option('hts_gsc_client_id','')),'placeholder'=>'xxxx.apps.googleusercontent.com','style'=>'width:100%;font-size:12px')); ?>
		</div>
		<div>
			<label style="font-size:11px;font-weight:600;color:var(--hts-text-2);display:block;margin-bottom:4px">Client Secret</label>
			<?php echo HTS_DS::input(array('type'=>'password','id'=>'hts-gsc-client-secret','value'=>esc_attr(get_option('hts_gsc_client_secret','')),'placeholder'=>'GOCSPX-xxxx','style'=>'width:100%;font-size:12px')); ?>
		</div>
	</div>
	<div style="display:flex;gap:8px;align-items:center">
		<?php echo HTS_DS::button('Enregistrer et connecter','default','sm',array('type'=>'button','onclick'=>'htsGscSaveAndConnect()','id'=>'hts-gsc-connect-btn')); ?>
		<span id="hts-gsc-status-msg" style="font-size:11px;color:var(--hts-text-3)"></span>
	</div>
	<details style="margin-top:12px">
		<summary style="font-size:11px;color:var(--hts-accent);cursor:pointer;font-weight:600">Comment obtenir les clés ?</summary>
		<div style="font-size:11px;color:var(--hts-text-3);line-height:1.8;padding:8px 0">
			1. <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">console.cloud.google.com</a><br>
			2. Créez un projet ou sélectionnez un existant<br>
			3. Activez l'API « Google Search Console API »<br>
			4. Créez un identifiant OAuth 2.0 (type: application Web)<br>
			5. URI de redirection : <?php echo HTS_DS::code( admin_url( 'admin.php?page=hts-api-settings&stab=connexions' ) ); ?><br>
			6. Copiez Client ID et Client Secret ici
		</div>
	</details>
	<?php endif; ?>
	<?php endif; ?>

	<div id="hts-gsc-feedback" style="margin-top:8px"></div>
</div></div>
<script>
(function(){
	var gscNonce = '<?php echo esc_js( $gsc_nonce_u ); ?>';
	window.htsGscProxyConnect = function() {
		var btn = document.getElementById('hts-gsc-connect-btn'), msg = document.getElementById('hts-gsc-status-msg');
		btn.disabled = true; msg.textContent = 'Connexion en cours...';
		var fd = new FormData(); fd.append('action','hts_gsc_connect'); fd.append('nonce',gscNonce);
		fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
			if(r.success&&r.data.redirect){msg.textContent='Redirection...';window.location.href=r.data.redirect}
			else{msg.textContent=r.data.message||'Erreur';msg.style.color='var(--hts-danger)';btn.disabled=false}
		}).catch(function(){msg.textContent='Erreur réseau';msg.style.color='var(--hts-danger)';btn.disabled=false});
	};
	window.htsGscSaveAndConnect = function() {
		var btn = document.getElementById('hts-gsc-connect-btn'), msg = document.getElementById('hts-gsc-status-msg');
		var cid = document.getElementById('hts-gsc-client-id').value.trim(), csc = document.getElementById('hts-gsc-client-secret').value.trim();
		if(!cid||!csc){msg.textContent='Remplissez les deux champs.';msg.style.color='var(--hts-danger)';return}
		btn.disabled=true;msg.textContent='Enregistrement...';
		var fd=new FormData();fd.append('action','hts_gsc_save_keys');fd.append('nonce',gscNonce);fd.append('client_id',cid);fd.append('client_secret',csc);
		fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
			if(!r.success){msg.textContent=r.data.message||'Erreur';msg.style.color='var(--hts-danger)';btn.disabled=false;return}
			msg.textContent='Redirection vers Google...';
			var fd2=new FormData();fd2.append('action','hts_gsc_connect');fd2.append('nonce',gscNonce);
			fetch(ajaxurl,{method:'POST',body:fd2}).then(function(r){return r.json()}).then(function(r){
				if(r.success&&r.data.redirect)window.location.href=r.data.redirect;
				else{msg.textContent=r.data.message||'Erreur OAuth';msg.style.color='var(--hts-danger)';btn.disabled=false}
			});
		});
	};
	window.htsGscDisconnect = function() {
		if(!confirm('Déconnecter Google Search Console ?'))return;
		var fd=new FormData();fd.append('action','hts_gsc_disconnect');fd.append('nonce',gscNonce);
		fetch(ajaxurl,{method:'POST',body:fd}).then(function(){location.reload()});
	};
	window.htsGscFetchNow = function() {
		var btn=document.getElementById('hts-gsc-fetch-btn'),fb=document.getElementById('hts-gsc-feedback');
		btn.disabled=true;btn.textContent='Synchronisation...';fb.innerHTML='';
		var fd=new FormData();fd.append('action','hts_gsc_fetch_now');fd.append('nonce',gscNonce);
		fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
			btn.disabled=false;btn.textContent='Synchroniser';
			if(r.success)fb.innerHTML='<span style="color:var(--hts-success);font-size:11px">\u2705 '+r.data.message+'</span>';
			else fb.innerHTML='<span style="color:var(--hts-danger);font-size:11px">\u274c '+(r.data.message||'Erreur')+'</span>';
		});
	};
	window.htsGscListSites = function() {
		var btn=document.getElementById('hts-gsc-list-btn'),box=document.getElementById('hts-gsc-sites-list');
		btn.disabled=true;btn.textContent='Chargement...';
		var fd=new FormData();fd.append('action','hts_gsc_list_sites');fd.append('nonce',gscNonce);
		fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
			btn.disabled=false;btn.textContent='Charger la liste';
			if(!r.success){box.innerHTML='<span style="color:var(--hts-danger);font-size:11px">'+(r.data.message||'Erreur')+'</span>';return}
			var sites=r.data.sites||[],am=r.data.auto_match||'';
			if(!sites.length){box.innerHTML='<span style="font-size:11px;color:var(--hts-caution)">Aucun site vérifié trouvé.</span>';return}
			if(am){box.innerHTML='<span style="font-size:11px;color:var(--hts-success)">\u2705 '+am+'</span>';htsGscSelectSite(am);return}
			var h='';sites.forEach(function(s){h+='<button type="button" style="margin:2px 4px 2px 0;padding:4px 10px;border:1px solid var(--hts-border);border-radius:6px;background:var(--hts-bg);cursor:pointer;font-size:11px" onclick="htsGscSelectSite(\''+s.url.replace(/'/g,"\\'")+'\')">'+s.url+'</button>'});
			box.innerHTML=h;
		});
	};
	window.htsGscSelectSite = function(url) {
		var box=document.getElementById('hts-gsc-sites-list');
		if(box)box.innerHTML='<span style="font-size:11px;color:var(--hts-text-3)">Sélection...</span>';
		var fd=new FormData();fd.append('action','hts_gsc_select_site');fd.append('nonce',gscNonce);fd.append('site_url',url);
		fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
			if(!r.success){if(box)box.innerHTML='<span style="color:var(--hts-danger);font-size:11px">\u274c '+(r.data.message||'Erreur')+'</span>';return}
			if(box)box.innerHTML='<span style="font-size:11px;color:var(--hts-success)">\u2705 Import en cours...</span>';
			var fd2=new FormData();fd2.append('action','hts_gsc_fetch_now');fd2.append('nonce',gscNonce);
			fetch(ajaxurl,{method:'POST',body:fd2}).then(function(){setTimeout(function(){location.reload()},1500)}).catch(function(){location.reload()});
		});
	};
})();
</script>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php
	$indexnow_enabled_c = get_option( 'hts_indexnow_enabled', '0' );
	$indexnow_key_c     = class_exists( 'HTS_IndexNow' ) ? HTS_IndexNow::get_api_key() : '';
	?>
	<?php echo HTS_DS::section_title('IndexNow — Indexation rapide','Prévient Google et Bing en temps réel quand vous publiez un contenu'); ?>
	<div style="display:flex;align-items:center;gap:12px">
		<?php if ( $indexnow_enabled_c === '1' ) : ?>
			<?php echo HTS_DS::dot('ok'); ?> <span style="font-size:13px;font-weight:500;color:var(--hts-success)">Actif</span>
			<?php if ( $indexnow_key_c ) : ?><?php echo HTS_DS::code( substr( $indexnow_key_c, 0, 16 ) . '...' ); ?><?php endif; ?>
		<?php else : ?>
			<?php echo HTS_DS::dot('warn'); ?> <span style="font-size:13px;color:var(--hts-caution)">Désactivé</span>
			<span style="font-size:12px;color:var(--hts-text-3)">Activez dans Réglages SEO pour être indexé plus vite</span>
		<?php endif; ?>
	</div>
</div></div>
<?php
// Tier selector — visible only on LOCAL dev (.test domains), NOT on prep/staging
$_is_dev = strpos( home_url(), '.test' ) !== false;
if ( $_is_dev && current_user_can( 'manage_options' ) ) :
	$_cur_tier = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::get_plan_tier() : 0;
	$_cur_plan = get_option( 'hts_api_plan', 'free' );
?>
<div class="hts-ds-card" style="margin-bottom:16px;border:2px dashed var(--hts-caution)"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title( 'Simulateur de tier (dev only)', 'Testez le gating sans changer d\'abonnement' ); ?>
	<div style="display:flex;gap:12px;margin-bottom:10px">
	<?php foreach ( array(
		array( 't' => 0, 'slug' => 'free',     'label' => 'Free',        'color' => 'var(--hts-text-3)' ),
		array( 't' => 1, 'slug' => 'wp_pro',   'label' => 'Pro 99€',     'color' => 'var(--hts-geo)' ),
		array( 't' => 2, 'slug' => 'wp_ultra',  'label' => 'Ultra 249€', 'color' => '#8b5cf6' ),
	) as $tp ) : $sel = ( $_cur_tier === $tp['t'] ); ?>
	<label style="flex:1;padding:14px 16px;border-radius:var(--hts-radius-sm);border:2px solid <?php echo $sel ? $tp['color'] : 'var(--hts-border)'; ?>;background:<?php echo $sel ? 'var(--hts-surface)' : 'var(--hts-bg)'; ?>;cursor:pointer;display:flex;align-items:center;gap:10px">
		<input type="radio" name="hts_tier_sim" value="<?php echo $tp['t']; ?>" data-slug="<?php echo esc_attr( $tp['slug'] ); ?>" <?php checked( $sel ); ?> style="accent-color:<?php echo $tp['color']; ?>" onchange="htsSetTier(this)">
		<div>
			<div style="font-size:14px;font-weight:700;color:<?php echo $tp['color']; ?>"><?php echo $tp['label']; ?></div>
			<div style="font-size:10px;color:var(--hts-text-3)">tier <?php echo $tp['t']; ?> · <?php echo $tp['slug']; ?></div>
		</div>
	</label>
	<?php endforeach; ?>
	</div>
	<div style="font-size:12px;color:var(--hts-text-3)">
		Tier actuel : <strong style="color:var(--hts-text)"><?php echo $_cur_tier; ?></strong> · Plan : <strong style="color:var(--hts-text)"><?php echo esc_html( $_cur_plan ); ?></strong>
		<span id="hts-tier-status" style="margin-left:8px"></span>
	</div>
</div></div>
<script>
function htsSetTier(el){
	var tier=el.value,slug=el.dataset.slug,st=document.getElementById('hts-tier-status');
	if(st)st.textContent='Enregistrement...';
	var fd=new FormData();
	fd.append('action','hts_dev_set_tier');fd.append('nonce','<?php echo esc_js( $nonce ); ?>');fd.append('tier',tier);fd.append('slug',slug);
	fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){
		if(r.success){if(st)st.textContent='OK — rechargement...';setTimeout(function(){location.reload()},500)}
		else{if(st)st.textContent='Erreur'}
	});
}
</script>
<?php endif; ?>
<!-- Ressources supprimé v2.6.3 -->
<?php
// ── Sprint 2 : Dashboard des coûts API (admin-only, préprod uniquement) ──
if ( current_user_can( 'manage_options' ) && defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS === true ) {
    include __DIR__ . '/api-costs.php';
}
?>
<?php endif; ?>

<?php if ( $active_tab === 'agents' ) : ?>
<?php
// ── Agent visual mapping (gradient + icon for card UI) ──
// IDs must match get_agent_labels() in class-hts-workflow-engine.php
$agent_visuals = array(
	'strategy'        => array( 'grad' => 'linear-gradient(135deg,#7C3AED,#A78BFA)', 'icon' => 'compass',  'featured' => true ),
	'geo_score'       => array( 'grad' => 'linear-gradient(135deg,#6366F1,#818CF8)', 'icon' => 'target',   'featured' => true ),
	'meta'            => array( 'grad' => 'linear-gradient(135deg,#EC4899,#F472B6)', 'icon' => 'search',   'featured' => false ),
	'linking'         => array( 'grad' => 'linear-gradient(135deg,#0EA5E9,#38BDF8)', 'icon' => 'link',     'featured' => false ),
	'coach'           => array( 'grad' => 'linear-gradient(135deg,#D946EF,#E879F9)', 'icon' => 'star',     'featured' => false ),
	'auto_write'      => array( 'grad' => 'linear-gradient(135deg,#8B5CF6,#A78BFA)', 'icon' => 'file',     'featured' => false ),
	'image'           => array( 'grad' => 'linear-gradient(135deg,#F97316,#FDBA74)', 'icon' => 'zap',      'featured' => false ),
	'content_quality' => array( 'grad' => 'linear-gradient(135deg,#22C55E,#86EFAC)', 'icon' => 'check',    'featured' => false ),
	'fresh'           => array( 'grad' => 'linear-gradient(135deg,#14B8A6,#5EEAD4)', 'icon' => 'refresh',  'featured' => false ),
	'cannib'          => array( 'grad' => 'linear-gradient(135deg,#EF4444,#F87171)', 'icon' => 'alert',    'featured' => false ),
	'monitoring'      => array( 'grad' => 'linear-gradient(135deg,#10A37F,#34D399)', 'icon' => 'eye',      'featured' => false ),
);
// CEO-priority order (most impactful → most technical)
$agent_order = array( 'strategy','geo_score','meta','linking','coach','auto_write','image','content_quality','cannib','monitoring' );
// Agents that require Ultra (tier 2) subscription
$_ultra_agents = array( 'meta' => 'maillage_ia', 'linking' => 'maillage_ia', 'auto_write' => 'auto_write', 'image' => 'auto_write' );
$_is_not_ultra = class_exists( 'HTS_Subscription' ) && ! HTS_Subscription::is_ultra() && HTS_Subscription::get_status() !== 'unknown';
$featured_agents = array();
$other_agents    = array();
// Use explicit order, falling back to whatever backend returns
$ordered_labels = array();
foreach ( $agent_order as $oid ) {
	if ( isset( $agent_labels[ $oid ] ) ) {
		$ordered_labels[ $oid ] = $agent_labels[ $oid ];
	}
}
// Append any backend agent not in our order list (safety for new agents)
foreach ( $agent_labels as $aid => $lbl ) {
	if ( ! isset( $ordered_labels[ $aid ] ) ) {
		$ordered_labels[ $aid ] = $lbl;
	}
}
foreach ( $ordered_labels as $agent_id => $label ) {
	$vis = isset( $agent_visuals[ $agent_id ] ) ? $agent_visuals[ $agent_id ] : array( 'grad' => 'linear-gradient(135deg,#94A3B8,#CBD5E1)', 'icon' => 'zap', 'featured' => false );
	if ( ! empty( $vis['featured'] ) ) {
		$featured_agents[ $agent_id ] = $label;
	} else {
		$other_agents[ $agent_id ] = $label;
	}
}
?>

<!-- ── Agents cards v7 ── -->
<?php if ( ! empty( $featured_agents ) ) : ?>
<div style="font-size:16px;font-weight:700;color:var(--hts-text);margin-bottom:16px;display:flex;align-items:center;gap:10px">Recommandés <?php echo HTS_DS::badge('GEO 2026','primary'); ?></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:32px">
<?php foreach ( $featured_agents as $agent_id => $label ) :
	$config  = isset( $agents[ $agent_id ] ) ? $agents[ $agent_id ] : array( 'enabled' => true, 'mode' => 'review', 'settings' => array() );
	$enabled = (bool) ( isset( $config['enabled'] ) ? $config['enabled'] : true );
	$mode    = isset( $config['mode'] ) ? $config['mode'] : 'review';
	$desc    = isset( $agent_descriptions[ $agent_id ] ) ? $agent_descriptions[ $agent_id ] : '';
	$vis     = $agent_visuals[ $agent_id ];
	$fields  = isset( $agent_schema[ $agent_id ] ) ? $agent_schema[ $agent_id ] : array();
	$has_opts = ! empty( $fields );
?>
<div class="hts-agent-card hts-agent-card--lg" data-agent="<?php echo esc_attr( $agent_id ); ?>" <?php if ( $has_opts ) : ?>onclick="htsOpenAgentModal('<?php echo esc_js( $agent_id ); ?>')"<?php endif; ?> style="cursor:<?php echo $has_opts ? 'pointer' : 'default'; ?>">
	<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:64px">
		<div class="hts-agent-icon hts-agent-icon--lg" style="background:<?php echo $vis['grad']; ?>">
			<?php echo HTS_DS::icon( $vis['icon'], 28, '#fff' ); ?>
		</div>
		<div onclick="event.stopPropagation()" style="display:flex;align-items:center;gap:8px">
			<label class="hts-onb-toggle" style="margin:0"><input type="checkbox" class="hts-agent-toggle" data-agent="<?php echo esc_attr( $agent_id ); ?>" <?php checked( $enabled ); ?>><span class="sl"></span></label>
		</div>
	</div>
	<div style="font-size:17px;font-weight:700;color:var(--hts-text);margin-bottom:6px"><?php echo esc_html( $label ); ?></div>
	<div style="font-size:14px;color:var(--hts-text-3);line-height:1.5"><?php echo esc_html( $desc ); ?></div>
	<?php if ( $enabled ) : ?>
	<div style="display:flex;align-items:center;gap:6px;margin-top:10px"><span class="hts-pulse-dot"></span><span style="font-size:11px;font-weight:600;color:var(--hts-success)">Actif</span></div>
	<?php endif; ?>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<div style="font-size:16px;font-weight:700;color:var(--hts-text);margin-bottom:16px">Tous les agents</div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;margin-bottom:24px">
<?php foreach ( $other_agents as $agent_id => $label ) :
	$config  = isset( $agents[ $agent_id ] ) ? $agents[ $agent_id ] : array( 'enabled' => true, 'mode' => 'review', 'settings' => array() );
	$enabled = (bool) ( isset( $config['enabled'] ) ? $config['enabled'] : true );
	$mode    = isset( $config['mode'] ) ? $config['mode'] : 'review';
	$desc    = isset( $agent_descriptions[ $agent_id ] ) ? $agent_descriptions[ $agent_id ] : '';
	$vis     = isset( $agent_visuals[ $agent_id ] ) ? $agent_visuals[ $agent_id ] : array( 'grad' => 'linear-gradient(135deg,#94A3B8,#CBD5E1)', 'icon' => 'zap' );
	$fields  = isset( $agent_schema[ $agent_id ] ) ? $agent_schema[ $agent_id ] : array();
	$has_opts = ! empty( $fields );
	$_agent_is_ultra = $_is_not_ultra && isset( $_ultra_agents[ $agent_id ] );
?>
<div class="hts-agent-card" data-agent="<?php echo esc_attr( $agent_id ); ?>" <?php if ( $has_opts && ! $_agent_is_ultra ) : ?>onclick="htsOpenAgentModal('<?php echo esc_js( $agent_id ); ?>')"<?php endif; ?> style="cursor:<?php echo ( $has_opts && ! $_agent_is_ultra ) ? 'pointer' : 'default'; ?>;<?php echo $_agent_is_ultra ? 'opacity:0.65;' : ''; ?>">
	<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:44px">
		<div class="hts-agent-icon" style="background:<?php echo $vis['grad']; ?>">
			<?php echo HTS_DS::icon( $vis['icon'], 22, '#fff' ); ?>
		</div>
		<div onclick="event.stopPropagation()" style="display:flex;align-items:center;gap:8px">
			<?php if ( $_agent_is_ultra ) : ?>
				<?php echo HTS_DS::ultra_badge(); ?>
			<?php else : ?>
				<label class="hts-onb-toggle" style="margin:0"><input type="checkbox" class="hts-agent-toggle" data-agent="<?php echo esc_attr( $agent_id ); ?>" <?php checked( $enabled ); ?>><span class="sl"></span></label>
			<?php endif; ?>
		</div>
	</div>
	<div style="font-size:15px;font-weight:700;color:var(--hts-text);margin-bottom:4px"><?php echo esc_html( $label ); ?></div>
	<div style="font-size:13px;color:var(--hts-text-3);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden"><?php echo esc_html( $desc ); ?></div>
	<?php if ( $_agent_is_ultra ) : ?>
	<div style="display:flex;align-items:center;gap:6px;margin-top:10px"><span style="font-size:11px;font-weight:600;color:var(--hts-caution)">Disponible avec Ultra</span></div>
	<?php elseif ( $enabled ) : ?>
	<div style="display:flex;align-items:center;gap:6px;margin-top:10px"><span class="hts-pulse-dot"></span><span style="font-size:11px;font-weight:600;color:var(--hts-success)">Actif</span></div>
	<?php endif; ?>
</div>
<?php endforeach; ?>
</div>

<!-- ── Coming soon agents ── -->
<div style="font-size:16px;font-weight:700;color:var(--hts-text);margin:32px 0 16px;display:flex;align-items:center;gap:10px">Prochainement <?php echo HTS_DS::badge('2026','geo'); ?></div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;margin-bottom:24px">
<?php
$coming_soon = array(
	array(
		'name' => 'Rafraîchir contenu',
		'desc' => 'Vos anciens articles perdent en pertinence. Cet agent les repère et demande une mise à jour avant que Google ne les oublie',
		'icon' => 'refresh',
		'grad' => 'linear-gradient(135deg,#14B8A6,#5EEAD4)',
	),
	array(
		'name' => 'Traduction automatique',
		'desc' => 'Publiez dans 12 langues en un clic. Chaque article est traduit, optimisé pour le SEO local et relié automatiquement avec les balises hreflang',
		'icon' => 'globe',
		'grad' => 'linear-gradient(135deg,#0EA5E9,#67E8F9)',
	),
	array(
		'name' => 'Espionnage concurrents',
		'desc' => 'Surveillez les positions de vos concurrents, leurs nouveaux contenus et leurs stratégies. Recevez une alerte quand ils vous dépassent',
		'icon' => 'eye',
		'grad' => 'linear-gradient(135deg,#1D1D1F,#4B5563)',
	),
	array(
		'name' => 'E-commerce SEO',
		'desc' => 'Optimisez vos fiches produits, générez les descriptions et les FAQ, gérez les pages saisonnières et les promotions expirées',
		'icon' => 'trending',
		'grad' => 'linear-gradient(135deg,#F59E0B,#FBBF24)',
	),
	array(
		'name' => 'Backlinks IA',
		'desc' => 'Identifiez les meilleurs sites pour obtenir des liens vers vos articles. Générez des emails de prospection personnalisés par l\'IA',
		'icon' => 'send',
		'grad' => 'linear-gradient(135deg,#8B5CF6,#C084FC)',
	),
	array(
		'name' => 'Audit technique',
		'desc' => 'Scannez votre site comme Google le voit : vitesse, Core Web Vitals, erreurs de crawl, problèmes de rendu. Corrections en 1 clic',
		'icon' => 'gear',
		'grad' => 'linear-gradient(135deg,#64748B,#94A3B8)',
	),
);
foreach ( $coming_soon as $cs ) : ?>
<div class="hts-agent-card" style="opacity:0.55;cursor:default">
	<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:44px">
		<div class="hts-agent-icon" style="background:<?php echo $cs['grad']; ?>">
			<?php echo HTS_DS::icon( $cs['icon'], 22, '#fff' ); ?>
		</div>
	</div>
	<div style="font-size:15px;font-weight:700;color:var(--hts-text);margin-bottom:4px"><?php echo esc_html( $cs['name'] ); ?></div>
	<div style="font-size:13px;color:var(--hts-text-3);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden"><?php echo esc_html( $cs['desc'] ); ?></div>
	<div style="margin-top:10px"><?php echo HTS_DS::badge( 'Prochainement', 'geo' ); ?></div>
</div>
<?php endforeach; ?>
</div>

<?php echo HTS_DS::info_box( '<strong>Mode Relecture</strong> : chaque agent vous fait des propositions dans l&#039;Inbox. Vous choisissez d&#039;accepter, modifier ou refuser chaque action.' ); ?>

<!-- ── Agent modals (hidden, shown via JS) ── -->
<div id="hts-agent-modal-backdrop" onclick="htsCloseAgentModal()" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.45);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);z-index:100000;animation:htsFadeIn .15s ease"></div>
<?php foreach ( $ordered_labels as $agent_id => $label ) :
	$config  = isset( $agents[ $agent_id ] ) ? $agents[ $agent_id ] : array( 'enabled' => true, 'mode' => 'review', 'settings' => array() );
	$enabled = (bool) ( isset( $config['enabled'] ) ? $config['enabled'] : true );
	$mode    = isset( $config['mode'] ) ? $config['mode'] : 'review';
	$desc    = isset( $agent_descriptions[ $agent_id ] ) ? $agent_descriptions[ $agent_id ] : '';
	$vis     = isset( $agent_visuals[ $agent_id ] ) ? $agent_visuals[ $agent_id ] : array( 'grad' => 'linear-gradient(135deg,#94A3B8,#CBD5E1)', 'icon' => 'zap' );
	$fields  = isset( $agent_schema[ $agent_id ] ) ? $agent_schema[ $agent_id ] : array();
	$has_opts = ! empty( $fields );
	$saved   = isset( $config['settings'] ) ? $config['settings'] : array();
	if ( $agent_id === 'image' ) {
		$io = get_option( 'hts_image_settings', array() );
		foreach ( $io as $ik => $iv ) {
			if ( ! isset( $saved[ $ik ] ) || $saved[ $ik ] === '' || $saved[ $ik ] === null ) $saved[ $ik ] = $iv;
		}
	}
	if ( ! $has_opts ) continue;
?>
<div id="hts-agent-modal-<?php echo esc_attr( $agent_id ); ?>" class="hts-agent-modal" onclick="event.stopPropagation()" style="display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--hts-bg);border-radius:24px;width:580px;max-height:90vh;overflow-y:auto;box-shadow:0 12px 48px rgba(0,0,0,.14),0 0 1px rgba(0,0,0,.1);z-index:100001;animation:htsScaleIn .2s ease">
	<!-- Close -->
	<button onclick="htsCloseAgentModal()" style="position:absolute;top:16px;right:16px;width:32px;height:32px;border-radius:50%;border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:10;font-size:16px;color:var(--hts-text-3);line-height:1">&times;</button>
	<!-- Icon -->
	<div style="display:flex;justify-content:center;padding-top:32px">
		<div style="width:72px;height:72px;border-radius:50%;background:<?php echo $vis['grad']; ?>;display:flex;align-items:center;justify-content:center">
			<?php echo HTS_DS::icon( $vis['icon'], 32, '#fff' ); ?>
		</div>
	</div>
	<!-- Header -->
	<div style="padding:12px 36px 0;text-align:center">
		<div style="font-size:22px;font-weight:700;color:var(--hts-text);margin-bottom:6px"><?php echo esc_html( $label ); ?></div>
		<div style="font-size:14px;color:var(--hts-text-3);line-height:1.5;margin-bottom:24px"><?php echo esc_html( $desc ); ?></div>
	</div>
	<!-- Toggle -->
	<div style="padding:0 36px 16px;display:flex;gap:16px">
		<div style="flex:1;background:var(--hts-surface);border-radius:var(--hts-radius-sm);padding:10px 14px;display:flex;align-items:center;gap:8px">
			<?php echo HTS_DS::icon( 'settings', 15, 'var(--hts-text-3)' ); ?>
			<span style="font-size:12px;font-weight:600;color:var(--hts-text-2);text-transform:uppercase">Mode</span>
			<div style="margin-left:auto"><span style="font-size:12px;font-weight:500;color:var(--hts-text)">Relecture</span></div>
		</div>
		<div style="background:var(--hts-surface);border-radius:var(--hts-radius-sm);padding:10px 14px;display:flex;align-items:center;gap:8px">
			<span style="font-size:12px;font-weight:600;color:var(--hts-text-2)">Actif</span>
			<label class="hts-onb-toggle" style="margin:0"><input type="checkbox" class="hts-agent-toggle" data-agent="<?php echo esc_attr( $agent_id ); ?>" <?php checked( $enabled ); ?>><span class="sl"></span></label>
		</div>
	</div>
	<!-- Settings -->
	<div style="padding:0 36px 32px">
		<?php
		$_show_keys = defined( 'HTS_SHOW_API_KEYS' ) && HTS_SHOW_API_KEYS;
		$client_fields = array_filter( $fields, function( $f ) use ( $_show_keys ) {
			if ( ! empty( $f['advanced'] ) ) return false;
			if ( ! empty( $f['require_show_keys'] ) && ! $_show_keys ) return false;
			return true;
		} );
		$advanced_fields = array_filter( $fields, function( $f ) use ( $_show_keys ) {
			if ( empty( $f['advanced'] ) ) return false;
			if ( ! empty( $f['require_show_keys'] ) && ! $_show_keys ) return false;
			return true;
		} );
		?>
		<div style="font-size:12px;font-weight:600;color:var(--hts-text-2);text-transform:uppercase;margin-bottom:8px">Réglages</div>
		<div style="background:var(--hts-surface);border-radius:var(--hts-radius-sm);padding:2px 0">
		<?php $fi = 0; foreach ( $client_fields as $field ) : $fkey = $field['key']; $fval = isset( $saved[ $fkey ] ) ? $saved[ $fkey ] : $field['default']; $fid = 'hts-as-' . $agent_id . '-' . $fkey; $fi++; ?>
			<?php if ( $field['type'] === 'visual_select' ) : ?>
			<div style="padding:10px 14px;<?php echo $fi < count( $client_fields ) ? 'border-bottom:1px solid var(--hts-border-sub);' : ''; ?>">
				<div style="font-size:13px;font-weight:500;color:var(--hts-text)"><?php echo esc_html( $field['label'] ); ?></div>
				<?php if ( ! empty( $field['desc'] ) ) : ?><div style="font-size:11px;color:var(--hts-text-3);margin-top:1px"><?php echo esc_html( $field['desc'] ); ?></div><?php endif; ?>
				<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:8px;">
				<?php $vs_icons = array( 'illustration' => "\xF0\x9F\x96\xBC\xEF\xB8\x8F", 'photo_realistic' => "\xF0\x9F\x93\xB7", 'infographic' => "\xF0\x9F\x93\x8A", 'minimalist' => "\xE2\x9C\xA8" );
				foreach ( $field['options'] as $vk => $vl ) : $vs_sel = ( (string) $fval === $vk ); ?>
				<label style="cursor:pointer;border:2px solid <?php echo $vs_sel ? 'var(--hts-geo)' : 'var(--hts-border)'; ?>;border-radius:12px;padding:14px 10px;text-align:center;transition:all .2s;<?php echo $vs_sel ? 'background:var(--hts-geo-soft);' : ''; ?>">
					<input type="radio" class="hts-agent-setting" data-agent="<?php echo esc_attr( $agent_id ); ?>" data-key="<?php echo esc_attr( $fkey ); ?>" name="<?php echo esc_attr( $fid ); ?>" value="<?php echo esc_attr( $vk ); ?>" <?php checked( $vs_sel ); ?> style="display:none;" onchange="this.closest('div[style*=grid]').querySelectorAll('label').forEach(function(l){l.style.border='2px solid var(--hts-border)';l.style.background='';});this.closest('label').style.border='2px solid var(--hts-geo)';this.closest('label').style.background='var(--hts-geo-soft)';">
					<div style="font-size:24px;margin-bottom:6px;"><?php echo $vs_icons[ $vk ] ?? "\xF0\x9F\x8E\xA8"; ?></div>
					<div style="font-size:11px;font-weight:<?php echo $vs_sel ? '600' : '400'; ?>;color:var(--hts-text);"><?php echo esc_html( $vl ); ?></div>
				</label>
				<?php endforeach; ?>
				</div>
			</div>
			<?php elseif ( $field['type'] === 'color' ) : ?>
			<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;<?php echo $fi < count( $client_fields ) ? 'border-bottom:1px solid var(--hts-border-sub);' : ''; ?>">
				<div style="flex:1;margin-right:12px">
					<div style="font-size:13px;font-weight:500;color:var(--hts-text)"><?php echo esc_html( $field['label'] ); ?></div>
					<?php if ( ! empty( $field['desc'] ) ) : ?><div style="font-size:11px;color:var(--hts-text-3);margin-top:1px"><?php echo esc_html( $field['desc'] ); ?></div><?php endif; ?>
				</div>
				<div style="display:flex;gap:8px;align-items:center;flex-shrink:0;">
					<input type="color" value="<?php echo esc_attr( $fval ?: '#3B82F6' ); ?>" style="width:40px;height:32px;border:1px solid var(--hts-border);border-radius:6px;cursor:pointer;" onchange="this.nextElementSibling.value=this.value">
					<input type="text" class="hts-agent-setting" id="<?php echo esc_attr( $fid ); ?>" data-agent="<?php echo esc_attr( $agent_id ); ?>" data-key="<?php echo esc_attr( $fkey ); ?>" value="<?php echo esc_attr( $fval ); ?>" placeholder="#3B82F6" style="width:100px;padding:6px 10px;border:1px solid var(--hts-border);border-radius:6px;font-size:12px;font-family:monospace;" oninput="this.previousElementSibling.value=this.value||'#3B82F6'">
				</div>
			</div>
			<?php else : ?>
			<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;<?php echo $fi < count( $client_fields ) ? 'border-bottom:1px solid var(--hts-border-sub);' : ''; ?>">
				<div style="flex:1;margin-right:12px">
					<div style="font-size:13px;font-weight:500;color:var(--hts-text)"><?php echo esc_html( $field['label'] ); ?></div>
					<?php if ( ! empty( $field['desc'] ) ) : ?><div style="font-size:11px;color:var(--hts-text-3);margin-top:1px"><?php echo esc_html( $field['desc'] ); ?></div><?php endif; ?>
				</div>
				<div style="flex-shrink:0">
				<?php if ( $field['type'] === 'number' ) : ?>
					<?php echo HTS_DS::input( array( 'type' => 'number', 'id' => $fid, 'class' => 'hts-agent-setting', 'value' => $fval, 'style' => 'width:100px;text-align:center', 'data-agent' => $agent_id, 'data-key' => $fkey ) ); ?>
					<?php if ( ! empty( $field['auto_recommend'] ) ) : ?><div id="hts-meta-recommend-<?php echo esc_attr( $fkey ); ?>" style="margin-top:4px;font-size:10px;color:var(--hts-geo);cursor:pointer" data-input="<?php echo esc_attr( $fid ); ?>"><span style="opacity:.6">Reco...</span></div><?php endif; ?>
				<?php elseif ( $field['type'] === 'select' ) : ?>
					<?php echo HTS_DS::select( $field['options'], (string) $fval, array( 'id' => $fid, 'class' => 'hts-agent-setting', 'data-agent' => $agent_id, 'data-key' => $fkey, 'style' => 'font-size:12px;padding:4px 8px' ) ); ?>
				<?php elseif ( $field['type'] === 'toggle' ) : ?>
					<label class="hts-onb-toggle"><input type="checkbox" class="hts-agent-setting" id="<?php echo esc_attr( $fid ); ?>" data-agent="<?php echo esc_attr( $agent_id ); ?>" data-key="<?php echo esc_attr( $fkey ); ?>" <?php checked( (bool) $fval ); ?>><span class="sl"></span></label>
				<?php elseif ( $field['type'] === 'password' ) : ?>
					<div style="display:flex;gap:8px;align-items:center"><?php echo HTS_DS::input( array( 'type' => 'password', 'id' => $fid, 'class' => 'hts-agent-setting', 'value' => $fval, 'style' => 'width:180px;font-size:12px;font-family:var(--hts-mono)', 'data-agent' => $agent_id, 'data-key' => $fkey ) ); ?><?php if ( ! empty( $field['test_action'] ) ) : echo HTS_DS::button( 'Tester', 'default', 'sm', array( 'type' => 'button', 'onclick' => "htsTestAgentKey(this,'" . esc_js( $field['test_action'] ) . "','" . esc_js( $fid ) . "','" . esc_js( isset( $field['test_param'] ) ? $field['test_param'] : $fkey ) . "')" ) ); endif; ?></div>
					<span id="<?php echo esc_attr( $fid ); ?>-status" style="font-size:10px;margin-top:3px;display:block"></span>
				<?php elseif ( $field['type'] === 'textarea' ) : ?>
					<textarea id="<?php echo esc_attr( $fid ); ?>" class="hts-ds-input hts-agent-setting" data-agent="<?php echo esc_attr( $agent_id ); ?>" data-key="<?php echo esc_attr( $fkey ); ?>" rows="2" maxlength="500" style="width:260px;font-size:12px;resize:vertical"><?php echo esc_textarea( $fval ); ?></textarea>
				<?php endif; ?>
				</div>
			</div>
			<?php endif; ?>
		<?php endforeach; ?>
		</div>
		<?php if ( ! empty( $advanced_fields ) ) : ?>
		<div style="margin-top:16px;">
			<div onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'block':'none';this.querySelector('span').textContent=this.nextElementSibling.style.display==='none'?'&#9654;':'&#9660;'" style="cursor:pointer;font-size:12px;color:var(--hts-text-3);padding:8px 0;">
				<span>&#9654;</span> Configuration avancée
			</div>
			<div style="display:none;background:var(--hts-surface);border-radius:var(--hts-radius-sm);padding:2px 0">
			<?php $afi = 0; foreach ( $advanced_fields as $field ) : $fkey = $field['key']; $fval = isset( $saved[ $fkey ] ) ? $saved[ $fkey ] : $field['default']; $fid = 'hts-as-' . $agent_id . '-' . $fkey; $afi++; ?>
				<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;<?php echo $afi < count( $advanced_fields ) ? 'border-bottom:1px solid var(--hts-border-sub);' : ''; ?>">
					<div style="flex:1;margin-right:12px">
						<div style="font-size:13px;font-weight:500;color:var(--hts-text)"><?php echo esc_html( $field['label'] ); ?></div>
					</div>
					<div style="flex-shrink:0">
					<?php if ( $field['type'] === 'select' ) : ?>
						<?php echo HTS_DS::select( $field['options'], (string) $fval, array( 'id' => $fid, 'class' => 'hts-agent-setting', 'data-agent' => $agent_id, 'data-key' => $fkey, 'style' => 'font-size:12px;padding:4px 8px' ) ); ?>
					<?php elseif ( $field['type'] === 'password' ) : ?>
						<div style="display:flex;gap:8px;align-items:center"><?php echo HTS_DS::input( array( 'type' => 'password', 'id' => $fid, 'class' => 'hts-agent-setting', 'value' => $fval, 'style' => 'width:180px;font-size:12px;font-family:var(--hts-mono)', 'data-agent' => $agent_id, 'data-key' => $fkey ) ); ?><?php if ( ! empty( $field['test_action'] ) ) : echo HTS_DS::button( 'Tester', 'default', 'sm', array( 'type' => 'button', 'onclick' => "htsTestAgentKey(this,'" . esc_js( $field['test_action'] ) . "','" . esc_js( $fid ) . "','" . esc_js( isset( $field['test_param'] ) ? $field['test_param'] : $fkey ) . "')" ) ); endif; ?></div>
						<span id="<?php echo esc_attr( $fid ); ?>-status" style="font-size:10px;margin-top:3px;display:block"></span>
					<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>
		<!-- Save + extras -->
		<div style="margin-top:14px;display:flex;align-items:center;gap:12px">
			<?php echo HTS_DS::button( 'Enregistrer', 'primary', 'sm', array( 'type' => 'button', 'onclick' => 'htsAgentSettingsSave(\'' . esc_js( $agent_id ) . '\')' ) ); ?>
			<?php if ( $agent_id === 'image' ) : echo HTS_DS::button( 'Tester une image', 'success', 'sm', array( 'type' => 'button', 'id' => 'hts-test-image-btn', 'onclick' => 'htsTestImageGen(this)' ) ); endif; ?>
			<span class="hts-agent-settings-status" data-agent="<?php echo esc_attr( $agent_id ); ?>" style="font-size:12px"></span>
		</div>
		<?php if ( $agent_id === 'image' ) : ?>
		<div id="hts-test-image-zone" style="display:none;margin-top:14px;padding:14px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:var(--hts-radius-sm)">
			<div style="display:flex;gap:8px;align-items:end;flex-wrap:wrap"><div style="flex:1;min-width:200px"><label style="font-size:10px;font-weight:600;color:var(--hts-text-2);display:block;margin-bottom:4px">Prompt de test</label><?php echo HTS_DS::input( array( 'type' => 'text', 'id' => 'hts-test-image-prompt', 'placeholder' => 'Ex: Modern office workspace', 'style' => 'width:100%;font-size:12px' ) ); ?></div><?php echo HTS_DS::button( 'Générer', 'primary', 'sm', array( 'type' => 'button', 'id' => 'hts-test-image-go', 'onclick' => 'htsTestImageGo()' ) ); ?></div>
			<div id="hts-test-image-status" style="font-size:11px;margin-top:8px;color:var(--hts-text-2)"></div><div id="hts-test-image-result" style="margin-top:10px"></div>
		</div>
		<?php endif; ?>
	</div>
</div>
<?php endforeach; ?>

<div class="hts-ds-card" style="margin-top:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Tester le mode automatique','Simule un passage de l&#039;agent Meta sur les 5 pages les plus faibles'); ?>
	<div style="display:flex;gap:10px;flex-wrap:wrap"><?php echo HTS_DS::button('Simulation (sans modifier)','primary','sm',array('type'=>'button','id'=>'hts-dry-run-btn','onclick'=>'htsDryRun(0)')); ?><?php echo HTS_DS::button('Exécuter sur 1 page','default','sm',array('type'=>'button','id'=>'hts-dry-run-exec-btn','onclick'=>'htsDryRun(1)')); ?><span id="hts-dry-run-status" style="font-size:12px;color:var(--hts-text-2)"></span></div>
	<div id="hts-dry-run-results" style="display:none;margin-top:16px"></div>
</div></div>
<div class="hts-ds-card" style="margin-top:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Transférer les réglages'); ?>
	<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
		<?php echo HTS_DS::button('Exporter (JSON)','default','sm',array('type'=>'button','id'=>'hts-agent-export-btn','onclick'=>'htsAgentExport()'),HTS_DS::icon('download',13,'var(--hts-text-2)')); ?>
		<label style="display:inline-flex;align-items:center"><?php echo HTS_DS::button('Importer (JSON)','default','sm',array(),HTS_DS::icon('upload',13,'var(--hts-text-2)')); ?><input type="file" accept=".json" id="hts-agent-import-input" onchange="htsAgentImport(this)" style="display:none"></label>
		<span id="hts-agent-transfer-status" style="font-size:12px;color:var(--hts-text-2)"></span>
	</div>
</div></div>
<div class="hts-ds-card" style="margin-top:16px"><div class="hts-ds-card__body">
	<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><?php echo HTS_DS::section_title('Historique des modifications'); ?><?php echo HTS_DS::button('Charger','default','sm',array('type'=>'button','onclick'=>'htsLoadAgentHistory()')); ?></div>
	<div id="hts-agent-history-list" style="font-size:12px;color:var(--hts-text-2);max-height:400px;overflow-y:auto">Cliquez « Charger » pour voir les dernières modifications.</div>
</div></div>
<?php endif; ?>

<?php if ( $active_tab === 'guardrails' ) : ?>
<!-- Warning banner -->
<div style="padding:14px 18px;background:var(--hts-caution-bg,#FFFBEB);border:1px solid var(--hts-caution,#F59E0B);border-radius:var(--hts-radius-sm);margin-bottom:16px;display:flex;gap:12px;align-items:flex-start">
	<?php echo HTS_DS::icon('shield',18,'var(--hts-caution)'); ?>
	<div>
		<div style="font-size:13px;font-weight:600;color:var(--hts-text);margin-bottom:2px">Ces limites sont calculées pour votre site</div>
		<div style="font-size:12px;color:var(--hts-text-2);line-height:1.5">Hack The SEO calibre automatiquement le rythme des modifications en fonction de la taille de votre site. Modifier ces valeurs sans raison peut provoquer des signaux inhabituels pour Google. En cas de doute, cliquez « Appliquer les valeurs recommandées ».</div>
	</div>
</div>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Rythme des modifications','Combien de changements chaque agent peut faire par semaine, et combien de temps attendre avant de retoucher la même page'); ?>
	<div id="hts-gf-agents-table" style="font-size:12px"><p style="color:var(--hts-text-3)">Chargement...</p></div>
	<div style="margin-top:16px;display:flex;align-items:center;gap:12px">
		<?php echo HTS_DS::button('Appliquer les valeurs recommandées','default','sm',array('type'=>'button','id'=>'hts-gf-agents-apply-reco','style'=>'border-color:var(--hts-geo);color:var(--hts-geo);background:var(--hts-geo-soft)'),HTS_DS::icon('lightbulb',13,'var(--hts-geo)')); ?>
		<?php echo HTS_DS::button('Enregistrer','primary','sm',array('type'=>'button','id'=>'hts-gf-agents-save')); ?>
		<span id="hts-gf-agents-status" style="font-size:12px"></span>
	</div>
</div></div>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Protection globale','Limites qui s&#039;appliquent à tous les agents en même temps'); ?>
	<!-- Budget API masqué — valeur par défaut 30$ appliquée automatiquement -->
	<?php /* echo HTS_DS::row('Budget API maximum par mois','Quand ce montant est atteint, toutes les actions IA s&#039;arrêtent jusqu&#039;au mois suivant','<div style="display:flex;align-items:center;gap:4px"><span style="font-size:13px;color:var(--hts-text-3)">$</span>'.HTS_DS::input(array('type'=>'number','id'=>'hts-gf-budget','value'=>$gf_max_budget,'style'=>'width:80px;text-align:right')).'</div>',false,'shield'); */ ?>
	<?php echo HTS_DS::row('Pages protégées (ne jamais toucher)','Vos pages les plus importantes. Aucun agent ne modifiera ces pages automatiquement (IDs séparés par des virgules)',HTS_DS::input(array('type'=>'text','id'=>'hts-gf-blacklist','value'=>$gf_blacklist_str,'placeholder'=>'ex : 42, 156, 789','style'=>'width:200px'))); ?>
	<?php echo HTS_DS::row('Seuil de trafic (clics/mois)','Les pages qui reçoivent beaucoup de trafic ne sont jamais modifiées automatiquement',HTS_DS::input(array('type'=>'number','id'=>'hts-gf-traffic','value'=>$gf_traffic_thr,'style'=>'width:80px;text-align:right')),false,'shield'); ?>
	<?php echo HTS_DS::row('Heures de travail des agents','Les agents automatiques n&#039;exécutent que dans cette plage horaire','<div style="display:flex;align-items:center;gap:6px">'.HTS_DS::input(array('type'=>'number','id'=>'hts-gf-auto-hours-start','value'=>$gf_auto_hours_start,'style'=>'width:60px;text-align:center')).'<span style="font-size:12px;color:var(--hts-text-3)">h à</span>'.HTS_DS::input(array('type'=>'number','id'=>'hts-gf-auto-hours-end','value'=>$gf_auto_hours_end,'style'=>'width:60px;text-align:center')).'<span style="font-size:12px;color:var(--hts-text-3)">h</span></div>'); ?>
	<?php /* ── Coach budget masqué — pas pertinent pour les clients ──
	echo HTS_DS::row('Budget Coach SEO','Le Coach SEO a son propre budget pour ses réponses. 100 000 tokens ≈ 50 questions','<div style="display:flex;align-items:center;gap:8px">'.HTS_DS::input(array('type'=>'number','id'=>'hts-gf-coach-budget','value'=>$coach_budget,'style'=>'width:140px;text-align:right')).'<span style="font-size:11px;color:var(--hts-text-3)">tokens</span></div>',true);
	*/ ?>
	<div style="margin-top:16px"><?php echo HTS_DS::button('Enregistrer','primary','md',array('type'=>'button','id'=>'hts-gf-save')); ?> <span id="hts-gf-status" style="margin-left:12px;font-size:12px"></span></div>
</div></div>
<?php endif; ?>

<?php if ( $active_tab === 'seo' ) :
	// Prepare variables expected by seo-settings.php
	$hts_embedded_seo = true;
	$settings = array(
		'home_title'       => get_option( 'hts_home_title', '' ),
		'home_description' => get_option( 'hts_home_description', '' ),
		'title_separator'  => get_option( 'hts_title_separator', "\xE2\x80\x94" ),
		'twitter_handle'   => get_option( 'hts_twitter_handle', '' ),
		'social_profiles'  => get_option( 'hts_social_profiles', array() ),
	);
	if ( ! is_array( $settings['social_profiles'] ) ) {
		$settings['social_profiles'] = array();
	}
	$competitor = false;
	$competitor_settings = array(
		'home_title' => '', 'home_description' => '',
		'title_separator' => '', 'twitter_handle' => '',
		'social_profiles' => array(),
	);
	// Enqueue SEO settings JS (handles SERP preview, char counters, schema preview, etc.)
	wp_enqueue_script(
		'hts-seo-settings',
		HTS__PLUGIN_URL . 'admin/js/hts-seo-settings.js',
		array( 'jquery' ),
		defined( 'HTS__VERSION' ) ? HTS__VERSION : '2.6.0',
		true
	);
	include HTS__PLUGIN_DIR . 'admin/partials/seo-settings.php';
endif; ?>

<?php if ( $active_tab === 'notifications' ) :
	$ns=get_option('hts_notif_settings',array());$nf=$ns['frequency']??'weekly';$nc=$ns['sections']??array('wins'=>'1','alerts'=>'1','kpis'=>'1','gsc'=>'1');$ne=get_option('hts_digest_enabled','1');$nem=get_option('hts_notif_email',get_option('admin_email'));
?>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Digest par email','Recevez un résumé de l&#039;activité SEO de votre site'); ?>
	<?php echo HTS_DS::row('Activer le digest','Envoi automatique du résumé par email','<label class="hts-onb-toggle"><input type="checkbox" id="hts-notif-enabled-toggle" '.checked($ne,'1',false).'><span class="sl"></span></label>',false,'mail'); ?>
	<?php echo HTS_DS::row('Adresse email','Adresse de réception',HTS_DS::input(array('type'=>'email','id'=>'hts-notif-email-input','value'=>$nem,'placeholder'=>'votre@email.com','style'=>'width:260px')),false,'mail'); ?>
	<?php echo HTS_DS::row('Fréquence','À quelle fréquence recevoir le digest','<div class="hts-ds-tabs" style="font-size:0">'.implode('',array_map(function($v,$l)use($nf){$c='hts-ds-tabs__item'.($nf===$v?' hts-ds-tabs__item--active':'');return '<label class="'.$c.'" style="cursor:pointer"><input type="radio" name="hts_notif_freq_u" value="'.esc_attr($v).'"'.checked($nf,$v,false).' style="display:none">'.esc_html($l).'</label>';},array_keys($ff=array('daily'=>'Quotidien','weekly'=>'Hebdo','biweekly'=>'Bi-mensuel','monthly'=>'Mensuel')),$ff)).'</div>',true); ?>
</div></div>
<div class="hts-ds-card" style="margin-bottom:16px"><div class="hts-ds-card__body">
	<?php echo HTS_DS::section_title('Sections du digest','Choisissez les sections incluses'); ?>
	<div class="hts-ds-grid-2">
	<?php foreach(array('wins'=>array('l'=>'Victoires SEO','d'=>'Gains de position, nouveaux mots-clés'),'alerts'=>array('l'=>'Alertes','d'=>'Erreurs 404, baisses de trafic'),'kpis'=>array('l'=>'KPIs','d'=>'Score moyen, couverture meta'),'gsc'=>array('l'=>'Google Search Console','d'=>'Clics, impressions, positions')) as $k=>$def):$ch=($nc[$k]??'1')==='1'; ?>
	<label style="display:flex;gap:10px;padding:14px 16px;border-radius:var(--hts-radius-sm);border:1.5px solid <?php echo $ch?'var(--hts-geo)':'var(--hts-border)'; ?>;background:<?php echo $ch?'var(--hts-geo-soft)':'var(--hts-bg)'; ?>;cursor:pointer">
		<input type="checkbox" class="hts-notif-section-cb" data-section="<?php echo esc_attr($k); ?>" <?php checked($ch); ?> style="accent-color:var(--hts-geo);margin-top:2px">
		<div><div style="font-size:13px;font-weight:600;color:var(--hts-text)"><?php echo esc_html($def['l']); ?></div><div style="font-size:11px;color:var(--hts-text-3);margin-top:2px"><?php echo esc_html($def['d']); ?></div></div>
	</label>
	<?php endforeach; ?>
	</div>
</div></div>
<div style="display:flex;gap:10px;align-items:center">
	<?php echo HTS_DS::button('Enregistrer','primary','md',array('type'=>'button','id'=>'hts-notif-save-btn','onclick'=>'htsSaveNotifSettings()')); ?>
	<?php echo HTS_DS::button('Envoyer un test','default','sm',array('type'=>'button','onclick'=>'htsTestDigestUnified()'),HTS_DS::icon('mail',13,'var(--hts-text-2)')); ?>
	<?php echo HTS_DS::button('Aperçu','default','sm',array('type'=>'button','onclick'=>'htsPreviewDigestUnified()'),HTS_DS::icon('eye',13,'var(--hts-text-2)')); ?>
	<span id="hts-notif-save-msg" style="font-size:12px;color:var(--hts-text-2)"></span>
</div>
<div id="hts-notif-preview-u" style="display:none;margin-top:16px;border:1px solid var(--hts-border);border-radius:var(--hts-radius);overflow:hidden">
	<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 16px;background:var(--hts-bg);border-bottom:1px solid var(--hts-border)"><span style="font-size:13px;font-weight:600">Aperçu du digest</span><button type="button" onclick="document.getElementById('hts-notif-preview-u').style.display='none'" style="border:none;background:none;cursor:pointer;font-size:16px;color:var(--hts-text-3)">✕</button></div>
	<iframe id="hts-notif-preview-u-iframe" style="width:100%;height:600px;border:none"></iframe>
</div>
<?php endif; ?>

<?php if ( $active_tab === 'health' ) :
	include HTS__PLUGIN_DIR . 'admin/partials/health.php';
endif; ?>

<?php if ( $active_tab === 'plans' ) :
	$_plan_tier = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::get_plan_tier() : 0;
	$_plan_slug = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::get_plan_slug() : 'free';
	$_plan_labels = array( 0 => 'Free', 1 => 'Pro (99€/mois)', 2 => 'Ultra (249€/mois)' );
	$_pricing_url = 'https://hacktheseo.com/pricing';
?>

<!-- Header -->
<div style="text-align:center;margin-bottom:32px">
	<h2 style="font-size:24px;font-weight:800;color:var(--hts-text);margin:0 0 8px">Choisissez votre plan</h2>
	<p style="font-size:14px;color:var(--hts-text-2);margin:0 0 16px">Du diagnostic gratuit à l'automatisation complète.</p>
	<span style="display:inline-flex;align-items:center;gap:6px;padding:6px 16px;border-radius:8px;background:var(--hts-success-bg);color:var(--hts-success);font-size:13px;font-weight:600">
		<?php echo HTS_DS::icon( 'check', 14, 'var(--hts-success)' ); ?> Votre plan : <?php echo esc_html( $_plan_labels[ $_plan_tier ] ?? 'Free' ); ?>
	</span>
</div>

<!-- 3 columns -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:40px">

	<!-- FREE -->
	<div class="hts-ds-card" style="padding:28px 24px;display:flex;flex-direction:column;<?php echo $_plan_tier === 0 ? 'border:2px solid var(--hts-success);' : ''; ?>">
		<div style="font-size:18px;font-weight:800;color:var(--hts-text);margin-bottom:4px">Free</div>
		<div style="font-size:28px;font-weight:800;color:var(--hts-text)">0€<span style="font-size:13px;font-weight:400;color:var(--hts-text-3)">/mois</span></div>
		<div style="font-size:12px;color:var(--hts-text-3);margin:8px 0 20px">Le check-up SEO complet, gratuit pour toujours.</div>
		<ul style="list-style:none;padding:0;margin:0 0 24px;flex:1">
			<?php foreach ( array(
				'SEO technique complet (12 modules)',
				'Score SEO + GEO Score',
				'Google Search Console',
				'Health Check complet',
				'Coach SEO (5 questions/mois)',
				'Support chat IA (10 questions/mois)',
				'Articles via le SaaS',
			) as $f ) : ?>
			<li style="display:flex;align-items:flex-start;gap:8px;padding:5px 0;font-size:12px;color:var(--hts-text-2)">
				<?php echo HTS_DS::icon( 'check', 13, 'var(--hts-success)' ); ?> <?php echo esc_html( $f ); ?>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $_plan_tier === 0 ) : ?>
			<div style="text-align:center;padding:10px;border-radius:10px;background:var(--hts-success-bg);color:var(--hts-success);font-size:13px;font-weight:700">Plan actuel</div>
		<?php else : ?>
			<div style="text-align:center;padding:10px;border-radius:10px;border:1px solid var(--hts-border);color:var(--hts-text-3);font-size:13px">Plan gratuit</div>
		<?php endif; ?>
	</div>

	<!-- PRO 99€ -->
	<div class="hts-ds-card" style="padding:28px 24px;display:flex;flex-direction:column;<?php echo $_plan_tier === 1 ? 'border:2px solid var(--hts-geo);' : ''; ?>">
		<div style="font-size:18px;font-weight:800;color:var(--hts-text);margin-bottom:4px">Pro</div>
		<div style="font-size:14px;font-weight:600;color:#94a3b8;text-decoration:line-through">199€/mois</div>
		<div style="font-size:28px;font-weight:800;color:var(--hts-geo)">99€<span style="font-size:13px;font-weight:400;color:var(--hts-text-3)">/mois</span></div>
		<div style="font-size:12px;color:var(--hts-text-3);margin:8px 0 20px">Analysez, planifiez et posez toutes vos questions.</div>
		<ul style="list-style:none;padding:0;margin:0 0 24px;flex:1">
			<li style="display:flex;align-items:flex-start;gap:8px;padding:5px 0;font-size:12px;color:var(--hts-geo);font-weight:600"><?php echo HTS_DS::icon( 'arrow-right', 13, 'var(--hts-geo)' ); ?> Tout le Free +</li>
			<?php foreach ( array(
				'Coach SEO illimité',
				'Rapports automatiques (maillage, contenu, performance, audit)',
				'Cocons sémantiques (analyse + planification IA)',
				'Détection de cannibalisation',
				'Suivi des contenus à rafraîchir',
				'10 articles/mois via le SaaS',
			) as $f ) : ?>
			<li style="display:flex;align-items:flex-start;gap:8px;padding:5px 0;font-size:12px;color:var(--hts-text-2)">
				<?php echo HTS_DS::icon( 'check', 13, 'var(--hts-success)' ); ?> <?php echo esc_html( $f ); ?>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $_plan_tier === 1 ) : ?>
			<div style="text-align:center;padding:10px;border-radius:10px;background:var(--hts-geo-soft);color:var(--hts-geo);font-size:13px;font-weight:700">Plan actuel</div>
		<?php elseif ( $_plan_tier < 1 ) : ?>
			<a href="<?php echo esc_url( $_pricing_url ); ?>" target="_blank" style="display:block;text-align:center;padding:12px;border-radius:10px;background:var(--hts-geo);color:#fff;font-size:14px;font-weight:700;text-decoration:none">S'abonner — 99€/mois</a>
		<?php else : ?>
			<div style="text-align:center;padding:10px;border-radius:10px;border:1px solid var(--hts-border);color:var(--hts-text-3);font-size:13px">Inclus dans Ultra</div>
		<?php endif; ?>
	</div>

	<!-- ULTRA 249€ -->
	<div class="hts-ds-card" style="padding:28px 24px;display:flex;flex-direction:column;border:2px solid #8b5cf6;position:relative;<?php echo $_plan_tier === 2 ? '' : ''; ?>">
		<div style="position:absolute;top:-10px;right:16px;padding:3px 12px;border-radius:6px;background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;font-size:10px;font-weight:700;letter-spacing:.04em">RECOMMANDÉ</div>
		<div style="font-size:18px;font-weight:800;color:var(--hts-text);margin-bottom:4px">Ultra</div>
		<div style="font-size:14px;font-weight:600;color:#94a3b8;text-decoration:line-through">499€/mois</div>
		<div style="font-size:28px;font-weight:800;color:#8b5cf6">249€<span style="font-size:13px;font-weight:400;color:var(--hts-text-3)">/mois</span></div>
		<div style="font-size:12px;color:var(--hts-text-3);margin:8px 0 20px">Tout est automatisé. Vous pilotez, l'IA exécute.</div>
		<ul style="list-style:none;padding:0;margin:0 0 24px;flex:1">
			<li style="display:flex;align-items:flex-start;gap:8px;padding:5px 0;font-size:12px;color:#8b5cf6;font-weight:600"><?php echo HTS_DS::icon( 'arrow-right', 13, '#8b5cf6' ); ?> Tout le Pro +</li>
			<?php foreach ( array(
				'50 articles/mois rédigés automatiquement avec images',
				'Maillage interne IA automatique',
				'Inbox : actions SEO en 1 clic',
				'Mode Agent : le Coach exécute pour vous',
				'Rapport hebdomadaire par email',
				'PDF avec votre logo',
				'Publication programmée automatique',
				'Agents optionnels (traduction, e-commerce, local)',
			) as $f ) : ?>
			<li style="display:flex;align-items:flex-start;gap:8px;padding:5px 0;font-size:12px;color:var(--hts-text-2)">
				<?php echo HTS_DS::icon( 'check', 13, '#8b5cf6' ); ?> <?php echo esc_html( $f ); ?>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $_plan_tier === 2 ) : ?>
			<div style="text-align:center;padding:10px;border-radius:10px;background:rgba(139,92,246,.1);color:#8b5cf6;font-size:13px;font-weight:700">Plan actuel</div>
		<?php else : ?>
			<a href="<?php echo esc_url( $_pricing_url ); ?>" target="_blank" style="display:block;text-align:center;padding:12px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;text-decoration:none;box-shadow:0 4px 14px rgba(99,102,241,.3)">S'abonner — 249€/mois</a>
		<?php endif; ?>
	</div>

</div>

<!-- FAQ -->
<div class="hts-ds-card" style="padding:28px 24px;margin-bottom:24px">
	<h3 style="font-size:16px;font-weight:700;color:var(--hts-text);margin:0 0 16px">Questions fréquentes</h3>
	<?php
	$_faqs = array(
		array( 'q' => 'Puis-je changer de plan à tout moment ?', 'a' => 'Oui, vous pouvez upgrader ou downgrader instantanément. Le changement prend effet immédiatement.' ),
		array( 'q' => 'Mes données sont-elles conservées si je change de plan ?', 'a' => 'Oui, vos cocons, configurations et articles restent intacts. Seules les fonctionnalités disponibles changent.' ),
		array( 'q' => 'Comment fonctionne la rédaction d\'articles ?', 'a' => 'En Pro, vous rédigez depuis le SaaS (app.hacktheseo.com). En Ultra, le plugin rédige automatiquement avec images et liens internes.' ),
		array( 'q' => 'Qu\'est-ce que le maillage IA ?', 'a' => 'Le plugin analyse vos articles et crée automatiquement des liens entre eux pour améliorer votre référencement. Disponible avec le plan Ultra.' ),
		array( 'q' => 'Puis-je ajouter plusieurs sites ?', 'a' => 'Oui, chaque site a son propre abonnement et sa propre clé API. Agences : 249€ + 150€/site supplémentaire.' ),
		array( 'q' => 'Y a-t-il un engagement ?', 'a' => 'Non, résiliation à tout moment. Des plans annuels avec -20% sont disponibles sur demande.' ),
	);
	foreach ( $_faqs as $i => $faq ) : ?>
	<details style="border-bottom:1px solid var(--hts-border-sub);<?php echo $i === 0 ? 'border-top:1px solid var(--hts-border-sub);' : ''; ?>">
		<summary style="padding:14px 0;font-size:14px;font-weight:600;color:var(--hts-text);cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center">
			<?php echo esc_html( $faq['q'] ); ?>
			<span style="font-size:18px;color:var(--hts-text-3);flex-shrink:0;margin-left:12px">+</span>
		</summary>
		<div style="padding:0 0 14px;font-size:13px;color:var(--hts-text-2);line-height:1.6"><?php echo esc_html( $faq['a'] ); ?></div>
	</details>
	<?php endforeach; ?>
</div>

<!-- CTA -->
<div style="text-align:center;padding:20px 0">
	<a href="mailto:bruno@hacktheseo.com" style="font-size:14px;color:var(--hts-geo);text-decoration:none;font-weight:600"><?php echo HTS_DS::icon( 'message-square', 14, 'var(--hts-geo)' ); ?> Besoin d'aide ? Parlez à un expert</a>
</div>

<?php endif; ?>

<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>

<script>
(function(){
'use strict';
var nonce='<?php echo esc_js($nonce); ?>',ajaxUrl='<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
function post(action,data,cb){data.action=action;data.nonce=nonce;fetch(ajaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)}).then(function(r){return r.json();}).then(cb).catch(function(){});}
var apiForm=document.getElementById('hts-api-form');if(apiForm){apiForm.addEventListener('submit',function(e){e.preventDefault();var btn=document.getElementById('hts-api-save'),key=document.getElementById('hts-api-key').value.trim();if(!key)return;btn.disabled=true;post('hts_save_and_validate_api_key',{api_key:key},function(d){btn.disabled=false;var al=document.getElementById('hts-api-alert');if(d.success){if(al)al.innerHTML='<div style="padding:10px 14px;background:var(--hts-success-bg);border:1px solid var(--hts-success);border-radius:var(--hts-radius-sm);color:#166534;font-size:13px;margin-bottom:12px">'+d.data.message+' V\u00e9rification de l\u0027abonnement\u2026</div>';post('hts_refresh_subscription',{},function(){setTimeout(function(){location.reload();},800);});}else{if(al)al.innerHTML='<div style="padding:10px 14px;background:var(--hts-danger-bg);border:1px solid var(--hts-danger);border-radius:var(--hts-radius-sm);color:#991b1b;font-size:13px;margin-bottom:12px">'+(d.data&&d.data.message?d.data.message:'Erreur')+'</div>';}});});}
<?php if ( defined( 'HTS_SHOW_API_KEYS' ) && HTS_SHOW_API_KEYS ) : ?>
var coachBtn=document.getElementById('hts-coach-key-save');if(coachBtn){coachBtn.addEventListener('click',function(){var key=document.getElementById('hts-coach-api-key').value.trim();coachBtn.disabled=true;post('hts_coach_config',{save:'1',api_key:key},function(d){coachBtn.disabled=false;var al=document.getElementById('hts-coach-key-alert');if(d.success&&al)al.innerHTML='<div style="padding:10px 14px;background:var(--hts-success-bg);border:1px solid var(--hts-success);border-radius:var(--hts-radius-sm);color:#166534;font-size:13px;margin-bottom:12px">Cl\u00e9 enregistr\u00e9e !</div>';});});}
var oaiBtn=document.getElementById('hts-openai-key-save');if(oaiBtn){oaiBtn.addEventListener('click',function(){var key=document.getElementById('hts-openai-key').value.trim();oaiBtn.disabled=true;post('hts_save_openai_key',{openai_key:key},function(d){oaiBtn.disabled=false;var al=document.getElementById('hts-openai-alert');if(d.success&&al)al.innerHTML='<div style="padding:10px 14px;background:var(--hts-success-bg);border:1px solid var(--hts-success);border-radius:var(--hts-radius-sm);color:#166534;font-size:13px;margin-bottom:12px">Cl\u00e9 enregistr\u00e9e !</div>';});});}
<?php endif; /* HTS_SHOW_API_KEYS — JS coach+oai */ ?>
document.querySelectorAll('.hts-agent-toggle').forEach(function(el){el.addEventListener('change',function(){var ag=this.dataset.agent,checked=this.checked;document.querySelectorAll('.hts-agent-toggle[data-agent="'+ag+'"]').forEach(function(other){if(other!==el)other.checked=checked;});post('hts_save_agent_config',{agent:ag,enabled:checked?1:0},function(){});});});
document.querySelectorAll('.hts-agent-mode').forEach(function(el){el.addEventListener('change',function(){var ag=this.dataset.agent,val=this.value;document.querySelectorAll('.hts-agent-mode[data-agent="'+ag+'"]').forEach(function(other){if(other!==el)other.value=val;});post('hts_save_agent_config',{agent:ag,mode:val},function(){});});});
window.htsOpenAgentModal=function(id){var b=document.getElementById('hts-agent-modal-backdrop'),m=document.getElementById('hts-agent-modal-'+id);if(!b||!m)return;document.querySelectorAll('.hts-agent-modal').forEach(function(el){el.style.display='none';});b.style.display='block';m.style.display='block';document.body.style.overflow='hidden';};
window.htsCloseAgentModal=function(){var b=document.getElementById('hts-agent-modal-backdrop');if(b)b.style.display='none';document.querySelectorAll('.hts-agent-modal').forEach(function(el){el.style.display='none';});document.body.style.overflow='';};
document.addEventListener('keydown',function(e){if(e.key==='Escape')htsCloseAgentModal();});
window.htsTestAgentKey=function(btn,action,inputId,paramName){var key=document.getElementById(inputId).value.trim(),st=document.getElementById(inputId+'-status');if(!key){if(st){st.textContent='Entrez une cl\u00e9';st.style.color='var(--hts-danger)';}return;}btn.disabled=true;if(st){st.textContent='V\u00e9rification...';st.style.color='var(--hts-geo)';}var data={action:action,nonce:nonce};data[paramName]=key;jQuery.post(ajaxUrl,data,function(r){btn.disabled=false;if(st){if(r.success){st.textContent=(r.data&&r.data.message||'OK');st.style.color='var(--hts-success)';}else{st.textContent=(r.data&&r.data.message||'Erreur');st.style.color='var(--hts-danger)';}}}).fail(function(){btn.disabled=false;if(st){st.textContent='Erreur r\u00e9seau';st.style.color='var(--hts-danger)';}});};
window.htsAgentSettingsSave=function(agent){var status=document.querySelector('.hts-agent-settings-status[data-agent="'+agent+'"]'),inputs=document.querySelectorAll('.hts-agent-setting[data-agent="'+agent+'"]'),settings={};inputs.forEach(function(inp){var key=inp.dataset.key;if(inp.type==='checkbox')settings[key]=inp.checked;else if(inp.type==='number')settings[key]=parseFloat(inp.value);else settings[key]=inp.value;});if(status){status.textContent='Enregistrement...';status.style.color='var(--hts-geo)';}post('hts_save_agent_config',{agent:agent,settings:JSON.stringify(settings)},function(d){if(status){status.textContent=d.success?'Enregistr\u00e9 !':'Erreur';status.style.color=d.success?'var(--hts-success)':'var(--hts-danger)';setTimeout(function(){status.textContent='';},3000);}});};
(function(){var r=document.getElementById('hts-meta-recommend-max_meta_per_week');if(!r)return;var iid=r.dataset.input;post('hts_meta_auto_recommend',{},function(d){if(!d.success||!d.data)return;var rec=d.data;r.innerHTML='<span style="cursor:pointer">'+rec.label+' <span style="text-decoration:underline;font-weight:600">Appliquer</span></span>';r.addEventListener('click',function(){var inp=document.getElementById(iid);if(inp){inp.value=rec.recommended;r.innerHTML='<span style="color:var(--hts-success)">Valeur appliqu\u00e9e</span>';}});});})();
function _htsDryRunCore(exec){var s=document.getElementById('hts-dry-run-status'),r=document.getElementById('hts-dry-run-results'),b1=document.getElementById('hts-dry-run-btn'),b2=document.getElementById('hts-dry-run-exec-btn');s.textContent=exec?'Ex\u00e9cution...':'Analyse (15-30s)...';s.style.color='var(--hts-geo)';r.style.display='none';b1.disabled=b2.disabled=true;post('hts_auto_dry_run',{agent:'meta',execute:exec},function(d){b1.disabled=b2.disabled=false;if(!d.success||!d.data){s.textContent='Erreur';s.style.color='var(--hts-danger)';return;}var st=d.data.stats;s.innerHTML=st.total_checked+' pages — <strong style="color:var(--hts-success)">'+st.eligible+' pr\u00eates</strong>, <span style="color:var(--hts-caution)">'+st.blocked+' bloqu\u00e9es</span>';s.style.color='var(--hts-text)';if(!d.data.results||!d.data.results.length){r.innerHTML='<p style="padding:16px;background:var(--hts-success-bg);border-radius:var(--hts-radius-sm);text-align:center;color:var(--hts-success)">Site bien optimis\u00e9 !</p>';r.style.display='block';return;}var h='';d.data.results.forEach(function(x){h+='<div class="hts-ds-card" style="padding:16px;margin-bottom:12px"><div style="font-weight:700;font-size:14px"><a href="'+x.post_url+'" target="_blank" style="color:var(--hts-geo);text-decoration:none">'+x.post_title+'</a></div>';if(x.variant_title)h+='<div style="margin-top:8px;padding:10px;background:var(--hts-surface);border-radius:var(--hts-radius-xs);font-size:12px"><strong>Title :</strong> '+x.variant_title+'</div>';h+='</div>';});r.innerHTML=h;r.style.display='block';});}
window.htsDryRun=function(exec){if(exec){_htsConfirm('Modifier les metas ?','Une seule page sera modifi\u00e9e avec la meilleure suggestion.','Modifier').then(function(ok){if(ok)_htsDryRunCore(true)});return;}_htsDryRunCore(false)};
(function(){var c=document.getElementById('hts-gf-agents-table');if(!c)return;var _r=null;post('hts_load_guardrails_recommendations',{},function(d){if(!d.success||!d.data){c.textContent='Erreur de chargement';return;}_r=d.data;rt(d.data);});
var ceoLabels={'max_per_week':'Actions / semaine','cooldown_days':'Pause entre 2 modifs (jours)','min_quality_score':'Score min.','images_month_limit':'Images / mois'};
function rt(data){var recs=data.recommendations,schema=data.schema,saved=data.saved||{};
/* Collect all unique field keys across agents */
var allKeys=[],keySet={};Object.keys(schema).forEach(function(ag){var fs=schema[ag].fields||[];fs.forEach(function(f){if(!keySet[f.key]){keySet[f.key]=true;allKeys.push(f.key);}});});
var h='<table class="hts-ds-table"><thead><tr><th style="text-align:left">Agent</th>';
allKeys.forEach(function(k){h+='<th style="text-align:center">'+(ceoLabels[k]||k)+'</th>';});
if(Object.keys(recs).length>1)h+='<th style="text-align:center">Recommandé</th>';
h+='</tr></thead><tbody>';
Object.keys(schema).forEach(function(ag){var as=schema[ag],sv=saved[ag]||{},fields=as.fields||[];
var fieldMap={};fields.forEach(function(f){fieldMap[f.key]=f;});
h+='<tr><td style="font-weight:500">'+(as.label||ag)+'</td>';
allKeys.forEach(function(k){var f=fieldMap[k];if(f){var v=sv[k]!==undefined?sv[k]:f.default;h+='<td style="text-align:center"><input type="number" class="hts-ds-input hts-ds-input--sm hts-gf-agent-input" data-agent="'+ag+'" data-key="'+k+'" value="'+v+'" min="'+(f.min||0)+'" max="'+(f.max||999)+'" style="width:70px;text-align:center"></td>';}else{h+='<td style="text-align:center;color:var(--hts-text-3)">\u2014</td>';}});
if(recs[ag])h+='<td style="text-align:center;font-size:11px;color:var(--hts-geo);font-weight:500">'+recs[ag].max_per_week+'/sem</td>';
else if(Object.keys(recs).length>1)h+='<td></td>';
h+='</tr>';});h+='</tbody></table>';c.innerHTML=h;}
var ab=document.getElementById('hts-gf-agents-apply-reco');if(ab)ab.addEventListener('click',function(){if(!_r)return;c.querySelectorAll('.hts-gf-agent-input').forEach(function(i){if(i.dataset.key==='max_per_week'&&_r.recommendations[i.dataset.agent])i.value=_r.recommendations[i.dataset.agent].max_per_week;});});
var sb=document.getElementById('hts-gf-agents-save');if(sb)sb.addEventListener('click',function(){var st=document.getElementById('hts-gf-agents-status');if(st){st.textContent='Enregistrement...';st.style.color='var(--hts-geo)';}var g={};c.querySelectorAll('.hts-gf-agent-input').forEach(function(i){if(!g[i.dataset.agent])g[i.dataset.agent]={};g[i.dataset.agent][i.dataset.key]=parseFloat(i.value)||0;});post('hts_save_agent_guardrails',{guardrails:JSON.stringify(g)},function(d){if(st){st.textContent=d.success?'Enregistr\u00e9 !':'Erreur';st.style.color=d.success?'var(--hts-success)':'var(--hts-danger)';setTimeout(function(){st.textContent='';},3000);}});});})();
var gfBtn=document.getElementById('hts-gf-save');if(gfBtn){gfBtn.addEventListener('click',function(){var st=document.getElementById('hts-gf-status');if(st){st.textContent='Enregistrement...';st.style.color='var(--hts-geo)';}post('hts_save_guardrails',{max_budget:(document.getElementById('hts-gf-budget')||{value:'30'}).value,traffic_thr:document.getElementById('hts-gf-traffic').value,coach_budget:(document.getElementById('hts-gf-coach-budget')||{value:'2000000'}).value,auto_hours_start:(document.getElementById('hts-gf-auto-hours-start')||{}).value||'0',auto_hours_end:(document.getElementById('hts-gf-auto-hours-end')||{}).value||'23',blacklist_pages:(document.getElementById('hts-gf-blacklist')||{}).value||''},function(d){if(st){st.textContent=d.success?'Enregistr\u00e9 !':'Erreur';st.style.color=d.success?'var(--hts-success)':'var(--hts-danger)';setTimeout(function(){st.textContent='';},3000);}});});}

var clr=document.getElementById('hts-clear-history');if(clr){clr.addEventListener('click',function(){_htsConfirm('Vider l\u0027historique ?','L\u0027historique des push sera supprim\u00e9.','Vider','danger').then(function(ok){if(!ok)return;post('hts_clear_push_history',{},function(d){if(d.success)location.reload();});});});}
window.htsSaveNotifSettings=function(){var m=document.getElementById('hts-notif-save-msg');m.textContent='Enregistrement\u2026';var en=document.getElementById('hts-notif-enabled-toggle').checked?'1':'0',em=document.getElementById('hts-notif-email-input').value,fr=document.querySelector('input[name=hts_notif_freq_u]:checked');fr=fr?fr.value:'weekly';var sc={};document.querySelectorAll('.hts-notif-section-cb').forEach(function(cb){sc[cb.dataset.section]=cb.checked?'1':'0';});var b='action=hts_save_notif_settings&nonce='+encodeURIComponent(nonce)+'&enabled='+en+'&email='+encodeURIComponent(em)+'&frequency='+fr;Object.keys(sc).forEach(function(k){b+='&section_'+k+'='+sc[k];});fetch(ajaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:b}).then(function(r){return r.json();}).then(function(r){m.innerHTML=r.success?'<span style="color:var(--hts-success)">Enregistr\u00e9</span>':'<span style="color:var(--hts-danger)">Erreur</span>';}).catch(function(){m.innerHTML='<span style="color:var(--hts-danger)">Erreur r\u00e9seau</span>';});};
window.htsTestDigestUnified=function(){var m=document.getElementById('hts-notif-save-msg'),em=document.getElementById('hts-notif-email-input').value;m.textContent='Envoi\u2026';fetch(ajaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=hts_send_test_digest&nonce='+encodeURIComponent(nonce)+'&email='+encodeURIComponent(em)}).then(function(r){return r.json();}).then(function(r){m.innerHTML=r.success?'<span style="color:var(--hts-success)">Envoy\u00e9</span>':'<span style="color:var(--hts-danger)">Erreur</span>';});};
window.htsPreviewDigestUnified=function(){document.getElementById('hts-notif-preview-u').style.display='block';fetch(ajaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=hts_preview_digest&nonce='+encodeURIComponent(nonce)}).then(function(r){return r.json();}).then(function(r){if(r.success){var f=document.getElementById('hts-notif-preview-u-iframe');f.contentDocument.open();f.contentDocument.write(r.data.html);f.contentDocument.close();}});};
window.htsAgentExport=function(){var st=document.getElementById('hts-agent-transfer-status');st.textContent='Chargement...';post('hts_export_agent_settings',{},function(d){if(d.success){var b=new Blob([JSON.stringify(d.data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='hack-the-seo-agents-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);st.innerHTML='<span style="color:var(--hts-success)">Export\u00e9</span>';}else st.innerHTML='<span style="color:var(--hts-danger)">Erreur</span>';});};
window.htsAgentImport=function(input){var file=input.files[0];if(!file)return;var st=document.getElementById('hts-agent-transfer-status');st.textContent='Lecture...';var reader=new FileReader();reader.onload=function(e){try{var p=JSON.parse(e.target.result);if(!p._hts_agent_export){st.innerHTML='<span style="color:var(--hts-danger)">Fichier invalide</span>';input.value='';return;}}catch(err){st.innerHTML='<span style="color:var(--hts-danger)">JSON invalide</span>';input.value='';return;}st.textContent='Import...';post('hts_import_agent_settings',{payload:JSON.stringify(p)},function(d){if(d.success){st.innerHTML='<span style="color:var(--hts-success)">'+(d.data.imported||0)+' agent(s) import\u00e9(s)</span>';setTimeout(function(){location.reload();},1200);}else st.innerHTML='<span style="color:var(--hts-danger)">Erreur</span>';});input.value='';};reader.readAsText(file);};
window.htsLoadAgentHistory=function(){var l=document.getElementById('hts-agent-history-list');l.innerHTML='<div style="padding:8px;color:var(--hts-text-3)">Chargement\u2026</div>';post('hts_agent_settings_history',{},function(r){if(!r.success||!r.data.history.length){l.innerHTML='<div style="padding:8px;color:var(--hts-text-3)">Aucune modification.</div>';return;}var h='';r.data.history.forEach(function(e){var d=new Date(e.date),ds=d.toLocaleDateString('fr-FR')+' '+d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});h+='<div style="display:flex;gap:12px;padding:10px 14px;border-bottom:1px solid var(--hts-border-sub);margin-bottom:4px"><div style="flex-shrink:0;width:120px;font-size:11px;color:var(--hts-text-3)">'+ds+'</div><div style="flex-shrink:0;width:70px;font-size:11px;font-weight:600;color:var(--hts-geo)">'+(e.agent||'?')+'</div><div style="flex:1;font-size:11.5px;color:var(--hts-text)">'+(e.changes||[]).join('<br>')+'</div><div style="flex-shrink:0;font-size:10px;color:var(--hts-text-3)">'+(e.user||'')+'</div></div>';});l.innerHTML=h;});};
window.htsTestImageGen=function(){var z=document.getElementById('hts-test-image-zone');if(z)z.style.display=z.style.display==='none'?'block':'none';};
window.htsTestImageGo=function(){var st=document.getElementById('hts-test-image-status'),res=document.getElementById('hts-test-image-result'),prompt=(document.getElementById('hts-test-image-prompt')||{}).value||'',go=document.getElementById('hts-test-image-go');if(go)go.disabled=true;if(st){st.innerHTML='G\u00e9n\u00e9ration\u2026 <span style="font-size:10px;color:var(--hts-text-3)">(30-120s)</span>';st.style.color='var(--hts-accent)';}if(res)res.innerHTML='';post('hts_test_image_generate',{prompt:prompt},function(d){if(go)go.disabled=false;if(!d.success){if(st){st.textContent=(d.data&&d.data.message||'Erreur');st.style.color='var(--hts-danger)';}return;}var data=d.data||{};if(st){st.innerHTML='Image en '+( data.elapsed||'?')+'s — <strong>'+(data.provider||'?')+'</strong>'+(data.cost?' — ~$'+data.cost:'');st.style.color='var(--hts-success)';}if(res&&data.url)res.innerHTML='<div style="margin-top:6px"><img src="'+data.url+'" style="max-width:400px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border)"/></div>';});};
})();
</script>
<style>
.hts-onb-toggle{position:relative;width:40px;height:22px;flex-shrink:0;display:inline-block}
.hts-onb-toggle input{opacity:0;width:0;height:0;position:absolute;pointer-events:none}
.hts-onb-toggle .sl{position:absolute;inset:0;background:var(--hts-gray-200);border-radius:11px;cursor:pointer;transition:background var(--hts-dur-normal) var(--hts-ease-in-out)}
.hts-onb-toggle .sl::after{content:'';position:absolute;width:18px;height:18px;background:#fff;border-radius:50%;top:2px;left:2px;box-shadow:0 1px 3px rgba(0,0,0,.15);transition:transform var(--hts-dur-normal) var(--hts-ease-spring)}
.hts-onb-toggle input:checked+.sl{background:var(--hts-success)}
.hts-onb-toggle input:checked+.sl::after{transform:translateX(18px)}
/* ── Agent cards v7 ── */
.hts-agent-card{background:var(--hts-bg);border-radius:20px;padding:24px 22px 20px;border:1px solid var(--hts-border);box-shadow:0 1px 3px rgba(0,0,0,.06),0 4px 16px rgba(0,0,0,.04);transition:transform .15s ease,box-shadow .15s ease}
.hts-agent-card:hover{transform:translateY(-3px);box-shadow:0 2px 12px rgba(0,0,0,.06),0 0 1px rgba(0,0,0,.08)}
.hts-agent-card--lg{padding:28px 26px 24px}
.hts-agent-icon{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.hts-agent-icon--lg{width:64px;height:64px}
.hts-pulse-dot{width:6px;height:6px;border-radius:50%;background:var(--hts-success);animation:htsPulse 2s infinite}
/* ── Modal animations ── */
@keyframes htsFadeIn{from{opacity:0}to{opacity:1}}
@keyframes htsScaleIn{from{opacity:0;transform:translate(-50%,-50%) scale(.95)}to{opacity:1;transform:translate(-50%,-50%) scale(1)}}
.hts-agent-modal{max-width:calc(100vw - 32px)}
</style>
