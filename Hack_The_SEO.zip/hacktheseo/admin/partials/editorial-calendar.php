<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Calendrier Éditorial — Admin Partial (Phase 6b)
 *
 * Vue semaines avec drag & drop pour planifier les articles cocon.
 * Affiche les articles reçus du Commander, triés par priorité.
 *
 * @package Hack_The_SEO
 * @since   1.25.0
 */

if ( ! defined( 'WPINC' ) ) die;

$commander = new HTS_Cocon_Commander();
$plans     = $commander->get_plans();

// Collect all schedulable articles
$all_articles = array();
foreach ( $plans as $cocon_id => $plan ) {
    foreach ( $plan['articles'] as $key => $art ) {
        if ( ! in_array( $art['status'], array( 'received', 'ready', 'scheduled' ), true ) ) continue;
        $post_id = $art['post_id'] ?? null;
        $post    = $post_id ? get_post( $post_id ) : null;

        $all_articles[] = array(
            'key'          => $key,
            'cocon_id'     => $cocon_id,
            'pillar'       => $plan['pillar_title'],
            'keyword'      => $art['keyword'],
            'priority'     => $art['publish_priority'] ?? 50,
            'intent'       => $art['intent'] ?? 'info',
            'status'       => $art['status'],
            'post_id'      => $post_id,
            'post_status'  => $post ? $post->post_status : 'draft',
            'post_date'    => $post ? $post->post_date : null,
        );
    }
}

// Sort by priority desc
usort( $all_articles, function( $a, $b ) {
    return $b['priority'] - $a['priority'];
} );

// Calculate week range (current week + 4 weeks ahead)
$today      = current_time( 'Y-m-d' );
$week_start = date( 'Y-m-d', strtotime( 'monday this week', strtotime( $today ) ) );
$weeks      = array();
for ( $w = 0; $w < 5; $w++ ) {
    $ws = date( 'Y-m-d', strtotime( "+{$w} weeks", strtotime( $week_start ) ) );
    $we = date( 'Y-m-d', strtotime( '+6 days', strtotime( $ws ) ) );
    $weeks[] = array( 'start' => $ws, 'end' => $we );
}

// Get cocon list for filters
$cocon_list = array();
foreach ( $plans as $cid => $p ) {
    $cocon_list[ $cid ] = $p['pillar_title'] ?: $cid;
}
?>

<style>
/* ── Editorial Calendar UI ── */
.hts-cal { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }

/* Filters bar */
.hts-cal-filters { display:flex; gap:12px; align-items:center; margin-bottom:20px; flex-wrap:wrap; }
.hts-cal-filter { font-size:12px; padding:6px 12px; border:1px solid #e5e7eb; border-radius:8px; background:#fff; cursor:pointer; font-weight:500; }
.hts-cal-filter.active { background:#6366f1; color:#fff; border-color:#6366f1; }
.hts-cal-filter select { font-size:12px; border:none; background:transparent; cursor:pointer; outline:none; }
.hts-cal-nav { display:flex; gap:8px; margin-left:auto; }
.hts-cal-nav button { font-size:12px; padding:6px 12px; border:1px solid #e5e7eb; border-radius:8px; background:#fff; cursor:pointer; font-weight:600; }
.hts-cal-nav button:hover { border-color:#6366f1; color:#6366f1; }

/* Week grid */
.hts-cal-grid { display:grid; grid-template-columns:repeat(7, 1fr); gap:1px; background:#e5e7eb; border:1px solid #e5e7eb; border-radius:10px; overflow:hidden; }
.hts-cal-header { background:#f8fafc; padding:10px 8px; text-align:center; font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:.5px; }
.hts-cal-day { background:#fff; min-height:120px; padding:8px; position:relative; }
.hts-cal-day.today { background:#f0fdf4; }
.hts-cal-day.past { background:#fafafa; opacity:0.7; }
.hts-cal-day-number { font-size:12px; font-weight:700; color:#1a1f36; margin-bottom:8px; }
.hts-cal-day.today .hts-cal-day-number { color:#16a34a; }

/* Article cards in calendar */
.hts-cal-article { font-size:10px; padding:4px 8px; border-radius:6px; margin-bottom:4px; cursor:grab; border-left:3px solid; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; transition:box-shadow .15s; }
.hts-cal-article:active { cursor:grabbing; }
.hts-cal-article:hover { box-shadow:0 2px 8px rgba(0,0,0,.1); }
.hts-cal-article[draggable="true"] { cursor:grab; }
.hts-cal-article.priority-high { background:#eff6ff; border-color:#3b82f6; color:#1e40af; }
.hts-cal-article.priority-medium { background:#fefce8; border-color:#eab308; color:#854d0e; }
.hts-cal-article.priority-low { background:#f3f4f6; border-color:#9ca3af; color:#4b5563; }
.hts-cal-article.published { background:#d1fae5; border-color:#10b981; color:#065f46; }
.hts-cal-article.future { background:#dbeafe; border-color:#6366f1; color:#312e81; }

/* Drop zone highlight */
.hts-cal-day.drag-over { background:#eef2ff; outline:2px dashed #6366f1; outline-offset:-2px; }

/* Unscheduled sidebar */
.hts-cal-layout { display:grid; grid-template-columns:1fr 260px; gap:20px; }
.hts-cal-sidebar { background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:16px; max-height:600px; overflow-y:auto; }
.hts-cal-sidebar-title { font-size:13px; font-weight:700; color:#1a1f36; margin-bottom:12px; display:flex; align-items:center; gap:6px; }
.hts-cal-sidebar-count { font-size:10px; background:#6366f1; color:#fff; padding:2px 8px; border-radius:10px; }
.hts-cal-unscheduled { font-size:11px; padding:8px 10px; background:#f8fafc; border:1px solid #e5e7eb; border-radius:8px; margin-bottom:6px; cursor:grab; border-left:3px solid #6366f1; transition:all .15s; }
.hts-cal-unscheduled:hover { border-color:#4f46e5; background:#eef2ff; }
.hts-cal-unscheduled .kw { font-weight:600; color:#1a1f36; }
.hts-cal-unscheduled .meta { color:#94a3b8; font-size:10px; margin-top:2px; }

/* Empty state */
.hts-cal-empty { text-align:center; padding:40px; color:#64748b; }
.hts-cal-empty .icon { font-size:48px; margin-bottom:12px; }
.hts-cal-empty .title { font-size:15px; font-weight:600; color:#1a1f36; margin-bottom:6px; }
.hts-cal-empty .desc { font-size:12px; max-width:380px; margin:0 auto; line-height:1.5; }

/* Week navigation header */
.hts-cal-week-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
.hts-cal-week-range { font-size:15px; font-weight:700; color:#1a1f36; }
.hts-cal-week-sub { font-size:12px; color:#64748b; font-weight:400; }

/* Modal for scheduling */
.hts-cal-modal-bg { display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,.4); z-index:100000; justify-content:center; align-items:center; }
.hts-cal-modal-bg.active { display:flex; }
.hts-cal-modal { background:#fff; border-radius:12px; padding:24px; width:380px; max-width:90vw; box-shadow:0 20px 60px rgba(0,0,0,.2); }
.hts-cal-modal h3 { font-size:16px; font-weight:700; margin:0 0 16px; color:#1a1f36; }
.hts-cal-modal label { font-size:12px; font-weight:600; color:#374151; display:block; margin-bottom:4px; }
.hts-cal-modal input[type="date"],
.hts-cal-modal input[type="time"] { width:100%; padding:8px 12px; border:1px solid #d1d5db; border-radius:8px; font-size:13px; margin-bottom:12px; }
.hts-cal-modal-actions { display:flex; gap:8px; justify-content:flex-end; margin-top:16px; }
.hts-cal-modal-actions button { font-size:12px; padding:8px 16px; border-radius:8px; font-weight:600; cursor:pointer; border:1px solid #e5e7eb; background:#fff; }
.hts-cal-modal-actions .primary { background:#6366f1; color:#fff; border-color:#6366f1; }
.hts-cal-modal-actions .primary:hover { background:#4f46e5; }
</style>

<div class="hts-cal">

<?php if ( empty( $all_articles ) ) : ?>
    <div class="hts-cal-empty">
        <div class="icon">📅</div>
        <div class="title">Aucun article à planifier</div>
        <div class="desc">
            Les articles apparaissent ici une fois reçus depuis le Cocon Commander.
            Commandez des articles dans vos plans cocon, ils arriveront automatiquement dans ce calendrier.
        </div>
    </div>
<?php else : ?>

    <!-- Filters -->
    <div class="hts-cal-filters">
        <div class="hts-cal-filter active" data-filter="all">Tous</div>
        <div class="hts-cal-filter" data-filter="unscheduled">À planifier</div>
        <div class="hts-cal-filter" data-filter="scheduled">Planifiés</div>
        <div class="hts-cal-filter" data-filter="published">Publiés</div>

        <?php if ( count( $cocon_list ) > 1 ) : ?>
        <div class="hts-cal-filter" id="hts-cal-filter-cocon">
            <select id="hts-cal-cocon-select">
                <option value="">Tous les cocons</option>
                <?php foreach ( $cocon_list as $cid => $title ) : ?>
                    <option value="<?php echo esc_attr( $cid ); ?>"><?php echo esc_html( $title ); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>

        <div class="hts-cal-nav">
            <button id="hts-cal-prev">← Semaine préc.</button>
            <button id="hts-cal-today">Aujourd\'hui</button>
            <button id="hts-cal-next">Semaine suiv. →</button>
        </div>
    </div>

    <!-- Calendar layout -->
    <div class="hts-cal-layout">
        <!-- Main grid -->
        <div>
            <div class="hts-cal-week-header">
                <div>
                    <div class="hts-cal-week-range" id="hts-cal-range"></div>
                    <div class="hts-cal-week-sub" id="hts-cal-sub"></div>
                </div>
            </div>

            <div class="hts-cal-grid" id="hts-cal-grid">
                <!-- Days of week headers -->
                <div class="hts-cal-header">Lun</div>
                <div class="hts-cal-header">Mar</div>
                <div class="hts-cal-header">Mer</div>
                <div class="hts-cal-header">Jeu</div>
                <div class="hts-cal-header">Ven</div>
                <div class="hts-cal-header">Sam</div>
                <div class="hts-cal-header">Dim</div>
                <!-- Day cells rendered by JS -->
            </div>
        </div>

        <!-- Sidebar: unscheduled articles -->
        <div class="hts-cal-sidebar" id="hts-cal-sidebar">
            <div class="hts-cal-sidebar-title">
                📋 À planifier
                <span class="hts-cal-sidebar-count" id="hts-cal-unscheduled-count">0</span>
            </div>
            <div id="hts-cal-unscheduled-list"></div>
        </div>
    </div>

    <!-- Schedule modal -->
    <div class="hts-cal-modal-bg" id="hts-cal-modal">
        <div class="hts-cal-modal">
            <h3>📅 Planifier la publication</h3>
            <input type="hidden" id="hts-cal-modal-post-id">
            <label>Date</label>
            <input type="date" id="hts-cal-modal-date">
            <label>Heure</label>
            <input type="time" id="hts-cal-modal-time" value="09:00">
            <div id="hts-cal-modal-info" style="font-size:12px;color:#64748b;margin-top:4px;"></div>
            <div class="hts-cal-modal-actions">
                <button onclick="htsCalCloseModal()">Annuler</button>
                <button class="primary" onclick="htsCalConfirmSchedule()">Planifier</button>
            </div>
        </div>
    </div>

<?php endif; ?>

</div>

<?php if ( ! empty( $all_articles ) ) : ?>
<script>
(function(){
    'use strict';

    /* ── Data ── */
    var articles = <?php echo wp_json_encode( $all_articles ); ?>;
    var ajaxUrl  = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
    var nonce    = '<?php echo esc_js( wp_create_nonce( "hts_admin_nonce" ) ); ?>';
    var today    = '<?php echo esc_js( $today ); ?>';

    var currentWeekOffset = 0;
    var activeFilter      = 'all';
    var activeCocon       = '';

    /* ── Utilities ── */
    function dateStr(d) { return d.toISOString().split('T')[0]; }
    function addDays(d, n) { var r = new Date(d); r.setDate(r.getDate() + n); return r; }
    function getMonday(d) {
        var copy = new Date(d.getTime()); // EC1: Clone pour ne pas muter l'original
        var day = copy.getDay(); var diff = copy.getDate() - day + (day === 0 ? -6 : 1);
        copy.setDate(diff); return copy;
    }
    function formatDateFr(d) {
        var months = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
        return d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
    }
    function priorityClass(p) {
        if (p >= 70) return 'priority-high';
        if (p >= 40) return 'priority-medium';
        return 'priority-low';
    }

    /* ── Filter logic ── */
    function filterArticles() {
        return articles.filter(function(a) {
            if (activeCocon && a.cocon_id !== activeCocon) return false;
            if (activeFilter === 'unscheduled') return a.post_status === 'draft';
            if (activeFilter === 'scheduled') return a.post_status === 'future';
            if (activeFilter === 'published') return a.post_status === 'publish';
            return true;
        });
    }

    /* ── Render calendar ── */
    function render() {
        var monday = getMonday(new Date(today));
        monday = addDays(monday, currentWeekOffset * 7);
        var sunday = addDays(new Date(monday), 6);

        // Header
        document.getElementById('hts-cal-range').textContent =
            formatDateFr(monday) + ' — ' + formatDateFr(sunday);
        document.getElementById('hts-cal-sub').textContent =
            'Semaine ' + getWeekNumber(monday);

        var grid = document.getElementById('hts-cal-grid');
        // Remove old day cells (keep headers)
        var old = grid.querySelectorAll('.hts-cal-day');
        old.forEach(function(el) { el.remove(); });

        var filtered = filterArticles();
        var unscheduled = [];

        // Render 7 day cells
        for (var d = 0; d < 7; d++) {
            var day = addDays(new Date(monday), d);
            var dayS = dateStr(day);

            var cell = document.createElement('div');
            cell.className = 'hts-cal-day';
            cell.dataset.date = dayS;
            if (dayS === today) cell.classList.add('today');
            if (dayS < today) cell.classList.add('past');

            var num = document.createElement('div');
            num.className = 'hts-cal-day-number';
            num.textContent = day.getDate();
            cell.appendChild(num);

            // Add articles scheduled for this day
            filtered.forEach(function(art) {
                if (!art.post_date) return;
                var artDate = art.post_date.split(' ')[0];
                if (artDate !== dayS) return;

                var el = createArticleCard(art);
                cell.appendChild(el);
            });

            // Drag & drop zones
            cell.addEventListener('dragover', function(e) { e.preventDefault(); this.classList.add('drag-over'); });
            cell.addEventListener('dragleave', function() { this.classList.remove('drag-over'); });
            cell.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('drag-over');
                var postId = e.dataTransfer.getData('text/plain');
                if (postId) scheduleArticle(parseInt(postId), this.dataset.date);
            });

            grid.appendChild(cell);
        }

        // Sidebar: unscheduled articles
        filtered.forEach(function(art) {
            if (art.post_status === 'draft' && art.post_id) {
                unscheduled.push(art);
            }
        });

        var sidebar = document.getElementById('hts-cal-unscheduled-list');
        sidebar.innerHTML = '';
        document.getElementById('hts-cal-unscheduled-count').textContent = unscheduled.length;

        unscheduled.forEach(function(art) {
            var el = document.createElement('div');
            el.className = 'hts-cal-unscheduled';
            el.draggable = true;
            el.innerHTML = '<div class="kw">' + escHtml(art.keyword) + '</div>' +
                '<div class="meta">' + escHtml(art.pillar) + ' · Priorité ' + art.priority + '</div>';

            el.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', art.post_id);
                e.dataTransfer.effectAllowed = 'move';
            });

            el.addEventListener('click', function() {
                openScheduleModal(art.post_id, art.keyword);
            });

            sidebar.appendChild(el);
        });
    }

    function createArticleCard(art) {
        var el = document.createElement('div');
        el.className = 'hts-cal-article';
        el.draggable = true;
        el.title = art.keyword + ' (priorité ' + art.priority + ')';

        if (art.post_status === 'publish') {
            el.classList.add('published');
        } else if (art.post_status === 'future') {
            el.classList.add('future');
        } else {
            el.classList.add(priorityClass(art.priority));
        }

        el.textContent = art.keyword;

        el.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', art.post_id);
        });

        el.addEventListener('click', function() {
            if (art.post_id) openScheduleModal(art.post_id, art.keyword);
        });

        return el;
    }

    function getWeekNumber(d) {
        var onejan = new Date(d.getFullYear(), 0, 1);
        return Math.ceil(((d - onejan) / 86400000 + onejan.getDay() + 1) / 7);
    }

    function escHtml(s) {
        var d = document.createElement('div'); d.textContent = s; return d.innerHTML;
    }

    /* ── Schedule article ── */
    function scheduleArticle(postId, date) {
        var data = new FormData();
        data.append('action', 'hts_calendar_schedule');
        data.append('nonce', nonce);
        data.append('post_id', postId);
        data.append('date', date);
        data.append('time', '09:00:00');

        fetch(ajaxUrl, { method: 'POST', body: data })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res.success) {
                    // Update local data
                    articles.forEach(function(a) {
                        if (a.post_id == postId) {
                            a.post_date = res.data.date;
                            a.post_status = res.data.status;
                        }
                    });
                    render();
                } else {
                    alert('Erreur : ' + (res.data || 'Planification échouée'));
                }
            });
    }

    /* ── Modal ── */
    window.openScheduleModal = function(postId, keyword) {
        document.getElementById('hts-cal-modal-post-id').value = postId;
        document.getElementById('hts-cal-modal-info').textContent = keyword;
        document.getElementById('hts-cal-modal-date').value = today;
        document.getElementById('hts-cal-modal').classList.add('active');
    };

    window.htsCalCloseModal = function() {
        document.getElementById('hts-cal-modal').classList.remove('active');
    };

    window.htsCalConfirmSchedule = function() {
        var postId = document.getElementById('hts-cal-modal-post-id').value;
        var date   = document.getElementById('hts-cal-modal-date').value;
        var time   = document.getElementById('hts-cal-modal-time').value || '09:00';
        if (!postId || !date) return;

        scheduleArticle(parseInt(postId), date + ' ' + time + ':00');
        htsCalCloseModal();
    };

    /* ── Filter handlers ── */
    document.querySelectorAll('.hts-cal-filter[data-filter]').forEach(function(el) {
        el.addEventListener('click', function() {
            document.querySelectorAll('.hts-cal-filter[data-filter]').forEach(function(f) { f.classList.remove('active'); });
            this.classList.add('active');
            activeFilter = this.dataset.filter;
            render();
        });
    });

    var coconSelect = document.getElementById('hts-cal-cocon-select');
    if (coconSelect) {
        coconSelect.addEventListener('change', function() {
            activeCocon = this.value;
            render();
        });
    }

    /* ── Navigation ── */
    document.getElementById('hts-cal-prev').addEventListener('click', function() { currentWeekOffset--; render(); });
    document.getElementById('hts-cal-next').addEventListener('click', function() { currentWeekOffset++; render(); });
    document.getElementById('hts-cal-today').addEventListener('click', function() { currentWeekOffset = 0; render(); });

    /* ── Init ── */
    render();

})();
</script>
<?php endif; ?>
