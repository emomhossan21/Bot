<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Migration Wizard — Progressive Import & Takeover
 *
 * Phase 1: Rank Math import (robots, canonical, redirections, focus kw, pillar)
 * Phase 2: Yoast, AIOSEO, SEOPress (future)
 *
 * Strategy:
 *   - Meta titles/descriptions: READ directly from competitor meta (no copy)
 *   - Robots, canonical, focus kw, pillar: COPY to HTS meta keys
 *   - Redirections: INSERT into hts_redirects table
 *   - Variables (%title%, %sitename%): resolved at read-time
 *   - Competitor data is NEVER modified or deleted
 *
 * @since 3.3.0
 */

class HTS_Migration_Wizard {

    const OPTION_STATE    = 'hts_migration_state';
    const OPTION_BACKUP   = 'hts_migration_backup';
    const OPTION_REPORT   = 'hts_migration_report';
    const BATCH_SIZE      = 100;
    const NONCE           = 'hts_migration_nonce';

    /* ═══════════════════════════════════════════════════
     *  META KEY MAPPING — Competitor → HTS
     * ═══════════════════════════════════════════════════ */

    private static $meta_map = array(
        'rank_math' => array(
            'robots'      => array( 'source' => 'rank_math_robots',           'target' => '_hts_robots_meta',       'type' => 'robots' ),
            'canonical'   => array( 'source' => 'rank_math_canonical_url',    'target' => '_hts_canonical_url',     'type' => 'string' ),
            'focus_kw'    => array( 'source' => 'rank_math_focus_keyword',    'target' => '_hts_focus_keyword',     'type' => 'string' ),
            'pillar'      => array( 'source' => 'rank_math_pillar_content',   'target' => '_hts_pillar',            'type' => 'bool' ),
            'meta_title'  => array( 'source' => 'rank_math_title',            'target' => '_hts_meta_title',        'type' => 'string' ),
            'meta_desc'   => array( 'source' => 'rank_math_description',      'target' => '_hts_meta_description',  'type' => 'string' ),
            'og_title'    => array( 'source' => 'rank_math_facebook_title',   'target' => '_hts_og_title',          'type' => 'string' ),
            'og_desc'     => array( 'source' => 'rank_math_facebook_description', 'target' => '_hts_og_description','type' => 'string' ),
            'og_image'    => array( 'source' => 'rank_math_facebook_image',   'target' => '_hts_og_image',          'type' => 'string' ),
            'tw_title'    => array( 'source' => 'rank_math_twitter_title',    'target' => '_hts_twitter_title',     'type' => 'string' ),
            'tw_desc'     => array( 'source' => 'rank_math_twitter_description','target' => '_hts_twitter_description','type' => 'string' ),
        ),
        'yoast' => array(
            'robots_noindex'  => array( 'source' => '_yoast_wpseo_meta-robots-noindex',  'target' => '_hts_robots_meta',       'type' => 'yoast_robots' ),
            'robots_nofollow' => array( 'source' => '_yoast_wpseo_meta-robots-nofollow', 'target' => '_hts_robots_meta',       'type' => 'yoast_robots' ),
            'canonical'       => array( 'source' => '_yoast_wpseo_canonical',            'target' => '_hts_canonical_url',     'type' => 'string' ),
            'focus_kw'        => array( 'source' => '_yoast_wpseo_focuskw',              'target' => '_hts_focus_keyword',     'type' => 'string' ),
            'pillar'          => array( 'source' => '_yoast_wpseo_is_cornerstone',       'target' => '_hts_pillar',            'type' => 'bool' ),
            'meta_title'      => array( 'source' => '_yoast_wpseo_title',                'target' => '_hts_meta_title',        'type' => 'string' ),
            'meta_desc'       => array( 'source' => '_yoast_wpseo_metadesc',             'target' => '_hts_meta_description',  'type' => 'string' ),
            'og_title'        => array( 'source' => '_yoast_wpseo_opengraph-title',      'target' => '_hts_og_title',          'type' => 'string' ),
            'og_desc'         => array( 'source' => '_yoast_wpseo_opengraph-description','target' => '_hts_og_description',    'type' => 'string' ),
            'og_image'        => array( 'source' => '_yoast_wpseo_opengraph-image',      'target' => '_hts_og_image',          'type' => 'string' ),
            'tw_title'        => array( 'source' => '_yoast_wpseo_twitter-title',        'target' => '_hts_twitter_title',     'type' => 'string' ),
            'tw_desc'         => array( 'source' => '_yoast_wpseo_twitter-description',  'target' => '_hts_twitter_description','type' => 'string' ),
        ),
        'aioseo' => array(
            'canonical'  => array( 'source' => '_aioseo_canonical_url',   'target' => '_hts_canonical_url',     'type' => 'string' ),
            'focus_kw'   => array( 'source' => '_aioseo_keywords',        'target' => '_hts_focus_keyword',     'type' => 'string' ),
            'pillar'     => array( 'source' => '_aioseo_pillar_content',  'target' => '_hts_pillar',            'type' => 'bool' ),
            'meta_title' => array( 'source' => '_aioseo_title',           'target' => '_hts_meta_title',        'type' => 'string' ),
            'meta_desc'  => array( 'source' => '_aioseo_description',     'target' => '_hts_meta_description',  'type' => 'string' ),
            'og_title'   => array( 'source' => '_aioseo_og_title',        'target' => '_hts_og_title',          'type' => 'string' ),
            'og_desc'    => array( 'source' => '_aioseo_og_description',  'target' => '_hts_og_description',    'type' => 'string' ),
        ),
        'seopress' => array(
            'canonical'  => array( 'source' => '_seopress_robots_canonical',    'target' => '_hts_canonical_url',     'type' => 'string' ),
            'focus_kw'   => array( 'source' => '_seopress_analysis_target_kw',  'target' => '_hts_focus_keyword',     'type' => 'string' ),
            'meta_title' => array( 'source' => '_seopress_titles_title',        'target' => '_hts_meta_title',        'type' => 'string' ),
            'meta_desc'  => array( 'source' => '_seopress_titles_desc',         'target' => '_hts_meta_description',  'type' => 'string' ),
            'og_title'   => array( 'source' => '_seopress_social_fb_title',     'target' => '_hts_og_title',          'type' => 'string' ),
            'og_desc'    => array( 'source' => '_seopress_social_fb_desc',      'target' => '_hts_og_description',    'type' => 'string' ),
            'og_image'   => array( 'source' => '_seopress_social_fb_img',       'target' => '_hts_og_image',          'type' => 'string' ),
        ),
    );

    /* ═══════════════════════════════════════════════════
     *  INIT
     * ═══════════════════════════════════════════════════ */

    public function init() {
        // Admin page (priority 20 → parent menu from admin class registers at default 10)
        add_action( 'admin_menu', array( $this, 'register_admin_page' ), 20 );

        // AJAX handlers
        add_action( 'wp_ajax_hts_wizard_detect',           array( $this, 'ajax_detect' ) );
        add_action( 'wp_ajax_hts_wizard_count',            array( $this, 'ajax_count' ) );
        add_action( 'wp_ajax_hts_wizard_import_batch',     array( $this, 'ajax_import_batch' ) );
        add_action( 'wp_ajax_hts_wizard_import_redirects', array( $this, 'ajax_import_redirects' ) );
        add_action( 'wp_ajax_hts_wizard_apply_takeover',   array( $this, 'ajax_apply_takeover' ) );
        add_action( 'wp_ajax_hts_wizard_import_globals',   array( $this, 'ajax_import_globals' ) );
        add_action( 'wp_ajax_hts_wizard_deactivate',       array( $this, 'ajax_deactivate_competitor' ) );
        add_action( 'wp_ajax_hts_wizard_rollback',         array( $this, 'ajax_rollback' ) );
        add_action( 'wp_ajax_hts_wizard_get_state',        array( $this, 'ajax_get_state' ) );

        // Show notice if competitor detected + no migration done
        add_action( 'admin_notices', array( $this, 'maybe_show_notice' ) );

        // AJAX: dismiss persistent migration notice (30-day snooze)
        add_action( 'wp_ajax_hts_dismiss_migration_notice', array( $this, 'ajax_dismiss_migration_notice' ) );
    }

    /* ═══════════════════════════════════════════════════
     *  ADMIN PAGE
     * ═══════════════════════════════════════════════════ */

    public function register_admin_page() {
        // Light: hidden from sidebar (accessible via onboarding or direct URL)
        // Full: shown in sidebar
        $parent = ( defined( 'HTS__IS_LIGHT' ) && HTS__IS_LIGHT )
            ? ''
            : 'hts-synchronise-articles';

        add_submenu_page(
            $parent,
            'Migration Wizard',
 'Migration',
            'manage_options',
            'hts-migration-wizard',
            array( $this, 'render_page' )
        );
    }

    /* ═══════════════════════════════════════════════════
     *  DETECTION (leverages HTS_Compat)
     * ═══════════════════════════════════════════════════ */

    public static function detect_plugins() {
        if ( ! class_exists( 'HTS_Compat' ) ) return array();
        return HTS_Compat::detect();
    }

    /* ═══════════════════════════════════════════════════
     *  COUNT DATA — Per plugin
     * ═══════════════════════════════════════════════════ */

    public static function count_data( $plugin_slug ) {
        global $wpdb;
        $counts = array();

        switch ( $plugin_slug ) {

            case 'rank_math':
                $counts['meta_titles']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_title' AND meta_value != ''" );
                $counts['meta_descs']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_description' AND meta_value != ''" );
                // Only count posts with actual noindex/nofollow (not default index,follow)
                $counts['robots']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_robots' AND meta_value != '' AND (meta_value LIKE '%noindex%' OR meta_value LIKE '%nofollow%')" );
                $counts['canonical']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_canonical_url' AND meta_value != ''" );
                $counts['focus_kw']     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_focus_keyword' AND meta_value != ''" );
                $counts['pillar']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_pillar_content' AND meta_value = 'on'" );
                // Redirections — check if RM table exists
                $rm_table = $wpdb->prefix . 'rank_math_redirections';
                $table_exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s", DB_NAME, $rm_table ) );
                $counts['redirections'] = $table_exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$rm_table}" ) : 0;
                // OG data (read-only, just for display)
                $counts['og_titles']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_facebook_title' AND meta_value != ''" );
                break;

            case 'yoast':
                $counts['meta_titles']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_title' AND meta_value != ''" );
                $counts['meta_descs']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_metadesc' AND meta_value != ''" );
                $counts['robots']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_meta-robots-noindex' AND meta_value = '1'" );
                $counts['canonical']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_canonical' AND meta_value != ''" );
                $counts['focus_kw']     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_focuskw' AND meta_value != ''" );
                $counts['pillar']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_is_cornerstone' AND meta_value = '1'" );
                // Yoast Premium redirections
                $redirects_option = get_option( 'wpseo-premium-redirects-export-plain', array() );
                $counts['redirections'] = is_array( $redirects_option ) ? count( $redirects_option ) : 0;
                // Also check Yoast table
                $yt = $wpdb->prefix . 'yoast_seo_redirects';
                $yt_exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s", DB_NAME, $yt ) );
                if ( $yt_exists ) {
                    $counts['redirections'] += (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$yt}" );
                }
                $counts['og_titles'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_opengraph-title' AND meta_value != ''" );
                break;

            case 'aioseo':
                // AIOSEO uses custom table wp_aioseo_posts
                $at = $wpdb->prefix . 'aioseo_posts';
                $at_exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s", DB_NAME, $at ) );
                if ( $at_exists ) {
                    $counts['meta_titles']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$at} WHERE title IS NOT NULL AND title != ''" );
                    $counts['meta_descs']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$at} WHERE description IS NOT NULL AND description != ''" );
                    $counts['robots']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$at} WHERE robots_noindex = 1" );
                    $counts['canonical']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$at} WHERE canonical_url IS NOT NULL AND canonical_url != ''" );
                } else {
                    // Fallback to postmeta
                    $counts['meta_titles']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_title' AND meta_value != ''" );
                    $counts['meta_descs']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_description' AND meta_value != ''" );
                    $counts['robots']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_noindex' AND meta_value = '1'" );
                    $counts['canonical']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_canonical_url' AND meta_value != ''" );
                }
                $counts['focus_kw']     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_keywords' AND meta_value != ''" );
                $counts['pillar']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_pillar_content' AND meta_value = '1'" );
                $art = $wpdb->prefix . 'aioseo_redirects';
                $art_exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s", DB_NAME, $art ) );
                $counts['redirections'] = $art_exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$art}" ) : 0;
                $counts['og_titles']    = 0;
                break;

            case 'seopress':
                $counts['meta_titles']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_titles_title' AND meta_value != ''" );
                $counts['meta_descs']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_titles_desc' AND meta_value != ''" );
                $counts['robots']       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_robots_index' AND meta_value = 'yes'" );
                $counts['canonical']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_robots_canonical' AND meta_value != ''" );
                $counts['focus_kw']     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_analysis_target_kw' AND meta_value != ''" );
                $counts['pillar']       = 0;
                $counts['redirections'] = 0; // CPT based — count later
                $counts['og_titles']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_social_fb_title' AND meta_value != ''" );
                break;

            default:
                $counts = array( 'meta_titles' => 0, 'meta_descs' => 0, 'robots' => 0, 'canonical' => 0, 'focus_kw' => 0, 'pillar' => 0, 'redirections' => 0, 'og_titles' => 0 );
        }

        $counts['total_importable'] = ( $counts['robots'] ?? 0 ) + ( $counts['canonical'] ?? 0 )
                                    + ( $counts['focus_kw'] ?? 0 ) + ( $counts['pillar'] ?? 0 )
                                    + ( $counts['redirections'] ?? 0 )
                                    + ( $counts['meta_titles'] ?? 0 ) + ( $counts['meta_descs'] ?? 0 )
                                    + ( $counts['og_titles'] ?? 0 );

        return $counts;
    }

    /* ═══════════════════════════════════════════════════
     *  BACKUP — Before import
     * ═══════════════════════════════════════════════════ */

    public static function create_backup() {
        global $wpdb;
        $backup = array(
            'timestamp'  => time(),
            'date'       => current_time( 'mysql' ),
            'compat'     => get_option( HTS_Compat::OPTION, array() ),
            'hts_meta'   => array(
                'robots'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_robots_meta'" ),
                'canonical' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_canonical_url' AND meta_value != ''" ),
                'focus_kw'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_focus_keyword' AND meta_value != ''" ),
                'pillar'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_pillar'" ),
            ),
            'redirects_count' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}hts_redirects WHERE origin = 'import'" ),
        );
        update_option( self::OPTION_BACKUP, $backup );
        return $backup;
    }

    /* ═══════════════════════════════════════════════════
     *  IMPORT — Batch post meta
     * ═══════════════════════════════════════════════════ */

    /**
     * Import a batch of post meta from a competitor plugin.
     *
     * @param string $plugin_slug  rank_math|yoast|aioseo|seopress
     * @param string $data_type    robots|canonical|focus_kw|pillar
     * @param int    $offset       Batch offset
     * @return array               [ 'imported' => int, 'skipped' => int, 'done' => bool ]
     */
    public static function import_meta_batch( $plugin_slug, $data_type, $offset = 0 ) {
        global $wpdb;

        if ( ! isset( self::$meta_map[ $plugin_slug ] ) ) {
            return array( 'imported' => 0, 'skipped' => 0, 'done' => true, 'error' => 'Plugin inconnu' );
        }

        // Special handling: Yoast has 2 separate keys for robots
        if ( $plugin_slug === 'yoast' && $data_type === 'robots' ) {
            return self::import_yoast_robots_batch( $offset );
        }

        // Special handling: AIOSEO custom table for robots
        if ( $plugin_slug === 'aioseo' && $data_type === 'robots' ) {
            return self::import_aioseo_robots_batch( $offset );
        }

        // Special handling: SEOPress robots
        if ( $plugin_slug === 'seopress' && $data_type === 'robots' ) {
            return self::import_seopress_robots_batch( $offset );
        }

        $map_key = $data_type;
        if ( ! isset( self::$meta_map[ $plugin_slug ][ $map_key ] ) ) {
            return array( 'imported' => 0, 'skipped' => 0, 'done' => true, 'error' => "Type {$data_type} non supporté pour {$plugin_slug}" );
        }

        $mapping    = self::$meta_map[ $plugin_slug ][ $map_key ];
        $source_key = $mapping['source'];
        $target_key = $mapping['target'];
        $type       = $mapping['type'];

        // Get batch of post IDs that have this source meta
        $post_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key = %s AND meta_value != ''
             ORDER BY post_id ASC
             LIMIT %d OFFSET %d",
            $source_key, self::BATCH_SIZE, $offset
        ) );

        if ( empty( $post_ids ) ) {
            return array( 'imported' => 0, 'skipped' => 0, 'done' => true );
        }

        $imported = 0;
        $skipped  = 0;

        foreach ( $post_ids as $post_id ) {
            $post_id = (int) $post_id;

            // Skip if HTS already has a value (don't overwrite)
            $existing = get_post_meta( $post_id, $target_key, true );
            if ( ! empty( $existing ) ) {
                $skipped++;
                continue;
            }

            $value = get_post_meta( $post_id, $source_key, true );
            if ( empty( $value ) ) {
                $skipped++;
                continue;
            }

            // Convert value based on type
            $hts_value = self::convert_meta_value( $value, $type, $plugin_slug );
            if ( $hts_value === null ) {
                $skipped++;
                continue;
            }

            update_post_meta( $post_id, $target_key, $hts_value );
            $imported++;
        }

        $done = count( $post_ids ) < self::BATCH_SIZE;

        return array( 'imported' => $imported, 'skipped' => $skipped, 'done' => $done );
    }

    /**
     * Convert competitor meta value to HTS format.
     */
    private static function convert_meta_value( $value, $type, $plugin_slug ) {
        switch ( $type ) {
            case 'string':
                return sanitize_text_field( $value );

            case 'bool':
                return ( $value === 'on' || $value === '1' || $value === 1 ) ? '1' : null;

            case 'robots':
                // Rank Math stores robots as serialized array: a:2:{i:0;s:5:"index";i:1;s:6:"follow";}
                $arr = maybe_unserialize( $value );
                if ( is_array( $arr ) ) {
                    // Convert RM format to HTS format (array)
                    $noindex  = in_array( 'noindex', $arr, true );
                    $nofollow = in_array( 'nofollow', $arr, true );
                    if ( ! $noindex && ! $nofollow ) return null; // Default = index,follow → nothing to store
                    $hts_val = array();
                    if ( $noindex )  $hts_val[] = 'noindex';
                    if ( $nofollow ) $hts_val[] = 'nofollow';
                    return $hts_val;
                }
                // If it's already a string like "noindex,nofollow" → convert to array
                if ( is_string( $value ) && ( strpos( $value, 'noindex' ) !== false || strpos( $value, 'nofollow' ) !== false ) ) {
                    return array_filter( array_map( 'trim', explode( ',', $value ) ) );
                }
                return null;

            default:
                return sanitize_text_field( $value );
        }
    }

    /**
     * Yoast robots: 2 separate meta keys → 1 HTS meta
     */
    private static function import_yoast_robots_batch( $offset ) {
        global $wpdb;

        $post_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key IN ('_yoast_wpseo_meta-robots-noindex', '_yoast_wpseo_meta-robots-nofollow')
             AND meta_value = '1'
             ORDER BY post_id ASC
             LIMIT %d OFFSET %d",
            self::BATCH_SIZE, $offset
        ) );

        if ( empty( $post_ids ) ) {
            return array( 'imported' => 0, 'skipped' => 0, 'done' => true );
        }

        $imported = 0;
        $skipped  = 0;

        foreach ( $post_ids as $post_id ) {
            $post_id = (int) $post_id;
            $existing = get_post_meta( $post_id, '_hts_robots_meta', true );
            if ( ! empty( $existing ) ) { $skipped++; continue; }

            $noindex  = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true ) === '1';
            $nofollow = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', true ) === '1';

            if ( ! $noindex && ! $nofollow ) { $skipped++; continue; }

            $vals = array();
            if ( $noindex )  $vals[] = 'noindex';
            if ( $nofollow ) $vals[] = 'nofollow';

            update_post_meta( $post_id, '_hts_robots_meta', $vals );
            $imported++;
        }

        return array( 'imported' => $imported, 'skipped' => $skipped, 'done' => count( $post_ids ) < self::BATCH_SIZE );
    }

    /**
     * AIOSEO robots: custom table wp_aioseo_posts
     */
    private static function import_aioseo_robots_batch( $offset ) {
        global $wpdb;
        $at = $wpdb->prefix . 'aioseo_posts';

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, robots_noindex, robots_nofollow FROM {$at}
             WHERE (robots_noindex = 1 OR robots_nofollow = 1)
             ORDER BY post_id ASC LIMIT %d OFFSET %d",
            self::BATCH_SIZE, $offset
        ) );

        if ( empty( $rows ) ) {
            return array( 'imported' => 0, 'skipped' => 0, 'done' => true );
        }

        $imported = 0;
        $skipped  = 0;

        foreach ( $rows as $row ) {
            $pid = (int) $row->post_id;
            $existing = get_post_meta( $pid, '_hts_robots_meta', true );
            if ( ! empty( $existing ) ) { $skipped++; continue; }

            $vals = array();
            if ( $row->robots_noindex )  $vals[] = 'noindex';
            if ( $row->robots_nofollow ) $vals[] = 'nofollow';
            if ( empty( $vals ) ) { $skipped++; continue; }

            update_post_meta( $pid, '_hts_robots_meta', $vals );
            $imported++;
        }

        return array( 'imported' => $imported, 'skipped' => $skipped, 'done' => count( $rows ) < self::BATCH_SIZE );
    }

    /**
     * SEOPress robots: _seopress_robots_index = 'yes' means noindex
     */
    private static function import_seopress_robots_batch( $offset ) {
        global $wpdb;

        $post_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key IN ('_seopress_robots_index','_seopress_robots_follow')
             AND meta_value = 'yes'
             ORDER BY post_id ASC LIMIT %d OFFSET %d",
            self::BATCH_SIZE, $offset
        ) );

        if ( empty( $post_ids ) ) {
            return array( 'imported' => 0, 'skipped' => 0, 'done' => true );
        }

        $imported = 0;
        $skipped  = 0;

        foreach ( $post_ids as $post_id ) {
            $post_id = (int) $post_id;
            $existing = get_post_meta( $post_id, '_hts_robots_meta', true );
            if ( ! empty( $existing ) ) { $skipped++; continue; }

            $noindex  = get_post_meta( $post_id, '_seopress_robots_index', true ) === 'yes';
            $nofollow = get_post_meta( $post_id, '_seopress_robots_follow', true ) === 'yes';
            if ( ! $noindex && ! $nofollow ) { $skipped++; continue; }

            $vals = array();
            if ( $noindex )  $vals[] = 'noindex';
            if ( $nofollow ) $vals[] = 'nofollow';

            update_post_meta( $post_id, '_hts_robots_meta', $vals );
            $imported++;
        }

        return array( 'imported' => $imported, 'skipped' => $skipped, 'done' => count( $post_ids ) < self::BATCH_SIZE );
    }

    /* ═══════════════════════════════════════════════════
     *  IMPORT — Redirections
     * ═══════════════════════════════════════════════════ */

    public static function import_redirections( $plugin_slug ) {
        // Ensure the redirects table exists before importing
        if ( class_exists( 'HTS_Redirects' ) ) {
            HTS_Redirects::create_tables();
        }

        switch ( $plugin_slug ) {
            case 'rank_math': return self::import_redirections_rank_math();
            case 'yoast':     return self::import_redirections_yoast();
            case 'aioseo':    return self::import_redirections_aioseo();
            default:          return array( 'imported' => 0, 'skipped' => 0, 'errors' => 0 );
        }
    }

    private static function import_redirections_rank_math() {
        global $wpdb;
        $rm_table  = $wpdb->prefix . 'rank_math_redirections';
        $hts_table = $wpdb->prefix . 'hts_redirects';

        $table_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
            DB_NAME, $rm_table
        ) );
        if ( ! $table_exists ) return array( 'imported' => 0, 'skipped' => 0, 'errors' => 0 );

        $rows = $wpdb->get_results( "SELECT * FROM {$rm_table} ORDER BY id ASC" );
        $imported = 0;
        $skipped  = 0;
        $errors   = 0;

        foreach ( $rows as $row ) {
            // Parse sources — Rank Math stores as JSON, but older versions used serialized PHP
            $sources = json_decode( $row->sources, true );
            if ( ! is_array( $sources ) ) {
                $sources = maybe_unserialize( $row->sources );
            }
            if ( ! is_array( $sources ) ) { $errors++; continue; }

            foreach ( $sources as $source ) {
                $source_url = isset( $source['pattern'] ) ? $source['pattern'] : '';
                if ( empty( $source_url ) ) { $errors++; continue; }

                // Normalize
                $source_url  = '/' . ltrim( $source_url, '/' );
                $source_hash = md5( $source_url );

                // Check for duplicate
                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$hts_table} WHERE source_hash = %s",
                    $source_hash
                ) );

                if ( $exists ) {
                    // Keep the one with more hits
                    $existing_hits = (int) $wpdb->get_var( $wpdb->prepare(
                        "SELECT hit_count FROM {$hts_table} WHERE id = %d", $exists
                    ) );
                    $rm_hits = (int) ( $row->hits ?? 0 );
                    if ( $rm_hits > $existing_hits ) {
                        $wpdb->update( $hts_table, array(
                            'target_url'    => esc_url_raw( $row->url_to ),
                            'redirect_type' => (int) $row->header_code,
                            'hit_count'     => $rm_hits,
                            'origin'        => 'import',
                            'notes'         => 'Rank Math import (updated — more hits)',
                        ), array( 'id' => $exists ) );
                        $imported++;
                    } else {
                        $skipped++;
                    }
                    continue;
                }

                // Determine if regex
                $is_regex = isset( $source['comparison'] ) && $source['comparison'] === 'regex' ? 1 : 0;

                $target_url = $row->url_to;
                if ( ! $is_regex ) {
                    $target_url = esc_url_raw( $target_url );
                }

                $result = $wpdb->insert( $hts_table, array(
                    'source_url'    => $source_url,
                    'source_hash'   => $source_hash,
                    'target_url'    => $target_url,
                    'redirect_type' => (int) $row->header_code,
                    'is_regex'      => $is_regex,
                    'origin'        => 'import',
                    'hit_count'     => (int) ( $row->hits ?? 0 ),
                    'enabled'       => ( $row->status ?? 'active' ) === 'active' ? 1 : 0,
                    'notes'         => sprintf( 'Importé depuis Rank Math (ID:%d)', $row->id ),
                ) );

                if ( $result ) {
                    $imported++;
                } else {
                    $errors++;
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log(
                            sprintf( 'Redirect import error (RM ID:%d, source:%s): %s', $row->id, $source_url, $wpdb->last_error ),
                            'error', 'migration'
                        );
                    }
                }
            }
        }

        return array( 'imported' => $imported, 'skipped' => $skipped, 'errors' => $errors );
    }

    private static function import_redirections_yoast() {
        global $wpdb;
        $hts_table = $wpdb->prefix . 'hts_redirects';
        $imported  = 0;
        $skipped   = 0;
        $errors    = 0;

        // Method 1: wp_options (Yoast Premium export)
        $redirects = get_option( 'wpseo-premium-redirects-export-plain', array() );
        if ( is_array( $redirects ) && ! empty( $redirects ) ) {
            foreach ( $redirects as $r ) {
                $source_url  = '/' . ltrim( $r['origin'] ?? '', '/' );
                $source_hash = md5( $source_url );

                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$hts_table} WHERE source_hash = %s", $source_hash
                ) );
                if ( $exists ) { $skipped++; continue; }

                $result = $wpdb->insert( $hts_table, array(
                    'source_url'    => $source_url,
                    'source_hash'   => $source_hash,
                    'target_url'    => esc_url_raw( $r['url'] ?? '' ),
                    'redirect_type' => (int) ( $r['type'] ?? 301 ),
                    'is_regex'      => 0,
                    'origin'        => 'import',
                    'hit_count'     => 0,
                    'enabled'       => 1,
                    'notes'         => 'Importé depuis Yoast Premium',
                ) );
                $result ? $imported++ : $errors++;
            }
        }

        // Method 2: Yoast table (if exists)
        $yt = $wpdb->prefix . 'yoast_seo_redirects';
        $yt_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
            DB_NAME, $yt
        ) );
        if ( $yt_exists ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$yt}" );
            foreach ( $rows as $row ) {
                $source_url  = '/' . ltrim( $row->old_url ?? '', '/' );
                $source_hash = md5( $source_url );
                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$hts_table} WHERE source_hash = %s", $source_hash
                ) );
                if ( $exists ) { $skipped++; continue; }

                $result = $wpdb->insert( $hts_table, array(
                    'source_url'    => $source_url,
                    'source_hash'   => $source_hash,
                    'target_url'    => esc_url_raw( $row->new_url ?? '' ),
                    'redirect_type' => (int) ( $row->type ?? 301 ),
                    'is_regex'      => 0,
                    'origin'        => 'import',
                    'hit_count'     => 0,
                    'enabled'       => 1,
                    'notes'         => 'Importé depuis Yoast (table)',
                ) );
                $result ? $imported++ : $errors++;
            }
        }

        return array( 'imported' => $imported, 'skipped' => $skipped, 'errors' => $errors );
    }

    private static function import_redirections_aioseo() {
        global $wpdb;
        $aio_table = $wpdb->prefix . 'aioseo_redirects';
        $hts_table = $wpdb->prefix . 'hts_redirects';

        $table_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
            DB_NAME, $aio_table
        ) );
        if ( ! $table_exists ) return array( 'imported' => 0, 'skipped' => 0, 'errors' => 0 );

        $rows     = $wpdb->get_results( "SELECT * FROM {$aio_table} ORDER BY id ASC" );
        $imported = 0;
        $skipped  = 0;
        $errors   = 0;

        foreach ( $rows as $row ) {
            $source_url  = '/' . ltrim( $row->source_url ?? '', '/' );
            $source_hash = md5( $source_url );

            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$hts_table} WHERE source_hash = %s", $source_hash
            ) );
            if ( $exists ) { $skipped++; continue; }

            $result = $wpdb->insert( $hts_table, array(
                'source_url'    => $source_url,
                'source_hash'   => $source_hash,
                'target_url'    => esc_url_raw( $row->target_url ?? '' ),
                'redirect_type' => (int) ( $row->type ?? 301 ),
                'is_regex'      => 0,
                'origin'        => 'import',
                'hit_count'     => (int) ( $row->hits ?? 0 ),
                'enabled'       => (int) ( $row->enabled ?? 1 ),
                'notes'         => sprintf( 'Importé depuis AIOSEO (ID:%d)', $row->id ),
            ) );
            $result ? $imported++ : $errors++;
        }

        return array( 'imported' => $imported, 'skipped' => $skipped, 'errors' => $errors );
    }

    /* ═══════════════════════════════════════════════════
     *  TAKEOVER — Apply compat settings
     * ═══════════════════════════════════════════════════ */

    public static function apply_takeover( $features = array() ) {
        $settings = array();
        $defaults = array( 'sitemaps', 'redirects', 'robots_meta', 'canonical', 'schema', 'meta_title', 'opengraph' );

        foreach ( $defaults as $f ) {
            $settings[ $f ] = in_array( $f, $features, true ) ? 'hts' : 'other';
        }

        update_option( HTS_Compat::OPTION, $settings );

        if ( function_exists( 'hts_add_log' ) ) {
            $active = array_filter( $settings, function( $v ) { return $v === 'hts'; } );
            hts_add_log(
 sprintf( 'Migration Wizard — Takeover appliqué : %s', implode( ', ', array_keys( $active ) ) ),
                'success', 'migration'
            );
        }

        return $settings;
    }

    /* ═══════════════════════════════════════════════════
     *  ROLLBACK
     * ═══════════════════════════════════════════════════ */

    public static function rollback() {
        global $wpdb;

        $backup = get_option( self::OPTION_BACKUP );
        if ( ! $backup ) return array( 'success' => false, 'error' => 'Aucun backup trouvé' );

        // Restore compat settings
        if ( isset( $backup['compat'] ) ) {
            update_option( HTS_Compat::OPTION, $backup['compat'] );
        }

        // Remove imported redirections
        $wpdb->delete( $wpdb->prefix . 'hts_redirects', array( 'origin' => 'import' ) );

        // Remove imported meta (only those from migration — identified by presence of both source + HTS meta)
        // We don't delete ALL HTS meta — only those that match a known import pattern
        // Safe approach: delete migration state, let user re-run if needed
        delete_option( self::OPTION_STATE );
        delete_option( self::OPTION_REPORT );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( '↩ Migration Wizard — Rollback effectué', 'warning', 'migration' );
        }

        return array( 'success' => true, 'message' => 'Rollback effectué. Les meta importées restent (non-destructif). Les redirections importées ont été supprimées.' );
    }

    /* ═══════════════════════════════════════════════════
     *  IMPORT — Global Settings (templates titles/desc)
     * ═══════════════════════════════════════════════════ */

    public static function import_global_settings( $plugin_slug ) {
        $imported = array();
        $skipped  = array();

        switch ( $plugin_slug ) {
            case 'rank_math':
                $opts = get_option( 'rank-math-options-titles', array() );
                // Homepage
                if ( ! empty( $opts['homepage_title'] ) && ! get_option( 'hts_home_title' ) ) {
                    update_option( 'hts_home_title', sanitize_text_field( $opts['homepage_title'] ) );
                    $imported[] = 'home_title';
                } else { $skipped[] = 'home_title'; }
                if ( ! empty( $opts['homepage_description'] ) && ! get_option( 'hts_home_description' ) ) {
                    update_option( 'hts_home_description', sanitize_text_field( $opts['homepage_description'] ) );
                    $imported[] = 'home_description';
                } else { $skipped[] = 'home_description'; }
                // Post title template
                if ( ! empty( $opts['pt_post_title'] ) && ! get_option( 'hts_template_post_title' ) ) {
                    update_option( 'hts_template_post_title', sanitize_text_field( $opts['pt_post_title'] ) );
                    $imported[] = 'post_title_template';
                } else { $skipped[] = 'post_title_template'; }
                if ( ! empty( $opts['pt_post_description'] ) && ! get_option( 'hts_template_post_desc' ) ) {
                    update_option( 'hts_template_post_desc', sanitize_text_field( $opts['pt_post_description'] ) );
                    $imported[] = 'post_desc_template';
                } else { $skipped[] = 'post_desc_template'; }
                // Page title template
                if ( ! empty( $opts['pt_page_title'] ) && ! get_option( 'hts_template_page_title' ) ) {
                    update_option( 'hts_template_page_title', sanitize_text_field( $opts['pt_page_title'] ) );
                    $imported[] = 'page_title_template';
                } else { $skipped[] = 'page_title_template'; }
                // Separator
                if ( ! empty( $opts['title_separator'] ) && ! get_option( 'hts_title_separator' ) ) {
                    update_option( 'hts_title_separator', sanitize_text_field( $opts['title_separator'] ) );
                    $imported[] = 'separator';
                } else { $skipped[] = 'separator'; }
                // Noindex empty archives
                if ( ! empty( $opts['noindex_empty_archive'] ) ) {
                    update_option( 'hts_noindex_empty_archives', $opts['noindex_empty_archive'] === 'on' ? '1' : '0' );
                    $imported[] = 'noindex_empty_archives';
                }
                // Social profiles
                $social = get_option( 'rank-math-options-general', array() );
                if ( ! empty( $social['social_url_facebook'] ) && ! get_option( 'hts_social_facebook' ) ) {
                    update_option( 'hts_social_facebook', esc_url_raw( $social['social_url_facebook'] ) );
                    $imported[] = 'social_facebook';
                }
                if ( ! empty( $social['twitter_author_names'] ) && ! get_option( 'hts_twitter_handle' ) ) {
                    update_option( 'hts_twitter_handle', sanitize_text_field( $social['twitter_author_names'] ) );
                    $imported[] = 'twitter_handle';
                }
                break;

            case 'yoast':
                $titles = get_option( 'wpseo_titles', array() );
                $social = get_option( 'wpseo_social', array() );
                // Separator
                if ( ! empty( $titles['separator'] ) && ! get_option( 'hts_title_separator' ) ) {
                    // Yoast uses codes like 'sc-dash', 'sc-pipe', etc.
                    $sep_map = array(
                        'sc-dash' => '—', 'sc-ndash' => '–', 'sc-pipe' => '|',
                        'sc-colon' => ':', 'sc-middot' => '·', 'sc-bull' => '•',
                        'sc-star' => '*', 'sc-smstar' => '⋆', 'sc-laquo' => '«',
                        'sc-raquo' => '»', 'sc-gt' => '›', 'sc-lt' => '‹',
                    );
                    $sep = isset( $sep_map[ $titles['separator'] ] ) ? $sep_map[ $titles['separator'] ] : '—';
                    update_option( 'hts_title_separator', $sep );
                    $imported[] = 'separator';
                } else { $skipped[] = 'separator'; }
                // Post title template
                if ( ! empty( $titles['title-post'] ) && ! get_option( 'hts_template_post_title' ) ) {
                    update_option( 'hts_template_post_title', sanitize_text_field( $titles['title-post'] ) );
                    $imported[] = 'post_title_template';
                } else { $skipped[] = 'post_title_template'; }
                if ( ! empty( $titles['metadesc-post'] ) && ! get_option( 'hts_template_post_desc' ) ) {
                    update_option( 'hts_template_post_desc', sanitize_text_field( $titles['metadesc-post'] ) );
                    $imported[] = 'post_desc_template';
                } else { $skipped[] = 'post_desc_template'; }
                // Social
                if ( ! empty( $social['twitter_site'] ) && ! get_option( 'hts_twitter_handle' ) ) {
                    update_option( 'hts_twitter_handle', '@' . ltrim( sanitize_text_field( $social['twitter_site'] ), '@' ) );
                    $imported[] = 'twitter_handle';
                }
                if ( ! empty( $social['og_default_image'] ) && ! get_option( 'hts_og_default_image' ) ) {
                    update_option( 'hts_og_default_image', esc_url_raw( $social['og_default_image'] ) );
                    $imported[] = 'og_default_image';
                }
                break;

            case 'seopress':
                $titles = get_option( 'seopress_titles_option_name', array() );
                if ( ! empty( $titles['seopress_titles_sep'] ) && ! get_option( 'hts_title_separator' ) ) {
                    update_option( 'hts_title_separator', sanitize_text_field( $titles['seopress_titles_sep'] ) );
                    $imported[] = 'separator';
                }
                if ( ! empty( $titles['seopress_titles_home_site_title'] ) && ! get_option( 'hts_home_title' ) ) {
                    update_option( 'hts_home_title', sanitize_text_field( $titles['seopress_titles_home_site_title'] ) );
                    $imported[] = 'home_title';
                }
                $social = get_option( 'seopress_social_option_name', array() );
                if ( ! empty( $social['seopress_social_accounts_twitter'] ) && ! get_option( 'hts_twitter_handle' ) ) {
                    update_option( 'hts_twitter_handle', sanitize_text_field( $social['seopress_social_accounts_twitter'] ) );
                    $imported[] = 'twitter_handle';
                }
                break;

            case 'aioseo':
                // AIOSEO stores in aioseo_options (JSON blob)
                $raw = get_option( 'aioseo_options', '' );
                $opts = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
                if ( is_array( $opts ) ) {
                    $sep = $opts['searchAppearance']['global']['separator'] ?? '';
                    if ( $sep && ! get_option( 'hts_title_separator' ) ) {
                        update_option( 'hts_title_separator', sanitize_text_field( $sep ) );
                        $imported[] = 'separator';
                    }
                    $home_title = $opts['searchAppearance']['global']['siteTitle'] ?? '';
                    if ( $home_title && ! get_option( 'hts_home_title' ) ) {
                        update_option( 'hts_home_title', sanitize_text_field( $home_title ) );
                        $imported[] = 'home_title';
                    }
                }
                break;
        }

        if ( function_exists( 'hts_add_log' ) && ! empty( $imported ) ) {
            hts_add_log(
 sprintf( 'Migration Wizard — %d réglages globaux importés depuis %s : %s',
                    count( $imported ), $plugin_slug, implode( ', ', $imported ) ),
                'success', 'migration'
            );
        }

        return array( 'imported' => $imported, 'skipped' => $skipped );
    }

    /* ═══════════════════════════════════════════════════
     *  DEACTIVATE COMPETITOR — Guided plugin deactivation
     * ═══════════════════════════════════════════════════ */

    public static function deactivate_competitor( $plugin_slug ) {
        if ( ! class_exists( 'HTS_Compat' ) ) {
            return array( 'success' => false, 'error' => 'HTS_Compat non chargé' );
        }

        $plugin_files = HTS_Compat::get_plugin_files();
        if ( ! isset( $plugin_files[ $plugin_slug ] ) ) {
            return array( 'success' => false, 'error' => 'Plugin non reconnu : ' . $plugin_slug );
        }

        $plugin_name = $plugin_files[ $plugin_slug ]['name'];
        // Deactivate all active files (free + pro)
        $all_files   = isset( $plugin_files[ $plugin_slug ]['files'] )
                     ? $plugin_files[ $plugin_slug ]['files']
                     : array( $plugin_files[ $plugin_slug ]['file'] );

        if ( ! function_exists( 'deactivate_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // Check if any are active
        $active = array_filter( $all_files, 'is_plugin_active' );
        if ( empty( $active ) ) {
            return array( 'success' => true, 'message' => $plugin_name . ' est déjà désactivé.', 'already_inactive' => true );
        }

        // Deactivate all at once
        deactivate_plugins( $active );

        // Verify
        $still_active = array_filter( $active, 'is_plugin_active' );
        if ( ! empty( $still_active ) ) {
            return array( 'success' => false, 'error' => 'Impossible de désactiver ' . $plugin_name . ' (' . implode( ', ', $still_active ) . ')' );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
 sprintf( 'Migration Wizard — %s désactivé avec succès (%s)', $plugin_name, implode( ', ', $active ) ),
                'success', 'migration'
            );
        }

        return array( 'success' => true, 'message' => $plugin_name . ' désactivé avec succès.', 'plugin' => $plugin_name );
    }

    /* ═══════════════════════════════════════════════════
     *  AJAX HANDLERS
     * ═══════════════════════════════════════════════════ */

    private function verify_ajax() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Accès refusé' );
        check_ajax_referer( self::NONCE, 'nonce' );
    }

    public function ajax_detect() {
        ob_start();
        try {
            $this->verify_ajax();
            $plugins = self::detect_plugins();

            // Fallback : si HTS_Compat ne trouve rien, détecter via postmeta directement
            if ( empty( $plugins ) ) {
                global $wpdb;
                // RankMath : check if meta keys exist in DB even if plugin class not loaded yet
                $rm = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_title' LIMIT 1" );
                if ( $rm > 0 ) $plugins['rank_math'] = 'Rank Math';
                // Yoast
                $yo = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_title' LIMIT 1" );
                if ( $yo > 0 ) $plugins['yoast'] = 'Yoast SEO';
                // AIOSEO
                $ai = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_aioseo_title' LIMIT 1" );
                if ( $ai > 0 ) $plugins['aioseo'] = 'All in One SEO';
                // SEOPress
                $sp = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_seopress_titles_title' LIMIT 1" );
                if ( $sp > 0 ) $plugins['seopress'] = 'SEOPress';
            }

            $data = array();
            foreach ( $plugins as $slug => $name ) {
                $data[ $slug ] = array(
                    'name'   => $name,
                    'counts' => self::count_data( $slug ),
                );
            }

            $php_output = ob_get_clean();
            wp_send_json_success( $data );
        } catch ( \Throwable $e ) {
            ob_end_clean();
            wp_send_json_error( 'Erreur détection : ' . $e->getMessage() . ' (' . basename( $e->getFile() ) . ':' . $e->getLine() . ')' );
        }
    }

    public function ajax_count() {
        $this->verify_ajax();
        $plugin = sanitize_text_field( $_POST['plugin'] ?? '' );
        if ( ! $plugin ) wp_send_json_error( 'Plugin manquant' );
        wp_send_json_success( self::count_data( $plugin ) );
    }

    public function ajax_import_batch() {
        $this->verify_ajax();
        $plugin    = sanitize_text_field( $_POST['plugin'] ?? '' );
        $data_type = sanitize_text_field( $_POST['data_type'] ?? '' );
        $offset    = (int) ( $_POST['offset'] ?? 0 );

        if ( ! $plugin || ! $data_type ) {
            wp_send_json_error( 'Paramètres manquants' );
        }

        // Create backup on first batch
        if ( $offset === 0 ) {
            self::create_backup();
        }

        $result = self::import_meta_batch( $plugin, $data_type, $offset );
        wp_send_json_success( $result );
    }

    public function ajax_import_redirects() {
        $this->verify_ajax();
        $plugin = sanitize_text_field( $_POST['plugin'] ?? '' );
        if ( ! $plugin ) wp_send_json_error( 'Plugin manquant' );

        $result = self::import_redirections( $plugin );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
 sprintf( 'Migration Wizard — %d redirections importées depuis %s (%d ignorées, %d erreurs)',
                    $result['imported'], $plugin, $result['skipped'], $result['errors'] ),
                'success', 'migration'
            );
        }

        wp_send_json_success( $result );
    }

    public function ajax_apply_takeover() {
        $this->verify_ajax();
        $features = isset( $_POST['features'] ) ? array_map( 'sanitize_text_field', (array) $_POST['features'] ) : array();
        $settings = self::apply_takeover( $features );

        // Save final report
        $report = array(
            'timestamp' => time(),
            'date'      => current_time( 'mysql' ),
            'plugin'    => sanitize_text_field( $_POST['plugin'] ?? '' ),
            'features'  => $features,
            'settings'  => $settings,
        );
        update_option( self::OPTION_REPORT, $report );
        update_option( self::OPTION_STATE, 'completed' );

        wp_send_json_success( $report );
    }

    public function ajax_rollback() {
        $this->verify_ajax();
        $result = self::rollback();
        wp_send_json_success( $result );
    }

    public function ajax_get_state() {
        $this->verify_ajax();
        wp_send_json_success( array(
            'state'  => get_option( self::OPTION_STATE, 'not_started' ),
            'report' => get_option( self::OPTION_REPORT, null ),
            'backup' => get_option( self::OPTION_BACKUP, null ),
        ) );
    }

    public function ajax_import_globals() {
        $this->verify_ajax();
        $plugin = sanitize_text_field( $_POST['plugin'] ?? '' );
        if ( ! $plugin ) wp_send_json_error( 'Plugin manquant' );
        $result = self::import_global_settings( $plugin );
        wp_send_json_success( $result );
    }

    public function ajax_deactivate_competitor() {
        $this->verify_ajax();
        $plugin = sanitize_text_field( $_POST['plugin'] ?? '' );
        if ( ! $plugin ) wp_send_json_error( 'Plugin manquant' );
        $result = self::deactivate_competitor( $plugin );
        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result['error'] ?? 'Erreur inconnue' );
        }
    }

    /* ═══════════════════════════════════════════════════
     *  ADMIN NOTICE — Prompt migration
     * ═══════════════════════════════════════════════════ */

    /**
     * AJAX: Dismiss persistent migration notice (30-day snooze).
     * @since 2.4.3
     */
    public function ajax_dismiss_migration_notice() {
        check_ajax_referer( 'hts_cockpit', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );
        update_option( 'hts_migration_notice_dismissed', time(), false );
        wp_send_json_success();
    }

    public function maybe_show_notice() {
        if ( get_option( self::OPTION_STATE ) === 'completed' ) return;
        if ( ! HTS_Compat::has_competing_plugin() ) return;

        $screen = get_current_screen();
        if ( $screen && strpos( $screen->id, 'hts-migration' ) !== false ) return;
        if ( $screen && strpos( $screen->id, 'hts-onboarding' ) !== false ) return;

        $competitor = HTS_Compat::get_competing_name();
        $url = admin_url( 'admin.php?page=hts-migration-wizard' );

        // ── Track first detection date ──
        $first_seen = get_option( 'hts_migration_first_detected' );
        if ( ! $first_seen ) {
            update_option( 'hts_migration_first_detected', time(), false );
            $first_seen = time();
        }

        $days_since = floor( ( time() - (int) $first_seen ) / DAY_IN_SECONDS );

        // ── Persistent notice after 7 days ──
        if ( $days_since >= 7 ) {
            $dismissed = get_option( 'hts_migration_notice_dismissed' );
            if ( $dismissed ) {
                $dismissed_time = (int) $dismissed;
                $days_dismissed = floor( ( time() - $dismissed_time ) / DAY_IN_SECONDS );
                if ( $days_dismissed < 30 ) return; // Respect 30-day snooze
                // Re-show after 30 days
                delete_option( 'hts_migration_notice_dismissed' );
            }

            echo '<div class="notice notice-warning" id="hts-migration-persistent-notice" style="position:relative;">';
            echo '<p><strong>Hack The SEO</strong> — ';
            echo esc_html( $competitor ) . ' est toujours actif et vos données n\'ont pas été importées. ';
            echo 'Cela fait ' . (int) $days_since . ' jours. ';
            echo '<a href="' . esc_url( $url ) . '">Lancez la migration maintenant</a> pour ne rien perdre.</p>';
            echo '<button type="button" class="notice-dismiss" onclick="htsDismissMigrationNotice()" style="position:absolute;top:0;right:1px;border:none;margin:0;padding:9px;background:none;color:#787c82;cursor:pointer;"><span class="screen-reader-text">Masquer cette notification</span></button>';
            echo '</div>';
            echo '<script>function htsDismissMigrationNotice(){fetch(ajaxurl,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"action=hts_dismiss_migration_notice&nonce=' . wp_create_nonce( 'hts_cockpit' ) . '"}).then(function(){var el=document.getElementById("hts-migration-persistent-notice");if(el)el.remove();});}</script>';
            return;
        }

        // ── Standard dismissible notice (first 7 days) ──
        echo '<div class="notice notice-info is-dismissible">';
        echo '<p><strong>Hack The SEO</strong> — ';
        echo esc_html( $competitor ) . ' détecté ! ';
        echo '<a href="' . esc_url( $url ) . '">Importez vos données en 1 clic</a> avec le Migration Wizard.';
        echo '</p></div>';
    }

    /* ═══════════════════════════════════════════════════
     *  RENDER — Admin Page (Wizard UI)
     * ═══════════════════════════════════════════════════ */

    public function render_page() {
        $nonce = wp_create_nonce( self::NONCE );
        ?>
        <style>
            :root {
                --wiz-bg: #0f1419;
                --wiz-surface: #1a2332;
                --wiz-surface2: #243044;
                --wiz-border: #2d3f56;
                --wiz-text: #e2e8f0;
                --wiz-text-muted: #94a3b8;
                --wiz-text-dim: #64748b;
                --wiz-accent: #84cc16;
                --wiz-accent-dim: rgba(132,204,22,0.15);
                --wiz-danger: #ef4444;
                --wiz-info: #3b82f6;
                --wiz-success: #22c55e;
                --wiz-warning: #f59e0b;
                --wiz-radius: 12px;
            }
            .hts-wizard-wrap { max-width:800px; margin:20px auto; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; color:var(--wiz-text); }
            .hts-wizard-wrap * { box-sizing:border-box; }
            .hts-wiz-card { background:var(--wiz-surface); border:1px solid var(--wiz-border); border-radius:var(--wiz-radius); padding:32px; margin-bottom:20px; }
            .hts-wiz-title { font-size:28px; font-weight:700; margin:0 0 8px; }
            .hts-wiz-subtitle { color:var(--wiz-text-muted); font-size:15px; margin:0 0 24px; }
            .hts-wiz-step { display:none; }
            .hts-wiz-step.active { display:block; }

            /* Progress bar */
            .hts-wiz-progress { display:flex; gap:8px; margin-bottom:32px; }
            .hts-wiz-progress .step-dot { flex:1; height:4px; border-radius:2px; background:var(--wiz-border); transition:background .3s; }
            .hts-wiz-progress .step-dot.done { background:var(--wiz-accent); }
            .hts-wiz-progress .step-dot.current { background:var(--wiz-accent); animation:pulse-dot 1.5s infinite; }
            @keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:.5} }

            /* Plugin card */
            .hts-wiz-plugin { background:var(--wiz-surface2); border:1px solid var(--wiz-border); border-radius:8px; padding:20px; margin-bottom:16px; }
            .hts-wiz-plugin-name { font-size:18px; font-weight:600; margin:0 0 12px; }
            .hts-wiz-stats { display:grid; grid-template-columns:1fr 1fr; gap:8px 16px; }
            .hts-wiz-stat { display:flex; justify-content:space-between; font-size:13px; padding:4px 0; }
            .hts-wiz-stat .label { color:var(--wiz-text-muted); }
            .hts-wiz-stat .value { font-weight:600; font-variant-numeric:tabular-nums; }

            /* Import progress */
            .hts-wiz-import-item { display:flex; align-items:center; gap:12px; padding:10px 0; border-bottom:1px solid var(--wiz-border); }
            .hts-wiz-import-item:last-child { border-bottom:none; }
            .hts-wiz-import-item .icon { font-size:18px; width:28px; text-align:center; }
            .hts-wiz-import-item .name { flex:1; font-size:14px; }
            .hts-wiz-import-item .status { font-size:13px; font-weight:600; min-width:80px; text-align:right; }
            .hts-wiz-import-item .status.pending { color:var(--wiz-text-dim); }
            .hts-wiz-import-item .status.running { color:var(--wiz-warning); }
            .hts-wiz-import-item .status.done { color:var(--wiz-success); }
            .hts-wiz-import-item .status.skip { color:var(--wiz-text-dim); }

            /* Progress bar inline */
            .hts-wiz-bar-wrap { width:100%; height:6px; background:var(--wiz-border); border-radius:3px; margin-top:16px; overflow:hidden; }
            .hts-wiz-bar { height:100%; background:var(--wiz-accent); border-radius:3px; transition:width .3s ease; width:0; }

            /* Checkbox list */
            .hts-wiz-check { display:flex; align-items:flex-start; gap:10px; padding:12px 16px; background:var(--wiz-surface2); border:1px solid var(--wiz-border); border-radius:8px; margin-bottom:10px; cursor:pointer; transition:border-color .2s; }
            .hts-wiz-check:hover { border-color:var(--wiz-accent); }
            .hts-wiz-check input { margin-top:2px; accent-color:var(--wiz-accent); }
            .hts-wiz-check .check-label { font-size:14px; font-weight:600; }
            .hts-wiz-check .check-desc { font-size:12px; color:var(--wiz-text-muted); margin-top:2px; }

            /* Buttons */
            .hts-wiz-btn { display:inline-flex; align-items:center; gap:8px; padding:12px 28px; border:none; border-radius:8px; font-size:15px; font-weight:600; cursor:pointer; transition:all .2s; }
            .hts-wiz-btn-primary { background:var(--wiz-accent); color:#0f1419; }
            .hts-wiz-btn-primary:hover { background:#9ae529; transform:translateY(-1px); }
            .hts-wiz-btn-primary:disabled { opacity:.5; cursor:not-allowed; transform:none; }
            .hts-wiz-btn-secondary { background:var(--wiz-surface2); color:var(--wiz-text); border:1px solid var(--wiz-border); }
            .hts-wiz-btn-secondary:hover { border-color:var(--wiz-text-muted); }
            .hts-wiz-btn-danger { background:rgba(239,68,68,0.15); color:var(--wiz-danger); border:1px solid rgba(239,68,68,0.3); }
            .hts-wiz-actions { display:flex; justify-content:space-between; align-items:center; margin-top:24px; }

            /* Summary */
            .hts-wiz-summary-grid { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin:20px 0; }
            .hts-wiz-summary-item { background:var(--wiz-surface2); border-radius:8px; padding:16px; text-align:center; }
            .hts-wiz-summary-item .num { font-size:28px; font-weight:700; color:var(--wiz-accent); }
            .hts-wiz-summary-item .lbl { font-size:12px; color:var(--wiz-text-muted); margin-top:4px; }

            /* Info box */
            .hts-wiz-info { background:rgba(59,130,246,0.1); border:1px solid rgba(59,130,246,0.25); border-radius:8px; padding:14px 18px; font-size:13px; color:var(--wiz-text-muted); margin:16px 0; }
            .hts-wiz-info strong { color:var(--wiz-text); }
            .hts-wiz-warn { background:rgba(245,158,11,0.1); border:1px solid rgba(245,158,11,0.25); border-radius:8px; padding:14px 18px; font-size:13px; color:var(--wiz-warning); margin:16px 0; }

            /* No competitor */
            .hts-wiz-empty { text-align:center; padding:48px 24px; }
            .hts-wiz-empty .emoji { font-size:48px; margin-bottom:16px; }
            .hts-wiz-empty p { color:var(--wiz-text-muted); max-width:400px; margin:8px auto; }

            /* Spinner */
            .hts-wiz-spinner { display:inline-block; width:16px; height:16px; border:2px solid var(--wiz-border); border-top-color:var(--wiz-accent); border-radius:50%; animation:hts-spin .6s linear infinite; }
            @keyframes hts-spin { to{transform:rotate(360deg)} }
            .hts-hidden { display:none !important; }

            /* Hide WP notices */
            .hts-migration-wizard .notice:not(.hts-notice) { display:none !important; }
        </style>

        <div class="wrap hts-migration-wizard">
        <div class="hts-wizard-wrap">

            <?php if ( isset( $_GET['from'] ) && $_GET['from'] === 'onboarding' ) : ?>
            <div style="margin-bottom:16px;">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-onboarding&step=2' ) ); ?>" style="color:var(--wiz-text-muted,#9da5b4);font-size:12px;text-decoration:none;">← Retour à la configuration</a>
            </div>
            <?php endif; ?>

            <!-- Progress dots -->
            <div class="hts-wiz-progress">
                <div class="step-dot current" data-step="1"></div>
                <div class="step-dot" data-step="2"></div>
                <div class="step-dot" data-step="3"></div>
                <div class="step-dot" data-step="4"></div>
                <div class="step-dot" data-step="5"></div>
            </div>

            <!-- ═══ STEP 1: DETECTION ═══ -->
            <div class="hts-wiz-step active" id="wiz-step-1">
                <div class="hts-wiz-card">
 <div class="hts-wiz-title"> Migration Wizard</div>
                    <div class="hts-wiz-subtitle">Importez vos données SEO en 1 clic, sans rien perdre.</div>
                    <div id="wiz-detect-loading" style="text-align:center;padding:32px;">
                        <span class="hts-wiz-spinner"></span>
                        <p style="color:var(--wiz-text-muted);margin-top:12px;">Détection des plugins SEO…</p>
                        <p id="wiz-detect-status" style="color:var(--wiz-accent);font-size:11px;margin-top:4px;min-height:16px;"></p>
                    </div>
                    <div id="wiz-detect-results" class="hts-hidden"></div>
                    <div id="wiz-detect-empty" class="hts-hidden">
                        <div class="hts-wiz-empty">
 <div class="emoji"></div>
                            <div class="hts-wiz-title" style="font-size:20px;">Aucun autre plugin SEO détecté</div>
                            <p>HTS est le seul plugin SEO actif. Pas besoin de migration !</p>
                            <a href="<?php echo esc_url( admin_url('admin.php?page=hts-seo-tools') ); ?>" class="hts-wiz-btn hts-wiz-btn-primary hts-mt-4">Aller aux Outils SEO →</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ═══ STEP 2: IMPORT ═══ -->
            <div class="hts-wiz-step" id="wiz-step-2">
                <div class="hts-wiz-card">
 <div class="hts-wiz-title"> Import des données</div>
                    <div class="hts-wiz-subtitle">Vos données SEO sont copiées dans HTS. L'original reste intact.</div>
                    <div id="wiz-import-list"></div>
                    <div class="hts-wiz-bar-wrap"><div class="hts-wiz-bar" id="wiz-import-bar"></div></div>
                    <div id="wiz-import-status" style="text-align:center;margin-top:12px;font-size:13px;color:var(--wiz-text-muted);"></div>
                    <div class="hts-wiz-actions">
                        <button class="hts-wiz-btn hts-wiz-btn-secondary" onclick="htsWizard.goStep(1)">← Retour</button>
                        <button class="hts-wiz-btn hts-wiz-btn-primary" id="wiz-btn-start-import">Lancer l'import →</button>
                        <button class="hts-wiz-btn hts-wiz-btn-primary hts-hidden" id="wiz-btn-next-2" onclick="htsWizard.goStep(3)">Continuer →</button>
                    </div>
                </div>
            </div>

            <!-- ═══ STEP 3: TAKEOVER ═══ -->
            <div class="hts-wiz-step" id="wiz-step-3">
                <div class="hts-wiz-card">
 <div class="hts-wiz-title"> Qui gère quoi ?</div>
                    <div class="hts-wiz-subtitle">Choisissez les features que Hack The SEO prend en charge. Modifiable à tout moment.</div>
                    <div id="wiz-takeover-list">
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="sitemaps" checked>
                            <div>
                                <div class="check-label">Sitemaps XML</div>
                                <div class="check-desc">Sitemaps IA avec structure cocon sémantique (recommandé)</div>
                            </div>
                        </label>
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="redirects" checked>
                            <div>
                                <div class="check-label">Redirections 301/302</div>
                                <div class="check-desc" id="wiz-redir-desc">Redirections importées + Monitor 404 + AI Semantic Redirect</div>
                            </div>
                        </label>
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="robots_meta" checked>
                            <div>
                                <div class="check-label">Robots Meta / Noindex</div>
                                <div class="check-desc">Règles importées + suggestions IA business-safe + Crawl Budget</div>
                            </div>
                        </label>
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="canonical" checked>
                            <div>
                                <div class="check-label">Canonical URLs</div>
                                <div class="check-desc">Anti-cannibalisation IA 6 couches + détection automatique</div>
                            </div>
                        </label>
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="schema" checked>
                            <div>
                                <div class="check-label">Schema / JSON-LD</div>
                                <div class="check-desc">Article complet + FAQ + HowTo + VideoObject + Speakable (remplace l'ancien plugin)</div>
                            </div>
                        </label>
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="meta_title" checked>
                            <div>
                                <div class="check-label">Meta Title & Description</div>
                                <div class="check-desc">Lecture cascade Hack The SEO → ancien plugin → auto. Résolution des variables %title%, %sitename%</div>
                            </div>
                        </label>
                        <label class="hts-wiz-check">
                            <input type="checkbox" name="takeover[]" value="opengraph" checked>
                            <div>
                                <div class="check-label">Open Graph & Twitter Cards</div>
                                <div class="check-desc">og:title, og:description, og:image, og:url, Twitter Cards avec image</div>
                            </div>
                        </label>
                    </div>
                    <div class="hts-wiz-info">
 <strong> À l'étape suivante</strong>, vous pourrez désactiver l'ancien plugin SEO directement depuis cet assistant. Toutes les features cochées seront gérées par Hack The SEO.
                    </div>
                    <div class="hts-wiz-actions">
                        <button class="hts-wiz-btn hts-wiz-btn-secondary" onclick="htsWizard.goStep(2)">← Retour</button>
                        <button class="hts-wiz-btn hts-wiz-btn-primary" id="wiz-btn-apply-takeover">Appliquer →</button>
                    </div>
                </div>
            </div>

            <!-- ═══ STEP 4: DEACTIVATE COMPETITOR ═══ -->
            <div class="hts-wiz-step" id="wiz-step-4">
                <div class="hts-wiz-card">
 <div class="hts-wiz-title"> Désactiver l'ancien plugin SEO</div>
                    <div class="hts-wiz-subtitle">Hack The SEO gère maintenant tout le SEO. Pour éviter les conflits, désactivez l'ancien plugin.</div>

                    <div class="hts-wiz-warn" style="margin-bottom:20px;">
 <strong> Pourquoi c'est important :</strong><br>
                        Deux plugins SEO actifs = meta titles en double, canonical en conflit, schema dupliqué, sitemaps en double.
                        Toutes vos données ont été importées dans Hack The SEO — l'ancien plugin n'est plus nécessaire.
                    </div>

                    <div id="wiz-deactivate-target" style="background:var(--wiz-surface2);border:1px solid var(--wiz-border);border-radius:8px;padding:20px;margin-bottom:16px;">
                        <div style="display:flex;align-items:center;justify-content:space-between;">
                            <div>
                                <div style="font-weight:600;font-size:16px;" id="wiz-deactivate-name">Ancien plugin SEO</div>
                                <div style="font-size:13px;color:var(--wiz-text-muted);margin-top:4px;">Sera désactivé (pas supprimé). Vous pouvez le réactiver à tout moment.</div>
                            </div>
                            <button class="hts-wiz-btn hts-wiz-btn-danger" id="wiz-btn-deactivate" onclick="deactivateCompetitor()" style="white-space:nowrap;">
 Désactiver
                            </button>
                        </div>
                    </div>

                    <div id="wiz-deactivate-result" class="hts-hidden"></div>

                    <div class="hts-wiz-info">
 <strong> Bon à savoir :</strong> Les données de l'ancien plugin restent en base. Si vous réactivez l'ancien plugin plus tard, rien n'est perdu.
                        Vous pouvez aussi le faire manuellement dans Extensions → Plugins installés.
                    </div>

                    <div class="hts-wiz-actions">
                        <button class="hts-wiz-btn hts-wiz-btn-secondary" onclick="htsWizard.goStep(3)">← Retour</button>
                        <button class="hts-wiz-btn hts-wiz-btn-primary" id="wiz-btn-skip-deactivate" onclick="htsWizard.goStep(5)">Passer cette étape →</button>
                    </div>
                </div>
            </div>

            <!-- ═══ STEP 5: DONE ═══ -->
            <div class="hts-wiz-step" id="wiz-step-5">
                <div class="hts-wiz-card hts-text-center">
 <div style="font-size:48px;margin-bottom:16px;"></div>
                    <div class="hts-wiz-title">Migration terminée !</div>
                    <div class="hts-wiz-subtitle">Hack The SEO est configuré et opérationnel.</div>
                    <div class="hts-wiz-summary-grid" id="wiz-summary"></div>
                    <div id="wiz-not-imported" style="text-align:left;margin-top:16px;padding:16px;background:var(--wiz-surface2);border-radius:8px;font-size:13px;display:none;">
 <div style="font-weight:600;color:var(--wiz-warning);margin-bottom:8px;">Non importé (géré différemment par Hack The SEO) :</div>
                        <ul style="margin:0;padding-left:20px;color:var(--wiz-text-muted);line-height:1.8;">
                            <li><strong>Analytics intégré</strong> — Hack The SEO utilise GSC directement, pas de tracker in-plugin</li>
                            <li><strong>Keyword Rank Tracker</strong> — Les données de position viennent de GSC</li>
                            <li><strong>Rôles utilisateurs SEO</strong> — Hack The SEO utilise les capabilities WordPress natives</li>
                            <li><strong>Réglages de performance</strong> — Pas de lazy load/minify, utilisez un plugin dédié (WP Rocket, etc.)</li>
                            <li><strong>Liens sociaux / profils</strong> — Gérés par le thème ou un plugin social</li>
                        </ul>
                    </div>
                    <div id="wiz-competitor-warn" class="hts-text-left"></div>
                    <div style="margin-top:24px;display:flex;gap:12px;justify-content:center;">
                        <?php
                        $from_onboarding = isset( $_GET['from'] ) && $_GET['from'] === 'onboarding';
                        if ( $from_onboarding ) : ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-onboarding&step=3' ) ); ?>" class="hts-wiz-btn hts-wiz-btn-primary">← Continuer la configuration</a>
                        <?php else : ?>
                        <a href="<?php echo esc_url( admin_url('admin.php?page=hts-light-dashboard') ); ?>" class="hts-wiz-btn hts-wiz-btn-primary">Démarrer →</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
        </div>

        <script>
        (function(){
            'use strict';

            const AJAX = '<?php echo esc_url( admin_url("admin-ajax.php") ); ?>';
            const NONCE = '<?php echo esc_js( $nonce ); ?>';

            // State
            let detectedPlugins = {};
            let primaryPlugin = '';
            let importResults = {};
            let currentStep = 1;

            const $ = s => document.querySelector(s);
            const $$ = s => document.querySelectorAll(s);

            /* ─── AJAX helper ─── */
            async function post(action, data = {}) {
                const fd = new FormData();
                fd.append('action', action);
                fd.append('nonce', NONCE);
                for (const [k,v] of Object.entries(data)) {
                    if (Array.isArray(v)) {
                        v.forEach(i => fd.append(k + '[]', i));
                    } else {
                        fd.append(k, v);
                    }
                }
                const r = await fetch(AJAX, { method:'POST', body:fd });
                return r.json();
            }

            /* ─── Step navigation ─── */
            function goStep(n) {
                currentStep = n;
                $$('.hts-wiz-step').forEach(el => el.classList.remove('active'));
                const target = document.getElementById('wiz-step-' + n);
                if (target) target.classList.add('active');
                $$('.step-dot').forEach((dot, i) => {
                    dot.className = 'step-dot';
                    if (i + 1 < n) dot.classList.add('done');
                    if (i + 1 === n) dot.classList.add('current');
                });
                // Show "non importé" info on completion step
                if (n === 5) {
                    const ni = document.getElementById('wiz-not-imported');
                    if (ni) ni.style.display = 'block';
                }
            }

            /* ─── STEP 1: Detect ─── */
            async function detect() {
                var loadEl = $('#wiz-detect-loading');
                var statusEl = $('#wiz-detect-status');
                function setStatus(msg) {
                    if (statusEl) statusEl.textContent = msg;
                }

                try {
                    setStatus('Connexion au serveur…');
                    const fd = new FormData();
                    fd.append('action', 'hts_wizard_detect');
                    fd.append('nonce', NONCE);

                    setStatus('Envoi de la requête…');
                    const controller = new AbortController();
                    const timeout = setTimeout(() => controller.abort(), 20000);
                    const r = await fetch(AJAX, { method:'POST', body:fd, signal:controller.signal });
                    clearTimeout(timeout);

                    setStatus('Réponse reçue (HTTP ' + r.status + '), lecture…');
                    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + r.statusText);

                    const rawText = await r.text();
                    setStatus('Analyse de la réponse (' + rawText.length + ' car.)…');

                    var res;
                    try { res = JSON.parse(rawText); } catch(pe) {
                        throw new Error('Réponse serveur invalide. Début: ' + rawText.substring(0, 100));
                    }

                    if (!res.success) {
                        throw new Error(res.data || 'Erreur serveur inconnue');
                    }

                    if (!res.data || Object.keys(res.data).length === 0) {
                        setStatus('Aucun plugin SEO détecté');
                        loadEl.style.display = 'none';
                        $('#wiz-detect-empty').classList.remove('hts-hidden');
                        return;
                    }

                    setStatus('Plugin(s) trouvé(s) : ' + Object.keys(res.data).join(', '));
                    detectedPlugins = res.data;
                    primaryPlugin = Object.keys(detectedPlugins)[0];

                    try {
                        renderDetection();
                    } catch(renderErr) {
                        throw new Error('Erreur affichage : ' + renderErr.message);
                    }
                } catch(err) {
                    var errMsg = err.name === 'AbortError'
                        ? 'Le serveur ne répond pas (20s). Vérifiez que WP-Cron fonctionne et qu\'aucun plugin de sécurité ne bloque les requêtes AJAX.'
                        : err.message;
                    loadEl.innerHTML =
                        '<div style="text-align:center;padding:24px;">' +
                        '<div style="font-size:32px;margin-bottom:12px;">⚠️</div>' +
                        '<p style="font-weight:600;color:var(--wiz-text,#fff);margin-bottom:8px;">Erreur de détection</p>' +
                        '<p style="font-size:12px;color:var(--wiz-text-muted,#9da5b4);margin-bottom:16px;">' + errMsg + '</p>' +
                        '<button class="hts-wiz-btn hts-wiz-btn-primary" onclick="location.reload()">🔄 Réessayer</button>' +
                        ' <a href="' + AJAX + '?action=hts_wizard_detect&nonce=' + NONCE + '" target="_blank" class="hts-wiz-btn" style="background:var(--wiz-surface2);">Tester manuellement</a>' +
                        '</div>';
                }
            }

            function renderDetection() {
                let html = '';
                for (const [slug, info] of Object.entries(detectedPlugins)) {
                    const c = info.counts;
                    html += `<div class="hts-wiz-plugin">
 <div class="hts-wiz-plugin-name"> ${info.name}</div>
                        <div class="hts-wiz-stats">
                            <div class="hts-wiz-stat"><span class="label">Meta titles</span><span class="value">${c.meta_titles}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Meta descriptions</span><span class="value">${c.meta_descs}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Robots (noindex)</span><span class="value">${c.robots}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Canonical URLs</span><span class="value">${c.canonical}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Focus keywords</span><span class="value">${c.focus_kw}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Pillar pages</span><span class="value">${c.pillar}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Redirections</span><span class="value">${c.redirections}</span></div>
                            <div class="hts-wiz-stat"><span class="label">Open Graph</span><span class="value">${c.og_titles}</span></div>
                        </div>
                    </div>`;
                }
                html += `<div class="hts-wiz-info">
 <strong> Ce que Hack The SEO va faire :</strong><br>
                    • Meta titles & descriptions → <strong>copiés dans Hack The SEO</strong><br>
                    • Robots meta, canonical, focus keywords, pillar → <strong>copiés</strong><br>
                    • Open Graph & social → <strong>copiés</strong><br>
                    • Redirections → <strong>importées</strong><br>
                    • Réglages globaux (templates, séparateur, social) → <strong>importés</strong><br>
                    • Puis : <strong>désactivation guidée de l'ancien plugin SEO</strong>
                </div>`;
                html += `<div class="hts-wiz-actions">
                    <div></div>
                    <button class="hts-wiz-btn hts-wiz-btn-primary" onclick="htsWizard.goStep(2)">Commencer l'import →</button>
                </div>`;

                $('#wiz-detect-loading').style.display = 'none';
                var resultsEl = $('#wiz-detect-results');
                resultsEl.classList.remove('hts-hidden');
                resultsEl.innerHTML = html;
            }

            /* ─── STEP 2: Import ─── */
            const IMPORT_TASKS = [
 { key:'meta_title', label:'Meta Titles', icon:'' },
 { key:'meta_desc', label:'Meta Descriptions', icon:'' },
 { key:'robots', label:'Robots Meta (noindex/nofollow)', icon:'' },
 { key:'canonical', label:'Canonical URLs', icon:'' },
 { key:'focus_kw', label:'Focus Keywords', icon:'' },
 { key:'pillar', label:'Pillar / Cornerstone Pages', icon:'' },
 { key:'og', label:'Open Graph / Social', icon:'' },
                { key:'redirects',  label:'Redirections 301/302',           icon:'↪' },
 { key:'globals', label:'Réglages globaux (templates)', icon:'' },
            ];

            function renderImportList() {
                const c = detectedPlugins[primaryPlugin]?.counts || {};
                let html = '';
                const countMap = {
                    meta_title: c.meta_titles || 0,
                    meta_desc: c.meta_descs || 0,
                    robots: c.robots || 0,
                    canonical: c.canonical || 0,
                    focus_kw: c.focus_kw || 0,
                    pillar: c.pillar || 0,
                    og: c.og_titles || 0,
                    redirects: c.redirections || 0,
                    globals: 1, // always 1 — it's a single operation
                };
                IMPORT_TASKS.forEach(t => {
                    const count = countMap[t.key] ?? 0;
                    const skip = count === 0 && t.key !== 'globals';
                    html += `<div class="hts-wiz-import-item" id="import-${t.key}">
                        <span class="icon">${t.icon}</span>
                        <span class="name">${t.label} <span style="color:var(--wiz-text-dim)">(${t.key === 'globals' ? 'auto' : count})</span></span>
                        <span class="status ${skip ? 'skip' : 'pending'}" id="import-status-${t.key}">${skip ? 'Aucune' : 'En attente'}</span>
                    </div>`;
                });
                $('#wiz-import-list').innerHTML = html;
            }

            async function runImport() {
                $('#wiz-btn-start-import').disabled = true;
                $('#wiz-btn-start-import').innerHTML = '<span class="hts-wiz-spinner"></span> Import en cours…';

                const c = detectedPlugins[primaryPlugin]?.counts || {};
                const countMap = {
                    meta_title: c.meta_titles || 0,
                    meta_desc: c.meta_descs || 0,
                    robots: c.robots || 0,
                    canonical: c.canonical || 0,
                    focus_kw: c.focus_kw || 0,
                    pillar: c.pillar || 0,
                    og: c.og_titles || 0,
                    redirects: c.redirections || 0,
                    globals: 1,
                };
                const total = Object.values(countMap).reduce((s, v) => s + v, 0);
                let done = 0;
                importResults = {};

                for (const task of IMPORT_TASKS) {
                    const count = countMap[task.key] ?? 0;
                    if (count === 0 && task.key !== 'globals') {
                        importResults[task.key] = { imported:0, skipped:0 };
                        continue;
                    }

                    const statusEl = document.getElementById('import-status-' + task.key);
                    statusEl.className = 'status running';
 statusEl.textContent = 'En cours…';

                    if (task.key === 'redirects') {
                        // Redirections: single call (not batched by offset)
                        const res = await post('hts_wizard_import_redirects', { plugin: primaryPlugin });
                        if (res.success) {
                            importResults[task.key] = res.data;
                            done += res.data.imported + res.data.skipped;
                            statusEl.className = 'status done';
                            let txt = `${res.data.imported} importées`;
                            if (res.data.errors > 0) txt += ` (${res.data.errors} erreurs)`;
 statusEl.textContent = txt;
                        } else {
                            statusEl.className = 'status skip';
 statusEl.textContent = 'Erreur';
                        }
                    } else if (task.key === 'globals') {
                        // Global settings: single call
                        const res = await post('hts_wizard_import_globals', { plugin: primaryPlugin });
                        if (res.success) {
                            importResults[task.key] = res.data;
                            done += (res.data.imported?.length || 0);
                            statusEl.className = 'status done';
 statusEl.textContent = ` ${res.data.imported?.length || 0} réglages`;
                        } else {
                            statusEl.className = 'status skip';
 statusEl.textContent = 'Aucun';
                        }
                    } else if (task.key === 'og') {
                        // OG: batch import og_title, og_desc, og_image, tw_title, tw_desc
                        const ogTypes = ['og_title','og_desc','og_image','tw_title','tw_desc'];
                        let totalOg = 0;
                        for (const ogType of ogTypes) {
                            let offset = 0, batchDone = false;
                            while (!batchDone) {
                                const res = await post('hts_wizard_import_batch', {
                                    plugin: primaryPlugin, data_type: ogType, offset: offset,
                                });
                                if (!res.success) { batchDone = true; break; }
                                totalOg += res.data.imported;
                                batchDone = res.data.done;
                                offset += <?php echo self::BATCH_SIZE; ?>;
                            }
                        }
                        importResults[task.key] = { imported: totalOg, skipped: 0 };
                        done += totalOg;
                        statusEl.className = 'status done';
 statusEl.textContent = totalOg > 0 ? ` ${totalOg} importés` : 'Aucun à importer';
                    } else {
                        // Meta: batched import
                        let offset = 0;
                        let totalImported = 0;
                        let totalSkipped = 0;
                        let batchDone = false;

                        while (!batchDone) {
                            const res = await post('hts_wizard_import_batch', {
                                plugin: primaryPlugin,
                                data_type: task.key,
                                offset: offset,
                            });
                            if (!res.success) { batchDone = true; break; }

                            totalImported += res.data.imported;
                            totalSkipped += res.data.skipped;
                            done += res.data.imported + res.data.skipped;
                            batchDone = res.data.done;
                            offset += <?php echo self::BATCH_SIZE; ?>;

                            // Update progress
 statusEl.textContent = ` ${totalImported}…`;
                            const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
                            $('#wiz-import-bar').style.width = pct + '%';
                            $('#wiz-import-status').textContent = `${pct}% — ${done}/${total} éléments traités`;
                        }

                        importResults[task.key] = { imported: totalImported, skipped: totalSkipped };
                        statusEl.className = 'status done';
 statusEl.textContent = totalImported > 0 ? ` ${totalImported} importés` : 'Aucun à importer';
                    }

                    // Update global bar
                    const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 100;
                    $('#wiz-import-bar').style.width = pct + '%';
                    $('#wiz-import-status').textContent = `${pct}% — Import terminé pour ${task.label}`;
                }

                // Done
                $('#wiz-import-bar').style.width = '100%';
 $('#wiz-import-status').innerHTML = '<strong style="color:var(--wiz-success)"> Import terminé !</strong>';
                $('#wiz-btn-start-import').style.display = 'none';
                $('#wiz-btn-next-2').classList.remove('hts-hidden');

                // Update redir desc
                const rr = importResults.redirects || {};
                if (rr.imported > 0) {
                    const el = $('#wiz-redir-desc');
                    if (el) el.textContent = `${rr.imported} redirections importées + Monitor 404 + AI Semantic Redirect`;
                }
            }

            /* ─── STEP 3: Takeover ─── */
            async function applyTakeover() {
                const checks = $$('input[name="takeover[]"]:checked');
                const features = Array.from(checks).map(c => c.value);

                $('#wiz-btn-apply-takeover').disabled = true;
                $('#wiz-btn-apply-takeover').innerHTML = '<span class="hts-wiz-spinner"></span> Application…';

                const res = await post('hts_wizard_apply_takeover', {
                    features: features,
                    plugin: primaryPlugin,
                });

                if (res.success) {
                    // Set competitor name for deactivation step
                    const competitorName = detectedPlugins[primaryPlugin]?.name || 'l\u0027ancien plugin';
                    const nameEl = $('#wiz-deactivate-name');
 if (nameEl) nameEl.textContent = ' ' + competitorName;
                    goStep(4); // → Deactivate step
                } else {
                    alert('Erreur lors de l\'application.');
                }
                $('#wiz-btn-apply-takeover').disabled = false;
                $('#wiz-btn-apply-takeover').textContent = 'Appliquer →';
            }

            /* ─── STEP 4: Deactivate Competitor ─── */
            async function deactivateCompetitor() {
                const btn = $('#wiz-btn-deactivate');
                btn.disabled = true;
                btn.innerHTML = '<span class="hts-wiz-spinner"></span> Désactivation…';

                const res = await post('hts_wizard_deactivate', { plugin: primaryPlugin });
                const resultEl = $('#wiz-deactivate-result');

                if (res.success) {
                    resultEl.className = 'hts-wiz-info';
 resultEl.innerHTML = `<strong> ${res.data.message}</strong><br>L\u0027ancien plugin est désactivé. Hack The SEO gère tout.`;
                    btn.style.display = 'none';
                    // Change skip button to continue
                    const skipBtn = $('#wiz-btn-skip-deactivate');
                    skipBtn.textContent = 'Terminer →';
                    skipBtn.className = 'hts-wiz-btn hts-wiz-btn-primary';
                } else {
                    resultEl.className = 'hts-wiz-warn';
 resultEl.innerHTML = `<strong> Erreur :</strong> ${res.data || 'Impossible de désactiver le plugin.'}
                        <br>Vous pouvez le faire manuellement : <a href="${'<?php echo esc_url( admin_url("plugins.php") ); ?>'}" target="_blank" style="color:var(--wiz-warning);">Extensions → Plugins</a>`;
                    btn.disabled = false;
 btn.textContent = 'Réessayer';
                }
            }
            window.deactivateCompetitor = deactivateCompetitor;

            /* ─── STEP 5: Summary ─── */
            function renderSummary(features) {
                const c = detectedPlugins[primaryPlugin]?.counts || {};
                const r = importResults;
                let html = '';

                html += `<div class="hts-wiz-summary-item"><div class="num">${(r.meta_title?.imported || 0)}</div><div class="lbl">Meta titles importés</div></div>`;
                html += `<div class="hts-wiz-summary-item"><div class="num">${(r.meta_desc?.imported || 0)}</div><div class="lbl">Meta descriptions importées</div></div>`;
                html += `<div class="hts-wiz-summary-item"><div class="num">${(r.robots?.imported || 0)}</div><div class="lbl">Robots meta importés</div></div>`;
                html += `<div class="hts-wiz-summary-item"><div class="num">${(r.redirects?.imported || 0)}</div><div class="lbl">Redirections migrées</div></div>`;
                html += `<div class="hts-wiz-summary-item"><div class="num">${(r.og?.imported || 0)}</div><div class="lbl">Open Graph importés</div></div>`;
                html += `<div class="hts-wiz-summary-item"><div class="num">${(r.canonical?.imported || 0) + (r.focus_kw?.imported || 0) + (r.pillar?.imported || 0)}</div><div class="lbl">Canonical + KW + Pillar</div></div>`;

                $('#wiz-summary').innerHTML = html;

                const competitorName = detectedPlugins[primaryPlugin]?.name || 'l\u0027ancien plugin';
                const warnEl = $('#wiz-competitor-warn');
                // Check if competitor was deactivated in step 4
                const deactivated = $('#wiz-btn-deactivate')?.style.display === 'none';
                if (deactivated) {
                    warnEl.className = 'hts-wiz-info';
 warnEl.innerHTML = `<strong> ${competitorName} désactivé.</strong> Hack The SEO gère tout le SEO technique. Migration complète !`;
                } else {
                    warnEl.className = 'hts-wiz-warn';
 warnEl.innerHTML = `<strong> ${competitorName} est toujours actif.</strong> Désactivez-le dans Extensions → Plugins pour éviter les conflits SEO.`;
                }
            }

            /* ─── Rollback ─── */
            async function rollback() {
                if (!confirm('Annuler la migration ?\n\nLes redirections importées seront supprimées.\nLes meta importées resteront (non-destructif).')) return;
                const res = await post('hts_wizard_rollback');
                if (res.success) {
                    alert('Rollback effectué. La page va se recharger.');
                    location.reload();
                }
            }

            /* ─── Init ─── */
            // Step navigation override
            const origGoStep = goStep;
            window.htsWizard = {
                goStep: function(n) {
                    origGoStep(n);
                    if (n === 2) renderImportList();
                    if (n === 5) {
                        const checks = $$('input[name="takeover[]"]:checked');
                        const features = Array.from(checks).map(c => c.value);
                        renderSummary(features);
                    }
                },
                rollback: rollback,
            };

            // Event bindings
            document.addEventListener('DOMContentLoaded', function() {
                $('#wiz-btn-start-import')?.addEventListener('click', runImport);
                $('#wiz-btn-apply-takeover')?.addEventListener('click', applyTakeover);
            });

            // Auto-detect on load
            detect();

        })();
        </script>
        <?php
    }
}
