<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS GSC Connect — Google Search Console (Proxy SaaS + Direct OAuth fallback)
 *
 * Flow Proxy (si hts_api_key existe) :
 *   1. Click "Connecter" → plugin demande l'URL au SaaS → redirect Google
 *   2. Google callback vers SaaS → SaaS stocke tokens → redirect WP
 *   3. Plugin vérifie status via SaaS, fetch data via SaaS proxy
 *
 * Flow Direct (fallback, si pas d'api_key) :
 *   1. User enters Client ID + Client Secret
 *   2. OAuth direct vers Google
 *
 * @since 1.9.0
 * @updated 1.22.0 — Ajout mode proxy SaaS
 */

class HTS_GSC_Connect {

    const TABLE_VERSION = '2.0';
    const NONCE_ACTION  = 'hts_gsc_admin';
    const SCOPE         = 'https://www.googleapis.com/auth/webmasters.readonly https://www.googleapis.com/auth/userinfo.email';
    const TOKEN_URL     = 'https://oauth2.googleapis.com/token';
    const AUTH_URL      = 'https://accounts.google.com/o/oauth2/v2/auth';
    const API_BASE      = 'https://www.googleapis.com/webmasters/v3/sites/';
    const USERINFO_URL  = 'https://www.googleapis.com/oauth2/v2/userinfo';

    private static $ctr_curve = array(
        1 => 27.6, 2 => 15.8, 3 => 11.0,
        4 => 8.4,  5 => 6.3,  6 => 4.9,
        7 => 3.9,  8 => 3.3,  9 => 2.7, 10 => 2.4,
    );

    /* ══════════════════════════════════════════════════
     *  PROXY HELPERS
     * ══════════════════════════════════════════════════ */

    /**
     * Détecte si on est en mode proxy (api_key configurée).
     */
    private function is_proxy_mode() {
        return ! empty( $this->get_api_key() );
    }

    private function get_api_key() {
        return get_option( 'hts_api_key', '' );
    }

    private function get_api_base() {
        return rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' );
    }

    /**
     * Appel API SaaS générique.
     *
     * @param string $endpoint  Ex: '/api/gsc/status'
     * @param string $method    'GET' ou 'POST'
     * @param array  $body      Données POST (optionnel)
     * @return array|WP_Error   Réponse décodée ou WP_Error
     */
    private function proxy_request( $endpoint, $method = 'GET', $body = array() ) {
        $url = $this->get_api_base() . $endpoint;
        $args = array(
            'timeout' => 30,
            'headers' => array(
                'X-API-KEY'    => $this->get_api_key(),
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ),
        );

        if ( $method === 'POST' ) {
            $args['body'] = wp_json_encode( $body );
            $resp = wp_remote_post( $url, $args );
        } else {
            $resp = wp_remote_get( $url, $args );
        }

        if ( is_wp_error( $resp ) ) {
            return $resp;
        }

        $code = wp_remote_retrieve_response_code( $resp );
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_error', 'Réponse GSC JSON invalide: ' . json_last_error_msg() );
        }

        if ( $code >= 400 ) {
            $msg = $data['error'] ?? $data['message'] ?? 'Erreur HTTP ' . $code;
            return new WP_Error( 'proxy_error', $msg );
        }

        return $data;
    }

    /* ══════════════════════════════════════════════════
     *  INIT
     * ══════════════════════════════════════════════════ */

    public function init() {
        if ( get_option( 'hts_module_gsc', '1' ) !== '1' ) return;

        add_action( 'admin_init', array( $this, 'maybe_create_table' ) );
        add_action( 'admin_init', array( $this, 'handle_oauth_callback' ), 5 );

        add_action( 'wp_ajax_hts_gsc_save_keys',   array( $this, 'ajax_save_keys' ) );
        add_action( 'wp_ajax_hts_gsc_connect',      array( $this, 'ajax_connect' ) );
        add_action( 'wp_ajax_hts_gsc_disconnect',    array( $this, 'ajax_disconnect' ) );
        add_action( 'wp_ajax_hts_gsc_list_sites',    array( $this, 'ajax_list_sites' ) );
        add_action( 'wp_ajax_hts_gsc_select_site',   array( $this, 'ajax_select_site' ) );
        add_action( 'wp_ajax_hts_gsc_fetch_now',     array( $this, 'ajax_fetch_now' ) );
        add_action( 'wp_ajax_hts_gsc_data',          array( $this, 'ajax_get_data' ) );

        add_action( 'hts_gsc_daily_fetch', array( $this, 'cron_fetch' ) );
        if ( ! wp_next_scheduled( 'hts_gsc_daily_fetch' ) && $this->is_connected() ) {
            wp_schedule_event( time() + 3600, 'daily', 'hts_gsc_daily_fetch' );
        }

        // Sync scores + GSC data to SaaS after GSC import
        add_action( 'hts_gsc_import_complete', array( __CLASS__, 'sync_to_saas_after_import' ), 5 );
    }

    /* ══════════════════════════════════════════════════
     *  TABLE
     * ══════════════════════════════════════════════════ */

    public function maybe_create_table() {
        if ( version_compare( get_option( 'hts_gsc_table_version', '0' ), self::TABLE_VERSION, '>=' ) ) return;
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ── Table pages (existante) ──
        $t = $wpdb->prefix . 'hts_gsc_data';
        $sql = "CREATE TABLE {$t} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            url VARCHAR(500) NOT NULL,
            fetch_date DATE NOT NULL,
            clicks INT UNSIGNED NOT NULL DEFAULT 0,
            impressions INT UNSIGNED NOT NULL DEFAULT 0,
            ctr DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            position DECIMAL(5,1) NOT NULL DEFAULT 0.0,
            PRIMARY KEY (id),
            UNIQUE KEY idx_url_date (url(191), fetch_date),
            KEY idx_post_date (post_id, fetch_date),
            KEY idx_date (fetch_date)
        ) {$c};";
        dbDelta( $sql );

        // ── Table queries (nouvelle v2.0) ──
        $tq = $wpdb->prefix . 'hts_gsc_queries';
        $sql2 = "CREATE TABLE {$tq} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            url VARCHAR(500) NOT NULL,
            query VARCHAR(500) NOT NULL,
            fetch_date DATE NOT NULL,
            clicks INT UNSIGNED NOT NULL DEFAULT 0,
            impressions INT UNSIGNED NOT NULL DEFAULT 0,
            ctr DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            position DECIMAL(5,1) NOT NULL DEFAULT 0.0,
            PRIMARY KEY (id),
            UNIQUE KEY idx_url_query_date (url(120), query(120), fetch_date),
            KEY idx_post_date (post_id, fetch_date),
            KEY idx_query (query(191)),
            KEY idx_date (fetch_date)
        ) {$c};";
        dbDelta( $sql2 );

        update_option( 'hts_gsc_table_version', self::TABLE_VERSION, false );
    }

    private function table() {
        global $wpdb;
        return $wpdb->prefix . 'hts_gsc_data';
    }

    private function queries_table() {
        global $wpdb;
        return $wpdb->prefix . 'hts_gsc_queries';
    }

    /* ══════════════════════════════════════════════════
     *  DOMAIN MATCHING HELPERS
     * ══════════════════════════════════════════════════ */

    /**
     * Extrait le domaine nu (sans www, sans schéma) à partir d'une URL ou sc-domain.
     */
    private function extract_bare_domain( $input ) {
        // sc-domain:example.com → example.com
        if ( strpos( $input, 'sc-domain:' ) === 0 ) {
            return strtolower( substr( $input, 10 ) );
        }
        // https://www.example.com/ → example.com
        $host = wp_parse_url( $input, PHP_URL_HOST );
        if ( ! $host ) return strtolower( $input );
        return strtolower( preg_replace( '/^www\./i', '', $host ) );
    }

    /**
     * Auto-match : trouve le site GSC qui correspond à ce WordPress.
     * Gère www/non-www, http/https, sc-domain vs URL property.
     *
     * @param array $sites Liste des sites GSC [{url, level}]
     * @return string|false URL GSC matchée ou false
     */
    private function auto_match_site( $sites ) {
        $wp_domain = $this->extract_bare_domain( home_url() );

        // Priorité 1 : sc-domain exact
        foreach ( $sites as $s ) {
            if ( $this->extract_bare_domain( $s['url'] ) === $wp_domain ) {
                if ( strpos( $s['url'], 'sc-domain:' ) === 0 ) {
                    return $s['url'];
                }
            }
        }

        // Priorité 2 : URL property avec même domaine (https d'abord)
        $https_match = false;
        $http_match  = false;
        foreach ( $sites as $s ) {
            if ( $this->extract_bare_domain( $s['url'] ) === $wp_domain ) {
                if ( strpos( $s['url'], 'https://' ) === 0 ) {
                    $https_match = $s['url'];
                } elseif ( strpos( $s['url'], 'http://' ) === 0 ) {
                    $http_match = $s['url'];
                }
            }
        }
        if ( $https_match ) return $https_match;
        if ( $http_match )  return $http_match;

        return false;
    }

    /* ══════════════════════════════════════════════════
     *  CREDENTIALS (direct mode only)
     * ══════════════════════════════════════════════════ */

    private function get_client_id()     { return get_option( 'hts_gsc_client_id', '' ); }
    private function get_client_secret() { return get_option( 'hts_gsc_client_secret', '' ); }

    private function get_redirect_uri() {
        return admin_url( 'admin.php?page=hts-api-settings&stab=connexions' );
    }

    /* ══════════════════════════════════════════════════
     *  STATUS
     * ══════════════════════════════════════════════════ */

    public function is_connected() {
        if ( $this->is_proxy_mode() ) {
            $meta = get_option( 'hts_gsc_meta', array() );
            return ! empty( $meta['proxy_connected'] );
        }
        $t = get_option( 'hts_gsc_tokens', array() );
        return ! empty( $t['access_token'] ) && ! empty( $t['refresh_token'] );
    }

    public function get_connection_status() {
        // En proxy, refresh le status depuis le SaaS (max 1x / 5 min)
        if ( $this->is_proxy_mode() ) {
            $this->maybe_refresh_proxy_status();
        }

        $meta = get_option( 'hts_gsc_meta', array() );
        return array(
            'connected'  => $this->is_connected(),
            'site_url'   => $meta['site_url'] ?? '',
            'last_fetch' => $meta['last_fetch'] ?? null,
            'email'      => $meta['email'] ?? '',
            'has_keys'   => $this->is_proxy_mode() || ( ! empty( $this->get_client_id() ) && ! empty( $this->get_client_secret() ) ),
            'proxy_mode' => $this->is_proxy_mode(),
        );
    }

    /**
     * Refresh le status proxy depuis le SaaS (cache 5 min).
     */
    private function maybe_refresh_proxy_status() {
        $cache_key = 'hts_gsc_proxy_status_check';
        if ( get_transient( $cache_key ) ) return;

        $data = $this->proxy_request( '/api/gsc/status' );
        if ( is_wp_error( $data ) ) return;

        $meta = get_option( 'hts_gsc_meta', array() );
        $meta['proxy_connected'] = ! empty( $data['connected'] );
        $meta['email']           = $data['email'] ?? ( $meta['email'] ?? '' );
        $meta['site_url']        = $data['selected_site'] ?? ( $meta['site_url'] ?? '' );
        if ( ! empty( $data['last_fetch'] ) ) {
            $meta['last_fetch'] = $data['last_fetch'];
        }
        update_option( 'hts_gsc_meta', $meta, false );

        set_transient( $cache_key, 1, 300 ); // 5 min cache
    }

    /* ══════════════════════════════════════════════════
     *  AJAX: SAVE KEYS (direct mode only)
     * ══════════════════════════════════════════════════ */

    public function ajax_save_keys() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        $cid = isset( $_POST['client_id'] )     ? sanitize_text_field( $_POST['client_id'] )     : '';
        $csc = isset( $_POST['client_secret'] ) ? sanitize_text_field( $_POST['client_secret'] ) : '';

        if ( empty( $cid ) || empty( $csc ) ) {
            wp_send_json_error( array( 'message' => 'Client ID et Client Secret requis.' ) );
        }

        update_option( 'hts_gsc_client_id', $cid, false );
        update_option( 'hts_gsc_client_secret', $csc, false );

        wp_send_json_success( array( 'message' => 'Cl&eacute;s enregistr&eacute;es.' ) );
    }

    /* ══════════════════════════════════════════════════
     *  AJAX: START OAUTH — Proxy ou Direct
     * ══════════════════════════════════════════════════ */

    public function ajax_connect() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        // ── MODE PROXY ──
        if ( $this->is_proxy_mode() ) {
            // Envoyer l'URL de retour pour que le SaaS redirige vers le bon WordPress
            $return_url = admin_url( 'admin.php?page=hts-api-settings&stab=connexions&hts_gsc_proxy_connected=1' );

            $data = $this->proxy_request( '/api/gsc/auth-url', 'POST', array(
                'return_url' => $return_url,
            ) );

            if ( is_wp_error( $data ) ) {
                wp_send_json_error( array( 'message' => 'Erreur SaaS : ' . $data->get_error_message() ) );
            }

            if ( empty( $data['url'] ) ) {
                wp_send_json_error( array( 'message' => 'URL de connexion non reçue du serveur.' ) );
            }

            wp_send_json_success( array( 'redirect' => $data['url'] ) );
            return;
        }

        // ── MODE DIRECT (fallback) ──
        $cid = $this->get_client_id();
        if ( empty( $cid ) ) {
            wp_send_json_error( array( 'message' => 'Client ID manquant.' ) );
        }

        $state = wp_create_nonce( 'hts_gsc_oauth_state' );
        set_transient( 'hts_gsc_oauth_state', $state, 600 );

        $url = self::AUTH_URL . '?' . http_build_query( array(
            'client_id'     => $cid,
            'redirect_uri'  => $this->get_redirect_uri(),
            'response_type' => 'code',
            'scope'         => self::SCOPE,
            'access_type'   => 'offline',
            'prompt'        => 'consent',
            'state'         => $state,
        ) );

        wp_send_json_success( array( 'redirect' => $url ) );
    }

    /* ══════════════════════════════════════════════════
     *  OAUTH CALLBACK (admin_init)
     * ══════════════════════════════════════════════════ */

    public function handle_oauth_callback() {
        if ( ! isset( $_GET['page'] ) ) return;
        if ( ! in_array( $_GET['page'], array( 'hts-seo-settings', 'hts-api-settings' ), true ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        // ── PROXY CALLBACK ──
        if ( isset( $_GET['hts_gsc_proxy_connected'] ) ) {
            // Le SaaS a redirigé ici après un OAuth réussi
            delete_transient( 'hts_gsc_proxy_status_check' ); // Force refresh

            // Récupérer le status immédiatement depuis le SaaS
            if ( $this->is_proxy_mode() ) {
                $data = $this->proxy_request( '/api/gsc/status' );
                if ( ! is_wp_error( $data ) && ! empty( $data['connected'] ) ) {
                    $meta = get_option( 'hts_gsc_meta', array() );
                    $meta['proxy_connected'] = true;
                    $meta['email']           = $data['email'] ?? '';
                    $meta['site_url']        = $data['selected_site'] ?? '';
                    $meta['connected_at']    = current_time( 'mysql' );

                    // Auto-match domaine si pas déjà sélectionné
                    if ( empty( $meta['site_url'] ) ) {
                        $sites = $this->list_sites();
                        if ( ! is_wp_error( $sites ) ) {
                            $matched = $this->auto_match_site( $sites );
                            if ( $matched ) {
                                $meta['site_url'] = $matched;
                                // Notifier aussi le SaaS du choix
                                $this->proxy_request( '/api/gsc/select-site', 'POST', array( 'site_url' => $matched ) );
                            }
                        }
                    }

                    update_option( 'hts_gsc_meta', $meta, false );

                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( 'GSC proxy connecté (' . ( $data['email'] ?? '' ) . ') → ' . ( $meta['site_url'] ?: 'pas de site matché' ), 'success', 'gsc' );
                    }

                    // Schedule cron
                    if ( ! wp_next_scheduled( 'hts_gsc_daily_fetch' ) ) {
                        wp_schedule_event( time() + 300, 'daily', 'hts_gsc_daily_fetch' );
                    }

                    // Fetch immédiat pour avoir des données tout de suite
                    // Asynchrone via single event pour ne pas bloquer le redirect
                    wp_schedule_single_event( time(), 'hts_gsc_daily_fetch' );
                    spawn_cron();
                }
            }

            // Redirect propre (enlever le param de l'URL)
            wp_safe_redirect( admin_url( 'admin.php?page=hts-api-settings&stab=connexions&hts_gsc_connected=1' ) );
            exit;
        }

        // ── DIRECT CALLBACK (code Google) ──
        if ( ! isset( $_GET['code'] ) ) return;

        $code  = sanitize_text_field( $_GET['code'] );
        $state = isset( $_GET['state'] ) ? sanitize_text_field( $_GET['state'] ) : '';

        // CSRF check
        $saved = get_transient( 'hts_gsc_oauth_state' );
        if ( empty( $saved ) || $state !== $saved ) {
            $this->add_admin_error( 'État OAuth invalide. Retentez la connexion.' );
            return;
        }
        delete_transient( 'hts_gsc_oauth_state' );

        // Exchange code → tokens
        $resp = wp_remote_post( self::TOKEN_URL, array(
            'timeout' => 30,
            'body'    => array(
                'code'          => $code,
                'client_id'     => $this->get_client_id(),
                'client_secret' => $this->get_client_secret(),
                'redirect_uri'  => $this->get_redirect_uri(),
                'grant_type'    => 'authorization_code',
            ),
        ) );

        if ( is_wp_error( $resp ) ) {
            $this->add_admin_error( 'Erreur réseau : ' . $resp->get_error_message() );
            return;
        }

        $http_code = wp_remote_retrieve_response_code( $resp );
        if ( $http_code < 200 || $http_code >= 300 ) {
            $this->add_admin_error( 'Google OAuth erreur HTTP ' . $http_code );
            return;
        }

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            $this->add_admin_error( 'Réponse OAuth JSON invalide: ' . json_last_error_msg() );
            return;
        }

        if ( isset( $body['error'] ) ) {
            $this->add_admin_error( 'Google : ' . ( $body['error_description'] ?? $body['error'] ) );
            return;
        }

        if ( empty( $body['access_token'] ) ) {
            $this->add_admin_error( 'Pas de token reçu.' );
            return;
        }

        // Store tokens
        update_option( 'hts_gsc_tokens', array(
            'access_token'  => $body['access_token'],
            'refresh_token' => $body['refresh_token'] ?? '',
            'expires_at'    => time() + (int) ( $body['expires_in'] ?? 3600 ),
        ), false );

        // Fetch user email
        $email = $this->fetch_user_email( $body['access_token'] );

        update_option( 'hts_gsc_meta', array(
            'email'        => $email,
            'site_url'     => '',
            'last_fetch'   => null,
            'connected_at' => current_time( 'mysql' ),
        ), false );

        // Schedule cron
        if ( ! wp_next_scheduled( 'hts_gsc_daily_fetch' ) ) {
            wp_schedule_event( time() + 300, 'daily', 'hts_gsc_daily_fetch' );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC connecte direct (' . $email . ')', 'success', 'gsc' );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=hts-api-settings&stab=connexions&hts_gsc_connected=1' ) );
        exit;
    }

    private function add_admin_error( $msg ) {
        add_action( 'admin_notices', function() use ( $msg ) {
            echo '<div class="notice notice-error"><p><strong>Hack The SEO GSC :</strong> ' . esc_html( $msg ) . '</p></div>';
        } );
    }

    private function fetch_user_email( $token ) {
        $r = wp_remote_get( self::USERINFO_URL, array(
            'headers' => array( 'Authorization' => 'Bearer ' . $token ),
            'timeout' => 10,
        ) );
        if ( is_wp_error( $r ) ) return '';
        $d = json_decode( wp_remote_retrieve_body( $r ), true );
        return $d['email'] ?? '';
    }

    /* ══════════════════════════════════════════════════
     *  DISCONNECT — Proxy ou Direct
     * ══════════════════════════════════════════════════ */

    public function ajax_disconnect() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        // Proxy : notifier le SaaS
        if ( $this->is_proxy_mode() ) {
            $this->proxy_request( '/api/gsc/disconnect', 'POST' );
        }

        // Nettoyage local (commun aux deux modes)
        delete_option( 'hts_gsc_tokens' );
        $meta = get_option( 'hts_gsc_meta', array() );
        $meta['proxy_connected'] = false;
        $meta['email'] = '';
        $meta['site_url'] = '';
        update_option( 'hts_gsc_meta', $meta, false );
        delete_transient( 'hts_gsc_proxy_status_check' );
        wp_clear_scheduled_hook( 'hts_gsc_daily_fetch' );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC deconnecte', 'warning', 'gsc' );
        }

        wp_send_json_success( array( 'message' => 'Deconnecte.' ) );
    }

    /* ══════════════════════════════════════════════════
     *  LIST + SELECT SITE — Proxy ou Direct
     * ══════════════════════════════════════════════════ */

    public function ajax_list_sites() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        $sites = $this->list_sites();
        if ( is_wp_error( $sites ) ) {
            wp_send_json_error( array( 'message' => $sites->get_error_message() ) );
        }

        // Auto-match
        $auto = $this->auto_match_site( $sites );

        wp_send_json_success( array( 'sites' => $sites, 'auto_match' => $auto ? $auto : '' ) );
    }

    public function list_sites() {
        // ── PROXY ──
        if ( $this->is_proxy_mode() ) {
            $data = $this->proxy_request( '/api/gsc/sites', 'POST' );
            if ( is_wp_error( $data ) ) return $data;
            return $data['sites'] ?? array();
        }

        // ── DIRECT ──
        $token = $this->get_access_token();
        if ( ! $token ) return new WP_Error( 'no_token', 'Token invalide.' );

        $r = wp_remote_get( 'https://www.googleapis.com/webmasters/v3/sites', array(
            'headers' => array( 'Authorization' => 'Bearer ' . $token ),
            'timeout' => 15,
        ) );
        if ( is_wp_error( $r ) ) return $r;

        $body = json_decode( wp_remote_retrieve_body( $r ), true );
        if ( isset( $body['error'] ) ) {
            return new WP_Error( 'api', $body['error']['message'] ?? 'Erreur API' );
        }

        $sites = array();
        foreach ( ( $body['siteEntry'] ?? array() ) as $e ) {
            $sites[] = array( 'url' => $e['siteUrl'] ?? '', 'level' => $e['permissionLevel'] ?? '' );
        }
        return $sites;
    }

    public function ajax_select_site() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        $raw = isset( $_POST['site_url'] ) ? sanitize_text_field( wp_unslash( $_POST['site_url'] ) ) : '';
        if ( empty( $raw ) ) wp_send_json_error( array( 'message' => 'URL requise.' ) );

        // GSC renvoie soit "sc-domain:example.com" soit "https://example.com/"
        if ( preg_match( '/^sc-domain:[a-z0-9.-]+\.[a-z]{2,}$/i', $raw ) ) {
            $url = $raw; // Format domain property — garder tel quel
        } else {
            $url = esc_url_raw( $raw );
            if ( empty( $url ) ) wp_send_json_error( array( 'message' => 'URL invalide.' ) );
        }

        // Proxy : aussi notifier le SaaS
        if ( $this->is_proxy_mode() ) {
            $this->proxy_request( '/api/gsc/select-site', 'POST', array( 'site_url' => $url ) );
        }

        $meta = get_option( 'hts_gsc_meta', array() );
        $meta['site_url'] = $url;
        update_option( 'hts_gsc_meta', $meta, false );

        wp_send_json_success( array( 'message' => 'Site selectionne.' ) );
    }

    /* ══════════════════════════════════════════════════
     *  TOKEN REFRESH (direct mode only)
     * ══════════════════════════════════════════════════ */

    private function get_access_token() {
        $t = get_option( 'hts_gsc_tokens', array() );
        if ( empty( $t['access_token'] ) ) return false;

        // Still valid
        if ( isset( $t['expires_at'] ) && time() < ( $t['expires_at'] - 60 ) ) {
            return $t['access_token'];
        }

        // Refresh
        if ( empty( $t['refresh_token'] ) ) return false;

        $r = wp_remote_post( self::TOKEN_URL, array(
            'timeout' => 15,
            'body'    => array(
                'refresh_token' => $t['refresh_token'],
                'client_id'     => $this->get_client_id(),
                'client_secret' => $this->get_client_secret(),
                'grant_type'    => 'refresh_token',
            ),
        ) );
        if ( is_wp_error( $r ) ) return false;

        $code = wp_remote_retrieve_response_code( $r );
        if ( $code < 200 || $code >= 300 ) return false;

        $b = json_decode( wp_remote_retrieve_body( $r ), true );
        if ( empty( $b['access_token'] ) ) return false;

        $t['access_token'] = $b['access_token'];
        $t['expires_at']   = time() + (int) ( $b['expires_in'] ?? 3600 );
        update_option( 'hts_gsc_tokens', $t, false );

        return $t['access_token'];
    }

    /* ══════════════════════════════════════════════════
     *  API FETCH — Proxy ou Direct
     * ══════════════════════════════════════════════════ */

    public function fetch_from_api( $start, $end, $limit = 5000, $dimensions = array( 'page' ) ) {
        $meta = get_option( 'hts_gsc_meta', array() );
        $site = $meta['site_url'] ?? '';
        if ( empty( $site ) ) $site = trailingslashit( home_url() );

        // ── PROXY ──
        if ( $this->is_proxy_mode() ) {
            $data = $this->proxy_request( '/api/gsc/query', 'POST', array(
                'site_url'   => $site,
                'start_date' => $start,
                'end_date'   => $end,
                'dimensions' => $dimensions,
                'row_limit'  => $limit,
            ) );

            if ( is_wp_error( $data ) ) return $data;

            return $data['rows'] ?? array();
        }

        // ── DIRECT ──
        $token = $this->get_access_token();
        if ( ! $token ) return new WP_Error( 'no_token', 'Token invalide. Reconnectez GSC.' );

        $api = self::API_BASE . urlencode( $site ) . '/searchAnalytics/query';

        $r = wp_remote_post( $api, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'timeout' => 30,
            'body'    => wp_json_encode( array(
                'startDate'  => $start,
                'endDate'    => $end,
                'dimensions' => $dimensions,
                'rowLimit'   => $limit,
            ) ),
        ) );

        if ( is_wp_error( $r ) ) return $r;

        $code = wp_remote_retrieve_response_code( $r );
        $body = json_decode( wp_remote_retrieve_body( $r ), true );

        if ( $code === 401 || $code === 403 ) {
            return new WP_Error( 'auth', 'Acces refuse (HTTP ' . $code . '). Verifiez que le site est verifie dans GSC.' );
        }
        if ( isset( $body['error'] ) ) {
            return new WP_Error( 'api', $body['error']['message'] ?? 'Erreur API (HTTP ' . $code . ')' );
        }

        return $body['rows'] ?? array();
    }

    public function store_api_data( $rows, $fetch_date ) {
        global $wpdb;
        $table = $this->table();
        $count = 0;
        $seen_posts = array();

        // Sprint Robustesse v2: snapshot positions BEFORE overwriting (for trend detection)
        do_action( 'hts_gsc_import_start' );

        foreach ( $rows as $row ) {
            $url = $row['keys'][0] ?? '';
            if ( empty( $url ) ) continue;

            $clicks      = (int)   ( $row['clicks']      ?? 0 );
            $impressions = (int)   ( $row['impressions']  ?? 0 );
            $ctr         = round( (float) ( $row['ctr'] ?? 0 ) * 100, 2 );
            $position    = round( (float) ( $row['position'] ?? 0 ), 1 );

            $post_id = hts_url_to_postid( $url );
            if ( ! $post_id ) $post_id = hts_url_to_postid( rtrim( $url, '/' ) );

            $wpdb->query( $wpdb->prepare(
                "INSERT INTO {$table} (post_id, url, fetch_date, clicks, impressions, ctr, position)
                 VALUES (%d, %s, %s, %d, %d, %f, %f)
                 ON DUPLICATE KEY UPDATE
                    post_id = VALUES(post_id), clicks = VALUES(clicks),
                    impressions = VALUES(impressions), ctr = VALUES(ctr), position = VALUES(position)",
                $post_id, $url, $fetch_date, $clicks, $impressions, $ctr, $position
            ) );

            if ( $post_id ) {
                $seen_posts[ $post_id ] = true;
            }
            $count++;
        }

        // Refresh post_meta from 30-day aggregates (not raw row values)
        // This ensures post_meta always reflects the same window regardless of import scope
        if ( ! empty( $seen_posts ) ) {
            $this->refresh_post_meta_from_table( array_keys( $seen_posts ) );
        }

        $meta = get_option( 'hts_gsc_meta', array() );
        $meta['last_fetch'] = current_time( 'mysql' );
        $meta['last_rows']  = $count;
        update_option( 'hts_gsc_meta', $meta, false );

        return $count;
    }

    /**
     * Refresh post_meta from 30-day table aggregates.
     * Ensures _hts_gsc_clicks etc. always reflect the same window.
     */
    private function refresh_post_meta_from_table( $post_ids = array() ) {
        global $wpdb;
        $t = $this->table();
        $cutoff = gmdate( 'Y-m-d', strtotime( '-30 days' ) );

        if ( empty( $post_ids ) ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT post_id, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                        ROUND(AVG(position), 1) AS position, ROUND(AVG(ctr), 2) AS ctr
                 FROM {$t} WHERE fetch_date >= %s AND post_id > 0
                 GROUP BY post_id", $cutoff
            ) );
        } else {
            $ids = implode( ',', array_map( 'intval', $post_ids ) );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT post_id, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                        ROUND(AVG(position), 1) AS position, ROUND(AVG(ctr), 2) AS ctr
                 FROM {$t} WHERE fetch_date >= %s AND post_id IN ({$ids})
                 GROUP BY post_id", $cutoff
            ) );
        }

        foreach ( $rows as $r ) {
            $pid = (int) $r->post_id;
            if ( $pid <= 0 ) continue;
            update_post_meta( $pid, '_hts_gsc_clicks', (int) $r->clicks );
            update_post_meta( $pid, '_hts_gsc_impressions', (int) $r->impressions );
            update_post_meta( $pid, '_hts_gsc_position', (float) $r->position );
            update_post_meta( $pid, '_hts_gsc_ctr', (float) $r->ctr );
            // Alias for workflow engine compatibility (reads _30d variant)
            update_post_meta( $pid, '_hts_gsc_clicks_30d', (int) $r->clicks );
        }
    }

    /**
     * Stocke les données queries (dimension page+query).
     * Met aussi à jour _hts_gsc_top_query et hts_gsc_queries pour compatibilité Coach/Meta-Score.
     *
     * @param array  $rows       Résultat API avec keys[0]=page, keys[1]=query
     * @param string $fetch_date Date d'import
     * @return int Nombre de lignes insérées
     */
    public function store_query_data( $rows, $fetch_date ) {
        global $wpdb;
        $table = $this->queries_table();
        $count = 0;
        $top_queries_by_post = array(); // post_id => [ query => clicks ]

        foreach ( $rows as $row ) {
            $url   = $row['keys'][0] ?? '';
            $query = $row['keys'][1] ?? '';
            if ( empty( $url ) || empty( $query ) ) continue;

            $clicks      = (int)   ( $row['clicks']      ?? 0 );
            $impressions = (int)   ( $row['impressions']  ?? 0 );
            $ctr         = round( (float) ( $row['ctr'] ?? 0 ) * 100, 2 );
            $position    = round( (float) ( $row['position'] ?? 0 ), 1 );

            $post_id = hts_url_to_postid( $url );
            if ( ! $post_id ) $post_id = hts_url_to_postid( rtrim( $url, '/' ) );

            $wpdb->query( $wpdb->prepare(
                "INSERT INTO {$table} (post_id, url, query, fetch_date, clicks, impressions, ctr, position)
                 VALUES (%d, %s, %s, %s, %d, %d, %f, %f)
                 ON DUPLICATE KEY UPDATE
                    post_id = VALUES(post_id), clicks = VALUES(clicks),
                    impressions = VALUES(impressions), ctr = VALUES(ctr), position = VALUES(position)",
                $post_id, $url, $query, $fetch_date, $clicks, $impressions, $ctr, $position
            ) );

            // Track top query par post
            if ( $post_id ) {
                if ( ! isset( $top_queries_by_post[ $post_id ] ) ) {
                    $top_queries_by_post[ $post_id ] = array();
                }
                if ( ! isset( $top_queries_by_post[ $post_id ][ $query ] ) ) {
                    $top_queries_by_post[ $post_id ][ $query ] = 0;
                }
                $top_queries_by_post[ $post_id ][ $query ] += $clicks;
            }
            $count++;
        }

        // Mise à jour _hts_gsc_top_query pour chaque post (query avec le + de clics)
        foreach ( $top_queries_by_post as $pid => $queries ) {
            arsort( $queries );
            $top_query = array_key_first( $queries );
            if ( $top_query ) {
                update_post_meta( $pid, '_hts_gsc_top_query', $top_query );
                // Auto-suggest focus keyword from GSC top query (pages without manual keyword)
                if ( ! get_post_meta( $pid, '_hts_focus_keyword', true ) ) {
                    update_post_meta( $pid, '_hts_focus_keyword', sanitize_text_field( $top_query ) );
                    update_post_meta( $pid, '_hts_focus_keyword_source', 'gsc_auto' );
                }
            }
        }

        // Mise à jour hts_gsc_queries pour compatibilité Coach
        $this->update_gsc_queries_option();

        return $count;
    }

    /**
     * Met à jour l'option hts_gsc_queries (format Coach/Cockpit compatible).
     * Top 200 queries agrégées sur 30 jours.
     */
    private function update_gsc_queries_option() {
        global $wpdb;
        $tq = $this->queries_table();
        $cutoff = gmdate( 'Y-m-d', strtotime( '-30 days' ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT query, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_position, AVG(ctr) AS avg_ctr
             FROM {$tq} WHERE fetch_date >= %s
             GROUP BY query ORDER BY clicks DESC LIMIT 200", $cutoff
        ) );

        $data = array();
        foreach ( $rows as $r ) {
            $data[] = array(
                'query'       => $r->query,
                'clicks'      => (int) $r->clicks,
                'impressions' => (int) $r->impressions,
                'position'    => round( (float) $r->avg_position, 1 ),
                'ctr'         => round( (float) $r->avg_ctr, 2 ),
            );
        }
        update_option( 'hts_gsc_queries', $data, false );
    }

    /* ══════════════════════════════════════════════════
     *  CRON + MANUAL
     * ══════════════════════════════════════════════════ */

    public function cron_fetch() {
        $lock_key = 'hts_lock_gsc_fetch';
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, 120 );

        try {
        if ( ! $this->is_connected() ) {
            delete_transient( $lock_key );
            return;
        }

        // ── DEBUG: état de la table AVANT le cron ──
        global $wpdb;
        $count_before = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table()}" );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "GSC cron START: {$count_before} rows in table", 'info', 'gsc' );
        }

        $is_first = ! $this->has_data();
        $end      = gmdate( 'Y-m-d', strtotime( '-2 days' ) );

        if ( $is_first ) {
            // First run: 90 days page data (more historical context for Feedback Loop)
            $start = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
            if ( function_exists( 'hts_add_log' ) ) hts_add_log( 'GSC cron: first run', 'info', 'gsc' );
        } else {
            // Daily: single day = no double counting
            $start = $end;
        }

        // ── Pages ──
        $rows = $this->fetch_from_api( $start, $end, 5000, array( 'page' ) );
        if ( is_wp_error( $rows ) ) {
            if ( function_exists( 'hts_add_log' ) ) hts_add_log( 'GSC cron pages: ' . $rows->get_error_message(), 'error', 'gsc' );
            return;
        }
        $np = $this->store_api_data( $rows, $end );

        // ── Queries (page + query) ──
        $qrows = $this->fetch_from_api( $start, $end, 5000, array( 'page', 'query' ) );
        $nq = 0;
        if ( ! is_wp_error( $qrows ) ) {
            $nq = $this->store_query_data( $qrows, $end );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC cron: ' . $np . ' pages, ' . $nq . ' requetes' . ( $is_first ? ' (backfill 90j)' : '' ), 'success', 'gsc' );
        }
        $this->cleanup_old_data();

        // ── Snapshots for Coach timeseries ──
        if ( $is_first ) {
            $this->backfill_snapshots(); // 90 days via date dimension
        } else {
            $this->save_daily_snapshot( $end );
        }

        /**
         * Action: fired after GSC data import completes.
         *
         * @since 1.31.0
         * @param string $type Import type ('pages').
         */
        do_action( 'hts_gsc_import_complete', 'pages' );

        // ── DEBUG: état de la table APRÈS le cron ──
        $count_after = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table()}" );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "GSC cron END: {$count_after} rows (was {$count_before})", 'info', 'gsc' );
        }

        // Purge object cache pour que les prochaines requêtes DB soient fraîches
        if ( function_exists( 'wp_cache_flush' ) ) {
            wp_cache_flush();
        }

        delete_transient( $lock_key );
        } catch ( \Throwable $e ) {
            delete_transient( $lock_key );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'GSC cron_fetch CRASH: ' . $e->getMessage() . ' L' . $e->getLine(), 'error', 'gsc' );
            }
        }
    }

    /**
     * Save a daily snapshot of site-wide GSC metrics for Coach timeseries.
     */
    private function save_daily_snapshot( $date ) {
        global $wpdb;
        $t = $this->table();

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    ROUND(AVG(position), 1) AS avg_position
             FROM {$t} WHERE fetch_date = %s", $date
        ) );

        if ( ! $row || ! $row->clicks ) return;

        $snapshots = get_option( 'hts_gsc_snapshots', array() );
        if ( ! is_array( $snapshots ) ) $snapshots = array();

        // Deduplicate by date
        $snapshots = array_filter( $snapshots, function( $s ) use ( $date ) {
            return ( $s['date'] ?? '' ) !== $date;
        });

        $snapshots[] = array(
            'date'         => $date,
            'clicks'       => (int) $row->clicks,
            'impressions'  => (int) $row->impressions,
            'avg_position' => (float) $row->avg_position,
        );

        // Keep max 180 days of snapshots
        usort( $snapshots, function( $a, $b ) {
            return strcmp( $a['date'] ?? '', $b['date'] ?? '' );
        });
        $snapshots = array_slice( $snapshots, -180 );

        update_option( 'hts_gsc_snapshots', $snapshots, false );
    }

    /**
     * Backfill snapshots by calling GSC API with 'date' dimension.
     * Gets real daily totals (not from table which has aggregated data).
     */
    private function backfill_snapshots() {
        $end   = gmdate( 'Y-m-d', strtotime( '-2 days' ) );
        $start = gmdate( 'Y-m-d', strtotime( '-180 days' ) ); // Extended: GSC API supports 16 months

        // Fetch daily totals from GSC API (dimension=date, no page grouping = lightweight)
        $rows = $this->fetch_from_api( $start, $end, 500, array( 'date' ) );
        if ( is_wp_error( $rows ) || empty( $rows ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'GSC backfill_snapshots: ' . ( is_wp_error( $rows ) ? $rows->get_error_message() : 'no data' ), 'warn', 'gsc' );
            }
            return;
        }

        $snapshots = array();
        foreach ( $rows as $row ) {
            $date = $row['keys'][0] ?? '';
            if ( empty( $date ) ) continue;
            $snapshots[] = array(
                'date'         => $date,
                'clicks'       => (int) ( $row['clicks'] ?? 0 ),
                'impressions'  => (int) ( $row['impressions'] ?? 0 ),
                'avg_position' => round( (float) ( $row['position'] ?? 0 ), 1 ),
            );
        }

        if ( empty( $snapshots ) ) return;

        usort( $snapshots, function( $a, $b ) {
            return strcmp( $a['date'], $b['date'] );
        });

        update_option( 'hts_gsc_snapshots', array_slice( $snapshots, -180 ), false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC snapshots: ' . count( $snapshots ) . ' jours backfilled', 'success', 'gsc' );
        }
    }

    public function ajax_fetch_now() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );
        if ( ! $this->is_connected() ) wp_send_json_error( array( 'message' => 'GSC non connecte.' ) );

        // Transient lock to prevent concurrent fetches
        if ( get_transient( 'hts_gsc_fetch_lock' ) ) {
            wp_send_json_error( array( 'message' => 'Fetch déjà en cours.' ) );
        }
        set_transient( 'hts_gsc_fetch_lock', 1, 300 );

        global $wpdb;
        $end = gmdate( 'Y-m-d', strtotime( '-2 days' ) );

        // Page data: always 30 days (matches get_site_data query window)
        $start = gmdate( 'Y-m-d', strtotime( '-32 days' ) );

        // Clean table completely to prevent legacy double-counting
        $wpdb->query( "TRUNCATE TABLE {$this->table()}" );
        $wpdb->query( "TRUNCATE TABLE {$this->queries_table()}" );

        // ── Pages ──
        $rows = $this->fetch_from_api( $start, $end, 5000, array( 'page' ) );
        if ( is_wp_error( $rows ) ) wp_send_json_error( array( 'message' => $rows->get_error_message() ) );
        $np = $this->store_api_data( $rows, $end );

        // ── Queries (page + query) ──
        $qrows = $this->fetch_from_api( $start, $end, 5000, array( 'page', 'query' ) );
        $nq = 0;
        if ( ! is_wp_error( $qrows ) ) {
            $nq = $this->store_query_data( $qrows, $end );
        }

        /** This action is documented in class-hts-gsc-connect.php */
        do_action( 'hts_gsc_import_complete', 'pages' );

        // Snapshots: 90 days via date dimension (separate lightweight API call)
        $this->backfill_snapshots();

        delete_transient( 'hts_gsc_fetch_lock' );

        // Purge object cache pour que les prochaines requêtes DB soient fraîches
        if ( function_exists( 'wp_cache_flush' ) ) {
            wp_cache_flush();
        }
        if ( function_exists( 'rocket_clean_domain' ) ) {
            rocket_clean_domain();
        }

        wp_send_json_success( array(
            'message' => $np . ' pages + ' . $nq . ' requetes importees (30j). Snapshots 90j.',
            'rows'    => $np,
            'queries' => $nq,
        ) );
    }

    public function ajax_get_data() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );
        $days = isset( $_POST['period'] ) ? absint( $_POST['period'] ) : 30;
        $pid  = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
        wp_send_json_success( $pid ? $this->get_post_data( $pid, $days ) : $this->get_site_data( $days ) );
    }

    /* ══════════════════════════════════════════════════
     *  CLEANUP
     * ══════════════════════════════════════════════════ */

    public function cleanup_old_data() {
        global $wpdb;
        $cutoff = gmdate( 'Y-m-d', strtotime( '-13 months' ) );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$this->table()} WHERE fetch_date < %s", $cutoff
        ) );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$this->queries_table()} WHERE fetch_date < %s", $cutoff
        ) );
    }

    /* ══════════════════════════════════════════════════
     *  PUBLIC API
     * ══════════════════════════════════════════════════ */

    public function get_site_data( $days = 30 ) {
        global $wpdb;
        $t = $this->table();
        $c = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );

        $tot = $wpdb->get_row( $wpdb->prepare(
            "SELECT SQL_NO_CACHE SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_position, AVG(ctr) AS avg_ctr,
                    COUNT(DISTINCT url) AS pages
             FROM {$t} WHERE fetch_date >= %s", $c
        ) );

        $pc = gmdate( 'Y-m-d', strtotime( "-" . ( $days * 2 ) . " days" ) );
        $prev = $wpdb->get_row( $wpdb->prepare(
            "SELECT SQL_NO_CACHE SUM(clicks) AS clicks FROM {$t} WHERE fetch_date >= %s AND fetch_date < %s", $pc, $c
        ) );

        $cn = (int) ( $tot->clicks ?? 0 );
        $cp = (int) ( $prev->clicks ?? 0 );
        $trend = $cp > 0 ? round( ( $cn - $cp ) / $cp * 100, 1 ) : ( $cn > 0 ? 100 : 0 );

        // Position trend: compare current avg position vs previous period
        $prev_pos = $wpdb->get_row( $wpdb->prepare(
            "SELECT SQL_NO_CACHE AVG(position) AS avg_position FROM {$t} WHERE fetch_date >= %s AND fetch_date < %s", $pc, $c
        ) );
        $pos_cur  = round( (float) ( $tot->avg_position ?? 0 ), 1 );
        $pos_prev = round( (float) ( $prev_pos->avg_position ?? 0 ), 1 );
        $pos_trend = ( $pos_prev > 0 && $pos_cur > 0 ) ? round( $pos_cur - $pos_prev, 1 ) : 0;

        $top_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT url, post_id, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_position, AVG(ctr) AS avg_ctr
             FROM {$t} WHERE fetch_date >= %s
             GROUP BY url, post_id ORDER BY clicks DESC LIMIT 10", $c
        ) );
        $top = array();
        foreach ( $top_rows as $p ) {
            $top[] = array(
                'url'         => $p->url,
                'post_id'     => (int) $p->post_id,
                'title'       => $p->post_id ? get_the_title( $p->post_id ) : basename( untrailingslashit( $p->url ) ),
                'clicks'      => (int) $p->clicks,
                'impressions' => (int) $p->impressions,
                'position'    => round( (float) $p->avg_position, 1 ),
                'ctr'         => round( (float) $p->avg_ctr, 2 ),
            );
        }

        $daily = $wpdb->get_results( $wpdb->prepare(
            "SELECT fetch_date, SUM(clicks) AS clicks, SUM(impressions) AS impressions
             FROM {$t} WHERE fetch_date >= %s GROUP BY fetch_date ORDER BY fetch_date ASC", $c
        ) );

        // Fallback: if table has < 3 daily rows (bulk import stores 1 date), use snapshots
        if ( count( $daily ) < 3 ) {
            $snapshots = get_option( 'hts_gsc_snapshots', array() );
            if ( is_array( $snapshots ) && count( $snapshots ) >= 3 ) {
                $cutoff_ts = strtotime( "-{$days} days" );
                $daily = array();
                foreach ( $snapshots as $s ) {
                    if ( strtotime( $s['date'] ?? '' ) >= $cutoff_ts ) {
                        $obj = new \stdClass();
                        $obj->fetch_date   = $s['date'];
                        $obj->clicks       = $s['clicks'];
                        $obj->impressions  = $s['impressions'];
                        $daily[] = $obj;
                    }
                }
            }
        }

        return array(
            'clicks' => $cn, 'impressions' => (int) ( $tot->impressions ?? 0 ),
            'avg_position' => $pos_cur,
            'avg_ctr' => round( (float) ( $tot->avg_ctr ?? 0 ), 2 ),
            'pages' => (int) ( $tot->pages ?? 0 ), 'clicks_trend' => $trend,
            'position_trend' => $pos_trend,
            'top_pages' => $top, 'daily' => $daily,
        );
    }

    /**
     * Top queries depuis la table wp_hts_gsc_queries.
     *
     * @param int $days Nombre de jours à couvrir.
     * @return array Tableau de rows [query, clicks, impressions, position].
     */
    public function get_queries_data( $days = 30 ) {
        global $wpdb;
        $t = $this->queries_table();
        $c = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT query, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    ROUND(AVG(position), 1) AS position
             FROM {$t} WHERE fetch_date >= %s
             GROUP BY query ORDER BY clicks DESC LIMIT 20", $c
        ), ARRAY_A ) ?: array();
    }

    public function get_post_data( $post_id, $days = 30 ) {
        global $wpdb;
        $t = $this->table();
        $c = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );

        $d = $wpdb->get_row( $wpdb->prepare(
            "SELECT SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_position, AVG(ctr) AS avg_ctr
             FROM {$t} WHERE post_id = %d AND fetch_date >= %s", $post_id, $c
        ) );

        $daily = $wpdb->get_results( $wpdb->prepare(
            "SELECT fetch_date, clicks, impressions, position
             FROM {$t} WHERE post_id = %d AND fetch_date >= %s ORDER BY fetch_date ASC", $post_id, $c
        ) );

        return array(
            'clicks' => (int) ( $d->clicks ?? 0 ), 'impressions' => (int) ( $d->impressions ?? 0 ),
            'avg_position' => round( (float) ( $d->avg_position ?? 0 ), 1 ),
            'avg_ctr' => round( (float) ( $d->avg_ctr ?? 0 ), 2 ),
            'daily' => $daily,
        );
    }

    public function get_declining_pages( $threshold = 3.0 ) {
        global $wpdb;
        $t  = $this->table();
        $rs = gmdate( 'Y-m-d', strtotime( '-16 days' ) );
        $re = gmdate( 'Y-m-d', strtotime( '-2 days' ) );
        $ps = gmdate( 'Y-m-d', strtotime( '-30 days' ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT r.url, r.post_id, r.avg_pos AS pos_new, p.avg_pos AS pos_old,
                    (r.avg_pos - p.avg_pos) AS pos_drop
             FROM (SELECT url, post_id, AVG(position) AS avg_pos FROM {$t} WHERE fetch_date >= %s AND fetch_date <= %s GROUP BY url, post_id) r
             INNER JOIN (SELECT url, AVG(position) AS avg_pos FROM {$t} WHERE fetch_date >= %s AND fetch_date < %s GROUP BY url) p ON r.url = p.url
             WHERE (r.avg_pos - p.avg_pos) >= %f ORDER BY pos_drop DESC LIMIT 10",
            $rs, $re, $ps, $rs, $threshold
        ) );

        $out = array();
        foreach ( $rows as $d ) {
            $out[] = array(
                'url' => $d->url, 'post_id' => (int) $d->post_id,
                'title' => $d->post_id ? get_the_title( $d->post_id ) : basename( $d->url ),
                'position_old' => round( (float) $d->pos_old, 1 ),
                'position_new' => round( (float) $d->pos_new, 1 ),
                'drop' => round( (float) $d->pos_drop, 1 ),
            );
        }
        return $this->filter_results_by_lang( $out );
    }

    public function get_opportunity_pages( $limit = 10 ) {
        global $wpdb;
        $t = $this->table();
        $c = gmdate( 'Y-m-d', strtotime( '-30 days' ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT url, post_id, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_pos, AVG(ctr) AS avg_ctr
             FROM {$t} WHERE fetch_date >= %s GROUP BY url, post_id
             HAVING avg_pos >= 4 AND avg_pos <= 20 AND impressions >= 50
             ORDER BY impressions DESC LIMIT %d", $c, $limit
        ) );

        $out = array();
        foreach ( $rows as $p ) {
            $pc = min( 10, max( 1, round( (float) $p->avg_pos ) ) );
            $exp = self::$ctr_curve[ $pc ] ?? 1.5;
            $pot = round( (int) $p->impressions * ( $exp / 100 ) ) - (int) $p->clicks;
            $out[] = array(
                'url' => $p->url, 'post_id' => (int) $p->post_id,
                'title' => $p->post_id ? get_the_title( $p->post_id ) : basename( $p->url ),
                'position' => round( (float) $p->avg_pos, 1 ), 'impressions' => (int) $p->impressions,
                'clicks' => (int) $p->clicks, 'ctr' => round( (float) $p->avg_ctr, 2 ),
                'expected_ctr' => $exp, 'potential_clicks' => max( 0, $pot ),
            );
        }
        usort( $out, function( $a, $b ) { return $b['potential_clicks'] <=> $a['potential_clicks']; } );
        return $this->filter_results_by_lang( $out );
    }

    public function get_dashboard_stats() {
        if ( ! $this->is_connected() || ! $this->has_data() ) {
            return array( 'connected' => $this->is_connected(), 'has_data' => false, 'clicks' => 0, 'impressions' => 0, 'avg_position' => 0, 'clicks_trend' => 0 );
        }
        $d = $this->get_site_data( 30 );
        return array( 'connected' => true, 'has_data' => true, 'clicks' => $d['clicks'], 'impressions' => $d['impressions'], 'avg_position' => $d['avg_position'], 'avg_ctr' => $d['avg_ctr'], 'clicks_trend' => $d['clicks_trend'], 'pages' => $d['pages'] );
    }

    /**
     * Top queries pour un post spécifique sur N jours.
     */
    public function get_post_queries( $post_id, $days = 30, $limit = 20 ) {
        global $wpdb;
        $tq = $this->queries_table();
        $cutoff = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT query, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_position, AVG(ctr) AS avg_ctr
             FROM {$tq} WHERE post_id = %d AND fetch_date >= %s
             GROUP BY query ORDER BY clicks DESC LIMIT %d",
            $post_id, $cutoff, $limit
        ) );
    }

    /**
     * Top queries globales du site sur N jours.
     */
    public function get_top_queries( $days = 30, $limit = 50 ) {
        global $wpdb;
        $tq = $this->queries_table();
        $cutoff = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT query, SUM(clicks) AS clicks, SUM(impressions) AS impressions,
                    AVG(position) AS avg_position, AVG(ctr) AS avg_ctr,
                    COUNT(DISTINCT url) AS pages
             FROM {$tq} WHERE fetch_date >= %s
             GROUP BY query ORDER BY clicks DESC LIMIT %d",
            $cutoff, $limit
        ) );
    }

    /* ══════════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════════ */

    /**
     * Filter GSC results by current language (if multilingual).
     */
    private function filter_results_by_lang( $results ) {
        if ( ! class_exists( 'HTS_Language' ) || ! HTS_Language::is_multilingual() ) {
            return $results;
        }
        $lang = HTS_Language::get_current_lang();
        if ( ! $lang ) return $results;

        return array_values( array_filter( $results, function( $r ) use ( $lang ) {
            if ( ! empty( $r['post_id'] ) && (int) $r['post_id'] > 0 ) {
                $post_lang = HTS_Language::get_post_language( (int) $r['post_id'] );
                return ! $post_lang || $post_lang === $lang;
            }
            $url = $r['url'] ?? '';
            $prefix = '/' . $lang . '/';
            return empty( $url ) || strpos( $url, $prefix ) !== false;
        } ) );
    }

    public function has_data() {
        global $wpdb;
        $table = $this->table();
        // SQL_NO_CACHE — avoid stale object cache results
        $count = $wpdb->get_var( "SELECT SQL_NO_CACHE COUNT(*) FROM {$table}" );
        return (int) $count > 0;
    }

    public static function expected_ctr( $pos ) {
        $r = min( 10, max( 1, round( $pos ) ) );
        return self::$ctr_curve[ $r ] ?? 1.5;
    }

    /* ══════════════════════════════════════════════════
     *  SAAS SYNC (post-import)
     * ══════════════════════════════════════════════════ */

    /**
     * Sync post scores and GSC data to the SaaS after a GSC import.
     * Hooked on `hts_gsc_import_complete` at priority 5.
     *
     * @param string $type  Import type passed by the action.
     */
    public static function sync_to_saas_after_import( $type = '' ) {
        // Only proceed if a remote flag is active and client is available
        if ( ! class_exists( 'HTS_Remote_Client' ) || ! HTS_Remote_Client::has_active_flags() || ! HTS_Remote_Client::is_available() ) {
            return;
        }

        // P6 FIX: Transient lock to prevent parallel execution
        if ( get_transient( 'hts_saas_sync_running' ) ) {
            return;
        }
        set_transient( 'hts_saas_sync_running', true, 300 ); // 5 min max

        $scores = self::collect_post_scores();

        if ( empty( $scores ) ) {
            delete_transient( 'hts_saas_sync_running' );
            return;
        }

        // Determine lang from first score entry (or site default)
        $lang = '';
        foreach ( $scores as $s ) {
            if ( ! empty( $s['lang'] ) ) {
                $lang = $s['lang'];
                break;
            }
        }
        if ( empty( $lang ) && class_exists( 'HTS_Language' ) ) {
            $lang = HTS_Language::get_current_lang();
        }

        // P2 FIX: Batch post scores in chunks of 200 to avoid payload size limits
        $batches = array_chunk( $scores, 200 );
        foreach ( $batches as $batch ) {
            $result_scores = HTS_Remote_Client::call( 'sync/post-scores', array(
                'scores' => $batch,
                'lang'   => $lang,
            ) );
            if ( empty( $result_scores['success'] ) ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'GSC sync: post-scores batch failed — ' . ( isset( $result_scores['error'] ) ? $result_scores['error'] : 'unknown' ), 'warning', 'gsc-sync' );
                }
                break; // Stop on first batch failure
            }
        }
        $result_scores = isset( $result_scores ) ? $result_scores : array( 'success' => false );
        if ( empty( $result_scores['success'] ) && function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC sync: post-scores failed — ' . ( isset( $result_scores['error'] ) ? $result_scores['error'] : 'unknown' ), 'warning', 'gsc-sync' );
        }

        // 2. POST GSC metrics
        $gsc_data = array();
        foreach ( $scores as $s ) {
            $gsc_data[] = array(
                'post_id'           => $s['post_id'],
                'gsc_clicks'        => $s['gsc_clicks'],
                'gsc_impressions'   => $s['gsc_impressions'],
                'gsc_position'      => $s['gsc_position'],
                'gsc_position_prev' => $s['gsc_position_prev'],
                'post_title'        => $s['post_title'],
                'post_type'         => $s['post_type'],
                'lang'              => $s['lang'],
            );
        }
        // P5 FIX: Reduced timeout + no retry for sync operations
        $sync_opts = array( 'timeout' => 10, 'retries' => 1 );
        $result_gsc = HTS_Remote_Client::call( 'sync/gsc-data', array(
            'gsc'  => $gsc_data,
            'lang' => $lang,
        ), 'POST', $sync_opts );
        if ( empty( $result_gsc['success'] ) && function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC sync: gsc-data failed — ' . ( isset( $result_gsc['error'] ) ? $result_gsc['error'] : 'unknown' ), 'warning', 'gsc-sync' );
        }

        // 3. POST feedback measure
        $result_feedback = HTS_Remote_Client::call( 'feedback/measure', array(
            'lang' => $lang,
        ), 'POST', $sync_opts );
        if ( empty( $result_feedback['success'] ) && function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC sync: feedback/measure failed — ' . ( isset( $result_feedback['error'] ) ? $result_feedback['error'] : 'unknown' ), 'warning', 'gsc-sync' );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'GSC sync to SaaS completed (' . count( $scores ) . ' posts)', 'info', 'gsc-sync' );
        }

        // P6 FIX: Release the sync lock
        delete_transient( 'hts_saas_sync_running' );
    }

    /**
     * Collect all published post scores and GSC metrics.
     *
     * @return array  Array of score arrays for each published post.
     */
    public static function collect_post_scores() {
        // FIX 9: Bulk load post meta to avoid N+1 queries (7 × get_post_meta per post)
        $posts = get_posts( array(
            'post_type'        => array( 'post', 'page' ),
            'post_status'      => 'publish',
            'posts_per_page'   => 500,
            'suppress_filters' => false, // Polylang compatibility
        ) );

        if ( empty( $posts ) ) return array();

        // Bulk prime the meta cache for all post IDs in one query
        $post_ids = wp_list_pluck( $posts, 'ID' );
        update_meta_cache( 'post', $post_ids );

        $meta_keys = array(
            '_hts_meta_score', '_hts_onpage_score', '_hts_global_score',
            '_hts_gsc_clicks', '_hts_gsc_impressions', '_hts_gsc_position', '_hts_gsc_position_prev',
        );

        $scores = array();
        foreach ( $posts as $post ) {
            $pid = $post->ID;
            $lang = '';
            if ( function_exists( 'pll_get_post_language' ) ) {
                $lang = pll_get_post_language( $pid, 'slug' );
            }

            // get_post_meta reads from cache (primed above) — no extra queries
            $scores[] = array(
                'post_id'           => $pid,
                'meta_score'        => (int) get_post_meta( $pid, '_hts_meta_score', true ),
                'onpage_score'      => (int) get_post_meta( $pid, '_hts_onpage_score', true ),
                'global_score'      => (int) get_post_meta( $pid, '_hts_global_score', true ),
                'gsc_clicks'        => (int) get_post_meta( $pid, '_hts_gsc_clicks', true ),
                'gsc_impressions'   => (int) get_post_meta( $pid, '_hts_gsc_impressions', true ),
                'gsc_position'      => (float) get_post_meta( $pid, '_hts_gsc_position', true ),
                'gsc_position_prev' => (float) get_post_meta( $pid, '_hts_gsc_position_prev', true ),
                'post_title'        => $post->post_title,
                'post_type'         => $post->post_type,
                'post_status'       => 'publish',
                'lang'              => $lang,
            );
        }

        return $scores;
    }
}
