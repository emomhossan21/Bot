<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS API Receiver — Module de réception des données SaaS
 *
 * Brique commune aux 3 plans pricing (69€/119€/299€).
 * Reçoit articles et audits depuis app.hacktheseo.com via REST API.
 *
 * Endpoints :
 *   POST /wp-json/hts-seo-sync/update  → recevoir articles + audits
 *   GET  /wp-json/hts-seo-sync/test    → test connexion
 *
 * Sécurité :
 *   - Auth via header x-api-key (hash_equals timing-safe)
 *   - Articles toujours en DRAFT — jamais publish auto
 *   - Zéro écriture dans meta RM/Yoast/AIOSEO — uniquement _hts_*
 *   - Audit ne touche jamais contenu ni statut
 *
 * @package    Hack_The_SEO_Light
 * @since      1.1.0
 */

class HTS_API_Receiver {

    /** @var string Option name for the API key */
    const OPT_API_KEY = 'hts_api_key';

    /** @var string Option name for push history */
    const OPT_PUSH_HISTORY = 'hts_api_push_history';

    /** @var int Max entries in push history */
    const PUSH_HISTORY_LIMIT = 100;

    /** @var string REST namespace */
    const REST_NAMESPACE = 'hts-seo-sync';

    /**
     * Initialize hooks — called from plugins_loaded
     */
    public function init() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );

        // Allow our REST namespace even when REST API is restricted by security plugins
        add_filter( 'rest_authentication_errors', function( $result ) {
            // If another plugin already denied access, check if this is our namespace
            if ( is_wp_error( $result ) || $result === false ) {
                $request_uri = $_SERVER['REQUEST_URI'] ?? '';
                if ( strpos( $request_uri, '/' . self::REST_NAMESPACE . '/' ) !== false ) {
                    // Our namespace — clear the error, let our permission_callback handle auth
                    return true;
                }
            }
            return $result;
        }, 999 );

        add_action( 'admin_menu', array( $this, 'register_admin_page' ), 11 );
        add_action( 'wp_ajax_hts_clear_push_history', array( $this, 'ajax_clear_push_history' ) );

        // ── PULL sync (same as Full plugin) ──
        add_action( 'wp_ajax_hts_sync_articles', array( $this, 'ajax_sync_articles' ) );
        add_action( 'wp_ajax_hts_sync_corrections', array( $this, 'ajax_sync_corrections' ) );

        // ── Save default article status ──
        add_action( 'wp_ajax_hts_save_article_default_status', array( $this, 'ajax_save_article_default_status' ) );
    }

    /* =========================================================================
     * REST ROUTES
     * ====================================================================== */

    /**
     * Register REST API routes
     */
    public function register_routes() {
        register_rest_route( self::REST_NAMESPACE, '/update', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'handle_update' ),
            'permission_callback' => array( $this, 'verify_api_key' ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/test', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'handle_test' ),
            'permission_callback' => array( $this, 'verify_api_key' ),
        ) );
    }

    /**
     * Verify API key from request header (timing-safe)
     *
     * @param WP_REST_Request $request
     * @return true|WP_Error
     */
    public function verify_api_key( WP_REST_Request $request ) {
        $stored_key = get_option( self::OPT_API_KEY, '' );

        if ( empty( $stored_key ) ) {
            return new WP_Error(
                'hts_no_api_key',
                'Aucune clé API configurée sur ce site.',
                array( 'status' => 403 )
            );
        }

        // Accept both x-api-key and x_api_key (nginx may rewrite hyphens)
        $header_key = $request->get_header( 'x-api-key' );
        if ( empty( $header_key ) ) {
            $header_key = $request->get_header( 'x_api_key' );
        }

        // Also try Authorization: Bearer <key>
        if ( empty( $header_key ) ) {
            $auth = $request->get_header( 'authorization' );
            if ( $auth && stripos( $auth, 'Bearer ' ) === 0 ) {
                $header_key = substr( $auth, 7 );
            }
        }

        if ( empty( $header_key ) ) {
            // Debug: log all received headers for diagnostic
            hts_add_log( 'API key missing — headers reçus: ' . implode( ', ', array_keys( $request->get_headers() ) ), 'error', 'api' );
            return new WP_Error(
                'hts_missing_key',
                'Header x-api-key manquant.',
                array( 'status' => 401 )
            );
        }

        // Trim whitespace/newlines that may sneak in
        $stored_key = trim( $stored_key );
        $header_key = trim( $header_key );

        if ( ! hash_equals( $stored_key, $header_key ) ) {
            hts_add_log(
                sprintf(
                    'Clé API invalide depuis %s — stockée: %s…(%d chars) / reçue: %s…(%d chars)',
                    $this->get_client_ip(),
                    substr( $stored_key, 0, 8 ),
                    strlen( $stored_key ),
                    substr( $header_key, 0, 8 ),
                    strlen( $header_key )
                ),
                'error', 'api'
            );
            return new WP_Error(
                'hts_invalid_key',
                'Clé API invalide.',
                array( 'status' => 401 )
            );
        }

        return true;
    }

    /* =========================================================================
     * ENDPOINT: TEST
     * ====================================================================== */

    /**
     * GET /test — Connection test endpoint
     */
    public function handle_test( WP_REST_Request $request ) {
        return rest_ensure_response( array(
            'status'  => 'success',
            'message' => 'Connexion Hack The SEO fonctionnelle',
            'data'    => array(
                'plugin'         => 'hack-the-seo-light',
                'version'        => defined( 'HTS__VERSION' ) ? HTS__VERSION : 'unknown',
                'php_version'    => PHP_VERSION,
                'wp_version'     => get_bloginfo( 'version' ),
                'is_light'       => true,
                'multisite'      => is_multisite(),
                'timestamp'      => current_time( 'Y-m-d H:i:s' ),
                'multilingual'   => $this->detect_multilingual_plugin(),
                'languages'      => class_exists( 'HTS_Language' ) ? HTS_Language::get_available_languages() : array(),
                'default_lang'   => class_exists( 'HTS_Language' ) ? HTS_Language::get_site_default_lang() : substr( get_locale(), 0, 2 ),
                'timezone'       => wp_timezone_string(),
            ),
        ) );
    }

    /* =========================================================================
     * ENDPOINT: UPDATE (articles + audits)
     * ====================================================================== */

    /**
     * POST /update — Main webhook receiver
     */
    public function handle_update( WP_REST_Request $request ) {
        try {
            $body = $request->get_body();

            if ( empty( $body ) ) {
                return $this->api_error( 'Body vide', 400 );
            }

            $data = json_decode( $body, true );
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                return $this->api_error( 'JSON invalide: ' . json_last_error_msg(), 400 );
            }

            if ( ! is_array( $data ) ) {
                return $this->api_error( 'Format de données invalide', 400 );
            }

            $type = isset( $data['type'] ) ? sanitize_text_field( $data['type'] ) : 'article';

            hts_add_log( 'API push reçu — type: ' . $type . ' depuis ' . $this->get_client_ip(), 'info', 'api' );

            switch ( $type ) {
                case 'audit':
                    $result = $this->process_audit( $data );
                    break;

                case 'cocon_plan':
                    $result = $this->process_cocon_plan( $data );
                    break;

                case 'article':
                default:
                    $result = $this->process_article( $data );
                    break;
            }

            // Log push to history
            $this->log_push( $type, $result );

            return rest_ensure_response( array(
                'status'       => 'success',
                'data'         => $result,
                'processed_at' => current_time( 'Y-m-d H:i:s' ),
            ) );

        } catch ( Exception $e ) {
            hts_add_log( 'Erreur API: ' . $e->getMessage(), 'error', 'api' );
            return $this->api_error( $e->getMessage(), 500 );
        }
    }

    /* =========================================================================
     * ARTICLE PROCESSING — Via webhook (SaaS push)
     *
     * IMPORTANT: Le webhook crée TOUJOURS un nouveau brouillon.
     * PAS de dédup ici — la dédup est dans do_sync_articles() (PULL).
     *
     * Le Full avait un findOrCreatePost() qui cherchait par article_id_api
     * mais ça causait des écrasements quand un post existant matchait.
     * Fix: webhook = création pure, sync = dédup.
     * ====================================================================== */

    /**
     * Process incoming article — TOUJOURS créer un nouveau DRAFT
     *
     * @param array $data Payload from SaaS
     * @return array Result summary
     */
    private function process_article( array $data ) {

        // Title: h1 → metatitle → title → fallback
        $title = sanitize_text_field(
            $data['h1'] ?? $data['metatitle'] ?? $data['title'] ?? 'Nouveau article'
        );

        // Content: article → content → empty
        $content = wp_kses_post( $data['article'] ?? $data['content'] ?? '' );

        if ( empty( $title ) && empty( $content ) ) {
            throw new Exception( 'Article vide: ni titre ni contenu reçu.' );
        }

        $article_id_api = sanitize_text_field( $data['unique_id'] ?? '' );
        $default_status = get_option( 'hts_article_default_status', 'draft' );

        // ── TOUJOURS créer un nouveau post — jamais écraser ──
        $post_id = wp_insert_post( array(
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $default_status,
            'post_type'    => 'post',
            'post_author'  => $this->get_default_author(),
        ), true );

        if ( is_wp_error( $post_id ) ) {
            throw new Exception( 'Erreur wp_insert_post: ' . $post_id->get_error_message() );
        }

        // ── Tag HTS ──
        update_post_meta( $post_id, '_hts_api_generated', 1 );
        update_post_meta( $post_id, '_hts_api_received_at', current_time( 'Y-m-d H:i:s' ) );
        if ( ! empty( $article_id_api ) ) {
            update_post_meta( $post_id, 'article_id_api', $article_id_api );
        }

        hts_add_log(
            sprintf( 'Nouveau article %s — ID %d (uid: %s)', $default_status, $post_id, $article_id_api ?: 'aucun' ),
            'success',
            'api'
        );

        // ── SEO meta (both paths) ──
        $meta_title = $data['metatitle'] ?? $data['meta_title'] ?? '';
        if ( ! empty( $meta_title ) ) {
            update_post_meta( $post_id, '_hts_meta_title', sanitize_text_field( $meta_title ) );
        }

        // Meta description
        $meta_desc = $data['metadescription'] ?? $data['meta_description'] ?? '';
        if ( ! empty( $meta_desc ) ) {
            update_post_meta( $post_id, '_hts_meta_description', sanitize_text_field( $meta_desc ) );
        }

        // Focus keyword
        $keyword = $data['keyword'] ?? $data['focus_keyword'] ?? '';
        if ( ! empty( $keyword ) ) {
            update_post_meta( $post_id, '_hts_focus_keyword', sanitize_text_field( $keyword ) );
        }

        // ── SEO plugin meta (Yoast/RM/natif) ──
        $this->update_seo_plugin_meta( $post_id, $data );

        // ── Optional fields ──
        if ( ! empty( $data['cocon_id'] ) ) {
            update_post_meta( $post_id, '_hts_cocon_id', sanitize_text_field( $data['cocon_id'] ) );
        }
        if ( ! empty( $data['pillar_url'] ) ) {
            update_post_meta( $post_id, '_hts_pillar_url', esc_url_raw( $data['pillar_url'] ) );
        }

        // Category
        $category = $data['category'] ?? '';
        if ( ! empty( $category ) ) {
            $this->assign_category( $post_id, sanitize_text_field( $category ) );
        }

        // Featured image
        $image = $data['featured_image'] ?? '';
        if ( ! empty( $image ) ) {
            $this->sideload_featured_image( $post_id, esc_url_raw( $image ) );
        }

        // Language + translation linking
        $lang = $data['lang'] ?? '';
        if ( ! empty( $lang ) ) {
            $translation_of    = (int) ( $data['translation_of'] ?? 0 );
            $translation_group = sanitize_text_field( $data['translation_group'] ?? '' );
            $this->assign_language( $post_id, sanitize_text_field( $lang ), $translation_of, $translation_group );
        }

        $permalink = get_permalink( $post_id );

        // ── Mark received in Cocon Commander plan (if article belongs to a cocon) ──
        if ( ! empty( $data['cocon_id'] ) && class_exists( 'HTS_Cocon_Commander' ) ) {
            $commander = new HTS_Cocon_Commander();
            $kw = $data['keyword'] ?? $data['focus_keyword'] ?? '';
            if ( $kw ) {
                $commander->mark_received( sanitize_text_field( $data['cocon_id'] ), $kw, $post_id );
            }
        }

        // ── Article Pipeline — enrichissement (images, schemas, cross-links, stuffing) ──
        $pipeline_result = array();
        if ( class_exists( 'HTS_Article_Pipeline' ) ) {
            $pipeline_result = HTS_Article_Pipeline::enrich_draft( $post_id, $title, $keyword, $content );
        }

        return array(
            'action'       => 'article_created',
            'post_id'      => $post_id,
            'status'       => $default_status,
            'title'        => $title,
            'url'          => $permalink,
            'unique_id'    => $article_id_api,
            'pipeline'     => ! empty( $pipeline_result ) ? array(
                'images'      => $pipeline_result['images_count'] ?? 0,
                'cross_links' => $pipeline_result['cross_links'] ?? 0,
                'schemas'     => $pipeline_result['schemas'] ?? array(),
            ) : null,
        );
    }

    /* =========================================================================
     * COCON PLAN PROCESSING — Phase 6a.1
     *
     * SaaS sends a topical map plan with articles to generate.
     * ====================================================================== */

    /**
     * Process incoming cocon plan — store and pre-check.
     *
     * @param array $data Payload from SaaS
     * @return array Result summary
     */
    private function process_cocon_plan( array $data ) {
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) {
            throw new \Exception( 'Module Cocon Commander non disponible.' );
        }

        $commander = new HTS_Cocon_Commander();
        $plan = $commander->save_plan( $data );
        $stats = $commander->get_plan_stats( $plan['cocon_id'] );

        return array(
            'action'     => 'cocon_plan_saved',
            'cocon_id'   => $plan['cocon_id'],
            'articles'   => $plan['article_count'],
            'stats'      => $stats,
        );
    }

    /**
     * Write SEO data to active SEO plugin
     */
    private function update_seo_plugin_meta( int $post_id, array $data ) {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $metatitle   = $data['metatitle'] ?? $data['meta_title'] ?? '';
        $metadesc    = $data['metadescription'] ?? $data['meta_description'] ?? '';
        $keyword     = $data['keyword'] ?? $data['focus_keyword'] ?? '';

        // ── Yoast ──
        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            if ( $metatitle ) update_post_meta( $post_id, '_yoast_wpseo_title', sanitize_text_field( $metatitle ) );
            if ( $metadesc )  update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field( $metadesc ) );
            if ( $keyword )   update_post_meta( $post_id, '_yoast_wpseo_focuskw', sanitize_text_field( $keyword ) );
            return;
        }

        // ── Rank Math ──
        if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            if ( $metatitle ) update_post_meta( $post_id, 'rank_math_title', sanitize_text_field( $metatitle ) );
            if ( $metadesc )  update_post_meta( $post_id, 'rank_math_description', sanitize_textarea_field( $metadesc ) );
            if ( $keyword )   update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $keyword ) );
            return;
        }

        // ── AIOSEO ──
        // AIOSEO uses its own table, skip for now — _hts_* meta is already written above
    }

    /* =========================================================================
     * AUDIT PROCESSING — Compatible SaaS payload
     *
     * SaaS sends:  type="audit", reports[]{url, updated_results}, image[]
     * Full plugin:  processAuditData() → processSeoReports() + processImageAlts()
     * Light:        Same logic, same field names
     * ====================================================================== */

    /**
     * Process audit — update meta only, NEVER touch content or status
     * Calqué sur SeoManager::processAuditData()
     *
     * @param array $data Payload from SaaS
     * @return array Results
     */
    private function process_audit( array $data ) {
        $results = array();

        // ── SEO Reports (meta title, desc, keywords, OG, headings) ──
        if ( ! empty( $data['reports'] ) && is_array( $data['reports'] ) ) {
            foreach ( $data['reports'] as $report ) {
                $result = $this->process_report( $report );
                $results[] = $result;
            }
        }

        // ── Fallback: old "items" format for backwards compatibility ──
        if ( ! empty( $data['items'] ) && is_array( $data['items'] ) && empty( $data['reports'] ) ) {
            foreach ( $data['items'] as $item ) {
                $result = $this->process_report_legacy( $item );
                $results[] = $result;
            }
        }

        // ── Image ALT updates (if present) ──
        if ( ! empty( $data['image'] ) ) {
            $img_result = $this->process_image_alts( $data['image'] );
            $results[] = $img_result;
        }

        $success_count = count( array_filter( $results, function( $r ) {
            return ( $r['status'] ?? '' ) === 'updated';
        } ) );

        hts_add_log(
            sprintf( 'Audit traité — %d/%d opérations réussies', $success_count, count( $results ) ),
            $success_count > 0 ? 'success' : 'warning',
            'api'
        );

        return array(
            'action'  => 'audit_processed',
            'total'   => count( $results ),
            'updated' => $success_count,
            'details' => $results,
        );
    }

    /**
     * Process single SEO report (SaaS format)
     * Calqué sur SeoManager::processSeoReports()
     *
     * Report format: { url: "/page/", updated_results: { title: {text:""}, metadescription: {text:""}, ... } }
     */
    private function process_report( array $report ) {
        if ( empty( $report['url'] ) || ! isset( $report['updated_results'] ) ) {
            return array( 'status' => 'skipped', 'reason' => 'url ou updated_results manquant' );
        }

        $url = sanitize_text_field( $report['url'] );

        // Parse updated_results (can be JSON string or array)
        $updated = $report['updated_results'];
        if ( is_string( $updated ) ) {
            $updated = json_decode( $updated, true );
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                return array( 'status' => 'error', 'url' => $url, 'reason' => 'JSON invalide dans updated_results' );
            }
        }

        if ( ! is_array( $updated ) ) {
            return array( 'status' => 'skipped', 'url' => $url, 'reason' => 'updated_results non-array' );
        }

        // Find post by URL
        $post_id = $this->find_post_by_url( $url );

        if ( ! $post_id ) {
            return array( 'status' => 'not_found', 'url' => $url, 'reason' => 'Aucun post trouvé' );
        }

        $fields_updated = array();

        // ── title.text → meta title ──
        if ( ! empty( $updated['title']['text'] ) ) {
            $val = sanitize_text_field( $updated['title']['text'] );
            update_post_meta( $post_id, '_hts_meta_title', $val );
            $fields_updated[] = 'meta_title';
        }

        // ── metadescription.text → meta description ──
        if ( ! empty( $updated['metadescription']['text'] ) ) {
            $val = sanitize_textarea_field( $updated['metadescription']['text'] );
            update_post_meta( $post_id, '_hts_meta_description', $val );
            $fields_updated[] = 'meta_description';
        }

        // ── keywords.text → focus keyword ──
        if ( ! empty( $updated['keywords']['text'] ) ) {
            $val = sanitize_text_field( $updated['keywords']['text'] );
            update_post_meta( $post_id, '_hts_focus_keyword', $val );
            $fields_updated[] = 'focus_keyword';
        }

        // ── Also write to active SEO plugin ──
        $this->update_seo_report_meta( $post_id, $updated );

        // ── Headings H1/H2 ──
        if ( ! empty( $updated['heading_h1']['text'] ) ) {
            $upd = wp_update_post( array(
                'ID'         => $post_id,
                'post_title' => sanitize_text_field( $updated['heading_h1']['text'] ),
            ) );
            if ( ! is_wp_error( $upd ) && $upd > 0 ) {
                $fields_updated[] = 'h1';
            } else {
                hts_add_log( 'API Receiver: échec mise à jour H1 post #' . $post_id, 'warning', 'api' );
            }
        }

        hts_add_log(
            sprintf( 'Audit report — Post %d (%s) — fields: %s', $post_id, $url, implode( ', ', $fields_updated ) ),
            'info',
            'api'
        );

        return array(
            'status'  => 'updated',
            'post_id' => $post_id,
            'url'     => $url,
            'fields'  => $fields_updated,
        );
    }

    /**
     * Write audit report SEO data to active competitor plugin
     * Calqué sur SeoManager::updateRankMathFromReport / updateYoastFromReport
     */
    private function update_seo_report_meta( int $post_id, array $data ) {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // ── Yoast ──
        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            if ( ! empty( $data['title']['text'] ) )
                update_post_meta( $post_id, '_yoast_wpseo_title', sanitize_text_field( $data['title']['text'] ) );
            if ( ! empty( $data['metadescription']['text'] ) )
                update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field( $data['metadescription']['text'] ) );
            if ( ! empty( $data['keywords']['text'] ) )
                update_post_meta( $post_id, '_yoast_wpseo_focuskw', sanitize_text_field( $data['keywords']['text'] ) );
            if ( ! empty( $data['graph_title']['text'] ) )
                update_post_meta( $post_id, '_yoast_wpseo_opengraph-title', sanitize_text_field( $data['graph_title']['text'] ) );
            if ( ! empty( $data['graph_description']['text'] ) )
                update_post_meta( $post_id, '_yoast_wpseo_opengraph-description', sanitize_textarea_field( $data['graph_description']['text'] ) );
            return;
        }

        // ── Rank Math ──
        if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            if ( ! empty( $data['title']['text'] ) )
                update_post_meta( $post_id, 'rank_math_title', sanitize_text_field( $data['title']['text'] ) );
            if ( ! empty( $data['metadescription']['text'] ) )
                update_post_meta( $post_id, 'rank_math_description', sanitize_textarea_field( $data['metadescription']['text'] ) );
            if ( ! empty( $data['keywords']['text'] ) )
                update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $data['keywords']['text'] ) );
            if ( ! empty( $data['graph_title']['text'] ) )
                update_post_meta( $post_id, 'rank_math_facebook_title', sanitize_text_field( $data['graph_title']['text'] ) );
            if ( ! empty( $data['graph_description']['text'] ) )
                update_post_meta( $post_id, 'rank_math_facebook_description', sanitize_textarea_field( $data['graph_description']['text'] ) );
            return;
        }
    }

    /**
     * Legacy audit item format (backwards compat)
     */
    private function process_report_legacy( array $item ) {
        if ( empty( $item['url'] ) ) {
            return array( 'status' => 'skipped', 'reason' => 'URL manquante' );
        }

        $url     = sanitize_text_field( $item['url'] );
        $post_id = $this->find_post_by_url( $url );

        if ( ! $post_id ) {
            return array( 'status' => 'not_found', 'url' => $url );
        }

        $fields = array();
        if ( ! empty( $item['meta_title'] ) ) {
            update_post_meta( $post_id, '_hts_meta_title', sanitize_text_field( $item['meta_title'] ) );
            $fields[] = 'meta_title';
        }
        if ( ! empty( $item['meta_description'] ) ) {
            update_post_meta( $post_id, '_hts_meta_description', sanitize_text_field( $item['meta_description'] ) );
            $fields[] = 'meta_description';
        }
        if ( ! empty( $item['focus_keyword'] ) ) {
            update_post_meta( $post_id, '_hts_focus_keyword', sanitize_text_field( $item['focus_keyword'] ) );
            $fields[] = 'focus_keyword';
        }

        return array( 'status' => 'updated', 'post_id' => $post_id, 'url' => $url, 'fields' => $fields );
    }

    /**
     * Process image ALT updates
     * Calqué sur SeoManager::processImageAlts()
     */
    private function process_image_alts( $image_data ) {
        try {
            $images = is_string( $image_data ) ? json_decode( $image_data, true ) : $image_data;

            if ( ! is_array( $images ) || empty( $images['alt'] ) ) {
                return array( 'status' => 'skipped', 'reason' => 'Aucune donnée ALT' );
            }

            $updated = 0;
            foreach ( $images['alt'] as $img ) {
                if ( empty( $img['src'] ) || empty( $img['alt'] ) ) continue;

                // Find attachment by URL
                $attach_id = attachment_url_to_postid( $img['src'] );
                if ( $attach_id ) {
                    update_post_meta( $attach_id, '_wp_attachment_image_alt', sanitize_text_field( $img['alt'] ) );
                    $updated++;
                }
            }

            return array( 'status' => 'updated', 'type' => 'image_alt', 'count' => $updated );
        } catch ( Exception $e ) {
            return array( 'status' => 'error', 'type' => 'image_alt', 'reason' => $e->getMessage() );
        }
    }

    /* =========================================================================
     * HELPERS — Article Processing
     * ====================================================================== */

    /**
     * Assign category by name — match existing or create
     */
    private function assign_category( int $post_id, string $category_name ) {
        if ( empty( $category_name ) ) {
            return;
        }

        $term = get_term_by( 'name', $category_name, 'category' );

        if ( ! $term ) {
            $result = wp_insert_term( $category_name, 'category' );
            if ( is_wp_error( $result ) ) {
                hts_add_log( 'Erreur création catégorie "' . $category_name . '": ' . $result->get_error_message(), 'warning', 'api' );
                return;
            }
            $term_id = $result['term_id'];
        } else {
            $term_id = $term->term_id;
        }

        wp_set_post_categories( $post_id, array( $term_id ) );
    }

    /**
     * Sideload featured image from URL into media library
     */
    private function sideload_featured_image( int $post_id, string $image_url ) {
        if ( empty( $image_url ) || ! filter_var( $image_url, FILTER_VALIDATE_URL ) ) {
            return;
        }

        // Load required WP functions
        if ( ! function_exists( 'media_sideload_image' ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $attachment_id = media_sideload_image( $image_url, $post_id, null, 'id' );

        if ( is_wp_error( $attachment_id ) ) {
            hts_add_log(
                'Erreur sideload image pour post ' . $post_id . ': ' . $attachment_id->get_error_message(),
                'warning',
                'api'
            );
            return;
        }

        set_post_thumbnail( $post_id, $attachment_id );
    }

    /**
     * Assign language via WPML or Polylang
     */
    private function assign_language( int $post_id, string $lang, $translation_of = 0, $translation_group = '' ) {
        if ( empty( $lang ) ) {
            return;
        }

        // WPML
        if ( defined( 'ICL_SITEPRESS_VERSION' ) && function_exists( 'wpml_get_default_language' ) ) {
            global $sitepress;
            $trid = false;

            // Link to existing translation if translation_of is provided
            if ( $translation_of > 0 ) {
                $trid = apply_filters( 'wpml_element_trid', null, $translation_of, 'post_post' );
            }

            if ( $sitepress && method_exists( $sitepress, 'set_element_language_details' ) ) {
                $sitepress->set_element_language_details(
                    $post_id,
                    'post_post',
                    $trid ?: false,
                    $lang
                );
            }
            return;
        }

        // Polylang
        if ( function_exists( 'pll_set_post_language' ) ) {
            pll_set_post_language( $post_id, $lang );

            // Link translations if translation_of is provided
            if ( $translation_of > 0 && function_exists( 'pll_save_post_translations' ) ) {
                $existing = function_exists( 'pll_get_post_translations' )
                    ? pll_get_post_translations( $translation_of )
                    : array();
                $existing[ $lang ] = $post_id;
                pll_save_post_translations( $existing );
            }
            return;
        }

        // No multilingual plugin — store as meta for reference
        update_post_meta( $post_id, '_hts_lang', $lang );
        if ( $translation_of > 0 ) {
            update_post_meta( $post_id, '_hts_translation_of', $translation_of );
        }
        if ( $translation_group ) {
            update_post_meta( $post_id, '_hts_translation_group', $translation_group );
        }
    }

    /**
     * Find post ID from URL (relative or absolute)
     */
    private function find_post_by_url( string $url ) {
        // Try url_to_postid first (handles absolute URLs)
        if ( strpos( $url, 'http' ) === 0 ) {
            $post_id = hts_url_to_postid( $url );
            if ( $post_id > 0 ) {
                return $post_id;
            }
        }

        // Try with site URL prepended (for relative URLs)
        if ( strpos( $url, '/' ) === 0 ) {
            $full_url = rtrim( home_url(), '/' ) . $url;
            $post_id = hts_url_to_postid( $full_url );
            if ( $post_id > 0 ) {
                return $post_id;
            }
        }

        // Fallback: query by post_name (slug)
        $slug = trim( $url, '/' );
        $slug = basename( $slug ); // Get last segment

        $query = new WP_Query( array(
            'name'           => $slug,
            'post_type'      => array( 'post', 'page', 'product' ),
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ) );

        if ( ! empty( $query->posts ) ) {
            return $query->posts[0];
        }

        return false;
    }

    /**
     * Get default author for new posts
     */
    private function get_default_author() {
        $admin_users = get_users( array(
            'role'    => 'administrator',
            'number'  => 1,
            'orderby' => 'ID',
            'order'   => 'ASC',
            'fields'  => 'ID',
        ) );

        return ! empty( $admin_users ) ? (int) $admin_users[0] : 1;
    }

    /**
     * Detect active multilingual plugin
     */
    private function detect_multilingual_plugin() {
        if ( defined( 'ICL_SITEPRESS_VERSION' ) ) {
            return 'wpml';
        }
        if ( function_exists( 'pll_the_languages' ) || defined( 'POLYLANG_VERSION' ) ) {
            return 'polylang';
        }
        return 'none';
    }

    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $headers = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' );
        foreach ( $headers as $header ) {
            if ( ! empty( $_SERVER[ $header ] ) ) {
                $ip = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) ) );
                return trim( $ip[0] );
            }
        }
        return 'unknown';
    }

    /* =========================================================================
     * PUSH HISTORY
     * ====================================================================== */

    /**
     * Log a push event to history
     */
    private function log_push( string $type, array $result ) {
        $history = get_option( self::OPT_PUSH_HISTORY, array() );
        if ( ! is_array( $history ) ) {
            $history = array();
        }

        $entry = array(
            'date'   => current_time( 'Y-m-d H:i:s' ),
            'type'   => $type,
            'status' => isset( $result['action'] ) ? 'success' : 'error',
            'detail' => $this->summarize_result( $type, $result ),
            'ip'     => $this->get_client_ip(),
        );

        array_unshift( $history, $entry );
        $history = array_slice( $history, 0, self::PUSH_HISTORY_LIMIT );

        update_option( self::OPT_PUSH_HISTORY, $history, false );
    }

    /**
     * Summarize result for history display
     */
    private function summarize_result( string $type, array $result ) {
        if ( $type === 'article' && ! empty( $result['title'] ) ) {
            $status = $result['status'] ?? 'draft';
            $uid    = ! empty( $result['unique_id'] ) ? ' (uid:' . $result['unique_id'] . ')' : '';
            return sprintf( '"%s" → Post #%d (%s)%s', $result['title'], $result['post_id'] ?? 0, $status, $uid );
        }
        if ( $type === 'audit' && isset( $result['updated'] ) ) {
            return sprintf( '%d/%d opérations', $result['updated'], $result['total'] );
        }
        return wp_json_encode( $result );
    }

    /* =========================================================================
     * API RESPONSE HELPERS
     * ====================================================================== */

    /**
     * Return standardized error response
     */
    private function api_error( string $message, int $status = 400 ) {
        return new WP_Error( 'hts_api_error', $message, array( 'status' => $status ) );
    }

    /* =========================================================================
     * PULL SYNC — Porté du Full plugin (hts_do_sync_articles / corrections)
     *
     * Le SaaS ne PUSH pas les articles au WP — c'est WP qui les TIRE
     * via GET /api/articles?page=X et GET /api/auditseo
     * ====================================================================== */

    /**
     * AJAX: Sync articles (PULL from SaaS)
     */
    public function ajax_sync_articles() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ), 403 );
        }

        try {
            $status = isset( $_POST['status_article'] ) ? sanitize_text_field( $_POST['status_article'] ) : 'draft';
            $cat    = isset( $_POST['cat_article'] ) ? absint( $_POST['cat_article'] ) : 0;
            $update = isset( $_POST['autoriser_maj'] ) && $_POST['autoriser_maj'] === '1';

            $result = $this->do_sync_articles( $status, $cat, $update );

            if ( $result['success'] ) {
                wp_send_json_success( $result );
            } else {
                wp_send_json_error( $result );
            }
        } catch ( Exception $e ) {
            hts_add_log( 'Erreur critique sync articles : ' . $e->getMessage(), 'error', 'sync' );
            wp_send_json_error( array( 'message' => 'Erreur : ' . $e->getMessage() ) );
        }
    }

    /**
     * AJAX: Sync corrections (PULL from SaaS)
     */
    public function ajax_sync_corrections() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permissions insuffisantes.' ), 403 );
        }

        try {
            $result = $this->do_sync_corrections();

            if ( $result['success'] ) {
                wp_send_json_success( $result );
            } else {
                wp_send_json_error( $result );
            }
        } catch ( Exception $e ) {
            hts_add_log( 'Erreur critique sync corrections : ' . $e->getMessage(), 'error', 'sync' );
            wp_send_json_error( array( 'message' => 'Erreur : ' . $e->getMessage() ) );
        }
    }

    /**
     * Pull articles from SaaS API — paginated
     * Ported from Full: hts_do_sync_articles()
     */
    private function do_sync_articles( $status_article = 'draft', $cat_article = 0, $allow_update = false ) {
        $api_key = get_option( self::OPT_API_KEY, '' );
        if ( empty( $api_key ) ) {
            return array( 'success' => false, 'message' => 'Clé API non configurée.' );
        }

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $allowed = array( 'publish', 'draft', 'pending', 'private' );
        if ( ! in_array( $status_article, $allowed, true ) ) {
            $status_article = 'draft';
        }

        hts_add_log( 'Sync articles démarrée (statut: ' . $status_article . ')', 'info', 'sync' );

        $base_url  = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
        $api_url   = $base_url . '/api/articles';
        $per_page  = 10;
        $page      = 0;
        $np_posts  = 0;
        $created   = 0;
        $updated   = 0;
        $skipped   = 0;

        do {
            $page++;
            $response = wp_remote_get( $api_url . '?page=' . $page, array(
                'headers' => array(
                    'x-api-key'    => $api_key,
                    'Content-Type' => 'application/json',
                ),
                'timeout' => 30,
            ) );

            if ( is_wp_error( $response ) ) {
                $msg = 'Erreur connexion API : ' . $response->get_error_message();
                hts_add_log( $msg, 'error', 'sync' );
                return array( 'success' => false, 'message' => $msg );
            }

            $http_code = wp_remote_retrieve_response_code( $response );
            $body      = wp_remote_retrieve_body( $response );
            $posts     = json_decode( $body, true );

            if ( $http_code !== 200 ) {
                $msg = 'API articles HTTP ' . $http_code . ' — ' . substr( $body, 0, 200 );
                hts_add_log( $msg, 'error', 'sync' );
                return array( 'success' => false, 'message' => $msg );
            }

            if ( isset( $posts['error'] ) ) {
                $msg = 'API erreur : ' . ( $posts['message'] ?? 'inconnue' );
                hts_add_log( $msg, 'error', 'sync' );
                return array( 'success' => false, 'message' => $msg );
            }

            $data_items = $posts['data']['data'] ?? array();
            $np_posts   = count( $data_items );

            if ( $np_posts === 0 && $page === 1 ) {
                hts_add_log( 'Aucun article à synchroniser', 'info', 'sync' );
                return array( 'success' => true, 'message' => 'Aucun article à synchroniser.', 'created' => 0, 'updated' => 0, 'skipped' => 0 );
            }

            foreach ( $data_items as $data ) {
                try {
                    $article_id_api = sanitize_text_field( $data['unique_id'] ?? '' );

                    // ── Guard: unique_id vide = toujours créer ──
                    if ( empty( $article_id_api ) || strlen( $article_id_api ) < 3 ) {
                        hts_add_log( 'unique_id vide/court — création forcée', 'warning', 'sync' );
                        if ( ! isset( $data['metatitle'] ) || ! isset( $data['article'] ) ) {
                            $skipped++;
                            continue;
                        }
                        $post_id = wp_insert_post( array(
                            'post_title'    => sanitize_text_field( $data['h1'] ?? $data['metatitle'] ?? 'Sans titre' ),
                            'post_content'  => wp_kses_post( $data['article'] ),
                            'post_status'   => $status_article,
                            'post_type'     => 'post',
                            'post_category' => $cat_article ? array( $cat_article ) : array(),
                        ) );
                        if ( $post_id && ! is_wp_error( $post_id ) ) {
                            update_post_meta( $post_id, '_hts_api_generated', 1 );
                            $created++;
                            $this->sync_update_post_seo_meta( (int) $post_id, $data );
                        }
                        continue;
                    }

                    // Check if already exists
                    $query = new WP_Query( array(
                        'post_type'      => 'post',
                        'post_status'    => array( 'publish', 'draft' ),
                        'meta_query'     => array( array(
                            'key'     => 'article_id_api',
                            'value'   => $article_id_api,
                            'compare' => '=',
                        ) ),
                        'posts_per_page' => 1,
                        'no_found_rows'  => true,
                    ) );

                    $post_id = 0;

                    if ( empty( $query->posts ) ) {
                        // ── CREATE new post ──
                        if ( ! isset( $data['metatitle'] ) || ! isset( $data['article'] ) ) {
                            $skipped++;
                            continue;
                        }

                        $post_id = wp_insert_post( array(
                            'post_title'    => sanitize_text_field( $data['h1'] ?? $data['metatitle'] ?? 'Sans titre' ),
                            'post_content'  => wp_kses_post( $data['article'] ),
                            'post_status'   => $status_article,
                            'post_type'     => 'post',
                            'post_category' => $cat_article ? array( $cat_article ) : array(),
                        ) );

                        if ( $post_id && ! is_wp_error( $post_id ) ) {
                            update_post_meta( $post_id, 'article_id_api', $article_id_api );
                            update_post_meta( $post_id, '_hts_api_generated', 1 );
                            $created++;
                        }

                    } elseif ( $allow_update ) {
                        $post_id = $query->posts[0]->ID;

                        // ── SÉCURITÉ: ne pas écraser un post non-HTS ──
                        $is_hts = get_post_meta( $post_id, '_hts_api_generated', true );
                        if ( ! $is_hts ) {
                            hts_add_log( 'PROTECTION: Post #' . $post_id . ' (uid:' . $article_id_api . ') pas créé par HTS — skip', 'warning', 'sync' );
                            $skipped++;
                            continue;
                        }

                        // ── UPDATE existing HTS post ──
                        $upd = wp_update_post( array(
                            'ID'           => $post_id,
                            'post_title'   => sanitize_text_field( $data['h1'] ?? $data['metatitle'] ?? '' ),
                            'post_content' => wp_kses_post( $data['article'] ?? '' ),
                        ) );
                        if ( is_wp_error( $upd ) || 0 === $upd ) {
                            hts_add_log( 'Sync: échec mise à jour post #' . $post_id, 'error', 'sync' );
                            $skipped++;
                        } else {
                            $updated++;
                        }
                    } else {
                        $skipped++;
                    }

                    // ── SEO meta (same as Full: hts_update_post_seo_meta) ──
                    if ( $post_id && ! is_wp_error( $post_id ) ) {
                        $this->sync_update_post_seo_meta( (int) $post_id, $data );
                    }

                } catch ( Exception $e ) {
                    $skipped++;
                    hts_add_log( 'Erreur article ' . ( $data['unique_id'] ?? '?' ) . ' : ' . $e->getMessage(), 'error', 'sync' );
                }
            }
        } while ( $np_posts >= $per_page );

        $msg = sprintf( 'Sync terminée : %d créé(s), %d mis à jour, %d ignoré(s)', $created, $updated, $skipped );
        hts_add_log( $msg, 'success', 'sync' );

        // Log to push history for visibility
        $this->log_push( 'sync_articles', array(
            'action'  => 'sync_articles',
            'title'   => $msg,
            'post_id' => 0,
        ) );

        return array(
            'success' => true,
            'message' => $msg,
            'created' => $created,
            'updated' => $updated,
            'skipped' => $skipped,
            'pages'   => $page,
        );
    }

    /**
     * Pull corrections from SaaS API
     * Ported from Full: hts_do_sync_corrections()
     */
    private function do_sync_corrections() {
        $api_key = get_option( self::OPT_API_KEY, '' );
        if ( empty( $api_key ) ) {
            return array( 'success' => false, 'message' => 'Clé API non configurée.' );
        }

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        hts_add_log( 'Sync corrections démarrée', 'info', 'sync' );

        $base_url = get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' );
        $api_url  = $base_url . '/api/auditseo';

        $response = wp_remote_get( $api_url, array(
            'headers' => array(
                'x-api-key'    => $api_key,
                'Content-Type' => 'application/json',
            ),
            'timeout' => 30,
        ) );

        if ( is_wp_error( $response ) ) {
            $msg = 'Erreur connexion API corrections : ' . $response->get_error_message();
            hts_add_log( $msg, 'error', 'sync' );
            return array( 'success' => false, 'message' => $msg );
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        $raw_body  = wp_remote_retrieve_body( $response );
        $body      = json_decode( $raw_body, true );

        if ( $http_code !== 200 ) {
            $msg = 'API corrections HTTP ' . $http_code . ' — ' . substr( $raw_body, 0, 200 );
            hts_add_log( $msg, 'error', 'sync' );
            return array( 'success' => false, 'message' => $msg );
        }

        if ( empty( $body['data'] ) ) {
            hts_add_log( 'Aucune correction à appliquer', 'info', 'sync' );
            return array( 'success' => true, 'message' => 'Aucune correction à appliquer.', 'results' => array() );
        }

        $all_results = array();
        foreach ( $body['data'] as $audit ) {
            // Process each audit's reports
            $reports = $audit['reports'] ?? array();
            foreach ( $reports as $report ) {
                $result = $this->process_report( $report );
                $all_results[] = $result;
            }
        }

        $success_count = count( array_filter( $all_results, function( $r ) {
            return ( $r['status'] ?? '' ) === 'updated';
        } ) );

        $msg = sprintf( 'Sync corrections terminée : %d/%d appliquées', $success_count, count( $all_results ) );
        hts_add_log( $msg, 'success', 'sync' );

        $this->log_push( 'sync_corrections', array(
            'action'  => 'sync_corrections',
            'title'   => $msg,
            'post_id' => 0,
        ) );

        return array(
            'success' => true,
            'message' => $msg,
            'total'   => count( $all_results ),
            'updated' => $success_count,
            'results' => $all_results,
        );
    }

    /**
     * Update SEO meta for a post during PULL sync
     * Ported from Full: hts_update_post_seo_meta()
     * Writes to active SEO plugin OR native _meta_* fields
     */
    private function sync_update_post_seo_meta( int $post_id, array $data ) {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
            // ── Yoast ──
            if ( isset( $data['metatitle'] ) )       update_post_meta( $post_id, '_yoast_wpseo_title', sanitize_text_field( $data['metatitle'] ) );
            if ( isset( $data['metadescription'] ) )  update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field( $data['metadescription'] ) );
            if ( isset( $data['keyword'] ) )          update_post_meta( $post_id, '_yoast_wpseo_focuskw', sanitize_text_field( $data['keyword'] ) );

        } elseif ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
            // ── RankMath ──
            if ( isset( $data['metatitle'] ) )       update_post_meta( $post_id, 'rank_math_title', sanitize_text_field( $data['metatitle'] ) );
            if ( isset( $data['metadescription'] ) )  update_post_meta( $post_id, 'rank_math_description', sanitize_textarea_field( $data['metadescription'] ) );
            if ( isset( $data['keyword'] ) )          update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $data['keyword'] ) );

        } else {
            // ── Natif (aucun plugin SEO) — exactement comme le Full ──
            if ( isset( $data['metatitle'] ) )       update_post_meta( $post_id, '_meta_title', sanitize_text_field( $data['metatitle'] ) );
            if ( isset( $data['metadescription'] ) )  update_post_meta( $post_id, '_meta_description', sanitize_textarea_field( $data['metadescription'] ) );
            if ( isset( $data['keyword'] ) )          update_post_meta( $post_id, '_meta_keywords', sanitize_text_field( $data['keyword'] ) );
        }

        // ── Always write _hts_* meta too ──
        if ( isset( $data['metatitle'] ) )       update_post_meta( $post_id, '_hts_meta_title', sanitize_text_field( $data['metatitle'] ) );
        if ( isset( $data['metadescription'] ) )  update_post_meta( $post_id, '_hts_meta_description', sanitize_textarea_field( $data['metadescription'] ) );
        if ( isset( $data['keyword'] ) )          update_post_meta( $post_id, '_hts_focus_keyword', sanitize_text_field( $data['keyword'] ) );
        update_post_meta( $post_id, '_hts_api_received_at', current_time( 'Y-m-d H:i:s' ) );

        // ── Language + translation linking ──
        $lang = $data['lang'] ?? $data['language'] ?? '';
        if ( ! empty( $lang ) ) {
            $translation_of    = (int) ( $data['translation_of'] ?? 0 );
            $translation_group = sanitize_text_field( $data['translation_group'] ?? '' );
            $this->assign_language( $post_id, sanitize_text_field( $lang ), $translation_of, $translation_group );
        }

        // ── Featured image ──
        $image = $data['featured_image'] ?? $data['image'] ?? $data['image_url'] ?? '';
        if ( ! empty( $image ) && ! has_post_thumbnail( $post_id ) ) {
            $this->sideload_featured_image( $post_id, esc_url_raw( $image ) );
        }

        // ── Category ──
        $category = $data['category'] ?? $data['categorie'] ?? '';
        if ( ! empty( $category ) ) {
            $this->assign_category( $post_id, sanitize_text_field( $category ) );
        }

        // ── Cocon / pillar ──
        if ( ! empty( $data['cocon_id'] ) ) {
            update_post_meta( $post_id, '_hts_cocon_id', sanitize_text_field( $data['cocon_id'] ) );
        }
        if ( ! empty( $data['pillar_url'] ) ) {
            update_post_meta( $post_id, '_hts_pillar_url', esc_url_raw( $data['pillar_url'] ) );
        }
    }

    /* =========================================================================
     * ADMIN PAGE
     * ====================================================================== */

    /**
     * Register admin submenu page
     */
    public function register_admin_page() {
        add_submenu_page(
            'hts-light-dashboard',
            'Paramètres',
 'Paramètres',
            defined( 'HTS_VIEW_CAPABILITY' ) ? HTS_VIEW_CAPABILITY : 'manage_options',
            'hts-api-settings',
            array( $this, 'render_admin_page' )
        );
    }

    /**
     * Render admin page
     */
    public function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Accès interdit.' );
        }

        $api_key       = get_option( self::OPT_API_KEY, '' );
        $push_history  = get_option( self::OPT_PUSH_HISTORY, array() );
        if ( ! is_array( $push_history ) ) {
            $push_history = array();
        }
        $push_history = array_slice( $push_history, 0, 20 );

        // Stats
        $total_received = count( get_option( self::OPT_PUSH_HISTORY, array() ) );
        $articles_count = $this->count_hts_articles();
        $last_sync      = ! empty( $push_history ) ? $push_history[0]['date'] : 'Jamais';

        include HTS__PLUGIN_DIR . 'admin/partials/settings-unified.php';
    }

    /**
     * Count articles generated by HTS API
     */
    private function count_hts_articles() {
        $query = new WP_Query( array(
            'post_type'      => 'post',
            'post_status'    => array( 'draft', 'publish', 'pending', 'future' ),
            'meta_key'       => '_hts_api_generated',
            'meta_value'     => '1',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ) );

        return count( $query->posts );
    }

    /* =========================================================================
     * AJAX HANDLERS
     * ====================================================================== */

    /**
     * AJAX: Clear push history
     */
    /**
     * AJAX: Save default article status
     */
    public function ajax_save_article_default_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permissions insuffisantes.' );
        }

        $status  = sanitize_text_field( $_POST['status'] ?? 'draft' );
        $allowed = array( 'draft', 'publish', 'pending' );
        if ( ! in_array( $status, $allowed, true ) ) {
            $status = 'draft';
        }

        update_option( 'hts_article_default_status', $status );
        hts_add_log( 'Statut par défaut des articles → ' . $status, 'info', 'api' );
        wp_send_json_success( array( 'status' => $status ) );
    }

    /**
     * AJAX: Clear push history
     */
    public function ajax_clear_push_history() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permissions insuffisantes.' );
        }

        delete_option( self::OPT_PUSH_HISTORY );
        hts_add_log( 'Historique API nettoyé', 'info', 'api' );
        wp_send_json_success( array( 'message' => 'Historique vidé.' ) );
    }
}
