# Guide de traduction — Hack The SEO

## Architecture en place

```
hacktheseo/
├── languages/
│   ├── hack-the-seo-light.pot          ← Template (strings source FR)
│   ├── hack-the-seo-light-en_US.po     ← Traduction anglaise
│   ├── hack-the-seo-light-en_US.mo     ← Compilé (WordPress lit ça)
│   ├── hack-the-seo-light-es_ES.po     ← Traduction espagnole
│   ├── hack-the-seo-light-es_ES.mo     ← Compilé
│   └── index.php
```

## Comment traduire un nouveau fichier

### 1. Wrapper les strings PHP

```php
// AVANT
echo '<h2>Tableau de bord</h2>';
$msg = 'Article introuvable.';

// APRÈS
$td = 'hack-the-seo-light';
echo '<h2>' . esc_html__( 'Tableau de bord', $td ) . '</h2>';
$msg = __( 'Article introuvable.', $td );
```

### 2. Raccourcis selon le contexte

| Fonction | Usage |
|----------|-------|
| `__( 'texte', $td )` | Retourne la traduction (pour variables, sprintf) |
| `_e( 'texte', $td )` | Echo direct la traduction |
| `esc_html__( 'texte', $td )` | Retourne + escape HTML |
| `esc_attr__( 'texte', $td )` | Retourne + escape attribut |
| `sprintf( __( '%d article(s)', $td ), $n )` | Avec variables |
| `_n( '%d article', '%d articles', $n, $td )` | Pluriel |

### 3. Règles importantes

- **Ne JAMAIS traduire les clés techniques** : noms de fonctions, slugs, meta_keys
- **Garder le `$td` cohérent** : toujours `'hack-the-seo-light'`
- **Les emojis sont OK** dans les traductions (ils passent gettext)
- **Les variables `%s`, `%d`** doivent rester dans le même ordre
- **JS inline** : utiliser `wp_localize_script()` pour passer les strings traduites

### 4. Strings JS (pour le sprint complet)

```php
// Dans le module PHP qui enqueue le JS :
wp_localize_script( 'hts-admin', 'htsI18n', array(
    'saving'      => __( 'Enregistrement...', 'hack-the-seo-light' ),
    'saved'       => __( 'Sauvegardé', 'hack-the-seo-light' ),
    'error'       => __( 'Erreur', 'hack-the-seo-light' ),
    'confirm'     => __( 'Êtes-vous sûr ?', 'hack-the-seo-light' ),
) );

// Dans le JS :
// toast(htsI18n.saved, 'success');
```

## Ordre de traduction recommandé (sprint post-prod)

1. `hack-the-seo-light.php` — menus, admin notices ✅ FAIT
2. `modules/class-hts-cockpit.php` — 329 strings (UI principale)
3. `admin/partials/cocon-commander.php` — UI Cocon
4. `admin/partials/settings-unified.php` — réglages
5. `modules/class-hts-workflow-engine.php` — inbox messages
6. `admin/partials/analytics.php` — dashboard analytics
7. `modules/class-hts-coach.php` — messages coach
8. Reste des modules

## Compilation

```bash
# Depuis le dossier languages/
msgfmt hack-the-seo-light-en_US.po -o hack-the-seo-light-en_US.mo
msgfmt hack-the-seo-light-es_ES.po -o hack-the-seo-light-es_ES.mo
```

## Tester

1. Installer le plugin sur un site WP en anglais (`Settings > General > Site Language`)
2. Les menus doivent s'afficher en anglais
3. Repasser en français → retour au français
