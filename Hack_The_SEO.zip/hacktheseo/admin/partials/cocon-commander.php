<?php
if ( ! defined( 'ABSPATH') ) exit;
/**
 * Cocon Commander V3 — S6 DS v5.7
 * "Groupes de contenus" (CEO language)
 * @since 2.6.0
 */
if ( ! defined( 'WPINC') ) die;
if ( ! class_exists( 'HTS_DS') && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php') ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}

/* ═══════════════════════════════════════
 * DATA PREPARATION
 * ═══════════════════════════════════════ */

// ── Tier gating for UI ──
$_hts_tier = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::get_plan_tier() : 2;
$_hts_can_write = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::can( 'cocon_write' ) : true;
$_hts_can_apply = class_exists( 'HTS_Subscription' ) ? HTS_Subscription::can( 'cocon_apply_links' ) : true;

// ── PERF: Resolve language FIRST (needed for plan filtering + cocon data) ──
$_hts_current_lang = '';
if ( class_exists( 'HTS_Language') ) {
 $_hts_current_lang = HTS_Language::get_current_lang();
 if ( $_hts_current_lang === 'all' || $_hts_current_lang === '' ) {
  $_hts_current_lang = substr( get_locale(), 0, 2 );
  if ( empty( get_option( 'hts_cocon_data_' . $_hts_current_lang, array() ) ) && function_exists( 'pll_default_language' ) ) {
   $pll_def = pll_default_language( 'slug' );
   if ( $pll_def && ! empty( get_option( 'hts_cocon_data_' . $pll_def, array() ) ) ) {
    $_hts_current_lang = $pll_def;
   }
  }
 }
}

$commander = new HTS_Cocon_Commander();
$plans = get_transient( 'hts_cocon_plans_cache' );
if ( false === $plans ) {
    $plans = $commander->get_plans();
    set_transient( 'hts_cocon_plans_cache', $plans, 5 * MINUTE_IN_SECONDS );
}

// ── Filter plans by current language (Polylang: don't show FR plans in EN view) ──
if ( $_hts_current_lang && count( $plans ) > 0 ) {
    $plans = array_filter( $plans, function( $p ) use ( $_hts_current_lang ) {
        $plan_lang = $p['language'] ?? $p['lang'] ?? '';
        if ( strlen( $plan_lang ) > 2 ) $plan_lang = substr( $plan_lang, 0, 2 );
        $plan_lang = strtolower( $plan_lang );
        if ( empty( $plan_lang ) && ! empty( $p['pillar_id'] ) && function_exists( 'pll_get_post_language' ) ) {
            $plan_lang = pll_get_post_language( (int) $p['pillar_id'], 'slug' );
        }
        return empty( $plan_lang ) || $plan_lang === $_hts_current_lang;
    } );
}
$hts_api_key = hts_get_api_key();
$ajax_url = admin_url( 'admin-ajax.php');
$nonce = wp_create_nonce( 'hts_admin_nonce');

// Embeddings + analysis status
$emb_stats = class_exists( 'HTS_Embeddings') ? HTS_Embeddings::get_stats() : null;
$emb_pct = $emb_stats ? (int) ( $emb_stats['coverage'] ?? 0 ) : 0;
$cocon_obj = class_exists( 'HTS_Cocon') ? new HTS_Cocon() : null;

// ── PERF: Load cocon_data ONCE and reuse everywhere ──
$_cocon_data_cache = $cocon_obj ? $cocon_obj->get_cocon_data( $_hts_current_lang ) : array();
$cocon_stats = null;
if ( $cocon_obj ) {
 // get_quick_stats normally re-calls get_cocon_data — skip it, build inline
 $last_analysis = get_option( 'hts_cocon_last_analysis', 0 );
 if ( ! empty( $_cocon_data_cache ) ) {
 $cocon_stats = array(
 'analyzed'=> true,
 'last'=> $last_analysis,
 'clusters'=> $_cocon_data_cache['clusters'] ?? array(),
 'stats'=> $_cocon_data_cache['stats'] ?? array(),
 'flagged_pages'=> array(),
 'missing_clusters'=> get_option( 'hts_cocon_missing_clusters', array() ),
 );
 // Merge flagged pages from decisions
 $decisions = get_option( 'hts_cocon_page_decisions', array() );
 foreach ( $decisions as $pid => $d ) {
 if ( ( $d['decision'] ?? '') === 'exclude') continue;
 if ( ! empty( $d['flagged'] ) ) $cocon_stats['flagged_pages'][] = $pid;
 }
 } else {
 $cocon_stats = array( 'analyzed'=> false, 'last'=> 0 );
 }
}
$is_analyzed = $cocon_stats && ! empty( $cocon_stats['analyzed'] ) && $cocon_stats['analyzed'] === true;

// Auto-Schedule data
$auto_sched_config = class_exists( 'HTS_Auto_Write') ? HTS_Auto_Write::get_auto_schedule_config() : array( 'enabled'=> false );
$auto_sched_next = class_exists( 'HTS_Auto_Write') && $auto_sched_config['enabled'] ? HTS_Auto_Write::get_next_auto_scheduled() : null;
$auto_sched_pending = class_exists( 'HTS_Auto_Write') && $auto_sched_config['enabled'] ? HTS_Auto_Write::count_pending_auto_schedule() : 0;
$auto_sched_week = class_exists( 'HTS_Auto_Write') ? HTS_Auto_Write::count_scheduled_this_week() : 0;
$auto_sched_max = class_exists( 'HTS_Auto_Write') ? HTS_Auto_Write::get_max_articles_per_week() : 3;
$as_days = $auto_sched_config['days'] ?? array( 1, 2, 3, 4, 5 );
$as_time = $auto_sched_config['time'] ?? '09:00';

// Pipeline counters
$pipeline_queued = 0;
$pipeline_drafts_no_img = 0;
if ( class_exists( 'HTS_Cocon_Commander') ) {
 foreach ( $plans as $plan ) {
 if ( empty( $plan['articles'] ) ) continue;
 foreach ( $plan['articles'] as $art ) {
 $st = $art['status'] ?? '';
 if ( in_array( $st, array( 'to_generate', 'pending_queue', 'queued'), true ) ) $pipeline_queued++;
 }
 }
 global $wpdb;
 $pipeline_drafts_no_img = (int) $wpdb->get_var(
 "SELECT COUNT(*) FROM {$wpdb->posts} p
 INNER JOIN {$wpdb->postmeta} aw ON p.ID = aw.post_id AND aw.meta_key = '_hts_auto_write'AND aw.meta_value = '1'
 LEFT JOIN {$wpdb->postmeta} th ON p.ID = th.post_id AND th.meta_key = '_thumbnail_id'
 WHERE p.post_status = 'draft'AND p.post_type IN ('post','page')
 AND ( th.meta_value IS NULL OR th.meta_value = ''OR th.meta_value = '0')"
 );
}

// Global stats
$total_plans = count( $plans );
$total_gen = 0;
$total_art = 0;
$total_todo = 0;
$total_error = 0;
foreach ( $plans as $cp ) {
 if ( empty( $cp['articles'] ) ) continue;
 foreach ( $cp['articles'] as $art ) {
 $total_art++;
 $as = $art['status'] ?? 'to_generate';
 if ( in_array( $as, array( 'received', 'ready', 'scheduled', 'published'), true ) ) $total_gen++;
 elseif ( $as === 'error') $total_error++;
 elseif ( $as === 'to_generate') $total_todo++;
 }
}

// Calendar data
$tz = wp_timezone();
$today = new DateTimeImmutable( 'now', $tz );
$monday = $today->modify( 'monday this week');
$next_sun = $monday->modify( '+13 days');

global $wpdb;
$sched_posts = $wpdb->get_results( $wpdb->prepare(
 "SELECT p.ID, p.post_title, p.post_date, p.post_status,
 COALESCE(pm.meta_value,'') AS cocon_keyword
 FROM {$wpdb->posts} p
 LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_cocon_keyword'
 WHERE p.post_status = 'future'
 AND p.post_type IN ('post','page')
 AND p.post_date BETWEEN %s AND %s
 ORDER BY p.post_date ASC",
 $monday->format( 'Y-m-d 00:00:00'),
 $next_sun->format( 'Y-m-d 23:59:59')
) );

$approved_drafts = $wpdb->get_results(
 "SELECT p.ID, p.post_title, p.post_date,
 COALESCE(ck.meta_value,'') AS cocon_keyword
 FROM {$wpdb->posts} p
 INNER JOIN {$wpdb->postmeta} ap ON p.ID = ap.post_id AND ap.meta_key = '_hts_schedule_approved'AND ap.meta_value = '1'
 LEFT JOIN {$wpdb->postmeta} ck ON p.ID = ck.post_id AND ck.meta_key = '_hts_cocon_keyword'
 WHERE p.post_status = 'draft'AND p.post_type IN ('post','page')
 ORDER BY p.post_date ASC
 LIMIT 30"
);

// Ready articles across all cocons (draft with post_id, not future)
// Pre-fetch all post IDs first, then batch-query metadata
$ready_articles = array();
$_ready_post_ids = array();
foreach ( $plans as $cid => $cp ) {
 if ( empty( $cp['articles'] ) ) continue;
 foreach ( $cp['articles'] as $akey => $art ) {
 $as = $art['status'] ?? '';
 if ( ! in_array( $as, array( 'received', 'ready'), true ) ) continue;
 $did = $art['post_id'] ?? 0;
 if ( $did ) $_ready_post_ids[ $did ] = array( 'cid'=> $cid, 'akey'=> $akey, 'art'=> $art );
 }
}
if ( ! empty( $_ready_post_ids ) ) {
 // Batch query posts
 $_ready_posts_q = get_posts( array(
 'post__in'=> array_keys( $_ready_post_ids ),
 'post_status'=> 'draft',
 'post_type'=> array( 'post', 'page'),
 'numberposts'=> -1,
 'orderby'=> 'post__in',
 ) );
 // Batch prefetch metadata
 if ( function_exists( 'update_meta_cache') ) {
 update_meta_cache( 'post', array_keys( $_ready_post_ids ) );
 }
 foreach ( $_ready_posts_q as $p ) {
 $did = $p->ID;
 if ( ! isset( $_ready_post_ids[ $did ] ) ) continue;
 $info = $_ready_post_ids[ $did ];
 $plan_kw = $plans[ $info['cid'] ]['keyword'] ?? $plans[ $info['cid'] ]['pillar_title'] ?? $info['cid'];
 $is_approved = (bool) get_post_meta( $did, '_hts_schedule_approved', true );
 $thumb_id = get_post_thumbnail_id( $did );
 $has_thumb = ! empty( $thumb_id );
 $thumb_url = $has_thumb ? get_the_post_thumbnail_url( $did, 'thumbnail') : '';
 $word_count = hts_word_count( wp_strip_all_tags( $p->post_content ) );
 $ready_articles[] = array(
 'post_id'=> $did,
 'title'=> $p->post_title,
 'cocon_kw'=> $plan_kw,
 'cocon_id'=> $info['cid'],
 'article_key'=> $info['akey'],
 'approved'=> $is_approved,
 'edit_url'=> get_edit_post_link( $did, 'raw'),
 'has_image'=> $has_thumb,
 'thumb_url'=> $thumb_url,
 'word_count'=> $word_count,
 );
 }
 unset( $_ready_post_ids, $_ready_posts_q );
}

$by_day = array();
foreach ( $sched_posts as $sp ) {
 $d = substr( $sp->post_date, 0, 10 );
 $by_day[ $d ][] = $sp;
}

$day_names = array( 1 => 'Lun', 2 => 'Mar', 3 => 'Mer', 4 => 'Jeu', 5 => 'Ven', 6 => 'Sam', 7 => 'Dim');

// ── NLP Clusters data (from hts_cocon_data) ──
$clusters_data = array();
$flagged_pages = array();
$missing_clusters = array();
$last_analysis = 0;
$cluster_pages = array(); // pages per cluster name
if ( $cocon_stats && ! empty( $cocon_stats['analyzed'] ) ) {
 $clusters_data = $cocon_stats['clusters'] ?? array();
 $flagged_pages = $cocon_stats['flagged_pages'] ?? array();
 $missing_clusters = $cocon_stats['missing_clusters'] ?? array();
 $last_analysis = $cocon_stats['last'] ?? 0;

 // PERF: reuse already-loaded cocon data (loaded once at top)
 if ( $cocon_obj && ! empty( $clusters_data ) && ! empty( $_cocon_data_cache ) ) {
 $full_clusters = $_cocon_data_cache['clusters'] ?? array();
 $full_nodes = $_cocon_data_cache['nodes'] ?? array();
 // Batch prefetch post metadata + cache for all node IDs
 $_all_node_ids = array_keys( $full_nodes );
 if ( ! empty( $_all_node_ids ) && function_exists( '_prime_post_caches') ) {
 _prime_post_caches( $_all_node_ids, true, true );
 }
 foreach ( $full_clusters as $fc ) {
 $cl_name = $fc['name'] ?? '';
 if ( empty( $cl_name ) || empty( $fc['pages'] ) ) continue;
 $cluster_pages[ $cl_name ] = array();
 foreach ( $fc['pages'] as $pid ) {
 if ( ! isset( $full_nodes[ $pid ] ) ) continue;
 $n = $full_nodes[ $pid ];
 $cluster_pages[ $cl_name ][] = array(
 'id'=> $pid,
 'title'=> $n['title'] ?? get_the_title( $pid ),
 'url'=> get_permalink( $pid ),
 'edit_url'=> get_edit_post_link( $pid, 'raw'),
 'role'=> $n['role'] ?? 'satellite',
 'is_orphan'=> ! empty( $n['is_orphan'] ),
 'is_dead_end'=> ! empty( $n['is_dead_end'] ),
 'incoming'=> count( $n['incoming'] ?? array() ),
 'outgoing'=> count( $n['outgoing'] ?? array() ),
 'cluster'=> $cl_name,
 );
 }
 }
 unset( $_all_node_ids, $full_clusters, $full_nodes );
 }
}
unset( $_cocon_data_cache ); // Free memory — no longer needed

// ── Money Pages — Discovery scoring system (per-language for Polylang) ──
$money_discovery = array();
if ( $_hts_current_lang ) {
    $money_discovery = get_option( 'hts_money_pages_discovery_' . $_hts_current_lang, array() );
}
if ( empty( $money_discovery['pages'] ) ) {
    $money_discovery = get_option( 'hts_money_pages_discovery', array() );
}
$money_discovery_done = ! empty( $money_discovery['timestamp'] );
$money_threshold = 30;

// ── Auto-discover if clusters exist but discovery hasn't run yet ──
// PERF FIX: Never run discover_money_pages synchronously on page load (causes 504 timeout).
// Instead, set a flag and trigger via AJAX after the page renders.
$money_needs_discovery = false;
if ( ! $money_discovery_done && ! empty( $clusters_data ) ) {
 $money_needs_discovery = true;
}
$money_pages_data = array();
$money_dismissed_data = array();

// ── Warning banner if "Non classé" is too big ──
$nc_warn_count = 0;
$nc_warn_total = 0;
if ( ! empty( $clusters_data ) ) {
    $nc_warn_total = array_sum( array_column( $clusters_data, 'page_count' ) );
    foreach ( $clusters_data as $clw ) {
        $clw_name = mb_strtolower( $clw['name'] ?? '' );
        if ( $clw_name === 'non classé' || $clw_name === 'non classe' ) {
            $nc_warn_count = (int) ( $clw['page_count'] ?? 0 );
        }
    }
}
$_hts_nc_warn_html = '';
if ( $nc_warn_count > 0 && $nc_warn_total > 10 && $nc_warn_count > $nc_warn_total * 0.3 ) {
    $_hts_nc_warn_html = '<div style="margin:16px 0;padding:14px 18px;background:var(--hts-caution-bg, #fff7ed);border:1px solid var(--hts-caution, #f59e0b);border-radius:10px;display:flex;align-items:flex-start;gap:12px">'
        . '<span style="font-size:22px;line-height:1">&#9888;&#65039;</span>'
        . '<div style="flex:1">'
        . '<div style="font-size:13px;font-weight:700;color:var(--hts-text)">' . $nc_warn_count . ' pages sur ' . $nc_warn_total . ' sont dans &laquo; Non class&eacute; &raquo;</div>'
        . '<div style="font-size:11px;color:var(--hts-text-3);margin-top:3px;line-height:1.5">Le clustering pr&eacute;c&eacute;dent a &eacute;chou&eacute; (probablement un probl&egrave;me de langue). Cliquez ci-dessous pour recr&eacute;er vos groupes proprement.</div>'
        . '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">'
        . '<button class="hts-cc-btn" style="padding:7px 14px;border:none;border-radius:8px;background:var(--hts-accent);color:#fff;font-size:12px;font-weight:600;cursor:pointer" onclick="htsFixBrokenClusters(this)">Recr&eacute;er les groupes</button>'
        . '<button class="hts-cc-btn outline sm" style="padding:7px 14px;border:1px solid var(--hts-border);border-radius:8px;background:var(--hts-bg);color:var(--hts-text-3);font-size:12px;cursor:pointer" onclick="htsCoconRestore(this)">Restaurer le backup</button>'
        . '</div>'
        . '</div></div>';
}

if ( $money_discovery_done && ! empty( $money_discovery['pages'] ) ) {
 foreach ( $money_discovery['pages'] as $mp ) {
 $mp_type = $mp['type'] ?? 'post';
 // ── Language filter: only show money pages matching current analysis language ──
 if ( $_hts_current_lang && $mp_type !== 'product_cat' && function_exists( 'pll_get_post_language' ) ) {
  $mp_lang = pll_get_post_language( (int) $mp['id'], 'slug' );
  if ( $mp_lang && $mp_lang !== $_hts_current_lang ) continue;
 }
 if ( $mp_type === 'product_cat') {
 $mp['dismissed'] = (bool) get_term_meta( $mp['id'], '_hts_money_page_dismissed', true );
 $mp['manual'] = false;
 $mp['cocon_count'] = 0; // Categories don't have cocon assignments yet
 } else {
 $mp['dismissed'] = (bool) get_post_meta( $mp['id'], '_hts_money_page_dismissed', true );
 $mp['manual'] = (bool) get_post_meta( $mp['id'], '_hts_money_page_manual', true );
 $mp['cocon_count'] = (int) $wpdb->get_var( $wpdb->prepare(
 "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_money_target'AND meta_value = %s",
 (string) $mp['id']
 ) );
 }
 if ( $mp['dismissed'] ) {
 $money_dismissed_data[] = $mp;
 } elseif ( ( $mp['score'] ?? 0 ) >= $money_threshold || ! empty( $mp['manual'] ) ) {
 $money_pages_data[] = $mp;
 }
 }
} elseif ( class_exists( 'HTS_Embeddings') ) {
 // Fallback: legacy method (pre-discovery)
 $mp_ids = HTS_Embeddings::get_money_pages();
 foreach ( $mp_ids as $mpid ) {
 $mp_post = get_post( (int) $mpid );
 if ( ! $mp_post || $mp_post->post_status !== 'publish') continue;
 $cocon_count = (int) $wpdb->get_var( $wpdb->prepare(
 "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_hts_money_target'AND meta_value = %s",
 (string) $mpid
 ) );
 $money_pages_data[] = array(
 'id'=> (int) $mpid,
 'title'=> $mp_post->post_title,
 'url'=> get_permalink( $mpid ),
 'score'=> 0,
 'reasons'=> array(),
 'cocon_count'=> $cocon_count,
 'gsc_clicks'=> (int) get_post_meta( $mpid, '_hts_gsc_clicks', true ),
 'gsc_pos'=> round( (float) get_post_meta( $mpid, '_hts_gsc_position', true ), 1 ),
 'manual'=> true,
 'dismissed'=> false,
 );
 }
}
$has_money_pages = ! empty( $money_pages_data );
$money_dismissed_count = count( $money_dismissed_data );

// ── Map: page_id → cluster name (for pages that are pillar of a cluster) ──
$pillar_to_cluster = array();
if ( ! empty( $clusters_data ) ) {
 foreach ( $clusters_data as $cl ) {
 $pid = (int) ( $cl['pillar_id'] ?? 0 );
 if ( $pid > 0 ) $pillar_to_cluster[ $pid ] = $cl['name'] ?? '';
 }
}
// Also map: page_id → cluster name for ANY page in a cluster (for non-pillar money pages)
$page_to_cluster = array();
if ( ! empty( $cluster_pages ) ) {
 foreach ( $cluster_pages as $cl_name => $pages ) {
 foreach ( $pages as $pg ) {
 $page_to_cluster[ (int) $pg['id'] ] = $cl_name;
 }
 }
}

// ── Check if clusters should be hidden (only after explicit "Tout supprimer" until maillage runs) ──
$awaiting_maillage = (bool) get_option( 'hts_cocon_awaiting_maillage', false );

// ── Count inbox linking actions (to show purge button even without clusters) ──
$inbox_linking_count = 0;
$wf_table_check = $wpdb->prefix . 'hts_workflow_actions';
if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wf_table_check ) ) === $wf_table_check ) {
 $inbox_linking_count = (int) $wpdb->get_var( $wpdb->prepare(
 "SELECT COUNT(*) FROM {$wf_table_check} WHERE agent = %s",
 'linking'
 ) );
}
$has_anything_to_purge = ! empty( $clusters_data ) || $has_money_pages || $money_discovery_done || $inbox_linking_count > 0;

// ── Cross-cocon proposals (inbox maillage) ──
$cross_cocon_enabled = (bool) get_option( 'hts_cross_cocon_enabled', false );
$cross_proposals_all = array();
if ( $cross_cocon_enabled ) {
 global $wpdb;
 $prop_rows = $wpdb->get_results(
 "SELECT p.ID, p.post_title, pm.meta_value AS proposals_json
 FROM {$wpdb->posts} p
 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_cross_cocon_proposals'
 WHERE p.post_status IN ('publish','draft','future')
 AND p.post_type IN ('post','page')
 ORDER BY p.post_date DESC
 LIMIT 100"
 );
 foreach ( $prop_rows as $pr ) {
 $props = maybe_unserialize( $pr->proposals_json );
 if ( ! is_array( $props ) || empty( $props ) ) continue;
 foreach ( $props as $idx => $prop ) {
 $prop['_post_id'] = (int) $pr->ID;
 $prop['_post_title'] = $pr->post_title;
 $prop['_prop_index'] = $idx;
 $cross_proposals_all[] = $prop;
 }
 }
}
$cross_pending = array_filter( $cross_proposals_all, function( $p ) { return ( $p['status'] ?? '') === 'pending'; } );
$cross_applied = array_filter( $cross_proposals_all, function( $p ) { return ( $p['status'] ?? '') === 'applied'; } );
$cross_history = array_filter( $cross_proposals_all, function( $p ) { return in_array( $p['status'] ?? '', array( 'applied', 'rolled_back', 'dismissed'), true ); } );

// ── Recommended links per cocon → DEFERRED to AJAX (perf: was blocking page load) ──
// loaded lazily via htsLoadRecommendedLinks() JS call after page render
$recommended_links_by_cocon = array();

// S6: $cross_count_by_post supprimé (HTML cross-cocon inbox supprimé)

$locale = get_locale();
$hreflang = str_replace( '_', '-', $locale );
// Sprint 6.3: if Polylang is active and filtering to a specific language, use that
if ( ! empty( $_hts_current_lang ) && strlen( $_hts_current_lang ) === 2 ) {
 // Polylang returns 'fr', 'en'etc — map to hreflang format
 $pll_locale_map = array(
 'fr'=> 'fr-FR', 'en'=> 'en-US', 'es'=> 'es-ES', 'de'=> 'de-DE',
 'it'=> 'it-IT', 'pt'=> 'pt-BR', 'nl'=> 'nl-NL',
 );
 if ( isset( $pll_locale_map[ $_hts_current_lang ] ) ) {
 $hreflang = $pll_locale_map[ $_hts_current_lang ];
 }
}
$lang_options = array(
 'fr-FR'=> 'Français (France)', 'fr-BE'=> 'Français (Belgique)',
 'fr-CA'=> 'Français (Canada)', 'fr-CH'=> 'Français (Suisse)',
 'en-US'=> 'English (US)', 'en-GB'=> 'English (UK)',
 'es-ES'=> 'Español', 'de-DE'=> 'Deutsch',
 'it-IT'=> 'Italiano', 'pt-BR'=> 'Português',
 'nl-NL'=> 'Nederlands',
);
if ( ! isset( $lang_options[ $hreflang ] ) ) $lang_options[ $hreflang ] = $hreflang;
?> <style>
/* ═══ BASE ═══ */
.hts-cc{font-family:var(--hts-font);max-width:1200px;margin:0 auto;padding:0 10px}
.hts-cc *{box-sizing:border-box}
.hts-cc h2{font-size:22px;font-weight:800;color:var(--hts-text);margin:0 0 4px;display:flex;align-items:center;gap:8px}
.hts-cc .subtitle{font-size:12px;color:var(--hts-text-2);margin-bottom:20px}
.hts-cc-section{margin-bottom:24px}
.hts-cc-card{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:var(--hts-radius);padding:20px;transition:box-shadow .15s}
.hts-cc-card:hover{box-shadow:var(--hts-shadow-md)}
.hts-cc-card h3{margin:0 0 14px;font-size:15px;font-weight:700;color:var(--hts-text)}
.hts-cc-badge{display:inline-block;font-size:10px;padding:2px 8px;border-radius:4px;font-weight:600}
.hts-cc-badge.green{background:var(--hts-success-bg);color:var(--hts-success)}.hts-cc-badge.orange{background:var(--hts-caution-bg);color:var(--hts-caution)}
.hts-cc-badge.red{background:var(--hts-danger-bg);color:var(--hts-danger)}.hts-cc-badge.blue{background:var(--hts-accent-bg);color:var(--hts-accent)}
.hts-cc-badge.gray{background:var(--hts-gray-100);color:var(--hts-gray-600)}
.hts-cc-btn{font-size:12px;padding:8px 16px;border-radius:var(--hts-radius-sm);cursor:pointer;font-weight:600;border:none;transition:all var(--hts-dur-fast);display:inline-flex;align-items:center;gap:4px;font-family:var(--hts-font)}
.hts-cc-btn.primary{background:var(--hts-geo);color:#fff}.hts-cc-btn.primary:hover{opacity:.9}
.hts-cc-btn.outline{background:none;color:var(--hts-geo);border:1px solid var(--hts-geo-border)}.hts-cc-btn.outline:hover{border-color:var(--hts-geo)}
.hts-cc-btn.danger{background:var(--hts-danger-bg);color:var(--hts-danger)}.hts-cc-btn.sm{font-size:10px;padding:4px 10px}
.hts-cc-btn:disabled{opacity:.5;cursor:not-allowed}
.hts-cc-form label{font-size:11px;font-weight:600;color:var(--hts-gray-600);display:block;margin-bottom:4px}
.hts-cc-form input,.hts-cc-form select{width:100%;padding:8px 12px;border:1px solid var(--hts-border);border-radius:var(--hts-radius-sm);font-size:13px;box-sizing:border-box;font-family:var(--hts-font)}
.hts-cc-form input:focus,.hts-cc-form select:focus{border-color:var(--hts-geo);outline:none;box-shadow:0 0 0 3px rgba(99,102,241,.1)}
.hts-cc-progress-bar{background:var(--hts-surface);border-radius:6px;height:8px;overflow:hidden}
.hts-cc-progress-fill{height:100%;border-radius:6px;transition:width .5s}

/* ═══ COCON GRID ═══ */
.hts-cocon-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:900px){.hts-cocon-grid{grid-template-columns:1fr}}
.hts-cocon-card{background:#fff;border:1px solid var(--hts-border);border-radius:12px;overflow:hidden;transition:box-shadow .15s}
.hts-cocon-card:hover{box-shadow:0 2px 10px rgba(0,0,0,.06)}
.hts-cocon-card-head{padding:16px 18px}
.hts-cocon-card-body{border-top:1px solid var(--hts-surface);padding:14px 18px}

/* ═══ PLANNING ═══ */
.hts-planning-split{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start}
@media(max-width:900px){.hts-planning-split{grid-template-columns:1fr}}
.hts-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}
.hts-cal-day{min-height:80px;background:var(--hts-surface);border:2px solid var(--hts-border);border-radius:8px;padding:6px 8px;font-size:10px;transition:all .2s}
.hts-cal-day.today{background:var(--hts-accent-bg);border-color:var(--hts-accent)}
.hts-cal-day.drop-over{background:var(--hts-success-bg);border-color:var(--hts-success);box-shadow:0 0 0 2px rgba(34,197,94,.25)}
.hts-cal-day .day-label{font-weight:700;margin-bottom:4px}
.hts-cal-day .cal-item{background:var(--hts-success-bg);border-radius:4px;padding:3px 6px;margin-bottom:3px;font-size:9px;color:var(--hts-success);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ═══ DRAG ITEMS ═══ */
.hts-drag-item{display:flex;align-items:center;gap:8px;padding:8px 12px;background:#fff;border:1px solid var(--hts-border);border-radius:8px;margin-bottom:6px;cursor:grab;transition:all .15s;font-size:12px}
.hts-drag-item:hover{border-color:var(--hts-geo);box-shadow:0 1px 4px rgba(99,102,241,.1)}
.hts-drag-item.dragging{opacity:.4;transform:scale(.95)}
.hts-drag-item .drag-handle{color:var(--hts-text-3);cursor:grab;flex-shrink:0;font-size:14px}
.hts-drag-item .drag-title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hts-drag-item .drag-cocon{font-size:9px;color:var(--hts-geo);flex-shrink:0}
.hts-drag-item .drag-actions{display:flex;gap:4px;flex-shrink:0;align-items:center}

/* ═══ ARTICLE ROWS ═══ */
.hts-art-row{display:flex;align-items:center;gap:6px;padding:5px 8px;border-radius:6px;font-size:11px;transition:background .1s}
.hts-art-row:hover{background:var(--hts-surface)}
.hts-art-row.generated{background:var(--hts-success-bg)}
.hts-status-badge{font-size:9px;padding:2px 8px;border-radius:10px;font-weight:600;white-space:nowrap;flex-shrink:0}

/* ═══ STAT BOXES ═══ */
.hts-stat-box{text-align:center;padding:12px 16px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:10px}
.hts-stat-box .num{font-size:22px;font-weight:800;color:var(--hts-text)}
.hts-stat-box .lbl{font-size:10px;color:var(--hts-text-2);margin-top:2px}

/* ═══ LOGS ═══ */
.hts-cc-log-table{width:100%;border-collapse:collapse}
.hts-cc-log-table td{padding:4px 6px;font-size:11px;border-bottom:1px solid var(--hts-surface)}

/* ═══ TOAST ═══ */
.hts-toast{position:fixed;bottom:20px;right:20px;padding:12px 20px;background:var(--hts-text);color:#fff;border-radius:10px;font-size:13px;z-index:9999;opacity:0;transform:translateY(10px);transition:all .3s;pointer-events:none}
.hts-toast.show{opacity:1;transform:translateY(0)}
.hts-toast.success{background:var(--hts-success)}.hts-toast.error{background:var(--hts-danger)}

@keyframes hts-spin{to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes hts-dot-pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.4);opacity:.6}}
@media screen and (max-width:782px){#hts-graph-view{top:46px!important}}
.hts-rl-card{background:var(--hts-bg);border:1px solid var(--hts-border);border-radius:14px;margin-bottom:12px;overflow:hidden}
.hts-rl-card-head{padding:16px 20px;display:flex;align-items:center;gap:14px}
.hts-rl-spinner{width:32px;height:32px;border-radius:50%;border:3px solid var(--hts-border-sub);border-top-color:var(--hts-geo);flex-shrink:0;animation:hts-spin .8s linear infinite}
.hts-rl-spinner.done{border-color:var(--hts-success);border-top-color:var(--hts-success);animation:none;background:var(--hts-success-bg)}
.hts-rl-spinner.error{border-color:var(--hts-danger);border-top-color:var(--hts-danger);animation:none;background:var(--hts-danger-bg)}
.hts-rl-bar{height:4px;background:var(--hts-border-sub)}.hts-rl-bar-fill{height:100%;background:linear-gradient(90deg,var(--hts-geo),var(--hts-accent));border-radius:0 2px 2px 0;transition:width .5s}
.hts-rl-steps{padding:14px 20px;background:var(--hts-surface);border-top:1px solid var(--hts-border-sub)}
.hts-rl-step{display:flex;align-items:flex-start;gap:12px;position:relative}
.hts-rl-step-line{position:absolute;left:9px;top:22px;width:2px;height:28px;background:var(--hts-border-sub);transition:background .3s}
.hts-rl-step-line.done{background:var(--hts-success)}
.hts-rl-dot{width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px;transition:background .3s}
.hts-rl-dot.done{background:var(--hts-success)}.hts-rl-dot.active{background:var(--hts-geo)}.hts-rl-dot.pending{background:var(--hts-border-sub)}
.hts-rl-dot.active .hts-rl-pulse{width:6px;height:6px;border-radius:50%;background:#fff;animation:hts-dot-pulse 1.2s ease-in-out infinite}
.hts-rl-step-body{flex:1;padding-bottom:14px}
.hts-rl-step-label{font-size:12px;font-weight:500;color:var(--hts-text)}.hts-rl-step-label.active{font-weight:700}.hts-rl-step-label.pending{color:var(--hts-text-3)}
.hts-rl-step-detail{font-size:11px;color:var(--hts-text-3);margin-top:2px}.hts-rl-step-detail.active{color:var(--hts-geo)}
.hts-rl-step-time{font-size:10px;color:var(--hts-text-3);font-family:monospace}
.hts-rl-retry{font-size:10px;padding:4px 10px;background:var(--hts-danger-bg);border:1px solid var(--hts-danger);border-radius:6px;color:var(--hts-danger);cursor:pointer;font-weight:600;font-family:var(--hts-font);margin-top:6px}
.hts-cc-empty{text-align:center;padding:40px 20px;color:var(--hts-text-2)}
.hts-cc-empty .icon{font-size:40px;margin-bottom:10px}

/* S6: cluster-grid, cluster-card, cross-table CSS supprimés (code mort) */

/* ═══ MODAL ═══ */
.hts-modal-overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.45);z-index:99999;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;pointer-events:none}
.hts-modal-overlay.active{opacity:1;pointer-events:auto}
.hts-modal{background:#fff;border-radius:14px;padding:28px 32px;max-width:440px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.2);transform:scale(.95);transition:transform .2s}
.hts-modal-overlay.active .hts-modal{transform:scale(1)}
.hts-modal h4{margin:0 0 10px;font-size:16px;font-weight:700;color:var(--hts-text)}
.hts-modal p{margin:0 0 18px;font-size:13px;color:var(--hts-text-2);line-height:1.5}
.hts-modal-actions{display:flex;gap:8px;justify-content:flex-end}

/* ═══ REC LINKS ═══ */
.hts-rec-link{display:flex;align-items:center;gap:6px;padding:4px 8px;border-radius:5px;font-size:10px;transition:background .1s}
.hts-rec-link:hover{background:var(--hts-success-bg)}

/* ═══ MONEY COCON ═══ */
.hts-mp-score{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;flex-shrink:0;line-height:1}
.hts-mc-dismiss-btn{width:28px;height:28px;border-radius:50%;border:1px solid var(--hts-border);background:#fff;cursor:pointer;font-size:14px;color:var(--hts-text-3);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .15s;font-family:inherit;padding:0}
.hts-mc-dismiss-btn:hover{background:var(--hts-danger-bg);border-color:var(--hts-danger-bg);color:var(--hts-danger)}
.hts-mp-card.dismissed{opacity:.5;border-style:dashed}
.hts-mc-empty{text-align:center;padding:32px 20px}
.hts-mc-empty-icon{font-size:36px;margin-bottom:8px}
.hts-mc-empty-title{font-size:14px;font-weight:700;color:var(--hts-text);margin-bottom:4px}
.hts-mc-empty-desc{font-size:12px;color:var(--hts-text-2);margin-bottom:16px;line-height:1.5}
.hts-money-mode-toggle{display:flex;background:var(--hts-surface);border-radius:10px;padding:3px;border:1px solid var(--hts-border)}
.hts-money-mode-btn{flex:1;padding:8px 12px;border-radius:8px;border:none;cursor:pointer;font-family:inherit;text-align:center;background:transparent;transition:all .2s}
.hts-money-mode-btn.active{background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.hts-money-mode-btn .icon{font-size:14px;display:block;margin-bottom:2px}
.hts-money-mode-btn .lbl{font-size:11px;font-weight:700;color:var(--hts-text-3)}
.hts-money-mode-btn.active .lbl{color:var(--hts-text)}
.hts-money-mode-btn .desc{font-size:9px;color:var(--hts-text-3)}
.hts-mp-card{display:flex;align-items:center;gap:12px;padding:14px 16px;background:#fff;border:1px solid var(--hts-border);border-radius:10px;margin-bottom:6px;cursor:pointer;transition:all .15s}
.hts-mp-card:hover{border-color:var(--hts-caution);box-shadow:0 2px 8px rgba(217,119,6,.08)}
.hts-mp-icon{width:40px;height:40px;border-radius:8px;background:var(--hts-caution-bg);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.hts-mp-info{flex:1;min-width:0}
.hts-mp-title{font-size:13px;font-weight:700;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hts-mp-url{font-size:10px;color:var(--hts-text-3);font-family:monospace}
.hts-mp-badges{display:flex;gap:4px;margin-top:3px;flex-wrap:wrap;align-items:center}
.hts-mc-article{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:8px;margin-bottom:3px;border:1px solid var(--hts-surface);transition:all .1s}
.hts-mc-article.checked{background:#fff;border-color:var(--hts-border)}
.hts-mc-article.checked.budget-full{background:var(--hts-danger-bg);border-color:var(--hts-danger-bg)}
.hts-mc-article.unchecked{background:var(--hts-surface);opacity:.55}
.hts-mc-cb{width:18px;height:18px;border-radius:4px;border:2px solid var(--hts-border);background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .15s}
.hts-mc-cb.on{background:var(--hts-geo);border-color:var(--hts-geo)}
.hts-mc-cb.on::after{content:'\2713';color:#fff;font-size:11px}
.hts-budget-bar{display:flex;align-items:center;gap:4px;flex-shrink:0}
.hts-budget-track{width:40px;height:5px;background:var(--hts-surface);border-radius:3px;overflow:hidden}
.hts-budget-fill{height:100%;border-radius:3px;transition:width .3s}
.hts-mc-role-btn{font-size:9px;padding:2px 6px;border-radius:4px;cursor:pointer;border:1px solid var(--hts-border);font-family:inherit;font-weight:600;white-space:nowrap;transition:all .1s}
.hts-mc-step{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:6px;font-size:12px;margin-bottom:4px}
.hts-mc-sticky{position:sticky;bottom:0;background:#fff;border-top:1px solid var(--hts-border);padding:10px 14px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 -4px 12px rgba(0,0,0,.04);margin-top:12px;border-radius:0 0 12px 12px}
.hts-mc-progress{max-width:300px;margin:12px auto;background:var(--hts-surface);border-radius:8px;height:8px;overflow:hidden}
.hts-mc-progress-fill{height:100%;background:var(--hts-geo);border-radius:8px;transition:width .4s}
/* ═══ MONEY PAGES PANEL ═══ */
.hts-mp-panel{background:#fff;border:1px solid var(--hts-border);border-radius:12px;margin-bottom:16px;overflow:visible}
.hts-mp-header{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;cursor:pointer;user-select:none;transition:background .15s}
.hts-mp-header:hover{background:var(--hts-surface)}
.hts-mp-header h4{margin:0;font-size:14px;font-weight:700;color:var(--hts-text);display:flex;align-items:center;gap:6px}
.hts-mp-header .mp-toggle{font-size:11px;color:var(--hts-text-3);transition:transform .2s}
.hts-mp-header .mp-toggle.open{transform:rotate(90deg)}
.hts-mp-body{padding:0 18px 16px;display:none}
.hts-mp-body.open{display:block}
.hts-mp-list{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}
.hts-mp-row{display:flex;align-items:center;gap:10px;padding:10px 14px;border:1px solid var(--hts-surface);border-radius:10px;transition:all .2s;background:#fff}
.hts-mp-row:hover{border-color:var(--hts-geo-soft);box-shadow:0 1px 4px rgba(99,102,241,.06)}
.hts-mp-row.dismissed{opacity:.45;background:var(--hts-surface)}
.hts-mp-switch{position:relative;width:36px;height:20px;flex-shrink:0}
.hts-mp-switch input{opacity:0;width:0;height:0}
.hts-mp-switch .slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:var(--hts-border);border-radius:20px;transition:.2s}
.hts-mp-switch .slider::before{content:'';position:absolute;height:16px;width:16px;left:2px;bottom:2px;background:#fff;border-radius:50%;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.12)}
.hts-mp-switch input:checked+.slider{background:var(--hts-geo)}
.hts-mp-switch input:checked+.slider::before{transform:translateX(16px)}
.hts-mp-info{flex:1;min-width:0}
.hts-mp-title{font-size:12px;font-weight:600;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hts-mp-title a{color:var(--hts-text);text-decoration:none}.hts-mp-title a:hover{color:var(--hts-geo)}
.hts-mp-meta{display:flex;gap:6px;align-items:center;margin-top:3px;flex-wrap:wrap}
.hts-mp-score{font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;display:inline-flex;align-items:center;gap:3px}
.hts-mp-score.high{background:var(--hts-success-bg);color:var(--hts-success)}.hts-mp-score.mid{background:var(--hts-caution-bg);color:var(--hts-caution)}.hts-mp-score.low{background:var(--hts-danger-bg);color:var(--hts-danger)}
.hts-mp-signal{font-size:9px;color:var(--hts-text-2);background:var(--hts-surface);padding:2px 6px;border-radius:4px}
.hts-mp-cocon-ct{font-size:9px;color:var(--hts-geo);font-weight:600}
.hts-mp-actions{display:flex;gap:4px;flex-shrink:0;align-items:center}
.hts-mp-search-wrap{position:relative;margin-top:2px}
.hts-mp-search{width:100%;padding:10px 14px 10px 34px;border:1px dashed var(--hts-border);border-radius:10px;font-size:12px;background:var(--hts-surface);transition:all .2s;box-sizing:border-box}
.hts-mp-search:focus{outline:none;border-color:var(--hts-geo);border-style:solid;background:#fff;box-shadow:0 0 0 3px rgba(99,102,241,.08)}
.hts-mp-search-icon{position:absolute;left:12px;top:50%;transform:translateY(-50%);font-size:14px;color:var(--hts-text-3);pointer-events:none}
.hts-mp-results{position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid var(--hts-border);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.12);z-index:9999;max-height:260px;overflow-y:auto;display:none;margin-top:4px}
.hts-mp-results.open{display:block}
.hts-mp-result{display:flex;align-items:center;gap:8px;padding:10px 14px;cursor:pointer;font-size:12px;transition:background .1s;border-bottom:1px solid var(--hts-surface)}
.hts-mp-result:last-child{border-bottom:none}
.hts-mp-result:hover{background:var(--hts-info-bg)}
.hts-mp-result.already{opacity:.4;cursor:not-allowed}
.hts-mp-result .r-type{font-size:9px;color:var(--hts-text-3);background:var(--hts-surface);padding:1px 6px;border-radius:4px;flex-shrink:0}
.hts-mp-dismissed-toggle{font-size:11px;color:var(--hts-text-3);cursor:pointer;padding:6px 0;display:flex;align-items:center;gap:4px;transition:color .15s}
.hts-mp-dismissed-toggle:hover{color:var(--hts-text-2)}
.hts-mp-dismissed-list{display:none;border-top:1px solid var(--hts-surface);padding-top:10px;margin-top:6px}
</style> <?php echo HTS_DS::page_open( true ); ?>

<!-- ═══ HERO JSX S6 ═══ -->
<div style="background:linear-gradient(135deg,#1D1D1F 0%,#2D2D30 60%,#1D1D1F 100%);border-radius:28px;padding:32px 36px;margin-bottom:24px;position:relative;overflow:hidden">
	<div style="position:absolute;top:-30px;right:-30px;width:180px;height:180px;border-radius:50%;background:radial-gradient(circle,rgba(99,102,241,.08) 0%,transparent 70%);pointer-events:none"></div>
	<div style="position:relative;z-index:1">
		<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
			<div>
				<h1 style="font-size:26px;font-weight:800;color:#fff;margin:0;letter-spacing:-.03em">Groupes de contenus</h1>
				<p style="font-size:14px;color:rgba(255,255,255,.5);margin:6px 0 0">Organisez vos articles pour dominer Google et les IA</p>
			</div>
			<div style="display:flex;gap:8px">
				<?php if ( ! empty( $hts_api_key ) ) : ?>
				<button class="hts-cc-btn" style="display:flex;align-items:center;gap:5px;padding:8px 16px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font)" id="hts-cc-full-refresh-btn" onclick="htsLangThenRefresh(this)"><?php echo HTS_DS::icon('refresh',13,'#fff'); ?> Lancer l&#039;analyse</button>
				<!-- Nouveau groupe: déplacé dans Outils avancés -->
				<?php endif; ?>
			</div>
		</div>
		<!-- KPIs -->
		<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px">
			<?php
			$hero_kpis = array(
				array( 'l' => 'Groupes', 'v' => $total_plans ),
				array( 'l' => 'Articles rédigés', 'v' => $total_gen . '/' . $total_art ),
				array( 'l' => 'À rédiger', 'v' => $total_todo, 'c' => $total_todo > 0 ? 'var(--hts-caution)' : '' ),
				array( 'l' => 'Publiés cette sem.', 'v' => $auto_sched_week . '/' . $auto_sched_max ),
				array( 'l' => 'Indexation', 'v' => $emb_pct . '%', 'c' => $emb_pct >= 80 ? 'var(--hts-success)' : ( $emb_pct >= 50 ? 'var(--hts-caution)' : 'var(--hts-danger)' ) ),
			);
			foreach ( $hero_kpis as $k ) : ?>
			<div style="text-align:center;padding:10px 8px;border-radius:10px;background:rgba(255,255,255,.04)">
				<div style="font-size:20px;font-weight:800;color:<?php echo ! empty( $k['c'] ) ? $k['c'] : '#fff'; ?>"><?php echo $k['v']; ?></div>
				<div style="font-size:9px;color:rgba(255,255,255,.35);font-weight:600;text-transform:uppercase;margin-top:2px"><?php echo esc_html( $k['l'] ); ?></div>
			</div>
			<?php endforeach; ?>
		</div>
		<!-- Analysis status bar -->
		<?php if ( $is_analyzed ) : ?>
		<div style="display:flex;align-items:center;gap:12px;margin-top:16px">
			<span style="font-size:11px;color:rgba(255,255,255,.4)">Analyse active — <?php echo count( $clusters_data ); ?> groupes · <?php echo (int) ( $cocon_stats['stats']['total_pages'] ?? 0 ); ?> pages · <?php echo $emb_pct; ?>% analys&#233;</span>
			<div style="flex:1;height:4px;border-radius:2px;background:rgba(255,255,255,.06);max-width:200px"><div style="width:<?php echo $emb_pct; ?>%;height:100%;border-radius:2px;background:var(--hts-success)"></div></div>
		</div>
		<?php endif; ?>
	</div>
</div>
<!-- ═══ ANALYSIS PROGRESS BAR ═══ -->
<div id="hts-analysis-progress" style="display:none;margin:0 0 2px;padding:14px 20px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:0 0 12px 12px;margin-top:-2px">
	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
		<span id="hts-ap-label" style="font-size:12px;font-weight:600;color:var(--hts-text)">Preparation...</span>
		<span id="hts-ap-detail" style="font-size:11px;color:var(--hts-text-3)"></span>
	</div>
	<div style="height:4px;border-radius:2px;background:var(--hts-border);overflow:hidden">
		<div id="hts-ap-bar" style="height:100%;border-radius:2px;background:var(--hts-accent);width:0;transition:width .4s ease"></div>
	</div>
	<div id="hts-ap-steps" style="display:flex;gap:6px;margin-top:10px">
		<span class="hts-ap-dot" data-step="embed" style="display:flex;align-items:center;gap:4px;font-size:10px;color:var(--hts-text-3)"><span style="width:6px;height:6px;border-radius:50%;background:var(--hts-border);display:inline-block" id="hts-ap-dot-embed"></span>Indexation</span>
		<span class="hts-ap-dot" data-step="nlp" style="display:flex;align-items:center;gap:4px;font-size:10px;color:var(--hts-text-3)"><span style="width:6px;height:6px;border-radius:50%;background:var(--hts-border);display:inline-block" id="hts-ap-dot-nlp"></span>Clustering</span>
		<span class="hts-ap-dot" data-step="done" style="display:flex;align-items:center;gap:4px;font-size:10px;color:var(--hts-text-3)"><span style="width:6px;height:6px;border-radius:50%;background:var(--hts-border);display:inline-block" id="hts-ap-dot-done"></span>Terminé</span>
	</div>
</div>

<?php
// Bug 1+2 fix: Create cocon panel ABOVE clusters, hidden by default unless first visit
$_show_create_panel = empty( $plans ) && empty( $clusters_data ) && ! $has_money_pages;
?>
<!-- Create cocon panel — hidden when no clusters exist (visible via htsPrefillCocon or Outils avancés) -->
<?php if ( ! empty( $clusters_data ) || $_show_create_panel ) : ?>
<div id="hts-create-cocon-panel" class="hts-cc-card hts-cc-form" style="<?php echo $_show_create_panel ? '' : 'display:none;'; ?>margin-bottom:16px;"> <h3 id="hts-create-cocon-title"> Créer un cocon</h3> <div id="hts-reinforce-banner" style="display:none;margin:0 0 12px;padding:10px 14px;background:var(--hts-accent-bg);border:1px solid var(--hts-info-bg);border-radius:8px;font-size:12px;color:var(--hts-info);"> <strong> Renforcer le cocon</strong> « <span id="hts-reinforce-kw"></span> »
 <span style="font-size:11px;display:block;margin-top:3px;color:var(--hts-text-2);">Un nouveau plan sera généré pour cette money page. Les nouveaux articles viendront compléter les <span id="hts-reinforce-count">0</span> articles existants.</span> <button type="button" onclick="htsClearReinforce()" style="font-size:10px;margin-top:4px;padding:2px 8px;background:none;border:1px solid var(--hts-accent);border-radius:4px;cursor:pointer;color:var(--hts-info);"> Nouveau cocon vierge</button> </div> <p id="hts-create-cocon-desc" style="font-size:12px;color:var(--hts-text-2);margin:0 0 14px;"><?php echo $_hts_can_write ? 'Entrez l&#39;URL de votre page principale et un mot-clé. Hack The SEO génère automatiquement des articles satellites.' : 'Hack The SEO analyse votre mot-clé et propose une structure d&#39;articles. La rédaction automatique est disponible avec le plan Ultra.'; ?></p> <?php if ( empty( $hts_api_key ) ) : ?> <div style="background:var(--hts-danger-bg);border:1px solid var(--hts-danger-bg);border-radius:8px;padding:12px 16px;font-size:12px;"><strong style="color:var(--hts-danger);"> Clé API manquante.</strong> <a href="<?php echo admin_url('admin.php?page=hts-api-settings'); ?>" style="color:var(--hts-geo);font-weight:600;">Configurer →</a></div> <?php else : ?> <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;"> <div><label>Money Page (URL) *</label><input type="url" id="hts-cc-pillar" placeholder="https://votre-site.com/votre-service/" onblur="htsCheckPillar()"><div style="font-size:9px;color:var(--hts-text-3);margin-top:3px;">La page qui doit se positionner</div></div> <div><label>Mot-clé principal *</label><input type="text" id="hts-cc-keyword" placeholder="Ex: référencement naturel"></div> <div><label>Langue</label><select id="hts-cc-lang"><?php foreach ( $lang_options as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $code, $hreflang ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div> <div><label>Nombre d&#39;articles</label><input type="number" id="hts-cc-max" value="15" min="1" max="50"><div style="font-size:9px;color:var(--hts-text-3);margin-top:3px;">10–20 recommandé</div></div> </div> <div id="hts-cc-pillar-health" style="display:none;margin-bottom:12px;padding:8px 12px;border-radius:8px;font-size:11px;"></div> <div style="display:flex;align-items:center;gap:12px;"> <button type="button" class="hts-cc-btn primary" id="hts-cc-gen-btn" onclick="htsGenPlan()" style="font-size:13px;padding:10px 22px;"> Créer de nouveaux contenus</button> <span id="hts-cc-gen-status" style="font-size:11px;"></span> </div> <?php if ( ! $_hts_can_write ) : ?><div style="margin-top:10px;padding:10px 14px;background:var(--hts-surface);border-radius:8px;font-size:11px;color:var(--hts-text-3);line-height:1.5">L'IA va analyser votre thématique et proposer des sujets d'articles. La rédaction automatique avec images et liens internes est disponible avec le <a href="https://hacktheseo.com/pricing" target="_blank" style="color:var(--hts-geo);font-weight:600;text-decoration:none">plan Ultra (249€/mois)</a>.</div><?php endif; ?> <?php endif; ?> </div>
<?php endif; /* clusters_data or _show_create_panel */ ?>
<!-- Polling + Progress -->
<div id="hts-cc-polling" style="display:none;margin-bottom:16px;padding:14px 20px;background:var(--hts-accent-bg);border:1px solid var(--hts-accent);border-radius:10px;"> <span style="display:inline-block;width:16px;height:16px;border:2px solid var(--hts-accent);border-top-color:var(--hts-accent);border-radius:50%;animation:hts-spin .8s linear infinite;margin-right:8px;vertical-align:middle;"></span> <span id="hts-cc-polling-text" style="font-size:13px;color:var(--hts-accent);font-weight:500;">Génération en cours...</span>
</div>
<div class="hts-cc">
<div class="hts-cc-section">
<?php /* AUTO-PUBLISH BAR — disabled for now, will be re-enabled when auto-schedule is active
<?php if ( $pipeline_queued > 0 ) : ?> <div>...</div> <?php endif; ?>
*/ ?>
</div><!-- /hts-cc-section -->

<!-- ═══ PILL TABS (JSX S6) ═══ -->
<?php
// ── Dedup plans: group by pillar_url, keep main plan (most articles rédigés) per pillar ──
$_plans_by_pillar = array();
foreach ( $plans as $_pid => $_pp ) {
	$_purl = rtrim( $_pp['pillar_url'] ?? '', '/' );
	if ( ! $_purl ) $_purl = $_pp['keyword'] ?? $_pid;
	$_gen = 0;
	foreach ( ( $_pp['articles'] ?? array() ) as $_a ) {
		if ( in_array( $_a['status'] ?? '', array( 'received', 'ready' ), true ) ) $_gen++;
	}
	$_plans_by_pillar[ $_purl ][] = array( 'id' => $_pid, 'gen' => $_gen );
}
$_hidden_plan_ids = array();
$_cocon_fallback_map = array(); // satellite_id => main_id
foreach ( $_plans_by_pillar as $_purl => $_group ) {
	if ( count( $_group ) <= 1 ) continue;
	usort( $_group, function( $a, $b ) { return $b['gen'] - $a['gen']; } );
	$_main_id = $_group[0]['id'];
	for ( $i = 1; $i < count( $_group ); $i++ ) {
		$_hidden_plan_ids[] = $_group[ $i ]['id'];
		$_cocon_fallback_map[ $_group[ $i ]['id'] ] = $_main_id;
	}
}

// ── S4: Build unified $groups — merge clusters + plans ──
$groups = array();
$_matched_cluster_names = array();
foreach ( $plans as $_gcid => $_gcp ) {
	if ( in_array( $_gcid, $_hidden_plan_ids, true ) ) continue;
	$_g = array( 'plan_id' => $_gcid, 'plan' => $_gcp, 'cluster' => null );
	$_gpillar = $_gcp['pillar_url'] ?? '';
	$_gkw = $_gcp['keyword'] ?? $_gcp['pillar_title'] ?? $_gcid;
	$_gmatched = '';
	if ( $_gpillar ) {
		$_gpid = hts_url_to_postid( $_gpillar );
		if ( $_gpid > 0 ) {
			if ( isset( $pillar_to_cluster[ $_gpid ] ) ) $_gmatched = $pillar_to_cluster[ $_gpid ];
			elseif ( isset( $page_to_cluster[ $_gpid ] ) ) $_gmatched = $page_to_cluster[ $_gpid ];
		}
	}
	if ( $_gpillar && ! $_gmatched ) {
		$_gpath = trim( parse_url( $_gpillar, PHP_URL_PATH ) ?: '', '/' );
		if ( $_gpath ) {
			$_gpg = get_page_by_path( $_gpath, OBJECT, array( 'post', 'page' ) );
			if ( $_gpg ) {
				if ( isset( $pillar_to_cluster[ $_gpg->ID ] ) ) $_gmatched = $pillar_to_cluster[ $_gpg->ID ];
				elseif ( isset( $page_to_cluster[ $_gpg->ID ] ) ) $_gmatched = $page_to_cluster[ $_gpg->ID ];
			} else {
				$_gparts = explode( '/', $_gpath );
				if ( count( $_gparts ) >= 2 && mb_strlen( $_gparts[0] ) <= 3 ) {
					$_gbare = implode( '/', array_slice( $_gparts, 1 ) );
					$_gpg2 = get_page_by_path( $_gbare, OBJECT, array( 'post', 'page' ) );
					if ( $_gpg2 ) {
						if ( isset( $pillar_to_cluster[ $_gpg2->ID ] ) ) $_gmatched = $pillar_to_cluster[ $_gpg2->ID ];
						elseif ( isset( $page_to_cluster[ $_gpg2->ID ] ) ) $_gmatched = $page_to_cluster[ $_gpg2->ID ];
					}
				}
			}
		}
	}
	if ( ! $_gmatched && ! empty( $clusters_data ) ) {
		foreach ( $clusters_data as $_gcl ) {
			if ( ( $_gcl['name'] ?? '' ) === $_gkw ) { $_gmatched = $_gcl['name']; break; }
		}
	}
	if ( ! $_gmatched && ! empty( $clusters_data ) ) {
		$_gkw_low = mb_strtolower( $_gkw );
		foreach ( $clusters_data as $_gcl ) {
			$_gcn = $_gcl['name'] ?? '';
			if ( ! $_gcn ) continue;
			$_gcn_low = mb_strtolower( $_gcn );
			if ( mb_strpos( $_gkw_low, $_gcn_low ) !== false || mb_strpos( $_gcn_low, $_gkw_low ) !== false ) {
				$_gmatched = $_gcn; break;
			}
		}
	}
	if ( $_gmatched ) {
		foreach ( $clusters_data as $_gcl ) {
			if ( ( $_gcl['name'] ?? '' ) === $_gmatched ) {
				$_g['cluster'] = $_gcl;
				$_matched_cluster_names[] = $_gmatched;
				break;
			}
		}
	}
	$groups[] = $_g;
}
if ( ! empty( $clusters_data ) ) {
	foreach ( $clusters_data as $_gcl ) {
		$_gcn = $_gcl['name'] ?? '';
		if ( $_gcn && ! in_array( $_gcn, $_matched_cluster_names, true ) ) {
			$groups[] = array( 'plan_id' => null, 'plan' => null, 'cluster' => $_gcl );
		}
	}
}
$total_groups = count( $groups );
?>
<script>
/* Tier gating variables — must be before any graph JS that references them */
var htsTier=<?php echo (int) $_hts_tier; ?>,htsCanWrite=<?php echo $_hts_can_write ? 'true' : 'false'; ?>,htsCanApply=<?php echo $_hts_can_apply ? 'true' : 'false'; ?>;
window._htsSaasUrl='<?php echo esc_js( get_option( "hts_api_base_url", "https://app.hacktheseo.com" ) ); ?>';
</script>
<script>window._htsFallbackMap=<?php echo wp_json_encode( (object) $_cocon_fallback_map ); ?>;
window._htsPlanArticles=<?php
// Articles to_generate par cocon_id — pour staging panel auto au chargement du graph
$_plan_todo = array();
foreach ( $plans as $_ptid => $_ptplan ) {
	$_ptarts = array();
	foreach ( ( $_ptplan['articles'] ?? array() ) as $_ptakey => $_ptart ) {
		$_ptas = $_ptart['status'] ?? 'to_generate';
		if ( $_ptas === 'to_generate' ) {
			$_ptarts[] = array(
				'title'    => $_ptart['title'] ?? $_ptart['keyword'] ?? '',
				'keyword'  => $_ptart['keyword'] ?? '',
				'akey'     => $_ptakey,
				'category' => $_ptart['category'] ?? '',
			);
		}
	}
	if ( ! empty( $_ptarts ) ) {
		$_plan_todo[ $_ptid ] = $_ptarts;
	}
}
echo wp_json_encode( (object) $_plan_todo );
?>;
window._htsProposedLinks=<?php
// Proposed links (Inbox pending) grouped by cluster name — for dashed lines in graph
$_page_to_cluster = array();
foreach ( $cluster_pages as $_cl_n => $_cl_pgs ) {
	foreach ( $_cl_pgs as $_cpg ) {
		$_page_to_cluster[ (int) $_cpg['id'] ] = $_cl_n;
	}
}
$_proposed_by_cluster = array();
foreach ( $cross_pending as $_cp ) {
	$_src_id = (int) ( $_cp['_post_id'] ?? 0 );
	$_tgt_id = (int) ( $_cp['target_id'] ?? 0 );
	if ( ! $_src_id || ! $_tgt_id ) continue;
	// Find which cluster this link belongs to (source or target)
	$_cl = '';
	if ( isset( $_page_to_cluster[ $_src_id ] ) ) $_cl = $_page_to_cluster[ $_src_id ];
	elseif ( isset( $_page_to_cluster[ $_tgt_id ] ) ) $_cl = $_page_to_cluster[ $_tgt_id ];
	if ( ! $_cl ) continue;
	if ( ! isset( $_proposed_by_cluster[ $_cl ] ) ) $_proposed_by_cluster[ $_cl ] = array();
	$_proposed_by_cluster[ $_cl ][] = array(
		'source' => $_src_id,
		'target' => $_tgt_id,
		'anchor' => $_cp['anchor_text'] ?? '',
	);
}
// Also include missing_links from cluster analysis (for sites without Inbox/crons)
foreach ( $clusters_data as $_cl_n => $_cl_data ) {
	if ( ! empty( $_cl_data['missing_links'] ) ) {
		if ( ! isset( $_proposed_by_cluster[ $_cl_n ] ) ) $_proposed_by_cluster[ $_cl_n ] = array();
		foreach ( $_cl_data['missing_links'] as $_ml ) {
			$_proposed_by_cluster[ $_cl_n ][] = array(
				'source' => (int) $_ml['source_id'],
				'target' => (int) $_ml['target_id'],
				'anchor' => $_ml['anchor'] ?? '',
			);
		}
	}
}
// ── TEST: inject 3 proposed links from real cluster pages for visual testing ──
if ( defined( 'HTS_UNLOCK_ALL' ) && HTS_UNLOCK_ALL ) {
	foreach ( $cluster_pages as $_test_cl => $_test_pgs ) {
		if ( count( $_test_pgs ) >= 4 ) {
			if ( ! isset( $_proposed_by_cluster[ $_test_cl ] ) ) $_proposed_by_cluster[ $_test_cl ] = array();
			$_proposed_by_cluster[ $_test_cl ][] = array( 'source' => (int) $_test_pgs[0]['id'], 'target' => (int) $_test_pgs[1]['id'], 'anchor' => 'guide complet' );
			$_proposed_by_cluster[ $_test_cl ][] = array( 'source' => (int) $_test_pgs[1]['id'], 'target' => (int) $_test_pgs[2]['id'], 'anchor' => 'en savoir plus' );
			$_proposed_by_cluster[ $_test_cl ][] = array( 'source' => (int) $_test_pgs[2]['id'], 'target' => (int) $_test_pgs[3]['id'], 'anchor' => 'article connexe' );
			break;
		}
	}
}
echo wp_json_encode( (object) $_proposed_by_cluster );
?>;</script>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px">
	<div style="display:inline-flex;gap:2px;padding:3px;background:rgba(120,120,128,.08);border-radius:10px">
		<?php
		$cc_tabs = array(
			array( 'id' => 'money', 'label' => 'Pages business', 'badge' => count( $money_pages_data ) ),
			array( 'id' => 'cocons', 'label' => 'Mes groupes', 'badge' => $total_groups ),
			array( 'id' => 'redaction', 'label' => 'Rédaction', 'badge' => $total_todo ),
		);
		$cc_default_tab = empty( $clusters_data ) ? 'money' : 'cocons';
		$cc_active_tab = isset( $_GET['tab'] ) && in_array( $_GET['tab'], array( 'money', 'cocons', 'redaction' ), true ) ? $_GET['tab'] : $cc_default_tab;
		foreach ( $cc_tabs as $cctab ) :
			$is_active = $cctab['id'] === $cc_active_tab;
		?>
		<button onclick="htsCCTab('<?php echo $cctab['id']; ?>')" class="hts-cc-tab-btn" data-tab="<?php echo $cctab['id']; ?>" style="display:inline-flex;align-items:center;gap:5px;padding:8px 16px;border-radius:8px;border:none;background:<?php echo $is_active ? 'var(--hts-pill-bg)' : 'transparent'; ?>;box-shadow:<?php echo $is_active ? 'var(--hts-pill-shadow)' : 'none'; ?>;color:<?php echo $is_active ? 'var(--hts-text)' : 'rgba(60,60,67,.45)'; ?>;font-size:12px;font-weight:<?php echo $is_active ? '600' : '500'; ?>;cursor:pointer;font-family:var(--hts-font)">
			<?php echo esc_html( $cctab['label'] ); ?>
			<span style="min-width:16px;height:16px;border-radius:8px;padding:0 4px;background:<?php echo $is_active ? 'var(--hts-geo)' : 'var(--hts-text-3)'; ?>;color:#fff;font-size:9px;font-weight:700;display:inline-flex;align-items:center;justify-content:center"><?php echo (int) $cctab['badge']; ?></span>
		</button>
		<?php endforeach; ?>
	</div>
	<!-- Nouveau groupe: déplacé dans Outils avancés -->
</div>

<!-- ═══ TAB PANEL: PAGES BUSINESS ═══ -->
<div id="hts-cc-panel-money" class="hts-cc-tab-panel" style="<?php echo $cc_active_tab !== 'money' ? 'display:none' : ''; ?>">
<!-- ═══════════════════════════════════════════════════
 * BLOC 2: CLUSTERS SÉMANTIQUES — Grille 2 colonnes
 * ═══════════════════════════════════════════════════ -->
<?php if ( $is_analyzed || $cross_cocon_enabled || ! empty( $cross_pending ) || $has_anything_to_purge ) : ?>
<div class="hts-cc-section" id="hts-maillage-section"> <?php echo $_hts_nc_warn_html; ?> <!-- Purge: moved to Outils avancés -->
<?php if ( empty( $clusters_data ) && ( $has_money_pages || $money_discovery_done ) ) : ?>
<!-- Money pages panel (no clusters yet — shown after Lancer l'analyse) -->
<div class="hts-mp-panel" id="hts-mp-panel" style="margin-bottom:16px;">
 <div class="hts-mp-header" onclick="htsMpTogglePanel()" style="cursor:pointer;">
  <h4>Pages business
   <?php if ( $has_money_pages ) : ?><span class="hts-cc-badge green"><?php echo count( $money_pages_data ); ?> active<?php echo count( $money_pages_data ) > 1 ? 's': ''; ?></span><?php endif; ?>
  </h4>
  <div style="display:flex;align-items:center;gap:8px;" onclick="event.stopPropagation()">
   <?php if ( $has_money_pages ) : ?>
   <button class="hts-cc-btn outline sm" onclick="htsMpBulkSelect(true)" title="Tout s&eacute;lectionner">Tout s&eacute;lectionner</button>
   <button class="hts-cc-btn outline sm" onclick="htsMpBulkSelect(false)" title="Tout d&eacute;s&eacute;lectionner">Tout d&eacute;s&eacute;lectionner</button>
   <?php endif; ?>
   <?php if ( $has_money_pages || $money_discovery_done ) : ?>
   <button class="hts-cc-btn outline sm" onclick="htsMcDiscover(this)" title="Re-d&eacute;tecter les pages business">Re-d&eacute;tecter</button>
   <?php else : ?>
   <button class="hts-cc-btn outline sm" onclick="htsMcDiscover(this)" title="D&eacute;tecter les pages business">D&eacute;tecter</button>
   <?php endif; ?>
   <span class="mp-toggle" id="hts-mp-toggle-arrow" onclick="event.stopPropagation();htsMpTogglePanel()">&#9660;</span>
  </div>
 </div>
 <div class="hts-mp-body" id="hts-mp-body" style="display:block;">
  <?php if ( $has_money_pages && empty( $clusters_data ) ) : ?>
  <div style="padding:12px 18px;margin:0 0 12px;background:linear-gradient(135deg,var(--hts-info-bg,#eff6ff),#ede9fe);border:1px solid var(--hts-info,#3b82f6);border-radius:10px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
    <div>
      <div style="font-size:13px;font-weight:600;color:var(--hts-text);">Sélectionnez vos pages principales</div>
      <div style="font-size:11px;color:var(--hts-text-2);margin-top:2px;">Activez les pages qui doivent se positionner sur Google, puis créez vos groupes.</div>
    </div>
    <button class="hts-cc-btn primary" onclick="htsCreateGroups(this)" style="white-space:nowrap;padding:10px 22px;font-size:13px;">Créer les groupes</button>
  </div>
  <?php elseif ( $has_money_pages && ! empty( $clusters_data ) ) : ?>
  <div style="padding:8px 14px;margin:0 0 12px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:8px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
    <div style="font-size:11px;color:var(--hts-text-2);">Modifiez vos pages principales ci-dessous, puis mettez à jour.</div>
    <button class="hts-cc-btn primary sm" onclick="htsCreateGroups(this)" style="white-space:nowrap;">Mettre à jour les groupes</button>
  </div>
  <?php endif; ?>
  <?php if ( $has_money_pages ) : ?>
  <div class="hts-mp-list" id="hts-mp-list">
   <?php foreach ( $money_pages_data as $mp ) :
    $mp_id = (int) $mp['id'];
    $mp_type = $mp['type'] ?? 'post';
    $mp_uid = $mp_type . '_' . $mp_id;
    $mp_score = (int) ( $mp['score'] ?? 0 );
    $mp_sc_cl = $mp_score >= 70 ? 'high' : ( $mp_score >= 40 ? 'med' : 'low' );
    $mp_cluster = $mp['cluster'] ?? '';
    $mp_manual = ! empty( $mp['manual'] );
    $mp_checked = $mp_manual ? 'checked' : '';
    $mp_in_menu = ! empty( $mp['in_menu'] );
    $mp_top_signal = $mp['top_signal'] ?? null;
    $mp_cocon_ct = (int) ( $mp['cocon_count'] ?? 0 );
    $mp_gsc_clicks = (int) ( $mp['gsc_clicks'] ?? 0 );
    $mp_gsc_pos = round( (float) ( $mp['gsc_pos'] ?? 0 ), 1 );
    $mp_is_pillar = false;
    $mp_edit_url = $mp_type === 'product_cat' ? admin_url( 'term.php?taxonomy=product_cat&tag_ID=' . $mp_id ) : get_edit_post_link( $mp_id, 'raw' );
   ?>
   <div class="hts-mp-row" id="hts-mp-card-<?php echo $mp_uid; ?>" data-mp-id="<?php echo $mp_id; ?>" data-mp-type="<?php echo esc_attr( $mp_type ); ?>">
    <label class="hts-mp-switch"><input type="checkbox" <?php echo $mp_checked; ?> onchange="htsMpTogglePage(<?php echo $mp_id; ?>,'<?php echo esc_js( $mp_type ); ?>',this)"><span class="slider"></span></label>
    <div class="hts-mp-info">
     <div class="hts-mp-title"><a href="<?php echo esc_url( $mp_edit_url ); ?>" target="_blank"><?php echo esc_html( mb_substr( $mp['title'] ?? '(sans titre)', 0, 55 ) ); ?></a></div>
     <div class="hts-mp-meta">
      <span class="hts-mp-score <?php echo $mp_sc_cl; ?>"><?php echo $mp_score; ?> pts</span>
      <?php if ( $mp_manual ) : ?><span class="hts-mp-signal">Manuel</span><?php endif; ?>
      <?php if ( $mp_in_menu ) : ?><span class="hts-mp-signal" style="background:var(--hts-accent-bg);color:var(--hts-accent);">Menu</span><?php endif; ?>
      <?php if ( $mp_gsc_clicks > 0 ) : ?><span class="hts-mp-signal"><?php echo $mp_gsc_clicks; ?> clics</span><?php endif; ?>
     </div>
    </div>
   </div>
   <?php endforeach; ?>
  </div>
  <?php else : ?>
  <div style="text-align:center;padding:20px;color:var(--hts-text-3);font-size:12px;">Aucune page business d&eacute;tect&eacute;e. Cliquez sur &laquo; D&eacute;tecter &raquo;.</div>
  <?php endif; ?>
  <div class="hts-mp-search-wrap" id="hts-mp-search-wrap">
   <span class="hts-mp-search-icon"></span>
   <input type="text" class="hts-mp-search" id="hts-mp-search" placeholder="Ajouter une page : tapez un titre ou collez une URL&hellip;" autocomplete="off">
   <div class="hts-mp-results" id="hts-mp-results"></div>
  </div>
 </div>
</div>
<!-- Étape suivante: déplacé en haut de la section pages business (U5) -->
<?php endif; ?>
<?php if ( ! empty( $clusters_data ) && $has_money_pages ) : ?>
<?php
// Detect orphan manual pages (not pillar of any cluster) → auto-show refresh banner
$_orphan_manual = false;
if ( ! empty( $clusters_data ) ) {
    $_cluster_pillar_ids = array();
    foreach ( $clusters_data as $_cd ) {
        if ( ! empty( $_cd['pillar_id'] ) ) $_cluster_pillar_ids[] = (int) $_cd['pillar_id'];
    }
    $_manual_ids = get_posts( array(
        'post_type' => array( 'post', 'page', 'product' ), 'post_status' => 'publish',
        'meta_key' => '_hts_money_page_manual', 'meta_value' => '1',
        'posts_per_page' => 50, 'fields' => 'ids',
    ) );
    foreach ( $_manual_ids as $_mid ) {
        if ( ! in_array( (int) $_mid, $_cluster_pillar_ids, true ) ) {
            $_orphan_manual = true;
            break;
        }
    }
}
$_banner_display = $_orphan_manual ? 'display:flex' : 'display:none';
?>
<!-- Refresh groups CTA (visible when manual pages not in clusters, or toggled by JS) -->
<div id="hts-refresh-groups-banner" style="<?php echo $_banner_display; ?>;padding:12px 18px;background:var(--hts-geo-soft);border:1px solid var(--hts-border);border-radius:10px;margin-bottom:14px;align-items:center;justify-content:space-between;gap:12px">
 <span style="font-size:12px;color:var(--hts-text)"><?php echo HTS_DS::icon('refresh',13,'var(--hts-geo)'); ?> <strong>Pages modifiées</strong> — mettez à jour les groupes pour inclure vos nouvelles pages.</span>
 <button class="hts-cc-btn primary sm" onclick="htsCreateGroups(this)" style="white-space:nowrap">Mettre à jour les groupes</button>
</div>
<?php endif; ?>
<?php if ( ! empty( $clusters_data ) ) : ?> <!-- Header --> <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;"> <h3 style="margin:0;font-size:16px;font-weight:700;color:var(--hts-text);"> Clusters sémantiques <span style="font-size:11px;font-weight:400;color:var(--hts-text-2);">(<?php echo count( $clusters_data ); ?> clusters · <?php echo (int) ( $cocon_stats['stats']['total_pages'] ?? 0 ); ?> pages)</span></h3> <div style="display:flex;gap:6px;align-items:center;"> <?php if ( $last_analysis ) : ?><span style="font-size:9px;color:var(--hts-text-3);">Analyse : <?php echo esc_html( date_i18n( 'j M H:i', $last_analysis ) ); ?></span><?php endif; ?> </div> </div> <!-- Maillage progress/result (hidden by default, shown by JS) --> <div id="hts-mc-inline-progress" style="display:none;margin-bottom:14px;padding:12px 16px;background:var(--hts-accent-bg);border:1px solid var(--hts-info-bg);border-radius:10px;"> <div style="display:flex;align-items:center;gap:10px;"> <span style="display:inline-block;width:16px;height:16px;border:2px solid var(--hts-accent);border-top-color:var(--hts-accent);border-radius:50%;animation:hts-spin .8s linear infinite;"></span> <span style="font-size:12px;font-weight:600;color:var(--hts-accent);" id="hts-mc-inline-status">Maillage en cours…</span> </div> <div class="hts-mc-progress" style="margin-top:8px;"><div class="hts-mc-progress-fill" id="hts-mc-inline-bar" style="width:0;"></div></div> </div> <div id="hts-mc-inline-result" style="display:none;margin-bottom:14px;"></div> <!-- ── MONEY PAGES — Sélection des pages business ── --> <?php if ( $money_discovery_done || $has_money_pages || ! empty( $clusters_data ) ) : ?> <div class="hts-mp-panel" id="hts-mp-panel"> <div class="hts-mp-header" onclick="htsMpTogglePanel()"> <h4> Pages business
 <?php if ( $has_money_pages ) : ?> <span class="hts-cc-badge green"><?php echo count( $money_pages_data ); ?> active<?php echo count( $money_pages_data ) > 1 ? 's': ''; ?></span> <?php endif; ?> <?php if ( $money_dismissed_count > 0 ) : ?> <span class="hts-cc-badge gray"><?php echo $money_dismissed_count; ?> masquée<?php echo $money_dismissed_count > 1 ? 's': ''; ?></span> <?php endif; ?> </h4> <div style="display:flex;align-items:center;gap:8px;" onclick="event.stopPropagation()"> <?php if ( ! empty( $clusters_data ) ) : ?> <button class="hts-cc-btn primary sm" onclick="htsMcAutoRun(this)" id="hts-mc-auto-btn" title="Cr&#233;er automatiquement les liens internes entre vos articles et leurs pages principales"> Proposer le maillage</button> <?php endif; ?> <?php if ( $has_money_pages || $money_discovery_done ) : ?> <button class="hts-cc-btn outline sm" onclick="htsMcDiscover(this)" title="Re-détecter les pages business"> Re-détecter</button> <?php else : ?> <button class="hts-cc-btn outline sm" onclick="htsMcDiscover(this)" title="Détecter les pages business"> Détecter</button> <?php endif; ?> <span class="mp-toggle" id="hts-mp-toggle-arrow" onclick="event.stopPropagation();htsMpTogglePanel()">▶</span> </div> </div> <div class="hts-mp-body" id="hts-mp-body"> <?php if ( $has_money_pages ) : ?> <!-- Active money pages --> <div class="hts-mp-list" id="hts-mp-list"> <?php foreach ( $money_pages_data as $mp ) :
 $mp_id = (int) $mp['id'];
 $mp_type = $mp['type'] ?? 'post';
 $mp_uid = $mp_type . '-'. $mp_id;
 $mp_score = (int) ( $mp['score'] ?? 0 );
 $mp_sc_cl = $mp_score >= 60 ? 'high': ( $mp_score >= 30 ? 'mid': 'low');
 $mp_manual = ! empty( $mp['manual'] );
 $mp_top_signal = ! empty( $mp['reasons'][0] ) ? $mp['reasons'][0] : null;
 $mp_cocon_ct = (int) ( $mp['cocon_count'] ?? 0 );
 $mp_edit_url = $mp_type === 'product_cat'? admin_url( 'term.php?taxonomy=product_cat&tag_ID='. $mp_id ) : get_edit_post_link( $mp_id, 'raw');
 $mp_gsc_clicks = (int) ( $mp['gsc_clicks'] ?? 0 );
 $mp_gsc_pos = round( (float) ( $mp['gsc_pos'] ?? 0 ), 1 );
 $mp_is_pillar = isset( $pillar_to_cluster[ $mp_id ] );
 $mp_cluster = $pillar_to_cluster[ $mp_id ] ?? ( $page_to_cluster[ $mp_id ] ?? '');
 $mp_in_menu = ! empty( $mp['in_menu'] );
 $mp_checked = ( $mp_manual || $mp_is_pillar ) ? 'checked' : '';
 ?> <div class="hts-mp-row" id="hts-mp-card-<?php echo $mp_uid; ?>" data-mp-id="<?php echo $mp_id; ?>" data-mp-type="<?php echo esc_attr( $mp_type ); ?>"> <label class="hts-mp-switch"> <input type="checkbox" <?php echo $mp_checked; ?> onchange="htsMpTogglePage(<?php echo $mp_id; ?>,'<?php echo esc_js( $mp_type ); ?>',this)"> <span class="slider"></span> </label> <div class="hts-mp-info"> <div class="hts-mp-title"> <a href="<?php echo esc_url( $mp_edit_url ); ?>" target="_blank" title="<?php echo esc_attr( $mp['title'] ?? ''); ?>"><?php echo esc_html( mb_substr( $mp['title'] ?? '(sans titre)', 0, 55 ) ); ?></a> </div> <div class="hts-mp-meta"> <span class="hts-mp-score <?php echo $mp_sc_cl; ?>"><?php echo $mp_score; ?> pts</span> <?php if ( $mp_cluster ) : ?><span class="hts-mp-signal" style="background:var(--hts-geo-soft);color:var(--hts-geo);"><?php echo $mp_is_pillar ? 'Pilier': ''; ?> <?php echo esc_html( mb_substr( $mp_cluster, 0, 25 ) ); ?></span><?php endif; ?> <?php if ( $mp_manual ) : ?><span class="hts-mp-signal"> Manuel</span><?php endif; ?> <?php if ( $mp_in_menu ) : ?><span class="hts-mp-signal" style="background:var(--hts-accent-bg);color:var(--hts-accent);">Menu</span><?php endif; ?> <?php if ( $mp_top_signal && ! $mp_manual ) : ?><span class="hts-mp-signal"><?php echo esc_html( $mp_top_signal['label'] ?? ''); ?></span><?php endif; ?> <?php if ( $mp_cocon_ct > 0 ) : ?><span class="hts-mp-cocon-ct"><?php echo $mp_cocon_ct; ?> article<?php echo $mp_cocon_ct > 1 ? 's': ''; ?> rattaché<?php echo $mp_cocon_ct > 1 ? 's': ''; ?></span><?php endif; ?> <?php if ( $mp_gsc_clicks > 0 ) : ?><span class="hts-mp-signal"> <?php echo $mp_gsc_clicks; ?> clics<?php echo $mp_gsc_pos > 0 ? '· pos '. $mp_gsc_pos : ''; ?></span><?php endif; ?> </div> </div> <!-- htsMcBuild masqué pour simplification UX --> </div> <?php endforeach; ?> </div> <?php else : ?> <div style="text-align:center;padding:20px;color:var(--hts-text-3);font-size:12px;"> <div style="font-size:28px;margin-bottom:6px;"></div> <div style="font-weight:600;color:var(--hts-text);margin-bottom:4px;">Aucune page business détectée</div> <div>Cliquez sur « Détecter » ci-dessus ou ajoutez manuellement vos pages de vente, services et produits.</div> </div> <?php endif; ?> <!-- Search to add manual money pages --> <div class="hts-mp-search-wrap" id="hts-mp-search-wrap"> <span class="hts-mp-search-icon"></span> <input type="text" class="hts-mp-search" id="hts-mp-search" placeholder="Ajouter une page : tapez un titre ou collez une URL…" autocomplete="off"> <div class="hts-mp-results" id="hts-mp-results"></div> </div> <!-- Maillage auto progress/result (shown by htsMcAutoRun JS) --> <div id="hts-mc-auto-progress" style="display:none;margin-top:14px;padding:12px 16px;background:var(--hts-accent-bg);border:1px solid var(--hts-info-bg);border-radius:10px;"> <div style="display:flex;align-items:center;gap:10px;"> <span style="display:inline-block;width:16px;height:16px;border:2px solid var(--hts-accent);border-top-color:var(--hts-accent);border-radius:50%;animation:hts-spin .8s linear infinite;"></span> <span style="font-size:12px;font-weight:600;color:var(--hts-accent);" id="hts-mc-auto-status">Maillage en cours…</span> </div> <div class="hts-mc-progress" style="margin-top:8px;"><div class="hts-mc-progress-fill" id="hts-mc-auto-bar" style="width:0;"></div></div> </div> <div id="hts-mc-auto-result" style="display:none;margin-top:14px;"></div> <!-- Manual build steps (shown by htsMcBuild JS) --> <div id="hts-mc-manual-view" style="display:none;margin-top:14px;"> <div id="hts-mc-step1"></div> <div id="hts-mc-step2" style="display:none;"></div> <div id="hts-mc-step3" style="display:none;"></div> </div> <!-- Dismissed pages --> <?php if ( $money_dismissed_count > 0 ) : ?> <div class="hts-mp-dismissed-toggle" onclick="htsMpToggleDismissed()"> <span id="hts-mp-dismissed-arrow">▶</span> <?php echo $money_dismissed_count; ?> page<?php echo $money_dismissed_count > 1 ? 's': ''; ?> masquée<?php echo $money_dismissed_count > 1 ? 's': ''; ?> </div> <div class="hts-mp-dismissed-list" id="hts-mp-dismissed-list"> <?php foreach ( $money_dismissed_data as $dmp ) :
 $dmp_id = (int) $dmp['id'];
 $dmp_type = $dmp['type'] ?? 'post';
 $dmp_uid = $dmp_type . '-'. $dmp_id;
 ?> <div class="hts-mp-row dismissed" id="hts-mp-dismissed-<?php echo $dmp_uid; ?>" style="padding:7px 12px;"> <span style="font-size:12px;color:var(--hts-text-3);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo esc_html( mb_substr( $dmp['title'] ?? '(sans titre)', 0, 50 ) ); ?></span> <span class="hts-mp-score low" style="font-size:9px;"><?php echo (int) ( $dmp['score'] ?? 0 ); ?> pts</span> <button class="hts-cc-btn outline sm" onclick="htsMcRestore(<?php echo $dmp_id; ?>,'<?php echo esc_js( $dmp_type ); ?>',this)" title="Restaurer cette page" style="font-size:10px;padding:3px 8px;">↩ Restaurer</button> </div> <?php endforeach; ?> </div> <?php endif; ?> </div> </div> <?php endif; ?> <!-- S6: cluster grid + cross-cocon inbox supprimés (code mort display:none) -->
<?php endif; ?>

</div>
<?php endif; ?> <!-- hts-money-cocon-section: containers now live inside hts-mp-panel (visible) -->
</div><!-- /hts-cc-panel-money -->

<!-- ═══ TAB PANEL: MES GROUPES ═══ -->
<div id="hts-cc-panel-cocons" class="hts-cc-tab-panel" style="<?php echo $cc_active_tab !== 'cocons' ? 'display:none' : ''; ?>">
<!-- ═══════════════════════════════════════════════════
 * BLOC 3: GROUPES UNIFIÉS — S4 cards (cluster NLP + plan)
 * ═══════════════════════════════════════════════════ -->
<?php if ( $total_groups > 0 ) : ?>
<div class="hts-cc-section">
<div class="hts-cocon-grid">
<?php foreach ( $groups as $_gi => $_group ) :
	$cid = $_group['plan_id'];
	$cp = $_group['plan'];
	$has_plan = ! empty( $cp );
	$has_cluster = ! empty( $_group['cluster'] );
	$_cl = $_group['cluster'];

	// ── Plan data ──
	if ( $has_plan ) {
		$plan_status = $cp['status'] ?? 'queued';
		$plan_articles = $cp['articles'] ?? array();
		$total_topics = count( $plan_articles );
		$gen_count = 0; $queued_count = 0; $error_count = 0; $todo_count = 0;
		foreach ( $plan_articles as $art ) {
			$as = $art['status'] ?? 'to_generate';
			if ( in_array( $as, array( 'received', 'ready' ), true ) ) $gen_count++;
			elseif ( $as === 'queued' || $as === 'pending_queue' ) $queued_count++;
			elseif ( $as === 'error' ) $error_count++;
			else $todo_count++;
		}
		$plan_kw = $cp['keyword'] ?? $cp['pillar_title'] ?? $cid;
		$plan_pct = $total_topics > 0 ? round( ( $gen_count / $total_topics ) * 100 ) : 0;
		$pillar_url = $cp['pillar_url'] ?? '';
		$intent_dist = HTS_Cocon_Commander::get_plan_intent_distribution( $plan_articles );
		$pct_info = $intent_dist['total'] > 0 ? round( ( $intent_dist['info'] / $intent_dist['total'] ) * 100 ) : 0;
		$pct_comm = $intent_dist['total'] > 0 ? round( ( $intent_dist['commercial'] / $intent_dist['total'] ) * 100 ) : 0;
		$pct_trans = $intent_dist['total'] > 0 ? round( ( $intent_dist['transactional'] / $intent_dist['total'] ) * 100 ) : 0;
	} else {
		$plan_status = ''; $plan_articles = array(); $total_topics = 0;
		$gen_count = 0; $queued_count = 0; $error_count = 0; $todo_count = 0;
		$plan_kw = ''; $plan_pct = 0; $pillar_url = '';
		$pct_info = 0; $pct_comm = 0; $pct_trans = 0;
		$intent_dist = array( 'total' => 0, 'info' => 0, 'commercial' => 0, 'transactional' => 0 );
	}

	// ── Cluster NLP data ──
	$cl_density = 0; $cl_orphans = 0; $cl_dead = 0; $cl_pages = 0;
	$cl_name = ''; $cl_total_links = 0; $nlp_score = 0; $cl_pillar_id = 0;
	if ( $has_cluster ) {
		$cl_density = (int) ( $_cl['density'] ?? 0 );
		$cl_orphans = (int) ( $_cl['orphans'] ?? $_cl['orphan_count'] ?? 0 );
		$cl_dead = (int) ( $_cl['dead_ends'] ?? 0 );
		$cl_pages = (int) ( $_cl['page_count'] ?? 0 );
		$cl_name = $_cl['name'] ?? '';
		$cl_pillar_id = (int) ( $_cl['pillar_id'] ?? 0 );
		if ( ! empty( $cluster_pages[ $cl_name ] ) ) {
			foreach ( $cluster_pages[ $cl_name ] as $cpg ) {
				$cl_total_links += (int) $cpg['incoming'] + (int) $cpg['outgoing'];
			}
		}
		if ( $cl_pages > 0 ) {
			$nlp_score = min( 40, $cl_density ) + round( ( $cl_pages - $cl_orphans ) / $cl_pages * 30 ) + round( ( $cl_pages - $cl_dead ) / $cl_pages * 30 );
			$nlp_score = min( 100, max( 0, $nlp_score ) );
		}
		if ( ! $has_plan ) {
			$plan_kw = $cl_name;
			$pillar_url = $cl_pillar_id ? get_permalink( $cl_pillar_id ) : '';
		}
	}

	// ── Fallback: compute NLP metrics from plan articles post metas ──
	if ( ! $has_cluster && $has_plan ) {
		$_fb_post_ids = array();
		// Pillar post
		if ( $pillar_url ) {
			$_fb_pid = hts_url_to_postid( $pillar_url );
			if ( $_fb_pid > 0 ) $_fb_post_ids[] = $_fb_pid;
		}
		// Articles with post_id (rédigés)
		foreach ( $plan_articles as $_fb_art ) {
			$_fb_did = (int) ( $_fb_art['post_id'] ?? 0 );
			if ( $_fb_did > 0 ) $_fb_post_ids[] = $_fb_did;
		}
		$_fb_post_ids = array_unique( $_fb_post_ids );
		$cl_pages = count( $_fb_post_ids );
		$cl_total_links = 0; $cl_orphans = 0;
		foreach ( $_fb_post_ids as $_fb_pid ) {
			$_fb_in = (int) get_post_meta( $_fb_pid, '_hts_internal_links_in', true );
			$_fb_out = (int) get_post_meta( $_fb_pid, '_hts_internal_links_out', true );
			$cl_total_links += $_fb_in + $_fb_out;
			if ( $_fb_in === 0 ) $cl_orphans++;
		}
		$cl_density = $cl_pages > 0 ? (int) round( $cl_total_links / $cl_pages ) : 0;
		// NLP score from computed metrics
		if ( $cl_pages > 0 ) {
			$nlp_score = min( 40, $cl_density ) + round( ( $cl_pages - $cl_orphans ) / $cl_pages * 30 ) + round( ( $cl_pages - $cl_dead ) / $cl_pages * 30 );
			$nlp_score = min( 100, max( 0, $nlp_score ) );
		}
	}

	$card_score = ( $has_cluster || ( $has_plan && $cl_pages > 0 ) ) ? $nlp_score : $plan_pct;
	$plan_cluster = $has_cluster ? $cl_name : ( $has_plan ? $plan_kw : '' );
	$_resolve_debug = $has_cluster ? array( 'matched=' . $cl_name ) : array( 'no_cluster' );
	$col = $card_score >= 75 ? 'var(--hts-success)' : ( $card_score >= 50 ? 'var(--hts-caution)' : 'var(--hts-danger)' );
	$col_text = $col;
	$bg_grad = $card_score >= 75
		? 'linear-gradient(160deg, var(--hts-success-bg) 0%, var(--hts-surface) 40%, var(--hts-bg) 100%)'
		: ( $card_score >= 50
			? 'linear-gradient(160deg, var(--hts-caution-bg) 0%, var(--hts-surface) 40%, var(--hts-bg) 100%)'
			: 'linear-gradient(160deg, var(--hts-danger-bg) 0%, var(--hts-surface) 40%, var(--hts-bg) 100%)' );

	// Issue detection (NLP metrics available for both cluster and fallback)
	$card_issue = null;
	if ( $cl_pages > 3 && $cl_density < 15 ) {
		$card_issue = array( 'type' => 'warn', 'text' => 'Maillage à ' . $cl_density . '% — renforcez les liens' );
	} elseif ( $cl_orphans > 0 && $cl_pages > 0 ) {
		$card_issue = array( 'type' => ( $cl_orphans > ( $cl_pages / 2 ) ? 'fail' : 'warn' ), 'text' => $cl_orphans . ' page(s) sans lien' );
	} elseif ( $has_plan && $error_count > 0 ) {
		$card_issue = array( 'type' => 'fail', 'text' => $error_count . ' article(s) en erreur' );
	} elseif ( $has_plan && $pct_info >= 90 && $intent_dist['total'] > 3 ) {
		$card_issue = array( 'type' => 'warn', 'text' => '100% informationnel — ajoutez du contenu commercial' );
	}
	$_pre_suggested = ! empty( $_cl['suggested'] );
	$_pre_nc = ( ( $_cl['name'] ?? '' ) === 'Non classé' );
	// Skip dismissed suggestions
	if ( $_pre_suggested ) {
		$_dismissed_sugs = get_option( 'hts_cocon_dismissed_suggestions', array() );
		if ( isset( $_dismissed_sugs[ $cl_name ] ) ) continue;
	}
	$_card_border = $_pre_suggested ? 'border:2px dashed var(--hts-info,#3b82f6);' : ( $_pre_nc ? 'border:2px dashed var(--hts-border);opacity:0.7;' : 'border:1px solid var(--hts-border);' );
?>
<div class="hts-cocon-card" data-cocon-id="<?php echo esc_attr( $cid ); ?>" data-gen="<?php echo $gen_count; ?>" data-kw="<?php echo esc_attr( $plan_kw ); ?>" data-topics="<?php echo $total_topics; ?>" data-pillar="<?php echo esc_attr( $pillar_url ); ?>" data-cluster="<?php echo esc_attr( $plan_cluster ); ?>" data-has-plan="<?php echo $has_plan ? '1' : '0'; ?>" data-has-cluster="<?php echo $has_cluster ? '1' : '0'; ?>" data-debug="<?php echo esc_attr( implode(' | ', $_resolve_debug) ); ?>" style="border-radius:22px;overflow:hidden;<?php echo $_card_border; ?>cursor:pointer;transition:transform .15s,box-shadow .15s" onclick="htsCCOpenGraph('<?php echo esc_js( $plan_cluster ?: $plan_kw ); ?>','<?php echo esc_js( $plan_kw ); ?>',<?php echo $cl_pages ?: $total_topics; ?>,<?php echo $cl_density; ?>,<?php echo $cl_orphans; ?>,<?php echo $cl_total_links; ?>,0,'<?php echo esc_js( $cid ); ?>','<?php echo esc_js( $pillar_url ); ?>')" onmouseenter="this.style.boxShadow='0 4px 20px rgba(0,0,0,.08)'" onmouseleave="this.style.boxShadow='none'">

	<!-- Card HEAD: gradient + ring + name + progress -->
	<div style="background:<?php echo $bg_grad; ?>;padding:28px 24px 22px;display:flex;flex-direction:column;align-items:center;position:relative">
		<div style="position:absolute;top:20px;width:100px;height:100px;border-radius:50%;background:<?php echo $col; ?>;opacity:.06;filter:blur(28px)"></div>
		<div style="position:relative;margin-bottom:14px"><?php echo HTS_DS::ring( $card_score, 84, 6 ); ?></div>
		<div style="font-size:17px;font-weight:700;color:var(--hts-text);text-align:center"><?php echo esc_html( $plan_kw ); ?></div>
		<?php if ( $pillar_url ) : ?>
		<div style="font-size:12px;color:var(--hts-text-3);margin-top:3px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( mb_substr( parse_url( $pillar_url, PHP_URL_PATH ) ?: $pillar_url, 0, 30 ) ); ?></div>
		<?php endif; ?>
		<?php if ( $has_plan && $total_topics > 0 ) : ?>
		<div style="display:flex;align-items:center;gap:8px;margin-top:14px;width:100%;max-width:200px">
			<div style="flex:1;height:3px;background:var(--hts-border-sub);border-radius:2px;overflow:hidden"><div style="height:100%;width:<?php echo $plan_pct; ?>%;background:<?php echo $col; ?>;border-radius:2px"></div></div>
			<span style="font-size:11px;font-weight:700;color:<?php echo $col_text; ?>"><?php echo $gen_count; ?>/<?php echo $total_topics; ?></span>
		</div>
		<?php elseif ( ! $has_plan ) : ?>
		<div style="margin-top:10px"><span style="font-size:10px;padding:3px 10px;border-radius:12px;background:var(--hts-geo-soft);color:var(--hts-geo);font-weight:600"><?php echo $cl_pages; ?> pages</span></div>
		<?php endif; ?>
	</div>

	<!-- Card BODY: metrics + intent + issue -->
	<div style="background:var(--hts-bg);padding:14px 20px 16px">
		<div style="display:flex">
			<?php
			$metrics = array(
				array( 'l' => 'Densité', 'v' => $cl_density . '%', 'w' => $cl_density < 15 && $cl_pages > 0 ),
				array( 'l' => 'Sans lien', 'v' => $cl_orphans, 'w' => $cl_orphans > 0 ),
				array( 'l' => 'Liens', 'v' => $cl_total_links ),
				array( 'l' => 'Pages', 'v' => $cl_pages ),
			);
			foreach ( $metrics as $j => $m ) : ?>
			<div style="flex:1;text-align:center;padding:6px 0;position:relative">
				<?php if ( $j > 0 ) : ?><div style="position:absolute;left:0;top:6px;bottom:6px;width:1px;background:var(--hts-border-sub)"></div><?php endif; ?>
				<div style="font-size:16px;font-weight:700;color:<?php echo ! empty( $m['w'] ) ? 'var(--hts-danger)' : 'var(--hts-text)'; ?>"><?php echo $m['v']; ?></div>
				<div style="font-size:10px;color:var(--hts-text-3);margin-top:2px"><?php echo esc_html( $m['l'] ); ?></div>
			</div>
			<?php endforeach; ?>
		</div>
		<?php if ( $has_plan && $intent_dist['total'] > 0 ) : ?>
		<div style="margin-top:12px">
			<div style="display:flex;height:5px;border-radius:3px;overflow:hidden;gap:2px">
				<?php if ( $pct_info > 0 ) : ?><div style="flex:<?php echo $pct_info; ?>;background:var(--hts-accent);border-radius:3px"></div><?php endif; ?>
				<?php if ( $pct_comm > 0 ) : ?><div style="flex:<?php echo $pct_comm; ?>;background:var(--hts-caution);border-radius:3px"></div><?php endif; ?>
				<?php if ( $pct_trans > 0 ) : ?><div style="flex:<?php echo $pct_trans; ?>;background:var(--hts-success);border-radius:3px"></div><?php endif; ?>
			</div>
			<div style="display:flex;gap:10px;margin-top:6px">
				<?php foreach ( array(
					array( 'l' => 'Info', 'v' => $pct_info, 'c' => 'var(--hts-accent)' ),
					array( 'l' => 'Commerce', 'v' => $pct_comm, 'c' => 'var(--hts-caution)' ),
					array( 'l' => 'Transac.', 'v' => $pct_trans, 'c' => 'var(--hts-success)' ),
				) as $t ) : ?>
				<div style="display:flex;align-items:center;gap:4px"><div style="width:6px;height:6px;border-radius:50%;background:<?php echo $t['c']; ?>"></div><span style="font-size:10px;color:var(--hts-text-3)"><?php echo esc_html( $t['l'] ); ?> <?php echo $t['v']; ?>%</span></div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>
		<?php if ( $card_issue ) : ?>
		<div style="margin-top:12px;padding:9px 14px;border-radius:12px;display:flex;align-items:center;gap:8px;border:1.5px solid <?php echo $card_issue['type'] === 'fail' ? 'var(--hts-danger)' : 'var(--hts-caution)'; ?>">
			<?php echo HTS_DS::dot( $card_issue['type'] === 'fail' ? 'fail' : 'warn', 6 ); ?>
			<span style="font-size:12px;color:<?php echo $card_issue['type'] === 'fail' ? 'var(--hts-danger)' : 'var(--hts-caution)'; ?>;line-height:1.35"><?php echo esc_html( $card_issue['text'] ); ?></span>
		</div>
		<?php endif; ?>
		<?php if ( $has_cluster && $cl_pages <= 1 ) : ?>
		<div style="margin-top:12px;padding:10px 14px;background:var(--hts-info-bg,#eff6ff);border:1px solid var(--hts-info-bg,#dbeafe);border-radius:8px;font-size:11px;color:var(--hts-info,#3b82f6);">
			Aucun article ne traite encore de ce sujet. Créez du contenu pour renforcer ce cocon et vous positionner.
			<button onclick="event.stopPropagation();htsPrefillCocon('<?php echo esc_js( $pillar_url ); ?>','<?php echo esc_js( $plan_kw ); ?>')" class="hts-cc-btn primary sm" style="margin-top:8px;display:block;">Créer de nouveaux contenus</button>
		</div>
		<?php endif; ?>
		<?php
		$_is_suggested = ! empty( $_cl['suggested'] );
		$_is_nc = ( $cl_name === 'Non classé' );
		?>
		<?php if ( $_is_suggested ) : ?>
		<div style="margin-top:10px;display:flex;justify-content:space-between;align-items:center;">
			<span style="font-size:10px;font-weight:600;color:var(--hts-info,#3b82f6);text-transform:uppercase;">Suggestion IA</span>
			<div style="display:flex;gap:6px;">
				<button onclick="event.stopPropagation();htsAcceptSuggestion(this,'<?php echo esc_js( $cl_name ); ?>')" class="hts-cc-btn primary sm" style="font-size:10px;padding:4px 10px;">Créer ce groupe</button>
				<button onclick="event.stopPropagation();htsDismissSuggestion(this,'<?php echo esc_js( $cl_name ); ?>',<?php echo $cl_pillar_id; ?>)" class="hts-cc-btn outline sm" style="font-size:10px;padding:4px 8px;color:var(--hts-text-3);">✕ Ignorer</button>
			</div>
		</div>
		<?php endif; ?>
		<?php if ( $_is_nc && $cl_pages > 0 ) : ?>
		<div style="margin-top:12px;padding:10px 14px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:8px;font-size:11px;color:var(--hts-text-3);">
			<?php echo $cl_pages; ?> page<?php echo $cl_pages > 1 ? 's' : ''; ?> ne correspond<?php echo $cl_pages > 1 ? 'ent' : ''; ?> à aucun de vos groupes. Ajoutez des pages business pour les organiser.
		</div>
		<?php endif; ?>
	</div>
</div>
<?php endforeach; ?>

<!-- Nouveau groupe: déplacé dans Outils avancés -->
</div>
</div>
<?php else : ?>
<div class="hts-cc-section"><div class="hts-ds-card" style="padding:40px;text-align:center">
	<?php echo HTS_DS::icon('plus', 40, 'var(--hts-faint)'); ?>
	<div style="font-size:15px;font-weight:700;color:var(--hts-text);margin:12px 0 6px">Aucun groupe</div>
	<div style="font-size:12px;color:var(--hts-text-3)">Lancez l'analyse ou créez un cocon ci-dessus.</div>
</div></div>
<?php endif; ?>

</div><!-- /hts-cc-panel-cocons -->

<!-- ═══ TAB PANEL: RÉDACTION ═══ -->
<div id="hts-cc-panel-redaction" class="hts-cc-tab-panel" style="<?php echo $cc_active_tab !== 'redaction' ? 'display:none' : ''; ?>">
<?php if ( ! $_hts_can_write ) : ?>
<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 30px;text-align:center;max-width:460px;margin:0 auto">
	<div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#6366f1);display:flex;align-items:center;justify-content:center;margin-bottom:20px"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div>
	<div style="font-size:20px;font-weight:800;color:var(--hts-text);margin-bottom:12px">R&eacute;daction automatique</div>
	<div style="font-size:14px;color:var(--hts-text-2);line-height:1.6;margin-bottom:10px">Vos articles sont r&eacute;dig&eacute;s par l&rsquo;IA avec images et liens internes.<br>50 articles/mois inclus dans le plan Ultra.</div>
	<div style="font-size:13px;color:var(--hts-text-3);line-height:1.6;margin-bottom:28px">Vous pouvez aussi r&eacute;diger vos articles depuis la plateforme SaaS et les envoyer vers WordPress.</div>
	<a href="https://hacktheseo.com/pricing" target="_blank" style="display:block;width:100%;max-width:320px;padding:14px;border-radius:12px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;text-decoration:none;text-align:center;margin-bottom:10px;box-sizing:border-box">Passer &agrave; Ultra &mdash; 249&euro;/mois</a>
	<a href="<?php echo esc_url( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ) ); ?>" target="_blank" style="display:block;width:100%;max-width:320px;padding:12px;border-radius:12px;border:1px solid var(--hts-border);background:var(--hts-bg);color:var(--hts-text-2);font-size:13px;font-weight:600;text-decoration:none;text-align:center;box-sizing:border-box">Ouvrir le SaaS &rarr;</a>
</div>
<?php else : ?>
<?php
// Compute pipeline data for JSX-style rendering
$_hts_plan_ready = 0;
$_hts_plan_scheduled = 0;
$_pipeline_active = array();
$_pipeline_pending = array(); // Articles waiting to be written (to_generate)
$_pipeline_done = array();
$_cocon_names = array();
foreach ( $plans as $_cp_id => $_cp ) {
	$_cp_kw = $_cp['keyword'] ?? $_cp['pillar_title'] ?? $_cp_id;
	$_cocon_names[ $_cp_id ] = $_cp_kw;
	foreach ( ( $_cp['articles'] ?? array() ) as $_akey => $_a ) {
		$_ast = $_a['status'] ?? 'to_generate';
		$_pid = $_a['post_id'] ?? 0;
		if ( $_pid && get_post_status( $_pid ) === 'draft' ) $_hts_plan_ready++;
		if ( $_pid && get_post_meta( $_pid, '_hts_schedule_approved', true ) ) $_hts_plan_scheduled++;

		if ( $_ast === 'queued' && ! empty( $_a['job_id'] ) ) {
			$_pipeline_active[] = array( 'title' => $_a['title'] ?? $_a['keyword'] ?? '', 'cocon' => $_cp_kw, 'cocon_id' => $_cp_id, 'job_id' => $_a['job_id'], 'phase' => $_a['phase'] ?? 'generation' );
		} elseif ( in_array( $_ast, array( 'to_generate', 'pending_queue' ), true ) ) {
			$_pipeline_pending[] = array(
				'title' => $_a['title'] ?? $_a['keyword'] ?? '',
				'keyword' => $_a['keyword'] ?? '',
				'cocon' => $_cp_kw,
				'cocon_id' => $_cp_id,
				'akey' => $_akey,
				'category' => $_a['category'] ?? '',
				'intent' => $_a['intent'] ?? 'info',
				'topic_id' => $_a['topic_id'] ?? 0,
			);
		} elseif ( in_array( $_ast, array( 'received', 'ready' ), true ) && $_pid ) {
			$_wc = (int) ( $_a['word_count'] ?? 0 );
			if ( ! $_wc && $_pid ) { $_p = get_post( $_pid ); $_wc = $_p ? str_word_count( wp_strip_all_tags( $_p->post_content ) ) : 0; }
			$_pipeline_done[] = array(
				'title' => $_a['title'] ?? get_the_title( $_pid ),
				'cocon' => $_cp_kw,
				'cocon_id' => $_cp_id,
				'post_id' => $_pid,
				'word_count' => $_wc,
				'edit_url' => get_edit_post_link( $_pid, 'raw' ),
				'approved' => (bool) get_post_meta( $_pid, '_hts_schedule_approved', true ),
				'scheduled' => get_post_status( $_pid ) === 'future',
				'pub_date' => get_post_status( $_pid ) === 'future' ? get_the_date( 'j M H:i', $_pid ) : '',
			);
		}
	}
}
$_pipeline_done = array_reverse( $_pipeline_done );
?>

<!-- Header pills -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px">
	<div style="display:flex;align-items:center;gap:8px">
		<span style="font-size:14px;font-weight:700;color:var(--hts-text)">File de rédaction</span>
		<?php if ( ! empty( $_pipeline_pending ) ) : ?>
		<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(245,158,11,.15);color:var(--hts-caution)"><?php echo count( $_pipeline_pending ); ?> en attente</span>
		<?php endif; ?>
		<?php if ( ! empty( $_pipeline_active ) ) : ?>
		<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(99,102,241,.15);color:var(--hts-geo)"><?php echo count( $_pipeline_active ); ?> en cours</span>
		<?php endif; ?>
		<?php if ( ! empty( $_pipeline_done ) ) : ?>
		<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(0,210,106,.15);color:var(--hts-success)"><?php echo count( $_pipeline_done ); ?> terminés</span>
		<?php endif; ?>
	</div>
	<?php if ( count( $_cocon_names ) > 1 ) : ?>
	<select id="hts-redac-filter" onchange="htsFilterRedac(this.value)" style="padding:6px 12px;border:1px solid var(--hts-border);border-radius:8px;font-size:11px;font-family:var(--hts-font);color:var(--hts-text-2)">
		<option value="">Tous les groupes</option>
		<?php foreach ( $_cocon_names as $_cid => $_cn ) : ?>
		<option value="<?php echo esc_attr( $_cn ); ?>" data-cocon-id="<?php echo esc_attr( $_cid ); ?>"><?php echo esc_html( mb_substr( $_cn, 0, 30 ) ); ?></option>
		<?php endforeach; ?>
	</select>
	<?php endif; ?>
</div>

<!-- Live generation cards (filled by JS) -->
<div id="hts-redac-live"></div>

<?php // En attente de rédaction — with checkboxes + generate button ?>
<?php if ( ! empty( $_pipeline_pending ) ) : ?>
<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin:8px 0 10px">En attente de rédaction</div>

<!-- Select all + Generate bar -->
<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;padding:8px 12px;background:var(--hts-surface);border-radius:8px">
	<label style="font-size:11px;display:flex;align-items:center;gap:6px;cursor:pointer;color:var(--hts-text-2)">
		<input type="checkbox" id="hts-redac-select-all" onchange="htsRedacSelectAll(this.checked)"> Tout
	</label>
	<span style="font-size:10px;color:var(--hts-text-3)" id="hts-redac-sel-count">0 sél.</span>
	<div style="margin-left:auto">
		<button class="hts-cc-btn primary sm" onclick="htsRedacGenBatch()" style="font-size:11px;padding:6px 16px">Générer</button>
	</div>
</div>

<?php
$_pending_by_cocon = array();
foreach ( $_pipeline_pending as $_p ) { $_pending_by_cocon[ $_p['cocon'] ][] = $_p; }
foreach ( $_pending_by_cocon as $_pcn => $_plist ) : ?>
<div class="hts-redac-group" data-cocon="<?php echo esc_attr( $_pcn ); ?>" style="margin-bottom:12px">
	<div style="font-size:11px;font-weight:600;color:var(--hts-text-2);margin-bottom:6px"><?php echo esc_html( $_pcn ); ?> <span style="font-weight:400;color:var(--hts-text-3)">(<?php echo count( $_plist ); ?>)</span></div>
	<?php foreach ( $_plist as $_pa ) : ?>
	<div class="hts-ds-card hts-redac-item" id="hts-redac-art-<?php echo esc_attr( $_pa['akey'] ); ?>" data-cocon="<?php echo esc_attr( $_pcn ); ?>" data-akey="<?php echo esc_attr( $_pa['akey'] ); ?>" style="padding:10px 18px;margin-bottom:4px">
		<div style="display:flex;align-items:center;gap:10px">
			<input type="checkbox" class="hts-redac-cb" data-cocon-id="<?php echo esc_attr( $_pa['cocon_id'] ); ?>" data-akey="<?php echo esc_attr( $_pa['akey'] ); ?>" data-topic="<?php echo (int) ( $_pa['topic_id'] ?? 0 ); ?>" onchange="htsRedacUpdateCount()" style="margin:0;flex-shrink:0">
			<div style="flex:1;min-width:0">
				<div style="font-size:12px;font-weight:600;color:var(--hts-text)"><?php echo esc_html( $_pa['title'] ); ?></div>
				<div style="font-size:10px;color:var(--hts-text-3);margin-top:1px"><?php echo esc_html( $_pa['keyword'] ); ?><?php if ( $_pa['category'] ) echo ' · ' . esc_html( $_pa['category'] ); ?></div>
			</div>
			<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(245,158,11,.15);color:var(--hts-caution);flex-shrink:0">En attente</span>
		</div>
	</div>
	<?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php // En cours de rédaction — JSX-style pipeline with steps ?>
<?php if ( ! empty( $_pipeline_active ) ) :
	$_act = $_pipeline_active[0];
	$_act_phase = $_act['phase'] ?? 'generation';
	$_steps = array(
		array( 'key' => 'plan',       'label' => 'Réception du plan',    'detail' => 'Titre, mot-clé, structure H2/H3 reçus' ),
		array( 'key' => 'generation',  'label' => 'Rédaction du contenu', 'detail' => 'Optimisé SEO GEO' ),
		array( 'key' => 'images',      'label' => 'Génération images',    'detail' => 'Images de l\x27article' ),
		array( 'key' => 'linking',     'label' => 'Maillage interne',     'detail' => 'Liens entrants + sortants auto' ),
		array( 'key' => 'publish',     'label' => 'Brouillon créé',       'detail' => 'Prêt à relire et programmer' ),
	);
	$_step_order = array_column( $_steps, 'key' );
	$_active_idx = array_search( $_act_phase, $_step_order );
	if ( $_active_idx === false ) $_active_idx = 1;
?>
<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin:20px 0 10px">En cours de rédaction</div>
<div class="hts-ds-card" style="margin-bottom:12px;overflow:hidden">
	<div style="padding:16px 20px;display:flex;align-items:center;gap:14px">
		<div style="width:32px;height:32px;border-radius:50%;border:3px solid var(--hts-border-sub);border-top-color:var(--hts-geo);flex-shrink:0;animation:hts-spin .8s linear infinite"></div>
		<div style="flex:1">
			<div style="font-size:14px;font-weight:700;color:var(--hts-text)"><?php echo esc_html( mb_substr( $_act['title'], 0, 50 ) ); ?></div>
			<div style="font-size:11px;color:var(--hts-text-3);margin-top:2px"><?php echo esc_html( $_act['cocon'] ); ?></div>
		</div>
		<div style="text-align:right">
			<div style="font-size:12px;font-weight:700;color:var(--hts-geo)">Étape <?php echo $_active_idx + 1; ?>/5</div>
			<div style="font-size:10px;color:var(--hts-text-3)"><?php echo esc_html( $_steps[ $_active_idx ]['label'] ?? '' ); ?></div>
		</div>
	</div>
	<div style="height:4px;background:var(--hts-border-sub)"><div style="width:<?php echo round( ( $_active_idx + 1 ) / 5 * 100 ); ?>%;height:100%;background:linear-gradient(90deg,var(--hts-geo),var(--hts-accent));border-radius:0 2px 2px 0"></div></div>
	<!-- Pipeline steps -->
	<div style="padding:14px 20px;background:var(--hts-surface);border-top:1px solid var(--hts-border-sub)">
		<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;margin-bottom:10px">Logs en direct</div>
		<?php foreach ( $_steps as $_si => $_step ) :
			$_is_done = $_si < $_active_idx;
			$_is_active = $_si === $_active_idx;
			$_is_pending = $_si > $_active_idx;
		?>
		<div style="display:flex;align-items:flex-start;gap:12px;position:relative">
			<?php if ( $_si < 4 ) : ?><div style="position:absolute;left:9px;top:22px;width:2px;height:28px;background:<?php echo $_is_done ? 'var(--hts-success)' : 'var(--hts-border-sub)'; ?>"></div><?php endif; ?>
			<div style="width:20px;height:20px;border-radius:50%;background:<?php echo $_is_done ? 'var(--hts-success)' : ( $_is_active ? 'var(--hts-geo)' : 'var(--hts-border-sub)' ); ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px">
				<?php if ( $_is_done ) : ?><?php echo HTS_DS::icon('check', 10, '#fff'); ?><?php endif; ?>
				<?php if ( $_is_active ) : ?><div style="width:6px;height:6px;border-radius:50%;background:#fff"></div><?php endif; ?>
			</div>
			<div style="flex:1;padding-bottom:14px">
				<div style="display:flex;justify-content:space-between">
					<span style="font-size:12px;font-weight:<?php echo $_is_active ? '700' : '500'; ?>;color:<?php echo $_is_pending ? 'var(--hts-text-3)' : 'var(--hts-text)'; ?>"><?php echo esc_html( $_step['label'] ); ?></span>
					<span style="font-size:10px;color:var(--hts-text-3);font-family:monospace"><?php echo $_is_done ? date( 'H:i:s' ) : ( $_is_pending ? '—' : '' ); ?></span>
				</div>
				<div style="font-size:11px;color:<?php echo $_is_active ? 'var(--hts-geo)' : 'var(--hts-text-3)'; ?>;margin-top:2px"><?php echo esc_html( $_step['detail'] ); ?></div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
</div>
<?php endif; ?>

<?php // En file ?>
<?php if ( $pipeline_queued > 1 ) : ?>
<?php $q_idx = 0; foreach ( $plans as $_cp_id => $_cp ) :
	foreach ( ( $_cp['articles'] ?? array() ) as $_a ) :
		if ( ( $_a['status'] ?? '' ) !== 'pending_queue' ) continue;
		$q_idx++;
		if ( $q_idx > 5 ) break 2;
?>
<div class="hts-ds-card" style="padding:14px 20px;margin-bottom:8px">
	<div style="display:flex;align-items:center;gap:14px">
		<div style="width:28px;height:28px;border-radius:50%;background:var(--hts-border-sub);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:var(--hts-text-3);flex-shrink:0"><?php echo $q_idx + 1; ?></div>
		<div style="flex:1">
			<div style="font-size:13px;font-weight:600;color:var(--hts-text)"><?php echo esc_html( mb_substr( $_a['title'] ?? $_a['keyword'] ?? '', 0, 50 ) ); ?></div>
			<div style="font-size:10px;color:var(--hts-text-3)"><?php echo esc_html( $_cp['keyword'] ?? '' ); ?></div>
		</div>
		<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(245,158,11,.15);color:var(--hts-caution)">En file</span>
	</div>
</div>
<?php endforeach; endforeach; ?>
<?php endif; ?>

<?php // Completed articles ?>
<?php if ( ! empty( $_pipeline_done ) ) : ?>
<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin:20px 0 10px">Terminés</div>
<?php foreach ( $_pipeline_done as $_done ) : ?>
<div class="hts-ds-card hts-redac-item" data-cocon="<?php echo esc_attr( $_done['cocon'] ); ?>" style="padding:14px 20px;margin-bottom:8px">
	<div style="display:flex;align-items:center;gap:14px">
		<div style="width:28px;height:28px;border-radius:50%;background:var(--hts-success-bg);display:flex;align-items:center;justify-content:center;flex-shrink:0"><?php echo HTS_DS::icon('check', 12, 'var(--hts-success)'); ?></div>
		<div style="flex:1">
			<div style="font-size:13px;font-weight:600;color:var(--hts-text)"><?php echo esc_html( mb_substr( $_done['title'], 0, 50 ) ); ?></div>
			<div style="display:flex;gap:8px;font-size:10px;color:var(--hts-text-3);margin-top:2px">
				<?php if ( $_done['word_count'] > 0 ) : ?><span><?php echo number_format( $_done['word_count'] ); ?> mots</span><?php endif; ?>
				<span><?php echo esc_html( $_done['cocon'] ); ?></span>
			</div>
			<?php if ( $_done['scheduled'] && $_done['pub_date'] ) : ?>
			<div style="font-size:10px;color:var(--hts-success);margin-top:2px">Publié le <?php echo esc_html( $_done['pub_date'] ); ?></div>
			<?php endif; ?>
		</div>
		<div style="display:flex;gap:6px;flex-shrink:0">
			<?php if ( ! $_done['scheduled'] && ! $_done['approved'] ) : ?>
			<button onclick="htsToggleApprove(<?php echo (int) $_done['post_id']; ?>,1,this)" style="padding:5px 12px;border-radius:6px;border:1px solid var(--hts-geo-border);background:var(--hts-geo-soft);font-size:11px;font-weight:600;color:var(--hts-geo);cursor:pointer;font-family:var(--hts-font)">Programmer</button>
			<?php endif; ?>
			<a href="<?php echo esc_url( $_done['edit_url'] ); ?>" target="_blank" style="padding:5px 12px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-2);text-decoration:none;font-family:var(--hts-font)">Voir</a>
		</div>
	</div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php // Empty state — different for Pro (can't write) vs Ultra (can write) ?>
<?php if ( empty( $_pipeline_active ) && empty( $_pipeline_done ) && $pipeline_queued === 0 ) : ?>
<?php if ( ! $_hts_can_write ) : ?>
<div class="hts-ds-card" style="padding:40px;text-align:center">
	<div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#6366f1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px"><?php echo HTS_DS::icon( 'zap', 28, '#fff' ); ?></div>
	<div style="font-size:16px;font-weight:700;color:var(--hts-text);margin-bottom:8px">Rédaction automatique</div>
	<div style="font-size:13px;color:var(--hts-text-2);max-width:380px;margin:0 auto 16px;line-height:1.6">Vos articles sont rédigés par l'IA avec images et liens internes automatiques. 50 articles/mois.</div>
	<div style="font-size:12px;color:var(--hts-text-3);max-width:380px;margin:0 auto 16px;line-height:1.5">Vous pouvez aussi rédiger manuellement vos articles ou les commander depuis le SaaS (<a href="<?php echo esc_url( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ) ); ?>" target="_blank" style="color:var(--hts-geo)">app.hacktheseo.com</a>).</div>
	<a href="https://hacktheseo.com/pricing" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;text-decoration:none"><?php echo HTS_DS::icon( 'zap', 16, '#fff' ); ?> Passer à Ultra — 249€/mois</a>
</div>
<?php else : ?>
<div class="hts-ds-card" style="padding:40px;text-align:center">
	<?php echo HTS_DS::icon( 'zap', 32, 'var(--hts-faint)' ); ?>
	<div style="font-size:14px;font-weight:700;color:var(--hts-text);margin:12px 0 6px">Aucun article en cours de rédaction</div>
	<div style="font-size:12px;color:var(--hts-text-3);max-width:340px;margin:0 auto">Sélectionnez des articles dans vos groupes et cliquez « Générer » pour lancer la rédaction automatique.</div>
</div>
<?php endif; ?>
<?php endif; ?>

<?php // Planification banner ?>
<?php if ( $_hts_plan_ready > 0 || $_hts_plan_scheduled > 0 ) : ?>
<div style="margin-top:20px;display:flex;justify-content:space-between;align-items:center;padding:16px 20px;background:var(--hts-accent-bg);border:1px solid var(--hts-accent-bg);border-radius:12px">
	<div>
		<div style="font-size:15px;font-weight:700;color:var(--hts-text)">Planification des publications</div>
		<div style="font-size:11px;color:var(--hts-text-2);margin-top:2px"><?php echo $_hts_plan_ready; ?> article(s) prêt(s) · <?php echo $_hts_plan_scheduled; ?> planifié(s)<?php if ( ! empty( $auto_sched_config['enabled'] ) ) : ?> · Auto-publication active<?php endif; ?></div>
	</div>
	<a href="<?php echo admin_url( 'admin.php?page=hts-planning'); ?>" style="font-size:11px;color:var(--hts-geo);background:#fff;padding:6px 14px;border-radius:8px;border:1px solid var(--hts-geo-border);text-decoration:none;font-weight:600">Gérer la planification</a>
</div>
<?php endif; ?>

<?php endif; /* end else _hts_can_write */ ?>
</div><!-- /hts-cc-panel-redaction -->
<script>
function htsFilterRedac(cocon){
	document.querySelectorAll('.hts-redac-item,.hts-redac-group').forEach(function(el){
		if(!cocon||el.dataset.cocon===cocon)el.style.display='block';
		else el.style.display='none';
	});
}
function htsRedacSelectAll(checked){
	document.querySelectorAll('.hts-redac-cb').forEach(function(cb){
		if(cb.closest('.hts-redac-item').style.display!=='none')cb.checked=checked;
	});
	htsRedacUpdateCount();
}
function htsRedacUpdateCount(){
	var n=document.querySelectorAll('.hts-redac-cb:checked').length;
	var el=document.getElementById('hts-redac-sel-count');
	if(el)el.textContent=n+' s\u00e9l.';
}

/* ═══ LIVE PIPELINE — 5-step inline in article rows ═══ */
var _rlSteps=[
	{key:'plan',label:'R\u00e9ception du plan',detail:'Titre, mot-cl\u00e9, structure H2/H3'},
	{key:'generation',label:'R\u00e9daction du contenu',detail:'Optimis\u00e9 SEO GEO'},
	{key:'images',label:'G\u00e9n\u00e9ration images',detail:'Images de l\u0027article'},
	{key:'linking',label:'Maillage interne',detail:'Liens entrants + sortants auto'},
	{key:'publish',label:'Brouillon cr\u00e9\u00e9',detail:'Pr\u00eat \u00e0 relire et programmer'}
];
function _rlNow(){var d=new Date();return ('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2)+':'+('0'+d.getSeconds()).slice(-2)}
function _rlPhaseIdx(phase){for(var i=0;i<_rlSteps.length;i++){if(_rlSteps[i].key===phase)return i}return 1}
function _rlEsc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}

/* Transform an article row into inline 5-step card */
function _rlInjectInline(el,id,title,coconName){
	el.className='hts-rl-card';
	el.style.cssText='margin-bottom:8px;overflow:hidden';
	el.innerHTML=
		'<div class="hts-rl-card-head">'
		+'<div class="hts-rl-spinner" id="hts-rl-spin-'+id+'"></div>'
		+'<div style="flex:1;min-width:0">'
		+'<div style="font-size:13px;font-weight:700;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" id="hts-rl-title-'+id+'">'+_rlEsc(title)+'</div>'
		+'<div style="font-size:10px;color:var(--hts-text-3);margin-top:2px">'+_rlEsc(coconName)+'</div>'
		+'</div>'
		+'<div style="text-align:right" id="hts-rl-phase-'+id+'">'
		+'<div style="font-size:11px;font-weight:700;color:var(--hts-geo)">\u00c9tape 1/5</div>'
		+'<div style="font-size:9px;color:var(--hts-text-3)">Envoi</div>'
		+'</div>'
		+'</div>'
		+'<div class="hts-rl-bar"><div class="hts-rl-bar-fill" id="hts-rl-bar-'+id+'" style="width:10%"></div></div>'
		+'<div class="hts-rl-steps" id="hts-rl-steps-'+id+'">'
		+'<div style="font-size:9px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;margin-bottom:8px">Logs en direct</div>'
		+_rlBuildSteps(id)
		+'</div>';
}

function _rlBuildSteps(id){
	var h='';
	for(var i=0;i<_rlSteps.length;i++){
		var s=_rlSteps[i];
		h+='<div class="hts-rl-step">';
		if(i<4)h+='<div class="hts-rl-step-line" id="hts-rl-ln-'+id+'-'+i+'"></div>';
		h+='<div class="hts-rl-dot pending" id="hts-rl-dot-'+id+'-'+i+'"></div>';
		h+='<div class="hts-rl-step-body">';
		h+='<div style="display:flex;justify-content:space-between">';
		h+='<span class="hts-rl-step-label pending" id="hts-rl-lbl-'+id+'-'+i+'">'+s.label+'</span>';
		h+='<span class="hts-rl-step-time" id="hts-rl-tm-'+id+'-'+i+'">\u2014</span>';
		h+='</div>';
		h+='<div class="hts-rl-step-detail" id="hts-rl-det-'+id+'-'+i+'">'+s.detail+'</div>';
		h+='</div></div>';
	}
	return h;
}

function _rlUpdatePhase(id,phaseIdx,detail){
	var bar=document.getElementById('hts-rl-bar-'+id);
	var phEl=document.getElementById('hts-rl-phase-'+id);
	if(bar)bar.style.width=Math.min(100,Math.round((phaseIdx+1)/5*100))+'%';
	if(phEl){
		if(phaseIdx>=5){
			phEl.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--hts-success)">Termin\u00e9</div>';
		}else{
			phEl.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--hts-geo)">\u00c9tape '+(phaseIdx+1)+'/5</div>'
				+'<div style="font-size:9px;color:var(--hts-text-3)">'+_rlEsc(_rlSteps[phaseIdx]?_rlSteps[phaseIdx].label:'')+'</div>';
		}
	}
	for(var i=0;i<_rlSteps.length;i++){
		var dot=document.getElementById('hts-rl-dot-'+id+'-'+i);
		var lbl=document.getElementById('hts-rl-lbl-'+id+'-'+i);
		var det=document.getElementById('hts-rl-det-'+id+'-'+i);
		var tm=document.getElementById('hts-rl-tm-'+id+'-'+i);
		var ln=document.getElementById('hts-rl-ln-'+id+'-'+i);
		if(!dot)continue;
		if(i<phaseIdx){
			dot.className='hts-rl-dot done';
			dot.innerHTML='<svg width="10" height="10" viewBox="0 0 24 24" fill="none"><polyline points="20,6 9,17 4,12" stroke="#fff" stroke-width="2.5" fill="none"/></svg>';
			if(lbl){lbl.className='hts-rl-step-label'}
			if(det){det.className='hts-rl-step-detail'}
			if(tm&&tm.textContent==='\u2014')tm.textContent=_rlNow();
			if(ln)ln.className='hts-rl-step-line done';
		}else if(i===phaseIdx){
			dot.className='hts-rl-dot active';
			dot.innerHTML='<div class="hts-rl-pulse"></div>';
			if(lbl){lbl.className='hts-rl-step-label active'}
			if(det){det.className='hts-rl-step-detail active';if(detail)det.textContent=detail}
			if(tm)tm.textContent=_rlNow();
		}else{
			dot.className='hts-rl-dot pending';dot.innerHTML='';
			if(lbl){lbl.className='hts-rl-step-label pending'}
			if(det){det.className='hts-rl-step-detail'}
		}
	}
}

function _rlMarkDone(id,info,editUrl,postId,thumbHtml){
	var spin=document.getElementById('hts-rl-spin-'+id);
	var phEl=document.getElementById('hts-rl-phase-'+id);
	var bar=document.getElementById('hts-rl-bar-'+id);
	if(spin){spin.className='hts-rl-spinner done';spin.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" style="margin:auto"><polyline points="20,6 9,17 4,12" stroke="var(--hts-success)" stroke-width="2.5" fill="none"/></svg>';spin.style.display='flex';spin.style.alignItems='center';spin.style.justifyContent='center'}
	if(bar)bar.style.width='100%';
	if(phEl)phEl.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--hts-success)">Termin\u00e9</div>'+(info?'<div style="font-size:9px;color:var(--hts-text-3)">'+_rlEsc(info)+'</div>':'')+(thumbHtml||'');
	_rlUpdatePhase(id,5,'');
	/* S14: inject "Voir le brouillon" DS button under the last step (publish) */
	var lastDet=document.getElementById('hts-rl-det-'+id+'-4');
	if(lastDet&&editUrl){
		var btn=document.createElement('a');
		btn.href=editUrl;btn.target='_blank';
		btn.className='hts-cc-btn primary';
		btn.style.cssText='margin-top:8px;font-size:11px;padding:6px 14px;text-decoration:none;display:inline-flex;align-items:center;gap:5px';
		btn.innerHTML='<svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M15 3h6v6M14 10l6.1-6.1M10 5H5a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2v-5" stroke="#fff" stroke-width="2"/></svg> Voir le brouillon'+(postId?' #'+postId:'');
		lastDet.parentNode.appendChild(btn);
	}
}

function _rlMarkError(id,msg,cid,akey,tid){
	var spin=document.getElementById('hts-rl-spin-'+id);
	var phEl=document.getElementById('hts-rl-phase-'+id);
	var bar=document.getElementById('hts-rl-bar-'+id);
	if(spin){spin.className='hts-rl-spinner error';spin.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" style="margin:auto"><path d="M18 6L6 18M6 6l12 12" stroke="var(--hts-danger)" stroke-width="2.2"/></svg>';spin.style.display='flex';spin.style.alignItems='center';spin.style.justifyContent='center'}
	if(bar){bar.style.background='var(--hts-danger)';bar.style.width='100%'}
	var retry=cid&&akey?'<button class="hts-rl-retry" onclick="event.stopPropagation();_rlRetry(this,\''+_rlEsc(id)+'\',\''+_rlEsc(cid)+'\',\''+_rlEsc(akey)+'\',\''+_rlEsc(tid||'')+'\')">R\u00e9essayer</button>':'';
	/* Detect "already queued" error → show force button instead of retry */
	var isQueued=msg&&(msg.indexOf('en cours de traitement')!==-1||msg.indexOf('queued')!==-1||msg.indexOf('d\u00e9j\u00e0 en cours')!==-1);
	if(isQueued&&cid&&akey){
		retry='<button class="hts-rl-retry" style="background:var(--hts-caution-bg);color:var(--hts-caution);border-color:var(--hts-caution)" onclick="event.stopPropagation();htsForceGen(this,\''+_rlEsc(cid)+'\',\''+_rlEsc(akey)+'\',\''+_rlEsc(tid||'')+'\')">Forcer</button>';
		msg='Article d\u00e9j\u00e0 en file c\u00f4t\u00e9 serveur';
	}
	if(phEl)phEl.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--hts-danger)">Erreur</div><div style="font-size:9px;color:var(--hts-text-3);max-width:180px;word-break:break-word">'+_rlEsc(msg)+'</div>'+retry;
}

function _rlRetry(btn,id,cid,akey,tid){
	btn.disabled=true;btn.textContent='...';
	var spin=document.getElementById('hts-rl-spin-'+id);
	if(spin){spin.className='hts-rl-spinner';spin.innerHTML='';spin.style.display='inline-flex'}
	var bar=document.getElementById('hts-rl-bar-'+id);
	if(bar){bar.style.background='';bar.style.width='10%'}
	_rlSendArticle(id,cid,akey,tid,function(){});
}

/* ═══ Switch to R\u00e9daction tab ═══ */
function _rlSwitchToRedac(){
	if(typeof htsCCTab==='function')htsCCTab('redaction');
}

/* ═══ Core: send article + poll with live step update ═══ */
function _rlSendArticle(id,cid,akey,tid,cb){
	_rlUpdatePhase(id,0,'Envoi de l\u0027article...');
	if(typeof window._htsPostFn!=='function'){_rlMarkError(id,'Fonction AJAX introuvable');if(cb)cb();return}
	window._htsPostFn('hts_cocon_gen_article',{cocon_id:cid,article_key:akey,topic_id:tid||''}).then(function(r){
		if(r.success&&r.data.job_id){
			_rlUpdatePhase(id,1,'Job #'+r.data.job_id+' lanc\u00e9');
			_rlPollArticle(id,r.data.job_id,cid,akey,cb);
		}else if(!r.success&&r.data&&r.data.cannibal_warning){
			var conflicts=r.data.conflicts||[];
			var msg='Cannibalisation';
			if(conflicts.length)msg+=': '+conflicts[0].title;
			_rlMarkError(id,msg,cid,akey,tid);if(cb)cb();
		}else{
			var msg=r.data&&r.data.message?r.data.message:(typeof r.data==='string'?r.data:'Erreur inconnue');
			/* ── Fallback: if cocon not found, retry with main plan cocon_id ── */
			var isNotFound=(msg.indexOf('n\u0027existe pas')!==-1||msg.indexOf('not found')!==-1||msg.indexOf('introuvable')!==-1);
			var fallbackId=window._htsFallbackMap&&window._htsFallbackMap[cid];
			if(isNotFound&&fallbackId&&fallbackId!==cid){
				_rlUpdatePhase(id,0,'Cocon #'+cid+' inconnu, retry avec #'+fallbackId+'...');
				window._htsPostFn('hts_cocon_gen_article',{cocon_id:fallbackId,article_key:akey,topic_id:tid||''}).then(function(r2){
					if(r2.success&&r2.data.job_id){
						_rlUpdatePhase(id,1,'Job #'+r2.data.job_id+' lanc\u00e9 (via #'+fallbackId+')');
						_rlPollArticle(id,r2.data.job_id,fallbackId,akey,cb);
					}else{
						var msg2=r2.data&&r2.data.message?r2.data.message:'Erreur';
						_rlMarkError(id,msg2,cid,akey,tid);if(cb)cb();
					}
				}).catch(function(err2){
					_rlMarkError(id,'R\u00e9seau (retry): '+(err2||'timeout'),cid,akey,tid);if(cb)cb();
				});
				return;
			}
			_rlMarkError(id,msg,cid,akey,tid);if(cb)cb();
		}
	}).catch(function(err){
		_rlMarkError(id,'R\u00e9seau: '+(err||'timeout'),cid,akey,tid);if(cb)cb();
	});
}

/* ═══ Poll article with phase mapping ═══ */
function _rlPollArticle(id,jid,cid,akey,cb){
	var lastPhase='',phaseStart=Date.now();
	var iv=setInterval(function(){
		if(typeof window._htsPostFn!=='function'){clearInterval(iv);return}
		window._htsPostFn('hts_cocon_poll_article',{job_id:jid,cocon_id:cid}).then(function(r){
			if(!r.success)return;
			var s=r.data.status,ph=r.data.phase||s;
			if(ph!==lastPhase){lastPhase=ph;phaseStart=Date.now()}
			var elapsed=Math.round((Date.now()-phaseStart)/1000);
			var idx=_rlPhaseIdx(ph);
			var det=r.data.article_title||_rlSteps[idx].detail;
			if(r.data.word_count)det+=(' \u00b7 '+r.data.word_count+' mots');
			if(elapsed>60)det+=' ('+elapsed+'s)';
			_rlUpdatePhase(id,idx,det);
			if(elapsed>300){clearInterval(iv);_rlMarkError(id,'Timeout (5min)',cid,akey,'');if(cb)cb();return}
			if(s==='completed'&&r.data.article_ready){
				clearInterval(iv);
				_rlUpdatePhase(id,2,'Cr\u00e9ation du brouillon...');
				window._htsPostFn('hts_cocon_create_draft',{cocon_id:cid,article_key:akey,job_id:jid}).then(function(d){
					if(d.success){
						var postId=d.data.post_id||0;
						var editUrl=d.data.edit_url||'';
						var titleTxt=d.data.title||'Article';
						var titleEl=document.getElementById('hts-rl-title-'+id);
						if(titleEl&&editUrl)titleEl.innerHTML='<a href="'+_rlEsc(editUrl)+'" target="_blank" style="color:var(--hts-text);text-decoration:none;font-weight:700">'+_rlEsc(titleTxt)+'</a> <span style="color:var(--hts-text-3);font-size:10px">#'+postId+'</span>';
						/* Step 3: Images + maillage en arrière-plan */
						_rlUpdatePhase(id,2,'Images + maillage en cours...');
						_rlPollImages(id,postId,editUrl,titleTxt,cb);
					}else{_rlMarkError(id,'Brouillon \u00e9chou\u00e9',cid,akey,'')}
					if(!d.success&&cb)cb();
				}).catch(function(){_rlMarkError(id,'R\u00e9seau (draft)',cid,akey,'');if(cb)cb()});
				return;
			}
			if(s==='failed'||s==='error'){clearInterval(iv);_rlMarkError(id,r.data.message||'\u00c9chec',cid,akey,'');if(cb)cb()}
		}).catch(function(){/* retry next interval */});
	},5000);
}

/* ═══ Poll images + maillage status after draft creation ═══ */
function _rlPollImages(id,postId,editUrl,titleTxt,cb){
	var attempts=0,maxAttempts=40,staleCount=0,gracePolls=2;
	_rlUpdatePhase(id,2,'Images IA en pr\u00e9paration\u2026');
	setTimeout(function(){
		_rlUpdatePhase(id,2,'Images IA + maillage en arri\u00e8re-plan\u2026');
		var iv=setInterval(function(){
			attempts++;
			if(typeof window._htsPostFn!=='function'){clearInterval(iv);_rlMarkDone(id,titleTxt,editUrl,postId);if(cb)cb();return}
			window._htsPostFn('hts_cocon_check_images_status',{post_id:postId}).then(function(r){
				if(!r.success){staleCount++;if(staleCount>=3){clearInterval(iv);_rlMarkDone(id,titleTxt+' (images en arri\u00e8re-plan)',editUrl,postId);if(cb)cb()}return}
				staleCount=0;
				if(r.data.status==='done'){
					if(!r.data.thumb_url&&r.data.img_count===0&&attempts<=gracePolls){
						_rlUpdatePhase(id,2,'Images IA en cours\u2026 ('+Math.round(12+attempts*15)+'s)');
						return;
					}
					clearInterval(iv);
					var imgDet='';
					if(r.data.img_count>0)imgDet=r.data.img_count+' image'+(r.data.img_count>1?'s':'');
					else imgDet='Termin\u00e9';
					_rlUpdatePhase(id,2,imgDet);
					var linkDet='';
					if(r.data.cross_links>0)linkDet=r.data.cross_links+' lien'+(r.data.cross_links>1?'s':'');
					else linkDet='Termin\u00e9';
					_rlUpdatePhase(id,3,linkDet);
					_rlUpdatePhase(id,4,'Brouillon #'+postId);
					var thumbHtml='';
					if(r.data.thumb_url){thumbHtml='<img src="'+_rlEsc(r.data.thumb_url)+'" style="width:32px;height:32px;border-radius:6px;object-fit:cover;border:1px solid var(--hts-border);margin-top:4px">'}
					_rlMarkDone(id,titleTxt,editUrl,postId,thumbHtml);
					if(cb)cb();
				}else{
					_rlUpdatePhase(id,2,'Images IA + maillage en arri\u00e8re-plan\u2026 ('+Math.round(12+attempts*15)+'s)');
				}
			}).catch(function(){staleCount++});
			if(attempts>=maxAttempts){
				clearInterval(iv);
				_rlMarkDone(id,titleTxt+' (images en arri\u00e8re-plan)',editUrl,postId);
				if(cb)cb();
			}
		},15000);
	},12000);
}

/* ═══ Batch from R\u00e9daction tab — INLINE in article rows ═══ */
function htsRedacGenBatch(){
	var cbs=document.querySelectorAll('.hts-redac-cb:checked');
	if(!cbs.length){_toast('S\u00e9lectionnez des articles');return}
	_rlSwitchToRedac();
	var items=[];
	cbs.forEach(function(cb){
		var row=cb.closest('.hts-redac-item');
		var titleEl=row?row.querySelector('[style*="font-weight:600"]'):null;
		items.push({
			akey:cb.dataset.akey,
			cid:cb.dataset.coconId,
			tid:cb.dataset.topic||'',
			title:titleEl?titleEl.textContent.trim():'Article',
			cocon:row?row.dataset.cocon||'':'',
			el:row
		});
	});
	htsRedacUpdateCount();
	/* Transform each row inline */
	items.forEach(function(it){
		if(it.el){
			_rlInjectInline(it.el,it.akey,it.title,it.cocon);
		}else{
			/* Fallback: inject in #hts-redac-live */
			var container=document.getElementById('hts-redac-live');
			if(container){
				var div=document.createElement('div');
				div.id='hts-redac-art-'+it.akey;
				container.insertBefore(div,container.firstChild);
				_rlInjectInline(div,it.akey,it.title,it.cocon);
			}
		}
	});
	/* Process sequentially */
	var idx=0;
	function nextItem(){
		if(idx>=items.length){_toast(items.length+' article(s) trait\u00e9(s)','success');return}
		var it=items[idx];idx++;
		_rlSendArticle(it.akey,it.cid,it.akey,it.tid,nextItem);
	}
	nextItem();
}
</script>

<!-- ═══════════════════════════════════════════════════
 * BLOC 5: LOGS — v2.5.13: mode expert uniquement
 * ═══════════════════════════════════════════════════ -->

<div class="hts-cc-section"> <div class="hts-cc-card" style="padding:0;"> <div style="display:flex;justify-content:space-between;align-items:center;cursor:pointer;padding:14px 18px;" onclick="var b=document.getElementById('hts-logs-body');var w=b.style.display==='none';b.style.display=w?'block':'none';this.querySelector('.chv').textContent=w?'▼':'▶';if(w&&!window._htsLogsLoaded){window._htsLogsLoaded=true;htsLoadCoconLogs()}"> <h3 style="margin:0;font-size:14px;"> Activité</h3> <span class="chv" style="font-size:12px;color:var(--hts-text-3);">▶</span> </div> <div id="hts-logs-body" style="display:none;border-top:1px solid var(--hts-surface);padding:16px 18px;"> <div style="display:flex;gap:6px;align-items:center;margin-bottom:10px;"> <select id="hts-log-filter" onchange="htsLoadCoconLogs()" style="font-size:10px;padding:2px 6px;border:1px solid var(--hts-border);border-radius:4px;"><option value="all">Tout</option><option value="articles"> Articles</option><option value="schedule"> Planification</option><option value="errors"> Erreurs</option><option value="links"> Maillage</option></select> <button class="hts-cc-btn outline sm" onclick="htsLoadCoconLogs()"></button> <button class="hts-cc-btn outline sm" onclick="htsExportLogs()"></button> </div> <div style="max-height:400px;overflow-y:auto;"><table class="hts-cc-log-table"><tbody id="hts-cocon-logs-body"><tr><td colspan="4" style="text-align:center;color:var(--hts-text-3);padding:12px;font-size:11px;">Cliquez pour charger</td></tr></tbody></table></div> </div> </div>
</div>
 <div id="hts-toast" class="hts-toast"></div>
</div>

<!-- ═══════════════════════════════════════════════════
 * DETAIL VIEW — Graph + Sidebar + Floating Bar
 * Full-viewport overlay, loaded via AJAX on cocon card click
 * ═══════════════════════════════════════════════════ -->
<div id="hts-graph-view" style="display:none;position:fixed;top:32px;left:0;right:0;bottom:0;z-index:9990;flex-direction:column;font-family:var(--hts-font)">
	<!-- Top bar (light gray) -->
	<div style="padding:12px 20px;display:flex;justify-content:space-between;align-items:center;background:var(--hts-bg,#fff);border-bottom:1px solid var(--hts-border,#E2E8F0);flex-shrink:0;z-index:15">
		<div style="display:flex;align-items:center;gap:12px">
			<div id="hts-graph-back" style="display:flex;align-items:center;gap:6px;padding:9px 18px 9px 14px;border-radius:10px;background:var(--hts-accent-bg,#EBF3FF);border:2px solid var(--hts-accent,#2D7FF9);cursor:pointer;transition:all .15s;box-shadow:0 1px 3px rgba(45,127,249,.15)" onmouseenter="this.style.background='var(--hts-accent)';this.querySelectorAll('span')[0].style.color='#fff'" onmouseleave="this.style.background='var(--hts-accent-bg)';this.querySelectorAll('span')[0].style.color='var(--hts-accent)'">
				<span style="font-size:13px;font-weight:700;color:var(--hts-accent,#2D7FF9)">&larr; Mes groupes</span>
			</div>
			<div style="width:1px;height:18px;background:var(--hts-border,#E2E8F0)"></div>
			<div>
				<div id="hts-graph-title" style="font-size:15px;font-weight:700;color:var(--hts-text,#111827)"></div>
				<div id="hts-graph-sub" style="font-size:11px;color:var(--hts-text-3,#9CA3AF)"></div>
			</div>
		</div>
		<!-- Toggle liens au milieu -->
		<div id="hts-graph-link-toggle" style="display:none;align-items:center;gap:2px;padding:3px;background:rgba(120,120,128,.08);border-radius:8px">
			<button onclick="htsCCToggleLinks('real')" data-mode="real" class="hts-link-toggle-btn active" style="padding:5px 10px;border-radius:6px;border:none;font-size:10px;font-weight:600;cursor:pointer;font-family:var(--hts-font);background:var(--hts-bg);color:var(--hts-text);box-shadow:0 1px 2px rgba(0,0,0,.06)">Liens</button>
			<button onclick="htsCCToggleLinks('proposed')" data-mode="proposed" class="hts-link-toggle-btn" style="padding:5px 10px;border-radius:6px;border:none;font-size:10px;font-weight:600;cursor:pointer;font-family:var(--hts-font);background:transparent;color:var(--hts-text-3)">Propositions</button>
			<button onclick="htsCCToggleLinks('all')" data-mode="all" class="hts-link-toggle-btn" style="padding:5px 10px;border-radius:6px;border:none;font-size:10px;font-weight:600;cursor:pointer;font-family:var(--hts-font);background:transparent;color:var(--hts-text-3)">Tous</button>
		</div>
		<!-- Badges à droite -->
		<div id="hts-graph-badges" style="display:flex;gap:6px"></div>
	</div>

	<!-- Main area: staging + graph + sidebar -->
	<div style="flex:1;display:flex;position:relative;overflow:hidden">
		<!-- Staging panel (left, hidden by default) -->
		<div id="hts-graph-staging" style="display:none;width:300px;background:var(--hts-bg);border-right:1px solid var(--hts-border);box-shadow:4px 0 24px rgba(0,0,0,.15);flex-direction:column;z-index:20;flex-shrink:0">
			<div id="hts-staging-header" style="padding:16px 18px;border-bottom:1px solid var(--hts-border);display:flex;justify-content:space-between;align-items:center">
				<div><div id="hts-staging-title" style="font-size:14px;font-weight:700;color:var(--hts-text)">Analyse en cours...</div><div id="hts-staging-sub" style="font-size:11px;color:var(--hts-text-3);margin-top:2px"></div></div>
				<div onclick="htsCCStagingClose()" style="width:24px;height:24px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--hts-text-3);font-size:14px">&times;</div>
			</div>
			<div id="hts-staging-body" style="flex:1;overflow-y:auto;padding:18px"></div>
			<div id="hts-staging-footer" style="display:none;padding:14px 18px;border-top:1px solid var(--hts-border)"></div>
		</div>

		<!-- Graph canvas -->
		<div id="hts-graph-canvas" style="flex:1;background:#141419;position:relative;overflow:hidden">
			<!-- Legend bottom-left -->
			<div style="position:absolute;bottom:60px;left:16px;display:flex;flex-direction:column;gap:6px;z-index:10">
				<div style="display:flex;align-items:center;gap:6px"><div style="width:8px;height:8px;border-radius:50%;background:var(--hts-success)"></div><span style="font-size:11px;color:rgba(255,255,255,.4)">&gt; 75</span></div>
				<div style="display:flex;align-items:center;gap:6px"><div style="width:8px;height:8px;border-radius:50%;background:var(--hts-caution)"></div><span style="font-size:11px;color:rgba(255,255,255,.4)">50-74</span></div>
				<div style="display:flex;align-items:center;gap:6px"><div style="width:8px;height:8px;border-radius:50%;background:var(--hts-danger)"></div><span style="font-size:11px;color:rgba(255,255,255,.4)">&lt; 50</span></div>
				<div id="hts-legend-proposed" style="display:none;align-items:center;gap:6px"><div style="width:18px;height:0;border-top:2px dashed var(--hts-geo)"></div><span style="font-size:11px;color:rgba(255,255,255,.4)">Lien propos&eacute;</span></div>
			</div>

			<!-- Floating Action Bar -->
			<div id="hts-graph-fab" style="position:absolute;bottom:16px;left:50%;transform:translateX(-50%);z-index:12;display:flex;align-items:center;gap:2px;padding:6px 8px;background:rgba(29,29,31,.8);backdrop-filter:blur(20px);border-radius:12px;border:1px solid rgba(255,255,255,.06)">
				<div id="hts-fab-info" style="display:flex;align-items:center;gap:8px;padding:5px 10px 5px 5px;border-radius:8px;background:rgba(255,255,255,.04);cursor:pointer"></div>
				<button onclick="htsCCStartComplete()" title="Proposer de nouveaux articles pour renforcer ce groupe" style="display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:8px;border:none;background:transparent;color:rgba(255,255,255,.6);font-size:11px;font-weight:500;cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon('plus',12,'rgba(255,255,255,.5)'); ?> Cr&#233;er de nouveaux contenus</button>
				<button onclick="htsCCGraphAction('link')" title="Cr&#233;e automatiquement les liens internes entre les articles de ce groupe" style="display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:8px;border:none;background:transparent;color:rgba(255,255,255,.6);font-size:11px;font-weight:500;cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon('link',12,'rgba(255,255,255,.5)'); ?> Cr&#233;er les liens</button>
				<?php /* Bouton Santé masqué — action disponible via sidebar Détails
				<button onclick="htsCCGraphAction('zap')" title="V&#233;rifier la sant&#233; du groupe" style="display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:8px;border:none;background:transparent;color:rgba(255,255,255,.6);font-size:11px;font-weight:500;cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon('zap',12,'rgba(255,255,255,.5)'); ?> V&#233;rifier la sant&#233;</button>
				*/ ?>
				<button onclick="htsCCSidebarToggle()" style="display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:8px;border:none;background:transparent;color:rgba(255,255,255,.6);font-size:11px;font-weight:500;cursor:pointer;font-family:var(--hts-font)"><?php echo HTS_DS::icon('chart',12,'rgba(255,255,255,.5)'); ?> D&#233;tails</button>
			</div>

			<!-- ARTICLES vertical band (left edge when staging closed) -->
			<div id="hts-graph-articles-band" onclick="event.stopPropagation();htsCCStagingReopen()" style="position:absolute;left:0;top:0;bottom:0;width:28px;background:rgba(255,255,255,.03);border-right:1px solid rgba(255,255,255,.06);cursor:pointer;display:none;align-items:center;justify-content:center;z-index:10">
				<span style="writing-mode:vertical-rl;transform:rotate(180deg);font-size:10px;font-weight:600;color:rgba(255,255,255,.2);letter-spacing:.08em">ARTICLES</span>
			</div>

			<!-- DETAILS vertical band (right edge when sidebar closed) -->
			<div id="hts-graph-details-band" onclick="event.stopPropagation();htsCCSidebarToggle(true)" style="position:absolute;right:0;top:0;bottom:0;width:28px;background:rgba(255,255,255,.03);border-left:1px solid rgba(255,255,255,.06);cursor:pointer;display:none;align-items:center;justify-content:center;z-index:10">
				<span style="writing-mode:vertical-rl;font-size:10px;font-weight:600;color:rgba(255,255,255,.2);letter-spacing:.08em">DETAILS</span>
			</div>

			<!-- SVG container -->
			<svg id="hts-graph-svg" width="100%" height="100%" viewBox="0 0 820 560" preserveAspectRatio="xMidYMid meet" style="display:block">
				<defs>
					<marker id="hts-arrow" markerWidth="10" markerHeight="8" refX="10" refY="4" orient="auto"><polygon points="0 0, 10 4, 0 8" fill="rgba(99,102,241,.5)"/></marker>
					<marker id="hts-arrow-sel" markerWidth="10" markerHeight="8" refX="10" refY="4" orient="auto"><polygon points="0 0, 10 4, 0 8" fill="var(--hts-accent)"/></marker>
					<marker id="hts-arrow-proposed" markerWidth="10" markerHeight="8" refX="10" refY="4" orient="auto"><polygon points="0 0, 10 4, 0 8" fill="var(--hts-geo)" opacity="0.6"/></marker>
				</defs>
				<g id="hts-graph-links"></g>
				<g id="hts-graph-nodes"></g>
			</svg>

			<!-- Empty state -->
			<div id="hts-graph-empty" style="display:none;position:absolute;inset:0;align-items:center;justify-content:center;color:rgba(255,255,255,.3);font-size:14px">Aucune donn&eacute;e pour ce groupe</div>
		</div>

		<!-- Sidebar -->
		<div id="hts-graph-sidebar" style="display:none;width:340px;background:var(--hts-bg);border-left:1px solid var(--hts-border);box-shadow:-4px 0 24px rgba(0,0,0,.1);overflow:auto;flex-shrink:0;flex-direction:column">
			<div id="hts-sidebar-body" style="padding:20px;flex:1"></div>
		</div>
	</div>
</div> <!-- Custom confirm modal (replaces native confirm()) — outside .hts-cc for proper viewport centering -->
<div id="hts-modal-overlay" class="hts-modal-overlay" onclick="if(event.target===this)htsModalClose(false)"> <div class="hts-modal"> <h4 id="hts-modal-title"></h4> <p id="hts-modal-msg"></p> <div class="hts-modal-actions"> <button class="hts-cc-btn outline" onclick="htsModalClose(false)" id="hts-modal-cancel">Annuler</button> <button class="hts-cc-btn primary" onclick="htsModalClose(true)" id="hts-modal-ok">Confirmer</button> </div> </div>
</div> <script>
/* ═══ Available NLP clusters (for debug + fuzzy matching) ═══ */
var _htsAvailableClusters=<?php echo wp_json_encode( array_map( function($c){ return $c['name'] ?? ''; }, $clusters_data ) ); ?>;

/* ═══ Tab switching (JSX S6 pill tabs) ═══ */
function htsCCTab(id){
	document.querySelectorAll('.hts-cc-tab-panel').forEach(function(p){p.style.display='none'});
	var panel=document.getElementById('hts-cc-panel-'+id);
	if(panel)panel.style.display='block';
	document.querySelectorAll('.hts-cc-tab-btn').forEach(function(b){
		var active=(b.dataset.tab===id);
		b.style.background=active?'var(--hts-pill-bg)':'transparent';
		b.style.boxShadow=active?'var(--hts-pill-shadow)':'none';
		b.style.color=active?'var(--hts-text)':'rgba(60,60,67,.45)';
		b.style.fontWeight=active?'600':'500';
		var badge=b.querySelector('span');
		if(badge)badge.style.background=active?'var(--hts-geo)':'var(--hts-text-3)';
	});
}

/* ═══ Card click: 0 rédigés → Rédaction; sinon → Graph overlay ═══ */
/* ═══ S4: Card click → direct graph (htsCardClick removed) ═══ */

/* ═══ DETAIL VIEW — Graph SVG rendering ═══ */
var _graphData=null,_graphSel=null,_graphCluster='',_graphClusterMeta={},_graphXhr=null,_graphAutoRetried=false;
function _ring(val,sz,sw){
	var r=(sz-sw)/2,c=Math.PI*2*r,off=c*(1-val/100),col=val>=75?'var(--hts-success)':val>=50?'var(--hts-caution)':'var(--hts-danger)';
	return '<svg width="'+sz+'" height="'+sz+'" style="transform:rotate(-90deg);flex-shrink:0"><circle cx="'+(sz/2)+'" cy="'+(sz/2)+'" r="'+r+'" fill="none" stroke="var(--hts-border-sub)" stroke-width="'+sw+'"/><circle cx="'+(sz/2)+'" cy="'+(sz/2)+'" r="'+r+'" fill="none" stroke="'+col+'" stroke-width="'+sw+'" stroke-linecap="round" stroke-dasharray="'+c.toFixed(1)+'" stroke-dashoffset="'+off.toFixed(1)+'"/><text x="'+(sz/2)+'" y="'+(sz/2)+'" text-anchor="middle" dominant-baseline="central" style="transform:rotate(90deg);transform-origin:center;font-size:'+(sz*.3)+'px;font-weight:800;fill:var(--hts-text);font-family:var(--hts-font)">'+val+'</text></svg>';
}
function htsCCOpenGraph(clusterName,clusterLabel,pageCount,density,orphans,links,position,coconId,pillarUrl){
	_graphCluster=clusterName;_graphSel=null;
	_graphClusterMeta={name:clusterLabel||clusterName,pages:pageCount,density:density||0,orphans:orphans||0,links:links||0,position:position||0,coconId:coconId||'',pillarUrl:pillarUrl||''};
	var view=document.getElementById('hts-graph-view');
	view.style.display='flex';
	document.getElementById('hts-graph-title').textContent=clusterLabel||clusterName;
	document.getElementById('hts-graph-sub').textContent=clusterName+' \u00b7 '+pageCount+' articles';
	// Badges
	var badges=document.getElementById('hts-graph-badges');
	badges.innerHTML='<span style="padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;background:var(--hts-accent-bg);color:var(--hts-accent)">'+pageCount+' en ligne</span>';
	if(orphans>0)badges.innerHTML+='<span onclick="htsHighlightOrphans()" style="padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;background:var(--hts-danger-bg);color:var(--hts-danger);cursor:pointer">'+orphans+' sans lien</span>';
	// FAB info — text only (no ring)
	document.getElementById('hts-fab-info').innerHTML='<span style="font-size:11px;color:rgba(255,255,255,.5);font-weight:500"><span style="color:rgba(255,255,255,.7);font-weight:600">'+pageCount+'</span> <span style="margin:0 5px;opacity:.3">\u00b7</span> <span style="color:'+(density<15?'var(--hts-danger)':'rgba(255,255,255,.45)')+'">'+density+'%</span>'+(orphans>0?'<span style="margin:0 5px;opacity:.3">\u00b7</span><span style="color:var(--hts-danger)">'+orphans+' sans lien</span>':'')+'</span>';
	// Load graph + show sidebar with cluster overview
	document.getElementById('hts-graph-links').innerHTML='';
	document.getElementById('hts-graph-nodes').innerHTML='';
	document.getElementById('hts-graph-sidebar').style.display='flex';
	/* S6 fix: htsCCGraphAction replaces sidebar.innerHTML, destroying #hts-sidebar-body.
	   Restore it before calling htsCCSelectNode which needs it. */
	if(!document.getElementById('hts-sidebar-body')){
		document.getElementById('hts-graph-sidebar').innerHTML='<div id="hts-sidebar-body" style="padding:20px;flex:1"></div>';
	}
	htsCCSelectNode(null); // show cluster overview in sidebar
	// Show loading state
	var emptyEl=document.getElementById('hts-graph-empty');
	emptyEl.textContent='Chargement du graphe...';emptyEl.style.display='flex';
	if(_graphXhr){try{_graphXhr.abort()}catch(e){}_graphXhr=null;}
	// [HTS Graph] AJAX hts_cocon_graph_data — filter:', clusterName, '| label:', clusterLabel);
	_graphXhr=jQuery.post('<?php echo esc_js($ajax_url); ?>',{action:'hts_cocon_graph_data',nonce:'<?php echo esc_js($nonce); ?>',cluster:clusterName},function(r){
		_graphXhr=null;
		var nodesCt=r.data&&r.data.nodes?r.data.nodes.length:0;
		var avail=r.data&&r.data.clusters?r.data.clusters:[];
		// [HTS Graph] Response:', r.success?'OK':'FAIL', 'nodes:', nodesCt, 'clusters dispo:', avail);

		if(!r.success||!r.data||!r.data.nodes||!nodesCt){
			// [HTS Graph warn] Empty. Filter "'+clusterName+'" matched 0 nodes. Available:', avail);
			// ── Auto-retry: fuzzy match sur clusters disponibles ──
			if(avail.length>0&&clusterName&&!_graphAutoRetried){
				var fuzzy=null,cn=clusterName.toLowerCase();
				for(var i=0;i<avail.length;i++){
					var an=avail[i].toLowerCase();
					if(an===cn)continue; // exact match already tried
					if(an.indexOf(cn)!==-1||cn.indexOf(an)!==-1){fuzzy=avail[i];break}
				}
				if(fuzzy){
					// [HTS Graph] Auto-retry fuzzy:', fuzzy);
					_graphAutoRetried=true;
					htsCCOpenGraph(fuzzy,clusterLabel,pageCount,density,orphans,links,position,coconId,pillarUrl);
					return;
				}
			}
			_graphAutoRetried=false;
			// ── Diagnostic UI ──
			var _em='<div style="text-align:center;max-width:380px">';
			_em+='<div style="font-size:14px;color:rgba(255,255,255,.4);margin-bottom:8px">Aucune donn\u00e9e de graphe pour</div>';
			_em+='<div style="font-size:15px;font-weight:700;color:rgba(255,255,255,.6);margin-bottom:4px">\u00ab '+esc(clusterName)+' \u00bb</div>';
			if(clusterLabel&&clusterLabel!==clusterName)_em+='<div style="font-size:10px;color:rgba(255,255,255,.2);margin-bottom:12px">(plan : '+esc(clusterLabel)+')</div>';
			if(avail.length>0){
				_em+='<div style="font-size:11px;color:rgba(255,255,255,.3);margin-bottom:8px">Clusters disponibles \u2014 cliquez pour essayer :</div>';
				_em+='<div style="display:flex;flex-wrap:wrap;gap:4px;justify-content:center;margin-bottom:16px">';
				avail.forEach(function(c){
					_em+='<button onclick="_graphAutoRetried=false;htsCCOpenGraph(\u0027'+c.replace(/\u0027/g,'\\\u0027')+'\u0027,\u0027'+c.replace(/\u0027/g,'\\\u0027')+'\u0027,0,0,0,0,0,\u0027'+(_graphClusterMeta.coconId||'')+'\u0027,\u0027'+(_graphClusterMeta.pillarUrl||'').replace(/\u0027/g,'\\\u0027')+'\u0027)" style="padding:5px 12px;border-radius:16px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:rgba(255,255,255,.55);font-size:11px;cursor:pointer;font-family:var(--hts-font);transition:background .15s" onmouseover="this.style.background=\u0027rgba(255,255,255,.12)\u0027" onmouseout="this.style.background=\u0027rgba(255,255,255,.06)\u0027">'+esc(c)+'</button>';
				});
				_em+='</div>';
			}else{
				_em+='<div style="font-size:11px;color:rgba(255,255,255,.25);line-height:1.5;margin-bottom:16px">Aucun cluster NLP d\u00e9tect\u00e9.<br>Lancez \u00ab Lancer l\u0027analyse \u00bb en haut de page.</div>';
			}
			if(_graphClusterMeta.coconId)_em+='<button onclick="htsCCResetCocon()" style="padding:10px 20px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:inline-flex;align-items:center;gap:6px">R\u00e9initialiser ce cocon</button>';
			_em+='</div>';
			emptyEl.innerHTML=_em;emptyEl.style.display='flex';return;
		}

		_graphAutoRetried=false;
		// [HTS Graph] Rendering', nodesCt, 'nodes,', r.data.links.length, 'links');
		emptyEl.style.display='none';
		_graphData=r.data;
		var orphanCount=0,totalIn=0,totalOut=0,totalScore=0;
		r.data.nodes.forEach(function(n){if(n.orphan)orphanCount++;totalIn+=n.in;totalOut+=n.out;totalScore+=n.score});
		var density=r.data.nodes.length>0?Math.round(r.data.links.length/(r.data.nodes.length*(r.data.nodes.length-1)/2||1)*100):0;
		_graphClusterMeta.pages=r.data.nodes.length;_graphClusterMeta.orphans=orphanCount;_graphClusterMeta.links=r.data.links.length;_graphClusterMeta.density=density;
		// S14: store GSC cluster aggregates for sidebar overview
		if(r.data.gsc){_graphClusterMeta.gsc=r.data.gsc;_graphClusterMeta.position=r.data.gsc.avg_position||0;}
		document.getElementById('hts-fab-info').innerHTML='<span style="font-size:11px;color:rgba(255,255,255,.5);font-weight:500"><span style="color:rgba(255,255,255,.7);font-weight:600">'+r.data.nodes.length+'</span> <span style="margin:0 5px;opacity:.3">\u00b7</span> <span style="color:'+(density<15?'var(--hts-danger)':'rgba(255,255,255,.45)')+'">'+density+'%</span>'+(orphanCount>0?'<span style="margin:0 5px;opacity:.3">\u00b7</span><span style="color:var(--hts-danger)">'+orphanCount+' orph.</span>':'')+'</span>';
		badges.innerHTML='<span style="padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;background:var(--hts-accent-bg);color:var(--hts-accent)">'+r.data.nodes.length+' pages</span>';
		if(orphanCount>0)badges.innerHTML+='<span style="padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;background:var(--hts-danger-bg);color:var(--hts-danger)">'+orphanCount+' sans lien</span>';
		htsCCRenderGraph(r.data);
		htsCCSelectNode(null);
		/* ── Auto-open staging panel if plan has to_generate articles ── */
		if(coconId&&window._htsPlanArticles&&window._htsPlanArticles[coconId]){
			var todoArts=window._htsPlanArticles[coconId];
			if(todoArts.length>0){
				htsCCStagingShowTodo(coconId,todoArts);
			}
		}
		/* S7: Load proposed links from Inbox for this cluster (async) */
		htsCCLoadInboxProposals();
	}).fail(function(jqXHR,textStatus){
		_graphXhr=null;_graphAutoRetried=false;
		if(textStatus==='abort')return;
		// [HTS Graph error] AJAX fail:', textStatus, jqXHR.status);
		emptyEl.textContent='Erreur de chargement du graphe ('+textStatus+')';emptyEl.style.display='flex';
		_toast('Impossible de charger les donn\u00e9es du graphe');
	});
}
function htsCCCloseGraph(){
	document.getElementById('hts-graph-view').style.display='none';
	document.getElementById('hts-graph-staging').style.display='none';
	if(_graphXhr){try{_graphXhr.abort()}catch(e){}_graphXhr=null;}
	_graphData=null;_graphSel=null;_graphClusterMeta={};
	document.getElementById('hts-graph-links').innerHTML='';
	document.getElementById('hts-graph-nodes').innerHTML='';
	document.getElementById('hts-graph-empty').style.display='none';
	var svg=document.getElementById('hts-graph-svg');if(svg)svg.onclick=null;
	/* S7: reset proposed links UI */
	var toggleEl=document.getElementById('hts-graph-link-toggle');if(toggleEl)toggleEl.style.display='none';
	var legendP=document.getElementById('hts-legend-proposed');if(legendP)legendP.style.display='none';
	var artBand=document.getElementById('hts-graph-articles-band');if(artBand)artBand.style.display='none';
	_graphLinkMode='real';
}
function htsHighlightOrphans(){
	if(!_graphData||!_graphData.nodes)return;
	htsCCSelectNode(null); // reset first
	document.querySelectorAll('#hts-graph-nodes g').forEach(function(g){
		var nid=parseInt(g.dataset.nodeId);
		var node=_graphData.nodes.find(function(n){return n.id===nid});
		var isOrphan=node&&node.orphan;
		g.style.opacity=isOrphan?'1':'0.15';
		var glow=g.querySelector('[data-role="glow"]');
		if(glow)glow.setAttribute('opacity',isOrphan?'0.4':'0.02');
	});
	document.querySelectorAll('#hts-graph-links line').forEach(function(l){
		if(l.dataset.proposed==='1'){l.setAttribute('opacity','0.1')}
		else{l.setAttribute('stroke','rgba(99,102,241,.35)');l.setAttribute('stroke-width','2')}
	});
	htsCCSidebarToggle(false);
}
document.getElementById('hts-graph-back').addEventListener('click',htsCCCloseGraph);

var _graphLinkMode='real'; /* real | proposed | all */
function htsCCToggleLinks(mode){
	_graphLinkMode=mode;
	/* Update toggle buttons */
	document.querySelectorAll('.hts-link-toggle-btn').forEach(function(btn){
		var isActive=btn.dataset.mode===mode;
		btn.style.background=isActive?'var(--hts-bg)':'transparent';
		btn.style.color=isActive?'var(--hts-text)':'var(--hts-text-3)';
		btn.style.boxShadow=isActive?'0 1px 2px rgba(0,0,0,.06)':'none';
	});
	/* Toggle link visibility */
	document.querySelectorAll('#hts-graph-links line').forEach(function(l){
		var isProposed=l.dataset.proposed==='1';
		if(mode==='real')l.style.display=isProposed?'none':'inline';
		else if(mode==='proposed')l.style.display=isProposed?'inline':'none';
		else l.style.display='inline';
	});
}

/* ── S7: Load proposed links from Inbox (workflow_actions) for current cluster ── */
function htsCCLoadInboxProposals(switchToProposed){
	if(typeof window._htsPostFn!=='function')return;
	if(!_graphData||!_graphData.nodes)return;
	window._htsPostFn('hts_inbox_list',{}).then(function(ir){
		if(!ir.success||!ir.data||!ir.data.cards)return;
		var clName=_graphCluster||_graphClusterMeta.name||'';
		var clLow=clName?clName.toLowerCase().trim():'';
		if(!clLow){/* No cluster name */return;}
		var proposed=[];
		var cards=ir.data.cards;
		for(var k in cards){
			if(!cards.hasOwnProperty(k))continue;
			var card=cards[k];
			if(card.agent!=='linking'||card.type!=='add_internal_links')continue;
			(card.actions||[]).forEach(function(act){
				var actData={};
				try{actData=typeof act.data==='string'?JSON.parse(act.data):(act.data||{})}catch(e){actData={}}
				var actCluster=(actData.cluster||'').toLowerCase().trim();
				if(!actCluster)return;
				if(actCluster!==clLow&&actCluster.indexOf(clLow)===-1&&clLow.indexOf(actCluster)===-1)return;
				var srcId=parseInt(act.post_id)||0;
				var tgtId=parseInt(actData.target_id)||0;
				if(srcId&&tgtId)proposed.push({source:srcId,target:tgtId,anchor:actData.anchor_text||'',action_id:parseInt(act.id)||0});
			});
		}
		if(proposed.length>0){
			if(!window._htsProposedLinks)window._htsProposedLinks={};
			window._htsProposedLinks[_graphCluster||'']=proposed;
			htsCCRenderProposedLinks();
			if(switchToProposed)htsCCToggleLinks('proposed');
			// [HTS Graph] Inbox proposed links:',proposed.length,'for cluster:',clName);
		}else{
			// [HTS Graph] No inbox proposals for cluster:',clName);
		}
	}).catch(function(e){/* Inbox list failed */});
}

/* ── Add proposed links to existing graph (no full re-render) ── */
function htsCCRenderProposedLinks(){
	if(!_graphData||!_graphData.nodes)return;
	var clName=_graphCluster||'';
	var proposed=window._htsProposedLinks&&window._htsProposedLinks[clName]?window._htsProposedLinks[clName]:[];
	if(!proposed.length)return;
	var nodes=_graphData.nodes;
	var linksG=document.getElementById('hts-graph-links');
	if(!linksG)return;
	/* Remove old proposed lines first */
	linksG.querySelectorAll('line[data-proposed="1"]').forEach(function(l){l.remove()});
	/* Draw new proposed links */
	proposed.forEach(function(pl){
		var src=nodes.find(function(n){return n.id===pl.source});
		var tgt=nodes.find(function(n){return n.id===pl.target});
		if(!src||!tgt||!src._x||!tgt._x)return;
		var rS=src.role==='pilier'?36:26,rT=tgt.role==='pilier'?36:26;
		var dx=tgt._x-src._x,dy=tgt._y-src._y,dist=Math.sqrt(dx*dx+dy*dy)||1;
		var line=document.createElementNS('http://www.w3.org/2000/svg','line');
		line.setAttribute('x1',src._x+(dx/dist)*rS);line.setAttribute('y1',src._y+(dy/dist)*rS);
		line.setAttribute('x2',tgt._x-(dx/dist)*rT);line.setAttribute('y2',tgt._y-(dy/dist)*rT);
		line.setAttribute('stroke','var(--hts-geo)');line.setAttribute('stroke-width','1.5');
		line.setAttribute('stroke-dasharray','6,4');line.setAttribute('opacity','0.5');
		line.setAttribute('marker-end','url(#hts-arrow-proposed)');
		line.dataset.src=pl.source;line.dataset.tgt=pl.target;line.dataset.proposed='1';
		if(pl.anchor)line.dataset.anchor=pl.anchor;
		if(pl.action_id)line.dataset.actionId=pl.action_id;
		line.style.cursor='pointer';
		line.addEventListener('mouseenter',function(){this.setAttribute('stroke-width','3');this.setAttribute('opacity','0.8')});
		line.addEventListener('mouseleave',function(){this.setAttribute('stroke-width','1.5');this.setAttribute('opacity','0.5')});
		line.addEventListener('click',function(e){e.stopPropagation();htsCCShowProposedLink(parseInt(this.dataset.src),parseInt(this.dataset.tgt),this.dataset.anchor||'',parseInt(this.dataset.actionId)||0)});
		linksG.appendChild(line);
	});
	/* Show toggle + legend but keep current link mode */
	var toggleEl=document.getElementById('hts-graph-link-toggle');
	if(toggleEl)toggleEl.style.display='flex';
	var legendProposed=document.getElementById('hts-legend-proposed');
	if(legendProposed)legendProposed.style.display='flex';
	/* Apply current mode (real by default, all/proposed if user changed it) */
	htsCCToggleLinks(_graphLinkMode);
}

/* ── S7: Proposed link click → sidebar detail with Apply/Reject ── */
function htsCCShowProposedLink(srcId,tgtId,anchor,actionId){
	if(!_graphData||!_graphData.nodes)return;
	var src=_graphData.nodes.find(function(n){return n.id===srcId});
	var tgt=_graphData.nodes.find(function(n){return n.id===tgtId});
	if(!src||!tgt)return;
	var sidebar=document.getElementById('hts-graph-sidebar');
	var body=document.getElementById('hts-sidebar-body');
	if(!body){sidebar.innerHTML='<div id="hts-sidebar-body" style="padding:20px;flex:1"></div>';body=document.getElementById('hts-sidebar-body');}
	sidebar.style.display='flex';
	/* Highlight this specific link */
	document.querySelectorAll('#hts-graph-links line[data-proposed="1"]').forEach(function(l){
		var isCur=(parseInt(l.dataset.src)===srcId&&parseInt(l.dataset.tgt)===tgtId);
		l.setAttribute('stroke',isCur?'var(--hts-accent)':'var(--hts-geo)');
		l.setAttribute('stroke-width',isCur?'3':'1.5');
		l.setAttribute('opacity',isCur?'1':'0.3');
	});
	var h='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><div style="font-size:12px;color:var(--hts-accent);cursor:pointer;display:flex;align-items:center;gap:5px;font-weight:600" onclick="htsCCSelectNode(null)">\u2190 Retour au groupe</div><button onclick="htsCCSidebarToggle(false)" style="width:28px;height:28px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--hts-text-3)">\u00d7</button></div>';
	h+='<div style="padding:12px 14px;background:var(--hts-geo-soft);border:1px solid var(--hts-geo-border);border-radius:12px;margin-bottom:16px">';
	h+='<div style="font-size:10px;font-weight:700;color:var(--hts-geo);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Lien propos\u00e9</div>';
	h+='<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><div style="width:8px;height:8px;border-radius:50%;background:var(--hts-geo);flex-shrink:0"></div><div style="font-size:12px;font-weight:600;color:var(--hts-text);line-height:1.3">'+esc(src.title)+'</div></div>';
	h+='<div style="padding-left:3px;margin:-2px 0 8px;font-size:16px;color:var(--hts-geo)">\u2193</div>';
	h+='<div style="display:flex;align-items:center;gap:8px"><div style="width:8px;height:8px;border-radius:50%;background:var(--hts-accent);flex-shrink:0"></div><div style="font-size:12px;font-weight:600;color:var(--hts-text);line-height:1.3">'+esc(tgt.title)+'</div></div>';
	h+='</div>';
	if(anchor){
		h+='<div style="padding:10px 14px;background:var(--hts-surface);border-radius:8px;margin-bottom:16px">';
		h+='<div style="font-size:10px;font-weight:600;color:var(--hts-text-3);margin-bottom:4px">Ancre</div>';
		h+='<div style="font-size:13px;color:var(--hts-text);font-style:italic">\u201c'+esc(anchor)+'\u201d</div>';
		h+='</div>';
	}
	/* KPIs */
	h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:16px">';
	h+='<div style="text-align:center;padding:8px 4px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:14px;font-weight:700;color:var(--hts-text)">'+(src.score||0)+'</div><div style="font-size:10px;color:var(--hts-text-3)">Score source</div></div>';
	h+='<div style="text-align:center;padding:8px 4px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:14px;font-weight:700;color:var(--hts-text)">'+(tgt.score||0)+'</div><div style="font-size:10px;color:var(--hts-text-3)">Score cible</div></div>';
	h+='</div>';
	/* Action buttons */
	h+='<div style="display:flex;flex-direction:column;gap:8px;margin-top:12px">';
	if(htsCanApply){
		h+='<button id="hts-pl-apply-btn" onclick="htsCCProposedAction(\'apply\','+srcId+','+tgtId+','+(actionId||0)+')" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-success);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Appliquer ce lien</button>';
		h+='<button id="hts-pl-reject-btn" onclick="htsCCProposedAction(\'dismiss\','+srcId+','+tgtId+','+(actionId||0)+')" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-danger);background:var(--hts-danger-bg);font-size:12px;font-weight:600;color:var(--hts-danger);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Rejeter</button>';
	}else{
		h+='<div style="padding:12px;background:var(--hts-surface);border-radius:8px;font-size:12px;color:var(--hts-text-3);line-height:1.5;text-align:center">Ajoutez ce lien manuellement dans l\u0027\u00e9diteur WordPress.<br>Avec <strong>Ultra</strong>, les liens sont cr\u00e9\u00e9s automatiquement.</div>';
		h+='<a href="https://hacktheseo.com/pricing" target="_blank" style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:10px;border-radius:var(--hts-radius-sm);background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:12px;font-weight:600;text-decoration:none;box-sizing:border-box">Passer \u00e0 Ultra \u2014 249\u20ac/mois</a>';
	}
	h+='</div>';
	body.innerHTML=h;
}
function htsCCProposedAction(action,srcId,tgtId,actionId){
	var btnApply=document.getElementById('hts-pl-apply-btn');
	var btnReject=document.getElementById('hts-pl-reject-btn');
	if(btnApply)btnApply.disabled=true;
	if(btnReject)btnReject.disabled=true;
	if(action==='apply'&&btnApply)btnApply.textContent='Application\u2026';
	if(action==='dismiss'&&btnReject)btnReject.textContent='Rejet\u2026';
	if(typeof window._htsPostFn!=='function'){_toast('AJAX non disponible');return}
	/* Use Workflow Engine inbox endpoints with action_id */
	var ajaxAction=action==='apply'?'hts_inbox_approve':'hts_inbox_dismiss';
	var postData={action_id:actionId};
	/* Fallback: if no action_id, try legacy cross-cocon */
	if(!actionId){ajaxAction='hts_cross_cocon_action';postData={post_id:srcId,target_id:tgtId,action:action}}
	window._htsPostFn(ajaxAction,postData).then(function(r){
		if(r.success){
			_toast(action==='apply'?'Lien appliqu\u00e9':'Lien rejet\u00e9','success');
			/* Update SVG: applied → solid white, dismissed → remove */
			document.querySelectorAll('#hts-graph-links line[data-proposed="1"]').forEach(function(l){
				if(parseInt(l.dataset.src)===srcId&&parseInt(l.dataset.tgt)===tgtId){
					if(action==='apply'){
						l.setAttribute('stroke','rgba(255,255,255,.6)');l.setAttribute('stroke-width','2');
						l.removeAttribute('stroke-dasharray');l.setAttribute('opacity','1');
						l.dataset.proposed='0';
					}else{
						l.remove();
					}
				}
			});
			htsCCSelectNode(null);
		}else{
			_toast(r.data||'Erreur','error');
			if(btnApply)btnApply.disabled=false;
			if(btnReject)btnReject.disabled=false;
			if(action==='apply'&&btnApply)btnApply.textContent='Appliquer ce lien';
			if(action==='dismiss'&&btnReject)btnReject.textContent='Rejeter';
		}
	}).catch(function(){
		_toast('Erreur r\u00e9seau');
		if(btnApply){btnApply.disabled=false;btnApply.textContent='Appliquer ce lien'}
		if(btnReject){btnReject.disabled=false;btnReject.textContent='Rejeter'}
	});
}

function htsCCRenderGraph(data){
	var svg=document.getElementById('hts-graph-svg');
	var W=820,H=560;
	var nodes=data.nodes,links=data.links||[];
	var pillar=null,children=[];
	nodes.forEach(function(n){if(n.role==='pilier')pillar=n;else children.push(n)});
	if(!pillar&&nodes.length>0)pillar=nodes[0];
	var cx=W/2,cy=H/2;

	// ── Elliptical layout: fills the viewBox like maquette JSX ──
	// Maquette uses x:200-680, y:80-450 in 820x560 = ~60% of space
	if(pillar){pillar._x=cx;pillar._y=cy;}
	var ct=children.length;
	if(ct>0){
		var rx=W*0.34,ry=H*0.37; // elliptical radii to fill viewBox
		var pad=50;
		if(ct<=8){
			// Single ring
			children.forEach(function(n,i){
				var angle=-Math.PI/2+(2*Math.PI*i/ct);
				n._x=cx+Math.cos(angle)*rx;
				n._y=cy+Math.sin(angle)*ry;
			});
		}else if(ct<=16){
			// Two rings: inner ~55%, outer 100%
			var inner=Math.min(6,Math.ceil(ct*0.4));
			var outer=ct-inner;
			for(var i=0;i<inner;i++){
				var angle=-Math.PI/2+(2*Math.PI*i/inner)+(Math.PI/inner);
				children[i]._x=cx+Math.cos(angle)*rx*0.52;
				children[i]._y=cy+Math.sin(angle)*ry*0.52;
			}
			for(var i=0;i<outer;i++){
				var angle=-Math.PI/2+(2*Math.PI*i/outer);
				children[inner+i]._x=cx+Math.cos(angle)*rx;
				children[inner+i]._y=cy+Math.sin(angle)*ry;
			}
		}else{
			// Three rings for 20+ nodes
			var r1ct=Math.min(5,Math.ceil(ct*0.2));
			var r2ct=Math.min(10,Math.ceil(ct*0.4));
			var r3ct=ct-r1ct-r2ct;
			for(var i=0;i<r1ct;i++){
				var angle=-Math.PI/2+(2*Math.PI*i/r1ct)+(Math.PI/r1ct);
				children[i]._x=cx+Math.cos(angle)*rx*0.35;
				children[i]._y=cy+Math.sin(angle)*ry*0.35;
			}
			for(var i=0;i<r2ct;i++){
				var angle=-Math.PI/2+(2*Math.PI*i/r2ct);
				children[r1ct+i]._x=cx+Math.cos(angle)*rx*0.68;
				children[r1ct+i]._y=cy+Math.sin(angle)*ry*0.68;
			}
			for(var i=0;i<r3ct;i++){
				var angle=-Math.PI/2+(2*Math.PI*i/r3ct)+(Math.PI/r3ct*0.5);
				children[r1ct+r2ct+i]._x=cx+Math.cos(angle)*rx;
				children[r1ct+r2ct+i]._y=cy+Math.sin(angle)*ry;
			}
		}
		// Overlap avoidance (minimum 70px = 2 nodes + label gap)
		var minDist=70;
		for(var pass=0;pass<50;pass++){
			var moved=false;
			for(var i=0;i<children.length;i++){
				for(var j=i+1;j<children.length;j++){
					var dx=children[j]._x-children[i]._x;
					var dy=children[j]._y-children[i]._y;
					var d=Math.sqrt(dx*dx+dy*dy)||0.1;
					if(d<minDist){
						var push=(minDist-d)/2+1;
						var px=dx/d*push,py=dy/d*push;
						children[i]._x-=px;children[i]._y-=py;
						children[j]._x+=px;children[j]._y+=py;
						moved=true;
					}
				}
				// Also avoid pillar
				if(pillar){
					var dx=children[i]._x-pillar._x;
					var dy=children[i]._y-pillar._y;
					var d=Math.sqrt(dx*dx+dy*dy)||0.1;
					var minPillar=85; // pillar is bigger
					if(d<minPillar){
						var push=minPillar-d+1;
						children[i]._x+=dx/d*push;
						children[i]._y+=dy/d*push;
						moved=true;
					}
				}
			}
			children.forEach(function(n){
				n._x=Math.max(pad,Math.min(W-pad,n._x));
				n._y=Math.max(pad,Math.min(H-pad,n._y));
			});
			if(!moved)break;
		}
	}

	// ── Render links (very subtle like maquette) ──
	var linksG=document.getElementById('hts-graph-links');linksG.innerHTML='';
	links.forEach(function(l){
		var src=nodes.find(function(n){return n.id===l.source});
		var tgt=nodes.find(function(n){return n.id===l.target});
		if(!src||!tgt||!src._x||!tgt._x)return;
		var rS=src.role==='pilier'?36:26,rT=tgt.role==='pilier'?36:26;
		var dx=tgt._x-src._x,dy=tgt._y-src._y,dist=Math.sqrt(dx*dx+dy*dy)||1;
		var line=document.createElementNS('http://www.w3.org/2000/svg','line');
		line.setAttribute('x1',src._x+(dx/dist)*rS);line.setAttribute('y1',src._y+(dy/dist)*rS);
		line.setAttribute('x2',tgt._x-(dx/dist)*rT);line.setAttribute('y2',tgt._y-(dy/dist)*rT);
		line.setAttribute('stroke','rgba(99,102,241,.5)');line.setAttribute('stroke-width','2.5');
		line.setAttribute('marker-end','url(#hts-arrow)');
		line.dataset.src=l.source;line.dataset.tgt=l.target;
		linksG.appendChild(line);
	});
	/* ── Proposed links from Inbox (dashed, purple) ── */
	var clName=_graphCluster||'';
	var proposed=window._htsProposedLinks&&window._htsProposedLinks[clName]?window._htsProposedLinks[clName]:[];
	proposed.forEach(function(pl){
		var src=nodes.find(function(n){return n.id===pl.source});
		var tgt=nodes.find(function(n){return n.id===pl.target});
		if(!src||!tgt||!src._x||!tgt._x)return;
		var rS=src.role==='pilier'?36:26,rT=tgt.role==='pilier'?36:26;
		var dx=tgt._x-src._x,dy=tgt._y-src._y,dist=Math.sqrt(dx*dx+dy*dy)||1;
		var line=document.createElementNS('http://www.w3.org/2000/svg','line');
		line.setAttribute('x1',src._x+(dx/dist)*rS);line.setAttribute('y1',src._y+(dy/dist)*rS);
		line.setAttribute('x2',tgt._x-(dx/dist)*rT);line.setAttribute('y2',tgt._y-(dy/dist)*rT);
		line.setAttribute('stroke','var(--hts-geo)');line.setAttribute('stroke-width','1');
		line.setAttribute('stroke-dasharray','6,4');line.setAttribute('opacity','0.4');
		line.setAttribute('marker-end','url(#hts-arrow-proposed)');
		line.dataset.src=pl.source;line.dataset.tgt=pl.target;line.dataset.proposed='1';
		if(pl.anchor)line.dataset.anchor=pl.anchor;
		if(pl.action_id)line.dataset.actionId=pl.action_id;
		line.style.cursor='pointer';
		line.addEventListener('mouseenter',function(){this.setAttribute('stroke-width','2.5');this.setAttribute('opacity','0.7')});
		line.addEventListener('mouseleave',function(){this.setAttribute('stroke-width','1');this.setAttribute('opacity','0.4')});
		line.addEventListener('click',function(e){e.stopPropagation();htsCCShowProposedLink(parseInt(this.dataset.src),parseInt(this.dataset.tgt),this.dataset.anchor||'',parseInt(this.dataset.actionId)||0)});
		linksG.appendChild(line);
	});
	/* Show/hide toggle based on whether there are proposed links */
	var toggleEl=document.getElementById('hts-graph-link-toggle');
	if(toggleEl)toggleEl.style.display=proposed.length>0?'flex':'none';
	/* Apply current link mode */
	if(proposed.length>0)htsCCToggleLinks(_graphLinkMode);
	// Render nodes
	var nodesG=document.getElementById('hts-graph-nodes');nodesG.innerHTML='';
	nodes.forEach(function(n){
		if(!n._x)return;
		var isPlanned=(n.status==='planned');
		var isDraft=n.is_draft||false;
		var col=(isPlanned||isDraft)?'var(--hts-geo)':n.score>=75?'var(--hts-success)':n.score>=50?'var(--hts-caution)':'var(--hts-danger)';
		var r=n.role==='pilier'?32:22;
		var g=document.createElementNS('http://www.w3.org/2000/svg','g');
		g.style.cursor='pointer';g.dataset.nodeId=n.id;g.dataset.nodeCol=col;g.dataset.nodeR=r;
		// Glow circle
		var glow=document.createElementNS('http://www.w3.org/2000/svg','circle');
		glow.setAttribute('cx',n._x);glow.setAttribute('cy',n._y);glow.setAttribute('r',r+6);
		glow.setAttribute('fill',col);glow.setAttribute('opacity','0.06');glow.setAttribute('data-role','glow');g.appendChild(glow);
		// Selection ring (hidden by default, shown on select — JSX dashed circle r+3)
		var selRing=document.createElementNS('http://www.w3.org/2000/svg','circle');
		selRing.setAttribute('cx',n._x);selRing.setAttribute('cy',n._y);selRing.setAttribute('r',r+3);
		selRing.setAttribute('fill','none');selRing.setAttribute('stroke',col);selRing.setAttribute('stroke-width','1');
		selRing.setAttribute('stroke-dasharray','3,3');selRing.setAttribute('opacity','0');selRing.setAttribute('data-role','sel-ring');g.appendChild(selRing);
		// Main circle
		var circle=document.createElementNS('http://www.w3.org/2000/svg','circle');
		circle.setAttribute('cx',n._x);circle.setAttribute('cy',n._y);circle.setAttribute('r',r);
		circle.setAttribute('fill','#1E1E24');circle.setAttribute('stroke',col);
		circle.setAttribute('stroke-width',(isPlanned||isDraft)?'1.5':'2.5');
		if(isPlanned||isDraft)circle.setAttribute('stroke-dasharray','5,4');
		circle.setAttribute('data-role','main');g.appendChild(circle);
		// Orphan indicator dot
		if(n.orphan){var dot=document.createElementNS('http://www.w3.org/2000/svg','circle');dot.setAttribute('cx',n._x+r-2);dot.setAttribute('cy',n._y-r+2);dot.setAttribute('r','4');dot.setAttribute('fill','var(--hts-danger)');g.appendChild(dot);}
		// Score text or "+" for planned nodes
		if(isPlanned){
			var plus=document.createElementNS('http://www.w3.org/2000/svg','text');plus.setAttribute('x',n._x);plus.setAttribute('y',n._y+5);plus.setAttribute('text-anchor','middle');plus.setAttribute('style','font-size:18px;fill:var(--hts-geo);font-family:var(--hts-font)');plus.textContent='+';g.appendChild(plus);
		}else if(n.score>0){
			var txt=document.createElementNS('http://www.w3.org/2000/svg','text');txt.setAttribute('x',n._x);txt.setAttribute('y',n._y+4);txt.setAttribute('text-anchor','middle');txt.setAttribute('style','font-size:'+(r>24?15:12)+'px;font-weight:800;fill:#fff;font-family:var(--hts-font)');txt.textContent=Math.round(n.score);g.appendChild(txt);
		}
		// Label below node
		var lblText=n.title.length>22?n.title.substring(0,20)+'\u2026':n.title;
		var lbl=document.createElementNS('http://www.w3.org/2000/svg','text');lbl.setAttribute('x',n._x);lbl.setAttribute('y',n._y+r+14);lbl.setAttribute('text-anchor','middle');lbl.setAttribute('style','font-size:9px;fill:rgba(255,255,255,'+(isDraft?'.25':'.35')+');font-family:var(--hts-font)');lbl.textContent=lblText;g.appendChild(lbl);
		if(isDraft){var lbl2=document.createElementNS('http://www.w3.org/2000/svg','text');lbl2.setAttribute('x',n._x);lbl2.setAttribute('y',n._y+r+25);lbl2.setAttribute('text-anchor','middle');lbl2.setAttribute('style','font-size:8px;fill:rgba(155,135,245,.5);font-style:italic;font-family:var(--hts-font)');lbl2.textContent='(brouillon)';g.appendChild(lbl2);}
		g.addEventListener('click',function(e){e.stopPropagation();htsCCSelectNode(n)});
		nodesG.appendChild(g);
	});
	// SVG background click — use onclick (not addEventListener) to avoid leak on re-render
	svg.onclick=function(){htsCCSelectNode(null);htsCCSidebarToggle(false);document.getElementById('hts-graph-staging').style.display='none';/* reset orphan highlight */document.querySelectorAll('#hts-graph-nodes g').forEach(function(g){g.style.opacity='1';var glow=g.querySelector('[data-role="glow"]');if(glow)glow.setAttribute('opacity','0.06')});document.querySelectorAll('#hts-graph-links line').forEach(function(l){if(l.dataset.proposed==='1'){l.setAttribute('stroke','var(--hts-geo)');l.setAttribute('stroke-width','1.5');l.setAttribute('opacity','0.5');l.setAttribute('marker-end','url(#hts-arrow-proposed)')}else{l.setAttribute('stroke','rgba(255,255,255,.08)');l.setAttribute('stroke-width','0.5');l.setAttribute('marker-end','url(#hts-arrow)')}});htsCCToggleLinks(_graphLinkMode)};
}
/* S7: Centralized sidebar + DETAILS band toggle */
function htsCCSidebarToggle(forceShow){
	var sb=document.getElementById('hts-graph-sidebar');
	var band=document.getElementById('hts-graph-details-band');
	if(!sb)return;
	var show=(forceShow!==undefined)?forceShow:(sb.style.display==='none'||sb.style.display==='');
	sb.style.display=show?'flex':'none';
	if(band)band.style.display=show?'none':'flex';
	if(show)htsCCSelectNode(null);
}
function htsCCSelectNode(node){
	_graphSel=node;
	if(_graphData){
		document.querySelectorAll('#hts-graph-links line').forEach(function(l){
			var isProposed=l.dataset.proposed==='1';
			var connected=node&&(parseInt(l.dataset.src)===node.id||parseInt(l.dataset.tgt)===node.id);
			if(node){
				if(isProposed){
					l.setAttribute('stroke',connected?'var(--hts-accent)':'var(--hts-geo)');
					l.setAttribute('stroke-width',connected?'2.5':'1.5');
					l.setAttribute('stroke-dasharray','6,4');
					l.setAttribute('opacity',connected?'0.8':'0.2');
					l.setAttribute('marker-end',connected?'url(#hts-arrow-sel)':'url(#hts-arrow-proposed)');
				}else{
					l.setAttribute('stroke',connected?'var(--hts-accent)':'rgba(255,255,255,.03)');
					l.setAttribute('stroke-width',connected?'2':'0.5');
					l.setAttribute('marker-end',connected?'url(#hts-arrow-sel)':'');
				}
			}else{
				if(isProposed){
					l.setAttribute('stroke','var(--hts-geo)');l.setAttribute('stroke-width','1.5');
					l.setAttribute('stroke-dasharray','6,4');l.setAttribute('opacity','0.5');
					l.setAttribute('marker-end','url(#hts-arrow-proposed)');
				}else{
					l.setAttribute('stroke','rgba(255,255,255,.08)');l.setAttribute('stroke-width','0.5');
					l.setAttribute('marker-end','url(#hts-arrow)');
				}
			}
		});
		// Build connected set for node dimming
		var connectedIds={};
		if(node&&_graphData&&_graphData.links){
			connectedIds[node.id]=true;
			_graphData.links.forEach(function(l){
				if(l.source===node.id)connectedIds[l.target]=true;
				if(l.target===node.id)connectedIds[l.source]=true;
			});
		}
		document.querySelectorAll('#hts-graph-nodes g').forEach(function(g){
			var nid=parseInt(g.dataset.nodeId);
			var isSel=node&&nid===node.id;
			var isConn=node?!!connectedIds[nid]:true;
			var col=g.dataset.nodeCol||'var(--hts-danger)';
			g.style.opacity=node?(isConn?'1':'0.25'):'1';
			var glow=g.querySelector('[data-role="glow"]');
			if(glow)glow.setAttribute('opacity',isSel?'0.35':'0.06');
			var selRing=g.querySelector('[data-role="sel-ring"]');
			if(selRing)selRing.setAttribute('opacity',isSel?'0.5':'0');
			var main=g.querySelector('[data-role="main"]');
			if(main){
				main.setAttribute('fill',isSel?col:'#1E1E24');
				main.setAttribute('fill-opacity',isSel?'0.12':'1');
			}
		});
	}
	var sidebar=document.getElementById('hts-graph-sidebar');
	var body=document.getElementById('hts-sidebar-body');
	/* S6 fix: restore #hts-sidebar-body if htsCCGraphAction destroyed it */
	if(!body){sidebar.innerHTML='<div id="hts-sidebar-body" style="padding:20px;flex:1"></div>';body=document.getElementById('hts-sidebar-body');}
	sidebar.style.display='flex';

	if(node){
		// ── NODE DETAIL (enriched like JSX) ──
		var isPlanned=(node.status==='planned');
		var h='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><div style="font-size:12px;color:var(--hts-accent);cursor:pointer;display:flex;align-items:center;gap:5px;font-weight:600" onclick="htsCCSelectNode(null)">\u2190 Retour au groupe</div><button onclick="htsCCSidebarToggle(false)" style="width:28px;height:28px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--hts-text-3)">\u00d7</button></div>';
		h+='<div style="font-size:15px;font-weight:700;color:var(--hts-text);line-height:1.3;margin-bottom:8px">'+esc(node.title)+'</div>';
		// Conditional badges (JSX: live/planned/pilier/orphan)
		h+='<div style="display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap">';
		if(isPlanned){
			h+='<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(99,102,241,.15);color:var(--hts-geo)">Planifi\u00e9</span>';
		}else{
			h+='<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(0,210,106,.15);color:var(--hts-success)">En ligne</span>';
		}
		if(node.role==='pilier')h+='<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(45,127,249,.15);color:var(--hts-accent)">Pilier</span>';
		if(node.orphan)h+='<span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(239,68,68,.15);color:var(--hts-danger)">Sans lien</span>';
		h+='</div>';

		if(isPlanned){
			// ── PLANNED NODE — simplified content (JSX L628-634) ──
			h+='<div style="text-align:center;padding:20px 0">';
			h+='<div style="font-size:13px;color:var(--hts-text-2);line-height:1.5;margin-bottom:16px">Cet article sera r\u00e9dig\u00e9 et publi\u00e9 selon votre calendrier.</div>';
			h+='<button onclick="_toast(\'Envoi en r\u00e9daction...\')" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">G\u00e9n\u00e9rer maintenant</button>';
			h+='</div>';
		}else{
			// ── LIVE NODE — full detail ──
			// Ring 64px
			h+='<div style="display:flex;justify-content:center;margin-bottom:16px">'+_ring(node.score||0,64,4.5)+'</div>';
			// 3 KPIs with safe defaults
			var nIn=node.in||0,nOut=node.out||0,nDepth=(node.click_depth!==undefined&&node.click_depth<999)?node.click_depth:'\u2014';
			h+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:16px">';
			h+='<div style="text-align:center;padding:8px 4px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:15px;font-weight:700;color:var(--hts-text)">'+nIn+'</div><div style="font-size:10px;color:var(--hts-text-3)">Entrants</div></div>';
			h+='<div style="text-align:center;padding:8px 4px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:15px;font-weight:700;color:var(--hts-text)">'+nOut+'</div><div style="font-size:10px;color:var(--hts-text-3)">Sortants</div></div>';
			h+='<div style="text-align:center;padding:8px 4px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:15px;font-weight:700;color:var(--hts-text)">'+nDepth+'</div><div style="font-size:10px;color:var(--hts-text-3)">Profondeur</div></div>';
			h+='</div>';
			// S14: GSC data per node (if available)
			if(node.gsc_clicks>0||node.gsc_impressions>0||node.gsc_position>0){
				h+='<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Google Search Console</div>';
				h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:16px">';
				h+='<div style="padding:8px 10px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:14px;font-weight:700;color:var(--hts-text)">'+(node.gsc_clicks||0)+'</div><div style="font-size:10px;color:var(--hts-text-3)">Clics 30j</div></div>';
				h+='<div style="padding:8px 10px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:14px;font-weight:700;color:var(--hts-text)">'+(node.gsc_impressions||0)+'</div><div style="font-size:10px;color:var(--hts-text-3)">Impressions</div></div>';
				var posCol=node.gsc_position>0&&node.gsc_position<=10?'var(--hts-success)':node.gsc_position<=20?'var(--hts-caution)':'var(--hts-text)';
				h+='<div style="padding:8px 10px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:14px;font-weight:700;color:'+posCol+'">'+(node.gsc_position||'\u2014')+'</div><div style="font-size:10px;color:var(--hts-text-3)">Position</div></div>';
				h+='<div style="padding:8px 10px;border-radius:6px;background:var(--hts-surface)"><div style="font-size:14px;font-weight:700;color:var(--hts-text)">'+(node.gsc_ctr>0?(node.gsc_ctr+'%'):'\u2014')+'</div><div style="font-size:10px;color:var(--hts-text-3)">CTR</div></div>';
				h+='</div>';
			}
			// Links detail section
			if(_graphData&&_graphData.links){
				var outLinks=_graphData.links.filter(function(l){return l.source===node.id});
				var inLinks=_graphData.links.filter(function(l){return l.target===node.id});
				h+='<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Liens internes</div>';
				// Outgoing
				h+='<div style="padding:10px 12px;border-radius:8px;background:var(--hts-surface);margin-bottom:6px">';
				h+='<div style="display:flex;justify-content:space-between;align-items:center"><div style="display:flex;align-items:center;gap:6px"><span style="font-size:12px;font-weight:500;color:var(--hts-text)">\u2197 Sortants</span></div><span style="font-size:13px;font-weight:700;color:var(--hts-text)">'+outLinks.length+'</span></div>';
				outLinks.slice(0,2).forEach(function(l){var tn=_graphData.nodes.find(function(n){return n.id===l.target});if(tn)h+='<div style="font-size:11px;color:var(--hts-text-3);margin-top:4px;padding-left:18px">\u2192 '+esc(tn.title)+'</div>'});
				if(outLinks.length>2){
					var _outId='hts-out-more-'+node.id;
					h+='<div id="'+_outId+'" style="display:none">';
					outLinks.slice(2).forEach(function(l){var tn=_graphData.nodes.find(function(n){return n.id===l.target});if(tn)h+='<div style="font-size:11px;color:var(--hts-text-3);margin-top:4px;padding-left:18px">\u2192 '+esc(tn.title)+'</div>'});
					h+='</div>';
					h+='<div style="font-size:11px;color:var(--hts-accent);margin-top:4px;padding-left:18px;cursor:pointer" onclick="var el=document.getElementById(\''+_outId+'\');if(el.style.display===\'none\'){el.style.display=\'block\';this.textContent=\'\u25b2 Masquer\'}else{el.style.display=\'none\';this.textContent=\'+'+( outLinks.length-2)+' autres\'}">+'+(outLinks.length-2)+' autres</div>';
				}
				h+='</div>';
				// Incoming
				h+='<div style="padding:10px 12px;border-radius:8px;background:var(--hts-surface)">';
				h+='<div style="display:flex;justify-content:space-between;align-items:center"><div style="display:flex;align-items:center;gap:6px"><span style="font-size:12px;font-weight:500;color:var(--hts-text)">\u2199 Entrants</span></div><span style="font-size:13px;font-weight:700;color:var(--hts-text)">'+inLinks.length+'</span></div>';
				inLinks.slice(0,2).forEach(function(l){var fn=_graphData.nodes.find(function(n){return n.id===l.source});if(fn)h+='<div style="font-size:11px;color:var(--hts-text-3);margin-top:4px;padding-left:18px">\u2190 '+esc(fn.title)+'</div>'});
				if(inLinks.length>2){
					var _inId='hts-in-more-'+node.id;
					h+='<div id="'+_inId+'" style="display:none">';
					inLinks.slice(2).forEach(function(l){var fn=_graphData.nodes.find(function(n){return n.id===l.source});if(fn)h+='<div style="font-size:11px;color:var(--hts-text-3);margin-top:4px;padding-left:18px">\u2190 '+esc(fn.title)+'</div>'});
					h+='</div>';
					h+='<div style="font-size:11px;color:var(--hts-accent);margin-top:4px;padding-left:18px;cursor:pointer" onclick="var el=document.getElementById(\''+_inId+'\');if(el.style.display===\'none\'){el.style.display=\'block\';this.textContent=\'\u25b2 Masquer\'}else{el.style.display=\'none\';this.textContent=\'+'+( inLinks.length-2)+' autres\'}">+'+(inLinks.length-2)+' autres</div>';
				}
				h+='</div>';
			}
			if(node.orphan)h+='<div style="padding:8px 12px;border-radius:8px;background:var(--hts-danger-bg);border:1px solid rgba(239,68,68,.2);font-size:12px;color:var(--hts-danger);margin:12px 0">Page isol\u00e9e \u2014 aucun lien ne pointe vers cette page</div>';
			// Action buttons
			h+='<div style="display:flex;flex-direction:column;gap:6px;margin-top:12px">';
			h+='<button onclick="_toast(\'Optimisation en cours...\')" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-accent);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Optimiser</button>';
			if(node.url)h+='<a href="'+esc(node.url)+'" target="_blank" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);text-decoration:none;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px;box-sizing:border-box">Voir l\u0027article</a>';
			if(node.edit_url)h+='<a href="'+esc(node.edit_url)+'" target="_blank" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);text-decoration:none;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px;box-sizing:border-box">Modifier</a>';
			h+='</div>';
		}
		body.innerHTML=h;
	} else {
		// ── CLUSTER OVERVIEW (like JSX when no node selected) ──
		var m=_graphClusterMeta;
		var clScore=Math.min(100,Math.round((m.density||0)*2)); // proxy score from density
		var h='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><span style="font-size:14px;font-weight:700;color:var(--hts-text)">Aper\u00e7u du groupe</span><button onclick="htsCCSidebarToggle(false)" style="width:28px;height:28px;border-radius:6px;border:1px solid var(--hts-border);background:var(--hts-bg);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--hts-text-3)">\u00d7</button></div>';
		h+='<div style="text-align:center;margin-bottom:16px">'+_ring(clScore,64,5)+'</div>';
		// 2x2 metrics + GSC section
		var mets=[
			{l:'Densit\u00e9',v:(m.density||0)+'%',w:(m.density||0)<15},
			{l:'Sans lien',v:m.orphans||0,w:(m.orphans||0)>0},
			{l:'Liens internes',v:m.links||0},
			{l:'Position moy.',v:m.position?m.position:'\u2014'}
		];
		h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:16px">';
		mets.forEach(function(mt){h+='<div style="padding:10px;border-radius:8px;background:'+(mt.w?'var(--hts-danger-bg)':'var(--hts-surface)')+'"><div style="font-size:16px;font-weight:700;color:'+(mt.w?'var(--hts-danger)':'var(--hts-text)')+'">'+mt.v+'</div><div style="font-size:10px;color:var(--hts-text-3);margin-top:1px">'+mt.l+'</div></div>'});
		h+='</div>';
		// S14: GSC cluster summary (if data available)
		var gsc=m.gsc||{};
		if(gsc.total_clicks>0||gsc.total_impressions>0){
			h+='<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Google Search Console</div>';
			h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:16px">';
			h+='<div style="padding:10px;border-radius:8px;background:var(--hts-surface)"><div style="font-size:16px;font-weight:700;color:var(--hts-text)">'+(gsc.total_clicks||0)+'</div><div style="font-size:10px;color:var(--hts-text-3);margin-top:1px">Clics 30j</div></div>';
			h+='<div style="padding:10px;border-radius:8px;background:var(--hts-surface)"><div style="font-size:16px;font-weight:700;color:var(--hts-text)">'+(gsc.total_impressions||0)+'</div><div style="font-size:10px;color:var(--hts-text-3);margin-top:1px">Impressions</div></div>';
			h+='</div>';
		}
		// Intent bar placeholder (we don't have intent data in graph_data)
		// Issues
		if(m.density<15)h+='<div style="padding:8px 10px;border-radius:8px;background:var(--hts-danger-bg);font-size:11px;color:var(--hts-danger);margin-bottom:6px">Maillage tr\u00e8s faible ('+m.density+'%)</div>';
		if(m.orphans>0)h+='<div style="padding:8px 10px;border-radius:8px;background:var(--hts-caution-bg);font-size:11px;color:var(--hts-caution);margin-bottom:6px">'+m.orphans+' pages sans lien</div>';
		// Action buttons
		h+='<div style="display:flex;flex-direction:column;gap:6px;margin-top:12px">';
		if(htsCanApply){
			h+='<button onclick="htsCCGraphAction(\'link\')" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Cr\u00e9er les liens automatiquement</button>';
		}else{
			h+='<div style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-border);color:var(--hts-text-3);font-size:12px;font-weight:600;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px;box-sizing:border-box;opacity:.6">\ud83d\udd12 Cr\u00e9er les liens</div>';
			h+='<div style="font-size:10px;color:var(--hts-text-3);text-align:center;line-height:1.4;margin-bottom:4px">Ajoutez vos liens manuellement. Avec Ultra, les liens sont cr\u00e9\u00e9s par l\u0027IA.</div>';
		}
		h+='<button onclick="htsCCStartComplete()" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Cr\u00e9er de nouveaux contenus</button>';
		h+='<button onclick="htsCCGraphAction(\'zap\')" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Actualiser les scores</button>';
		if(htsCanWrite){
			h+='<button onclick="htsCCGoToRedaction(\u0027'+esc(m.coconId||'')+'\u0027)" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-geo);cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">Voir dans R\u00e9daction \u2192</button>';
		}else{
			h+='<div style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-border);color:var(--hts-text-3);font-size:12px;font-weight:600;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px;box-sizing:border-box;opacity:.6">\ud83d\udd12 Voir dans R\u00e9daction</div>';
			h+='<div style="font-size:10px;color:var(--hts-text-3);text-align:center;line-height:1.4">La r\u00e9daction automatique est disponible avec Ultra.</div>';
		}
		h+='</div>';
		if(m.coconId)h+='<div style="text-align:center;margin-top:16px;display:flex;gap:12px;justify-content:center"><span onclick="htsCCResetCocon()" style="font-size:10px;color:var(--hts-text-3);cursor:pointer;text-decoration:underline">R\u00e9initialiser</span><span onclick="htsDeletePlan(\u0027'+esc(m.coconId)+'\u0027)" style="font-size:10px;color:var(--hts-danger);cursor:pointer;text-decoration:underline">Supprimer ce plan</span></div>';
		h+='</div>';
		body.innerHTML=h;
	}
}
function htsCCGraphAction(type){
	var sidebar=document.getElementById('hts-graph-sidebar');
	/* Ensure sidebar is visible */
	sidebar.style.display='flex';
	var band=document.getElementById('hts-graph-details-band');if(band)band.style.display='none';

	if(type==='link'){
		/* ═══ CRÉER LES LIENS ═══ */
		/* Show simple spinner if already seen the 3-step flow once */
		function _linkShowSimple(){
			sidebar.innerHTML='<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:12px;padding:20px"><div style="width:28px;height:28px;border:3px solid var(--hts-border-sub);border-top-color:var(--hts-geo);border-radius:50%;animation:hts-spin .8s linear infinite"></div><div style="font-size:13px;font-weight:600;color:var(--hts-text)">Cr\u00e9ation des liens\u2026</div><div style="font-size:11px;color:var(--hts-text-3)">Analyse et g\u00e9n\u00e9ration en cours</div></div>';
		}
		function _linkShowSteps(){
			var steps=[
				{l:'Analyse des pages du groupe',done:false,active:true},
				{l:'Recherche des meilleures ancres',done:false,active:false},
				{l:'Cr\u00e9ation des propositions de liens',done:false,active:false}
			];
			var currentStep=0;
			function renderLinkSteps(){
				var h='<div style="padding:18px 20px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px"><span style="font-size:14px;font-weight:700;color:var(--hts-text)">Cr\u00e9ation des liens</span></div>';
				steps.forEach(function(s,i){
					var isDone=s.done,isActive=s.active,isPending=!isDone&&!isActive;
					var bg=isDone?'var(--hts-success)':isActive?'var(--hts-geo)':'var(--hts-border-sub)';
					h+='<div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;position:relative">';
					if(i<2)h+='<div style="position:absolute;left:9px;top:24px;width:2px;height:24px;background:'+(isDone?'var(--hts-success)':'var(--hts-border-sub)')+'"></div>';
					h+='<div style="width:20px;height:20px;border-radius:50%;background:'+bg+';display:flex;align-items:center;justify-content:center;flex-shrink:0">';
					if(isDone)h+='<svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" stroke-width="1.5" fill="none"/></svg>';
					else if(isActive)h+='<div style="width:6px;height:6px;border-radius:50%;background:#fff;animation:pulse 1.5s infinite"></div>';
					h+='</div>';
					h+='<span style="font-size:12px;font-weight:'+(isActive?'600':'400')+';color:'+(isPending?'var(--hts-text-3)':'var(--hts-text)')+'">'+s.l+'</span>';
					h+='</div>';
				});
				h+='<div style="font-size:11px;color:var(--hts-text-3);text-align:center;margin-top:12px">Les propositions de liens seront envoy\u00e9es dans votre Inbox pour validation.</div>';
				h+='</div>';
				sidebar.innerHTML=h;
			}
			function advanceLinkStep(){
				if(currentStep<3){steps[currentStep].done=true;steps[currentStep].active=false;currentStep++;if(currentStep<3){steps[currentStep].active=true}renderLinkSteps()}
			}
			renderLinkSteps();
			return {advance:advanceLinkStep,finish:function(){steps.forEach(function(s){s.done=true;s.active=false});currentStep=3;}};
		}
		var stepCtrl=null,stepTimer=null;
		if(window._graphLinkFlowSeen){
			_linkShowSimple();
		}else{
			stepCtrl=_linkShowSteps();
			stepTimer=setTimeout(function(){stepCtrl.advance();stepTimer=setTimeout(function(){stepCtrl.advance()},3000)},2000);
		}
		/* Call single-cluster linking API (fast, no timeout) */
		if(typeof window._htsPostFn==='function'){
			var _clusterName=_graphCluster||_graphClusterMeta.name||'';
			/* Step 1: Check if pending proposals already exist */
			window._htsPostFn('hts_cocon_link_cluster',{cluster:_clusterName,lang:(window.htsCoconLang||''),check_only:'1'}).then(function(chk){
				if(chk.success&&chk.data&&chk.data.existing_pending>0){
					/* Already have pending proposals — skip creation */
					if(stepTimer)clearTimeout(stepTimer);
					if(stepCtrl)stepCtrl.finish();
					window._graphLinkFlowSeen=true;
					var displayCount=chk.data.existing_pending;
					_showGraphLinkResult(displayCount,'D\u00e9j\u00e0 en attente dans l\u0027Inbox','proposed');
					return;
				}
				if(chk.success&&chk.data&&chk.data.well_linked){
					/* Cluster already checked and well-linked (cache 1h) */
					if(stepTimer)clearTimeout(stepTimer);
					if(stepCtrl)stepCtrl.finish();
					window._graphLinkFlowSeen=true;
					_showGraphLinkResult(chk.data.done||0,'Ce groupe est bien maill\u00e9 !','done');
					return;
				}
				/* Step 2: No pending — create proposals for THIS cluster only */
				window._htsPostFn('hts_cocon_link_cluster',{cluster:_clusterName,lang:(window.htsCoconLang||'')}).then(function(r){
					if(stepTimer)clearTimeout(stepTimer);
					if(stepCtrl)stepCtrl.finish();
					window._graphLinkFlowSeen=true;
					if(r.success){
						var d=r.data||{};
						if(d.message==='well_linked'||(d.proposed===0&&(d.done||0)>0)){
							_showGraphLinkResult(d.done||0,'Ce groupe est bien maill\u00e9 !','done');
						}else if((d.proposed||0)>0){
							_showGraphLinkResult(d.proposed,'Envoy\u00e9es dans votre Inbox','proposed');
						}else if((d.skipped||0)>0&&(d.done||0)===0){
							_showGraphLinkResult(0,'Aucun nouveau lien possible (articles satur\u00e9s ou ancres modifi\u00e9es)','skipped');
						}else{
							_showGraphLinkResult(0,'Aucune opportunit\u00e9 de lien d\u00e9tect\u00e9e','empty');
						}
					}else{
						sidebar.innerHTML='<div style="padding:20px;text-align:center"><div style="font-size:14px;color:var(--hts-danger);margin-bottom:8px">Erreur</div><div style="font-size:12px;color:var(--hts-text-3)">'+esc(r.data||'Erreur inconnue')+'</div><button onclick="htsCCSelectNode(null)" style="margin-top:12px;padding:8px 16px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Retour</button></div>';
					}
				}).catch(function(){
					if(stepTimer)clearTimeout(stepTimer);
					sidebar.innerHTML='<div style="padding:20px;text-align:center"><div style="font-size:14px;color:var(--hts-caution);margin-bottom:8px">Traitement en cours\u2026</div><div style="font-size:12px;color:var(--hts-text-3);margin-bottom:12px">V\u00e9rifiez l\u0027Inbox dans quelques instants.</div><button onclick="window.location.href=\'<?php echo admin_url("admin.php?page=hts-light-dashboard&tab=inbox"); ?>\'" style="margin-top:4px;padding:10px 16px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font)">Voir l\u0027Inbox \u2192</button></div>';
				});
			}).catch(function(){
				/* check_only failed — fallback: run linking directly */
				window._htsPostFn('hts_cocon_link_cluster',{cluster:_clusterName,lang:(window.htsCoconLang||'')}).then(function(r){
					if(stepTimer)clearTimeout(stepTimer);if(stepCtrl)stepCtrl.finish();window._graphLinkFlowSeen=true;
					if(r.success){var fd=r.data||{};if(fd.message==='well_linked'){_showGraphLinkResult(fd.done||0,'Ce groupe est bien maill\u00e9 !','done')}else{_showGraphLinkResult(fd.proposed||0,'Envoy\u00e9es dans votre Inbox','proposed')}}
					else{sidebar.innerHTML='<div style="padding:20px;text-align:center;color:var(--hts-danger)">'+esc(r.data||'Erreur')+'</div>'}
				}).catch(function(){if(stepTimer)clearTimeout(stepTimer);_toast('Erreur — v\u00e9rifiez l\u0027Inbox')});
			});
			/* Shared result renderer for graph sidebar */
			function _showGraphLinkResult(count,subtitle,rtype){
				if(!htsCanApply&&rtype!=='skipped'&&rtype!=='empty'){
					/* ── Pro tier: show proposed links summary + CTA Ultra ── */
					var h='<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:16px;padding:30px;text-align:center">';
					h+='<div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#6366f1);display:flex;align-items:center;justify-content:center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg></div>';
					h+='<div style="font-size:18px;font-weight:800;color:var(--hts-text)">'+count+' lien'+(count>1?'s':'')+' propos\u00e9'+(count>1?'s':'')+'</div>';
					h+='<div style="font-size:13px;color:var(--hts-text-2);line-height:1.6">Cliquez sur un lien violet dans le graphe pour voir le d\u00e9tail (source \u2192 cible).</div>';
					h+='<div style="font-size:12px;color:var(--hts-text-3);line-height:1.5">Les liens doivent \u00eatre ajout\u00e9s manuellement.<br>Avec Ultra, ils sont appliqu\u00e9s automatiquement.</div>';
					h+='<a href="https://hacktheseo.com/pricing" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:10px 24px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:13px;font-weight:700;text-decoration:none;margin-top:4px">Passer \u00e0 Ultra \u2014 249\u20ac/mois</a>';
					h+='</div>';
					sidebar.innerHTML=h;
					htsCCLoadInboxProposals(true);
					return;
				}
				var h='<div style="padding:20px;text-align:center">';
				if(rtype==='done'){
					h+='<div style="width:48px;height:48px;border-radius:50%;background:var(--hts-success-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 12px"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><polyline points="20,6 9,17 4,12" stroke="var(--hts-success)" stroke-width="2.5" fill="none"/></svg></div>';
					h+='<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px">'+count+' lien'+(count>1?'s':'')+' en place</div>';
				}else if(rtype==='skipped'||rtype==='empty'){
					h+='<div style="width:48px;height:48px;border-radius:50%;background:var(--hts-caution-bg, #FFF3E0);display:flex;align-items:center;justify-content:center;margin:0 auto 12px"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M12 9v4m0 4h.01M12 3l9.5 16.5H2.5L12 3z" stroke="var(--hts-caution, #FF9800)" stroke-width="2" fill="none"/></svg></div>';
					h+='<div style="font-size:14px;font-weight:700;color:var(--hts-text);margin-bottom:4px">Aucun nouveau lien</div>';
				}else{
					h+='<div style="width:48px;height:48px;border-radius:50%;background:var(--hts-success-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 12px"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><polyline points="20,6 9,17 4,12" stroke="var(--hts-success)" stroke-width="2.5" fill="none"/></svg></div>';
					h+='<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px">'+count+' proposition'+(count>1?'s':'')+' de liens</div>';
				}
				h+='<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px">'+esc(subtitle)+'</div>';
				var _inboxUrl='<?php echo admin_url("admin.php?page=hts-light-dashboard&tab=inbox"); ?>';
				var _clName=_graphCluster||_graphClusterMeta.name||'';
				if(_clName)_inboxUrl+='&cluster='+encodeURIComponent(_clName);
				if(rtype!=='skipped'&&rtype!=='empty'){
					h+='<button onclick="window.location.href=\''+_inboxUrl+'\'" style="width:100%;padding:12px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:13px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:6px;margin-bottom:8px">Voir dans l\u0027Inbox \u2192</button>';
				}
				h+='<button onclick="location.reload()" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-3);cursor:pointer;font-family:var(--hts-font)">Retour au groupe</button>';
				h+='</div>';
				sidebar.innerHTML=h;
				htsCCLoadInboxProposals(true);
				/* Recharger le graph après 2s pour montrer les liens réels mis à jour */
				if(count>0)setTimeout(function(){
					var c=_graphCluster;if(c&&typeof htsCCOpenGraph==='function'){
						/* Soft refresh : re-fetch data et re-render */
						var wrap=document.getElementById('hts-report-dropdown-wrap');
						if(wrap)wrap.style.pointerEvents='none';
						htsCCOpenGraph(c,c,_graphClusterMeta.pages||0,_graphClusterMeta.density||0,_graphClusterMeta.orphans||0,_graphClusterMeta.links||0,_graphClusterMeta.position||0,_graphClusterMeta.coconId||'',_graphClusterMeta.pillarUrl||'');
						if(wrap)setTimeout(function(){wrap.style.pointerEvents=''},500);
					}
				},2000);
			}
		}else{
			_toast('Fonction de maillage non disponible');
		}

	}else if(type==='zap'){
		/* ═══ VÉRIFIER LA SANTÉ — Analyse flow in sidebar ═══ */
		var zSteps=[
			{l:'Indexation des pages',done:false,active:true},
			{l:'Analyse des liens internes',done:false,active:false},
			{l:'Calcul des scores',done:false,active:false}
		];
		var zStep=0;
		function renderZapSteps(){
			var h='<div style="padding:18px 20px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px"><span style="font-size:14px;font-weight:700;color:var(--hts-text)">V\u00e9rification en cours</span></div>';
			zSteps.forEach(function(s,i){
				var isDone=s.done,isActive=s.active,isPending=!isDone&&!isActive;
				var bg=isDone?'var(--hts-success)':isActive?'var(--hts-geo)':'var(--hts-border-sub)';
				h+='<div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;position:relative">';
				if(i<2)h+='<div style="position:absolute;left:9px;top:24px;width:2px;height:24px;background:'+(isDone?'var(--hts-success)':'var(--hts-border-sub)')+'"></div>';
				h+='<div style="width:20px;height:20px;border-radius:50%;background:'+bg+';display:flex;align-items:center;justify-content:center;flex-shrink:0">';
				if(isDone)h+='<svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" stroke-width="1.5" fill="none"/></svg>';
				else if(isActive)h+='<div style="width:6px;height:6px;border-radius:50%;background:#fff;animation:pulse 1.5s infinite"></div>';
				h+='</div>';
				h+='<span style="font-size:12px;font-weight:'+(isActive?'600':'400')+';color:'+(isPending?'var(--hts-text-3)':'var(--hts-text)')+'">'+s.l+'</span>';
				h+='</div>';
			});
			h+='<div style="font-size:11px;color:var(--hts-text-3);text-align:center;margin-top:12px">Les scores seront recalcul\u00e9s pour tout le groupe.</div>';
			h+='</div>';
			sidebar.innerHTML=h;
		}
		function advanceZapStep(){
			if(zStep<3){zSteps[zStep].done=true;zSteps[zStep].active=false;zStep++;if(zStep<3){zSteps[zStep].active=true}renderZapSteps()}
		}
		renderZapSteps();
		/* Use htsFullRefresh logic: embed loop then NLP */
		if(typeof window._htsPostFn==='function'){
			var totalIdx=0,stale=0;
			function graphEmbedLoop(){
				advanceZapStep();
				window._htsPostFn('hts_cocon_embed_pending',{}).then(function(r){
					if(!r.success){showZapDone(false,'Erreur d\u0027indexation');return}
					var bIdx=r.data.indexed||0,rem=r.data.remaining||0;
					totalIdx+=bIdx;
					if(bIdx===0&&rem>0){stale++;if(stale>=3){graphNLP();return}}else stale=0;
					if(rem>0)setTimeout(graphEmbedLoop,1000);
					else graphNLP();
				}).catch(function(){stale++;if(stale>=3)showZapDone(false,'Erreur r\u00e9seau');else setTimeout(graphEmbedLoop,2000)});
			}
			function graphNLP(){
				advanceZapStep();
				htsChunkedAnalyze(window.htsCoconLang||'',false).then(function(r2){
					advanceZapStep();
					if(r2.success)showZapDone(true);
					else{var emsg=r2.data&&r2.data.message?r2.data.message:'Erreur d\u0027analyse';showZapDone(false,emsg)}
				}).catch(function(){showZapDone(false,'Erreur r\u00e9seau')});
			}
			function showZapDone(ok,errMsg){
				if(ok){
					var h='<div style="padding:20px;text-align:center">';
					h+='<div style="width:48px;height:48px;border-radius:50%;background:var(--hts-success-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 12px"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><polyline points="20,6 9,17 4,12" stroke="var(--hts-success)" stroke-width="2.5" fill="none"/></svg></div>';
					h+='<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px">Analyse termin\u00e9e</div>';
					h+='<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px">Les scores ont \u00e9t\u00e9 recalcul\u00e9s. La page va se recharger pour afficher les nouveaux r\u00e9sultats.</div>';
					h+='</div>';
					sidebar.innerHTML=h;
					setTimeout(function(){location.reload()},2000);
				}else{
					sidebar.innerHTML='<div style="padding:20px;text-align:center"><div style="font-size:14px;color:var(--hts-danger);margin-bottom:8px">'+esc(errMsg||'Erreur')+'</div><button onclick="htsCCSelectNode(null)" style="margin-top:12px;padding:8px 16px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Retour</button></div>';
				}
			}
			graphEmbedLoop();
		}else{
			_toast('Fonction d\u0027analyse non disponible');
		}
	}
}
/* ═══ RESET COCON — Full pipeline: Delete → Embedding → NLP → Regenerate → Poll → Reload ═══ */
function htsCCResetCocon(){
	var m=_graphClusterMeta;
	if(!m.coconId){_toast('Impossible : cocon ID manquant');return}
	var kw=m.name||_graphCluster;
	var pillar=m.pillarUrl||'';
	var cid=m.coconId;
	window.htsModalConfirm(
		'R\u00e9initialiser ce cocon ?',
		'Le plan \u00ab '+kw+' \u00bb sera supprim\u00e9, les embeddings et clusters recalcul\u00e9s, puis le plan recr\u00e9\u00e9. Les brouillons WordPress existants ne sont pas affect\u00e9s.',
		'R\u00e9initialiser','danger'
	).then(function(ok){
		if(!ok)return;
		var post=window._htsPostFn;
		// Progress UI in empty state
		var emptyEl=document.getElementById('hts-graph-empty');
		emptyEl.innerHTML='<div style="text-align:center;max-width:300px"><div style="font-size:14px;font-weight:600;color:rgba(255,255,255,.6);margin-bottom:10px">R\u00e9initialisation</div><div id="hts-reset-step" style="font-size:12px;color:rgba(255,255,255,.35);line-height:1.6">1/5 Suppression du plan...</div></div>';
		emptyEl.style.display='flex';
		var stepEl=document.getElementById('hts-reset-step');
		function setStep(n,txt){if(stepEl)stepEl.textContent=n+'/5 '+txt}

		// ── Step 1: Delete plan ──
		setStep(1,'Suppression du plan...');
		post('hts_cocon_delete_plan',{cocon_id:cid}).then(function(r){
			if(!r.success){_toast(r.data||'Erreur suppression');return Promise.reject('delete')}

			// ── Step 2: Embedding loop (same logic as htsFullRefresh) ──
			setStep(2,'Indexation des embeddings...');
			return new Promise(function(resolve,reject){
				var stale=0;
				function embedLoop(){
					post('hts_cocon_embed_pending',{}).then(function(r){
						if(!r.success){reject('embed');return}
						var rem=r.data.remaining||0,idx=r.data.indexed||0;
						if(idx===0&&rem>0){stale++;if(stale>=3){resolve();return}}else stale=0;
						if(rem>0){setStep(2,'Indexation ('+rem+' restant'+(rem>1?'s':'')+'...)');setTimeout(embedLoop,1000)}
						else resolve();
					}).catch(function(){stale++;if(stale>=3)reject('embed-net');else setTimeout(embedLoop,2000)});
				}
				embedLoop();
			});
		}).then(function(){

			// ── Step 3: NLP clustering ──
			setStep(3,'Clustering NLP...');
			return htsChunkedAnalyze(window.htsCoconLang||'',false);
		}).then(function(r){
			if(!r.success){_toast('Erreur NLP');return Promise.reject('nlp')}

			// ── Step 4: Regenerate plan ──
			setStep(4,'G\u00e9n\u00e9ration du nouveau plan...');
			return post('hts_cocon_generate_plan',{
				pillar_url:pillar,
				main_keyword:kw,
				language:'<?php echo esc_js($hreflang); ?>',
				max_articles:15
			});
		}).then(function(r){
			if(!r||!r.success){_toast(r&&r.data?r.data.message||r.data:'Erreur plan');return Promise.reject('plan')}

			// ── Step 5: Poll until plan ready ──
			setStep(5,'Attente du plan...');
			var newCid=r.data.cocon_id;
			var pollN=0;
			var pollIv=setInterval(function(){
				pollN++;
				post('hts_cocon_poll_plan',{cocon_id:newCid}).then(function(pr){
					if(pr.success&&pr.data.status==='success'){
						clearInterval(pollIv);
						setStep(5,'Termin\u00e9 ! Rechargement...');
						_toast('Cocon recr\u00e9\u00e9 avec clusters !');
						setTimeout(function(){location.reload()},1500);
					}else{
						setStep(5,'Attente... ('+(pr.data?pr.data.status:'?')+')');
					}
				});
				if(pollN>60){
					clearInterval(pollIv);
					setStep(5,'Timeout \u2014 rechargez la page');
					_toast('Timeout, rechargez la page');
				}
			},5000);
		}).catch(function(err){
			if(err&&typeof err==='string'&&err!=='delete')_toast('Erreur \u00e0 l\u0027\u00e9tape : '+err);
		});
	});
}
/* ═══ STAGING PANEL — Compléter le groupe ═══ */
/* Staging panel close */
function htsCCStagingClose(){
	document.getElementById('hts-graph-staging').style.display='none';
	var band=document.getElementById('hts-graph-articles-band');
	if(band)band.style.display='flex';
}
function htsCCStagingReopen(){
	var staging=document.getElementById('hts-graph-staging');
	var band=document.getElementById('hts-graph-articles-band');
	if(staging&&staging.dataset.hasContent==='1'){
		staging.style.display='flex';
		if(band)band.style.display='none';
	}else{
		htsCCStartComplete();
	}
}
function htsCCStartComplete(){
	var coconId=_graphClusterMeta.coconId||'';
	/* If articles to_generate exist, show them instead of the generate form */
	if(coconId&&window._htsPlanArticles&&window._htsPlanArticles[coconId]&&window._htsPlanArticles[coconId].length>0){
		htsCCStagingShowTodo(coconId,window._htsPlanArticles[coconId]);
		return;
	}
	htsCCStartCompleteForce();
}
function htsCCStartCompleteForce(){
	var pillarUrl='',keyword=_graphClusterMeta.name||_graphCluster;
	var pageCount=_graphClusterMeta.pages||0;
	if(_graphData&&_graphData.nodes){
		var pillar=_graphData.nodes.find(function(n){return n.role==='pilier'});
		if(pillar)pillarUrl=pillar.url||'';
	}
	if(!keyword){_toast('Cluster non identifi\u00e9');return}
	// Show staging panel with confirmation
	var panel=document.getElementById('hts-graph-staging');
	panel.style.display='flex';panel.dataset.hasContent='1';
	var artBand=document.getElementById('hts-graph-articles-band');if(artBand)artBand.style.display='none';
	document.getElementById('hts-staging-title').textContent='Cr\u00e9er de nouveaux contenus';
	document.getElementById('hts-staging-sub').textContent='';
	document.getElementById('hts-staging-footer').style.display='none';
	// Phase 1: Confirmation
	var h='<div style="padding:8px 14px;background:var(--hts-accent-bg);border:1px solid var(--hts-accent);border-radius:10px;margin-bottom:16px">';
	h+='<div style="font-size:13px;font-weight:700;color:var(--hts-accent);margin-bottom:4px">Renforcer le groupe</div>';
	h+='<div style="font-size:12px;color:var(--hts-text-2);line-height:1.4">\u00ab '+esc(keyword)+' \u00bb</div>';
	h+='<div style="font-size:11px;color:var(--hts-text-3);margin-top:6px">Hack The SEO va proposer de nouveaux articles pour renforcer ce groupe. Vous choisirez lesquels garder.</div>';
	h+='</div>';
	if(pillarUrl)h+='<div style="font-size:11px;color:var(--hts-text-3);margin-bottom:12px;word-break:break-all">Page principale : '+esc(pillarUrl)+'</div>';
	h+='<div style="display:flex;gap:8px">';
	h+='<button onclick="htsCCStagingClose()" style="flex:1;padding:10px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:12px;font-weight:600;color:var(--hts-text-2);cursor:pointer;font-family:var(--hts-font)">Annuler</button>';
	h+='<button onclick="htsCCStartGenerate()" style="flex:2;padding:10px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:5px">G\u00e9n\u00e9rer le plan</button>';
	h+='</div>';
	document.getElementById('hts-staging-body').innerHTML=h;
}
function htsCCStartGenerate(){
	var pillarUrl='',keyword=_graphClusterMeta.name||_graphCluster;
	if(_graphData&&_graphData.nodes){
		var pillar=_graphData.nodes.find(function(n){return n.role==='pilier'});
		if(pillar)pillarUrl=pillar.url||'';
	}
	var maxArt=25; /* API returns ~25 articles regardless of requested count */
	document.getElementById('hts-staging-title').textContent='G\u00e9n\u00e9ration...';
	// Phase 2: Loading steps
	var steps=[
		{l:'Analyse du cocon',done:false,active:true},
		{l:'Recherche de mots-cl\u00e9s',done:false,active:false},
		{l:'D\u00e9tection des manques',done:false,active:false},
		{l:'G\u00e9n\u00e9ration des suggestions',done:false,active:false}
	];
	var currentStep=0;
	function renderSteps(){
		var h='';
		steps.forEach(function(s,i){
			var isDone=s.done,isActive=s.active,isPending=!isDone&&!isActive;
			var bg=isDone?'var(--hts-success)':isActive?'var(--hts-geo)':'var(--hts-border-sub)';
			h+='<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">';
			h+='<div style="width:20px;height:20px;border-radius:50%;background:'+bg+';display:flex;align-items:center;justify-content:center;flex-shrink:0">';
			if(isDone)h+='<svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" stroke-width="1.5" fill="none"/></svg>';
			else if(isActive)h+='<div style="width:6px;height:6px;border-radius:50%;background:#fff;animation:pulse 1.5s infinite"></div>';
			h+='</div>';
			h+='<span style="font-size:12px;font-weight:'+(isActive?'600':'400')+';color:'+(isPending?'var(--hts-text-3)':'var(--hts-text)')+'">'+s.l+'</span>';
			h+='</div>';
		});
		h+='<div style="font-size:12px;color:var(--hts-text-3);text-align:center;margin-top:8px">Hack The SEO analyse votre cocon et g\u00e9n\u00e8re des suggestions...</div>';
		document.getElementById('hts-staging-body').innerHTML=h;
	}
	function advanceStep(){
		if(currentStep<4){steps[currentStep].done=true;steps[currentStep].active=false;currentStep++;if(currentStep<4){steps[currentStep].active=true}renderSteps()}
	}
	renderSteps();
	// Call API
	jQuery.post('<?php echo esc_js($ajax_url); ?>',{
		action:'hts_cocon_generate_plan',
		nonce:'<?php echo esc_js($nonce); ?>',
		pillar_url:pillarUrl,
		main_keyword:keyword,
		language:'<?php echo esc_js($hreflang); ?>',
		max_articles:maxArt
	},function(r){
		advanceStep();
		if(!r.success){
			document.getElementById('hts-staging-title').textContent='Erreur';
			document.getElementById('hts-staging-body').innerHTML='<div style="color:var(--hts-danger);font-size:12px;padding:20px">'+(r.data&&r.data.message?esc(r.data.message):esc(r.data||'Erreur API'))+'</div>';
			return;
		}
		advanceStep();
		var coconId=r.data.cocon_id;
		document.getElementById('hts-staging-title').textContent='G\u00e9n\u00e9ration du plan...';
		var pollN=0;
		var pollIv=setInterval(function(){
			pollN++;
			jQuery.post('<?php echo esc_js($ajax_url); ?>',{action:'hts_cocon_poll_plan',nonce:'<?php echo esc_js($nonce); ?>',cocon_id:coconId},function(pr){
				if(pr.success){
					var st=pr.data.status||'unknown';
					if(st==='processing'&&currentStep<3)advanceStep();
					if(st==='success'){
						clearInterval(pollIv);advanceStep();advanceStep();
						setTimeout(function(){htsCCStagingReady(coconId,pr.data)},500);
					}
				}
			});
			if(pollN>60){clearInterval(pollIv);document.getElementById('hts-staging-title').textContent='Timeout';document.getElementById('hts-staging-body').innerHTML='<div style="color:var(--hts-caution);font-size:12px;padding:20px">Rechargez la page pour voir le plan.</div>'}
		},5000);
	}).fail(function(){
		document.getElementById('hts-staging-title').textContent='Erreur r\u00e9seau';
		document.getElementById('hts-staging-body').innerHTML='<div style="color:var(--hts-danger);font-size:12px;padding:20px">Impossible de contacter l\u0027API.</div>';
	});
}
/* ── Staging panel: show existing to_generate articles on graph open ── */
function htsCCStagingShowTodo(coconId,todoArts){
	var panel=document.getElementById('hts-graph-staging');
	panel.style.display='flex';panel.dataset.hasContent='1';
	var artBand=document.getElementById('hts-graph-articles-band');if(artBand)artBand.style.display='none';
	document.getElementById('hts-staging-title').textContent=todoArts.length+' article'+(todoArts.length>1?'s':'')+' \u00e0 r\u00e9diger';
	document.getElementById('hts-staging-sub').textContent='Pr\u00eats \u00e0 \u00eatre envoy\u00e9s en r\u00e9daction';
	/* Article list — read-only, no checkboxes */
	var h='';
	var lastCat='';
	todoArts.forEach(function(a,i){
		if(a.category&&a.category!==lastCat){
			lastCat=a.category;
			h+='<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;padding:10px 0 4px">'+esc(a.category)+'</div>';
		}
		h+='<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid var(--hts-border-sub)">';
		h+='<div style="width:20px;height:20px;border-radius:50%;background:var(--hts-geo-soft);display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px"><svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="var(--hts-geo)" stroke-width="2.5" stroke-linecap="round"/></svg></div>';
		h+='<div><div style="font-size:13px;font-weight:500;color:var(--hts-text);line-height:1.35">'+esc(a.title)+'</div>';
		if(a.keyword&&a.keyword!==a.title)h+='<div style="font-size:10px;color:var(--hts-text-3);margin-top:2px">'+esc(a.keyword)+'</div>';
		h+='</div></div>';
	});
	if(!htsCanWrite){
		/* ── Pro tier: CTA en haut + liste floutée en bas ── */
		var out='<div style="padding:20px 10px;text-align:center;border-bottom:1px solid var(--hts-border)">';
		out+='<div style="font-size:14px;font-weight:700;color:var(--hts-text);margin-bottom:8px">Votre plan de contenu est pr\u00eat</div>';
		out+='<div style="font-size:12px;color:var(--hts-text-2);line-height:1.5;margin-bottom:8px">'+todoArts.length+' sujets identifi\u00e9s par l\u0027IA.</div>';
		out+='<div style="font-size:11px;color:var(--hts-text-3);line-height:1.5;margin-bottom:16px">Avec le plan Ultra (249\u20ac/mois), vos articles sont r\u00e9dig\u00e9s automatiquement avec images et liens internes.</div>';
		out+='<a href="https://hacktheseo.com/pricing" target="_blank" style="display:block;width:100%;padding:12px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:13px;font-weight:700;text-decoration:none;text-align:center;box-sizing:border-box;margin-bottom:8px">Passer \u00e0 Ultra \u2014 249\u20ac/mois</a>';
		out+='<a href="'+(window._htsSaasUrl||'https://app.hacktheseo.com')+'" target="_blank" style="display:block;width:100%;padding:10px;border-radius:10px;border:1px solid var(--hts-border);color:var(--hts-text-2);font-size:12px;font-weight:600;text-decoration:none;text-align:center;box-sizing:border-box">R\u00e9diger depuis le SaaS \u2192</a>';
		out+='</div>';
		out+='<div style="filter:blur(4px);pointer-events:none;user-select:none">'+h+'</div>';
		document.getElementById('hts-staging-body').innerHTML=out;
		document.getElementById('hts-staging-footer').style.display='none';
	}else{
		document.getElementById('hts-staging-body').innerHTML=h;
		/* Footer: primary CTA + secondary option */
		var fh='';
		fh+='<button onclick="htsCCGoToRedaction(\u0027'+esc(coconId||'')+'\u0027)" style="width:100%;padding:12px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:13px;font-weight:600;cursor:pointer;font-family:var(--hts-font);display:flex;align-items:center;justify-content:center;gap:6px;margin-bottom:8px">Lancer la r\u00e9daction \u2192</button>';
		fh+='<button onclick="htsCCStagingClose();htsCCStartCompleteForce()" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-3);cursor:pointer;font-family:var(--hts-font)">Ajouter d\u0027autres articles\u2026</button>';
		document.getElementById('hts-staging-footer').style.display='block';
		document.getElementById('hts-staging-footer').innerHTML=fh;
	}
}
/* ── Navigate to Rédaction tab from graph ── */
function htsCCGoToRedaction(targetCoconId){
	if(!htsCanWrite){htsShowLockedModal({required:'ultra',message:'Commandez un article le matin, retrouvez-le r\u00e9dig\u00e9 et illustr\u00e9 le soir. 50 articles/mois, images incluses.',upgrade_url:'https://hacktheseo.com/pricing'});return}
	var coconId=targetCoconId||(_graphClusterMeta?_graphClusterMeta.coconId:'');
	var u=new URL(window.location.href);
	u.searchParams.set('tab','redaction');
	if(coconId)u.searchParams.set('cocon',coconId);
	window.location.href=u.toString();
	return;
	// Legacy tab switch below (kept for reference)
	var coconName=_graphClusterMeta?_graphClusterMeta.name:'';
	htsCCCloseGraph();
	htsCCTab('redaction');
	var sel=document.getElementById('hts-redac-filter');
	if(sel&&(coconId||coconName)){
		var matched=false;
		/* Pass 0: match par data-cocon-id (prioritaire) */
		if(coconId){
			for(var i=0;i<sel.options.length;i++){
				if(sel.options[i].getAttribute('data-cocon-id')===coconId){
					sel.selectedIndex=i;matched=true;break;
				}
			}
		}
		/* Pass 1: exact match on value or text */
		if(!matched&&coconName){
			for(var i=0;i<sel.options.length;i++){
				if(sel.options[i].value===coconName||sel.options[i].textContent.trim()===coconName){
					sel.selectedIndex=i;matched=true;break;
				}
			}
		}
		/* Pass 2: fuzzy match */
		if(!matched&&coconName){
			var nameLow=coconName.toLowerCase().trim();
			for(var i=0;i<sel.options.length;i++){
				var optLow=sel.options[i].textContent.toLowerCase().trim();
				var valLow=(sel.options[i].value||'').toLowerCase().trim();
				if(optLow&&(optLow.indexOf(nameLow)!==-1||nameLow.indexOf(optLow)!==-1||valLow.indexOf(nameLow)!==-1||nameLow.indexOf(valLow)!==-1)){
					sel.selectedIndex=i;matched=true;break;
				}
			}
		}
		if(matched){sel.dispatchEvent(new Event('change'));if(typeof htsFilterRedac==='function')htsFilterRedac(sel.value)}
	}
	window.scrollTo({top:0,behavior:'smooth'});
}
// Phase 3: Checklist of new articles
function htsCCStagingReady(coconId,planData){
	document.getElementById('hts-staging-title').textContent='Articles propos\u00e9s';
	// Parse articles from plan — structure: plan[]{category, articles[]{title, keyword}}
	var articles=[];
	var plan=planData.plan||[];
	if(Array.isArray(plan)){
		plan.forEach(function(cat){
			var catName=cat.category||'';
			(cat.articles||[]).forEach(function(a){
				articles.push({title:a.title||a.keyword||'',keyword:a.keyword||'',category:catName});
			});
		});
	}
	// Fallback: direct articles array
	if(!articles.length&&planData.articles)articles=planData.articles;
	if(!articles.length&&planData.data&&planData.data.articles)articles=planData.data.articles;

	if(!articles.length){
		document.getElementById('hts-staging-body').innerHTML='<div style="color:var(--hts-success);font-size:12px;padding:20px;text-align:center">Plan g\u00e9n\u00e9r\u00e9 ! Rechargez la page pour voir les articles.</div>';
		document.getElementById('hts-staging-footer').style.display='block';
		document.getElementById('hts-staging-footer').innerHTML='<button onclick="location.reload()" style="width:100%;padding:10px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--hts-font)">Recharger la page</button>';
		return;
	}
	document.getElementById('hts-staging-sub').textContent=articles.length+' articles propos\u00e9s';
	function renderList(){
		var h='';
		var lastCat='';
		articles.forEach(function(a,i){
			if(a.category&&a.category!==lastCat){
				lastCat=a.category;
				h+='<div style="font-size:10px;font-weight:700;color:var(--hts-text-3);text-transform:uppercase;letter-spacing:.06em;padding:10px 0 4px">'+esc(a.category)+'</div>';
			}
			h+='<div style="display:flex;align-items:flex-start;gap:10px;padding:8px 0;border-bottom:1px solid var(--hts-border-sub)">';
			h+='<div style="width:6px;height:6px;border-radius:50%;background:var(--hts-geo);flex-shrink:0;margin-top:6px"></div>';
			h+='<div><div style="font-size:12px;font-weight:500;color:var(--hts-text);line-height:1.35">'+esc(a.title)+'</div>';
			if(a.keyword&&a.keyword!==a.title)h+='<div style="font-size:10px;color:var(--hts-text-3);margin-top:2px">'+esc(a.keyword)+'</div>';
			h+='</div></div>';
		});
		if(!htsCanWrite){
			/* ── Pro tier: CTA en haut + liste floutée en bas ── */
			var out='<div style="padding:20px 10px;text-align:center;border-bottom:1px solid var(--hts-border)">';
			out+='<div style="font-size:14px;font-weight:700;color:var(--hts-text);margin-bottom:8px">Votre plan de contenu est pr\u00eat</div>';
			out+='<div style="font-size:12px;color:var(--hts-text-2);line-height:1.5;margin-bottom:8px">'+articles.length+' sujets identifi\u00e9s par l\u0027IA.</div>';
			out+='<div style="font-size:11px;color:var(--hts-text-3);line-height:1.5;margin-bottom:16px">Avec le plan Ultra (249\u20ac/mois), vos articles sont r\u00e9dig\u00e9s automatiquement avec images et liens internes.</div>';
			out+='<a href="https://hacktheseo.com/pricing" target="_blank" style="display:block;width:100%;padding:12px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:13px;font-weight:700;text-decoration:none;text-align:center;box-sizing:border-box;margin-bottom:8px">Passer \u00e0 Ultra \u2014 249\u20ac/mois</a>';
			out+='<a href="'+(window._htsSaasUrl||'https://app.hacktheseo.com')+'" target="_blank" style="display:block;width:100%;padding:10px;border-radius:10px;border:1px solid var(--hts-border);color:var(--hts-text-2);font-size:12px;font-weight:600;text-decoration:none;text-align:center;box-sizing:border-box">R\u00e9diger depuis le SaaS \u2192</a>';
			out+='</div>';
			out+='<div style="filter:blur(4px);pointer-events:none;user-select:none">'+h+'</div>';
			document.getElementById('hts-staging-body').innerHTML=out;
			document.getElementById('hts-staging-footer').style.display='none';
		}else{
			document.getElementById('hts-staging-body').innerHTML=h;
			// Footer — CTA principal
			var fh='';
			fh+='<div style="background:var(--hts-geo-soft);border-radius:8px;padding:8px 12px;font-size:11px;color:var(--hts-geo);line-height:1.4;margin-bottom:10px">'+articles.length+' articles propos\u00e9s. Retrouvez-les dans l\u0027onglet R\u00e9daction pour lancer l\u0027\u00e9criture.</div>';
			fh+='<button onclick="htsCCGoToRedaction(\u0027'+esc(coconId||'')+'\u0027)" style="width:100%;display:flex;align-items:center;justify-content:center;gap:5px;padding:10px;border-radius:var(--hts-radius-sm);border:none;background:var(--hts-geo);color:#fff;font-size:13px;font-weight:600;cursor:pointer;font-family:var(--hts-font);margin-bottom:8px">Lancer la r\u00e9daction \u2192</button>';
			fh+='<button onclick="htsCCStagingClose()" style="width:100%;padding:8px;border-radius:var(--hts-radius-sm);border:1px solid var(--hts-border);background:var(--hts-bg);font-size:11px;font-weight:600;color:var(--hts-text-3);cursor:pointer;font-family:var(--hts-font)">Fermer</button>';
			document.getElementById('hts-staging-footer').style.display='block';
			document.getElementById('hts-staging-footer').innerHTML=fh;
		}
	}
	renderList();
	// Fix 5+C: State + reload après fermeture pour que le graph soit à jour
	if (typeof _graphClusterMeta !== 'undefined') _graphClusterMeta.hasPlan = true;
	if (typeof _graphClusterMeta !== 'undefined' && coconId) _graphClusterMeta.coconId = coconId;
	var _origStagingClose = window.htsCCStagingClose;
	window.htsCCStagingClose = function() {
		if (_origStagingClose) _origStagingClose();
		location.reload();
	};
}
function esc(s){if(!s)return '';var d=document.createElement('div');d.textContent=s;return d.innerHTML}
function _toast(msg){var t=document.getElementById('hts-toast');if(t){t.textContent=msg;t.className='hts-toast show';setTimeout(function(){t.className='hts-toast'},3000)}}
(function(){
'use strict';
var ajaxurl='<?php echo esc_js($ajax_url); ?>',nonce='<?php echo esc_js($nonce); ?>';
<?php
// Detect current Polylang admin language for AJAX calls
$_hts_cocon_lang = '';
if ( class_exists( 'HTS_Language' ) ) {
    $_hts_cocon_lang = HTS_Language::get_current_lang();
}
if ( empty( $_hts_cocon_lang ) && function_exists( 'pll_default_language' ) ) {
    $_hts_cocon_lang = pll_default_language( 'slug' );
}
if ( empty( $_hts_cocon_lang ) ) {
    $_hts_cocon_lang = substr( get_locale(), 0, 2 );
}
?>
var htsCoconLang='<?php echo esc_js( $_hts_cocon_lang ); ?>';
<?php
// Build available languages array for Polylang popup
$_hts_langs_js = array();
if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
    $_hts_langs_js = HTS_Language::get_available_languages();
}
?>
var htsCoconLangs=<?php echo wp_json_encode( (object) $_hts_langs_js ); ?>;
function htsPost(a,d){d=d||{};d.action=a;d.nonce=nonce;if(a.indexOf('hts_cocon')===0&&(!d.lang||d.lang===''))d.lang=htsCoconLang;return new Promise(function(ok,ko){jQuery.post(ajaxurl,d,function(r){if(!r.success&&r.data&&r.data.locked){htsShowLockedModal(r.data);ok(r);return}ok(r)}).fail(function(xhr,st,err){ko(err)})})}
/* Global locked response handler */
function htsShowLockedModal(d){
 var name=d.required==='ultra'?'Ultra (249\u20ac/mois)':'Pro (99\u20ac/mois)';
 var url=d.upgrade_url||'https://hacktheseo.com/pricing';
 var existing=document.getElementById('hts-locked-overlay');
 if(existing)existing.remove();
 var ov=document.createElement('div');ov.id='hts-locked-overlay';
 ov.style.cssText='position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center';
 ov.innerHTML='<div style="background:#fff;border-radius:20px;padding:40px;max-width:420px;width:90%;text-align:center;box-shadow:0 8px 40px rgba(0,0,0,.15)">'
  +'<div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#6366f1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg></div>'
  +'<div style="font-size:18px;font-weight:700;margin-bottom:8px">Plan '+name+' requis</div>'
  +'<div style="font-size:14px;color:#64748b;line-height:1.6;margin-bottom:20px">'+(d.message||'Cette fonctionnalit\u00e9 n\u00e9cessite un abonnement sup\u00e9rieur.')+'</div>'
  +'<a href="'+url+'" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:14px;font-weight:700;text-decoration:none">Voir les plans</a>'
  +'<div style="margin-top:12px"><button onclick="this.closest(\'#hts-locked-overlay\').remove()" style="border:none;background:none;color:#94a3b8;font-size:13px;cursor:pointer">Fermer</button></div>'
  +'</div>';
 document.body.appendChild(ov);
 ov.addEventListener('click',function(e){if(e.target===ov)ov.remove()});
}
window._htsPostFn=htsPost;
window._htsClusterNames=<?php echo wp_json_encode( array_values( array_map( function( $cl ) { return $cl['name'] ?? ''; }, $clusters_data ) ) ); ?>;

/* ═══ LANGUAGE PICKER POPUP (Polylang) ═══ */
window.htsLangThenRefresh=function(btn){
 var keys=Object.keys(htsCoconLangs);
 // Monolingue ou langue déjà sélectionnée dans Polylang → pas de popup
 if(keys.length<2 || (htsCoconLang && htsCoconLang!=='all' && htsCoconLang!=='')){
  htsFullRefresh(btn);return;
 }
 // Build popup
 var ov=document.createElement('div');
 ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;display:flex;align-items:center;justify-content:center;animation:hts-fade-in .15s';
 var box=document.createElement('div');
 box.style.cssText='background:var(--hts-surface,#fff);border-radius:14px;padding:28px 32px;min-width:320px;max-width:400px;box-shadow:0 20px 60px rgba(0,0,0,.2);font-family:var(--hts-font,Inter,sans-serif)';
 box.innerHTML='<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px">Langue de l\u0027analyse</div>'
  +'<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:18px;line-height:1.5">Choisissez la langue des articles \u00e0 analyser. Seuls les contenus dans cette langue seront inclus.</div>'
  +'<div id="hts-lang-choices" style="display:flex;flex-direction:column;gap:8px"></div>'
  +'<label style="display:flex;align-items:center;gap:8px;margin-top:14px;padding:10px 14px;border:1px solid var(--hts-border);border-radius:8px;cursor:pointer;font-size:12px;color:var(--hts-text-2)"><input type="checkbox" id="hts-lang-force-recluster" style="width:16px;height:16px;accent-color:var(--hts-accent)"> Recr\u00e9er les groupes depuis z\u00e9ro <span style="font-size:10px;color:var(--hts-text-3)">(backup auto)</span></label>'
  +'<div style="margin-top:14px;text-align:right"><button id="hts-lang-cancel" style="padding:6px 14px;border:1px solid var(--hts-border);border-radius:8px;background:var(--hts-bg);color:var(--hts-text-3);font-size:12px;font-weight:600;cursor:pointer">Annuler</button></div>';
 ov.appendChild(box);
 document.body.appendChild(ov);
 var choices=box.querySelector('#hts-lang-choices');
 keys.forEach(function(slug){
  var label=htsCoconLangs[slug];
  var b=document.createElement('button');
  b.style.cssText='display:flex;align-items:center;gap:10px;padding:12px 16px;border:1px solid var(--hts-border);border-radius:10px;background:var(--hts-bg);cursor:pointer;font-size:13px;font-weight:600;color:var(--hts-text);text-align:left;transition:border-color .15s,background .15s';
  if(slug===htsCoconLang)b.style.cssText+=';border-color:var(--hts-accent);background:var(--hts-accent-bg)';
  var flag=slug.toUpperCase();
  b.innerHTML='<span style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:20px;border-radius:4px;background:var(--hts-border);font-size:10px;font-weight:700;color:var(--hts-text);letter-spacing:.5px">'+flag+'</span> <span>'+esc(label)+' <span style="font-weight:400;color:var(--hts-text-3);font-size:11px">('+slug+')</span></span>';
  b.onclick=function(){htsCoconLang=slug;document.body.removeChild(ov);var force=document.getElementById('hts-lang-force-recluster');if(force&&force.checked){apShow();apSet('Clustering NLP...','Recr\u00e9ation des groupes ('+slug+')',60,'nlp');htsChunkedAnalyze(slug,true).then(function(r){if(r.success){apSet('Termin\u00e9',r.data.message||'',100,'done');toast('Groupes recr\u00e9\u00e9s !','success');setTimeout(function(){location.reload()},1500)}else{apSet('Erreur',r.data&&r.data.message||'',60,'nlp');apHide();toast(r.data&&r.data.message||'Erreur','error');btn.disabled=false}}).catch(function(){apHide();btn.disabled=false})}else{htsFullRefresh(btn)}};
  choices.appendChild(b);
 });
 box.querySelector('#hts-lang-cancel').onclick=function(){document.body.removeChild(ov)};
 ov.onclick=function(e){if(e.target===ov)document.body.removeChild(ov)};
};

/* ═══ FIX BROKEN CLUSTERS — force recluster with lang popup ═══ */
window.htsFixBrokenClusters=function(btn){
 var keys=Object.keys(htsCoconLangs);
 function doFix(lang){
  htsCoconLang=lang;
  btn.disabled=true;btn.textContent='Recr\u00e9ation...';
  apShow();apSet('Indexation des articles...','',10,'embed');
  htsPost('hts_cocon_embed_pending',{}).then(function(){
   apSet('Clustering NLP en cours...','Regroupement par th\u00e9matique ('+lang+')',60,'nlp');
   htsChunkedAnalyze(lang,true).then(function(r){
    if(r.success){
     apSet('Groupes recr\u00e9\u00e9s',r.data.message||'',100,'done');
     btn.textContent='Recr\u00e9er les groupes';
     toast('Groupes recr\u00e9\u00e9s avec succ\u00e8s !','success');
     setTimeout(function(){location.reload()},1500);
    }else{
     btn.disabled=false;btn.textContent='Recr\u00e9er les groupes';
     var emsg=r.data&&r.data.message?r.data.message:'Erreur';
     apSet('Erreur',emsg,60,'nlp');apHide();
     toast(emsg,'error');
     if(r.data&&r.data.restored)setTimeout(function(){toast('Backup restaur\u00e9 automatiquement.','info')},1500);
    }
   }).catch(function(){btn.disabled=false;btn.textContent='Recr\u00e9er les groupes';apSet('Erreur r\u00e9seau','',0,'embed');apHide();toast('Erreur r\u00e9seau','error')});
  }).catch(function(){
   apSet('Clustering NLP...','Tentative directe',60,'nlp');
   htsChunkedAnalyze(lang,true).then(function(r){
    if(r.success){apSet('Termin\u00e9','',100,'done');btn.textContent='Recr\u00e9er les groupes';toast('Groupes recr\u00e9\u00e9s !','success');setTimeout(function(){location.reload()},1500)}
    else{btn.disabled=false;btn.textContent='Recr\u00e9er les groupes';apHide();toast(r.data&&r.data.message||'Erreur','error')}
   }).catch(function(){btn.disabled=false;btn.textContent='Recr\u00e9er les groupes';apHide()});
  });
 }
 if(keys.length<2){doFix(htsCoconLang);return}
 // Reuse same popup pattern
 var ov=document.createElement('div');
 ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;display:flex;align-items:center;justify-content:center';
 var box=document.createElement('div');
 box.style.cssText='background:var(--hts-surface,#fff);border-radius:14px;padding:28px 32px;min-width:320px;max-width:400px;box-shadow:0 20px 60px rgba(0,0,0,.2);font-family:var(--hts-font,Inter,sans-serif)';
 box.innerHTML='<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px">Recr\u00e9er les groupes</div>'
  +'<div style="font-size:12px;color:var(--hts-text-3);margin-bottom:18px;line-height:1.5">Choisissez la langue. Les groupes actuels seront remplac\u00e9s (un backup sera cr\u00e9\u00e9 automatiquement).</div>'
  +'<div id="hts-fix-choices" style="display:flex;flex-direction:column;gap:8px"></div>'
  +'<div style="margin-top:14px;text-align:right"><button id="hts-fix-cancel" style="padding:6px 14px;border:1px solid var(--hts-border);border-radius:8px;background:var(--hts-bg);color:var(--hts-text-3);font-size:12px;font-weight:600;cursor:pointer">Annuler</button></div>';
 ov.appendChild(box);document.body.appendChild(ov);
 var choices=box.querySelector('#hts-fix-choices');
 keys.forEach(function(slug){
  var label=htsCoconLangs[slug];
  var b=document.createElement('button');
  b.style.cssText='display:flex;align-items:center;gap:10px;padding:12px 16px;border:1px solid var(--hts-border);border-radius:10px;background:var(--hts-bg);cursor:pointer;font-size:13px;font-weight:600;color:var(--hts-text);text-align:left;transition:all .15s';
  if(slug===htsCoconLang)b.style.cssText+=';border-color:var(--hts-accent);background:var(--hts-accent-bg)';
  var flag=slug.toUpperCase();
  b.innerHTML='<span style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:20px;border-radius:4px;background:var(--hts-border);font-size:10px;font-weight:700;color:var(--hts-text);letter-spacing:.5px">'+flag+'</span> <span>'+esc(label)+'</span>';
  b.onclick=function(){document.body.removeChild(ov);doFix(slug)};
  choices.appendChild(b);
 });
 box.querySelector('#hts-fix-cancel').onclick=function(){document.body.removeChild(ov)};
 ov.onclick=function(e){if(e.target===ov)document.body.removeChild(ov)};
};

function toast(msg,type){var t=document.getElementById('hts-toast');if(!t)return;t.textContent=msg;t.className='hts-toast '+(type?type+' ':'')+'show';setTimeout(function(){t.className='hts-toast'},3000)}
function esc(s){if(!s)return'';var d=document.createElement('div');d.textContent=s;return d.innerHTML}

/* ═══ CUSTOM MODAL (replaces native confirm) ═══ */
var _htsModalResolve=null;
window.htsModalConfirm=function(title,msg,okLabel,dangerClass){
 return new Promise(function(resolve){
 _htsModalResolve=resolve;
 document.getElementById('hts-modal-title').textContent=title;
 document.getElementById('hts-modal-msg').textContent=msg;
 var okBtn=document.getElementById('hts-modal-ok');
 okBtn.textContent=okLabel||'Confirmer';
 okBtn.className='hts-cc-btn '+(dangerClass||'primary');
 document.getElementById('hts-modal-overlay').classList.add('active');
 });
};
window.htsModalClose=function(result){
 document.getElementById('hts-modal-overlay').classList.remove('active');
 if(_htsModalResolve){_htsModalResolve(result);_htsModalResolve=null}
};
document.addEventListener('keydown',function(e){
 if(e.key==='Escape'&&document.getElementById('hts-modal-overlay').classList.contains('active')){
 htsModalClose(false);
 }
});

/* ═══ PLAN ═══ */
window.htsGenPlan=function(){var pl=document.getElementById('hts-cc-pillar').value.trim(),kw=document.getElementById('hts-cc-keyword').value.trim(),lg=document.getElementById('hts-cc-lang').value,mx=parseInt(document.getElementById('hts-cc-max').value)||15,st=document.getElementById('hts-cc-gen-status'),bt=document.getElementById('hts-cc-gen-btn');if(!pl||!kw){st.textContent='URL + mot-cl\u00e9 requis';st.style.color='var(--hts-danger)';return}bt.disabled=true;bt.textContent='Envoi...';htsPost('hts_cocon_generate_plan',{pillar_url:pl,main_keyword:kw,language:lg,max_articles:mx}).then(function(r){if(r.success){st.textContent='Plan envoy\u00e9';st.style.color='var(--hts-success)';document.getElementById('hts-cc-polling').style.display='block';htsPollLoop(r.data.cocon_id);toast('Plan envoy\u00e9 !','success')}else{st.textContent=''+(r.data&&r.data.message?r.data.message:(r.data||'Erreur'));st.style.color='var(--hts-danger)';bt.disabled=false;bt.textContent='Cr\u00e9er de nouveaux contenus'}}).catch(function(){st.textContent='R\u00e9seau';bt.disabled=false;bt.textContent='Cr\u00e9er de nouveaux contenus'})};
function htsPollLoop(cid){var pt=document.getElementById('hts-cc-polling-text'),n=0,iv=setInterval(function(){n++;htsPost('hts_cocon_poll_plan',{cocon_id:cid}).then(function(r){if(r.success&&r.data.status==='success'){clearInterval(iv);pt.textContent='Pr\u00eat !';toast('Cocon pr\u00eat !','success');setTimeout(function(){var u=new URL(window.location.href);u.searchParams.set('tab','redaction');window.location.href=u.toString()},1500)}else pt.textContent='En attente... ('+(r.data?r.data.status:'?')+')'});if(n>60){clearInterval(iv);pt.textContent='Timeout'}},5000)}
window.htsPollPlan=function(cid,b){b.disabled=true;b.textContent='...';htsPost('hts_cocon_poll_plan',{cocon_id:cid}).then(function(r){if(r.success&&r.data.status==='success'){b.textContent='';toast('Plan pr\u00eat !','success');setTimeout(function(){location.reload()},1000)}else{b.textContent=''+(r.data?r.data.status:'?');b.disabled=false}}).catch(function(){b.textContent='';b.disabled=false})};
window.htsDeletePlan=function(cid){htsModalConfirm('Supprimer ce cocon ?','Le plan et ses articles associ\u00e9s seront supprim\u00e9s. Les brouillons WordPress ne sont pas affect\u00e9s.','Supprimer','danger').then(function(ok){if(!ok)return;htsPost('hts_cocon_delete_plan',{cocon_id:cid}).then(function(r){if(r.success){toast('Supprim\u00e9','success');location.reload()}else{toast(r.data||'Erreur','error')}})})};

/* ═══ PILLAR ═══ */
window.htsCheckPillar=function(){var url=document.getElementById('hts-cc-pillar').value.trim(),box=document.getElementById('hts-cc-pillar-health');if(!url||!box)return;box.style.display='block';box.textContent='Analyse...';box.style.background='var(--hts-info-bg)';box.style.color='var(--hts-info)';htsPost('hts_cocon_check_pillar',{pillar_url:url}).then(function(r){if(!r.success){box.textContent=''+r.data;box.style.background='var(--hts-caution-bg)';box.style.color='var(--hts-caution)';return}var d=r.data,tp=d.type,colors={strong:'background:var(--hts-success-bg);color:var(--hts-success);border:1px solid var(--hts-success-bg)',moderate:'background:var(--hts-caution-bg);color:var(--hts-caution);border:1px solid var(--hts-caution)',weak:'background:var(--hts-danger-bg);color:var(--hts-danger);border:1px solid var(--hts-danger-bg)',unknown:'background:var(--hts-surface);color:var(--hts-text-2);border:1px solid var(--hts-border)'},icons={strong:'',moderate:'',weak:'',unknown:'\u2753'},labels={strong:'Page solide',moderate:'Page correcte',weak:'Page faible',unknown:'Non trouv\u00e9e'};box.style.cssText='display:block;padding:8px 12px;border-radius:8px;font-size:11px;margin-bottom:12px;'+colors[tp];box.innerHTML=icons[tp]+'<strong>'+labels[tp]+'</strong>'+(d.details?'\u2014 '+d.details:'')}).catch(function(){box.textContent='V\u00e9rification impossible';box.style.background='var(--hts-surface)';box.style.color='var(--hts-text-2)'})};

/* ═══ BATCH ═══ */
window.htsSelectAll=function(cid,ch){document.querySelectorAll('.hts-cc-cb[data-cocon="'+cid+'"]').forEach(function(c){c.checked=ch});htsUpdateCount(cid)};
window.htsUpdateCount=function(cid){var n=document.querySelectorAll('.hts-cc-cb[data-cocon="'+cid+'"]:checked').length;var e=document.getElementById('hts-cc-count-'+cid);if(e)e.textContent=n+' s\u00e9l.'};
window.htsQueueBatch=function(cid){if(!htsCanWrite){htsShowLockedModal({required:'ultra',message:'Commandez un article le matin, retrouvez-le r\u00e9dig\u00e9 et illustr\u00e9 le soir. 50 articles/mois, images incluses.',upgrade_url:'https://hacktheseo.com/pricing'});return}var cbs=document.querySelectorAll('.hts-cc-cb[data-cocon="'+cid+'"]:checked');if(!cbs.length){toast('S\u00e9lectionnez des articles.','error');return}var keys=[];cbs.forEach(function(c){keys.push(c.value)});htsModalConfirm('Mettre en file ?',keys.length+' article(s) seront ajout\u00e9s \u00e0 la file.','Confirmer').then(function(ok){if(!ok)return;var pe=document.getElementById('hts-cc-progress'),le=document.getElementById('hts-cc-progress-list');if(pe)pe.style.display='block';if(le)le.innerHTML='<div style="font-size:12px;padding:4px 0;">Envoi...</div>';htsPost('hts_cocon_queue_articles',{cocon_id:cid,article_keys:keys}).then(function(r){if(r.success){if(le)le.innerHTML='<div style="color:var(--hts-success);">'+r.data.message+'</div>';toast('En file !','success');setTimeout(function(){location.reload()},2000)}else{if(le)le.innerHTML='<div style="color:var(--hts-danger);">'+(r.data||'Erreur')+'</div>'}}).catch(function(){if(le)le.innerHTML='<div style="color:var(--hts-danger);">R\u00e9seau</div>'})})};
window.htsGenBatch=function(cid){if(!htsCanWrite){htsShowLockedModal({required:'ultra',message:'Commandez un article le matin, retrouvez-le r\u00e9dig\u00e9 et illustr\u00e9 le soir. 50 articles/mois, images incluses.',upgrade_url:'https://hacktheseo.com/pricing'});return}var cbs=document.querySelectorAll('.hts-cc-cb[data-cocon="'+cid+'"]:checked');if(!cbs.length){toast('S\u00e9lectionnez des articles.','error');return}
var items=[];cbs.forEach(function(c){
	var row=document.getElementById('hts-art-'+c.value);
	var titleEl=row?row.querySelector('[style*="font-weight:600"],[style*="font-weight:700"]'):null;
	var title=titleEl?titleEl.textContent.trim():'Article';
	items.push({key:c.value,tid:c.dataset.topic||'',cid:cid,title:title});
	c.checked=false;
});
htsUpdateCount(cid);
/* Switch to R\u00e9daction and transform rows inline */
if(typeof _rlSwitchToRedac==='function')_rlSwitchToRedac();
var coconName=cid;
var cCard=document.querySelector('.hts-cocon-card[data-cocon-id="'+cid+'"]');
if(cCard){var kw=cCard.dataset.kw;if(kw)coconName=kw;}
items.forEach(function(it){
	/* Try rédaction row first, then cocon row, then create new */
	var el=document.getElementById('hts-redac-art-'+it.key)||document.getElementById('hts-art-'+it.key);
	if(el&&typeof _rlInjectInline==='function'){
		_rlInjectInline(el,it.key,it.title,coconName);
	}else if(typeof _rlInjectInline==='function'){
		var container=document.getElementById('hts-redac-live');
		if(container){var d=document.createElement('div');d.id='hts-redac-art-'+it.key;container.insertBefore(d,container.firstChild);_rlInjectInline(d,it.key,it.title,coconName)}
	}
});
var idx=0;
function nextLive(){
	if(idx>=items.length){toast(items.length+' article(s) trait\u00e9(s)','success');return}
	var it=items[idx];idx++;
	if(typeof _rlSendArticle==='function'){_rlSendArticle(it.key,it.cid,it.key,it.tid,nextLive)}else{nextLive()}
}
nextLive();};
window.htsForceGen=function(btn,cid,key,tid){btn.disabled=true;btn.textContent='...';var row=btn.parentElement;htsPost('hts_cocon_gen_article',{cocon_id:cid,article_key:key,topic_id:tid,skip_cannibal_check:1}).then(function(r){if(r.success&&r.data.job_id){row.innerHTML='Forc\u00e9e...';poll(r.data.job_id,cid,key,row,function(){htsLoadCoconLogs()})}else{row.innerHTML=''+(r.data&&r.data.message||'Erreur')}})};
window.htsResetArticle=function(cid,akey,btn){btn.disabled=true;btn.textContent='...';htsPost('hts_cocon_reset_article',{cocon_id:cid,article_key:akey}).then(function(r){if(r.success){toast('R\u00e9initialis\u00e9','success');setTimeout(function(){location.reload()},800)}else{btn.disabled=false;btn.textContent='\u2715'}}).catch(function(){btn.disabled=false;btn.textContent='\u2715'})};
window.htsDismissArticle=function(cid,akey,btn){btn.disabled=true;btn.textContent='...';htsPost('hts_cocon_dismiss_article',{cocon_id:cid,article_key:akey,dismiss_action:'skip'}).then(function(r){if(r.success){var row=document.getElementById('hts-art-'+akey);if(row){row.style.transition='opacity .3s';row.style.opacity='.3';row.style.pointerEvents='none'}}else{btn.textContent='';btn.disabled=false}}).catch(function(){btn.textContent='';btn.disabled=false})};

/* ═══ POLL ═══ */
function poll(jid,cid,ak,row,cb){var lastPhase='',phaseStart=Date.now(),warnShown=false;var iv=setInterval(function(){htsPost('hts_cocon_poll_article',{job_id:jid,cocon_id:cid}).then(function(r){if(!r.success)return;var s=r.data.status,ph=r.data.phase||s;if(ph!==lastPhase){lastPhase=ph;phaseStart=Date.now();warnShown=false}var elapsed=Math.round((Date.now()-phaseStart)/1000);row.textContent=''+(r.data.article_title||'')+'\u2014 '+ph;if(elapsed>120&&!warnShown){row.innerHTML=''+(r.data.article_title||'')+'\u2014 '+ph+'<span style="color:var(--hts-caution);">('+elapsed+'s)</span>';warnShown=true}if(elapsed>300){clearInterval(iv);row.innerHTML='Timeout';cb();return}if(s==='completed'&&r.data.article_ready){clearInterval(iv);htsPost('hts_cocon_create_draft',{cocon_id:cid,article_key:ak,job_id:jid}).then(function(d){if(d.success){var pid=d.data.post_id,t=esc(d.data.title),eu=esc(d.data.edit_url);row.innerHTML='<div style="margin-bottom:4px;"><a href="'+eu+'" target="_blank" style="color:var(--hts-text);font-weight:600;text-decoration:none;">'+t+'</a> <span style="color:var(--hts-text-3);font-size:10px;">#'+pid+'</span></div>'+'<div id="hts-st-'+pid+'" style="padding:4px 10px;background:var(--hts-accent-bg);border:1px solid var(--hts-accent);border-radius:6px;font-size:11px;color:var(--hts-accent);display:flex;align-items:center;gap:6px;">'+'<span style="display:inline-block;width:12px;height:12px;border:2px solid var(--hts-accent);border-top-color:var(--hts-accent);border-radius:50%;animation:hts-spin .8s linear infinite;"></span>'+'<span id="hts-st-txt-'+pid+'">Images IA + maillage en arri\u00e8re-plan\u2026</span>'+'</div>';htsPollStatus(pid);htsLoadCoconLogs();cb()}else{row.textContent='Brouillon \u00e9chou\u00e9';htsLoadCoconLogs();cb()}});return}if(s==='failed'||s==='error'){clearInterval(iv);row.textContent='\u00c9chec';htsLoadCoconLogs();cb()}})},5000)}

/* ═══ STATUS POLL (simple — replaces old progress bar) ═══ */
function htsPollStatus(postId){
var attempts=0,maxAttempts=30,staleCount=0,gracePolls=2;
setTimeout(function(){
var iv=setInterval(function(){
 attempts++;
 htsPost('hts_cocon_check_images_status',{post_id:postId}).then(function(r){
 if(!r.success){staleCount++;if(staleCount>=3){clearInterval(iv);var b=document.getElementById('hts-st-'+postId),t=document.getElementById('hts-st-txt-'+postId);if(b){b.style.background='var(--hts-caution-bg)';b.style.borderColor='var(--hts-caution)';b.style.color='var(--hts-caution)';}if(t)t.innerHTML='V\u00e9rification impossible \u2014 le traitement continue en arri\u00e8re-plan. <a href="javascript:location.reload()" style="color:var(--hts-geo);">Rafra\u00eechir</a>'}return}
 staleCount=0;
 var box=document.getElementById('hts-st-'+postId),txt=document.getElementById('hts-st-txt-'+postId);
 if(!box||!txt)return;
 if(r.data.status==='done'){
 if(!r.data.thumb_url&&r.data.img_count===0&&attempts<=gracePolls){
 txt.textContent='Images IA en cours\u2026 ('+Math.round(12+attempts*15)+'s)';
 return;
 }
 clearInterval(iv);
 var parts=['Termin\u00e9'];
 if(r.data.img_count>0)parts.push(r.data.img_count+' image'+(r.data.img_count>1?'s':''));
 if(r.data.cross_links>0)parts.push(r.data.cross_links+' lien'+(r.data.cross_links>1?'s':''));
 box.style.background='var(--hts-success-bg)';box.style.borderColor='var(--hts-success)';box.style.color='var(--hts-success)';
 txt.textContent=parts.join(' \u2022 ');
 var sp=box.querySelector('span[style*="animation"]');if(sp)sp.remove();
 if(r.data.thumb_url){
 box.insertAdjacentHTML('afterend','<div style="margin-top:4px;display:flex;gap:6px;align-items:center;"><img src="'+r.data.thumb_url+'" style="width:36px;height:36px;border-radius:4px;object-fit:cover;border:1px solid var(--hts-border);"><span style="font-size:10px;color:var(--hts-success);">Image \u00e0 la une g\u00e9n\u00e9r\u00e9e</span></div>');
 }
 htsLoadCoconLogs();
 }else{
 txt.textContent='Images IA + maillage en arri\u00e8re-plan\u2026 ('+Math.round(12+attempts*15)+'s)';
 }
 }).catch(function(){staleCount++});
 if(attempts>=maxAttempts){
 clearInterval(iv);
 var txt=document.getElementById('hts-st-txt-'+postId),box=document.getElementById('hts-st-'+postId);
 if(box){box.style.background='var(--hts-caution-bg)';box.style.borderColor='var(--hts-caution)';box.style.color='var(--hts-caution)';}
 if(txt)txt.innerHTML='Pas de r\u00e9ponse \u2014 le traitement continue en arri\u00e8re-plan. <a href="javascript:location.reload()" style="color:var(--hts-geo);">Rafra\u00eechir</a>';
 }
},15000);
},12000);
}

/* ═══ LINKING ═══ */
window.htsSaveLinkingCfg=function(cid){var s=document.getElementById('hts-lk-status-'+cid);s.textContent='...';htsPost('hts_cocon_save_linking_settings',{cocon_id:cid,max_outbound:document.getElementById('hts-lk-out-'+cid).value,max_inbound:document.getElementById('hts-lk-in-'+cid).value,depth:document.getElementById('hts-lk-depth-'+cid).value,min_relevance:document.getElementById('hts-lk-rel-'+cid).value,count_saas_links:document.getElementById('hts-lk-saas-'+cid).checked?'1':'0'}).then(function(r){if(r.success){s.textContent='';s.style.color='var(--hts-success)';toast('Maillage sauvegard\u00e9','success')}else{s.textContent='';s.style.color='var(--hts-danger)'}}).catch(function(){s.textContent='';s.style.color='var(--hts-danger)'})};
window.htsBatchCannibalCheck=function(cid,btn){btn.disabled=true;btn.textContent='...';htsPost('hts_cocon_batch_cannibal',{cocon_id:cid}).then(function(r){if(r.success){btn.textContent='';toast('V\u00e9rification OK','success');setTimeout(function(){location.reload()},2000)}else{btn.textContent='';btn.disabled=false}}).catch(function(){btn.textContent='';btn.disabled=false})};

/* ═══ LOGS ═══ */
window.htsLoadCoconLogs=function(){var c=document.getElementById('hts-cocon-logs-body');if(!c)return;c.innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--hts-text-3);padding:12px;">...</td></tr>';htsPost('hts_cocon_get_logs',{}).then(function(r){if(!r.success||!r.data.logs||!r.data.logs.length){c.innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--hts-text-3);padding:12px;">Aucun log</td></tr>';return}var filter=(document.getElementById('hts-log-filter')||{}).value||'all',fm={articles:['article_queued','article_ready','article_error','draft_created','draft_error','ai_metas','content_cleaned'],schedule:['auto_sched_config','auto_sched_trigger','auto_sched_article','auto_sched_published','auto_sched_skipped','auto_sched_cron','auto_sched_preview'],errors:['article_error','draft_error','ai_metas_error'],links:['cross_links','cross_link_proposed','cross_link_applied','cross_link_rollback','cross_link_dismissed','anchor_ai']},logs=r.data.logs.slice(-100).reverse();if(filter!=='all'){var types=fm[filter]||[];logs=logs.filter(function(l){return types.indexOf(l.type)!==-1})}window._htsLogsRaw=r.data.logs;var icons={'plan_queued':'','plan_ready':'','plan_deleted':'','article_queued':'','article_error':'','article_ready':'','draft_created':'','draft_error':'','ai_metas':'','content_cleaned':'','cross_links':'','cross_link_applied':'','cross_link_rollback':'','auto_sched_config':'','auto_sched_trigger':'','auto_sched_published':'','auto_sched_cron':'','anchor_ai':''},h='';logs.forEach(function(l){if(l.type==='poll_article')return;var i=icons[l.type]||'',d=l.data||{},dt='';if(d.keyword)dt+=d.keyword+'';if(d.title)dt+='"'+d.title+'" ';if(d.words)dt+=d.words+'w ';if(d.reason)dt+=d.reason;var tc=l.type&&l.type.indexOf('error')!==-1?'color:var(--hts-danger);':'';h+='<tr><td style="font-size:10px;color:var(--hts-text-3);white-space:nowrap;">'+(l.time||'').substring(5)+'</td><td>'+i+'</td><td style="'+tc+'">'+(l.message||'')+'</td><td style="color:var(--hts-text-2);font-size:10px;">'+dt+'</td></tr>'});c.innerHTML=h||'<tr><td colspan="4" style="text-align:center;color:var(--hts-text-3);padding:12px;">Aucun</td></tr>'})};
window.htsExportLogs=function(){var logs=window._htsLogsRaw;if(!logs||!logs.length){toast('Aucun log','error');return}var csv='Date;Type;Message;D\u00e9tails\n';logs.forEach(function(l){var d=l.data||{},det=[];if(d.keyword)det.push('KW:'+d.keyword);if(d.title)det.push(d.title);if(d.words)det.push(d.words+'mots');csv+=(l.time||'')+';'+(l.type||'')+';'+(l.message||'').replace(/;/g,',')+';'+det.join(', ').replace(/;/g,',')+'\n'});var b=new Blob([csv],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='hts-cocon-logs-'+new Date().toISOString().slice(0,10)+'.csv';a.click()};

/* ═══ APPROVE ═══ */
window.htsToggleApprove=function(pid,approve,btn){btn.disabled=true;var orig=btn.textContent;btn.textContent='...';htsPost('hts_toggle_schedule_approval',{post_ids:[pid],approved:approve}).then(function(r){if(r.success){if(approve){btn.textContent='\u2713 Valid\u00e9';btn.style.background='var(--hts-accent-bg)';btn.style.color='var(--hts-accent)';btn.style.borderColor='var(--hts-accent)';btn.onclick=function(){htsToggleApprove(pid,0,btn)};toast('Valid\u00e9','success')}else{btn.textContent='Valider';btn.style.background='';btn.style.color='var(--hts-geo)';btn.style.borderColor='';btn.onclick=function(){htsToggleApprove(pid,1,btn)}}btn.disabled=false}else{btn.textContent='';setTimeout(function(){btn.textContent=orig;btn.disabled=false},2000)}}).catch(function(){btn.textContent='';setTimeout(function(){btn.textContent=orig;btn.disabled=false},2000)})};
window.htsUnapprove=function(pid,btn){btn.disabled=true;htsPost('hts_toggle_schedule_approval',{post_ids:[pid],approved:0}).then(function(r){if(r.success){var sp=btn.parentElement;if(sp)sp.style.display='none'}else btn.disabled=false}).catch(function(){btn.disabled=false})};

/* ═══ REMOVE FROM PLANNING ═══ */
window.htsRemoveFromPlanning=function(pid,btn){
 htsModalConfirm('Retirer de la planification ?','Le brouillon ne sera pas supprim\u00e9, seulement retir\u00e9 de la liste.','Retirer','danger').then(function(ok){
 if(!ok)return;
 btn.disabled=true;
 htsPost('hts_toggle_schedule_approval',{post_ids:[pid],approved:0}).then(function(r){
 var item=document.getElementById('drag-'+pid);
 if(item){item.style.transition='all .3s';item.style.opacity='0';item.style.height='0';item.style.padding='0';item.style.margin='0';item.style.overflow='hidden';setTimeout(function(){item.remove()},300)}
 toast('Retir\u00e9 de la planification','success')
 }).catch(function(){btn.disabled=false;btn.style.opacity='1'})
 });
};

/* ═══ WEEK ═══ */
var _htsWeek=1;window.htsToggleWeek=function(){_htsWeek=_htsWeek===1?2:1;document.querySelectorAll('#hts-week-grid > div').forEach(function(d){d.style.display=(d.dataset.week==String(_htsWeek))?'':'none'});document.getElementById('hts-week-toggle').textContent=_htsWeek===1?'Sem. suivante \u2192':'\u2190 Sem. actuelle';var lbl=document.getElementById('hts-week-label');if(lbl)lbl.textContent=_htsWeek===1?lbl.dataset.w1:lbl.dataset.w2};

/* ═══ DRAG & DROP ═══ */
document.querySelectorAll('.hts-drag-item').forEach(function(el){el.addEventListener('dragstart',function(e){e.dataTransfer.setData('text/plain',el.dataset.postId);e.dataTransfer.effectAllowed='move';el.classList.add('dragging')});el.addEventListener('dragend',function(){el.classList.remove('dragging')})});
window.htsDropArticle=function(e,dayEl){e.preventDefault();dayEl.classList.remove('drop-over');var postId=parseInt(e.dataTransfer.getData('text/plain'),10),date=dayEl.dataset.date,time=(document.getElementById('hts-default-time')||{}).value||'09:00';if(!postId||isNaN(postId)||!date){return}var dragItem=document.getElementById('drag-'+postId),title=dragItem?dragItem.dataset.title:'Article #'+postId;var tmp=document.createElement('div');tmp.className='cal-item';tmp.style.background='var(--hts-accent-bg)';tmp.style.color='var(--hts-accent)';tmp.textContent=''+time+''+title.substring(0,18)+'...';dayEl.appendChild(tmp);htsPost('hts_calendar_schedule',{post_id:postId,date:date,time:time+':00'}).then(function(r){if(r.success&&r.data&&r.data.verified){tmp.style.background='var(--hts-success-bg)';tmp.style.color='var(--hts-success)';tmp.textContent=''+time+''+title.substring(0,18);toast('Planifi\u00e9 le '+date+'\u00e0 '+time,'success');if(dragItem){dragItem.style.transition='all .3s';dragItem.style.opacity='0';dragItem.style.height='0';dragItem.style.padding='0';dragItem.style.margin='0';dragItem.style.overflow='hidden';setTimeout(function(){dragItem.remove()},300)}}else{var msg=r.success?'V\u00e9rification \u00e9chou\u00e9e':(typeof r.data==='string'?r.data:(r.data&&r.data.message?r.data.message:'Erreur'));tmp.style.background='var(--hts-danger-bg)';tmp.style.color='var(--hts-danger)';tmp.textContent=''+msg.substring(0,40);toast('Erreur: '+msg,'error');setTimeout(function(){tmp.remove()},5000)}}).catch(function(err){tmp.style.background='var(--hts-danger-bg)';tmp.textContent='R\u00e9seau';setTimeout(function(){tmp.remove()},3000)})};

/* ═══ AUTO MODE ═══ */
window.htsEmergencyStop=function(btn){htsModalConfirm('Arr\u00eat d\u0027urgence','Ceci va annuler tous les articles en file d\u0027attente et en g\u00e9n\u00e9ration, et d\u00e9sactiver le mode auto. Les brouillons d\u00e9j\u00e0 termin\u00e9s ne seront pas supprim\u00e9s.','Tout arr\u00eater','danger').then(function(ok){if(!ok)return;btn.disabled=true;btn.textContent='Arr\u00eat...';htsPost('hts_emergency_stop_generation',{}).then(function(r){if(r.success){btn.textContent='Arr\u00eat\u00e9';btn.style.background='var(--hts-success-bg)';btn.style.borderColor='var(--hts-success)';btn.style.color='var(--hts-success)';toast(r.data.message,'success');htsLoadCoconLogs();setTimeout(function(){location.reload()},2000)}else{btn.textContent='Erreur';btn.disabled=false}}).catch(function(){btn.textContent='R\u00e9seau';btn.disabled=false})})};
window.htsToggleAutoMode=function(on){var f=document.getElementById('hts-auto-fields');if(f){f.style.opacity=on?'1':'.4';f.style.pointerEvents=on?'auto':'none'}var slider=document.getElementById('hts-auto-slider');if(slider)slider.style.background=on?'var(--hts-geo)':'var(--hts-border)';var knob=document.getElementById('hts-auto-knob');if(knob)knob.style.left=on?'21px':'3px';htsSaveAutoConfig()};
window.htsSaveAutoConfig=function(){var days=[];document.querySelectorAll('.hts-auto-day:checked').forEach(function(c){days.push(c.value)});var time=(document.getElementById('hts-auto-time')||{}).value||'09:00',enabled=document.getElementById('hts-auto-toggle').checked,st=document.getElementById('hts-auto-status');st.textContent='...';st.style.color='var(--hts-geo)';htsPost('hts_save_auto_schedule',{enabled:enabled?'1':'0',days:days.join(','),time:time,max_per_day:1,min_gap_hours:4}).then(function(r){if(r.success){st.textContent='';st.style.color='var(--hts-success)';toast('Auto sauvegard\u00e9','success')}else{st.textContent='';st.style.color='var(--hts-danger)'}}).catch(function(){st.textContent='R\u00e9seau';st.style.color='var(--hts-danger)'})};

/* ═══ PREVIEW ═══ */
window.htsPreviewSchedule=function(btn){btn.disabled=true;btn.textContent='...';var panel=document.getElementById('hts-preview-panel'),list=document.getElementById('hts-preview-list'),sum=document.getElementById('hts-preview-summary');htsPost('hts_preview_auto_schedule',{}).then(function(r){btn.disabled=false;btn.textContent='Aper\u00e7u';if(!r.success){list.innerHTML='<div style="color:var(--hts-danger);">'+(r.data||'Erreur')+'</div>';panel.style.display='block';return}var posts=r.data.posts||[],h='';if(!posts.length){list.innerHTML='<div style="color:var(--hts-text-3);">Aucun candidat.</div>';panel.style.display='block';return}posts.forEach(function(p){var status='',bg='';if(p.slot){status=''+p.slot;bg='background:var(--hts-success-bg);'}else if(p.approved&&p.eligible){status='En attente';bg='background:var(--hts-accent-bg);'}else if(p.approved){status='Bloqu\u00e9';bg='background:var(--hts-caution-bg);'}else{status='Non valid\u00e9';bg='background:var(--hts-surface);'}h+='<div style="display:flex;align-items:center;gap:4px;padding:3px 5px;border-radius:4px;margin-bottom:2px;'+bg+'"><span style="font-size:9px;min-width:90px;">'+status+'</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+p.title+'</span></div>'});list.innerHTML=h;if(r.data.summary)sum.textContent=r.data.summary;panel.style.display='block'}).catch(function(){btn.disabled=false;btn.textContent='Aper\u00e7u'})};

/* ═══ PRE-FILL (reinforcement mode) ═══ */
window.htsPreFillCommander=function(pillarUrl,keyword,lang,existingCount){
 var panel=document.getElementById('hts-create-cocon-panel');
 if(panel)panel.style.display='block';
 setTimeout(function(){
 panel.scrollIntoView({behavior:'smooth',block:'start'});
 var pf=document.getElementById('hts-cc-pillar'),
 kf=document.getElementById('hts-cc-keyword'),
 lf=document.getElementById('hts-cc-lang'),
 mf=document.getElementById('hts-cc-max'),
 banner=document.getElementById('hts-reinforce-banner'),
 title=document.getElementById('hts-create-cocon-title'),
 desc=document.getElementById('hts-create-cocon-desc');
 if(pf&&pillarUrl)pf.value=pillarUrl;
 if(kf&&keyword)kf.value=keyword;
 if(lf&&lang){for(var i=0;i<lf.options.length;i++){if(lf.options[i].value===lang){lf.selectedIndex=i;break}}}
 if(mf)mf.value=Math.min(50,Math.max(5,10));
 /* Show reinforcement banner */
 if(banner&&keyword){
 banner.style.display='block';
 document.getElementById('hts-reinforce-kw').textContent=keyword;
 document.getElementById('hts-reinforce-count').textContent=existingCount||0;
 if(title)title.textContent='\uD83D\uDCAA Renforcer le cocon';
 if(desc)desc.style.display='none';
 }
 /* Highlight fields */
 [pf,kf].forEach(function(f){if(f){f.style.transition='background .3s';f.style.background='var(--hts-caution-bg)';setTimeout(function(){f.style.background=''},1500)}});
 if(pillarUrl)setTimeout(htsCheckPillar,300);
 },100);
};
/* ═══ CLEAR REINFORCE MODE ═══ */
window.htsClearReinforce=function(){
 var banner=document.getElementById('hts-reinforce-banner'),
 title=document.getElementById('hts-create-cocon-title'),
 desc=document.getElementById('hts-create-cocon-desc'),
 pf=document.getElementById('hts-cc-pillar'),
 kf=document.getElementById('hts-cc-keyword'),
 mf=document.getElementById('hts-cc-max');
 if(banner)banner.style.display='none';
 if(title)title.textContent='\uD83D\uDCCB Cr\u00e9er un cocon';
 if(desc)desc.style.display='block';
 if(pf)pf.value='';
 if(kf)kf.value='';
 if(mf)mf.value='15';
};

/* ═══ CROSS-COCON ACTIONS ═══ */
window.htsCrossAction=function(action,postId,propIndex,btn){
 btn.disabled=true;var orig=btn.textContent;btn.textContent='...';
 var endpoints={apply:'hts_cocon_apply_cross_link',dismiss:'hts_cocon_dismiss_cross_link',rollback:'hts_cocon_rollback_cross_link'};
 var endpoint=endpoints[action];if(!endpoint){btn.textContent='';btn.disabled=false;return}
 htsPost(endpoint,{post_id:postId,prop_index:propIndex}).then(function(r){
 if(r.success){
 var row=btn.closest('tr');
 if(action==='apply'){btn.textContent='';toast('Lien appliqu\u00e9','success');if(row){row.style.transition='opacity .3s';row.style.opacity='.3';setTimeout(function(){row.remove()},1500)}}
 else if(action==='dismiss'){btn.textContent='\u23ed';toast('Ignor\u00e9','success');if(row){row.style.transition='opacity .3s';row.style.opacity='.3';setTimeout(function(){row.remove()},1500)}}
 else if(action==='rollback'){btn.textContent='';toast('Lien annul\u00e9','success');if(row){var badge=row.querySelector('.hts-cc-badge');if(badge){badge.className='hts-cc-badge orange';badge.textContent=' Annul\u00e9'}btn.remove()}}
 }else{btn.textContent='';toast(r.data||'Erreur','error');setTimeout(function(){btn.textContent=orig;btn.disabled=false},2000)}
 }).catch(function(){btn.textContent='R\u00e9seau';setTimeout(function(){btn.textContent=orig;btn.disabled=false},2000)})
};
window.htsScanCrossCocon=function(postId,btn){
 btn.disabled=true;btn.textContent='Scan...';
 htsPost('hts_cocon_scan_cross_cocon',{post_id:postId}).then(function(r){
 if(r.success){btn.textContent=''+(r.data.count||0)+'trouv\u00e9(s)';toast(r.data.message||'Scan termin\u00e9','success');if(r.data.count>0)setTimeout(function(){location.reload()},2000)}
 else{btn.textContent='';toast(r.data||'Erreur','error');setTimeout(function(){btn.textContent='Scan';btn.disabled=false},2000)}
 }).catch(function(){btn.textContent='R\u00e9seau';setTimeout(function(){btn.textContent='Scan';btn.disabled=false},2000)})
};

/* ═══ RESCAN MAILLAGE → puis relance l'analyse NLP pour actualiser les compteurs ═══ */
window.htsRescanMaillage=function(coconId,btn){
 btn.disabled=true;var orig=btn.textContent;btn.textContent='Scan liens...';
 htsPost('hts_cocon_rescan_maillage',{cocon_id:coconId}).then(function(r){
 if(r.success){
 var d=r.data;
 toast(d.message,'success');
 // Chain: re-run NLP analysis to update link counts in clusters
 btn.textContent='Mise \u00e0 jour clusters...';
 htsChunkedAnalyze(window.htsCoconLang||'',false).then(function(r2){
 if(r2.success){
 btn.textContent=''+d.links_added+'liens · clusters OK';
 toast('Clusters mis \u00e0 jour','success');
 setTimeout(function(){location.reload()},2000)
 }else{
 btn.textContent=''+d.links_added+'liens (clusters non mis \u00e0 jour)';
 setTimeout(function(){location.reload()},2500)
 }
 }).catch(function(){
 btn.textContent=''+d.links_added+'liens (clusters non mis \u00e0 jour)';
 setTimeout(function(){location.reload()},2500)
 })
 }else if(r.data&&r.data.message==='use_batch'&&window.htsJobPoller){
 btn.textContent='Scan par lots…';
 htsJobPoller.start({initAction:r.data.batch_init,stepAction:r.data.batch_step,nonce:htsNonce,params:{cocon_id:coconId},
  onProgress:function(d){btn.textContent=(d.message||'Scan...')+' '+(d.progress||0)+'%';},
  onComplete:function(d){toast('Maillage scanné !','success');setTimeout(function(){location.reload()},1200);},
  onError:function(msg){btn.disabled=false;btn.textContent=orig;toast(msg,'error');}
 });return;
 }else{
 btn.textContent=''+(r.data&&r.data.message?r.data.message:'Erreur');
 setTimeout(function(){btn.textContent=orig;btn.disabled=false},3000)
 }
 }).catch(function(){btn.textContent='R\u00e9seau';setTimeout(function(){btn.textContent=orig;btn.disabled=false},3000)})
};

/* ═══ FULL REFRESH (protected mode — keeps clusters) ═══ */
/* ═══ PROGRESS BAR HELPERS ═══ */
var _ap=document.getElementById('hts-analysis-progress'),
    _apL=document.getElementById('hts-ap-label'),
    _apD=document.getElementById('hts-ap-detail'),
    _apB=document.getElementById('hts-ap-bar');
function apShow(){if(_ap)_ap.style.display='block'}
function apHide(){if(_ap)setTimeout(function(){_ap.style.display='none'},2000)}
function apSet(label,detail,pct,step){
 if(_apL)_apL.textContent=label;
 if(_apD)_apD.textContent=detail||'';
 if(_apB)_apB.style.width=Math.min(100,pct)+'%';
 ['embed','nlp','done'].forEach(function(s){
  var d=document.getElementById('hts-ap-dot-'+s);
  if(!d)return;
  if(s===step)d.style.background='var(--hts-accent)';
  else if(['embed','nlp','done'].indexOf(s)<['embed','nlp','done'].indexOf(step))d.style.background='var(--hts-success)';
 });
}

/* === CREATE GROUPS — runs cluster + finalize steps after money pages are validated === */
window.htsPrefillCocon=function(pillarUrl,pillarTitle){
 var panel=document.getElementById('hts-create-cocon-panel');
 if(panel){panel.style.display='block';panel.scrollIntoView({behavior:'smooth'});}
 var kwInput=document.getElementById('hts-new-cocon-kw');if(kwInput)kwInput.value=pillarTitle||'';
 var urlInput=document.getElementById('hts-new-cocon-pillar');if(urlInput)urlInput.value=pillarUrl||'';
};
window.htsDismissSuggestion=function(btn,name,pillarId){
 var card=btn.closest('.hts-cocon-card');
 if(card)card.style.display='none';
 htsPost('hts_dismiss_suggestion',{cluster_name:name});
};
window.htsAcceptSuggestion=function(btn,name){
 btn.disabled=true;btn.textContent='...';
 htsPost('hts_cocon_accept_suggestion',{cluster_name:name}).then(function(r){
  if(r.success){toast('Groupe créé !','success');setTimeout(function(){location.reload()},1000)}
  else{btn.disabled=false;btn.textContent='Créer ce groupe';toast(r.data&&r.data.message||'Erreur','error')}
 }).catch(function(){btn.disabled=false;btn.textContent='Créer ce groupe';toast('Erreur réseau','error')});
};
window.htsCreateGroups=function(b){
 try{
 b.disabled=true;b.textContent='Cr\u00e9ation en cours...';
 var lang=window.htsCoconLang||'';

 /* Collect active money page IDs from toggles — source of truth is the UI, not the DB */
 var pillarIds=[];
 document.querySelectorAll('.hts-mp-row input[type=checkbox]:checked').forEach(function(cb){
  var row=cb.closest('.hts-mp-row');
  if(!row||!row.dataset.mpId) return;
  if(row.style.display==='none'||row.classList.contains('dismissed')) return;
  pillarIds.push(parseInt(row.dataset.mpId));
 });
 /* Also collect from standalone panel (no-clusters view) */
 document.querySelectorAll('#hts-mp-panel .hts-mp-row input[type=checkbox]:checked, [id^=hts-mp-card-] input[type=checkbox]:checked').forEach(function(cb){
  var row=cb.closest('[data-mp-id]');
  if(!row||!row.dataset.mpId) return;
  if(row.style.display==='none'||row.classList.contains('dismissed')) return;
  var id=parseInt(row.dataset.mpId);if(pillarIds.indexOf(id)===-1)pillarIds.push(id);
 });

 if(pillarIds.length===0){toast('Aucune page business active. Activez au moins 2 pages.','error');b.disabled=false;b.textContent='Cr\u00e9er les groupes';return}


 apShow();

 /* Re-run init + scan + links first (fresh data), then cluster + finalize */
 apSet('Initialisation...','Chargement des articles',5,'nlp');
 htsPost('hts_cocon_analyze_step',{step:'init',lang:lang,force_recluster:1}).then(function(r){
  if(!r.success){b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast(r.data||'Erreur','error');apHide();return}
  var total=r.data.total||0,offset=0;

  function scanLoop(){
   var pct=5+Math.round((offset/Math.max(total,1))*25);
   apSet('Scan des articles...',offset+'/'+total,pct,'nlp');
   htsPost('hts_cocon_analyze_step',{step:'scan',lang:lang,offset:offset}).then(function(r2){
    if(!r2.success){b.disabled=false;b.textContent='Cr\u00e9er les groupes';apHide();return}
    if(r2.data.done){doLinks()}
    else{offset=r2.data.processed;setTimeout(scanLoop,300)}
   }).catch(function(err){console.error('HTS scan error:',err);b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast('Erreur scan','error');apHide()});
  }

  function doLinks(){
   apSet('Calcul du maillage...','Liens internes et scores',35,'nlp');
   htsPost('hts_cocon_analyze_step',{step:'links',lang:lang}).then(function(r3){
    doEmbed(0);
   }).catch(function(err){console.error('HTS links error:',err);b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast('Erreur links','error');apHide()});
  }

  function doEmbed(eOff){
   apSet('Indexation s\u00e9mantique...','Embeddings '+(eOff||0)+' ...',40,'nlp');
   htsPost('hts_cocon_analyze_step',{step:'embed',lang:lang,offset:eOff}).then(function(r3b){
    if(!r3b.success){doCluster();return}
    if(r3b.data.skipped||r3b.data.done){
     var pct=r3b.data.skipped?42:50;
     apSet('Embeddings termin\u00e9s',r3b.data.message||'OK',pct,'nlp');
     doCluster();
    }else{
     var p=r3b.data.processed||0,t=r3b.data.total||1;
     var pct=40+Math.round((p/t)*10);
     apSet('Indexation s\u00e9mantique...',p+'/'+t+' embeddings',pct,'nlp');
     setTimeout(function(){doEmbed(p)},300);
    }
   }).catch(function(err){console.error('HTS embed error:',err);doCluster()});
  }

  function doCluster(){
   apSet('Clustering NLP...','Regroupement par th\u00e9matique (peut prendre 30-60s)',55,'nlp');
   htsPost('hts_cocon_analyze_step',{step:'cluster',lang:lang,force_recluster:1,pillar_ids:pillarIds.join(',')}).then(function(r4){
    if(!r4.success){b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast(r4.data&&r4.data.message||'Erreur clustering','error');apHide();return}
    doFinalize();
   }).catch(function(err){console.error('HTS cluster error:',err);b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast('Erreur clustering \u2014 v\u00e9rifiez la console','error');apHide()});
  }

  function doFinalize(){
   apSet('Finalisation...','Sauvegarde des groupes',90,'nlp');
   htsPost('hts_cocon_analyze_step',{step:'finalize',lang:lang,force_recluster:1}).then(function(r5){
    if(r5.success){
     apSet('Termin\u00e9',r5.data.message||'',100,'done');
     toast('Groupes cr\u00e9\u00e9s !','success');
     setTimeout(function(){location.reload()},1500);
    }else{
     b.disabled=false;b.textContent='Cr\u00e9er les groupes';
     toast(r5.data&&r5.data.message||'Erreur','error');apHide();
    }
   }).catch(function(err){console.error('HTS finalize error:',err);b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast('Erreur finalisation \u2014 v\u00e9rifiez la console','error');apHide()});
  }

  scanLoop();
 }).catch(function(err){console.error('HTS init error:',err);b.disabled=false;b.textContent='Cr\u00e9er les groupes';toast('Erreur init \u2014 v\u00e9rifiez la console','error');apHide()});
 }catch(e){console.error('HTS FATAL:',e);toast('Erreur JS: '+e.message,'error');b.disabled=false;b.textContent='Cr\u00e9er les groupes';}
};

/* === CHUNKED ANALYZE — replaces single hts_cocon_analyze call === */
window.htsChunkedAnalyze=function(lang,force){
 return new Promise(function(resolve,reject){
  var fc=force?1:0;
  apSet('Initialisation...','Chargement des articles',10,'nlp');
  htsPost('hts_cocon_analyze_step',{step:'init',lang:lang,force_recluster:fc}).then(function(r){
   if(!r.success){reject(r);return}
   var total=r.data.total||0;
   if(r.data.step==='done'){resolve(r);return}
   var offset=0;
   function scanLoop(){
    var pct=10+Math.round((offset/Math.max(total,1))*40);
    apSet('Scan des articles...',offset+'/'+total+' analys\u00e9s',pct,'nlp');
    htsPost('hts_cocon_analyze_step',{step:'scan',lang:lang,offset:offset}).then(function(r2){
     if(!r2.success){reject(r2);return}
     if(r2.data.done){doLinks()}
     else{offset=r2.data.processed;setTimeout(scanLoop,300)}
    }).catch(reject);
   }
   function doLinks(){
    apSet('Calcul du maillage...','Liens internes et scores',55,'nlp');
    htsPost('hts_cocon_analyze_step',{step:'links',lang:lang}).then(function(r3){
     if(!r3.success){reject(r3);return}
     doCluster();
    }).catch(reject);
   }
   function doCluster(){
    apSet('Clustering NLP...','Regroupement par th\u00e9matique',70,'nlp');
    htsPost('hts_cocon_analyze_step',{step:'cluster',lang:lang,force_recluster:fc}).then(function(r4){
     if(!r4.success){reject(r4);return}
     doFinalize();
    }).catch(reject);
   }
   function doFinalize(){
    apSet('Finalisation...','Calcul des scores et sauvegarde',90,'nlp');
    htsPost('hts_cocon_analyze_step',{step:'finalize',lang:lang,force_recluster:fc}).then(function(r5){
     if(!r5.success){reject(r5);return}
     resolve(r5);
    }).catch(reject);
   }
   scanLoop();
  }).catch(reject);
 });
};

window.htsFullRefresh=function(b){
 b.disabled=true;b.textContent='Analyse en cours...';
 apShow();apSet('Indexation des articles...','',5,'embed');
 var totalIndexed=0,staleCount=0;
 var lang=window.htsCoconLang||'';

 function embedLoop(){
  htsPost('hts_cocon_embed_pending',{}).then(function(r){
   if(!r.success){apSet('Erreur indexation',r.data||'',0,'embed');b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide();return}
   var bIdx=r.data.indexed||0,rem=r.data.remaining||0;
   totalIndexed+=bIdx;
   if(bIdx===0&&rem>0){staleCount++;if(staleCount>=3){launchScan();return}}else staleCount=0;
   if(rem>0){
    var pct=Math.round(((totalIndexed)/(totalIndexed+rem))*60);
    apSet('Indexation des articles...',totalIndexed+' index\u00e9(s), '+rem+' restant(s)',Math.max(5,pct),'embed');
    setTimeout(embedLoop,1000);
   }else{launchScan()}
  }).catch(function(){staleCount++;if(staleCount>=3){apSet('Erreur r\u00e9seau','',0,'embed');b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide()}else setTimeout(embedLoop,2000)});
 }

 /* Step 2: Init + Scan + Links (no clustering!) */
 function launchScan(){
  apSet('Initialisation...','Chargement des articles',10,'nlp');
  htsPost('hts_cocon_analyze_step',{step:'init',lang:lang,force_recluster:0}).then(function(r){
   if(!r.success){apSet('Erreur',r.data||'',10,'nlp');b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide();return}
   var total=r.data.total||0;
   if(r.data.step==='done'){finish('Aucun article trouv\u00e9.');return}
   var offset=0;
   function scanLoop(){
    var pct=15+Math.round((offset/Math.max(total,1))*40);
    apSet('Scan des articles...',offset+'/'+total+' analys\u00e9s',pct,'nlp');
    htsPost('hts_cocon_analyze_step',{step:'scan',lang:lang,offset:offset}).then(function(r2){
     if(!r2.success){apSet('Erreur scan',r2.data||'',pct,'nlp');b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide();return}
     if(r2.data.done){doLinks()}
     else{offset=r2.data.processed;setTimeout(scanLoop,300)}
    }).catch(function(){b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide()});
   }
   function doLinks(){
    apSet('Calcul du maillage...','Liens internes, scores et pages business',65,'nlp');
    htsPost('hts_cocon_analyze_step',{step:'links',lang:lang}).then(function(r3){
     if(!r3.success){apSet('Erreur',r3.data||'',65,'nlp');b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide();return}
     var msg=r3.data.links+' liens d\u00e9tect\u00e9s';
     if(r3.data.money_pages>0) msg+=', '+r3.data.money_pages+' pages business';
     finish(msg);
    }).catch(function(){b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide()});
   }
   scanLoop();
  }).catch(function(){b.textContent='Lancer l\u0027analyse';b.disabled=false;apHide()});
 }

 function finish(msg){
  apSet('Analyse termin\u00e9e',msg,100,'done');
  b.textContent='Lancer l\u0027analyse';
  toast('Analyse termin\u00e9e ! V\u00e9rifiez vos pages business.','success');
  setTimeout(function(){location.reload()},1500);
 }

 embedLoop();
};


/* ═══ RESET ALL COCONS (purge clusters + money pages) ═══ */
window.htsResetCocons=function(btn){
 htsModalConfirm(
 'Tout supprimer ?',
 'Ceci va supprimer tous les clusters s\u00e9mantiques et la d\u00e9tection de pages business. Les articles et brouillons ne sont pas touch\u00e9s. Vous pourrez relancer avec \u00ab Recr\u00e9er les clusters \u00bb.',
 'Supprimer',
 'danger'
 ).then(function(ok){
 if(!ok)return;
 btn.disabled=true;btn.textContent='Suppression\u2026';
 htsPost('hts_reset_cocon_data',{}).then(function(r){
 if(r.success){
 toast('Clusters et pages business supprim\u00e9s','success');
 setTimeout(function(){location.reload()},1000);
 }else{
 btn.disabled=false;btn.textContent='Tout supprimer';
 toast(r.data||'Erreur','error');
 }
 }).catch(function(){btn.disabled=false;btn.textContent='Tout supprimer';toast('Erreur r\u00e9seau','error')});
 });
};

/* ═══ FORCE RECLUSTER (full reset → NLP → discovery → awaiting maillage) ═══ */
window.htsForceRecluster=function(b){
 htsModalConfirm(
 'Recr\u00e9er tous les clusters ?',
 'Les clusters et pages business seront supprim\u00e9s puis recalcul\u00e9s. Vous pourrez ensuite valider les pages piliers et lancer le maillage.',
 'Recr\u00e9er',
 'danger'
 ).then(function(ok){
 if(!ok)return;
 b.disabled=true;

 /* Step 1: Reset everything (sets awaiting_maillage flag) */
 b.textContent='Nettoyage\u2026';
 htsPost('hts_reset_cocon_data',{}).then(function(){

 /* Step 2: Index pending embeddings */
 b.textContent='Indexation\u2026';
 var p=document.getElementById('hts-cc-embed-progress'),totalIndexed=0,staleCount=0;
 function embedLoop(){
 htsPost('hts_cocon_embed_pending',{}).then(function(r){
 if(!r.success){b.textContent=''+(r.data||'Erreur');b.disabled=false;return}
 var bIdx=r.data.indexed||0,rem=r.data.remaining||0;totalIndexed+=bIdx;
 if(p)p.textContent=totalIndexed>0?totalIndexed+'index\u00e9e(s)'+(rem>0?', '+rem+'restante(s)':''):'';
 if(bIdx===0&&rem>0){staleCount++;if(staleCount>=3){launchNLP();return}}else staleCount=0;
 if(rem>0){b.textContent='Indexation ('+rem+')';setTimeout(embedLoop,1000)}
 else launchNLP()
 }).catch(function(){staleCount++;if(staleCount>=3){b.textContent='R\u00e9seau';b.disabled=false}else setTimeout(embedLoop,2000)})
 }

 /* Step 3: NLP clustering */
 function launchNLP(){
 b.textContent='Clustering NLP\u2026';
 htsChunkedAnalyze(window.htsCoconLang||'',true).then(function(r2){
 if(!r2.success){b.textContent='Analyse';b.disabled=false;var emsg=r2.data&&r2.data.message?r2.data.message:'Erreur clustering';toast(emsg,'error');if(r2.data&&r2.data.restored){setTimeout(function(){toast('Groupes pr\u00e9c\u00e9dents restaur\u00e9s automatiquement.','info')},1500)}return}

 /* Step 4: Discover money pages */
 b.textContent='D\u00e9tection pages business\u2026';
 htsPost('hts_discover_money_pages',{}).then(function(){
 b.textContent='Termin\u00e9 — validez les piliers';
 toast('Clusters recr\u00e9\u00e9s ! Validez les pages piliers puis cliquez Cr\u00e9er les liens.','success');
 setTimeout(function(){location.reload()},1500);
 }).catch(function(){
 b.textContent='Clusters recr\u00e9\u00e9s';
 toast('Clusters recr\u00e9\u00e9s (d\u00e9tection partielle)','success');
 setTimeout(function(){location.reload()},1500);
 });
 }).catch(function(){b.textContent='R\u00e9seau';b.disabled=false})
 }
 embedLoop();

 }).catch(function(){b.textContent='R\u00e9seau';b.disabled=false});
 });
};

/* ═══ AUTO-RESUME ═══ */
(function(){
var queued=document.querySelectorAll('[data-job]');
if(!queued.length)return;
var pe=document.getElementById('hts-cc-progress'),le=document.getElementById('hts-cc-progress-list');
if(pe)pe.style.display='block';
if(le)le.innerHTML='<div style="font-weight:600;color:var(--hts-accent);padding:6px 0;font-size:13px;">Reprise de '+queued.length+'article(s) en cours de g\u00e9n\u00e9ration\u2026</div>';
queued.forEach(function(el){
 var jid=el.dataset.job,cid=el.dataset.cocon,ak=el.dataset.akey;
 if(!jid||!cid||!ak)return;
 var row=document.createElement('div');
 row.style.cssText='font-size:12px;padding:4px 0;';
 row.textContent='Reprise job '+jid.substring(0,8)+'\u2026';
 if(le)le.appendChild(row);
 poll(jid,cid,ak,row,function(){htsLoadCoconLogs()})
});
})();

/* ═══ LAZY-LOAD: Recommended links (deferred from page render for perf) ═══ */
(function(){
 var cocons=<?php echo wp_json_encode( array_keys( array_filter( $plans, function($p){ return ($p['status']??'') === 'success'; } ) ) ); ?>;
 if(!cocons.length)return;
 var i=0;
 function loadNext(){
 if(i>=cocons.length)return;
 var cid=cocons[i++];
 htsPost('hts_cocon_get_recommended_links',{cocon_id:cid}).then(function(r){
 if(r.success&&r.data.links&&r.data.links.length){
 var box=document.getElementById('hts-rec-links-'+cid);
 if(!box){loadNext();return}
 box.style.display='block';
 box.querySelector('.hts-rec-count').textContent='('+r.data.links.length+')';
 var list=box.querySelector('.hts-rec-list'),h='';
 r.data.links.forEach(function(rl){
 h+='<div class="hts-rec-link"><span style="color:var(--hts-geo);">\u2192</span>'
 +'<a href="'+esc(rl.url)+'" target="_blank" style="flex:1;color:var(--hts-text);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="'+esc(rl.title)+'">'+esc((rl.title||'').substring(0,40))+'</a>'
 +(rl.anchor_text?'<span style="font-size:8px;color:var(--hts-text-2);flex-shrink:0;">\u201c'+esc((rl.anchor_text||'').substring(0,20))+'\u201d</span>':'')
 +'</div>';
 });
 list.innerHTML=h;
 }
 loadNext();
 }).catch(function(){loadNext()});
 }
 // Start loading after 500ms (let page render first)
 setTimeout(loadNext,500);
})();

/* ═══ MONEY PAGES PANEL — Toggle, Search, Add Manual ═══ */
window.htsMpTogglePanel=function(){
 var body=document.getElementById('hts-mp-body'),arrow=document.getElementById('hts-mp-toggle-arrow');
 if(!body)return;
 var isOpen=body.classList.contains('open');
 body.classList.toggle('open');
 if(arrow)arrow.classList.toggle('open');
};
window.htsMpBulkSelect=function(state){
 document.querySelectorAll('.hts-mp-row:not(.dismissed)').forEach(function(row){
  if(row.style.display==='none') return;
  var cb=row.querySelector('input[type=checkbox]');
  if(!cb||cb.checked===state) return;
  cb.checked=state;
  // Update slider visual without triggering onchange AJAX
  var sl=cb.nextElementSibling;
  if(sl&&sl.classList.contains('slider')){
   sl.style.background=state?'var(--hts-geo,#6366f1)':'var(--hts-border,#d1d5db)';
  }
  // Update row visual — only remove dismissed on select, never add it (dismissed = explicit user dismiss only)
  if(state) row.classList.remove('dismissed');
 });
 // Update badge count
 var badge=document.querySelector('.hts-mp-header .hts-cc-badge');
 if(badge){
  var ct=document.querySelectorAll('.hts-mp-row input[type=checkbox]:checked').length;
  badge.textContent=ct+' active'+(ct>1?'s':'');
 }
};
window.htsMpTogglePage=function(postId,mpType,checkbox){
 if(!checkbox.checked){
 /* Pass checkbox so htsMcDismiss can restore it on cancel/error */
 htsMcDismiss(postId,mpType,checkbox);
 }
 /* Show refresh banner when toggles change */
 var rb=document.getElementById('hts-refresh-groups-banner');
 if(rb)rb.style.display='flex';
};

window.htsMpToggleDismissed=function(){
 var el=document.getElementById('hts-mp-dismissed-list'),arrow=document.getElementById('hts-mp-dismissed-arrow');
 if(el){
 var show=el.style.display==='none'||el.style.display==='';
 el.style.display=show?'block':'none';
 if(arrow)arrow.textContent=show?'▼':'▶';
 }
};

/* Search + Auto-open on DOM ready */
var _htsMpSearchTimer=null;
document.addEventListener('DOMContentLoaded',function(){
 /* ── PERF: Deferred money pages discovery (avoid 504 on page load) ── */
 <?php if ( $money_needs_discovery ) : ?>
 htsPost('hts_discover_money_pages',{}).then(function(r){
  if(r&&r.success) location.reload();
 });
 <?php endif; ?>

 /* ── Auto-switch tab from URL ?tab=redaction ── */
 var urlTab=new URLSearchParams(window.location.search).get('tab');
 if(urlTab&&typeof htsCCTab==='function')htsCCTab(urlTab);

 /* Auto-open the panel */
 var panelBody=document.getElementById('hts-mp-body'),panelArrow=document.getElementById('hts-mp-toggle-arrow');
 if(panelBody){panelBody.classList.add('open');if(panelArrow)panelArrow.classList.add('open');}

 var input=document.getElementById('hts-mp-search');
 if(!input)return;
 input.addEventListener('input',function(){
 clearTimeout(_htsMpSearchTimer);
 var q=this.value.trim();
 if(q.length<2){htsMpCloseResults();return;}
 _htsMpSearchTimer=setTimeout(function(){htsMpSearch(q)},350);
 });
 input.addEventListener('focus',function(){
 if(this.value.trim().length>=2)htsMpSearch(this.value.trim());
 });
 document.addEventListener('click',function(e){
 var wrap=document.getElementById('hts-mp-search-wrap');
 if(wrap&&!wrap.contains(e.target))htsMpCloseResults();
 });
});

function htsMpSearch(q){
 htsPost('hts_search_pages_for_money',{q:q}).then(function(r){
 if(!r.success||!r.data||!r.data.pages){htsMpCloseResults();return;}
 var box=document.getElementById('hts-mp-results'),h='';
 if(r.data.pages.length===0){
 h='<div style="padding:14px;text-align:center;color:var(--hts-text-3);font-size:11px;">Aucun résultat pour « '+esc(q)+'»</div>';
 }else{
 r.data.pages.forEach(function(p){
 var typeMap={page:'Page',post:'Article',product:'Produit'};
 var typeLabel=typeMap[p.type]||p.type;
 if(p.already){
 h+='<div class="hts-mp-result already" onclick="htsMpAddManual('+p.id+',this)" title="Promouvoir en page business manuelle"><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+esc(p.title)+'</span><span class="r-type">'+typeLabel+'</span><span style="font-size:10px;color:var(--hts-geo);font-weight:600;flex-shrink:0;">+ Activer</span></div>';
 }else{
 h+='<div class="hts-mp-result" onclick="htsMpAddManual('+p.id+',this)"><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+esc(p.title)+'</span><span class="r-type">'+typeLabel+'</span><span style="font-size:10px;color:var(--hts-geo);font-weight:600;flex-shrink:0;">+ Ajouter</span></div>';
 }
 });
 }
 box.innerHTML=h;box.classList.add('open');
 }).catch(function(){htsMpCloseResults()});
}

function htsMpCloseResults(){var box=document.getElementById('hts-mp-results');if(box){box.classList.remove('open');box.innerHTML='';}}

window.htsMpAddManual=function(postId,el){
 if(el){el.style.opacity='.5';el.style.pointerEvents='none';el.querySelector('span:last-child').textContent='';}
 htsPost('hts_add_manual_money_page',{post_id:postId}).then(function(r){
 if(r.success){
 toast('Page business ajout\u00e9e : '+r.data.title,'success');
 htsMpCloseResults();
 document.getElementById('hts-mp-search').value='';
 /* Show refresh groups banner — user must click "Mettre à jour" to create cluster */
 var rb=document.getElementById('hts-refresh-groups-banner');
 if(rb)rb.style.display='flex';
 /* Reload page to show the new money page in the list */
 setTimeout(function(){location.reload()},1000);
 }else{
 toast(r.data||'Erreur','error');
 if(el){el.style.opacity='1';el.style.pointerEvents='';el.querySelector('span:last-child').textContent='+ Ajouter';}
 }
 }).catch(function(){
 toast('Erreur r\u00e9seau','error');
 if(el){el.style.opacity='1';el.style.pointerEvents='';el.querySelector('span:last-child').textContent='+ Ajouter';}
 });
};

/* ═══ MONEY COCON — Discovery & Dismiss ═══ */
window.htsMcDiscover=function(btn){
 btn.disabled=true;var origText=btn.textContent;btn.textContent='Analyse…';
 htsPost('hts_discover_money_pages',{}).then(function(r){
 if(r.success){
 toast(r.data.count+' page(s) business détectée(s) sur '+r.data.total_scanned+' analysées','success');
 setTimeout(function(){location.reload()},1200);
 }else if(r.data&&r.data.message==='use_batch'&&window.htsJobPoller){
 /* Serveur limité — switch automatique vers le batch */
 btn.textContent='Analyse par lots…';
 htsJobPoller.start({
  initAction:r.data.batch_init,stepAction:r.data.batch_step,nonce:htsNonce,params:{},
  onProgress:function(d){btn.textContent='Analyse… '+(d.progress||0)+'%';},
  onComplete:function(d){toast((d.count||0)+' page(s) business détectée(s)','success');setTimeout(function(){location.reload()},1200);},
  onError:function(msg){btn.disabled=false;btn.textContent=origText;toast(msg,'error');}
 });
 }else{
 btn.disabled=false;btn.textContent=origText;toast(r.data&&r.data.message?r.data.message:'Erreur','error');
 }
 }).catch(function(){btn.disabled=false;btn.textContent=origText;toast('Erreur réseau','error')});
};
window.htsMcDismiss=function(postId,mpType,toggleEl){
 htsModalConfirm('Masquer cette page ?','Elle ne sera plus proposée comme page business. Vous pourrez la restaurer à tout moment.','Masquer','').then(function(ok){
 if(!ok){
 /* User cancelled — restore the toggle switch if it was a checkbox */
 if(toggleEl&&toggleEl.type==='checkbox')toggleEl.checked=true;
 return;
 }
 var uid=mpType+'-'+postId;
 var card=document.getElementById('hts-mp-card-'+uid);
 if(card){card.style.transition='all .3s';card.style.opacity='0';card.style.height='0';card.style.padding='0';card.style.margin='0';card.style.overflow='hidden';}
 htsPost('hts_dismiss_money_page',{post_id:postId,mp_type:mpType}).then(function(r){
 if(r.success){
 toast('Page masquée','success');
 setTimeout(function(){if(card)card.remove()},350);
 }else{
 toast(r.data||'Erreur','error');
 if(toggleEl&&toggleEl.type==='checkbox')toggleEl.checked=true;
 if(card){card.style.opacity='1';card.style.height='';card.style.padding='';card.style.margin='';card.style.overflow='';}
 }
 }).catch(function(){
 toast('Erreur réseau','error');
 if(toggleEl&&toggleEl.type==='checkbox')toggleEl.checked=true;
 if(card){card.style.opacity='1';card.style.height='';card.style.padding='';card.style.margin='';card.style.overflow='';}
 });
 });
};
window.htsMcRestore=function(postId,mpType,btn){
 btn.disabled=true;btn.textContent='';
 htsPost('hts_restore_money_page',{post_id:postId,mp_type:mpType}).then(function(r){
 if(r.success){
 toast('Page restaurée — rechargement…','success');
 setTimeout(function(){location.reload()},1200);
 }else{btn.disabled=false;btn.textContent='↩';toast(r.data||'Erreur','error');}
 }).catch(function(){btn.disabled=false;btn.textContent='↩';toast('Erreur réseau','error')});
};
/* ═══ MONEY COCON — Auto Mode (progressive cluster-by-cluster) ═══ */
window.htsMcAutoRun=function(btn){
 htsModalConfirm('Envoyer les propositions de maillage ?','Pour chaque cluster, des propositions de liens seront envoyées dans l\u0027Inbox. Vous pourrez valider ou rejeter chaque lien avant application.','Envoyer','primary').then(function(ok){
 if(!ok)return;
 btn.disabled=true;btn.textContent='Traitement…';
 /* Ensure panel body is open so progress is visible */
 var body=document.getElementById('hts-mp-body');if(body&&!body.classList.contains('open')){body.classList.add('open');var arr=document.getElementById('hts-mp-toggle-arrow');if(arr)arr.classList.add('open');}
 var prog=document.getElementById('hts-mc-auto-progress');if(prog){prog.style.display='block';prog.scrollIntoView({behavior:'smooth',block:'nearest'});}
 var statusEl=document.getElementById('hts-mc-auto-status');
 var barEl=document.getElementById('hts-mc-auto-bar');
 var clusters=window._htsClusterNames||[];
 /* Fallback: if no cluster list available, use the legacy single-call endpoint */
 if(!clusters.length){
  htsPost('hts_auto_money_cocons',{}).then(function(r){
   if(!r.success&&r.data&&r.data.message==='use_batch'&&window.htsJobPoller){
    if(statusEl)statusEl.textContent='Traitement par lots…';
    htsJobPoller.start({initAction:r.data.batch_init,stepAction:r.data.batch_step,nonce:htsNonce,params:{},
     onProgress:function(d){if(statusEl)statusEl.textContent=(d.message||'En cours…');if(barEl)barEl.style.width=(d.progress||0)+'%';},
     onComplete:function(d){toast('Maillage terminé !','success');setTimeout(function(){location.reload()},1200);},
     onError:function(msg){btn.disabled=false;btn.textContent='Relancer';toast(msg,'error');}
    });return;
   }
   _htsMcAutoShowResult(btn,r);
  }).catch(function(){btn.disabled=false;btn.style.display='inline-flex';btn.textContent='Relancer';var pg=document.getElementById('hts-mc-auto-progress');if(pg)pg.style.display='none';var st=document.getElementById('hts-mc-auto-status');if(st)st.innerHTML='Le traitement continue en arri\u00e8re-plan. <a href="'+htsAdmin.adminUrl+'admin.php?page=hts-inbox" style="color:var(--hts-primary);text-decoration:underline;">V\u00e9rifiez l\u0027Inbox</a> dans quelques instants.';else toast('Le traitement continue — v\u00e9rifiez l\u0027Inbox','info')});
  return;
 }
 /* Progressive: iterate cluster by cluster */
 (async function(){
  var totalProposed=0,totalDone=0,totalSkipped=0,details=[];
  for(var i=0;i<clusters.length;i++){
   var pct=Math.round(((i)/clusters.length)*100);
   if(statusEl)statusEl.textContent='Groupe '+(i+1)+'/'+clusters.length+' : '+clusters[i];
   if(barEl)barEl.style.width=pct+'%';
   try{
    var r=await htsPost('hts_cocon_link_cluster',{cluster:clusters[i]});
    if(r&&r.success&&r.data){
     var d=r.data;
     totalProposed+=(d.proposed||0);
     totalDone+=(d.done||0);
     totalSkipped+=(d.skipped||0);
     details.push({cluster:d.cluster||clusters[i],links_added:d.proposed||0,done:d.done||0,skipped:d.skipped||0});
    }else{
     details.push({cluster:clusters[i],links_added:0,done:0,skipped:0,error:(r&&r.data)?r.data:'Erreur'});
    }
   }catch(e){
    console.warn('Cluster error:',clusters[i],e);
    details.push({cluster:clusters[i],links_added:0,done:0,skipped:0,error:'Timeout — voir Inbox'});
   }
  }
  if(barEl)barEl.style.width='100%';
  /* Build a synthetic response matching the legacy format for _htsMcAutoShowResult */
  var synthResp={success:true,data:{
   money_pages_processed:clusters.length,
   total_links_added:totalProposed,
   total_cocon_pages:totalProposed+totalDone+totalSkipped,
   total_budget_full:0,
   details:details
  }};
  _htsMcAutoShowResult(btn,synthResp);
 })();
 });
};
/* Shared result renderer for both legacy and progressive modes */
function _htsMcAutoShowResult(btn,r){
 btn.style.display='none';
 document.getElementById('hts-mc-auto-progress').style.display='none';
 var res=document.getElementById('hts-mc-auto-result');res.style.display='block';
 if(r.success){
 var d=r.data||{},h='<div style="font-size:44px;margin-bottom:8px;"></div>'
 +'<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px;">Propositions envoyées !</div>'
 +'<div style="font-size:12px;color:var(--hts-text-2);margin-bottom:16px;">'+(d.money_pages_processed||0)+' cluster(s) · '+(d.total_links_added||0)+' propositions \u2192 Inbox</div>'
 +'<div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:16px;">'
 +'<div style="padding:10px 16px;background:var(--hts-accent-bg);border:1px solid var(--hts-accent);border-radius:10px;text-align:center;"><div style="font-size:20px;font-weight:800;color:var(--hts-accent);">'+(d.total_links_added||0)+'</div><div style="font-size:9px;color:var(--hts-accent);">propositions</div></div>'
 +'<div style="padding:10px 16px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:10px;text-align:center;"><div style="font-size:20px;font-weight:800;color:var(--hts-text);">'+(d.total_cocon_pages||0)+'</div><div style="font-size:9px;color:var(--hts-text-2);">articles analys\u00e9s</div></div>';
 if((d.total_budget_full||0)>0)h+='<div style="padding:10px 16px;background:var(--hts-danger-bg);border:1px solid var(--hts-danger-bg);border-radius:10px;text-align:center;"><div style="font-size:20px;font-weight:800;color:var(--hts-danger);">'+d.total_budget_full+'</div><div style="font-size:9px;color:var(--hts-danger);">satur\u00e9s</div></div>';
 h+='</div>';
 if(d.details&&d.details.length>0){
 h+='<div style="text-align:left;border:1px solid var(--hts-border);border-radius:8px;overflow:hidden;margin-bottom:14px;">';
 d.details.forEach(function(dd,i){
 var clName=dd.cluster||'';
 h+='<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;font-size:11px;'+(i>0?'border-top:1px solid var(--hts-surface);':'')+'">'
 +'<span style="flex:1;font-weight:600;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="'+esc(clName)+'">'+esc(clName)+'</span>'
 +'<span class="hts-cc-badge green">+'+(dd.links_added||0)+'</span>'
 +(dd.error?'<span class="hts-cc-badge red">'+esc(dd.error)+'</span>':'')+'</div>';
 });
 h+='</div>';
 }
 h+='<div style="padding:8px 12px;background:var(--hts-info-bg);border:1px solid var(--hts-info-bg);border-radius:8px;font-size:10px;color:var(--hts-info);text-align:left;"> Rendez-vous dans l\u0027Inbox pour valider et appliquer les liens.</div>';
 res.innerHTML=h;toast((d.total_links_added||0)+' propositions envoy\u00e9es','success');
 /* Reload to show clusters now that maillage is done */
 setTimeout(function(){location.reload()},3000);
 }else{
 res.innerHTML='<div style="color:var(--hts-danger);font-size:13px;"> '+esc(r.data||'Erreur')+'</div>';
 btn.style.display='inline-flex';btn.disabled=false;btn.textContent='Relancer';
 }
}

/* ═══ MONEY COCON — Manual: Build (Step 1→2) ═══ */
var _htsMcMoney=null,_htsMcArticles=[];

window.htsMcBuild=function(mpId,el){
 var origText='';
 if(el&&el.tagName==='BUTTON'){origText=el.textContent;el.disabled=true;el.textContent='';}
 htsPost('hts_build_money_cocon',{money_page_id:mpId}).then(function(r){
 if(el&&el.tagName==='BUTTON'){el.disabled=false;el.textContent=origText;}
 if(!r.success){toast(r.data||'Erreur','error');return}
 _htsMcMoney=r.data;
 _htsMcArticles=(r.data.cocon_pages||[]).concat(r.data.orphan_candidates||[]);
 _htsMcArticles.forEach(function(a){
 a._checked=(a.source==='cluster')||(a.similarity>=0.40);
 a._role=(['transactional','commercial'].indexOf(a.intent)!==-1)?'support':'info';
 });
 /* Show the manual-view container + ensure panel is open */
 var mv=document.getElementById('hts-mc-manual-view');if(mv)mv.style.display='block';
 var body=document.getElementById('hts-mp-body');if(body&&!body.classList.contains('open')){body.classList.add('open');var arr=document.getElementById('hts-mp-toggle-arrow');if(arr)arr.classList.add('open');}
 htsMcRenderStep2(r.data.money_page);
 document.getElementById('hts-mc-step1').style.display='none';
 document.getElementById('hts-mc-step2').style.display='block';
 document.getElementById('hts-mc-step3').style.display='none';
 /* Scroll to the build area */
 if(mv)mv.scrollIntoView({behavior:'smooth',block:'start'});
 }).catch(function(){if(el&&el.tagName==='BUTTON'){el.disabled=false;el.textContent=origText;}toast('Erreur réseau','error')});
};

function htsMcRenderStep2(mp){
 var c=document.getElementById('hts-mc-step2'),h='';
 // Header money page
 h+='<div style="padding:12px;margin-bottom:10px;border-left:3px solid var(--hts-caution);background:var(--hts-caution-bg);border-radius:0 10px 10px 0;display:flex;align-items:center;gap:8px;">'
 +'<span style="font-size:18px;"></span><div><div style="font-size:13px;font-weight:700;color:var(--hts-caution);">'+esc(mp.title)+'</div>'
 +'<div style="font-size:10px;color:var(--hts-caution);font-family:monospace;">'+esc(mp.url)+'</div></div></div>';
 // Budget legend
 h+='<div style="display:flex;gap:10px;margin-bottom:12px;padding:6px 10px;background:var(--hts-surface);border-radius:6px;font-size:10px;color:var(--hts-text-2);align-items:center;flex-wrap:wrap;">'
 +'<span style="font-weight:700;color:var(--hts-text);">Budget liens :</span><span> OK</span><span> Presque plein</span><span style="color:var(--hts-danger);"> Saturé</span></div>';
 // Groups
 var sources={cluster:{icon:'',label:'Même thématique'},semantic:{icon:'',label:'Proches sémantiquement'},other_cluster:{icon:'',label:'Autres clusters'},orphan:{icon:'',label:'Candidats optionnels'}};
 var groups={};_htsMcArticles.forEach(function(a){var s=a.source||'orphan';if(!groups[s])groups[s]=[];groups[s].push(a)});
 ['cluster','semantic','other_cluster','orphan'].forEach(function(src){
 if(!groups[src]||!groups[src].length)return;
 var g=groups[src],sl=sources[src]||sources.orphan,ck=g.filter(function(a){return a._checked}).length;
 h+='<div style="margin-bottom:12px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">'
 +'<span style="font-size:12px;font-weight:700;color:var(--hts-text);">'+sl.icon+''+sl.label+'<span style="font-weight:400;color:var(--hts-text-3);">('+ck+'/'+g.length+')</span></span>'
 +'<button class="hts-cc-btn sm" onclick="htsMcSelectAll(\''+src+'\')">Tout cocher</button></div>';
 g.forEach(function(a){
 var bPct=Math.min(100,((a.links_existing||0)/Math.max(1,a.links_target||8))*100);
 var bFull=(a.links_existing||0)>=(a.links_target||8);
 var bCol=bFull?'var(--hts-danger)':bPct>75?'var(--hts-caution)':'var(--hts-success)';
 var cls='hts-mc-article '+(a._checked?'checked':'unchecked')+(a._checked&&bFull&&!a.has_link?'budget-full':'');
 var intMap={transactional:['','Achat','orange'],commercial:['','Décision','blue'],info:['','Découverte','gray']};
 var inte=intMap[a.intent]||intMap.info;
 h+='<div class="'+cls+'" id="hts-mc-art-'+a.id+'">'
 +'<div class="hts-mc-cb '+(a._checked?'on':'')+'" onclick="htsMcToggle('+a.id+')"></div>'
 +'<div style="flex:1;min-width:0;"><div style="font-size:11px;font-weight:600;color:var(--hts-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+esc(a.title)+'</div>'
 +'<div style="display:flex;gap:4px;margin-top:2px;align-items:center;flex-wrap:wrap;">'
 +'<span class="hts-cc-badge '+inte[2]+'">'+inte[0]+''+inte[1]+'</span>'
 +'<span style="font-size:9px;color:var(--hts-text-3);">'+(a.word_count||0)+'mots</span>'
 +(a.similarity<1?'<span style="font-size:9px;color:var(--hts-text-3);">~'+Math.round(a.similarity*100)+'%</span>':'')
 +(a.has_link?'<span class="hts-cc-badge green"> lié</span>':'')
 +'</div></div>'
 +'<div class="hts-budget-bar"><div class="hts-budget-track"><div class="hts-budget-fill" style="width:'+bPct+'%;background:'+bCol+';"></div></div>'
 +'<span style="font-size:9px;color:'+bCol+';font-weight:'+(bFull?'700':'400')+';">'+(a.links_existing||0)+'/'+(a.links_target||8)+(bFull?'':'')+'</span></div>'
 +(a._checked&&!bFull?'<button class="hts-mc-role-btn" id="hts-mc-role-'+a.id+'" onclick="htsMcFlipRole('+a.id+')" style="background:'+(a._role==='support'?'var(--hts-accent-bg)':'var(--hts-surface)')+';color:'+(a._role==='support'?'var(--hts-accent)':'var(--hts-text-2)')+';">'+(a._role==='support'?'Soutien':'Fond')+'↕</button>':'')
 +'</div>';
 });
 h+='</div>';
 });
 // Sticky bar
 h+='<div class="hts-mc-sticky" id="hts-mc-sticky2"><div id="hts-mc-summary2" style="display:flex;gap:8px;align-items:center;">'+htsMcSummary()+'</div>'
 +'<div style="display:flex;gap:6px;"><button class="hts-cc-btn outline" onclick="htsMcBackToStep1()">← Retour</button>'
 +'<button class="hts-cc-btn primary" id="hts-mc-next-btn" onclick="htsMcGoStep3()">Prévisualiser →</button></div></div>';
 c.innerHTML=h;
}

function htsMcSummary(){
 var ck=_htsMcArticles.filter(function(a){return a._checked});
 var wa=ck.filter(function(a){return !a.has_link&&!((a.links_existing||0)>=(a.links_target||8))});
 var bf=ck.filter(function(a){return !a.has_link&&(a.links_existing||0)>=(a.links_target||8)});
 return '<span style="font-size:12px;font-weight:700;">'+ck.length+'sélectionnés</span>'
 +'<span class="hts-cc-badge green">+'+wa.length+'liens</span>'
 +(bf.length>0?'<span class="hts-cc-badge red"> '+bf.length+'saturés</span>':'');
}

window.htsMcToggle=function(id){
 var a=_htsMcArticles.find(function(x){return x.id===id});if(!a)return;
 a._checked=!a._checked;
 var el=document.getElementById('hts-mc-art-'+id),cb=el.querySelector('.hts-mc-cb');
 var bFull=(a.links_existing||0)>=(a.links_target||8);
 el.className='hts-mc-article '+(a._checked?'checked':'unchecked')+(a._checked&&bFull&&!a.has_link?'budget-full':'');
 cb.className='hts-mc-cb'+(a._checked?'on':'');
 var s=document.getElementById('hts-mc-summary2');if(s)s.innerHTML=htsMcSummary();
};

window.htsMcFlipRole=function(id){
 var a=_htsMcArticles.find(function(x){return x.id===id});if(!a)return;
 a._role=a._role==='support'?'info':'support';
 var btn=document.getElementById('hts-mc-role-'+id);
 if(btn){btn.style.background=a._role==='support'?'var(--hts-accent-bg)':'var(--hts-surface)';btn.style.color=a._role==='support'?'var(--hts-accent)':'var(--hts-text-2)';btn.textContent=(a._role==='support'?'Soutien':'Fond')+'↕';}
};

window.htsMcSelectAll=function(src){
 _htsMcArticles.forEach(function(a){
 if(a.source===src&&!a._checked){a._checked=true;var el=document.getElementById('hts-mc-art-'+a.id);if(el){el.className='hts-mc-article checked';el.querySelector('.hts-mc-cb').className='hts-mc-cb on';}}
 });
 var s=document.getElementById('hts-mc-summary2');if(s)s.innerHTML=htsMcSummary();
};

window.htsMcBackToStep1=function(){
 /* Hide the entire build area — money page list in the panel IS step 1 */
 var mv=document.getElementById('hts-mc-manual-view');if(mv)mv.style.display='none';
 document.getElementById('hts-mc-step1').style.display='none';
 document.getElementById('hts-mc-step2').style.display='none';
 document.getElementById('hts-mc-step3').style.display='none';
};

/* ═══ MONEY COCON — Manual: Preview (Step 2→3) ═══ */
window.htsMcGoStep3=function(){
 var mp=_htsMcMoney.money_page;
 var ck=_htsMcArticles.filter(function(a){return a._checked});
 var wa=ck.filter(function(a){return !a.has_link&&!((a.links_existing||0)>=(a.links_target||8))});
 var bf=ck.filter(function(a){return !a.has_link&&(a.links_existing||0)>=(a.links_target||8)});
 var al=ck.filter(function(a){return a.has_link});
 var sup=ck.filter(function(a){return a._role==='support'});
 var inf=ck.filter(function(a){return a._role==='info'});
 if(wa.length===0){toast('Aucun lien à ajouter','error');return}
 // Store confirm data
 var pids=ck.map(function(a){return a.id}),roles={};ck.forEach(function(a){roles[a.id]=a._role});
 window._htsMcConfirm={money_page_id:mp.id,page_ids:pids,roles:roles};
 var c=document.getElementById('hts-mc-step3'),h='';
 h+='<div style="padding:12px;margin-bottom:10px;border-left:3px solid var(--hts-caution);background:var(--hts-caution-bg);border-radius:0 10px 10px 0;">'
 +'<div style="font-size:13px;font-weight:700;color:var(--hts-caution);"> '+esc(mp.title)+'</div>'
 +'<div style="font-size:10px;color:var(--hts-caution);">'+ck.length+'articles · '+al.length+'déjà liés · '+wa.length+'liens à créer</div></div>';
 h+='<div style="background:#fff;border:1px solid var(--hts-border);border-radius:10px;padding:14px;margin-bottom:12px;">'
 +'<div style="font-size:13px;font-weight:700;color:var(--hts-text);margin-bottom:10px;">Ce qui va se passer</div>';
 h+='<div class="hts-mc-step" style="background:var(--hts-caution-bg);">1⃣ <div style="flex:1;"><strong>'+wa.length+'articles</strong> recevront un lien vers votre page business</div><span class="hts-cc-badge orange">→ </span></div>';
 if(sup.length>0&&inf.length>0)h+='<div class="hts-mc-step" style="background:var(--hts-accent-bg);">2⃣ <div style="flex:1;">Les <strong>articles de fond</strong> lieront aussi vers un <strong>article de soutien</strong></div><span class="hts-cc-badge blue"> → </span></div>';
 if(sup.length>0)h+='<div class="hts-mc-step" style="background:var(--hts-geo-soft);">3⃣ <div style="flex:1;">Votre page business liera vers <strong>'+Math.min(3,sup.length)+'article(s) de soutien</strong><br><span style="font-size:10px;color:var(--hts-text-3);">Renforce votre expertise aux yeux de Google</span></div><span class="hts-cc-badge gray"> → </span></div>';
 if(bf.length>0)h+='<div class="hts-mc-step" style="background:var(--hts-danger-bg);"> <div style="flex:1;"><strong>'+bf.length+'article(s) ignoré(s)</strong> — trop de liens existants</div><span class="hts-cc-badge red">saturé</span></div>';
 if(al.length>0)h+='<div style="font-size:11px;color:var(--hts-text-3);padding-left:10px;">ℹ '+al.length+'déjà lié(s) — ignorés</div>';
 h+='</div>';
 h+='<div style="padding:8px 12px;background:var(--hts-caution-bg);border:1px solid var(--hts-caution);border-radius:8px;font-size:11px;color:var(--hts-caution);margin-bottom:14px;"> <strong>Réversible</strong> — chaque lien est tracé</div>';
 h+='<div style="display:flex;justify-content:space-between;"><button class="hts-cc-btn outline" onclick="htsMcBackToStep2()">← Modifier</button>'
 +'<button class="hts-cc-btn primary" id="hts-mc-apply-btn" style="font-size:13px;padding:12px 24px;background:var(--hts-success);" onclick="htsMcApply()"> Appliquer ('+wa.length+'liens)</button></div>';
 c.innerHTML=h;
 document.getElementById('hts-mc-step2').style.display='none';
 document.getElementById('hts-mc-step3').style.display='block';
};

window.htsMcBackToStep2=function(){
 document.getElementById('hts-mc-step2').style.display='block';
 document.getElementById('hts-mc-step3').style.display='none';
};

/* ═══ MONEY COCON — Manual: Apply ═══ */
window.htsMcApply=function(){
 var btn=document.getElementById('hts-mc-apply-btn');btn.disabled=true;btn.textContent='Application…';
 var cd=window._htsMcConfirm;
 if(!cd||!cd.money_page_id){btn.disabled=false;btn.textContent='Erreur';toast('Données manquantes','error');return}
 htsPost('hts_confirm_money_cocon',{money_page_id:cd.money_page_id,page_ids:cd.page_ids,roles:cd.roles}).then(function(r){
 if(!r.success)throw new Error(r.data||'Erreur confirmation');
 return htsPost('hts_apply_money_maillage',{money_page_id:cd.money_page_id});
 }).then(function(r){
 if(!r.success)throw new Error(r.data||'Erreur maillage');
 var d=r.data||{},c=document.getElementById('hts-mc-step3');
 c.innerHTML='<div style="text-align:center;padding:32px 20px;">'
 +'<div style="font-size:44px;margin-bottom:8px;"></div>'
 +'<div style="font-size:16px;font-weight:800;color:var(--hts-text);margin-bottom:4px;">Maillage appliqué</div>'
 +'<div style="font-size:12px;color:var(--hts-text-2);margin-bottom:16px;">'+(d.links_added||0)+'liens créés'+((d.budget_full||0)>0?'· '+d.budget_full+'saturés':'')+((d.money_outlinks||0)>0?'· page business → '+d.money_outlinks+'soutien':'')+'</div>'
 +'<div style="padding:8px 12px;background:var(--hts-info-bg);border:1px solid var(--hts-info-bg);border-radius:8px;font-size:10px;color:var(--hts-info);margin-bottom:16px;"> Revenez dans quelques semaines pour l\u0027impact Search Console.</div>'
 +'<button class="hts-cc-btn primary" onclick="htsMcBackToStep1();document.getElementById(\'hts-mc-step3\').style.display=\'none\';">← Retour</button></div>';
 toast((d.links_added||0)+'liens créés','success');
 setTimeout(function(){location.reload()},3000);
 }).catch(function(err){btn.disabled=false;btn.textContent='Erreur';toast(err.message||'Erreur réseau','error')});
};

/* ═══ LAZY-LOAD: Logs ═══ */
setTimeout(function(){htsLoadCoconLogs()},800);

/* ═══ Auto-open cluster from dashboard deep link: ?open_cluster=NAME ═══ */
(function(){
	var p=new URLSearchParams(window.location.search);
	var oc=p.get('open_cluster');
	if(!oc)return;
	var tries=0;
	function tryOpen(){
		if(typeof htsCCOpenGraph!=='function'){
			if(++tries<10)setTimeout(tryOpen,500);
			return;
		}
		var cards=document.querySelectorAll('.hts-cocon-card');
		for(var i=0;i<cards.length;i++){
			if(cards[i].dataset.cluster===oc||cards[i].dataset.kw===oc){
				cards[i].scrollIntoView({behavior:'smooth',block:'center'});
				cards[i].click();
				return;
			}
		}
	}
	setTimeout(tryOpen,800);
})();

})();
</script>

<!-- ═══ BACKUP / RESTORE COCON ═══ -->
<?php
$backup_key = ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() )
    ? 'hts_cocon_data_' . ( HTS_Language::get_current_lang() ?: 'fr' ) . '_backup'
    : 'hts_cocon_data_backup';
$backup_ts  = get_option( $backup_key . '_ts', '' );
$has_backup = ! empty( get_option( $backup_key, array() ) );
?>
<div style="margin-top:24px;">
    <div onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'block':'none';this.querySelector('span').textContent=this.nextElementSibling.style.display==='none'?'▶':'▼'" style="cursor:pointer;font-size:12px;color:var(--hts-text-3);padding:8px 0;">
        <span>▶</span> Outils avancés
    </div>
    <div style="display:none;padding:12px 16px;background:var(--hts-surface);border:1px solid var(--hts-border);border-radius:8px;margin-top:4px;">
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button class="hts-cc-btn outline sm" onclick="htsMcDiscover(this)">Re-détecter les pages business</button>
            <button class="hts-cc-btn outline sm" onclick="htsRescanMaillage('all',this)">Re-scanner le maillage</button>
            <button class="hts-cc-btn outline sm" onclick="htsCoconExport()">Exporter JSON</button>
            <?php if ( $_hts_can_write ) : ?>
            <label class="hts-cc-btn outline sm" style="cursor:pointer">
                Importer JSON
                <input type="file" accept=".json" style="display:none" onchange="htsCoconImport(this.files[0])">
            </label>
            <?php endif; ?>
            <?php if ( $has_backup ) : ?>
            <button class="hts-cc-btn outline sm" onclick="htsCoconRestore(this)" style="color:var(--hts-caution);border-color:var(--hts-caution)">Restaurer le backup</button>
            <?php endif; ?>
            <?php if ( $_hts_can_write ) : ?>
            <button class="hts-cc-btn outline sm" onclick="htsResetCocons(this)" style="color:var(--hts-danger);border-color:var(--hts-danger)">Réinitialiser tout</button>
            <?php endif; ?>
        </div>
        <div style="font-size:10px;color:var(--hts-text-3);margin-top:8px;">
            <?php if ( $has_backup && $backup_ts ) : ?>
                Dernier backup : <?php echo esc_html( $backup_ts ); ?>. Un backup est créé automatiquement avant chaque analyse.
            <?php else : ?>
                Un backup est créé automatiquement avant chaque analyse.
            <?php endif; ?>
        </div>
        <div id="hts-cocon-backup-msg" style="display:none;margin-top:10px;padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600"></div>
    </div>
</div>
<script>
function _bMsg(msg,ok){var el=document.getElementById('hts-cocon-backup-msg');el.style.display='block';el.style.background=ok?'var(--hts-success-bg)':'var(--hts-danger-bg)';el.style.color=ok?'var(--hts-success)':'var(--hts-danger)';el.textContent=msg;setTimeout(function(){el.style.display='none'},5000)}
window.htsCoconRestore=function(btn){_htsConfirm('Restaurer le backup ?','Les groupes actuels seront remplacés par la sauvegarde précédente.','Restaurer','danger').then(function(ok){if(!ok)return;btn.disabled=true;btn.textContent='...';htsPost('hts_cocon_restore',{}).then(function(r){btn.disabled=false;btn.textContent='Restaurer le backup';if(r.success){_bMsg(r.data.message,true);setTimeout(function(){location.reload()},1500)}else{_bMsg(r.data&&r.data.message?r.data.message:'Erreur',false)}}).catch(function(){btn.disabled=false;btn.textContent='Restaurer le backup';_bMsg('Erreur réseau',false)})})};
window.htsCoconExport=function(){htsPost('hts_cocon_export',{}).then(function(r){if(r.success){var blob=new Blob([JSON.stringify(r.data.data)],{type:'application/json'});var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='hacktheseo-cocon-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();_bMsg('Export téléchargé ('+r.data.clusters+' groupes, '+r.data.nodes+' pages)',true)}else{_bMsg('Erreur export',false)}})};
window.htsCoconImport=function(file){if(!file)return;var reader=new FileReader();reader.onload=function(e){_htsConfirm('Importer ce fichier ?','Les groupes actuels seront remplac\u00e9s. Un backup sera cr\u00e9\u00e9 automatiquement.','Importer').then(function(ok){if(!ok)return;var fd=new FormData();fd.append('action','hts_cocon_import');fd.append('nonce','<?php echo wp_create_nonce("hts_admin_nonce"); ?>');fd.append('cocon_data',e.target.result);fetch(ajaxurl,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(r){if(r.success){_bMsg(r.data.message,true);setTimeout(function(){location.reload()},1500)}else{_bMsg(r.data&&r.data.message?r.data.message:'Erreur import',false)}}).catch(function(){_bMsg('Erreur r\u00e9seau',false)})})};reader.readAsText(file)};
window.htsCoconPurge=function(btn){var _pl='<?php echo esc_js( $_hts_current_lang ); ?>';_htsConfirm('Tout effacer ('+_pl.toUpperCase()+') ?','Supprime les clusters, pages business et backup pour cette langue. Les articles ne sont PAS supprim\u00e9s. Cette action est irr\u00e9versible.','Tout effacer','danger').then(function(ok){if(!ok)return;btn.disabled=true;btn.textContent='...';jQuery.post(ajaxurl,{action:'hts_cocon_purge',nonce:'<?php echo wp_create_nonce("hts_admin_nonce"); ?>',lang:_pl},function(r){btn.disabled=false;btn.textContent='Tout effacer';if(r.success){_bMsg(r.data.message,true);setTimeout(function(){location.reload()},1500)}else{_bMsg(r.data&&r.data.message?r.data.message:'Erreur',false)}})})};
</script>
<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>
