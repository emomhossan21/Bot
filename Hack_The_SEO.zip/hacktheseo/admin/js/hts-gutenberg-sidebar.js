/**
 * HTS SEO Sidebar — Gutenberg Block Editor Plugin
 *
 * Registers a sidebar panel in the Gutenberg editor showing:
 * - Score ring (SVG) with live updates
 * - Focus keyword badge
 * - Top 3 priority fixes
 * - Quick link to full metabox panel
 *
 * Uses wp.element.createElement (no JSX / no build step required).
 *
 * @since 1.4.8
 */
(function () {
    'use strict';

    /* ── Guard: bail if WP block editor APIs are not available ── */
    if (typeof wp === 'undefined' || !wp.element || !wp.plugins || !wp.data) {
        return;
    }

    /* ── WP dependencies (compat: Gutenberg plugin moved editPost → editor) ── */
    var el         = wp.element.createElement;
    var Fragment   = wp.element.Fragment;
    var useState   = wp.element.useState;
    var useEffect  = wp.element.useEffect;
    var useRef     = wp.element.useRef;
    var registerPlugin = wp.plugins.registerPlugin;

    /* Gutenberg plugin 16+ moved PluginSidebar from wp.editPost to wp.editor */
    var _ed = (wp.editor || {});
    var _ep = (wp.editPost || {});
    var PluginSidebar = _ed.PluginSidebar || _ep.PluginSidebar;
    var PluginSidebarMoreMenuItem = _ed.PluginSidebarMoreMenuItem || _ep.PluginSidebarMoreMenuItem;

    /* Bail if sidebar API not available at all */
    if (!PluginSidebar || !registerPlugin) {
        console.warn('[HTS] Gutenberg sidebar API not available');
        return;
    }

    /* ── Config from wp_localize_script ── */
    var cfg = window.htsSidebar || {};

    /* ── Helpers ── */
    function scoreColor(s) {
        if (s >= 80) return '#16a34a';
        if (s >= 50) return '#d97706';
        return '#dc2626';
    }

    function scoreLabel(s) {
        if (s >= 80) return 'Excellent';
        if (s >= 60) return 'Bon';
        if (s >= 40) return 'Moyen';
        return 'Faible';
    }

    function statusIcon(st) {
        if (st === 'ok')   return '\u2705';
        if (st === 'warn') return '\u26a0\ufe0f';
        return '\u274c';
    }

    /* ── Score Ring SVG component ── */
    function ScoreRing(props) {
        var s = props.score || 0;
        var color = scoreColor(s);
        var circumference = 119.38; // 2 * PI * 19
        var offset = circumference - (circumference * s / 100);

        return el('div', { style: { position: 'relative', width: 64, height: 64, margin: '0 auto 8px' } },
            el('svg', { width: 64, height: 64, style: { transform: 'rotate(-90deg)' } },
                el('circle', { cx: 32, cy: 32, r: 19, fill: 'none', stroke: '#e5e7eb', strokeWidth: 4 }),
                el('circle', {
                    cx: 32, cy: 32, r: 19, fill: 'none',
                    stroke: color, strokeWidth: 4, strokeLinecap: 'round',
                    strokeDasharray: circumference,
                    strokeDashoffset: offset,
                    style: { transition: 'stroke-dashoffset 0.6s ease, stroke 0.3s ease' }
                })
            ),
            el('div', {
                style: {
                    position: 'absolute', inset: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 18, fontWeight: 700, color: color
                }
            }, s)
        );
    }

    /* ── Check Item component ── */
    function CheckItem(props) {
        var c = props.check;
        var colors = { ok: '#16a34a', warn: '#d97706', fail: '#dc2626' };
        var bgColors = { ok: '#f0fdf4', warn: '#fffbeb', fail: '#fef2f2' };

        return el('div', {
            style: {
                display: 'flex', alignItems: 'flex-start', gap: 8,
                padding: '8px 10px', marginBottom: 4,
                background: bgColors[c.status] || '#f8f9fb',
                borderRadius: 6, fontSize: 12, lineHeight: '1.4'
            }
        },
            el('span', { style: { flexShrink: 0, fontSize: 11 } }, statusIcon(c.status)),
            el('span', { style: { color: '#1a1f36' } }, c.text)
        );
    }

    /* ── Group component ── */
    function CheckGroup(props) {
        var g = props.group;
        var failCount = 0, warnCount = 0;
        (g.checks || []).forEach(function (c) {
            if (c.status === 'fail') failCount++;
            else if (c.status === 'warn') warnCount++;
        });

        var badgeColor = failCount > 0 ? '#dc2626' : (warnCount > 0 ? '#d97706' : '#16a34a');
        var badgeBg = failCount > 0 ? '#fef2f2' : (warnCount > 0 ? '#fffbeb' : '#f0fdf4');
        var badgeText = failCount > 0 ? failCount + ' erreur' + (failCount > 1 ? 's' : '') : (warnCount > 0 ? warnCount + ' \u00e0 am\u00e9liorer' : '\u2713');

        return el('div', { style: { marginBottom: 12 } },
            el('div', {
                style: {
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '6px 0', borderBottom: '1px solid #ebeef2', marginBottom: 6
                }
            },
                el('span', { style: { fontSize: 12, fontWeight: 600, color: '#1a1f36' } },
                    g.label, ' ',
                    el('span', { style: { color: '#9da5b4', fontWeight: 400 } }, '(' + g.weight + '%)')
                ),
                el('span', {
                    style: {
                        fontSize: 10, fontWeight: 600, padding: '2px 8px',
                        borderRadius: 10, color: badgeColor, background: badgeBg
                    }
                }, badgeText)
            ),
            (g.checks || []).map(function (c, i) {
                return el(CheckItem, { key: i, check: c });
            })
        );
    }

    /* ── Main Sidebar Panel ── */
    function HTSSidebarPanel() {
        var _s = useState(null);
        var data = _s[0], setData = _s[1];
        var _l = useState(false);
        var loading = _l[0], setLoading = _l[1];
        var prevSig = useRef('');
        var timer = useRef(null);
        var reqRef = useRef(null);

        /* Fetch score from AJAX */
        function fetchScore(live) {
            if (reqRef.current) {
                try { reqRef.current.abort(); } catch (e) {}
            }
            setLoading(true);

            var fd = new FormData();
            fd.append('action', 'hts_panel_score');
            fd.append('nonce', cfg.nonce);
            fd.append('post_id', cfg.postId);

            if (live) {
                var title = '', content = '';
                try {
                    var store = wp.data.select('core/editor');
                    if (store && store.getEditedPostAttribute) title = store.getEditedPostAttribute('title') || '';
                    if (store && store.getEditedPostContent) content = store.getEditedPostContent() || '';
                } catch (e) {}

                /* Read values from metabox fields if they exist */
                var kwEl = document.getElementById('hp-kw');
                var ttEl = document.getElementById('hp-tt');
                var dsEl = document.getElementById('hp-ds');
                var slEl = document.getElementById('hp-slug');

                fd.append('live_kw', kwEl ? kwEl.value : '');
                fd.append('live_title', ttEl ? ttEl.value : '');
                fd.append('live_desc', dsEl ? dsEl.value : '');
                fd.append('live_slug', slEl ? slEl.value : '');
                fd.append('live_post_title', title);
                fd.append('live_content', content);
            }

            var xhr = new XMLHttpRequest();
            reqRef.current = xhr;
            xhr.open('POST', cfg.ajaxUrl, true);
            xhr.onload = function () {
                setLoading(false);
                reqRef.current = null;
                try {
                    var r = JSON.parse(xhr.responseText);
                    if (r.success) {
                        setData({
                            score: r.data.score,
                            color: r.data.color,
                            label: r.data.label,
                            issues: r.data.issues,
                            groups: r.data.groups || [],
                            fixes: r.data.top_fixes || [],
                            debug: r.data.debug || {}
                        });
                    }
                } catch (e) { console.error('[HTS Sidebar]', e); }
            };
            xhr.onerror = function () { setLoading(false); reqRef.current = null; };
            xhr.send(fd);
        }

        /* Subscribe to editor changes */
        useEffect(function () {
            /* Initial fetch */
            fetchScore(false);

            /* Listen for metabox AJAX updates (keyword/meta field changes) */
            function onMetaboxUpdate(e) {
                var d = e.detail;
                if (!d) return;
                setData({
                    score: d.score,
                    color: d.color,
                    label: d.label,
                    issues: d.issues,
                    groups: d.groups || [],
                    fixes: d.top_fixes || [],
                    debug: d.debug || {}
                });
                setLoading(false);
            }
            document.addEventListener('hts:score-updated', onMetaboxUpdate);

            /* djb2 hash */
            function hash(s) {
                var h = 5381;
                for (var i = 0; i < s.length; i++) { h = ((h << 5) + h) + s.charCodeAt(i); h = h & h; }
                return h;
            }

            /* Safely subscribe — some Gutenberg versions crash if store not ready */
            var unsub = null;
            try {
                unsub = wp.data.subscribe(function () {
                    try {
                        var store = wp.data.select('core/editor');
                        if (!store) return;
                        var t = (store.getEditedPostAttribute ? store.getEditedPostAttribute('title') : '') || '';
                        var c = (store.getEditedPostContent ? store.getEditedPostContent() : '') || '';
                        var sig = t + '|' + hash(c);
                        if (sig !== prevSig.current) {
                            prevSig.current = sig;
                            /* Don't fetch here — the metabox will do it and dispatch hts:score-updated */
                            /* Only fetch if metabox hasn't responded in 2s (fallback) */
                            if (timer.current) clearTimeout(timer.current);
                            timer.current = setTimeout(function () { fetchScore(true); }, 2000);
                        }
                    } catch (e) {}
                });
            } catch (e) {
                console.warn('[HTS] wp.data.subscribe failed:', e.message);
            }

            return function () {
                if (unsub) unsub();
                document.removeEventListener('hts:score-updated', onMetaboxUpdate);
                if (timer.current) clearTimeout(timer.current);
            };
        }, []);

        /* ── Render ── */
        var score = data ? data.score : 0;
        var kw = data && data.debug ? data.debug.kw : '';
        var words = data && data.debug ? data.debug.words : 0;

        return el(Fragment, null,
            PluginSidebarMoreMenuItem ? el(PluginSidebarMoreMenuItem, { target: 'hts-seo-sidebar', icon: 'admin-site-alt3' }, 'Hack The SEO') : null,
            el(PluginSidebar, {
                name: 'hts-seo-sidebar',
                title: 'Hack The SEO',
                icon: 'admin-site-alt3'
            },
                el('div', { style: { padding: 16 } },

                    /* ── Score section ── */
                    el('div', {
                        style: {
                            textAlign: 'center', padding: '16px 0',
                            borderBottom: '1px solid #ebeef2', marginBottom: 16,
                            opacity: loading ? 0.5 : 1, transition: 'opacity 0.2s'
                        }
                    },
                        el(ScoreRing, { score: score }),
                        el('div', { style: { fontSize: 13, fontWeight: 600, color: scoreColor(score) } }, scoreLabel(score)),
                        words ? el('div', { style: { fontSize: 11, color: '#9da5b4', marginTop: 4 } }, words + ' mots') : null,
                        kw ? el('div', {
                            style: {
                                display: 'inline-block', marginTop: 8,
                                background: '#eff6ff', color: '#2563eb',
                                fontSize: 11, fontWeight: 600,
                                padding: '3px 12px', borderRadius: 20
                            }
                        }, kw) : el('div', {
                            style: { fontSize: 11, color: '#d97706', marginTop: 8 }
                        }, 'Aucun mot-cl\u00e9 d\u00e9fini')
                    ),

                    /* ── All check groups ── */
                    data && data.groups ? Object.keys(data.groups).map(function (gk) {
                        return el(CheckGroup, { key: gk, group: data.groups[gk] });
                    }) : el('div', { style: { textAlign: 'center', padding: 20, color: '#9da5b4', fontSize: 12 } }, 'Chargement\u2026'),

                    /* ── Penalty ── */
                    data && data.score !== undefined && data.debug && data.debug.penalty > 0 ? el('div', {
                        style: {
                            padding: '8px 12px', background: '#fef2f2', color: '#dc2626',
                            borderRadius: 6, fontSize: 11, marginTop: 8
                        }
                    }, 'Sur-optimisation : -' + data.debug.penalty + ' points') : null,

                    /* ── Scroll to metabox ── */
                    el('div', { style: { marginTop: 16, textAlign: 'center' } },
                        el('button', {
                            type: 'button',
                            onClick: function () {
                                var mb = document.getElementById('hts-seo-panel');
                                if (mb) mb.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            },
                            style: {
                                background: '#f8f9fb', border: '1px solid #dfe3e8', color: '#5e6687',
                                padding: '8px 16px', borderRadius: 6, fontSize: 12, fontWeight: 600,
                                cursor: 'pointer', width: '100%'
                            }
                        }, '\u2193 D\u00e9tails dans le panneau complet')
                    )
                )
            )
        );
    }

    /* ── Register Plugin (deferred to ensure all stores are ready) ── */
    function doRegister() {
        try {
            registerPlugin('hts-seo-sidebar', {
                render: HTSSidebarPanel,
                icon: 'admin-site-alt3'
            });
        } catch (e) {
            console.warn('[HTS] Sidebar registration failed:', e.message);
        }
    }

    if (wp.domReady) {
        wp.domReady(doRegister);
    } else {
        doRegister();
    }

})();
