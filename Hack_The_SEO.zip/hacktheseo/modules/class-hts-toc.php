<?php
defined( 'ABSPATH' ) || exit;
/**
 * Module : Table of Contents automatique
 *
 * Options :
 * - hts_toc_depth : 'h2' (H2 uniquement) ou 'h2h3' (H2 + H3)
 * - hts_toc_style : 'hts' (style HackTheSEO) ou 'minimal' (CSS minimal, hérite du thème)
 * - hts_toc_min   : nombre minimum de titres pour afficher le TOC (défaut 3)
 *
 * @since 2.3.1
 */

class HTS_Table_Of_Contents {

    public function init() {
        if ( get_option( 'hts_module_toc', '0' ) !== '1' ) return;
        add_filter( 'the_content', array( $this, 'inject_toc' ), 15 );
        add_action( 'wp_head', array( $this, 'inject_css' ), 20 );
    }

    public function inject_toc( $content ) {
        if ( ! is_singular( 'post' ) || is_admin() || wp_doing_ajax() ) return $content;

        $depth   = get_option( 'hts_toc_depth', 'h2h3' );
        $min     = (int) get_option( 'hts_toc_min', 3 );
        $pattern = $depth === 'h2' ? '/<(h2)(.*?)>(.*?)<\/\1>/si' : '/<(h[23])(.*?)>(.*?)<\/\1>/si';

        if ( ! preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER ) ) return $content;
        if ( count( $matches ) < $min ) return $content;

        $toc_items = array();
        $used_ids  = array();

        foreach ( $matches as $match ) {
            $tag   = strtolower( $match[1] );
            $attrs = $match[2];
            $raw   = $match[3];
            $title = wp_strip_all_tags( $raw );
            $title = html_entity_decode( $title, ENT_QUOTES, 'UTF-8' );
            $title = trim( $title );

            // Ignorer les titres vides ou trop courts
            if ( mb_strlen( $title ) < 2 ) continue;

            $slug  = $this->slug( $title, $used_ids );
            $used_ids[] = $slug;

            // Vérifier si le heading a déjà un id
            $has_id = preg_match( '/\bid\s*=\s*["\']([^"\']+)["\']/i', $attrs, $id_match );
            if ( $has_id ) {
                $slug = $id_match[1];
            } else {
                // Injecter l'id
                $new_tag = '<' . $tag . ' id="' . esc_attr( $slug ) . '"' . $attrs . '>' . $raw . '</' . $tag . '>';
                $content = str_replace( $match[0], $new_tag, $content );
            }

            $toc_items[] = array(
                'title' => $title,
                'slug'  => $slug,
                'level' => $tag === 'h2' ? 1 : 2,
            );
        }

        $toc_html = $this->render( $toc_items, $depth );

        // Injecter après le premier paragraphe
        $first_p_end = strpos( $content, '</p>' );
        if ( $first_p_end !== false && $first_p_end < 800 ) {
            $pos = $first_p_end + 4;
            $content = substr( $content, 0, $pos ) . "\n" . $toc_html . "\n" . substr( $content, $pos );
        } else {
            $content = $toc_html . "\n" . $content;
        }

        return $content;
    }

    private function render( $items, $depth ) {
        $style = get_option( 'hts_toc_style', 'hts' );
        $class = $style === 'minimal' ? 'hts-toc hts-toc--minimal' : 'hts-toc';

        $html  = '<nav class="' . $class . '" aria-label="Sommaire">';
        $html .= '<div class="hts-toc-header"><span class="hts-toc-title">Sommaire</span></div>';
        $html .= '<ol class="hts-toc-list">';

        foreach ( $items as $item ) {
            if ( $depth === 'h2' && $item['level'] === 2 ) continue; // ne devrait pas arriver
            $sub = $item['level'] === 2 ? ' class="hts-toc-sub"' : '';
            $html .= '<li' . $sub . '><a href="#' . esc_attr( $item['slug'] ) . '">' . esc_html( $item['title'] ) . '</a></li>';
        }

        $html .= '</ol></nav>';
        return $html;
    }

    private function slug( $text, $used ) {
        $s = remove_accents( $text );
        $s = strtolower( $s );
        $s = preg_replace( '/[^a-z0-9]+/', '-', $s );
        $s = trim( $s, '-' );
        if ( empty( $s ) ) $s = 'section';
        $o = $s;
        $c = 2;
        while ( in_array( $s, $used, true ) ) { $s = $o . '-' . $c++; }
        return $s;
    }

    public function inject_css() {
        if ( ! is_singular( 'post' ) || is_admin() ) return;
        $style = get_option( 'hts_toc_style', 'hts' );
        ?>
        <style>
        .hts-toc {
            border-radius: 8px;
            padding: 20px 24px;
            margin: 24px 0;
            font-size: 15px;
            line-height: 1.7;
        }
        <?php if ( $style === 'hts' ) : ?>
        .hts-toc {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-left: 4px solid #3b82f6;
        }
        .hts-toc-title { font-weight: 700; font-size: 16px; color: #1e293b; }
        .hts-toc-list { margin: 12px 0 0; padding: 0; list-style: none; counter-reset: toc-c; }
        .hts-toc-list > li { counter-increment: toc-c; padding: 3px 0; }
        .hts-toc-list > li::before { content: counter(toc-c) ". "; font-weight: 600; color: #3b82f6; }
        .hts-toc-list > li.hts-toc-sub { padding-left: 24px; font-size: 14px; }
        .hts-toc-list > li.hts-toc-sub::before { content: "— "; color: #94a3b8; font-weight: 400; }
        .hts-toc a { color: #334155; text-decoration: none; }
        .hts-toc a:hover { color: #3b82f6; text-decoration: underline; }
        <?php else : /* minimal */ ?>
        .hts-toc--minimal {
            background: transparent;
            border: none;
            border-left: 3px solid currentColor;
            opacity: 0.85;
            padding: 12px 20px;
        }
        .hts-toc--minimal .hts-toc-title { font-weight: 600; }
        .hts-toc--minimal .hts-toc-list { margin: 8px 0 0; padding: 0 0 0 18px; }
        .hts-toc--minimal .hts-toc-list > li { padding: 2px 0; }
        .hts-toc--minimal .hts-toc-list > li.hts-toc-sub { padding-left: 16px; font-size: 0.9em; }
        .hts-toc--minimal a { color: inherit; text-decoration: none; }
        .hts-toc--minimal a:hover { text-decoration: underline; }
        <?php endif; ?>
        </style>
        <?php
    }
}
