<?php
defined( 'ABSPATH' ) || exit;
/**
 * Workflow Engine — Backbone pour les agents SEO.
 *
 * Chaque agent propose des actions (content_refresh, merge, article_write, etc.)
 * Le client les approuve/rejette dans l'Inbox.
 * L'engine dispatch l'exécution vers le bon module.
 *
 * Tables :
 *  - {prefix}_hts_workflow_actions : actions proposées par les agents
 *  - {prefix}_hts_workflow_agents  : config ON/OFF + paramètres par agent
 *
 * @since 1.31.0
 * @package HackTheSEO
 */

class HTS_Workflow_Engine {

    const ACTIONS_TABLE = 'hts_workflow_actions';
    const AGENTS_TABLE  = 'hts_workflow_agents';

    /* Batch sync: collect actions during scan_proposals instead of syncing each individually */
    private static $batch_sync_queue = null; // null = not batching, array = collecting

    /* Statuts d'action */
    const STATUS_PENDING   = 'pending';
    const STATUS_APPROVED  = 'approved';
    const STATUS_REJECTED  = 'rejected';
    const STATUS_DISMISSED = 'dismissed';
    const STATUS_EXECUTING = 'executing';
    const STATUS_DONE      = 'done';
    const STATUS_FAILED    = 'failed';
    const STATUS_BLOCKED   = 'blocked';

    /* Priorités */
    const PRIORITY_LOW      = 'low';
    const PRIORITY_MEDIUM   = 'medium';
    const PRIORITY_HIGH     = 'high';
    const PRIORITY_CRITICAL = 'critical';

    /* Modes d'exécution */
    const MODE_REVIEW = 'review';
    const MODE_AUTO   = 'auto';

    /* Garde-fous par défaut */
    const DEFAULT_MAX_ACTIONS_PER_WEEK = 10;
    const DEFAULT_MAX_BUDGET_PER_MONTH = 50; // en dollars API
    const DEFAULT_TRAFFIC_THRESHOLD    = 100; // clics/mois — ne pas toucher au-dessus

    /* ═══════════════════════════════════════════════
     *  INIT
     * ═══════════════════════════════════════════════ */

    public function __construct() {
        add_action( 'wp_ajax_hts_inbox_list',     array( $this, 'ajax_inbox_list' ) );
        add_action( 'wp_ajax_hts_inbox_approve',  array( $this, 'ajax_inbox_approve' ) );
        add_action( 'wp_ajax_hts_inbox_reject',   array( $this, 'ajax_inbox_reject' ) );
        add_action( 'wp_ajax_hts_inbox_dismiss',  array( $this, 'ajax_inbox_dismiss' ) );
        add_action( 'wp_ajax_hts_inbox_execute',  array( $this, 'ajax_inbox_execute' ) );
        add_action( 'wp_ajax_hts_inbox_batch',    array( $this, 'ajax_inbox_batch' ) );
        add_action( 'wp_ajax_hts_inbox_batch_init', array( $this, 'ajax_inbox_batch_init' ) );
        add_action( 'wp_ajax_hts_inbox_batch_step', array( $this, 'ajax_inbox_batch_step' ) );
        add_action( 'wp_ajax_hts_purge_linking',  array( $this, 'ajax_purge_linking' ) );
        add_action( 'wp_ajax_hts_full_audit',     array( $this, 'ajax_full_audit' ) );
        add_action( 'wp_ajax_hts_full_audit_init', array( $this, 'ajax_full_audit_init' ) );
        add_action( 'wp_ajax_hts_full_audit_step', array( $this, 'ajax_full_audit_step' ) );
        add_action( 'wp_ajax_hts_inbox_scan',     array( $this, 'ajax_inbox_scan' ) );
        add_action( 'wp_ajax_hts_scan_cluster_linking', array( $this, 'ajax_scan_cluster_linking' ) );
        add_action( 'wp_ajax_hts_inbox_preview',  array( $this, 'ajax_inbox_preview' ) );
        add_action( 'wp_ajax_hts_inbox_history',  array( $this, 'ajax_inbox_history' ) );
        add_action( 'wp_ajax_hts_inbox_rollback', array( $this, 'ajax_inbox_rollback' ) );
        add_action( 'wp_ajax_hts_inbox_rollback_retry', array( $this, 'ajax_inbox_rollback_retry' ) );
        add_action( 'wp_ajax_hts_inbox_retry',    array( $this, 'ajax_inbox_retry' ) );
        add_action( 'wp_ajax_hts_inbox_refresh_anchor', array( $this, 'ajax_refresh_anchor' ) );
        add_action( 'wp_ajax_hts_purge_history',  array( $this, 'ajax_purge_history' ) );
        add_action( 'wp_ajax_hts_inbox_rollback_preview', array( $this, 'ajax_inbox_rollback_preview' ) );
        add_action( 'wp_ajax_hts_inbox_select_variant', array( $this, 'ajax_inbox_select_variant' ) );
        add_action( 'wp_ajax_hts_inbox_regen_variants', array( $this, 'ajax_inbox_regen_variants' ) );
        add_action( 'wp_ajax_hts_workflow_stats', array( $this, 'ajax_workflow_stats' ) );

        // Session H+ : Impact measurement AJAX
        add_action( 'wp_ajax_hts_impact_report', array( $this, 'ajax_impact_report' ) );
        add_action( 'wp_ajax_hts_meta_auto_recommend', array( $this, 'ajax_meta_auto_recommend' ) );
        add_action( 'wp_ajax_hts_auto_dry_run', array( $this, 'ajax_auto_dry_run' ) );
        add_action( 'wp_ajax_hts_load_guardrails_recommendations', array( $this, 'ajax_load_guardrails_recommendations' ) );
        add_action( 'wp_ajax_hts_save_agent_guardrails', array( $this, 'ajax_save_agent_guardrails' ) );

        // Cron cleanup des vieilles actions (daily)
        add_action( 'hts_workflow_daily_cleanup', array( __CLASS__, 'cron_cleanup' ) );

        // Session H+ : Impact measurement cron (daily)
        add_action( 'hts_impact_measure', array( __CLASS__, 'process_impact_queue' ) );
        if ( ! wp_next_scheduled( 'hts_impact_measure' ) ) {
            wp_schedule_event( time() + 7200, 'daily', 'hts_impact_measure' );
        }
        if ( ! wp_next_scheduled( 'hts_workflow_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'hts_workflow_daily_cleanup' );
        }

        // Cron weekly scan — détection automatique des problèmes → propositions Inbox
        add_action( 'hts_inbox_weekly_scan', array( __CLASS__, 'cron_inbox_scan' ) );
        add_action( 'hts_inbox_first_scan', array( __CLASS__, 'cron_inbox_scan' ) );
        if ( ! wp_next_scheduled( 'hts_inbox_weekly_scan' ) ) {
            wp_schedule_event( time() + 3600, 'weekly', 'hts_inbox_weekly_scan' );
        }

        // Sprint 4.3 : Cron daily purge — supprime les actions meta pending > 3 jours
        add_action( 'hts_inbox_purge_stale', array( __CLASS__, 'cron_purge_stale_actions' ) );
        if ( ! wp_next_scheduled( 'hts_inbox_purge_stale' ) ) {
            wp_schedule_event( time() + 7200, 'daily', 'hts_inbox_purge_stale' );
        }

        // Session M : Cron auto-drip — exécute les actions auto progressivement (max 2/heure)
        add_action( 'hts_auto_drip', array( __CLASS__, 'cron_auto_drip' ) );
        if ( ! wp_next_scheduled( 'hts_auto_drip' ) ) {
            wp_schedule_event( time() + 1800, 'hourly', 'hts_auto_drip' );
        }

        // Batch linking drip — traite les liens approuvés en masse par lots de 5
        add_action( 'hts_batch_linking_drip', array( __CLASS__, 'cron_batch_linking_drip' ) );

        // SaaS sync: push actions history when a remote flag is first activated
        add_action( 'hts_deferred_sync_saas', array( __CLASS__, 'sync_actions_to_saas' ) );
        if ( class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::has_active_flags() && HTS_Remote_Client::is_available() ) {
            if ( ! get_option( 'hts_remote_sync_done', false ) ) {
                if ( ! wp_next_scheduled( 'hts_deferred_sync_saas' ) ) {
                    wp_schedule_single_event( time() + 5, 'hts_deferred_sync_saas' );
                }
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  TABLE MANAGEMENT
     * ═══════════════════════════════════════════════ */

    /**
     * Créer les deux tables workflow.
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ── Table actions ──
        $actions_table = $wpdb->prefix . self::ACTIONS_TABLE;
        $sql_actions = "CREATE TABLE IF NOT EXISTS {$actions_table} (
            id          BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            agent       VARCHAR(50)  NOT NULL DEFAULT '',
            type        VARCHAR(50)  NOT NULL DEFAULT '',
            post_id     BIGINT(20)   UNSIGNED NOT NULL DEFAULT 0,
            data        LONGTEXT     NULL,
            priority    VARCHAR(10)  NOT NULL DEFAULT 'medium',
            status      VARCHAR(20)  NOT NULL DEFAULT 'pending',
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            resolved_at DATETIME     NULL,
            resolved_by BIGINT(20)   UNSIGNED NOT NULL DEFAULT 0,
            execution_log TEXT       NULL,
            INDEX idx_agent    (agent),
            INDEX idx_status   (status),
            INDEX idx_priority (priority),
            INDEX idx_post     (post_id),
            INDEX idx_created  (created_at),
            INDEX idx_agent_type_status (agent, type, status)
        ) {$charset};";
        dbDelta( $sql_actions );

        // ── Table config agents ──
        $agents_table = $wpdb->prefix . self::AGENTS_TABLE;
        $sql_agents = "CREATE TABLE IF NOT EXISTS {$agents_table} (
            agent    VARCHAR(50)  NOT NULL PRIMARY KEY,
            enabled  TINYINT(1)   NOT NULL DEFAULT 1,
            mode     VARCHAR(10)  NOT NULL DEFAULT 'review',
            settings LONGTEXT     NULL
        ) {$charset};";
        dbDelta( $sql_agents );

        // ── Seed default agents ──
        self::seed_default_agents();
    }

    /**
     * Vérifier que les tables existent.
     */
    public static function tables_exist() {
        global $wpdb;
        return self::_table_exists_cached( $wpdb->prefix . self::ACTIONS_TABLE )
            && self::_table_exists_cached( $wpdb->prefix . self::AGENTS_TABLE );
    }

    /**
     * S13-B: Static cache for SHOW TABLES — avoids 10+ redundant queries per request.
     * Once a table is confirmed to exist, it won't disappear during the same request.
     */
    private static function _table_exists_cached( $table_name ) {
        static $cache = array();
        if ( isset( $cache[ $table_name ] ) ) return $cache[ $table_name ];
        global $wpdb;
        $exists = (bool) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) );
        $cache[ $table_name ] = $exists;
        return $exists;
    }

    /**
     * Seed les agents par défaut (idempotent).
     */
    private static function seed_default_agents() {
        $defaults = array(
            'visibility'     => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'authority'      => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'commander'      => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{"max_articles_per_week":3}' ),
            'linking'        => array( 'enabled' => 1, 'mode' => 'manual', 'settings' => '{}' ),
            'meta'           => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'strategy'       => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'cannibalization'=> array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'fresh'          => array( 'enabled' => 0, 'mode' => 'review', 'settings' => '{}' ),
            'geo_score'      => array( 'enabled' => 0, 'mode' => 'review', 'settings' => '{}' ),
            'auto_write'     => array( 'enabled' => 0, 'mode' => 'review', 'settings' => '{"max_articles_per_week":3}' ),
            'content_quality'=> array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'image'          => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
            'coach'          => array( 'enabled' => 1, 'mode' => 'review', 'settings' => '{}' ),
        );

        global $wpdb;
        $table = $wpdb->prefix . self::AGENTS_TABLE;

        foreach ( $defaults as $agent => $config ) {
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT agent FROM {$table} WHERE agent = %s", $agent
            ) );
            if ( ! $exists ) {
                $wpdb->insert( $table, array(
                    'agent'    => $agent,
                    'enabled'  => $config['enabled'],
                    'mode'     => $config['mode'],
                    'settings' => $config['settings'],
                ) );
            }
        }

        // ── Session L : Migration meta_optimizer → meta ──
        $old_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT agent FROM {$table} WHERE agent = %s", 'meta_optimizer'
        ) );
        if ( $old_exists ) {
            // Transférer les settings de l'ancien slug vers le nouveau
            $new_exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT agent FROM {$table} WHERE agent = %s", 'meta'
            ) );
            if ( ! $new_exists ) {
                $wpdb->update( $table, array( 'agent' => 'meta' ), array( 'agent' => 'meta_optimizer' ) );
            } else {
                // Les deux existent, supprimer l'ancien
                $wpdb->delete( $table, array( 'agent' => 'meta_optimizer' ) );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  API INTERNE — PROPOSE
     * ═══════════════════════════════════════════════ */

    /**
     * Un agent propose une action.
     *
     * @param string $agent    Identifiant agent (ex: 'fresh', 'commander')
     * @param string $type     Type d'action (ex: 'content_refresh', 'merge')
     * @param int    $post_id  Post concerné (0 si global)
     * @param array  $data     Données arbitraires (reason, suggestion, scores...)
     * @param string $priority low|medium|high|critical
     * @return int|false       ID de l'action créée, ou false
     */
    public static function propose( $agent, $type, $post_id = 0, $data = array(), $priority = 'medium' ) {
        global $wpdb;

        // Phase 5.3: block linking proposals without a valid target_id
        // These create "Appliquer" buttons that do nothing in the Inbox
        $linking_types = array( 'add_internal_links', 'add_link', 'fix_orphan_links' );
        if ( in_array( $type, $linking_types, true ) && empty( $data['target_id'] ) ) {
            if ( function_exists( 'hts_debug_log' ) ) {
                hts_debug_log( sprintf( '[5.3 WE] propose() BLOCKED: %s without target_id — post=%d', $type, $post_id ) );
            }
            return false;
        }

        // fix7: trace cocon proposals specifically
        $is_cocon_trace = ! empty( $data['source_cocon'] );

        // ── Vérifier que l'agent est activé ──
        if ( ! self::is_agent_enabled( $agent ) ) {
            if ( $is_cocon_trace ) {
                hts_debug_log( sprintf( '[fix7 WE] propose() BLOCKED: agent "%s" is DISABLED — post=%d target=%d',
                    $agent, $post_id, $data['target_id'] ?? 0 ) );
            }
            return false;
        }

        // ── Garde-fou : pas de doublon pending pour le même post+type+agent ──
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // fix8: ALWAYS verify table exists (was conditional on cocon in fix7)
        // Sprint 6.3c: cache result to avoid repeated SHOW TABLES queries
        static $table_verified = false;
        if ( ! $table_verified ) {
            $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
            if ( ! $table_exists ) {
                hts_debug_log( '[fix8 WE] propose() table ' . $table . ' does NOT EXIST — creating now' );
                self::ensure_tables();
            }
            $table_verified = true;
        }

        // For linking proposals with a specific target, dedup on post_id+target_id
        $dedup_target = ! empty( $data['target_id'] ) ? (int) $data['target_id'] : 0;
        $is_cocon_proposal = ! empty( $data['source_cocon'] );

        if ( $dedup_target > 0 ) {
            // Specific target link: only dedup against same target
            // fix8: use exact match with trailing comma/brace to avoid partial match (123 vs 1234)
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE agent = %s AND type = %s AND post_id = %d AND status = 'pending' AND (data LIKE %s OR data LIKE %s)",
                $agent, $type, $post_id,
                '%"target_id":' . $dedup_target . ',%',
                '%"target_id":' . $dedup_target . '}'
            ) );
        } elseif ( $is_cocon_proposal ) {
            // Cocon proposal without target: no dedup against generic proposals
            $existing = null;
        } elseif ( ! empty( $data['_dedup_key'] ) ) {
            // Sprint 6.3d: dedup by custom key (e.g. GEO criterion) — allows multiple geo_optimize per page
            $dedup_key = sanitize_key( $data['_dedup_key'] );
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE agent = %s AND type = %s AND post_id = %d AND status = 'pending' AND data LIKE %s",
                $agent, $type, $post_id, '%"_dedup_key":"' . $dedup_key . '"%'
            ) );
        } else {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE agent = %s AND type = %s AND post_id = %d AND status = 'pending'",
                $agent, $type, $post_id
            ) );
        }
        if ( $existing ) {
            if ( $is_cocon_trace ) {
                hts_debug_log( sprintf( '[fix7 WE] propose() DEDUP: existing=%d post=%d target=%d — returning existing',
                    $existing, $post_id, $dedup_target ) );
            }
            // Still queue for batch sync even if dedup — action may not have been synced to SaaS yet
            if ( is_array( self::$batch_sync_queue ) && defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS ) {
                $lang = '';
                if ( $post_id && function_exists( 'pll_get_post_language' ) ) {
                    $lang = pll_get_post_language( $post_id, 'slug' );
                }
                if ( ! $lang && class_exists( 'HTS_Language' ) ) {
                    $lang = HTS_Language::get_current_lang();
                }
                if ( ! $lang ) {
                    $lang = substr( get_locale(), 0, 2 );
                }
                self::$batch_sync_queue[] = array(
                    'action_type' => $type,
                    'post_id'     => $post_id,
                    'target_id'   => isset( $data['target_id'] ) ? (int) $data['target_id'] : null,
                    'status'      => self::STATUS_PENDING,
                    'priority'    => 50,
                    'data_json'   => $data,
                    'lang'        => $lang,
                    'created_at'  => current_time( 'mysql' ),
                );
                hts_debug_log( '[BATCH] Queued DEDUP action type=' . $type . ' post=' . $post_id . ' queue_size=' . count( self::$batch_sync_queue ) );
            }
            return (int) $existing;
        }

        // v2.5.13: Check if this source→target pair was previously dismissed (blacklist)
        // This prevents re-proposing links the user explicitly rejected
        if ( $agent === 'linking' && $dedup_target > 0 ) {
            $dismissed_exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE agent = 'linking' AND post_id = %d AND status = 'dismissed' AND (data LIKE %s OR data LIKE %s) LIMIT 1",
                $post_id,
                '%"target_id":' . $dedup_target . ',%',
                '%"target_id":' . $dedup_target . '}'
            ) );
            if ( $dismissed_exists ) {
                if ( $is_cocon_trace || function_exists( 'hts_debug_log' ) ) {
                    hts_debug_log( sprintf( '[v2.5.13 WE] propose() BLACKLISTED: dismissed=%d post=%d target=%d — skipping',
                        $dismissed_exists, $post_id, $dedup_target ) );
                }
                return false; // Blacklisted — don't re-propose
            }
        }

        // ── Session P : weekly limit retiré de propose() ──
        // Les propositions sont TOUJOURS créées et visibles dans l'Inbox.
        // La limite hebdo s'applique uniquement à l'EXÉCUTION (check_all_guardrails → execute/cron_auto_drip).

        // ── Orphan rescue bypass — forced suggestions for orphan pages skip guards ──
        $is_orphan_rescue = ! empty( $data['orphan_rescue'] ) || $type === 'fix_orphan_links';
        // Cocon linking proposals go to Inbox for manual approval — skip cross-agent conflict
        $is_cocon_linking = ! empty( $data['source_cocon'] );
        // Coach Agent Mode : l'utilisateur a explicitement demandé l'action → bypass les garde-fous
        $is_coach_agent = ! empty( $data['source'] ) && $data['source'] === 'coach_agent';
        // Sprint 5.4: Coach AI suggestions bypass traffic threshold too — they're proposals, not auto-execution
        $is_coach_ai = ! empty( $data['source'] ) && $data['source'] === 'coach_ai';
        // Sprint 6.3c: fix_image_alt ne modifie que les metas d'attachment, pas le contenu article
        // → pas de conflit possible avec les autres agents, bypass les gardes-fous
        $is_alt_fix = ( $type === 'fix_image_alt' );

        // ── Garde-fou : seuil trafic (ne pas toucher les pages performantes) ──
        // fix_image_alt bypass : corriger les ALT est toujours bénéfique, même sur les pages performantes
        if ( $post_id > 0 && ! $is_orphan_rescue && ! $is_cocon_linking && ! $is_coach_agent && ! $is_coach_ai && ! $is_alt_fix && ! self::check_traffic_threshold( $post_id ) ) {
            return false;
        }

        // ── P4 Garde-fou : page dans la blacklist ──
        if ( $post_id > 0 && ! $is_orphan_rescue && ! $is_cocon_linking && ! $is_coach_agent && ! $is_coach_ai && ! $is_alt_fix && ! self::check_blacklist( $post_id ) ) {
            return false;
        }

        // ── Sprint 6.3d : exclure les pages système (CGV, panier, mentions légales…) ──
        if ( $post_id > 0 && ! $is_coach_agent && self::is_excluded_page( $post_id ) ) {
            return false;
        }

        // ── Session M : Cooldown — ne pas proposer si page modifiée récemment ──
        if ( $post_id > 0 && ! $is_orphan_rescue && ! $is_cocon_linking && ! $is_coach_agent && ! $is_coach_ai && ! $is_alt_fix ) {
            $cooldown = self::check_cooldown( $agent, $post_id );
            if ( $cooldown !== true ) {
                return false;
            }
        }

        // ── Session M : Conflit cross-agent — ne pas proposer si autre agent actif ──
        if ( $post_id > 0 && ! $is_orphan_rescue && ! $is_cocon_linking && ! $is_coach_agent && ! $is_coach_ai && ! $is_alt_fix ) {
            $conflict = self::check_cross_agent_conflict( $agent, $post_id );
            if ( $conflict !== true ) {
                return false;
            }
        }

        // ── Session J : Snapshot "before" au moment du propose (pour diff preview) ──
        // Sprint 6.3c: skip content-heavy snapshots for linking — sera fait à l'exécution
        if ( $post_id > 0 && empty( $data['_snapshot_before'] ) && $type !== 'add_internal_links' ) {
            $data['_snapshot_before'] = self::capture_propose_snapshot( $post_id, $type );
        }

        // ── S13-B : Confidence-based priority adjustment ──
        // If feedback loop has enough data on this action type, adjust priority
        if ( class_exists( 'HTS_Feedback_Loop' ) ) {
            $conf = HTS_Feedback_Loop::get_type_confidence( $type );
            if ( $conf >= 0 ) { // -1 means insufficient data
                if ( $conf >= 70 && $priority === 'medium' ) {
                    $priority = 'high';
                    $data['_confidence_boost'] = $conf;
                } elseif ( $conf < 30 && in_array( $priority, array( 'medium', 'high' ), true ) ) {
                    $priority = 'low';
                    $data['_confidence_warn'] = $conf;
                    $data['_confidence_note'] = 'Ce type d\'action a un faible taux de succès (' . $conf . '%). Vérifiez avant d\'approuver.';
                }
            }
        }

        // ── Insérer l'action ──
        $inserted = $wpdb->insert( $table, array(
            'agent'      => sanitize_key( $agent ),
            'type'       => sanitize_key( $type ),
            'post_id'    => absint( $post_id ),
            'data'       => wp_json_encode( $data ) ?: wp_json_encode( $data, JSON_INVALID_UTF8_SUBSTITUTE ),
            'priority'   => in_array( $priority, array( 'low', 'medium', 'high', 'critical' ), true ) ? $priority : 'medium',
            'status'     => self::STATUS_PENDING,
            'created_at' => current_time( 'mysql' ),
        ) );

        if ( ! $inserted ) {
            if ( $is_cocon_trace ) {
                hts_debug_log( sprintf( '[fix7 WE] propose() INSERT FAILED: agent=%s type=%s post=%d target=%d wpdb_error="%s"',
                    $agent, $type, $post_id, $data['target_id'] ?? 0, $wpdb->last_error ) );
            }
            return false;
        }

        $action_id = (int) $wpdb->insert_id;

        // P3 FIX: Sync new action to SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = '';
            if ( $post_id && function_exists( 'pll_get_post_language' ) ) {
                $lang = pll_get_post_language( $post_id, 'slug' );
            }
            if ( ! $lang && class_exists( 'HTS_Language' ) ) {
                $lang = HTS_Language::get_current_lang();
            }
            // Fallback: use site locale if Polylang returns nothing (admin-ajax context)
            if ( ! $lang ) {
                $lang = substr( get_locale(), 0, 2 );
            }
            $action_payload = array(
                'action_type' => $type,
                'post_id'     => $post_id,
                'target_id'   => isset( $data['target_id'] ) ? (int) $data['target_id'] : null,
                'status'      => self::STATUS_PENDING,
                'priority'    => 50,
                'data_json'   => $data,
                'lang'        => $lang,
                'created_at'  => current_time( 'mysql' ),
            );

            // If batch mode active (scan_proposals), queue instead of sending
            if ( is_array( self::$batch_sync_queue ) ) {
                self::$batch_sync_queue[] = $action_payload;
                hts_debug_log( '[BATCH] Queued action type=' . $type . ' post=' . $post_id . ' queue_size=' . count( self::$batch_sync_queue ) );
            } else {
                hts_debug_log( '[BATCH] Queue is null, sending individually type=' . $type . ' post=' . $post_id );
                HTS_Remote_Client::call( 'sync/actions', array( 'actions' => array( $action_payload ) ) );
            }
        }

        hts_debug_log( sprintf(
            '[HTS WE] propose() OK: id=%d agent=%s type=%s post=%d mode=%s coach_agent=%s',
            $action_id, $agent, $type, $post_id, self::get_agent_mode( $agent ),
            $is_coach_agent ? 'YES' : 'no'
        ) );

        // ── Mode auto → approuver mais NE PAS exécuter immédiatement ──
        // Les actions auto sont exécutées progressivement par le cron hts_auto_drip
        // (max 2 par heure) pour un profil de modification naturel.
        // EXCEPTION : les actions Coach Agent restent TOUJOURS en pending (l'utilisateur
        // a demandé explicitement → il doit voir et valider dans l'Inbox).
        // EXCEPTION 2 : les propositions cocon (source_cocon) restent en pending —
        // le flow "Mailler" est conçu pour que l'utilisateur valide dans l'Inbox.
        $mode = self::get_agent_mode( $agent );
        if ( $mode === self::MODE_AUTO && ! $is_coach_agent && ! $is_cocon_linking ) {
            // Marquer comme approved sans exécuter
            $wpdb->update( $table,
                array(
                    'status'      => self::STATUS_APPROVED,
                    'resolved_at' => current_time( 'mysql' ),
                    'resolved_by' => 0, // 0 = auto
                ),
                array( 'id' => $action_id )
            );
        }

        return $action_id;
    }

    /* ═══════════════════════════════════════════════
     *  API INTERNE — APPROVE / REJECT / EXECUTE
     * ═══════════════════════════════════════════════ */

    /**
     * Approuver une action.
     *
     * @param int $id Action ID
     * @return bool
     */
    public static function approve( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $action = self::get_action( $id );
        if ( ! $action || $action->status !== self::STATUS_PENDING ) {
            return false;
        }

        $updated = $wpdb->update( $table,
            array(
                'status'      => self::STATUS_APPROVED,
                'resolved_at' => current_time( 'mysql' ),
                'resolved_by' => get_current_user_id(),
            ),
            array( 'id' => $id )
        );

        if ( $updated ) {
            // Tenter l'exécution immédiate
            self::execute( $id );
            // Sprint 4.3: Invalidate Coach badge cache when Coach action is completed
            if ( $action->agent === 'coach' ) {
                delete_transient( 'hts_coach_alert_count' );
            }
        }

        return (bool) $updated;
    }

    /**
     * Rejeter une action.
     *
     * @param int $id Action ID
     * @return bool
     */
    public static function reject( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $action = self::get_action( $id );
        if ( ! $action || $action->status !== self::STATUS_PENDING ) {
            return false;
        }

        return (bool) $wpdb->update( $table,
            array(
                'status'      => self::STATUS_REJECTED,
                'resolved_at' => current_time( 'mysql' ),
                'resolved_by' => get_current_user_id(),
            ),
            array( 'id' => $id )
        );
    }

    /**
     * Batch approve.
     *
     * @param array $ids Array d'IDs
     * @return int Nombre d'actions approuvées
     */
    public static function batch_approve( $ids ) {
        $count = 0;
        $linking_ids = array();

        foreach ( (array) $ids as $id ) {
            $id = (int) $id;
            $action = self::get_action( $id );
            if ( ! $action || $action->status !== self::STATUS_PENDING ) continue;

            // Pour les liens : approuver SANS exécuter immédiatement (queue)
            if ( $action->type === 'add_internal_links' || $action->type === 'fix_orphan_links' ) {
                global $wpdb;
                $table = $wpdb->prefix . self::ACTIONS_TABLE;
                $updated = $wpdb->update( $table,
                    array(
                        'status'      => self::STATUS_APPROVED,
                        'resolved_at' => current_time( 'mysql' ),
                        'resolved_by' => get_current_user_id(),
                    ),
                    array( 'id' => $id )
                );
                if ( $updated ) {
                    $linking_ids[] = $id;
                    $count++;
                }
                continue;
            }

            // Autres types : exécution immédiate comme avant
            // Sprint 5.3: Track LLM-heavy actions to limit batch execution
            $llm_types = array( 'add_faq', 'content_refresh', 'generate_article', 'geo_optimize', 'enrich_thin_content',
                'add_meta_title', 'add_meta_desc', 'optimize_meta_both', 'optimize_meta_title', 'optimize_meta_desc' );
            $is_llm = in_array( $action->type, $llm_types, true );
            if ( $is_llm && ( $llm_executed ?? 0 ) >= 3 ) {
                // Approve only (skip execution) — will be picked up by cron auto-drip
                global $wpdb;
                $table = $wpdb->prefix . self::ACTIONS_TABLE;
                $wpdb->update( $table,
                    array( 'status' => self::STATUS_APPROVED, 'resolved_at' => current_time( 'mysql' ), 'resolved_by' => get_current_user_id() ),
                    array( 'id' => $id )
                );
                $count++;
                continue;
            }
            if ( self::approve( $id ) ) {
                $count++;
                if ( $is_llm ) {
                    $llm_executed = ( $llm_executed ?? 0 ) + 1;
                }
            }
        }

        // Exécuter les liens approuvés en queue : max 5 maintenant, le reste via cron
        if ( ! empty( $linking_ids ) ) {
            $batch_limit = 5;
            $executed = 0;
            foreach ( $linking_ids as $lid ) {
                if ( $executed >= $batch_limit ) break;
                self::execute( $lid );
                $executed++;
                // Petit délai pour ne pas surcharger la BDD
                usleep( 200000 ); // 200ms
            }

            $remaining = count( $linking_ids ) - $executed;
            if ( $remaining > 0 && function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    "Batch linking : {$executed} exécuté(s) immédiatement, {$remaining} en file d'attente (cron auto-drip).",
                    'info', 'workflow'
                );
            }

            // Programmer un cron ponctuel pour traiter la suite rapidement (toutes les 5 min)
            if ( $remaining > 0 && ! wp_next_scheduled( 'hts_batch_linking_drip' ) ) {
                wp_schedule_single_event( time() + 300, 'hts_batch_linking_drip' );
            }
        }

        return $count;
    }

    /**
     * Batch reject.
     *
     * @param array $ids Array d'IDs
     * @return int Nombre d'actions rejetées
     */
    public static function batch_reject( $ids ) {
        $count = 0;
        foreach ( (array) $ids as $id ) {
            if ( self::reject( (int) $id ) ) {
                $count++;
            }
        }
        return $count;
    }

    /**
     * Exécuter une action approuvée.
     * Dispatch vers le bon module selon agent+type.
     *
     * @param int $id Action ID
     * @return bool
     */
    public static function execute( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $action = self::get_action( $id );
        if ( ! $action || $action->status !== self::STATUS_APPROVED ) {
            return false;
        }

        // S13-B: Atomic lock — prevents double execution from concurrent cron runs
        // UPDATE only succeeds if status is still 'approved' (row-level lock)
        $locked = $wpdb->query( $wpdb->prepare(
            "UPDATE {$table} SET status = 'executing' WHERE id = %d AND status = 'approved'",
            $id
        ) );
        if ( ! $locked ) {
            // Another process already grabbed this action
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Execute #{$id}: race condition avoided — already executing", 'warn', 'workflow' );
            }
            return false;
        }

        // P4 — Vérification garde-fous avant exécution
        // S13-B: Verify post still exists (may have been deleted between approve and execute)
        $post_id_exec = (int) $action->post_id;
        if ( $post_id_exec > 0 && ! get_post_status( $post_id_exec ) ) {
            $wpdb->update( $table,
                array(
                    'status'        => self::STATUS_FAILED,
                    'resolved_at'   => current_time( 'mysql' ),
                    'execution_log' => 'Article supprimé entre approbation et exécution.',
                ),
                array( 'id' => $id )
            );
            return false;
        }

        // Cocon linking & orphan rescue: user manually approved from Inbox → skip cooldown + cross-agent
        $action_data_raw = json_decode( $action->data, true ) ?: array();
        $is_cocon_exec   = ! empty( $action_data_raw['source_cocon'] );
        $is_orphan_exec  = ! empty( $action_data_raw['orphan_rescue'] ) || $action->type === 'fix_orphan_links';
        $is_coach_exec   = ! empty( $action_data_raw['source'] ) && in_array( $action_data_raw['source'], array( 'coach_agent', 'coach_ai' ), true );

        // Sprint 6.3: Toute action approuvée manuellement (resolved_by = user) → bypass cross-agent
        // L'utilisateur a cliqué "Appliquer" dans l'Inbox, il a confirmé dans la modale preview
        $is_manual_approve = ( (int) ( $action->resolved_by ?? 0 ) > 0 );

        if ( $is_coach_exec || $is_manual_approve ) {
            $guardrail_check = true;
        } else {
            $guardrail_check = self::check_all_guardrails( $action->agent, $action->type, (int) $action->post_id, $is_cocon_exec, $is_orphan_exec );
        }
        // Vérifier au minimum la blacklist même pour les approbations manuelles
        if ( $is_manual_approve && ! $is_coach_exec ) {
            $bl = get_option( 'hts_blacklisted_posts', array() );
            if ( is_array( $bl ) && in_array( (int) $action->post_id, array_map( 'intval', $bl ), true ) ) {
                $guardrail_check = false;
            }
        }
        if ( $guardrail_check !== true ) {
            $wpdb->update( $table,
                array(
                    'status'        => self::STATUS_BLOCKED,
                    'resolved_at'   => current_time( 'mysql' ),
                    'execution_log' => 'Bloqué par garde-fou : ' . $guardrail_check,
                ),
                array( 'id' => $id )
            );
            return false;
        }

        // Status already set to 'executing' by atomic lock above

        $data    = json_decode( $action->data, true ) ?: array();
        $success = false;
        $log     = '';

        // ── Snapshot AVANT exécution (pour rollback) ──
        $backup = self::create_backup( (int) $action->post_id, $action->type );

        // Sprint 6.3c: sauvegarder l'ID de la dernière révision AVANT exécution
        // pour que le fallback révision ne restaure pas une révision post-FAQ
        $pre_revisions = wp_get_post_revisions( (int) $action->post_id, array( 'numberposts' => 1 ) );
        if ( ! empty( $pre_revisions ) ) {
            $backup['_pre_revision_id'] = reset( $pre_revisions )->ID;
            // Safety net: also save as separate meta (survives corrupted backup JSON)
            update_post_meta( (int) $action->post_id, '_hts_pre_rev_' . $id, reset( $pre_revisions )->ID );
        }

        // ── Session H+ : Snapshot KPI AVANT exécution (pour mesure d'impact) ──
        $kpi_before = self::capture_kpi_snapshot( (int) $action->post_id );

        try {
            $dispatch_result = self::dispatch( $action->agent, $action->type, (int) $action->post_id, $data );

            // v2.4.17: dispatch can return array with rich log (linking actions)
            if ( is_array( $dispatch_result ) ) {
                $success = ! empty( $dispatch_result['success'] );
                $log     = $dispatch_result['log'] ?? ( $success ? 'Exécution réussie' : 'Échec' );
                // Store context for post-apply display
                if ( ! empty( $dispatch_result['context'] ) ) {
                    $log .= "\n" . '📍 ' . $dispatch_result['context'];
                }
            } else {
                $success = (bool) $dispatch_result;
                $log = $success ? 'Exécution réussie' : 'Échec';

                // Enrichir le log avec ce qui a changé
                $changes = self::detect_changes( (int) $action->post_id, $action->type, $backup );
                if ( $changes ) {
                    $log .= ' — ' . $changes;
                }
            }
        } catch ( \Throwable $e ) {
            $log = 'Erreur : ' . $e->getMessage();
            $success = false;
        }

        // Sauvegarder le backup si succès
        if ( $success && ! empty( $backup ) ) {
            $pid = (int) $action->post_id;
            $backup_key = '_hts_action_backup_' . $id;

            // Sprint 6.3c fix: stocker les données builder séparément pour éviter
            // le dépassement max_allowed_packet MySQL (silent fail sur gros Elementor data)
            $builder_keys = array( '_elementor_data', '_fl_builder_data', '_bricks_page_content_2' );
            $builder_backup = array();
            foreach ( $builder_keys as $bk ) {
                if ( ! empty( $backup[ $bk ] ) ) {
                    $builder_backup[ $bk ] = $backup[ $bk ];
                    unset( $backup[ $bk ] ); // Retirer du backup principal
                }
            }

            // Sauvegarder le backup principal (sans builder data = taille raisonnable)
            $json = wp_json_encode( $backup );
            $saved = update_post_meta( $pid, $backup_key, wp_slash( $json ) );
            if ( ! $saved && function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf( 'Backup principal échec post #%d (taille: %d)', $pid, strlen( $json ) ), 'error', 'workflow' );
            }

            // Sauvegarder chaque builder data séparément (peut être très gros)
            foreach ( $builder_backup as $bk => $bk_data ) {
                $bk_saved = update_post_meta( $pid, $backup_key . $bk, $bk_data );
                if ( ! $bk_saved && function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf( 'Backup builder %s échec post #%d (taille: %d)', $bk, $pid, strlen( is_string( $bk_data ) ? $bk_data : wp_json_encode( $bk_data ) ) ), 'error', 'workflow' );
                }
            }
        }

        // Session H+ : Sauvegarder le snapshot KPI avant pour mesure d'impact
        if ( $success && ! empty( $kpi_before ) ) {
            $impact_data = array(
                'action_id'   => $id,
                'agent'       => $action->agent,
                'type'        => $action->type,
                'post_id'     => (int) $action->post_id,
                'executed_at' => current_time( 'mysql' ),
                'kpi_before'  => $kpi_before,
                'kpi_7d'      => null,
                'kpi_30d'     => null,
            );
            update_post_meta( (int) $action->post_id, '_hts_impact_' . $id, wp_json_encode( $impact_data ) );
            // Schedule follow-up measurements
            $impact_queue = get_option( 'hts_impact_queue', array() );
            $impact_queue[] = array(
                'action_id' => $id,
                'post_id'   => (int) $action->post_id,
                'check_7d'  => gmdate( 'Y-m-d', strtotime( '+7 days' ) ),
                'check_30d' => gmdate( 'Y-m-d', strtotime( '+30 days' ) ),
            );
            // S13-B: Cap queue size — drop oldest items if exceeding 200
            if ( count( $impact_queue ) > 200 ) {
                $impact_queue = array_slice( $impact_queue, -200 );
            }
            update_option( 'hts_impact_queue', $impact_queue, false );
        }

        // Si skipped (ancre stale sans recalcul possible), laisser en pending
        $was_skipped = ( is_array( $dispatch_result ) && ! empty( $dispatch_result['skipped'] ) );
        if ( $was_skipped ) {
            // Ne pas changer le statut — laisser en pending pour recalcul futur
            return array( 'skipped' => true );
        }

        $new_status = $success ? self::STATUS_DONE : self::STATUS_FAILED;
        $wpdb->update( $table,
            array(
                'status'        => $new_status,
                'resolved_at'   => current_time( 'mysql' ),
                'execution_log' => $log,
            ),
            array( 'id' => $id )
        );

        // BUG 8 FIX: Sync status change to SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            HTS_Remote_Client::call( 'sync/actions', array(
                'actions' => array( array(
                    'action_type' => $action->type,
                    'post_id'     => (int) $action->post_id,
                    'status'      => $new_status,
                    'created_at'  => $action->created_at,
                ) ),
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
        }

        return $success;
    }

    /**
     * Dispatch l'exécution vers le bon module.
     * Chaque Phase ajoutera ses handlers ici.
     *
     * @param string $agent
     * @param string $type
     * @param int    $post_id
     * @param array  $data
     * @return bool
     */
    private static function dispatch( $agent, $type, $post_id, $data ) {

        // ── Sprint 6.3 V1 : actions désactivées temporairement (sauf si le Coach les demande explicitement) ──
        $is_coach_source = ( $agent === 'coach' ) || ( ! empty( $data['source'] ) && in_array( $data['source'], array( 'coach_agent', 'coach_ai' ), true ) );
        if ( ! $is_coach_source && $type === 'content_refresh' ) {
            return array( 'success' => false, 'log' => '⏳ Rafraîchissement automatique bientôt disponible. En attendant, mettez à jour manuellement cet article.' );
        }

        /**
         * Filter: allow modules to handle their own workflow action types.
         *
         * @since 1.30.0
         * @param bool|null $result  null = not handled, true = success, false = failure.
         * @param string    $agent   Agent name.
         * @param string    $type    Action type.
         * @param int       $post_id Post ID.
         * @param array     $data    Action data.
         */
        $result = apply_filters( 'hts_workflow_dispatch', null, $agent, $type, $post_id, $data );
        if ( $result !== null ) {
            // Sprint 5.3: Propagate rich returns (array with success+log) for better execution feedback
            return is_array( $result ) ? $result : (bool) $result;
        }

        // ── Handlers intégrés pour les actions du scan Inbox ──

        // Meta : générer title ou description via IA
        if ( in_array( $type, array( 'add_meta_title', 'add_meta_desc', 'optimize_meta_title', 'optimize_meta_desc', 'optimize_meta_both' ), true ) ) {
            return self::dispatch_meta_generation( $type, $post_id, $data );
        }

        // Liens internes : analyser et proposer des liens
        if ( $type === 'add_internal_links' || $type === 'fix_orphan_links' ) {
            return self::dispatch_internal_links( $post_id, $data );
        }

        // GEO optimize : recalculer le score et marquer pour amélioration
        if ( $type === 'geo_optimize' ) {
            return self::dispatch_geo_optimize( $post_id, $data );
        }

        // FAQ : générer et injecter la section FAQ dans l'article
        if ( $type === 'add_faq' ) {
            if ( ! get_post( $post_id ) ) return false;
            // Sprint 5.3: Delegate to real generator
            if ( class_exists( 'HTS_Content_Refresh' ) && method_exists( 'HTS_Content_Refresh', 'add_faq_from_coach' ) ) {
                $faq_params = array( 'post_id' => $post_id );
                if ( ! empty( $data['questions'] ) ) {
                    $faq_params['questions'] = $data['questions'];
                }
                $result = HTS_Content_Refresh::add_faq_from_coach( $faq_params );
                // Handle skipped (FAQ already exists)
                if ( is_array( $result ) && ! empty( $result['skipped'] ) ) {
                    return array( 'success' => true, 'log' => $result['reason'] ?? 'FAQ déjà présente' );
                }
                return (bool) $result;
            }
            return false;
        }

        // Thin content : enrichir l'article via Content Refresh
        // ── Sprint 6.3 V1 : désactivé — pipeline SaaS pas encore testé de bout en bout ──
        if ( $type === 'enrich_thin_content' ) {
            return array( 'success' => false, 'log' => '⏳ Enrichissement automatique bientôt disponible. En attendant, enrichissez manuellement cet article.' );
        }

        // Featured image : générer UNIQUEMENT l'image mise en avant (pas in-content)
        if ( $type === 'add_featured_image' ) {
            return self::dispatch_generate_featured_image( $post_id, $data );
        }

        // ALT images : générer les ALT manquants via IA
        if ( $type === 'fix_image_alt' ) {
            return self::dispatch_fix_image_alt( $post_id, $data );
        }

        // Delete page : corbeille (jamais suppression definitive)
        if ( $type === 'delete_page' ) {
            if ( ! get_post( $post_id ) ) return false;
            return (bool) wp_trash_post( $post_id );
        }

        // Si aucun handler n'a géré → log et fail gracieux
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Workflow: aucun handler pour {$agent}/{$type}", 'warn', 'workflow' );
        }

        return false;
    }

    /* ═══════════════════════════════════════════════
     *  DISPATCH HELPERS — Exécution des actions Inbox
     * ═══════════════════════════════════════════════ */

    /**
     * Générer meta title ou description via IA (Meta Score).
     *
     * Session L : utilise les variantes pré-générées au preview si disponibles,
     * sinon génère à la volée (fallback).
     *
     * @since 2.4.0
     * @since 2.4.8 — pre-generated variants support
     * @param string $type   add_meta_title ou add_meta_desc
     * @param int    $post_id
     * @param array  $action_data  Données de l'action (peut contenir _generated_variants)
     * @return bool
     */
    /** @var array Cache of generated variants per post_id during batch operations */
    private static $batch_variants_cache = array();

    private static function dispatch_meta_generation( $type, $post_id, $action_data = array() ) {
        if ( ! class_exists( 'HTS_Meta_Score' ) ) return false;
        if ( ! get_post( $post_id ) ) return false;

        // Normalize: optimize_meta_* → same logic as add_meta_*
        $is_title = in_array( $type, array( 'add_meta_title', 'optimize_meta_title' ), true );
        $is_desc  = in_array( $type, array( 'add_meta_desc', 'optimize_meta_desc' ), true );
        $is_both  = ( $type === 'optimize_meta_both' );

        // ── Session M : Score minimum pour mode auto ──
        $is_auto        = self::get_agent_mode( 'meta' ) === self::MODE_AUTO;
        $min_score      = (int) self::get_agent_guardrail( 'meta', 'min_quality_score' );
        if ( $min_score <= 0 ) $min_score = 0;

        // ── Batch: check if we have cached variants from a previous action on the same post ──
        if ( empty( $action_data['_generated_variants'] ) && isset( self::$batch_variants_cache[ $post_id ] ) ) {
            $action_data['_generated_variants'] = self::$batch_variants_cache[ $post_id ];
        }

        // ── Session L : Utiliser les variantes déjà générées au preview ──
        if ( ! empty( $action_data['_generated_variants'] ) ) {
            $best = $action_data['_generated_variants'][0];

            if ( $is_auto && isset( $best['score'] ) && (int) $best['score'] < $min_score ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Meta auto : variante rejetée pour post #{$post_id} (score {$best['score']} < seuil {$min_score})", 'info', 'workflow' );
                }
                return false;
            }

            $applied = false;
            if ( ( $is_title || $is_both ) && ! empty( $best['title'] ) ) {
                update_post_meta( $post_id, '_hts_meta_title', sanitize_text_field( $best['title'] ) );
                $applied = true;
            }
            if ( ( $is_desc || $is_both ) && ! empty( $best['description'] ) ) {
                update_post_meta( $post_id, '_hts_meta_description', sanitize_textarea_field( $best['description'] ) );
                $applied = true;
            }
            if ( $applied ) return true;
        }

        // ── Fallback : générer à la volée (skip rate limit for batch/user-initiated actions) ──
        $meta_score = new HTS_Meta_Score();
        if ( ! method_exists( $meta_score, 'generate_variants' ) ) return false;

        $result = $meta_score->generate_variants( $post_id, true );

        if ( isset( $result['error'] ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Workflow meta gen : {$result['error']}", 'warn', 'workflow' );
            }
            return false;
        }

        if ( ! empty( $result['variants'] ) ) {
            // Cache variants for other actions on the same post (batch: title + desc in 1 LLM call)
            self::$batch_variants_cache[ $post_id ] = $result['variants'];

            $best = $result['variants'][0];

            if ( $is_auto && isset( $best['score'] ) && (int) $best['score'] < $min_score ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Meta auto : variante rejetée pour post #{$post_id} (score {$best['score']} < seuil {$min_score})", 'info', 'workflow' );
                }
                return false;
            }

            $applied = false;
            if ( ( $is_title || $is_both ) && ! empty( $best['title'] ) ) {
                update_post_meta( $post_id, '_hts_meta_title', sanitize_text_field( $best['title'] ) );
                $applied = true;
            }
            if ( ( $is_desc || $is_both ) && ! empty( $best['description'] ) ) {
                update_post_meta( $post_id, '_hts_meta_description', sanitize_textarea_field( $best['description'] ) );
                $applied = true;
            }
            if ( $applied ) return true;
        }

        return false;
    }

    /**
     * Analyser et proposer des liens internes.
     *
     * @since 2.4.0
     * @param int $post_id
     * @return bool|array  Bool for simple result, array with 'log' key for detailed execution_log.
     */
    /**
     * Find an alternative anchor text outside H2-H6 headings.
     */
    private static function find_alternative_anchor_outside_headings( $content, $original_anchor, $target_title ) {
        $body_only = preg_replace( '/<h[2-6][^>]*>.*?<\/h[2-6]>/si', '', $content );
        $text = html_entity_decode( wp_strip_all_tags( $body_only ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        $target_words = array_filter( preg_split( '/[\s,\-:]+/', mb_strtolower( $target_title ) ), function( $w ) { return mb_strlen( $w ) >= 3; } );
        if ( empty( $target_words ) ) return null;

        $sentences = preg_split( '/(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $best = null;
        $best_score = 0;

        foreach ( $sentences as $sent ) {
            $words = preg_split( '/\s+/', trim( $sent ) );
            for ( $len = 3; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $s = 0; $s <= count( $words ) - $len; $s++ ) {
                    $seg = implode( ' ', array_slice( $words, $s, $len ) );
                    $seg = trim( preg_replace( '/[.,;:!?]+$/', '', $seg ) );
                    if ( mb_strlen( $seg ) < 10 || mb_strlen( $seg ) > 80 ) continue;
                    if ( mb_strtolower( $seg ) === mb_strtolower( $original_anchor ) ) continue;
                    $matches = 0;
                    foreach ( $target_words as $tw ) {
                        if ( mb_strpos( mb_strtolower( $seg ), $tw ) !== false ) $matches++;
                    }
                    if ( ! $matches ) continue;
                    if ( mb_strpos( $body_only, $seg ) === false ) continue;
                    if ( preg_match( '/<a[^>]*>[^<]*' . preg_quote( $seg, '/' ) . '/si', $content ) ) continue;
                    $sc = $matches * 20 + ( $len >= 3 && $len <= 5 ? 15 : 0 );
                    if ( $sc > $best_score ) { $best_score = $sc; $best = $seg; }
                }
            }
        }
        return $best;
    }

    /**
     * Find the best anchor text in a post's content for a given target.
     * Reusable by both ajax_refresh_anchor and auto-refresh in batch.
     */
    public static function find_best_anchor( $post_id, $target_id ) {
        $post = get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) return null;

        $target_keyword = get_post_meta( $target_id, '_hts_focus_keyword', true ) ?: get_the_title( $target_id );
        $content = html_entity_decode( wp_strip_all_tags( $post->post_content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $search_words = array_filter( preg_split( '/[\s,\-:]+/', mb_strtolower( $target_keyword ) ), function( $w ) { return mb_strlen( $w ) >= 3; } );
        if ( empty( $search_words ) ) return null;

        $sentences = preg_split( '/(?<=[.!?])\s+/', $content, -1, PREG_SPLIT_NO_EMPTY );
        $best = null;
        $best_score = 0;

        foreach ( $sentences as $sent ) {
            $words = preg_split( '/\s+/', trim( $sent ) );
            for ( $len = 3; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $s = 0; $s <= count( $words ) - $len; $s++ ) {
                    $seg = implode( ' ', array_slice( $words, $s, $len ) );
                    $seg = trim( preg_replace( '/[.,;:!?]+$/', '', $seg ) );
                    if ( mb_strlen( $seg ) < 10 || mb_strlen( $seg ) > 80 ) continue;
                    $matches = 0;
                    foreach ( $search_words as $sw ) {
                        if ( mb_strpos( mb_strtolower( $seg ), $sw ) !== false ) $matches++;
                    }
                    if ( ! $matches ) continue;
                    if ( mb_strpos( $post->post_content, $seg ) === false ) continue;
                    if ( preg_match( '/<a[^>]*>[^<]*' . preg_quote( $seg, '/' ) . '/si', $post->post_content ) ) continue;
                    $sc = $matches * 20 + ( $len >= 3 && $len <= 5 ? 15 : 0 );
                    if ( $sc > $best_score ) { $best_score = $sc; $best = $seg; }
                }
            }
        }
        return $best;
    }

    private static function dispatch_internal_links( $post_id, $action_data = array() ) {
        if ( ! class_exists( 'HTS_Internal_Linking' ) ) return array( 'success' => false, 'log' => 'Le module de maillage interne n\'est pas disponible. Contactez le support Hack The SEO.' );
        if ( ! get_post( $post_id ) ) return false;

        // Sprint Robustesse: prevent cross-language linking
        $target_id = (int) ( $action_data['target_id'] ?? 0 );
        if ( $target_id > 0 && class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $src_lang = HTS_Language::get_post_language( $post_id ) ?: '';
            $tgt_lang = HTS_Language::get_post_language( $target_id ) ?: '';
            if ( $src_lang && $tgt_lang && $src_lang !== $tgt_lang ) {
                return array( 'success' => false, 'log' => sprintf( 'Ce lien relie un article en %s vers un article en %s. Les liens internes doivent rester dans la même langue. Cette proposition a été bloquée.', strtoupper( $src_lang ), strtoupper( $tgt_lang ) ) );
            }
        }

        // ── Sprint 6.2d : Unified budget check ──
        // Always recount from real HTML (never trust stale meta)
        $current_out = self::recount_internal_links( $post_id );

        // Primary: use cocon budget (4-12 by word count + 3 HTS cap) if available
        // Fallback: hard ceiling hts_max_links_per_page (default 20)
        $budget_full = false;
        $pre_swap_content = null; // Sprint 6.2d: rollback target if swap+insert fails
        if ( class_exists( 'HTS_Cocon_Commander' ) && method_exists( 'HTS_Cocon_Commander', 'get_link_budget_for_post' ) ) {
            $budget_info = HTS_Cocon_Commander::get_link_budget_for_post( $post_id );
            $budget_full = ( $budget_info['budget'] <= 0 );
        } else {
            $max_links_per_page = (int) get_option( 'hts_max_links_per_page', 20 );
            $budget_full = ( $current_out >= $max_links_per_page );
        }

        if ( $budget_full ) {

            // ── Sprint 6.2c : Smart Link Swap — try replacing worst link instead of blocking ──
            if ( ! empty( $action_data['source_cocon'] ) && class_exists( 'HTS_Cocon_Commander' ) ) {

                $swap_threshold = (int) get_option( 'hts_swap_score_threshold', 30 );
                $scored         = HTS_Cocon_Commander::score_existing_links( $post_id );

                if ( empty( $scored ) ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log(
                            sprintf( 'Swap impossible : page #%d — aucun lien remplaçable', $post_id ),
                            'warn', 'workflow'
                        );
                    }
                    return array( 'success' => false, 'log' => 'Cet article contient déjà beaucoup de liens internes. Aucun lien existant ne peut être remplacé automatiquement. Pour ajouter ce lien, retirez manuellement un lien moins important.' );
                }

                $worst = $scored[0];

                if ( $worst['score'] >= $swap_threshold ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log(
                            sprintf( 'Swap refusé : page #%d — tous les liens sont pertinents (pire score: %d, seuil: %d)', $post_id, $worst['score'], $swap_threshold ),
                            'warn', 'workflow'
                        );
                    }
                    $existing_count = $current_out;
                    $target_count   = isset( $budget_info['target'] ) ? $budget_info['target'] : $current_out;
                    return array( 'success' => false, 'log' => sprintf( 'Cet article contient déjà %d liens internes (recommandation : %d). Tous vos liens actuels sont utiles — aucun n\'a été retiré. Retirez manuellement un lien moins prioritaire pour faire de la place.', $existing_count, $target_count ) );
                }

                // ── Perform the swap: remove worst link ──
                $post_obj    = get_post( $post_id );
                $old_content = $post_obj->post_content;
                $pre_swap_content = $old_content; // Sprint 6.2d: save for rollback if insertion fails

                $linker      = new HTS_Internal_Linking();
                $new_content = $linker->remove_link_from_content( $old_content, $worst['full_tag'] );

                if ( $new_content === $old_content ) {
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log(
                            sprintf( 'Swap échoué : tag non trouvé dans le contenu de la page #%d', $post_id ),
                            'warn', 'workflow'
                        );
                    }
                    return array( 'success' => false, 'log' => 'Le lien à remplacer a été modifié ou supprimé depuis la dernière analyse. Relancez une analyse du groupe pour obtenir des propositions à jour.' );
                }

                // Save content with removed link
                wp_update_post( array(
                    'ID'           => $post_id,
                    'post_content' => $new_content,
                ) );

                // Update outgoing link count (recount from real content after removal)
                $current_out = self::recount_internal_links( $post_id );

                $old_anchor = $worst['anchor'];
                $old_target = $worst['target_id'];
                $anchor     = $action_data['anchor_text'] ?? '';
                $swap_log   = sprintf(
                    'Lien ajouté : « %s » vers « %s ». Pour faire de la place, le lien « %s » vers « %s » a été retiré (peu utile au référencement).',
                    mb_substr( $anchor, 0, 50 ),
                    mb_substr( get_the_title( $target_id ), 0, 50 ),
                    mb_substr( $old_anchor, 0, 50 ),
                    mb_substr( get_the_title( $old_target ), 0, 50 )
                );

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( $swap_log, 'info', 'workflow' );
                }

                // Store swap info for enriched execution log
                $action_data['_swap_log'] = $swap_log;

                // Fall through to normal link insertion below (budget now has room)

            } else {
                // Not a cocon action — standard block
                $existing_count = $current_out;
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Linking bloqué : page #%d a déjà %d liens internes (budget plein)', $post_id, $current_out ),
                        'warn', 'workflow'
                    );
                }
                return array( 'success' => false, 'log' => sprintf( 'Cet article contient déjà %d liens internes. Pour ne pas diluer votre référencement, aucun lien supplémentaire n\'est ajouté. Retirez un lien existant ou augmentez la taille de l\'article.', $existing_count ) );
            }
        }

        $linker = new HTS_Internal_Linking();

        // ── Session N : Si l'action vient du cocon, utiliser directement les données cocon ──
        if ( ! empty( $action_data['source_cocon'] ) && ! empty( $action_data['target_id'] ) ) {
            $target_id   = (int) $action_data['target_id'];
            $anchor_text = $action_data['anchor_text'] ?? '';

            if ( ! $target_id || ! get_post( $target_id ) ) {
                if ( $pre_swap_content !== null ) {
                    wp_update_post( array( 'ID' => $post_id, 'post_content' => $pre_swap_content ) );
                    self::recount_internal_links( $post_id );
                }
                return array( 'success' => false, 'log' => 'L\'article vers lequel ce lien devait pointer n\'existe plus ou a été mis en brouillon. Cette proposition est devenue obsolète.' );
            }

            // Pre-check + auto-refresh : si l'ancre extract n'existe plus, tenter un recalcul automatique
            $anchor_type_check = $action_data['anchor_type'] ?? '';
            if ( $anchor_type_check === 'extract' && ! empty( $anchor_text ) ) {
                $src_content = get_post_field( 'post_content', $post_id );
                if ( $src_content ) {
                    $txt_clean = mb_strtolower( wp_strip_all_tags( html_entity_decode( $src_content, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
                    $txt_clean = str_replace( array( "\xC2\xA0", "\xA0" ), ' ', $txt_clean );
                    $txt_clean = str_replace( array( "\xE2\x80\x98", "\xE2\x80\x99" ), "'", $txt_clean );
                    $txt_clean = str_replace( array( "\xE2\x80\x91", "\xE2\x80\x93", "\xE2\x80\x94" ), '-', $txt_clean );
                    $anc_clean = mb_strtolower( trim( $anchor_text ) );
                    $anc_clean = str_replace( array( "\xC2\xA0", "\xA0" ), ' ', $anc_clean );
                    $anc_clean = str_replace( array( "\xE2\x80\x98", "\xE2\x80\x99" ), "'", $anc_clean );
                    $anc_clean = str_replace( array( "\xE2\x80\x91", "\xE2\x80\x93", "\xE2\x80\x94" ), '-', $anc_clean );
                    if ( mb_strpos( $txt_clean, $anc_clean ) === false ) {
                        // Ancre stale → tenter un recalcul automatique
                        $old_anchor = $anchor_text;
                        $new_anchor = self::find_best_anchor( $post_id, $target_id );
                        if ( $new_anchor ) {
                            $anchor_text = $new_anchor;
                            $action_data['anchor_text']   = $new_anchor;
                            $action_data['anchor_type']   = 'extract';
                            $action_data['anchor_method'] = 'php';
                            unset( $action_data['anchor_bridge'] );
                            $action_data['_auto_refreshed'] = true;
                            if ( function_exists( 'hts_add_log' ) ) {
                                hts_add_log( sprintf( 'Auto-refresh ancre : « %s » → « %s » pour #%d', mb_substr( $old_anchor, 0, 40 ), mb_substr( $new_anchor, 0, 40 ), $post_id ), 'info', 'workflow' );
                            }
                        } else {
                            if ( $pre_swap_content !== null ) {
                                wp_update_post( array( 'ID' => $post_id, 'post_content' => $pre_swap_content ) );
                                self::recount_internal_links( $post_id );
                            }
                            return array( 'success' => false, 'skipped' => true, 'log' => sprintf(
                                'Aucune ancre trouvée dans l\'article #%d pour « %s ». L\'article n\'a pas de passage pertinent.',
                                $post_id, mb_substr( get_the_title( $target_id ), 0, 50 )
                            ) );
                        }
                    }
                }
            }

            // v2.4.17: Use return_mode to capture result without wp_die()
            if ( method_exists( $linker, 'do_apply_link' ) ) {
                $apply_options = array();
                if ( ! empty( $action_data['anchor_type'] ) ) {
                    $apply_options['anchor_type'] = $action_data['anchor_type'];
                }
                if ( ! empty( $action_data['anchor_bridge'] ) ) {
                    $apply_options['anchor_bridge'] = $action_data['anchor_bridge'];
                }
                $result = $linker->do_apply_link( $post_id, $target_id, $anchor_text, true, $apply_options );

                // S16 Fix P3: needs_confirm means fuzzy anchor match — auto-confirm in workflow context
                if ( is_array( $result ) && ! empty( $result['success'] ) && ! empty( $result['data']['needs_confirm'] ) ) {
                    // Re-run with confirmed=true to actually insert the link
                    $_POST['confirmed'] = '1';
                    $apply_options['confirmed'] = true;
                    $result = $linker->do_apply_link( $post_id, $target_id, $anchor_text, true, $apply_options );
                    unset( $_POST['confirmed'] );
                }

                if ( is_array( $result ) && ! empty( $result['success'] ) && empty( $result['data']['needs_confirm'] ) ) {
                    // Build rich execution log with context
                    $rd = $result['data'] ?? array();
                    $log_parts = array();
                    $log_parts[] = 'Lien ajouté';
                    if ( ! empty( $rd['matched_anchor'] ) ) {
                        $log_parts[] = 'ancre : « ' . mb_substr( $rd['matched_anchor'], 0, 50 ) . ' »';
                    }
                    if ( ! empty( $rd['target_title'] ) ) {
                        $log_parts[] = '→ ' . mb_substr( $rd['target_title'], 0, 60 );
                    }
                    if ( ! empty( $rd['strategy'] ) ) {
                        $log_parts[] = '(' . $rd['strategy'] . ')';
                    }
                    // Invalider tous les caches linking + cocon pour que le graph montre les nouveaux liens
                    global $wpdb;
                    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient%hts\_cocon\_data%' OR option_name LIKE '_transient%hts\_cocon\_sug%' OR option_name LIKE '_transient%hts\_cluster\_links\_%' OR option_name LIKE '_transient%hts\_wl\_%'" );

                    return array(
                        'success' => true,
                        'log'     => implode( ' — ', $log_parts ) . ( ! empty( $action_data['_swap_log'] ) ? "\n" . $action_data['_swap_log'] : '' ),
                        'context' => $rd['context'] ?? '',
                        'anchor'  => $rd['matched_anchor'] ?? $anchor_text,
                        'target'  => $rd['target_title'] ?? '',
                        'target_url' => $rd['target_url'] ?? '',
                    );
                }
                // Return mode failed — try fallback
                if ( is_array( $result ) && ! $result['success'] ) {
                    // Sprint 6.2d: rollback swap if insertion failed
                    if ( $pre_swap_content !== null ) {
                        wp_update_post( array( 'ID' => $post_id, 'post_content' => $pre_swap_content ) );
                        self::recount_internal_links( $post_id );
                        if ( function_exists( 'hts_add_log' ) ) {
                            hts_add_log( sprintf( '↩️ Swap annulé (insertion échouée) : page #%d', $post_id ), 'warn', 'workflow' );
                        }
                    }
                    return array( 'success' => false, 'log' => sprintf( 'Le texte « %s » n\'a pas été trouvé dans l\'article #%d (insertion directe). Le contenu a peut-être été modifié. Cliquez "Nouvelle ancre" pour recalculer.', mb_substr( $anchor_text, 0, 60 ), $post_id ) );
                }
            }

            // Fallback : insertion via Cocon
            if ( class_exists( 'HTS_Cocon' ) ) {
                $cocon = new \HTS_Cocon();
                if ( method_exists( $cocon, 'apply_single_link' ) ) {
                    $ok = $cocon->apply_single_link( $post_id, $target_id, $anchor_text );
                    if ( $ok ) {
                        return array(
                            'success' => true,
                            'log'     => ( ! empty( $action_data['_swap_log'] ) ? $action_data['_swap_log'] . "\n" : '' ) . 'Lien ajouté (cocon) — ancre : « ' . mb_substr( $anchor_text, 0, 50 ) . ' » → ' . mb_substr( get_the_title( $target_id ), 0, 60 ),
                        );
                    }
                }
            }

            // Sprint 6.2d: all insertion paths failed — rollback swap if it happened
            if ( $pre_swap_content !== null ) {
                wp_update_post( array( 'ID' => $post_id, 'post_content' => $pre_swap_content ) );
                self::recount_internal_links( $post_id );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf( '↩️ Swap annulé (aucune méthode d\'insertion n\'a réussi) : page #%d', $post_id ), 'warn', 'workflow' );
                }
            }
            return array( 'success' => false, 'log' => sprintf( 'Le texte « %s » n\'a pas été trouvé dans l\'article #%d (toutes les méthodes épuisées). L\'ancre proposée n\'existe pas mot pour mot dans le contenu actuel. Cliquez "Nouvelle ancre" pour recalculer.', mb_substr( $anchor_text, 0, 60 ), $post_id ) );
        }

        // ── Fallback : analyse IA standalone (pas de données cocon) ──
        // S16 Fix P2: analyze_for_post only STORES suggestions, it does NOT insert links.
        // Return explicit failure so the CEO sees "no target specified" instead of fake "Applied".
        if ( method_exists( $linker, 'analyze_for_post' ) ) {
            try {
                $suggestions = $linker->analyze_for_post( $post_id );
            } catch ( \Exception $e ) {
                // S16 Fix P5: wrap in try/catch to prevent zombie 'executing' status
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf( 'analyze_for_post crash post #%d: %s', $post_id, $e->getMessage() ), 'error', 'workflow' );
                }
                return array( 'success' => false, 'log' => 'Erreur d\'analyse : ' . mb_substr( $e->getMessage(), 0, 80 ) );
            }

            if ( ! empty( $suggestions ) ) {
                update_post_meta( $post_id, '_hts_link_suggestions', wp_json_encode( $suggestions ) );
                update_post_meta( $post_id, '_hts_link_suggestions_count', count( $suggestions ) );
                return array(
                    'success' => false,
                    'log'     => count( $suggestions ) . ' suggestion(s) trouvée(s) — sélectionnez un lien dans le graphe Cocon pour l\'appliquer',
                );
            }
        }

        return array( 'success' => false, 'log' => 'Aucune cible de lien identifiée pour cette page' );
    }

    /**
     * Recount internal outbound links from post content and sync the meta.
     * Sprint 6.2d: Single source of truth for _hts_internal_links_out.
     * Aligned with HTS_Cocon_Commander::count_all_internal_links() for consistent counts.
     *
     * @since 2.5.0
     * @param int $post_id
     * @return int Current internal link count
     */
    public static function recount_internal_links( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) {
            update_post_meta( $post_id, '_hts_internal_links_out', 0 );
            return 0;
        }

        // Use home_url host (same as count_all_internal_links in Cocon Commander)
        $host  = wp_parse_url( home_url(), PHP_URL_HOST );
        $count = 0;

        // Pre-compute self-URL variants to skip self-links
        $self_urls = array();
        $self_permalink = get_permalink( $post_id );
        if ( $self_permalink ) {
            $self_urls[] = $self_permalink;
            $self_urls[] = untrailingslashit( $self_permalink );
            $self_urls[] = trailingslashit( $self_permalink );
            $self_rel = wp_make_link_relative( $self_permalink );
            if ( $self_rel ) {
                $self_urls[] = $self_rel;
                $self_urls[] = untrailingslashit( $self_rel );
                $self_urls[] = trailingslashit( $self_rel );
            }
        }

        if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\'#]+)["\'][^>]*>/i', $post->post_content, $m ) ) {
            foreach ( $m[1] as $href ) {
                $is_internal = ( strpos( $href, $host ) !== false )
                            || ( strpos( $href, '/' ) === 0 && strpos( $href, '//' ) !== 0 );
                if ( ! $is_internal ) continue;

                // Skip self-links
                if ( ! empty( $self_urls ) ) {
                    $href_clean = untrailingslashit( $href );
                    $is_self = false;
                    foreach ( $self_urls as $su ) {
                        if ( $href_clean === untrailingslashit( $su ) ) { $is_self = true; break; }
                    }
                    if ( $is_self ) continue;
                }

                $count++;
            }
        }

        update_post_meta( $post_id, '_hts_internal_links_out', $count );
        return $count;
    }

    /**
     * Optimiser pour la visibilité IA (recalculer GEO + identifier les critères faibles).
     *
     * @since 2.4.0
     * @param int   $post_id
     * @param array $data Action data with criterion, suggestion, etc.
     * @return bool|array  Bool for simple result, array with 'success'+'log' for rich feedback.
     */
    private static function dispatch_geo_optimize( $post_id, $data ) {
        if ( ! get_post( $post_id ) ) return false;

        $criterion = $data['criterion'] ?? '';

        // ── Sprint 6.3 fix : critère FAQ → générer une vraie FAQ via LLM ──
        if ( $criterion === 'faq_lists' ) {
            if ( class_exists( 'HTS_Content_Refresh' ) && method_exists( 'HTS_Content_Refresh', 'add_faq_from_coach' ) ) {
                $faq_result = HTS_Content_Refresh::add_faq_from_coach( array( 'post_id' => $post_id ) );

                // FAQ déjà présente → succès silencieux
                if ( is_array( $faq_result ) && ! empty( $faq_result['skipped'] ) ) {
                    return array( 'success' => true, 'log' => $faq_result['reason'] ?? 'FAQ déjà présente' );
                }

                if ( $faq_result ) {
                    // Recalculer le GEO score après ajout FAQ
                    $new_score = 0;
                    if ( class_exists( 'HTS_Geo_Score' ) ) {
                        $geo = new HTS_Geo_Score();
                        $new_result = $geo->calculate( $post_id, true );
                        $new_score  = (int) ( $new_result['geo_score'] ?? 0 );
                    } elseif ( class_exists( 'HTS_GEO_Score' ) ) {
                        $geo = new \HTS_GEO_Score();
                        $new_result = $geo->calculate( $post_id, true );
                        $new_score  = (int) ( $new_result['geo_score'] ?? 0 );
                    }
                    $old_score = (int) ( $data['geo_score'] ?? 0 );
                    return array(
                        'success' => true,
                        'log'     => sprintf( 'FAQ ajoutée (5 Q&A) — Score GEO : %d → %d', $old_score, $new_score ),
                    );
                }

                // Échec génération FAQ (pas de clé API IA, erreur LLM, etc.)
                return array( 'success' => false, 'log' => 'Impossible de générer la FAQ — vérifiez qu\'une clé API IA (OpenAI ou Anthropic) est configurée dans les réglages Coach SEO.' );
            }
            return array( 'success' => false, 'log' => 'Module Content Refresh indisponible.' );
        }

        // ── Autres critères GEO : recalculer le score + stocker les recommandations ──
        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $geo = new HTS_Geo_Score();
            $result = $geo->calculate( $post_id, true );
        } elseif ( class_exists( 'HTS_GEO_Score' ) ) {
            $geo = new HTS_GEO_Score();
            $result = $geo->calculate( $post_id, true );
        }

        // Stocker les recommandations en meta pour la page article
        $suggestions = array();
        if ( ! empty( $data['suggestion'] ) ) {
            $suggestions[] = sanitize_text_field( $data['suggestion'] );
        }
        if ( ! empty( $data['top_why'] ) ) {
            $suggestions[] = sanitize_text_field( $data['top_why'] );
        }
        if ( ! empty( $suggestions ) ) {
            update_post_meta( $post_id, '_hts_geo_suggestions', wp_json_encode( $suggestions ) );
        }

        // Marquer l'article pour optimisation GEO
        update_post_meta( $post_id, '_hts_needs_geo_optimize', 1 );
        update_post_meta( $post_id, '_hts_geo_optimize_reason', sanitize_text_field( $data['reason'] ?? '' ) );

        $new_score = isset( $result ) ? (int) ( $result['geo_score'] ?? 0 ) : 0;
        $old_score = (int) ( $data['geo_score'] ?? 0 );
        $suggestion_text = $data['suggestion'] ?? '';

        return array(
            'success' => true,
            'log'     => sprintf( 'Score GEO recalculé : %d → %d. Recommandation : %s', $old_score, $new_score, $suggestion_text ),
        );
    }

    /**
     * Générer une image mise en avant via le pipeline image existant (Flux / GPT Image / Pexels).
     *
     * @since 2.5.6
     * @param int   $post_id
     * @param array $data
     * @return array { success, log }
     */
    private static function dispatch_generate_featured_image( $post_id, $data ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'success' => false, 'log' => 'Article introuvable.' );

        // Déjà une image ?
        if ( has_post_thumbnail( $post_id ) ) {
            return array( 'success' => true, 'log' => 'Image mise en avant déjà présente.' );
        }

        // Vérifier que le pipeline image est dispo
        if ( ! class_exists( 'Hts_Synchronise_Articles_Admin' ) || ! method_exists( 'Hts_Synchronise_Articles_Admin', 'cocon_generate_article_images' ) ) {
            return array( 'success' => false, 'log' => 'Module de génération d\'images indisponible.' );
        }

        $img_cfg  = \Hts_Synchronise_Articles_Admin::get_image_settings();
        $provider = $img_cfg['image_provider'] ?? 'openai';

        // Vérifier la clé API du provider choisi
        if ( $provider === 'flux' && empty( $img_cfg['flux_api_key'] ?? '' ) ) {
            return array( 'success' => false, 'log' => 'Clé API BFL (Flux) manquante. Configurez-la dans Réglages → Images IA.' );
        }
        if ( $provider !== 'flux' ) {
            $openai_key = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : '';
            if ( empty( $openai_key ) ) {
                return array( 'success' => false, 'log' => 'Clé API OpenAI manquante. Configurez-la dans Réglages → Clés API.' );
            }
        }

        // ── Quota mensuel images Inbox ──
        $month_key     = 'hts_inbox_images_' . wp_date( 'Y_m' );
        $month_used    = (int) get_option( $month_key, 0 );
        $month_limit   = (int) self::get_agent_guardrail( 'content_quality', 'images_month_limit' );
        if ( $month_limit <= 0 ) $month_limit = 50; // Défaut : 50 images/mois

        // v2.5.12: Only 1 featured image from Inbox
        $estimated_images = 1;
        if ( ( $month_used + $estimated_images ) > $month_limit ) {
            return array(
                'success' => false,
                'log'     => sprintf( 'Quota images Inbox atteint : %d/%d ce mois-ci. Le quota se réinitialise le 1er du mois.', $month_used, $month_limit ),
            );
        }

        $title   = $post->post_title;
        $keyword = get_post_meta( $post_id, '_hts_api_keyword', true )
                ?: get_post_meta( $post_id, '_hts_focus_keyword', true )
                ?: $title;
        $content = $post->post_content;

        // v2.5.12: From Inbox, only generate the FEATURED image (1 image, not 3)
        // In-content images are generated during article creation, not from Inbox
        // v2.6.2: Use a filter instead of modifying the global option to avoid race conditions
        $inbox_image_override = function ( $settings ) {
            $settings['featured_enabled']  = true;
            $settings['incontent_enabled'] = false;
            $settings['incontent_count']   = 0;
            return $settings;
        };
        add_filter( 'hts_image_settings', $inbox_image_override, 99 );

        try {
            // v2.5.12: Temporarily switch locale to post language for image prompt generation
            $post_lang_img = '';
            if ( function_exists( 'pll_get_post_language' ) ) {
                $post_lang_img = pll_get_post_language( $post_id, 'locale' ) ?: '';
            }
            $original_locale = get_locale();
            if ( $post_lang_img && $post_lang_img !== $original_locale && function_exists( 'switch_to_locale' ) ) {
                switch_to_locale( $post_lang_img );
            }

            $img_result = \Hts_Synchronise_Articles_Admin::cocon_generate_article_images(
                $post_id, $title, $keyword, $content
            );

            // Restore original locale
            if ( $post_lang_img && $post_lang_img !== $original_locale && function_exists( 'restore_previous_locale' ) ) {
                restore_previous_locale();
            }

            // Remove the filter
            remove_filter( 'hts_image_settings', $inbox_image_override, 99 );

            $count = $img_result['count'] ?? 0;
            if ( $count > 0 || has_post_thumbnail( $post_id ) ) {
                // Incrémenter le compteur mensuel
                update_option( $month_key, $month_used + max( $count, 1 ), false );

                // v2.5.12: Return thumbnail URL for rich UI feedback
                $thumb_url = '';
                $thumb_id = get_post_thumbnail_id( $post_id );
                if ( $thumb_id ) {
                    $thumb_src = wp_get_attachment_image_src( $thumb_id, 'medium' );
                    $thumb_url = $thumb_src ? $thumb_src[0] : '';
                }

                return array(
                    'success'       => true,
                    'log'           => sprintf( '%d image(s) générée(s) via %s — Quota : %d/%d ce mois', $count, ucfirst( $provider ), $month_used + $count, $month_limit ),
                    'thumbnail_url' => $thumb_url,
                );
            }

            return array( 'success' => false, 'log' => 'Le pipeline image n\'a produit aucun résultat. Vérifiez les logs et la configuration.' );
        } catch ( \Throwable $e ) {
            remove_filter( 'hts_image_settings', $inbox_image_override, 99 );
            // v2.5.12: Restore locale on error too
            if ( ! empty( $post_lang_img ) && $post_lang_img !== $original_locale && function_exists( 'restore_previous_locale' ) ) {
                restore_previous_locale();
            }
            return array( 'success' => false, 'log' => 'Erreur génération image : ' . mb_substr( $e->getMessage(), 0, 200 ) );
        }
    }

    /**
     * Corriger les ALT manquants des images d'un article via IA (GPT-4.1-mini).
     *
     * @since 2.5.6
     * @param int   $post_id
     * @param array $data
     * @return array { success, log }
     */
    private static function dispatch_fix_image_alt( $post_id, $data ) {
        $post = get_post( $post_id );
        if ( ! $post ) return array( 'success' => false, 'log' => 'Article introuvable.' );

        // ── 1. Trouver les attachments image sans ALT (approche hybride) ──
        global $wpdb;

        // D'abord : images directement rattachées via post_parent
        $attachments = $wpdb->get_results( $wpdb->prepare( "
            SELECT att.ID, att.guid, att.post_title
            FROM {$wpdb->posts} att
            LEFT JOIN {$wpdb->postmeta} alt_meta
                ON att.ID = alt_meta.post_id AND alt_meta.meta_key = '_wp_attachment_image_alt'
            WHERE att.post_type = 'attachment'
              AND att.post_mime_type LIKE 'image/%%'
              AND att.post_parent = %d
              AND (alt_meta.meta_value IS NULL OR alt_meta.meta_value = '')
            LIMIT 20
        ", $post_id ) );

        // Ensuite : images sans post_parent mais dont le filename apparaît dans post_content
        if ( empty( $attachments ) || count( $attachments ) < 5 ) {
            $found_ids = wp_list_pluck( $attachments, 'ID' );
            $orphan_atts = $wpdb->get_results( "
                SELECT att.ID, att.guid, att.post_title
                FROM {$wpdb->posts} att
                LEFT JOIN {$wpdb->postmeta} alt_meta
                    ON att.ID = alt_meta.post_id AND alt_meta.meta_key = '_wp_attachment_image_alt'
                WHERE att.post_type = 'attachment'
                  AND att.post_mime_type LIKE 'image/%'
                  AND att.post_parent = 0
                  AND (alt_meta.meta_value IS NULL OR alt_meta.meta_value = '')
                ORDER BY att.ID DESC
                LIMIT 100
            " );

            $content_to_search = $post->post_content;
            // Aussi chercher dans _elementor_data si Elementor
            $el_data = get_post_meta( $post_id, '_elementor_data', true );
            if ( $el_data ) $content_to_search .= ' ' . $el_data;

            foreach ( $orphan_atts as $oatt ) {
                if ( count( $attachments ) >= 20 ) break;
                if ( in_array( (int) $oatt->ID, $found_ids, true ) ) continue;
                $filename = basename( $oatt->guid );
                if ( $filename && stripos( $content_to_search, $filename ) !== false ) {
                    $attachments[] = $oatt;
                    $found_ids[] = (int) $oatt->ID;
                }
            }
        }

        if ( empty( $attachments ) ) {
            return array( 'success' => true, 'log' => 'Toutes les images ont déjà un attribut ALT.' );
        }

        // ── 2. Préparer le contexte pour l'IA ──
        $title   = $post->post_title;
        $keyword = get_post_meta( $post_id, '_hts_api_keyword', true )
                ?: get_post_meta( $post_id, '_hts_focus_keyword', true )
                ?: $title;

        // v2.5.12: Detect post language for Polylang/WPML — ALT must match content language
        $post_lang = '';
        $lang_instruction = '';
        if ( function_exists( 'pll_get_post_language' ) ) {
            $post_lang = pll_get_post_language( $post_id, 'slug' ) ?: '';
        } elseif ( function_exists( 'wpml_get_language_information' ) ) {
            $lang_info = wpml_get_language_information( null, $post_id );
            $post_lang = $lang_info['language_code'] ?? '';
        }
        if ( empty( $post_lang ) ) {
            $post_lang = strtolower( substr( get_locale(), 0, 2 ) );
        }
        $lang_names = array( 'fr' => 'français', 'en' => 'anglais', 'es' => 'espagnol', 'de' => 'allemand', 'it' => 'italien', 'pt' => 'portugais', 'nl' => 'néerlandais' );
        $lang_name = $lang_names[ $post_lang ] ?? $post_lang;
        $lang_instruction = "\n- LANGUE : Tous les ALT doivent être rédigés en **{$lang_name}** (langue du contenu)";

        $missing_alt = array();
        $images_desc = array();
        foreach ( $attachments as $i => $att ) {
            $src = wp_get_attachment_url( (int) $att->ID ) ?: $att->guid;
            $filename = basename( $src );
            $missing_alt[] = array(
                'src'           => $src,
                'attachment_id' => (int) $att->ID,
                'filename'      => $filename,
            );
            $images_desc[] = sprintf( '%d. Fichier : %s (URL : %s)', $i + 1, $filename, $src );
        }

        // ── 3. Appel IA — GPT-4.1-mini (rapide + pas cher) ──
        $openai_key = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : '';
        if ( empty( $openai_key ) ) {
            // Fallback Anthropic
            $anthropic_key = hts_get_anthropic_key();
            if ( empty( $anthropic_key ) || strlen( $anthropic_key ) < 20 ) {
                return array( 'success' => false, 'log' => 'Aucune clé API IA configurée pour générer les ALT.' );
            }
            return self::dispatch_fix_image_alt_anthropic( $post_id, $missing_alt, $title, $keyword, $images_desc, $anthropic_key, $lang_instruction );
        }

        $prompt = "Tu es un expert SEO. Génère un attribut ALT optimisé pour chaque image de cet article.

Titre de l'article : {$title}
Mot-clé cible : {$keyword}

Images sans ALT :
" . implode( "\n", $images_desc ) . "

RÈGLES :
- ALT descriptif de 5-15 mots, naturel, pas de keyword stuffing
- Inclure le mot-clé ou un synonyme dans au moins 1 ALT sur 3
- Déduire le contenu de l'image à partir du nom de fichier et du contexte de l'article
- PAS de \"image de\" ou \"photo de\" au début{$lang_instruction}

Réponds UNIQUEMENT en JSON valide :
[{\"src\":\"URL_IMAGE\",\"alt\":\"texte ALT\"}]";

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $openai_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'model'       => 'gpt-4.1-mini',
                'messages'    => array(
                    array( 'role' => 'system', 'content' => 'Tu réponds UNIQUEMENT en JSON valide. Pas de markdown, pas de backticks.' ),
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
                'temperature' => 0.2,
                'max_tokens'  => 1000,
            ) ),
        ) );

        return self::process_alt_response( $response, 'openai', $post_id, $missing_alt );
    }

    /**
     * Fallback Anthropic pour la génération d'ALT.
     */
    private static function dispatch_fix_image_alt_anthropic( $post_id, $missing_alt, $title, $keyword, $images_desc, $api_key, $lang_instruction = '' ) {
        $prompt = "Tu es un expert SEO. Génère un attribut ALT optimisé pour chaque image.

Titre : {$title}
Mot-clé : {$keyword}

Images sans ALT :
" . implode( "\n", $images_desc ) . "

RÈGLES : ALT de 5-15 mots, naturel, mot-clé dans 1/3 des ALT, pas de \"image de\" au début.{$lang_instruction}

Réponds UNIQUEMENT en JSON : [{\"src\":\"URL\",\"alt\":\"texte\"}]";

        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
            'timeout' => 30,
            'headers' => array(
                'x-api-key'        => $api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type'     => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'model'      => 'claude-haiku-4-5-20251001',
                'max_tokens' => 1000,
                'system'     => 'Tu réponds UNIQUEMENT en JSON valide.',
                'messages'   => array(
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
            ) ),
        ) );

        return self::process_alt_response( $response, 'anthropic', $post_id, $missing_alt );
    }

    /**
     * Traiter la réponse IA et appliquer les ALT via Content Writer.
     */
    private static function process_alt_response( $response, $provider, $post_id, $missing_alt ) {
        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'log' => 'Erreur API : ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            $err = $provider === 'anthropic'
                ? ( $body['error']['message'] ?? 'HTTP ' . $code )
                : ( $body['error']['message'] ?? 'HTTP ' . $code );
            return array( 'success' => false, 'log' => 'Erreur IA : ' . $err );
        }

        $text = $provider === 'anthropic'
            ? ( $body['content'][0]['text'] ?? '' )
            : ( $body['choices'][0]['message']['content'] ?? '' );

        $text = trim( $text );
        $text = preg_replace( '/^```(?:json)?\s*/i', '', $text );
        $text = preg_replace( '/\s*```$/', '', $text );

        $alts = json_decode( $text, true );
        if ( ! is_array( $alts ) || empty( $alts ) ) {
            return array( 'success' => false, 'log' => 'Réponse IA non parsable : ' . mb_substr( $text, 0, 200 ) );
        }

        // ── Appliquer les ALT via Content Writer (builder-aware) ──
        $applied = 0;
        $errors  = 0;

        // Indexer les ALT par src pour lookup rapide
        $alt_map = array();
        foreach ( $alts as $alt_item ) {
            if ( ! empty( $alt_item['src'] ) && ! empty( $alt_item['alt'] ) ) {
                $alt_map[ $alt_item['src'] ] = sanitize_text_field( $alt_item['alt'] );
            }
        }

        foreach ( $missing_alt as $img ) {
            $new_alt = $alt_map[ $img['src'] ] ?? null;
            if ( ! $new_alt ) continue;

            // Sprint 6.3c: mettre à jour le ALT dans l'attachment WordPress (bibliothèque média)
            // C'est la source de vérité — fonctionne quel que soit le builder
            $attachment_id = ! empty( $img['attachment_id'] ) ? (int) $img['attachment_id'] : attachment_url_to_postid( $img['src'] );
            if ( $attachment_id ) {
                update_post_meta( $attachment_id, '_wp_attachment_image_alt', $new_alt );
                $applied++;
            }

            // Aussi mettre à jour dans le contenu (post_content / builder) si possible
            if ( class_exists( 'HTS_Content_Writer' ) ) {
                HTS_Content_Writer::update_image_alt( $post_id, $img['src'], $new_alt );
            }
        }

        if ( $applied > 0 ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf( 'Fix ALT: %d ALT générés pour post #%d via %s', $applied, $post_id, $provider ), 'info', 'workflow' );
            }
            return array(
                'success' => true,
                'log'     => sprintf( '%d attribut(s) ALT généré(s) et appliqué(s)%s', $applied, $errors > 0 ? sprintf( ' (%d erreur(s))', $errors ) : '' ),
            );
        }

        return array( 'success' => false, 'log' => 'Aucun ALT n\'a pu être appliqué.' );
    }

    /* ═══════════════════════════════════════════════
     *  BACKUP / PREVIEW / ROLLBACK
     * ═══════════════════════════════════════════════ */

    /**
     * Snapshot de l'état actuel AVANT exécution (pour rollback).
     *
     * @since 2.3.1
     */
    /**
     * Capture KPI snapshot for a post (Session H+ — impact measurement).
     *
     * @param int $post_id
     * @return array
     */
    public static function capture_kpi_snapshot( $post_id ) {
        if ( $post_id <= 0 ) return array();

        $snap = array(
            'captured_at' => current_time( 'mysql' ),
            'score'       => (int) get_post_meta( $post_id, '_hts_combined_score', true ),
            'geo_score'   => (int) get_post_meta( $post_id, '_hts_geo_score', true ),
            'gsc_clicks'      => (int) get_post_meta( $post_id, '_hts_gsc_clicks', true ),
            'gsc_impressions' => (int) get_post_meta( $post_id, '_hts_gsc_impressions', true ),
            'gsc_position'    => round( (float) get_post_meta( $post_id, '_hts_gsc_position', true ), 1 ),
            'gsc_ctr'         => round( (float) get_post_meta( $post_id, '_hts_gsc_ctr', true ), 2 ),
        );

        // AI traffic if available
        if ( class_exists( 'HTS_Impact_Tracker' ) ) {
            $tracker = new \HTS_Impact_Tracker();
            $ps = $tracker->get_post_stats( $post_id );
            $snap['ai_visits']  = (int) ( $ps['ai_visits'] ?? 0 );
            $snap['total_visits'] = (int) ( $ps['total_visits'] ?? 0 );
        }

        return $snap;
    }

    /**
     * Process impact measurement queue (called by daily cron).
     * Captures KPI at 7d and 30d after action execution.
     */
    public static function process_impact_queue() {
        $queue = get_option( 'hts_impact_queue', array() );
        if ( empty( $queue ) ) return;

        $today   = gmdate( 'Y-m-d' );
        $updated = false;
        $remaining = array();

        foreach ( $queue as $item ) {
            $action_id = (int) ( $item['action_id'] ?? 0 );
            $post_id   = (int) ( $item['post_id'] ?? 0 );
            $done_7d   = false;
            $done_30d  = false;

            if ( ! $action_id || ! $post_id ) continue;

            // S13-B: Skip deleted posts — don't accumulate stale queue items
            if ( ! get_post_status( $post_id ) ) {
                $updated = true;
                continue; // Drop from queue
            }

            // S13-B: Drop items older than 45 days (measurement window passed)
            $check_30d = $item['check_30d'] ?? '';
            if ( $check_30d && strtotime( $check_30d ) < strtotime( '-15 days' ) ) {
                $updated = true;
                continue; // Drop from queue
            }

            $meta_key = '_hts_impact_' . $action_id;
            $raw = get_post_meta( $post_id, $meta_key, true );
            $impact = $raw ? json_decode( $raw, true ) : null;
            if ( ! $impact ) continue;

            // Check 7-day measurement
            if ( empty( $impact['kpi_7d'] ) && $today >= ( $item['check_7d'] ?? '' ) ) {
                $impact['kpi_7d'] = self::capture_kpi_snapshot( $post_id );
                $updated = true;
                $done_7d = true;
            } else {
                $done_7d = ! empty( $impact['kpi_7d'] );
            }

            // Check 30-day measurement
            if ( empty( $impact['kpi_30d'] ) && $today >= ( $item['check_30d'] ?? '' ) ) {
                $impact['kpi_30d'] = self::capture_kpi_snapshot( $post_id );
                $updated = true;
                $done_30d = true;
            } else {
                $done_30d = ! empty( $impact['kpi_30d'] );
            }

            if ( $updated ) {
                update_post_meta( $post_id, $meta_key, wp_json_encode( $impact ) );
            }

            // Keep in queue until both measurements are done
            if ( ! $done_7d || ! $done_30d ) {
                $remaining[] = $item;
            }
        }

        update_option( 'hts_impact_queue', $remaining, false );

        // Check for inefficient agents (Session I)
        self::check_inefficient_agents();
    }

    /**
     * Detect agents with low success rate and notify admin (Session I).
     *
     * Rule: success_rate < 30% over 10+ measured actions → admin notice.
     * Stores alerts in `hts_agent_inefficiency_alerts` option.
     * Runs once daily via process_impact_queue cron.
     */
    public static function check_inefficient_agents() {
        $report = self::get_impact_report( 200 );
        if ( empty( $report['by_agent'] ) ) return;

        $alerts = array();
        $notif_settings = get_option( 'hts_notification_settings', array() );
        $notify_enabled = ! isset( $notif_settings['agent_inefficient'] ) || ! empty( $notif_settings['agent_inefficient'] );

        foreach ( $report['by_agent'] as $agent_name => $stats ) {
            if ( (int) $stats['count'] < 10 ) continue;
            $success = (int) ( $stats['success_rate'] ?? 100 );
            if ( $success >= 30 ) continue;

            $alerts[] = array(
                'agent'        => $agent_name,
                'success_rate' => $success,
                'count'        => (int) $stats['count'],
                'avg_lift'     => $stats['avg_score_lift'] ?? 0,
                'detected_at'  => gmdate( 'Y-m-d H:i:s' ),
            );
        }

        if ( ! empty( $alerts ) ) {
            update_option( 'hts_agent_inefficiency_alerts', $alerts, false );

            // Send admin notice if notifications enabled
            if ( $notify_enabled ) {
                $admin_email = get_option( 'admin_email' );
                $site_name   = get_bloginfo( 'name' );
                $agent_list  = array();
                foreach ( $alerts as $al ) {
                    $agent_list[] = sprintf( '%s : %d%% de réussite sur %d actions', $al['agent'], $al['success_rate'], $al['count'] );
                }
                $message  = sprintf( "Bonjour,\n\nHack The SEO a détecté des agents avec un taux de réussite faible sur votre site \"%s\" :\n\n", $site_name );
                $message .= implode( "\n", $agent_list );
                $message .= "\n\nNous vous recommandons de désactiver ou reconfigurer ces agents depuis les réglages du plugin.";
                $message .= "\n\n— Hack The SEO";
                wp_mail( $admin_email, '[Hack The SEO] Agent(s) peu efficace(s) détecté(s)', $message );
            }
        } else {
            delete_option( 'hts_agent_inefficiency_alerts' );
        }

        return $alerts;
    }

    /**
     * Get impact data for display — aggregated by agent.
     *
     * @param int $limit Max actions to analyze.
     * @return array
     */
    public static function get_impact_report( $limit = 50 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $actions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, agent, type, post_id, resolved_at
             FROM {$table}
             WHERE status = 'done'
             ORDER BY resolved_at DESC
             LIMIT %d",
            $limit
        ) );

        $by_agent = array();
        $items    = array();

        foreach ( $actions as $a ) {
            $meta_key = '_hts_impact_' . $a->id;
            $raw = get_post_meta( (int) $a->post_id, $meta_key, true );
            if ( ! $raw ) continue;

            $impact = json_decode( $raw, true );
            if ( ! $impact || empty( $impact['kpi_before'] ) ) continue;

            $before = $impact['kpi_before'];
            $after  = $impact['kpi_7d'] ?? $impact['kpi_30d'] ?? null;
            $period = ! empty( $impact['kpi_30d'] ) ? '30j' : ( ! empty( $impact['kpi_7d'] ) ? '7j' : 'en attente' );

            $item = array(
                'action_id'   => (int) $a->id,
                'agent'       => $a->agent,
                'type'        => $a->type,
                'post_id'     => (int) $a->post_id,
                'post_title'  => get_the_title( (int) $a->post_id ),
                'executed_at' => $impact['executed_at'] ?? $a->resolved_at,
                'period'      => $period,
                'before'      => $before,
                'after'       => $after,
                'deltas'      => array(),
            );

            if ( $after ) {
                $item['deltas'] = array(
                    'score'       => ( $after['score'] ?? 0 ) - ( $before['score'] ?? 0 ),
                    'gsc_clicks'  => ( $after['gsc_clicks'] ?? 0 ) - ( $before['gsc_clicks'] ?? 0 ),
                    'gsc_impressions' => ( $after['gsc_impressions'] ?? 0 ) - ( $before['gsc_impressions'] ?? 0 ),
                    'gsc_position' => round( ( $before['gsc_position'] ?? 0 ) - ( $after['gsc_position'] ?? 0 ), 1 ), // inverted: lower is better
                    'ai_visits'   => ( $after['ai_visits'] ?? 0 ) - ( $before['ai_visits'] ?? 0 ),
                );

                // Aggregate by agent
                $ag = $a->agent;
                if ( ! isset( $by_agent[ $ag ] ) ) {
                    $by_agent[ $ag ] = array( 'count' => 0, 'score_lift' => 0, 'clicks_lift' => 0, 'position_lift' => 0, 'positive' => 0, 'neutral' => 0, 'negative' => 0 );
                }
                $by_agent[ $ag ]['count']++;
                $by_agent[ $ag ]['score_lift']    += $item['deltas']['score'];
                $by_agent[ $ag ]['clicks_lift']   += $item['deltas']['gsc_clicks'];
                $by_agent[ $ag ]['position_lift'] += $item['deltas']['gsc_position'];

                // Classify: positive if score OR clicks improved
                $is_positive = $item['deltas']['score'] > 0 || $item['deltas']['gsc_clicks'] > 0 || $item['deltas']['gsc_position'] > 0;
                $is_negative = $item['deltas']['score'] < -5 || $item['deltas']['gsc_clicks'] < -10;
                if ( $is_positive ) $by_agent[ $ag ]['positive']++;
                elseif ( $is_negative ) $by_agent[ $ag ]['negative']++;
                else $by_agent[ $ag ]['neutral']++;
            }

            $items[] = $item;
        }

        // Calculate averages
        foreach ( $by_agent as $ag => &$stats ) {
            if ( $stats['count'] > 0 ) {
                $stats['avg_score_lift']    = round( $stats['score_lift'] / $stats['count'], 1 );
                $stats['avg_clicks_lift']   = round( $stats['clicks_lift'] / $stats['count'], 1 );
                $stats['avg_position_lift'] = round( $stats['position_lift'] / $stats['count'], 1 );
                $stats['success_rate']      = round( $stats['positive'] / $stats['count'] * 100 );
            }
        }
        unset( $stats );

        return array(
            'items'    => $items,
            'by_agent' => $by_agent,
            'total'    => count( $items ),
        );
    }

    public static function create_backup( $post_id, $action_type ) {
        if ( $post_id <= 0 ) return array();

        $backup = array( 'timestamp' => current_time( 'mysql' ), 'type' => $action_type );

        switch ( $action_type ) {
            case 'add_meta_title':
            case 'optimize_meta_title':
                $backup['meta_title'] = get_post_meta( $post_id, '_hts_meta_title', true );
                break;
            case 'add_meta_desc':
            case 'optimize_meta_desc':
                $backup['meta_description'] = get_post_meta( $post_id, '_hts_meta_description', true );
                break;
            case 'optimize_meta_both':
                $backup['meta_title']       = get_post_meta( $post_id, '_hts_meta_title', true );
                $backup['meta_description'] = get_post_meta( $post_id, '_hts_meta_description', true );
                break;
            case 'add_featured_image':
                $backup['thumbnail_id'] = get_post_thumbnail_id( $post_id );
                break;
            case 'delete_page':
                $post = get_post( $post_id );
                $backup['post_status'] = $post ? $post->post_status : '';
                $backup['post_title']  = $post ? $post->post_title : '';
                break;
            case 'content_refresh':
                $post = get_post( $post_id );
                $backup['content']          = $post ? $post->post_content : '';
                $backup['post_title']       = $post ? $post->post_title : '';
                $backup['meta_title']       = get_post_meta( $post_id, '_hts_meta_title', true );
                $backup['meta_description'] = get_post_meta( $post_id, '_hts_meta_description', true );
                $backup = self::backup_builder_data( $post_id, $backup );
                break;

            // ── Toutes les actions qui modifient le contenu → backup content + tous builders ──
            case 'fix_orphan_links':
            case 'add_internal_links':
            case 'add_faq':
            case 'geo_optimize':
            case 'enrich_thin_content':
                $post = get_post( $post_id );
                $backup['content']   = $post ? $post->post_content : '';
                $backup['links_out'] = get_post_meta( $post_id, '_hts_internal_links_out', true );
                $backup = self::backup_builder_data( $post_id, $backup );
                break;

            case 'fix_image_alt':
                $post = get_post( $post_id );
                $backup['content']   = $post ? $post->post_content : '';
                $backup = self::backup_builder_data( $post_id, $backup );
                // Sprint 6.3c: sauvegarder les ALT actuels des attachments pour rollback
                global $wpdb;
                $attachments = $wpdb->get_results( $wpdb->prepare( "
                    SELECT att.ID
                    FROM {$wpdb->posts} att
                    WHERE att.post_type = 'attachment'
                      AND att.post_mime_type LIKE 'image/%%'
                      AND att.post_parent = %d
                ", $post_id ) );
                $alt_backup = array();
                foreach ( $attachments as $att ) {
                    $alt_backup[ (int) $att->ID ] = get_post_meta( (int) $att->ID, '_wp_attachment_image_alt', true ) ?: '';
                }
                $backup['attachment_alts'] = $alt_backup;
                break;

            default:
                $post = get_post( $post_id );
                if ( $post ) {
                    $backup['content']    = $post->post_content;
                    $backup['post_title'] = $post->post_title;
                }
                $backup = self::backup_builder_data( $post_id, $backup );
                break;
        }

        return $backup;
    }

    /**
     * Backup all page builder data for a post (Elementor, Beaver, Bricks).
     * Called by create_backup() for any action that modifies content.
     *
     * @since 2.5.6
     * @param int   $post_id
     * @param array $backup Existing backup array to enrich
     * @return array Enriched backup
     */
    private static function backup_builder_data( $post_id, $backup ) {
        // Elementor
        $el_data = get_post_meta( $post_id, '_elementor_data', true );
        if ( $el_data ) $backup['_elementor_data'] = $el_data;

        // Beaver Builder
        $bb_data = get_post_meta( $post_id, '_fl_builder_data', true );
        if ( $bb_data ) $backup['_fl_builder_data'] = $bb_data;

        // Bricks
        $bricks_data = get_post_meta( $post_id, '_bricks_page_content_2', true );
        if ( $bricks_data ) $backup['_bricks_page_content_2'] = $bricks_data;

        return $backup;
    }

    /**
     * Restore all page builder data from a backup.
     * Called by rollback() for any action that modified content.
     *
     * @since 2.5.6
     * @param int   $post_id
     * @param array $backup Backup array containing builder data
     */
    private static function restore_builder_data( $post_id, $backup ) {
        // Elementor
        if ( ! empty( $backup['_elementor_data'] ) ) {
            // Full restore from backup
            update_post_meta( $post_id, '_elementor_data', wp_slash( $backup['_elementor_data'] ) );
            delete_post_meta( $post_id, '_elementor_css' );
            if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
                \Elementor\Plugin::$instance->files_manager->clear_cache();
            }
        } elseif ( isset( $backup['content'] ) && class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_elementor( $post_id ) ) {
            // Legacy backup (pre-v2.5.6): no _elementor_data in backup but post is Elementor.
            // Clean HTS-injected content from current _elementor_data.
            $current_el_data = get_post_meta( $post_id, '_elementor_data', true );
            $data_arr        = is_string( $current_el_data ) ? json_decode( $current_el_data, true ) : null;

            if ( is_array( $data_arr ) && ! empty( $data_arr ) ) {
                // Remove any HTS FAQ widgets (hts-faq markers) from Elementor data
                $cleaned = false;
                array_walk_recursive( $data_arr, function( &$val, $key ) use ( &$cleaned ) {
                    if ( $key === 'editor' && is_string( $val ) && strpos( $val, 'hts-faq' ) !== false ) {
                        $val = ''; // Clear the FAQ content from the widget
                        $cleaned = true;
                    }
                });

                // Also check for HTS Coach FAQ markers (old format)
                array_walk_recursive( $data_arr, function( &$val, $key ) use ( &$cleaned ) {
                    if ( $key === 'editor' && is_string( $val ) && strpos( $val, 'HTS Coach FAQ' ) !== false ) {
                        $val = '';
                        $cleaned = true;
                    }
                });

                // Remove empty widgets after cleanup
                if ( $cleaned ) {
                    $data_arr = self::remove_empty_elementor_widgets( $data_arr );
                    $json = wp_json_encode( $data_arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
                    update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
                    delete_post_meta( $post_id, '_elementor_css' );
                    if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
                        \Elementor\Plugin::$instance->files_manager->clear_cache();
                    }
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf( 'Rollback: FAQ nettoyée dans _elementor_data pour post #%d (backup legacy)', $post_id ), 'info', 'workflow' );
                    }
                }
            }
        }

        // Beaver Builder
        if ( ! empty( $backup['_fl_builder_data'] ) ) {
            update_post_meta( $post_id, '_fl_builder_data', $backup['_fl_builder_data'] );
        } elseif ( isset( $backup['content'] ) && class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_beaver( $post_id ) ) {
            // Legacy: try to clean HTS content from Beaver data
            $bb_data = get_post_meta( $post_id, '_fl_builder_data', true );
            if ( is_array( $bb_data ) ) {
                $cleaned = false;
                foreach ( $bb_data as $nid => $node ) {
                    $text = $node->settings->text ?? ( $node['settings']['text'] ?? '' );
                    if ( is_string( $text ) && ( strpos( $text, 'hts-faq' ) !== false || strpos( $text, 'HTS Coach FAQ' ) !== false ) ) {
                        unset( $bb_data[ $nid ] );
                        $cleaned = true;
                    }
                }
                if ( $cleaned ) {
                    update_post_meta( $post_id, '_fl_builder_data', $bb_data );
                }
            }
        }

        // Bricks
        if ( ! empty( $backup['_bricks_page_content_2'] ) ) {
            update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( $backup['_bricks_page_content_2'] ) );
        } elseif ( isset( $backup['content'] ) && class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_bricks( $post_id ) ) {
            // Legacy: try to clean HTS content from Bricks data
            $bricks_data = get_post_meta( $post_id, '_bricks_page_content_2', true );
            if ( is_string( $bricks_data ) ) $bricks_data = json_decode( $bricks_data, true );
            if ( is_array( $bricks_data ) ) {
                $cleaned = false;
                foreach ( $bricks_data as $idx => $el ) {
                    $text = $el['settings']['text'] ?? '';
                    if ( is_string( $text ) && ( strpos( $text, 'hts-faq' ) !== false || strpos( $text, 'HTS Coach FAQ' ) !== false ) ) {
                        unset( $bricks_data[ $idx ] );
                        $cleaned = true;
                    }
                }
                if ( $cleaned ) {
                    $bricks_data = array_values( $bricks_data ); // Re-index
                    update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $bricks_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
                }
            }
        }
    }

    /**
     * Remove Elementor widgets whose editor content is empty (after FAQ cleanup).
     *
     * @since 2.5.6
     * @param array $elements Elementor data tree
     * @return array Cleaned tree
     */
    private static function remove_empty_elementor_widgets( $elements ) {
        $result = array();
        foreach ( $elements as $el ) {
            if ( isset( $el['widgetType'] ) && $el['widgetType'] === 'text-editor' ) {
                $editor = $el['settings']['editor'] ?? '';
                if ( trim( $editor ) === '' ) continue; // Skip empty text-editor widgets
            }
            if ( ! empty( $el['elements'] ) ) {
                $el['elements'] = self::remove_empty_elementor_widgets( $el['elements'] );
            }
            $result[] = $el;
        }
        return $result;
    }

    /**
     * Nettoyer les contenus HTS (FAQ, liens) injectés dans les données builder.
     * Utilisé quand le rollback tombe en fallback révision WP (pas de backup builder dispo).
     * wp_restore_post_revision ne touche que post_content, pas _elementor_data/_fl_builder_data etc.
     *
     * @since 2.5.7
     * @param int $post_id
     */
    private static function clean_hts_from_builder_data( $post_id ) {
        // ── Elementor ──
        if ( class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_elementor( $post_id ) ) {
            $el_data = get_post_meta( $post_id, '_elementor_data', true );
            $data_arr = is_string( $el_data ) ? json_decode( $el_data, true ) : null;
            if ( is_array( $data_arr ) && ! empty( $data_arr ) ) {
                $cleaned = false;
                // Supprimer les widgets contenant du contenu HTS (FAQ, liens HTS)
                array_walk_recursive( $data_arr, function( &$val, $key ) use ( &$cleaned ) {
                    if ( $key === 'editor' && is_string( $val ) ) {
                        if ( strpos( $val, 'hts-faq' ) !== false || strpos( $val, 'HTS Coach FAQ' ) !== false ) {
                            $val = '';
                            $cleaned = true;
                        }
                    }
                });
                if ( $cleaned ) {
                    $data_arr = self::remove_empty_elementor_widgets( $data_arr );
                    $json = wp_json_encode( $data_arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
                    update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
                    delete_post_meta( $post_id, '_elementor_css' );
                    if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
                        \Elementor\Plugin::$instance->files_manager->clear_cache();
                    }
                    // Sync post_content: déjà restauré par wp_restore_post_revision ou wp_update_post
                    // Elementor lira _elementor_data nettoyé au prochain rendu
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf( 'Rollback: _elementor_data nettoyé (FAQ HTS supprimée) pour post #%d', $post_id ), 'info', 'workflow' );
                    }
                }
            }
        }

        // ── Beaver Builder ──
        if ( class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_beaver( $post_id ) ) {
            $bb_data = get_post_meta( $post_id, '_fl_builder_data', true );
            if ( is_array( $bb_data ) ) {
                $cleaned = false;
                foreach ( $bb_data as $nid => $node ) {
                    $text = $node->settings->text ?? ( $node['settings']['text'] ?? '' );
                    if ( is_string( $text ) && ( strpos( $text, 'hts-faq' ) !== false || strpos( $text, 'HTS Coach FAQ' ) !== false ) ) {
                        unset( $bb_data[ $nid ] );
                        $cleaned = true;
                    }
                }
                if ( $cleaned ) {
                    update_post_meta( $post_id, '_fl_builder_data', $bb_data );
                }
            }
        }

        // ── Bricks ──
        if ( class_exists( 'HTS_Content_Extractor' ) && HTS_Content_Extractor::is_bricks( $post_id ) ) {
            $bricks_data = get_post_meta( $post_id, '_bricks_page_content_2', true );
            if ( is_string( $bricks_data ) ) $bricks_data = json_decode( $bricks_data, true );
            if ( is_array( $bricks_data ) ) {
                $cleaned = false;
                foreach ( $bricks_data as $idx => $el ) {
                    $text = $el['settings']['text'] ?? '';
                    if ( is_string( $text ) && ( strpos( $text, 'hts-faq' ) !== false || strpos( $text, 'HTS Coach FAQ' ) !== false ) ) {
                        unset( $bricks_data[ $idx ] );
                        $cleaned = true;
                    }
                }
                if ( $cleaned ) {
                    $bricks_data = array_values( $bricks_data );
                    update_post_meta( $post_id, '_bricks_page_content_2', wp_slash( wp_json_encode( $bricks_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
                }
            }
        }
    }

    /**
     * Détecter ce qui a changé après exécution (pour le feedback).
     *
     * @since 2.3.1
     */
    private static function detect_changes( $post_id, $action_type, $before ) {
        if ( $post_id <= 0 || empty( $before ) ) return '';

        switch ( $action_type ) {
            case 'add_meta_title':
            case 'optimize_meta_title':
                $new = get_post_meta( $post_id, '_hts_meta_title', true );
                $old = $before['meta_title'] ?? '';
                if ( $new && $new !== $old ) return 'Meta title mis à jour : "' . wp_trim_words( $new, 10 ) . '"';
                return $old === $new ? 'Aucun changement détecté' : '';

            case 'add_meta_desc':
            case 'optimize_meta_desc':
                $new = get_post_meta( $post_id, '_hts_meta_description', true );
                $old = $before['meta_description'] ?? '';
                if ( $new && $new !== $old ) return 'Meta description mise à jour : "' . wp_trim_words( $new, 12 ) . '"';
                return $old === $new ? 'Aucun changement détecté' : '';

            case 'optimize_meta_both':
                $changes = array();
                $new_t = get_post_meta( $post_id, '_hts_meta_title', true );
                $old_t = $before['meta_title'] ?? '';
                if ( $new_t && $new_t !== $old_t ) $changes[] = 'Meta title : "' . wp_trim_words( $new_t, 10 ) . '"';
                $new_d = get_post_meta( $post_id, '_hts_meta_description', true );
                $old_d = $before['meta_description'] ?? '';
                if ( $new_d && $new_d !== $old_d ) $changes[] = 'Meta desc : "' . wp_trim_words( $new_d, 12 ) . '"';
                return ! empty( $changes ) ? implode( ' | ', $changes ) : 'Aucun changement détecté';

            case 'fix_orphan_links':
            case 'add_internal_links':
                $new_count = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );
                $old_count = (int) ( $before['links_out'] ?? 0 );
                $diff = $new_count - $old_count;
                return $diff > 0 ? $diff . ' lien(s) interne(s) ajouté(s)' : '';

            case 'content_refresh':
                return 'Contenu envoyé en réécriture via Hack The SEO';

            case 'delete_page':
                return 'Article déplacé dans la corbeille';

            default:
                return '';
        }
    }

    /**
     * Aperçu de ce qu'une action va faire (preview avant apply).
     *
     * @since 2.3.1
     */
    public static function get_preview( $action_id ) {
        $action = self::get_action( $action_id );
        if ( ! $action ) return array( 'error' => 'Action introuvable' );

        $post_id = (int) $action->post_id;
        $post    = get_post( $post_id );
        $data    = json_decode( $action->data, true ) ?: array();

        $preview = array(
            'action_id'   => $action_id,
            'action_type' => $action->type,
            'agent'       => $action->agent,
            'post_id'     => $post_id,
            'post_title'  => $post ? $post->post_title : '(article supprime)',
            'post_url'    => $post ? get_permalink( $post_id ) : '',
            'edit_url'    => $post ? get_edit_post_link( $post_id, 'raw' ) : '',
            'reason'      => $data['reason'] ?? '',
            'suggestion'  => $data['suggestion'] ?? ( $data['top_fix'] ?? '' ),
            'before'      => array(),
            'after_desc'  => '',
        );

        if ( ! $post ) return $preview;

        switch ( $action->type ) {
            case 'optimize_meta_title':
            case 'add_meta_title':
                $current = get_post_meta( $post_id, '_hts_meta_title', true );
                $preview['before']     = array( 'label' => 'Meta title actuel', 'value' => $current ?: '(aucun — WordPress génère automatiquement)' );
                if ( ! empty( $data['_generated_variants'] ) ) {
                    $best_title = $data['_generated_variants'][0]['title'] ?? '';
                    $preview['after_desc'] = $best_title ?: 'Variante générée (cliquez Voir pour afficher)';
                } else {
                    $preview['after_desc'] = $data['suggestion'] ?? 'Cliquez sur Voir pour générer un titre SEO optimisé par l\'IA.';
                }
                break;

            case 'optimize_meta_desc':
            case 'add_meta_desc':
                $current = get_post_meta( $post_id, '_hts_meta_description', true );
                $preview['before']     = array( 'label' => 'Meta description actuelle', 'value' => $current ?: '(aucune — les moteurs utilisent un extrait aléatoire)' );
                if ( ! empty( $data['_generated_variants'] ) ) {
                    $best_desc = $data['_generated_variants'][0]['description'] ?? '';
                    $preview['after_desc'] = $best_desc ?: 'Variante générée (cliquez Voir pour afficher)';
                } else {
                    $preview['after_desc'] = $data['suggestion'] ?? 'Cliquez sur Voir pour générer une description SEO optimisée par l\'IA.';
                }
                break;

            case 'optimize_meta_both':
                $current_t = get_post_meta( $post_id, '_hts_meta_title', true );
                $current_d = get_post_meta( $post_id, '_hts_meta_description', true );
                $preview['before'] = array(
                    'label' => 'Balises actuelles',
                    'value' => 'Title : ' . ( $current_t ?: '(aucun)' ) . "\nDescription : " . ( $current_d ?: '(aucune)' ),
                );
                $after_parts = array();
                if ( ! empty( $data['suggestion'] ) ) {
                    $after_parts[] = $data['suggestion'];
                } else {
                    if ( ! empty( $data['_generated_variants'][0]['title'] ) ) $after_parts[] = 'Title : ' . $data['_generated_variants'][0]['title'];
                    if ( ! empty( $data['_generated_variants'][0]['description'] ) ) $after_parts[] = 'Description : ' . $data['_generated_variants'][0]['description'];
                }
                $preview['after_desc'] = ! empty( $after_parts ) ? implode( "\n", $after_parts ) : 'Cliquez sur Voir pour générer titre + description optimisés.';
                break;

            case 'fix_orphan_links':
            case 'add_internal_links':
                $links_out = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );
                if ( $links_out <= 0 ) {
                    $links_out = preg_match_all( '/<a\s[^>]*href=["\'][^"\']*["\'][^>]*>/i', $post->post_content ?? '', $_m );
                }
                $target_id    = (int) ( $data['target_id'] ?? 0 );
                $anchor_text  = $data['anchor_text'] ?? '';
                $link_type    = $data['link_type'] ?? '';
                $target_title = $data['target_title'] ?? '';
                $target_url   = $target_id ? get_permalink( $target_id ) : '';
                $cluster      = $data['cluster'] ?? '';

                // Build a clear "what will happen" description
                $link_label = '';
                if ( $link_type === 'child_to_pillar' ) $link_label = 'enfant → pilier';
                elseif ( $link_type === 'pillar_to_child' ) $link_label = 'pilier → enfant';
                else $link_label = 'lien sémantique';

                $preview['before'] = array(
                    'label' => 'Liens internes sortants',
                    'value' => $links_out . ' lien(s) actuellement',
                );

                // Rich linking preview
                $linking_detail = array(
                    'target_id'     => $target_id,
                    'target_title'  => $target_title ?: ( $target_id ? get_the_title( $target_id ) : '' ),
                    'target_url'    => $target_url,
                    'anchor_text'   => $anchor_text,
                    'anchor_method' => $data['anchor_method'] ?? '',
                    'link_type'     => $link_type,
                    'link_label'    => $link_label,
                    'cluster'       => $cluster,
                );
                $preview['linking'] = $linking_detail;

                // ── Contexte : phrase source contenant l'ancre ──
                // Priorité 1 : anchor_sentence renvoyée par l'IA (passage réel)
                // Priorité 2 : extraction par recherche dans le contenu
                $context_snippet = '';
                $ai_sentence = $data['anchor_sentence'] ?? '';

                if ( $ai_sentence && $anchor_text ) {
                    // L'IA a fourni la phrase — on insère les marqueurs de surlignage
                    $pos = mb_stripos( $ai_sentence, $anchor_text );
                    if ( $pos !== false ) {
                        $before = mb_substr( $ai_sentence, 0, $pos );
                        $match  = mb_substr( $ai_sentence, $pos, mb_strlen( $anchor_text ) );
                        $after  = mb_substr( $ai_sentence, $pos + mb_strlen( $anchor_text ) );
                        $context_snippet = '…' . trim( $before ) . ' {HL_START}' . $match . '{HL_END} ' . trim( $after ) . '…';
                    } else {
                        // L'ancre n'est pas dans la phrase telle quelle — afficher la phrase quand même
                        $context_snippet = '…' . $ai_sentence . '… → ancre : {HL_START}' . $anchor_text . '{HL_END}';
                    }
                }

                if ( ! $context_snippet && $anchor_text && $post && ! empty( $post->post_content ) ) {
                    $context_snippet = self::extract_anchor_context( $post->post_content, $anchor_text );
                }

                if ( $context_snippet ) {
                    $preview['linking']['context_snippet'] = $context_snippet;
                }

                // ── INTRO ZONE WARNING (v2.4.12) ──
                // Detect if anchor is in the intro zone and if intro is already saturated
                if ( $anchor_text && $post && ! empty( $post->post_content ) ) {
                    $content_check = $post->post_content;

                    // ── HEADING WARNING: check if anchor text is inside a H2/H3/H4 ──
                    if ( preg_match_all( '/<(h[2-4])[^>]*>(.*?)<\/\1>/si', $content_check, $_hd_matches ) ) {
                        foreach ( $_hd_matches[2] as $_hd_text ) {
                            $heading_plain = html_entity_decode( wp_strip_all_tags( $_hd_text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                            if ( mb_stripos( $heading_plain, $anchor_text ) !== false ) {
                                $preview['linking']['intro_warning'] = 'L\'ancre « ' . mb_substr( $anchor_text, 0, 30 ) . ' » se trouve dans un titre (H2/H3). Les liens ne doivent pas être placés dans les titres — ce lien sera bloqué à l\'application.';
                                break;
                            }
                        }
                    }

                    // ── H2/H3 DETECTED: chercher ancre alternative hors titres ──
                    if ( ! empty( $preview['linking']['intro_warning'] ) && strpos( $preview['linking']['intro_warning'], 'titre' ) !== false ) {
                        $alt = self::find_alternative_anchor_outside_headings( $content_check, $anchor_text, get_the_title( $target_id ) );
                        if ( $alt ) {
                            $preview['linking']['alt_anchor'] = $alt;
                            $preview['linking']['intro_warning'] .= ' Une ancre alternative a été trouvée : « ' . mb_substr( $alt, 0, 50 ) . ' ».';
                        } else {
                            $preview['linking']['intro_warning'] .= ' Aucune ancre alternative trouvée dans le corps du texte.';
                        }
                    }

                    // ── INTRO ZONE: check saturation ──
                    if ( empty( $preview['linking']['intro_warning'] ) ) {
                        $h2_check_pos = false;
                        if ( preg_match( '/<h2[\s>]/i', $content_check, $_h2m, PREG_OFFSET_CAPTURE ) ) {
                            $h2_check_pos = $_h2m[0][1];
                        }
                        if ( $h2_check_pos !== false ) {
                            // Check if anchor text exists in the intro zone
                            $intro_html = substr( $content_check, 0, $h2_check_pos );
                            $anchor_in_intro = ( mb_stripos( wp_strip_all_tags( html_entity_decode( $intro_html, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ), $anchor_text ) !== false );

                            // Count existing internal links in intro
                            $site_url_check = home_url();
                            $intro_link_count = 0;
                            if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $intro_html, $_im ) ) {
                                foreach ( $_im[1] as $_href ) {
                                    if ( strpos( $_href, $site_url_check ) === 0 || ( strpos( $_href, '/' ) === 0 && strpos( $_href, '//' ) !== 0 ) ) {
                                        $intro_link_count++;
                                    }
                                }
                            }

                            if ( $anchor_in_intro && $intro_link_count >= 1 ) {
                                // Check if anchor also exists after H2
                                $after_h2_text = wp_strip_all_tags( html_entity_decode( substr( $content_check, $h2_check_pos ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
                                $anchor_after_h2 = ( mb_stripos( $after_h2_text, $anchor_text ) !== false );

                                if ( $anchor_after_h2 ) {
                                    $preview['linking']['intro_warning'] = 'L\'ancre existe dans l\'introduction (déjà ' . $intro_link_count . ' lien(s) interne(s)) — le lien sera placé plus bas dans l\'article.';
                                } else {
                                    $preview['linking']['intro_warning'] = 'L\'ancre n\'existe que dans l\'introduction qui contient déjà ' . $intro_link_count . ' lien(s) interne(s). Ce lien pourrait être bloqué à l\'application (max 1 lien avant la première H2).';
                                }
                            }
                        }
                    }
                }

                if ( $target_id && $anchor_text ) {
                    $preview['after_desc'] = sprintf(
                        'Un lien sera ajouté vers « %s » avec l\'ancre « %s » (%s).',
                        mb_substr( $linking_detail['target_title'], 0, 50 ),
                        mb_substr( $anchor_text, 0, 40 ),
                        $link_label
                    );
                } else {
                    $preview['after_desc'] = 'Hack The SEO va analyser le contenu et ajouter 2-4 liens internes vers des articles connexes.';
                }
                break;

            case 'enrich_thin_content':
            case 'content_refresh':
                $age_days   = (int) ( ( time() - strtotime( $post->post_modified ) ) / DAY_IN_SECONDS );
                $word_count = hts_word_count( wp_strip_all_tags( $post->post_content ) );
                $preview['before']     = array( 'label' => 'État actuel', 'value' => "Dernière modification il y a {$age_days} jours — {$word_count} mots" );
                $preview['after_desc'] = $data['suggestion'] ?? 'Le contenu sera envoyé en réécriture via l\'API Hack The SEO. Vous recevrez un brouillon à valider.';
                break;

            case 'add_featured_image':
                $has_thumb = has_post_thumbnail( $post_id );
                $preview['before']     = array( 'label' => 'Image mise en avant', 'value' => $has_thumb ? 'Image existante' : 'Aucune image de couverture' );
                $preview['after_desc'] = $data['suggestion'] ?? 'L\'IA va générer une image de couverture optimisée pour cet article.';
                break;

            case 'geo_optimize':
                $geo_score = get_post_meta( $post_id, '_hts_geo_score', true );
                $preview['before']     = array( 'label' => 'Score visibilité IA', 'value' => ( $geo_score ?: '?' ) . '/100' );
                $preview['after_desc'] = $data['suggestion'] ?? 'Optimisations recommandées pour améliorer la visibilité dans les résultats IA.';
                break;

            case 'add_faq':
                $preview['before']     = array( 'label' => 'Section FAQ', 'value' => 'Aucune section FAQ détectée' );
                $preview['after_desc'] = 'Une section FAQ structurée sera ajoutée en bas de l\'article.';
                break;

            case 'delete_page':
                $clicks = (int) get_post_meta( $post_id, '_hts_gsc_clicks_30d', true );
                $preview['before']     = array( 'label' => 'Statut actuel', 'value' => ucfirst( $post->post_status ) . ' — ' . $clicks . ' clics/30j' );
                $preview['after_desc'] = 'L\'article sera déplacé dans la corbeille WordPress (récupérable). ' . ( $data['reason'] ?? '' );
                break;

            case 'fix_image_alt':
                $missing = (int) ( $data['missing_count'] ?? 0 );
                $total   = (int) ( $data['total_images'] ?? 0 );
                $preview['before'] = array(
                    'label' => 'Images sans ALT',
                    'value' => sprintf( '%d image(s) sans attribut ALT sur %d au total', $missing, $total ),
                );
                $preview['after_desc'] = 'L\'IA va générer un texte ALT descriptif et optimisé SEO pour chaque image.';
                // Sprint 6.3c: inclure les thumbnails des images concernées
                if ( ! empty( $data['images'] ) && is_array( $data['images'] ) ) {
                    $preview['images'] = $data['images'];
                }
                break;

            default:
                $preview['before']     = array( 'label' => 'État actuel', 'value' => 'Pas d\'aperçu détaillé pour ce type d\'action' );
                $preview['after_desc'] = $data['suggestion'] ?? 'Action à appliquer.';
                break;
        }

        return $preview;
    }

    /* ═══════════════════════════════════════════════
     *  SESSION J — DIFF ENGINE & ROLLBACK PREVIEW
     * ═══════════════════════════════════════════════ */

    /**
     * Extraire le contexte (phrase ou paragraphe) autour de l'ancre dans le contenu source.
     * Retourne le texte brut avec des marqueurs {HL_START} et {HL_END} autour de l'ancre.
     *
     * @since 2.4.10
     * @param string $content     Contenu HTML du post source.
     * @param string $anchor_text Texte de l'ancre à chercher.
     * @return string|null        Contexte avec marqueurs ou null si introuvable.
     */
    public static function extract_anchor_context( $content, $anchor_text ) {
        if ( empty( $content ) || empty( $anchor_text ) ) return null;

        $anchor_decoded = html_entity_decode( $anchor_text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $content_decoded = html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        // Chercher dans les paragraphes
        if ( preg_match_all( '/<p[^>]*>(.*?)<\/p>/si', $content_decoded, $matches ) ) {
            foreach ( $matches[1] as $para_html ) {
                $para_text = wp_strip_all_tags( $para_html );
                if ( mb_strlen( $para_text ) < 20 ) continue;

                $anchor_pos = mb_stripos( $para_text, $anchor_decoded );
                if ( $anchor_pos !== false ) {
                    // Tronquer le paragraphe si trop long (garder ~150 chars autour de l'ancre)
                    $snippet = self::truncate_around( $para_text, $anchor_decoded, $anchor_pos, 120 );
                    return $snippet;
                }
            }
        }

        // Fallback : chercher dans le texte brut complet
        $text = wp_strip_all_tags( $content_decoded );
        $anchor_pos = mb_stripos( $text, $anchor_decoded );
        if ( $anchor_pos !== false ) {
            $snippet = self::truncate_around( $text, $anchor_decoded, $anchor_pos, 120 );
            return $snippet;
        }

        return null;
    }

    /**
     * Tronquer un texte autour d'une position, avec marqueurs de highlight.
     */
    private static function truncate_around( $text, $anchor, $pos, $context_chars = 120 ) {
        $before_start = max( 0, $pos - $context_chars );
        $after_end    = min( mb_strlen( $text ), $pos + mb_strlen( $anchor ) + $context_chars );

        // Reculer au début du mot / de la phrase
        if ( $before_start > 0 ) {
            $space_pos = mb_strpos( $text, ' ', $before_start );
            if ( $space_pos !== false && $space_pos < $pos ) {
                $before_start = $space_pos + 1;
            }
        }

        $snippet = mb_substr( $text, $before_start, $after_end - $before_start );

        // Replacer l'ancre avec les marqueurs de highlight
        $anchor_in_snippet = mb_stripos( $snippet, $anchor );
        if ( $anchor_in_snippet !== false ) {
            $actual_anchor = mb_substr( $snippet, $anchor_in_snippet, mb_strlen( $anchor ) );
            $snippet = mb_substr( $snippet, 0, $anchor_in_snippet )
                     . '{HL_START}' . $actual_anchor . '{HL_END}'
                     . mb_substr( $snippet, $anchor_in_snippet + mb_strlen( $anchor ) );
        }

        $prefix = $before_start > 0 ? '…' : '';
        $suffix = $after_end < mb_strlen( $text ) ? '…' : '';

        return $prefix . trim( $snippet ) . $suffix;
    }

    /**
     * Labels non-expert pour chaque champ (Session J — P6).
     *
     * @since 2.4.6
     * @return array
     */
    public static function get_field_labels() {
        return array(
            'meta_title'       => 'Titre SEO',
            'meta_description' => 'Description pour Google',
            'content'          => 'Contenu de l\'article',
            'post_title'       => 'Titre de l\'article',
            'internal_links'   => 'Liens internes',
            'links_out'        => 'Nombre de liens internes sortants',
            'schema'           => 'Données structurées',
            'thumbnail_id'     => 'Image mise en avant',
            'post_status'      => 'Statut de l\'article',
            'faq'              => 'Section FAQ',
            'geo_score'        => 'Score de visibilité IA',
        );
    }

    /**
     * Capturer un snapshot au moment du propose() pour le diff preview.
     *
     * @since 2.4.6
     * @param int    $post_id
     * @param string $type Action type
     * @return array
     */
    public static function capture_propose_snapshot( $post_id, $type ) {
        if ( $post_id <= 0 ) return array();

        $snapshot = array( 'captured_at' => current_time( 'mysql' ) );

        switch ( $type ) {
            case 'optimize_meta_title':
            case 'add_meta_title':
                $snapshot['meta_title'] = get_post_meta( $post_id, '_hts_meta_title', true ) ?: '';
                break;
            case 'optimize_meta_desc':
            case 'add_meta_desc':
                $snapshot['meta_description'] = get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
                break;
            case 'optimize_meta_both':
                $snapshot['meta_title'] = get_post_meta( $post_id, '_hts_meta_title', true ) ?: '';
                $snapshot['meta_description'] = get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
                break;
            case 'fix_orphan_links':
            case 'add_internal_links':
                $snapshot['links_out'] = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );
                $post = get_post( $post_id );
                $snapshot['content'] = $post ? $post->post_content : '';
                break;
            case 'content_refresh':
                $post = get_post( $post_id );
                $snapshot['content']          = $post ? mb_substr( $post->post_content, 0, 5000 ) : '';
                $snapshot['post_title']       = $post ? $post->post_title : '';
                $snapshot['meta_title']       = get_post_meta( $post_id, '_hts_meta_title', true ) ?: '';
                $snapshot['meta_description'] = get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
                break;
            case 'add_faq':
                $post = get_post( $post_id );
                $snapshot['has_faq'] = $post ? ( strpos( $post->post_content, 'class="hts-faq' ) !== false || strpos( $post->post_content, 'wp:heading' ) !== false ) : false;
                break;
            case 'geo_optimize':
                $snapshot['geo_score'] = get_post_meta( $post_id, '_hts_geo_score', true ) ?: 0;
                break;
            case 'enrich_thin_content':
                $post = get_post( $post_id );
                $snapshot['content']    = $post ? mb_substr( $post->post_content, 0, 5000 ) : '';
                $snapshot['post_title'] = $post ? $post->post_title : '';
                $snapshot['word_count'] = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;
                break;
            case 'add_featured_image':
                $snapshot['thumbnail_id'] = get_post_thumbnail_id( $post_id );
                break;
            case 'delete_page':
                $post = get_post( $post_id );
                $snapshot['post_status'] = $post ? $post->post_status : '';
                $snapshot['post_title']  = $post ? $post->post_title : '';
                break;
            default:
                $post = get_post( $post_id );
                if ( $post ) {
                    $snapshot['content']    = mb_substr( $post->post_content, 0, 5000 );
                    $snapshot['post_title'] = $post->post_title;
                }
                break;
        }

        return $snapshot;
    }

    /**
     * Générer un diff structuré pour une action (avant/après par champ).
     *
     * @since 2.4.6
     * @param int $action_id
     * @return array
     */
    public static function get_action_diff( $action_id ) {
        $action = self::get_action( $action_id );
        if ( ! $action ) return array( 'error' => 'Action introuvable' );

        $post_id = (int) $action->post_id;
        $post    = get_post( $post_id );
        $data    = json_decode( $action->data, true ) ?: array();
        $labels  = self::get_field_labels();

        $diff = array(
            'action_id'  => $action_id,
            'type'       => $action->type,
            'agent'      => $action->agent,
            'post_id'    => $post_id,
            'post_title' => $post ? $post->post_title : '(article supprimé)',
            'status'     => $action->status,
            'reason'     => $data['reason'] ?? '',
            'why'        => '',
            'metrics'    => array(),
            'fields'     => array(),
        );

        $snapshot = $data['_snapshot_before'] ?? array();

        switch ( $action->type ) {
            case 'optimize_meta_title':
            case 'add_meta_title':
                $before = $snapshot['meta_title'] ?? ( get_post_meta( $post_id, '_hts_meta_title', true ) ?: '' );
                $after  = $data['suggestion'] ?? 'Génération en cours\u2026 Cliquez sur Voir pour lancer l\'IA';
                $before_len = mb_strlen( $before );
                $after_len  = mb_strlen( $after );
                $title_target = 60;
                if ( class_exists( 'HTS_Meta_Score' ) ) {
                    $title_target = HTS_Meta_Score::get_title_max_length();
                }
                // Si la variante a été générée, afficher des metrics sur le résultat
                $has_generated = ! empty( $data['_generated_variants'] );
                $diff['fields'][] = array(
                    'field' => 'meta_title',
                    'label' => $labels['meta_title'],
                    'before' => $before ?: '(aucun — WordPress génère automatiquement)',
                    'after'  => $action->status === 'done' ? ( get_post_meta( $post_id, '_hts_meta_title', true ) ?: $after ) : $after,
                    'type'   => 'text',
                );
                $diff['why'] = 'Un titre SEO personnalisé augmente le taux de clic dans Google.';
                $diff['metrics'] = array(
                    array( 'label' => 'Longueur actuelle',       'value' => $before_len . ' car.', 'status' => $before_len >= 30 && $before_len <= $title_target ? 'ok' : 'warning' ),
                    array( 'label' => 'Longueur recommandée',    'value' => '50-' . $title_target . ' car.', 'status' => 'info' ),
                    array( 'label' => 'Mot-clé principal',       'value' => ! empty( $data['keyword'] ) ? $data['keyword'] : 'Non défini', 'status' => ( ! empty( $data['keyword'] ) && $before && mb_stripos( $before, $data['keyword'] ) !== false ) ? 'ok' : 'warning' ),
                    array( 'label' => 'Score meta',              'value' => ( $data['meta_score'] ?? '?' ) . '/100', 'status' => ( $data['meta_score'] ?? 0 ) >= 60 ? 'ok' : 'warning' ),
                );
                if ( $has_generated ) {
                    $diff['metrics'][] = array( 'label' => 'Nouveau titre', 'value' => $after_len . ' car.', 'status' => $after_len >= 45 && $after_len <= $title_target ? 'ok' : 'warning' );
                }
                // Ajouter les alternatives si disponibles
                if ( ! empty( $data['_all_titles'] ) && count( $data['_all_titles'] ) > 1 ) {
                    $diff['alternatives'] = array_slice( $data['_all_titles'], 1 );
                }
                break;

            case 'optimize_meta_desc':
            case 'add_meta_desc':
                $before = $snapshot['meta_description'] ?? ( get_post_meta( $post_id, '_hts_meta_description', true ) ?: '' );
                $after  = $data['suggestion'] ?? 'Génération en cours\u2026 Cliquez sur Voir pour lancer l\'IA';
                $before_len = mb_strlen( $before );
                $after_len  = mb_strlen( $after );
                $desc_target = 155;
                if ( class_exists( 'HTS_Meta_Score' ) ) {
                    $desc_target = HTS_Meta_Score::get_desc_max_length();
                }
                $has_generated = ! empty( $data['_generated_variants'] );
                $diff['fields'][] = array(
                    'field' => 'meta_description',
                    'label' => $labels['meta_description'],
                    'before' => $before ?: '(aucune — Google utilise un extrait aléatoire)',
                    'after'  => $action->status === 'done' ? ( get_post_meta( $post_id, '_hts_meta_description', true ) ?: $after ) : $after,
                    'type'   => 'text',
                );
                $diff['why'] = 'Une meta description bien rédigée augmente le taux de clic de 20 à 30%.';
                $diff['metrics'] = array(
                    array( 'label' => 'Longueur actuelle',       'value' => $before_len . ' car.', 'status' => $before_len >= 80 && $before_len <= $desc_target ? 'ok' : 'warning' ),
                    array( 'label' => 'Longueur recommandée',    'value' => '120-' . $desc_target . ' car.', 'status' => 'info' ),
                    array( 'label' => 'Mot-clé principal',       'value' => ! empty( $data['keyword'] ) ? $data['keyword'] : 'Non défini', 'status' => ( ! empty( $data['keyword'] ) && $before && mb_stripos( $before, $data['keyword'] ) !== false ) ? 'ok' : 'warning' ),
                    array( 'label' => 'Score meta',              'value' => ( $data['meta_score'] ?? '?' ) . '/100', 'status' => ( $data['meta_score'] ?? 0 ) >= 60 ? 'ok' : 'warning' ),
                );
                if ( $has_generated ) {
                    $diff['metrics'][] = array( 'label' => 'Nouvelle description', 'value' => $after_len . ' car.', 'status' => $after_len >= 120 && $after_len <= $desc_target ? 'ok' : 'warning' );
                }
                if ( ! empty( $data['_all_descriptions'] ) && count( $data['_all_descriptions'] ) > 1 ) {
                    $diff['alternatives'] = array_slice( $data['_all_descriptions'], 1 );
                }
                break;

            case 'optimize_meta_both':
                $before_t = $snapshot['meta_title'] ?? ( get_post_meta( $post_id, '_hts_meta_title', true ) ?: '' );
                $before_d = $snapshot['meta_description'] ?? ( get_post_meta( $post_id, '_hts_meta_description', true ) ?: '' );
                $after_t  = $data['suggestion'] ?? '';
                $after_d  = $data['suggestion_desc'] ?? $data['suggestion'] ?? '';
                if ( ! empty( $data['_generated_variants'][0] ) ) {
                    $after_t = $data['_generated_variants'][0]['title'] ?? $after_t;
                    $after_d = $data['_generated_variants'][0]['description'] ?? $after_d;
                }
                $diff['fields'][] = array( 'field' => 'meta_title', 'label' => 'Title SEO', 'before' => $before_t ?: '(aucun)', 'after' => $after_t ?: 'En attente de g\u00e9n\u00e9ration', 'type' => 'text' );
                $diff['fields'][] = array( 'field' => 'meta_description', 'label' => 'Meta description', 'before' => $before_d ?: '(aucune)', 'after' => $after_d ?: 'En attente de g\u00e9n\u00e9ration', 'type' => 'text' );
                $diff['why'] = 'Des balises bien r\u00e9dig\u00e9es augmentent le taux de clic dans Google de 20 \u00e0 30%.';
                $diff['metrics'] = array(
                    array( 'label' => 'Title actuel', 'value' => mb_strlen( $before_t ) . ' car.', 'status' => mb_strlen( $before_t ) >= 30 && mb_strlen( $before_t ) <= 65 ? 'ok' : 'warning' ),
                    array( 'label' => 'Description actuelle', 'value' => mb_strlen( $before_d ) . ' car.', 'status' => mb_strlen( $before_d ) >= 80 && mb_strlen( $before_d ) <= 160 ? 'ok' : 'warning' ),
                    array( 'label' => 'Score meta', 'value' => ( $data['meta_score'] ?? '?' ) . '/100', 'status' => ( $data['meta_score'] ?? 0 ) >= 60 ? 'ok' : 'warning' ),
                );
                break;

            case 'fix_orphan_links':
            case 'add_internal_links':
                $before_count = (int) ( $snapshot['links_out'] ?? get_post_meta( $post_id, '_hts_internal_links_out', true ) );
                $links_in     = (int) ( $data['links_in'] ?? get_post_meta( $post_id, '_hts_internal_links_in', true ) );
                $after_count  = $action->status === 'done' ? (int) get_post_meta( $post_id, '_hts_internal_links_out', true ) : ( $before_count + 3 );
                $max_links    = 5;
                if ( class_exists( 'HTS_Internal_Linking' ) ) {
                    $max_links = HTS_Internal_Linking::get_max_links_per_post();
                }
                $diff['fields'][] = array(
                    'field'  => 'links_out',
                    'label'  => $labels['internal_links'],
                    'before' => $before_count . ' lien(s) sortant(s)',
                    'after'  => $after_count . ' lien(s) sortant(s) (environ +' . max( 1, $after_count - $before_count ) . ')',
                    'type'   => 'count',
                );
                $diff['why'] = 'Les liens internes aident Google à comprendre la structure de votre site et renforcent vos pages importantes.';
                $is_orphan = ( $before_count === 0 && $links_in === 0 );
                $diff['metrics'] = array(
                    array( 'label' => 'Liens sortants actuels', 'value' => $before_count, 'status' => $before_count >= 2 ? 'ok' : 'warning' ),
                    array( 'label' => 'Liens entrants',         'value' => $links_in, 'status' => $links_in >= 1 ? 'ok' : 'warning' ),
                    array( 'label' => 'Objectif liens/article', 'value' => $max_links, 'status' => 'info' ),
                    array( 'label' => 'Page orpheline',         'value' => $is_orphan ? 'Oui' : 'Non', 'status' => $is_orphan ? 'warning' : 'ok' ),
                );
                if ( ! empty( $data['cluster'] ) ) {
                    $diff['metrics'][] = array( 'label' => 'Cluster', 'value' => $data['cluster'], 'status' => 'info' );
                }
                break;

            case 'content_refresh':
                $age_days = $post ? (int) ( ( time() - strtotime( $post->post_modified ) ) / DAY_IN_SECONDS ) : 0;
                $word_count = $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0;
                $gsc_clicks = (int) get_post_meta( $post_id, '_hts_gsc_clicks_30d', true );
                $geo_score  = (int) ( $data['geo_score'] ?? get_post_meta( $post_id, '_hts_geo_score', true ) );
                $diff['fields'][] = array(
                    'field'  => 'content',
                    'label'  => $labels['content'],
                    'before' => "Dernière modification il y a {$age_days} jour(s) — {$word_count} mots",
                    'after'  => 'Le contenu sera envoyé en réécriture via Hack The SEO. Vous recevrez un brouillon à valider.',
                    'type'   => 'description',
                );
                $diff['why'] = 'Un contenu régulièrement mis à jour est mieux classé par Google et génère plus de trafic.';
                $diff['metrics'] = array(
                    array( 'label' => 'Ancienneté',       'value' => $age_days . ' jours', 'status' => $age_days > 365 ? 'warning' : ( $age_days > 180 ? 'ok' : 'ok' ) ),
                    array( 'label' => 'Clics/30j (GSC)',   'value' => $gsc_clicks, 'status' => $gsc_clicks > 10 ? 'ok' : 'warning' ),
                    array( 'label' => 'Nombre de mots',    'value' => $word_count, 'status' => $word_count >= 800 ? 'ok' : 'warning' ),
                    array( 'label' => 'Score visibilité IA', 'value' => $geo_score . '/100', 'status' => $geo_score >= 50 ? 'ok' : 'warning' ),
                );
                break;

            case 'geo_optimize':
                $geo_score = $snapshot['geo_score'] ?? ( get_post_meta( $post_id, '_hts_geo_score', true ) ?: 0 );
                $fixes_count = (int) ( $data['fixes_count'] ?? 0 );
                $diff['fields'][] = array(
                    'field'  => 'geo_score',
                    'label'  => $labels['geo_score'],
                    'before' => (int) $geo_score . '/100',
                    'after'  => $data['suggestion'] ?? 'Optimisations recommandées pour améliorer votre visibilité dans les résultats IA',
                    'type'   => 'score',
                );
                $diff['why'] = 'Les moteurs de recherche IA (ChatGPT, Perplexity) prennent de plus en plus de place. Optimiser votre visibilité IA protège votre trafic futur.';
                // Translate criterion for CEO
                $_geo_crit_labels = array( 'faq_lists' => 'Ajouter une FAQ', 'intro_direct' => 'Reformuler l\'intro', 'data_stats' => 'Ajouter des données', 'images_alt' => 'Images avec ALT', 'meta_seo' => 'Compléter les meta', 'sources_citations' => 'Ajouter des sources', 'structured_data' => 'Structured data', 'content_depth' => 'Enrichir le contenu', 'entity_coverage' => 'Couvrir les entités', 'heading_structure' => 'Améliorer les H2/H3', 'content_freshness' => 'Mettre à jour', 'internal_links' => 'Liens internes' );
                $crit_label = $_geo_crit_labels[ $data['criterion'] ?? '' ] ?? ( $data['criterion'] ?? 'Non spécifié' );
                $diff['metrics'] = array(
                    array( 'label' => 'Score GEO actuel',      'value' => (int) $geo_score . '/100', 'status' => (int) $geo_score >= 60 ? 'ok' : 'warning' ),
                    array( 'label' => 'Critères à corriger',   'value' => $fixes_count > 0 ? $fixes_count : '?', 'status' => $fixes_count > 3 ? 'warning' : 'ok' ),
                    array( 'label' => 'Critère prioritaire',   'value' => $crit_label, 'status' => 'info' ),
                    array( 'label' => 'Correction proposée',   'value' => $data['top_fix'] ?? 'Voir les détails', 'status' => 'info' ),
                );
                // Ajouter confiance si propagation strategy
                if ( ! empty( $data['confidence'] ) ) {
                    $diff['metrics'][] = array( 'label' => 'Confiance stratégie', 'value' => (int) $data['confidence'] . '%', 'status' => (int) $data['confidence'] >= 70 ? 'ok' : 'info' );
                }
                break;

            case 'add_faq':
                $diff['fields'][] = array(
                    'field'  => 'faq',
                    'label'  => $labels['faq'],
                    'before' => 'Aucune section FAQ détectée',
                    'after'  => 'Une section FAQ structurée sera ajoutée en bas de l\'article',
                    'type'   => 'description',
                );
                $diff['why'] = 'Les FAQ structurées peuvent apparaître directement dans Google sous forme de résultats enrichis.';
                break;

            case 'enrich_thin_content':
                $word_count = $snapshot['word_count'] ?? ( $post ? hts_word_count( wp_strip_all_tags( $post->post_content ) ) : 0 );
                $diff['fields'][] = array(
                    'field'  => 'content',
                    'label'  => $labels['content'],
                    'before' => $word_count . ' mots (contenu trop court)',
                    'after'  => 'Le contenu sera enrichi pour atteindre un minimum de 800 mots',
                    'type'   => 'description',
                );
                $diff['why'] = 'Un contenu trop court est souvent considéré comme peu utile par Google. L\'enrichir améliore son classement.';
                break;

            case 'add_featured_image':
                $thumb_id = $snapshot['thumbnail_id'] ?? get_post_thumbnail_id( $post_id );
                $diff['fields'][] = array(
                    'field'  => 'thumbnail_id',
                    'label'  => $labels['thumbnail_id'],
                    'before' => $thumb_id ? 'Image existante (#' . $thumb_id . ')' : 'Aucune image mise en avant',
                    'after'  => 'Une image sera générée ou sélectionnée dans votre bibliothèque média',
                    'type'   => 'description',
                );
                $diff['why'] = 'Les articles avec image sont plus cliqués dans les résultats de recherche et sur les réseaux sociaux.';
                break;

            case 'fix_image_alt':
                $missing = (int) ( $data['missing_count'] ?? 0 );
                $total   = (int) ( $data['total_images'] ?? 0 );
                $diff['fields'][] = array(
                    'field'  => 'image_alt',
                    'label'  => 'Attributs ALT images',
                    'before' => $missing . ' image(s) sans ALT sur ' . $total . ' au total',
                    'after'  => 'L\'IA va générer un texte ALT descriptif et optimisé SEO pour chaque image',
                    'type'   => 'description',
                );
                $diff['why'] = 'Google ne référence pas les images sans texte alternatif. Des ALT descriptifs améliorent le référencement images.';
                $diff['metrics'] = array(
                    array( 'label' => 'Images sans ALT', 'value' => $missing, 'status' => $missing > 0 ? 'warning' : 'ok' ),
                    array( 'label' => 'Images totales', 'value' => $total, 'status' => 'info' ),
                );
                break;

            case 'delete_page':
                $clicks = (int) get_post_meta( $post_id, '_hts_gsc_clicks_30d', true );
                $diff['fields'][] = array(
                    'field'  => 'post_status',
                    'label'  => $labels['post_status'],
                    'before' => $post ? ucfirst( $post->post_status ) . ' — ' . $clicks . ' clic(s)/30j' : 'Inconnu',
                    'after'  => 'L\'article sera déplacé dans la corbeille (récupérable)',
                    'type'   => 'status',
                );
                $diff['why'] = $data['reason'] ?? 'Cet article génère très peu de trafic et peut nuire à la qualité globale de votre site.';
                break;

            default:
                $diff['fields'][] = array(
                    'field'  => 'general',
                    'label'  => 'Modification',
                    'before' => 'État actuel',
                    'after'  => $data['suggestion'] ?? 'Action à appliquer',
                    'type'   => 'description',
                );
                break;
        }

        return $diff;
    }

    /**
     * Générer un aperçu du rollback (diff inversé) pour une action "done".
     *
     * @since 2.4.6
     * @param int $action_id
     * @return array
     */
    public static function get_rollback_preview( $action_id ) {
        $action = self::get_action( $action_id );
        if ( ! $action ) return array( 'error' => 'Action introuvable' );
        if ( $action->status !== self::STATUS_DONE ) return array( 'error' => 'Seules les actions terminées peuvent être annulées' );

        $post_id     = (int) $action->post_id;
        $post        = get_post( $post_id );
        $backup_json = get_post_meta( $post_id, '_hts_action_backup_' . $action_id, true );

        if ( ! $backup_json ) {
            // Sprint 6.3c: fallback — montrer quand même un preview utile
            $revisions = wp_get_post_revisions( $post_id, array( 'numberposts' => 5 ) );
            if ( ! empty( $revisions ) ) {
                // Chercher une révision propre (sans FAQ HTS)
                $target_rev = null;
                foreach ( $revisions as $rev ) {
                    if ( strpos( $rev->post_content, '<!-- hts-faq -->' ) === false
                        && strpos( $rev->post_content, 'hts-faq-section' ) === false ) {
                        $target_rev = $rev;
                        break;
                    }
                }
                if ( ! $target_rev ) $target_rev = reset( $revisions );
                $current_len = $post ? mb_strlen( $post->post_content ) : 0;
                $restore_len = mb_strlen( $target_rev->post_content );
                return array(
                    'error'        => false,
                    'action_id'    => $action_id,
                    'type'         => $action->type,
                    'post_title'   => $post ? $post->post_title : '',
                    'agent_label'  => self::get_agent_labels()[ $action->agent ] ?? ucfirst( $action->agent ),
                    'fallback'     => 'revision',
                    'can_rollback' => true,
                    'fields'       => array( array(
                        'label'   => 'Contenu',
                        'current' => 'Version actuelle (' . number_format( $current_len ) . ' caractères)',
                        'restore' => 'Version WordPress du ' . get_the_date( 'd/m/Y H:i', $target_rev ) . ' (' . number_format( $restore_len ) . ' caractères)',
                    ) ),
                );
            }
            return array( 'error' => 'Aucun point de restauration disponible' );
        }

        $backup = json_decode( $backup_json, true );
        if ( ! is_array( $backup ) ) {
            // Sprint 6.2c: Try to recover — maybe double-encoded
            $backup = json_decode( stripslashes( $backup_json ), true );
        }
        if ( ! is_array( $backup ) ) {
            // Fallback: WordPress revisions — chercher révision propre
            $revisions = wp_get_post_revisions( $post_id, array( 'numberposts' => 5 ) );
            if ( ! empty( $revisions ) ) {
                $target_rev = null;
                foreach ( $revisions as $rev ) {
                    if ( strpos( $rev->post_content, '<!-- hts-faq -->' ) === false
                        && strpos( $rev->post_content, 'hts-faq-section' ) === false ) {
                        $target_rev = $rev;
                        break;
                    }
                }
                if ( ! $target_rev ) $target_rev = reset( $revisions );
                $current_len = $post ? mb_strlen( $post->post_content ) : 0;
                $restore_len = mb_strlen( $target_rev->post_content );
                return array(
                    'error'        => false,
                    'action_id'    => $action_id,
                    'type'         => $action->type,
                    'post_title'   => $post ? $post->post_title : '',
                    'agent_label'  => self::get_agent_labels()[ $action->agent ] ?? ucfirst( $action->agent ),
                    'fallback'     => 'revision',
                    'can_rollback' => true,
                    'fields'       => array( array(
                        'label'   => 'Contenu',
                        'current' => 'Version actuelle (' . number_format( $current_len ) . ' caractères)',
                        'restore' => 'Révision WordPress du ' . get_the_date( 'd/m/Y H:i', $target_rev ) . ' (' . number_format( $restore_len ) . ' caractères)',
                    ) ),
                );
            }
            return array( 'error' => 'Données de restauration corrompues' );
        }

        $labels = self::get_field_labels();
        $agent_labels = self::get_agent_labels();

        $preview = array(
            'action_id'   => $action_id,
            'type'        => $action->type,
            'agent'       => $action->agent,
            'agent_label' => $agent_labels[ $action->agent ] ?? ucfirst( $action->agent ),
            'post_id'     => $post_id,
            'post_title'  => $post ? $post->post_title : '(article supprimé)',
            'fields'      => array(),
            'can_rollback' => true,
        );

        // Construire le diff inversé : current → backup (restauration)
        switch ( $action->type ) {
            case 'add_meta_title':
            case 'optimize_meta_title':
                $current = get_post_meta( $post_id, '_hts_meta_title', true ) ?: '';
                $restore = $backup['meta_title'] ?? '';
                $preview['fields'][] = array(
                    'label'   => $labels['meta_title'],
                    'current' => $current ?: '(aucun)',
                    'restore' => $restore ?: '(aucun — WordPress génèrera automatiquement)',
                );
                break;

            case 'add_meta_desc':
            case 'optimize_meta_desc':
                $current = get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
                $restore = $backup['meta_description'] ?? '';
                $preview['fields'][] = array(
                    'label'   => $labels['meta_description'],
                    'current' => $current ?: '(aucune)',
                    'restore' => $restore ?: '(aucune — Google utilisera un extrait aléatoire)',
                );
                break;

            case 'optimize_meta_both':
                $current_t = get_post_meta( $post_id, '_hts_meta_title', true ) ?: '';
                $restore_t = $backup['meta_title'] ?? '';
                $preview['fields'][] = array(
                    'label'   => $labels['meta_title'],
                    'current' => $current_t ?: '(aucun)',
                    'restore' => $restore_t ?: '(aucun)',
                );
                $current_d = get_post_meta( $post_id, '_hts_meta_description', true ) ?: '';
                $restore_d = $backup['meta_description'] ?? '';
                $preview['fields'][] = array(
                    'label'   => $labels['meta_description'],
                    'current' => $current_d ?: '(aucune)',
                    'restore' => $restore_d ?: '(aucune)',
                );
                break;

            case 'fix_orphan_links':
            case 'add_internal_links':
            case 'add_faq':
            case 'geo_optimize':
            case 'fix_image_alt':
                $current_len = $post ? mb_strlen( $post->post_content ) : 0;
                $restore_len = mb_strlen( $backup['content'] ?? '' );
                $preview['fields'][] = array(
                    'label'   => $labels['content'],
                    'current' => 'Version actuelle (' . number_format( $current_len ) . ' caractères)',
                    'restore' => 'Version précédente (' . number_format( $restore_len ) . ' caractères)',
                );
                break;

            case 'add_featured_image':
                $current_thumb = get_post_thumbnail_id( $post_id );
                $backup_thumb  = $backup['thumbnail_id'] ?? 0;
                $preview['fields'][] = array(
                    'label'   => 'Image mise en avant',
                    'current' => $current_thumb ? 'Image #' . $current_thumb : '(aucune)',
                    'restore' => $backup_thumb ? 'Image #' . $backup_thumb : '(aucune — l\'image sera supprimée)',
                );
                break;

            case 'content_refresh':
                if ( isset( $backup['meta_title'] ) ) {
                    $preview['fields'][] = array(
                        'label'   => $labels['meta_title'],
                        'current' => get_post_meta( $post_id, '_hts_meta_title', true ) ?: '(aucun)',
                        'restore' => $backup['meta_title'] ?: '(aucun)',
                    );
                }
                if ( isset( $backup['meta_description'] ) ) {
                    $preview['fields'][] = array(
                        'label'   => $labels['meta_description'],
                        'current' => get_post_meta( $post_id, '_hts_meta_description', true ) ?: '(aucune)',
                        'restore' => $backup['meta_description'] ?: '(aucune)',
                    );
                }
                $current_len = $post ? mb_strlen( $post->post_content ) : 0;
                $restore_len = mb_strlen( $backup['content'] ?? '' );
                $preview['fields'][] = array(
                    'label'   => $labels['content'],
                    'current' => 'Version actuelle (' . number_format( $current_len ) . ' caractères)',
                    'restore' => 'Version sauvegardée (' . number_format( $restore_len ) . ' caractères)',
                );
                break;

            case 'delete_page':
                $preview['fields'][] = array(
                    'label'   => $labels['post_status'],
                    'current' => $post ? ucfirst( $post->post_status ) : 'Corbeille',
                    'restore' => ucfirst( $backup['post_status'] ?? 'publish' ),
                );
                break;

            default:
                if ( isset( $backup['content'] ) ) {
                    $current_len = $post ? mb_strlen( $post->post_content ) : 0;
                    $restore_len = mb_strlen( $backup['content'] );
                    $preview['fields'][] = array(
                        'label'   => $labels['content'],
                        'current' => 'Version actuelle (' . number_format( $current_len ) . ' caractères)',
                        'restore' => 'Version sauvegardée (' . number_format( $restore_len ) . ' caractères)',
                    );
                }
                break;
        }

        // Vérifier si le post existe encore
        if ( ! $post && $action->type !== 'delete_page' ) {
            $preview['can_rollback'] = false;
            $preview['error'] = 'L\'article a été supprimé définitivement — impossible de restaurer';
        }

        return $preview;
    }

    /**
     *
     * @since 2.3.1
     */
    public static function rollback( $action_id ) {
        $action = self::get_action( $action_id );
        if ( ! $action ) return new \WP_Error( 'not_found', 'Action introuvable' );
        if ( $action->status !== self::STATUS_DONE ) return new \WP_Error( 'invalid_status', 'Seules les actions terminées peuvent être annulées' );

        $post_id     = (int) $action->post_id;
        $backup_json = get_post_meta( $post_id, '_hts_action_backup_' . $action_id, true );
        if ( ! $backup_json ) {
            // Sprint 6.3c: pas de backup JSON → le update_post_meta a probablement échoué (taille)
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( sprintf( 'Rollback: backup JSON absent pour post #%d action %d — fallback révision WP', $post_id, $action_id ), 'warn', 'workflow' );
            }

            // v2.6.2 fix: priorité au pre_revision_id sauvé séparément (filet de sécurité)
            $pre_rev_id = (int) get_post_meta( $post_id, '_hts_pre_rev_' . $action_id, true );
            if ( $pre_rev_id > 0 ) {
                $pre_rev = get_post( $pre_rev_id );
                if ( $pre_rev && $pre_rev->post_type === 'revision' ) {
                    wp_restore_post_revision( $pre_rev_id );
                    self::clean_hts_from_builder_data( $post_id );
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf( 'Rollback via pre_rev sauvée #%d pour post #%d (action %d)', $pre_rev_id, $post_id, $action_id ), 'info', 'workflow' );
                    }
                    $backup = array( 'type' => $action->type, '_revision_fallback' => true );
                } else {
                    $pre_rev_id = 0; // invalide, continuer vers heuristique
                }
            }

            if ( $pre_rev_id <= 0 ) {
            $revisions = wp_get_post_revisions( $post_id, array( 'numberposts' => 5 ) );
            if ( ! empty( $revisions ) ) {
                // Sprint 6.3c: essayer de trouver une révision SANS marqueur HTS-FAQ
                $target_rev = null;
                foreach ( $revisions as $rev ) {
                    if ( strpos( $rev->post_content, '<!-- hts-faq -->' ) === false
                        && strpos( $rev->post_content, 'hts-faq-section' ) === false ) {
                        $target_rev = $rev;
                        break;
                    }
                }
                if ( ! $target_rev ) $target_rev = reset( $revisions ); // dernier recours
                wp_restore_post_revision( $target_rev->ID );
                self::clean_hts_from_builder_data( $post_id );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( sprintf( 'Rollback via révision WP #%d pour post #%d (action %d)', $target_rev->ID, $post_id, $action_id ), 'info', 'workflow' );
                }
                $backup = array( 'type' => $action->type, '_revision_fallback' => true );
            } else {
                return new \WP_Error( 'no_backup', 'Aucun point de restauration disponible' );
            }
            }
        }

        if ( ! isset( $backup ) ) {
            $backup = json_decode( $backup_json, true );
            if ( ! is_array( $backup ) ) {
                $backup = json_decode( stripslashes( $backup_json ), true );
            }
            if ( ! is_array( $backup ) ) {
                // v2.6.2 fix: priorité au pre_revision_id sauvé séparément
                $pre_rev_id2 = (int) get_post_meta( $post_id, '_hts_pre_rev_' . $action_id, true );
                if ( $pre_rev_id2 > 0 ) {
                    $pre_rev2 = get_post( $pre_rev_id2 );
                    if ( $pre_rev2 && $pre_rev2->post_type === 'revision' ) {
                        wp_restore_post_revision( $pre_rev_id2 );
                        self::clean_hts_from_builder_data( $post_id );
                        if ( function_exists( 'hts_add_log' ) ) {
                            hts_add_log( sprintf( 'Rollback via pre_rev sauvée #%d (backup corrompu) post #%d action %d', $pre_rev_id2, $post_id, $action_id ), 'warn', 'workflow' );
                        }
                        $backup = array( 'type' => $action->type, '_revision_fallback' => true );
                    } else {
                        $pre_rev_id2 = 0;
                    }
                }
                if ( $pre_rev_id2 <= 0 ) {
                // Last fallback: WordPress revisions — chercher une révision propre
                $revisions = wp_get_post_revisions( $post_id, array( 'numberposts' => 5 ) );
                if ( ! empty( $revisions ) ) {
                    $target_rev = null;
                    foreach ( $revisions as $rev ) {
                        if ( strpos( $rev->post_content, '<!-- hts-faq -->' ) === false
                            && strpos( $rev->post_content, 'hts-faq-section' ) === false ) {
                            $target_rev = $rev;
                            break;
                        }
                    }
                    if ( ! $target_rev ) $target_rev = reset( $revisions );
                    wp_restore_post_revision( $target_rev->ID );
                    self::clean_hts_from_builder_data( $post_id );
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf( 'Rollback via révision WP (backup corrompu) post #%d — rev #%d', $post_id, $target_rev->ID ), 'warn', 'workflow' );
                    }
                    $backup = array( 'type' => $action->type, '_revision_fallback' => true );
                } else {
                    return new \WP_Error( 'corrupt_backup', 'Données de restauration corrompues' );
                }
                }
            }
        }

        $type = $backup['type'] ?? $action->type;

        // Sprint 6.3c fix: recharger les données builder depuis les metas séparées
        // (stockées séparément depuis 6.3c pour éviter le dépassement max_allowed_packet)
        $backup_key = '_hts_action_backup_' . $action_id;
        $builder_keys = array( '_elementor_data', '_fl_builder_data', '_bricks_page_content_2' );
        foreach ( $builder_keys as $bk ) {
            if ( empty( $backup[ $bk ] ) ) {
                $bk_data = get_post_meta( $post_id, $backup_key . $bk, true );
                if ( $bk_data ) {
                    $backup[ $bk ] = $bk_data;
                }
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            $has_content = isset( $backup['content'] ) ? 'oui (' . strlen( $backup['content'] ) . ' chars)' : 'NON';
            $has_el      = ! empty( $backup['_elementor_data'] ) ? 'oui' : 'non';
            hts_add_log( sprintf( 'Rollback post #%d type=%s | content=%s | elementor=%s | revision_fallback=%s',
                $post_id, $type, $has_content, $has_el, empty( $backup['_revision_fallback'] ) ? 'non' : 'OUI' ), 'info', 'workflow' );
        }

        // Sprint 6.2c: If revision fallback already restored, skip manual restore
        if ( empty( $backup['_revision_fallback'] ) ) {
        switch ( $type ) {
            case 'add_meta_title':
            case 'optimize_meta_title':
                if ( isset( $backup['meta_title'] ) ) update_post_meta( $post_id, '_hts_meta_title', $backup['meta_title'] );
                break;
            case 'add_meta_desc':
            case 'optimize_meta_desc':
                if ( isset( $backup['meta_description'] ) ) update_post_meta( $post_id, '_hts_meta_description', $backup['meta_description'] );
                break;
            case 'optimize_meta_both':
                if ( isset( $backup['meta_title'] ) ) update_post_meta( $post_id, '_hts_meta_title', $backup['meta_title'] );
                if ( isset( $backup['meta_description'] ) ) update_post_meta( $post_id, '_hts_meta_description', $backup['meta_description'] );
                break;
            case 'fix_orphan_links':
            case 'add_internal_links':
            case 'add_faq':
            case 'geo_optimize':
            case 'enrich_thin_content':
                if ( isset( $backup['content'] ) ) {
                    $rb = wp_update_post( array( 'ID' => $post_id, 'post_content' => $backup['content'] ) );
                    if ( is_wp_error( $rb ) || 0 === $rb ) hts_add_log( 'Workflow rollback échec post #' . $post_id, 'error', 'workflow' );
                }
                // Restore all builder data
                self::restore_builder_data( $post_id, $backup );
                break;
            case 'fix_image_alt':
                // Sprint 6.3c: restaurer les ALT des attachments
                if ( ! empty( $backup['attachment_alts'] ) && is_array( $backup['attachment_alts'] ) ) {
                    $restored_alts = 0;
                    foreach ( $backup['attachment_alts'] as $att_id => $old_alt ) {
                        if ( empty( $old_alt ) ) {
                            delete_post_meta( (int) $att_id, '_wp_attachment_image_alt' );
                        } else {
                            update_post_meta( (int) $att_id, '_wp_attachment_image_alt', $old_alt );
                        }
                        $restored_alts++;
                    }
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log( sprintf( 'Rollback fix_image_alt: %d ALT restaurés pour post #%d', $restored_alts, $post_id ), 'info', 'workflow' );
                    }
                }
                // Restaurer aussi le contenu et builder data
                if ( isset( $backup['content'] ) ) {
                    wp_update_post( array( 'ID' => $post_id, 'post_content' => $backup['content'] ) );
                }
                self::restore_builder_data( $post_id, $backup );
                break;
            case 'add_featured_image':
                if ( isset( $backup['thumbnail_id'] ) ) {
                    if ( $backup['thumbnail_id'] ) {
                        set_post_thumbnail( $post_id, (int) $backup['thumbnail_id'] );
                    } else {
                        delete_post_thumbnail( $post_id );
                    }
                }
                break;
            case 'content_refresh':
                if ( isset( $backup['content'] ) ) {
                    $update = array( 'ID' => $post_id, 'post_content' => $backup['content'] );
                    if ( ! empty( $backup['post_title'] ) ) $update['post_title'] = sanitize_text_field( $backup['post_title'] );
                    $rb = wp_update_post( $update );
                    if ( is_wp_error( $rb ) || 0 === $rb ) hts_add_log( 'Workflow rollback refresh échec post #' . $post_id, 'error', 'workflow' );
                }
                if ( isset( $backup['meta_title'] ) ) update_post_meta( $post_id, '_hts_meta_title', $backup['meta_title'] );
                if ( isset( $backup['meta_description'] ) ) update_post_meta( $post_id, '_hts_meta_description', $backup['meta_description'] );
                self::restore_builder_data( $post_id, $backup );
                break;
            case 'delete_page':
                if ( isset( $backup['post_status'] ) && $backup['post_status'] !== 'trash' ) {
                    $rb = wp_update_post( array( 'ID' => $post_id, 'post_status' => $backup['post_status'] ) );
                    if ( is_wp_error( $rb ) || 0 === $rb ) hts_add_log( 'Workflow rollback status échec post #' . $post_id, 'error', 'workflow' );
                }
                break;
            default:
                if ( isset( $backup['content'] ) ) {
                    $rb = wp_update_post( array( 'ID' => $post_id, 'post_content' => $backup['content'] ) );
                    if ( is_wp_error( $rb ) || 0 === $rb ) hts_add_log( 'Workflow rollback default échec post #' . $post_id, 'error', 'workflow' );
                }
                self::restore_builder_data( $post_id, $backup );
                break;
        }
        } // end if ! _revision_fallback

        // Marquer comme rollbacked
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        $wpdb->update( $table,
            array(
                'execution_log' => ( $action->execution_log ? $action->execution_log . ' | ' : '' ) . 'Restauré le ' . current_time( 'mysql' ),
                'status'        => 'rollbacked',
            ),
            array( 'id' => $action_id )
        );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Workflow rollback : action #{$action_id} ({$type}) sur post #{$post_id}", 'info', 'workflow' );
        }

        return true;
    }

    /* ═══════════════════════════════════════════════
     *  API INTERNE — QUERY
     * ═══════════════════════════════════════════════ */

    /**
     * Récupérer une action par ID.
     *
     * @param int $id
     * @return object|null
     */
    public static function get_action( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
    }

    /**
     * Récupérer les actions pending, optionnellement filtrées par agent.
     *
     * @param string|null $agent  Filtrer par agent (null = tous)
     * @param int         $limit  Max résultats
     * @return array
     */
    public static function get_pending( $agent = null, $limit = 50 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        if ( $agent ) {
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$table} WHERE status = 'pending' AND agent = %s ORDER BY FIELD(priority, 'critical', 'high', 'medium', 'low'), created_at ASC LIMIT %d",
                $agent, $limit
            ) );
        }

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE status = 'pending' ORDER BY FIELD(priority, 'critical', 'high', 'medium', 'low'), created_at ASC LIMIT %d",
            $limit
        ) );
    }

    /**
     * Récupérer les actions pending groupées par agent+type (= cartes Inbox).
     *
     * @return array [ { agent, type, count, priority_max, actions[] } ]
     */
    public static function get_inbox_cards() {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $raw = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE status = %s ORDER BY FIELD(priority, 'critical', 'high', 'medium', 'low'), created_at ASC",
            self::STATUS_PENDING
        ) );

        $agent_labels  = self::get_agent_labels();
        $action_labels = self::get_action_labels();

        $cards = array();

        // v2.5.12: Get current language for Polylang/WPML filtering
        $current_lang = null;
        if ( function_exists( 'pll_current_language' ) ) {
            $current_lang = pll_current_language( 'slug' );
        } elseif ( defined( 'ICL_LANGUAGE_CODE' ) ) {
            $current_lang = ICL_LANGUAGE_CODE;
        }

        foreach ( $raw as $action ) {

            // v2.5.12: Filter by current language
            if ( $current_lang && (int) $action->post_id > 0 ) {
                $post_lang = null;
                if ( function_exists( 'pll_get_post_language' ) ) {
                    $post_lang = pll_get_post_language( (int) $action->post_id, 'slug' );
                } elseif ( function_exists( 'wpml_get_language_information' ) ) {
                    $lang_info = wpml_get_language_information( null, (int) $action->post_id );
                    $post_lang = $lang_info['language_code'] ?? null;
                }
                if ( $post_lang && $post_lang !== $current_lang ) {
                    continue;
                }
            }

            $key = $action->agent . '::' . $action->type;
            if ( ! isset( $cards[ $key ] ) ) {
                $cards[ $key ] = array(
                    'agent'        => $action->agent,
                    'agent_label'  => $agent_labels[ $action->agent ] ?? ucfirst( $action->agent ),
                    'type'         => $action->type,
                    'type_label'   => $action_labels[ $action->type ] ?? ucfirst( str_replace( '_', ' ', $action->type ) ),
                    'count'        => 0,
                    'priority_max' => $action->priority,
                    'actions'      => array(),
                );
            }
            $cards[ $key ]['count']++;

            // Enrichir chaque action avec post_title, date relative, raison
            $enriched = (array) $action;
            if ( (int) $action->post_id > 0 ) {
                $enriched['post_title'] = get_the_title( (int) $action->post_id ) ?: '(article #' . $action->post_id . ')';
                $enriched['post_url']   = get_permalink( (int) $action->post_id );
            }
            $data = json_decode( $action->data, true );
            $enriched['reason'] = $data['reason'] ?? '';
            $enriched['time_ago'] = human_time_diff( ( new \DateTimeImmutable( $action->created_at, wp_timezone() ) )->getTimestamp() );
            // S13-B: Pass confidence data to Inbox template
            if ( ! empty( $data['_confidence_warn'] ) ) {
                $enriched['_confidence_warn'] = (int) $data['_confidence_warn'];
                $enriched['_confidence_note'] = $data['_confidence_note'] ?? '';
            }
            if ( ! empty( $data['_confidence_boost'] ) ) {
                $enriched['_confidence_boost'] = (int) $data['_confidence_boost'];
            }

            $cards[ $key ]['actions'][] = (object) $enriched;

            // Garder la priorité max
            $order = array( 'critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1 );
            if ( ( $order[ $action->priority ] ?? 0 ) > ( $order[ $cards[ $key ]['priority_max'] ] ?? 0 ) ) {
                $cards[ $key ]['priority_max'] = $action->priority;
            }
        }

        return array_values( $cards );
    }

    /**
     * Stats du workflow.
     *
     * @return array { pending, approved, rejected, done, failed, total, by_agent }
     */
    public static function get_stats( $days = 0 ) {
        // Request-level cache — called 4 times per cockpit load
        static $cached = array();
        if ( isset( $cached[ $days ] ) ) return $cached[ $days ];

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // Vérifier que la table existe
        if ( ! self::_table_exists_cached( $table ) ) {
            $cached[ $days ] = array( 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'done' => 0, 'failed' => 0, 'total' => 0, 'by_agent' => array() );
            return $cached[ $days ];
        }

        $date_clause = '';
        if ( $days > 0 ) {
            $cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
            $date_clause = $wpdb->prepare( ' AND created_at >= %s', $cutoff );
        }

        $counts = $wpdb->get_results(
            "SELECT status, COUNT(*) as cnt FROM {$table} WHERE 1=1{$date_clause} GROUP BY status"
        );

        $stats = array( 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'dismissed' => 0, 'executing' => 0, 'done' => 0, 'failed' => 0, 'blocked' => 0, 'total' => 0 );
        foreach ( $counts as $c ) {
            $stats[ $c->status ] = (int) $c->cnt;
            $stats['total'] += (int) $c->cnt;
        }

        // Par agent
        $by_agent = $wpdb->get_results(
            "SELECT agent, status, COUNT(*) as cnt FROM {$table} WHERE 1=1{$date_clause} GROUP BY agent, status"
        );
        $agents = array();
        foreach ( $by_agent as $row ) {
            if ( ! isset( $agents[ $row->agent ] ) ) {
                $agents[ $row->agent ] = array( 'pending' => 0, 'done' => 0, 'failed' => 0 );
            }
            $agents[ $row->agent ][ $row->status ] = (int) $row->cnt;
        }
        $stats['by_agent'] = $agents;

        $cached[ $days ] = $stats;
        return $cached[ $days ];
    }

    /* ═══════════════════════════════════════════════
     *  AGENT CONFIG
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifier si un agent est activé.
     */
    public static function is_agent_enabled( $agent ) {
        global $wpdb;
        $table = $wpdb->prefix . self::AGENTS_TABLE;

        if ( ! self::_table_exists_cached( $table ) ) return true; // Avant création de table, on laisse passer

        $enabled = $wpdb->get_var( $wpdb->prepare(
            "SELECT enabled FROM {$table} WHERE agent = %s", $agent
        ) );

        // Agent pas en base → considéré comme activé par défaut
        if ( $enabled === null ) return true;

        return (bool) $enabled;
    }

    /**
     * Récupérer le mode d'un agent (review|auto).
     */
    public static function get_agent_mode( $agent ) {
        global $wpdb;
        $table = $wpdb->prefix . self::AGENTS_TABLE;

        if ( ! self::_table_exists_cached( $table ) ) return self::MODE_REVIEW;

        $mode = $wpdb->get_var( $wpdb->prepare(
            "SELECT mode FROM {$table} WHERE agent = %s", $agent
        ) );

        return $mode ?: self::MODE_REVIEW;
    }

    /**
     * Récupérer les settings d'un agent.
     */
    public static function get_agent_settings( $agent ) {
        global $wpdb;
        $table = $wpdb->prefix . self::AGENTS_TABLE;

        if ( ! self::_table_exists_cached( $table ) ) return array();

        $json = $wpdb->get_var( $wpdb->prepare(
            "SELECT settings FROM {$table} WHERE agent = %s", $agent
        ) );

        return json_decode( (string) $json, true ) ?: array();
    }

    /**
     * Schéma des réglages par agent : clé, label, type, défaut, description, contraintes.
     *
     * @since 2.4.2
     * @return array { agent_id => [ [ 'key'=>…, 'label'=>…, 'type'=>…, 'default'=>…, 'desc'=>…, 'min'=>…, 'max'=>… ], … ] }
     */
    public static function get_agent_settings_schema() {
        return array(
            'auto_write' => array(
                array( 'key' => 'max_articles_week', 'label' => 'Articles max par semaine',  'type' => 'number', 'default' => 3,  'min' => 1, 'max' => 20, 'desc' => 'Nombre maximum de nouveaux articles générés par semaine.' ),
                array( 'key' => 'publish_mode',      'label' => 'Mode de publication',        'type' => 'select', 'default' => 'draft', 'options' => array( 'draft' => 'Brouillon', 'publish' => 'Publication directe' ), 'desc' => 'Les articles sont créés en brouillon ou publiés automatiquement.' ),
            ),
            'fresh' => array(
                array( 'key' => 'min_age_days',   'label' => 'Ancienneté min. (jours)',  'type' => 'number', 'default' => 180, 'min' => 30, 'max' => 730, 'desc' => 'Nombre de jours sans mise à jour avant de signaler un article.' ),
                array( 'key' => 'max_clicks',      'label' => 'Seuil clics max',          'type' => 'number', 'default' => 5,   'min' => 0,  'max' => 1000, 'desc' => 'Les articles avec plus de clics que ce seuil ne seront pas signalés.' ),
            ),
            'commander' => array(
                array( 'key' => 'max_articles_week', 'label' => 'Articles max par semaine',  'type' => 'number', 'default' => 3, 'min' => 1, 'max' => 20, 'desc' => 'Nombre maximum de commandes d\'articles par semaine.' ),
                array( 'key' => 'default_category',  'label' => 'Catégorie par défaut',      'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 99999, 'desc' => 'ID de la catégorie WordPress par défaut (0 = non catégorisé).' ),
            ),
            'meta' => array(
                array( 'key' => 'title_max_length',    'label' => 'Longueur cible titre',          'type' => 'number', 'default' => 60,  'min' => 30,  'max' => 80,  'desc' => 'Nombre de caractères visé pour les titres SEO.' ),
                array( 'key' => 'desc_max_length',     'label' => 'Longueur cible description',     'type' => 'number', 'default' => 155, 'min' => 80,  'max' => 200, 'desc' => 'Nombre de caractères visé pour les meta descriptions.' ),
            ),
            'linking' => array(
                array( 'key' => 'max_links_per_post',  'label' => 'Liens max par article',    'type' => 'number', 'default' => 5,    'min' => 1,    'max' => 30, 'desc' => 'Nombre maximum de liens internes proposés par article.' ),
                array( 'key' => 'min_semantic_score',   'label' => 'Score sémantique min.',     'type' => 'number', 'default' => 0.30, 'min' => 0.10, 'max' => 0.90, 'desc' => 'Score de proximité sémantique minimum entre deux articles (0.1 à 0.9).' ),
            ),
            'content_quality' => array(
                array( 'key' => 'thin_content_words', 'label' => 'Seuil "contenu court" (mots)', 'type' => 'number', 'default' => 300, 'min' => 100, 'max' => 1000, 'desc' => 'En dessous de ce nombre de mots, un article est considéré comme trop court.' ),
                array( 'key' => 'check_alt',          'label' => 'Vérifier les ALT des images', 'type' => 'toggle',  'default' => true, 'desc' => 'Détecter les images sans attribut ALT dans vos articles.' ),
            ),
            'geo_score' => array(
                array( 'key' => 'min_score_alert', 'label' => 'Score minimum pour alerte', 'type' => 'number', 'default' => 50, 'min' => 10, 'max' => 90, 'desc' => 'Les articles avec un score inférieur déclenchent une proposition dans l\'Inbox.' ),
            ),
            'coach' => array(
                array( 'key' => 'model',       'label' => 'Modèle IA',        'type' => 'select', 'default' => 'auto', 'options' => array( 'auto' => 'Auto 3 tiers (4o-mini → 4.1-mini → Haiku)', 'claude-sonnet-4-5-20250929' => 'Claude Sonnet 4.5 (premium)', 'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5 (tout)', 'gpt-4.1-mini' => 'GPT-4.1 mini (tout)', 'gpt-4o-mini' => 'GPT-4o mini (tout)' ), 'desc' => 'Auto = 4o-mini (support/simple), 4.1-mini (analyse SEO), Haiku (stratégie). Le plus économique.' ),
                array( 'key' => 'temperature', 'label' => 'Température',      'type' => 'number', 'default' => 0.3, 'min' => 0, 'max' => 1.0, 'desc' => 'Créativité des réponses du Coach (0 = factuel, 1 = créatif).' ),
            ),
            'cannib' => array(
                array( 'key' => 'similarity_threshold', 'label' => 'Seuil de similarité',  'type' => 'number', 'default' => 0.85, 'min' => 0.50, 'max' => 0.99, 'desc' => 'Score de similarité au-dessus duquel deux articles sont considérés en conflit.' ),
            ),
            'strategy' => array(
                array( 'key' => 'auto_prioritize', 'label' => 'Priorisation automatique',  'type' => 'toggle', 'default' => true, 'desc' => 'Trier automatiquement les actions par impact estimé.' ),
            ),
            'image' => array(
                // ── CLIENT-FACING ──
                array( 'key' => 'featured_source',      'label' => 'Image mise en avant',    'type' => 'select', 'default' => 'ai', 'options' => array( 'ai' => 'Générée par l\'IA (recommandé)', 'media_library' => 'Depuis ma bibliothèque média', 'disabled' => 'Désactivé' ), 'desc' => 'Chaque article aura une image de couverture unique.' ),
                array( 'key' => 'image_style',          'label' => 'Style des images',       'type' => 'visual_select', 'default' => 'illustration', 'options' => array( 'illustration' => 'Illustration', 'photo_realistic' => 'Photo réaliste', 'infographic' => 'Infographie', 'minimalist' => 'Minimaliste' ), 'desc' => 'L\'ambiance visuelle de toutes vos images IA.' ),
                array( 'key' => 'incontent_enabled',    'label' => 'Images dans le contenu', 'type' => 'toggle', 'default' => true, 'desc' => '2 images par article, placées dans le corps du texte pour illustrer vos propos.' ),
                array( 'key' => 'brand_color_primary',  'label' => 'Couleur principale',     'type' => 'color', 'default' => '', 'desc' => 'Couleur dominante de votre marque. Les images IA l\'utiliseront.' ),
                array( 'key' => 'brand_color_secondary','label' => 'Couleur secondaire',     'type' => 'color', 'default' => '', 'desc' => 'Couleur d\'accent.' ),
                array( 'key' => 'extra_instructions',   'label' => 'Instructions personnalisées', 'type' => 'textarea', 'default' => '', 'desc' => 'Consignes ajoutées à chaque image (ex: "style corporate", "toujours inclure des plantes vertes"). Max 500 caractères.' ),
                // ── TECHNIQUE (section avancée) ──
                array( 'key' => 'image_provider',    'label' => 'Fournisseur IA',      'type' => 'select', 'default' => 'flux', 'options' => array( 'openai' => 'OpenAI', 'flux' => 'BFL Flux' ), 'advanced' => true, 'require_show_keys' => true ),
                array( 'key' => 'openai_model',      'label' => 'Modèle OpenAI',       'type' => 'select', 'default' => 'gpt-image-1', 'options' => array( 'gpt-image-1' => 'gpt-image-1', 'gpt-image-1-mini' => 'gpt-image-1-mini' ), 'advanced' => true, 'require_show_keys' => true ),
                array( 'key' => 'flux_model',        'label' => 'Modèle Flux',         'type' => 'select', 'default' => 'flux-2-pro', 'options' => array( 'flux-2-pro' => 'FLUX.2 pro', 'flux-2-klein-4b' => 'FLUX.2 klein 4B' ), 'advanced' => true, 'require_show_keys' => true ),
                array( 'key' => 'flux_api_key',      'label' => 'Clé API BFL',         'type' => 'password', 'default' => '', 'advanced' => true, 'require_show_keys' => true, 'test_action' => 'hts_test_flux_key', 'test_param' => 'flux_api_key' ),
                array( 'key' => 'pexels_api_key',    'label' => 'Clé API Pexels',      'type' => 'password', 'default' => '', 'advanced' => true, 'require_show_keys' => true ),
            ),
            'monitoring' => array(
                array( 'key' => 'check_interval_hours', 'label' => 'Fréquence de vérification (heures)', 'type' => 'number', 'default' => 6, 'min' => 1, 'max' => 24, 'desc' => 'Intervalle entre chaque vérification automatique.' ),
            ),
        );
    }

    /**
     * Récupérer les réglages d'un agent, avec fallback sur les défauts.
     *
     * @since 2.4.2
     * @param string $agent Agent ID.
     * @return array Merged settings.
     */
    public static function get_agent_settings_with_defaults( $agent ) {
        $schema   = self::get_agent_settings_schema();
        $fields   = $schema[ $agent ] ?? array();
        $saved    = self::get_agent_settings( $agent );
        $merged   = array();
        foreach ( $fields as $field ) {
            $key = $field['key'];
            if ( isset( $saved[ $key ] ) ) {
                $merged[ $key ] = $saved[ $key ];
            } else {
                $merged[ $key ] = $field['default'];
            }
        }

        // Image agent: forced defaults + migration
        if ( $agent === 'image' ) {
            // Migrate old featured_style / incontent_types → unified image_style
            if ( ! empty( $saved['featured_style'] ) && empty( $saved['image_style'] ) ) {
                $merged['image_style'] = $saved['featured_style'];
            }
            // Force technical defaults (not exposed in UI)
            $merged['featured_quality']      = 'medium';
            $merged['incontent_quality']     = 'medium';
            $merged['incontent_count']       = 2;
            $merged['incontent_position']    = 'after_h2_p';
            $merged['featured_text_overlay'] = 'none';
            $merged['featured_enabled']      = ( $merged['featured_source'] ?? 'ai' ) !== 'disabled';
            // Sync style to old keys for backward compat
            $merged['featured_style']  = $merged['image_style'] ?? 'illustration';
            $merged['incontent_types'] = $merged['image_style'] ?? 'illustration';
        }

        return $merged;
    }

    /**
     * Mettre à jour la config d'un agent.
     */
    public static function update_agent_config( $agent, $enabled = null, $mode = null, $settings = null ) {
        global $wpdb;
        $table = $wpdb->prefix . self::AGENTS_TABLE;

        $update = array();
        if ( $enabled !== null ) $update['enabled']  = (int) $enabled;
        if ( $mode !== null )    $update['mode']     = in_array( $mode, array( 'review', 'auto' ), true ) ? $mode : 'review';
        if ( $settings !== null ) $update['settings'] = wp_json_encode( $settings );

        if ( empty( $update ) ) return false;

        return (bool) $wpdb->update( $table, $update, array( 'agent' => $agent ) );
    }

    /**
     * Récupérer tous les agents avec leur config.
     */
    public static function get_all_agents() {
        global $wpdb;
        $table = $wpdb->prefix . self::AGENTS_TABLE;

        if ( ! self::_table_exists_cached( $table ) ) return array();

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE 1=%d ORDER BY agent ASC", 1
        ) );
        $agents = array();
        foreach ( $rows as $row ) {
            $agents[ $row->agent ] = array(
                'enabled'  => (bool) $row->enabled,
                'mode'     => $row->mode,
                'settings' => json_decode( $row->settings, true ) ?: array(),
            );
        }
        return $agents;
    }

    /* ═══════════════════════════════════════════════
     *  GARDE-FOUS
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifier la limite hebdo pour un agent (centralisée dans les garde-fous).
     */
    public static function check_weekly_limit( $agent, $type, $is_cocon = false ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        if ( ! self::_table_exists_cached( $table ) ) return true;

        // Utiliser la limite par agent des garde-fous centralisés
        $max = (int) self::get_agent_guardrail( $agent, 'max_per_week' );
        if ( $max <= 0 ) return true; // 0 = pas de limite
        // Cocon-aware linking proposals get a higher weekly limit (3x)
        if ( $is_cocon ) $max = max( $max, $max * 3 );

        $week_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
        // Compter seulement les actions EXÉCUTÉES cette semaine (pas les pending)
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE agent = %s AND status IN ('approved','executing','done') AND created_at >= %s",
            $agent, $week_ago
        ) );

        return $count < $max;
    }

    /**
     * Session P : Récupérer l'état d'utilisation hebdo pour affichage Inbox.
     *
     * @since 2.4.8
     * @return array { agent => [ 'used' => int, 'max' => int, 'remaining' => int ] }
     */
    public static function get_weekly_usage() {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        if ( ! self::_table_exists_cached( $table ) ) return array();

        $week_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
        $agents_raw = $wpdb->get_results( $wpdb->prepare(
            "SELECT agent, COUNT(*) as cnt FROM {$table} WHERE status IN ('approved','executing','done') AND created_at >= %s GROUP BY agent",
            $week_ago
        ) );

        $usage = array();
        foreach ( $agents_raw as $row ) {
            $max = (int) self::get_agent_guardrail( $row->agent, 'max_per_week' );
            $used = (int) $row->cnt;
            $usage[ $row->agent ] = array(
                'used'      => $used,
                'max'       => $max,
                'remaining' => max( 0, $max - $used ),
            );
        }
        return $usage;
    }

    /**
     * Vérifier le budget API mensuel.
     */
    public static function check_budget() {
        $max_budget = (float) get_option( 'hts_workflow_max_budget_month', self::DEFAULT_MAX_BUDGET_PER_MONTH );
        $spent      = (float) get_option( 'hts_api_cost_this_month', 0 );
        return $spent < $max_budget;
    }

    /**
     * Vérifier le seuil de trafic (ne pas toucher les pages performantes).
     */
    public static function check_traffic_threshold( $post_id ) {
        $threshold = (int) get_option( 'hts_workflow_traffic_threshold', self::DEFAULT_TRAFFIC_THRESHOLD );

        // Récupérer les clics GSC du dernier mois si disponible
        $clicks = (int) get_post_meta( $post_id, '_hts_gsc_clicks_30d', true );

        // Si pas de données GSC → laisser passer
        if ( $clicks <= 0 ) return true;

        // Si trafic au-dessus du seuil → bloquer les modifications auto
        return $clicks < $threshold;
    }

    /**
     * P4 : Vérifier la limite hebdo de réécritures.
     *
     * @since 2.4.2
     * @return bool true si on peut encore réécrire.
     */
    public static function check_rewrite_limit() {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // S13-B: Use static cache for table existence
        if ( ! self::_table_exists_cached( $table ) ) return true;

        $max = (int) get_option( 'hts_workflow_max_rewrites_per_week', 2 );
        if ( $max <= 0 ) return true;

        $week_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) );

        // S13-B: Avoid splat ...$args — forbidden on WP 6.2+ with prepare()
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE type IN (%s,%s,%s) AND status IN ('done','executing') AND created_at >= %s",
            'content_refresh', 'enrich_thin_content', 'geo_optimize', $week_ago
        ) );

        return $count < $max;
    }

    /**
     * P4 : Vérifier si on est dans les horaires autorisés pour les modifications auto.
     *
     * @since 2.4.2
     * @return bool true si on peut exécuter.
     */
    public static function check_auto_hours() {
        $start = (int) get_option( 'hts_workflow_auto_hours_start', 0 );
        $end   = (int) get_option( 'hts_workflow_auto_hours_end', 23 );

        // 0h-23h = toujours actif
        if ( $start === 0 && $end === 23 ) return true;

        $now = (int) current_time( 'G' ); // Heure locale WP (0-23)

        if ( $start <= $end ) {
            return $now >= $start && $now <= $end;
        }
        // Si plage inversée (ex: 22h à 6h)
        return $now >= $start || $now <= $end;
    }

    /**
     * P4 : Vérifier si une page est dans la blacklist.
     *
     * @since 2.4.2
     * @param int $post_id Post ID.
     * @return bool true si la page n'est PAS dans la blacklist (OK pour modifier).
     */
    public static function check_blacklist( $post_id ) {
        $blacklist = get_option( 'hts_workflow_blacklist_pages', array() );
        if ( ! is_array( $blacklist ) || empty( $blacklist ) ) return true;
        return ! in_array( (int) $post_id, array_map( 'intval', $blacklist ), true );
    }

    /**
     * Sprint 6.3d — Exclure les pages système de l'Inbox.
     *
     * Filtre automatique : pages WooCommerce (panier, checkout, mon-compte),
     * CGV, mentions légales, politique de confidentialité, etc.
     * Ces pages n'ont aucun intérêt SEO et encombrent l'Inbox.
     *
     * @since 2.5.8
     * @param int $post_id Post ID.
     * @return bool true si la page doit être exclue.
     */
    public static function is_excluded_page( $post_id ) {
        static $cache = array();
        $post_id = (int) $post_id;
        if ( $post_id <= 0 ) return true;
        if ( isset( $cache[ $post_id ] ) ) return $cache[ $post_id ];

        $post = get_post( $post_id );
        if ( ! $post ) { $cache[ $post_id ] = true; return true; }

        // ── WooCommerce system pages ──
        if ( function_exists( 'wc_get_page_id' ) ) {
            $woo_keys = array( 'cart', 'checkout', 'myaccount', 'shop', 'terms' );
            foreach ( $woo_keys as $wk ) {
                if ( (int) wc_get_page_id( $wk ) === $post_id ) {
                    $cache[ $post_id ] = true;
                    return true;
                }
            }
        }

        // ── WordPress system pages (front page, posts page, privacy) ──
        $wp_system_ids = array_filter( array(
            (int) get_option( 'wp_page_for_privacy_policy', 0 ),
            (int) get_option( 'page_for_posts', 0 ),
        ) );
        if ( in_array( $post_id, $wp_system_ids, true ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        $slug = $post->post_name;

        // ── Exact slug exclusions (FR + EN + DE + ES) ──
        $excluded_slugs = array(
            // Legal
            'cgv', 'cgu', 'conditions-generales-de-vente', 'conditions-generales',
            'mentions-legales', 'mention-legale', 'legal-notice', 'impressum',
            'politique-de-confidentialite', 'privacy-policy', 'politique-confidentialite',
            'donnees-personnelles', 'rgpd', 'gdpr',
            'conditions-dutilisation', 'terms-of-service', 'terms-and-conditions', 'terms',
            // E-commerce
            'panier', 'cart', 'checkout', 'commande', 'paiement', 'payment',
            'mon-compte', 'my-account', 'account',
            'wishlist', 'liste-de-souhaits',
            'retours-et-remboursements', 'refund-policy', 'returns',
            // Contact & utility
            'contact', 'contactez-nous', 'contact-us', 'nous-contacter',
            'a-propos', 'about', 'about-us', 'qui-sommes-nous',
            'code-de-conduite', 'code-conduite', 'code-of-conduct',
            'charte', 'reglement', 'reglement-interieur', 'rules',
            'faq', 'aide', 'help', 'support',
            // Blog / archive / index (Elementor pages used as blog listing)
            'blog', 'news', 'actualites', 'actualite', 'articles',
            'category', 'categories', 'tag', 'tags', 'archive', 'archives',
            // Site utility
            'sitemap', 'plan-du-site',
            'recherche', 'search', 'search-results',
            'connexion', 'login', 'register', 'inscription',
            'merci', 'thank-you', 'confirmation', 'order-received',
            'sample-page', 'exemple-de-page',
            '404-2', 'error-404', 'page-404',
            'cookie-policy', 'politique-de-cookies', 'cookies',
        );
        if ( in_array( $slug, $excluded_slugs, true ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        // ── Keyword patterns in slug (partial match) ──
        if ( preg_match( '/^(cgv|cgu|rgpd|gdpr|cookie|legal|terms|refund|retour|livraison-et-retour|thank-?you|merci|confirmation|order-received|sample|exemple)$/i', $slug ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        // ── Blog / archive pattern: slug is just a language prefix + "blog" ──
        // Catches: /fr/blog/, /en/blog/, /blog-2/, /actualites-2/
        if ( preg_match( '/^(blog|news|actualites|articles|archives?)(-\d+)?$/i', $slug ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        // ── Page template exclusions (WooCommerce, Elementor special) ──
        $template = get_page_template_slug( $post_id );
        if ( $template && preg_match( '/woocommerce|cart|checkout|account|elementor_(header|footer|archive|single|search|404)/i', $template ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        // ── Elementor: exclude pages used as theme templates (header, footer, archive, etc.) ──
        $el_type = get_post_meta( $post_id, '_elementor_template_type', true );
        if ( $el_type && in_array( $el_type, array(
            'header', 'footer', 'archive', 'search-results', 'single',
            'single-post', 'single-page', 'error-404', 'wp-post', 'kit',
            'popup', 'section', 'loop-item',
        ), true ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        // ── Post type: exclude non-content types ──
        $exclude_types = array(
            'elementor_library', 'elementor-thhf', 'e-landing-page',
            'wp_template', 'wp_template_part', 'wp_navigation', 'wp_global_styles',
            'fl-builder-template', 'brizy_template',
            'acf-field-group', 'wpcf7_contact_form', 'shop_order', 'shop_coupon',
        );
        if ( in_array( $post->post_type, $exclude_types, true ) ) {
            $cache[ $post_id ] = true;
            return true;
        }

        // ── Noindex pages — pas de sens d'optimiser le SEO d'une page exclue de Google ──
        $noindex_metas = array(
            '_hts_robots',                    // HTS
            '_yoast_wpseo_meta-robots-noindex', // Yoast (1 = noindex)
            'rank_math_robots',               // RankMath (serialized array)
            '_aioseo_noindex',                // AIOSEO
            '_seopress_robots_index',         // SEOPress
        );
        foreach ( $noindex_metas as $mk ) {
            $val = get_post_meta( $post_id, $mk, true );
            if ( empty( $val ) ) continue;
            // Yoast: '1' = noindex
            if ( $mk === '_yoast_wpseo_meta-robots-noindex' && $val === '1' ) {
                $cache[ $post_id ] = true;
                return true;
            }
            // RankMath: array or serialized containing 'noindex'
            if ( $mk === 'rank_math_robots' ) {
                $rm = is_array( $val ) ? $val : (array) maybe_unserialize( $val );
                if ( in_array( 'noindex', $rm, true ) ) {
                    $cache[ $post_id ] = true;
                    return true;
                }
            }
            // SEOPress: '1' = noindex
            if ( $mk === '_seopress_robots_index' && $val === '1' ) {
                $cache[ $post_id ] = true;
                return true;
            }
            // HTS / generic: string containing 'noindex'
            if ( is_string( $val ) && stripos( $val, 'noindex' ) !== false ) {
                $cache[ $post_id ] = true;
                return true;
            }
        }

        // ── Contenu quasi-vide (moins de 50 mots et c'est une "page" WP, pas un article) ──
        // Typiquement les pages d'accueil Elementor avec juste des widgets
        if ( $post->post_type === 'page' ) {
            $text = wp_strip_all_tags( $post->post_content );
            $word_count = hts_word_count( $text );
            // Page avec Elementor mais contenu textuel quasi-vide = page système/layout
            $has_elementor = ! empty( get_post_meta( $post_id, '_elementor_data', true ) );
            if ( $has_elementor && $word_count < 30 ) {
                $cache[ $post_id ] = true;
                return true;
            }
        }

        $cache[ $post_id ] = false;
        return false;
    }

    /**
     * Sprint 6.3d — Score de priorité d'une page pour l'Inbox.
     *
     * Calcule un score 0-100 basé sur :
     * - Données GSC (position striking distance, impressions, clicks)
     * - Nombre d'actions pending
     * - Signaux de qualité (contenu mince, liens internes faibles)
     * - Fraîcheur du contenu
     *
     * Plus le score est élevé, plus la page a besoin d'attention.
     *
     * @since 2.5.8
     * @param int   $post_id      Post ID.
     * @param int   $action_count Nombre d'actions pending sur cette page.
     * @param array $actions      Actions pending (enriched arrays with type, priority…).
     * @return array { score: int, signals: string[], label: string }
     */
    public static function compute_page_priority( $post_id, $action_count = 1, $actions = array() ) {
        $score   = 0;
        $signals = array();

        $post = get_post( $post_id );
        if ( ! $post ) {
            return array( 'score' => 0, 'signals' => array(), 'label' => 'low', 'gsc' => false );
        }

        // ── GSC data (strongest signal) ──
        $gsc_clicks      = (int) get_post_meta( $post_id, '_hts_gsc_clicks', true );
        $gsc_impressions = (int) get_post_meta( $post_id, '_hts_gsc_impressions', true );
        $gsc_position    = (float) get_post_meta( $post_id, '_hts_gsc_position', true );
        $has_gsc = ( $gsc_impressions > 0 || $gsc_clicks > 0 );

        if ( $has_gsc ) {
            // Striking distance (pos 5-20) = highest potential
            if ( $gsc_position > 3 && $gsc_position <= 10 ) {
                $score += 35;
                $signals[] = 'Position ' . round( $gsc_position, 1 ) . ' — gros potentiel';
            } elseif ( $gsc_position > 10 && $gsc_position <= 20 ) {
                $score += 25;
                $signals[] = 'Position ' . round( $gsc_position, 1 ) . ' — améliorable';
            } elseif ( $gsc_position > 20 && $gsc_position <= 50 ) {
                $score += 10;
            } else {
                $score += 3;
            }

            if ( $gsc_impressions > 1000 ) {
                $score += 20;
                $signals[] = number_format( $gsc_impressions, 0, ',', ' ' ) . ' impressions';
            } elseif ( $gsc_impressions > 500 ) {
                $score += 15;
                $signals[] = number_format( $gsc_impressions, 0, ',', ' ' ) . ' impressions';
            } elseif ( $gsc_impressions > 100 ) {
                $score += 8;
            } elseif ( $gsc_impressions > 0 ) {
                $score += 3;
            }

            if ( $gsc_clicks > 50 ) {
                $score += 10;
            } elseif ( $gsc_clicks > 10 ) {
                $score += 5;
            }
        }

        // ── Action priority weight ──
        $has_high_priority = false;
        $has_actionable    = false;
        foreach ( $actions as $act ) {
            $pri = $act['priority'] ?? 'medium';
            if ( in_array( $pri, array( 'critical', 'high' ), true ) ) {
                $has_high_priority = true;
            }
            $type = $act['type'] ?? '';
            // Actionable = can be auto-applied (not disabled)
            if ( ! in_array( $type, array( 'content_refresh', 'enrich_thin_content' ), true ) ) {
                $has_actionable = true;
            }
        }
        if ( $has_high_priority ) {
            $score += 12;
            $signals[] = 'Priorité haute';
        }

        // ── Multiple actions = more urgent ──
        if ( $action_count >= 5 ) {
            $score += 18;
            $signals[] = $action_count . ' optimisations possibles';
        } elseif ( $action_count >= 3 ) {
            $score += 12;
            $signals[] = $action_count . ' optimisations possibles';
        } elseif ( $action_count >= 2 ) {
            $score += 6;
        }

        // ── Post type: articles are more SEO-valuable than pages ──
        if ( $post->post_type === 'post' ) {
            $score += 8;
        }

        // ── Content quality (granular) ──
        $word_est = hts_word_count( wp_strip_all_tags( $post->post_content ) );
        if ( $word_est >= 800 ) {
            $score += 10; // Substantial content = worth optimizing
            $signals[] = $word_est . ' mots';
        } elseif ( $word_est >= 300 ) {
            $score += 6;
        } elseif ( $word_est > 0 ) {
            $score += 3;
            $signals[] = 'Contenu court (' . $word_est . ' mots)';
        }

        // ── Missing SEO basics = more room for improvement ──
        $has_meta_title = ! empty( get_post_meta( $post_id, '_hts_meta_title', true ) );
        $has_meta_desc  = ! empty( get_post_meta( $post_id, '_hts_meta_description', true ) );
        if ( ! $has_meta_title && ! $has_meta_desc ) {
            $score += 8;
        } elseif ( ! $has_meta_title || ! $has_meta_desc ) {
            $score += 4;
        }

        // ── Cocon membership = more strategic ──
        $cocon_id = (int) get_post_meta( $post_id, '_hts_cocon_id', true );
        if ( $cocon_id > 0 ) {
            $score += 5;
        }

        // ── Internal links ──
        $links_out = (int) get_post_meta( $post_id, '_hts_internal_links_out', true );
        if ( $links_out <= 1 ) {
            $score += 4;
        }

        // ── Recency bonus: recently published articles are more urgent ──
        $days_since = ( time() - strtotime( $post->post_date ) ) / DAY_IN_SECONDS;
        if ( $days_since < 30 ) {
            $score += 5;
        } elseif ( $days_since < 90 ) {
            $score += 3;
        }

        // ── Penalty: all actions disabled (content_refresh, enrich) = less urgent ──
        if ( ! $has_actionable && $action_count > 0 ) {
            $score -= 15;
        }

        $score = min( 100, max( 0, $score ) );

        // Label
        if ( $score >= 60 ) {
            $label = 'high';
        } elseif ( $score >= 35 ) {
            $label = 'medium';
        } else {
            $label = 'low';
        }

        return array(
            'score'   => $score,
            'signals' => $signals,
            'label'   => $label,
            'gsc'     => $has_gsc,
        );
    }

    /**
     * Sprint 6.3d — Inbox groupé par page avec score de priorité.
     *
     * Retourne les actions pending groupées par post_id, triées par score décroissant.
     * Chaque entrée contient : post info, priority score, liste d'actions.
     *
     * @since 2.5.8
     * @return array [ { post_id, post_title, post_url, edit_url, priority, actions[] } ]
     */
    public static function get_inbox_by_page() {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $raw = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE status = %s ORDER BY FIELD(priority, 'critical', 'high', 'medium', 'low'), created_at ASC",
            self::STATUS_PENDING
        ) );

        $agent_labels  = self::get_agent_labels();
        $action_labels = self::get_action_labels();

        // v2.5.12: Get current language for Polylang/WPML filtering
        $current_lang = null;
        if ( function_exists( 'pll_current_language' ) ) {
            $current_lang = pll_current_language( 'slug' );
        } elseif ( defined( 'ICL_LANGUAGE_CODE' ) ) {
            $current_lang = ICL_LANGUAGE_CODE;
        }

        // Group by post_id
        $by_page = array();
        foreach ( $raw as $action ) {
            $pid = (int) $action->post_id;

            // v2.5.12: Filter by current language (Polylang/WPML)
            if ( $current_lang && $pid > 0 ) {
                $post_lang = null;
                if ( function_exists( 'pll_get_post_language' ) ) {
                    $post_lang = pll_get_post_language( $pid, 'slug' );
                } elseif ( function_exists( 'wpml_get_language_information' ) ) {
                    $lang_info = wpml_get_language_information( null, $pid );
                    $post_lang = $lang_info['language_code'] ?? null;
                }
                if ( $post_lang && $post_lang !== $current_lang ) {
                    continue; // Skip actions for posts in other languages
                }
            }

            // Filter excluded pages (skip non-SEO pages)
            if ( $pid > 0 && self::is_excluded_page( $pid ) ) {
                // Auto-dismiss excluded page actions
                $wpdb->update( $table, array( 'status' => 'dismissed' ), array( 'id' => (int) $action->id ) );
                continue;
            }

            // Sprint 6.3d: Filter out non-actionable GEO proposals (only keep faq_lists)
            if ( $action->type === 'geo_optimize' ) {
                $action_data = json_decode( $action->data, true ) ?: array();
                $geo_criterion = $action_data['criterion'] ?? '';
                $geo_actionable = array( 'faq_lists' );
                if ( ! in_array( $geo_criterion, $geo_actionable, true ) ) {
                    $wpdb->update( $table, array( 'status' => 'dismissed' ), array( 'id' => (int) $action->id ) );
                    continue;
                }
            }

            $key = $pid > 0 ? $pid : 'no_page_' . $action->id;

            if ( ! isset( $by_page[ $key ] ) ) {
                $post_title = '';
                $post_url   = '';
                $edit_url   = '';
                if ( $pid > 0 ) {
                    $post_title = get_the_title( $pid ) ?: '(article #' . $pid . ')';
                    $post_url   = get_permalink( $pid );
                    $edit_url   = get_edit_post_link( $pid, 'raw' );
                }
                $by_page[ $key ] = array(
                    'post_id'    => $pid,
                    'post_title' => $post_title,
                    'post_url'   => $post_url,
                    'edit_url'   => $edit_url,
                    'actions'    => array(),
                );
            }

            // Enrich action
            $enriched = (array) $action;
            $data = json_decode( $action->data, true ) ?: array();
            $enriched['agent_label'] = $agent_labels[ $action->agent ] ?? ucfirst( $action->agent );
            $enriched['type_label']  = $action_labels[ $action->type ] ?? ucfirst( str_replace( '_', ' ', $action->type ) );
            $enriched['reason']      = $data['reason'] ?? '';
            $enriched['suggestion']  = $data['suggestion'] ?? ( $data['top_fix'] ?? '' );
            $enriched['time_ago']    = human_time_diff( ( new \DateTimeImmutable( $action->created_at, wp_timezone() ) )->getTimestamp() );
            $enriched['data_parsed'] = $data;

            $by_page[ $key ]['actions'][] = $enriched;
        }

        // Compute priority + sort
        foreach ( $by_page as $key => &$page ) {
            $page['priority'] = self::compute_page_priority( $page['post_id'], count( $page['actions'] ), $page['actions'] );
        }
        unset( $page );

        // Sort by score descending
        usort( $by_page, function( $a, $b ) {
            return $b['priority']['score'] - $a['priority']['score'];
        } );

        return array_values( $by_page );
    }

    /**
     * Vérifier le cooldown d'une page pour un agent.
     *
     * Empêche de re-modifier les metas d'une page trop tôt après une précédente modification.
     * Le délai est configurable dans les settings de l'agent (cooldown_days, défaut 28j).
     *
     * @since 2.4.8
     * @param string $agent   Agent ID.
     * @param int    $post_id Post ID.
     * @return true|string true si OK, sinon message de blocage.
     */
    public static function check_cooldown( $agent, $post_id ) {
        if ( $post_id <= 0 ) return true;

        $cooldown_days = (int) self::get_agent_guardrail( $agent, 'cooldown_days' );
        if ( $cooldown_days <= 0 ) return true;

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // Chercher la dernière action exécutée pour cet agent+post
        $last_executed = $wpdb->get_var( $wpdb->prepare(
            "SELECT resolved_at FROM {$table}
             WHERE agent = %s AND post_id = %d AND status IN ('done', 'executed')
             ORDER BY resolved_at DESC LIMIT 1",
            $agent, $post_id
        ) );

        if ( ! $last_executed ) return true;

        $diff_days = ( time() - strtotime( $last_executed ) ) / DAY_IN_SECONDS;
        if ( $diff_days < $cooldown_days ) {
            $remaining = (int) ceil( $cooldown_days - $diff_days );
            return "Page modifiée récemment par cet agent (il y a " . (int) floor( $diff_days ) . "j). "
                 . "Prochaine modification possible dans {$remaining} jours "
                 . "(cooldown : {$cooldown_days}j pour laisser Google indexer).";
        }

        return true;
    }

    /**
     * Vérifier qu'aucun autre agent n'a une action en cours sur cette page.
     *
     * Évite les conflits : si un agent content_refresh ou auto_write est pending/executing
     * sur la même page, on ne touche pas aux metas.
     *
     * @since 2.4.8
     * @param string $agent   Agent ID (l'agent qui veut agir).
     * @param int    $post_id Post ID.
     * @return true|string true si OK, sinon message de blocage.
     */
    public static function check_cross_agent_conflict( $agent, $post_id ) {
        if ( $post_id <= 0 ) return true;

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // Chercher des actions pending ou executing d'AUTRES agents sur cette page
        $conflict = $wpdb->get_row( $wpdb->prepare(
            "SELECT agent, type, status FROM {$table}
             WHERE post_id = %d AND agent != %s AND status IN ('pending', 'approved', 'executing')
             LIMIT 1",
            $post_id, $agent
        ) );

        if ( $conflict ) {
            $agent_labels = self::get_agent_labels();
            $label = $agent_labels[ $conflict->agent ] ?? ucfirst( $conflict->agent );
            return "Action en cours sur cette page par l'agent \"{$label}\" ({$conflict->type}). "
                 . "Modification reportée pour éviter un conflit.";
        }

        return true;
    }

    /**
     * Vérifier la limite hebdomadaire spécifique à l'agent meta (max_meta_per_week).
     *
     * Compte les actions meta (title + desc confondus) exécutées cette semaine.
     *
     * @since 2.4.8
     * @return true|string true si OK, sinon message de blocage.
     */
    public static function check_meta_weekly_limit() {
        $max = (int) self::get_agent_guardrail( 'meta', 'max_per_week' );
        if ( $max <= 0 ) return true; // 0 = pas de limite

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE agent = 'meta' AND status IN ('done', 'executed')
             AND resolved_at >= %s",
            gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) )
        ) );

        if ( $count >= $max ) {
            $settings_url = admin_url( 'admin.php?page=hts-settings#tab-agents' );
            return "Limite hebdomadaire de l'agent Meta atteinte ({$count}/{$max} optimisations). "
                 . "<a href=\"{$settings_url}\" target=\"_blank\">Modifier dans Réglages → Agents → Meta</a>";
        }

        return true;
    }

    /**
     * Calculer la recommandation de cadence meta auto en fonction du nombre de pages publiées.
     *
     * @since 2.4.8
     * @return array { 'recommended' => int, 'total_posts' => int, 'label' => string }
     */
    public static function get_meta_auto_recommendation() {
        $rec = self::get_all_recommendations();
        return array(
            'recommended' => $rec['meta']['max_per_week'],
            'total_posts' => $rec['_total_posts'],
            'label'       => "Recommandation : {$rec['meta']['max_per_week']}/semaine pour votre site ({$rec['_total_posts']} pages publiées)",
        );
    }

    /**
     * Schéma centralisé des garde-fous par agent.
     *
     * Chaque agent qui modifie du contenu a :
     * - max_per_week : limite hebdomadaire
     * - cooldown_days : délai entre 2 modifications sur la même page
     * - min_quality_score : score minimum requis (si applicable)
     *
     * NOTE : quand on crée un nouvel agent, ajouter sa ligne ici.
     *
     * @since 2.4.8
     * @return array
     */
    public static function get_guardrails_schema() {
        return array(
            'meta' => array(
                'label'       => 'Optimisation meta',
                'description' => 'Titres SEO et meta descriptions générés par l\'IA',
                'has_limit'   => true,
                'has_cooldown' => true,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Metas optimisées / semaine',        'type' => 'number', 'default' => 20, 'min' => 1,  'max' => 100 ),
                    array( 'key' => 'cooldown_days',     'label' => 'Cooldown entre 2 modifs (jours)',   'type' => 'number', 'default' => 28, 'min' => 7,  'max' => 90  ),
                ),
            ),
            'linking' => array(
                'label'       => 'Maillage interne',
                'description' => 'Liens internes ajoutés entre vos articles (cocon + orphelins)',
                'has_limit'   => true,
                'has_cooldown' => true,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Liens ajoutés / semaine',            'type' => 'number', 'default' => 10, 'min' => 1,  'max' => 100 ),
                    array( 'key' => 'cooldown_days',     'label' => 'Cooldown entre 2 modifs (jours)',   'type' => 'number', 'default' => 14, 'min' => 7,  'max' => 90  ),
                ),
            ),
            'fresh' => array(
                'label'       => 'Fraîcheur contenu',
                'description' => 'Réécriture d\'articles obsolètes (bientôt disponible)',
                'has_limit'   => true,
                'has_cooldown' => true,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Réécritures / semaine',              'type' => 'number', 'default' => 2,  'min' => 1,  'max' => 20  ),
                    array( 'key' => 'cooldown_days',     'label' => 'Cooldown entre 2 modifs (jours)',   'type' => 'number', 'default' => 60, 'min' => 14, 'max' => 180 ),
                ),
            ),
            'auto_write' => array(
                'label'       => 'Rédaction auto',
                'description' => 'Nouveaux articles rédigés automatiquement par l\'IA',
                'has_limit'   => true,
                'has_cooldown' => false,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Nouveaux articles / semaine',        'type' => 'number', 'default' => 3,  'min' => 1,  'max' => 20  ),
                ),
            ),
            'geo_score' => array(
                'label'       => 'Visibilité IA',
                'description' => 'Optimisations pour ChatGPT, Perplexity, Google AI : FAQ, scores GEO',
                'has_limit'   => true,
                'has_cooldown' => true,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Optimisations / semaine',            'type' => 'number', 'default' => 5,  'min' => 1,  'max' => 50  ),
                    array( 'key' => 'cooldown_days',     'label' => 'Cooldown entre 2 modifs (jours)',   'type' => 'number', 'default' => 28, 'min' => 7,  'max' => 90  ),
                ),
            ),
            'strategy' => array(
                'label'       => 'Stratégie SEO',
                'description' => 'Recommandations cannibalisations, fusions, redirections',
                'has_limit'   => true,
                'has_cooldown' => false,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Recommandations / semaine',          'type' => 'number', 'default' => 10, 'min' => 1,  'max' => 50  ),
                ),
            ),
            'image' => array(
                'label'       => 'Images IA',
                'description' => 'Images générées par Flux ou GPT Image pour vos articles',
                'has_limit'   => true,
                'has_cooldown' => false,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',      'label' => 'Images générées / semaine',           'type' => 'number', 'default' => 10, 'min' => 1,  'max' => 100 ),
                ),
            ),
            'content_quality' => array(
                'label'       => 'Qualité contenu',
                'description' => 'Images featured + in-content, ALT manquants, enrichissement contenu mince',
                'has_limit'   => true,
                'has_cooldown' => true,
                'has_quality'  => false,
                'fields'      => array(
                    array( 'key' => 'max_per_week',       'label' => 'Actions qualité / semaine',          'type' => 'number', 'default' => 10, 'min' => 1,  'max' => 50  ),
                    array( 'key' => 'cooldown_days',      'label' => 'Cooldown entre 2 modifs (jours)',   'type' => 'number', 'default' => 14, 'min' => 7,  'max' => 90  ),
                    array( 'key' => 'images_month_limit', 'label' => 'Images Inbox max / mois',           'type' => 'number', 'default' => 50, 'min' => 5,  'max' => 500 ),
                ),
            ),
        );
    }

    /**
     * Calculer les recommandations pour TOUS les agents basé sur la taille du site.
     *
     * @since 2.4.8
     * @return array { agent_id => { max_per_week, cooldown_days }, _total_posts => int }
     */
    public static function get_all_recommendations() {
        $total = (int) wp_count_posts( 'post' )->publish + (int) wp_count_posts( 'page' )->publish;

        // Grille de recommandations par taille de site
        if ( $total < 50 ) {
            $tier = 'small';
        } elseif ( $total < 200 ) {
            $tier = 'medium';
        } elseif ( $total < 500 ) {
            $tier = 'large';
        } else {
            $tier = 'xlarge';
        }

        $grid = array(
            //                       small  medium  large  xlarge
            'meta'       => array( 'max_per_week' => array( 5, 10, 20, 30 ), 'cooldown_days' => 28 ),
            'linking'    => array( 'max_per_week' => array( 5, 10, 15, 20 ), 'cooldown_days' => 14 ),
            'fresh'      => array( 'max_per_week' => array( 1, 2,  3,  5  ), 'cooldown_days' => 60 ),
            'auto_write' => array( 'max_per_week' => array( 1, 2,  3,  5  ), 'cooldown_days' => 0  ),
            'geo_score'  => array( 'max_per_week' => array( 3, 5,  10, 15 ), 'cooldown_days' => 28 ),
            'strategy'   => array( 'max_per_week' => array( 5, 10, 15, 20 ), 'cooldown_days' => 0  ),
            'image'      => array( 'max_per_week' => array( 5, 10, 15, 25 ), 'cooldown_days' => 0  ),
        );

        $tier_index = array( 'small' => 0, 'medium' => 1, 'large' => 2, 'xlarge' => 3 );
        $idx = $tier_index[ $tier ];

        $result = array( '_total_posts' => $total, '_tier' => $tier );
        foreach ( $grid as $agent => $values ) {
            $result[ $agent ] = array(
                'max_per_week'  => $values['max_per_week'][ $idx ],
                'cooldown_days' => $values['cooldown_days'],
            );
        }

        return $result;
    }

    /**
     * Récupérer une valeur de garde-fou par agent (centralisée).
     *
     * Priorité : option sauvegardée > défaut du schéma.
     *
     * @since 2.4.8
     * @param string $agent Agent ID.
     * @param string $key   Field key (max_per_week, cooldown_days, min_quality_score).
     * @return int|float
     */
    public static function get_agent_guardrail( $agent, $key ) {
        // Option sauvegardée
        $saved = get_option( 'hts_guardrails_agents', array() );
        if ( isset( $saved[ $agent ][ $key ] ) ) {
            return $saved[ $agent ][ $key ];
        }

        // Défaut du schéma
        $schema = self::get_guardrails_schema();
        if ( isset( $schema[ $agent ]['fields'] ) ) {
            foreach ( $schema[ $agent ]['fields'] as $field ) {
                if ( $field['key'] === $key ) {
                    return $field['default'];
                }
            }
        }

        // Fallback sécurisé par type de clé
        if ( $key === 'max_per_week' ) return 10;
        if ( $key === 'cooldown_days' ) return 28;
        return 0;
    }

    /**
     * Vérifier TOUS les garde-fous avant exécution auto d'une action.
     *
     * @since 2.4.2
     * @param string $agent   Agent ID.
     * @param string $type    Action type.
     * @param int    $post_id Post ID.
     * @return true|string true si OK, sinon message de blocage.
     */
    public static function check_all_guardrails( $agent, $type, $post_id = 0, $is_cocon = false, $is_orphan = false ) {
        if ( ! self::check_weekly_limit( $agent, $type ) ) {
            $max = (int) self::get_agent_guardrail( $agent, 'max_per_week' );
            $agent_labels = self::get_agent_labels();
            $label = $agent_labels[ $agent ] ?? ucfirst( $agent );
            $settings_url = admin_url( 'admin.php?page=hts-settings#tab-guardrails' );
            return "Limite hebdomadaire atteinte pour l'agent \"{$label}\" ({$max} actions/semaine). <a href=\"{$settings_url}\" target=\"_blank\">Modifier dans Réglages → Garde-fous</a>";
        }
        if ( ! self::check_budget() ) {
            $max_budget = (float) get_option( 'hts_workflow_max_budget_month', self::DEFAULT_MAX_BUDGET_PER_MONTH );
            $settings_url = admin_url( 'admin.php?page=hts-settings#tab-guardrails' );
            return "Budget API mensuel atteint ({$max_budget}$). <a href=\"{$settings_url}\" target=\"_blank\">Modifier dans Réglages → Garde-fous</a>";
        }
        if ( $post_id && ! self::check_traffic_threshold( $post_id ) ) {
            $threshold = (int) get_option( 'hts_workflow_traffic_threshold', self::DEFAULT_TRAFFIC_THRESHOLD );
            $clicks = (int) get_post_meta( $post_id, '_hts_gsc_clicks_30d', true );
            return "Page protégée : {$clicks} clics/30j (seuil : {$threshold}). Les pages performantes ne sont pas modifiées automatiquement.";
        }
        if ( $post_id && ! self::check_blacklist( $post_id ) ) {
            return 'Page dans la liste de pages protégées.';
        }
        $rewrite_types = array( 'content_refresh', 'enrich_thin_content', 'geo_optimize' );
        if ( in_array( $type, $rewrite_types, true ) && ! self::check_rewrite_limit() ) {
            $max_rewrites = (int) get_option( 'hts_workflow_max_rewrites_per_week', 2 );
            $settings_url = admin_url( 'admin.php?page=hts-settings#tab-guardrails' );
            return "Limite hebdomadaire de réécritures atteinte ({$max_rewrites}/semaine). <a href=\"{$settings_url}\" target=\"_blank\">Modifier dans Réglages → Garde-fous</a>";
        }
        if ( ! self::check_auto_hours() ) {
            return 'En dehors des horaires autorisés pour les modifications automatiques.';
        }

        // ── Sprint 6.2d : Unified budget check for auto-mode guard ──
        if ( $post_id && ( $type === 'add_internal_links' || $type === 'fix_orphan_links' ) ) {
            $current_out = self::recount_internal_links( $post_id );
            $auto_budget_full = false;
            if ( class_exists( 'HTS_Cocon_Commander' ) && method_exists( 'HTS_Cocon_Commander', 'get_link_budget_for_post' ) ) {
                $bi = HTS_Cocon_Commander::get_link_budget_for_post( $post_id );
                $auto_budget_full = ( $bi['budget'] <= 0 );
            } else {
                $max_links = (int) get_option( 'hts_max_links_per_page', 20 );
                $auto_budget_full = ( $current_out >= $max_links );
            }
            if ( $auto_budget_full ) {
                return sprintf( 'Cette page contient déjà %d liens internes (budget plein). Supprimez des liens existants avant d\'en ajouter.', $current_out );
            }
        }

        // ── Session M : Garde-fous spécifiques au mode auto ──

        // Cooldown : ne pas re-modifier une page trop tôt
        // Cocon linking & orphan rescue bypass cooldown (user approved manually)
        if ( $post_id && ! $is_cocon && ! $is_orphan ) {
            $cooldown_check = self::check_cooldown( $agent, $post_id );
            if ( $cooldown_check !== true ) {
                return $cooldown_check;
            }
        }

        // Conflit cross-agent : ne pas toucher une page en cours de traitement par un autre agent
        // Cocon linking & orphan rescue bypass cross-agent (manual Inbox approval = no conflict risk)
        if ( $post_id && ! $is_cocon && ! $is_orphan ) {
            $conflict_check = self::check_cross_agent_conflict( $agent, $post_id );
            if ( $conflict_check !== true ) {
                return $conflict_check;
            }
        }

        // Limite hebdo spécifique agent meta
        $meta_types = array( 'add_meta_title', 'add_meta_desc' );
        if ( $agent === 'meta' && in_array( $type, $meta_types, true ) ) {
            $meta_limit = self::check_meta_weekly_limit();
            if ( $meta_limit !== true ) {
                return $meta_limit;
            }
        }

        return true;
    }

    /**
     * Récupérer une valeur de garde-fou, avec fallback sur les settings agent puis les défauts.
     */
    private static function get_guardrail( $key, $agent = '' ) {
        // D'abord vérifier les settings de l'agent
        if ( $agent ) {
            $settings = self::get_agent_settings( $agent );
            if ( isset( $settings[ $key ] ) ) {
                return (int) $settings[ $key ];
            }
        }

        // Puis l'option globale
        $global = get_option( 'hts_workflow_' . $key, null );
        if ( $global !== null ) return (int) $global;

        // Puis le défaut
        $defaults = array(
            'max_actions_per_week' => self::DEFAULT_MAX_ACTIONS_PER_WEEK,
            'max_budget_per_month' => self::DEFAULT_MAX_BUDGET_PER_MONTH,
            'traffic_threshold'    => self::DEFAULT_TRAFFIC_THRESHOLD,
        );

        return $defaults[ $key ] ?? 10;
    }

    /* ═══════════════════════════════════════════════
     *  AJAX HANDLERS — INBOX
     * ═══════════════════════════════════════════════ */

    /**
     * AJAX : Lister les cartes Inbox.
     */
    public function ajax_inbox_list() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(1);

        self::ensure_tables();

        $cards = self::get_inbox_cards();

        wp_send_json_success( array(
            'cards' => $cards,
            'stats' => self::get_stats(),
        ) );
    }

    /**
     * AJAX : Approuver une action.
     */
    public function ajax_inbox_approve() {
        // v2.5.12: Buffer any PHP warnings/notices from image generation or other heavy tasks
        // Without this, PHP notices corrupt the JSON response and the JS can't parse it
        ob_start();

        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) { ob_end_clean(); wp_send_json_error( 'Permission refusée' ); }
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) { ob_end_clean(); wp_send_json_error( 'ID manquant' ); }

        // S16: Pre-approve checks — variant swap + hreflang guard
        $meta_types_s16 = array( 'add_meta_title', 'add_meta_desc', 'optimize_meta_title', 'optimize_meta_desc', 'optimize_meta_both' );
        $variant_idx = isset( $_POST['variant_index'] ) ? (int) $_POST['variant_index'] : 0;
        $pre_action  = self::get_action( $id );

        if ( $pre_action && $pre_action->status === self::STATUS_PENDING && in_array( $pre_action->type, $meta_types_s16, true ) ) {
            $act_data = json_decode( $pre_action->data, true ) ?: array();

            // ── Swap variant if CEO chose an alternative ──
            if ( $variant_idx > 0 && ! empty( $act_data['_generated_variants'][ $variant_idx ] ) ) {
                $chosen = $act_data['_generated_variants'][ $variant_idx ];
                $act_data['_generated_variants'][ $variant_idx ] = $act_data['_generated_variants'][0];
                $act_data['_generated_variants'][0] = $chosen;
                $is_t = in_array( $pre_action->type, array( 'add_meta_title', 'optimize_meta_title', 'optimize_meta_both' ), true );
                $is_d = in_array( $pre_action->type, array( 'add_meta_desc', 'optimize_meta_desc', 'optimize_meta_both' ), true );
                if ( $is_t && ! empty( $chosen['title'] ) )       $act_data['suggestion'] = $chosen['title'];
                if ( $is_d && ! empty( $chosen['description'] ) ) $act_data['suggestion_desc'] = $chosen['description'];
                global $wpdb;
                $wpdb->update(
                    $wpdb->prefix . self::ACTIONS_TABLE,
                    array( 'data' => wp_json_encode( $act_data ) ),
                    array( 'id' => $id )
                );
                // Refresh act_data after write
                $best_var = $chosen;
            } else {
                $best_var = $act_data['_generated_variants'][0] ?? array();
            }

            // ── Hreflang guard: block if language mismatch ──
            if ( function_exists( 'pll_get_post_language' ) ) {
                $post_lang = pll_get_post_language( (int) $pre_action->post_id, 'slug' );
                $gen_lang  = $best_var['lang'] ?? '';
                if ( $post_lang && $gen_lang && $post_lang !== $gen_lang ) {
                    ob_end_clean();
                    wp_send_json_error( 'Langue incompatible : la variante est en ' . strtoupper( $gen_lang ) . ' mais l\'article est en ' . strtoupper( $post_lang ) . '. Régénérez les variantes.' );
                }
            }
        }

        // Sprint 5.3: Extend timeout for LLM-heavy actions (FAQ, content_refresh, generate_article)
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 120 );
        }

        $ok = self::approve( $id );
        if ( $ok ) {
            // Recharger pour avoir le statut final + log d'exécution
            $updated  = self::get_action( $id );
            $response = array(
                'action_id' => $id,
                'status'    => $updated ? $updated->status : 'approved',
                'log'       => $updated ? ( $updated->execution_log ?? '' ) : '',
            );
            if ( $updated && (int) $updated->post_id > 0 ) {
                $response['post_title'] = get_the_title( (int) $updated->post_id );
                $response['post_url']   = get_permalink( (int) $updated->post_id );
                $response['edit_url']   = get_edit_post_link( (int) $updated->post_id, 'raw' );
            }
            // v2.4.17: Parse linking context from execution_log for rich UI feedback
            if ( $updated && $updated->type === 'add_internal_links' && ! empty( $updated->execution_log ) ) {
                $exec_data = json_decode( $updated->data, true ) ?: array();
                $response['link_context'] = array(
                    'anchor'       => $exec_data['anchor_text'] ?? '',
                    'target_title' => $exec_data['target_title'] ?? '',
                    'target_url'   => ( $exec_data['target_id'] ?? 0 ) ? get_permalink( (int) $exec_data['target_id'] ) : '',
                );
            }
            // Sprint 4.3 + 5.3: Include before/after for meta actions in response
            $meta_types = array( 'add_meta_title', 'add_meta_desc', 'optimize_meta_title', 'optimize_meta_desc', 'optimize_meta_both' );

            // v2.5.12: Include thumbnail preview for image actions
            if ( $updated && $updated->type === 'add_featured_image' && $updated->status === 'done' && (int) $updated->post_id > 0 ) {
                $thumb_id = get_post_thumbnail_id( (int) $updated->post_id );
                if ( $thumb_id ) {
                    $thumb_src = wp_get_attachment_image_src( $thumb_id, 'medium' );
                    if ( $thumb_src ) {
                        $response['thumbnail_url'] = $thumb_src[0];
                    }
                }
            }
            if ( $updated && in_array( $updated->type, $meta_types, true ) && $updated->status === 'done' && (int) $updated->post_id > 0 ) {
                $pid = (int) $updated->post_id;
                $backup_json = get_post_meta( $pid, '_hts_action_backup_' . $id, true );
                $backup_data = $backup_json ? json_decode( $backup_json, true ) : array();
                $is_title = in_array( $updated->type, array( 'add_meta_title', 'optimize_meta_title' ), true );
                $is_desc  = in_array( $updated->type, array( 'add_meta_desc', 'optimize_meta_desc' ), true );
                $is_both  = $updated->type === 'optimize_meta_both';
                if ( $is_title || $is_both ) {
                    $old_t = $backup_data['meta_title'] ?? '';
                    $new_t = get_post_meta( $pid, '_hts_meta_title', true );
                    $response['meta_result'] = array(
                        'field'  => 'Meta Title',
                        'before' => $old_t ?: '— aucun (auto WordPress)',
                        'after'  => $new_t ?: '(non généré)',
                    );
                }
                if ( $is_desc || $is_both ) {
                    $old_d = $backup_data['meta_description'] ?? '';
                    $new_d = get_post_meta( $pid, '_hts_meta_description', true );
                    $desc_result = array(
                        'field'  => 'Meta Description',
                        'before' => $old_d ?: '— aucune (auto WordPress)',
                        'after'  => mb_substr( $new_d ?: '(non générée)', 0, 160 ),
                    );
                    if ( $is_both && isset( $response['meta_result'] ) ) {
                        // Combine both results
                        $response['meta_result']['field'] = 'Metas';
                        $response['meta_result']['after'] .= ' | Desc: ' . $desc_result['after'];
                    } else {
                        $response['meta_result'] = $desc_result;
                    }
                }
            }
            ob_end_clean();
            wp_send_json_success( $response );
        } else {
            ob_end_clean();
            wp_send_json_error( 'Impossible d\'approuver cette action' );
        }
    }

    /**
     * AJAX : Rejeter une action.
     */
    public function ajax_inbox_reject() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        $ok = self::reject( $id );
        if ( $ok ) {
            wp_send_json_success( array( 'action_id' => $id, 'status' => 'rejected' ) );
        } else {
            wp_send_json_error( 'Impossible de rejeter cette action' );
        }
    }

    /**
     * AJAX : Batch approve/reject.
     */
    public function ajax_inbox_batch() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $ids    = array_map( 'intval', (array) ( $_POST['ids'] ?? array() ) );
        $action = sanitize_key( $_POST['batch_action'] ?? '' );

        if ( empty( $ids ) || ! in_array( $action, array( 'approve', 'reject', 'dismiss' ), true ) ) {
            wp_send_json_error( 'Paramètres invalides' );
        }

        // Auto-detect limited server → batch mode
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time <= 60 && count( $ids ) > 5 && class_exists( 'HTS_Job_Runner' ) ) {
            wp_send_json_error( array( 'message' => 'use_batch', 'batch_init' => 'hts_inbox_batch_init', 'batch_step' => 'hts_inbox_batch_step' ) );
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 );

        $count = 0;
        if ( $action === 'approve' ) {
            $count = self::batch_approve( $ids );
        } elseif ( $action === 'reject' ) {
            $count = self::batch_reject( $ids );
        } elseif ( $action === 'dismiss' ) {
            foreach ( $ids as $id ) { if ( self::dismiss( $id ) ) $count++; }
        }

        wp_send_json_success( array( 'processed' => $count, 'action' => $action ) );
    }

    public function ajax_inbox_batch_init() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $ids    = array_map( 'intval', (array) ( $_POST['ids'] ?? array() ) );
        $action = sanitize_key( $_POST['batch_action'] ?? '' );
        if ( empty( $ids ) ) wp_send_json_error();
        $job = HTS_Job_Runner::create( 'inbox_batch', array( 'ids' => $ids, 'batch_action' => $action ), count( $ids ) );
        wp_send_json_success( array( 'job_id' => $job['job_id'], 'total' => count( $ids ) ) );
    }

    public function ajax_inbox_batch_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        $job = HTS_Job_Runner::load( $job_id );
        if ( ! $job ) wp_send_json_error( array( 'message' => 'Job introuvable' ) );

        $start     = microtime( true );
        $ids       = $job['params']['ids'] ?? array();
        $action    = $job['params']['batch_action'] ?? 'dismiss';
        $processed = (int) $job['processed'];
        $count     = (int) ( $job['result']['count'] ?? 0 );
        $batch     = array_slice( $ids, $processed, 5 );

        foreach ( $batch as $id ) {
            if ( ! HTS_Job_Runner::has_time( $start ) ) break;
            if ( $action === 'approve' ) { if ( self::approve( $id ) ) $count++; }
            elseif ( $action === 'reject' ) { if ( self::reject( $id ) ) $count++; }
            elseif ( $action === 'dismiss' ) { if ( self::dismiss( $id ) ) $count++; }
            $processed++;
        }

        $done = ( $processed >= count( $ids ) );
        if ( $done ) {
            HTS_Job_Runner::complete( $job_id, array( 'count' => $count, 'action' => $action ) );
            wp_send_json_success( array( 'status' => 'done', 'processed' => $count, 'action' => $action, 'total' => count( $ids ), 'progress' => 100 ) );
        }
        HTS_Job_Runner::update( $job_id, array( 'processed' => $processed, 'step' => $job['step'] + 1, 'result' => array( 'count' => $count ) ) );
        wp_send_json_success( array( 'status' => 'running', 'processed' => $processed, 'total' => count( $ids ), 'progress' => HTS_Job_Runner::progress_pct( $job ), 'message' => $action . '... ' . $processed . '/' . count( $ids ) ) );
    }

    /**
     * AJAX : Dismiss une action (ignorer sans rejeter).
     *
     * @since 2.1.0
     */
    public function ajax_inbox_dismiss() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        // Récupérer l'action avant dismiss pour checker le linking_paused après
        $action = self::get_action( $id );
        $ok = self::dismiss( $id );
        if ( $ok ) {
            $response = array( 'action_id' => $id, 'status' => 'dismissed' );
            // D3: toast si 3 dismiss → pause 30j
            if ( $action && $action->agent === 'linking' ) {
                $dc = (int) get_post_meta( (int) $action->post_id, 'hts_linking_dismiss_count_' . (int) $action->post_id, true );
                if ( $dc >= 3 ) {
                    $response['linking_paused'] = true;
                    $response['pause_message'] = 'Compris ! Hack The SEO ne proposera plus de liens sur cet article pendant 30 jours.';
                }
            }
            wp_send_json_success( $response );
        } else {
            wp_send_json_error( 'Impossible d\'ignorer cette action' );
        }
    }

    /**
     * AJAX : Exécuter manuellement une action approuvée.
     *
     * @since 2.1.0
     */
    public function ajax_inbox_execute() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        $action = self::get_action( $id );
        if ( ! $action ) {
            wp_send_json_error( 'Action introuvable' );
        }

        // Approuver d'abord si pending, puis exécuter
        if ( $action->status === self::STATUS_PENDING ) {
            self::approve( $id );
        } elseif ( $action->status === self::STATUS_APPROVED ) {
            self::execute( $id );
        } else {
            wp_send_json_error( 'Cette action ne peut pas être exécutée (statut : ' . esc_html( $action->status ) . ')' );
        }

        // Recharger pour avoir le statut final
        $updated = self::get_action( $id );
        wp_send_json_success( array(
            'action_id' => $id,
            'status'    => $updated ? $updated->status : 'unknown',
            'log'       => $updated ? $updated->execution_log : '',
        ) );
    }

    /**
     * AJAX : Stats du workflow.
     */
    public function ajax_workflow_stats() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(1);

        wp_send_json_success( self::get_stats() );
    }

    /**
     * AJAX : Preview d'une action avant exécution.
     * @since 2.3.1
     */
    public function ajax_inbox_preview() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(1);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        // ── Session L : Générer les variantes IA au moment du preview pour meta ──
        $meta_variant_types = array( 'add_meta_title', 'add_meta_desc', 'optimize_meta_title', 'optimize_meta_desc', 'optimize_meta_both' );
        $action = self::get_action( $id );
        if ( $action && $action->status === 'pending' && in_array( $action->type, $meta_variant_types, true ) ) {
            $data = json_decode( $action->data, true ) ?: array();
            // Ne régénérer que si pas déjà fait (cache dans l'action data)
            if ( empty( $data['_generated_variants'] ) ) {

                // Session L fix : vérifier si l'autre action du même post a déjà des variantes
                $sibling_variants = self::get_sibling_variants( $id, $action );

                if ( ! empty( $sibling_variants ) ) {
                    $variants_list = $sibling_variants;
                } else {
                    $variants_result = self::generate_meta_variants_for_preview( (int) $action->post_id );
                    $variants_list = ! empty( $variants_result['variants'] ) ? $variants_result['variants'] : array();
                }

                if ( ! empty( $variants_list ) ) {
                    // S16: Tag each variant with the post language for hreflang guard
                    $post_lang = function_exists( 'pll_get_post_language' ) ? pll_get_post_language( (int) $action->post_id, 'slug' ) : '';
                    if ( $post_lang ) {
                        foreach ( $variants_list as &$_vr ) {
                            if ( empty( $_vr['lang'] ) ) $_vr['lang'] = $post_lang;
                        }
                        unset( $_vr );
                    }
                    $data['_generated_variants'] = $variants_list;
                    $best = $variants_list[0];
                    $is_title_type = in_array( $action->type, array( 'add_meta_title', 'optimize_meta_title', 'optimize_meta_both' ), true );
                    $is_desc_type  = in_array( $action->type, array( 'add_meta_desc', 'optimize_meta_desc', 'optimize_meta_both' ), true );
                    if ( $is_title_type && ! empty( $best['title'] ) ) {
                        $data['suggestion'] = $best['title'];
                        $data['_all_titles'] = array_map( function( $v ) { return $v['title'] ?? ''; }, $variants_list );
                    }
                    if ( $is_desc_type && ! empty( $best['description'] ) ) {
                        if ( ! $is_title_type ) $data['suggestion'] = $best['description'];
                        $data['suggestion_desc'] = $best['description'];
                        $data['_all_descriptions'] = array_map( function( $v ) { return $v['description'] ?? ''; }, $variants_list );
                    }
                    global $wpdb;
                    $wpdb->update(
                        $wpdb->prefix . self::ACTIONS_TABLE,
                        array( 'data' => wp_json_encode( $data ) ),
                        array( 'id' => $id )
                    );
                }
            }
        }

        $preview = self::get_preview( $id );
        if ( isset( $preview['error'] ) ) wp_send_json_error( $preview['error'] );

        // Session J : Ajouter le diff structuré
        $diff = self::get_action_diff( $id );
        if ( ! isset( $diff['error'] ) ) {
            $preview['diff'] = $diff;
        }

        // Session L : Ajouter les variantes alternatives si disponibles
        // Recharger l'action depuis la BDD car les data ont pu être mises à jour par la génération
        $fresh_action = self::get_action( $id );
        if ( $fresh_action && in_array( $fresh_action->type, $meta_variant_types, true ) ) {
            $fresh_data = json_decode( $fresh_action->data, true ) ?: array();
            if ( ! empty( $fresh_data['_generated_variants'] ) ) {
                $preview['variants'] = $fresh_data['_generated_variants'];
            }
            // Compteur de régénérations
            $max_regens = 2;
            $regen_count = (int) ( $fresh_data['_regen_count'] ?? 0 );
            $preview['regen_left'] = $max_regens - $regen_count;
        }

        wp_send_json_success( $preview );
    }

    /**
     * Générer les variantes meta via IA pour le preview Inbox.
     *
     * @since 2.4.8
     * @param int $post_id
     * @return array
     */
    private static function generate_meta_variants_for_preview( $post_id ) {
        if ( ! class_exists( 'HTS_Meta_Score' ) ) return array();
        if ( ! get_post( $post_id ) ) return array();

        $meta_score = new HTS_Meta_Score();
        if ( ! method_exists( $meta_score, 'generate_variants' ) ) return array();

        // Skip rate limit pour les previews Inbox
        return $meta_score->generate_variants( $post_id, true );
    }

    /**
     * Chercher les variantes déjà générées dans l'action sœur (même post, autre type meta).
     *
     * Ex: si on preview add_meta_desc et que add_meta_title a déjà été previewé,
     * on récupère les mêmes variantes sans refaire un appel IA.
     *
     * @since 2.4.8
     * @param int    $current_action_id
     * @param object $current_action
     * @return array  Variantes ou tableau vide
     */
    private static function get_sibling_variants( $current_action_id, $current_action ) {
        $sibling_type = $current_action->type === 'add_meta_title' ? 'add_meta_desc' : 'add_meta_title';

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        $sibling = $wpdb->get_row( $wpdb->prepare(
            "SELECT data FROM {$table} WHERE agent = %s AND type = %s AND post_id = %d AND status = 'pending' AND id != %d LIMIT 1",
            $current_action->agent, $sibling_type, (int) $current_action->post_id, $current_action_id
        ) );

        if ( $sibling ) {
            $sibling_data = json_decode( $sibling->data, true ) ?: array();
            if ( ! empty( $sibling_data['_generated_variants'] ) ) {
                return $sibling_data['_generated_variants'];
            }
        }

        return array();
    }

    /**
     * AJAX : Historique des actions terminées (done/failed/rollbacked).
     * @since 2.3.1
     */
    public function ajax_inbox_history() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(1);

        self::ensure_tables();

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        $limit = min( 50, max( 5, (int) ( $_POST['limit'] ?? 20 ) ) );

        // v2.4.17: Auto-fix actions stuck in "executing" for >5 minutes (bug pre-2.4.17)
        $wpdb->query(
            "UPDATE {$table} SET status = 'failed', execution_log = 'Exécution interrompue (corrigé en v2.4.17)' WHERE status = 'executing' AND resolved_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)"
        );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE status IN ('done', 'failed', 'blocked', 'rollbacked') ORDER BY resolved_at DESC LIMIT %d",
            $limit
        ) );

        $agent_labels  = self::get_agent_labels();
        $action_labels = self::get_action_labels();
        $history = array();

        foreach ( $rows as $row ) {
            $post_title = (int) $row->post_id > 0 ? get_the_title( (int) $row->post_id ) : '';
            $has_backup = ! empty( get_post_meta( (int) $row->post_id, '_hts_action_backup_' . $row->id, true ) );

            // Session M : Ajouter les données d'impact (score avant/après)
            $impact_raw    = get_post_meta( (int) $row->post_id, '_hts_impact_' . $row->id, true );
            $impact        = $impact_raw ? json_decode( $impact_raw, true ) : null;
            $score_before  = $impact && isset( $impact['kpi_before']['score'] ) ? (int) $impact['kpi_before']['score'] : null;
            $score_after   = null;
            $impact_period = null;
            if ( $impact ) {
                if ( ! empty( $impact['kpi_30d'] ) ) {
                    $score_after   = (int) $impact['kpi_30d']['score'];
                    $impact_period = '30j';
                } elseif ( ! empty( $impact['kpi_7d'] ) ) {
                    $score_after   = (int) $impact['kpi_7d']['score'];
                    $impact_period = '7j';
                }
            }

            $history[] = array(
                'id'            => (int) $row->id,
                'agent_label'   => $agent_labels[ $row->agent ] ?? ucfirst( $row->agent ),
                'type_label'    => $action_labels[ $row->type ] ?? ucfirst( str_replace( '_', ' ', $row->type ) ),
                'post_id'       => (int) $row->post_id,
                'post_title'    => $post_title,
                'post_url'      => (int) $row->post_id > 0 ? get_permalink( (int) $row->post_id ) : '',
                'edit_url'      => (int) $row->post_id > 0 ? get_edit_post_link( (int) $row->post_id, 'raw' ) : '',
                'status'        => $row->status,
                'execution_log' => $row->execution_log ?? '',
                'time_ago'      => $row->resolved_at ? human_time_diff( ( new \DateTimeImmutable( $row->resolved_at, wp_timezone() ) )->getTimestamp() ) : '',
                'can_rollback'  => $row->status === 'done' && $has_backup,
                'is_auto'       => (int) ( $row->resolved_by ?? 1 ) === 0,
                'score_before'  => $score_before,
                'score_after'   => $score_after,
                'score_delta'   => ( $score_before !== null && $score_after !== null ) ? $score_after - $score_before : null,
                'impact_period' => $impact_period,
            );
        }

        wp_send_json_success( array( 'history' => $history ) );
    }

    /**
     * AJAX : Rollback une action exécutée.
     * @since 2.3.1
     */
    /**
     * AJAX : Réessayer une action bloquée par garde-fou → remet en pending.
     */
    /**
     * AJAX : Purger toutes les propositions linking pending.
     * @since 2.4.9
     */
    public function ajax_purge_linking() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        self::ensure_tables();

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        $deleted = (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE agent = %s AND status = %s",
            'linking', self::STATUS_PENDING
        ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Purge linking : {$deleted} proposition(s) supprimée(s)", 'info', 'workflow' );
        }

        wp_send_json_success( array( 'deleted' => $deleted ) );
    }

    /**
     * Sprint 6.3d — Full Audit : purge tout + rescan complet.
     *
     * Supprime TOUTES les propositions pending/dismissed/rejected,
     * puis lance un scan complet comme si c'était la première fois.
     * Le client repart de zéro avec un audit frais.
     *
     * @since 2.5.8
     */
    public function ajax_full_audit() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        // Auto-detect limited server
        $max_time = (int) ini_get( 'max_execution_time' );
        if ( $max_time > 0 && $max_time <= 60 && class_exists( 'HTS_Job_Runner' ) ) {
            wp_send_json_error( array( 'message' => 'use_batch', 'batch_init' => 'hts_full_audit_init', 'batch_step' => 'hts_full_audit_step' ) );
        }

        if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 180 );

        self::ensure_tables();

        // FIX 2: Reset circuit breaker before audit — previous failures must not block sync
        delete_transient( 'hts_circuit_breaker' );

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // ── 1. Purger les propositions non-exécutées ──
        // S16: Preserve cocon-aware linking proposals — 2-step for performance (no LIKE on TEXT column)
        // S16: Don't purge 'rejected' — the CEO explicitly said no
        // Step A: collect IDs of cocon proposals to keep (indexed agent column = fast)
        $cocon_ids = $wpdb->get_col(
            "SELECT id FROM {$table} WHERE status IN ('pending','blocked') AND agent = 'linking' AND type = 'add_internal_links'"
        );
        $keep_ids = array();
        if ( ! empty( $cocon_ids ) ) {
            // Step B: among those, filter by source_cocon (small result set, LIKE is fine)
            $ids_in = implode( ',', array_map( 'intval', $cocon_ids ) );
            $keep_ids = $wpdb->get_col(
                "SELECT id FROM {$table} WHERE id IN ({$ids_in}) AND data LIKE '%\"source_cocon\"%'"
            );
        }
        // Step C: delete all pending/blocked EXCEPT the preserved cocon IDs
        if ( ! empty( $keep_ids ) ) {
            $keep_in = implode( ',', array_map( 'intval', $keep_ids ) );
            $purged = (int) $wpdb->query(
                "DELETE FROM {$table} WHERE status IN ('pending','blocked') AND id NOT IN ({$keep_in})"
            );
        } else {
            $purged = (int) $wpdb->query(
                "DELETE FROM {$table} WHERE status IN ('pending','blocked')"
            );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Audit complet : {$purged} anciennes propositions purgées", 'info', 'workflow' );
        }

        // ── 2. Scanner tout le site ──
        $result = self::scan_proposals( false );

        $stats = self::get_stats();

        wp_send_json_success( array(
            'purged'   => $purged,
            'scanned'  => $result['scanned'] ?? 0,
            'proposed' => $result['proposed'] ?? 0,
            'pending'  => (int) ( $stats['pending'] ?? 0 ),
        ) );
    }

    /**
     * v2.4.17: Purge ALL workflow history (done, failed, blocked, executing, rollbacked).
     * Also cleans up associated backup meta and impact data.
     * Use with caution — this is a full reset.
     */
    public function ajax_full_audit_init() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $job = HTS_Job_Runner::create( 'full_audit', array(), 2 );
        wp_send_json_success( array( 'job_id' => $job['job_id'], 'total' => 2 ) );
    }

    public function ajax_full_audit_step() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        $job = HTS_Job_Runner::load( $job_id );
        if ( ! $job ) wp_send_json_error( array( 'message' => 'Job introuvable' ) );

        $step = (int) $job['step'];

        if ( $step === 0 ) {
            // Phase 1: Purge old proposals
            self::ensure_tables();
            delete_transient( 'hts_circuit_breaker' );
            global $wpdb;
            $table = $wpdb->prefix . self::ACTIONS_TABLE;
            $purged = (int) $wpdb->query( "DELETE FROM {$table} WHERE status IN ('pending','blocked')" );
            HTS_Job_Runner::update( $job_id, array( 'step' => 1, 'processed' => 1, 'result' => array( 'purged' => $purged ) ) );
            wp_send_json_success( array( 'status' => 'running', 'step' => 1, 'total' => 2, 'processed' => 1, 'progress' => 50, 'message' => $purged . ' propositions purgées. Scan en cours...' ) );
        }

        if ( $step === 1 ) {
            // Phase 2: Scan proposals
            $result = self::scan_proposals( false );
            $stats = self::get_stats();
            $final = array_merge( $job['result'] ?? array(), array(
                'scanned' => $result['scanned'] ?? 0, 'proposed' => $result['proposed'] ?? 0,
                'pending' => (int) ( $stats['pending'] ?? 0 ),
            ) );
            HTS_Job_Runner::complete( $job_id, $final );
            wp_send_json_success( array( 'status' => 'done', 'step' => 2, 'total' => 2, 'processed' => 2, 'progress' => 100, 'result' => $final ) );
        }
    }

    public function ajax_purge_history() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        self::ensure_tables();

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // Get IDs of actions to purge (for meta cleanup)
        $purge_statuses = array( 'done', 'failed', 'blocked', 'executing', 'rollbacked' );
        $placeholders   = implode( ',', array_fill( 0, count( $purge_statuses ), '%s' ) );
        $action_rows    = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, post_id FROM {$table} WHERE status IN ({$placeholders})",
                $purge_statuses
            )
        );

        // Clean up backup meta and impact meta
        $cleaned_meta = 0;
        foreach ( $action_rows as $row ) {
            $pid = (int) $row->post_id;
            $aid = (int) $row->id;
            if ( $pid > 0 ) {
                delete_post_meta( $pid, '_hts_action_backup_' . $aid );
                // Sprint 6.3c: aussi nettoyer les metas builder séparées
                delete_post_meta( $pid, '_hts_action_backup_' . $aid . '_elementor_data' );
                delete_post_meta( $pid, '_hts_action_backup_' . $aid . '_fl_builder_data' );
                delete_post_meta( $pid, '_hts_action_backup_' . $aid . '_bricks_page_content_2' );
                delete_post_meta( $pid, '_hts_impact_' . $aid );
                $cleaned_meta++;
            }
        }

        // Delete all resolved actions
        $deleted = (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE status IN ({$placeholders})",
                $purge_statuses
            )
        );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Purge historique : {$deleted} action(s) supprimée(s), {$cleaned_meta} meta nettoyées", 'info', 'workflow' );
        }

        wp_send_json_success( array( 'deleted' => $deleted, 'meta_cleaned' => $cleaned_meta ) );
    }

    public function ajax_inbox_retry() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        global $wpdb;
        $table  = $wpdb->prefix . self::ACTIONS_TABLE;
        $action = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );

        if ( ! $action || ! in_array( $action->status, array( self::STATUS_BLOCKED, self::STATUS_FAILED ), true ) ) {
            wp_send_json_error( 'Action introuvable ou non éligible au retry (statut: ' . ( $action->status ?? '?' ) . ')' );
        }

        $wpdb->update( $table,
            array(
                'status'        => self::STATUS_PENDING,
                'resolved_at'   => null,
                'execution_log' => '',
            ),
            array( 'id' => $id )
        );

        wp_send_json_success( array( 'message' => 'Action remise en file d\'attente' ) );
    }

    public function ajax_refresh_anchor() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier(2);

        $action_id = absint( $_POST['action_id'] ?? 0 );
        if ( ! $action_id ) wp_send_json_error( 'ID requis.' );

        global $wpdb;
        $table  = $wpdb->prefix . self::ACTIONS_TABLE;
        $action = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $action_id ) );
        if ( ! $action ) wp_send_json_error( 'Action introuvable.' );

        $data = json_decode( $action->data, true );
        if ( ! is_array( $data ) ) wp_send_json_error( 'Données invalides.' );

        $post = get_post( $action->post_id );
        if ( ! $post ) wp_send_json_error( 'Article introuvable.' );

        $target_id = (int) ( $data['target_id'] ?? 0 );
        $target_keyword = get_post_meta( $target_id, '_hts_focus_keyword', true ) ?: get_the_title( $target_id );

        $content = html_entity_decode( wp_strip_all_tags( $post->post_content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $search_words = array_filter( preg_split( '/[\s,\-:]+/', mb_strtolower( $target_keyword ) ), function( $w ) { return mb_strlen( $w ) >= 3; } );
        if ( empty( $search_words ) ) wp_send_json_error( 'Aucun mot-clé exploitable.' );

        $sentences = preg_split( '/(?<=[.!?])\s+/', $content, -1, PREG_SPLIT_NO_EMPTY );
        $best = null;
        $best_score = 0;

        foreach ( $sentences as $sent ) {
            $words = preg_split( '/\s+/', trim( $sent ) );
            for ( $len = 3; $len <= min( 6, count( $words ) ); $len++ ) {
                for ( $s = 0; $s <= count( $words ) - $len; $s++ ) {
                    $seg = implode( ' ', array_slice( $words, $s, $len ) );
                    $seg = trim( preg_replace( '/[.,;:!?]+$/', '', $seg ) );
                    if ( mb_strlen( $seg ) < 10 || mb_strlen( $seg ) > 80 ) continue;
                    $matches = 0;
                    foreach ( $search_words as $sw ) {
                        if ( mb_strpos( mb_strtolower( $seg ), $sw ) !== false ) $matches++;
                    }
                    if ( ! $matches ) continue;
                    if ( mb_strpos( $post->post_content, $seg ) === false ) continue;
                    if ( preg_match( '/<a[^>]*>[^<]*' . preg_quote( $seg, '/' ) . '/si', $post->post_content ) ) continue;
                    $sc = $matches * 20 + ( $len >= 3 && $len <= 5 ? 15 : 0 );
                    if ( $sc > $best_score ) { $best_score = $sc; $best = $seg; }
                }
            }
        }

        if ( ! $best ) {
            wp_send_json_error( 'Aucun passage pertinent trouvé dans le contenu actuel. Ajoutez du contenu sur ce thème puis relancez.' );
        }

        $data['anchor_text']   = $best;
        $data['anchor_type']   = 'extract';
        $data['anchor_method'] = 'php';
        unset( $data['anchor_bridge'] );

        $wpdb->update( $table, array(
            'data'   => wp_json_encode( $data ),
            'status' => self::STATUS_PENDING,
        ), array( 'id' => $action_id ) );

        wp_send_json_success( array( 'new_anchor' => $best, 'action_id' => $action_id ) );
    }

    public function ajax_inbox_rollback() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        $result = self::rollback( $id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( array(
            'action_id' => $id,
            'status'    => 'rollbacked',
            'message'   => 'Restauration effectuée avec succès',
        ) );
    }

    /**
     * AJAX : Rollback + remettre en pending (pour re-tester).
     * @since 2.5.10
     */
    public function ajax_inbox_rollback_retry() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        // Step 1: rollback content
        $result = self::rollback( $id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( 'Rollback échoué : ' . $result->get_error_message() );
        }

        // Step 2: reset status to pending
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        $wpdb->update( $table,
            array(
                'status'        => self::STATUS_PENDING,
                'resolved_at'   => null,
                'execution_log' => '',
            ),
            array( 'id' => $id )
        );

        wp_send_json_success( array(
            'action_id' => $id,
            'status'    => 'pending',
            'message'   => 'Contenu restauré et action remise dans l\'Inbox',
        ) );
    }

    /**
     * AJAX : Aperçu du rollback (diff inversé) — Session J.
     * @since 2.4.6
     */
    /**
     * AJAX : Régénérer les variantes IA pour une action meta (Session L).
     *
     * Efface le cache des variantes et relance la génération.
     * Utile quand le client a changé la langue ou veut de nouvelles propositions.
     *
     * @since 2.4.8
     */
    public function ajax_inbox_regen_variants() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $action_id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $action_id ) wp_send_json_error( 'ID manquant' );

        $action = self::get_action( $action_id );
        if ( ! $action || $action->status !== 'pending' ) {
            wp_send_json_error( 'Action introuvable ou déjà traitée' );
        }

        if ( ! in_array( $action->type, array( 'add_meta_title', 'add_meta_desc' ), true ) ) {
            wp_send_json_error( 'Type d\'action non supporté pour la régénération' );
        }

        $data = json_decode( $action->data, true ) ?: array();

        // ── Session L : Limite de régénérations (max 2 par action) ──
        $max_regens = 2;
        $regen_count = (int) ( $data['_regen_count'] ?? 0 );
        if ( $regen_count >= $max_regens ) {
            wp_send_json_error( 'Limite atteinte : ' . $max_regens . ' régénérations maximum par proposition. Modifiez la langue ou le mot-clé dans le panneau SEO de l\'article, puis relancez un scan.' );
        }

        // Incrémenter le compteur
        $data['_regen_count'] = $regen_count + 1;

        // Effacer le cache pour forcer la régénération
        unset( $data['_generated_variants'], $data['_all_titles'], $data['_all_descriptions'], $data['suggestion'] );

        // Effacer aussi le rate limit sur le post pour permettre la regen
        delete_post_meta( (int) $action->post_id, '_hts_meta_gen_ts' );

        // Sauvegarder le data nettoyé
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;
        $wpdb->update( $table,
            array( 'data' => wp_json_encode( $data ) ),
            array( 'id' => $action_id )
        );

        // ── Session L fix : aussi effacer le cache du sibling (title ↔ desc) ──
        $sibling_type = $action->type === 'add_meta_title' ? 'add_meta_desc' : 'add_meta_title';
        $sibling_row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, data FROM {$table} WHERE agent = %s AND type = %s AND post_id = %d AND status = 'pending' AND id != %d LIMIT 1",
            $action->agent, $sibling_type, (int) $action->post_id, $action_id
        ) );
        if ( $sibling_row ) {
            $sib_data = json_decode( $sibling_row->data, true ) ?: array();
            unset( $sib_data['_generated_variants'], $sib_data['_all_titles'], $sib_data['_all_descriptions'], $sib_data['suggestion'] );
            $wpdb->update( $table,
                array( 'data' => wp_json_encode( $sib_data ) ),
                array( 'id' => (int) $sibling_row->id )
            );
        }

        wp_send_json_success( array( 'action_id' => $action_id, 'cleared' => true, 'regen_left' => $max_regens - $data['_regen_count'] ) );
    }

    /**
     * AJAX : Sélectionner une variante meta (Session L).
     *
     * Le client choisit parmi les variantes générées par l'IA.
     * Met à jour l'action data avec la variante choisie comme suggestion principale.
     *
     * @since 2.4.8
     */
    public function ajax_inbox_select_variant() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $action_id   = (int) ( $_POST['action_id'] ?? 0 );
        $variant_idx = (int) ( $_POST['variant_idx'] ?? 0 );

        if ( ! $action_id ) wp_send_json_error( 'ID manquant' );

        $action = self::get_action( $action_id );
        if ( ! $action || $action->status !== 'pending' ) {
            wp_send_json_error( 'Action introuvable ou déjà traitée' );
        }

        $data = json_decode( $action->data, true ) ?: array();
        if ( empty( $data['_generated_variants'] ) ) {
            wp_send_json_error( 'Aucune variante disponible' );
        }

        $variants = $data['_generated_variants'];
        if ( ! isset( $variants[ $variant_idx ] ) ) {
            wp_send_json_error( 'Index de variante invalide' );
        }

        // Réorganiser : mettre la variante choisie en premier
        $chosen = $variants[ $variant_idx ];
        array_splice( $variants, $variant_idx, 1 );
        array_unshift( $variants, $chosen );
        $data['_generated_variants'] = $variants;

        // Mettre à jour la suggestion visible
        $selected_text = '';
        if ( $action->type === 'add_meta_title' && ! empty( $chosen['title'] ) ) {
            $data['suggestion'] = $chosen['title'];
            $selected_text = $chosen['title'];
            $data['_all_titles'] = array_map( function( $v ) { return $v['title'] ?? ''; }, $variants );
        }
        if ( $action->type === 'add_meta_desc' && ! empty( $chosen['description'] ) ) {
            $data['suggestion'] = $chosen['description'];
            $selected_text = $chosen['description'];
            $data['_all_descriptions'] = array_map( function( $v ) { return $v['description'] ?? ''; }, $variants );
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . self::ACTIONS_TABLE,
            array( 'data' => wp_json_encode( $data ) ),
            array( 'id' => $action_id )
        );

        wp_send_json_success( array(
            'action_id'     => $action_id,
            'variant_idx'   => 0,
            'selected_text' => $selected_text,
        ) );
    }

    /**
     * AJAX : Aperçu du rollback (diff inversé) — Session J.
     * @since 2.4.6
     */
    public function ajax_inbox_rollback_preview() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $id = (int) ( $_POST['action_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID manquant' );

        $preview = self::get_rollback_preview( $id );
        if ( isset( $preview['error'] ) && $preview['error'] !== false && empty( $preview['fields'] ) ) {
            $error_msg = is_string( $preview['error'] ) ? $preview['error'] : 'Aucun point de restauration disponible pour cette action.';
            wp_send_json_error( $error_msg );
        }

        wp_send_json_success( $preview );
    }

    /**
     * AJAX : Impact report — mesure d'efficacité des agents (Session H+).
     */
    /**
     * AJAX : Récupérer la recommandation de cadence pour le mode auto meta.
     *
     * @since 2.4.8
     */
    public function ajax_meta_auto_recommend() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $rec = self::get_meta_auto_recommendation();
        wp_send_json_success( $rec );
    }

    /**
     * AJAX : Dry-run du mode automatique.
     *
     * Simule un passage du mode auto sur les 5 pires pages :
     * — Score avant
     * — Garde-fous OK/KO
     * — Génération IA (si demandé avec execute=1, exécute réellement 1 action)
     * — Score après (si exécuté)
     *
     * @since 2.4.8
     */
    public function ajax_auto_dry_run() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        self::ensure_tables();

        $agent   = sanitize_key( $_POST['agent'] ?? 'meta' );
        $execute = (int) ( $_POST['execute'] ?? 0 );

        $results = array();

        if ( $agent === 'meta' && class_exists( 'HTS_Meta_Score' ) ) {
            $meta_score_obj = new \HTS_Meta_Score();
            $min_score      = 0; // Meta quality gate supprimée (v2.4.9)

            // Récupérer les posts+pages publiés
            $post_ids = get_posts( array(
                'post_type'      => array( 'post', 'page' ),
                'post_status'    => 'publish',
                'posts_per_page' => 200,
                'fields'         => 'ids',
            ) );

            // Scorer et trier
            $scored = array();
            foreach ( $post_ids as $pid ) {
                $result = $meta_score_obj->score_post( $pid, true );
                $score  = (int) ( $result['score'] ?? 100 );
                if ( $score < 60 ) {
                    $scored[] = array( 'pid' => $pid, 'score' => $score );
                }
            }
            usort( $scored, function( $a, $b ) { return $a['score'] - $b['score']; } );
            $scored = array_slice( $scored, 0, 5 );

            $executed_one = false;

            foreach ( $scored as $item ) {
                $pid   = $item['pid'];
                $score = $item['score'];
                $post  = get_post( $pid );

                $entry = array(
                    'post_id'        => $pid,
                    'post_title'     => $post ? $post->post_title : "(#{$pid})",
                    'post_url'       => get_permalink( $pid ),
                    'score_before'   => $score,
                    'score_after'    => null,
                    'delta'          => null,
                    'guardrails'     => array(),
                    'would_be_blocked' => false,
                    'eligible'       => true,
                    'executed'       => false,
                    'variant_score'  => null,
                    'variant_title'  => null,
                    'variant_desc'   => null,
                    'blocked_reasons' => array(),
                );

                // ── Vérifier chaque garde-fou (informatif, ne bloque PAS la simulation) ──
                $checks = array(
                    'Limite hebdo'     => self::check_weekly_limit( $agent, 'add_meta_title' ),
                    'Budget API'       => self::check_budget(),
                    'Seuil trafic'     => self::check_traffic_threshold( $pid ),
                    'Blacklist'        => self::check_blacklist( $pid ),
                    'Horaires auto'    => self::check_auto_hours(),
                    'Cooldown (28j)'   => self::check_cooldown( $agent, $pid ),
                    'Conflit agent'    => self::check_cross_agent_conflict( $agent, $pid ),
                    'Limite meta/sem.' => self::check_meta_weekly_limit(),
                );

                foreach ( $checks as $label => $check_result ) {
                    $ok = ( $check_result === true );
                    $entry['guardrails'][] = array(
                        'label'  => $label,
                        'ok'     => $ok,
                        'reason' => $ok ? '' : ( is_string( $check_result ) ? wp_strip_all_tags( $check_result ) : 'Bloqué' ),
                    );
                    if ( ! $ok ) {
                        $entry['would_be_blocked'] = true;
                        $entry['blocked_reasons'][] = $label;
                    }
                }

                // ── TOUJOURS générer la variante IA (c'est une simulation) ──
                if ( method_exists( $meta_score_obj, 'generate_variants' ) ) {
                    $gen_result = $meta_score_obj->generate_variants( $pid );
                    if ( ! empty( $gen_result['variants'] ) ) {
                        $best = $gen_result['variants'][0];
                        $entry['variant_score'] = (int) ( $best['score'] ?? 0 );
                        $entry['variant_title'] = $best['title'] ?? '';
                        $entry['variant_desc']  = $best['description'] ?? '';

                        if ( $entry['variant_score'] < $min_score ) {
                            $entry['would_be_blocked'] = true;
                            $entry['blocked_reasons'][] = "Score IA ({$entry['variant_score']}) < seuil ({$min_score})";
                        }
                    } elseif ( isset( $gen_result['error'] ) ) {
                        $entry['would_be_blocked'] = true;
                        $entry['blocked_reasons'][] = 'Erreur IA : ' . ( $gen_result['error'] ?? 'inconnue' );
                    }
                }

                // Éligible = aucun garde-fou bloquant ET variante OK
                $entry['eligible'] = ! $entry['would_be_blocked'] && $entry['variant_score'] !== null;

                // ── Exécuter réellement la 1ère éligible si demandé ──
                if ( $execute && $entry['eligible'] && ! $executed_one ) {
                    if ( ! empty( $entry['variant_title'] ) ) {
                        update_post_meta( $pid, '_hts_meta_title', sanitize_text_field( $entry['variant_title'] ) );
                    }
                    if ( ! empty( $entry['variant_desc'] ) ) {
                        update_post_meta( $pid, '_hts_meta_description', sanitize_textarea_field( $entry['variant_desc'] ) );
                    }

                    $after_result = $meta_score_obj->score_post( $pid, true );
                    $entry['score_after'] = (int) ( $after_result['score'] ?? 0 );
                    $entry['delta']       = $entry['score_after'] - $entry['score_before'];
                    $entry['executed']    = true;
                    $executed_one = true;

                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log(
                            "Dry-run meta exécuté : post #{$pid} — score {$entry['score_before']} → {$entry['score_after']} (+" . max( 0, $entry['delta'] ) . ")",
                            'info', 'workflow'
                        );
                    }
                }

                $results[] = $entry;
            }
        }

        // Stats globales
        $eligible_count = count( array_filter( $results, function( $r ) { return $r['eligible']; } ) );
        $blocked_count  = count( array_filter( $results, function( $r ) { return $r['would_be_blocked']; } ) );
        $with_variant   = count( array_filter( $results, function( $r ) { return $r['variant_score'] !== null; } ) );

        $stats = array(
            'total_checked'  => count( $results ),
            'eligible'       => $eligible_count,
            'blocked'        => $blocked_count,
            'with_variant'   => $with_variant,
            'executed'       => count( array_filter( $results, function( $r ) { return $r['executed']; } ) ),
        );

        wp_send_json_success( array( 'results' => $results, 'stats' => $stats ) );
    }

    public function ajax_impact_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $report = self::get_impact_report( 50 );
        wp_send_json_success( $report );
    }

    /**
     * AJAX : Charger les recommandations garde-fous pour tous les agents.
     * @since 2.4.8
     */
    public function ajax_load_guardrails_recommendations() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $recs   = self::get_all_recommendations();
        $schema = self::get_guardrails_schema();
        $saved  = get_option( 'hts_guardrails_agents', array() );

        wp_send_json_success( array(
            'recommendations' => $recs,
            'schema'          => $schema,
            'saved'           => $saved,
        ) );
    }

    /**
     * AJAX : Sauvegarder les garde-fous par agent.
     * @since 2.4.8
     */
    public function ajax_save_agent_guardrails() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $raw = $_POST['guardrails'] ?? '';
        $data = json_decode( stripslashes( $raw ), true );
        if ( ! is_array( $data ) ) wp_send_json_error( 'Données invalides' );

        // Valider chaque valeur contre le schéma
        $schema = self::get_guardrails_schema();
        $clean  = array();
        foreach ( $data as $agent => $values ) {
            if ( ! isset( $schema[ $agent ] ) ) continue;
            $clean[ $agent ] = array();
            foreach ( $schema[ $agent ]['fields'] as $field ) {
                $key = $field['key'];
                if ( isset( $values[ $key ] ) ) {
                    $val = $field['type'] === 'number' ? ( is_numeric( $values[ $key ] ) ? (float) $values[ $key ] : $field['default'] ) : $values[ $key ];
                    if ( isset( $field['min'] ) ) $val = max( $field['min'], $val );
                    if ( isset( $field['max'] ) ) $val = min( $field['max'], $val );
                    $clean[ $agent ][ $key ] = $val;
                }
            }
        }

        update_option( 'hts_guardrails_agents', $clean, false );
        wp_send_json_success( array( 'saved' => $clean ) );
    }

    /**
     * AJAX : Lancer un scan complet du site pour remplir l'Inbox.
     *
     * Combine GEO Score + Content Refresh + analyse directe des pages faibles.
     * Utilise des seuils plus larges que les crons pour garantir des propositions
     * même sur un site récent ou peu alimenté.
     *
     * @since 2.3.0
     */
    public function ajax_inbox_scan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );

        // Étendre le timeout PHP pour le scan complet (GEO + refresh + meta + linking + IA)
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 120 );
        }

        self::ensure_tables();

        $result = self::scan_proposals( false );

        // Stats après scan
        $stats = self::get_stats();

        wp_send_json_success( array(
            'scanned'  => $result['scanned'],
            'proposed' => $result['proposed'],
            'pending'  => (int) ( $stats['pending'] ?? 0 ),
        ) );
    }

    /**
     * AJAX : Scanner le maillage d'un cluster spécifique.
     *
     * Appelé depuis le bouton "Mailler ce cluster" du Cocon Commander.
     * Ne scanne que le cluster demandé au lieu de tout le site.
     *
     * @since 2.4.9
     */
    public function ajax_scan_cluster_linking() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée' );
        HTS_Subscription::require_tier(2);

        $cluster_name = sanitize_text_field( $_POST['cluster'] ?? '' );
        if ( empty( $cluster_name ) ) {
            wp_send_json_error( 'Nom du cluster manquant' );
        }

        self::ensure_tables();

        $proposed = 0;

        if ( class_exists( 'HTS_Internal_Linking' ) && self::is_agent_enabled( 'linking' ) ) {
            $linker = new \HTS_Internal_Linking();

            // Scan uniquement le cluster demandé
            if ( method_exists( $linker, 'scan_cluster_linking' ) ) {
                $proposed = $linker->scan_cluster_linking( $cluster_name );
            } elseif ( class_exists( 'HTS_Cocon' ) ) {
                // Fallback : utiliser suggest_cluster_links directement
                $cocon  = new \HTS_Cocon();
                $result = $cocon->suggest_cluster_links( $cluster_name );

                if ( ! empty( $result['suggestions'] ) ) {
                    $inbox_diag = array( 'total' => 0, 'skip_done' => 0, 'skip_no_ids' => 0, 'skip_fallback' => 0, 'skip_semantic_title' => 0, 'proposed' => 0, 'propose_failed' => 0 );
                    foreach ( $result['suggestions'] as $sug ) {
                        $inbox_diag['total']++;
                        $source_id = (int) ( $sug['source_id'] ?? 0 );
                        $target_id = (int) ( $sug['target_id'] ?? 0 );
                        if ( ! $source_id || ! $target_id ) { $inbox_diag['skip_no_ids']++; continue; }

                        // v2.4.16: Use the state computed by suggest_cluster_links() triple-check
                        // instead of re-doing a fragile stripos check here
                        $sug_state = $sug['state'] ?? 'pending';
                        if ( $sug_state === 'done' ) { $inbox_diag['skip_done']++; continue; } // Link already in content
                        // 'lost' = HTS applied it before but it disappeared — re-propose
                        // 'pending' = new suggestion — propose

                        // v2.4.19: Only block raw fallback (title truncation). 
                        // semantic_title, partial_title, contextual, ai all pass — the Inbox IS the quality gate.
                        $anchor_method = $sug['anchor_method'] ?? '';
                        if ( $anchor_method === 'fallback' ) {
                            $inbox_diag[ 'skip_fallback' ]++;
                            if ( function_exists( 'hts_add_log' ) ) {
                                hts_add_log(
                                    'Inbox skip (ancre ' . $anchor_method . ') : "' . mb_substr( $sug['anchor_text'] ?? '', 0, 40 ) . '" → ' . mb_substr( $sug['target_title'] ?? '', 0, 40 ),
                                    'info', 'workflow'
                                );
                            }
                            continue;
                        }

                        $link_type = $sug['link_type'] ?? 'cluster';
                        $priority  = $sug['priority'] ?? 'medium';

                        $why = sprintf(
                            '%sLien manquant dans le cocon "%s" : %s → %s (%s)',
                            $sug_state === 'lost' ? 'Lien perdu — ' : '',
                            $cluster_name,
                            mb_substr( $sug['source_title'] ?? '', 0, 40 ),
                            mb_substr( $sug['target_title'] ?? '', 0, 40 ),
                            $link_type === 'child_to_pillar' ? 'enfant vers pilier' :
                                ( $link_type === 'pillar_to_child' ? 'pilier vers enfant' : 'lien sémantique' )
                        );

                        // GSC data for enrichment
                        $gsc_tag = ! empty( $sug['gsc']['tag'] ) ? $sug['gsc']['tag'] : '';
                        if ( $gsc_tag && strpos( $why, '📊' ) === false ) {
                            $why .= ' · ' . $gsc_tag;
                        }

                        $action_id = self::propose(
                            'linking',
                            'add_internal_links',
                            $source_id,
                            array(
                                'reason'          => $why,
                                'source_cocon'    => true,
                                'cluster'         => $cluster_name,
                                'target_id'       => $target_id,
                                'target_title'    => $sug['target_title'] ?? '',
                                'anchor_text'     => $sug['anchor_text'] ?? '',
                                'anchor_method'   => $sug['anchor_method'] ?? '',
                                'anchor_type'     => $sug['anchor_type'] ?? '',
                                'anchor_bridge'   => $sug['anchor_bridge'] ?? '',
                                'anchor_sentence' => $sug['anchor_sentence'] ?? '',
                                'link_type'       => $link_type,
                                'suggestion'      => 'Ajouter un lien vers "' . mb_substr( $sug['target_title'] ?? '', 0, 50 ) . '"',
                                'gsc'             => $sug['gsc'] ?? array(),
                                'orphan_rescue'   => ! empty( $sug['orphan_rescue'] ),
                            ),
                            $priority
                        );
                        if ( $action_id && $action_id !== true ) { $proposed++; $inbox_diag['proposed']++; } else { $inbox_diag['propose_failed']++; }
                    }

                    // ── FUNNEL LOG: Inbox filter summary ──
                    if ( function_exists( 'hts_add_log' ) ) {
                        hts_add_log(
                            'FUNNEL Inbox ["' . $cluster_name . '"] : '
                            . $inbox_diag['total'] . ' suggestions reçues → '
                            . 'done=' . $inbox_diag['skip_done'] . ', '
                            . 'no_ids=' . $inbox_diag['skip_no_ids'] . ', '
                            . 'skip_fallback=' . $inbox_diag['skip_fallback'] . ', '
                            . 'skip_semantic_title=' . $inbox_diag['skip_semantic_title'] . ', '
                            . 'propose_failed=' . $inbox_diag['propose_failed'] . ' → '
                            . $inbox_diag['proposed'] . ' proposées dans Inbox',
                            'info', 'workflow'
                        );
                    }
                }
            }
        }

        wp_send_json_success( array(
            'cluster'  => $cluster_name,
            'proposed' => $proposed,
        ) );
    }

    /**
     * Cron callback : scan hebdomadaire des propositions Inbox.
     *
     * @since 2.4.1
     */
    public static function cron_inbox_scan() {
        self::ensure_tables();
        $result = self::scan_proposals( true );
        if ( $result['proposed'] > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                'Scan Inbox hebdo : ' . $result['proposed'] . ' proposition(s) créée(s) sur ' . $result['scanned'] . ' éléments scannés.',
                'info', 'workflow'
            );
        }
    }

    /**
     * Sprint 4.3 — Cron daily : purge les actions meta pending > 3 jours.
     *
     * Les propositions de meta title/desc non traitées après 3 jours sont
     * probablement obsolètes (le contenu a pu changer). On les supprime
     * pour garder l'Inbox propre et éviter d'appliquer des metas dépassées.
     *
     * @since 4.0.0 Sprint 4.3
     */
    public static function cron_purge_stale_actions() {
        $lock_key = 'hts_lock_purge_stale_actions';
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, 120 );

        self::ensure_tables();
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // 1. Original: purge stale pending meta proposals > 3 days
        $cutoff_3d = gmdate( 'Y-m-d H:i:s', time() - ( 3 * DAY_IN_SECONDS ) );
        $deleted_meta = (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE status = 'pending'
               AND type IN ('add_meta_title', 'add_meta_desc')
               AND created_at < %s",
            $cutoff_3d
        ) );

        // 2. S13-B: Recover stuck 'executing' actions (PHP timeout mid-dispatch)
        // If an action has been 'executing' for > 1 hour, something crashed → mark failed
        $cutoff_1h = gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS );
        $stuck = (int) $wpdb->query( $wpdb->prepare(
            "UPDATE {$table}
             SET status = 'failed', execution_log = CONCAT(IFNULL(execution_log,''), ' [Auto-recovery: stuck executing > 1h]'), resolved_at = %s
             WHERE status = 'executing'
               AND created_at < %s",
            current_time( 'mysql' ), $cutoff_1h
        ) );

        // 3. S13-B: Purge old 'blocked' actions > 30 days (guardrail blocked, never executed)
        $cutoff_30d = gmdate( 'Y-m-d H:i:s', time() - ( 30 * DAY_IN_SECONDS ) );
        $deleted_blocked = (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE status = 'blocked'
               AND resolved_at < %s",
            $cutoff_30d
        ) );

        // 4. S13-B: Purge very old 'failed' actions > 60 days (keep done/dismissed for history)
        $cutoff_60d = gmdate( 'Y-m-d H:i:s', time() - ( 60 * DAY_IN_SECONDS ) );
        $deleted_failed = (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE status = 'failed'
               AND resolved_at < %s",
            $cutoff_60d
        ) );

        $total_cleaned = $deleted_meta + $stuck + $deleted_blocked + $deleted_failed;

        // 5. S13-B: Purge stale pending proposals > 14 days (all types)
        // Any proposal not acted on in 14 days is outdated (content may have changed)
        $cutoff_14d = gmdate( 'Y-m-d H:i:s', time() - ( 14 * DAY_IN_SECONDS ) );
        $deleted_stale = (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE status = 'pending'
               AND created_at < %s",
            $cutoff_14d
        ) );
        $total_cleaned += $deleted_stale;

        // 6. S13-B: Purge dismissed > 90 days (keep for blacklist dedup, then clean)
        $cutoff_90d = gmdate( 'Y-m-d H:i:s', time() - ( 90 * DAY_IN_SECONDS ) );
        $deleted_dismissed = (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE status = 'dismissed'
               AND resolved_at < %s",
            $cutoff_90d
        ) );
        $total_cleaned += $deleted_dismissed;

        if ( $total_cleaned > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( 'Purge actions : %d meta périmées, %d exécutions bloquées récupérées, %d bloquées supprimées, %d échouées supprimées.',
                    $deleted_meta, $stuck, $deleted_blocked, $deleted_failed ),
                'info', 'workflow'
            );
        }

        delete_transient( $lock_key );
    }

    /**
     * Cron auto-drip : exécute les actions auto-approuvées progressivement.
     *
     * Maximum 2 actions par exécution (1 run/heure = max ~48/jour).
     * Les actions sont traitées par priorité (critical > high > medium > low)
     * puis par date de création (FIFO).
     *
     * Ce mécanisme garantit un profil de modification naturel :
     * les metas ne sont pas toutes modifiées d'un coup, mais étalées sur la semaine.
     *
     * @since 2.4.8
     */
    public static function cron_auto_drip() {
        if ( get_transient( 'hts_auto_drip_lock' ) ) {
            return;
        }
        set_transient( 'hts_auto_drip_lock', 1, 120 );

        try {
        self::ensure_tables();

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        // Récupérer les actions approved (auto) non encore exécutées, triées par priorité
        $priority_order = "FIELD(priority, 'critical', 'high', 'medium', 'low')";
        $actions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, agent, type, post_id, data FROM {$table}
             WHERE status = %s
             ORDER BY {$priority_order}, created_at ASC
             LIMIT 5",
            'approved'
        ) );

        if ( empty( $actions ) ) {
            delete_transient( 'hts_auto_drip_lock' );
            return;
        }

        $executed = 0;
        $skipped  = 0;

        foreach ( $actions as $action ) {
            // Re-vérifier les garde-fous au moment de l'exécution
            $drip_data      = json_decode( $action->data ?? '{}', true ) ?: array();
            $drip_is_cocon  = ! empty( $drip_data['source_cocon'] );
            $drip_is_orphan = ! empty( $drip_data['orphan_rescue'] ) || $action->type === 'fix_orphan_links';
            $drip_is_coach  = ! empty( $drip_data['source'] ) && in_array( $drip_data['source'], array( 'coach_agent', 'coach_ai' ), true );

            if ( $drip_is_coach ) {
                $guardrail = true;
            } else {
                $guardrail = self::check_all_guardrails( $action->agent, $action->type, (int) $action->post_id, $drip_is_cocon, $drip_is_orphan );
            }
            if ( $guardrail !== true ) {
                // Bloquer l'action avec le motif
                $wpdb->update( $table,
                    array(
                        'status'        => self::STATUS_BLOCKED,
                        'resolved_at'   => current_time( 'mysql' ),
                        'execution_log' => 'Auto-drip bloqué : ' . wp_strip_all_tags( $guardrail ),
                    ),
                    array( 'id' => (int) $action->id )
                );
                $skipped++;
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Auto-drip : action #{$action->id} bloquée — " . wp_strip_all_tags( $guardrail ), 'warn', 'workflow' );
                }
                continue;
            }

            // Exécuter l'action
            self::execute( (int) $action->id );
            $executed++;
        }

        if ( ( $executed + $skipped ) > 0 && function_exists( 'hts_add_log' ) ) {
            $remaining = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status = %s",
                'approved'
            ) );
            hts_add_log(
                "Auto-drip : {$executed} exécutée(s), {$skipped} bloquée(s), {$remaining} en attente.",
                'info', 'workflow'
            );
        }
        // P2 #28: Track last cron run for DISABLE_WP_CRON detection
        update_option( 'hts_last_cron_run', time(), false );
        delete_transient( 'hts_auto_drip_lock' );
        } catch ( \Throwable $e ) {
            delete_transient( 'hts_auto_drip_lock' );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Auto-drip CRASH: ' . $e->getMessage() . ' L' . $e->getLine(), 'error', 'workflow' );
            }
        }
    }

    /**
     * Cron ponctuel : traite les liens approuvés en masse par lots de 5.
     * Se re-programme tant qu'il reste des liens approved.
     *
     * @since 2.4.9
     */
    public static function cron_batch_linking_drip() {
        $lock_key = 'hts_lock_batch_linking_drip';
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, 120 );

        try {
        self::ensure_tables();

        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $actions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, agent, type, post_id, data FROM {$table}
             WHERE status = %s AND type IN ('add_internal_links', 'fix_orphan_links')
             ORDER BY FIELD(priority, 'critical', 'high', 'medium', 'low'), created_at ASC
             LIMIT 5",
            self::STATUS_APPROVED
        ) );

        if ( empty( $actions ) ) return;

        $executed = 0;
        foreach ( $actions as $action ) {
            $drip_data2      = json_decode( $action->data, true ) ?: array();
            $drip_is_cocon2  = ! empty( $drip_data2['source_cocon'] );
            $drip_is_orphan2 = ! empty( $drip_data2['orphan_rescue'] ) || $action->type === 'fix_orphan_links';
            $drip_is_coach2  = ! empty( $drip_data2['source'] ) && in_array( $drip_data2['source'], array( 'coach_agent', 'coach_ai' ), true );

            if ( $drip_is_coach2 ) {
                $guardrail = true;
            } else {
                $guardrail = self::check_all_guardrails( $action->agent, $action->type, (int) $action->post_id, $drip_is_cocon2, $drip_is_orphan2 );
            }
            if ( $guardrail !== true ) {
                $wpdb->update( $table,
                    array(
                        'status'        => self::STATUS_BLOCKED,
                        'resolved_at'   => current_time( 'mysql' ),
                        'execution_log' => 'Batch-drip bloqué : ' . wp_strip_all_tags( $guardrail ),
                    ),
                    array( 'id' => (int) $action->id )
                );
                continue;
            }
            self::execute( (int) $action->id );
            $executed++;
            usleep( 200000 ); // 200ms entre chaque
        }

        // Vérifier s'il reste des liens à traiter
        $remaining = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE status = %s AND type IN ('add_internal_links', 'fix_orphan_links')",
            self::STATUS_APPROVED
        ) );

        if ( $remaining > 0 ) {
            // Re-programmer dans 5 min
            if ( ! wp_next_scheduled( 'hts_batch_linking_drip' ) ) {
                wp_schedule_single_event( time() + 300, 'hts_batch_linking_drip' );
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                "Batch-drip linking : {$executed} exécuté(s), {$remaining} restant(s).",
                'info', 'workflow'
            );
        }
        delete_transient( $lock_key );
        } catch ( \Throwable $e ) {
            delete_transient( $lock_key );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'cron', 'batch_linking_drip error: ' . $e->getMessage() );
            }
        }
    }

    /**
     * Scanner tous les problèmes détectables et créer des propositions Inbox.
     * Utilisé par le bouton manuel ET le cron hebdo.
     *
     * @since 2.4.1
     * @param bool $is_cron  true si appelé par le cron (limites plus strictes)
     * @return array { scanned, proposed }
     */
    public static function scan_proposals( $is_cron = false ) {
        global $wpdb;
        $table    = $wpdb->prefix . self::ACTIONS_TABLE;
        $proposed = 0;
        $scanned  = 0;
        $max_per_type = $is_cron ? 20 : 50; // Limite par type pour éviter les batch trop gros

        // Batch sync: collect all actions, send ONE call at the end
        self::$batch_sync_queue = array();
        hts_debug_log( '[BATCH] scan_proposals START — queue initialized, remote=' . ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS ? 'ON' : 'OFF' ) . ' available=' . ( class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ? 'YES' : 'NO' ) );

        // Sprint 6.3c: garde-fou timeout — avorter proprement si on approche la limite
        $scan_start = microtime( true );
        $time_budget = 45; // secondes max pour tout le scan (nginx coupe a 60s, 15s de marge)
        $time_check = function() use ( $scan_start, $time_budget ) {
            $ok = ( microtime( true ) - $scan_start ) < $time_budget;
            if ( ! $ok ) {
                // Flush batch sync before early return (timeout)
                $tc_count = is_array( self::$batch_sync_queue ) ? count( self::$batch_sync_queue ) : 0;
                hts_debug_log( '[BATCH] TIMEOUT — flushing ' . $tc_count . ' actions before early return' );
                if ( ! empty( self::$batch_sync_queue ) && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
                    $batches = array_chunk( self::$batch_sync_queue, 200 );
                    foreach ( $batches as $batch ) {
                        $result = HTS_Remote_Client::call( 'sync/actions', array( 'actions' => $batch ), 'POST', array( 'timeout' => 10, 'retries' => 1 ) );
                        hts_debug_log( '[BATCH] Timeout flush: ' . count( $batch ) . ' actions — ' . ( ! empty( $result['success'] ) ? 'OK' : 'FAIL' ) );
                    }
                }
                self::$batch_sync_queue = null;
            }
            return $ok;
        };

        // ── 1. GEO Score scan — calcule + propose (seuil élargi à 75) ──
        if ( class_exists( 'HTS_GEO_Score' ) && $time_check() ) {
            $geo = new \HTS_GEO_Score();
            $posts = get_posts( array(
                'post_type'      => array( 'post', 'page' ),
                'post_status'    => 'publish',
                'posts_per_page' => 30, // Sprint 6.3c: réduit de 80 à 30 pour éviter timeout
                'fields'         => 'ids',
                'orderby'        => 'modified',
                'order'          => 'ASC',
            ) );
            $geo_proposed = 0;
            foreach ( $posts as $pid ) {
                if ( ! $time_check() ) break; // Sprint 6.3c: time guard
                $result = $geo->calculate( $pid, true );
                if ( ! $result || empty( $result['recommendations'] ) ) continue;
                $scanned++;

                $score = (int) ( $result['geo_score'] ?? 100 );
                if ( $score < 75 && $geo_proposed < $max_per_type ) {
                    $priority = $score < 30 ? 'high' : ( $score < 50 ? 'medium' : 'low' );

                    // Sprint 6.3d: Only propose GEO criteria we can actually execute automatically.
                    // Everything else (intro, stats, sources, structure) = advice we can't action → skip.
                    $actionable_criteria = array( 'faq_lists' );
                    foreach ( $result['recommendations'] as $rec_idx => $rec ) {
                        $criterion = $rec['criterion'] ?? 'unknown_' . $rec_idx;
                        if ( ! in_array( $criterion, $actionable_criteria, true ) ) continue;
                        $id = self::propose(
                            'geo_score',
                            'geo_optimize',
                            $pid,
                            array(
                                'reason'      => sprintf( 'Score visibilité IA : %d/100 — %s', $score, $rec['fix'] ),
                                'geo_score'   => $score,
                                'suggestion'  => $rec['fix'],
                                'top_why'     => $rec['why'] ?? '',
                                'criterion'   => $criterion,
                                'fixes_count' => count( $result['recommendations'] ),
                                '_dedup_key'  => $criterion, // used by propose() for dedup
                            ),
                            $priority
                        );
                        if ( $id ) { $proposed++; $geo_proposed++; }
                    }
                }
            }
        }

        // ── 2. Content Refresh — articles obsolètes ──
        if ( class_exists( 'HTS_Content_Refresh' ) && $time_check() ) {
            if ( ! $is_cron ) {
                add_filter( 'hts_refresh_min_age_days', function() { return 90; } );
                add_filter( 'hts_refresh_max_clicks', function() { return 10; } );
            }

            $refresh = new \HTS_Content_Refresh();
            $stale = $refresh->scan_stale_articles();
            if ( ! empty( $stale ) ) {
                $proposed += (int) $refresh->propose_stale_to_inbox( $stale );
            }

            if ( ! $is_cron ) {
                remove_all_filters( 'hts_refresh_min_age_days' );
                remove_all_filters( 'hts_refresh_max_clicks' );
            }
        }

        // ── 3. Meta TITLES manquants ──
        if ( ! $time_check() ) return array( 'scanned' => $scanned, 'proposed' => $proposed, 'partial' => true );
        $no_title = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $max_per_type,
            'fields'         => 'ids',
            'meta_query'     => array(
                'relation' => 'OR',
                array( 'key' => '_hts_meta_title', 'compare' => 'NOT EXISTS' ),
                array( 'key' => '_hts_meta_title', 'value' => '', 'compare' => '=' ),
            ),
        ) );
        // Sprint 6.3d: meta keys from other SEO plugins that provide a custom title
        $other_title_keys = array( '_yoast_wpseo_title', 'rank_math_title', '_aioseo_title', '_seopress_titles_title' );
        foreach ( $no_title as $pid ) {
            // Skip if another plugin already provides a custom title
            $has_other_title = false;
            foreach ( $other_title_keys as $otk ) {
                $val = get_post_meta( $pid, $otk, true );
                if ( ! empty( $val ) ) { $has_other_title = true; break; }
            }
            if ( $has_other_title ) { $scanned++; continue; }

            $id = self::propose(
                'meta',
                'add_meta_title',
                $pid,
                array(
                    'reason'     => 'Aucun titre SEO personnalisé — Google utilise le titre WordPress brut',
                    'suggestion' => 'Générer un titre SEO optimisé pour le clic et les moteurs de recherche',
                ),
                'high'
            );
            if ( $id && $id !== true ) { $proposed++; }
            $scanned++;
        }

        // ── 4. Meta DESCRIPTIONS manquantes ──
        if ( ! $time_check() ) return array( 'scanned' => $scanned, 'proposed' => $proposed, 'partial' => true );
        $no_desc = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $max_per_type,
            'fields'         => 'ids',
            'meta_query'     => array(
                'relation' => 'OR',
                array( 'key' => '_hts_meta_description', 'compare' => 'NOT EXISTS' ),
                array( 'key' => '_hts_meta_description', 'value' => '', 'compare' => '=' ),
            ),
        ) );
        // Sprint 6.3d: meta keys from other SEO plugins that provide a custom description
        $other_desc_keys = array( '_yoast_wpseo_metadesc', 'rank_math_description', '_aioseo_description', '_seopress_titles_desc' );
        foreach ( $no_desc as $pid ) {
            // Skip if another plugin already provides a custom description
            $has_other_desc = false;
            foreach ( $other_desc_keys as $odk ) {
                $val = get_post_meta( $pid, $odk, true );
                if ( ! empty( $val ) ) { $has_other_desc = true; break; }
            }
            if ( $has_other_desc ) { $scanned++; continue; }

            $id = self::propose(
                'meta',
                'add_meta_desc',
                $pid,
                array(
                    'reason'     => 'Aucune meta description — les moteurs de recherche génèrent un extrait aléatoire',
                    'suggestion' => 'Générer une meta description optimisée pour le clic',
                ),
                'medium'
            );
            if ( $id && $id !== true ) { $proposed++; }
            $scanned++;
        }

        // ── 5. Contenu mince — articles < 300 mots ──
        if ( ! $time_check() ) return array( 'scanned' => $scanned, 'proposed' => $proposed, 'partial' => true );
        global $wpdb;
        $pt_in = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $thin_posts = $wpdb->get_results( $wpdb->prepare( "
            SELECT ID, post_title, LENGTH(post_content) - LENGTH(REPLACE(post_content, ' ', '')) + 1 AS word_est
            FROM {$wpdb->posts}
            WHERE post_status = 'publish' AND post_type {$pt_in}
            HAVING word_est < 300
            ORDER BY word_est ASC
            LIMIT %d
        ", $max_per_type ) );
        foreach ( $thin_posts as $tp ) {
            $words = (int) $tp->word_est;
            $id = self::propose(
                'content_quality',
                'enrich_thin_content',
                (int) $tp->ID,
                array(
                    'reason'     => sprintf( 'Article trop court (%d mots) — Google considère moins de 300 mots comme du contenu mince', $words ),
                    'suggestion' => 'Enrichir le contenu avec plus de détails, exemples ou données pour dépasser 300 mots',
                    'word_count' => $words,
                ),
                $words < 100 ? 'high' : 'medium'
            );
            if ( $id && $id !== true ) { $proposed++; }
            $scanned++;
        }

        // ── 6. Images mise en avant manquantes ──
        if ( ! $time_check() ) return array( 'scanned' => $scanned, 'proposed' => $proposed, 'partial' => true );
        $no_thumb = $wpdb->get_col( $wpdb->prepare( "
            SELECT p.ID FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_thumbnail_id'
            WHERE p.post_status = 'publish' AND p.post_type {$pt_in}
              AND (pm.meta_value IS NULL OR pm.meta_value = '')
            ORDER BY p.post_date DESC
            LIMIT %d
        ", $max_per_type ) );
        foreach ( $no_thumb as $pid ) {
            $pid = (int) $pid;
            $id = self::propose(
                'content_quality',
                'add_featured_image',
                $pid,
                array(
                    'reason'     => 'Pas d\'image mise en avant — pas d\'og:image pour le partage social ni de visuel en recherche',
                    'suggestion' => 'Ajouter une image mise en avant (DALL-E ou bibliothèque média)',
                ),
                'low'
            );
            if ( $id && $id !== true ) { $proposed++; }
            $scanned++;
        }

        // ── 7. Liens internes faibles — pages avec 0-1 lien interne ──
        // S16 Fix P5: exclude pages that already had a linking action applied (done) in last 30 days
        if ( ! $time_check() ) return array( 'scanned' => $scanned, 'proposed' => $proposed, 'partial' => true );
        $thirty_days_ago = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
        // Pre-fetch recently linked post IDs (fast indexed query on actions table)
        $recently_linked = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$table} WHERE agent = 'linking' AND status = 'done' AND resolved_at >= %s",
            $thirty_days_ago
        ) );
        $exclude_clause = '';
        if ( ! empty( $recently_linked ) ) {
            $exclude_clause = ' AND p.ID NOT IN (' . implode( ',', array_map( 'intval', $recently_linked ) ) . ')';
        }
        $orphans = $wpdb->get_col( $wpdb->prepare( "
            SELECT p.ID FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} il ON p.ID = il.post_id AND il.meta_key = '_hts_internal_links_out'
            WHERE p.post_type IN ('post','page') AND p.post_status = 'publish'
              AND (il.meta_value IS NULL OR il.meta_value + 0 <= 1)
              {$exclude_clause}
            ORDER BY p.post_date DESC
            LIMIT %d
        ", $max_per_type ) );
        foreach ( $orphans as $pid ) {
            $pid = (int) $pid;
            $id = self::propose(
                'linking',
                'add_internal_links',
                $pid,
                array(
                    'reason'     => 'Page isolée — peu ou pas de liens internes vers d\'autres contenus',
                    'suggestion' => 'Ajouter 2-3 liens vers des articles connexes pour transférer l\'autorité',
                ),
                'low'
            );
            if ( $id && $id !== true ) { $proposed++; }
            $scanned++;
        }

        // ── 8. Cocon-aware linking — specific target+anchor proposals from cluster analysis ──
        // Sprint Robustesse: heavy AI anchor scan runs ONLY in cron mode to avoid
        // saturating the server when user triggers manual scan while articles are generating.
        // Manual mode gets lightweight proposals from section 7 (PHP-only anchors).
        if ( $is_cron && class_exists( 'HTS_Internal_Linking' ) && self::is_agent_enabled( 'linking' ) && $time_check() ) {
            // Concurrency guard: skip if another heavy job is running (article generation, image generation)
            $busy = get_transient( 'hts_heavy_job_running' );
            if ( $busy ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Linking cron skipped: heavy job running (' . $busy . ')', 'info', 'linking' );
                }
            } else {
                set_transient( 'hts_heavy_job_running', 'cron_linking', 300 ); // 5 min TTL
                $linker = new \HTS_Internal_Linking();
                if ( method_exists( $linker, 'cron_scan_linking' ) ) {
                    $linker->cron_scan_linking();
                    global $wpdb;
                    $linking_table = $wpdb->prefix . self::ACTIONS_TABLE;
                    $new_linking = (int) $wpdb->get_var( $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$linking_table} WHERE agent = 'linking' AND status = 'pending' AND created_at >= %s",
                        gmdate( 'Y-m-d H:i:s', time() - 60 )
                    ) );
                    $proposed += $new_linking;
                }
                delete_transient( 'hts_heavy_job_running' );
            }
        }

        // ── 9. Images sans ALT — sprint 6.3c — scan robuste multi-builder ──
        if ( $time_check() ) {

        // Étape 1 : récupérer toutes les images sans ALT
        $all_no_alt = $wpdb->get_results( "
            SELECT att.ID AS att_id, att.guid, att.post_parent
            FROM {$wpdb->posts} att
            LEFT JOIN {$wpdb->postmeta} alt_meta
                ON att.ID = alt_meta.post_id AND alt_meta.meta_key = '_wp_attachment_image_alt'
            WHERE att.post_type = 'attachment'
              AND att.post_mime_type LIKE 'image/%'
              AND (alt_meta.meta_value IS NULL OR alt_meta.meta_value = '')
            ORDER BY att.ID DESC
            LIMIT 300
        " );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'ALT scan: %d images sans ALT trouvées', count( $all_no_alt ) ), 'info', 'workflow' );
        }

        // Étape 2 : pour les images orphelines (post_parent=0), construire un index
        // filename → post_id en scannant les post_content des articles publiés
        $orphan_filenames = array();
        foreach ( $all_no_alt as $att ) {
            if ( (int) $att->post_parent <= 0 ) {
                $fn = basename( $att->guid );
                if ( $fn ) $orphan_filenames[ $fn ] = (int) $att->att_id;
            }
        }

        $filename_to_post = array(); // filename => post_id
        if ( ! empty( $orphan_filenames ) && $time_check() ) {
            // Charger les post_content + _elementor_data en une seule passe
            $published = $wpdb->get_results( "
                SELECT p.ID, p.post_content, em.meta_value AS el_data
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} em ON p.ID = em.post_id AND em.meta_key = '_elementor_data'
                WHERE p.post_type IN ('post','page')
                  AND p.post_status = 'publish'
                LIMIT 500
            " );
            foreach ( $published as $pub ) {
                $haystack = $pub->post_content . ( $pub->el_data ?: '' );
                foreach ( $orphan_filenames as $fn => $att_id ) {
                    if ( isset( $filename_to_post[ $fn ] ) ) continue; // Déjà trouvé
                    if ( stripos( $haystack, $fn ) !== false ) {
                        $filename_to_post[ $fn ] = (int) $pub->ID;
                    }
                }
            }
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'ALT scan: %d orphelins, %d retrouvés dans des articles', count( $orphan_filenames ), count( $filename_to_post ) ), 'info', 'workflow' );
        }

        // Étape 3 : grouper par article
        $by_post = array();
        foreach ( $all_no_alt as $att ) {
            $pid = (int) $att->post_parent;

            if ( $pid <= 0 ) {
                $fn = basename( $att->guid );
                $pid = $filename_to_post[ $fn ] ?? 0;
            }

            if ( $pid <= 0 ) continue;

            if ( ! isset( $by_post[ $pid ] ) ) {
                $p = get_post( $pid );
                if ( ! $p || $p->post_status !== 'publish' || ! in_array( $p->post_type, array( 'post', 'page' ), true ) ) continue;
                $by_post[ $pid ] = array( 'images' => array() );
            }

            $thumb_url = wp_get_attachment_image_url( (int) $att->att_id, 'thumbnail' );
            $by_post[ $pid ]['images'][] = array(
                'id'        => (int) $att->att_id,
                'filename'  => basename( $att->guid ),
                'thumb_url' => $thumb_url ?: $att->guid,
                'edit_url'  => admin_url( 'post.php?post=' . $att->att_id . '&action=edit' ),
            );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'ALT scan: %d articles avec images sans ALT', count( $by_post ) ), 'info', 'workflow' );
        }

        // Étape 4 : proposer
        $alt_proposed = 0;
        foreach ( $by_post as $pid => $info ) {
            if ( ! $time_check() || $alt_proposed >= $max_per_type ) break;
            $missing = count( $info['images'] );

            $id = self::propose(
                'content_quality',
                'fix_image_alt',
                (int) $pid,
                array(
                    'reason'        => sprintf( '%d image(s) sans attribut ALT — invisible pour Google Images et les lecteurs d\'écran', $missing ),
                    'suggestion'    => 'Générer des ALT descriptifs optimisés via IA',
                    'missing_count' => $missing,
                    'total_images'  => $missing,
                    'images'        => array_slice( $info['images'], 0, 10 ),
                ),
                $missing >= 3 ? 'medium' : 'low'
            );
            if ( $id && $id !== true ) { $proposed++; $alt_proposed++; }
            $scanned++;
        }
        } // end time_check section 9

        // Sprint 6.3c: log durée totale du scan
        // Flush batch sync: send all collected actions in ONE call
        $queue_count = is_array( self::$batch_sync_queue ) ? count( self::$batch_sync_queue ) : 0;
        hts_debug_log( '[BATCH] scan_proposals END — queue_count=' . $queue_count . ' available=' . ( class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ? 'YES' : 'NO' ) );
        if ( ! empty( self::$batch_sync_queue ) && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $batches = array_chunk( self::$batch_sync_queue, 200 );
            foreach ( $batches as $i => $batch ) {
                $result = HTS_Remote_Client::call( 'sync/actions', array( 'actions' => $batch ), 'POST', array( 'timeout' => 10, 'retries' => 1 ) );
                hts_debug_log( '[BATCH] Flushed batch ' . ( $i + 1 ) . '/' . count( $batches ) . ' (' . count( $batch ) . ' actions) — result=' . ( ! empty( $result['success'] ) ? 'OK synced=' . ( $result['data']['synced'] ?? '?' ) : 'FAIL ' . ( $result['error'] ?? '?' ) ) );
            }
        } elseif ( $queue_count > 0 ) {
            hts_debug_log( '[BATCH] Queue has ' . $queue_count . ' actions but Remote Client not available — NOT flushed' );
        }
        self::$batch_sync_queue = null; // Disable batch mode

        if ( function_exists( 'hts_add_log' ) ) {
            $elapsed = round( microtime( true ) - $scan_start, 1 );
            hts_add_log( sprintf( 'Inbox scan terminé en %ss — %d scanné(s), %d proposé(s)', $elapsed, $scanned, $proposed ), 'info', 'workflow' );
        }

        return array( 'scanned' => $scanned, 'proposed' => $proposed );
    }

    /* ═══════════════════════════════════════════════
     *  DISMISS — Ignorer sans rejeter (v2.1)
     * ═══════════════════════════════════════════════ */

    /**
     * Ignorer une action (le client ne veut pas la traiter maintenant).
     * Différent de reject : dismissed = "pas maintenant", rejected = "jamais".
     *
     * @since 2.1.0
     * @param int $id Action ID
     * @return bool
     */
    public static function dismiss( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $action = self::get_action( $id );
        if ( ! $action || $action->status !== self::STATUS_PENDING ) {
            return false;
        }

        $ok = (bool) $wpdb->update( $table,
            array(
                'status'      => self::STATUS_DISMISSED,
                'resolved_at' => current_time( 'mysql' ),
                'resolved_by' => get_current_user_id(),
            ),
            array( 'id' => $id )
        );

        // Pause 30j après 3 dismiss sur le même article source (linking)
        if ( $ok && $action->agent === 'linking' ) {
            $post_id       = (int) $action->post_id;
            $dismiss_key   = 'hts_linking_dismiss_count_' . $post_id;
            $dismiss_count = (int) get_post_meta( $post_id, $dismiss_key, true );
            $dismiss_count++;
            update_post_meta( $post_id, $dismiss_key, $dismiss_count );

            if ( $dismiss_count >= 3 ) {
                update_post_meta( $post_id, '_hts_linking_paused', time() + 30 * DAY_IN_SECONDS );
                if ( function_exists( 'hts_debug_log' ) ) {
                    hts_debug_log( '[Linking] Pause 30j sur #' . $post_id . ' après ' . $dismiss_count . ' dismiss' );
                }
            }
        }

        return $ok;
    }

    /* ═══════════════════════════════════════════════
     *  LABELS — Non-expert, sans jargon (v2.1)
     * ═══════════════════════════════════════════════ */

    /**
     * Labels humains pour chaque agent.
     * Pas de jargon, pas de code technique.
     *
     * @since 2.1.0
     * @return array { agent_slug => label }
     */
    public static function get_agent_labels() {
        return array(
            'coach'       => 'Coach SEO',
            'fresh'       => 'Fraîcheur contenu',
            'geo_score'   => 'Visibilité IA',
            'meta'        => 'Optimisation meta',
            'linking'     => 'Maillage interne',
            'cannib'      => 'Anti-cannibalisation',
            'strategy'    => 'Stratégie SEO',
            'auto_write'      => 'Rédaction auto',
            'image'           => 'Images IA',
            'content_quality' => 'Qualité contenu',
            'monitoring'      => 'Surveillance',
        );
    }

    /**
     * Labels humains pour chaque type d'action.
     *
     * @since 2.1.0
     * @return array { action_type => label }
     */
    public static function get_action_labels() {
        return array(
            'add_meta_title'       => 'Générer un titre SEO',
            'add_meta_desc'        => 'Générer une description SEO',
            'add_faq'              => 'Ajouter une section FAQ',
            'add_internal_links'   => 'Proposer des liens internes',
            'enrich_thin_content'  => 'Enrichir un contenu trop court',
            'add_featured_image'   => 'Ajouter une image mise en avant',
            'fix_image_alt'        => 'Corriger les ALT des images',
            'content_refresh'      => 'Rafraîchir le contenu',
            'geo_optimize'       => 'Optimiser pour les moteurs IA',
            'delete_page'        => 'Mettre en corbeille',
            'merge'              => 'Fusionner avec un autre article',
            'redirect'           => 'Créer une redirection',
            'differentiate'      => 'Différencier le contenu',
            'article_write'      => 'Rédiger un nouvel article',
            'schedule_publish'   => 'Planifier la publication',
            'coach_suggestion'   => 'Suggestion du Coach',
            // Sprint 5.1: labels for new Coach action types
            'fix_orphan_links'      => 'Corriger les pages orphelines',
            'schedule_publication'  => 'Programmer la publication',
            'generate_article'      => 'Générer un article SEO',
            'optimize_meta_both'    => 'Optimiser titre + description',
            'optimize_meta_title'   => 'Optimiser le meta title',
            'optimize_meta_desc'    => 'Optimiser la meta description',
            'create_cocon_articles' => 'Créer les articles du cocon',
            'bulk_optimize_metas'   => 'Optimiser les metas en masse',
        );
    }

    /* ═══════════════════════════════════════════════
     *  HELPERS
     * ═══════════════════════════════════════════════ */

    /**
     * S'assurer que les tables existent (lazy creation).
     */
    public static function ensure_tables() {
        if ( ! self::tables_exist() ) {
            self::create_tables();
        }
    }

    /**
     * Cron callback : nettoyer les vieilles actions.
     */
    public static function cron_cleanup() {
        $deleted = self::cleanup_old_actions( 90 );
        if ( $deleted > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Workflow cleanup : {$deleted} action(s) expirées supprimées", 'info', 'workflow' );
        }
    }

    /**
     * Nettoyer les vieilles actions (> 90 jours, résolues).
     */
    public static function cleanup_old_actions( $days = 90 ) {
        global $wpdb;
        $table = $wpdb->prefix . self::ACTIONS_TABLE;

        $cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
        return $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE status IN ('done','rejected','dismissed','failed','blocked') AND resolved_at < %s",
            $cutoff
        ) );
    }

    /* ═══════════════════════════════════════════════
     *  SAAS SYNC — one-time actions history push
     * ═══════════════════════════════════════════════ */

    /**
     * Sync the last 90 days of workflow actions to the SaaS backend.
     *
     * Sends actions in batches of 100 to POST /api/v1/sync/actions.
     * Runs only once: sets hts_remote_sync_done = 1 in wp_options on completion.
     */
    public static function sync_actions_to_saas() {
        // Guard: only run once
        if ( get_option( 'hts_remote_sync_done', false ) ) {
            return;
        }

        if ( ! class_exists( 'HTS_Remote_Client' ) || ! HTS_Remote_Client::is_available() ) {
            return;
        }

        global $wpdb;
        $table  = $wpdb->prefix . self::ACTIONS_TABLE;
        $cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-90 days' ) );

        // BUG 1 FIX: Filter out corrupted/useless actions before sync
        $actions = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE created_at >= %s AND type != 'unknown' AND status NOT IN ('rollbacked','dismissed') ORDER BY created_at ASC",
            $cutoff
        ), ARRAY_A );

        if ( empty( $actions ) ) {
            update_option( 'hts_remote_sync_done', 1, false );
            return;
        }

        // Map WP column names to SaaS expected names
        $mapped = array();
        foreach ( $actions as $a ) {
            $mapped[] = array(
                'action_type' => isset( $a['type'] ) ? $a['type'] : ( isset( $a['action_type'] ) ? $a['action_type'] : 'unknown' ),
                'post_id'     => (int) ( isset( $a['post_id'] ) ? $a['post_id'] : 0 ),
                'status'      => isset( $a['status'] ) ? $a['status'] : 'pending',
                'priority'    => 50,
                'lang'        => '',
                'created_at'  => isset( $a['created_at'] ) ? $a['created_at'] : '',
            );
        }

        $batches = array_chunk( $mapped, 100 );
        $all_ok  = true;

        foreach ( $batches as $batch ) {
            $result = HTS_Remote_Client::call( 'sync/actions', array(
                'actions' => $batch,
            ), 'POST', array( 'timeout' => 10, 'retries' => 1 ) );

            if ( empty( $result['success'] ) ) {
                $all_ok = false;
                if ( function_exists( 'hts_add_log' ) ) {
                    $err = isset( $result['error'] ) ? $result['error'] : 'unknown';
                    hts_add_log( 'Workflow sync batch failed: ' . $err, 'warning', 'workflow-sync' );
                }
                break; // Stop sending further batches on failure
            }
        }

        // Always mark as done — bulk sync is best-effort, batch sync from audit covers the rest
        update_option( 'hts_remote_sync_done', 1, false );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( 'Workflow sync_actions_to_saas done (ok=' . ( $all_ok ? 'yes' : 'partial' ) . ', actions=' . count( $actions ) . ')', 'info', 'workflow-sync' );
        }
    }
}
