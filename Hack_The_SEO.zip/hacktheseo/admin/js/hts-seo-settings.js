/**
 * Hack The SEO — SEO Settings JS
 *
 * - AJAX save all SEO settings
 * - Live SERP preview (title + desc)
 * - Schema Organization JSON preview
 * - Separator picker
 * - Char counters
 * - Import competitor settings
 * - Module toggle cards
 *
 * @since 3.3.1
 */

document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    // ── Safety shim: guarantee htsAdmin exists even if bootstrap JS fails ──
    if (typeof htsAdmin === 'undefined') {
        window.htsAdmin = {
            ajaxUrl: (typeof ajaxurl !== 'undefined') ? ajaxurl : '/wp-admin/admin-ajax.php',
            nonce:   '',
            lang:    { isMultilingual: false, currentLang: '', languages: [] }
        };
        // htsAdmin shimmed — nonce empty, saves may fail
    }

    var form = document.getElementById('hts-seo-settings-form');
    if (!form) return;

    // =========================================================================
    // SEPARATOR PICKER
    // =========================================================================
    var sepBtns = document.querySelectorAll('.hts-sep-btn');
    var sepInput = document.getElementById('hts-title-sep');

    sepBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            sepBtns.forEach(function (b) { b.classList.remove('active'); });
            btn.classList.add('active');
            sepInput.value = btn.dataset.sep;
            updateSerpPreview();
        });
    });

    // =========================================================================
    // CHAR COUNTERS
    // =========================================================================
    function setupCharCounter(inputId, countId, warnAt, dangerAt) {
        var input = document.getElementById(inputId);
        var count = document.getElementById(countId);
        if (!input || !count) return;

        function update() {
            var len = input.value.length;
            count.textContent = len;
            var parent = count.closest('.hts-char-count');
            parent.classList.remove('warn', 'danger');
            if (len > dangerAt) parent.classList.add('danger');
            else if (len > warnAt) parent.classList.add('warn');
        }

        input.addEventListener('input', update);
        update();
    }

    setupCharCounter('hts-home-title', 'hts-home-title-count', 55, 65);
    setupCharCounter('hts-home-desc', 'hts-home-desc-count', 150, 165);

    // =========================================================================
    // LIVE SERP PREVIEW
    // =========================================================================
    var titleInput = document.getElementById('hts-home-title');
    var descInput  = document.getElementById('hts-home-desc');
    var serpTitle   = document.getElementById('hts-serp-title');
    var serpDesc    = document.getElementById('hts-serp-desc');

    function updateSerpPreview() {
        if (!serpTitle || !serpDesc) return;

        var title = titleInput.value || titleInput.placeholder;
        var desc  = descInput.value || descInput.placeholder;
        var sep   = sepInput ? sepInput.value : '—';

        // Resolve common SEO variables (imported from Rank Math / Yoast)
        var siteName = document.querySelector('.hts-serp-url') ? '' : '';
        // Extract site name from URL or use title placeholder
        var siteUrl = (document.querySelector('.hts-serp-url') || {}).textContent || '';
        var resolvedSiteName = titleInput.placeholder || '';
        // Common variable patterns
        var vars = {
            '%sitename%': resolvedSiteName,
            '%sep%': sep,
            '%page%': '',
            '%sitedesc%': descInput.placeholder || '',
            '%%sitename%%': resolvedSiteName,
            '%%sep%%': sep,
            '%%page%%': '',
            '%%sitedesc%%': descInput.placeholder || ''
        };
        Object.keys(vars).forEach(function(v) {
            title = title.split(v).join(vars[v]);
            desc = desc.split(v).join(vars[v]);
        });
        // Clean up extra spaces from resolved empty variables
        title = title.replace(/\s{2,}/g, ' ').trim();
        desc = desc.replace(/\s{2,}/g, ' ').trim();

        serpTitle.textContent = title || resolvedSiteName;
        serpDesc.textContent  = desc;
    }

    if (titleInput) titleInput.addEventListener('input', updateSerpPreview);
    if (descInput)  descInput.addEventListener('input', updateSerpPreview);

    // =========================================================================
    // SCHEMA PREVIEW TOGGLE
    // =========================================================================
    var schemaToggle = document.getElementById('hts-schema-preview-toggle');
    var schemaBody   = document.getElementById('hts-schema-preview-body');
    var schemaArrow  = document.getElementById('hts-schema-arrow');
    var schemaJson   = document.getElementById('hts-schema-json');

    if (schemaToggle) {
        schemaToggle.addEventListener('click', function () {
            var visible = schemaBody.style.display !== 'none';
            schemaBody.style.display = visible ? 'none' : 'block';
            schemaArrow.classList.toggle('open', !visible);
            if (!visible) updateSchemaPreview();
        });
    }

    function updateSchemaPreview() {
        if (!schemaJson) return;

        var siteName = titleInput ? (titleInput.value || titleInput.placeholder) : '';
        var siteUrl  = (document.querySelector('.hts-serp-url') || {}).textContent || '';

        var socials = [];
        var socialInputs = document.querySelectorAll('[name^="social_"]');
        socialInputs.forEach(function (inp) {
            if (inp.name === 'social_profiles') return; // skip hidden
            var val = inp.value.trim();
            if (val) socials.push(val);
        });

        var schema = {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": siteName,
            "url": siteUrl.trim()
        };

        if (socials.length > 0) {
            schema.sameAs = socials;
        }

        schemaJson.textContent = JSON.stringify(schema, null, 2);
    }

    // =========================================================================
    // MODULE TOGGLE CARDS
    // =========================================================================
    var toggleCards = document.querySelectorAll('.hts-toggle-card');
    toggleCards.forEach(function (card) {
        card.addEventListener('click', function () {
            var cb = card.querySelector('input[type="checkbox"]');
            cb.checked = !cb.checked;
            card.classList.toggle('active', cb.checked);
        });
    });

    // =========================================================================
    // IMPORT COMPETITOR SETTINGS
    // =========================================================================
    var importBtn = document.getElementById('hts-import-competitor');
    if (importBtn) {
        importBtn.addEventListener('click', function () {
            importBtn.disabled = true;
            importBtn.textContent = 'Import en cours…';

            fetch(htsAdmin.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'hts_seo_import_competitor',
                    nonce:  htsAdmin.nonce
                })
            })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success && data.data) {
                    var d = data.data;
                    // Fill empty fields with imported values
                    if (d.home_title && !titleInput.value)
                        titleInput.value = d.home_title;
                    if (d.home_description && !descInput.value)
                        descInput.value = d.home_description;
                    if (d.twitter_handle) {
                        var th = document.getElementById('hts-twitter-handle');
                        if (th && !th.value) th.value = d.twitter_handle;
                    }
                    if (d.social_profiles) {
                        Object.keys(d.social_profiles).forEach(function (key) {
                            var inp = document.getElementById('hts-social-' + key);
                            if (inp && !inp.value && d.social_profiles[key]) {
                                inp.value = d.social_profiles[key];
                            }
                        });
                    }

                    updateSerpPreview();
                    showSeoAlert('success', '✓ Réglages importés depuis ' + (d.source || 'concurrent') + '. Vérifiez et sauvegardez.');
                } else {
                    showSeoAlert('danger', 'Erreur : ' + ((data.data && data.data.message) || 'import impossible'));
                }
                importBtn.disabled = false;
                importBtn.textContent = 'Réglages importés ✓';
            })
            .catch(function (err) {
                importBtn.disabled = false;
                importBtn.textContent = 'Réessayer';
                showSeoAlert('danger', 'Erreur réseau : ' + err.message);
            });
        });
    }

    // =========================================================================
    // SAVE FORM
    // =========================================================================
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        var btn = document.getElementById('hts-seo-save');
        var btnTop = document.getElementById('hts-seo-save-top');
        btn.classList.add('hts-btn--loading');
        btn.disabled = true;
        if (btnTop) { btnTop.disabled = true; btnTop.textContent = '…'; }

        // Collect social profiles
        var socialProfiles = {};
        var socialKeys = ['facebook','twitter','linkedin','youtube','instagram','tiktok','pinterest','github'];
        socialKeys.forEach(function (key) {
            var inp = document.getElementById('hts-social-' + key);
            if (inp && inp.value.trim()) {
                socialProfiles[key] = inp.value.trim();
            }
        });

        // Collect module toggles
        var modules = {};
        toggleCards.forEach(function (card) {
            var cb = card.querySelector('input[type="checkbox"]');
            var name = cb.name.replace('module_', '');
            modules[name] = cb.checked ? '1' : '0';
        });

        var payload = {
            action:           'hts_save_seo_settings',
            nonce:            htsAdmin.nonce,
            home_title:       (titleInput.value || '').trim(),
            home_description: (descInput.value || '').trim(),
            title_separator:  sepInput.value,
            twitter_handle:   (document.getElementById('hts-twitter-handle').value || '').trim(),
            social_profiles:  JSON.stringify(socialProfiles),
            modules:          JSON.stringify(modules)
        };

        // Local SEO fields
        var localFields = ['name','phone','address','city','postal_code','country','email','url','lat','lng','price_range','opening_hours'];
        var localData = {};
        localFields.forEach(function (key) {
            var fieldId = 'hts-local-' + key.replace('_', '-').replace('postal-code', 'postal').replace('price-range', 'price').replace('opening-hours', 'hours');
            // Map field keys to input IDs
            var idMap = {
                'name': 'hts-local-name', 'phone': 'hts-local-phone', 'address': 'hts-local-address',
                'city': 'hts-local-city', 'postal_code': 'hts-local-postal', 'country': 'hts-local-country',
                'email': 'hts-local-email', 'url': 'hts-local-url', 'lat': 'hts-local-lat', 'lng': 'hts-local-lng',
                'price_range': 'hts-local-price', 'opening_hours': 'hts-local-hours'
            };
            var inp = document.getElementById(idMap[key]);
            if (inp) localData[key] = inp.value.trim();
        });
        payload.local_seo = JSON.stringify(localData);

        // Sitemap settings
        var sitemapData = {};
        var smPtToggles = document.querySelectorAll('.sm-pt-toggle');
        if (smPtToggles.length > 0) {
            sitemapData.post_types = [];
            smPtToggles.forEach(function (cb) {
                if (cb.checked) sitemapData.post_types.push(cb.value);
            });
            var smImages = document.getElementById('sm-images');
            var smTaxonomy = document.getElementById('sm-taxonomy');
            var smCocon = document.getElementById('sm-cocon');
            var smPingGoogle = document.getElementById('sm-ping-google');
            var smPingBing = document.getElementById('sm-ping-bing');
            var smLegacy = document.getElementById('sm-legacy');
            var smMaxUrls = document.getElementById('sm-max-urls');
            if (smImages) sitemapData.image_sitemap = smImages.checked;
            if (smTaxonomy) sitemapData.taxonomy_sitemap = smTaxonomy.checked;
            if (smCocon) sitemapData.cocon_sitemaps = smCocon.checked;
            if (smPingGoogle) sitemapData.ping_google = smPingGoogle.checked;
            if (smPingBing) sitemapData.ping_bing = smPingBing.checked;
            if (smLegacy) sitemapData.include_legacy_tags = smLegacy.checked;
            if (smMaxUrls) sitemapData.max_urls_per_sitemap = parseInt(smMaxUrls.value);
        }
        payload.sitemap_settings = JSON.stringify(sitemapData);

        // Notification settings
        var notifFreqEl = document.querySelector('input[name="hts_notif_freq"]:checked');
        var notifSections = {};
        ['wins', 'alerts', 'kpis', 'gsc'].forEach(function(key) {
            var cb = document.querySelector('input[name="hts_notif_section_' + key + '"]');
            notifSections[key] = cb && cb.checked ? '1' : '0';
        });
        payload.notif_settings = JSON.stringify({
            frequency: notifFreqEl ? notifFreqEl.value : 'weekly',
            sections: notifSections
        });
        var notifEmailInput = document.getElementById('hts-notif-email');
        if (notifEmailInput && notifEmailInput.value.trim()) {
            payload.notif_email = notifEmailInput.value.trim();
        }

        // Robots global rules
        var robotsGlobal = {};
        document.querySelectorAll('.robots-global-cb').forEach(function (cb) {
            var type = cb.dataset.type;
            var directive = cb.dataset.directive;
            if (!robotsGlobal[type]) robotsGlobal[type] = [];
            if (cb.checked) robotsGlobal[type].push(directive);
        });
        payload.robots_global = JSON.stringify(robotsGlobal);

        // Breadcrumbs settings (activation controlled by module toggle, not here)
        var bcSep = document.getElementById('bc-separator');
        var bcHome = document.getElementById('bc-home-label');
        var bcMax = document.getElementById('bc-max-chars');
        if (bcSep) {
            payload.breadcrumbs_settings = JSON.stringify({
                enabled: '1',
                separator: bcSep.value,
                home_label: bcHome ? bcHome.value : 'Accueil',
                max_title_chars: bcMax ? parseInt(bcMax.value) || 60 : 60
            });
        }

        // Schema auto-detected types
        var schemaToggles = document.querySelectorAll('.schema-auto-toggle');
        if (schemaToggles.length) {
            var schemaTypes = {};
            schemaToggles.forEach(function(cb) {
                schemaTypes[cb.dataset.type] = cb.checked ? '1' : '0';
            });
            payload.schema_auto_types = JSON.stringify(schemaTypes);
        }

        // llms.txt settings
        var llmstxtEnabled = document.getElementById('llmstxt-enabled');
        var llmstxtMode = document.getElementById('llmstxt-mode');
        if (llmstxtEnabled) {
            payload.llmstxt_settings = JSON.stringify({
                enabled: llmstxtEnabled.value,
                mode: llmstxtMode ? llmstxtMode.value : 'auto'
            });
        }

        // TOC settings
        var tocDepth = document.getElementById('toc-depth');
        var tocMin = document.getElementById('toc-min');
        var tocStyle = document.getElementById('toc-style');
        if (tocDepth) {
            payload.toc_settings = JSON.stringify({
                depth: tocDepth.value,
                min: tocMin ? parseInt(tocMin.value) || 3 : 3,
                style: tocStyle ? tocStyle.value : 'hts'
            });
        }

        // Webmaster verification
        var wmGoogle = document.getElementById('wm-google');
        if (wmGoogle) {
            payload.webmaster_verification = JSON.stringify({
                google: wmGoogle.value.trim(),
                bing: (document.getElementById('wm-bing') || {}).value || '',
                pinterest: (document.getElementById('wm-pinterest') || {}).value || '',
                yandex: (document.getElementById('wm-yandex') || {}).value || ''
            });
        }

        // OG default image
        var ogDefault = document.getElementById('og-default-image');
        if (ogDefault) payload.og_default_image = ogDefault.value.trim();

        // Robots.txt editor
        var robotstxtEditor = document.getElementById('robotstxt-editor');
        if (robotstxtEditor) {
            payload.robotstxt_custom = robotstxtEditor.value;
        }

        // IndexNow settings
        var indexnowEnabled = document.getElementById('indexnow-enabled');
        if (indexnowEnabled) {
            payload.indexnow_enabled = indexnowEnabled.value;
        }

        // Settings mode
        var modeRadio = document.querySelector('input[name="hts_mode"]:checked');
        if (modeRadio) payload.settings_mode = modeRadio.value;

        // Article default status
        var defaultStatus = document.getElementById('hts-default-status');
        if (defaultStatus) payload.article_default_status = defaultStatus.value;

        // Rel prev/next
        var relPrevNext = document.getElementById('hts-rel-prev-next');
        if (relPrevNext) payload.rel_prev_next = relPrevNext.checked ? '1' : '0';

        // Hreflang
        var hreflangEl = document.getElementById('hts-hreflang');
        if (hreflangEl) payload.hreflang = hreflangEl.checked ? '1' : '0';

        fetch(htsAdmin.ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(payload)
        })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            btn.classList.remove('hts-btn--loading');
            btn.disabled = false;
            if (btnTop) { btnTop.disabled = false; btnTop.textContent = 'Enregistrer'; }

            if (data.success) {
                showSeoAlert('success', '✓ Réglages SEO sauvegardés');
                // Scroll to top so the alert is visible
                var alertBox = document.getElementById('hts-seo-alert');
                if (alertBox) alertBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                // Remove fallback badges
                document.querySelectorAll('.hts-badge--info').forEach(function (b) { b.remove(); });
            } else {
                showSeoAlert('danger', (data.data && data.data.message) || 'Erreur sauvegarde');
            }
        })
        .catch(function (err) {
            btn.classList.remove('hts-btn--loading');
            btn.disabled = false;
            if (btnTop) { btnTop.disabled = false; btnTop.textContent = 'Enregistrer'; }
            showSeoAlert('danger', 'Erreur réseau : ' + err.message);
        });
    });

    // =========================================================================
    // ALERT HELPER
    // =========================================================================
    function _esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

    function showSeoAlert(type, message) {
        var box = document.getElementById('hts-seo-alert');
        if (!box) return;
        box.innerHTML = '<div class="hts-alert hts-alert--' + type + '" style="margin-bottom:16px;padding:12px 16px;border-radius:8px;font-size:14px;' +
            (type === 'success' ? 'background:var(--hts-success-bg);color:var(--hts-success);border:1px solid var(--hts-success);' : '') +
            (type === 'danger'  ? 'background:var(--hts-danger-bg);color:var(--hts-danger);border:1px solid var(--hts-danger);' : '') +
            (type === 'info'    ? 'background:var(--hts-info-bg);color:var(--hts-info);border:1px solid var(--hts-info);' : '') +
        '">' + _esc(message) + '</div>';
        setTimeout(function () { box.innerHTML = ''; }, 6000);
    }
});

// =========================================================================
// MODE TOGGLE: Amateur / Expert (outside DOMContentLoaded)
// =========================================================================
function htsToggleMode(mode) {
    var expertBlocks = document.querySelectorAll('.hts-expert-only');
    expertBlocks.forEach(function (el) {
        // Toggle hts-hidden class (has !important) instead of inline style
        if (mode === 'expert') {
            el.classList.remove('hts-hidden');
        } else {
            el.classList.add('hts-hidden');
        }
    });
    // Update label styles
    var amateur = document.getElementById('mode-amateur-label');
    var expert  = document.getElementById('mode-expert-label');
    var hint    = document.getElementById('mode-hint');
    if (amateur && expert) {
        if (mode === 'expert') {
            expert.classList.add('hts-mode-btn--active');
            amateur.classList.remove('hts-mode-btn--active');
        } else {
            amateur.classList.add('hts-mode-btn--active');
            expert.classList.remove('hts-mode-btn--active');
        }
    }
    if (hint) hint.textContent = mode === 'expert'
        ? 'Tous les réglages sont affichés'
        : 'Seuls les réglages essentiels sont affichés';

    // Save mode immediately via AJAX (no need to click "Enregistrer")
    if (typeof htsAdmin !== 'undefined' && htsAdmin.ajaxUrl) {
        fetch(htsAdmin.ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'hts_save_settings_mode',
                nonce:  htsAdmin.nonce,
                mode:   mode
            })
        }).catch(function() { /* silent — will be saved with next full save anyway */ });
    }
}

// =========================================================================
// MEDIA PICKER for OG default image
// =========================================================================
function htsMediaPicker(targetId) {
    if (!wp || !wp.media) { alert('Erreur: le media picker WP n\'est pas disponible.'); return; }
    var frame = wp.media({ title: 'Choisir une image', multiple: false, library: { type: 'image' } });
    frame.on('select', function () {
        var attachment = frame.state().get('selection').first().toJSON();
        var input = document.getElementById(targetId);
        if (input) input.value = attachment.url;
    });
    frame.open();
}

// =========================================================================
// LLMS.TXT — Preview & Refresh
// =========================================================================
document.addEventListener('DOMContentLoaded', function() {
    var previewBtn = document.getElementById('llmstxt-preview-btn');
    var refreshBtn = document.getElementById('llmstxt-refresh-btn');
    var previewBox = document.getElementById('llmstxt-preview-box');
    var statusEl   = document.getElementById('llmstxt-status');

    function llmstxtAjax(action, callback) {
        if (statusEl) statusEl.textContent = 'Chargement…';
        jQuery.post(ajaxurl, {
            action: action,
            nonce: (typeof htsAdmin !== 'undefined' ? htsAdmin.nonce : '') || ''
        }, function(response) {
            if (response.success) {
                callback(response.data);
            } else {
                if (statusEl) statusEl.textContent = '[ERREUR] Erreur';
            }
        }).fail(function() {
            if (statusEl) statusEl.textContent = '[ERREUR] Erreur réseau';
        });
    }

    if (previewBtn) {
        previewBtn.addEventListener('click', function() {
            // If already visible, just hide (toggle behavior)
            if (previewBox && previewBox.style.display === 'block') {
                previewBox.style.display = 'none';
                previewBtn.textContent = 'Aperçu';
                return;
            }
            llmstxtAjax('hts_llmstxt_preview', function(data) {
                if (previewBox) {
                    previewBox.textContent = data.content;
                    previewBox.style.display = 'block';
                    previewBtn.textContent = 'Masquer';
                }
                if (statusEl) statusEl.textContent = '' + data.url_count + ' URLs • ' + data.url;
            });
        });
    }

    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            llmstxtAjax('hts_llmstxt_refresh', function(data) {
                if (previewBox) {
                    previewBox.textContent = data.content;
                    previewBox.style.display = 'block';
                }
                if (statusEl) statusEl.textContent = '[OK] Régénéré — ' + data.url_count + ' URLs';
            });
        });
    }
});

// =========================================================================
// ROBOTS.TXT EDITOR — Live validation only
// =========================================================================
document.addEventListener('DOMContentLoaded', function() {
    var editor     = document.getElementById('robotstxt-editor');
    var warningsEl = document.getElementById('robotstxt-warnings');

    if (!editor) return;

    function validateEditor() {
        if (!warningsEl) return;
        var content = editor.value;
        var warnings = [];

        var lines = content.split('\n');
        var currentUA = '';
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (line === '' || line.charAt(0) === '#') continue;
            if (line.toLowerCase().indexOf('user-agent:') === 0) {
                currentUA = line.substring(11).trim();
            }
            if (/^disallow:\s*\/\s*$/i.test(line) && currentUA === '*') {
                warnings.push('<strong>Disallow: /</strong> détecté pour User-agent: * — bloque tous les moteurs de recherche !');
            }
        }
        if (/disalow:|dissallow:/i.test(content)) {
            warnings.push('[!] Faute de frappe détectée : vérifiez l\'orthographe de <strong>Disallow</strong>.');
        }

        if (warnings.length > 0) {
            warningsEl.innerHTML = warnings.map(function(w) {
                return '<div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:6px;padding:8px 12px;margin-bottom:6px;font-size:12px;color:#991b1b;">' + w + '</div>';
            }).join('');
            warningsEl.style.display = 'block';
        } else {
            warningsEl.style.display = 'none';
        }
    }

    editor.addEventListener('input', validateEditor);
    validateEditor();

    // Tab key support
    editor.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            e.preventDefault();
            var start = this.selectionStart;
            var end = this.selectionEnd;
            this.value = this.value.substring(0, start) + '    ' + this.value.substring(end);
            this.selectionStart = this.selectionEnd = start + 4;
        }
    });
});

// =========================================================================
// INDEXNOW — Ping & Key management
// =========================================================================
document.addEventListener('DOMContentLoaded', function() {
    var pingAllBtn  = document.getElementById('indexnow-ping-all');
    var resetKeyBtn = document.getElementById('indexnow-reset-key');
    var keyInput    = document.getElementById('indexnow-key');
    var statusEl    = document.getElementById('indexnow-status');

    if (pingAllBtn) {
        pingAllBtn.addEventListener('click', function() {
            if (!confirm('Envoyer les 50 derniers contenus modifiés à IndexNow ?')) return;
            pingAllBtn.disabled = true;
            pingAllBtn.textContent = 'Envoi en cours…';
            if (statusEl) statusEl.textContent = '';

            jQuery.post(ajaxurl, {
                action: 'hts_indexnow_ping_all',
                nonce: (typeof htsAdmin !== 'undefined' ? htsAdmin.nonce : '') || ''
            }, function(response) {
                if (response.success) {
                    if (statusEl) statusEl.textContent = '[OK] ' + response.data.message + ' (HTTP ' + response.data.code + ')';
                } else {
                    if (statusEl) statusEl.textContent = '[ERREUR] ' + (response.data || 'Erreur');
                }
                pingAllBtn.disabled = false;
                pingAllBtn.textContent = 'Ping les 50 derniers contenus';
            }).fail(function() {
                if (statusEl) statusEl.textContent = '[ERREUR] Erreur réseau';
                pingAllBtn.disabled = false;
                pingAllBtn.textContent = 'Ping les 50 derniers contenus';
            });
        });
    }

    if (resetKeyBtn) {
        resetKeyBtn.addEventListener('click', function() {
            if (!confirm('Régénérer la clé API IndexNow ? L\'ancienne clé ne sera plus valide.')) return;
            resetKeyBtn.disabled = true;

            jQuery.post(ajaxurl, {
                action: 'hts_indexnow_reset_key',
                nonce: (typeof htsAdmin !== 'undefined' ? htsAdmin.nonce : '') || ''
            }, function(response) {
                if (response.success) {
                    if (keyInput) keyInput.value = response.data.key;
                    if (statusEl) statusEl.textContent = 'Nouvelle clé générée';
                } else {
                    if (statusEl) statusEl.textContent = '[ERREUR] Erreur';
                }
                resetKeyBtn.disabled = false;
            }).fail(function() {
                if (statusEl) statusEl.textContent = '[ERREUR] Erreur réseau';
                resetKeyBtn.disabled = false;
            });
        });
    }
});
