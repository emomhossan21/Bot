<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Redirections & 404 Monitor
 *
 * Features:
 * - 404 monitoring with grouped logs (hit count, source, user-agent)
 * - AI Semantic Redirect: uses existing embeddings (0 API call)
 * - Slug Change Guardian: auto-301 when post_name changes
 * - Cocon-aware: deleted post → redirect to cluster pillar
 * - Regex Redirects for complex migrations
 * - Server method: PHP (universal) or .htaccess (faster)
 * - Import/Export CSV
 * - Dashboard: grouped logs, AI suggestions, 1-click actions
 *
 * @since 3.0.0
 */

class HTS_Redirects {

    const TABLE_404     = 'hts_404_log';
    const TABLE_RULES   = 'hts_redirects';
    const VERSION_KEY   = 'hts_redirects_db_version';
    const DB_VERSION    = '1.1';

    /* ══════════════════════════════════════════════
     *  INIT
     * ══════════════════════════════════════════════ */

    public function init() {
        // ── Cockpit guard: if module is OFF, no redirects/404 monitoring ──
        if ( get_option( 'hts_module_redirects', '1' ) !== '1' ) return;

        // Create tables on first load
        self::maybe_create_tables();

        // ── Migrate: add source column if missing (v1.1) ──
        self::maybe_migrate_tables();

        // ── Frontend: Monitor 404 ──
        if ( ! is_admin() ) {
            add_action( 'template_redirect', array( $this, 'handle_request' ), 1 );
        }

        // ── Slug Change Guardian ──
        add_action( 'post_updated', array( $this, 'slug_change_guardian' ), 10, 3 );

        // ── Post Trash/Delete → Cocon-aware redirect ──
        add_action( 'wp_trash_post', array( $this, 'on_post_trash' ) );

        // ── AJAX endpoints ──
        add_action( 'wp_ajax_hts_redirect_action',     array( $this, 'ajax_redirect_action' ) );
        add_action( 'wp_ajax_hts_404_action',           array( $this, 'ajax_404_action' ) );
        add_action( 'wp_ajax_hts_redirect_import_csv',  array( $this, 'ajax_import_csv' ) );
        add_action( 'wp_ajax_hts_redirect_export_csv',  array( $this, 'ajax_export_csv' ) );
        add_action( 'wp_ajax_hts_redirect_suggest_ai',  array( $this, 'ajax_suggest_ai' ) );
        add_action( 'wp_ajax_hts_redirect_bulk',        array( $this, 'ajax_bulk_action' ) );
        add_action( 'wp_ajax_hts_redirect_get_data',    array( $this, 'ajax_get_dashboard_data' ) );
        add_action( 'wp_ajax_hts_redirect_search_pages', array( $this, 'ajax_search_pages' ) );

        // ── Cron: cleanup old 404 logs ──
        add_action( 'hts_redirects_cleanup', array( $this, 'cron_cleanup' ) );
        if ( ! wp_next_scheduled( 'hts_redirects_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'hts_redirects_cleanup' );
        }
    }

    /* ══════════════════════════════════════════════
     *  DATABASE TABLES
     * ══════════════════════════════════════════════ */

    public static function maybe_create_tables() {
        if ( get_option( self::VERSION_KEY ) === self::DB_VERSION ) return;
        self::create_tables();
        update_option( self::VERSION_KEY, self::DB_VERSION );
    }

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        // ── 404 Log table ──
        $t404 = $wpdb->prefix . self::TABLE_404;
        $sql1 = "CREATE TABLE IF NOT EXISTS {$t404} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            url VARCHAR(2048) NOT NULL,
            url_hash CHAR(32) NOT NULL,
            referer VARCHAR(2048) DEFAULT '',
            user_agent VARCHAR(512) DEFAULT '',
            ip_hash CHAR(32) DEFAULT '',
            hit_count INT UNSIGNED NOT NULL DEFAULT 1,
            is_external TINYINT(1) NOT NULL DEFAULT 0,
            first_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status ENUM('new','redirected','ignored','suggested') NOT NULL DEFAULT 'new',
            suggested_target BIGINT(20) UNSIGNED DEFAULT NULL,
            suggested_score FLOAT DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY idx_url_hash (url_hash),
            KEY idx_status (status),
            KEY idx_hits (hit_count),
            KEY idx_last (last_seen)
        ) {$charset};";

        // ── Redirects rules table ──
        $tred = $wpdb->prefix . self::TABLE_RULES;
        $sql2 = "CREATE TABLE IF NOT EXISTS {$tred} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            source_url VARCHAR(2048) NOT NULL,
            source_hash CHAR(32) NOT NULL,
            target_url VARCHAR(2048) NOT NULL,
            redirect_type SMALLINT NOT NULL DEFAULT 301,
            is_regex TINYINT(1) NOT NULL DEFAULT 0,
            origin ENUM('manual','slug_change','ai_auto','ai_suggested','cocon','import','pattern') NOT NULL DEFAULT 'manual',
            hit_count INT UNSIGNED NOT NULL DEFAULT 0,
            last_hit DATETIME DEFAULT NULL,
            notes VARCHAR(500) DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            enabled TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (id),
            UNIQUE KEY idx_source_hash (source_hash),
            KEY idx_enabled (enabled),
            KEY idx_origin (origin)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql1 );
        dbDelta( $sql2 );
    }

    /**
     * Add new columns to existing tables (safe: checks if column exists first).
     */
    public static function maybe_migrate_tables() {
        global $wpdb;
        $t404 = $wpdb->prefix . self::TABLE_404;

        // v1.1: Add 'source' column to track where 404 was detected (monitor, gsc, import)
        $col_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = %s AND table_name = %s AND column_name = 'source'",
            DB_NAME, $t404
        ) );
        if ( ! $col_exists ) {
            $wpdb->query( "ALTER TABLE {$t404} ADD COLUMN source VARCHAR(20) NOT NULL DEFAULT 'monitor' AFTER suggested_score" );
        }
    }

    /* ══════════════════════════════════════════════
     *  FRONTEND: HANDLE REQUEST (404 + Redirect)
     * ══════════════════════════════════════════════ */

    public function handle_request() {
        // Skip admin, AJAX, cron
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) return;

        global $wpdb;
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $request_path = strtok( $request_uri, '?' ); // Strip query string for matching

        // ── Never redirect critical paths ──
        $safe_paths = array( '/', '/wp-admin', '/wp-login.php', '/wp-cron.php', '/xmlrpc.php' );
        $normalized_request = self::normalize_url( $request_path );
        foreach ( $safe_paths as $sp ) {
            if ( $normalized_request === self::normalize_url( $sp ) ) return;
        }

        // ── Check redirect rules ──
        $redirect = $this->find_redirect_rule( $request_path );
        if ( $redirect ) {
            $target = $redirect['target_url'];

            // Loop protection: don't redirect to self
            $target_path = wp_parse_url( $target, PHP_URL_PATH ) ?: $target;
            $current_path = self::normalize_url( $request_path );
            $target_norm  = self::normalize_url( $target_path );

            if ( $target_norm === $current_path ) {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( 'Redirect loop blocked: ' . $current_path . ' → ' . $target, 'warning', 'redirects' );
                }
                return;
            }

            // Update hit count
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}" . self::TABLE_RULES . " SET hit_count = hit_count + 1, last_hit = NOW() WHERE id = %d",
                $redirect['id']
            ) );

            $rtype = (int) $redirect['redirect_type'];

            // 410 Gone: no Location header, send proper HTTP 410 + noindex for fast deindexation
            if ( $rtype === 410 ) {
                status_header( 410 );
                header( 'X-Robots-Tag: noindex' );
                nocache_headers();
                if ( file_exists( get_404_template() ) ) {
                    include get_404_template();
                } else {
                    echo '<!DOCTYPE html><html><head><title>410 Gone</title></head><body><h1>410 Gone</h1><p>Cette page a été définitivement supprimée.</p></body></html>';
                }
                exit;
            }

            wp_redirect( $target, $rtype );
            exit;
        }

        // ── If 404, log it ──
        if ( is_404() ) {
            $this->log_404( $request_path );
        }
    }

    /**
     * Find matching redirect rule for a URI.
     * Priority: exact match > regex match.
     */
    private function find_redirect_rule( $uri ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_RULES;

        // Normalize URI
        $uri_clean = self::normalize_url( $uri );
        $hash      = md5( $uri_clean );

        // Exact match (indexed, fast)
        $exact = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE source_hash = %s AND enabled = 1 AND is_regex = 0 LIMIT 1",
            $hash
        ), ARRAY_A );

        if ( $exact ) return $exact;

        // Regex match (slower, only if we have regex rules)
        // Use transient (DB-backed) as fallback — wp_cache alone is per-request on most shared hosting.
        $regex_rules = wp_cache_get( 'hts_redirect_regex_rules' );
        if ( false === $regex_rules ) {
            $regex_rules = get_transient( 'hts_redirect_regex_rules' );
        }
        if ( false === $regex_rules || ! is_array( $regex_rules ) ) {
            $regex_rules = $wpdb->get_results(
                "SELECT * FROM {$table} WHERE is_regex = 1 AND enabled = 1 ORDER BY id ASC",
                ARRAY_A
            );
            wp_cache_set( 'hts_redirect_regex_rules', $regex_rules, '', 300 );
            set_transient( 'hts_redirect_regex_rules', $regex_rules, 300 );
        }

        foreach ( $regex_rules as $rule ) {
            $pattern = '@' . str_replace( '@', '\\@', $rule['source_url'] ) . '@i';
            if ( @preg_match( $pattern, $uri_clean, $matches ) ) {
                // Support backreferences in target ($1, $2, etc.)
                $target = preg_replace( $pattern, $rule['target_url'], $uri_clean );
                $rule['target_url'] = $target;
                return $rule;
            }
        }

        return null;
    }

    /* ══════════════════════════════════════════════
     *  404 LOGGING
     * ══════════════════════════════════════════════ */

    /**
     * Log a 404 hit. Groups by URL (increment hit_count if already exists).
     * Includes a safety check: verify the URL doesn't resolve to a real published page
     * (protects against false 404s from Polylang, rewrite rule conflicts, etc.)
     */
    private function log_404( $uri ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_404;

        // Bot filter for 404 logging (3 tiers):
        // 1. AI bots (gptbot, perplexity, claudebot, cohere, googlebot) → ALWAYS log (GEO opportunities)
        // 2. Spam bots (semrush, ahrefs, mj12, dotbot, bytespider, ccbot) → NEVER log
        // 3. Generic bot patterns (bot, crawl, spider) → skip if NOT an AI bot
        $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';

        // Check AI bots first — these are valuable, always log them
        $ai_bot_patterns = array( 'gptbot', 'perplexity', 'claudebot', 'cohere', 'googlebot', 'bingbot', 'google-extended' );
        $is_ai_bot = false;
        foreach ( $ai_bot_patterns as $aip ) {
            if ( strpos( $ua, $aip ) !== false ) {
                $is_ai_bot = true;
                break;
            }
        }

        if ( ! $is_ai_bot ) {
            // Not an AI bot → check if it's a spam bot or generic crawler
            $spam_patterns = array( 'semrush', 'ahrefs', 'mj12', 'dotbot', 'bytespider', 'ccbot', 'slurp', 'yandex', 'baidu', 'sogou', 'seznambot' );
            foreach ( $spam_patterns as $sp ) {
                if ( strpos( $ua, $sp ) !== false ) return; // Spam → don't log
            }
            // Generic bot patterns → skip (noise from unknown crawlers)
            $generic_patterns = array( 'bot', 'crawl', 'spider' );
            foreach ( $generic_patterns as $gp ) {
                if ( strpos( $ua, $gp ) !== false ) return; // Generic crawler → don't log
            }
        }

        // Skip bots, assets, wp-admin, etc.
        if ( $this->should_skip_404( $uri ) ) return;

        // ── Safety: verify this is a REAL 404 (not a false positive) ──
        if ( $this->url_resolves_to_content( $uri ) ) return;

        $url_clean = self::normalize_url( $uri );
        $url_hash  = md5( $url_clean );
        $referer   = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( $_SERVER['HTTP_REFERER'] ) : '';
        $ua        = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( substr( $_SERVER['HTTP_USER_AGENT'], 0, 500 ) ) : '';
        $ip_hash   = md5( $_SERVER['REMOTE_ADDR'] ?? '' ); // Privacy: only store hash

        // Is external referrer?
        $is_external = 0;
        if ( $referer ) {
            $ref_host  = wp_parse_url( $referer, PHP_URL_HOST );
            $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
            $is_external = ( $ref_host && $ref_host !== $site_host ) ? 1 : 0;
        }

        // Upsert: increment hit_count if URL already exists
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE url_hash = %s LIMIT 1",
            $url_hash
        ) );

        if ( $existing ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$table} SET hit_count = hit_count + 1, last_seen = NOW(), 
                 referer = CASE WHEN %s != '' THEN %s ELSE referer END,
                 is_external = GREATEST(is_external, %d)
                 WHERE id = %d",
                $referer, $referer, $is_external, $existing
            ) );
        } else {
            $wpdb->insert( $table, array(
                'url'         => $url_clean,
                'url_hash'    => $url_hash,
                'referer'     => $referer,
                'user_agent'  => $ua,
                'ip_hash'     => $ip_hash,
                'hit_count'   => 1,
                'is_external' => $is_external,
                'first_seen'  => current_time( 'mysql' ),
                'last_seen'   => current_time( 'mysql' ),
                'status'      => 'new',
            ) );

            // Schedule AI suggest asynchronously to avoid frontend slowdown.
            // If a bot scans 100 URLs in 10s, synchronous matching causes memory overflow.
            // Rate-limit: max 1 suggestion batch per 60s via transient lock.
            $suggest_id = $wpdb->insert_id;
            if ( ! get_transient( 'hts_ai_suggest_lock' ) ) {
                set_transient( 'hts_ai_suggest_lock', 1, 60 );
                $this->auto_suggest_redirect( $url_clean, $suggest_id );
            }
            // Remaining unsugested 404s will be processed by bulk_rescan_ai or cron.
        }
    }

    /**
     * Skip logging for irrelevant 404s.
     */
    private function should_skip_404( $uri ) {
        // NEVER skip SEO-critical files — a 404 on these needs immediate attention
        $basename = basename( $uri );
        if ( $basename === 'robots.txt' || preg_match( '/^sitemap.*\.xml$/i', $basename ) ) return false;

        // Static assets (images, fonts, scripts, styles, sourcemaps)
        if ( preg_match( '/\.(css|js|png|jpg|jpeg|gif|svg|webp|avif|woff2?|ttf|eot|otf|ico|map)$/i', $uri ) ) return true;
        // Data/config files (json, rss, atom — but NOT xml/txt which may include sitemap/robots above)
        if ( preg_match( '/\.(json|rss|atom)$/i', $uri ) ) return true;
        // Non-critical xml/txt files (skip manifest.json-like, but keep sitemap/robots visible)
        if ( preg_match( '/\.(xml|txt)$/i', $uri ) && strpos( $uri, '/wp-content/' ) !== false ) return true;
        // WP uploads / media (srcset, thumbnails, encoded image URLs)
        if ( strpos( $uri, '/wp-content/uploads/' ) !== false ) return true;
        if ( strpos( $uri, '/wp-content/themes/' ) !== false ) return true;
        if ( strpos( $uri, '/wp-content/plugins/' ) !== false ) return true;
        // URL-encoded garbage (srcset leaks like image.jpg%201024w,%20https://...)
        if ( strpos( $uri, '%20' ) !== false && strpos( $uri, 'http' ) !== false ) return true;
        // WP internal
        if ( strpos( $uri, '/wp-admin' ) !== false ) return true;
        if ( strpos( $uri, '/wp-json' ) !== false )  return true;
        if ( strpos( $uri, '/wp-cron' ) !== false )  return true;
        if ( strpos( $uri, '/xmlrpc' ) !== false )   return true;
        if ( strpos( $uri, '/feed' ) !== false )     return true;
        // Common bot probes & security scanners
        if ( preg_match( '/\.(php|asp|aspx|jsp|cgi|env|git|bak|sql|zip|rar|tar|gz|log|ini|conf|yml|yaml|toml|sh)$/i', $uri ) ) return true;
        if ( strpos( $uri, '.well-known' ) !== false ) return true;
        if ( strpos( $uri, '/wp-includes' ) !== false ) return true;
        // Security scanner / CMS probe paths (never real content)
        $probe_paths = array(
            '/phpmyadmin', '/pma', '/myadmin', '/mysql',
            '/shell', '/webshell', '/cmd', '/getcmd', '/console',
            '/admin/config', '/administrator/', '/magento_version',
            '/.env', '/.git/', '/vendor/', '/node_modules/', '/cgi-bin/',
            '/solr', '/actuator', '/telescope', '/debug/',
            '/typo3', '/umbraco', '/joomla', '/drupal', '/struts',
        );
        $uri_lower = strtolower( $uri );
        foreach ( $probe_paths as $pp ) {
            if ( strpos( $uri_lower, $pp ) !== false ) return true;
        }
        // Ignore sourcemap and service-worker requests
        if ( strpos( $uri, 'service-worker' ) !== false ) return true;
        if ( strpos( $uri, 'browserconfig' ) !== false ) return true;
        // Very long URLs (> 500 chars) are almost always garbage/bot probes
        if ( strlen( $uri ) > 500 ) return true;
        return false;
    }

    /**
     * Check if a URI actually resolves to published content.
     * Catches false 404s caused by Polylang, rewrite conflicts, or taxonomy archives.
     * Uses hts_url_to_postid() + manual slug lookup + taxonomy check.
     *
     * @param string $uri The request URI path.
     * @return bool True if URL maps to real content (= false 404).
     */
    private function url_resolves_to_content( $uri ) {
        global $wpdb;

        // Negative cache: if we already checked this URI recently and it was a real 404, skip DB queries.
        // Prevents 100s of queries on bot scans hitting the same set of URLs.
        $cache_key = 'hts_404_real_' . md5( $uri );
        $cached = wp_cache_get( $cache_key, 'hts_redirects' );
        if ( $cached === 'miss' ) return false; // Known real 404

        // Method 1: WordPress url_to_postid (handles most permalink structures)
        $full_url = home_url( $uri );
        $post_id  = hts_url_to_postid( $full_url );
        if ( $post_id > 0 ) {
            $post = get_post( $post_id );
            if ( $post && $post->post_status === 'publish' ) return true;
        }

        // Method 2: Manual slug lookup — only for single-segment paths to avoid false matches
        // e.g. /domain-authority/ → slug "domain-authority" is safe
        // but /en/seo/ → slug "seo" could match an unrelated FR page
        $path = trim( $uri, '/' );
        $segments = explode( '/', $path );
        $slug = end( $segments );

        if ( count( $segments ) === 1 && $slug && strlen( $slug ) >= 2 ) {
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_status = 'publish' LIMIT 1",
                $slug
            ) );
            if ( $exists ) return true;
        }

        // Method 3: Check if it's a taxonomy term archive (category, tag) — single segment only
        if ( count( $segments ) === 1 && $slug ) {
            $term = get_term_by( 'slug', $slug, 'category' );
            if ( ! $term ) $term = get_term_by( 'slug', $slug, 'post_tag' );
            if ( $term && ! is_wp_error( $term ) ) return true;
        }

        // Method 4: Polylang language root (e.g. /fr/, /en/, /es/)
        if ( function_exists( 'pll_languages_list' ) ) {
            $lang_slugs = pll_languages_list( array( 'fields' => 'slug' ) );
            $first_segment = $segments[0] ?? '';
            if ( in_array( $first_segment, $lang_slugs, true ) ) {
                // Language homepage like /fr/
                if ( count( $segments ) === 1 ) return true;
                // For lang-prefixed URLs, try url_to_postid with the full URL
                // (Polylang hooks into this and resolves translated slugs)
                // Already checked in Method 1 above, so only do slug lookup
                // for 2-segment paths like /en/seo/ where slug is unambiguous
                if ( count( $segments ) === 2 ) {
                    $lang_slug = $segments[1];
                    if ( $lang_slug && strlen( $lang_slug ) >= 2 ) {
                        $exists = $wpdb->get_var( $wpdb->prepare(
                            "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_status = 'publish' LIMIT 1",
                            $lang_slug
                        ) );
                        if ( $exists ) return true;
                    }
                }
            }
        }

        // No content found — cache as negative for 5 min to avoid repeated DB hits
        wp_cache_set( $cache_key, 'miss', 'hts_redirects', 300 );
        return false;
    }

    /* ══════════════════════════════════════════════
     *  AI SEMANTIC REDIRECT (KILLER FEATURE)
     *  Uses EXISTING embeddings — 0 API calls
     * ══════════════════════════════════════════════ */

    /**
     * Suggest a redirect target for a 404 URL using semantic similarity.
     * ALL suggestions require client validation (no auto-apply).
     *
     * Strategy:
     *   1. Extract meaningful words from the 404 slug
     *   2. Find published page with best title/slug overlap (lexical)
     *   3. If embeddings available, use cosine similarity for precision
     *   4. If in a cocon, fallback to cluster pillar
     *
     * All results are saved as status='suggested' in the 404 log.
     * The client validates/rejects from the Inbox UI.
     */
    private function auto_suggest_redirect( $url, $log_id ) {
        global $wpdb;
        $t404 = $wpdb->prefix . self::TABLE_404;

        // Extract slug words from the 404 URL
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( ! $path ) return;

        // ── Pre-check: skip if a redirect rule already exists for this URL ──
        $normalized = self::normalize_url( $path );
        $hash = md5( $normalized );
        $existing_rule = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}" . self::TABLE_RULES . " WHERE source_hash = %s LIMIT 1",
            $hash
        ) );
        if ( $existing_rule ) {
            $wpdb->update( $t404, array( 'status' => 'redirected' ), array( 'id' => $log_id ) );
            return;
        }

        // ── Pre-check: skip if URL resolves to real content (false 404) ──
        if ( $this->url_resolves_to_content( $path ) ) {
            $wpdb->delete( $t404, array( 'id' => $log_id ) );
            return;
        }

        $slug = basename( rtrim( $path, '/' ) );
        if ( ! $slug || $slug === '/' ) return;

        $words = $this->extract_slug_words( $slug );
        if ( empty( $words ) ) return;

        // ── Detect language from URL prefix (Polylang/hreflang) ──
        $url_lang = $this->detect_url_language( $path );

        // ── Strategy A: Lexical pre-filter (free, fast, language-aware) ──
        $best_match = $this->lexical_match( $words, $url_lang );

        // ── Strategy B: Embedding similarity (if available, more accurate) ──
        $embedding_match = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $embedding_match = $this->embedding_match( $slug, $words );
            // Post-filter: verify language matches
            if ( $embedding_match && $url_lang && ! $this->post_matches_language( $embedding_match['post_id'], $url_lang ) ) {
                $embedding_match = null;
            }
        }

        // Use the best score between lexical and embedding
        $target_id = null;
        $score     = 0.0;
        $method    = '';

        if ( $embedding_match && $embedding_match['score'] >= ( $best_match['score'] ?? 0 ) ) {
            $target_id = $embedding_match['post_id'];
            $score     = $embedding_match['score'];
            $method    = 'embedding';
        } elseif ( $best_match && $best_match['score'] > 0.2 ) {
            $target_id = $best_match['post_id'];
            $score     = $best_match['score'];
            $method    = 'lexical';
        }

        // ── Strategy C: Cocon pillar fallback ──
        if ( ! $target_id || $score < 0.50 ) {
            $pillar = $this->find_closest_pillar( $words );
            if ( $pillar && $url_lang && ! $this->post_matches_language( $pillar['post_id'], $url_lang ) ) {
                $pillar = null;
            }
            if ( $pillar && ( ! $target_id || $pillar['score'] > $score ) ) {
                $target_id = $pillar['post_id'];
                $score     = $pillar['score'];
                $method    = 'cocon_pillar';
            }
        }

        // ── Strategy D: SaaS AI fallback (OpenAI 4.1-mini via HTS SaaS) ──
        if ( ( ! $target_id || $score < 0.40 ) && $this->can_use_saas_ai() ) {
            $ai_match = $this->saas_ai_suggest( $slug, $words, $url_lang );
            if ( $ai_match && $ai_match['score'] > $score ) {
                $target_id = $ai_match['post_id'];
                $score     = $ai_match['score'];
                $method    = 'saas_ai';
            }
        }

        // ── Final guard: never suggest a page in the wrong language ──
        if ( $target_id && $url_lang && ! $this->post_matches_language( $target_id, $url_lang ) ) {
            $target_id = null;
        }

        if ( ! $target_id ) return;

        // Update 404 log with suggestion
        $wpdb->update( $t404, array(
            'suggested_target' => $target_id,
            'suggested_score'  => round( $score, 4 ),
            'status'           => 'suggested',
        ), array( 'id' => $log_id ) );

        // ── All AI suggestions require client validation ──
        // Slug changes and cocon redirects are auto (deterministic),
        // but AI semantic matching ALWAYS goes through the Inbox.
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( 'Suggestion IA : %s → %s (score %.0f%%, %s)', $slug, get_the_title( $target_id ), $score * 100, $method ),
                'info', 'redirects'
            );
        }
    }

    /**
     * Extract meaningful words from a URL slug.
     */
    private function extract_slug_words( $slug ) {
        // Remove file extensions
        $slug = preg_replace( '/\.[a-z]{2,4}$/', '', $slug );
        // Split on separators
        $parts = preg_split( '/[-_\/]+/', $slug );
        // Filter stopwords and short words
        $stopwords = function_exists( 'hts_get_stopwords' ) ? hts_get_stopwords() : array();
        $stopwords = array_merge( $stopwords, array( 'html', 'php', 'com', 'www', 'http', 'https', 'page', 'index' ) );

        $words = array();
        foreach ( $parts as $w ) {
            $w = mb_strtolower( trim( $w ) );
            if ( mb_strlen( $w ) >= 3 && ! in_array( $w, $stopwords, true ) ) {
                $words[] = $w;
            }
        }
        return $words;
    }

    /**
     * Lexical matching: find published page whose slug/title best matches the 404 words.
     * If $url_lang is set (Polylang), only matches pages in that language.
     * Returns [ 'post_id' => int, 'score' => float ] or null.
     */
    private function lexical_match( $words, $url_lang = null ) {
        global $wpdb;

        // Build Polylang language filter if applicable
        $lang_join  = '';
        $lang_where = '';
        if ( $url_lang && function_exists( 'pll_languages_list' ) ) {
            $tax = 'language';
            $term = get_term_by( 'slug', $url_lang, $tax );
            if ( $term && ! is_wp_error( $term ) ) {
                $lang_join  = " INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID";
                $lang_where = $wpdb->prepare( " AND tr.term_taxonomy_id = %d", $term->term_taxonomy_id );
            }
        }

        // Build LIKE conditions for each word
        $like_clauses = array();
        $like_values  = array();
        foreach ( $words as $w ) {
            $like_clauses[] = "(p.post_name LIKE %s OR p.post_title LIKE %s)";
            $like_values[]  = '%' . $wpdb->esc_like( $w ) . '%';
            $like_values[]  = '%' . $wpdb->esc_like( $w ) . '%';
        }

        if ( empty( $like_clauses ) ) return null;

        // Count matching words per post (higher = better match)
        $select_parts = array();
        foreach ( $words as $w ) {
            $esc = $wpdb->esc_like( $w );
            $select_parts[] = $wpdb->prepare(
                "(CASE WHEN p.post_name LIKE %s THEN 1 ELSE 0 END) + (CASE WHEN p.post_title LIKE %s THEN 1 ELSE 0 END)",
                '%' . $esc . '%', '%' . $esc . '%'
            );
        }
        $score_expr = implode( ' + ', $select_parts );
        $total_possible = count( $words ) * 2; // max score = all words in both slug and title

        $where = implode( ' OR ', $like_clauses );
        $query = $wpdb->prepare(
            "SELECT p.ID, ({$score_expr}) as match_score
             FROM {$wpdb->posts} p{$lang_join}
             WHERE p.post_status = 'publish'
               AND p.post_type " . hts_sql_post_types_in() . "
               AND ({$where}){$lang_where}
             ORDER BY match_score DESC
             LIMIT 1",
            $like_values
        );

        $result = $wpdb->get_row( $query );
        if ( ! $result || $result->match_score <= 0 ) return null;

        return array(
            'post_id' => (int) $result->ID,
            'score'   => min( 1.0, (float) $result->match_score / max( 1, $total_possible ) ),
        );
    }

    /**
     * Embedding-based matching: generate a pseudo-embedding from the 404 slug
     * by averaging embeddings of similar published posts (found via lexical pre-filter).
     * Then compare with all stored embeddings.
     *
     * This uses 0 API calls — purely local computation.
     */
    private function embedding_match( $slug, $words ) {
        if ( ! class_exists( 'HTS_Embeddings' ) ) return null;

        $emb = new HTS_Embeddings();
        $all_vectors = $emb->load_all_vectors( true );
        if ( empty( $all_vectors ) ) return null;

        // Build a query text from slug words
        $query_text = implode( ' ', $words );

        // Strategy: find post whose title best matches, use ITS embedding as proxy
        // Then find the actual closest post via cosine
        $best_id    = null;
        $best_score = 0.0;

        // Get all published post titles for comparison
        global $wpdb;
        $posts = $wpdb->get_results(
            "SELECT ID, post_title, post_name FROM {$wpdb->posts} 
             WHERE post_status = 'publish' AND post_type " . hts_sql_post_types_in() . "
             AND ID IN (" . implode( ',', array_map( 'intval', array_keys( $all_vectors ) ) ) . ")",
            ARRAY_A
        );

        if ( empty( $posts ) ) return null;

        // Score each post by word overlap with the 404 slug
        $candidates = array();
        foreach ( $posts as $p ) {
            $title_words = $this->extract_slug_words( $p['post_name'] . '-' . $p['post_title'] );
            $overlap     = array_intersect( $words, $title_words );
            if ( ! empty( $overlap ) ) {
                $candidates[ (int) $p['ID'] ] = count( $overlap ) / max( count( $words ), 1 );
            }
        }

        if ( empty( $candidates ) ) return null;

        // Top 5 lexical candidates → use their average embedding as query vector
        arsort( $candidates );
        $top_ids = array_slice( array_keys( $candidates ), 0, 5 );

        $avg_vector = null;
        $count      = 0;
        foreach ( $top_ids as $pid ) {
            if ( isset( $all_vectors[ $pid ] ) ) {
                $vec = $all_vectors[ $pid ];
                if ( $avg_vector === null ) {
                    $avg_vector = $vec;
                } else {
                    for ( $i = 0, $len = count( $vec ); $i < $len; $i++ ) {
                        $avg_vector[ $i ] += $vec[ $i ];
                    }
                }
                $count++;
            }
        }

        if ( ! $avg_vector || $count === 0 ) return null;

        // Normalize average
        for ( $i = 0, $len = count( $avg_vector ); $i < $len; $i++ ) {
            $avg_vector[ $i ] /= $count;
        }

        // Compare with ALL embeddings
        foreach ( $all_vectors as $pid => $vec ) {
            $sim = HTS_Embeddings::cosine_similarity( $avg_vector, $vec );
            if ( $sim > $best_score ) {
                $best_score = $sim;
                $best_id    = $pid;
            }
        }

        if ( ! $best_id || $best_score < 0.25 ) return null;

        return array(
            'post_id' => $best_id,
            'score'   => round( $best_score, 4 ),
        );
    }

    /**
     * Find the closest cocon pillar for fallback redirect.
     */
    private function find_closest_pillar( $words ) {
        if ( ! class_exists( 'HTS_Cocon' ) ) return null;

        $cocon = new HTS_Cocon();
        $data  = $cocon->get_cocon_data();

        if ( empty( $data['clusters'] ) ) return null;

        $query = implode( ' ', $words );
        $best  = null;

        foreach ( $data['clusters'] as $name => $cl ) {
            if ( strtolower( $name ) === 'navigation' ) continue;

            $pillar_id = $cl['pillar_id'] ?? 0;
            if ( ! $pillar_id ) continue;

            // Score: word overlap between 404 slug and cluster name
            $cluster_words = $this->extract_slug_words( $name );
            $overlap       = array_intersect( $words, $cluster_words );
            $score         = count( $overlap ) / max( count( $words ), 1 );

            if ( $score > 0.3 && ( ! $best || $score > $best['score'] ) ) {
                $best = array( 'post_id' => $pillar_id, 'score' => $score );
            }
        }

        return $best;
    }

    /* ══════════════════════════════════════════════
     *  SLUG CHANGE GUARDIAN
     * ══════════════════════════════════════════════ */

    /**
     * When a post's slug changes, auto-create a 301 redirect from old to new.
     */
    public function slug_change_guardian( $post_id, $post_after, $post_before ) {
        // Only published posts
        if ( $post_before->post_status !== 'publish' && $post_after->post_status !== 'publish' ) return;
        // Only if slug actually changed
        if ( $post_before->post_name === $post_after->post_name ) return;
        // Skip revisions and auto-drafts
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
        // Guard: never create redirects for critical paths
        $safe_paths = array( '/', '/wp-admin', '/wp-login.php', '/wp-cron.php', '/xmlrpc.php', '/wp-json' );
        if ( in_array( '/' . trim( $post_before->post_name, '/' ), $safe_paths, true ) ) {
            return;
        }

        $new_url = get_permalink( $post_id );
        if ( ! $new_url ) return;

        // Build old URL by replacing ONLY the slug segment in the new permalink path.
        // Using str_replace on the full URL is dangerous when the slug appears in the
        // domain or parent slugs (e.g. /seo/seo-guide/ with slug "seo" → corrupts URL).
        $new_path = wp_parse_url( $new_url, PHP_URL_PATH );
        if ( ! $new_path ) return;

        // Replace only the last occurrence of the new slug with the old slug in the path.
        // This handles hierarchical posts (/parent/child/) and flat structures (/slug/).
        $old_slug = $post_before->post_name;
        $new_slug = $post_after->post_name;
        $last_pos = strrpos( $new_path, $new_slug );
        if ( $last_pos !== false ) {
            $old_path = substr_replace( $new_path, $old_slug, $last_pos, strlen( $new_slug ) );
        } else {
            // Fallback: simple slug path
            $old_path = '/' . $old_slug . '/';
        }

        $this->add_redirect_rule(
            $old_path,
            $new_url,
            301,
            'slug_change',
            sprintf( 'Slug change auto-detect: "%s" → "%s"', $post_before->post_name, $post_after->post_name )
        );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
 sprintf( 'Slug modifié : "%s" → "%s" (301 auto-créée)', $post_before->post_name, $post_after->post_name ),
                'success', 'redirects'
            );
        }
    }

    /* ══════════════════════════════════════════════
     *  POST TRASH → COCON-AWARE REDIRECT
     * ══════════════════════════════════════════════ */

    /**
     * When a post is trashed, redirect to its cluster pillar.
     */
    public function on_post_trash( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return;

        $old_url = get_permalink( $post_id );
        if ( ! $old_url ) return;

        $target_url = null;
        $note       = '';
        $rtype      = 301;

        // Strategy 1: Cocon pillar redirect (best for SEO: stays in topic cluster)
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new HTS_Cocon();
            $data  = $cocon->get_cocon_data();
            foreach ( $data['clusters'] ?? array() as $cname => $cl ) {
                $pages = $cl['pages'] ?? array();
                if ( in_array( $post_id, $pages, true ) ) {
                    $pillar_id = $cl['pillar_id'] ?? 0;
                    if ( $pillar_id && $pillar_id !== $post_id ) {
                        $target_url = get_permalink( $pillar_id );
                        $note = sprintf( 'Cocon "%s" pillar redirect (post trashed)', $cname );
                    }
                    break;
                }
            }
        }

        // Strategy 2: Parent category archive (topically relevant, better than homepage)
        if ( ! $target_url ) {
            $categories = get_the_category( $post_id );
            if ( ! empty( $categories ) ) {
                // Pick the deepest (most specific) category
                usort( $categories, function( $a, $b ) {
                    return $b->parent - $a->parent;
                } );
                $cat_link = get_category_link( $categories[0]->term_id );
                if ( $cat_link && $cat_link !== home_url( '/' ) ) {
                    $target_url = $cat_link;
                    $note = sprintf( 'Post trashed → catégorie "%s" (fallback SEO-safe)', $categories[0]->name );
                }
            }
        }

        // Strategy 3: 410 Gone (better than homepage 301 — Google 2026 recommends
        // explicit deletion signals over soft-404 patterns to homepage)
        if ( ! $target_url ) {
            $rtype = 410;
            $target_url = ''; // 410 has no target
            $note = 'Post trashed, 410 Gone (aucun cocon/catégorie trouvé — évite redirect aveugle vers homepage)';
        }

        $old_path = wp_parse_url( $old_url, PHP_URL_PATH );
        if ( $old_path ) {
            $this->add_redirect_rule( $old_path, $target_url ? $target_url : home_url( '/' ), $rtype, 'cocon', $note );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( 'Post supprimé "%s" → %s', $post->post_title, $rtype === 410 ? '410 Gone' : $target_url ),
                    'info', 'redirects'
                );
            }
        }
    }

    /* ══════════════════════════════════════════════
     *  REDIRECT RULE MANAGEMENT
     * ══════════════════════════════════════════════ */

    /**
     * Add a redirect rule (upsert: update if source already exists).
     */
    public function add_redirect_rule( $source, $target, $type = 301, $origin = 'manual', $notes = '' ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_RULES;

        $source_clean = self::normalize_url( $source );

        // ── Truncate URLs to fit VARCHAR(255) column ──
        if ( mb_strlen( $source_clean ) > 255 ) {
            $source_clean = mb_substr( $source_clean, 0, 255 );
        }
        if ( mb_strlen( $target ) > 255 ) {
            $target = mb_substr( $target, 0, 255 );
        }

        // ── Never allow redirects on critical paths ──
        $blocked = array( '/', '/wp-admin/', '/wp-login.php/', '/wp-cron.php/', '/xmlrpc.php/', '/feed/' );
        if ( in_array( $source_clean, $blocked, true ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Blocked redirect on critical path: ' . $source_clean, 'warning', 'redirects' );
            }
            return 0;
        }

        // ── Prevent self-redirect (source = target path) ──
        $target_path = self::normalize_url( wp_parse_url( $target, PHP_URL_PATH ) ?: $target );
        if ( $source_clean === $target_path ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Blocked self-redirect: ' . $source_clean, 'warning', 'redirects' );
            }
            return 0;
        }

        // ── Prevent chain creation: auto-shortcut if target already redirects elsewhere ──
        // Follow the chain up to 5 hops to find the final destination.
        // This prevents A→B→C chains that waste crawl budget.
        $final_target = $target;
        $final_target_path = $target_path;
        $hops = 0;
        while ( $hops < 5 ) {
            $chain_hash = md5( $final_target_path );
            $chain_rule = $wpdb->get_row( $wpdb->prepare(
                "SELECT target_url, redirect_type FROM {$table} WHERE source_hash = %s AND enabled = 1 LIMIT 1",
                $chain_hash
            ), ARRAY_A );
            if ( ! $chain_rule ) break;
            // Don't follow 410 chains
            if ( (int) $chain_rule['redirect_type'] === 410 ) break;
            $final_target = $chain_rule['target_url'];
            $final_target_path = self::normalize_url( wp_parse_url( $final_target, PHP_URL_PATH ) ?: $final_target );
            // Safety: don't loop back to source
            if ( $final_target_path === $source_clean ) break;
            $hops++;
        }
        if ( $hops > 0 ) {
            $target = $final_target;
            $target_path = $final_target_path;
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
                    sprintf( 'Chaîne raccourcie (%d hops) : %s → %s', $hops, $source_clean, $target_path ),
                    'info', 'redirects'
                );
            }
        }

        $source_hash  = md5( $source_clean );

        // Check if rule already exists for this source
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE source_hash = %s LIMIT 1",
            $source_hash
        ) );

        // Sanitize target: keep paths as-is, sanitize full URLs
        $safe_target = ( strpos( $target, '/' ) === 0 )
            ? sanitize_text_field( $target )
            : esc_url_raw( $target );

        if ( $existing ) {
            $wpdb->update( $table, array(
                'target_url'    => $safe_target,
                'redirect_type' => (int) $type,
                'notes'         => sanitize_text_field( $notes ),
                'enabled'       => 1,
            ), array( 'id' => $existing ) );
            return (int) $existing;
        }

        $wpdb->insert( $table, array(
            'source_url'    => $source_clean,
            'source_hash'   => $source_hash,
            'target_url'    => $safe_target,
            'redirect_type' => (int) $type,
            'is_regex'      => 0,
            'origin'        => $origin,
            'notes'         => sanitize_text_field( $notes ),
            'enabled'       => 1,
        ) );

        // Invalidate regex cache
        wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );

        return (int) $wpdb->insert_id;
    }

    /**
     * Normalize a URL/path for consistent matching.
     */
    public static function normalize_url( $url ) {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( ! $path ) $path = $url;
        $path = strtolower( trim( $path ) );
        // Ensure trailing slash for consistency
        if ( substr( $path, -1 ) !== '/' && ! preg_match( '/\.[a-z]{2,4}$/', $path ) ) {
            $path .= '/';
        }
        return $path;
    }

    /* ══════════════════════════════════════════════
     *  PATTERN DETECTION
     * ══════════════════════════════════════════════ */

    /**
     * Detect patterns in 404 logs (e.g., year migration, path prefix changes).
     * Returns suggested regex redirects.
     */
    public static function detect_patterns() {
        global $wpdb;
        $t404  = $wpdb->prefix . self::TABLE_404;
        $trule = $wpdb->prefix . self::TABLE_RULES;

        $patterns = array();

        // Year pattern: /2024/ → /2025/
        // Exclude URLs that already have a redirect rule (LEFT JOIN)
        $year_404s = $wpdb->get_results(
            "SELECT f.url, f.hit_count FROM {$t404} f
             LEFT JOIN {$trule} r ON r.source_hash = MD5(LOWER(TRIM(f.url)))
             WHERE f.status = 'new' AND r.id IS NULL
               AND f.url REGEXP '/20[0-9]{2}/'
               AND f.url NOT LIKE '%/wp-content/%'
               AND f.url NOT LIKE '%\\%20%'
               AND CHAR_LENGTH(f.url) < 200
             ORDER BY f.hit_count DESC LIMIT 100",
            ARRAY_A
        );

        $year_groups = array(); // year → [ urls ]
        $year_counts = array();
        foreach ( $year_404s as $row ) {
            if ( preg_match( '/(20\d{2})/', $row['url'], $m ) ) {
                $year = $m[1];
                if ( ! isset( $year_counts[ $year ] ) ) { $year_counts[ $year ] = 0; $year_groups[ $year ] = array(); }
                $year_counts[ $year ] += (int) $row['hit_count'];
                // Only include clean, short URLs as samples (skip wp-content/uploads, encoded garbage)
                if ( count( $year_groups[ $year ] ) < 5
                    && strlen( $row['url'] ) < 120
                    && strpos( $row['url'], '/wp-content/' ) === false
                    && strpos( $row['url'], '%20' ) === false
                ) {
                    $year_groups[ $year ][] = $row['url'];
                }
            }
        }

        foreach ( $year_counts as $year => $count ) {
            if ( $count >= 10 ) {
                $patterns[] = array(
                    'type'    => 'year_migration',
                    'pattern' => "/{$year}/(.+)",
                    'target'  => '/$1',
                    'count'   => $count,
                    'label'   => sprintf( 'Migration année %s détectée (%d hits)', $year, $count ),
                    'samples' => $year_groups[ $year ] ?? array(),
                );
            }
        }

        // Prefix pattern: /old-prefix/slug → /new-prefix/slug
        // Exclude URLs that already have a redirect rule
        $prefix_404s = $wpdb->get_results(
            "SELECT f.url, f.hit_count FROM {$t404} f
             LEFT JOIN {$trule} r ON r.source_hash = MD5(LOWER(TRIM(f.url)))
             WHERE f.status = 'new' AND r.id IS NULL
               AND f.hit_count >= 3
             ORDER BY f.hit_count DESC LIMIT 200",
            ARRAY_A
        );

        $prefix_counts = array();
        $prefix_groups = array();
        foreach ( $prefix_404s as $row ) {
            // Skip wp-content and encoded garbage entirely from prefix detection
            if ( strpos( $row['url'], '/wp-content/' ) !== false ) continue;
            if ( strpos( $row['url'], '%20' ) !== false ) continue;
            if ( strlen( $row['url'] ) > 200 ) continue;

            $parts = explode( '/', trim( $row['url'], '/' ) );
            if ( count( $parts ) >= 2 ) {
                $prefix = '/' . $parts[0] . '/';
                if ( ! isset( $prefix_counts[ $prefix ] ) ) { $prefix_counts[ $prefix ] = 0; $prefix_groups[ $prefix ] = array(); }
                $prefix_counts[ $prefix ]++;
                if ( count( $prefix_groups[ $prefix ] ) < 5 && strlen( $row['url'] ) < 120 ) {
                    $prefix_groups[ $prefix ][] = $row['url'];
                }
            }
        }

        foreach ( $prefix_counts as $prefix => $count ) {
            if ( $count >= 5 ) {
                $patterns[] = array(
                    'type'    => 'prefix_migration',
                    'pattern' => $prefix . '(.+)',
                    'target'  => '/$1',
                    'count'   => $count,
                    'label'   => sprintf( 'Préfixe "%s" obsolète (%d URLs)', $prefix, $count ),
                    'samples' => $prefix_groups[ $prefix ] ?? array(),
                );
            }
        }

        return $patterns;
    }

    /* ══════════════════════════════════════════════
     *  AJAX HANDLERS
     * ══════════════════════════════════════════════ */

    /**
     * Manage redirect rules (add, edit, delete, toggle).
     */
    public function ajax_redirect_action() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        global $wpdb;
        $table  = $wpdb->prefix . self::TABLE_RULES;
        $action = sanitize_text_field( $_POST['sub_action'] ?? '' );

        switch ( $action ) {
            case 'add':
                $source = sanitize_text_field( $_POST['source'] ?? '' );
                $raw_target = sanitize_text_field( $_POST['target'] ?? '' );
                $target = ( strpos( $raw_target, '/' ) === 0 )
                    ? $raw_target
                    : esc_url_raw( $raw_target );
                $type   = (int) ( $_POST['type'] ?? 301 );
                if ( ! in_array( $type, array( 301, 302, 307, 410 ), true ) ) $type = 301;
                $regex  = (int) ( $_POST['is_regex'] ?? 0 );
                $notes  = sanitize_text_field( $_POST['notes'] ?? '' );

                if ( ! $source ) {
                    wp_send_json_error( 'Source requise' );
                }
                if ( $type !== 410 && ! $target ) {
                    wp_send_json_error( 'Source et cible requises' );
                }

                // Validate regex if applicable
                if ( $regex && @preg_match( '@' . str_replace( '@', '\\@', $source ) . '@', '' ) === false ) {
                    wp_send_json_error( 'Expression régulière invalide' );
                }

                // Prevent redirect loop
                $source_path = $regex ? $source : self::normalize_url( $source );
                $target_path = self::normalize_url( wp_parse_url( $target, PHP_URL_PATH ) ?: $target );
                if ( ! $regex && $source_path === $target_path ) {
                    wp_send_json_error( 'Boucle détectée : source et cible identiques' );
                }

                // Use upsert method for non-regex (handles duplicates gracefully)
                if ( ! $regex ) {
                    $rule_id = $this->add_redirect_rule( $source, $target, $type, 'manual', $notes );
                } else {
                    $source_hash = md5( $source );
                    $existing = $wpdb->get_var( $wpdb->prepare(
                        "SELECT id FROM {$table} WHERE source_hash = %s LIMIT 1", $source_hash
                    ) );
                    if ( $existing ) {
                        $wpdb->update( $table, array(
                            'target_url' => $target, 'redirect_type' => $type,
                            'notes' => $notes, 'enabled' => 1,
                        ), array( 'id' => $existing ) );
                        $rule_id = (int) $existing;
                    } else {
                        $wpdb->insert( $table, array(
                            'source_url' => $source, 'source_hash' => $source_hash,
                            'target_url' => $target, 'redirect_type' => $type,
                            'is_regex' => 1, 'origin' => 'manual',
                            'notes' => $notes, 'enabled' => 1,
                        ) );
                        $rule_id = (int) $wpdb->insert_id;
                    }
                }

                if ( ! $rule_id ) {
                    wp_send_json_error( 'Erreur base de données : ' . $wpdb->last_error );
                }

                wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );

                // For regex rules: mark all matching 404s as redirected
                if ( $regex ) {
                    $t404_mark = $wpdb->prefix . self::TABLE_404;
                    $pending_404s = $wpdb->get_results(
                        "SELECT id, url FROM {$t404_mark} WHERE status IN ('new','suggested') LIMIT 500",
                        ARRAY_A
                    );
                    $pattern_safe = '@' . str_replace( '@', '\\@', $source ) . '@i';
                    foreach ( $pending_404s as $p404 ) {
                        $test_path = self::normalize_url( wp_parse_url( $p404['url'], PHP_URL_PATH ) ?: $p404['url'] );
                        if ( @preg_match( $pattern_safe, $test_path ) ) {
                            $wpdb->update( $t404_mark, array( 'status' => 'redirected' ), array( 'id' => (int) $p404['id'] ) );
                        }
                    }
                }

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Redirect : {$source_path} → " . wp_parse_url( $target, PHP_URL_PATH ), 'success', 'redirects' );
                }
                wp_send_json_success( array( 'id' => $rule_id ) );
                break;

            case 'edit':
                $id     = (int) ( $_POST['id'] ?? 0 );
                $raw_target = sanitize_text_field( $_POST['target'] ?? '' );
                $target = ( strpos( $raw_target, '/' ) === 0 )
                    ? $raw_target
                    : esc_url_raw( $raw_target );
                $type   = (int) ( $_POST['type'] ?? 301 );
                if ( ! in_array( $type, array( 301, 302, 307, 410 ), true ) ) $type = 301;
                $notes  = sanitize_text_field( $_POST['notes'] ?? '' );

                if ( ! $id || ! $target ) wp_send_json_error( 'ID et cible requises' );

                $old = $wpdb->get_row( $wpdb->prepare( "SELECT source_url, target_url, redirect_type FROM {$table} WHERE id = %d", $id ), ARRAY_A );
                $wpdb->update( $table, array(
                    'target_url'    => $target,
                    'redirect_type' => $type,
                    'notes'         => $notes,
                ), array( 'id' => $id ) );

                wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );
                if ( function_exists('hts_add_log') && $old ) {
 hts_add_log( sprintf('Redirect modifie : %s → %s (was → %s, type %d→%d)', $old['source_url'], $target, $old['target_url'], $old['redirect_type'], $type), 'info', 'redirects' );
                }
                wp_send_json_success();
                break;

            case 'delete':
                $id = (int) ( $_POST['id'] ?? 0 );
                if ( ! $id ) wp_send_json_error( 'ID requise' );
                $old = $wpdb->get_row( $wpdb->prepare( "SELECT source_url, target_url FROM {$table} WHERE id = %d", $id ), ARRAY_A );
                $wpdb->delete( $table, array( 'id' => $id ) );
                wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );
                if ( function_exists('hts_add_log') && $old ) {
 hts_add_log( sprintf('Redirect supprime : %s → %s', $old['source_url'], $old['target_url']), 'warning', 'redirects' );
                }
                wp_send_json_success();
                break;

            case 'toggle':
                $id = (int) ( $_POST['id'] ?? 0 );
                if ( ! $id ) wp_send_json_error( 'ID requise' );
                $row = $wpdb->get_row( $wpdb->prepare( "SELECT source_url, enabled FROM {$table} WHERE id = %d", $id ), ARRAY_A );
                $current = $row ? $row['enabled'] : 0;
                $wpdb->update( $table, array( 'enabled' => $current ? 0 : 1 ), array( 'id' => $id ) );
                wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );
                if ( function_exists('hts_add_log') && $row ) {
 hts_add_log( sprintf('%s Redirect %s : %s', $current ? '' : '', $current ? 'desactive' : 'reactive', $row['source_url']), 'info', 'redirects' );
                }
                wp_send_json_success( array( 'enabled' => ! $current ) );
                break;

            default:
                wp_send_json_error( 'Action inconnue' );
        }
    }

    /**
     * Manage 404 logs (ignore, create redirect, clear).
     */
    public function ajax_404_action() {
        // JSON-safe nonce check (check_ajax_referer dies with -1 HTML on failure → breaks fetch .json())
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) {
            wp_send_json_error( 'Session expirée — rechargez la page (F5)' );
        }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        global $wpdb;
        $t404   = $wpdb->prefix . self::TABLE_404;
        $action = sanitize_text_field( $_POST['sub_action'] ?? '' );

        switch ( $action ) {
            case 'ignore':
                $id = (int) ( $_POST['id'] ?? 0 );
                $row_404 = $wpdb->get_row( $wpdb->prepare( "SELECT url FROM {$t404} WHERE id = %d", $id ), ARRAY_A );
                $wpdb->update( $t404, array( 'status' => 'ignored' ), array( 'id' => $id ) );
                if ( function_exists('hts_add_log') && $row_404 ) {
 hts_add_log( ' 404 ignoree : ' . $row_404['url'], 'info', 'redirects' );
                }
                wp_send_json_success();
                break;

            case 'redirect':
                $id     = (int) ( $_POST['id'] ?? 0 );
                $raw_target = sanitize_text_field( $_POST['target'] ?? '' );
                // If it starts with / it's a path, keep as-is; if full URL, sanitize
                $target = ( strpos( $raw_target, '/' ) === 0 )
                    ? $raw_target
                    : esc_url_raw( $raw_target );
                $type   = (int) ( $_POST['type'] ?? 301 );
                if ( ! in_array( $type, array( 301, 302, 307, 410 ), true ) ) $type = 301;

                if ( ! $id || ! $target ) wp_send_json_error( 'ID et cible requises' );

                $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t404} WHERE id = %d", $id ), ARRAY_A );
                if ( ! $row ) wp_send_json_error( '404 non trouvée' );

                $rule_id = $this->add_redirect_rule(
                    wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'],
                    $target,
                    $type,
                    'manual',
                    sprintf( '404 → redirect (%d hits)', $row['hit_count'] )
                );

                $wpdb->update( $t404, array( 'status' => 'redirected' ), array( 'id' => $id ) );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( " 404 redirigée : {$row['url']} → {$target}", 'success', 'redirects' );
                }
                wp_send_json_success( array( 'rule_id' => $rule_id ) );
                break;

            case 'accept_suggestion':
                $id = (int) ( $_POST['id'] ?? 0 );
                $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t404} WHERE id = %d", $id ), ARRAY_A );
                if ( ! $row || ! $row['suggested_target'] ) wp_send_json_error( 'Pas de suggestion' );

                $target_url = get_permalink( (int) $row['suggested_target'] );
                if ( ! $target_url ) wp_send_json_error( 'Cible invalide' );

                $rule_id = $this->add_redirect_rule(
                    wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'],
                    $target_url,
                    301,
                    'ai_suggested',
                    sprintf( 'AI suggestion acceptée (score %.0f%%)', ( $row['suggested_score'] ?? 0 ) * 100 )
                );

                $wpdb->update( $t404, array( 'status' => 'redirected' ), array( 'id' => $id ) );
                if ( function_exists('hts_add_log') ) {
 hts_add_log( sprintf(' 404 suggestion IA acceptee : %s → %s (score %.0f%%)', $row['url'], $target_url, ($row['suggested_score']??0)*100), 'success', 'redirects' );
                }
                wp_send_json_success( array( 'rule_id' => $rule_id ) );
                break;

            case 'clear_resolved':
                $count_cleared = $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('redirected','ignored')" );
                $wpdb->query( "DELETE FROM {$t404} WHERE status IN ('redirected','ignored')" );
                if ( function_exists('hts_add_log') ) {
 hts_add_log( ' 404 resolues purgees : ' . (int)$count_cleared . ' entrees', 'info', 'redirects' );
                }
                wp_send_json_success();
                break;

            case 'clear_all':
                $count_all = $wpdb->get_var( "SELECT COUNT(*) FROM {$t404}" );
                $wpdb->query( "TRUNCATE TABLE {$t404}" );
                if ( function_exists('hts_add_log') ) {
 hts_add_log( ' 404 TOUTES purgees : ' . (int)$count_all . ' entrees', 'warning', 'redirects' );
                }
                wp_send_json_success();
                break;

            case 'purge_bot_probes':
                // Delete 404 entries that are clearly bot probes / security scans / not real pages
                // This cleans up historical noise so only real 404s remain
                $probe_patterns = array(
                    // Security probes
                    '/forgot-password', '/login', '/register', '/admin', '/administrator',
                    '/phpmyadmin', '/pma', '/shell', '/webshell', '/cmd', '/getcmd',
                    '/wp-login.php', '/user/login', '/user/register', '/signin', '/signup',
                    // Tech probes
                    '/.env', '/.env.save', '/.env.backup', '/.git', '/wp-config',
                    '/backup', '/graphql', '/magento', '/magento_version',
                    '/debug', '/console', '/solr', '/actuator', '/telescope',
                    // CMS probes (not WordPress)
                    '/typo3', '/umbraco', '/joomla', '/drupal', '/struts',
                    '/vendor/', '/node_modules/', '/cgi-bin/',
                );
                $deleted = 0;
                $probe_rows = $wpdb->get_results(
                    "SELECT id, url FROM {$t404} WHERE status IN ('new','suggested') LIMIT 2000",
                    ARRAY_A
                );
                foreach ( $probe_rows as $row ) {
                    $url_lower = strtolower( $row['url'] );
                    foreach ( $probe_patterns as $probe ) {
                        if ( strpos( $url_lower, $probe ) !== false ) {
                            $wpdb->delete( $t404, array( 'id' => (int) $row['id'] ) );
                            $deleted++;
                            break;
                        }
                    }
                }
                // Also delete spam bot entries (user_agent contains spam bot names)
                $spam_ua_deleted = (int) $wpdb->query(
                    "DELETE FROM {$t404}
                     WHERE status IN ('new','suggested')
                       AND (user_agent LIKE '%semrush%' OR user_agent LIKE '%ahrefs%'
                            OR user_agent LIKE '%bytespider%' OR user_agent LIKE '%mj12%'
                            OR user_agent LIKE '%dotbot%' OR user_agent LIKE '%ccbot%'
                            OR user_agent LIKE '%petalbot%' OR user_agent LIKE '%dataforseo%'
                            OR user_agent LIKE '%zoominfobot%')"
                );
                $total_purged = $deleted + $spam_ua_deleted;
                if ( function_exists('hts_add_log') ) {
                    hts_add_log( sprintf( '404 bots purgés : %d probe URLs + %d spam bots = %d total', $deleted, $spam_ua_deleted, $total_purged ), 'info', 'redirects' );
                }
                $remaining = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
                wp_send_json_success( array(
                    'purged'    => $total_purged,
                    'probes'    => $deleted,
                    'spam_bots' => $spam_ua_deleted,
                    'remaining' => $remaining,
                ) );
                break;

            case 'cleanup_false_positives':
                $trule_fp = $wpdb->prefix . self::TABLE_RULES;
                $step = sanitize_text_field( $_POST['step'] ?? 'all' );
                $result = array();

                if ( $step === 'rules' || $step === 'all' ) {
                    // Step 0: Bulk-mark 404s that have a redirect rule
                    $marked = (int) $wpdb->query(
                        "UPDATE {$t404} f
                         INNER JOIN {$trule_fp} r ON (
                             r.source_hash = f.url_hash
                             OR r.source_hash = MD5(LOWER(CONCAT(TRIM(TRAILING '/' FROM f.url), '/')))
                         )
                         SET f.status = 'redirected'
                         WHERE f.status IN ('new','suggested')"
                    );
                    $result['marked_rules'] = $marked;
                    if ( $step === 'rules' ) {
                        $result['remaining'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
                        wp_send_json_success( $result );
                    }
                }

                if ( $step === 'extensions' || $step === 'all' ) {
                    // Step 1: Extension filter
                    $ext_404s = $wpdb->get_results(
                        "SELECT id, url FROM {$t404} WHERE status IN ('new','suggested') LIMIT 500",
                        ARRAY_A
                    );
                    $skipped = 0;
                    foreach ( $ext_404s as $row ) {
                        $path = wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'];
                        if ( $this->should_skip_404( $path ) ) {
                            $wpdb->delete( $t404, array( 'id' => (int) $row['id'] ) );
                            $skipped++;
                        }
                    }
                    $result['skipped_ext'] = $skipped;
                    if ( $step === 'extensions' ) {
                        $result['remaining'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
                        wp_send_json_success( $result );
                    }
                }

                if ( $step === 'content' || $step === 'all' ) {
                    // Step 2: URL resolution (posts, taxonomies, Polylang)
                    $content_404s = $wpdb->get_results(
                        "SELECT id, url FROM {$t404} WHERE status IN ('new','suggested') ORDER BY hit_count DESC LIMIT 500",
                        ARRAY_A
                    );
                    $cleaned = 0;
                    foreach ( $content_404s as $row ) {
                        $path = wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'];
                        if ( $this->url_resolves_to_content( $path ) ) {
                            $wpdb->delete( $t404, array( 'id' => (int) $row['id'] ) );
                            $cleaned++;
                        }
                    }
                    $result['cleaned'] = $cleaned;
                    if ( $step === 'content' ) {
                        $result['remaining'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
                        wp_send_json_success( $result );
                    }
                }

                if ( $step === 'http' || $step === 'all' ) {
                    // Step 3: HTTP HEAD check (WordPress native redirects)
                    // Limited to 20 URLs to avoid PHP timeout (20 × 3s = 60s max)
                    $http_404s = $wpdb->get_results(
                        "SELECT id, url FROM {$t404} WHERE status IN ('new','suggested') ORDER BY hit_count DESC LIMIT 20",
                        ARRAY_A
                    );
                    $wp_redirect = 0;
                    foreach ( $http_404s as $row ) {
                        $path = wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'];
                        $test_url = home_url( $path );
                        $response = wp_remote_head( $test_url, array(
                            'timeout'     => 3,
                            'redirection' => 0,
                            'sslverify'   => false,
                        ) );
                        if ( ! is_wp_error( $response ) ) {
                            $code = wp_remote_retrieve_response_code( $response );
                            if ( $code >= 200 && $code < 400 ) {
                                $wpdb->delete( $t404, array( 'id' => (int) $row['id'] ) );
                                $wp_redirect++;
                            }
                        }
                    }
                    $result['wp_redirect'] = $wp_redirect;
                    if ( $step === 'http' ) {
                        $result['remaining'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
                        wp_send_json_success( $result );
                    }
                }

                // Full run (step=all): return totals
                $total = ( $result['marked_rules'] ?? 0 ) + ( $result['skipped_ext'] ?? 0 )
                       + ( $result['cleaned'] ?? 0 ) + ( $result['wp_redirect'] ?? 0 );
                $result['total'] = $total;
                $result['remaining'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Nettoyage : %d règles, %d pages, %d ext, %d WP. %d restantes',
                            $result['marked_rules'] ?? 0, $result['cleaned'] ?? 0,
                            $result['skipped_ext'] ?? 0, $result['wp_redirect'] ?? 0, $result['remaining'] ),
                        'success', 'redirects'
                    );
                }
                wp_send_json_success( $result );
                break;

            case 'bulk_rescan_ai':
                // Re-run AI suggestions on 404s that have no suggestion yet
                $no_sugg = $wpdb->get_results(
                    "SELECT id, url FROM {$t404} WHERE status = 'new' AND suggested_target IS NULL ORDER BY hit_count DESC LIMIT 100",
                    ARRAY_A
                );
                $found = 0;
                $scanned = 0;
                foreach ( $no_sugg as $row ) {
                    $scanned++;
                    $this->auto_suggest_redirect( $row['url'], (int) $row['id'] );
                    // Check if suggestion was added
                    $updated = $wpdb->get_var( $wpdb->prepare(
                        "SELECT suggested_target FROM {$t404} WHERE id = %d", $row['id']
                    ) );
                    if ( $updated ) $found++;
                }
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Rescan IA : %d scannées, %d nouvelles suggestions trouvées', $scanned, $found ),
                        'success', 'redirects'
                    );
                }
                wp_send_json_success( array( 'scanned' => $scanned, 'found' => $found ) );
                break;

            case 'import_gsc_404s':
                // Cross-reference GSC URLs with published posts to discover 404s from Google's perspective
                $t_gsc = $wpdb->prefix . 'hts_gsc_data';
                $gsc_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$t_gsc}'" );
                if ( ! $gsc_exists ) {
                    wp_send_json_error( 'Table GSC introuvable. Connectez la Search Console et lancez un premier import.' );
                }

                // Get all unique GSC URLs that had traffic in the last 90 days
                $gsc_urls = $wpdb->get_results(
                    "SELECT url, SUM(clicks) as total_clicks, SUM(impressions) as total_impressions, MAX(fetch_date) as last_fetch
                     FROM {$t_gsc}
                     WHERE fetch_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
                     GROUP BY url
                     HAVING total_clicks > 0 OR total_impressions > 5
                     ORDER BY total_clicks DESC
                     LIMIT 500",
                    ARRAY_A
                );

                $imported = 0;
                $already_ok = 0;
                $already_redirected = 0;
                $already_logged = 0;
                $site_url = trailingslashit( home_url() );

                foreach ( $gsc_urls as $gsc_row ) {
                    $full_url = $gsc_row['url'];
                    // Extract path from the full URL
                    $path = wp_parse_url( $full_url, PHP_URL_PATH );
                    if ( ! $path || $path === '/' ) continue;

                    // Skip filtered URLs
                    if ( $this->should_skip_404( $path ) ) continue;

                    // Check if this URL resolves to real content (posts, pages, Polylang homes, taxonomies)
                    // Uses the same comprehensive check as the live 404 monitor
                    if ( $this->url_resolves_to_content( $path ) ) {
                        $already_ok++;
                        continue;
                    }

                    // Check if there's already a redirect rule for this URL
                    $normalized = self::normalize_url( $path );
                    $hash = md5( $normalized );
                    $has_rule = $wpdb->get_var( $wpdb->prepare(
                        "SELECT id FROM {$wpdb->prefix}" . self::TABLE_RULES . " WHERE source_hash = %s AND enabled = 1 LIMIT 1",
                        $hash
                    ) );
                    if ( $has_rule ) {
                        $already_redirected++;
                        continue;
                    }

                    // Check if already in the 404 log
                    $url_hash = md5( $normalized );
                    $exists = $wpdb->get_var( $wpdb->prepare(
                        "SELECT id FROM {$t404} WHERE url_hash = %s LIMIT 1",
                        $url_hash
                    ) );
                    if ( $exists ) {
                        // Update source to 'gsc' if it was 'monitor' and add GSC clicks data
                        $wpdb->query( $wpdb->prepare(
                            "UPDATE {$t404} SET source = 'gsc' WHERE id = %d AND source = 'monitor'",
                            $exists
                        ) );
                        $already_logged++;
                        continue;
                    }

                    // This is a NEW 404 discovered via GSC — import it
                    $wpdb->insert( $t404, array(
                        'url'         => $normalized,
                        'url_hash'    => $url_hash,
                        'referer'     => 'Google Search',
                        'user_agent'  => 'Googlebot (GSC import)',
                        'ip_hash'     => '',
                        'hit_count'   => max( 1, (int) $gsc_row['total_clicks'] ),
                        'is_external' => 1,
                        'first_seen'  => current_time( 'mysql' ),
                        'last_seen'   => current_time( 'mysql' ),
                        'status'      => 'new',
                        'source'      => 'gsc',
                    ) );

                    // Try to auto-suggest a redirect
                    $new_id = $wpdb->insert_id;
                    if ( $new_id ) {
                        $this->auto_suggest_redirect( $normalized, $new_id );
                        $imported++;
                    }
                }

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Import GSC 404 : %d nouvelles, %d déjà loggées, %d déjà redirigées, %d OK',
                            $imported, $already_logged, $already_redirected, $already_ok ),
                        'success', 'redirects'
                    );
                }
                wp_send_json_success( array(
                    'imported'           => $imported,
                    'already_logged'     => $already_logged,
                    'already_redirected' => $already_redirected,
                    'already_ok'         => $already_ok,
                    'total_checked'      => count( $gsc_urls ),
                ) );
                break;

            case 'audit_ai_redirects':
                // Audit all ai_auto redirections: check if source actually 404s and target resolves
                global $wpdb;
                $trule = $wpdb->prefix . self::TABLE_RULES;
                $ai_rules = $wpdb->get_results(
                    "SELECT id, source_url, target_url, hit_count, notes FROM {$trule} WHERE origin = 'ai_auto' AND enabled = 1 ORDER BY hit_count DESC LIMIT 200",
                    ARRAY_A
                );
                $ok = 0;
                $broken_target = array();
                $high_traffic_redirected = array();
                $total = count( $ai_rules );

                // Check if GSC table exists
                $t_gsc_audit = $wpdb->prefix . 'hts_gsc_data';
                $gsc_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$t_gsc_audit}'" );

                foreach ( $ai_rules as $rule ) {
                    // GSC traffic of the SOURCE page (was it valuable before redirect?)
                    $src_gsc = 0;
                    if ( $gsc_exists ) {
                        $full_src = home_url( $rule['source_url'] );
                        $src_gsc = (int) $wpdb->get_var( $wpdb->prepare(
                            "SELECT SUM(clicks) FROM {$t_gsc_audit} WHERE url = %s AND fetch_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)",
                            $full_src
                        ) );
                    }

                    // Check if target post still exists
                    $target_id = hts_url_to_postid( $rule['target_url'] );
                    $target_ok = false;
                    if ( $target_id > 0 ) {
                        $post = get_post( $target_id );
                        if ( $post && $post->post_status === 'publish' ) {
                            $target_ok = true;
                        }
                    }

                    if ( $target_ok ) {
                        $ok++;
                        // Flag if source had significant GSC traffic (>10 clicks = needs review)
                        if ( $src_gsc > 10 ) {
                            $high_traffic_redirected[] = array(
                                'id'         => $rule['id'],
                                'source'     => $rule['source_url'],
                                'target'     => $rule['target_url'],
                                'gsc_clicks' => $src_gsc,
                                'hits'       => $rule['hit_count'],
                            );
                        }
                    } else {
                        $broken_target[] = array(
                            'id'         => $rule['id'],
                            'source'     => $rule['source_url'],
                            'target'     => $rule['target_url'],
                            'gsc_clicks' => $src_gsc,
                            'hits'       => $rule['hit_count'],
                        );
                    }
                }
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Audit IA : %d vérifiées, %d OK, %d cibles cassées, %d avec trafic GSC', $total, $ok, count( $broken_target ), count( $high_traffic_redirected ) ),
                        count( $broken_target ) > 0 ? 'warning' : 'success', 'redirects'
                    );
                }
                wp_send_json_success( array(
                    'total'          => $total,
                    'ok'             => $ok,
                    'broken'         => count( $broken_target ),
                    'broken_list'    => array_slice( $broken_target, 0, 20 ),
                    'high_traffic'   => count( $high_traffic_redirected ),
                    'high_traffic_list' => array_slice( $high_traffic_redirected, 0, 20 ),
                ) );
                break;

            default:
                wp_send_json_error( 'Action inconnue' );
        }
    }

    /**
     * Re-run AI suggestion for a specific 404.
     */
    public function ajax_suggest_ai() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        $id = (int) ( $_POST['id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'ID requise' );

        global $wpdb;
        $t404 = $wpdb->prefix . self::TABLE_404;
        $row  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t404} WHERE id = %d", $id ), ARRAY_A );
        if ( ! $row ) wp_send_json_error( '404 non trouvée' );

        // Reset and re-suggest
        $wpdb->update( $t404, array( 'status' => 'new', 'suggested_target' => null, 'suggested_score' => null ), array( 'id' => $id ) );
        $this->auto_suggest_redirect( $row['url'], $id );

        // Reload
        $updated = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t404} WHERE id = %d", $id ), ARRAY_A );
        wp_send_json_success( $updated );
    }

    /**
     * Bulk actions on 404s or redirects.
     */
    public function ajax_bulk_action() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        global $wpdb;
        $action = sanitize_text_field( $_POST['sub_action'] ?? '' );
        $ids    = array_map( 'intval', (array) ( $_POST['ids'] ?? array() ) );
        // Filter out zeros (invalid IDs)
        $ids    = array_filter( $ids, function( $id ) { return $id > 0; } );

        if ( empty( $ids ) ) wp_send_json_error( 'Aucun ID sélectionné' );

        // Build safe placeholders for IN clause
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

        switch ( $action ) {
            case 'ignore_404s':
                $wpdb->query( $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}" . self::TABLE_404 . " SET status = 'ignored' WHERE id IN ({$placeholders})",
                    $ids
                ) );
                if ( function_exists('hts_add_log') ) {
                    hts_add_log( '404 ignorées en lot : ' . count($ids) . ' entrées', 'info', 'redirects' );
                }
                break;
            case 'delete_redirects':
                $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$wpdb->prefix}" . self::TABLE_RULES . " WHERE id IN ({$placeholders})",
                    $ids
                ) );
                wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );
                if ( function_exists('hts_add_log') ) {
                    hts_add_log( 'Redirections supprimées en lot : ' . count($ids), 'warning', 'redirects' );
                }
                break;
            case 'accept_all_suggestions':
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}" . self::TABLE_404 . " WHERE id IN ({$placeholders}) AND suggested_target IS NOT NULL AND status IN ('new','suggested')",
                    $ids
                ), ARRAY_A );
                $created = 0;
                foreach ( $rows as $row ) {
                    $target_url = get_permalink( (int) $row['suggested_target'] );
                    if ( $target_url ) {
                        $this->add_redirect_rule(
                            wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'],
                            $target_url, 301, 'ai_suggested',
                            sprintf( 'Bulk AI accept (score %.0f%%)', ( $row['suggested_score'] ?? 0 ) * 100 )
                        );
                        $wpdb->update( $wpdb->prefix . self::TABLE_404, array( 'status' => 'redirected' ), array( 'id' => $row['id'] ) );
                        $created++;
                    }
                }
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "{$created} suggestions IA acceptées en lot", 'success', 'redirects' );
                }
                break;
        }

        wp_send_json_success();
    }

    /**
     * Get full dashboard data via AJAX.
     */
    public function ajax_get_dashboard_data() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        $offset    = (int) ( $_POST['offset'] ?? 0 );
        $hide_bots = ( $_POST['hide_bots'] ?? '1' ) === '1';
        wp_send_json_success( self::get_dashboard_data( $offset, $hide_bots ) );
    }

    /* ══════════════════════════════════════════════
     *  IMPORT / EXPORT CSV
     * ══════════════════════════════════════════════ */

    public function ajax_import_csv() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        if ( empty( $_FILES['csv_file'] ) ) wp_send_json_error( 'Aucun fichier' );

        // Validate file extension
        $ext = strtolower( pathinfo( $_FILES['csv_file']['name'] ?? '', PATHINFO_EXTENSION ) );
        if ( ! in_array( $ext, array( 'csv', 'tsv', 'txt' ), true ) ) {
            wp_send_json_error( 'Format accepté : CSV, TSV ou TXT uniquement.' );
        }

        // Validate file size (max 2MB)
        if ( ( $_FILES['csv_file']['size'] ?? 0 ) > 2 * 1024 * 1024 ) {
            wp_send_json_error( 'Fichier trop volumineux (max 2 Mo).' );
        }

        $file = $_FILES['csv_file']['tmp_name'];
        if ( ! is_readable( $file ) ) wp_send_json_error( 'Fichier illisible' );

        $handle  = fopen( $file, 'r' );
        if ( ! $handle ) {
            wp_send_json_error( 'Impossible d\'ouvrir le fichier.' );
        }
        $header  = fgetcsv( $handle, 0, ',' );
        $count   = 0;
        $errors  = 0;
        $max_rows = 2000; // Safety limit to prevent PHP timeout on massive files

        while ( ( $row = fgetcsv( $handle, 0, ',' ) ) !== false ) {
            if ( $count + $errors >= $max_rows ) {
                $errors++;
                break; // Stop processing, inform client
            }
            if ( count( $row ) < 2 ) { $errors++; continue; }

            $source = trim( $row[0] );
            $target = trim( $row[1] );
            $type   = isset( $row[2] ) ? (int) $row[2] : 301;
            $regex  = isset( $row[3] ) ? (int) $row[3] : 0;
            $notes  = isset( $row[4] ) ? trim( $row[4] ) : 'Import CSV';

            // Validate redirect type
            if ( ! in_array( $type, array( 301, 302, 307, 308, 410 ), true ) ) $type = 301;

            if ( ! $source || ( ! $target && $type !== 410 ) ) { $errors++; continue; }

            global $wpdb;
            $source_clean = $regex ? $source : self::normalize_url( $source );
            $wpdb->insert( $wpdb->prefix . self::TABLE_RULES, array(
                'source_url'    => $source_clean,
                'source_hash'   => md5( $source_clean ),
                'target_url'    => ( strpos( $target, '/' ) === 0 ) ? sanitize_text_field( $target ) : esc_url_raw( $target ),
                'redirect_type' => $type,
                'is_regex'      => $regex,
                'origin'        => 'import',
                'notes'         => sanitize_text_field( $notes ),
                'enabled'       => 1,
            ) );
            $count++;
        }

        fclose( $handle );
        wp_cache_delete( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_regex_rules' ); delete_transient( 'hts_redirect_patterns_cache' );
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Import CSV : {$count} redirections importées" . ( $errors ? ", {$errors} erreurs" : '' ), 'success', 'redirects' );
        }
        wp_send_json_success( array( 'imported' => $count, 'errors' => $errors ) );
    }

    public function ajax_export_csv() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_RULES;
        $rules = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY created_at DESC", ARRAY_A );

        $csv = "source_url,target_url,redirect_type,is_regex,notes,origin,hit_count,enabled\n";
        foreach ( $rules as $r ) {
            $csv .= sprintf(
                '"%s","%s",%d,%d,"%s","%s",%d,%d' . "\n",
                $r['source_url'], $r['target_url'], $r['redirect_type'], $r['is_regex'],
                str_replace( '"', '""', $r['notes'] ), $r['origin'], $r['hit_count'], $r['enabled']
            );
        }

        wp_send_json_success( array( 'csv' => $csv ) );
    }

    /* ══════════════════════════════════════════════
     *  DASHBOARD DATA
     * ══════════════════════════════════════════════ */

    public static function get_dashboard_data( $offset = 0, $hide_bots = true ) {
        global $wpdb;
        $t404  = $wpdb->prefix . self::TABLE_404;
        $trule = $wpdb->prefix . self::TABLE_RULES;

        // Stats
        $stats = array(
            'total_404'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404}" ),
            'new_404'         => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status = 'new'" ),
            'suggested_404'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status = 'suggested'" ),
            'redirected_404'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status = 'redirected'" ),
            'total_redirects' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trule}" ),
            'active_redirects'=> (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trule} WHERE enabled = 1" ),
            'auto_redirects'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trule} WHERE origin IN ('slug_change','cocon')" ),
            'ai_redirects'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trule} WHERE origin IN ('ai_auto','ai_suggested')" ),
            'total_hits'      => (int) $wpdb->get_var( "SELECT COALESCE(SUM(hit_count),0) FROM {$trule}" ),
        );

        // GSC connection status
        $gsc_connected = class_exists( 'HTS_GSC_Connect' ) && ( new HTS_GSC_Connect() )->is_connected();
        $stats['gsc_connected'] = $gsc_connected;

        // GSC-based real traffic metrics (not bot hits)
        $t_gsc = $wpdb->prefix . 'hts_gsc_data';
        $gsc_table_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$t_gsc}'" );

        $stats['gsc_lost_clicks'] = 0;    // Clicks on pages that are now 404
        $stats['gsc_saved_clicks'] = 0;   // Clicks on pages that have been redirected

        if ( $gsc_table_exists ) {
            // Lost clicks: sum GSC clicks for URLs currently in the 404 log (status new/suggested)
            $stats['gsc_lost_clicks'] = (int) $wpdb->get_var(
                "SELECT COALESCE(SUM(g.clicks), 0)
                 FROM {$t_gsc} g
                 INNER JOIN {$t404} f ON g.url = CONCAT('" . esc_sql( home_url() ) . "', f.url)
                 WHERE f.status IN ('new','suggested')
                   AND g.fetch_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)"
            );

            // Saved clicks: sum GSC clicks for URLs that have active redirects
            $stats['gsc_saved_clicks'] = (int) $wpdb->get_var(
                "SELECT COALESCE(SUM(g.clicks), 0)
                 FROM {$t_gsc} g
                 INNER JOIN {$trule} r ON g.url = CONCAT('" . esc_sql( home_url() ) . "', r.source_url)
                 WHERE r.enabled = 1
                   AND g.fetch_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)"
            );
        }

        // Top 404s (new + suggested, grouped, sorted by impact)
        // Exclude 404s that already have ANY redirect rule (enabled OR disabled)
        // If a rule exists, it belongs in the Redirections tab, not here
        // Bot filtering is done in PHP after the query (not in SQL — avoids edge cases with NULL/encoding)
        // See post-query filter below after $top_404s is populated

        // Count total pending (for pagination)
        $total_pending = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$t404} f
             LEFT JOIN {$trule} r ON (
                 r.source_hash = f.url_hash
                 OR r.source_hash = MD5(LOWER(CONCAT(TRIM(TRAILING '/' FROM f.url), '/')))
             )
             WHERE f.status IN ('new','suggested')
               AND r.id IS NULL"
        );
        $stats['total_pending'] = $total_pending;

        $per_page = 200; // Fetch more rows to compensate for PHP bot filtering
        $safe_offset = max( 0, (int) $offset );

        $top_404s = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT f.*,
                        f.last_seen as last_hit,
                        (f.hit_count * (1 + f.is_external * 2)) as impact_score
                 FROM {$t404} f
                 LEFT JOIN {$trule} r ON (
                     r.source_hash = f.url_hash
                     OR r.source_hash = MD5(LOWER(CONCAT(TRIM(TRAILING '/' FROM f.url), '/')))
                 )
                 WHERE f.status IN ('new','suggested')
                   AND r.id IS NULL
                 ORDER BY impact_score DESC
                 LIMIT %d OFFSET %d",
                $per_page, $safe_offset
            ),
            ARRAY_A
        );

        // Auto-mark 404s that have ANY rule (On or Off) as 'redirected'
        $wpdb->query(
            "UPDATE {$t404} f
             INNER JOIN {$trule} r ON (
                 r.source_hash = f.url_hash
                 OR r.source_hash = MD5(LOWER(CONCAT(TRIM(TRAILING '/' FROM f.url), '/')))
             )
             SET f.status = 'redirected'
             WHERE f.status IN ('new','suggested')"
        );

        // Enrich 404s with suggestion titles, GSC data, and GEO bot flag
        // GEO = only TRUE AI content seekers (not search engine crawlers)
        $geo_bot_patterns = array( 'gptbot', 'perplexitybot', 'perplexity-user', 'claudebot', 'cohere-ai', 'google-extended', 'chatgpt-user', 'amazonbot', 'anthropic-ai' );
        // URLs that are NEVER GEO opportunities (bot probes, utility pages, security scans)
        $probe_url_patterns = array(
            '/forgot-password', '/login', '/register', '/admin', '/administrator',
            '/wp-login', '/user/', '/account', '/signin', '/signup', '/auth',
            '/phpmyadmin', '/pma', '/shell', '/webshell', '/cmd', '/getcmd',
            '/backup', '/new', '/terms', '/theme/', '/support',
            '/graphql', '/magento', '/wp-config', '/.env', '/.git',
            '/xmlrpc', '/wp-json', '/api/', '/rest/', '/debug',
        );
        foreach ( $top_404s as &$item ) {
            // Flag AI bots with multiple hits as GEO opportunities
            $ua_lower = strtolower( $item['user_agent'] ?? '' );
            $url_lower = strtolower( $item['url'] ?? '' );
            $item['is_geo_bot'] = false;

            // Must have 3+ hits AND be a real AI bot AND not a probe URL
            if ( (int) $item['hit_count'] >= 3 ) {
                $is_ai = false;
                foreach ( $geo_bot_patterns as $pattern ) {
                    if ( strpos( $ua_lower, $pattern ) !== false ) {
                        $is_ai = true;
                        break;
                    }
                }
                if ( $is_ai ) {
                    // Check URL is not a known probe/utility path
                    $is_probe = false;
                    foreach ( $probe_url_patterns as $probe ) {
                        if ( strpos( $url_lower, $probe ) !== false ) {
                            $is_probe = true;
                            break;
                        }
                    }
                    // Only content-like URLs get the GEO badge
                    $item['is_geo_bot'] = ! $is_probe;
                }
            }
            if ( $item['suggested_target'] ) {
                $sugg_post = get_post( (int) $item['suggested_target'] );
                if ( $sugg_post && $sugg_post->post_status === 'publish' ) {
                    $item['suggested_title'] = $sugg_post->post_title;
                    $item['suggested_url']   = get_permalink( $sugg_post );
                    $target_clicks = (int) get_post_meta( $sugg_post->ID, '_hts_gsc_clicks', true );
                    $item['target_gsc_clicks'] = $target_clicks;
                } else {
                    // Post deleted or unpublished — clear stale suggestion
                    $item['suggested_target'] = null;
                    $item['suggested_score']  = 0;
                    $item['suggested_title']  = '';
                    $item['suggested_url']    = '';
                }
            }

            // GSC traffic of the 404 URL itself (was this page getting traffic before it broke?)
            if ( $gsc_table_exists ) {
                $full_404_url = home_url( $item['url'] );
                $gsc_clicks = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT SUM(clicks) FROM {$t_gsc} WHERE url = %s AND fetch_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)",
                    $full_404_url
                ) );
                $item['gsc_clicks'] = $gsc_clicks;
            } else {
                $item['gsc_clicks'] = 0;
            }
        }
        unset( $item );

        // ── PHP bot filter (replaces SQL $bot_clause — bulletproof, no SQL edge cases) ──
        // When hide_bots is true: remove ONLY named spam bots from the results
        // AI bots (GEO opportunities), real visitors, GSC imports → always kept
        $pre_filter_count = count( $top_404s );
        if ( $hide_bots && ! empty( $top_404s ) ) {
            $spam_patterns = array( 'semrush', 'ahrefs', 'ahrefsbot', 'bytespider', 'mj12', 'dotbot', 'ccbot', 'yandexbot', 'baiduspider', 'sogou', 'seznambot', 'petalbot', 'dataforseo', 'zoominfobot' );
            $top_404s = array_values( array_filter( $top_404s, function( $row ) use ( $spam_patterns ) {
                $ua = strtolower( $row['user_agent'] ?? '' );
                if ( $ua === '' ) return true; // No user_agent = real visitor or unknown → keep
                foreach ( $spam_patterns as $sp ) {
                    if ( strpos( $ua, $sp ) !== false ) return false; // Spam bot → hide
                }
                return true; // Not a spam bot → keep (includes AI bots, real visitors, security probes)
            } ) );
        }
        $post_filter_count = count( $top_404s );
        // Cap at 50 for display
        $top_404s = array_slice( $top_404s, 0, 50 );
        // Use filtered count for pending (so pagination and badge are accurate)
        $stats['total_pending'] = $hide_bots ? $post_filter_count : $pre_filter_count;
        // Debug info (visible in browser console → Network → response JSON)
        $stats['_debug_filter'] = array(
            'hide_bots'        => $hide_bots,
            'sql_fetched'      => $pre_filter_count,
            'after_php_filter' => $post_filter_count,
            'displayed'        => count( $top_404s ),
            'sample_ua'        => ! empty( $top_404s ) ? substr( $top_404s[0]['user_agent'] ?? '(empty)', 0, 80 ) : '(no rows)',
        );

        // Active redirect rules
        $rules = $wpdb->get_results(
            "SELECT * FROM {$trule} ORDER BY created_at DESC LIMIT 100",
            ARRAY_A
        );

        // Enrich rules with GSC traffic of source URL (was it a valuable page?)
        if ( $gsc_table_exists ) {
            foreach ( $rules as &$rule ) {
                $full_src_url = home_url( $rule['source_url'] );
                $src_clicks = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT SUM(clicks) FROM {$t_gsc} WHERE url = %s AND fetch_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)",
                    $full_src_url
                ) );
                $rule['gsc_clicks_source'] = $src_clicks;
            }
            unset( $rule );
        }

        // Pattern detection — cached 5 min to avoid expensive REGEXP queries on every dashboard load
        $patterns = get_transient( 'hts_redirect_patterns_cache' );
        if ( false === $patterns ) {
            $patterns = self::detect_patterns();
            set_transient( 'hts_redirect_patterns_cache', $patterns, 300 );
        }

        // ── Health checks (best practice: Rank Math, Redirection, AIOSEO) ──
        $health = array();

        // A1: Redirect chain detection (A→B where B is source of another rule B→C)
        $chains = $wpdb->get_results(
            "SELECT r1.id as chain_start_id, r1.source_url as chain_start, r1.target_url as chain_mid,
                    r2.target_url as chain_end, r1.hit_count
             FROM {$trule} r1
             INNER JOIN {$trule} r2 ON r2.source_hash = MD5(LOWER(TRIM(TRAILING '/' FROM
                 COALESCE(SUBSTRING_INDEX(r1.target_url, '://', -1), r1.target_url)
             )))
             WHERE r1.enabled = 1 AND r2.enabled = 1
             LIMIT 20",
            ARRAY_A
        );
        // Simpler fallback: check if any target path matches a source
        if ( empty( $chains ) ) {
            $chains = $wpdb->get_results(
                "SELECT r1.id as chain_start_id, r1.source_url as chain_start, r1.target_url as chain_mid,
                        r2.target_url as chain_end, r1.hit_count
                 FROM {$trule} r1
                 INNER JOIN {$trule} r2 ON r2.source_url = TRIM(TRAILING '/' FROM
                     SUBSTRING_INDEX(r1.target_url, '://', -1)
                 ) OR r2.source_url = CONCAT(TRIM(TRAILING '/' FROM
                     SUBSTRING_INDEX(r1.target_url, '://', -1)
                 ), '/')
                 WHERE r1.enabled = 1 AND r2.enabled = 1 AND r1.id != r2.id
                 LIMIT 20",
                ARRAY_A
            );
        }
        if ( ! empty( $chains ) ) {
            $health[] = array(
                'type'    => 'chain',
                'severity'=> 'warning',
                'label'   => sprintf( '%d chaîne(s) de redirections détectée(s)', count( $chains ) ),
                'desc'    => 'Des redirections pointent vers d\'autres redirections. Cela ralentit le site et gaspille le budget de crawl Google.',
                'action'  => 'Raccourcir les chaînes pour pointer directement vers la destination finale.',
                'items'   => array_slice( $chains, 0, 5 ),
            );
        }

        // A3: Stale redirects (target URL no longer resolves to a published post)
        $stale = array();
        $sample_rules = $wpdb->get_results(
            "SELECT id, source_url, target_url, hit_count FROM {$trule} WHERE enabled = 1 AND is_regex = 0 ORDER BY hit_count DESC LIMIT 50",
            ARRAY_A
        );
        foreach ( $sample_rules as $rule ) {
            $target_path = wp_parse_url( $rule['target_url'], PHP_URL_PATH );
            if ( $target_path ) {
                $target_id = hts_url_to_postid( $rule['target_url'] );
                if ( $target_id > 0 ) {
                    $post = get_post( $target_id );
                    if ( $post && $post->post_status !== 'publish' ) {
                        $stale[] = $rule;
                    }
                }
                // Also flag if target is homepage and source is a content page (lazy redirect)
            }
        }
        if ( ! empty( $stale ) ) {
            $health[] = array(
                'type'     => 'stale',
                'severity' => 'error',
                'label'    => sprintf( '%d redirection(s) vers des pages supprimées', count( $stale ) ),
                'desc'     => 'Ces redirections pointent vers des pages qui n\'existent plus ou ne sont plus publiées.',
                'action'   => 'Mettre à jour la destination ou supprimer la redirection.',
                'items'    => array_slice( $stale, 0, 5 ),
            );
        }

        // A4: 404 spike detection (last 24h vs 7-day average)
        $last_24h = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$t404} WHERE first_seen >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );
        $avg_7d = (float) $wpdb->get_var(
            "SELECT COUNT(*) / 7 FROM {$t404} WHERE first_seen >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND first_seen < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );
        if ( $avg_7d > 0 && $last_24h > $avg_7d * 3 && $last_24h > 10 ) {
            $health[] = array(
                'type'     => 'spike',
                'severity' => 'warning',
                'label'    => sprintf( 'Pic de 404 : %d nouvelles erreurs en 24h (moyenne : %.0f/jour)', $last_24h, $avg_7d ),
                'desc'     => 'Le nombre d\'erreurs 404 a triplé par rapport à la normale. Vérifiez si une migration ou une modification a cassé des liens.',
                'action'   => 'Vérifier les dernières modifications du site.',
                'items'    => array(),
            );
        }

        return array(
            'stats'    => $stats,
            'top_404s' => $top_404s,
            'rules'    => $rules,
            'patterns' => $patterns,
            'health'   => $health,
        );
    }

    /**
     * Quick stats for sidebar badge.
     */
    public static function get_pending_count() {
        global $wpdb;
        $t404 = $wpdb->prefix . self::TABLE_404;

        // Check table exists
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
            DB_NAME, $t404
        ) );
        if ( ! $exists ) return 0;

        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t404} WHERE status IN ('new','suggested')" );
    }

    /* ══════════════════════════════════════════════
     *  CRON CLEANUP
     * ══════════════════════════════════════════════ */

    /**
     * Clean up old 404 logs (keep 90 days for new, 30 days for resolved).
     */
    public function cron_cleanup() {
        global $wpdb;
        $t404 = $wpdb->prefix . self::TABLE_404;

        // Remove resolved 404s older than 30 days
        $deleted_resolved = $wpdb->query(
            "DELETE FROM {$t404} WHERE status IN ('redirected','ignored') AND last_seen < DATE_SUB(NOW(), INTERVAL 30 DAY)"
        );

        // Remove new 404s older than 90 days with < 3 hits (likely one-off probes)
        $deleted_old = $wpdb->query(
            "DELETE FROM {$t404} WHERE status = 'new' AND hit_count < 3 AND last_seen < DATE_SUB(NOW(), INTERVAL 90 DAY)"
        );

        // Remove stale "new" 404s older than 180 days (prevents table from growing indefinitely)
        $deleted_stale = $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$t404} WHERE status = 'new' AND last_seen < DATE_SUB(NOW(), INTERVAL %d DAY) LIMIT 1000",
            180
        ) );

        // ── Auto-cleanup false positives: remove 404s that match filtered extensions ──
        $deleted_ext = 0;
        $pending = $wpdb->get_results(
            "SELECT id, url FROM {$t404} WHERE status IN ('new','suggested') LIMIT 500",
            ARRAY_A
        );
        foreach ( $pending as $row ) {
            $path = wp_parse_url( $row['url'], PHP_URL_PATH ) ?: $row['url'];
            if ( $this->should_skip_404( $path ) ) {
                $wpdb->delete( $t404, array( 'id' => (int) $row['id'] ) );
                $deleted_ext++;
            }
        }

        if ( $deleted_resolved || $deleted_old || $deleted_stale || $deleted_ext ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log(
 sprintf( 'Redirects cleanup : %d résolues, %d anciennes, %d stale 180j, %d faux positifs supprimés', $deleted_resolved, $deleted_old, $deleted_stale, $deleted_ext ),
                    'info', 'redirects'
                );
            }
        }

        // ── Cron AI suggest: process 404s that were rate-limited on frontend ──
        // This catches all 404s where auto_suggest was skipped due to the transient lock.
        $unsugested = $wpdb->get_results(
            "SELECT id, url FROM {$t404} WHERE status = 'new' AND suggested_target IS NULL ORDER BY hit_count DESC LIMIT 20",
            ARRAY_A
        );
        $cron_suggested = 0;
        foreach ( $unsugested as $row ) {
            $this->auto_suggest_redirect( $row['url'], (int) $row['id'] );
            $cron_suggested++;
        }
        if ( $cron_suggested > 0 && function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf( 'Cron AI suggest : %d 404s traitées', $cron_suggested ), 'info', 'redirects' );
        }

        // Invalidate patterns cache after cleanup (data changed)
        delete_transient( 'hts_redirect_patterns_cache' );
    }

    /* ══════════════════════════════════════════════
     *  .HTACCESS MANAGEMENT (optional performance mode)
     * ══════════════════════════════════════════════ */

    /**
     * Write redirect rules to .htaccess for Apache performance.
     * Only non-regex, 301 redirects are written.
     */
    public static function sync_htaccess() {
        if ( get_option( 'hts_redirects_method', 'php' ) !== 'htaccess' ) return false;

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_RULES;
        $rules = $wpdb->get_results(
            "SELECT source_url, target_url, redirect_type FROM {$table} WHERE enabled = 1 AND is_regex = 0 ORDER BY id ASC",
            ARRAY_A
        );

        $htaccess_path = ABSPATH . '.htaccess';
        if ( ! is_writable( $htaccess_path ) ) return false;

        $content = file_get_contents( $htaccess_path );

        // Remove existing HTS block
        $content = preg_replace(
            '/# BEGIN HTS Redirects.*?# END HTS Redirects\n?/s',
            '',
            $content
        );

        // Build new block
        $block = "# BEGIN HTS Redirects\n";
        $block .= "<IfModule mod_rewrite.c>\n";
        $block .= "RewriteEngine On\n";
        foreach ( $rules as $r ) {
            $src = ltrim( $r['source_url'], '/' );
            $safe_target = str_replace( array( "\r", "\n" ), '', $r['target_url'] );
            $block .= sprintf(
                "RewriteRule ^%s$ %s [R=%d,L]\n",
                preg_quote( $src, '/' ),
                $safe_target,
                $r['redirect_type']
            );
        }
        $block .= "</IfModule>\n";
        $block .= "# END HTS Redirects\n";

        // Prepend before WordPress block
        $wp_marker = '# BEGIN WordPress';
        $pos = strpos( $content, $wp_marker );
        if ( $pos !== false ) {
            $content = substr( $content, 0, $pos ) . $block . "\n" . substr( $content, $pos );
        } else {
            $content = $block . $content;
        }

        $written = file_put_contents( $htaccess_path, $content, LOCK_EX );
        if ( $written === false ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Redirects: échec écriture .htaccess — vérifier les permissions', 'error', 'redirects' );
            }
            return false;
        }
        return true;
    }

    /* ══════════════════════════════════════════════
     *  SAAS AI SUGGEST (OpenAI 4.1-mini fallback)
     *  Uses llm.hacktheseo.com API — ~$0.001 per call
     * ══════════════════════════════════════════════ */

    /**
     * Check if SaaS AI is available (API key configured + endpoint reachable).
     */
    private function can_use_saas_ai() {
        $api_key = ( function_exists( 'hts_get_api_key' ) ? hts_get_api_key() : get_option( 'hts_api_key', '' ) );
        return ! empty( $api_key );
    }

    /**
     * Detect language from a URL path using Polylang language prefixes.
     * e.g. /fr/guide-seo/ → 'fr', /en/seo-guide/ → 'en', /guide-seo/ → null
     *
     * @param string $path URL path
     * @return string|null Language slug or null if no language prefix detected
     */
    private function detect_url_language( $path ) {
        if ( ! function_exists( 'pll_languages_list' ) ) return null;

        $lang_slugs = pll_languages_list( array( 'fields' => 'slug' ) );
        if ( empty( $lang_slugs ) ) return null;

        $segments = explode( '/', trim( $path, '/' ) );
        $first = isset( $segments[0] ) ? $segments[0] : '';

        if ( $first && in_array( $first, $lang_slugs, true ) ) {
            return $first;
        }

        // Polylang can also use subdomains or query params — for now we only handle directory prefix
        return null;
    }

    /**
     * Check if a post belongs to a specific Polylang language.
     *
     * @param int    $post_id Post ID
     * @param string $lang    Language slug (e.g. 'fr', 'en')
     * @return bool True if post is in the specified language (or Polylang not active)
     */
    private function post_matches_language( $post_id, $lang ) {
        if ( ! function_exists( 'pll_get_post_language' ) ) return true; // No Polylang = always match

        $post_lang = pll_get_post_language( (int) $post_id, 'slug' );
        if ( ! $post_lang ) return true; // Post has no language assigned = allow

        return $post_lang === $lang;
    }

    /**
     * Ask SaaS AI (OpenAI 4.1-mini) to find the best redirect target.
     * Sends 404 slug + list of published page titles → returns best match post_id + score.
     *
     * @param string $slug The 404 URL slug.
     * @param array  $words Extracted meaningful words from the slug.
     * @return array|null ['post_id' => int, 'score' => float] or null.
     */
    private function saas_ai_suggest( $slug, $words, $url_lang = null ) {
        global $wpdb;

        $api_key = ( function_exists( 'hts_get_api_key' ) ? hts_get_api_key() : get_option( 'hts_api_key', '' ) );
        if ( ! $api_key ) return null;

        // Get top 50 published pages filtered by language if Polylang active
        $lang_join  = '';
        $lang_where = '';
        if ( $url_lang && function_exists( 'pll_languages_list' ) ) {
            $term = get_term_by( 'slug', $url_lang, 'language' );
            if ( $term && ! is_wp_error( $term ) ) {
                $lang_join  = " INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = ID";
                $lang_where = $wpdb->prepare( " AND tr.term_taxonomy_id = %d", $term->term_taxonomy_id );
            }
        }

        $candidates = $wpdb->get_results(
            "SELECT ID, post_title, post_name FROM {$wpdb->posts}{$lang_join}
             WHERE post_status = 'publish' AND post_type " . hts_sql_post_types_in() . "{$lang_where}
             ORDER BY ID DESC LIMIT 50",
            ARRAY_A
        );
        if ( empty( $candidates ) ) return null;

        // Build compact candidate list for the prompt
        $list = array();
        foreach ( $candidates as $c ) {
            $list[] = $c['ID'] . '|' . $c['post_name'] . '|' . $c['post_title'];
        }

        $lang_hint = $url_lang ? "\nLangue détectée de l'URL 404 : " . strtoupper( $url_lang ) . ". Ne proposer QUE des pages dans cette langue.\n" : '';
        $prompt = "Une URL 404 a été détectée : /" . $slug . "/\n"
                . "Mots-clés extraits : " . implode( ', ', $words ) . "\n"
                . $lang_hint . "\n"
                . "Voici les pages publiées du site (ID|slug|titre) :\n"
                . implode( "\n", $list ) . "\n\n"
                . "Quelle page est la meilleure cible de redirection 301 pour cette 404 ?\n"
                . "Réponds UNIQUEMENT en JSON : {\"post_id\": NUMBER, \"score\": FLOAT_0_TO_1, \"reason\": \"...\"}\n"
                . "Si aucune page ne correspond (score < 0.3), réponds : {\"post_id\": 0, \"score\": 0}";

        // Call SaaS endpoint
        $saas_url = defined( 'HTS_SAAS_URL' ) ? HTS_SAAS_URL : 'https://app.hacktheseo.com';
        $response = wp_remote_post( $saas_url . '/api/v1/redirect-suggest', array(
            'timeout' => 10,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'model'   => 'gpt-4.1-mini',
                'prompt'  => $prompt,
                'site_id' => get_option( 'hts_site_id', '' ),
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'SaaS AI suggest error: ' . $response->get_error_message(), 'warning', 'redirects' );
            }
            return null;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) return null;

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        // Handle direct JSON response or nested in 'result'
        $result = $data['result'] ?? $data;
        if ( ! is_array( $result ) ) {
            // Try parsing as raw JSON string
            $result = json_decode( $result, true );
        }

        $post_id = (int) ( $result['post_id'] ?? 0 );
        $ai_score = (float) ( $result['score'] ?? 0 );

        if ( $post_id <= 0 || $ai_score < 0.3 ) return null;

        // Verify the post actually exists and is published
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) return null;

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( 'SaaS AI suggest : /%s/ → %s (score %.0f%%, raison: %s)',
                    $slug, $post->post_title, $ai_score * 100, $result['reason'] ?? '?' ),
                'info', 'redirects'
            );
        }

        return array(
            'post_id' => $post_id,
            'score'   => $ai_score,
        );
    }

    /* ══════════════════════════════════════════════
     *  PAGE SEARCH (Autocomplete for redirect target)
     * ══════════════════════════════════════════════ */

    /**
     * Search published pages by title/slug for autocomplete.
     * Returns up to 8 results matching the query.
     */
    public function ajax_search_pages() {
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? $_REQUEST['nonce'] ?? '', 'hts_admin_nonce' ) ) { wp_send_json_error( 'Session expirée — rechargez la page (F5)' ); }
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied' );

        $q = sanitize_text_field( $_POST['q'] ?? '' );
        if ( strlen( $q ) < 2 ) wp_send_json_success( array() );

        global $wpdb;
        $like = '%' . $wpdb->esc_like( $q ) . '%';
        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_name FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type " . hts_sql_post_types_in() . "
               AND (post_title LIKE %s OR post_name LIKE %s)
             ORDER BY 
               CASE WHEN post_title LIKE %s THEN 0 ELSE 1 END,
               post_date DESC
             LIMIT 8",
            $like, $like, $like
        ), ARRAY_A );

        $pages = array();
        foreach ( $results as $r ) {
            $permalink = get_permalink( (int) $r['ID'] );
            $path = wp_parse_url( $permalink, PHP_URL_PATH ) ?: '/' . $r['post_name'] . '/';
            $pages[] = array(
                'id'    => (int) $r['ID'],
                'title' => $r['post_title'],
                'url'   => $path,
            );
        }

        wp_send_json_success( $pages );
    }
}
