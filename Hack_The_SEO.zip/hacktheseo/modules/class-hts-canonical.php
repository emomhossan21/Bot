<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Canonical & Anti-Cannibalisation Module v2
 *
 * 4-Layer Detection Engine:
 *   Layer 1: TRUE DUPLICATES     — same content hash, same title, same slug
 *   Layer 2: KEYWORD CANNIB.     — same focus keyword (RankMath/Yoast) targeting same query
 *   Layer 3: CONTENT OVERLAP     — actual text word overlap + H2 structure overlap
 *   Layer 4: GEO CONSOLIDATION   — thin pages in same cluster -> merge opportunity
 *
 * Business logic:
 *   - Embeddings are CONFIRMATION, never the primary signal
 *   - On niche sites, related content is NORMAL — only flag real conflicts
 *   - Focus keyword is the #1 cannibalisation signal
 *   - Content hash catches CMS duplicates (migration, staging, copy errors)
 *
 * @since 3.1.0
 */

class HTS_Canonical {

    const OPT_SETTINGS  = 'hts_canonical_settings';
    const OPT_CONFLICTS = 'hts_canonical_conflicts';
    const OPT_DISMISSED = 'hts_canonical_dismissed';
    const META_CANONICAL = '_hts_canonical_url';
    const MAX_CONFLICTS  = 60;

    /* French stopwords — expanded */
    private static $stopwords_fr = array(
        'dans','avec','pour','plus','aussi','cette','tout','mais','sont','etre','être','avoir','fait',
        'meme','même','comme','sans','nous','vous','leur','tres','très','bien','apres','après',
        'alors','autre','entre','quand','depuis','encore','quelque','toujours','tous','quel','quelle',
        'elle','elles','ils','cela','ceci','dont','donc','sera','etait','était','faire','peut',
        'vers','chez','doit','faut','aucun','celui','celle','ceux','rien','mieux','moins','sous',
        'avant','chaque','notre','votre','leurs','autres','assez','contre','pendant','selon','parce',
        'ainsi','deja','déjà','tant','ces','des','les','une','que','qui','par','sur','aux','ses','son',
        'comment','pourquoi','lorsque','plusieurs','seul','seule','nouveau','nouvelle','grand','grande',
        'petit','petite','premier','premiere','première','dernier','derniere','dernière','certains',
        'certaines','souvent','vraiment','toute','toutes','beaucoup','plutot','plutôt','cependant',
        'pourtant','toutefois','surtout','autrement','egalement','également','evidemment','évidemment',
        'simplement','uniquement','directement','actuellement','generalement','généralement',
        'article','page','site','blog','guide','complet','decouvrir','découvrir','savoir',
    );

    /* English stopwords */
    private static $stopwords_en = array(
        'the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','is','are',
        'was','were','be','been','has','have','had','do','does','did','will','would','could','should',
        'may','might','can','shall','this','that','these','those','it','its','not','no','nor','as',
        'if','so','than','too','very','just','about','above','after','again','all','also','am','any',
        'because','before','between','both','each','few','more','most','other','our','out','own',
        'same','some','such','then','there','through','under','up','what','when','where','which',
        'while','who','whom','why','how',
    );

    /* Spanish stopwords */
    private static $stopwords_es = array(
        'el','la','los','las','un','una','unos','unas','de','del','al','y','o','en','que','es',
        'por','con','para','como','pero','su','sus','se','no','más','este','esta','estos','estas',
    );

    /* German stopwords */
    private static $stopwords_de = array(
        'der','die','das','ein','eine','und','oder','aber','in','von','mit','auf','für','an','bei',
        'nach','zu','aus','um','über','ist','sind','war','hat','haben','wird','werden','kann',
        'nicht','auch','noch','nur','schon','wenn','als','wie','so','dass',
    );

    /* Merged stopwords (all languages) */
    private static $stopwords = null;

    /**
     * Get merged stopwords from all languages.
     *
     * @return array
     */
    private static function get_stopwords() {
        if ( self::$stopwords === null ) {
            self::$stopwords = array_merge(
                self::$stopwords_fr,
                self::$stopwords_en,
                self::$stopwords_es,
                self::$stopwords_de
            );
        }
        return self::$stopwords;
    }

    /**
     * Strip accents from a string (é→e, è→e, ê→e, etc.)
     */
    private static function strip_accents( $str ) {
        $map = array(
            'à'=>'a','â'=>'a','ä'=>'a','á'=>'a','ã'=>'a',
            'è'=>'e','ê'=>'e','ë'=>'e','é'=>'e',
            'ì'=>'i','î'=>'i','ï'=>'i','í'=>'i',
            'ò'=>'o','ô'=>'o','ö'=>'o','ó'=>'o','õ'=>'o',
            'ù'=>'u','û'=>'u','ü'=>'u','ú'=>'u',
            'ÿ'=>'y','ý'=>'y','ñ'=>'n','ç'=>'c','œ'=>'oe','æ'=>'ae',
        );
        return strtr( mb_strtolower( $str ), $map );
    }

    private static $defaults = array(
        'enabled'              => '1',
        'auto_inject'          => '1',
        'self_referencing'     => '1',
        'strategy'             => 'smart',
        'remove_wp_canonical'  => '1',
        'exclude_noindex'      => '1',
        'content_overlap_min'  => '0.25',
        'enable_geo_layer'     => '1',
    );

    public function __construct() {
        if ( get_option( 'hts_module_canonical', '1' ) !== '1' ) return;
        $this->init();
    }

    public function init() {
        // HTS always handles canonical (competitor must be deactivated via Migration Wizard)
        add_action( 'wp_head', array( $this, 'inject_canonical' ), 1 );
        $s = self::get_settings();
        if ( $s['remove_wp_canonical'] === '1' ) {
            remove_action( 'wp_head', 'rel_canonical' );
            remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
        }

        // Anti-cannibalisation detection: always active (doesn't output anything)
        add_action( 'add_meta_boxes', array( $this, 'register_metabox' ) );
        add_action( 'save_post', array( $this, 'save_metabox' ), 10, 2 );
        add_action( 'init', array( $this, 'register_post_meta' ) );

        add_action( 'wp_ajax_hts_canonical_get_data',      array( $this, 'ajax_get_data' ) );
        add_action( 'wp_ajax_hts_canonical_detect',        array( $this, 'ajax_detect' ) );
        add_action( 'wp_ajax_hts_canonical_resolve',       array( $this, 'ajax_resolve' ) );
        add_action( 'wp_ajax_hts_canonical_dismiss',       array( $this, 'ajax_dismiss' ) );
        add_action( 'wp_ajax_hts_canonical_restore',       array( $this, 'ajax_restore_dismissed' ) );
        add_action( 'wp_ajax_hts_canonical_save_settings', array( $this, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_hts_canonical_set_manual',    array( $this, 'ajax_set_manual' ) );
    }

    public static function get_settings() {
        return wp_parse_args( get_option( self::OPT_SETTINGS, array() ), self::$defaults );
    }

    /* == CANONICAL INJECTION == */

    public function inject_canonical() {
        if ( is_admin() || wp_doing_ajax() ) return;

        $s = self::get_settings();
        if ( $s['enabled'] !== '1' || $s['auto_inject'] !== '1' ) return;

        // ── Archives: category, tag, author, date, post type, pagination ──
        if ( ! is_singular() ) {
            $canonical = self::get_archive_canonical();
            if ( $canonical ) {
                echo '<link rel="canonical" href="' . esc_url( $canonical ) . '" />' . "\n";
            }
            return;
        }

        // ── Singular posts/pages ──
        $post_id = get_queried_object_id();
        if ( ! $post_id ) return;
        $canonical = self::get_canonical_url( $post_id );
        if ( $canonical ) echo '<link rel="canonical" href="' . esc_url( $canonical ) . '" />' . "\n";
    }

    /**
     * Get canonical URL for archive pages.
     *
     * Logic:
     *  - Paginated archives (/page/2+) → canonical to page 1 (base URL)
     *  - Category / Tag / Author / PostType → self-referencing (page 1)
     *  - Date archives → self-referencing
     *  - Search → no canonical (noindex anyway)
     *  - 404 → no canonical
     */
    public static function get_archive_canonical() {
        // No canonical for search results or 404
        if ( is_search() || is_404() ) return '';

        $canonical = '';

        if ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();
            if ( $term && ! is_wp_error( $term ) ) {
                $canonical = get_term_link( $term );
                if ( is_wp_error( $canonical ) ) $canonical = '';
            }
        } elseif ( is_author() ) {
            $canonical = get_author_posts_url( get_queried_object_id() );
        } elseif ( is_date() ) {
            if ( is_day() ) {
                $canonical = get_day_link( get_query_var( 'year' ), get_query_var( 'monthnum' ), get_query_var( 'day' ) );
            } elseif ( is_month() ) {
                $canonical = get_month_link( get_query_var( 'year' ), get_query_var( 'monthnum' ) );
            } elseif ( is_year() ) {
                $canonical = get_year_link( get_query_var( 'year' ) );
            }
        } elseif ( is_post_type_archive() ) {
            $canonical = get_post_type_archive_link( get_query_var( 'post_type' ) );
        } elseif ( is_home() ) {
            // Blog page
            $page_for_posts = (int) get_option( 'page_for_posts' );
            $canonical = $page_for_posts ? get_permalink( $page_for_posts ) : home_url( '/' );
        } elseif ( is_front_page() && ! is_singular() ) {
            $canonical = home_url( '/' );
        }

        // All archive canonicals point to page 1 — strip /page/N/
        if ( ! empty( $canonical ) && is_paged() ) {
            // Already pointing to base URL (page 1), no pagination appended
            // get_term_link / get_author_posts_url already return base URLs
        }

        return $canonical;
    }

    public static function get_canonical_url( $post_id ) {
        $manual = get_post_meta( $post_id, self::META_CANONICAL, true );
        if ( ! empty( $manual ) ) return $manual;

        $conflicts = get_option( self::OPT_CONFLICTS, array() );
        foreach ( $conflicts as $c ) {
            if ( ( $c['status'] ?? '' ) !== 'resolved' ) continue;
            if ( (int) ( $c['loser_id'] ?? 0 ) === (int) $post_id ) {
                $w = $c['winner_id'] ?? 0;
                if ( $w ) return get_permalink( $w );
            }
        }

        $s = self::get_settings();
        return $s['self_referencing'] === '1' ? get_permalink( $post_id ) : '';
    }

    public static function is_canonical( $pid ) {
        $url = self::get_canonical_url( $pid );
        return ( $url === get_permalink( $pid ) || empty( $url ) );
    }

    /* == METABOX == */

    public function register_post_meta() {
        foreach ( get_post_types( array( 'public' => true ) ) as $pt ) {
            register_post_meta( $pt, self::META_CANONICAL, array(
                'show_in_rest' => true, 'single' => true, 'type' => 'string',
                'auth_callback' => function() { return current_user_can( 'edit_posts' ); },
            ) );
        }
    }

    public function register_metabox() {
        foreach ( get_post_types( array( 'public' => true ) ) as $pt ) {
            add_meta_box( 'hts_canonical_metabox', "\xF0\x9F\x94\x97 HTS \xe2\x80\x94 Canonical URL", array( $this, 'render_metabox' ), $pt, 'side', 'default' );
        }
    }

    public function render_metabox( $post ) {
        wp_nonce_field( 'hts_canonical_save', 'hts_canonical_nonce' );
        $value = get_post_meta( $post->ID, self::META_CANONICAL, true );
        echo '<div style="font-size:12px;">';
        echo '<label style="font-weight:600;display:block;margin-bottom:6px;">URL Canonical</label>';
        echo '<input type="url" name="hts_canonical_url" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( get_permalink( $post->ID ) ) . '" style="width:100%;padding:6px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;">';
        echo '<p style="color:#94a3b8;margin:6px 0 0;font-size:11px;">Vide = self-referencing canonical.</p>';

        $conflicts = get_option( self::OPT_CONFLICTS, array() );
        foreach ( $conflicts as $c ) {
            if ( ( $c['status'] ?? '' ) === 'resolved' ) continue;
            if ( (int) ( $c['page_a'] ?? 0 ) === $post->ID || (int) ( $c['page_b'] ?? 0 ) === $post->ID ) {
                $other = (int) $c['page_a'] === $post->ID ? $c['page_b'] : $c['page_a'];
                echo '<div style="margin-top:8px;padding:8px;background:#fef3c7;border-radius:4px;font-size:11px;">';
                echo esc_html( $c['layer_label'] ?? 'Cannibalisation' ) . ' avec : ';
                echo '<a href="' . get_edit_post_link( $other ) . '">' . esc_html( get_the_title( $other ) ) . '</a>';
                echo '</div>';
                break;
            }
        }
        echo '</div>';
    }

    public function save_metabox( $post_id, $post ) {
        if ( ! isset( $_POST['hts_canonical_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['hts_canonical_nonce'], 'hts_canonical_save' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        $url = esc_url_raw( trim( $_POST['hts_canonical_url'] ?? '' ) );
        if ( $url === get_permalink( $post_id ) ) $url = '';
        $url ? update_post_meta( $post_id, self::META_CANONICAL, $url ) : delete_post_meta( $post_id, self::META_CANONICAL );
    }

    /* ====================================================
     *  4-LAYER DETECTION ENGINE
     * ==================================================== */

    public function detect_conflicts() {
        $settings  = self::get_settings();
        $dismissed = get_option( self::OPT_DISMISSED, array() );

        // FIX 1: Preserve previously resolved conflicts
        $old_conflicts = get_option( self::OPT_CONFLICTS, array() );
        $resolved_map  = array();
        foreach ( $old_conflicts as $oc ) {
            if ( ( $oc['status'] ?? '' ) === 'resolved' ) {
                $resolved_map[ $oc['pair_key'] ] = $oc;
            }
        }

        $posts = get_posts( array(
            'post_type' => array( 'post', 'page' ), 'post_status' => 'publish',
            'posts_per_page' => 500, 'fields' => 'ids',
        ) );
        if ( count( $posts ) < 2 ) return array();

        // FIX 3: Strip accents in stopwords once
        $sw_normalized = array();
        foreach ( self::get_stopwords() as $sw ) {
            $sw_normalized[] = self::strip_accents( $sw );
        }

        // Pre-load all page data
        $pages = array();
        $word_doc_freq = array(); // FIX 2: track how many pages contain each word
        foreach ( $posts as $pid ) {
            $post = get_post( $pid );
            if ( ! $post ) continue;
            if ( $settings['exclude_noindex'] === '1' && class_exists( 'HTS_Robots' ) && HTS_Robots::is_noindex( $pid ) ) continue;

            // FIX 5: Detect page builders — skip Elementor/Divi JSON content
            $is_builder = false;
            if ( get_post_meta( $pid, '_elementor_data', true ) ) $is_builder = true;
            if ( get_post_meta( $pid, '_et_pb_use_builder', true ) === 'on' ) $is_builder = true;

            $raw_content = $post->post_content;
            $text = wp_strip_all_tags( $raw_content );
            $wc   = hts_word_count( $text );

            // FIX 3: Strip accents before word extraction
            $text_norm = self::strip_accents( $text );

            // Significant words (accent-normalized)
            $all_words = preg_split( '/[\s\-_:,\.\|;!?\(\)\/\'"«»\x{2019}\x{2018}]+/u', $text_norm );
            $sig = array();
            foreach ( $all_words as $w ) {
                $w = trim( $w );
                if ( mb_strlen( $w ) <= 3 || in_array( $w, $sw_normalized ) ) continue;
                $sig[] = $w;
            }
            $sig_set = array_unique( $sig );

            // FIX 2: Track document frequency for each word
            foreach ( $sig_set as $word ) {
                if ( ! isset( $word_doc_freq[ $word ] ) ) $word_doc_freq[ $word ] = 0;
                $word_doc_freq[ $word ]++;
            }

            // H2 headings
            preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $raw_content, $h2m );
            $h2s = array_map( function( $h ) { return self::strip_accents( trim( wp_strip_all_tags( $h ) ) ); }, $h2m[1] ?? array() );

            // Focus keyword
            $fkw = get_post_meta( $pid, 'rank_math_focus_keyword', true ) ?: get_post_meta( $pid, '_yoast_wpseo_focuskw', true );

            $pages[ $pid ] = array(
                'title'      => self::strip_accents( trim( $post->post_title ) ),
                'slug'       => $post->post_name,
                'hash'       => md5( $text ),
                'wc'         => $wc,
                'sig'        => $sig,
                'sig_set'    => $sig_set,
                'h2s'        => $h2s,
                'fkw'        => self::strip_accents( trim( $fkw ) ),
                'cluster'    => '',
                'is_pillar'  => false,
                'is_builder' => $is_builder,
            );
        }

        $page_count = count( $pages );

        // FIX 2: Build corpus stopwords — words appearing in >40% of pages
        $corpus_threshold = max( 3, (int) ( $page_count * 0.40 ) );
        $corpus_stopwords = array();
        foreach ( $word_doc_freq as $word => $freq ) {
            if ( $freq >= $corpus_threshold ) {
                $corpus_stopwords[ $word ] = true;
            }
        }

        // FIX 2: Filter sig_set to remove corpus-wide common words
        foreach ( $pages as $pid => &$pdata ) {
            $pdata['sig_set_filtered'] = array_values( array_filter( $pdata['sig_set'], function( $w ) use ( $corpus_stopwords ) {
                return ! isset( $corpus_stopwords[ $w ] );
            } ) );
        }
        unset( $pdata );

        // Load cocon data
        $pillars = array();
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new HTS_Cocon();
            $cdata = $cocon->get_cocon_data();
            foreach ( $cdata['clusters'] ?? array() as $cn => $cl ) {
                $pil = (int) ( $cl['pillar_id'] ?? 0 );
                if ( $pil ) $pillars[ $cn ] = $pil;
                foreach ( $cl['pages'] ?? array() as $cpid ) {
                    if ( isset( $pages[ (int)$cpid ] ) ) {
                        $pages[ (int)$cpid ]['cluster']   = $cn;
                        $pages[ (int)$cpid ]['is_pillar'] = ( (int)$cpid === $pil );
                    }
                }
            }
        }

        // Load embeddings (confirmation only)
        $vectors = array();
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb = new HTS_Embeddings();
            $vectors = $emb->load_all_vectors( true );
        }

        // Detection loop
        $conflicts = array();
        $seen = array();
        $pids = array_keys( $pages );
        $cnt  = count( $pids );

        for ( $i = 0; $i < $cnt; $i++ ) {
            for ( $j = $i + 1; $j < $cnt; $j++ ) {
                $pa = $pids[$i]; $pb = $pids[$j];
                $pk = $pa . '-' . $pb;
                if ( in_array( $pk, $dismissed ) || isset( $seen[$pk] ) ) continue;

                $a = $pages[$pa]; $b = $pages[$pb];
                $c = null;

                // Layer 1: Duplicates
                $c = $this->layer_duplicate( $pa, $pb, $a, $b );
                // Layer 2: Keywords
                if ( !$c ) $c = $this->layer_keyword( $pa, $pb, $a, $b, $vectors );
                // Layer 3: Content (uses filtered sig_set)
                if ( !$c ) $c = $this->layer_content( $pa, $pb, $a, $b, $vectors, $settings );
                // Layer 4: GEO
                if ( !$c && $settings['enable_geo_layer'] === '1' ) $c = $this->layer_geo( $pa, $pb, $a, $b, $vectors );

                if ( $c ) {
                    $c['pair_key'] = $pk;
                    $c['page_a']   = $pa;
                    $c['page_b']   = $pb;
                    $c['title_a']  = get_the_title( $pa );
                    $c['title_b']  = get_the_title( $pb );
                    $c['status']   = 'pending';
                    $c['suggestion'] = $this->suggest( $pa, $pb, $a, $b, $c, $pillars, $settings['strategy'] );

                    // FIX 1: Restore resolved status if previously resolved
                    if ( isset( $resolved_map[ $pk ] ) ) {
                        $c['status']      = 'resolved';
                        $c['resolved_at'] = $resolved_map[ $pk ]['resolved_at'] ?? '';
                        $c['winner_id']   = $resolved_map[ $pk ]['winner_id'] ?? 0;
                        $c['loser_id']    = $resolved_map[ $pk ]['loser_id'] ?? 0;
                        $c['action']      = $resolved_map[ $pk ]['action'] ?? '';
                    }

                    $conflicts[] = $c;
                    $seen[$pk] = 1;
                }
            }
        }

        // FIX 1: Also keep resolved conflicts that are no longer detected (don't lose history)
        foreach ( $resolved_map as $pk => $rc ) {
            if ( ! isset( $seen[$pk] ) ) {
                $conflicts[] = $rc;
            }
        }

        // Sort
        $ro = array( 'critical' => 0, 'high' => 1, 'medium' => 2, 'opportunity' => 3 );
        usort( $conflicts, function( $a, $b ) use ( $ro ) {
            // Resolved always at the end
            $sa = ( $a['status'] ?? '' ) === 'resolved' ? 1 : 0;
            $sb = ( $b['status'] ?? '' ) === 'resolved' ? 1 : 0;
            if ( $sa !== $sb ) return $sa - $sb;
            $ra = $ro[$a['risk'] ?? 'medium'] ?? 9;
            $rb = $ro[$b['risk'] ?? 'medium'] ?? 9;
            return $ra !== $rb ? $ra - $rb : ($b['score'] ?? 0) <=> ($a['score'] ?? 0);
        } );

        $total = count( $conflicts );
        if ( $total > self::MAX_CONFLICTS ) $conflicts = array_slice( $conflicts, 0, self::MAX_CONFLICTS );

        update_option( self::OPT_CONFLICTS, $conflicts, false );
        update_option( 'hts_canonical_total_found', $total, false );

        // Store corpus stats for debug
        update_option( 'hts_canonical_corpus_stopwords', count( $corpus_stopwords ), false );
        update_option( 'hts_canonical_last_scan', current_time( 'mysql' ), false );

        return $conflicts;
    }

    /* -- LAYER 1: TRUE DUPLICATES -- */
    private function layer_duplicate( $pa, $pb, $a, $b ) {
        // Slug similarity (helps detect copy errors vs real duplicates)
        $slug_sim = 0;
        $sw_a = array_filter( preg_split('/[-_]/', $a['slug']), function($w){ return mb_strlen($w) > 2; } );
        $sw_b = array_filter( preg_split('/[-_]/', $b['slug']), function($w){ return mb_strlen($w) > 2; } );
        if ( !empty($sw_a) && !empty($sw_b) ) {
            $si = count( array_intersect($sw_a, $sw_b) );
            $su = count( array_unique( array_merge($sw_a, $sw_b) ) );
            $slug_sim = $su > 0 ? $si / $su : 0;
        }

        // ── Case 1: Exact same content (hash match) ──
        // FIX 4: wc > 100 (was 50) to avoid false positives on thin/placeholder content
        // FIX 5: Skip if either page uses a page builder (Elementor/Divi strip to same text)
        if ( $a['hash'] === $b['hash'] && $a['wc'] > 100 && !($a['is_builder'] ?? false) && !($b['is_builder'] ?? false) ) {
            // Slugs very different = CMS copy error (content pasted in wrong post)
            if ( $slug_sim < 0.20 ) {
                return array(
                    'layer' => 'copy_error', 'layer_label' => "\xF0\x9F\x94\xB4 Erreur CMS",
                    'risk' => 'critical', 'score' => 100,
                    'detail' => "post_content identique (MD5) mais slugs differents :\n/" . $a['slug'] . "/ vs /" . $b['slug'] . "/\n→ Le contenu a ete copie dans le mauvais post. Verifier et corriger le post_content.",
                    'evidence' => array('type'=>'copy_error','hash_match'=>true,'slug_a'=>$a['slug'],'slug_b'=>$b['slug'],'slug_sim'=>round($slug_sim,4),'wc_a'=>$a['wc'],'wc_b'=>$b['wc']),
                );
            }
            // Slugs similar = true duplicate
            return array(
                'layer' => 'duplicate', 'layer_label' => "\xF0\x9F\x94\xB4 Doublon exact",
                'risk' => 'critical', 'score' => 100,
                'detail' => 'Contenu identique (MD5)' . ($a['title']===$b['title'] ? ' + titre identique' : '') . ' — /' . $a['slug'] . '/ vs /' . $b['slug'] . '/',
                'evidence' => array('type'=>'content_duplicate','hash_match'=>true,'slug_a'=>$a['slug'],'slug_b'=>$b['slug'],'wc_a'=>$a['wc'],'wc_b'=>$b['wc']),
            );
        }

        // ── Case 2: Same title — check if content is similar or not ──
        if ( $a['title'] === $b['title'] && ! empty( $a['title'] ) ) {
            // Quick content similarity check via sig_words
            $sa = $a['sig_set']; $sb = $b['sig_set'];
            $content_sim = 0;
            if ( ! empty( $sa ) && ! empty( $sb ) ) {
                $inter = count( array_intersect( $sa, $sb ) );
                $union = count( array_unique( array_merge( $sa, $sb ) ) );
                $content_sim = $union > 0 ? $inter / $union : 0;
            }

            if ( $content_sim > 0.30 ) {
                return array(
                    'layer' => 'duplicate', 'layer_label' => "\xF0\x9F\x94\xB4 Quasi-doublon",
                    'risk' => 'critical', 'score' => 95,
                    'detail' => 'Titre identique + contenu similaire (' . round($content_sim*100) . '%) — /' . $a['slug'] . '/ vs /' . $b['slug'] . '/',
                    'evidence' => array('type'=>'near_duplicate','content_sim'=>round($content_sim,4),'slug_a'=>$a['slug'],'slug_b'=>$b['slug'],'wc_a'=>$a['wc'],'wc_b'=>$b['wc']),
                );
            } else {
                return array(
                    'layer' => 'title_bug', 'layer_label' => "\xF0\x9F\x94\xB4 Bug titre",
                    'risk' => 'critical', 'score' => 90,
                    'detail' => 'Meme titre mais contenu different (' . round($content_sim*100) . '% overlap) — /' . $a['slug'] . '/ vs /' . $b['slug'] . '/ → un post_title est incorrect',
                    'evidence' => array('type'=>'title_mismatch','content_sim'=>round($content_sim,4),'slug_a'=>$a['slug'],'slug_b'=>$b['slug'],'wc_a'=>$a['wc'],'wc_b'=>$b['wc']),
                );
            }
        }

        // ── Case 3: Same slug ──
        if ( $a['slug'] === $b['slug'] && ! empty( $a['slug'] ) ) {
            return array(
                'layer' => 'duplicate', 'layer_label' => "\xF0\x9F\x94\xB4 Slug doublon",
                'risk' => 'high', 'score' => 70,
                'detail' => 'Slug identique : /' . $a['slug'] . '/',
                'evidence' => array('type'=>'slug_duplicate','slug'=>$a['slug']),
            );
        }

        return null;
    }

    /* -- LAYER 2: KEYWORD CANNIBALISATION -- */
    private function layer_keyword( $pa, $pb, $a, $b, $vectors ) {
        if ( empty($a['fkw']) || empty($b['fkw']) ) return null;

        $exact    = ( $a['fkw'] === $b['fkw'] );

        // "Contains" check — but exclude pillar/support relationships
        $contains = false;
        if ( !$exact ) {
            $a_in_b = mb_strpos( $b['fkw'], $a['fkw'] ) !== false;
            $b_in_a = mb_strpos( $a['fkw'], $b['fkw'] ) !== false;

            if ( $a_in_b || $b_in_a ) {
                // Count words in each keyword
                $wa = count( array_filter( explode(' ', $a['fkw']), function($w){ return mb_strlen($w) > 1; } ) );
                $wb = count( array_filter( explode(' ', $b['fkw']), function($w){ return mb_strlen($w) > 1; } ) );
                $short = min($wa, $wb);
                $long  = max($wa, $wb);

                // If the short keyword is 1 word and the long is 2+, this is pillar/support
                // e.g. "psilocybine" (1 word) vs "depression psilocybine" (2 words) → NOT cannibalization
                // But "depression psilocybine" (2) vs "psilocybine depression traitement" (3) → could be cannibalization
                if ( $short === 1 && $long >= 2 ) {
                    // 1-word keyword contained in 2+ word keyword = pillar/support → SKIP
                    $contains = false;
                } elseif ( $long - $short >= 2 ) {
                    // Very different lengths (2+ extra words) = hierarchical → SKIP
                    $contains = false;
                } else {
                    // Close in length (e.g. "depression psilocybine" vs "psilocybine depression") → real overlap
                    $contains = true;
                }

                // Exception: if BOTH pages are pillar → flag anyway (conflict)
                if ( !$contains && $a['is_pillar'] && $b['is_pillar'] ) {
                    $contains = true;
                }
            }
        }

        // Cross-title check (keyword A in title B AND keyword B in title A)
        $cross = !$exact && !$contains && ( mb_strpos($b['title'],$a['fkw']) !== false && mb_strpos($a['title'],$b['fkw']) !== false );

        if ( !$exact && !$contains && !$cross ) return null;

        $esim = 0;
        if ( isset($vectors[$pa]) && isset($vectors[$pb]) ) $esim = HTS_Embeddings::cosine_similarity($vectors[$pa],$vectors[$pb]);

        $risk = 'high'; $score = 80;
        if ( $exact ) { $risk = 'critical'; $score = 95; }
        elseif ( $contains && $esim > 0.85 ) { $risk = 'critical'; $score = 90; }

        $r = array();
        if ($exact) $r[] = 'Meme focus keyword : "' . $a['fkw'] . '"';
        elseif ($contains) $r[] = 'Keywords proches : "' . $a['fkw'] . '" / "' . $b['fkw'] . '"';
        else $r[] = 'Keywords croises dans les titres';
        if ($esim > 0.80) $r[] = 'Embeddings : ' . round($esim*100) . '%';
        if ($a['cluster'] && $a['cluster']===$b['cluster']) $r[] = 'Cluster : ' . $a['cluster'];

        return array(
            'layer' => 'keyword', 'layer_label' => "\xF0\x9F\x9F\xA0 Meme mot-cle",
            'risk' => $risk, 'score' => $score,
            'detail' => implode( ' / ', $r ),
            'evidence' => array( 'fkw_a'=>$a['fkw'], 'fkw_b'=>$b['fkw'], 'exact'=>$exact, 'contains'=>$contains, 'embed_sim'=>round($esim,4) ),
        );
    }

    /* -- LAYER 3: CONTENT OVERLAP -- */
    private function layer_content( $pa, $pb, $a, $b, $vectors, $settings ) {
        if ( $a['wc'] < 100 || $b['wc'] < 100 ) return null;
        // Must be same cluster
        if ( !$a['cluster'] || $a['cluster'] !== $b['cluster'] ) return null;

        // FIX 2: Use corpus-filtered significant words (removes niche-wide common terms)
        $sa = $a['sig_set_filtered'] ?? $a['sig_set'];
        $sb = $b['sig_set_filtered'] ?? $b['sig_set'];
        if ( empty($sa) || empty($sb) ) return null;

        $inter  = array_intersect( $sa, $sb );
        $union  = array_unique( array_merge( $sa, $sb ) );
        $jacc   = count($union) > 0 ? count($inter) / count($union) : 0;

        // H2 overlap
        $h2ov = 0;
        if ( !empty($a['h2s']) && !empty($b['h2s']) ) {
            $h2c = 0;
            foreach ( $a['h2s'] as $ha ) {
                foreach ( $b['h2s'] as $hb ) {
                    $wa = array_filter(explode(' ',$ha), function($w){return mb_strlen($w)>3;});
                    $wb = array_filter(explode(' ',$hb), function($w){return mb_strlen($w)>3;});
                    if (!empty($wa) && !empty($wb)) {
                        $cm = count(array_intersect($wa,$wb));
                        if ($cm / min(count($wa),count($wb)) > 0.6) $h2c++;
                    }
                }
            }
            $minh = min(count($a['h2s']),count($b['h2s']));
            $h2ov = $minh > 0 ? $h2c / $minh : 0;
        }

        // Embedding confirmation
        $esim = 0;
        if ( isset($vectors[$pa]) && isset($vectors[$pb]) ) $esim = HTS_Embeddings::cosine_similarity($vectors[$pa],$vectors[$pb]);

        $min_ov = (float)($settings['content_overlap_min'] ?? 0.25);
        if ( $jacc < $min_ov ) return null;

        // Need 2+ signals
        $h2ok  = $h2ov > 0.40;
        $embok = $esim > 0.88;
        if ( !$h2ok && !$embok && $jacc < 0.40 ) return null;

        $risk = 'medium'; $score = round($jacc*100);
        if ( $jacc > 0.45 && ($h2ok || $embok) ) {
            $risk = 'high';
            $score = round( $jacc*60 + $h2ov*20 + $esim*20 );
        }

        $r = array('Contenu : ' . round($jacc*100) . '% mots communs');
        if ($h2ok) $r[] = 'H2 similaires : ' . round($h2ov*100) . '%';
        if ($embok) $r[] = 'Embeddings : ' . round($esim*100) . '%';
        $r[] = 'Cluster : ' . $a['cluster'];

        return array(
            'layer' => 'content', 'layer_label' => "\xF0\x9F\x9F\xA1 Contenu similaire",
            'risk' => $risk, 'score' => $score,
            'detail' => implode( ' / ', $r ),
            'evidence' => array( 'jaccard'=>round($jacc,4), 'h2_overlap'=>round($h2ov,4), 'embed_sim'=>round($esim,4), 'shared_words'=>count($inter) ),
        );
    }

    /* -- LAYER 4: GEO CONSOLIDATION -- */
    private function layer_geo( $pa, $pb, $a, $b, $vectors ) {
        if ( !$a['cluster'] || $a['cluster'] !== $b['cluster'] ) return null;
        if ( $a['wc'] >= 800 || $b['wc'] >= 800 ) return null;
        if ( $a['is_pillar'] || $b['is_pillar'] ) return null;

        // FIX 6: Gate by content overlap instead of embeddings (which are unreliable on niche sites)
        $sa = $a['sig_set_filtered'] ?? $a['sig_set'];
        $sb = $b['sig_set_filtered'] ?? $b['sig_set'];
        if ( empty($sa) || empty($sb) ) return null;

        $inter = array_intersect( $sa, $sb );
        $union = array_unique( array_merge( $sa, $sb ) );
        $jacc  = count($union) > 0 ? count($inter) / count($union) : 0;

        // Need at least 15% filtered content overlap to suggest merge
        if ( $jacc < 0.15 ) return null;

        // Check if similar focus keywords (stronger signal)
        $fkw_related = false;
        if ( !empty($a['fkw']) && !empty($b['fkw']) ) {
            $fkw_related = ( $a['fkw'] === $b['fkw'] )
                || ( mb_strpos($a['fkw'], $b['fkw']) !== false )
                || ( mb_strpos($b['fkw'], $a['fkw']) !== false );
        }

        $total_wc = $a['wc'] + $b['wc'];
        $score = round( $jacc * 60 + ( $fkw_related ? 30 : 0 ) + ( 800 - min($a['wc'],$b['wc']) ) / 80 );

        return array(
            'layer' => 'geo', 'layer_label' => "\xF0\x9F\x9F\xA2 Opportunite GEO",
            'risk' => 'opportunity',
            'score' => $score,
            'detail' => $a['wc'] . ' + ' . $b['wc'] . ' mots = ' . $total_wc . ' — '
                . round($jacc*100) . '% contenu commun'
                . ($fkw_related ? ' + keywords proches' : '')
                . ' → fusionner pour meilleure citation IA',
            'evidence' => array( 'wc_a'=>$a['wc'], 'wc_b'=>$b['wc'], 'jaccard'=>round($jacc,4), 'fkw_related'=>$fkw_related, 'cluster'=>$a['cluster'] ),
        );
    }

    /* -- SUGGESTION ENGINE -- */
    private function suggest( $pa, $pb, $a, $b, $conflict, $pillars, $strategy ) {
        $layer = $conflict['layer'] ?? '';

        if ( $layer === 'copy_error' ) {
            // Don't suggest redirect — the content was pasted in the wrong post
 return array('action'=>'review','winner_id'=>0,'loser_id'=>0,'reason'=>'Erreur CMS : le post_content est identique mais les slugs indiquent des sujets differents. Ouvrir les 2 posts et corriger le contenu du mauvais.');
        }
        if ( $layer === 'duplicate' ) {
            $sa = $this->strength($pa); $sb = $this->strength($pb);
            $w = $sa >= $sb ? $pa : $pb; $l = $w===$pa ? $pb : $pa;
            return array('action'=>'redirect','winner_id'=>$w,'loser_id'=>$l,'reason'=>'Vrai doublon CMS → redirect 301 vers la page la plus forte');
        }
        if ( $layer === 'title_bug' ) {
            // Don't suggest merge — suggest fixing the title
            return array('action'=>'review','winner_id'=>0,'loser_id'=>0,'reason'=>'Corriger le titre incorrect — les contenus sont differents, un post_title est faux');
        }
        if ( $layer === 'geo' ) {
            return array('action'=>'merge','winner_id'=>0,'loser_id'=>0,'reason'=>'Fusionner 2 pages thin en 1 page complete pour citation IA');
        }
        if ( $strategy === 'manual' ) {
            return array('action'=>'review','winner_id'=>0,'loser_id'=>0,'reason'=>'Revue manuelle requise');
        }

        $cl = $a['cluster'] ?: $b['cluster'];
        $pil = $pillars[$cl] ?? 0;

        if ( $strategy === 'pillar_first' && $pil ) {
            if ((int)$pa===$pil) return array('action'=>'canonical','winner_id'=>$pa,'loser_id'=>$pb,'reason'=>'Pilier du cluster');
            if ((int)$pb===$pil) return array('action'=>'canonical','winner_id'=>$pb,'loser_id'=>$pa,'reason'=>'Pilier du cluster');
        }

        $sa = $this->strength($pa); $sb = $this->strength($pb);
        if ($pil && (int)$pa===$pil) $sa += 50;
        if ($pil && (int)$pb===$pil) $sb += 50;
        $w = $sa >= $sb ? $pa : $pb; $l = $w===$pa ? $pb : $pa;

        $risk = $conflict['risk'] ?? 'medium';
        if ( $risk === 'critical' || $risk === 'high' ) {
            return array('action'=>'canonical','winner_id'=>$w,'loser_id'=>$l,'reason'=>'Page la plus forte (GSC + contenu + pilier)');
        }
        return array('action'=>'differentiate','winner_id'=>0,'loser_id'=>0,'reason'=>'Differencier le contenu — angle unique par page');
    }

    private function strength( $pid ) {
        $cl = (int) get_post_meta($pid,'_hts_gsc_clicks',true);
        $im = (int) get_post_meta($pid,'_hts_gsc_impressions',true);
        $p  = get_post($pid);
        $wc = $p ? hts_word_count(wp_strip_all_tags($p->post_content)) : 0;
        return ($cl*3) + ($im*0.1) + ($wc/100);
    }

    /* == RESOLVE == */
    public function resolve_conflict( $pk, $wid, $lid, $act = 'canonical' ) {
        $cs = get_option( self::OPT_CONFLICTS, array() );
        foreach ( $cs as &$c ) {
            if ( $c['pair_key'] !== $pk ) continue;
            $c['status'] = 'resolved'; $c['winner_id'] = (int)$wid; $c['loser_id'] = (int)$lid;
            $c['action'] = $act; $c['resolved_at'] = current_time('mysql');

            if ( $act === 'canonical' && $lid && $wid ) {
                update_post_meta( $lid, self::META_CANONICAL, get_permalink($wid) );
                if (function_exists('hts_add_log')) hts_add_log(sprintf('Canonical: "%s" → "%s" (%s)', get_the_title($lid), get_the_title($wid), $c['layer_label']??''));
            } elseif ( $act === 'redirect' && $lid && $wid ) {
                global $wpdb; $t = $wpdb->prefix.'hts_redirects';
                if ( $wpdb->get_var("SHOW TABLES LIKE '{$t}'") === $t ) {
                    $wpdb->replace($t, array('source'=>wp_make_link_relative(get_permalink($lid)),'target'=>get_permalink($wid),'type'=>301,'is_regex'=>0,'origin'=>'Anti-cannib','notes'=>$c['layer_label']??'','enabled'=>1,'hit_count'=>0,'created_at'=>current_time('mysql')));
                }
                if (function_exists('hts_add_log')) hts_add_log(sprintf('Redirect 301 (cannib): "%s" → "%s" (%s)', get_the_title($lid), get_the_title($wid), $c['layer_label']??''));
            } elseif ( $act === 'merge' && $lid && $wid ) {
                // Merge = redirect 301 + mark for content consolidation
                global $wpdb; $t = $wpdb->prefix.'hts_redirects';
                if ( $wpdb->get_var("SHOW TABLES LIKE '{$t}'") === $t ) {
                    $wpdb->replace($t, array('source'=>wp_make_link_relative(get_permalink($lid)),'target'=>get_permalink($wid),'type'=>301,'is_regex'=>0,'origin'=>'Anti-cannib merge','notes'=>$c['layer_label']??'','enabled'=>1,'hit_count'=>0,'created_at'=>current_time('mysql')));
                }
                if (function_exists('hts_add_log')) hts_add_log(sprintf('Merge (cannib): "%s" → "%s" — 301 cree, contenu a consolider (%s)', get_the_title($lid), get_the_title($wid), $c['layer_label']??''));
            }
            break;
        }
        update_option( self::OPT_CONFLICTS, $cs, false );
        return true;
    }

    /* == STATS == */
    public static function get_stats() {
        $cs = get_option( self::OPT_CONFLICTS, array() );
        $st = array('total'=>count($cs),'pending'=>0,'resolved'=>0,
            'by_layer'=>array('copy_error'=>0,'duplicate'=>0,'title_bug'=>0,'keyword'=>0,'content'=>0,'geo'=>0),
            'by_risk'=>array('critical'=>0,'high'=>0,'medium'=>0,'opportunity'=>0),
            'custom_canonicals'=>0);
        foreach ($cs as $c) {
            if (($c['status']??'')==='resolved') $st['resolved']++; else {
                $st['pending']++;
                $l=$c['layer']??''; $r=$c['risk']??'';
                if (isset($st['by_layer'][$l])) $st['by_layer'][$l]++;
                if (isset($st['by_risk'][$r])) $st['by_risk'][$r]++;
            }
        }
        global $wpdb;
        $st['custom_canonicals'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='".self::META_CANONICAL."' AND meta_value!=''");
        return $st;
    }

    public static function get_conflict_count() {
        $cs = get_option( self::OPT_CONFLICTS, array() );
        return count(array_filter($cs, function($c){return ($c['status']??'')!=='resolved';}));
    }

    /* == AJAX == */
    public function ajax_get_data() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        wp_send_json_success(array('conflicts'=>get_option(self::OPT_CONFLICTS,array()),'stats'=>self::get_stats(),'settings'=>self::get_settings()));
    }

    public function ajax_detect() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        $cs = $this->detect_conflicts();
        $tf = (int)get_option('hts_canonical_total_found',count($cs));
        $st = self::get_stats();
        $csw = (int)get_option('hts_canonical_corpus_stopwords', 0);
        $p = array();
        if ($st['by_layer']['copy_error']) $p[] = $st['by_layer']['copy_error'].' erreur(s) CMS';
        if ($st['by_layer']['duplicate']) $p[] = $st['by_layer']['duplicate'].' doublon(s)';
        if ($st['by_layer']['title_bug']) $p[] = $st['by_layer']['title_bug'].' bug(s) titre';
        if ($st['by_layer']['keyword']) $p[] = $st['by_layer']['keyword'].' keyword(s)';
        if ($st['by_layer']['content']) $p[] = $st['by_layer']['content'].' contenu';
        if ($st['by_layer']['geo']) $p[] = $st['by_layer']['geo'].' GEO';
        $msg = count($cs).' conflit(s)';
        if (!empty($p)) $msg .= ' : ' . implode(', ', $p);
        if ($csw > 0) $msg .= ' ('. $csw .' mots niche exclus)';

        // LOG: Scan
        if (function_exists('hts_add_log')) {
            hts_add_log('Canonical scan : ' . $msg . ' (resolved preserves: ' . $st['resolved'] . ')');
        }

        wp_send_json_success(array('conflicts'=>$cs,'stats'=>$st,'total_found'=>$tf,'message'=>$msg));
    }

    public function ajax_resolve() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        $pk = sanitize_text_field($_POST['pair_key']??'');
        $wid = (int)($_POST['winner_id']??0); $lid = (int)($_POST['loser_id']??0);
        $act = sanitize_text_field($_POST['resolve_action']??'canonical');
        if (!$pk||!$wid||!$lid) wp_send_json_error('Params manquants');
        if (!in_array($act,array('canonical','redirect','merge'))) $act='canonical';
        $this->resolve_conflict($pk,$wid,$lid,$act);
        wp_send_json_success(array('stats'=>self::get_stats(),'message'=>'Conflit resolu'));
    }

    public function ajax_dismiss() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        $pk = sanitize_text_field($_POST['pair_key']??'');
        if (!$pk) wp_send_json_error('Param manquant');

        // Store full conflict data before removing (for restore)
        $cs = get_option(self::OPT_CONFLICTS,array());
        $dismissed_data = get_option('hts_canonical_dismissed_data', array());
        foreach ($cs as $c) {
            if ($c['pair_key'] === $pk) {
                $c['dismissed_at'] = current_time('mysql');
                $dismissed_data[$pk] = $c;

                // LOG: Dismiss with details
                if (function_exists('hts_add_log')) {
                    $ta = $c['title_a'] ?? 'ID '.$c['page_a'];
                    $tb = $c['title_b'] ?? 'ID '.$c['page_b'];
                    hts_add_log(sprintf('Canonical dismiss : "%s" vs "%s" (%s)', $ta, $tb, $c['layer_label']??$c['layer']??''));
                }
                break;
            }
        }
        update_option('hts_canonical_dismissed_data', $dismissed_data, false);

        // Add to dismissed keys list
        $d = get_option(self::OPT_DISMISSED,array());
        if (!in_array($pk,$d)) { $d[]=$pk; update_option(self::OPT_DISMISSED,$d,false); }

        // Remove from active conflicts
        $cs = array_values(array_filter($cs, function($c)use($pk){return $c['pair_key']!==$pk;}));
        update_option(self::OPT_CONFLICTS,$cs,false);

        wp_send_json_success(array('stats'=>self::get_stats()));
    }

    /**
     * AJAX: Restore a dismissed conflict
     */
    public function ajax_restore_dismissed() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        $pk = sanitize_text_field($_POST['pair_key']??'');
        if (!$pk) wp_send_json_error('Param manquant');

        // Remove from dismissed keys
        $d = get_option(self::OPT_DISMISSED, array());
        $d = array_values(array_filter($d, function($k) use($pk) { return $k !== $pk; }));
        update_option(self::OPT_DISMISSED, $d, false);

        // Restore conflict data if available
        $dismissed_data = get_option('hts_canonical_dismissed_data', array());
        if (isset($dismissed_data[$pk])) {
            $restored = $dismissed_data[$pk];
            $restored['status'] = 'pending';
            unset($restored['dismissed_at']);
            $cs = get_option(self::OPT_CONFLICTS, array());
            $cs[] = $restored;
            update_option(self::OPT_CONFLICTS, $cs, false);
            unset($dismissed_data[$pk]);
            update_option('hts_canonical_dismissed_data', $dismissed_data, false);

            // LOG: Restore
            if (function_exists('hts_add_log')) {
                $ta = $restored['title_a'] ?? 'ID '.$restored['page_a'];
                $tb = $restored['title_b'] ?? 'ID '.$restored['page_b'];
                hts_add_log(sprintf('Canonical restore : "%s" vs "%s"', $ta, $tb));
            }
        }

        wp_send_json_success(array('stats'=>self::get_stats()));
    }

    public function ajax_save_settings() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        $new = array(
            'enabled'=>sanitize_text_field($_POST['enabled']??'1'),
            'auto_inject'=>sanitize_text_field($_POST['auto_inject']??'1'),
            'self_referencing'=>sanitize_text_field($_POST['self_referencing']??'1'),
            'strategy'=>sanitize_text_field($_POST['strategy']??'smart'),
            'remove_wp_canonical'=>sanitize_text_field($_POST['remove_wp_canonical']??'1'),
            'exclude_noindex'=>sanitize_text_field($_POST['exclude_noindex']??'1'),
            'content_overlap_min'=>max(0.10,min(0.50,(float)($_POST['content_overlap_min']??0.25))),
            'enable_geo_layer'=>sanitize_text_field($_POST['enable_geo_layer']??'1'),
        );
        $old = self::get_settings();
        update_option(self::OPT_SETTINGS, $new);

        // LOG: Settings change with diff
        if (function_exists('hts_add_log')) {
            $changes = array();
            foreach ($new as $k => $v) {
                if (($old[$k] ?? '') != $v) $changes[] = $k . ': ' . ($old[$k]??'') . ' → ' . $v;
            }
            if (!empty($changes)) {
                hts_add_log('Canonical settings : ' . implode(', ', $changes));
            }
        }

        wp_send_json_success('OK');
    }

    public function ajax_set_manual() {
        check_ajax_referer('hts_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permissions');
        $pid = (int)($_POST['post_id']??0); $url = esc_url_raw(trim($_POST['canonical_url']??''));
        if (!$pid) wp_send_json_error('Post ID manquant');
        $old_url = get_post_meta($pid, self::META_CANONICAL, true);
        $url ? update_post_meta($pid,self::META_CANONICAL,$url) : delete_post_meta($pid,self::META_CANONICAL);

        // LOG: Manual canonical
        if (function_exists('hts_add_log')) {
            if ($url) {
                hts_add_log(sprintf('Canonical manual : "%s" → %s (was: %s)', get_the_title($pid), $url, $old_url ?: 'self'));
            } else {
                hts_add_log(sprintf('Canonical manual supprime : "%s" (was: %s)', get_the_title($pid), $old_url));
            }
        }

        wp_send_json_success('OK');
    }
}
