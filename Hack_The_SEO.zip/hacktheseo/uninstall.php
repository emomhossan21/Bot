<?php
/**
 * Hack The SEO — Uninstall cleanup
 *
 * Runs when the plugin is DELETED (not just deactivated).
 * By default, preserves API keys and data for easy reinstallation.
 * Set hts_delete_data_on_uninstall = 1 in Reglages to wipe everything.
 *
 * @since 1.4.3
 * @updated 2.3.1 — Preserve API keys by default, add keep-data toggle
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// ── Check if user explicitly wants full cleanup ──
$full_cleanup = get_option( 'hts_delete_data_on_uninstall', '0' ) === '1';

if ( ! $full_cleanup ) {
    // ── SAFE MODE: Only clean crons + transients, keep all data + keys ──
    // This allows reinstalling the plugin without losing configuration.

    // Clean transients only
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_hts\_%'" );
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_timeout\_hts\_%'" );

    // Clean crons
    $crons_to_clear = array(
        'hts_audit_purge_cron', 'hts_auto_write_weekly', 'hts_batch_score_compute',
        'hts_coach_monthly_reset', 'hts_decision_engine_weekly', 'hts_embeddings_index',
        'hts_embeddings_smart_cron', 'hts_every_6h', 'hts_geo_score_cron_scan',
        'hts_global_score_weekly_snapshot', 'hts_gsc_daily_fetch', 'hts_health_cron',
        'hts_impact_cleanup', 'hts_redirects_cleanup', 'hts_refresh_weekly_scan',
        'hts_sitemap_cron', 'hts_sitemap_first_generation', 'hts_strategy_weekly',
        'hts_workflow_daily_cleanup',
        'hts_auto_schedule_check', 'hts_poll_pending_jobs', 'hts_coach_weekly_purge',
        'hts_inbox_weekly_scan', 'hts_inbox_purge_stale', 'hts_linking_weekly_scan',
        'hts_weekly_interlink_maintenance', 'hts_meta_score_weekly_scan',
        'hts_auto_drip', 'hts_batch_linking_drip', 'hts_deferred_images', 'hts_deferred_cross_interlink', 'hts_batch_cleanup_internal_links',
        'hts_impact_measure',
    );
    foreach ( $crons_to_clear as $hook ) {
        wp_clear_scheduled_hook( $hook );
    }

    // Clean first-run flags (so upgrade detection works on reinstall)
    delete_option( 'hts_light_version' );
    delete_option( 'hts_sitemap_first_run' );
    delete_option( 'hts_scores_first_run' );
    delete_option( 'hts_batch_score_offset' );
    delete_option( 'hts_sitemap_flush_needed' );
    delete_option( 'hts_sitemap_rules_installed' );

    flush_rewrite_rules();
    return; // STOP — keep everything else (tables, options, post meta, API keys)
}

// ══════════════════════════════════════════════════════════════════════════
// FULL CLEANUP MODE — only if hts_delete_data_on_uninstall = 1
// ══════════════════════════════════════════════════════════════════════════

/* 1. DROP CUSTOM TABLES */
$tables_to_drop = array(
    'hts_embeddings', 'hts_actions', 'hts_strategy_patterns', 'hts_404_log',
    'hts_redirects', 'hts_cocons', 'hts_crawls', 'hts_visits', 'hts_gsc_data',
    'hts_gsc_queries', 'hts_workflow_actions', 'hts_workflow_agents',
    'hts_coach_sessions', 'hts_coach_messages', 'hts_coach_memory',
    'hts_coach_artifacts', 'hts_coach_analytics',
);
foreach ( $tables_to_drop as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" );
}

/* 2. DELETE ALL HTS OPTIONS */
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'hts\_%'" );

/* 3. DELETE ALL HTS POST META */
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '\_hts\_%'" );

/* 4. DELETE ALL HTS TRANSIENTS */
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_hts\_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_timeout\_hts\_%'" );

/* 5. CLEAR ALL HTS CRONS */
$crons_to_clear = array(
    'hts_audit_purge_cron', 'hts_auto_write_weekly', 'hts_batch_score_compute',
    'hts_coach_monthly_reset', 'hts_decision_engine_weekly', 'hts_embeddings_index',
    'hts_embeddings_smart_cron', 'hts_every_6h', 'hts_geo_score_cron_scan',
    'hts_global_score_weekly_snapshot', 'hts_gsc_daily_fetch', 'hts_health_cron',
    'hts_impact_cleanup', 'hts_redirects_cleanup', 'hts_refresh_weekly_scan',
    'hts_sitemap_cron', 'hts_sitemap_first_generation', 'hts_strategy_weekly',
    'hts_workflow_daily_cleanup',
    'hts_auto_schedule_check', 'hts_poll_pending_jobs', 'hts_coach_weekly_purge',
    'hts_inbox_weekly_scan', 'hts_inbox_purge_stale', 'hts_linking_weekly_scan',
    'hts_weekly_interlink_maintenance', 'hts_meta_score_weekly_scan',
    'hts_auto_drip', 'hts_batch_linking_drip', 'hts_deferred_images', 'hts_deferred_cross_interlink', 'hts_batch_cleanup_internal_links',
    'hts_impact_measure',
);
foreach ( $crons_to_clear as $hook ) {
    wp_clear_scheduled_hook( $hook );
}

/* 6. FLUSH REWRITE RULES */
flush_rewrite_rules();
