<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Hack The SEO — Onboarding Wizard
 *
 * Triggered on first install (when hts_onboarding_done is not set).
 * 4 steps: Welcome → Migration → API → Configuration → Done
 *
 * @since 1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! current_user_can( 'manage_options' ) ) return;

$nonce      = wp_create_nonce( 'hts_admin_nonce' );
$ajax       = admin_url( 'admin-ajax.php' );
$site_name  = get_bloginfo( 'name' );
$site_url   = home_url();

// Detect existing SEO plugins
$detected_plugin = '';
$detected_icon   = '';
$active_plugins  = (array) get_option( 'active_plugins', array() );
$seo_plugins = array(
 'seo-by-rank-math/rank-math.php' => array( 'Rank Math', '' ),
 'wordpress-seo/wp-seo.php' => array( 'Yoast SEO', '' ),
 'wp-seopress/seopress.php' => array( 'SEOPress', '' ),
 'all-in-one-seo-pack/all_in_one_seo_pack.php' => array( 'All in One SEO', '' ),
);
foreach ( $seo_plugins as $file => $info ) {
    if ( in_array( $file, $active_plugins, true ) ) {
        $detected_plugin = $info[0];
        $detected_icon   = $info[1];
        break;
    }
}

// P1 Session E : Détection Polylang, WooCommerce, et environnement
$has_polylang    = in_array( 'polylang/polylang.php', $active_plugins, true ) || in_array( 'polylang-pro/polylang.php', $active_plugins, true );
$has_wpml        = in_array( 'sitepress-multilingual-cms/sitepress.php', $active_plugins, true );
$has_woocommerce = in_array( 'woocommerce/woocommerce.php', $active_plugins, true );
$has_elementor   = in_array( 'elementor/elementor.php', $active_plugins, true );
$has_divi        = function_exists( 'et_setup_theme' ) || defined( 'ET_BUILDER_PLUGIN_DIR' );
$post_count      = (int) wp_count_posts( 'post' )->publish;
$page_count      = (int) wp_count_posts( 'page' )->publish;
$total_content   = $post_count + $page_count;
$is_multilingual = $has_polylang || $has_wpml;
$detected_env    = array();
if ( $has_polylang )    $detected_env[] = array( 'name' => 'Polylang',    'desc' => 'Multilingue — Hack The SEO s\'adaptera automatiquement à chaque langue.', 'icon' => '[i18n]' );
if ( $has_wpml )        $detected_env[] = array( 'name' => 'WPML',        'desc' => 'Multilingue — Hack The SEO s\'adaptera automatiquement à chaque langue.', 'icon' => '[i18n]' );
if ( $has_woocommerce ) $detected_env[] = array( 'name' => 'WooCommerce', 'desc' => 'Boutique — Les fiches produit seront aussi optimisées.', 'icon' => '[Shop]' );
if ( $has_elementor )   $detected_env[] = array( 'name' => 'Elementor',   'desc' => 'Page builder — Le contenu sera extrait correctement.', 'icon' => '[Builder]' );
if ( $has_divi )        $detected_env[] = array( 'name' => 'Divi',        'desc' => 'Page builder — Le contenu sera extrait correctement.', 'icon' => '[Builder]' );

// Current settings
$separator = get_option( 'hts_title_separator', '—' );
$api_key   = hts_get_api_key();

// P3 Session F : Détection état migration
$migration_state = get_option( 'hts_migration_state', array() );
$migration_done  = ! empty( $migration_state['completed'] ) || ! empty( $migration_state['phase'] ) && $migration_state['phase'] === 'done';
$migration_counts = array( 'titles' => 0, 'descs' => 0 );
if ( ! empty( $migration_state['report'] ) && is_array( $migration_state['report'] ) ) {
    foreach ( $migration_state['report'] as $type => $data ) {
        if ( $type === 'meta_titles' && isset( $data['imported'] ) ) $migration_counts['titles'] = (int) $data['imported'];
        if ( $type === 'meta_descs' && isset( $data['imported'] ) ) $migration_counts['descs'] = (int) $data['imported'];
    }
}
// Also check report option
if ( ! $migration_counts['titles'] && ! $migration_counts['descs'] ) {
    $migration_report = get_option( 'hts_migration_report', array() );
    if ( is_array( $migration_report ) ) {
        foreach ( $migration_report as $type => $data ) {
            if ( $type === 'meta_titles' && isset( $data['imported'] ) ) $migration_counts['titles'] = (int) $data['imported'];
            if ( $type === 'meta_descs' && isset( $data['imported'] ) ) $migration_counts['descs'] = (int) $data['imported'];
        }
    }
}
$has_pending_migration = $detected_plugin && ! $migration_done;
?>
<div class="wrap">
<style>
.hts-onb { max-width:680px; margin:40px auto; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }
.hts-onb-header { text-align:center; margin-bottom:32px; }
.hts-onb-header h1 { font-size:26px; font-weight:700; color:#1a1f36; margin:0 0 8px; }
.hts-onb-header p { color:#64748b; font-size:14px; margin:0; }
.hts-onb-progress { display:flex; gap:8px; margin-bottom:32px; }
.hts-onb-progress .step { flex:1; height:4px; border-radius:2px; background:#e5e7eb; transition:background .3s; }
.hts-onb-progress .step.done { background:#6366f1; }
.hts-onb-progress .step.active { background:linear-gradient(90deg,#6366f1,#a5b4fc); }
.hts-onb-card { background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:32px; box-shadow:0 1px 3px rgba(0,0,0,.05); line-height:1.6; text-align:left; }
.hts-onb-card h2 { font-size:18px; font-weight:700; color:#1a1f36; margin:0 0 8px; text-align:left; }
.hts-onb-card .subtitle { color:#64748b; font-size:13px; margin:0 0 24px; line-height:1.5; text-align:left; }
.hts-onb-card .field { margin-bottom:20px; }
.hts-onb-card .field label { display:block; font-size:12px; font-weight:600; color:#374151; margin-bottom:4px; }
.hts-onb-card .field input, .hts-onb-card .field select { width:100%; padding:9px 14px; border:1px solid #e5e7eb; border-radius:8px; font-size:13px; }
.hts-onb-card .field input:focus, .hts-onb-card .field select:focus { outline:none; border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,.1); }
.hts-onb-footer { display:flex; justify-content:space-between; align-items:center; margin-top:24px; }
.hts-onb-btn { padding:10px 24px; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; border:none; transition:all .15s; }
.hts-onb-btn-primary { background:#6366f1; color:#fff; }
.hts-hidden { display: none !important; }
.hts-onb-btn-primary:hover { background:#4f46e5; color:#fff; box-shadow:0 2px 8px rgba(99,102,241,.3); }
.hts-onb-btn-secondary { background:#f3f4f6; color:#374151; }
.hts-onb-btn-secondary:hover { background:#e5e7eb; color:#1a1f36; }
.hts-onb-btn-skip { background:none; color:#9da5b4; font-size:12px; cursor:pointer; border:none; }
.hts-onb-btn-skip:hover { color:#374151; text-decoration:underline; }
.hts-onb-detect { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:14px 18px; margin-bottom:16px; display:flex; align-items:center; gap:10px; }
.hts-onb-detect .icon { font-size:20px; }
.hts-onb-detect .text { font-size:13px; color:#166534; }
.hts-onb-detect .text strong { color:#15803d; }
.hts-onb-nodetect { background:#f8fafc; border:1px solid #e5e7eb; border-radius:8px; padding:14px 18px; margin-bottom:16px; text-align:center; color:#9da5b4; font-size:13px; }
.hts-onb-toggle-row { display:flex; align-items:center; justify-content:space-between; padding:12px 0; border-bottom:1px solid #f3f4f6; }
.hts-onb-toggle-row:last-child { border-bottom:none; }
.hts-onb-toggle-row .hts-tog-name { font-size:13px; color:#1a1f36; font-weight:500; }
.hts-onb-toggle-row .hts-tog-desc { font-size:11px; color:#9da5b4; margin-top:2px; line-height:1.4; }
.hts-onb-toggle { position:relative; width:40px; height:22px; flex-shrink:0; }
.hts-onb-toggle input { opacity:0; width:0; height:0; position:absolute; pointer-events:none; }
.hts-onb-toggle .sl { position:absolute; inset:0; background:#d1d5db; border-radius:11px; cursor:pointer; transition:background .2s; }
.hts-onb-toggle .sl::after { content:''; position:absolute; width:16px; height:16px; background:#fff; border-radius:50%; top:3px; left:3px; transition:transform .2s; }
.hts-onb-toggle input:checked + .sl { background:#6366f1; }
.hts-onb-toggle input:checked + .sl::after { transform:translateX(18px); }
.hts-onb-features { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin:20px 0; }
.hts-onb-feature { background:#f8fafc; border-radius:8px; padding:14px 16px; display:flex; flex-direction:column !important; gap:2px; }
.hts-feat-name { font-size:13px; font-weight:600; color:#1a1f36 !important; display:block !important; margin-bottom:2px; }
.hts-feat-desc { font-size:11px; color:#9da5b4 !important; display:block !important; line-height:1.4; }
.hts-onb-done { text-align:center; padding:20px 0; }
.hts-onb-done .check { font-size:48px; margin-bottom:12px; }
.hts-onb-done h2 { font-size:20px; margin-bottom:8px; }
@keyframes hts-onb-spin { to { transform:rotate(360deg); } }
@keyframes hts-onb-pulse { 0%,100% { opacity:1; } 50% { opacity:.5; } }
.hts-loading { position:relative; }
.hts-loading::after { content:''; display:inline-block; width:16px; height:16px; border:2px solid #e5e7eb; border-top-color:#6366f1; border-radius:50%; animation:hts-onb-spin .6s linear infinite; vertical-align:middle; }

/* Pipeline task list */
.onb-task { display:flex; align-items:flex-start; gap:14px; padding:12px 16px; border-radius:8px; transition:background .3s, opacity .3s; opacity:.5; }
.onb-task.is-running { opacity:1; background:#f8fafc; }
.onb-task.is-done { opacity:1; }
.onb-task.is-skip { opacity:.4; }
.onb-task-icon { flex-shrink:0; width:24px; height:24px; display:flex; align-items:center; justify-content:center; font-size:16px; margin-top:1px; }
.onb-ico { display:none; }
.onb-ico-pending { display:inline; color:#d1d5db; }
.onb-ico-running { color:#6366f1; animation:hts-onb-pulse 1s ease-in-out infinite; }
.onb-ico-done { color:#16a34a; font-weight:700; }
.onb-ico-skip { color:#9da5b4; }
.onb-task.is-running .onb-ico-pending { display:none; }
.onb-task.is-running .onb-ico-running { display:inline; }
.onb-task.is-done .onb-ico-pending { display:none; }
.onb-task.is-done .onb-ico-done { display:inline; }
.onb-task.is-skip .onb-ico-pending { display:none; }
.onb-task.is-skip .onb-ico-skip { display:inline; }
.onb-task-label { font-size:13px; font-weight:600; color:#1a1f36; line-height:1.4; }
.onb-task.is-done .onb-task-label { color:#16a34a; }
.onb-task-detail { font-size:11px; color:#64748b; margin-top:2px; min-height:16px; }
.onb-task-bar { height:4px; background:#e5e7eb; border-radius:2px; margin-top:8px; overflow:hidden; }
.onb-task-bar-fill { height:100%; width:0%; background:#6366f1; border-radius:2px; transition:width .5s ease; }
</style>

<div class="hts-onb">

<!-- Header -->
<div class="hts-onb-header">
 <h1> Bienvenue sur Hack The SEO</h1>
    <p>Configurons votre SEO en quelques clics</p>
</div>

<!-- Progress -->
<div class="hts-onb-progress">
    <div class="step active" id="prog-1"></div>
    <div class="step" id="prog-2"></div>
    <div class="step" id="prog-3"></div>
    <div class="step" id="prog-4"></div>
    <div class="step" id="prog-5"></div>
    <div class="step" id="prog-6"></div>
    <div class="step" id="prog-7"></div>
    <div class="step" id="prog-8"></div>
</div>

<!-- ═══ STEP 1: Welcome + Détection environnement ═══ -->
<div class="hts-onb-card" id="step-1">
    <h2>Bienvenue sur Hack The SEO</h2>
    <p class="subtitle">Un plugin SEO complet qui remplace Rank Math, Yoast & co — avec des agents IA pour optimiser votre site automatiquement.</p>
    
    <div class="hts-onb-features">
 <div class="hts-onb-feature"><div class="hts-feat-name">Meta Tags</div><div class="hts-feat-desc">Title, description, OG, Twitter</div></div>
 <div class="hts-onb-feature"><div class="hts-feat-name">Schema JSON-LD</div><div class="hts-feat-desc">Article, FAQ, HowTo, Video</div></div>
 <div class="hts-onb-feature"><div class="hts-feat-name">Sitemap XML</div><div class="hts-feat-desc">Avec sous-sitemaps par cocon</div></div>
        <div class="hts-onb-feature"><div class="hts-feat-name">Redirections</div><div class="hts-feat-desc">301/302 + monitoring 404</div></div>
 <div class="hts-onb-feature"><div class="hts-feat-name">Canonical</div><div class="hts-feat-desc">Anti-duplication automatique</div></div>
 <div class="hts-onb-feature"><div class="hts-feat-name">Score SEO</div><div class="hts-feat-desc">20 critères par article</div></div>
 <div class="hts-onb-feature"><div class="hts-feat-name">Maillage IA</div><div class="hts-feat-desc">Liens internes intelligents</div></div>
 <div class="hts-onb-feature"><div class="hts-feat-name">Agents SEO</div><div class="hts-feat-desc">Détection et correction auto</div></div>
    </div>

    <!-- Détection environnement -->
    <div style="margin-top:20px;">
        <div style="font-size:12px;font-weight:600;color:#374151;margin-bottom:10px;">Votre site a été analysé :</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:8px;">
            <span style="background:#f0fdf4;color:#166534;font-size:12px;padding:4px 12px;border-radius:6px;font-weight:500;">
                <?php echo esc_html( $post_count ); ?> article<?php echo $post_count > 1 ? 's' : ''; ?>
            </span>
            <span style="background:#f0fdf4;color:#166534;font-size:12px;padding:4px 12px;border-radius:6px;font-weight:500;">
                <?php echo esc_html( $page_count ); ?> page<?php echo $page_count > 1 ? 's' : ''; ?>
            </span>
        </div>
        <?php if ( ! empty( $detected_env ) ) : ?>
        <?php foreach ( $detected_env as $env ) : ?>
        <div class="hts-onb-detect" style="margin-bottom:8px;">
            <div class="icon"><?php echo $env['icon']; ?></div>
            <div class="text"><strong><?php echo esc_html( $env['name'] ); ?></strong> — <?php echo esc_html( $env['desc'] ); ?></div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
        <?php if ( $detected_plugin ) : ?>
        <div class="hts-onb-detect">
            <div class="icon">🔄</div>
            <div class="text"><strong><?php echo esc_html( $detected_plugin ); ?></strong> détecté — vos données SEO pourront être importées à l\'étape suivante.</div>
        </div>
        <?php endif; ?>
        <?php if ( empty( $detected_env ) && ! $detected_plugin ) : ?>
        <div class="hts-onb-nodetect">
            Installation WordPress standard — parfait, aucune complication !
        </div>
        <?php endif; ?>
    </div>

    <div class="hts-onb-footer">
        <div></div>
        <button class="hts-onb-btn hts-onb-btn-primary" onclick="htsOnbNext(2)">Commencer la configuration →</button>
    </div>
</div>

<!-- ═══ STEP 2: Migration ═══ -->
<div class="hts-onb-card hts-hidden" id="step-2">
    <h2>Migration depuis un plugin existant</h2>
    <p class="subtitle">Hack The SEO peut importer vos titres, descriptions et réglages depuis votre plugin SEO actuel.</p>

    <?php if ( $detected_plugin ) : ?>
    <div class="hts-onb-detect">
        <div class="icon"><?php echo $detected_icon; ?></div>
        <div class="text"><strong><?php echo esc_html( $detected_plugin ); ?></strong> détecté ! Nous pouvons importer toutes vos données SEO.</div>
    </div>
    <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-migration-wizard&from=onboarding' ) ); ?>" class="hts-onb-btn hts-onb-btn-primary" style="display:block;text-align:center;text-decoration:none;margin-bottom:12px;">
 Lancer l'assistant de migration
    </a>
    <p style="font-size:11px;color:#9da5b4;text-align:center;">L'assistant importera vos titres, descriptions, redirections et réglages. Vous pourrez revenir ici ensuite.</p>
    <?php if ( $migration_done && ( $migration_counts['titles'] || $migration_counts['descs'] ) ) : ?>
    <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;margin-top:12px;font-size:12px;color:#166534;text-align:center;">
        ✅ Migration effectuée — <?php echo $migration_counts['titles']; ?> titre(s) et <?php echo $migration_counts['descs']; ?> description(s) importé(s)
    </div>
    <?php endif; ?>
    <?php else : ?>
    <div class="hts-onb-nodetect">
 Aucun plugin SEO concurrent détecté. Hack The SEO part de zéro — c\'est parfait ! 
    </div>
    <?php endif; ?>

    <div class="hts-onb-footer">
        <button class="hts-onb-btn hts-onb-btn-secondary" onclick="htsOnbNext(1)">← Retour</button>
        <div>
            <?php if ( $detected_plugin ) : ?>
            <button class="hts-onb-btn-skip" onclick="htsOnbNext(3)">Plus tard →</button>
            <?php endif; ?>
            <button class="hts-onb-btn hts-onb-btn-primary" onclick="htsOnbNext(3)"><?php echo $detected_plugin ? 'Continuer →' : 'Suivant →'; ?></button>
        </div>
    </div>
</div>

<!-- ═══ STEP 3: API Key (optional) ═══ -->
<div class="hts-onb-card hts-hidden" id="step-3">
 <h2> Connexion au SaaS (optionnel)</h2>
    <p class="subtitle">Si vous avez un abonnement Hack The SEO, entrez votre clé API pour recevoir vos articles SEO directement dans WordPress.</p>

    <?php if ( $has_pending_migration ) : ?>
    <div class="hts-onb-detect" style="background:#fffbeb;border-color:#f59e0b;">
        <div class="icon">⚠️</div>
        <div class="text">
            <strong><?php echo esc_html( $detected_plugin ); ?></strong> est toujours actif et vos données n'ont pas été importées.
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-migration-wizard&from=onboarding' ) ); ?>" style="color:#d97706;font-weight:600;text-decoration:underline;">Lancer la migration</a> pour ne rien perdre, ou continuer sans importer.
        </div>
    </div>
    <?php elseif ( $detected_plugin && $migration_done ) : ?>
    <div class="hts-onb-detect" style="background:#f0fdf4;border-color:#16a34a;">
        <div class="icon">✅</div>
        <div class="text">
            Migration depuis <strong><?php echo esc_html( $detected_plugin ); ?></strong> terminée
            <?php if ( $migration_counts['titles'] || $migration_counts['descs'] ) : ?>
            — <?php echo $migration_counts['titles']; ?> titre(s) et <?php echo $migration_counts['descs']; ?> description(s) importé(s).
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="field">
        <label>Clé API</label>
        <input type="text" id="onb-api-key" placeholder="hts_xxxxxxxxxxxxxxxxxx" value="<?php echo esc_attr( $api_key ); ?>">
    </div>
    <p style="font-size:11px;color:#9da5b4;margin-top:-8px;">Vous la trouverez dans votre espace client sur <a href="https://www.hacktheseo.com" target="_blank">hacktheseo.com</a>. Pas d'abonnement ? Pas de souci — Hack The SEO fonctionne sans.</p>

    <div class="hts-onb-footer">
        <button class="hts-onb-btn hts-onb-btn-secondary" onclick="htsOnbNext(2)">← Retour</button>
        <div>
            <button class="hts-onb-btn-skip" onclick="htsOnbNext(4)">Passer →</button>
            <button class="hts-onb-btn hts-onb-btn-primary" onclick="htsOnbSaveApi()">Enregistrer et continuer →</button>
        </div>
    </div>
</div>

<!-- ═══ STEP 4: Configuration + Preview ═══ -->
<div class="hts-onb-card hts-hidden" id="step-4">
 <h2> Configuration de base</h2>
    <p class="subtitle">Derniers réglages avant de lancer le SEO sur votre site.</p>

    <div class="field">
        <label>Séparateur de titre</label>
        <select id="onb-separator" onchange="htsOnbUpdatePreview()">
            <option value="—" <?php selected( $separator, '—' ); ?>>— (tiret cadratin)</option>
            <option value="|" <?php selected( $separator, '|' ); ?>>| (pipe)</option>
            <option value="-" <?php selected( $separator, '-' ); ?>>- (tiret)</option>
            <option value="·" <?php selected( $separator, '·' ); ?>>· (point médian)</option>
            <option value="»" <?php selected( $separator, '»' ); ?>>> (chevron)</option>
        </select>
    </div>

    <div class="hts-mt-4">
        <label style="font-size:12px;font-weight:600;color:#374151;margin-bottom:8px;display:block;">Modules actifs</label>
        
        <div class="hts-onb-toggle-row">
            <div><div class="hts-tog-name">Meta Tags</div><div class="hts-tog-desc">Title, description, OG, Twitter</div></div>
            <label class="hts-onb-toggle"><input type="checkbox" checked data-mod="meta_tags" onchange="htsOnbUpdatePreview()"><span class="sl"></span></label>
        </div>
        <div class="hts-onb-toggle-row">
            <div><div class="hts-tog-name">Schema JSON-LD</div><div class="hts-tog-desc">Article, FAQ, HowTo auto-détection</div></div>
            <label class="hts-onb-toggle"><input type="checkbox" checked data-mod="schema" onchange="htsOnbUpdatePreview()"><span class="sl"></span></label>
        </div>
        <div class="hts-onb-toggle-row">
            <div><div class="hts-tog-name">Sitemap XML</div><div class="hts-tog-desc">Génération automatique</div></div>
            <label class="hts-onb-toggle"><input type="checkbox" checked data-mod="sitemap" onchange="htsOnbUpdatePreview()"><span class="sl"></span></label>
        </div>
        <div class="hts-onb-toggle-row">
            <div><div class="hts-tog-name">Redirections & 404</div><div class="hts-tog-desc">Monitoring et auto-redirect sur changement de slug</div></div>
            <label class="hts-onb-toggle"><input type="checkbox" checked data-mod="redirects" onchange="htsOnbUpdatePreview()"><span class="sl"></span></label>
        </div>
        <div class="hts-onb-toggle-row">
            <div><div class="hts-tog-name">Canonical</div><div class="hts-tog-desc">Self-referencing anti-duplication</div></div>
            <label class="hts-onb-toggle"><input type="checkbox" checked data-mod="canonical" onchange="htsOnbUpdatePreview()"><span class="sl"></span></label>
        </div>
    </div>

    <!-- Preview panel -->
    <div id="onb-preview-panel" style="margin-top:24px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;padding:20px;">
        <div style="font-size:12px;font-weight:600;color:#374151;margin-bottom:12px;">Aperçu de votre configuration</div>
        
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px;margin-bottom:12px;">
            <div style="font-size:11px;color:#16a34a;font-weight:600;margin-bottom:2px;">Résultat Google</div>
            <div id="onb-preview-title" style="font-size:16px;color:#1a0dab;font-weight:400;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                Mon article <?php echo esc_html( $separator ); ?> <?php echo esc_html( $site_name ); ?>
            </div>
            <div style="font-size:13px;color:#006621;"><?php echo esc_html( str_replace( array( 'https://', 'http://' ), '', $site_url ) ); ?> › mon-article</div>
            <div style="font-size:12px;color:#4d5156;margin-top:2px;">Votre meta description apparaîtra ici. Hack The SEO vous aidera à la rédiger.</div>
        </div>

        <div id="onb-preview-modules" style="display:flex;flex-wrap:wrap;gap:6px;">
        </div>

        <?php if ( ! empty( $detected_env ) ) : ?>
        <div style="margin-top:10px;font-size:11px;color:#64748b;">
            <?php if ( $is_multilingual ) : ?>
                🌐 Le SEO sera géré séparément pour chaque langue.
            <?php endif; ?>
            <?php if ( $has_woocommerce ) : ?>
                🛍️ Les fiches produit seront incluses dans l\'analyse.
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="hts-onb-footer">
        <button class="hts-onb-btn hts-onb-btn-secondary" onclick="htsOnbNext(3)">← Retour</button>
 <button class="hts-onb-btn hts-onb-btn-primary" onclick="htsOnbNext(5)">Configurer les agents →</button>
    </div>
</div>

<!-- ═══ STEP 5: Agent Quick Setup (Session I) ═══ -->
<div class="hts-onb-card hts-hidden" id="step-5">
    <h2>🤖 Vos agents SEO</h2>
    <p class="subtitle">Chaque agent automatise une partie de votre SEO. Activez ceux qui vous correspondent — vous pourrez tout ajuster plus tard.</p>

    <div style="max-width:520px;margin:0 auto;">
        <?php
        $onb_agents = array(
            'meta'            => array( 'label' => 'Optimisation des balises', 'desc' => 'Améliore vos titres et descriptions SEO automatiquement.', 'default' => true ),
            'linking'         => array( 'label' => 'Maillage interne', 'desc' => 'Propose des liens entre vos articles pour renforcer votre structure.', 'default' => true ),
            'content_quality' => array( 'label' => 'Qualité du contenu', 'desc' => 'Détecte les articles trop courts ou les images sans description.', 'default' => true ),
            'fresh'           => array( 'label' => 'Contenu frais', 'desc' => 'Signale les articles anciens qui mériteraient une mise à jour.', 'default' => true ),
            'geo_score'       => array( 'label' => 'Score GEO / IA', 'desc' => 'Mesure la compatibilité de vos pages avec les moteurs IA.', 'default' => false ),
            'cannib'          => array( 'label' => 'Détection de cannibalisation', 'desc' => 'Repère les pages qui se font concurrence entre elles.', 'default' => false ),
        );
        foreach ( $onb_agents as $ag_key => $ag ) :
        ?>
        <label style="display:flex;align-items:flex-start;gap:12px;padding:12px 16px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:8px;cursor:pointer;transition:border-color .2s;"
               onmouseover="this.style.borderColor='#a5b4fc'" onmouseout="this.style.borderColor='#e5e7eb'">
            <input type="checkbox" class="onb-agent-toggle" data-agent="<?php echo esc_attr( $ag_key ); ?>"
                   <?php echo $ag['default'] ? 'checked' : ''; ?>
                   style="margin-top:3px;width:16px;height:16px;accent-color:#6366f1;">
            <div>
                <div style="font-size:13px;font-weight:600;color:#1a1f36;"><?php echo esc_html( $ag['label'] ); ?></div>
                <div style="font-size:11px;color:#64748b;margin-top:2px;"><?php echo esc_html( $ag['desc'] ); ?></div>
            </div>
        </label>
        <?php endforeach; ?>
    </div>

    <!-- auto-formation : liens vers ressources -->
    <div id="onb-auto-formation" style="max-width:520px;margin:20px auto 0;padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
        <h3 style="font-size:14px;font-weight:600;color:#1a1f36;margin:0 0 8px;">📚 Auto-formation</h3>
        <p style="font-size:12px;color:#64748b;margin:0 0 10px;">Pour tirer le meilleur de Hack The SEO, consultez ces ressources après la configuration :</p>
        <ul style="margin:0;padding:0 0 0 18px;font-size:12px;color:#475569;list-style:disc;">
            <li style="margin-bottom:4px;">Guide de démarrage rapide dans le Coach SEO</li>
            <li style="margin-bottom:4px;">Comprendre vos scores SEO et GEO</li>
            <li style="margin-bottom:4px;">Configurer vos agents pour un maximum d\u0027efficacité</li>
        </ul>
    </div>

    <div class="hts-onb-footer" style="max-width:520px;margin:20px auto 0;">
        <button class="hts-onb-btn hts-onb-btn-secondary" onclick="htsOnbNext(4)">← Retour</button>
        <button class="hts-onb-btn hts-onb-btn-primary" onclick="htsOnbSaveAgents()"> Valider et lancer l'analyse →</button>
    </div>
</div>

<!-- ═══ STEP 6: Auto-Pilot Magic ═══ -->
<div class="hts-onb-card hts-hidden" id="step-6">
    <div style="text-align:center;margin-bottom:24px;">
        <h2 style="font-size:22px;">Hack The SEO prend les commandes</h2>
        <p class="subtitle" style="max-width:460px;margin:8px auto 0;">Installez-vous, on s'occupe de tout. Votre site va être analysé, configuré et optimisé automatiquement.</p>
    </div>

    <!-- Pipeline tasks -->
    <div id="onb-pipeline" style="max-width:520px;margin:0 auto;">

        <div class="onb-task" id="onb-t-modules" data-action="check_modules">
            <div class="onb-task-icon">
                <span class="onb-ico onb-ico-pending">○</span>
                <span class="onb-ico onb-ico-running hts-hidden">◎</span>
                <span class="onb-ico onb-ico-done hts-hidden">✓</span>
                <span class="onb-ico onb-ico-skip hts-hidden">–</span>
            </div>
            <div class="onb-task-body">
                <div class="onb-task-label">Activation des modules SEO</div>
                <div class="onb-task-detail"></div>
            </div>
        </div>

        <div class="onb-task" id="onb-t-sitemap" data-action="regen_sitemap">
            <div class="onb-task-icon">
                <span class="onb-ico onb-ico-pending">○</span>
                <span class="onb-ico onb-ico-running hts-hidden">◎</span>
                <span class="onb-ico onb-ico-done hts-hidden">✓</span>
                <span class="onb-ico onb-ico-skip hts-hidden">–</span>
            </div>
            <div class="onb-task-body">
                <div class="onb-task-label">Génération du sitemap XML</div>
                <div class="onb-task-detail"></div>
            </div>
        </div>

        <div class="onb-task" id="onb-t-flush" data-action="flush_rewrites">
            <div class="onb-task-icon">
                <span class="onb-ico onb-ico-pending">○</span>
                <span class="onb-ico onb-ico-running hts-hidden">◎</span>
                <span class="onb-ico onb-ico-done hts-hidden">✓</span>
                <span class="onb-ico onb-ico-skip hts-hidden">–</span>
            </div>
            <div class="onb-task-body">
                <div class="onb-task-label">Configuration des permaliens</div>
                <div class="onb-task-detail"></div>
            </div>
        </div>

        <div class="onb-task" id="onb-t-health" data-action="health_check">
            <div class="onb-task-icon">
                <span class="onb-ico onb-ico-pending">○</span>
                <span class="onb-ico onb-ico-running hts-hidden">◎</span>
                <span class="onb-ico onb-ico-done hts-hidden">✓</span>
                <span class="onb-ico onb-ico-skip hts-hidden">–</span>
            </div>
            <div class="onb-task-body">
                <div class="onb-task-label">Diagnostic de santé du site</div>
                <div class="onb-task-detail"></div>
            </div>
        </div>

        <div class="onb-task" id="onb-t-done" data-action="summary">
            <div class="onb-task-icon">
                <span class="onb-ico onb-ico-pending">○</span>
                <span class="onb-ico onb-ico-running hts-hidden">◎</span>
                <span class="onb-ico onb-ico-done hts-hidden">✓</span>
                <span class="onb-ico onb-ico-skip hts-hidden">–</span>
            </div>
            <div class="onb-task-body">
                <div class="onb-task-label">Préparation de votre tableau de bord</div>
                <div class="onb-task-detail"></div>
            </div>
        </div>
    </div>

    <!-- Global progress bar -->
    <div id="onb-global-bar" style="max-width:520px;margin:24px auto 0;">
        <div style="background:#f3f4f6;border-radius:8px;overflow:hidden;height:6px;">
            <div id="onb-global-fill" style="height:100%;width:0%;background:linear-gradient(90deg,#6366f1,#a78bfa);border-radius:8px;transition:width .6s ease;"></div>
        </div>
        <p id="onb-global-status" style="font-size:11px;color:#9da5b4;text-align:center;margin-top:8px;"></p>
    </div>

    <!-- Results panel (hidden until pipeline completes) -->
    <div id="onb-results-panel" class="hts-hidden" style="max-width:520px;margin:28px auto 0;text-align:center;">
        <div style="font-size:48px;margin-bottom:12px;">🎉</div>
        <h3 style="font-size:18px;font-weight:700;color:#1a1f36;margin-bottom:8px;">Tout est configuré !</h3>
        <p style="font-size:13px;color:#64748b;max-width:400px;margin:0 auto;">Hack The SEO est actif sur votre site. Retrouvez vos scores, actions et recommandations dans le tableau de bord.</p>
    </div>

    <!-- Buttons -->
    <div class="hts-onb-footer" style="max-width:520px;margin:20px auto 0;">
        <button class="hts-onb-btn hts-onb-btn-secondary" id="onb-back-btn" onclick="htsOnbNext(5)">← Retour</button>
        <div>
            <button class="hts-onb-btn-skip" id="onb-skip-btn" onclick="htsOnbSkipToEnd()">Passer →</button>
            <button class="hts-onb-btn hts-onb-btn-primary" id="onb-launch-btn" onclick="htsOnbLaunchPipeline()">
                🚀 Lancer la configuration
            </button>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard' ) ); ?>" class="hts-onb-btn hts-onb-btn-primary hts-hidden" id="onb-dashboard-btn" style="display:inline-block;text-decoration:none;">
                Accéder au tableau de bord →
            </a>
        </div>
    </div>
</div>

</div><!-- .hts-onb -->

<script>
var HTS_ONB = { nonce: '<?php echo esc_js( $nonce ); ?>', ajax: '<?php echo esc_js( $ajax ); ?>' };
var TOTAL_STEPS = 6; // 6 steps: Welcome, Migration, API, Config, Agents, Auto-pilot
var PROGRESS_SEGMENTS = 8;

/* ═══ Navigation ═══ */
function htsOnbNext(step) {
    for (var i = 1; i <= TOTAL_STEPS; i++) {
        var el = document.getElementById('step-' + i);
        if (el) { el.classList.add('hts-hidden'); el.style.display = ''; }
    }
    var target = document.getElementById('step-' + step);
    if (target) target.classList.remove('hts-hidden');

    // Progress: steps 1-4 map to segments 1-4, step 5 = segment 5 (fills up during pipeline)
    for (var j = 1; j <= PROGRESS_SEGMENTS; j++) {
        var prog = document.getElementById('prog-' + j);
        if (!prog) continue;
        prog.className = 'step';
        if (j < step) prog.classList.add('done');
        else if (j === step) prog.classList.add('active');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ═══ Config steps (unchanged) ═══ */
function htsOnbSaveApi() {
    var key = document.getElementById('onb-api-key').value.trim();
    if (!key) { htsOnbNext(4); return; }
    var fd = new FormData();
    fd.append('action', 'hts_save_api_key');
    fd.append('nonce', HTS_ONB.nonce);
    fd.append('api_key', key);
    fetch(HTS_ONB.ajax, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function() { htsOnbNext(4); });
}

/* ═══ Preview ═══ */
function htsOnbUpdatePreview() {
    var sep = document.getElementById('onb-separator').value;
    var titleEl = document.getElementById('onb-preview-title');
    if (titleEl) {
        titleEl.textContent = 'Mon article ' + sep + ' <?php echo esc_js( $site_name ); ?>';
    }
    var modPanel = document.getElementById('onb-preview-modules');
    if (modPanel) {
        var toggles = document.querySelectorAll('.hts-onb-toggle-row input[data-mod]');
        var badges = '';
        var names = { meta_tags: 'Meta Tags', schema: 'Schema', sitemap: 'Sitemap', redirects: 'Redirections', canonical: 'Canonical' };
        toggles.forEach(function(t) {
            var on = t.checked;
            var name = names[t.dataset.mod] || t.dataset.mod;
            badges += '<span style="font-size:11px;padding:3px 10px;border-radius:10px;font-weight:500;' +
                (on ? 'background:#f0fdf4;color:#166534;' : 'background:#fef2f2;color:#dc2626;text-decoration:line-through;') +
                '">' + (on ? '✓ ' : '✗ ') + name + '</span>';
        });
        modPanel.innerHTML = badges;
    }
}
// Init preview on step 4 show
var _origHtsOnbNext = htsOnbNext;
htsOnbNext = function(step) {
    _origHtsOnbNext(step);
    if (step === 4) htsOnbUpdatePreview();
};

function htsOnbSaveAgents() {
    var checks = document.querySelectorAll('.onb-agent-toggle');
    var agents = {};
    checks.forEach(function(c) { agents[c.dataset.agent] = c.checked ? 1 : 0; });
    var fd = new FormData();
    fd.append('action', 'hts_onboarding_save_agents');
    fd.append('nonce', HTS_ONB.nonce);
    fd.append('agents', JSON.stringify(agents));
    fetch(HTS_ONB.ajax, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function() { htsOnbFinish(); });
}

function htsOnbFinish() {
    var sep = document.getElementById('onb-separator').value;
    var toggles = document.querySelectorAll('.hts-onb-toggle-row input[data-mod]');
    var modules = {};
    toggles.forEach(function(t) { modules[t.dataset.mod] = t.checked ? 1 : 0; });
    var fd = new FormData();
    fd.append('action', 'hts_onboarding_finish');
    fd.append('nonce', HTS_ONB.nonce);
    fd.append('separator', sep);
    fd.append('modules', JSON.stringify(modules));
    fetch(HTS_ONB.ajax, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function() { htsOnbNext(6); });
}

/* ═══ Auto-Pilot Pipeline Engine ═══ */
var _pipelineData = { health: null };
var _tasks = ['onb-t-modules','onb-t-sitemap','onb-t-flush','onb-t-health','onb-t-done'];
var _pollScanTimer = null;

/**
 * Poll le statut du scan pendant le pipeline.
 * Vérifie toutes les 3s si le scan batch est terminé.
 */
function _pollScan(resolve) {
    _pollScanTimer = setInterval(function() {
        _ajaxPost('hts_onboarding_scan_status').then(function(res) {
            if (res.success && res.data) {
                var pct = res.data.percent || 0;
                _setGlobalProgress(33 + Math.round(pct * 0.17), 'Scan en cours… ' + pct + '%');
                if (res.data.complete) {
                    clearInterval(_pollScanTimer);
                    _pollScanTimer = null;
                    resolve(res.data);
                }
            }
        }).catch(function() {
            clearInterval(_pollScanTimer);
            _pollScanTimer = null;
            resolve(null);
        });
    }, 3000);
}

function _setTask(id, state, detail) {
    var el = document.getElementById(id);
    if (!el) return;
    el.className = 'onb-task' + (state ? ' is-' + state : '');
    var det = el.querySelector('.onb-task-detail');
    if (det && detail !== undefined) det.textContent = detail;
}

function _setGlobalProgress(pct, text) {
    var fill = document.getElementById('onb-global-fill');
    var status = document.getElementById('onb-global-status');
    if (fill) fill.style.width = pct + '%';
    if (status) status.textContent = text || '';

    // Also fill progress bar segments
    var segFilled = Math.ceil((pct / 100) * 3) + 4; // 4 config segments done + up to 3 more
    for (var j = 1; j <= PROGRESS_SEGMENTS; j++) {
        var prog = document.getElementById('prog-' + j);
        if (!prog) continue;
        prog.className = 'step';
        if (j <= Math.min(segFilled, PROGRESS_SEGMENTS)) prog.classList.add('done');
        else if (j === segFilled + 1) prog.classList.add('active');
    }
}

function _ajaxPost(action, extraData) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', HTS_ONB.nonce);
    if (extraData) {
        for (var k in extraData) fd.append(k, extraData[k]);
    }
    return fetch(HTS_ONB.ajax, { method: 'POST', body: fd }).then(function(r) { return r.json(); });
}

function _sleep(ms) { return new Promise(function(r) { setTimeout(r, ms); }); }

async function htsOnbLaunchPipeline() {
    // Hide launch button, show pipeline running
    document.getElementById('onb-launch-btn').classList.add('hts-hidden');
    document.getElementById('onb-skip-btn').classList.add('hts-hidden');
    document.getElementById('onb-back-btn').classList.add('hts-hidden');

    // ─── Task 1: Check modules ───
    _setTask('onb-t-modules', 'running', 'Vérification en cours…');
    _setGlobalProgress(5, 'Initialisation…');
    await _sleep(600);
    var mods = [];
    document.querySelectorAll('.hts-onb-toggle-row input[data-mod]').forEach(function(t) {
        if (t.checked) mods.push(t.dataset.mod);
    });
    _setTask('onb-t-modules', 'done', mods.length + ' modules activés');
    _setGlobalProgress(10, 'Modules vérifiés');

    // ─── Task 2: Regen sitemap ───
    _setTask('onb-t-sitemap', 'running', 'Création en cours…');
    _setGlobalProgress(15, 'Génération du sitemap…');
    try {
        await _ajaxPost('hts_onboarding_regen_sitemap');
        _setTask('onb-t-sitemap', 'done', 'Sitemap généré avec succès');
    } catch(e) {
        _setTask('onb-t-sitemap', 'done', 'Sitemap planifié');
    }
    _setGlobalProgress(22);

    // ─── Task 3: Flush rewrites ───
    _setTask('onb-t-flush', 'running', 'Mise à jour…');
    _setGlobalProgress(25, 'Permaliens…');
    try {
        await _ajaxPost('hts_onboarding_flush_rewrites');
        _setTask('onb-t-flush', 'done', 'Permaliens à jour');
    } catch(e) {
        _setTask('onb-t-flush', 'done', 'OK');
    }
    _setGlobalProgress(30);

    // ─── Task 4: Health check ───
    _setTask('onb-t-health', 'running', 'Vérification de 12+ composants…');
    _setGlobalProgress(33, 'Diagnostic de santé…');
    try {
        var hRes = await _ajaxPost('hts_onboarding_health_check');
        if (hRes.success && hRes.data) {
            _pipelineData.health = hRes.data;
            var pct = hRes.data.percent || hRes.data.score || '—';
            _setTask('onb-t-health', 'done', 'Santé : ' + pct + '%');
        } else {
            _setTask('onb-t-health', 'done', 'Diagnostic terminé');
        }
    } catch(e) {
        _setTask('onb-t-health', 'done', 'Diagnostic terminé');
    }
    _setGlobalProgress(50);

    // ─── Task 5: Summary ───
    _setTask('onb-t-done', 'running', 'Finalisation…');
    _setGlobalProgress(80, 'Préparation du tableau de bord…');
    await _sleep(600);

    // Mark onboarding complete
    _ajaxPost('hts_onboarding_v2_done');

    _setTask('onb-t-done', 'done', 'Tout est prêt !');
    _setGlobalProgress(100, 'Terminé !');
    await _sleep(400);

    // ─── Show results ───
    document.getElementById('onb-results-panel').classList.remove('hts-hidden');
    document.getElementById('onb-dashboard-btn').classList.remove('hts-hidden');
    document.getElementById('onb-global-bar').style.display = 'none';
}

/* ═══ Skip / URL nav ═══ */
function htsOnbSkipToEnd() {
    _ajaxPost('hts_onboarding_v2_done');
    window.location.href = '<?php echo esc_url( admin_url( 'admin.php?page=hts-light-dashboard' ) ); ?>';
}

(function() {
    function _applyStepFromUrl() {
        var params = new URLSearchParams(window.location.search);
        var startStep = parseInt(params.get('step'));
        if (startStep && startStep >= 2 && startStep <= TOTAL_STEPS) {
            htsOnbNext(startStep);
        }
    }
    // Run immediately
    _applyStepFromUrl();
    // Also on DOMContentLoaded (in case DOM not ready)
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', _applyStepFromUrl);
    }
    // Also on pageshow (back/forward cache)
    window.addEventListener('pageshow', function(e) {
        if (e.persisted) _applyStepFromUrl();
    });
})();
</script>
</div>
<?php
