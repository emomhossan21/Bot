<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Standalone Article Generator — Session Q
 *
 * API integration for generating standalone articles via app.hacktheseo.com.
 * Separate from the Cocon Commander flow (no cocon_id required).
 *
 * @package Hack_The_SEO
 * @since   2.4.8
 */


class HTS_Standalone_Article {

    /** Base API path (appended to hts_api_base_url option). */
    const API_PATH = '/api/v1/article';

    /** Option key for storing active jobs. */
    const JOBS_OPTION = 'hts_standalone_jobs';

    public function init() {
        add_action( 'wp_ajax_hts_standalone_generate',     array( $this, 'ajax_generate' ) );
        add_action( 'wp_ajax_hts_standalone_status',       array( $this, 'ajax_poll_status' ) );
        add_action( 'wp_ajax_hts_standalone_create_draft', array( $this, 'ajax_create_draft' ) );
        add_action( 'wp_ajax_hts_standalone_jobs',         array( $this, 'ajax_get_jobs' ) );
        add_action( 'wp_ajax_hts_standalone_suggest',      array( $this, 'ajax_suggest_subtopic' ) );

        // Background enrichment hook (images, schemas, cross-links)
        add_action( 'hts_standalone_enrich_draft', array( $this, 'background_enrich_draft' ), 10, 4 );
    }

    /* =========================================================================
     * API HELPER
     * ====================================================================== */

    /**
     * Call the standalone article API.
     * Note: The standalone article API is ALWAYS on app.hacktheseo.com,
     * NOT on the cocon base URL (which may be prep.hacktheseo.com for testing).
     *
     * @param string $method  GET or POST
     * @param string $endpoint  e.g. 'generate', 'status/42'
     * @param array  $body  Payload for POST
     * @return array { success, status, data, error }
     */
    private function api_call( $method, $endpoint, $body = array() ) {
        $api_key = hts_get_api_key();
        $base    = rtrim( get_option( 'hts_api_base_url', 'https://app.hacktheseo.com' ), '/' );
        $url     = $base . self::API_PATH . '/' . ltrim( $endpoint, '/' );

        $args = array(
            'timeout' => $method === 'POST' ? 30 : 15,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'x-api-key'    => $api_key,
            ),
        );

        if ( $method === 'POST' ) {
            $args['method'] = 'POST';
            $args['body']   = wp_json_encode( $body );
            $response = wp_remote_post( $url, $args );
        } else {
            $response = wp_remote_get( $url, $args );
        }

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'error' => $response->get_error_message(), 'status' => 0, 'data' => null );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        // Handle specific error codes with friendly messages
        $error = null;
        if ( $code === 401 ) {
            $error = 'Clé API invalide ou manquante. Vérifiez vos réglages.';
        } elseif ( $code === 403 ) {
            $error = $data['message'] ?? 'Crédit articles insuffisant. Rendez-vous sur votre espace Hack The SEO pour en acheter.';
        } elseif ( $code === 422 ) {
            $errors = $data['errors'] ?? array();
            $error  = $data['message'] ?? 'Données invalides.';
            if ( ! empty( $errors ) ) {
                $error .= ' ' . implode( ' ', array_map( function( $msgs ) {
                    return is_array( $msgs ) ? implode( ', ', $msgs ) : $msgs;
                }, $errors ) );
            }
        } elseif ( $code >= 400 ) {
            $error = $data['message'] ?? $data['error'] ?? 'Erreur HTTP ' . $code;
        }

        return array(
            'success' => $code >= 200 && $code < 300,
            'status'  => $code,
            'data'    => $data,
            'error'   => $error,
        );
    }

    /* =========================================================================
     * AJAX HANDLERS
     * ====================================================================== */

    /**
     * AJAX: Launch a standalone article generation.
     */
    public function ajax_generate() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission refusée.' );
        HTS_Subscription::require_tier(2);

        $keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
        $subject = sanitize_text_field( $_POST['subject'] ?? '' );
        $intent  = sanitize_text_field( $_POST['intent'] ?? 'informational' );
        $tone    = sanitize_text_field( $_POST['tone'] ?? '' );
        $word_count = (int) ( $_POST['word_count'] ?? 0 );
        $parent_id  = (int) ( $_POST['parent_id'] ?? 0 ); // For petit-fils flow

        if ( empty( $keyword ) || empty( $subject ) ) {
            wp_send_json_error( 'Mot-clé et sujet sont obligatoires.' );
        }

        // Build language code
        $locale = get_locale();
        $lang   = substr( $locale, 0, 2 );
        if ( strlen( $locale ) >= 5 ) {
            $lang = substr( $locale, 0, 2 ) . '-' . strtoupper( substr( $locale, 3, 2 ) );
        }
        if ( class_exists( 'HTS_Language' ) ) {
            $hts_lang = \HTS_Language::get_current_lang();
            if ( strlen( $hts_lang ) >= 2 && $hts_lang !== 'all' ) $lang = $hts_lang;
        }
        // Guard: never send 'all' as language
        if ( empty( $lang ) || $lang === 'all' ) {
            $lang = 'fr-FR';
        }

        // Anti-cannibalisation pre-check
        $cannibal_warning = null;
        if ( class_exists( 'HTS_Embeddings' ) ) {
            $emb = new \HTS_Embeddings();
            $proposed_vector = $emb->get_embedding( trim( $subject . ' ' . $keyword ) );
            if ( ! empty( $proposed_vector ) ) {
                $vectors = $emb->load_all_vectors( true );
                $conflicts = array();
                foreach ( $vectors as $pid => $vec ) {
                    if ( $parent_id && $pid === $parent_id ) continue;
                    $sim = \HTS_Embeddings::cosine_similarity( $proposed_vector, $vec );
                    if ( $sim >= 0.82 ) {
                        $conflicts[] = array(
                            'post_id'    => $pid,
                            'title'      => get_the_title( $pid ),
                            'similarity' => round( $sim * 100 ),
                        );
                    }
                }
                if ( ! empty( $conflicts ) ) {
                    usort( $conflicts, function( $a, $b ) { return $b['similarity'] - $a['similarity']; } );
                    $cannibal_warning = array(
                        'message'   => sprintf( 'Attention : « %s » est similaire à %d article(s) existant(s).', mb_substr( $subject, 0, 50 ), count( $conflicts ) ),
                        'conflicts' => array_slice( $conflicts, 0, 5 ),
                    );
                }
            }
        }

        // If cannibal check found issues and skip not set, return warning
        $skip_cannibal = (bool) ( $_POST['skip_cannibal_check'] ?? false );
        if ( $cannibal_warning && ! $skip_cannibal ) {
            wp_send_json_error( array(
                'cannibal_warning' => true,
                'message'   => $cannibal_warning['message'],
                'conflicts' => $cannibal_warning['conflicts'],
            ) );
        }

        // Build request body
        $body = array(
            'keyword'  => $keyword,
            'subject'  => $subject,
            'site_url' => site_url(),
            'language' => $lang,
            'intent'   => $intent,
        );
        if ( ! empty( $tone ) ) $body['tone'] = $tone;
        if ( $word_count >= 500 && $word_count <= 5000 ) $body['word_count'] = $word_count;

        $result = $this->api_call( 'POST', 'generate', $body );

        if ( ! $result['success'] ) {
            wp_send_json_error( array( 'message' => $result['error'] ?? 'Erreur API' ) );
        }

        $job_id = (int) ( $result['data']['job_id'] ?? 0 );

        // Store job info
        $jobs = get_option( self::JOBS_OPTION, array() );
        $jobs[ $job_id ] = array(
            'job_id'     => $job_id,
            'keyword'    => $keyword,
            'subject'    => $subject,
            'intent'     => $intent,
            'parent_id'  => $parent_id,
            'status'     => 'queued',
            'created_at' => current_time( 'Y-m-d H:i:s' ),
            'post_id'    => null,
        );
        update_option( self::JOBS_OPTION, $jobs, false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( '✍️ Article standalone lancé : « %s » (job #%d)', mb_substr( $subject, 0, 50 ), $job_id ),
                'success', 'standalone'
            );
        }

        wp_send_json_success( array(
            'job_id'    => $job_id,
            'status'    => 'queued',
            'message'   => $result['data']['message'] ?? 'Génération en cours...',
            'estimated' => $result['data']['estimated_seconds'] ?? 120,
        ) );
    }

    /**
     * AJAX: Poll standalone article status.
     */
    public function ajax_poll_status() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $job_id = (int) ( $_POST['job_id'] ?? 0 );
        if ( ! $job_id ) wp_send_json_error( 'job_id requis.' );

        $result = $this->api_call( 'GET', 'status/' . $job_id );

        if ( ! $result['success'] ) {
            wp_send_json_error( array( 'message' => $result['error'] ?? 'Erreur polling' ) );
        }

        $data   = $result['data'];
        $status = $data['status'] ?? 'unknown';

        // If completed, store article in transient for draft creation
        if ( $status === 'completed' && ! empty( $data['article'] ) ) {

            // ── DEBUG: Log raw API response BEFORE any processing ──
            $raw_html    = $data['article']['content_html'] ?? '';
            $raw_words   = count( preg_split( '/\s+/', trim( wp_strip_all_tags( $raw_html ) ), -1, PREG_SPLIT_NO_EMPTY ) );
            $raw_bytes   = strlen( $raw_html );
            $raw_last100 = mb_substr( strip_tags( $raw_html ), -100 );
            $api_wc      = $data['article']['word_count'] ?? 'N/A';

            if ( class_exists( 'HTS_Cocon_Commander' ) ) {
                \HTS_Cocon_Commander::cocon_log( 'standalone_raw', sprintf(
                    'API BRUT: %d mots réels | API dit %s mots | %d bytes | Fin: ...%s',
                    $raw_words, $api_wc, $raw_bytes, mb_substr( $raw_last100, -80 )
                ), array( 'job_id' => $job_id ) );
            }

            set_transient( 'hts_standalone_article_' . $job_id, $data['article'], HOUR_IN_SECONDS );

            // Update job status
            $jobs = get_option( self::JOBS_OPTION, array() );
            if ( isset( $jobs[ $job_id ] ) ) {
                $jobs[ $job_id ]['status'] = 'completed';
                update_option( self::JOBS_OPTION, $jobs, false );
            }
        }

        if ( $status === 'failed' ) {
            $jobs = get_option( self::JOBS_OPTION, array() );
            if ( isset( $jobs[ $job_id ] ) ) {
                $jobs[ $job_id ]['status'] = 'failed';
                update_option( self::JOBS_OPTION, $jobs, false );
            }
        }

        wp_send_json_success( array(
            'status'  => $status,
            'phase'   => $data['phase'] ?? '',
            'job_id'  => $job_id,
            'article' => ( $status === 'completed' ) ? array(
                'title'      => $data['article']['title'] ?? '',
                'word_count' => $data['article']['word_count'] ?? 0,
                'slug'       => $data['article']['slug'] ?? '',
            ) : null,
        ) );
    }

    /**
     * AJAX: Create WordPress draft from completed standalone article.
     */
    public function ajax_create_draft() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        // Extend execution time — enrichment (DALL-E images, cross-linking) can take 60s+
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 120 );
        }

        $job_id    = (int) ( $_POST['job_id'] ?? 0 );
        $parent_id = (int) ( $_POST['parent_id'] ?? 0 );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Standalone create_draft START — job #{$job_id}, parent #{$parent_id}", 'info', 'standalone' );
        }

        $article = get_transient( 'hts_standalone_article_' . $job_id );
        if ( ! $article || empty( $article['content_html'] ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Standalone create_draft — transient vide pour job #{$job_id}", 'error', 'standalone' );
            }
            wp_send_json_error( array( 'message' => 'Article introuvable — le transient a expiré.' ) );
        }

        $keyword      = $article['keyword'] ?? '';
        $content_html = $article['content_html'];
        $meta_title   = sanitize_text_field( $article['meta_title'] ?? '' );
        $meta_desc    = sanitize_text_field( $article['meta_description'] ?? '' );
        $slug         = sanitize_title( $article['slug'] ?? '' );

        if ( class_exists( 'HTS_Cocon_Commander' ) ) {
            $pre_words = count( preg_split( '/\s+/', trim( wp_strip_all_tags( $content_html ) ), -1, PREG_SPLIT_NO_EMPTY ) );
            $pre_last  = mb_substr( strip_tags( $content_html ), -80 );
            \HTS_Cocon_Commander::cocon_log( 'standalone_before', sprintf(
                'AVANT traitement: %d mots | %d bytes | Fin: ...%s',
                $pre_words, strlen( $content_html ), $pre_last
            ), array( 'keyword' => $keyword ) );
        }

        // ── 1. Extract metas from HTML <head> if not provided by API ──
        $admin_class = 'HTS_Synchronise_Articles_Admin';
        if ( empty( $meta_title ) && class_exists( $admin_class ) && method_exists( $admin_class, 'cocon_extract_metas_from_html' ) ) {
            $extracted = $admin_class::cocon_extract_metas_from_html( $content_html );
            if ( empty( $meta_title ) ) $meta_title = $extracted['meta_title'] ?? '';
            if ( empty( $meta_desc ) )  $meta_desc  = $extracted['meta_description'] ?? '';
        }

        // ── 2. Strip <html>, <head>, <body> wrappers (API may return full page) ──
        if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $content_html, $body_match ) ) {
            $content_html = $body_match[1];
        }

        // ── 3. Extract H1 for post title ──
        $wp_title = '';
        if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/si', $content_html, $h1m ) ) {
            $wp_title = wp_strip_all_tags( $h1m[1] );
        }
        if ( empty( $wp_title ) ) {
            $wp_title = sanitize_text_field( $article['title'] ?? 'Article sans titre' );
        }

        // ── 4. SEO metas — use API values directly (AI optimization disabled for speed) ──
        // cocon_generate_seo_metas is an OpenAI call that can timeout the AJAX request.
        // TODO: re-enable once base flow is stable.
        $meta_title = mb_substr( $meta_title, 0, 60 );
        $meta_desc  = mb_substr( $meta_desc, 0, 155 );
        if ( empty( $meta_title ) ) $meta_title = mb_substr( $wp_title, 0, 60 );
        if ( empty( $slug ) ) $slug = sanitize_title( $keyword ?: $wp_title );

        // ── 5. Clean HTML — same pipeline as Full version ──
        $wp_content = $content_html;
        $wp_content = preg_replace( '/<meta[^>]*>/i', '', $wp_content )          ?? $wp_content;
        $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content )  ?? $wp_content;
        $wp_content = preg_replace( '/<title>.*?<\/title>/si', '', $wp_content ) ?? $wp_content;
        $wp_content = preg_replace( '/\nSTOP\n.*$/s', '', $wp_content )          ?? $wp_content;
        $wp_content = preg_replace( '/<!--.*?-->/s', '', $wp_content )           ?? $wp_content;

        // ── 5b. Fix markdown-style citation links → proper HTML <a> ──
        if ( class_exists( $admin_class ) && method_exists( $admin_class, 'cocon_fix_markdown_links' ) ) {
            $links_result = $admin_class::cocon_fix_markdown_links( $wp_content );
            if ( $links_result !== null && $links_result !== '' ) {
                $wp_content = $links_result;
            }
        }

        // ── 5c. Remove AI spam blocks (only very specific foreign-language keyword dumps) ──
        $wp_content = preg_replace(
            '/\s*(?:<p>)?\s*(?:Note\s+s[ée]mantique|S[ée]mantique\s*[:\(]|Keywords?\s*[:\(])[^<]*(?:downloads|cookies|technologien|lunacourses|gutscheine|personalisierte|anleitung|hinzuf[üu]gen|kollektion|werbung)[^<]*(?:<\/p>)?\s*/si',
            '', $wp_content
        ) ?? $wp_content;

        $wp_content = trim( $wp_content );

        // ── DEBUG: Log AFTER cleaning ──
        if ( class_exists( 'HTS_Cocon_Commander' ) ) {
            $post_words = count( preg_split( '/\s+/', trim( wp_strip_all_tags( $wp_content ) ), -1, PREG_SPLIT_NO_EMPTY ) );
            $post_last  = mb_substr( strip_tags( $wp_content ), -80 );
            \HTS_Cocon_Commander::cocon_log( 'standalone_after', sprintf(
                'APRÈS nettoyage: %d mots | %d bytes | Fin: ...%s',
                $post_words, strlen( $wp_content ), $post_last
            ), array( 'keyword' => $keyword ) );
        }

        // ── 5e. Safety net: if content is empty after cleaning, fallback to raw ──
        if ( empty( $wp_content ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Standalone contenu vide après nettoyage — fallback raw', 'warn', 'standalone' );
            }
            $wp_content = $article['content_html'];
            if ( preg_match( '/<body[^>]*>(.*)<\/body>/s', $wp_content, $fb ) ) {
                $wp_content = $fb[1];
            }
            $wp_content = preg_replace( '/<h1[^>]*>.*?<\/h1>/si', '', $wp_content ) ?? $wp_content;
            $wp_content = trim( $wp_content );
        }

        // ── 6. Create draft — NO wp_kses, same as Full version ──
        $default_author = (int) get_option( 'hts_default_author', 0 );
        $post_id = wp_insert_post( array(
            'post_title'   => $wp_title,
            'post_name'    => sanitize_title( $slug ),
            'post_content' => $wp_content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => $default_author > 0 ? $default_author : get_current_user_id(),
            'meta_input'   => array(
                '_hts_api_generated'       => 1,
                '_hts_api_keyword'         => $keyword,
                '_hts_standalone_job_id'   => $job_id,
            ),
        ) );

        if ( is_wp_error( $post_id ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Standalone wp_insert_post FAILED: ' . $post_id->get_error_message(), 'error', 'standalone' );
            }
            wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "Standalone draft créé: post #{$post_id} — « " . mb_substr( $wp_title, 0, 40 ) . ' »', 'success', 'standalone' );
        }

        // Apply SEO metas (all plugins)
        try {
            if ( class_exists( 'HTS_Cocon_Commander' ) && method_exists( 'HTS_Cocon_Commander', 'apply_seo_metas_multi_plugin' ) ) {
                \HTS_Cocon_Commander::apply_seo_metas_multi_plugin( $post_id, $meta_title, $meta_desc, $keyword );
            } else {
                update_post_meta( $post_id, '_hts_meta_title', $meta_title );
                update_post_meta( $post_id, '_hts_meta_description', $meta_desc );
                update_post_meta( $post_id, '_hts_keyword', $keyword );
                if ( defined( 'WPSEO_VERSION' ) ) {
                    update_post_meta( $post_id, '_yoast_wpseo_title', $meta_title );
                    update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_desc );
                    update_post_meta( $post_id, '_yoast_wpseo_focuskw', $keyword );
                }
                if ( class_exists( 'RankMath' ) ) {
                    update_post_meta( $post_id, 'rank_math_title', $meta_title );
                    update_post_meta( $post_id, 'rank_math_description', $meta_desc );
                    update_post_meta( $post_id, 'rank_math_focus_keyword', $keyword );
                }
            }
        } catch ( \Exception $e ) {
            // Non-blocking
        }

        /* ══════════════════════════════════════════════════════════════
         * ENRICHISSEMENT DÉSACTIVÉ TEMPORAIREMENT
         * Images DALL-E, schemas, cross-interlink, cluster assignment
         * → À réactiver une fois que le brouillon de base fonctionne
         * ══════════════════════════════════════════════════════════════ */

        // Petit-fils: assign to parent cluster (lightweight, no API calls)
        if ( $parent_id > 0 ) {
            $this->auto_assign_to_parent_cluster( $post_id, $parent_id, $wp_title, $keyword );
        }

        // Update job
        $jobs = get_option( self::JOBS_OPTION, array() );
        if ( isset( $jobs[ $job_id ] ) ) {
            $jobs[ $job_id ]['status']  = 'draft_created';
            $jobs[ $job_id ]['post_id'] = $post_id;
            update_option( self::JOBS_OPTION, $jobs, false );
        }

        // Cleanup
        delete_transient( 'hts_standalone_article_' . $job_id );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( 'Brouillon standalone créé : « %s » → #%d (%d mots)',
                    mb_substr( $wp_title, 0, 40 ), $post_id, $article['word_count'] ?? 0 ),
                'success', 'standalone'
            );
        }

        // Compute actual word count (French-aware)
        $final_text = wp_strip_all_tags( $wp_content );
        $final_words = hts_word_count( $final_text );
        if ( $final_words < 50 ) {
            $final_words = count( preg_split( '/\s+/', trim( $final_text ), -1, PREG_SPLIT_NO_EMPTY ) );
        }

        // Detect truncation
        $requested_wc = (int) ( $article['word_count'] ?? 0 );
        $truncation_warning = '';
        if ( $requested_wc > 0 && $final_words < ( $requested_wc * 0.7 ) ) {
            $truncation_warning = sprintf(
                'Article possiblement incomplet : %d mots reçus sur %d demandés. L\u0027API a livré un contenu tronqué.',
                $final_words, $requested_wc
            );
        }

        wp_send_json_success( array(
            'post_id'             => $post_id,
            'title'               => $wp_title,
            'word_count'          => $final_words,
            'edit_url'            => get_edit_post_link( $post_id, 'raw' ),
            'truncation_warning'  => $truncation_warning,
        ) );
    }

    /**
     * AJAX: Get active/recent jobs for display.
     */
    public function ajax_get_jobs() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $jobs = get_option( self::JOBS_OPTION, array() );
        // Return last 10, newest first
        $jobs = array_slice( array_reverse( $jobs, true ), 0, 10, true );
        wp_send_json_success( array( 'jobs' => array_values( $jobs ) ) );
    }

    /* =========================================================================
     * PETIT-FILS FLOW — Auto-assign + auto-link
     * ====================================================================== */

    /**
     * Assign a newly created article to its parent's NLP cluster
     * and create linking proposals (child↔parent).
     *
     * @param int    $post_id    New article post ID
     * @param int    $parent_id  Parent article post ID
     * @param string $title      New article title
     * @param string $keyword    New article keyword
     */
    /**
     * Background enrichment via WP Cron — runs after AJAX response is sent.
     * Handles images (DALL-E), schemas, and cross-cocon interlinking.
     */
    public function background_enrich_draft( $post_id, $title, $keyword, $content ) {
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( "🔄 Standalone background enrichment START pour #{$post_id}", 'info', 'standalone' );
        }
        try {
            if ( class_exists( 'HTS_Article_Pipeline' ) ) {
                \HTS_Article_Pipeline::enrich_draft( $post_id, $title, $keyword, $content );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "Standalone pipeline enrichment done pour #{$post_id}", 'info', 'standalone' );
                }
            } else {
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "HTS_Article_Pipeline non disponible — enrichissement ignoré pour #{$post_id}", 'warn', 'standalone' );
                }
            }
        } catch ( \Exception $e ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Standalone pipeline erreur: ' . $e->getMessage(), 'warn', 'standalone' );
            }
        }
    }

    /**
     * Auto-detect the nearest cluster for a standalone article (no parent).
     * Uses embeddings similarity to find the closest existing article,
     * then assigns the standalone to that article's cluster.
     * Actual link injection is handled by cocon_cross_interlink() after this.
     */
    private function auto_detect_nearest_cluster( $post_id, $title, $keyword, $content ) {
        // ── 1. Index the new article in embeddings first ──
        if ( class_exists( 'HTS_Embeddings' ) ) {
            try {
                $emb = new \HTS_Embeddings();
                $emb->index_post( $post_id );
                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log( "📐 Standalone #{$post_id} indexé dans embeddings", 'info', 'standalone' );
                }
            } catch ( \Exception $e ) {
                // Non-blocking
            }
        }

        // ── 2. Find most similar articles via embeddings ──
        $similar = array();
        if ( class_exists( 'HTS_Embeddings' ) ) {
            try {
                $emb = new \HTS_Embeddings();
                $similar = $emb->find_similar( $post_id, 10, 0.3 );
            } catch ( \Exception $e ) {
                // fallback: cocon_cross_interlink will still work with TF-IDF
            }
        }

        if ( empty( $similar ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "ℹ Standalone #{$post_id} : aucun article similaire trouvé — maillage via TF-IDF uniquement", 'info', 'standalone' );
            }
            return;
        }

        // ── 3. Find which cluster the closest article belongs to ──
        $cocon_data = get_option( 'hts_cocon_data', array() );
        $best_cluster = '';

        foreach ( $similar as $s ) {
            $peer_id = (int) $s['post_id'];
            $peer_cluster = $cocon_data['nodes'][ $peer_id ]['cluster'] ?? '';
            if ( ! empty( $peer_cluster ) ) {
                $best_cluster = $peer_cluster;
                break;
            }
        }

        if ( empty( $best_cluster ) ) {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "ℹ Standalone #{$post_id} : articles similaires trouvés mais aucun dans un cluster", 'info', 'standalone' );
            }
            return;
        }

        // ── 4. Assign to cluster ──
        if ( ! empty( $cocon_data['clusters'][ $best_cluster ]['pages'] ) ) {
            if ( ! in_array( $post_id, $cocon_data['clusters'][ $best_cluster ]['pages'] ) ) {
                $cocon_data['clusters'][ $best_cluster ]['pages'][] = $post_id;
            }
        }
        $cocon_data['nodes'][ $post_id ] = array(
            'id'        => $post_id,
            'title'     => $title,
            'url'       => get_permalink( $post_id ),
            'cluster'   => $best_cluster,
            'is_pillar' => false,
            'is_orphan' => false,
            'incoming'  => array(),
            'outgoing'  => array(),
            'in_links'  => 0,
            'out_links' => 0,
            'keywords'  => array( $keyword ),
        );
        update_option( 'hts_cocon_data', $cocon_data, false );
        update_post_meta( $post_id, '_hts_cocon_id', $best_cluster );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( sprintf(
                '📌 Standalone « %s » auto-assigné au cluster « %s » — maillage auto suivra',
                mb_substr( $title, 0, 40 ), mb_substr( $best_cluster, 0, 30 )
            ), 'info', 'standalone' );
        }
    }

    private function auto_assign_to_parent_cluster( $post_id, $parent_id, $title, $keyword ) {
        if ( ! class_exists( 'HTS_Cocon' ) ) return;

        $cocon_data = get_option( 'hts_cocon_data', array() );
        $parent_cluster = $cocon_data['nodes'][ $parent_id ]['cluster'] ?? '';

        if ( empty( $parent_cluster ) ) return;

        // Add to cluster
        if ( ! empty( $cocon_data['clusters'][ $parent_cluster ]['pages'] ) ) {
            if ( ! in_array( $post_id, $cocon_data['clusters'][ $parent_cluster ]['pages'] ) ) {
                $cocon_data['clusters'][ $parent_cluster ]['pages'][] = $post_id;
            }
        }

        // Add node
        $cocon_data['nodes'][ $post_id ] = array(
            'id'        => $post_id,
            'title'     => $title,
            'url'       => get_permalink( $post_id ),
            'cluster'   => $parent_cluster,
            'is_pillar' => false,
            'is_orphan' => true,
            'incoming'  => array(),
            'outgoing'  => array(),
            'in_links'  => 0,
            'out_links' => 0,
            'keywords'  => array( $keyword ),
        );
        update_option( 'hts_cocon_data', $cocon_data, false );
        update_post_meta( $post_id, '_hts_cocon_id', $parent_cluster );

        // Create linking proposals
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            // petit-fils → parent
            \HTS_Workflow_Engine::propose(
                'linking', 'add_internal_links', $post_id,
                array(
                    'reason'       => sprintf( 'Sous-article « %s » : lien vers le parent manquant', mb_substr( $title, 0, 40 ) ),
                    'source_cocon' => true,
                    'cluster'      => $parent_cluster,
                    'target_id'    => $parent_id,
                    'target_title' => get_the_title( $parent_id ),
                    'anchor_text'  => $keyword,
                    'link_type'    => 'child_to_pillar',
                    'suggestion'   => 'Ajouter un lien vers « ' . mb_substr( get_the_title( $parent_id ), 0, 50 ) . ' »',
                ),
                'high'
            );

            // parent → petit-fils
            \HTS_Workflow_Engine::propose(
                'linking', 'add_internal_links', $parent_id,
                array(
                    'reason'       => sprintf( 'Nouveau sous-article « %s » : lien depuis le parent manquant', mb_substr( $title, 0, 40 ) ),
                    'source_cocon' => true,
                    'cluster'      => $parent_cluster,
                    'target_id'    => $post_id,
                    'target_title' => $title,
                    'anchor_text'  => $keyword,
                    'link_type'    => 'pillar_to_child',
                    'suggestion'   => 'Ajouter un lien vers « ' . mb_substr( $title, 0, 50 ) . ' »',
                ),
                'high'
            );
        }

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( '📌 Sous-article « %s » assigné au cluster « %s » + 2 liens proposés',
                    mb_substr( $title, 0, 40 ), mb_substr( $parent_cluster, 0, 30 ) ),
                'info', 'standalone'
            );
        }
    }

    /* =========================================================================
     * SUGGEST SUB-TOPIC VIA AI
     * ====================================================================== */

    /**
     * AJAX: Suggest a sub-topic keyword + subject for a given parent article.
     * Uses OpenAI or Anthropic to generate a deeper angle.
     */
    public function ajax_suggest_subtopic() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        HTS_Subscription::require_tier(2);

        $parent_id = (int) ( $_POST['parent_id'] ?? 0 );
        if ( ! $parent_id || ! get_post( $parent_id ) ) {
            wp_send_json_error( 'Article parent introuvable.' );
        }

        $parent = get_post( $parent_id );
        $parent_title   = $parent->post_title;
        $parent_keyword = get_post_meta( $parent_id, '_hts_focus_keyword', true )
                       ?: get_post_meta( $parent_id, '_hts_keyword', true )
                       ?: get_post_meta( $parent_id, '_hts_api_keyword', true )
                       ?: '';

        // Get existing content excerpt for context
        $content_excerpt = '';
        if ( class_exists( 'HTS_Content_Extractor' ) ) {
            $content_excerpt = wp_strip_all_tags( \HTS_Content_Extractor::get_content( $parent_id ) );
        } else {
            $content_excerpt = wp_strip_all_tags( $parent->post_content );
        }
        $content_excerpt = mb_substr( $content_excerpt, 0, 2000 );

        // Get existing sibling articles in same cluster to avoid duplicates
        $siblings = array();
        $cocon_data = get_option( 'hts_cocon_data', array() );
        $parent_cluster = $cocon_data['nodes'][ $parent_id ]['cluster'] ?? '';
        if ( ! empty( $parent_cluster ) && ! empty( $cocon_data['clusters'][ $parent_cluster ]['pages'] ) ) {
            foreach ( $cocon_data['clusters'][ $parent_cluster ]['pages'] as $pid ) {
                if ( $pid !== $parent_id ) {
                    $siblings[] = get_the_title( $pid );
                }
            }
        }

        $siblings_text = ! empty( $siblings )
            ? "Articles déjà existants dans ce cluster (NE PAS proposer de sujets similaires) :\n- " . implode( "\n- ", array_slice( $siblings, 0, 15 ) )
            : '';

        $prompt = "Tu es un expert SEO. Analyse cet article parent et propose UN sous-article qui va en profondeur sur un aspect spécifique du sujet.\n\n"
                . "ARTICLE PARENT :\n"
                . "Titre : {$parent_title}\n"
                . "Mot-clé : {$parent_keyword}\n"
                . "Extrait du contenu :\n{$content_excerpt}\n\n"
                . ( $siblings_text ? $siblings_text . "\n\n" : '' )
                . "RÈGLES :\n"
                . "- Le sous-article doit aller PLUS EN PROFONDEUR (pas résumer le parent)\n"
                . "- Choisir un angle précis, pratique et utile pour le lecteur\n"
                . "- Le mot-clé doit être une requête longue traîne recherchée\n"
                . "- Le sujet doit être un titre d'article complet et accrocheur\n\n"
                . "Réponds UNIQUEMENT en JSON valide (sans backticks) :\n"
                . "{\"keyword\": \"mot-clé longue traîne\", \"subject\": \"Titre complet de l'article proposé\", \"why\": \"Explication en 1 phrase de pourquoi ce sous-article\"}";

        // Try OpenAI first, then Anthropic
        $openai_key    = function_exists( 'hts_get_openai_key' ) ? hts_get_openai_key() : '';
        $anthropic_key = hts_get_anthropic_key();

        $text = '';
        if ( ! empty( $openai_key ) ) {
            $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
                'timeout' => 30,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $openai_key,
                    'Content-Type'  => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'       => 'gpt-4o-mini',
                    'max_tokens'  => 300,
                    'temperature' => 0.8,
                    'messages'    => array(
                        array( 'role' => 'system', 'content' => 'Expert SEO. Réponds en JSON uniquement.' ),
                        array( 'role' => 'user', 'content' => $prompt ),
                    ),
                ) ),
            ) );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $data = json_decode( wp_remote_retrieve_body( $response ), true );
                $text = $data['choices'][0]['message']['content'] ?? '';
            }
        } elseif ( ! empty( $anthropic_key ) && strlen( $anthropic_key ) >= 20 ) {
            $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
                'timeout' => 30,
                'headers' => array(
                    'x-api-key'        => $anthropic_key,
                    'anthropic-version' => '2023-06-01',
                    'Content-Type'     => 'application/json',
                ),
                'body' => wp_json_encode( array(
                    'model'      => 'claude-haiku-4-5-20251001',
                    'max_tokens' => 300,
                    'system'     => 'Expert SEO. Réponds en JSON uniquement, sans backticks.',
                    'messages'   => array(
                        array( 'role' => 'user', 'content' => $prompt ),
                    ),
                ) ),
            ) );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $data = json_decode( wp_remote_retrieve_body( $response ), true );
                $text = $data['content'][0]['text'] ?? '';
            }
        } else {
            wp_send_json_error( 'Aucune clé API IA configurée (OpenAI ou Anthropic).' );
        }

        // Parse JSON
        $text = trim( $text );
        $text = preg_replace( '/^```json\s*/', '', $text );
        $text = preg_replace( '/\s*```$/', '', $text );
        $suggestion = json_decode( $text, true );

        if ( ! $suggestion || empty( $suggestion['keyword'] ) || empty( $suggestion['subject'] ) ) {
            wp_send_json_error( 'L\'IA n\'a pas pu générer de suggestion. Réessayez.' );
        }

        wp_send_json_success( array(
            'keyword' => sanitize_text_field( $suggestion['keyword'] ),
            'subject' => sanitize_text_field( $suggestion['subject'] ),
            'why'     => sanitize_text_field( $suggestion['why'] ?? '' ),
        ) );
    }
}
