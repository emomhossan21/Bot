<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Notifications — Weekly email digest with wins, alerts & KPIs.
 *
 * Sends a branded HTML email every Monday morning with:
 *   - Section 1: Wins & milestones (valorise l'outil)
 *   - Section 2: Preventive alerts & action items
 *   - Section 3: KPI summary (AI visits, total visits, scans, avg score)
 *   - Section 4: GSC highlights (if connected)
 *
 * @since 1.10.0
 * @updated 1.11.0 — Added wins, preventive alerts, enriched structure
 */

class HTS_Notifications {

    const CRON_HOOK   = 'hts_weekly_digest';
    const OPTION_KEY  = 'hts_module_notifications';
    const LAST_SENT   = 'hts_digest_last_sent';

    /** Click milestones for wins. */
    private static $milestones = array( 100, 500, 1000, 5000, 10000, 50000 );

    /* ══════════════════════════════════════════════════════════════
     *  INIT
     * ══════════════════════════════════════════════════════════════ */

    public function init() {
        // Schedule weekly cron (Monday 8:00 AM site time)
        add_action( self::CRON_HOOK, array( $this, 'send_digest' ) );

        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            $next_monday = strtotime( 'next monday 08:00:00' );
            wp_schedule_event( $next_monday, 'weekly', self::CRON_HOOK );
        }

        // AJAX: send test digest
        add_action( 'wp_ajax_hts_send_test_digest', array( $this, 'ajax_test_digest' ) );

        // AJAX: preview digest HTML
        add_action( 'wp_ajax_hts_preview_digest', array( $this, 'ajax_preview_digest' ) );

        // AJAX: toggle notifications
        add_action( 'wp_ajax_hts_toggle_notifications', array( $this, 'ajax_toggle' ) );
    }

    /* ══════════════════════════════════════════════════════════════
     *  GATHER DATA
     * ══════════════════════════════════════════════════════════════ */

    /**
     * Collect all data for the digest email.
     *
     * @return array Digest data with 'wins' and 'alerts' arrays.
     */
    private function gather_data() {
        global $wpdb;

        $data = array(
            'site_name' => get_bloginfo( 'name' ),
            'site_url'  => home_url(),
            'period'    => '7 derniers jours',
            'wins'      => array(),
            'alerts'    => array(),
        );

        // ── Impact Tracker data (7 days) ──
        if ( class_exists( 'HTS_Impact_Tracker' ) && get_option( 'hts_module_impact_tracker', '1' ) === '1'
             && method_exists( 'HTS_Impact_Tracker', 'get_analytics_data' ) ) {
            $tracker   = new HTS_Impact_Tracker();
            $analytics = $tracker->get_analytics_data( 7 );
            if ( ! is_array( $analytics ) ) $analytics = array();

            $data['ai_visits']    = $analytics['ai_total'];
            $data['ai_trend']     = $analytics['ai_trend'];
            $data['total_visits'] = $analytics['engagement']['total'];
            $data['avg_time']     = $analytics['engagement']['avg_time'];
            $data['avg_scroll']   = $analytics['engagement']['avg_scroll'];
            $data['bounce_rate']  = $analytics['engagement']['bounce_rate'];
            $data['crawl_total']  = $analytics['crawl']['total'];
            $data['crawl_trend']  = $analytics['crawl']['trend'];
            $data['crawl_ai']     = $analytics['crawl']['cat_totals']['ai'] ?? 0;
            $data['crawl_seo']    = $analytics['crawl']['cat_totals']['seo'] ?? 0;
            $data['stale_count']  = count( $analytics['stale_posts'] );
            $data['top_articles'] = array_slice( $analytics['top_articles'], 0, 3 );

            // ── WIN: AI crawl spike (+50%) ──
            if ( $analytics['crawl']['trend'] >= 50 ) {
                $data['wins'][] = array(
                    'title' => 'Pic de crawl IA',
                    'desc'  => 'Les robots IA ont scanné votre site ' . round( $analytics['crawl']['trend'] ) . '% de plus que la semaine précédente. Votre contenu gagne en visibilité IA !',
                );
            }

            // ── ALERT: AI crawl drop (-30%) ──
            if ( $analytics['crawl']['trend'] <= -30 && $analytics['crawl']['total'] > 0 ) {
                $data['alerts'][] = array(
                    'type'   => 'warning',
                    'title'  => 'Baisse du crawl IA',
                    'desc'   => 'Les robots IA scannent moins votre site (' . round( $analytics['crawl']['trend'] ) . '%). Vérifiez votre robots.txt et llms.txt.',
                    'action' => 'Vérifier mes réglages Robots.txt',
                    'action_url' => admin_url( 'admin.php?page=hts-api-settings&stab=seo' ),
                );
            }

            // ── ALERT: Stale content (preventive) ──
            if ( $data['stale_count'] > 0 ) {
                $severity = $data['stale_count'] > 5 ? 'warning' : 'info';
                $data['alerts'][] = array(
                    'type'   => $severity,
                    'title'  => $data['stale_count'] . ' article' . ( $data['stale_count'] > 1 ? 's' : '' ) . ' à mettre à jour',
                    'desc'   => 'Ces articles n\'ont pas été modifiés depuis plus de 12 mois. Google et les IA privilégient le contenu frais.',
                    'action' => 'Voir dans le Cockpit',
                    'action_url' => admin_url( 'admin.php?page=hts-light-dashboard' ),
                );
            }

            // ── WIN: AI traffic up ──
            if ( ( $data['ai_trend'] ?? 0 ) > 20 && ( $data['ai_visits'] ?? 0 ) > 10 ) {
                $data['wins'][] = array(
                    'title' => 'Trafic IA en hausse',
                    'desc'  => '+' . round( $data['ai_trend'] ) . '% de visites IA cette semaine. Vos optimisations portent leurs fruits !',
                );
            }
        }

        // ── Average SEO score + detection ──
        $pt_in    = function_exists( 'hts_sql_post_types_in' ) ? hts_sql_post_types_in() : "IN ('post','page')";
        $avg_score = (float) $wpdb->get_var(
            "SELECT AVG(CAST(pm.meta_value AS UNSIGNED))
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key = '_hts_seo_score' AND p.post_status = 'publish' AND p.post_type {$pt_in}"
        );
        $data['avg_score'] = round( $avg_score );

        // Score change detection: compare current avg vs stored value
        $prev_avg = (int) get_option( 'hts_digest_prev_avg_score', 0 );
        if ( $prev_avg > 0 ) {
            $diff = $data['avg_score'] - $prev_avg;

            // ── ALERT: Score drop ──
            if ( $diff <= -5 ) {
                $data['alerts'][] = array(
                    'type'   => 'error',
                    'title'  => 'Score SEO en baisse',
                    'desc'   => 'Le score moyen est passé de ' . $prev_avg . ' à ' . $data['avg_score'] . '. Vérifiez les articles récemment modifiés.',
                    'action' => 'Voir le Cockpit',
                    'action_url' => admin_url( 'admin.php?page=hts-light-dashboard' ),
                );
            }
            // ── ALERT: Score approaching danger zone (preventive) ──
            elseif ( $diff <= -3 && $data['avg_score'] < 60 ) {
                $data['alerts'][] = array(
                    'type'   => 'info',
                    'title'  => 'Score SEO à surveiller',
                    'desc'   => 'Votre score moyen descend lentement (' . $prev_avg . ' → ' . $data['avg_score'] . '). Quelques optimisations maintenant éviteront une baisse plus importante.',
                    'action' => 'Voir les articles à optimiser',
                    'action_url' => admin_url( 'admin.php?page=hts-light-dashboard' ),
                );
            }

            // ── WIN: Score up ──
            if ( $diff >= 5 ) {
                $data['wins'][] = array(
                    'title' => 'Score SEO en hausse',
                    'desc'  => 'Le score moyen est passé de ' . $prev_avg . ' à ' . $data['avg_score'] . '. Bravo, vos optimisations fonctionnent !',
                );
            }
        }
        update_option( 'hts_digest_prev_avg_score', $data['avg_score'], false );

        // ── 404 / Redirections alerts (preventive) ──
        if ( class_exists( 'HTS_Redirects' ) && get_option( 'hts_module_redirects', '1' ) === '1' ) {
            $pending_404 = HTS_Redirects::get_pending_count();
            if ( $pending_404 > 0 ) {
                $severity = $pending_404 > 10 ? 'warning' : 'info';
                $data['alerts'][] = array(
                    'type'   => $severity,
                    'title'  => $pending_404 . ' page' . ( $pending_404 > 1 ? 's' : '' ) . ' en erreur 404',
                    'desc'   => 'Des visiteurs et des moteurs de recherche tombent sur des pages introuvables. Chaque 404 est une opportunité perdue.',
                    'action' => 'Gérer les redirections',
                    'action_url' => admin_url( 'admin.php?page=hts-redirections' ),
                );
            }
            $data['pending_404'] = $pending_404;
        }

        // ── GSC data (if connected) ──
        $data['gsc'] = null;
        if ( class_exists( 'HTS_GSC_Connect' ) && get_option( 'hts_module_gsc', '1' ) === '1' ) {
            $gsc = new HTS_GSC_Connect();
            if ( $gsc->is_connected() && $gsc->has_data() ) {
                $gsc_7  = $gsc->get_site_data( 7 );
                $gsc_30 = $gsc->get_site_data( 30 );
                $data['gsc'] = array(
                    'clicks'      => $gsc_7['clicks'],
                    'impressions' => $gsc_7['impressions'],
                    'position'    => $gsc_7['avg_position'],
                    'ctr'         => $gsc_7['avg_ctr'],
                    'trend'       => $gsc_7['clicks_trend'],
                    'top_pages'   => array_slice( $gsc_7['top_pages'] ?? array(), 0, 3 ),
                );

                // ── WIN: GSC clicks milestone ──
                $total_clicks_30d = (int) ( $gsc_30['clicks'] ?? 0 );
                $prev_milestone   = (int) get_option( 'hts_digest_gsc_milestone', 0 );
                foreach ( self::$milestones as $m ) {
                    if ( $total_clicks_30d >= $m && $prev_milestone < $m ) {
                        $data['wins'][] = array(
                            'title' => number_format_i18n( $m ) . ' clics Google atteints !',
                            'desc'  => 'Votre site a franchi le cap des ' . number_format_i18n( $m ) . ' clics sur les 30 derniers jours dans la recherche Google. Félicitations !',
                        );
                        update_option( 'hts_digest_gsc_milestone', $m, false );
                        break;
                    }
                }

                // ── WIN: GSC clicks trend up ──
                if ( $gsc_7['clicks_trend'] > 20 && $gsc_7['clicks'] > 10 ) {
                    $data['wins'][] = array(
                        'title' => 'Clics Google en hausse',
                        'desc'  => '+' . round( $gsc_7['clicks_trend'] ) . '% de clics Google cette semaine. Votre visibilité progresse !',
                    );
                }

                // ── WIN: Page enters top 10 ──
                $top_pages      = $gsc_7['top_pages'] ?? array();
                $prev_positions = get_option( 'hts_digest_gsc_positions', array() );
                $new_positions  = array();
                foreach ( $top_pages as $tp ) {
                    $url_key = md5( $tp['url'] );
                    $new_positions[ $url_key ] = $tp['position'];
                    if ( $tp['position'] <= 10.0 && $tp['position'] > 0 ) {
                        if ( isset( $prev_positions[ $url_key ] ) && $prev_positions[ $url_key ] > 10 ) {
                            $title = ! empty( $tp['title'] ) ? $tp['title'] : basename( untrailingslashit( $tp['url'] ) );
                            $data['wins'][] = array(
                                'title' => 'Nouvelle page en top 10 !',
                                'desc'  => '"' . mb_strimwidth( $title, 0, 50, '…' ) . '" est maintenant en position ' . $tp['position'] . ' sur Google.',
                            );
                        }
                    }
                }
                update_option( 'hts_digest_gsc_positions', $new_positions, false );

                // ── ALERT: Declining pages (preventive) ──
                $declining = $gsc->get_declining_pages( 3.0 );
                if ( ! empty( $declining ) ) {
                    $count = count( $declining );
                    $worst = $declining[0];
                    $data['alerts'][] = array(
                        'type'   => 'warning',
                        'title'  => $count . ' page' . ( $count > 1 ? 's' : '' ) . ' en perte de position',
                        'desc'   => 'La plus touchée : "' . mb_strimwidth( $worst['title'], 0, 40, '…' ) . '" a perdu ' . $worst['drop'] . ' positions. Agissez avant que la baisse ne s\'accélère.',
                        'action' => 'Voir dans le Cockpit',
                        'action_url' => admin_url( 'admin.php?page=hts-light-dashboard' ),
                    );
                }

                // ── ALERT: Low CTR on high impression pages ──
                foreach ( $top_pages as $tp ) {
                    if ( ( $tp['impressions'] ?? 0 ) > 100 && ( $tp['ctr'] ?? 0 ) < 1.0 && ( $tp['position'] ?? 50 ) <= 20 ) {
                        $title = ! empty( $tp['title'] ) ? $tp['title'] : basename( untrailingslashit( $tp['url'] ) );
                        $data['alerts'][] = array(
                            'type'   => 'info',
                            'title'  => 'CTR faible sur une page visible',
                            'desc'   => '"' . mb_strimwidth( $title, 0, 40, '…' ) . '" a ' . (int) $tp['impressions'] . ' impressions mais seulement ' . $tp['ctr'] . '% de clics. Le titre et la méta description pourraient être améliorés.',
                            'action' => 'Optimiser les balises SEO',
                            'action_url' => admin_url( 'admin.php?page=hts-light-dashboard' ),
                        );
                        break; // Only show the worst one
                    }
                }
            }
        }

        // ── Sprint 4.6: Inbox / Workflow Engine data ──
        $data['inbox'] = null;
        if ( class_exists( 'HTS_Workflow_Engine' ) && HTS_Workflow_Engine::tables_exist() ) {
            global $wpdb;
            $wf_table = $wpdb->prefix . 'hts_workflow_actions';

            $wf_stats = HTS_Workflow_Engine::get_stats();
            $pending   = (int) ( $wf_stats['pending'] ?? 0 );
            $done_7d   = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wf_table} WHERE status = 'done' AND resolved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
            );
            $failed_7d = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wf_table} WHERE status IN ('failed','blocked') AND resolved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
            );

            // Top agents this week
            $top_agents = $wpdb->get_results(
                "SELECT agent, COUNT(*) as cnt FROM {$wf_table}
                 WHERE status = 'done' AND resolved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                 GROUP BY agent ORDER BY cnt DESC LIMIT 3"
            );
            $agent_labels = HTS_Workflow_Engine::get_agent_labels();
            $top_agents_list = array();
            foreach ( $top_agents as $ta ) {
                $top_agents_list[] = array(
                    'agent' => $ta->agent,
                    'label' => $agent_labels[ $ta->agent ] ?? ucfirst( $ta->agent ),
                    'count' => (int) $ta->cnt,
                );
            }

            $data['inbox'] = array(
                'pending'    => $pending,
                'done_7d'    => $done_7d,
                'failed_7d'  => $failed_7d,
                'top_agents' => $top_agents_list,
            );

            // ── WIN: Actions applied this week ──
            if ( $done_7d >= 5 ) {
                $data['wins'][] = array(
                    'title' => $done_7d . ' optimisations appliquées',
                    'desc'  => $done_7d . ' actions SEO ont été exécutées cette semaine. Votre site progresse activement !',
                );
            }

            // ── ALERT: Pending actions piling up ──
            if ( $pending >= 20 ) {
                $data['alerts'][] = array(
                    'type'       => 'info',
                    'title'      => $pending . ' propositions en attente',
                    'desc'       => 'Votre Inbox contient ' . $pending . ' optimisations à valider. Prenez 5 minutes pour les traiter.',
                    'action'     => 'Ouvrir l\'Inbox',
                    'action_url' => admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ),
                );
            }

            // ── ALERT: Failed actions ──
            if ( $failed_7d > 0 ) {
                $data['alerts'][] = array(
                    'type'       => 'warning',
                    'title'      => $failed_7d . ' action' . ( $failed_7d > 1 ? 's' : '' ) . ' en échec',
                    'desc'       => 'Certaines optimisations automatiques ont échoué. Vérifiez l\'historique dans l\'Inbox.',
                    'action'     => 'Voir l\'historique',
                    'action_url' => admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' ),
                );
            }
        }

        // ── Sprint 4.6: Global Score + GEO ──
        $data['global_score_avg'] = null;
        $data['geo_score_avg']    = null;
        if ( class_exists( 'HTS_Global_Score' ) ) {
            $gs_avg = (float) $wpdb->get_var(
                "SELECT AVG(CAST(pm.meta_value AS DECIMAL(5,1)))
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE pm.meta_key = '_hts_global_score' AND p.post_status = 'publish' AND p.post_type IN ('post','page')
                 AND pm.meta_value > 0"
            );
            $data['global_score_avg'] = round( $gs_avg, 1 );

            // Delta vs last digest
            $prev_global = (float) get_option( 'hts_digest_prev_global_score', 0 );
            $data['global_score_delta'] = $prev_global > 0 ? round( $gs_avg - $prev_global, 1 ) : 0;
            update_option( 'hts_digest_prev_global_score', $gs_avg, false );

            // WIN: Global score improved
            if ( $data['global_score_delta'] >= 3 ) {
                $data['wins'][] = array(
                    'title' => 'Score SEO global en hausse',
                    'desc'  => 'Le score moyen est passé de ' . $prev_global . ' à ' . $data['global_score_avg'] . '/100. Les optimisations portent leurs fruits !',
                );
            }
        }

        // GEO score
        $geo_avg = (float) $wpdb->get_var(
            "SELECT AVG(CAST(pm.meta_value AS DECIMAL(5,1)))
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key = '_hts_geo_score' AND p.post_status = 'publish' AND p.post_type IN ('post','page')
             AND pm.meta_value > 0"
        );
        if ( $geo_avg > 0 ) {
            $data['geo_score_avg'] = round( $geo_avg, 1 );

            $prev_geo = (float) get_option( 'hts_digest_prev_geo_score', 0 );
            $data['geo_score_delta'] = $prev_geo > 0 ? round( $geo_avg - $prev_geo, 1 ) : 0;
            update_option( 'hts_digest_prev_geo_score', $geo_avg, false );
        }

        // ── Sprint 4.6: Coach activity ──
        $data['coach_sessions_7d'] = 0;
        if ( class_exists( 'HTS_Coach' ) ) {
            $coach_table = $wpdb->prefix . 'hts_coach_sessions';
            $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $coach_table ) );
            if ( $table_exists ) {
                $data['coach_sessions_7d'] = (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$coach_table} WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
                );
            }
        }

        // ── Sprint 4.6: Worst 3 pages (lowest global score) ──
        $data['worst_pages'] = array();
        $worst_rows = $wpdb->get_results(
            "SELECT pm.post_id, pm.meta_value as score, p.post_title
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key = '_hts_global_score' AND p.post_status = 'publish'
             AND p.post_type IN ('post','page') AND CAST(pm.meta_value AS UNSIGNED) > 0
             ORDER BY CAST(pm.meta_value AS UNSIGNED) ASC LIMIT 3"
        );
        foreach ( $worst_rows as $wr ) {
            $data['worst_pages'][] = array(
                'id'    => (int) $wr->post_id,
                'title' => $wr->post_title,
                'score' => (int) $wr->score,
                'url'   => get_permalink( (int) $wr->post_id ),
            );
        }

        return $data;
    }

    /* ══════════════════════════════════════════════════════════════
     *  BUILD EMAIL HTML
     * ══════════════════════════════════════════════════════════════ */

    private function build_email( $data ) {
        // ── DS v5.7 brand colors (hardcoded for email HTML — mirrors hts-ds-tokens.css) ──
        $accent = '#2D7FF9';
        $geo    = '#6366F1';
        $bg     = '#F9FAFB';
        $card   = '#FFFFFF';
        $text   = '#111827';
        $muted  = '#9CA3AF';
        $text2  = '#6B7280';
        $green  = '#00D26A';
        $red    = '#FF4D6A';
        $orange = '#FF9500';
        $info   = '#00C2FF';
        $border = '#E5E7EB';
        $hero1  = '#1D1D1F';
        $hero2  = '#2D2D30';

        $dash_url    = admin_url( 'admin.php?page=hts-light-dashboard' );
        $inbox_url   = admin_url( 'admin.php?page=hts-light-dashboard&tab=inbox' );
        $settings_url = admin_url( 'admin.php?page=hts-seo-settings&stab=notifications' );

        ob_start();
        ?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:<?php echo $bg; ?>;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:<?php echo $bg; ?>;padding:24px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

<!-- Header — dark brand hero (DS v5.7 gradient) -->
<tr><td style="background:linear-gradient(135deg,<?php echo $hero1; ?> 0%,<?php echo $hero2; ?> 60%,<?php echo $hero1; ?> 100%);padding:28px 32px;border-radius:14px 14px 0 0;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
        <td>
            <p style="margin:0;font-size:11px;font-weight:600;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:1px;">Rapport <?php echo esc_html( ucfirst( $data['frequency_label'] ?? 'hebdomadaire' ) ); ?></p>
            <h1 style="margin:6px 0 0;font-size:24px;font-weight:700;color:#fff;line-height:1.3;"><?php echo esc_html( $data['site_name'] ); ?></h1>
            <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,.5);"><?php echo esc_html( $data['period'] ); ?></p>
        </td>
        <td width="60" style="text-align:right;vertical-align:top;">
            <div style="width:48px;height:48px;border-radius:12px;background:<?php echo $accent; ?>;display:inline-block;text-align:center;line-height:48px;">
                <span style="font-size:20px;font-weight:800;color:#fff;">H</span>
            </div>
        </td>
    </tr></table>
</td></tr>

<!-- ═══ SECTION 1: WINS ═══ -->
<?php if ( ! empty( $data['wins'] ) ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:24px 32px 12px;border-bottom:1px solid <?php echo $border; ?>;">
    <p style="margin:0 0 14px;font-size:11px;font-weight:700;color:<?php echo $green; ?>;text-transform:uppercase;letter-spacing:0.5px;">Vos succ&egrave;s cette semaine</p>
    <?php foreach ( $data['wins'] as $win ) : ?>
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:10px;"><tr>
        <td width="4" style="background:<?php echo $green; ?>;border-radius:3px;"></td>
        <td style="padding:12px 16px;">
            <p style="margin:0;font-size:14px;font-weight:600;color:<?php echo $text; ?>;"><?php echo esc_html( $win['title'] ); ?></p>
            <p style="margin:4px 0 0;font-size:12px;color:<?php echo $muted; ?>;line-height:1.5;"><?php echo esc_html( $win['desc'] ); ?></p>
        </td>
    </tr></table>
    <?php endforeach; ?>
</td></tr>
<?php endif; ?>

<!-- ═══ SECTION 2: ALERTS ═══ -->
<?php if ( ! empty( $data['alerts'] ) ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:24px 32px 12px;border-bottom:1px solid <?php echo $border; ?>;">
    <p style="margin:0 0 14px;font-size:11px;font-weight:700;color:<?php echo $text; ?>;text-transform:uppercase;letter-spacing:0.5px;">Points d'attention</p>
    <?php foreach ( $data['alerts'] as $alert ) :
        $abc = isset( $alert['type'] ) && $alert['type'] === 'error' ? $red : ( isset( $alert['type'] ) && $alert['type'] === 'warning' ? $orange : $accent );
    ?>
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:10px;"><tr>
        <td width="4" style="background:<?php echo $abc; ?>;border-radius:3px;"></td>
        <td style="padding:12px 16px;">
            <p style="margin:0;font-size:14px;font-weight:600;color:<?php echo $text; ?>;"><?php echo esc_html( $alert['title'] ); ?></p>
            <p style="margin:4px 0 0;font-size:12px;color:<?php echo $muted; ?>;line-height:1.5;"><?php echo esc_html( $alert['desc'] ); ?></p>
            <?php if ( ! empty( $alert['action_url'] ) ) : ?>
            <p style="margin:8px 0 0;"><a href="<?php echo esc_url( $alert['action_url'] ); ?>" style="font-size:12px;font-weight:600;color:<?php echo $accent; ?>;text-decoration:none;"><?php echo esc_html( $alert['action'] ?? 'Voir' ); ?> &rarr;</a></p>
            <?php endif; ?>
        </td>
    </tr></table>
    <?php endforeach; ?>
</td></tr>
<?php endif; ?>

<!-- ═══ SECTION 3: KPIs ═══ -->
<?php if ( empty( $data['hide_kpis'] ) ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:24px 32px;border-bottom:1px solid <?php echo $border; ?>;">
    <p style="margin:0 0 16px;font-size:11px;font-weight:700;color:<?php echo $text; ?>;text-transform:uppercase;letter-spacing:0.5px;">R&eacute;sum&eacute; de la semaine</p>
    <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td width="32%" style="padding:12px 8px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <div style="font-size:28px;font-weight:800;color:<?php echo $geo; ?>;letter-spacing:-1px;"><?php echo (int) ( $data['ai_visits'] ?? 0 ); ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">Visites IA <?php echo $this->fmt_trend( $data['ai_trend'] ?? 0 ); ?></div>
        </td>
        <td width="2%"></td>
        <td width="32%" style="padding:12px 8px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <div style="font-size:28px;font-weight:800;color:<?php echo $text; ?>;letter-spacing:-1px;"><?php echo (int) ( $data['total_visits'] ?? 0 ); ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">Visites totales</div>
        </td>
        <td width="2%"></td>
        <td width="32%" style="padding:12px 8px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <?php $sc = ( $data['avg_score'] ?? 0 ) >= 70 ? $green : ( ( $data['avg_score'] ?? 0 ) >= 50 ? $orange : $red ); ?>
            <div style="font-size:28px;font-weight:800;color:<?php echo $sc; ?>;letter-spacing:-1px;"><?php echo (int) ( $data['avg_score'] ?? 0 ); ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">Score SEO</div>
        </td>
    </tr>
    </table>
</td></tr>
<?php endif; ?>

<!-- ═══ SECTION 3b: INBOX ═══ -->
<?php if ( ! empty( $data['inbox'] ) ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:24px 32px;border-bottom:1px solid <?php echo $border; ?>;">
    <p style="margin:0 0 16px;font-size:11px;font-weight:700;color:<?php echo $text; ?>;text-transform:uppercase;letter-spacing:0.5px;">Activit&eacute; des agents</p>
    <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td width="32%" style="padding:12px 8px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <div style="font-size:28px;font-weight:800;color:<?php echo $green; ?>;letter-spacing:-1px;"><?php echo (int) $data['inbox']['done_7d']; ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">Appliqu&eacute;es</div>
        </td>
        <td width="2%"></td>
        <td width="32%" style="padding:12px 8px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <div style="font-size:28px;font-weight:800;color:<?php echo $accent; ?>;letter-spacing:-1px;"><?php echo (int) $data['inbox']['pending']; ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">En attente</div>
        </td>
        <td width="2%"></td>
        <td width="32%" style="padding:12px 8px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <?php $fc = $data['inbox']['failed_7d'] > 0 ? $red : $green; ?>
            <div style="font-size:28px;font-weight:800;color:<?php echo $fc; ?>;letter-spacing:-1px;"><?php echo (int) $data['inbox']['failed_7d']; ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">&Eacute;chou&eacute;es</div>
        </td>
    </tr>
    </table>
    <?php if ( $data['inbox']['pending'] > 0 ) : ?>
    <p style="margin:16px 0 0;text-align:center;">
        <a href="<?php echo esc_url( $inbox_url ); ?>" style="display:inline-block;padding:10px 24px;background:<?php echo $accent; ?>;color:#fff;text-decoration:none;border-radius:8px;font-size:13px;font-weight:600;"><?php echo (int) $data['inbox']['pending']; ?> proposition<?php echo $data['inbox']['pending'] > 1 ? 's' : ''; ?> &agrave; traiter</a>
    </p>
    <?php endif; ?>
</td></tr>
<?php endif; ?>

<!-- ═══ SECTION 3b-bis: TOP AGENTS + COACH ═══ -->
<?php if ( ! empty( $data['inbox']['top_agents'] ) || ( $data['coach_sessions_7d'] ?? 0 ) > 0 ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:20px 32px;border-bottom:1px solid <?php echo $border; ?>;">
    <?php if ( ! empty( $data['inbox']['top_agents'] ) ) : ?>
    <p style="margin:0 0 10px;font-size:11px;font-weight:700;color:<?php echo $text2; ?>;text-transform:uppercase;letter-spacing:0.5px;">Agents les plus actifs</p>
    <?php foreach ( $data['inbox']['top_agents'] as $ta ) : ?>
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:4px;"><tr>
        <td style="padding:5px 0;font-size:13px;color:<?php echo $text; ?>;"><?php echo esc_html( $ta['label'] ); ?></td>
        <td style="padding:5px 0;font-size:13px;text-align:right;"><strong style="color:<?php echo $accent; ?>;"><?php echo (int) $ta['count']; ?> action<?php echo $ta['count'] > 1 ? 's' : ''; ?></strong></td>
    </tr></table>
    <?php endforeach; ?>
    <?php endif; ?>
    <?php if ( ( $data['coach_sessions_7d'] ?? 0 ) > 0 ) : ?>
    <p style="margin:<?php echo ! empty( $data['inbox']['top_agents'] ) ? '14px' : '0'; ?> 0 0;font-size:12px;color:<?php echo $text2; ?>;">
        Coach SEO : <strong style="color:<?php echo $accent; ?>;"><?php echo (int) $data['coach_sessions_7d']; ?></strong> session<?php echo $data['coach_sessions_7d'] > 1 ? 's' : ''; ?> cette semaine
    </p>
    <?php endif; ?>
</td></tr>
<?php endif; ?>

<!-- ═══ SECTION 3c: SCORES SEO + GEO ═══ -->
<?php if ( isset( $data['global_score_avg'] ) && $data['global_score_avg'] !== null ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:24px 32px;border-bottom:1px solid <?php echo $border; ?>;">
    <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td width="48%" style="padding:14px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <?php $gsc2 = $data['global_score_avg'] >= 70 ? $green : ( $data['global_score_avg'] >= 50 ? $orange : $red ); ?>
            <div style="font-size:32px;font-weight:800;color:<?php echo $gsc2; ?>;letter-spacing:-1px;"><?php echo $data['global_score_avg']; ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">Score SEO global <?php if ( $data['global_score_delta'] != 0 ) echo $this->fmt_trend( $data['global_score_delta'] ); ?></div>
        </td>
        <td width="4%"></td>
        <td width="48%" style="padding:14px;text-align:center;background:<?php echo $bg; ?>;border-radius:10px;">
            <?php if ( isset( $data['geo_score_avg'] ) && $data['geo_score_avg'] !== null ) :
                $gc2 = $data['geo_score_avg'] >= 60 ? $green : ( $data['geo_score_avg'] >= 40 ? $orange : $red );
            ?>
            <div style="font-size:32px;font-weight:800;color:<?php echo $gc2; ?>;letter-spacing:-1px;"><?php echo $data['geo_score_avg']; ?></div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;margin-top:4px;">Score GEO (IA) <?php if ( ( $data['geo_score_delta'] ?? 0 ) != 0 ) echo $this->fmt_trend( $data['geo_score_delta'] ); ?></div>
            <?php else : ?>
            <div style="font-size:20px;font-weight:700;color:<?php echo $muted; ?>;padding:8px 0;">&mdash;</div>
            <div style="font-size:11px;color:<?php echo $muted; ?>;">Score GEO non calcul&eacute;</div>
            <?php endif; ?>
        </td>
    </tr>
    </table>
</td></tr>
<?php endif; ?>

<!-- ═══ SECTION 4: GSC ═══ -->
<?php if ( ! empty( $data['gsc'] ) ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:24px 32px;border-bottom:1px solid <?php echo $border; ?>;">
    <p style="margin:0 0 16px;font-size:11px;font-weight:700;color:<?php echo $text; ?>;text-transform:uppercase;letter-spacing:0.5px;">Visibilit&eacute; Google</p>
    <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td width="24%" style="padding:10px 4px;text-align:center;background:<?php echo $bg; ?>;border-radius:8px;">
            <div style="font-size:22px;font-weight:800;color:<?php echo $accent; ?>;"><?php echo (int) $data['gsc']['clicks']; ?></div>
            <div style="font-size:10px;color:<?php echo $muted; ?>;">Clics organiques <?php echo $this->fmt_trend( $data['gsc']['trend'] ); ?></div>
        </td>
        <td width="1%"></td>
        <td width="24%" style="padding:10px 4px;text-align:center;background:<?php echo $bg; ?>;border-radius:8px;">
            <div style="font-size:22px;font-weight:800;color:<?php echo $text; ?>;"><?php echo (int) $data['gsc']['impressions']; ?></div>
            <div style="font-size:10px;color:<?php echo $muted; ?>;">Apparitions Google</div>
        </td>
        <td width="1%"></td>
        <td width="24%" style="padding:10px 4px;text-align:center;background:<?php echo $bg; ?>;border-radius:8px;">
            <?php $pc = $data['gsc']['position'] <= 10 ? $green : ( $data['gsc']['position'] <= 20 ? $orange : $red ); ?>
            <div style="font-size:22px;font-weight:800;color:<?php echo $pc; ?>;"><?php echo esc_html( $data['gsc']['position'] ); ?></div>
            <div style="font-size:10px;color:<?php echo $muted; ?>;">Position moyenne</div>
        </td>
        <td width="1%"></td>
        <td width="24%" style="padding:10px 4px;text-align:center;background:<?php echo $bg; ?>;border-radius:8px;">
            <div style="font-size:22px;font-weight:800;color:<?php echo $text; ?>;"><?php echo esc_html( $data['gsc']['ctr'] ); ?>%</div>
            <div style="font-size:10px;color:<?php echo $muted; ?>;">Taux de clic</div>
        </td>
    </tr>
    </table>
</td></tr>
<?php endif; ?>

<!-- ═══ WORST PAGES ═══ -->
<?php if ( ! empty( $data['worst_pages'] ) ) : ?>
<tr><td style="background:<?php echo $card; ?>;padding:20px 32px;border-bottom:1px solid <?php echo $border; ?>;">
    <p style="margin:0 0 10px;font-size:11px;font-weight:700;color:<?php echo $muted; ?>;text-transform:uppercase;letter-spacing:0.5px;">Pages &agrave; am&eacute;liorer</p>
    <?php foreach ( $data['worst_pages'] as $i => $wp_item ) :
        $wsc = $wp_item['score'] >= 60 ? $orange : $red;
    ?>
    <p style="margin:0;padding:6px 0;font-size:12px;color:<?php echo $text; ?>;<?php echo $i > 0 ? 'border-top:1px solid ' . $border . ';' : ''; ?>">
        <strong style="color:<?php echo $wsc; ?>;font-size:13px;"><?php echo (int) $wp_item['score']; ?></strong>
        <span style="color:<?php echo $muted; ?>;margin:0 4px;">/100</span>
        <?php echo esc_html( mb_strimwidth( $wp_item['title'], 0, 45, '...' ) ); ?>
    </p>
    <?php endforeach; ?>
</td></tr>
<?php endif; ?>

<!-- ═══ SUMMARY BADGE ═══ -->
<tr><td style="background:<?php echo $card; ?>;padding:20px 32px;">
    <?php
    $win_count   = count( $data['wins'] );
    $alert_count = count( $data['alerts'] );
    if ( $win_count > 0 && $alert_count === 0 ) {
        $badge_text = 'Tout va bien. ' . $win_count . ' bonne' . ( $win_count > 1 ? 's' : '' ) . ' nouvelle' . ( $win_count > 1 ? 's' : '' ) . ' cette semaine.';
        $badge_bg   = '#D5FFE8'; $badge_c = $green;
    } elseif ( $win_count > 0 && $alert_count > 0 ) {
        $badge_text = $win_count . " succ\xC3\xA8s et " . $alert_count . ' point' . ( $alert_count > 1 ? 's' : '' ) . " d\x27attention cette semaine.";
        $badge_bg   = '#EBF3FF'; $badge_c = $accent;
    } elseif ( $alert_count > 0 ) {
        $badge_text = $alert_count . ' point' . ( $alert_count > 1 ? 's' : '' ) . " d\x27attention \xC3\xA0 traiter.";
        $badge_bg   = '#FFF4CC'; $badge_c = $orange;
    } else {
        $badge_text = 'Votre site est sur la bonne voie.';
        $badge_bg   = $bg; $badge_c = $muted;
    }
    ?>
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
        <td style="background:<?php echo $badge_bg; ?>;border-radius:10px;padding:14px 18px;text-align:center;">
            <p style="margin:0;font-size:13px;font-weight:600;color:<?php echo $badge_c; ?>;"><?php echo esc_html( $badge_text ); ?></p>
        </td>
    </tr></table>
</td></tr>

<!-- ═══ CTA ═══ -->
<tr><td style="background:<?php echo $card; ?>;padding:12px 32px 28px;text-align:center;border-radius:0 0 14px 14px;">
    <a href="<?php echo esc_url( $dash_url ); ?>" style="display:inline-block;padding:12px 32px;background:<?php echo $accent; ?>;color:#fff;text-decoration:none;border-radius:10px;font-size:14px;font-weight:700;">Ouvrir le tableau de bord</a>
</td></tr>

<!-- ═══ FOOTER ═══ -->
<tr><td style="padding:20px 32px;text-align:center;">
    <p style="margin:0;font-size:11px;color:<?php echo $muted; ?>;line-height:1.6;">
        Envoy&eacute; par <strong style="color:<?php echo $text; ?>;">Hack The SEO</strong><br>
        <a href="<?php echo esc_url( $settings_url ); ?>" style="color:<?php echo $accent; ?>;text-decoration:none;">G&eacute;rer les notifications</a>
    </p>
</td></tr>

</table>
</td></tr>
</table>
</body>
</html>
        <?php
        return ob_get_clean();
    }

    /* ══════════════════════════════════════════════════════════════
     *  SEND DIGEST
     * ══════════════════════════════════════════════════════════════ */

    public function send_digest() {
        // Check if enabled
        if ( get_option( self::OPTION_KEY, '1' ) !== '1' ) return;

        // Respect configured frequency
        $settings  = get_option( 'hts_notif_settings', array() );
        $frequency = $settings['frequency'] ?? 'weekly';
        $last      = get_option( self::LAST_SENT, 0 );

        $min_interval = DAY_IN_SECONDS * 6; // default weekly
        if ( $frequency === 'biweekly' ) {
            $min_interval = DAY_IN_SECONDS * 13;
        } elseif ( $frequency === 'monthly' ) {
            $min_interval = DAY_IN_SECONDS * 27;
        }

        if ( $last && ( time() - $last ) < $min_interval ) return;

        $data  = $this->gather_data();
        $data  = $this->filter_sections( $data );
        $html  = $this->build_email( $data );
        $email = get_option( 'hts_notif_email', '' );
        if ( ! $email ) {
            $email = get_option( 'admin_email' );
        }

        if ( ! $email ) return;

        $subject = $this->build_subject( $data );

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Hack The SEO <noreply@' . wp_parse_url( home_url(), PHP_URL_HOST ) . '>',
        );

        $sent = wp_mail( $email, $subject, $html, $headers );

        if ( $sent ) {
            update_option( self::LAST_SENT, time(), false );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Digest hebdo envoyé à ' . $email . ' (' . count( $data['wins'] ) . ' wins, ' . count( $data['alerts'] ) . ' alertes)', 'success', 'notifications' );
            }
        } else {
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Échec envoi digest à ' . $email, 'error', 'notifications' );
            }
        }

        return $sent;
    }

    /**
     * Build a smart subject line based on content.
     */
    private function build_subject( $data ) {
        $wins   = count( $data['wins'] );
        $alerts = count( $data['alerts'] );
        $name   = $data['site_name'];

        if ( $wins > 0 && $alerts === 0 ) {
            return $name . ' — ' . $wins . ' bonne' . ( $wins > 1 ? 's' : '' ) . ' nouvelle' . ( $wins > 1 ? 's' : '' ) . ' SEO';
        }
        if ( $wins > 0 && $alerts > 0 ) {
            return $name . ' — ' . $wins . ' succ' . "\xC3\xA8" . 's, ' . $alerts . ' alerte' . ( $alerts > 1 ? 's' : '' );
        }
        if ( $alerts > 0 ) {
            return $name . ' — ' . $alerts . ' point' . ( $alerts > 1 ? 's' : '' ) . ' d\'attention SEO';
        }
        return $name . ' — Rapport SEO hebdomadaire';
    }

    /* ══════════════════════════════════════════════════════════════
     *  AJAX
     * ══════════════════════════════════════════════════════════════ */

    public function ajax_test_digest() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        $email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';

        try {
            $sent = $this->send_digest_now( $email );
            wp_send_json_success( array( 'sent' => $sent, 'email' => $email ) );
        } catch ( \Throwable $e ) {
            wp_send_json_error( array( 'message' => 'Erreur : ' . $e->getMessage() ) );
        }
    }

    /**
     * Force send now (ignores throttle). Accepts optional custom email.
     *
     * @param string $to_email Optional override email. Falls back to saved notif email, then admin_email.
     */
    public function send_digest_now( $to_email = '' ) {
        $data  = $this->gather_data();
        $data  = $this->filter_sections( $data );
        $html  = $this->build_email( $data );

        if ( $to_email && is_email( $to_email ) ) {
            $email = $to_email;
        } else {
            $email = get_option( 'hts_notif_email', '' );
            if ( ! $email ) {
                $email = get_option( 'admin_email' );
            }
        }

        if ( ! $email ) return false;

        $subject = $this->build_subject( $data ) . ' (test)';
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Hack The SEO <noreply@' . wp_parse_url( home_url(), PHP_URL_HOST ) . '>',
        );

        return wp_mail( $email, $subject, $html, $headers );
    }

    public function ajax_toggle() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        $enabled = isset( $_POST['enabled'] ) ? sanitize_text_field( $_POST['enabled'] ) : '1';
        update_option( self::OPTION_KEY, $enabled );
        wp_send_json_success( array( 'enabled' => $enabled ) );
    }

    /**
     * Preview digest HTML (no email sent).
     */
    public function ajax_preview_digest() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden' );

        try {
            $data = $this->gather_data();
            $data = $this->filter_sections( $data );
            $html = $this->build_email( $data );

            wp_send_json_success( array(
                'html'   => $html,
                'wins'   => count( $data['wins'] ),
                'alerts' => count( $data['alerts'] ),
            ) );
        } catch ( \Throwable $e ) {
            wp_send_json_error( array( 'message' => 'Erreur lors de la génération : ' . $e->getMessage() ) );
        }
    }

    /**
     * Filter data based on user section preferences.
     */
    private function filter_sections( $data ) {
        $settings = get_option( 'hts_notif_settings', array() );
        $sections = $settings['sections'] ?? array( 'wins' => '1', 'alerts' => '1', 'kpis' => '1', 'gsc' => '1', 'inbox' => '1', 'scores' => '1' );

        if ( ( $sections['wins'] ?? '1' ) !== '1' ) {
            $data['wins'] = array();
        }
        if ( ( $sections['alerts'] ?? '1' ) !== '1' ) {
            $data['alerts'] = array();
        }
        if ( ( $sections['gsc'] ?? '1' ) !== '1' ) {
            $data['gsc'] = null;
        }
        // KPIs: if disabled, zero out the display values (keeps gather working for alerts)
        if ( ( $sections['kpis'] ?? '1' ) !== '1' ) {
            $data['hide_kpis'] = true;
        }
        // Sprint 4.6: Inbox section
        if ( ( $sections['inbox'] ?? '1' ) !== '1' ) {
            $data['inbox'] = null;
        }
        // Sprint 4.6: Scores section
        if ( ( $sections['scores'] ?? '1' ) !== '1' ) {
            $data['global_score_avg'] = null;
            $data['worst_pages'] = array();
        }

        return $data;
    }

    /* ══════════════════════════════════════════════════════════════
     *  HELPERS
     * ══════════════════════════════════════════════════════════════ */

    private function fmt_trend( $pct ) {
        if ( $pct > 0 ) return '<span style="color:#00D26A;font-weight:600;">+' . (int) $pct . '%</span>';
        if ( $pct < 0 ) return '<span style="color:#FF4D6A;font-weight:600;">' . (int) $pct . '%</span>';
        return '';
    }

    /**
     * Format seconds as human-readable time.
     * Local copy to avoid dependency on analytics.php which is only loaded on the Analytics page.
     */
    private function fmt_time( $s ) {
        $s = (int) $s;
        if ( $s < 60 ) return $s . 's';
        $m = floor( $s / 60 );
        $sec = $s % 60;
        return $m . 'min' . ( $sec > 0 ? ' ' . $sec . 's' : '' );
    }
}
