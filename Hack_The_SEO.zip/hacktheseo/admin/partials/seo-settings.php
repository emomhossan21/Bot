<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * SEO Settings page — Hack The SEO Admin (DS v5.7 reskin)
 *
 * Variables passées par render_seo_settings() :
 * $settings — array with all HTS SEO settings
 * $competitor — detected competitor slug or empty
 * $competitor_settings — auto-imported values from RM/Yoast/AIOSEO/SEOPress
 *
 * @since 3.3.1
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'HTS_DS' ) && file_exists( HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php' ) ) {
	require_once HTS__PLUGIN_DIR . 'modules/class-hts-design-system.php';
}
?>

<?php if ( empty( $hts_embedded_seo ) ) : ?>
<?php echo HTS_DS::page_open( true ); ?>

<?php echo HTS_DS::hero(
	'Réglages SEO',
	'Personnalisez comment votre site apparaît sur Google et les réseaux sociaux',
	'<div style="display:flex;gap:10px;margin-top:14px">'
	. HTS_DS::button( 'Enregistrer', 'default', 'sm', array(
		'type' => 'button',
		'id'   => 'hts-seo-save-top',
		'onclick' => "document.getElementById('hts-seo-settings-form').requestSubmit();",
		'style' => 'border-color:rgba(255,255,255,.15);background:rgba(255,255,255,.08);color:#fff',
	) )
	. '</div>'
); ?>
<?php endif; ?>

<div class="hts-wrap" style="max-width:none;padding:0">

    <!-- ALERT -->
    <div id="hts-seo-alert"></div>

    <!-- MODE TOGGLE: Amateur / Expert -->
    <?php $expert_mode = get_option( 'hts_settings_mode', 'amateur' ); ?>
    <div class="hts-mode-bar">
        <span class="hts-label-sm" style="margin-bottom:0;">Mode :</span>
        <div class="hts-mode-toggle">
            <label class="hts-mode-btn<?php echo $expert_mode !== 'expert' ? ' hts-mode-btn--active' : ''; ?>" id="mode-amateur-label">
                <input type="radio" name="hts_mode" value="amateur" <?php checked( $expert_mode, 'amateur' ); ?> onchange="htsToggleMode(this.value)" class="hts-hidden">
                Simplifié
            </label>
            <label class="hts-mode-btn<?php echo $expert_mode === 'expert' ? ' hts-mode-btn--active' : ''; ?>" id="mode-expert-label">
                <input type="radio" name="hts_mode" value="expert" <?php checked( $expert_mode, 'expert' ); ?> onchange="htsToggleMode(this.value)" class="hts-hidden">
                Expert
            </label>
        </div>
        <span class="hts-hint" id="mode-hint" style="margin-top:0;">
            <?php echo $expert_mode === 'expert' ? 'Tous les réglages sont affichés' : 'Seuls les réglages essentiels sont affichés'; ?>
        </span>
    </div>

    <?php if ( ! empty( $competitor ) && ! empty( $competitor_settings ) ) : ?>
    <div class="hts-card hts-card hts-card--fallback hts-mb-5">
        <div class="hts-card-body">
            <p class="hts-help hts-m-0">
                <?php echo HTS_DS::icon('info',16,'var(--hts-text-3)'); ?> <strong><?php echo esc_html( ucfirst( $competitor ) ); ?></strong> détecté — les champs vides ci-dessous utilisent automatiquement ses réglages en fallback.
                <button type="button" class="hts-btn hts-btn--sm hts-btn--outline" id="hts-import-competitor">
                    Importer les réglages <?php echo esc_html( ucfirst( $competitor ) ); ?> → Hack The SEO
                </button>
            </p>
        </div>
    </div>
    <?php endif; ?>

    <form id="hts-seo-settings-form">

        <div class="hts-grid hts-grid-2">

            <!-- ══════════════════════════════════════
                 SECTION 1 — GENERAL
                 ══════════════════════════════════════ -->
            <div class="hts-card">
                <div class="hts-card-header">
                    <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('settings',16,'var(--hts-text-3)'); ?> Général</h3>
                </div>
                <div class="hts-card-body">

                    <!-- Home Title -->
                    <div class="hts-form-group">
                        <label class="hts-label" for="hts-home-title">
                            Titre de la page d'accueil
                            <?php if ( ! empty( $competitor_settings['home_title'] ) && empty( $settings['home_title'] ) ) : ?>
                                <span class="hts-badge hts-badge--info hts-hint">fallback <?php echo esc_html( $competitor ); ?></span>
                            <?php endif; ?>
                        </label>
                        <input
                            type="text"
                            class="hts-input"
                            id="hts-home-title"
                            name="home_title"
                            value="<?php echo esc_attr( $settings['home_title'] ); ?>"
                            placeholder="<?php echo esc_attr( $competitor_settings['home_title'] ?: get_bloginfo( 'name' ) ); ?>"
                            maxlength="70"
                        >
                        <div class="hts-char-count">
                            <span id="hts-home-title-count"><?php echo strlen( $settings['home_title'] ); ?></span>/70
                            <span class="hts-char-hint">— Recommandé : 50-60 caractères</span>
                        </div>
                    </div>

                    <!-- Home Description -->
                    <div class="hts-form-group">
                        <label class="hts-label" for="hts-home-desc">
                            Description de la page d'accueil
                            <?php if ( ! empty( $competitor_settings['home_description'] ) && empty( $settings['home_description'] ) ) : ?>
                                <span class="hts-badge hts-badge--info hts-hint">fallback <?php echo esc_html( $competitor ); ?></span>
                            <?php endif; ?>
                        </label>
                        <textarea
                            class="hts-input"
                            id="hts-home-desc"
                            name="home_description"
                            rows="3"
                            placeholder="<?php echo esc_attr( $competitor_settings['home_description'] ?: get_bloginfo( 'description' ) ); ?>"
                            maxlength="170"
                        ><?php echo esc_textarea( $settings['home_description'] ); ?></textarea>
                        <div class="hts-char-count">
                            <span id="hts-home-desc-count"><?php echo strlen( $settings['home_description'] ); ?></span>/170
                            <span class="hts-char-hint">— Recommandé : 120-160 caractères</span>
                        </div>
                    </div>

                    <!-- Title Separator -->
                    <div class="hts-form-group">
                        <label class="hts-label">Séparateur de titre</label>
                        <div class="hts-separator-picker" id="hts-sep-picker">
                            <?php
 $separators = array( '—', '–', '|', '·', '>', '<', '-', '/', '\\', '•', '→', '←', '', '' );
                            $current_sep = $settings['title_separator'] ?: '—';
                            foreach ( $separators as $sep ) :
                            ?>
                                <button type="button"
                                    class="hts-sep-btn <?php echo $sep === $current_sep ? 'active' : ''; ?>"
                                    data-sep="<?php echo esc_attr( $sep ); ?>"
                                ><?php echo esc_html( $sep ); ?></button>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="title_separator" id="hts-title-sep" value="<?php echo esc_attr( $current_sep ); ?>">
                    </div>

                    <!-- SERP Preview -->
                    <div class="hts-form-group">
                        <label class="hts-label">Aperçu Google — Page d'accueil</label>
                        <div class="hts-serp-preview" id="hts-serp-preview">
                            <div class="hts-serp-url"><?php echo esc_html( home_url( '/' ) ); ?></div>
                            <?php
                            // Resolve common SEO variable patterns (%%var%% from Rank Math, %var% etc.)
                            $serp_title_raw = $settings['home_title'] ?: $competitor_settings['home_title'] ?: get_bloginfo( 'name' );
                            $serp_desc_raw  = $settings['home_description'] ?: $competitor_settings['home_description'] ?: get_bloginfo( 'description' );
                            $serp_vars = array(
                                '%%sitename%%' => get_bloginfo( 'name' ),
                                '%sitename%'   => get_bloginfo( 'name' ),
                                '%%sep%%'      => $current_sep,
                                '%sep%'        => $current_sep,
                                '%%page%%'     => '',
                                '%page%'       => '',
                                '%%sitedesc%%' => get_bloginfo( 'description' ),
                                '%sitedesc%'   => get_bloginfo( 'description' ),
                            );
                            $serp_title = trim( preg_replace( '/\s{2,}/', ' ', str_replace( array_keys( $serp_vars ), array_values( $serp_vars ), $serp_title_raw ) ) );
                            $serp_desc  = trim( preg_replace( '/\s{2,}/', ' ', str_replace( array_keys( $serp_vars ), array_values( $serp_vars ), $serp_desc_raw ) ) );
                            ?>
                            <div class="hts-serp-title" id="hts-serp-title">
                                <?php echo esc_html( $serp_title ); ?>
                            </div>
                            <div class="hts-serp-desc" id="hts-serp-desc">
                                <?php echo esc_html( $serp_desc ); ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- ══════════════════════════════════════
                 SECTION 2 — SOCIAL PROFILES
                 ══════════════════════════════════════ -->
            <div class="hts-card">
                <div class="hts-card-header">
                    <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('globe',16,'var(--hts-text-3)'); ?> Profils sociaux</h3>
                    <span class="hts-help">Schema Organization → sameAs</span>
                </div>
                <div class="hts-card-body">

                    <p class="hts-help hts-mb-4 hts-mt-0">
                        Ces URLs apparaissent dans le schema Organization (sameAs) et aident Google à associer votre marque à vos profils.
                    </p>

                    <?php
                    $social_fields = array(
                        'facebook'  => array( 'label' => 'Facebook',  'icon' => 'facebook', 'placeholder' => 'https://www.facebook.com/votre-page' ),
                        'twitter'   => array( 'label' => 'Twitter / X','icon' => 'twitter', 'placeholder' => 'https://x.com/votre-compte' ),
                        'linkedin'  => array( 'label' => 'LinkedIn',  'icon' => 'linkedin', 'placeholder' => 'https://www.linkedin.com/company/votre-page' ),
                        'youtube'   => array( 'label' => 'YouTube',   'icon' => 'youtube', 'placeholder' => 'https://www.youtube.com/@votre-chaine' ),
                        'instagram' => array( 'label' => 'Instagram', 'icon' => 'instagram', 'placeholder' => 'https://www.instagram.com/votre-compte' ),
                        'tiktok'    => array( 'label' => 'TikTok',    'icon' => 'music', 'placeholder' => 'https://www.tiktok.com/@votre-compte' ),
                        'pinterest' => array( 'label' => 'Pinterest', 'icon' => 'pin', 'placeholder' => 'https://www.pinterest.com/votre-compte' ),
                        'github'    => array( 'label' => 'GitHub',    'icon' => 'github', 'placeholder' => 'https://github.com/votre-organisation' ),
                    );

                    $social_profiles = $settings['social_profiles'];
                    foreach ( $social_fields as $key => $field ) :
                        $val = isset( $social_profiles[ $key ] ) ? $social_profiles[ $key ] : '';
                        $fb  = isset( $competitor_settings['social_profiles'][ $key ] ) ? $competitor_settings['social_profiles'][ $key ] : '';
                    ?>
                    <div class="hts-form-group hts-form-group--compact">
                        <label class="hts-label hts-label--inline" for="hts-social-<?php echo $key; ?>">
                            <?php echo HTS_DS::icon( $field['icon'], 16, 'var(--hts-text-3)' ); ?> <?php echo esc_html( $field['label'] ); ?>
                            <?php if ( $fb && ! $val ) : ?>
                                <span class="hts-badge hts-badge--info hts-hint">fallback</span>
                            <?php endif; ?>
                        </label>
                        <input
                            type="url"
                            class="hts-input hts-input--sm"
                            id="hts-social-<?php echo $key; ?>"
                            name="social_<?php echo $key; ?>"
                            value="<?php echo esc_attr( $val ); ?>"
                            placeholder="<?php echo esc_attr( $fb ?: $field['placeholder'] ); ?>"
                        >
                    </div>
                    <?php endforeach; ?>

                    <!-- Twitter Handle -->
                    <div class="hts-form-group hts-form-group--compact hts-mt-4" style="padding-top:16px;border-top:1px solid var(--hts-border);">
                        <label class="hts-label hts-label--inline" for="hts-twitter-handle">
                            <?php echo HTS_DS::icon('twitter',16,'var(--hts-text-3)'); ?> Twitter Handle <span class="hts-hint">(pour Twitter Cards)</span>
                        </label>
                        <input
                            type="text"
                            class="hts-input hts-input--sm"
                            id="hts-twitter-handle"
                            name="twitter_handle"
                            value="<?php echo esc_attr( $settings['twitter_handle'] ); ?>"
                            placeholder="<?php echo esc_attr( $competitor_settings['twitter_handle'] ?: '@votre_compte' ); ?>"
                            style="max-width:220px;"
                        >
                    </div>

                </div>
            </div>

        </div>

        <!-- ══════════════════════════════════════
             SECTION 2B — RÉCEPTION DES ARTICLES (toujours visible)
             ══════════════════════════════════════ -->
        <?php $default_status = get_option( 'hts_article_default_status', 'draft' ); ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('download',16,'var(--hts-text-3)'); ?> Réception des articles</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-3 hts-mt-0">
                    Quand un article est envoyé depuis le SaaS Hack The SEO, il est créé dans WordPress avec le statut choisi ci-dessous.
                </p>
                <div class="hts-form-group" style="max-width:300px;">
                    <label class="hts-label" for="hts-default-status">Statut par défaut des articles reçus</label>
                    <select id="hts-default-status" class="hts-input">
                        <option value="draft" <?php selected( $default_status, 'draft' ); ?>>Brouillon — relecture avant publication</option>
                        <option value="publish" <?php selected( $default_status, 'publish' ); ?>>Publié — publication immédiate</option>
                        <option value="pending" <?php selected( $default_status, 'pending' ); ?>>En attente de relecture</option>
                    </select>
                    <p class="hts-hint">Recommandé : « Brouillon » pour vérifier le contenu avant mise en ligne.</p>
                </div>
            </div>
        </div>

        <!-- ══════════════════════════════════════
             SECTION 3 — SCHEMA (toujours visible)
             ══════════════════════════════════════ -->

        <!-- ── SCHEMA — Types auto-détectés ── -->
        <?php
        $schema_auto_defaults = array( 'faq'=>'1', 'howto'=>'1', 'video'=>'1', 'itemlist'=>'1', 'speakable'=>'1' );
        $schema_auto = wp_parse_args( get_option( 'hts_schema_auto_types', array() ), $schema_auto_defaults );
        $schema_type_labels = array(
            'faq'       => array( 'help-circle', 'FAQPage', 'Détecte les questions (H2-H6 avec ?) dans le contenu' ),
            'howto'     => array( 'list-ordered', 'HowTo', 'Détecte les listes d\'étapes numérotées' ),
            'video'     => array( 'video', 'VideoObject', 'Détecte les embeds YouTube / Vimeo' ),
            'itemlist'  => array( 'layout-list', 'ItemList', 'Détecte les listicles (Top X, X meilleurs…)' ),
            'speakable' => array( 'volume-2', 'Speakable', 'Optimise pour Google Assistant + citations IA' ),
        );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title">Schema — Types auto-détectés</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-3 hts-mt-0">
                    Choisissez quels schemas structurés sont générés automatiquement. Les Schema Pro (Book, Review, SoftwareApp) se configurent par article.
                </p>
                <?php foreach ( $schema_type_labels as $key => $info ) : ?>
                <label class="hts-schema-row" style="cursor:pointer;"
                    onmouseover="this.style.background='var(--hts-surface)'" onmouseout="this.style.background='transparent'">
                    <input type="checkbox" class="schema-auto-toggle" data-type="<?php echo esc_attr( $key ); ?>"
                        <?php checked( $schema_auto[ $key ], '1' ); ?>
                        class="hts-check-sm">
                    <span ><?php echo HTS_DS::icon( $info[0], 16, 'var(--hts-text-3)' ); ?></span>
                    <span class="hts-schema-row__type"><?php echo esc_html( $info[1] ); ?></span>
                    <span class="hts-schema-row__desc"><?php echo esc_html( $info[2] ); ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ══════════════════════════════════════
             EXPERT SECTIONS — Schema Preview, Sitemap, Robots, Breadcrumbs, TOC, Webmaster, OG
             ══════════════════════════════════════ -->
        <div class="hts-expert-only<?php if ( $expert_mode !== 'expert' ) echo ' hts-hidden'; ?>">

        <!-- ── SCHEMA PREVIEW (Expert only) ── -->
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header" style="cursor:pointer;" onclick="var b=document.getElementById('hts-schema-preview-body');b.classList.toggle('hts-hidden');" id="hts-schema-preview-toggle">
                <h3 class="hts-ds-card__title">Aperçu Schema Organization</h3>
 <span class="hts-toggle-arrow" id="hts-schema-arrow"></span>
            </div>
            <div class="hts-card-body hts-hidden" id="hts-schema-preview-body">
                <pre id="hts-schema-json" class="hts-json-preview" style="max-height:400px;"></pre>
                <p class="hts-help hts-mt-3">
                    Ce schema sera injecté automatiquement sur toutes les pages. Sauvegardez pour actualiser.
                </p>
            </div>
        </div>

        <!-- ══════════════════════════════════════
             SECTION 4 — SITEMAP SETTINGS
             ══════════════════════════════════════ -->
        <?php
        $sm_settings  = class_exists( 'HTS_Sitemap' ) ? HTS_Sitemap::get_settings() : array();
        $sm_stats     = get_option( 'hts_sitemap_stats', array() );
        $sm_pt_active = isset( $sm_settings['post_types'] ) ? (array) $sm_settings['post_types'] : array( 'post', 'page' );
        $all_pts      = get_post_types( array( 'public' => true ), 'objects' );
        unset( $all_pts['attachment'] );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('map',16,'var(--hts-text-3)'); ?> Sitemap XML</h3>
            </div>
            <div class="hts-card-body">
                <!-- Stats row -->
                <?php if ( ! empty( $sm_stats['last_generated'] ) ) : ?>
                <div class="hts-stats-bar hts-flex-wrap hts-mb-4" style="padding:12px;background:var(--hts-surface);border-radius:var(--hts-radius-sm);">
                    <span>Dernier build : <strong class="hts-text-primary"><?php echo esc_html( $sm_stats['last_generated'] ); ?></strong></span>
                    <?php if ( ! empty( $sm_stats['last_served'] ) ) : ?>
                    <span>Dernier crawl : <strong class="hts-text-primary"><?php echo esc_html( $sm_stats['last_served'] ); ?></strong></span>
                    <?php endif; ?>
                    <?php
                    $total_urls = 0;
                    foreach ( $sm_stats as $k => $v ) {
                        if ( is_array( $v ) && isset( $v['urls'] ) ) $total_urls += (int) $v['urls'];
                    }
                    if ( $total_urls ) : ?>
                    <span>URLs : <strong class="hts-text-primary"><?php echo number_format( $total_urls ); ?></strong></span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Post types -->
                <div class="hts-mb-4">
                    <label class="hts-label-sm hts-mb-2">Post types inclus dans le sitemap</label>
                    <div class="hts-flex-wrap hts-gap-3">
                        <?php foreach ( $all_pts as $pt_slug => $pt_obj ) : ?>
                        <label class="hts-check-inline">
                            <input type="checkbox" class="sm-pt-toggle" value="<?php echo esc_attr( $pt_slug ); ?>"
                                   <?php checked( in_array( $pt_slug, $sm_pt_active, true ) ); ?>>
                            <?php echo esc_html( $pt_obj->label ); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Toggles -->
                <div class="hts-grid-auto hts-mb-4" style="gap:8px;">
                    <label class="hts-check-inline">
                        <input type="checkbox" id="sm-images" <?php checked( ! empty( $sm_settings['image_sitemap'] ) ); ?>>
                        Images dans le sitemap
                    </label>
                    <label class="hts-check-inline">
                        <input type="checkbox" id="sm-taxonomy" <?php checked( ! empty( $sm_settings['taxonomy_sitemap'] ) ); ?>>
                        Taxonomies (catégories, tags…)
                    </label>
                    <label class="hts-check-inline">
                        <input type="checkbox" id="sm-cocon" <?php checked( ! empty( $sm_settings['cocon_sitemaps'] ) ); ?>>
                        Sous-sitemaps par cocon
                    </label>
                    <label class="hts-check-inline">
                        <input type="checkbox" id="sm-ping-google" <?php checked( ! empty( $sm_settings['ping_google'] ) ); ?>>
                        Ping Google
                    </label>
                    <label class="hts-check-inline">
                        <input type="checkbox" id="sm-ping-bing" <?php checked( ! empty( $sm_settings['ping_bing'] ) ); ?>>
                        Ping Bing
                    </label>
                    <label class="hts-check-inline">
                        <input type="checkbox" id="sm-legacy" <?php checked( ! empty( $sm_settings['include_legacy_tags'] ) ); ?>>
                        changefreq + priority
                    </label>
                </div>

                <!-- Max URLs -->
                <div class="hts-mb-4">
                    <label class="hts-label-sm">Max URLs par sous-sitemap</label>
                    <select id="sm-max-urls" class="hts-input hts-input--sm">
                        <?php foreach ( array( 500, 1000, 2500, 5000, 10000 ) as $opt ) : ?>
                        <option value="<?php echo $opt; ?>" <?php selected( (int)($sm_settings['max_urls_per_sitemap'] ?? 1000), $opt ); ?>><?php echo number_format( $opt ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span class="hts-hint">Google recommande ≤ 50 000, mais 1000-2500 = crawl plus rapide</span>
                </div>

                <!-- Action buttons -->
                <div class="hts-flex hts-gap-2 hts-mt-2" style="padding-top:8px;border-top:1px solid var(--hts-border-sub);">
                    <a href="<?php echo esc_url( home_url( '/sitemap.xml' ) ); ?>" target="_blank" class="hts-btn hts-fs-sm">
                        Voir le sitemap
                    </a>
                </div>
            </div>
        </div>

        <!-- ══════════════════════════════════════
             EXPERT SECTIONS continued
             ══════════════════════════════════════ -->

        <!-- ── ROBOTS GLOBAL RULES ── -->
        <?php
        $robots_global = get_option( 'hts_robots_global', array() );
        $archive_types = array(
            'category'   => array( 'label' => 'Pages de catégories',    'icon' => 'folder', 'desc' => 'Archives de catégories WordPress' ),
            'post_tag'   => array( 'label' => 'Pages de tags',          'icon' => 'hash', 'desc' => 'Archives de mots-clés' ),
            'author'     => array( 'label' => 'Pages auteur',           'icon' => 'user', 'desc' => 'Archives par auteur — souvent thin content' ),
            'date'       => array( 'label' => 'Archives par date',      'icon' => 'calendar', 'desc' => 'Archives mensuelles/annuelles — toujours noindex recommandé' ),
            'search'     => array( 'label' => 'Pages de recherche',     'icon' => 'search', 'desc' => 'Résultats de recherche interne — toujours noindex' ),
            'pagination' => array( 'label' => 'Pages paginées',         'icon' => 'file-text', 'desc' => '/page/2, /page/3… — noindex recommandé' ),
        );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('bot',16,'var(--hts-text-3)'); ?> Robots Meta — Règles globales</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-4 hts-mt-0">
                    Contrôlez l'indexation des différents types d'archives. Ces règles s'appliquent globalement — les pages individuelles peuvent être overridées via la metabox.
                </p>
                <?php foreach ( $archive_types as $akey => $ainfo ) :
                    $is_noindex  = isset( $robots_global[ $akey ] ) && is_array( $robots_global[ $akey ] ) && in_array( 'noindex', $robots_global[ $akey ], true );
                    $is_nofollow = isset( $robots_global[ $akey ] ) && is_array( $robots_global[ $akey ] ) && in_array( 'nofollow', $robots_global[ $akey ], true );
                    $recommended = in_array( $akey, array( 'date', 'search', 'pagination' ), true );
                ?>
                <div class="hts-robots-row" style="padding:10px 0;border-bottom:1px solid var(--hts-border-sub);">
                    <div class="hts-flex-1">
                        <div class="hts-label-sm" style="font-size:13px;"><?php echo HTS_DS::icon( $ainfo['icon'], 16, 'var(--hts-text-3)' ); ?> <?php echo esc_html( $ainfo['label'] ); ?><?php if ( $recommended ) : ?> <span class="hts-badge hts-badge--warning">recommandé noindex</span><?php endif; ?></div>
                        <div class="hts-hint hts-m-0"><?php echo esc_html( $ainfo['desc'] ); ?></div>
                    </div>
                    <div class="hts-robots-row__checks">
                        <label class="hts-check-inline hts-fs-sm">
                            <input type="checkbox" class="robots-global-cb" data-type="<?php echo esc_attr( $akey ); ?>" data-directive="noindex" <?php checked( $is_noindex ); ?>> noindex
                        </label>
                        <label class="hts-check-inline hts-fs-sm">
                            <input type="checkbox" class="robots-global-cb" data-type="<?php echo esc_attr( $akey ); ?>" data-directive="nofollow" <?php checked( $is_nofollow ); ?>> nofollow
                        </label>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ── BREADCRUMBS ── -->
        <?php
        // ── ROBOTS.TXT EDITOR ──
        $robotstxt_custom  = get_option( 'hts_robotstxt_custom', '' );
        $has_physical_file = class_exists( 'HTS_Robots' ) ? HTS_Robots::has_physical_file() : false;
        $blog_public       = get_option( 'blog_public', '1' );
        // Auto-generate defaults if empty (never show blank textarea)
        if ( empty( $robotstxt_custom ) && class_exists( 'HTS_Robots' ) ) {
            $robotstxt_custom = HTS_Robots::get_default_robotstxt();
        }
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header hts-flex-between">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('file-text',16,'var(--hts-text-3)'); ?> Robots.txt</h3>
                <a href="<?php echo esc_url( home_url( '/robots.txt' ) ); ?>" target="_blank" rel="noopener" class="hts-btn-text">
                    Voir robots.txt ↗
                </a>
            </div>
            <div class="hts-card-body">

                <?php if ( $has_physical_file ) : ?>
                <div class="hts-alert-compact hts-mb-3">
                    <?php echo HTS_DS::icon('alert-triangle',16,'var(--hts-text-3)'); ?> <strong>Fichier physique détecté</strong> à la racine — il a priorité sur cet éditeur. Supprimez-le via FTP pour que vos modifications prennent effet.
                </div>
                <?php endif; ?>

                <?php if ( '0' === (string) $blog_public ) : ?>
                <div class="hts-alert-compact hts-mb-3" style="background:var(--hts-danger-bg,#FEF2F2);border:1px solid var(--hts-danger);border-radius:var(--hts-radius-sm);padding:12px 16px;">
                    <?php echo HTS_DS::icon('alert',16,'var(--hts-danger)'); ?> <strong>Votre site est invisible pour Google.</strong> WordPress bloque tous les moteurs de recherche. Pour corriger : allez dans <a href="<?php echo admin_url( 'options-reading.php' ); ?>" style="color:var(--hts-danger);font-weight:600;text-decoration:underline">Réglages &rarr; Lecture</a> et décochez « Demander aux moteurs de recherche de ne pas indexer ce site ».
                </div>
                <?php endif; ?>

                <div id="robotstxt-warnings" class="hts-hidden hts-mb-3"></div>

                <textarea id="robotstxt-editor"
                          class="hts-textarea-code" style="min-height:260px;resize:vertical;"
                          spellcheck="false"><?php echo esc_textarea( $robotstxt_custom ); ?></textarea>

                <p class="hts-hint hts-mt-2">
                    Fichier virtuel — les modifications s'appliquent à la sauvegarde. Les commentaires commencent par <code>#</code>.
                </p>
            </div>
        </div>

        <?php
        $bc_defaults = array( 'enabled'=>'1', 'separator'=>' › ', 'home_label'=>'Accueil', 'show_home'=>'1', 'max_title_chars'=>60 );
        $bc_settings = wp_parse_args( get_option( 'hts_breadcrumbs_settings', array() ), $bc_defaults );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('chevron-right',16,'var(--hts-text-3)'); ?> Breadcrumbs (Fil d'Ariane)</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-3 hts-mt-0">L'activation des breadcrumbs se gère via le toggle du module Cockpit.</p>
                <div class="hts-grid-3">
                    <div>
                        <label class="hts-label-sm">Séparateur</label>
                        <select id="bc-separator" class="hts-input hts-input--sm">
                            <option value=" › " <?php selected( $bc_settings['separator'], ' › ' ); ?>>›</option>
                            <option value=" > " <?php selected( $bc_settings['separator'], ' > ' ); ?>>></option>
                            <option value=" → " <?php selected( $bc_settings['separator'], ' → ' ); ?>>→</option>
                            <option value=" » " <?php selected( $bc_settings['separator'], ' » ' ); ?>>»</option>
                            <option value=" / " <?php selected( $bc_settings['separator'], ' / ' ); ?>>/</option>
                        </select>
                    </div>
                    <div>
                        <label class="hts-label-sm">Label "Accueil"</label>
                        <input type="text" id="bc-home-label" value="<?php echo esc_attr( $bc_settings['home_label'] ); ?>" class="hts-input hts-input--sm" placeholder="Accueil">
                    </div>
                    <div>
                        <label class="hts-label-sm">Max caractères titre</label>
                        <input type="number" id="bc-max-chars" value="<?php echo (int) $bc_settings['max_title_chars']; ?>" min="20" max="200" class="hts-input hts-input--sm">
                    </div>
                </div>
                <p class="hts-hint hts-mt-3">Shortcode : <code>[hts_breadcrumbs]</code> — PHP : <code>&lt;?php hts_breadcrumbs(); ?&gt;</code></p>
            </div>
        </div>

        <!-- ── LLMS.TXT — AI DISCOVERY ── -->
        <?php
        $llmstxt_enabled = get_option( 'hts_llmstxt_enabled', '1' );
        $llmstxt_mode    = get_option( 'hts_llmstxt_mode', 'auto' );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('brain',16,'var(--hts-text-3)'); ?> llms.txt — Visibilité IA</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-3 hts-mt-0">
                    Génère un fichier <code>/llms.txt</code> qui guide les LLMs (ChatGPT, Claude, Gemini, Perplexity) vers votre contenu prioritaire.
                    <a href="https://llmstxt.org/" target="_blank" rel="noopener" class="hts-btn-text hts-p-0">Spécification ↗</a>
                </p>
                <div class="hts-grid-2">
                    <div>
                        <label class="hts-label-sm">Activation</label>
                        <select id="llmstxt-enabled" class="hts-input hts-input--sm">
                            <option value="1" <?php selected( $llmstxt_enabled, '1' ); ?>>Activé</option>
                            <option value="0" <?php selected( $llmstxt_enabled, '0' ); ?>>Désactivé</option>
                        </select>
                    </div>
                    <div>
                        <label class="hts-label-sm">Mode</label>
                        <select id="llmstxt-mode" class="hts-input hts-input--sm">
                            <option value="auto" <?php selected( $llmstxt_mode, 'auto' ); ?>>Auto — Piliers + Pages clés + Posts récents</option>
                            <option value="manual" <?php selected( $llmstxt_mode, 'manual' ); ?>>Manuel — Sélection manuelle</option>
                        </select>
                    </div>
                </div>
                <div class="hts-flex-center hts-gap-2 hts-mt-3">
                    <button type="button" id="llmstxt-preview-btn" class="button button-secondary hts-fs-sm">
                        Aperçu
                    </button>
                    <button type="button" id="llmstxt-refresh-btn" class="button button-secondary hts-fs-sm">
                        Régénérer
                    </button>
                    <?php if ( $llmstxt_enabled === '1' ) : ?>
                    <a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank" rel="noopener" class="button button-secondary hts-fs-sm">
                        Voir llms.txt
                    </a>
                    <?php endif; ?>
                    <span id="llmstxt-status" class="hts-hint"></span>
                </div>
                <div id="llmstxt-preview-box" class="hts-code-preview hts-mt-3" style="display:none;background:var(--hts-text);color:var(--hts-border);max-height:400px;"></div>
            </div>
        </div>

        <!-- ── INDEXNOW — Instant Indexing ── -->
        <?php
        $indexnow_enabled = get_option( 'hts_indexnow_enabled', '0' );
        $indexnow_key     = class_exists( 'HTS_IndexNow' ) ? HTS_IndexNow::get_api_key() : '';
        $indexnow_stats   = class_exists( 'HTS_IndexNow' ) ? HTS_IndexNow::get_stats() : array( 'total' => 0, 'success' => 0, 'errors' => 0, 'last' => '' );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('satellite-dish',16,'var(--hts-text-3)'); ?> IndexNow — Indexation instantanée</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-3 hts-mt-0">
                    Notifie automatiquement Bing, Yandex et les autres moteurs compatibles
                    <a href="https://www.indexnow.org/" target="_blank" rel="noopener" class="hts-btn-text hts-p-0">IndexNow ↗</a>
                    dès qu'un contenu est publié ou mis à jour. Indexation en quelques minutes au lieu de quelques jours.
                </p>

                <div class="hts-grid-2">
                    <div>
                        <label class="hts-label-sm">Activation</label>
                        <select id="indexnow-enabled" class="hts-input hts-input--sm">
                            <option value="1" <?php selected( $indexnow_enabled, '1' ); ?>>Activé — Ping auto à chaque publication</option>
                            <option value="0" <?php selected( $indexnow_enabled, '0' ); ?>>Désactivé</option>
                        </select>
                    </div>
                    <div>
                        <label class="hts-label-sm">Clé API</label>
                        <div class="hts-flex-center hts-gap-2">
                            <input type="text" id="indexnow-key" value="<?php echo esc_attr( $indexnow_key ); ?>" readonly
                                   class="hts-input hts-input--sm hts-input--mono hts-flex-1">
                            <button type="button" id="indexnow-reset-key" class="hts-btn hts-btn--sm hts-btn--outline" title="Régénérer la clé"><?php echo HTS_DS::icon('refresh-cw',16,'var(--hts-text-3)'); ?></button>
                        </div>
                    </div>
                </div>

                <?php if ( $indexnow_stats['total'] > 0 ) : ?>
                <div class="hts-stats-bar hts-mt-3" style="padding:10px 14px;background:var(--hts-success-bg);border-radius:var(--hts-radius-xs);">
                    <div>
                        <span class="hts-stats-bar--success">Stats :</span>
                        <span class="hts-text-primary"><?php echo (int) $indexnow_stats['total']; ?> pings</span>
 <span style="color:var(--hts-success);">• <?php echo (int) $indexnow_stats['success']; ?> </span>
                        <?php if ( $indexnow_stats['errors'] > 0 ) : ?>
 <span style="color:var(--hts-danger);">• <?php echo (int) $indexnow_stats['errors']; ?> </span>
                        <?php endif; ?>
                        <?php if ( ! empty( $indexnow_stats['last'] ) ) : ?>
                        <span style="color:var(--hts-text-2);">• Dernier : <?php echo esc_html( $indexnow_stats['last'] ); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="hts-btn-group hts-flex-wrap hts-mt-3">
                    <button type="button" id="indexnow-ping-all" class="button button-secondary hts-fs-sm">
                        Ping les 50 derniers contenus
                    </button>
                    <?php if ( $indexnow_key ) : ?>
                    <a href="<?php echo esc_url( home_url( '/' . $indexnow_key . '.txt' ) ); ?>" target="_blank" rel="noopener" class="button button-secondary hts-fs-sm">
                        Vérifier la clé
                    </a>
                    <?php endif; ?>
                    <span id="indexnow-status" class="hts-hint hts-ml-auto"></span>
                </div>

                <div class="hts-tip hts-mt-3">
                    <p class="hts-hint hts-m-0">
                        <?php echo HTS_DS::icon('info',16,'var(--hts-text-3)'); ?> <strong>Comment ça marche :</strong>
                        À chaque publication/mise à jour, Hack The SEO envoie l'URL à IndexNow.
                        Les pages noindex sont automatiquement exclues.
                        Rate limit : 1 ping par URL toutes les 10 minutes.
                        Moteurs supportés : Bing, Yandex, Naver, Seznam.
                    </p>
                </div>
            </div>
        </div>

        <!-- ── TABLE DES MATIÈRES (TOC) ── -->
        <?php
        $toc_depth = get_option( 'hts_toc_depth', 'h2h3' );
        $toc_min   = (int) get_option( 'hts_toc_min', 3 );
        $toc_style = get_option( 'hts_toc_style', 'hts' );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('list-tree',16,'var(--hts-text-3)'); ?> Table des matières</h3>
            </div>
            <div class="hts-card-body">
                <div class="hts-grid-3">
                    <div>
                        <label class="hts-label-sm">Profondeur</label>
                        <select id="toc-depth" class="hts-input hts-input--sm">
                            <option value="h2" <?php selected( $toc_depth, 'h2' ); ?>>H2 uniquement</option>
                            <option value="h2h3" <?php selected( $toc_depth, 'h2h3' ); ?>>H2 + H3</option>
                        </select>
                    </div>
                    <div>
                        <label class="hts-label-sm">Minimum de titres</label>
                        <input type="number" id="toc-min" value="<?php echo $toc_min; ?>" min="2" max="10" class="hts-input hts-input--sm">
                    </div>
                    <div>
                        <label class="hts-label-sm">Style</label>
                        <select id="toc-style" class="hts-input hts-input--sm">
                            <option value="hts" <?php selected( $toc_style, 'hts' ); ?>>Hack The SEO (stylé)</option>
                            <option value="minimal" <?php selected( $toc_style, 'minimal' ); ?>>Minimal (hérite du thème)</option>
                        </select>
                    </div>
                </div>
                <p class="hts-hint hts-mt-3">Le sommaire s'insère automatiquement avant le premier H2 des articles. Minimum <?php echo $toc_min; ?> titres requis.</p>
            </div>
        </div>

        <!-- ── WEBMASTER VERIFICATION ── -->
        <?php
        $wm = get_option( 'hts_webmaster_verification', array() );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('shield',16,'var(--hts-text-3)'); ?> Vérification Webmaster</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-4 hts-mt-0">
                    Codes de vérification injectés dans le <code>&lt;head&gt;</code>. Copiez le contenu de la balise meta fournie par chaque service.
                </p>
                <div class="hts-grid-2" style="gap:12px;">
                    <div class="hts-form-group hts-form-group--compact">
                        <label class="hts-label hts-label--inline"><?php echo HTS_DS::icon('search',16,'var(--hts-text-3)'); ?> Google Search Console</label>
                        <input type="text" class="hts-input hts-input--sm" id="wm-google" value="<?php echo esc_attr( $wm['google'] ?? '' ); ?>" placeholder="content=&quot;xxxx&quot; → collez juste xxxx">
                    </div>
                    <div class="hts-form-group hts-form-group--compact">
                        <label class="hts-label hts-label--inline"><?php echo HTS_DS::icon('globe',16,'var(--hts-text-3)'); ?> Bing Webmaster</label>
                        <input type="text" class="hts-input hts-input--sm" id="wm-bing" value="<?php echo esc_attr( $wm['bing'] ?? '' ); ?>" placeholder="Code de vérification Bing">
                    </div>
                    <div class="hts-form-group hts-form-group--compact">
                        <label class="hts-label hts-label--inline"><?php echo HTS_DS::icon('pin',16,'var(--hts-text-3)'); ?> Pinterest</label>
                        <input type="text" class="hts-input hts-input--sm" id="wm-pinterest" value="<?php echo esc_attr( $wm['pinterest'] ?? '' ); ?>" placeholder="Code de vérification Pinterest">
                    </div>
                    <div class="hts-form-group hts-form-group--compact">
                        <label class="hts-label hts-label--inline">🅱 Yandex</label>
                        <input type="text" class="hts-input hts-input--sm" id="wm-yandex" value="<?php echo esc_attr( $wm['yandex'] ?? '' ); ?>" placeholder="Code de vérification Yandex">
                    </div>
                </div>
            </div>
        </div>

        <!-- ── OG DEFAULT IMAGE ── -->
        <?php $og_default = get_option( 'hts_og_default_image', '' ); ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('image',16,'var(--hts-text-3)'); ?> Image Open Graph par défaut</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-3 hts-mt-0">
                    Utilisée quand un article n'a pas d'image mise en avant. Recommandé : 1200×630px.
                </p>
                <div class="hts-flex-center hts-gap-3">
                    <input type="text" id="og-default-image" class="hts-input" value="<?php echo esc_attr( $og_default ); ?>" placeholder="https://example.com/default-og.jpg" style="flex:1;">
                    <button type="button" class="hts-btn hts-btn--sm hts-btn--outline" onclick="htsMediaPicker('og-default-image')">Choisir</button>
                </div>
                <?php if ( $og_default ) : ?>
                <img src="<?php echo esc_url( $og_default ); ?>" class="hts-og-preview" style="border:1px solid var(--hts-border);" alt="OG default">
                <?php endif; ?>
            </div>
        </div>

        <!-- ══════════════════════════════════════
             SECTION — REL PREV/NEXT & HREFLANG
             ══════════════════════════════════════ -->
        <?php
        $rel_prev_next = get_option( 'hts_rel_prev_next', '1' );
        $hreflang      = get_option( 'hts_hreflang', '1' );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('link',16,'var(--hts-text-3)'); ?> Pagination & Multilingue</h3>
            </div>
            <div class="hts-card-body">

                <div class="hts-form-group">
                    <label class="hts-check-inline">
                        <input type="checkbox" name="hts_rel_prev_next" value="1" <?php checked( $rel_prev_next, '1' ); ?> class="hts-check-sm" id="hts-rel-prev-next">
                        <span><strong>rel prev / next</strong> — Indique à Google les pages précédentes et suivantes des listes paginées</span>
                    </label>
                    <p class="hts-hint">WordPress a retiré ces balises en v5.3. Elles aident Google à comprendre la structure de vos archives.</p>
                </div>

                <div class="hts-form-group hts-mb-0">
                    <label class="hts-check-inline">
                        <input type="checkbox" name="hts_hreflang" value="1" <?php checked( $hreflang, '1' ); ?> class="hts-check-sm" id="hts-hreflang">
                        <span><strong>hreflang</strong> — Signale les versions traduites de chaque page aux moteurs de recherche</span>
                    </label>
                    <p class="hts-hint">Détection automatique de WPML, Polylang et TranslatePress. Aucune configuration manuelle nécessaire.</p>
                </div>

            </div>
        </div>

        </div><!-- .hts-expert-only -->

        <!-- ══════════════════════════════════════
             SECTION 5 — MODULE TOGGLES
             ══════════════════════════════════════ -->
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h3 class="hts-ds-card__title"><?php echo HTS_DS::icon('sliders',16,'var(--hts-text-3)'); ?> Modules actifs</h3>
            </div>
            <div class="hts-card-body">
                <p class="hts-help hts-mb-4 hts-mt-0">
                    Désactiver un module redonne le contrôle au concurrent détecté (si présent).
                </p>
                <div class="hts-grid-modules">
                    <?php
                    $modules = array(
                        'meta_tags' => array( 'label' => 'Meta Title & Description', 'icon' => 'file-text' ),
                        'schema'    => array( 'label' => 'Schema / JSON-LD',        'icon' => 'code-2' ),
                        'opengraph' => array( 'label' => 'Open Graph & Twitter',     'icon' => 'globe' ),
                    );
                    foreach ( $modules as $mod_key => $mod ) :
                        $opt_key = 'hts_module_' . $mod_key;
                        $enabled = get_option( $opt_key, '1' ) === '1';
                    ?>
                    <label class="hts-toggle-card <?php echo $enabled ? 'active' : ''; ?>">
                        <input type="checkbox" name="module_<?php echo $mod_key; ?>" value="1" <?php checked( $enabled ); ?>>
                        <span class="hts-toggle-icon"><?php echo HTS_DS::icon( $mod['icon'], 16, 'var(--hts-text-3)' ); ?></span>
                        <span class="hts-toggle-label"><?php echo esc_html( $mod['label'] ); ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ══════════════════════════════════════
             UPGRADE BANNER — Full-only features (commented: à réactiver pour upsell)
             ══════════════════════════════════════ -->
        <?php /* Upgrade banner — décommenté quand prêt pour l'upsell Light→Full
        <div class="hts-card hts-card hts-card--upgrade hts-mt-5" style="background:linear-gradient(135deg,var(--hts-caution-bg),var(--hts-caution-bg));">
            <div class="hts-card-body" style="text-align:center;padding:30px;">
                
                <h3 style="color:var(--hts-caution);font-size:18px;margin:0 0 8px;">Fonctionnalités disponibles dans Hack The SEO Full</h3>
                <p class="hts-help hts-mb-4" style="color:var(--hts-caution);font-size:14px;max-width:500px;display:inline-block;">
                    Role Manager, Local SEO, WooCommerce SEO avancé,
                    IA rédaction, Maillage sémantique, Cocon automatique, et plus encore.
                </p>
                <div>
                    <a href="<?php echo admin_url( 'admin.php?page=hts-upgrade' ); ?>" class="hts-btn hts-btn--primary hts-btn hts-btn--lg" style="background:linear-gradient(135deg,var(--hts-caution),var(--hts-caution));color:#fff;border:none;">
                        Voir le comparatif Light vs Full
                    </a>
                </div>
            </div>
        </div>
        */ ?>




        <!-- ══════════════════════════════════════
             GOOGLE SEARCH CONSOLE
             ══════════════════════════════════════ -->
        <?php
        $gsc_status = array( 'connected' => false, 'has_keys' => false, 'site_url' => '', 'email' => '', 'last_fetch' => null, 'proxy_mode' => false );
        if ( class_exists( 'HTS_GSC_Connect' ) ) {
            $gsc_obj    = new HTS_GSC_Connect();
            $gsc_status = $gsc_obj->get_connection_status();
        }
        $gsc_nonce = wp_create_nonce( 'hts_gsc_admin' );
        $gsc_proxy = ! empty( $gsc_status['proxy_mode'] );
        ?>
        <div class="hts-card hts-mt-5" id="hts-gsc-section">
            <div class="hts-card-header">
                <h2 class="hts-ds-card__title"><?php echo HTS_DS::icon('trending-up',16,'var(--hts-text-3)'); ?> Google Search Console</h2>
                <?php if ( $gsc_status['connected'] ) : ?>
                <span style="background:var(--hts-success-bg);color:var(--hts-success);font-size:10px;font-weight:700;padding:2px 8px;border-radius:8px;">Connect&eacute;</span>
                <?php endif; ?>
            </div>
            <div class="hts-card-body">

                <?php if ( $gsc_status['connected'] ) : ?>
                <!-- CONNECTED STATE -->
                <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:var(--hts-success-bg);border:1px solid var(--hts-success-bg);border-radius:8px;margin-bottom:16px;">
                    <div style="width:36px;height:36px;border-radius:50%;background:var(--hts-success-bg);display:flex;align-items:center;justify-content:center;">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--hts-success)" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                    </div>
                    <div style="flex:1;">
                        <div style="font-size:13px;font-weight:700;color:var(--hts-success);">Connect&eacute; &agrave; Google Search Console</div>
                        <?php if ( $gsc_status['email'] ) : ?>
                        <div style="font-size:11px;color:var(--hts-success);"><?php echo esc_html( $gsc_status['email'] ); ?></div>
                        <?php endif; ?>
                        <?php if ( $gsc_status['site_url'] ) : ?>
                        <div style="font-size:11px;color:var(--hts-success);">Site : <?php echo esc_html( $gsc_status['site_url'] ); ?></div>
                        <?php endif; ?>
                        <?php if ( $gsc_status['last_fetch'] ) : ?>
                        <div style="font-size:10px;color:var(--hts-text-3);margin-top:2px;">Derni&egrave;re synchro : <?php echo esc_html( $gsc_status['last_fetch'] ); ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="hts-btn hts-btn--sm" onclick="htsGscFetchNow()" id="hts-gsc-fetch-btn" style="font-size:11px;">
                        Synchroniser maintenant
                    </button>
                    <button type="button" class="hts-btn hts-btn--sm hts-btn--ghost" onclick="htsGscDisconnect()" style="font-size:11px;color:var(--hts-danger);">
                        D&eacute;connecter
                    </button>
                </div>

                <?php if ( empty( $gsc_status['site_url'] ) ) : ?>
                <!-- SITE SELECTION -->
                <div style="padding:12px 16px;background:var(--hts-caution-bg);border:1px solid var(--hts-caution);border-radius:8px;margin-bottom:16px;">
                    <div style="font-size:12px;font-weight:700;color:var(--hts-caution);margin-bottom:8px;">S&eacute;lectionnez votre site</div>
                    <div style="font-size:11px;color:var(--hts-caution);margin-bottom:8px;">Choisissez le site v&eacute;rifi&eacute; dans Search Console qui correspond &agrave; ce WordPress.</div>
                    <button type="button" class="hts-btn hts-btn--sm" onclick="htsGscListSites()" id="hts-gsc-list-btn">Charger la liste des sites</button>
                    <div id="hts-gsc-sites-list" style="margin-top:8px;"></div>
                </div>
                <?php endif; ?>

                <?php else : ?>
                <!-- NOT CONNECTED -->

                <?php if ( $gsc_proxy ) : ?>
                <!-- MODE PROXY : Un seul bouton -->
                <div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px;line-height:1.6;">
                    Connectez votre compte Google Search Console en un clic pour voir vos clics, impressions, CTR et position moyenne directement dans Hack The SEO.
                </div>
                <div style="display:flex;gap:8px;align-items:center;">
                    <button type="button" class="hts-btn hts-btn--sm" onclick="htsGscProxyConnect()" id="hts-gsc-connect-btn" style="display:inline-flex;align-items:center;gap:6px;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A10.96 10.96 0 001 12c0 1.77.42 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        Connecter Google Search Console
                    </button>
                    <span id="hts-gsc-status-msg" style="font-size:11px;color:var(--hts-text-3);"></span>
                </div>

                <?php else : ?>
                <!-- MODE DIRECT : Client ID + Secret (fallback) -->
                <div style="font-size:12px;color:var(--hts-text-3);margin-bottom:16px;line-height:1.6;">
                    Connectez Google Search Console pour voir vos clics, impressions, CTR et position moyenne directement dans Hack The SEO.
                </div>

                <div class="hts-row hts-gap-3 hts-mb-3">
                    <div class="hts-col" style="flex:1;">
                        <label class="hts-label hts-label--sm">Client ID</label>
                        <input type="text" id="hts-gsc-client-id" class="hts-input"
                               value="<?php echo esc_attr( get_option( 'hts_gsc_client_id', '' ) ); ?>"
                               placeholder="xxxx.apps.googleusercontent.com">
                    </div>
                    <div class="hts-col" style="flex:1;">
                        <label class="hts-label hts-label--sm">Client Secret</label>
                        <input type="password" id="hts-gsc-client-secret" class="hts-input"
                               value="<?php echo esc_attr( get_option( 'hts_gsc_client_secret', '' ) ); ?>"
                               placeholder="GOCSPX-xxxx">
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:center;">
                    <button type="button" class="hts-btn hts-btn--sm" onclick="htsGscSaveAndConnect()" id="hts-gsc-connect-btn">
                        Enregistrer et connecter
                    </button>
                    <span id="hts-gsc-status-msg" style="font-size:11px;color:var(--hts-text-3);"></span>
                </div>
                <details style="margin-top:12px;">
                    <summary style="font-size:11px;color:var(--hts-accent);cursor:pointer;font-weight:600;">Comment obtenir les cl&eacute;s ?</summary>
                    <div style="font-size:11px;color:var(--hts-text-3);line-height:1.8;padding:8px 0;">
                        1. Allez sur <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">console.cloud.google.com</a><br>
                        2. Cr&eacute;ez un projet ou s&eacute;lectionnez un existant<br>
                        3. Activez l&#039;API &laquo; Google Search Console API &raquo;<br>
                        4. Cr&eacute;ez un identifiant OAuth 2.0 (type: application Web)<br>
                        5. URI de redirection autoris&eacute;e : <code style="background:var(--hts-border-sub);padding:1px 4px;border-radius:3px;font-size:10px;"><?php echo esc_html( admin_url( 'admin.php?page=hts-seo-settings' ) ); ?></code><br>
                        6. Copiez Client ID et Client Secret ici
                    </div>
                </details>
                <?php endif; ?>

                <?php endif; ?>

                <div id="hts-gsc-feedback" style="margin-top:8px;"></div>
            </div>
        </div>

        <script>
        (function(){
            var nonce = '<?php echo esc_js( $gsc_nonce ); ?>';
            var isProxy = <?php echo $gsc_proxy ? 'true' : 'false'; ?>;

            /* ── PROXY CONNECT (1 clic) ── */
            window.htsGscProxyConnect = function() {
                var btn = document.getElementById('hts-gsc-connect-btn');
                var msg = document.getElementById('hts-gsc-status-msg');
                btn.disabled = true;
                msg.textContent = 'Connexion en cours...';
                msg.style.color = 'var(--hts-text-3)';

                var fd = new FormData();
                fd.append('action', 'hts_gsc_connect');
                fd.append('nonce', nonce);

                fetch(ajaxurl, {method:'POST', body:fd}).then(function(r){return r.json();}).then(function(r){
                    if (r.success && r.data.redirect) {
                        msg.textContent = 'Redirection vers Google...';
                        window.location.href = r.data.redirect;
                    } else {
                        msg.textContent = r.data.message || 'Erreur de connexion';
                        msg.style.color = 'var(--hts-danger)';
                        btn.disabled = false;
                    }
                }).catch(function() {
                    msg.textContent = 'Erreur r\u00e9seau';
                    msg.style.color = 'var(--hts-danger)';
                    btn.disabled = false;
                });
            };

            /* ── DIRECT CONNECT (save keys + OAuth) ── */
            window.htsGscSaveAndConnect = function() {
                var btn = document.getElementById('hts-gsc-connect-btn');
                var msg = document.getElementById('hts-gsc-status-msg');
                var cid = document.getElementById('hts-gsc-client-id').value.trim();
                var csc = document.getElementById('hts-gsc-client-secret').value.trim();

                if (!cid || !csc) { msg.textContent = 'Remplissez les deux champs.'; msg.style.color = 'var(--hts-danger)'; return; }

                btn.disabled = true;
                msg.textContent = 'Enregistrement...';
                msg.style.color = 'var(--hts-text-3)';

                var fd = new FormData();
                fd.append('action', 'hts_gsc_save_keys');
                fd.append('nonce', nonce);
                fd.append('client_id', cid);
                fd.append('client_secret', csc);

                fetch(ajaxurl, {method:'POST', body:fd}).then(function(r){return r.json();}).then(function(r){
                    if (!r.success) { msg.textContent = r.data.message || 'Erreur'; msg.style.color = 'var(--hts-danger)'; btn.disabled = false; return; }

                    msg.textContent = 'Redirection vers Google...';
                    var fd2 = new FormData();
                    fd2.append('action', 'hts_gsc_connect');
                    fd2.append('nonce', nonce);

                    fetch(ajaxurl, {method:'POST', body:fd2}).then(function(r){return r.json();}).then(function(r){
                        if (r.success && r.data.redirect) {
                            window.location.href = r.data.redirect;
                        } else {
                            msg.textContent = r.data.message || 'Erreur OAuth';
                            msg.style.color = 'var(--hts-danger)';
                            btn.disabled = false;
                        }
                    });
                });
            };

            /* ── DISCONNECT ── */
            window.htsGscDisconnect = function() {
                _htsConfirm('D\u00e9connecter Google Search Console ?','Les donn\u00e9es seront conserv\u00e9es. Vous pourrez reconnecter plus tard.','D\u00e9connecter','danger').then(function(ok){
                if (!ok) return;
                var fd = new FormData();
                fd.append('action', 'hts_gsc_disconnect');
                fd.append('nonce', nonce);
                fetch(ajaxurl, {method:'POST', body:fd}).then(function(r){return r.json();}).then(function(){
                    location.reload();
                });
                });
            };

            /* ── FETCH NOW ── */
            window.htsGscFetchNow = function() {
                var btn = document.getElementById('hts-gsc-fetch-btn');
                var fb  = document.getElementById('hts-gsc-feedback');
                btn.disabled = true;
                btn.textContent = 'Synchronisation...';
                fb.innerHTML = '';

                var fd = new FormData();
                fd.append('action', 'hts_gsc_fetch_now');
                fd.append('nonce', nonce);

                fetch(ajaxurl, {method:'POST', body:fd}).then(function(r){return r.json();}).then(function(r){
                    btn.disabled = false;
                    btn.textContent = 'Synchroniser maintenant';
                    if (r.success) {
                        fb.innerHTML = '<span style="color:var(--hts-success);font-size:11px;font-weight:600;">\u2705 ' + r.data.message + '</span>';
                    } else {
                        fb.innerHTML = '<span style="color:var(--hts-danger);font-size:11px;">\u274c ' + (r.data.message || 'Erreur') + '</span>';
                    }
                });
            };

            /* ── LIST SITES ── */
            window.htsGscListSites = function() {
                var btn = document.getElementById('hts-gsc-list-btn');
                var box = document.getElementById('hts-gsc-sites-list');
                btn.disabled = true;
                btn.textContent = 'Chargement...';

                var fd = new FormData();
                fd.append('action', 'hts_gsc_list_sites');
                fd.append('nonce', nonce);

                fetch(ajaxurl, {method:'POST', body:fd}).then(function(r){return r.json();}).then(function(r){
                    btn.disabled = false;
                    btn.textContent = 'Charger la liste des sites';
                    if (!r.success) { box.innerHTML = '<span style="color:var(--hts-danger);font-size:11px;">' + (r.data.message || 'Erreur') + '</span>'; return; }

                    var sites = r.data.sites || [];
                    var autoMatch = r.data.auto_match || '';
                    if (!sites.length) { box.innerHTML = '<span style="font-size:11px;color:var(--hts-caution);">Aucun site v\u00e9rifi\u00e9 trouv\u00e9. V\u00e9rifiez votre Search Console.</span>'; return; }

                    // Auto-select si match trouvé
                    if (autoMatch) {
                        box.innerHTML = '<span style="font-size:11px;color:var(--hts-success);">\u2705 Site d\u00e9tect\u00e9 automatiquement : <strong>' + autoMatch + '</strong></span>';
                        htsGscSelectSite(autoMatch);
                        return;
                    }

                    // Sinon afficher la liste
                    var html = '<div style="font-size:11px;color:var(--hts-caution);margin-bottom:6px;">Plusieurs sites trouv\u00e9s. Choisissez celui qui correspond \u00e0 ce WordPress :</div>';
                    sites.forEach(function(s) {
                        html += '<button type="button" class="hts-btn hts-btn--sm hts-btn--ghost" style="margin:2px 4px 2px 0;font-size:11px;" onclick="htsGscSelectSite(\'' + s.url.replace(/'/g, "\\'") + '\')">' + s.url + '</button>';
                    });
                    box.innerHTML = html;
                });
            };

            /* ── SELECT SITE ── */
            window.htsGscSelectSite = function(url) {
                var box = document.getElementById('hts-gsc-sites-list');
                if (box) box.innerHTML = '<span style="font-size:11px;color:var(--hts-text-3);">S\u00e9lection de ' + url + '...</span>';

                var fd = new FormData();
                fd.append('action', 'hts_gsc_select_site');
                fd.append('nonce', nonce);
                fd.append('site_url', url);
                fetch(ajaxurl, {method:'POST', body:fd}).then(function(r){return r.json();}).then(function(r){
                    if (!r.success) {
                        if (box) box.innerHTML = '<span style="color:var(--hts-danger);font-size:11px;">\u274c ' + (r.data.message || 'Erreur') + '</span>';
                        return;
                    }
                    // Auto-fetch data after selecting site
                    if (box) box.innerHTML = '<span style="font-size:11px;color:var(--hts-success);">\u2705 Site s\u00e9lectionn\u00e9. Import des donn\u00e9es en cours...</span>';
                    var fd2 = new FormData();
                    fd2.append('action', 'hts_gsc_fetch_now');
                    fd2.append('nonce', nonce);
                    fetch(ajaxurl, {method:'POST', body:fd2}).then(function(r2){return r2.json();}).then(function(r2){
                        if (r2.success) {
                            if (box) box.innerHTML = '<span style="font-size:11px;color:var(--hts-success);">\u2705 ' + r2.data.message + '</span>';
                        }
                        setTimeout(function(){ location.reload(); }, 1500);
                    }).catch(function(){
                        location.reload();
                    });
                }).catch(function(){
                    if (box) box.innerHTML = '<span style="color:var(--hts-danger);font-size:11px;">\u274c Erreur r\u00e9seau</span>';
                });
            };
        })();
        </script>

        <!-- ═══ NOTIFICATIONS ═══ -->
        <?php if ( empty( $hts_embedded_seo ) ) : // Notifications handled by unified settings tab ?>
        <?php
        $notif_settings = get_option( 'hts_notif_settings', array() );
        $notif_freq     = $notif_settings['frequency'] ?? 'weekly';
        $notif_sections = $notif_settings['sections'] ?? array( 'wins' => '1', 'alerts' => '1', 'kpis' => '1', 'gsc' => '1' );
        ?>
        <div class="hts-card hts-mt-5">
            <div class="hts-card-header">
                <h2 class="hts-ds-card__title">📧 Rapport par email</h2>
            </div>
            <div class="hts-card-body">
                <p style="font-size:12px;color:var(--hts-text-3);margin:0 0 16px;">
                    Recevez un récapitulatif de vos performances SEO avec les succès, les alertes et les KPI.
                </p>

                <!-- Email destinataire -->
                <div style="margin-bottom:16px;">
                    <label style="display:block;font-size:13px;font-weight:600;color:var(--hts-text-1);margin-bottom:6px;">Adresse email de réception</label>
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <input type="email" id="hts-notif-email" value="<?php echo esc_attr( get_option( 'hts_notif_email', get_option( 'admin_email' ) ) ); ?>" placeholder="votre@email.com" style="flex:1;min-width:220px;padding:8px 12px;border:1px solid var(--hts-border);border-radius:8px;font-size:13px;">
                        <span style="font-size:11px;color:var(--hts-text-3);">Par défaut : <?php echo esc_html( get_option( 'admin_email' ) ); ?></span>
                    </div>
                </div>

                <!-- Fréquence -->
                <div style="margin-bottom:16px;">
                    <label style="display:block;font-size:13px;font-weight:600;color:var(--hts-text-1);margin-bottom:8px;">Fréquence d'envoi</label>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <?php
                        $freq_options = array(
                            'weekly'    => 'Chaque semaine (lundi)',
                            'biweekly'  => 'Toutes les 2 semaines',
                            'monthly'   => 'Chaque mois (1er lundi)',
                        );
                        foreach ( $freq_options as $val => $label ) : ?>
                        <label style="display:flex;align-items:center;gap:6px;padding:8px 14px;border-radius:8px;border:1px solid <?php echo $notif_freq === $val ? 'var(--hts-primary)' : 'var(--hts-border)'; ?>;background:<?php echo $notif_freq === $val ? 'var(--hts-primary-bg, var(--hts-geo-soft))' : '#fff'; ?>;cursor:pointer;font-size:12px;transition:all .2s;">
                            <input type="radio" name="hts_notif_freq" value="<?php echo esc_attr( $val ); ?>" <?php checked( $notif_freq, $val ); ?> style="accent-color:var(--hts-primary);">
                            <?php echo esc_html( $label ); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Sections à inclure -->
                <div style="margin-bottom:16px;">
                    <label style="display:block;font-size:13px;font-weight:600;color:var(--hts-text-1);margin-bottom:8px;">Contenu du rapport</label>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                        <?php
                        $section_options = array(
                            'wins'   => array( '🎉', 'Succès et félicitations', 'Milestones de trafic, pages en top 10, score en hausse…' ),
                            'alerts' => array( '⚠️', 'Alertes et actions', 'Erreurs 404, baisse de position, score en chute, contenu périmé…' ),
                            'kpis'   => array( '📊', 'KPI de la semaine', 'Visites IA, visites totales, score SEO moyen, taux de rebond…' ),
                            'gsc'    => array( '🔍', 'Google Search Console', 'Clics, impressions, position moyenne, CTR, top pages…' ),
                        );
                        foreach ( $section_options as $key => $sec ) :
                            $checked = ( $notif_sections[ $key ] ?? '1' ) === '1';
                        ?>
                        <label class="hts-notif-section-toggle" style="display:flex;gap:10px;padding:10px 12px;border-radius:8px;border:1px solid <?php echo $checked ? 'var(--hts-primary)' : 'var(--hts-border)'; ?>;background:<?php echo $checked ? 'var(--hts-primary-bg, var(--hts-geo-soft))' : '#fff'; ?>;cursor:pointer;transition:all .2s;">
                            <input type="checkbox" name="hts_notif_section_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $checked ); ?> style="accent-color:var(--hts-primary);margin-top:2px;">
                            <div>
                                <div style="font-size:13px;font-weight:600;color:var(--hts-text-1);"><?php echo $sec[0] . ' ' . esc_html( $sec[1] ); ?></div>
                                <div style="font-size:11px;color:var(--hts-text-3);margin-top:2px;"><?php echo esc_html( $sec[2] ); ?></div>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Actions -->
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <button type="button" class="hts-btn hts-btn--sm" id="hts-notif-test-btn" onclick="htsTestDigest()">
                        📨 Envoyer un test
                    </button>
                    <button type="button" class="hts-btn hts-btn--sm hts-btn--outline" id="hts-notif-preview-btn" onclick="htsPreviewDigest()">
                        👁 Prévisualiser
                    </button>
                    <span id="hts-notif-test-msg" style="font-size:11px;color:var(--hts-text-3);"></span>
                </div>

                <!-- Preview modal (inline, no popup blocker issues) -->
                <div id="hts-notif-preview-modal" style="display:none;margin-top:16px;border:1px solid var(--hts-border);border-radius:12px;overflow:hidden;background:var(--hts-surface);">
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 14px;background:var(--hts-surface);border-bottom:1px solid var(--hts-border);">
                        <span style="font-size:12px;font-weight:600;color:var(--hts-text-2);">Aperçu du rapport</span>
                        <button type="button" onclick="document.getElementById('hts-notif-preview-modal').style.display='none'" style="border:none;background:none;cursor:pointer;font-size:16px;color:var(--hts-text-3);">✕</button>
                    </div>
                    <iframe id="hts-notif-preview-iframe" style="width:100%;height:600px;border:none;"></iframe>
                </div>

                <script>
                function htsTestDigest() {
                    var btn = document.getElementById('hts-notif-test-btn');
                    var msg = document.getElementById('hts-notif-test-msg');
                    var emailInput = document.getElementById('hts-notif-email');
                    var email = emailInput ? emailInput.value.trim() : '';
                    if (!email) {
                        msg.textContent = '❌ Saisissez une adresse email';
                        msg.style.color = 'var(--hts-danger)';
                        if (emailInput) emailInput.focus();
                        return;
                    }
                    btn.disabled = true;
                    msg.textContent = 'Envoi à ' + email + '…';
                    msg.style.color = 'var(--hts-text-3)';
                    var fd = new FormData();
                    fd.append('action', 'hts_send_test_digest');
                    fd.append('nonce', htsAdmin.nonce);
                    fd.append('email', email);
                    fetch(htsAdmin.ajaxUrl, { method: 'POST', body: fd })
                        .then(function(r) { return r.json(); })
                        .then(function(r) {
                            btn.disabled = false;
                            if (r.success && r.data.sent) {
                                msg.textContent = '✅ Email envoyé à ' + email + ' ! Vérifiez votre boîte.';
                                msg.style.color = 'var(--hts-success)';
                            } else {
                                var errMsg = (r.data && r.data.message) ? r.data.message : 'Vérifiez la configuration email du serveur.';
                                msg.textContent = '❌ ' + errMsg;
                                msg.style.color = 'var(--hts-danger)';
                            }
                        })
                        .catch(function(err) {
                            btn.disabled = false;
                            msg.textContent = '❌ Erreur réseau — ' + (err.message || 'vérifiez la console');
                            msg.style.color = 'var(--hts-danger)';
                        });
                }
                function htsPreviewDigest() {
                    var btn = document.getElementById('hts-notif-preview-btn');
                    var msg = document.getElementById('hts-notif-test-msg');
                    btn.disabled = true;
                    btn.textContent = '⏳ Génération…';
                    msg.textContent = '';
                    var fd = new FormData();
                    fd.append('action', 'hts_preview_digest');
                    fd.append('nonce', htsAdmin.nonce);
                    fetch(htsAdmin.ajaxUrl, { method: 'POST', body: fd })
                        .then(function(r) { return r.json(); })
                        .then(function(r) {
                            btn.disabled = false;
                            btn.textContent = '👁 Prévisualiser';
                            if (r.success && r.data.html) {
                                var modal = document.getElementById('hts-notif-preview-modal');
                                var iframe = document.getElementById('hts-notif-preview-iframe');
                                modal.style.display = 'block';
                                iframe.srcdoc = r.data.html;
                                modal.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            } else {
                                var errMsg = (r.data && r.data.message) ? r.data.message : 'Erreur inconnue';
                                msg.textContent = '❌ ' + errMsg;
                                msg.style.color = 'var(--hts-danger)';
                            }
                        })
                        .catch(function(err) {
                            btn.disabled = false;
                            btn.textContent = '👁 Prévisualiser';
                            msg.textContent = '❌ Erreur réseau — ' + (err.message || 'vérifiez la console');
                            msg.style.color = 'var(--hts-danger)';
                        });
                }
                // Toggle visual styling on section checkboxes
                document.querySelectorAll('.hts-notif-section-toggle input[type="checkbox"]').forEach(function(cb) {
                    cb.addEventListener('change', function() {
                        var label = this.closest('.hts-notif-section-toggle');
                        if (this.checked) {
                            label.style.borderColor = 'var(--hts-primary)';
                            label.style.background = 'var(--hts-primary-bg, var(--hts-geo-soft))';
                        } else {
                            label.style.borderColor = 'var(--hts-border)';
                            label.style.background = '#fff';
                        }
                    });
                });
                // Toggle visual styling on frequency radios
                document.querySelectorAll('input[name="hts_notif_freq"]').forEach(function(radio) {
                    radio.addEventListener('change', function() {
                        document.querySelectorAll('input[name="hts_notif_freq"]').forEach(function(r) {
                            var lbl = r.closest('label');
                            if (r.checked) {
                                lbl.style.borderColor = 'var(--hts-primary)';
                                lbl.style.background = 'var(--hts-primary-bg, var(--hts-geo-soft))';
                            } else {
                                lbl.style.borderColor = 'var(--hts-border)';
                                lbl.style.background = '#fff';
                            }
                        });
                    });
                });
                </script>
            </div>
        </div>
        <?php endif; // end embedded_seo notifications check ?>


        <!-- SAVE -->
        <div class="hts-save-bar">
            <button type="submit" class="hts-btn hts-btn--primary hts-btn--lg" id="hts-seo-save">
                <span class="hts-spinner"></span>
                <span class="hts-btn-label">Enregistrer les réglages SEO</span>
            </button>
            <span id="hts-seo-saved-msg" class="hts-save-msg hts-hidden">
 Réglages sauvegardés
            </span>
        </div>

    </form>

</div>

<?php if ( empty( $hts_embedded_seo ) ) : ?>
<?php echo HTS_DS::footer(); ?>
<?php echo HTS_DS::page_close(); ?>
<?php endif; ?>
