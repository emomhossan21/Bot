<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Cannibalization Detector — Phase 6c
 *
 * Détecte les paires de pages en cannibalisation SEO via 3 méthodes :
 * - Embeddings (similarité sémantique > seuil)
 * - Focus keywords identiques/proches
 * - Titres trop similaires (Jaccard)
 *
 * Calcule un score 0-100 par paire et recommande : merge, redirect, ou garder.
 *
 * @package    Hack_The_SEO
 * @since      1.26.0
 */

if ( ! defined( 'WPINC' ) ) die;

class HTS_Cannibalization {

    /** Option key for stored pairs */
    const PAIRS_OPTION = 'hts_cannibal_pairs';

    /** Thresholds */
    const EMB_THRESHOLD_HIGH   = 0.90; // Cosine > this = strong cannibal
    const EMB_THRESHOLD_MEDIUM = 0.82; // Cosine > this = possible cannibal
    const JACCARD_THRESHOLD    = 0.65; // Title Jaccard > this = suspicious
    const SCORE_CRITICAL       = 80;
    const SCORE_WARNING        = 50;

    /** Option key for stored groups */
    const GROUPS_OPTION = 'hts_cannibal_groups';

    /** Groups with more pages than this will be split into sub-clusters */
    const SUBCLUSTER_THRESHOLD = 15;

    public function init() {
        add_action( 'wp_ajax_hts_cannibal_scan',         array( $this, 'ajax_scan' ) );
        add_action( 'wp_ajax_hts_cannibal_get_pairs',    array( $this, 'ajax_get_pairs' ) );
        add_action( 'wp_ajax_hts_cannibal_get_groups',   array( $this, 'ajax_get_groups' ) );
        add_action( 'wp_ajax_hts_cannibal_action',       array( $this, 'ajax_action' ) );
        add_action( 'wp_ajax_hts_cannibal_group_action', array( $this, 'ajax_group_action' ) );
        add_action( 'wp_ajax_hts_cannibal_dismiss',      array( $this, 'ajax_dismiss' ) );

        // Workflow engine integration: handle cannibal_redirect and cannibal_merge dispatch
        add_filter( 'hts_workflow_dispatch', array( $this, 'handle_workflow_dispatch' ), 10, 5 );
    }

    /**
     * Handle workflow dispatch for cannibal actions.
     *
     * @param bool|null $result
     * @param string    $agent
     * @param string    $type
     * @param int       $post_id   The loser post ID
     * @param array     $data      Contains pillar_id, group_keyword, etc.
     * @return bool|null
     */
    public function handle_workflow_dispatch( $result, $agent, $type, $post_id, $data ) {
        if ( $agent !== 'cannibalization' ) return $result;

        if ( $type === 'cannibal_redirect' ) {
            return $this->dispatch_cannibal_redirect( $post_id, $data );
        }

        if ( $type === 'cannibal_merge' ) {
            return $this->dispatch_cannibal_merge( $post_id, $data );
        }

        return $result;
    }

    /**
     * Execute a cannibal redirect: create 301 from loser to pillar.
     *
     * @param int   $post_id  Loser post ID
     * @param array $data     Must contain 'pillar_id'
     * @return bool
     */
    private function dispatch_cannibal_redirect( $post_id, $data ) {
        $pillar_id = (int) ( $data['pillar_id'] ?? 0 );
        if ( ! $pillar_id || ! get_post( $post_id ) || ! get_post( $pillar_id ) ) return false;

        if ( class_exists( 'HTS_Redirects' ) ) {
            $from = wp_make_link_relative( get_permalink( $post_id ) );
            $to   = get_permalink( $pillar_id );
            $redirects = new HTS_Redirects();
            if ( method_exists( $redirects, 'add_redirect' ) ) {
                $redirects->add_redirect( $from, $to, 301 );
            }
        }

        // Update pair status
        $this->update_pair_status( $pillar_id, $post_id, 'redirected', array(
            'type'   => 'redirect',
            'winner' => $pillar_id,
            'loser'  => $post_id,
            'date'   => current_time( 'Y-m-d H:i:s' ),
            'via'    => 'workflow_drip',
        ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( '↪️ Redirection drip : #%d → #%d (%s)', $post_id, $pillar_id, get_the_title( $pillar_id ) ),
                'success', 'cannibalization'
            );
        }

        return true;
    }

    /**
     * Execute a cannibal merge: placeholder for IA merge.
     * Currently just marks as merge_pending and logs.
     *
     * @param int   $post_id  Loser post ID
     * @param array $data     Must contain 'pillar_id'
     * @return bool
     */
    private function dispatch_cannibal_merge( $post_id, $data ) {
        $pillar_id = (int) ( $data['pillar_id'] ?? 0 );
        if ( ! $pillar_id || ! get_post( $post_id ) ) return false;

        // Update pair status
        $this->update_pair_status( $pillar_id, $post_id, 'merge_pending', array(
            'type'   => 'merge',
            'winner' => $pillar_id,
            'loser'  => $post_id,
            'date'   => current_time( 'Y-m-d H:i:s' ),
            'via'    => 'workflow_drip',
        ) );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                sprintf( '🔀 Merge planifié (drip) : #%d ← #%d', $pillar_id, $post_id ),
                'info', 'cannibalization'
            );
        }

        // TODO P4c: Call content-writer API to merge loser content into pillar
        return true;
    }

    /* =========================================================================
     * DETECTION — 3 layers
     * ====================================================================== */

    /**
     * Run full cannibalization scan.
     * Combines 3 detection methods, deduplicates, scores each pair.
     *
     * @return array [ pairs[], stats ]
     */
    public function run_scan() {
        $pairs = array();

        // Layer 1: Embeddings (semantic similarity)
        $emb_pairs = $this->detect_by_embeddings();
        foreach ( $emb_pairs as $p ) {
            $key = $this->pair_key( $p['post_a'], $p['post_b'] );
            $pairs[ $key ] = $p;
        }

        // Layer 2: Focus keywords
        $kw_pairs = $this->detect_by_keywords();
        foreach ( $kw_pairs as $p ) {
            $key = $this->pair_key( $p['post_a'], $p['post_b'] );
            if ( isset( $pairs[ $key ] ) ) {
                // Merge methods
                $pairs[ $key ]['methods'][] = 'keyword';
                $pairs[ $key ]['keyword_match'] = $p['keyword_match'] ?? '';
            } else {
                $pairs[ $key ] = $p;
            }
        }

        // Layer 3: Title similarity
        $title_pairs = $this->detect_by_titles();
        foreach ( $title_pairs as $p ) {
            $key = $this->pair_key( $p['post_a'], $p['post_b'] );
            if ( isset( $pairs[ $key ] ) ) {
                $pairs[ $key ]['methods'][] = 'title';
                $pairs[ $key ]['title_similarity'] = $p['title_similarity'] ?? 0;
            } else {
                $pairs[ $key ] = $p;
            }
        }

        // Score each pair
        foreach ( $pairs as &$pair ) {
            $pair['score'] = $this->calculate_cannibal_score( $pair );
            $pair['recommendation'] = $this->recommend_action( $pair );
        }
        unset( $pair );

        // ── MERGE with existing data ──
        // Strategy: keep ALL existing pairs, update re-detected ones, add new ones
        $existing = get_option( self::PAIRS_OPTION, array() );
        $existing_pairs = $existing['pairs'] ?? array();

        // Index existing by key
        $existing_by_key = array();
        foreach ( $existing_pairs as $ep ) {
            $ek = $this->pair_key( $ep['post_a'], $ep['post_b'] );
            $existing_by_key[ $ek ] = $ep;
        }

        // Build final set: start with all existing, then overlay new detections
        $final = $existing_by_key;

        foreach ( $pairs as $key => $new_pair ) {
            if ( isset( $final[ $key ] ) ) {
                $old = $final[ $key ];
                // Update detection data (score, methods, cosine) with fresh scan
                $new_pair['status']       = $old['status'] ?? 'active';
                $new_pair['action_taken'] = $old['action_taken'] ?? null;
                $final[ $key ] = $new_pair;
            } else {
                // Brand new pair
                $new_pair['status'] = 'active';
                $final[ $key ] = $new_pair;
            }
        }

        // Sort by score desc
        uasort( $final, function( $a, $b ) { return ( $b['score'] ?? 0 ) - ( $a['score'] ?? 0 ); } );

        // Store
        $result = array(
            'pairs'      => array_values( $final ),
            'total'      => count( $final ),
            'critical'   => count( array_filter( $final, function( $p ) { return ( $p['score'] ?? 0 ) >= self::SCORE_CRITICAL; } ) ),
            'warning'    => count( array_filter( $final, function( $p ) { return ( $p['score'] ?? 0 ) >= self::SCORE_WARNING && ( $p['score'] ?? 0 ) < self::SCORE_CRITICAL; } ) ),
            'scanned_at' => current_time( 'Y-m-d H:i:s' ),
        );

        update_option( self::PAIRS_OPTION, $result, false );

        // ── BUILD GROUPS (Union-Find clustering) ──
        $groups = $this->build_groups( array_values( $final ) );
        $groups_data = array(
            'groups'       => $groups,
            'total_groups' => count( $groups ),
            'total_pages'  => array_sum( array_column( $groups, 'page_count' ) ),
            'scanned_at'   => current_time( 'Y-m-d H:i:s' ),
        );
        update_option( self::GROUPS_OPTION, $groups_data, false );

        if ( function_exists( 'hts_add_log' ) ) {
            $new_count = count( $pairs ) - count( array_intersect_key( $pairs, $existing_by_key ) );
            hts_add_log(
                sprintf( 'Scan cannibalisation : %d paire(s) total (%d nouvelles, %d critiques, %d attention) → %d groupe(s)',
                    $result['total'], max( 0, $new_count ), $result['critical'], $result['warning'], count( $groups ) ),
                $result['critical'] > 0 ? 'warning' : 'success', 'cannibalization'
            );
        }

        return $result;
    }

    /**
     * Layer 1: Detect by embeddings cosine similarity.
     * Finds pages that are semantically too similar.
     */
    public function detect_by_embeddings() {
        $pairs = array();
        if ( ! class_exists( 'HTS_Embeddings' ) ) return $pairs;

        $emb = new HTS_Embeddings();
        $vectors = $emb->load_all_vectors( true );
        if ( count( $vectors ) < 2 ) return $pairs;

        // ── Filtrer par langue (Polylang/WPML) : ne comparer que des articles de la même langue ──
        $is_multilingual = class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual();
        $post_langs = array();
        if ( $is_multilingual ) {
            foreach ( array_keys( $vectors ) as $pid ) {
                $post_langs[ $pid ] = HTS_Language::get_post_language( (int) $pid );
            }
        }

        $post_ids = array_keys( $vectors );
        $count    = count( $post_ids );

        // Pre-load titles and permalinks to avoid N queries inside O(n²) loop
        $title_cache = array();
        $url_cache   = array();
        foreach ( $post_ids as $pid ) {
            $title_cache[ $pid ] = get_the_title( $pid );
            $url_cache[ $pid ]   = get_permalink( $pid );
        }

        for ( $i = 0; $i < $count; $i++ ) {
            for ( $j = $i + 1; $j < $count; $j++ ) {
                $pid_a = $post_ids[ $i ];
                $pid_b = $post_ids[ $j ];

                // Skip cross-language pairs (a translation is not cannibalization)
                if ( $is_multilingual ) {
                    $lang_a = $post_langs[ $pid_a ] ?? '';
                    $lang_b = $post_langs[ $pid_b ] ?? '';
                    if ( $lang_a && $lang_b && $lang_a !== $lang_b ) continue;
                }

                $sim = HTS_Embeddings::cosine_similarity( $vectors[ $pid_a ], $vectors[ $pid_b ] );

                if ( $sim >= self::EMB_THRESHOLD_MEDIUM ) {
                    $pairs[] = array(
                        'post_a'          => $pid_a,
                        'post_b'          => $pid_b,
                        'title_a'         => $title_cache[ $pid_a ],
                        'title_b'         => $title_cache[ $pid_b ],
                        'url_a'           => $url_cache[ $pid_a ],
                        'url_b'           => $url_cache[ $pid_b ],
                        'cosine'          => round( $sim, 3 ),
                        'methods'         => array( 'embeddings' ),
                        'keyword_match'   => '',
                        'title_similarity' => 0,
                    );
                }
            }
        }

        return $pairs;
    }

    /**
     * Layer 2: Detect by identical/overlapping focus keywords.
     * Two published pages targeting the same keyword = cannibal.
     */
    public function detect_by_keywords() {
        $pairs = array();

        // Collect all focus keywords
        $posts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => 500,
        ) );

        $is_multilingual = class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual();

        $kw_map = array(); // keyword => [ post_ids ]
        foreach ( $posts as $p ) {
            $kw = get_post_meta( $p->ID, '_hts_focus_keyword', true );
            if ( ! $kw ) $kw = get_post_meta( $p->ID, 'rank_math_focus_keyword', true );
            if ( ! $kw ) $kw = get_post_meta( $p->ID, '_yoast_wpseo_focuskw', true );
            if ( empty( $kw ) ) continue;

            $normalized = mb_strtolower( trim( $kw ) );
            // On multilingue, grouper par langue+keyword pour ne pas mélanger
            if ( $is_multilingual ) {
                $lang = HTS_Language::get_post_language( $p->ID );
                $normalized = $lang . ':' . $normalized;
            }
            $kw_map[ $normalized ][] = $p->ID;
        }

        // Find duplicates
        foreach ( $kw_map as $kw => $pids ) {
            if ( count( $pids ) < 2 ) continue;

            // Nettoyer le préfixe langue pour le display
            $display_kw = $is_multilingual ? preg_replace( '/^[a-z]{2}:/', '', $kw ) : $kw;

            // Generate pairs for all combinations
            for ( $i = 0; $i < count( $pids ); $i++ ) {
                for ( $j = $i + 1; $j < count( $pids ); $j++ ) {
                    $pairs[] = array(
                        'post_a'          => $pids[ $i ],
                        'post_b'          => $pids[ $j ],
                        'title_a'         => get_the_title( $pids[ $i ] ),
                        'title_b'         => get_the_title( $pids[ $j ] ),
                        'url_a'           => get_permalink( $pids[ $i ] ),
                        'url_b'           => get_permalink( $pids[ $j ] ),
                        'cosine'          => 0,
                        'methods'         => array( 'keyword' ),
                        'keyword_match'   => $display_kw,
                        'title_similarity' => 0,
                    );
                }
            }
        }

        return $pairs;
    }

    /**
     * Layer 3: Detect by title similarity (Jaccard index).
     * Titles that share too many words = likely cannibal.
     */
    public function detect_by_titles() {
        $pairs = array();

        $posts = get_posts( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => 500,
        ) );

        $is_multilingual = class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual();

        // Pre-load languages to avoid N² calls to get_post_language()
        $lang_cache = array();
        if ( $is_multilingual ) {
            foreach ( $posts as $p ) {
                $lang_cache[ $p->ID ] = HTS_Language::get_post_language( $p->ID );
            }
        }

        $count = count( $posts );
        for ( $i = 0; $i < $count; $i++ ) {
            $words_a = $this->title_words( $posts[ $i ]->post_title );
            if ( count( $words_a ) < 3 ) continue; // Skip very short titles

            for ( $j = $i + 1; $j < $count; $j++ ) {
                // Skip cross-language pairs
                if ( $is_multilingual ) {
                    $lang_a = $lang_cache[ $posts[ $i ]->ID ] ?? '';
                    $lang_b = $lang_cache[ $posts[ $j ]->ID ] ?? '';
                    if ( $lang_a && $lang_b && $lang_a !== $lang_b ) continue;
                }

                $words_b = $this->title_words( $posts[ $j ]->post_title );
                if ( count( $words_b ) < 3 ) continue;

                $sim = $this->jaccard( $words_a, $words_b );
                if ( $sim >= self::JACCARD_THRESHOLD ) {
                    $pairs[] = array(
                        'post_a'          => $posts[ $i ]->ID,
                        'post_b'          => $posts[ $j ]->ID,
                        'title_a'         => $posts[ $i ]->post_title,
                        'title_b'         => $posts[ $j ]->post_title,
                        'url_a'           => get_permalink( $posts[ $i ]->ID ),
                        'url_b'           => get_permalink( $posts[ $j ]->ID ),
                        'cosine'          => 0,
                        'methods'         => array( 'title' ),
                        'keyword_match'   => '',
                        'title_similarity' => round( $sim, 3 ),
                    );
                }
            }
        }

        return $pairs;
    }

    /* =========================================================================
     * SCORING
     * ====================================================================== */

    /**
     * Calculate cannibal score 0-100 for a pair.
     *
     * Factors:
     * - Number of detection methods (more methods = higher confidence)
     * - Cosine similarity (from embeddings)
     * - Keyword exact match bonus
     * - Title similarity
     * - Both published (vs draft)
     *
     * @param array $pair
     * @return int Score 0-100
     */
    public function calculate_cannibal_score( array $pair ) {
        $score = 0;

        // Methods count: detected by more methods = stronger signal
        $methods = $pair['methods'] ?? array();
        $score += count( $methods ) * 15; // 15 per method, max 45

        // Cosine similarity (0-40 points)
        $cosine = $pair['cosine'] ?? 0;
        if ( $cosine >= self::EMB_THRESHOLD_HIGH ) {
            $score += 40;
        } elseif ( $cosine >= 0.86 ) {
            // 0.86-0.90 = forte similarité
            $score += 35;
        } elseif ( $cosine >= self::EMB_THRESHOLD_MEDIUM ) {
            $score += (int) round( 25 * ( $cosine - self::EMB_THRESHOLD_MEDIUM ) / ( 0.86 - self::EMB_THRESHOLD_MEDIUM ) );
        }

        // Keyword exact match (0-20 points)
        if ( ! empty( $pair['keyword_match'] ) ) {
            $score += 20;
        }

        // Title similarity (0-15 points)
        $title_sim = $pair['title_similarity'] ?? 0;
        if ( $title_sim > 0 ) {
            $score += (int) round( 15 * $title_sim );
        }

        return min( 100, max( 0, $score ) );
    }

    /**
     * Recommend action based on pair analysis.
     *
     * @param array $pair
     * @return array { action, reason, details }
     */
    private function recommend_action( array $pair ) {
        $score  = $pair['score'] ?? 0;
        $cosine = $pair['cosine'] ?? 0;

        // Get GSC performance for each page
        $perf_a = $this->get_page_performance( $pair['post_a'] );
        $perf_b = $this->get_page_performance( $pair['post_b'] );

        // If one page clearly outperforms, recommend redirect the weaker
        if ( $perf_a && $perf_b ) {
            $score_a = ( $perf_a['clicks'] ?? 0 ) * 2 + ( $perf_a['impressions'] ?? 0 );
            $score_b = ( $perf_b['clicks'] ?? 0 ) * 2 + ( $perf_b['impressions'] ?? 0 );

            if ( $score_a > $score_b * 3 && $score >= self::SCORE_WARNING ) {
                return array(
                    'action'  => 'redirect',
                    'reason'  => sprintf(
                        'La page A performe nettement mieux (%d clics vs %d). Redirigez B vers A.',
                        $perf_a['clicks'] ?? 0, $perf_b['clicks'] ?? 0
                    ),
                    'winner'  => $pair['post_a'],
                    'loser'   => $pair['post_b'],
                );
            }

            if ( $score_b > $score_a * 3 && $score >= self::SCORE_WARNING ) {
                return array(
                    'action'  => 'redirect',
                    'reason'  => sprintf(
                        'La page B performe nettement mieux (%d clics vs %d). Redirigez A vers B.',
                        $perf_b['clicks'] ?? 0, $perf_a['clicks'] ?? 0
                    ),
                    'winner'  => $pair['post_b'],
                    'loser'   => $pair['post_a'],
                );
            }
        }

        // High score + high cosine = merge candidate
        if ( $score >= self::SCORE_CRITICAL && $cosine >= self::EMB_THRESHOLD_HIGH ) {
            return array(
                'action' => 'merge',
                'reason' => 'Contenu très similaire. Fusionnez les deux articles en un seul plus complet.',
                'winner' => ( $perf_a && $perf_b && ( $perf_a['clicks'] ?? 0 ) >= ( $perf_b['clicks'] ?? 0 ) )
                    ? $pair['post_a'] : $pair['post_b'],
                'loser'  => ( $perf_a && $perf_b && ( $perf_a['clicks'] ?? 0 ) >= ( $perf_b['clicks'] ?? 0 ) )
                    ? $pair['post_b'] : $pair['post_a'],
            );
        }

        // Medium score = differentiate
        if ( $score >= self::SCORE_WARNING ) {
            return array(
                'action' => 'differentiate',
                'reason' => 'Ces pages ciblent des sujets proches. Différenciez-les en précisant l\'angle unique de chacune.',
                'winner' => null,
                'loser'  => null,
            );
        }

        // Low score = keep both
        return array(
            'action' => 'keep',
            'reason' => 'Risque faible. Les pages sont suffisamment différenciées.',
            'winner' => null,
            'loser'  => null,
        );
    }

    /* =========================================================================
     * GROUPING — Union-Find + Cluster Builder
     * ====================================================================== */

    /**
     * Build cannibalization groups from pairs using Union-Find.
     *
     * Instead of showing 190 individual pairs for 20 "ai writer" pages,
     * groups them into a single actionable cluster:
     * "ai writer — 22 pages se cannibalisent → garder 1, traiter 21"
     *
     * @param array $pairs  All detected pairs
     * @return array Groups with pages, stats, and pillar recommendation
     */
    public function build_groups( array $pairs ) {
        if ( empty( $pairs ) ) return array();

        // ── Step 1: Union-Find to build connected components ──
        $parent = array();
        $rank   = array();

        // Initialize: each post_id is its own parent
        foreach ( $pairs as $pair ) {
            $a = (int) $pair['post_a'];
            $b = (int) $pair['post_b'];
            if ( ! isset( $parent[ $a ] ) ) { $parent[ $a ] = $a; $rank[ $a ] = 0; }
            if ( ! isset( $parent[ $b ] ) ) { $parent[ $b ] = $b; $rank[ $b ] = 0; }
        }

        // Only union pairs with score >= WARNING (skip noise)
        foreach ( $pairs as $pair ) {
            $score = $pair['score'] ?? 0;
            if ( $score < self::SCORE_WARNING ) continue;
            if ( in_array( $pair['status'] ?? '', array( 'dismissed', 'redirected' ), true ) ) continue;

            $this->uf_union( $parent, $rank, (int) $pair['post_a'], (int) $pair['post_b'] );
        }

        // ── Step 2: Collect components ──
        $components = array(); // root => [ post_ids ]
        foreach ( array_keys( $parent ) as $pid ) {
            $root = $this->uf_find( $parent, $pid );
            $components[ $root ][] = $pid;
        }

        // Filter: only groups with 2+ pages are interesting
        $components = array_filter( $components, function( $members ) {
            return count( $members ) >= 2;
        } );

        if ( empty( $components ) ) return array();

        // ── Step 3: Enrich each group ──
        // Index pairs by post for fast lookup
        $pairs_by_post = array();
        foreach ( $pairs as $pair ) {
            $pairs_by_post[ (int) $pair['post_a'] ][] = $pair;
            $pairs_by_post[ (int) $pair['post_b'] ][] = $pair;
        }

        $groups = array();
        $group_idx = 0;

        foreach ( $components as $root => $member_ids ) {
            $member_ids = array_unique( $member_ids );
            sort( $member_ids );

            // Collect all pairs within this group
            $group_pairs = array();
            $member_set = array_flip( $member_ids );
            $seen_pairs = array();
            foreach ( $member_ids as $pid ) {
                foreach ( ( $pairs_by_post[ $pid ] ?? array() ) as $pair ) {
                    $pkey = $this->pair_key( $pair['post_a'], $pair['post_b'] );
                    if ( isset( $seen_pairs[ $pkey ] ) ) continue;
                    // Only include pairs where both posts are in this group
                    if ( isset( $member_set[ (int) $pair['post_a'] ] ) && isset( $member_set[ (int) $pair['post_b'] ] ) ) {
                        $group_pairs[ $pkey ] = $pair;
                        $seen_pairs[ $pkey ] = true;
                    }
                }
            }

            // Compute group stats
            $scores = array_column( $group_pairs, 'score' );
            $avg_score = ! empty( $scores ) ? round( array_sum( $scores ) / count( $scores ) ) : 0;
            $max_score = ! empty( $scores ) ? max( $scores ) : 0;

            // Find common keyword(s) across pairs
            $kw_freq = array();
            foreach ( $group_pairs as $gp ) {
                $kw = $gp['keyword_match'] ?? '';
                if ( ! empty( $kw ) ) {
                    $kw_freq[ $kw ] = ( $kw_freq[ $kw ] ?? 0 ) + 1;
                }
            }
            arsort( $kw_freq );
            $common_keywords = array_keys( $kw_freq );
            $primary_keyword = ! empty( $common_keywords ) ? $common_keywords[0] : '';

            // If no keyword match, try to find common words in titles
            if ( empty( $primary_keyword ) ) {
                $primary_keyword = $this->find_common_title_theme( $member_ids );
            }

            // Build page details with enriched pillar signals
            $pages = array();
            foreach ( $member_ids as $pid ) {
                $post = get_post( $pid );
                if ( ! $post ) continue;

                $perf = $this->get_page_performance( $pid );
                $pages[] = array(
                    'post_id'        => $pid,
                    'title'          => get_the_title( $pid ),
                    'url'            => get_permalink( $pid ),
                    'clicks'         => (int) ( $perf['clicks'] ?? 0 ),
                    'impressions'    => (int) ( $perf['impressions'] ?? 0 ),
                    'avg_position'   => round( (float) ( $perf['avg_position'] ?? 0 ), 1 ),
                    'content_length' => mb_strlen( $post->post_content ?? '' ),
                    'in_links'       => $this->get_internal_links_in( $pid ),
                    'date'           => $post->post_date,
                    'status'         => $post->post_status,
                    'pillar_score'   => 0, // Will be calculated below
                );
            }

            // Calculate pillar score for each page (relative to group)
            foreach ( $pages as &$pg ) {
                $pg['pillar_score'] = $this->calculate_pillar_score( $pg, $pages );
            }
            unset( $pg );

            // Sort pages by pillar_score desc (enriched multi-signal ranking)
            usort( $pages, function( $a, $b ) {
                return $b['pillar_score'] - $a['pillar_score'];
            } );

            // Pillar = highest pillar_score page
            $pillar_id = ! empty( $pages ) ? $pages[0]['post_id'] : $member_ids[0];

            // Severity
            $severity = 'ok';
            if ( $max_score >= self::SCORE_CRITICAL ) $severity = 'critical';
            elseif ( $max_score >= self::SCORE_WARNING ) $severity = 'warning';

            $groups[] = array(
                'id'               => 'group_' . $group_idx,
                'keyword'          => $primary_keyword,
                'common_keywords'  => array_slice( $common_keywords, 0, 5 ),
                'pages'            => $pages,
                'page_count'       => count( $pages ),
                'pairs_count'      => count( $group_pairs ),
                'avg_score'        => $avg_score,
                'max_score'        => $max_score,
                'severity'         => $severity,
                'pillar_id'        => $pillar_id,
                'pillar_title'     => get_the_title( $pillar_id ),
                'advice'           => '', // Will be filled below
            );

            $group_idx++;
        }

        // ── Step 4: Sub-cluster large groups ──
        $split_groups = array();
        foreach ( $groups as $g ) {
            if ( $g['page_count'] > self::SUBCLUSTER_THRESHOLD ) {
                $subs = $this->split_large_group( $g, $pairs_by_post );
                foreach ( $subs as $sub ) {
                    $sub['id'] = 'group_' . $group_idx;
                    $group_idx++;
                    $split_groups[] = $sub;
                }
            } else {
                $split_groups[] = $g;
            }
        }
        $groups = $split_groups;

        // ── Step 5: Generate actionable advice for each group ──
        foreach ( $groups as &$g ) {
            $g['advice'] = $this->generate_group_advice( $g );
        }
        unset( $g );

        // Sort groups: critical first, then by page_count desc
        usort( $groups, function( $a, $b ) {
            $sev_order = array( 'critical' => 0, 'warning' => 1, 'ok' => 2 );
            $sa = $sev_order[ $a['severity'] ] ?? 2;
            $sb = $sev_order[ $b['severity'] ] ?? 2;
            if ( $sa !== $sb ) return $sa - $sb;
            return $b['page_count'] - $a['page_count'];
        } );

        return $groups;
    }

    /**
     * Find common theme from titles when no keyword match exists.
     */
    private function find_common_title_theme( array $post_ids ) {
        $all_words = array();
        foreach ( $post_ids as $pid ) {
            $words = $this->title_words( get_the_title( $pid ) );
            foreach ( $words as $w ) {
                $all_words[ $w ] = ( $all_words[ $w ] ?? 0 ) + 1;
            }
        }

        // Words that appear in >50% of titles
        $threshold = count( $post_ids ) * 0.5;
        $common = array_filter( $all_words, function( $count ) use ( $threshold ) {
            return $count >= $threshold;
        } );

        arsort( $common );
        $top = array_slice( array_keys( $common ), 0, 3 );
        return ! empty( $top ) ? implode( ' ', $top ) : '(thème commun)';
    }

    /**
     * Split a large group into thematic sub-clusters using title word similarity.
     *
     * For groups > SUBCLUSTER_THRESHOLD pages, re-clusters by Jaccard similarity
     * on title words with a higher threshold (0.30) to create tighter sub-groups.
     *
     * @param array $group       The original group data
     * @param array $pairs_by_post  Pairs indexed by post_id
     * @return array Sub-groups (same structure as a group)
     */
    private function split_large_group( array $group, array $pairs_by_post ) {
        $pages = $group['pages'] ?? array();
        if ( count( $pages ) <= self::SUBCLUSTER_THRESHOLD ) {
            return array( $group );
        }

        // Build title-word vectors for each page
        $page_words = array();
        foreach ( $pages as $pg ) {
            $page_words[ $pg['post_id'] ] = $this->title_words( $pg['title'] ?? '' );
        }

        // Greedy clustering: assign each page to the most similar existing cluster
        $clusters = array(); // [ [ 'centroid_words' => [...], 'all_words' => [...], 'pids' => [...] ] ]

        foreach ( $pages as $pg ) {
            $pid = $pg['post_id'];
            $words = $page_words[ $pid ] ?? array();
            if ( empty( $words ) ) {
                if ( empty( $clusters ) ) {
                    $clusters[] = array( 'centroid_words' => $words, 'all_words' => array(), 'pids' => array( $pid ) );
                } else {
                    $clusters[0]['pids'][] = $pid;
                }
                continue;
            }

            $best_idx = -1;
            $best_sim = 0;

            foreach ( $clusters as $idx => $cl ) {
                $sim = $this->jaccard( $words, $cl['centroid_words'] );
                if ( $sim > $best_sim ) {
                    $best_sim = $sim;
                    $best_idx = $idx;
                }
            }

            if ( $best_sim >= 0.30 && $best_idx >= 0 ) {
                // Add to existing cluster
                $clusters[ $best_idx ]['pids'][] = $pid;
                // Track all words with frequency
                foreach ( $words as $w ) {
                    $clusters[ $best_idx ]['all_words'][ $w ] = ( $clusters[ $best_idx ]['all_words'][ $w ] ?? 0 ) + 1;
                }
                // Rebuild centroid: top 6 most frequent words (prevents centroid bloat)
                $freq = $clusters[ $best_idx ]['all_words'];
                arsort( $freq );
                $clusters[ $best_idx ]['centroid_words'] = array_slice( array_keys( $freq ), 0, 6 );
            } else {
                // Start new cluster
                $word_freq = array();
                foreach ( $words as $w ) { $word_freq[ $w ] = 1; }
                $clusters[] = array( 'centroid_words' => $words, 'all_words' => $word_freq, 'pids' => array( $pid ) );
            }
        }

        // Merge tiny clusters (< 2 pages) into the nearest cluster
        $merged = array();
        $orphans = array();
        foreach ( $clusters as $cl ) {
            if ( count( $cl['pids'] ) >= 2 ) {
                $merged[] = $cl;
            } else {
                $orphans = array_merge( $orphans, $cl['pids'] );
            }
        }
        // Assign orphans to nearest cluster
        foreach ( $orphans as $opid ) {
            $words = $page_words[ $opid ] ?? array();
            $best_idx = 0;
            $best_sim = -1;
            foreach ( $merged as $idx => $cl ) {
                $sim = $this->jaccard( $words, $cl['centroid_words'] );
                if ( $sim > $best_sim ) { $best_sim = $sim; $best_idx = $idx; }
            }
            if ( ! empty( $merged ) ) {
                $merged[ $best_idx ]['pids'][] = $opid;
            }
        }

        // If we only got 1 cluster, splitting didn't help → return original
        if ( count( $merged ) <= 1 ) {
            $group['advice'] = '';
            return array( $group );
        }

        // Build sub-groups from clusters
        $pages_by_id = array();
        foreach ( $pages as $pg ) {
            $pages_by_id[ $pg['post_id'] ] = $pg;
        }

        $sub_groups = array();
        foreach ( $merged as $cl ) {
            $sub_pages = array();
            foreach ( $cl['pids'] as $pid ) {
                if ( isset( $pages_by_id[ $pid ] ) ) {
                    $sub_pages[] = $pages_by_id[ $pid ];
                }
            }
            if ( empty( $sub_pages ) ) continue;

            // Re-sort by pillar_score
            usort( $sub_pages, function( $a, $b ) {
                return ( $b['pillar_score'] ?? 0 ) - ( $a['pillar_score'] ?? 0 );
            } );

            $pillar_id = $sub_pages[0]['post_id'];

            // Count intra-cluster pairs
            $sub_set = array_flip( $cl['pids'] );
            $sub_pairs_count = 0;
            $sub_scores = array();
            $counted = array();
            foreach ( $cl['pids'] as $pid ) {
                foreach ( ( $pairs_by_post[ $pid ] ?? array() ) as $pair ) {
                    if ( isset( $sub_set[ (int) $pair['post_a'] ] ) && isset( $sub_set[ (int) $pair['post_b'] ] ) ) {
                        $pkey = $this->pair_key( $pair['post_a'], $pair['post_b'] );
                        if ( ! isset( $counted[ $pkey ] ) ) {
                            $sub_pairs_count++;
                            $sub_scores[] = $pair['score'] ?? 0;
                            $counted[ $pkey ] = true;
                        }
                    }
                }
            }

            $avg_score = ! empty( $sub_scores ) ? (int) round( array_sum( $sub_scores ) / count( $sub_scores ) ) : $group['avg_score'];
            $max_score = ! empty( $sub_scores ) ? max( $sub_scores ) : $group['max_score'];

            $severity = 'ok';
            if ( $max_score >= self::SCORE_CRITICAL ) $severity = 'critical';
            elseif ( $max_score >= self::SCORE_WARNING ) $severity = 'warning';

            // Sub-group keyword from common title words
            $sub_keyword = $this->find_common_title_theme( $cl['pids'] );

            $sub_groups[] = array(
                'id'               => '', // Will be assigned by caller
                'keyword'          => $sub_keyword,
                'common_keywords'  => array( $sub_keyword ),
                'pages'            => $sub_pages,
                'page_count'       => count( $sub_pages ),
                'pairs_count'      => $sub_pairs_count,
                'avg_score'        => $avg_score,
                'max_score'        => $max_score,
                'severity'         => $severity,
                'pillar_id'        => $pillar_id,
                'pillar_title'     => get_the_title( $pillar_id ),
                'advice'           => '',
                'parent_keyword'   => $group['keyword'] ?? '',
            );
        }

        return $sub_groups;
    }

    /**
     * Generate actionable advice for a group based on its data.
     * Rules-based, no AI needed.
     *
     * @param array $group
     * @return string Human-readable advice
     */
    private function generate_group_advice( array $group ) {
        $pages      = $group['pages'] ?? array();
        $page_count = $group['page_count'] ?? count( $pages );
        $pillar_id  = $group['pillar_id'] ?? 0;
        $max_score  = $group['max_score'] ?? 0;
        $severity   = $group['severity'] ?? 'ok';

        if ( $page_count < 2 ) return '';

        // Count pages with zero clicks
        $zero_clicks = 0;
        $with_traffic = 0;
        $pillar_clicks = 0;
        foreach ( $pages as $pg ) {
            if ( (int) ( $pg['clicks'] ?? 0 ) === 0 ) {
                $zero_clicks++;
            } else {
                $with_traffic++;
            }
            if ( (int) $pg['post_id'] === (int) $pillar_id ) {
                $pillar_clicks = (int) ( $pg['clicks'] ?? 0 );
            }
        }

        $advice_parts = array();

        // ── Pattern 1: Massive group with mostly zero-traffic pages ──
        if ( $page_count > 10 && $zero_clicks > $page_count * 0.8 ) {
            $advice_parts[] = sprintf(
                '%d/%d pages n\u0027ont aucun clic. Redirigez-les vers le pilier pour concentrer l\u0027autorité.',
                $zero_clicks, $page_count
            );
        }

        // ── Pattern 2: Small group (2-4 pages) ──
        elseif ( $page_count <= 4 ) {
            if ( $max_score >= self::SCORE_CRITICAL ) {
                $advice_parts[] = 'Contenu très similaire. Fusionnez manuellement les meilleurs passages dans le pilier, puis redirigez.';
            } else {
                $advice_parts[] = 'Différenciez les angles : précisez le sujet unique de chaque page pour éliminer le chevauchement.';
            }
        }

        // ── Pattern 3: Medium group with a strong pillar ──
        elseif ( $pillar_clicks > 0 && $zero_clicks > $page_count * 0.5 ) {
            $advice_parts[] = sprintf(
                'Le pilier capte déjà du trafic (%d clics). Redirigez les %d pages sans clic pour renforcer son autorité.',
                $pillar_clicks, $zero_clicks
            );
        }

        // ── Pattern 4: All pages have zero traffic ──
        elseif ( $with_traffic === 0 ) {
            $advice_parts[] = 'Aucune page ne génère de trafic. Gardez la plus complète comme pilier, redirigez les autres, et enrichissez le pilier.';
        }

        // ── Pattern 5: Multiple pages with traffic (real competition) ──
        elseif ( $with_traffic >= 3 ) {
            $advice_parts[] = sprintf(
                '%d pages captent du trafic : vérifiez si elles ciblent des intentions différentes avant de rediriger.',
                $with_traffic
            );
        }

        // ── Default ──
        else {
            $advice_parts[] = 'Gardez le pilier recommandé et redirigez les pages redondantes vers celui-ci.';
        }

        // ── Bonus: sub-clustered group hint ──
        if ( ! empty( $group['parent_keyword'] ) ) {
            $advice_parts[] = sprintf(
                'Ce sous-groupe fait partie du cluster « %s » qui a été découpé automatiquement.',
                $group['parent_keyword']
            );
        }

        return implode( ' ', $advice_parts );
    }

    /**
     * Union-Find: Find root with path compression.
     */
    private function uf_find( array &$parent, $x ) {
        if ( $parent[ $x ] !== $x ) {
            $parent[ $x ] = $this->uf_find( $parent, $parent[ $x ] );
        }
        return $parent[ $x ];
    }

    /**
     * Union-Find: Union by rank.
     */
    private function uf_union( array &$parent, array &$rank, $x, $y ) {
        $rx = $this->uf_find( $parent, $x );
        $ry = $this->uf_find( $parent, $y );
        if ( $rx === $ry ) return;

        if ( $rank[ $rx ] < $rank[ $ry ] ) {
            $parent[ $rx ] = $ry;
        } elseif ( $rank[ $rx ] > $rank[ $ry ] ) {
            $parent[ $ry ] = $rx;
        } else {
            $parent[ $ry ] = $rx;
            $rank[ $rx ]++;
        }
    }

    /**
     * Get stored groups from last scan.
     */
    public function get_groups() {
        return get_option( self::GROUPS_OPTION, array( 'groups' => array(), 'total_groups' => 0 ) );
    }

    /* =========================================================================
     * HELPERS
     * ====================================================================== */

    /**
     * Calculate enriched pillar score for a page within a group.
     *
     * Signals (weighted):
     * - Clics GSC 30j          : 30 pts max (primary traffic signal)
     * - Impressions GSC 30j    : 15 pts max (visibility signal)
     * - Position moyenne       : 15 pts max (ranking signal, lower = better)
     * - Liens internes entrants: 20 pts max (authority/structure signal from Cocon)
     * - Longueur contenu       : 10 pts max (depth signal)
     * - Ancienneté             : 10 pts max (older = more authority)
     *
     * @param array $page_data  Page data with clicks, impressions, avg_position, content_length, date
     * @param array $all_pages  All pages in the group (for relative scoring)
     * @return int Score 0-100
     */
    public function calculate_pillar_score( array $page_data, array $all_pages ) {
        $score = 0;

        // Extract max values from group for relative scoring
        $clicks_arr      = array_column( $all_pages, 'clicks' );
        $max_clicks      = ! empty( $clicks_arr ) ? max( 1, max( $clicks_arr ) ) : 1;
        $impressions_arr = array_column( $all_pages, 'impressions' );
        $max_impressions = ! empty( $impressions_arr ) ? max( 1, max( $impressions_arr ) ) : 1;
        $length_arr      = array_column( $all_pages, 'content_length' );
        $max_length      = ! empty( $length_arr ) ? max( 1, max( $length_arr ) ) : 1;
        $in_links_arr    = array_column( $all_pages, 'in_links' );
        $max_in_links    = ! empty( $in_links_arr ) ? max( 1, max( $in_links_arr ) ) : 1;

        // Oldest date in group (for relative age)
        $dates = array_filter( array_column( $all_pages, 'date' ) );
        $oldest_ts = ! empty( $dates ) ? min( array_map( 'strtotime', $dates ) ) : time();
        $newest_ts = ! empty( $dates ) ? max( array_map( 'strtotime', $dates ) ) : time();
        $age_range = max( 1, $newest_ts - $oldest_ts );

        // 1. Clics (30 pts) — most important signal
        $clicks = (int) ( $page_data['clicks'] ?? 0 );
        $score += (int) round( 30 * ( $clicks / $max_clicks ) );

        // 2. Impressions (15 pts)
        $impressions = (int) ( $page_data['impressions'] ?? 0 );
        $score += (int) round( 15 * ( $impressions / $max_impressions ) );

        // 3. Position moyenne (15 pts) — lower position = better score
        $pos = (float) ( $page_data['avg_position'] ?? 0 );
        if ( $pos > 0 && $pos <= 100 ) {
            // Position 1 = 15 pts, position 10 = 9 pts, position 50 = 0 pts
            $score += (int) round( max( 0, 15 * ( 1 - ( $pos - 1 ) / 49 ) ) );
        }

        // 4. Liens internes entrants (20 pts)
        $in_links = (int) ( $page_data['in_links'] ?? 0 );
        $score += (int) round( 20 * ( $in_links / $max_in_links ) );

        // 5. Longueur contenu (10 pts)
        $length = (int) ( $page_data['content_length'] ?? 0 );
        $score += (int) round( 10 * ( $length / $max_length ) );

        // 6. Ancienneté (10 pts) — older = more authority
        $page_ts = strtotime( $page_data['date'] ?? 'now' );
        $age_from_newest = $newest_ts - $page_ts; // seconds since newest page
        $score += (int) round( 10 * ( $age_from_newest / $age_range ) );

        return min( 100, max( 0, $score ) );
    }

    /**
     * Get internal inbound link count for a post from Cocon data.
     *
     * @param int $post_id
     * @return int Number of internal links pointing to this page
     */
    private function get_internal_links_in( $post_id ) {
        static $cocon_cache = null;

        if ( $cocon_cache === null ) {
            $cocon_cache = array();

            // Try language-specific data first
            $data = null;
            if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
                $lang = HTS_Language::get_current_lang();
                if ( $lang ) {
                    $data = get_option( 'hts_cocon_data_' . $lang, array() );
                }
            }
            if ( empty( $data['nodes'] ) ) {
                $data = get_option( 'hts_cocon_data', array() );
            }

            if ( ! empty( $data['nodes'] ) ) {
                foreach ( $data['nodes'] as $node ) {
                    $pid = (int) ( $node['id'] ?? 0 );
                    if ( $pid > 0 ) {
                        $cocon_cache[ $pid ] = (int) ( $node['in_count'] ?? $node['in_count_semantic'] ?? 0 );
                    }
                }
            }
        }

        return $cocon_cache[ (int) $post_id ] ?? 0;
    }

    /**
     * Get GSC performance data for a page.
     */
    private function get_page_performance( $post_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'hts_gsc_data';

        // Check table exists (cached)
        static $gsc_table_exists = null;
        if ( $gsc_table_exists === null ) {
            $gsc_table_exists = (bool) ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table );
        }
        if ( ! $gsc_table_exists ) {
            return null;
        }

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT SUM(clicks) as clicks, SUM(impressions) as impressions, AVG(position) as avg_position
             FROM {$table} WHERE post_id = %d AND fetch_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)",
            $post_id
        ), ARRAY_A );

        return ( $row && $row['clicks'] !== null ) ? $row : null;
    }

    /**
     * Generate a consistent key for a pair (always lower ID first).
     */
    private function pair_key( $a, $b ) {
        return min( $a, $b ) . '_' . max( $a, $b );
    }

    /**
     * Extract significant words from a title.
     */
    private function title_words( $title ) {
        $stop = function_exists( 'hts_get_stopwords' ) ? hts_get_stopwords() : array();
        $title = preg_replace( '/[^\p{L}\p{N}\s\'-]/u', ' ', mb_strtolower( trim( $title ) ) );
        $words = preg_split( '/\s+/', $title, -1, PREG_SPLIT_NO_EMPTY );
        return array_values( array_unique( array_filter( $words, function( $w ) use ( $stop ) {
            return mb_strlen( $w ) >= 2 && ! in_array( $w, $stop, true );
        } ) ) );
    }

    /**
     * Jaccard similarity between two word arrays.
     */
    private function jaccard( array $a, array $b ) {
        $sa = array_flip( $a );
        $sb = array_flip( $b );
        $inter = count( array_intersect_key( $sa, $sb ) );
        $union = count( $sa ) + count( $sb ) - $inter;
        return $union > 0 ? $inter / $union : 0;
    }

    /**
     * Get stored pairs from last scan.
     */
    public function get_pairs() {
        return get_option( self::PAIRS_OPTION, array( 'pairs' => array(), 'total' => 0 ) );
    }

    /* =========================================================================
     * AJAX HANDLERS
     * ====================================================================== */

    /**
     * AJAX: Run full scan.
     */
    public function ajax_scan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $result = $this->run_scan();
        wp_send_json_success( $result );
    }

    /**
     * AJAX: Get stored pairs.
     */
    public function ajax_get_pairs() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        wp_send_json_success( $this->get_pairs() );
    }

    /**
     * AJAX: Get stored groups with pagination and severity filter.
     *
     * Params (GET/POST):
     * - offset (int, default 0)
     * - limit  (int, default 20)
     * - severity (string: 'all'|'critical'|'warning', default 'all')
     */
    public function ajax_get_groups() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        $data     = $this->get_groups();
        $groups   = $data['groups'] ?? array();
        $offset   = max( 0, (int) ( $_POST['offset'] ?? 0 ) );
        $limit    = max( 1, min( 50, (int) ( $_POST['limit'] ?? 20 ) ) );
        $severity = sanitize_text_field( $_POST['severity'] ?? 'all' );

        // Filter by severity
        if ( $severity !== 'all' ) {
            $groups = array_values( array_filter( $groups, function( $g ) use ( $severity ) {
                return ( $g['severity'] ?? '' ) === $severity;
            } ) );
        }

        $total_filtered = count( $groups );
        $page_groups    = array_slice( $groups, $offset, $limit );

        wp_send_json_success( array(
            'groups'         => $page_groups,
            'total_filtered' => $total_filtered,
            'total_groups'   => $data['total_groups'] ?? 0,
            'total_pages'    => $data['total_pages'] ?? 0,
            'scanned_at'     => $data['scanned_at'] ?? '',
            'offset'         => $offset,
            'limit'          => $limit,
            'has_more'       => ( $offset + $limit ) < $total_filtered,
        ) );
    }

    /**
     * AJAX: Execute action on a pair (merge_pending, redirect, dismiss).
     */
    public function ajax_action() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $pair_key = sanitize_text_field( $_POST['pair_key'] ?? '' );
        $action   = sanitize_text_field( $_POST['action_type'] ?? '' );
        $winner   = (int) ( $_POST['winner'] ?? 0 );
        $loser    = (int) ( $_POST['loser'] ?? 0 );

        $data = $this->get_pairs();
        $pairs = $data['pairs'] ?? array();

        // Find the pair
        $found = false;
        foreach ( $pairs as &$pair ) {
            $key = $this->pair_key( $pair['post_a'], $pair['post_b'] );
            if ( $key === $pair_key ) {
                $found = true;

                switch ( $action ) {
                    case 'merge':
                        // Mark as merge_pending — will be handled in Phase 6c.3 or manually
                        $pair['status'] = 'merge_pending';
                        $pair['action_taken'] = array(
                            'type'   => 'merge',
                            'winner' => $winner,
                            'loser'  => $loser,
                            'date'   => current_time( 'Y-m-d H:i:s' ),
                        );

                        // If Commander is available, mark the loser post
                        $cocon_id = get_post_meta( $loser, '_hts_cocon_id', true );
                        if ( $cocon_id && class_exists( 'HTS_Cocon_Commander' ) ) {
                            $cc = new HTS_Cocon_Commander();
                            $kw = get_post_meta( $loser, '_hts_focus_keyword', true );
                            if ( $kw ) {
                                $article_key = md5( $kw );
                                $cc->update_article_status( $cocon_id, $article_key, 'merge_pending' );
                            }
                        }

                        hts_add_log(
                            sprintf( '🔀 Merge planifié : #%d (garder) ← #%d (fusionner)', $winner, $loser ),
                            'info', 'cannibalization'
                        );
                        break;

                    case 'redirect':
                        // Create 301 redirect from loser to winner
                        if ( $winner && $loser && class_exists( 'HTS_Redirects' ) ) {
                            $from = wp_make_link_relative( get_permalink( $loser ) );
                            $to   = get_permalink( $winner );
                            $redirects = new HTS_Redirects();
                            if ( method_exists( $redirects, 'add_redirect' ) ) {
                                $redirects->add_redirect( $from, $to, 301 );
                            }
                        }
                        $pair['status'] = 'redirected';
                        $pair['action_taken'] = array(
                            'type'   => 'redirect',
                            'winner' => $winner,
                            'loser'  => $loser,
                            'date'   => current_time( 'Y-m-d H:i:s' ),
                        );

                        hts_add_log(
                            sprintf( '↪️ Redirection créée : #%d → #%d', $loser, $winner ),
                            'success', 'cannibalization'
                        );
                        break;

                    case 'keep':
                    case 'dismiss':
                        $pair['status'] = 'dismissed';
                        break;
                }

                break;
            }
        }
        unset( $pair );

        if ( ! $found ) {
            wp_send_json_error( 'Paire introuvable.' );
        }

        $data['pairs'] = $pairs;
        update_option( self::PAIRS_OPTION, $data, false );

        wp_send_json_success( array( 'action' => $action, 'pair_key' => $pair_key ) );
    }

    /**
     * AJAX: Execute batch action on an entire group.
     *
     * Supports: redirect_all (redirect all non-pillar pages to pillar),
     *           dismiss_group (dismiss all pairs in the group).
     */
    public function ajax_group_action() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );

        $group_id    = sanitize_text_field( $_POST['group_id'] ?? '' );
        $action_type = sanitize_text_field( $_POST['action_type'] ?? '' );
        $pillar_id   = absint( $_POST['pillar_id'] ?? 0 );
        // Optional: selected post IDs to act on (if not all)
        $selected    = isset( $_POST['selected_ids'] ) ? array_map( 'absint', (array) $_POST['selected_ids'] ) : array();

        if ( empty( $group_id ) || empty( $action_type ) ) {
            wp_send_json_error( 'Paramètres manquants.' );
        }

        // Load groups
        $groups_data = $this->get_groups();
        $groups = $groups_data['groups'] ?? array();
        $group = null;
        foreach ( $groups as $g ) {
            if ( ( $g['id'] ?? '' ) === $group_id ) {
                $group = $g;
                break;
            }
        }

        if ( ! $group ) {
            wp_send_json_error( 'Groupe introuvable.' );
        }

        // Determine pillar
        if ( ! $pillar_id ) {
            $pillar_id = $group['pillar_id'] ?? 0;
        }

        $results = array( 'processed' => 0, 'errors' => 0, 'actions' => array() );

        $page_ids = array_column( $group['pages'] ?? array(), 'post_id' );
        // If specific selection, only act on those
        $targets = ! empty( $selected ) ? $selected : $page_ids;
        // Remove pillar from targets
        $targets = array_diff( $targets, array( $pillar_id ) );

        switch ( $action_type ) {
            case 'redirect_all':
                if ( ! $pillar_id ) {
                    wp_send_json_error( 'Aucune page pilier sélectionnée.' );
                }

                $has_workflow = class_exists( 'HTS_Workflow_Engine' ) && method_exists( 'HTS_Workflow_Engine', 'propose' );

                foreach ( $targets as $loser_id ) {
                    if ( $has_workflow ) {
                        // Queue via workflow engine → drip execution (2-3/hour via cron)
                        $action_id = HTS_Workflow_Engine::propose( 'cannibalization', 'cannibal_redirect', (int) $loser_id, array(
                            'pillar_id'     => $pillar_id,
                            'pillar_title'  => get_the_title( $pillar_id ),
                            'loser_title'   => get_the_title( $loser_id ),
                            'group_keyword' => $group['keyword'] ?? '',
                            'group_id'      => $group_id,
                            'reason'        => sprintf( 'Cannibalisation "%s" : redirection vers le pilier', $group['keyword'] ?? '' ),
                        ), $group['severity'] === 'critical' ? 'high' : 'medium' );

                        if ( $action_id ) {
                            $results['processed']++;
                            $results['actions'][] = sprintf( '#%d → file attente (action #%d)', $loser_id, $action_id );
                        } else {
                            $results['errors']++;
                        }
                    } else {
                        // Fallback: immediate execution if workflow engine not available
                        if ( class_exists( 'HTS_Redirects' ) ) {
                            $from = wp_make_link_relative( get_permalink( $loser_id ) );
                            $to   = get_permalink( $pillar_id );
                            $redirects = new HTS_Redirects();
                            if ( method_exists( $redirects, 'add_redirect' ) ) {
                                $redirects->add_redirect( $from, $to, 301 );
                            }
                        }
                        $results['processed']++;
                        $results['actions'][] = sprintf( '#%d → #%d (immédiat)', $loser_id, $pillar_id );
                    }
                }

                // Mark pairs as queued (not yet redirected — will be updated on dispatch)
                $queue_status = $has_workflow ? 'queued' : 'redirected';
                $bulk = array();
                foreach ( $targets as $loser_id ) {
                    $bulk[] = array(
                        'a'      => $pillar_id,
                        'b'      => $loser_id,
                        'status' => $queue_status,
                        'action' => array(
                            'type'   => 'redirect',
                            'winner' => $pillar_id,
                            'loser'  => $loser_id,
                            'date'   => current_time( 'Y-m-d H:i:s' ),
                            'via'    => $has_workflow ? 'workflow_queue' : 'group_action',
                        ),
                    );
                }
                $this->update_pairs_status_bulk( $bulk );

                $results['mode'] = $has_workflow ? 'queued' : 'immediate';

                if ( function_exists( 'hts_add_log' ) ) {
                    if ( $has_workflow ) {
                        hts_add_log(
                            sprintf( '📋 Groupe "%s" : %d redirection(s) ajoutée(s) à la file d\u0027attente vers #%d (%s)',
                                $group['keyword'], $results['processed'], $pillar_id, get_the_title( $pillar_id ) ),
                            'info', 'cannibalization'
                        );
                    } else {
                        hts_add_log(
                            sprintf( '↪️ Groupe "%s" : %d redirection(s) vers #%d (%s)',
                                $group['keyword'], $results['processed'], $pillar_id, get_the_title( $pillar_id ) ),
                            'success', 'cannibalization'
                        );
                    }
                }
                break;

            case 'merge_all':
                if ( ! $pillar_id ) {
                    wp_send_json_error( 'Aucune page pilier sélectionnée.' );
                }

                $has_workflow = class_exists( 'HTS_Workflow_Engine' ) && method_exists( 'HTS_Workflow_Engine', 'propose' );

                foreach ( $targets as $loser_id ) {
                    if ( $has_workflow ) {
                        $action_id = HTS_Workflow_Engine::propose( 'cannibalization', 'cannibal_merge', (int) $loser_id, array(
                            'pillar_id'     => $pillar_id,
                            'pillar_title'  => get_the_title( $pillar_id ),
                            'loser_title'   => get_the_title( $loser_id ),
                            'group_keyword' => $group['keyword'] ?? '',
                            'group_id'      => $group_id,
                            'reason'        => sprintf( 'Cannibalisation "%s" : merge vers le pilier', $group['keyword'] ?? '' ),
                        ), 'medium' );

                        if ( $action_id ) {
                            $results['processed']++;
                        } else {
                            $results['errors']++;
                        }
                    } else {
                        $results['processed']++;
                    }
                }

                $bulk = array();
                foreach ( $targets as $loser_id ) {
                    $bulk[] = array(
                        'a'      => $pillar_id,
                        'b'      => $loser_id,
                        'status' => 'merge_pending',
                        'action' => array(
                            'type'   => 'merge',
                            'winner' => $pillar_id,
                            'loser'  => $loser_id,
                            'date'   => current_time( 'Y-m-d H:i:s' ),
                            'via'    => $has_workflow ? 'workflow_queue' : 'group_action',
                        ),
                    );
                }
                $this->update_pairs_status_bulk( $bulk );

                $results['mode'] = $has_workflow ? 'queued' : 'immediate';

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( '🔀 Groupe "%s" : %d merge(s) planifié(s) vers #%d',
                            $group['keyword'], $results['processed'], $pillar_id ),
                        'info', 'cannibalization'
                    );
                }
                break;

            case 'dismiss_group':
                $bulk = array();
                foreach ( $page_ids as $pid_a ) {
                    foreach ( $page_ids as $pid_b ) {
                        if ( $pid_a >= $pid_b ) continue;
                        $bulk[] = array(
                            'a'      => $pid_a,
                            'b'      => $pid_b,
                            'status' => 'dismissed',
                            'action' => null,
                        );
                    }
                }
                $this->update_pairs_status_bulk( $bulk );
                $results['processed'] = count( $page_ids );

                if ( function_exists( 'hts_add_log' ) ) {
                    hts_add_log(
                        sprintf( 'Groupe "%s" ignoré (%d pages)', $group['keyword'], count( $page_ids ) ),
                        'info', 'cannibalization'
                    );
                }
                break;
        }

        // Rebuild groups after changes
        $data = $this->get_pairs();
        $all_pairs = $data['pairs'] ?? array();
        $new_groups = $this->build_groups( $all_pairs );
        $groups_data = array(
            'groups'       => $new_groups,
            'total_groups' => count( $new_groups ),
            'total_pages'  => array_sum( array_column( $new_groups, 'page_count' ) ),
            'scanned_at'   => current_time( 'Y-m-d H:i:s' ),
        );
        update_option( self::GROUPS_OPTION, $groups_data, false );

        wp_send_json_success( $results );
    }

    /**
     * Helper: Update status of a pair by post IDs.
     * For single-pair updates only. For batch, use update_pairs_status_bulk().
     */
    private function update_pair_status( $post_a, $post_b, $status, $action_taken = null ) {
        $data = $this->get_pairs();
        $pairs = $data['pairs'] ?? array();
        $target_key = $this->pair_key( $post_a, $post_b );

        foreach ( $pairs as &$pair ) {
            $key = $this->pair_key( $pair['post_a'], $pair['post_b'] );
            if ( $key === $target_key ) {
                $pair['status'] = $status;
                if ( $action_taken !== null ) {
                    $pair['action_taken'] = $action_taken;
                }
                break;
            }
        }
        unset( $pair );

        $data['pairs'] = $pairs;
        update_option( self::PAIRS_OPTION, $data, false );
    }

    /**
     * Helper: Bulk update status of multiple pairs in one DB write.
     *
     * @param array $updates [ [ 'a' => post_a, 'b' => post_b, 'status' => '...', 'action' => [...] ], ... ]
     */
    private function update_pairs_status_bulk( array $updates ) {
        $data = $this->get_pairs();
        $pairs = $data['pairs'] ?? array();

        // Index updates by pair_key for O(1) lookup
        $updates_map = array();
        foreach ( $updates as $u ) {
            $key = $this->pair_key( $u['a'], $u['b'] );
            $updates_map[ $key ] = $u;
        }

        // Single pass through pairs
        foreach ( $pairs as &$pair ) {
            $key = $this->pair_key( $pair['post_a'], $pair['post_b'] );
            if ( isset( $updates_map[ $key ] ) ) {
                $u = $updates_map[ $key ];
                $pair['status'] = $u['status'];
                if ( ! empty( $u['action'] ) ) {
                    $pair['action_taken'] = $u['action'];
                }
            }
        }
        unset( $pair );

        $data['pairs'] = $pairs;
        update_option( self::PAIRS_OPTION, $data, false );
    }

    /**
     * AJAX: Dismiss a pair.
     */
    public function ajax_dismiss() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        $_POST['action_type'] = 'dismiss';
        $this->ajax_action();
    }
}
