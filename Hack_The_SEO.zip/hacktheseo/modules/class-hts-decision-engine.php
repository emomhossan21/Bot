<?php
defined( 'ABSPATH' ) || exit;
/**
 * HTS Decision Engine — Phase 3 (Light)
 *
 * The "brain" of the plugin: observes all scores, evaluates priority,
 * and recommends actions to the user sorted by impact.
 *
 * Ported from Full v4.0.0 Orchestrator, adapted for Light:
 * - No auto-mode / auto-pilot (Light = always semi-auto, user validates)
 * - No Feedback Loop / Confidence Scores (Phase 4)
 * - No Content Doctor / Engagement Tracker / Freshness (Full only)
 * - No Canary / Verify crons (Phase 4+)
 * - Simplified recommendations based on available Light modules only
 * - All Full-only deps guarded by class_exists()
 *
 * @since 1.15.0
 * @depends Phase 1 (Meta Score), Phase 2 (On-Page + Content Writer), Phase 2b (Cocon + Maillage)
 */

class HTS_Decision_Engine {

    const OPT_RECOMMENDATIONS = 'hts_decision_engine_recs';
    const OPT_REPORT          = 'hts_decision_engine_report';
    const OPT_LAST_RUN        = 'hts_decision_engine_last_run';
    const MAX_RECOMMENDATIONS = 20;

    /* ──────────────────────────────────────────────
     *  INIT
     * ────────────────────────────────────────────── */

    public function init() {
        // AJAX
        add_action( 'wp_ajax_hts_decision_get_recommendations', array( $this, 'ajax_get_recommendations' ) );
        add_action( 'wp_ajax_hts_decision_dismiss',             array( $this, 'ajax_dismiss_action' ) );
        add_action( 'wp_ajax_hts_decision_get_report',          array( $this, 'ajax_get_report' ) );
        add_action( 'wp_ajax_hts_decision_run_now',             array( $this, 'ajax_run_now' ) );

        // Weekly cron
        add_action( 'hts_decision_engine_weekly', array( $this, 'run_analysis' ) );
        if ( ! wp_next_scheduled( 'hts_decision_engine_weekly' ) ) {
            wp_schedule_event( time(), 'weekly', 'hts_decision_engine_weekly' );
        }

        // Also run after GSC import (opportunistic, max once per 24h)
        add_action( 'hts_gsc_import_complete', array( $this, 'on_gsc_import' ), 20 );
    }

    /**
     * Trigger analysis after GSC import (throttled).
     */
    public function on_gsc_import( $type = 'pages' ) {
        if ( $type !== 'pages' ) return;
        // FIX 4: sync hook (prio 5) already triggers SaaS evaluation — skip local
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            return;
        }
        $last = get_option( self::OPT_LAST_RUN, '' );
        if ( $last && strtotime( $last ) > strtotime( '-24 hours' ) ) return;
        $this->run_analysis();
    }

    /* ──────────────────────────────────────────────
     *  MAIN ANALYSIS — Observe + Evaluate + Decide
     * ────────────────────────────────────────────── */

    public function run_analysis() {
        // P1 FIX: In remote mode, delegate to SaaS instead of running locally
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            HTS_Remote_Client::call( 'decision/evaluate', array( 'lang' => $lang ) );
            return;
        }

        $start = microtime( true );

        // Step 1: OBSERVE
        $observations = $this->step_observe();

        // Step 2: DECIDE (generate recommendations)
        $recommendations = $this->step_decide( $observations );

        // Build report
        $report = array(
            'generated_at'     => current_time( 'mysql' ),
            'duration_ms'      => round( ( microtime( true ) - $start ) * 1000 ),
            'observations'     => $observations,
            'recommendations'  => count( $recommendations ),
            'pending'          => count( array_filter( $recommendations, function( $r ) { return ( $r['status'] ?? '' ) === 'pending'; } ) ),
        );

        update_option( self::OPT_REPORT, $report, false );
        update_option( self::OPT_LAST_RUN, current_time( 'mysql' ), false );

        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log(
                'Decision Engine : ' . count( $recommendations ) . ' recommandation(s) générée(s)',
                'info', 'decision'
            );
        }

        return $report;
    }

    /* ──────────────────────────────────────────────
     *  STEP 1: OBSERVE — Collect current state
     * ────────────────────────────────────────────── */

    private function step_observe() {
        $obs = array(
            'gsc_available'   => false,
            'pages_total'     => 0,
            'opportunities'   => array(),
            'no_traffic'      => array(),
            'recent_actions'  => 0,
            'meta_score'      => array(),
            'onpage'          => array(),
            'cocon_coverage'  => array(),
            'schema'          => array(),
            'canonical'       => array(),
            'redirects'       => array(),
        );

        global $wpdb;

        // S18 FIX: Build SQL language clause for filtering
        $de_lang_clause = '';
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $de_lang = HTS_Language::get_current_lang();
            if ( $de_lang ) {
                $lang_args = array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => 'publish',
                    'posts_per_page' => -1,
                    'fields'         => 'ids',
                    'suppress_filters' => false,
                );
                $lang_args = HTS_Language::filter_query_args( $lang_args, $de_lang );
                $de_post_ids = get_posts( $lang_args );
                if ( HTS_Language::detect_method() === 'url' ) {
                    $de_post_objects = array_map( 'get_post', $de_post_ids );
                    $de_post_objects = array_values( HTS_Language::filter_posts_by_lang( $de_post_objects, $de_lang ) );
                    $de_post_ids = wp_list_pluck( $de_post_objects, 'ID' );
                }
                if ( ! empty( $de_post_ids ) ) {
                    $ids_str = implode( ',', array_map( 'intval', $de_post_ids ) );
                    $de_lang_clause = " AND p.ID IN ({$ids_str})";
                }
            }
        }

        // ── META SCORE AUDIT ──
        if ( class_exists( 'HTS_Meta_Score' ) ) {
            // Worst scored posts
            $worst_meta = $wpdb->get_results(
                "SELECT pm.post_id, pm.meta_value as score, p.post_title
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE pm.meta_key = '_hts_meta_score'
                 AND p.post_status = 'publish'
                 AND CAST(pm.meta_value AS UNSIGNED) < 60
                 {$de_lang_clause}
                 ORDER BY CAST(pm.meta_value AS UNSIGNED) ASC
                 LIMIT 10",
                ARRAY_A
            );
            $obs['meta_score']['worst'] = $worst_meta ?: array();

            // Missing meta count
            $obs['meta_score']['missing_title'] = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} p
                 WHERE p.post_type IN ('post','page') AND p.post_status = 'publish'
                 {$de_lang_clause}
                 AND p.ID NOT IN (
                    SELECT post_id FROM {$wpdb->postmeta}
                    WHERE meta_key = '_hts_meta_title' AND meta_value != ''
                 )"
            );
            $obs['meta_score']['missing_desc'] = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} p
                 WHERE p.post_type IN ('post','page') AND p.post_status = 'publish'
                 {$de_lang_clause}
                 AND p.ID NOT IN (
                    SELECT post_id FROM {$wpdb->postmeta}
                    WHERE meta_key = '_hts_meta_description' AND meta_value != ''
                 )"
            );
        }

        // ── ON-PAGE SCORE AUDIT ──
        if ( class_exists( 'HTS_On_Page_Score' ) ) {
            $worst_onpage = $wpdb->get_results(
                "SELECT pm.post_id, pm.meta_value as score, p.post_title
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE pm.meta_key = '_hts_onpage_score'
                 AND p.post_status = 'publish'
                 {$de_lang_clause}
                 AND CAST(pm.meta_value AS UNSIGNED) < 50
                 ORDER BY CAST(pm.meta_value AS UNSIGNED) ASC
                 LIMIT 10",
                ARRAY_A
            );
            $obs['onpage']['worst'] = $worst_onpage ?: array();
        }

        // ── GSC DATA ──
        $gsc_pages = get_option( 'hts_gsc_pages', array() );
        $obs['gsc_available'] = ! empty( $gsc_pages );
        $obs['pages_total']   = count( $gsc_pages );

        // Opportunities: pages pos 4-20 with high impressions
        foreach ( $gsc_pages as $p ) {
            $pos  = (float) ( $p['position'] ?? 0 );
            $impr = (int) ( $p['impressions'] ?? 0 );
            if ( $pos >= 4 && $pos <= 20 && $impr >= 50 ) {
                $obs['opportunities'][] = array(
                    'url'         => $p['url'] ?? '',
                    'position'    => $pos,
                    'impressions' => $impr,
                    'clicks'      => (int) ( $p['clicks'] ?? 0 ),
                );
            }
        }
        usort( $obs['opportunities'], function( $a, $b ) { return $b['impressions'] <=> $a['impressions']; } );
        $obs['opportunities'] = array_slice( $obs['opportunities'], 0, 10 );

        // No traffic: published posts with 0 impressions
        $args = array(
            'post_type' => 'post', 'post_status' => 'publish',
            'posts_per_page' => 100, 'fields' => 'ids',
        );
        if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
            $args = HTS_Language::filter_query_args( $args );
        }
        $published = get_posts( $args );
        foreach ( $published as $pid ) {
            $impr = (int) get_post_meta( $pid, '_hts_gsc_impressions', true );
            $days = ( time() - get_post_time( 'U', false, $pid ) ) / DAY_IN_SECONDS;
            if ( $impr === 0 && $days > 14 ) {
                $obs['no_traffic'][] = array(
                    'post_id'  => $pid,
                    'title'    => get_the_title( $pid ),
                    'days_old' => round( $days ),
                );
            }
        }
        $obs['no_traffic'] = array_slice( $obs['no_traffic'], 0, 10 );

        // Recent actions count (7 days)
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            $stats = HTS_Audit_Trail::get_stats();
            $obs['recent_actions'] = $stats['last_7d'] ?? 0;
        }

        // ── COCON COVERAGE ──
        if ( class_exists( 'HTS_Cocon' ) ) {
            $cocon = new HTS_Cocon();
            if ( method_exists( $cocon, 'get_clusters' ) ) {
                $clusters = $cocon->get_clusters();
                if ( is_array( $clusters ) ) {
                    foreach ( $clusters as $cid => $cluster ) {
                        $pages   = $cluster['pages'] ?? array();
                        $orphans = array_filter( $pages, function( $p ) { return ( $p['role'] ?? '' ) === 'orphan'; } );
                        $obs['cocon_coverage'][] = array(
                            'cluster_id' => $cid,
                            'name'       => $cluster['name'] ?? 'Cluster #' . $cid,
                            'total'      => count( $pages ),
                            'orphans'    => count( $orphans ),
                        );
                    }
                }
            }
        }

        // ── SCHEMA AUDIT ──
        if ( class_exists( 'HTS_Schema_Markup' ) ) {
            $no_schema = array();
            foreach ( $published as $pid ) {
                $count = (int) get_post_meta( $pid, '_hts_schemas_count', true );
                $impr  = (int) get_post_meta( $pid, '_hts_gsc_impressions', true );
                if ( $count === 0 && $impr > 20 ) {
                    $no_schema[] = array(
                        'post_id'     => $pid,
                        'title'       => get_the_title( $pid ),
                        'impressions' => $impr,
                    );
                }
            }
            usort( $no_schema, function( $a, $b ) { return $b['impressions'] <=> $a['impressions']; } );
            $obs['schema']['no_schema'] = array_slice( $no_schema, 0, 10 );
        }

        // ── CANONICAL CONFLICTS ──
        if ( class_exists( 'HTS_Canonical' ) ) {
            $conflicts = get_option( 'hts_canonical_conflicts', array() );
            $critical  = array_filter( $conflicts, function( $c ) {
                return ( $c['status'] ?? '' ) !== 'resolved' && ( $c['risk'] ?? '' ) === 'critical';
            } );
            $obs['canonical']['critical'] = array_slice( array_values( $critical ), 0, 5 );
        }

        // ── REDIRECTS: TOP 404 ──
        if ( class_exists( 'HTS_Redirects' ) ) {
            $t404 = $wpdb->prefix . 'hts_404_log';
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $t404 ) ) === $t404 ) {
                $top_404 = $wpdb->get_results(
                    "SELECT url, hit_count, last_seen FROM {$t404}
                     WHERE status = 'new'
                     ORDER BY hit_count DESC LIMIT 10",
                    ARRAY_A
                );
                $obs['redirects']['top_404'] = $top_404 ?: array();
            }

            // Redirect chains
            $t_redir = $wpdb->prefix . 'hts_redirects';
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $t_redir ) ) === $t_redir ) {
                $chains = $wpdb->get_results(
                    "SELECT r1.source_url as source, r1.target_url as target, r2.target_url as final_target
                     FROM {$t_redir} r1
                     INNER JOIN {$t_redir} r2 ON r1.target_url = r2.source_url
                     WHERE r1.enabled = 1 AND r2.enabled = 1
                     LIMIT 10",
                    ARRAY_A
                );
                $obs['redirects']['chains'] = $chains ?: array();
            }
        }

        return $obs;
    }

    /* ──────────────────────────────────────────────
     *  STEP 2: DECIDE — Generate prioritized recommendations
     * ────────────────────────────────────────────── */

    private function step_decide( $observations ) {
        $recs = array();

        // ── 1. WEAK META TAGS ──
        if ( ! empty( $observations['meta_score']['worst'] ) ) {
            foreach ( array_slice( $observations['meta_score']['worst'], 0, 5 ) as $weak ) {
                $pid   = (int) $weak['post_id'];
                $score = (int) $weak['score'];
                $pos   = (float) get_post_meta( $pid, '_hts_gsc_position', true );

                $recs[] = array(
                    'id'          => 'meta_weak_' . $pid,
                    'type'        => 'optimize_meta',
                    'priority'    => $score < 30 ? 82 : ( $score < 50 ? 72 : 62 ),
                    'title'       => 'Meta à optimiser',
                    'description' => '"' . $weak['post_title'] . '" — Score ' . $score . '/100' . ( $pos > 0 ? ' · Pos ' . round( $pos, 1 ) : '' ),
                    'action_data' => array( 'post_id' => $pid, 'score' => $score ),
                    'impact_est'  => 'Améliorer le CTR en optimisant title + description',
                    'why'         => 'Un score meta faible signifie que Google affiche un extrait peu attractif pour vos visiteurs potentiels.',
                    'how'         => 'Allez dans l\'éditeur de l\'article, cliquez sur "Générer les metas IA" dans le panneau SEO.',
                    'status'      => 'pending',
                );
            }
        }

        // ── 2. MISSING META DESCRIPTIONS ──
        $missing_desc = $observations['meta_score']['missing_desc'] ?? 0;
        if ( $missing_desc > 0 ) {
            $recs[] = array(
                'id'          => 'meta_missing_desc',
                'type'        => 'generate_meta',
                'priority'    => 72,
                'title'       => 'Meta descriptions manquantes',
                'description' => $missing_desc . ' articles sans meta description — Google choisit le texte affiché à votre place',
                'action_data' => array( 'missing_count' => $missing_desc ),
                'impact_est'  => 'Reprendre le contrôle de ce que vos visiteurs voient dans Google',
                'why'         => 'Sans meta description, Google génère un extrait automatique qui peut être peu pertinent.',
                'how'         => 'Utilisez le scoring batch depuis le Cockpit pour repérer les articles sans description.',
                'status'      => 'pending',
            );
        }

        // ── 3. ON-PAGE SCORE LOW ──
        $onpage_worst = $observations['onpage']['worst'] ?? array();
        foreach ( array_slice( $onpage_worst, 0, 5 ) as $op ) {
            $pid      = (int) $op['post_id'];
            $op_score = (int) $op['score'];
            $recs[] = array(
                'id'          => 'onpage_fix_' . $pid,
                'type'        => 'fix_onpage',
                'priority'    => $op_score < 30 ? 72 : ( $op_score < 40 ? 58 : 48 ),
                'title'       => 'Contenu à améliorer — Score ' . $op_score . '/100',
                'description' => '"' . ( $op['post_title'] ?? '' ) . '" — structure Hn, images, liens internes à corriger',
                'action_data' => array( 'post_id' => $pid, 'score' => $op_score ),
                'impact_est'  => 'Améliorer la lisibilité et l\'accessibilité de la page',
                'why'         => 'Un score On-Page faible indique des problèmes de structure que Google peut pénaliser.',
                'how'         => 'Ouvrez l\'article, le panneau SEO détaille chaque critère à corriger.',
                'status'      => 'pending',
            );
        }

        // ── 4. OPPORTUNITIES (pos 4-20, high impressions) ──
        foreach ( $observations['opportunities'] as $opp ) {
            $post_id = hts_url_to_postid( $opp['url'] );
            if ( ! $post_id ) continue;

            $internal_links = (int) get_post_meta( $post_id, '_hts_cross_links_in', true );
            if ( $internal_links < 3 ) {
                $recs[] = array(
                    'id'          => 'boost_links_' . $post_id,
                    'type'        => 'add_internal_links',
                    'priority'    => 80,
                    'title'       => 'Renforcer le maillage interne',
                    'description' => '"' . get_the_title( $post_id ) . '" est en position ' . round( $opp['position'], 1 ) . ' avec ' . $opp['impressions'] . ' impressions — seulement ' . $internal_links . ' lien(s) entrant(s)',
                    'action_data' => array( 'post_id' => $post_id, 'current_pos' => $opp['position'] ),
                    'impact_est'  => 'Gagner 2 à 5 positions avec plus de liens internes',
                    'why'         => 'Cet article est proche de la première page mais manque de liens internes pour remonter.',
                    'how'         => 'Dans le panneau SEO de l\'article, section Maillage Interne, cliquez sur "Suggérer des liens".',
                    'status'      => 'pending',
                );
            }
        }

        // ── 5. NO TRAFFIC PAGES ──
        foreach ( array_slice( $observations['no_traffic'], 0, 3 ) as $nt ) {
            $recs[] = array(
                'id'          => 'no_traffic_' . $nt['post_id'],
                'type'        => 'investigate',
                'priority'    => 60,
                'title'       => 'Aucune impression Google',
                'description' => '"' . $nt['title'] . '" publié depuis ' . $nt['days_old'] . ' jours — 0 impression',
                'action_data' => array( 'post_id' => $nt['post_id'] ),
                'impact_est'  => 'Retravailler le title et la meta pour obtenir des impressions',
                'why'         => 'Google ne montre pas cet article dans ses résultats. Il faut comprendre pourquoi.',
                'how'         => 'Vérifiez le score meta, la qualité du contenu et l\'indexation de cette page.',
                'status'      => 'pending',
            );
        }

        // ── 6. MISSING SCHEMA ON HIGH-TRAFFIC PAGES ──
        if ( ! empty( $observations['schema']['no_schema'] ) ) {
            foreach ( array_slice( $observations['schema']['no_schema'], 0, 5 ) as $ns ) {
                $recs[] = array(
                    'id'          => 'schema_missing_' . $ns['post_id'],
                    'type'        => 'add_schema',
                    'priority'    => 62,
                    'title'       => 'Schema manquant sur une page visitée',
                    'description' => '"' . $ns['title'] . '" — ' . $ns['impressions'] . ' impressions sans Schema Markup',
                    'action_data' => array( 'post_id' => $ns['post_id'] ),
                    'impact_est'  => 'Apparaître avec des Rich Snippets dans Google → meilleur taux de clic',
                    'why'         => 'Le Schema Markup aide Google à comprendre votre contenu et à afficher des résultats enrichis.',
                    'how'         => 'Éditez l\'article, le plugin détecte automatiquement le type de schema à ajouter.',
                    'status'      => 'pending',
                );
            }
        }

        // ── 7. CANONICAL CONFLICTS ──
        if ( ! empty( $observations['canonical']['critical'] ) ) {
            foreach ( array_slice( $observations['canonical']['critical'], 0, 3 ) as $cc ) {
                $recs[] = array(
                    'id'          => 'canonical_conflict_' . md5( wp_json_encode( $cc ) ),
                    'type'        => 'fix_canonical',
                    'priority'    => 82,
                    'title'       => 'Pages en conflit — Google hésite',
                    'description' => ( $cc['label'] ?? 'Conflit canonical détecté' ) . ' — risque de cannibalisation',
                    'action_data' => $cc,
                    'impact_est'  => 'Clarifier quelle page Google doit référencer pour éviter la dilution',
                    'why'         => 'Quand deux pages se font concurrence, aucune des deux ne se positionne bien.',
                    'how'         => 'Résolvez le conflit depuis le Cockpit (section Pages en conflit).',
                    'status'      => 'pending',
                );
            }
        }

        // ── 8. TOP 404 ERRORS ──
        if ( ! empty( $observations['redirects']['top_404'] ) ) {
            foreach ( array_slice( $observations['redirects']['top_404'], 0, 3 ) as $err ) {
                $hits = (int) ( $err['hit_count'] ?? 0 );
                if ( $hits >= 5 ) {
                    $recs[] = array(
                        'id'          => 'redirect_404_' . md5( $err['url'] ?? '' ),
                        'type'        => 'create_redirect',
                        'priority'    => $hits >= 50 ? 80 : ( $hits >= 20 ? 68 : 58 ),
                        'title'       => 'Erreur 404 fréquente (' . $hits . ' visites)',
                        'description' => ( $err['url'] ?? '' ),
                        'action_data' => array( 'url' => $err['url'] ?? '', 'hit_count' => $hits ),
                        'impact_est'  => 'Récupérer le trafic et les liens entrants perdus',
                        'why'         => 'Des visiteurs et des robots arrivent sur une page qui n\'existe plus — c\'est du trafic perdu.',
                        'how'         => 'Créez une redirection 301 vers la page la plus pertinente depuis Redirections.',
                        'status'      => 'pending',
                    );
                }
            }
        }

        // ── 9. REDIRECT CHAINS ──
        if ( ! empty( $observations['redirects']['chains'] ) ) {
            $chain_count = count( $observations['redirects']['chains'] );
            $recs[] = array(
                'id'          => 'redirect_chains',
                'type'        => 'fix_redirect_chain',
                'priority'    => 66,
                'title'       => $chain_count . ' chaîne(s) de redirections',
                'description' => 'Redirections en cascade détectées (A→B→C) — ça ralentit Google et dilue le PageRank',
                'action_data' => array( 'chains' => array_slice( $observations['redirects']['chains'], 0, 5 ) ),
                'impact_est'  => 'Corriger les chaînes pour A→C direct',
                'why'         => 'Chaque maillon dans la chaîne fait perdre du temps à Google et de la valeur SEO.',
                'how'         => 'Modifiez les redirections depuis le menu Redirections pour pointer directement vers la cible finale.',
                'status'      => 'pending',
            );
        }

        // Sort by priority desc
        usort( $recs, function( $a, $b ) { return $b['priority'] <=> $a['priority']; } );

        // ── Strategy Engine enrichment: adjust priorities by pattern confidence ──
        if ( class_exists( 'HTS_Strategy_Engine' ) ) {
            foreach ( $recs as &$r ) {
                $r = HTS_Strategy_Engine::enrich_recommendation( $r );
            }
            unset( $r );
            // Re-sort after enrichment
            usort( $recs, function( $a, $b ) { return $b['priority'] <=> $a['priority']; } );
        }

        // Merge with existing (keep dismissed, replace pending)
        $existing = get_option( self::OPT_RECOMMENDATIONS, array() );
        $existing_map = array();
        foreach ( $existing as $e ) {
            if ( ! empty( $e['status'] ) && $e['status'] !== 'pending' ) {
                $existing_map[ $e['id'] ] = $e;
            }
        }
        foreach ( $recs as &$r ) {
            if ( isset( $existing_map[ $r['id'] ] ) ) {
                $r['status'] = $existing_map[ $r['id'] ]['status'];
            }
        }

        // Cap
        $recs = array_slice( $recs, 0, self::MAX_RECOMMENDATIONS );

        update_option( self::OPT_RECOMMENDATIONS, $recs, false );
        return $recs;
    }

    /* ──────────────────────────────────────────────
     *  PUBLIC API — for other modules
     * ────────────────────────────────────────────── */

    /**
     * Get prioritized actions for a specific post (for SEO Panel integration).
     *
     * @param int $post_id
     * @return array
     */
    public static function get_prioritized_actions( $post_id ) {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'decision/recommendations', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data'] ) ) {
                $all = is_array( $result['data'] ) ? $result['data'] : array();
                $filtered = array();
                foreach ( $all as $r ) {
                    if ( (int) ( isset( $r['post_id'] ) ? $r['post_id'] : 0 ) === (int) $post_id ) {
                        $filtered[] = $r;
                    }
                }
                return $filtered;
            }
        }
        $recs = get_option( self::OPT_RECOMMENDATIONS, array() );
        $post_recs = array();

        foreach ( $recs as $r ) {
            if ( ( $r['status'] ?? '' ) !== 'pending' ) continue;
            $rec_pid = $r['action_data']['post_id'] ?? 0;
            if ( (int) $rec_pid === (int) $post_id ) {
                $post_recs[] = $r;
            }
        }

        return $post_recs;
    }

    /**
     * Get pending count for sidebar badge.
     */
    public static function get_pending_count() {
        $recs = get_option( self::OPT_RECOMMENDATIONS, array() );
        return count( array_filter( $recs, function( $r ) { return ( $r['status'] ?? '' ) === 'pending'; } ) );
    }

    /**
     * Get all pending recommendations.
     */
    public static function get_pending_recommendations() {
        // BUG 7 FIX: In remote mode, fetch from SaaS
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $result = HTS_Remote_Client::call( 'decision/recommendations', array(
                'lang' => class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '',
            ), 'POST', array( 'timeout' => 5, 'retries' => 1 ) );
            if ( ! empty( $result['success'] ) && isset( $result['data'] ) ) {
                return is_array( $result['data'] ) ? $result['data'] : array();
            }
        }
        $recs = get_option( self::OPT_RECOMMENDATIONS, array() );
        return array_values( array_filter( $recs, function( $r ) { return ( $r['status'] ?? '' ) === 'pending'; } ) );
    }

    /* ──────────────────────────────────────────────
     *  AJAX HANDLERS
     * ────────────────────────────────────────────── */

    public function ajax_get_recommendations() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'decision/recommendations', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote decision/recommendations failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $recs    = get_option( self::OPT_RECOMMENDATIONS, array() );
        $pending = array_filter( $recs, function( $r ) { return ( $r['status'] ?? '' ) === 'pending'; } );

        wp_send_json_success( array(
            'recommendations' => array_values( $pending ),
            'total'           => count( $recs ),
            'pending'         => count( $pending ),
            'last_run'        => get_option( self::OPT_LAST_RUN, 'jamais' ),
        ) );
    }

    public function ajax_dismiss_action() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'decision/dismiss', array(
                'lang'      => $lang,
                'action_id' => sanitize_text_field( isset( $_POST['rec_id'] ) ? $_POST['rec_id'] : '' ),
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // P4 FIX: No fallback for write operations — return error instead
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote decision/dismiss failed, no fallback (write op)', 'warning', 'remote' );
            }
            wp_send_json_error( array( 'message' => 'Le service est temporairement indisponible. Réessayez dans quelques minutes.' ) );
        }

        // ── LOCAL MODE ──
        $rec_id = sanitize_text_field( $_POST['rec_id'] ?? '' );
        $recs   = get_option( self::OPT_RECOMMENDATIONS, array() );

        foreach ( $recs as &$r ) {
            if ( $r['id'] === $rec_id ) {
                $r['status']       = 'dismissed';
                $r['dismissed_at'] = current_time( 'mysql' );
                update_option( self::OPT_RECOMMENDATIONS, $recs, false );
                wp_send_json_success( array( 'message' => 'Recommandation ignorée.' ) );
                return;
            }
        }

        wp_send_json_error( 'Recommandation introuvable.' );
    }

    public function ajax_get_report() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'decision/report', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // Fallback to local if SaaS fails
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote decision/report failed, fallback local', 'warning', 'remote' );
            }
        }

        // ── LOCAL MODE ──
        $report = get_option( self::OPT_REPORT, null );
        if ( ! $report ) {
            wp_send_json_error( 'Aucun rapport disponible. Lancez une analyse depuis le Cockpit.' );
        }
        wp_send_json_success( $report );
    }

    public function ajax_run_now() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        // ── REMOTE MODE ──
        if ( defined( 'HTS_REMOTE_DECISIONS' ) && HTS_REMOTE_DECISIONS && class_exists( 'HTS_Remote_Client' ) && HTS_Remote_Client::is_available() ) {
            $lang = class_exists( 'HTS_Language' ) ? HTS_Language::get_current_lang() : '';
            $result = HTS_Remote_Client::call( 'decision/evaluate', array(
                'lang' => $lang,
            ), 'POST', array( 'timeout' => 15, 'retries' => 0 ) );
            if ( ! empty( $result['success'] ) ) {
                wp_send_json_success( isset( $result['data'] ) ? $result['data'] : array() );
            }
            // P4 FIX: No fallback for write operations — return error instead
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( 'Remote decision/evaluate failed, no fallback (write op)', 'warning', 'remote' );
            }
            wp_send_json_error( array( 'message' => 'Le service est temporairement indisponible. Réessayez dans quelques minutes.' ) );
        }

        // ── LOCAL MODE ──
        $report = $this->run_analysis();
        wp_send_json_success( array(
            'message' => 'Analyse terminée. ' . $report['recommendations'] . ' recommandation(s) générée(s).',
            'report'  => $report,
        ) );
    }
}
