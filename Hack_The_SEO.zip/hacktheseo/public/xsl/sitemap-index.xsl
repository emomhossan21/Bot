<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
    xmlns:html="http://www.w3.org/TR/REC-html40"
    xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Plan de site XML — Hack The SEO</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif; color: #1e293b; background: #f8fafc; }
        #description { background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%); color: #fff; padding: 24px 32px; }
        #description h1 { font-size: 22px; font-weight: 700; margin-bottom: 8px; }
        #description p { font-size: 13px; opacity: 0.85; line-height: 1.6; }
        #description a { color: #60a5fa; text-decoration: underline; }
        #description a:hover { color: #93c5fd; }
        .brand { display: inline-flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.1); padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; margin-top: 10px; }
        .brand img { width: 16px; height: 16px; }
        #content { max-width: 1200px; margin: 24px auto; padding: 0 24px; }
        .count { font-size: 14px; color: #64748b; margin-bottom: 16px; }
        .count strong { color: #1e293b; }
        table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
        th { background: #0f172a; color: #fff; padding: 12px 16px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
        td { padding: 10px 16px; font-size: 13px; border-bottom: 1px solid #f1f5f9; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #f0f9ff; }
        td a { color: #2563eb; text-decoration: none; }
        td a:hover { text-decoration: underline; }
        .date { color: #64748b; font-size: 12px; font-family: 'SF Mono', Monaco, monospace; }
        #footer { text-align: center; padding: 24px; font-size: 11px; color: #94a3b8; }
        #footer a { color: #64748b; }
    </style>
</head>
<body>
    <div id="description">
        <h1>Plan de site XML</h1>
        <p>Ce plan de site XML est généré par le plugin SEO <a href="https://www.hacktheseo.com/?utm_source=sitemap" target="_blank">Hack The SEO</a>. Il aide les moteurs de recherche comme Google à explorer et indexer les articles, pages et contenus de votre site.</p>
        <p><a href="https://www.hacktheseo.com/?utm_source=sitemap" target="_blank">En savoir plus sur Hack The SEO →</a></p>
        <div class="brand">🚀 Propulsé par Hack The SEO</div>
    </div>
    <div id="content">
        <p class="count">Ce fichier d'index contient <strong><xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/></strong> plan(s) de site.</p>
        <table>
            <thead>
                <tr>
                    <th>Plan de site</th>
                    <th style="width:220px;">Dernière modification</th>
                </tr>
            </thead>
            <tbody>
                <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                    <tr>
                        <td>
                            <a>
                                <xsl:attribute name="href"><xsl:value-of select="sitemap:loc"/></xsl:attribute>
                                <xsl:value-of select="sitemap:loc"/>
                            </a>
                        </td>
                        <td class="date">
                            <xsl:value-of select="sitemap:lastmod"/>
                        </td>
                    </tr>
                </xsl:for-each>
            </tbody>
        </table>
    </div>
    <div id="footer">
        Généré par <a href="https://www.hacktheseo.com/?utm_source=sitemap" target="_blank">Hack The SEO</a> — Plugin SEO WordPress propulsé par l'IA
    </div>
</body>
</html>
</xsl:template>
</xsl:stylesheet>
