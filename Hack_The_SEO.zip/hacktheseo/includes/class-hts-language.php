<?php
/**
 * Language Helper — Multilingual support for all modules
 *
 * Detects post language via Polylang, WPML, TranslatePress, or URL pattern.
 * Ensures cocon/maillage/content-doctor/freshness only work within a single language.
 *
 * @since 2.4.2
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class HTS_Language {

    /** @var string|null Cached detection method */
    private static $method = null;

    /** @var array Cached post languages */
    private static $cache = array();

    /**
     * Detect which multilingual plugin is active.
     * @return string  polylang|wpml|translatepress|url|none
     */
    public static function detect_method() {
        if ( self::$method !== null ) return self::$method;

        if ( function_exists( 'pll_get_post_language' ) ) {
            self::$method = 'polylang';
        } elseif ( defined( 'ICL_SITEPRESS_VERSION' ) || function_exists( 'wpml_get_language_information' ) ) {
            self::$method = 'wpml';
        } elseif ( class_exists( 'TRP_Translate_Press' ) ) {
            self::$method = 'translatepress';
        } elseif ( self::site_has_lang_urls() ) {
            self::$method = 'url';
        } else {
            self::$method = 'none';
        }

        return self::$method;
    }

    /**
     * Check if the site uses /xx/ language prefixes in URLs.
     */
    private static function site_has_lang_urls() {
        $sample = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'posts_per_page' => 10 ) );
        $pattern = '#^https?://[^/]+/([a-z]{2}(?:-[a-z]{2})?)/#i';
        $langs = array();
        foreach ( $sample as $p ) {
            $url = get_permalink( $p->ID );
            if ( preg_match( $pattern, $url, $m ) ) {
                $langs[ $m[1] ] = true;
            }
        }
        // If we detect 2+ different lang prefixes, or known lang codes
        return count( $langs ) >= 1;
    }

    /**
     * Get the language of a specific post.
     * @param int $post_id
     * @return string  Language code (e.g. 'fr', 'en') or '' if unknown.
     */
    public static function get_post_language( $post_id ) {
        if ( isset( self::$cache[ $post_id ] ) ) return self::$cache[ $post_id ];

        $method = self::detect_method();
        $lang = '';

        switch ( $method ) {
            case 'polylang':
                $lang = pll_get_post_language( $post_id, 'slug' );
                break;

            case 'wpml':
                $info = apply_filters( 'wpml_post_language_details', null, $post_id );
                if ( is_array( $info ) && ! empty( $info['language_code'] ) ) {
                    $lang = $info['language_code'];
                }
                break;

            case 'translatepress':
                // TranslatePress stores translations in a single post, 
                // the "original" language is the site default
                $lang = self::get_site_default_lang();
                break;

            case 'url':
                $url = get_permalink( $post_id );
                $lang = self::extract_lang_from_url( $url );
                break;
        }

        $lang = strtolower( trim( $lang ) );
        // Normalize: 'fr-fr' → 'fr', 'en-us' → 'en'
        if ( strlen( $lang ) > 2 && strpos( $lang, '-' ) !== false ) {
            $lang = explode( '-', $lang )[0];
        }

        self::$cache[ $post_id ] = $lang;
        return $lang;
    }

    /**
     * Extract language code from URL pattern like /fr/ or /en/.
     */
    public static function extract_lang_from_url( $url ) {
        // Match /xx/ after domain: https://example.com/fr/page-title/
        if ( preg_match( '#^https?://[^/]+/([a-z]{2})(?:/|$)#i', $url, $m ) ) {
            $code = strtolower( $m[1] );
            // Validate it's a real lang code (ISO 639-1)
            $valid = array( 'aa','ab','af','am','ar','as','ay','az','ba','be','bg','bh','bi','bn','bo','br','ca','co','cs','cy','da','de','dz','el','en','eo','es','et','eu','fa','fi','fj','fo','fr','fy','ga','gd','gl','gn','gu','ha','he','hi','hr','hu','hy','ia','id','ie','ik','is','it','ja','jw','ka','kk','kl','km','kn','ko','ks','ku','ky','la','ln','lo','lt','lv','mg','mi','mk','ml','mn','mo','mr','ms','mt','my','na','ne','nl','no','oc','om','or','pa','pl','ps','pt','qu','rm','rn','ro','ru','rw','sa','sd','sg','sh','si','sk','sl','sm','sn','so','sq','sr','ss','st','su','sv','sw','ta','te','tg','th','ti','tk','tl','tn','to','tr','ts','tt','tw','ug','uk','ur','uz','vi','vo','wo','xh','yi','yo','za','zh','zu' );
            if ( in_array( $code, $valid ) ) {
                return $code;
            }
        }
        return '';
    }

    /**
     * Get site default language.
     */
    public static function get_site_default_lang() {
        if ( function_exists( 'pll_default_language' ) ) {
            return pll_default_language( 'slug' );
        }
        $locale = get_locale(); // e.g. 'fr_FR'
        return substr( $locale, 0, 2 );
    }

    /**
     * Get the current admin language (for filtering).
     * Priority: POST param > Polylang admin filter > site default
     */
    public static function get_current_lang() {
        // Explicit param from AJAX or form
        if ( ! empty( $_POST['lang'] ) ) {
            return sanitize_text_field( $_POST['lang'] );
        }
        if ( ! empty( $_GET['lang'] ) ) {
            return sanitize_text_field( $_GET['lang'] );
        }

        // Polylang admin language filter
        if ( function_exists( 'pll_current_language' ) ) {
            $l = pll_current_language( 'slug' );
            if ( $l ) return $l;
        }

        // WPML current language
        if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
            return ICL_LANGUAGE_CODE;
        }

        return self::get_site_default_lang();
    }

    /**
     * Get all available languages on the site.
     * @return array  e.g. [ 'fr' => 'Français', 'en' => 'English' ]
     */
    public static function get_available_languages() {
        $method = self::detect_method();

        if ( $method === 'polylang' && function_exists( 'pll_languages_list' ) ) {
            $slugs = pll_languages_list( array( 'fields' => 'slug' ) );
            $names = pll_languages_list( array( 'fields' => 'name' ) );
            return array_combine( $slugs, $names );
        }

        if ( $method === 'wpml' ) {
            $langs = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0 ) );
            if ( is_array( $langs ) ) {
                $result = array();
                foreach ( $langs as $l ) {
                    $result[ $l['language_code'] ] = $l['translated_name'];
                }
                return $result;
            }
        }

        if ( $method === 'url' ) {
            return self::detect_url_languages();
        }

        // Single language site
        $default = self::get_site_default_lang();
        $names = array( 'fr' => 'Français', 'en' => 'English', 'es' => 'Español', 'de' => 'Deutsch', 'it' => 'Italiano', 'pt' => 'Português', 'nl' => 'Nederlands', 'ja' => '日本語', 'zh' => '中文' );
        return array( $default => $names[ $default ] ?? $default );
    }

    /**
     * Detect languages from URL patterns across all posts.
     */
    private static function detect_url_languages() {
        $posts = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'posts_per_page' => 200 ) );
        $langs = array();
        $names = array( 'fr' => 'Français', 'en' => 'English', 'es' => 'Español', 'de' => 'Deutsch', 'it' => 'Italiano', 'pt' => 'Português', 'nl' => 'Nederlands', 'ja' => '日本語', 'zh' => '中文', 'ar' => 'العربية', 'ru' => 'Русский', 'ko' => '한국어', 'pl' => 'Polski', 'sv' => 'Svenska', 'tr' => 'Türkçe' );

        foreach ( $posts as $p ) {
            $code = self::extract_lang_from_url( get_permalink( $p->ID ) );
            if ( $code && ! isset( $langs[ $code ] ) ) {
                $langs[ $code ] = $names[ $code ] ?? strtoupper( $code );
            }
        }

        if ( empty( $langs ) ) {
            $default = self::get_site_default_lang();
            $langs[ $default ] = $names[ $default ] ?? $default;
        }

        return $langs;
    }

    /**
     * Check if the site is multilingual (has 2+ languages).
     */
    public static function is_multilingual() {
        return count( self::get_available_languages() ) > 1;
    }

    /**
     * Filter a WP_Query args array to only get posts of a specific language.
     * Works with Polylang, WPML, or returns unmodified for URL-based detection.
     *
     * @param array  $args  WP_Query arguments
     * @param string $lang  Language code
     * @return array  Modified query args
     */
    public static function filter_query_args( $args, $lang = '' ) {
        if ( ! $lang ) $lang = self::get_current_lang();
        if ( ! $lang ) return $args;

        $method = self::detect_method();

        if ( $method === 'polylang' ) {
            $args['lang'] = $lang;
        } elseif ( $method === 'wpml' ) {
            // WPML auto-filters based on current language
            // Force specific language via suppress_filters
            $args['suppress_filters'] = false;
        }
        // For URL-based: we filter post-query (see filter_posts_by_lang)

        return $args;
    }

    /**
     * Filter an array of posts to keep only those matching a language.
     * Useful for URL-based detection where we can't filter at query level.
     *
     * @param array  $posts  Array of WP_Post objects
     * @param string $lang   Language code
     * @return array  Filtered posts
     */
    public static function filter_posts_by_lang( $posts, $lang = '' ) {
        if ( ! $lang ) $lang = self::get_current_lang();
        if ( ! $lang || ! self::is_multilingual() ) return $posts;

        return array_filter( $posts, function( $post ) use ( $lang ) {
            $post_id = is_object( $post ) ? $post->ID : (int) $post;
            $post_lang = HTS_Language::get_post_language( $post_id );
            // Keep if same lang, or if we can't detect the lang (empty)
            return $post_lang === $lang || $post_lang === '';
        } );
    }

    /**
     * Get the option key suffixed by language.
     * e.g. 'hts_cocon_data' → 'hts_cocon_data_fr'
     *
     * @param string $base_key
     * @param string $lang
     * @return string
     */
    public static function lang_option_key( $base_key, $lang = '' ) {
        if ( ! $lang ) $lang = self::get_current_lang();
        if ( ! self::is_multilingual() || ! $lang ) return $base_key;
        return $base_key . '_' . $lang;
    }

    /**
     * Clear the internal cache (useful during analysis).
     */
    public static function clear_cache() {
        self::$cache = array();
        self::$method = null;
    }
}
