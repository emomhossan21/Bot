/**
 * HTS Impact Tracker — Front-end visit tracking
 *
 * Lightweight: ~2KB minified. No dependencies.
 * Tracks: referrer (AI detection server-side), active time, scroll depth.
 * Sends data via navigator.sendBeacon on page unload for reliability.
 *
 * @since 1.7.0
 */
(function() {
    'use strict';

    if ( typeof htsTrack === 'undefined' || ! htsTrack.postId ) return;

    var startTime   = Date.now();
    var activeTime  = 0;
    var maxScroll   = 0;
    var isActive    = true;
    var sent        = false;
    var IDLE_MS     = 30000; // 30s idle = inactive
    var idleTimer   = null;

    /* ── Active time tracking ── */
    function resetIdle() {
        if ( ! isActive ) {
            isActive = true;
        }
        clearTimeout( idleTimer );
        idleTimer = setTimeout( function() { isActive = false; }, IDLE_MS );
    }

    // Track activity
    var events = ['mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    for ( var i = 0; i < events.length; i++ ) {
        document.addEventListener( events[i], resetIdle, { passive: true } );
    }
    resetIdle();

    // Update active time every 5 seconds
    setInterval( function() {
        if ( isActive ) {
            activeTime += 5;
        }
    }, 5000 );

    /* ── Scroll depth tracking ── */
    function updateScroll() {
        var docHeight = Math.max(
            document.body.scrollHeight,
            document.body.offsetHeight,
            document.documentElement.scrollHeight,
            document.documentElement.offsetHeight
        );
        var winHeight = window.innerHeight || document.documentElement.clientHeight;
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if ( docHeight <= winHeight ) {
            maxScroll = 100;
            return;
        }
        var pct = Math.round( ( scrollTop + winHeight ) / docHeight * 100 );
        if ( pct > maxScroll ) maxScroll = pct;
    }

    document.addEventListener( 'scroll', updateScroll, { passive: true } );
    // Initial check (page might be short enough to be 100%)
    setTimeout( updateScroll, 1000 );

    /* ── Send data ── */
    function buildPayload() {
        var elapsed = Math.round( ( Date.now() - startTime ) / 1000 );
        // Active time is at least the tracked intervals, capped at elapsed
        var finalActive = Math.min( activeTime, elapsed );

        var data = new FormData();
        data.append( 'action',       'hts_track_visit' );
        data.append( 'nonce',        htsTrack.nonce );
        data.append( 'post_id',      htsTrack.postId );
        data.append( 'active_time',  finalActive );
        data.append( 'scroll_depth', Math.min( maxScroll, 100 ) );
        data.append( 'referrer',     document.referrer || '' );
        return data;
    }

    function sendData() {
        if ( sent ) return;
        sent = true;

        var data = buildPayload();

        // Prefer sendBeacon (reliable on unload)
        if ( navigator.sendBeacon ) {
            navigator.sendBeacon( htsTrack.ajaxUrl, data );
        } else {
            // Fallback: sync XHR (less ideal but works)
            var xhr = new XMLHttpRequest();
            xhr.open( 'POST', htsTrack.ajaxUrl, false ); // sync
            xhr.send( data );
        }
    }

    /* ── Trigger on page leave ── */
    // visibilitychange is more reliable than beforeunload on mobile
    document.addEventListener( 'visibilitychange', function() {
        if ( document.visibilityState === 'hidden' ) {
            sendData();
        }
    } );

    // Fallback for older browsers
    window.addEventListener( 'beforeunload', sendData );

    // Also send after 5 minutes as safety net (long readers)
    setTimeout( function() {
        if ( ! sent ) {
            sent = true;
            var data = buildPayload();
            var xhr = new XMLHttpRequest();
            xhr.open( 'POST', htsTrack.ajaxUrl, true );
            xhr.send( data );
            // Allow re-send on unload with updated data
            setTimeout( function() { sent = false; }, 1000 );
        }
    }, 300000 ); // 5 min

})();
