<?php
defined( 'ABSPATH' ) || exit;
/**
 * Module : Auto-Write — Écriture automatique planifiée.
 *
 * Identifie les articles manquants (topical map + Strategy Engine),
 * vérifie les garde-fous, et propose l'écriture dans l'Inbox.
 * Supporte les articles standalone (sans cocon_id).
 *
 * Cron hebdomadaire (lundi) : identifie les sujets → propose dans Inbox.
 * L'exécution effective passe par Commander (cocon) ou API (standalone).
 *
 * @since 1.34.0 (Phase 5 — v2.0)
 * @package HackTheSEO
 */

class HTS_Auto_Write {

    /* ═══════════════════════════════════════════════
     *  CONSTANTES
     * ═══════════════════════════════════════════════ */

    const AGENT_ID                     = 'auto_write';
    const DEFAULT_MAX_ARTICLES_PER_WEEK = 3;
    const HARD_LIMIT_ARTICLES_PER_WEEK = 10;
    const CRON_HOOK                    = 'hts_auto_write_weekly';
    const CRON_HOOK_AUTO_SCHEDULE      = 'hts_auto_schedule_check';
    const OPTION_LAST_RUN              = 'hts_auto_write_last_run';
    const OPTION_QUEUE                 = 'hts_auto_write_queue';
    const OPTION_AUTO_SCHEDULE         = 'hts_auto_schedule_config';

    /* Sources de sujets */
    const SOURCE_TOPICAL_MAP  = 'topical_map';
    const SOURCE_STRATEGY     = 'strategy_engine';
    const SOURCE_MANUAL       = 'manual';

    /* ═══════════════════════════════════════════════
     *  INIT
     * ═══════════════════════════════════════════════ */

    public function init() {
        // Cron hebdomadaire
        add_action( self::CRON_HOOK, array( $this, 'cron_weekly_scan' ) );
        add_action( 'init', array( $this, 'register_cron' ) );

        // Cron auto-schedule (toutes les 6h)
        add_action( self::CRON_HOOK_AUTO_SCHEDULE, array( $this, 'cron_auto_schedule' ) );
        add_action( 'init', array( $this, 'register_auto_schedule_cron' ) );

        // Cron léger: poll les jobs en cours (toutes les 15 min)
        add_action( 'hts_poll_pending_jobs', array( $this, 'cron_poll_pending_jobs' ) );
        add_action( 'init', array( $this, 'register_poll_cron' ) );

        // Workflow dispatch handler
        add_filter( 'hts_workflow_dispatch', array( $this, 'handle_dispatch' ), 10, 5 );

        // AJAX handlers (admin only)
        add_action( 'wp_ajax_hts_auto_write_trigger', array( $this, 'ajax_trigger_scan' ) );
        add_action( 'wp_ajax_hts_emergency_stop_generation', array( $this, 'ajax_emergency_stop' ) );
        add_action( 'wp_ajax_hts_auto_write_config',  array( $this, 'ajax_update_config' ) );
        add_action( 'wp_ajax_hts_auto_write_queue',   array( $this, 'ajax_get_queue' ) );

        // AJAX auto-schedule
        add_action( 'wp_ajax_hts_save_auto_schedule',    array( $this, 'ajax_save_auto_schedule' ) );
        add_action( 'wp_ajax_hts_get_auto_schedule',     array( $this, 'ajax_get_auto_schedule' ) );
        add_action( 'wp_ajax_hts_trigger_auto_schedule', array( $this, 'ajax_trigger_auto_schedule' ) );
        add_action( 'wp_ajax_hts_force_auto_schedule',   array( $this, 'ajax_force_auto_schedule' ) );
        add_action( 'wp_ajax_hts_preview_auto_schedule', array( $this, 'ajax_preview_auto_schedule' ) );
        add_action( 'wp_ajax_hts_toggle_schedule_approval', array( $this, 'ajax_toggle_schedule_approval' ) );

        // Hook post publication (future → publish) for auto-scheduled articles
        add_action( 'transition_post_status', array( $this, 'on_auto_scheduled_publish' ), 15, 3 );
    }

    /**
     * Enregistre le cron hebdomadaire (lundi 06h00).
     */
    public function register_cron() {
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            // Prochain lundi 06:00 UTC
            $next_monday = strtotime( 'next Monday 06:00:00' );
            wp_schedule_event( $next_monday, 'weekly', self::CRON_HOOK );
        }
    }

    /**
     * Enregistre le cron auto-schedule (toutes les 6h).
     */
    public function register_auto_schedule_cron() {
        if ( ! isset( wp_get_schedules()['hts_six_hours'] ) ) return;
        if ( ! wp_next_scheduled( self::CRON_HOOK_AUTO_SCHEDULE ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hts_six_hours', self::CRON_HOOK_AUTO_SCHEDULE );
        }
    }

    /**
     * Cron léger toutes les 2 min : poll les articles en cours de génération.
     * Si rien à faire → return immédiat (< 1ms).
     * Si un job est prêt → crée le brouillon + images.
     */
    public function register_poll_cron() {
        if ( ! wp_next_scheduled( 'hts_poll_pending_jobs' ) ) {
            // 2 min interval: fast enough for sequential queue, light enough (returns instantly if nothing to do)
            wp_schedule_event( time() + 120, 'hts_two_minutes', 'hts_poll_pending_jobs' );
        }
    }

    /**
     * Lightweight cron (every 2 min):
     *
     * 1. DISPATCH: If any articles are in 'pending_queue', send ONE to the API
     *    (sequential processing — protects the SaaS from N simultaneous requests).
     * 2. POLL: Check if any 'queued' articles (with job_id) are ready,
     *    and create drafts + images if so.
     *
     * If nothing to do → return immediately (< 1ms).
     */
    public function cron_poll_pending_jobs() {
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) return;

        $commander = new HTS_Cocon_Commander();
        $plans     = $commander->get_plans();

        // ── Check for emergency stop flag ──
        if ( get_transient( 'hts_generation_emergency_stop' ) ) {
            // Cancel all pending_queue articles
            $cancelled = 0;
            foreach ( $plans as $cocon_id => $plan ) {
                if ( empty( $plan['articles'] ) ) continue;
                foreach ( $plan['articles'] as $akey => $art ) {
                    $st = $art['status'] ?? '';
                    if ( $st === 'pending_queue' ) {
                        $commander->update_article_status( $cocon_id, $akey, 'to_generate', array(
                            'cancelled_at' => current_time( 'Y-m-d H:i:s' ),
                        ) );
                        $cancelled++;
                    }
                }
            }
            if ( $cancelled > 0 ) {
                HTS_Cocon_Commander::cocon_log( 'emergency_stop', sprintf(
                    '🛑 Arrêt d\'urgence : %d article(s) retirés de la file d\'attente', $cancelled
                ), array() );
            }
            delete_transient( 'hts_generation_emergency_stop' );
            return; // Don't process anything this cycle
        }

        // ── PHASE 1: Dispatch ONE pending_queue article to the API ──
        // Concurrency lock: only 1 API call at a time across all crons/users
        $dispatch_lock = 'hts_dispatch_lock';
        $dispatched    = false;

        // Stale lock recovery: if lock exists but no active job, the lock is orphaned
        $lock_val = get_transient( $dispatch_lock );
        if ( $lock_val ) {
            $has_active_job_for_lock = false;
            foreach ( $plans as $plan ) {
                if ( empty( $plan['articles'] ) ) continue;
                foreach ( $plan['articles'] as $art ) {
                    if ( ( $art['status'] ?? '' ) === 'queued' && ! empty( $art['job_id'] ) ) {
                        $has_active_job_for_lock = true;
                        break 2;
                    }
                }
            }
            if ( ! $has_active_job_for_lock ) {
                // Lock is orphaned (PHP timeout or crash during API call) — clear it
                delete_transient( $dispatch_lock );
                $lock_val = false;
                HTS_Cocon_Commander::cocon_log( 'dispatch_lock_recovery', '🔓 Lock dispatch orphelin nettoyé (aucun job actif)', array() );
            }
        }

        if ( ! $lock_val ) {
            // Also check: don't dispatch if there's already an active job being generated
            $has_active_job = false;
            foreach ( $plans as $plan ) {
                if ( empty( $plan['articles'] ) ) continue;
                foreach ( $plan['articles'] as $art ) {
                    if ( ( $art['status'] ?? '' ) === 'queued' && ! empty( $art['job_id'] ) ) {
                        $has_active_job = true;
                        break 2;
                    }
                }
            }

            if ( ! $has_active_job ) {
                // Find the oldest pending_queue article
                $best_cocon  = null;
                $best_akey   = null;
                $best_art    = null;
                $best_time   = '9999-99-99';

                foreach ( $plans as $cocon_id => $plan ) {
                    if ( empty( $plan['articles'] ) ) continue;
                    foreach ( $plan['articles'] as $akey => $art ) {
                        if ( ( $art['status'] ?? '' ) !== 'pending_queue' ) continue;
                        $qt = $art['queued_at'] ?? '9999-99-99';
                        if ( $qt < $best_time ) {
                            $best_time  = $qt;
                            $best_cocon = $cocon_id;
                            $best_akey  = $akey;
                            $best_art   = $art;
                        }
                    }
                }

                if ( $best_cocon && $best_akey && $best_art ) {
                    // Lock for 10 min to prevent parallel dispatch
                    set_transient( $dispatch_lock, time(), 10 * MINUTE_IN_SECONDS );

                    $plan = $commander->get_plan( $best_cocon );
                    if ( $plan ) {
                        $siblings        = $commander->get_existing_siblings( $best_cocon );
                        $pillar_post_id  = hts_url_to_postid( $plan['pillar_url'] ?? '' );
                        $pillar_title    = $pillar_post_id ? get_the_title( $pillar_post_id ) : '';
                        $topic_id        = (int) ( $best_art['topic_id'] ?? 0 );

                        $api_body = array(
                            'cocon_id'          => $best_cocon,
                            'topic_id'          => $topic_id,
                            'site_url'          => site_url(),
                            'pillar_url'        => $plan['pillar_url'] ?? '',
                            'pillar_title'      => $pillar_title,
                            'siblings'          => $siblings,
                            'recommended_links' => $commander->get_recommended_links( $best_cocon ),
                            'language'          => $plan['language'] ?? 'fr-FR',
                            'auto_validate'     => true,
                        );

                        $result = $commander->cocon_api_call_public( 'POST', 'generate-article', $api_body );

                        if ( $result['success'] && ! empty( $result['data']['job_id'] ) ) {
                            $commander->update_article_status( $best_cocon, $best_akey, HTS_Cocon_Commander::STATUS_QUEUED, array(
                                'ordered_at' => current_time( 'Y-m-d H:i:s' ),
                                'job_id'     => $result['data']['job_id'],
                                'topic_id'   => $topic_id,
                            ) );

                            HTS_Cocon_Commander::cocon_log( 'queue_dispatched', sprintf(
                                '📤 Article envoyé à l\'API : « %s »',
                                mb_substr( $best_art['title'] ?? $best_art['keyword'] ?? '?', 0, 50 )
                            ), array(
                                'cocon_id' => $best_cocon,
                                'job_id'   => $result['data']['job_id'],
                            ) );

                            $dispatched = true;
                        } else {
                            $commander->update_article_status( $best_cocon, $best_akey, 'error', array(
                                'error_reason' => $result['error'] ?? 'Échec envoi API',
                            ) );
                            delete_transient( $dispatch_lock );

                            HTS_Cocon_Commander::cocon_log( 'queue_dispatch_error', sprintf(
                                'Échec envoi API : « %s » — %s',
                                $best_art['title'] ?? '?',
                                $result['error'] ?? 'Erreur inconnue'
                            ), array( 'cocon_id' => $best_cocon ) );
                        }
                    } else {
                        delete_transient( $dispatch_lock );
                    }
                }
            }
        }

        // ── PHASE 2: Poll existing queued jobs (with job_id) ──
        // Refresh plans in case Phase 1 modified them
        $plans     = $commander->get_plans();
        $processed = 0;

        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) ) continue;

            foreach ( $plan['articles'] as $akey => $art ) {
                if ( ( $art['status'] ?? '' ) !== 'queued' ) continue;
                if ( empty( $art['job_id'] ) ) continue;

                // ── Timeout: if queued for > 30 min, mark as error ──
                $ordered_at = $art['ordered_at'] ?? '';
                if ( ! empty( $ordered_at ) ) {
                    $elapsed = time() - strtotime( $ordered_at );
                    if ( $elapsed > 30 * MINUTE_IN_SECONDS ) {
                        $commander->update_article_status( $cocon_id, $akey, 'error', array(
                            'error_reason' => 'Timeout : pas de réponse API après 30 min',
                        ) );
                        delete_transient( $dispatch_lock );

                        HTS_Cocon_Commander::cocon_log( 'article_timeout', sprintf(
                            '⏰ Timeout : « %s » — aucune réponse après 30 min',
                            mb_substr( $art['title'] ?? $art['keyword'] ?? '?', 0, 50 )
                        ), array( 'cocon_id' => $cocon_id, 'job_id' => $art['job_id'] ) );
                        continue;
                    }
                }

                // Poll API for this job
                $result = $commander->cocon_api_call_public( 'GET', 'article-status/' . $art['job_id'] );
                if ( ! $result['success'] ) continue;

                $status = $result['data']['status'] ?? 'unknown';

                if ( $status === 'completed' && ! empty( $result['data']['article'] ) ) {
                    // Anti-accumulation: don't create more drafts if too many pending
                    if ( ! self::check_draft_accumulation() ) {
                        HTS_Cocon_Commander::cocon_log( 'cron_accumulation', '⏸️ Trop de brouillons non validés — création différée', array(
                            'cocon_id' => $cocon_id,
                            'job_id'   => $art['job_id'],
                        ) );
                        // Don't create draft but keep the job active — next cron will retry
                        continue;
                    }

                    // Release dispatch lock — this job is done, next one can start
                    delete_transient( $dispatch_lock );

                    // Store article in transient
                    $transient_key = 'hts_article_' . $art['job_id'];
                    set_transient( $transient_key, $result['data']['article'], 7200 ); // G3: 2h au lieu d'1h

                    // Create draft
                    $draft = $commander->create_draft_from_article( $cocon_id, $akey, $art['job_id'] );

                    if ( $draft && ! empty( $draft['post_id'] ) ) {
                        // Note: images are already scheduled via HTS_Article_Pipeline::enrich_draft()
                        // called from create_draft_from_article → hts_deferred_images cron.
                        // Do NOT call cocon_generate_article_images() here — it would double-generate.

                        HTS_Cocon_Commander::cocon_log( 'cron_draft_created', '🤖 Brouillon créé (images programmées en arrière-plan)', array(
                            'post_id' => $draft['post_id'],
                            'title'   => $draft['title'] ?? '',
                            'cocon'   => $cocon_id,
                        ) );

                        $processed++;
                    }
                } elseif ( $status === 'failed' || $status === 'error' ) {
                    // Release dispatch lock — error, let next one proceed
                    delete_transient( $dispatch_lock );

                    $commander->update_article_status( $cocon_id, $akey, 'error', array(
                        'error_reason' => $result['data']['message'] ?? 'Échec API',
                    ) );
                }
                // If still pending → do nothing, check again next cron cycle
            }
        }

        if ( $processed > 0 ) {
            hts_add_log(
                sprintf( '🤖 Cron poll: %d article(s) récupéré(s) et brouillon(s) créé(s)', $processed ),
                'success', 'auto-write'
            );
        }

        // ── PHASE 3: Cleanup completed standalone plans (older than 24h) ──
        $plans = $commander->get_plans();
        $cleaned = 0;
        $terminal_statuses = array( 'received', 'published', 'error' );
        foreach ( $plans as $cid => $plan ) {
            if ( empty( $plan['standalone'] ) ) continue;

            // Check if plan is done: status 'completed' OR all articles in terminal state
            $plan_status = $plan['status'] ?? '';
            $is_done = ( $plan_status === 'completed' );
            if ( ! $is_done && ! empty( $plan['articles'] ) ) {
                $is_done = true;
                foreach ( $plan['articles'] as $a ) {
                    if ( ! in_array( $a['status'] ?? '', $terminal_statuses, true ) ) {
                        $is_done = false;
                        break;
                    }
                }
            }

            if ( ! $is_done ) continue;

            $updated = strtotime( $plan['updated_at'] ?? '' );
            if ( $updated && ( time() - $updated ) > 86400 ) {
                unset( $plans[ $cid ] );
                $cleaned++;
            }
        }
        if ( $cleaned > 0 ) {
            // Use atomic write lock for plans update
            if ( hts_acquire_lock( 'plans_write', 5, 10, 150 ) ) {
            update_option( \HTS_Cocon_Commander::PLANS_OPTION, $plans, false );
            hts_release_lock( 'plans_write' );
            HTS_Cocon_Commander::cocon_log( 'standalone_cleanup', sprintf(
                '%d plan(s) standalone terminé(s) nettoyé(s)', $cleaned
            ), array() );
            }
        }
    }

    /* ═══════════════════════════════════════════════
     *  CRON : SCAN HEBDOMADAIRE
     * ═══════════════════════════════════════════════ */

    /**
     * Scan hebdomadaire : identifie les sujets à écrire et propose dans l'Inbox.
     *
     * @return array Résumé { topics_found, proposed, skipped_cannib, skipped_budget }
     */
    public function cron_weekly_scan() {
        if ( class_exists( 'HTS_Subscription' ) && HTS_Subscription::get_plan_tier() < 2 ) return;
        $start = microtime( true );

        // ── 1. Agent activé ? ──
        if ( ! self::is_enabled() ) {
            self::log( 'Auto-Write désactivé — scan ignoré', 'info' );
            return array( 'skipped' => 'disabled' );
        }

        // ── 2. Budget OK ? ──
        if ( ! self::check_budget_guard() ) {
            self::log( 'Auto-Write : budget API épuisé — scan ignoré', 'warn' );
            return array( 'skipped' => 'budget' );
        }

        // ── 3. Collecter les sujets ──
        $topics = self::collect_topics();

        // ── 4. Appliquer la limite/semaine ──
        $max_per_week = self::get_max_articles_per_week();
        $already_this_week = self::count_articles_this_week();
        $remaining = max( 0, $max_per_week - $already_this_week );

        if ( $remaining <= 0 ) {
            self::log( sprintf(
                'Auto-Write : limite atteinte (%d/%d cette semaine) — pas de nouvelles propositions',
                $already_this_week, $max_per_week
            ), 'info' );
            return array( 'skipped' => 'limit_reached', 'already' => $already_this_week );
        }

        $topics = array_slice( $topics, 0, $remaining );

        // ── 5. Pre-check chaque sujet + proposer dans Inbox ──
        $proposed = 0;
        $skipped_cannib = 0;
        $skipped_other = 0;

        foreach ( $topics as $topic ) {
            try {
                $check_result = self::pre_check_topic( $topic );

                if ( $check_result === 'cannib' ) {
                    $skipped_cannib++;
                    continue;
                }

                if ( $check_result === 'skip' ) {
                    $skipped_other++;
                    continue;
                }

                // Proposer dans l'Inbox
                $action_type = ! empty( $topic['cocon_id'] ) ? 'article_write_cocon' : 'article_write_standalone';

                if ( class_exists( 'HTS_Workflow_Engine' ) ) {
                    HTS_Workflow_Engine::propose(
                        self::AGENT_ID,
                        $action_type,
                        0, // pas de post_id existant
                        array(
                            'keyword'     => $topic['keyword'],
                            'title'       => $topic['title'] ?? '',
                            'cocon_id'    => $topic['cocon_id'] ?? '',
                            'topic_id'    => $topic['topic_id'] ?? 0,
                            'article_key' => $topic['article_key'] ?? '',
                            'source'      => $topic['source'],
                            'reason'      => $topic['reason'] ?? 'Sujet identifié par le scan automatique',
                            'intent'      => $topic['intent'] ?? 'info',
                        ),
                        $topic['priority'] ?? 'medium'
                    );
                    $proposed++;
                }
            } catch ( \Exception $e ) {
                self::log( 'Auto-Write erreur sujet "' . ( $topic['keyword'] ?? '?' ) . '" : ' . $e->getMessage(), 'error' );
                $skipped_other++;
                // Skip, pas de crash — gate debug
                continue;
            }
        }

        // ── 6. Stocker le résultat ──
        $result = array(
            'topics_found'   => count( $topics ) + $skipped_cannib + $skipped_other,
            'proposed'       => $proposed,
            'skipped_cannib' => $skipped_cannib,
            'skipped_other'  => $skipped_other,
            'remaining_week' => $remaining - $proposed,
            'duration_ms'    => round( ( microtime( true ) - $start ) * 1000 ),
        );

        update_option( self::OPTION_LAST_RUN, array_merge( $result, array(
            'date' => current_time( 'mysql' ),
        ) ), false );

        self::log( sprintf(
            'Auto-Write scan terminé : %d sujets proposés, %d cannibalisation, %d ignorés (%dms)',
            $proposed, $skipped_cannib, $skipped_other, $result['duration_ms']
        ), $proposed > 0 ? 'success' : 'info' );

        return $result;
    }

    /* ═══════════════════════════════════════════════
     *  COLLECTE DES SUJETS
     * ═══════════════════════════════════════════════ */

    /**
     * Collecte les sujets depuis les deux sources.
     * A) Topical map (articles manquants)
     * B) Strategy Engine (opportunités content gaps)
     *
     * @return array [ { keyword, title, cocon_id, topic_id, source, reason, priority, intent } ]
     */
    public static function collect_topics() {
        $topics = array();

        // ── Source A : Topical Map (articles to_generate dans les cocoons) ──
        $topics = array_merge( $topics, self::collect_from_topical_map() );

        // ── Source B : Strategy Engine (opportunités) ──
        $topics = array_merge( $topics, self::collect_from_strategy() );

        // Dédupliquer par keyword
        $seen = array();
        $unique = array();
        foreach ( $topics as $t ) {
            $kw_key = mb_strtolower( trim( $t['keyword'] ) );
            if ( isset( $seen[ $kw_key ] ) ) continue;
            $seen[ $kw_key ] = true;
            $unique[] = $t;
        }

        // Trier par priorité : high > medium > low
        $priority_map = array( 'critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1 );
        usort( $unique, function( $a, $b ) use ( $priority_map ) {
            $pa = $priority_map[ $a['priority'] ?? 'medium' ] ?? 2;
            $pb = $priority_map[ $b['priority'] ?? 'medium' ] ?? 2;
            return $pb <=> $pa;
        });

        return $unique;
    }

    /**
     * Source A : Articles manquants dans les topical maps.
     */
    private static function collect_from_topical_map() {
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) return array();

        $commander = new HTS_Cocon_Commander();
        $plans = $commander->get_plans();
        $topics = array();

        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) || ! is_array( $plan['articles'] ) ) continue;

            foreach ( $plan['articles'] as $key => $art ) {
                // Uniquement les articles à générer
                if ( ( $art['status'] ?? '' ) !== HTS_Cocon_Commander::STATUS_TO_GENERATE ) continue;

                $topics[] = array(
                    'keyword'     => $art['keyword'] ?? '',
                    'title'       => $art['title'] ?? $art['keyword'] ?? '',
                    'cocon_id'    => $cocon_id,
                    'topic_id'    => $art['topic_id'] ?? 0,
                    'article_key' => $key,
                    'source'      => self::SOURCE_TOPICAL_MAP,
                    'reason'      => sprintf(
                        'Article manquant dans le cocon « %s »',
                        $plan['pillar_title'] ?? $cocon_id
                    ),
                    'priority'    => 'high',
                    'intent'      => $art['intent'] ?? 'info',
                );
            }
        }

        return $topics;
    }

    /**
     * Source B : Opportunités identifiées par Strategy Engine.
     * Filtre : uniquement les actions de type "new_content" / "content_gap".
     */
    private static function collect_from_strategy() {
        if ( ! class_exists( 'HTS_Strategy_Engine' ) ) return array();

        $plan = HTS_Strategy_Engine::get_monthly_plan();
        if ( ! $plan || empty( $plan['weeks'] ) ) return array();

        $topics = array();
        $content_actions = array( 'new_content', 'content_gap', 'create_pillar', 'expand_cluster' );

        foreach ( $plan['weeks'] as $week ) {
            if ( empty( $week['items'] ) ) continue;
            foreach ( $week['items'] as $item ) {
                if ( ! in_array( $item['action_type'] ?? '', $content_actions, true ) ) continue;

                // Uniquement les items sans post_id (= articles à créer, pas à modifier)
                if ( ! empty( $item['post_id'] ) ) continue;

                $keyword = $item['keyword'] ?? $item['title'] ?? '';
                if ( empty( $keyword ) ) continue;

                $topics[] = array(
                    'keyword'     => $keyword,
                    'title'       => $item['title'] ?? $keyword,
                    'cocon_id'    => '', // standalone
                    'topic_id'    => 0,
                    'article_key' => '',
                    'source'      => self::SOURCE_STRATEGY,
                    'reason'      => $item['why'] ?? 'Opportunité identifiée par le Strategy Engine',
                    'priority'    => 'medium',
                    'intent'      => $item['intent'] ?? 'info',
                );
            }
        }

        return $topics;
    }

    /* ═══════════════════════════════════════════════
     *  PRE-CHECKS
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifie un sujet avant de le proposer.
     * 1. Check cannibalisation
     * 2. Check budget
     * 3. Check limite/semaine
     *
     * @param array $topic
     * @return string 'ok' | 'cannib' | 'skip'
     */
    public static function pre_check_topic( $topic ) {
        $keyword = $topic['keyword'] ?? '';
        $title   = $topic['title'] ?? '';

        // ── Check cannibalisation (systématique) ──
        if ( class_exists( 'HTS_Cannibalization_Merge' ) && ! empty( $keyword ) ) {
            $cannib = HTS_Cannibalization_Merge::pre_check( $keyword, $title );
            if ( $cannib && $cannib['action'] === 'block' ) {
                self::log( sprintf(
                    'Auto-Write : sujet « %s » bloqué — cannibalisation avec #%d',
                    $keyword, $cannib['post_id']
                ), 'warn' );
                return 'cannib';
            }
        }

        // ── Check via filtre Commander (d'autres modules peuvent bloquer) ──
        /**
         * Filter: allow modules to block auto-write for a keyword.
         *
         * @since 1.33.0
         * @param bool   $allow   Whether to allow writing. Return false to block.
         * @param string $keyword Target keyword.
         * @param string $title   Proposed title.
         */
        $pre_write = apply_filters( 'hts_commander_pre_write_check', true, $keyword, $title );
        if ( $pre_write === false ) {
            return 'cannib'; // Un module a bloqué
        }

        return 'ok';
    }

    /* ═══════════════════════════════════════════════
     *  WORKFLOW DISPATCH
     * ═══════════════════════════════════════════════ */

    /**
     * Handler de dispatch pour les actions auto_write approuvées.
     *
     * @param bool|null $result
     * @param string    $agent
     * @param string    $type
     * @param int       $post_id
     * @param array     $data
     * @return bool|null
     */
    public function handle_dispatch( $result, $agent, $type, $post_id, $data ) {
        if ( $agent !== self::AGENT_ID ) return $result;

        if ( $type === 'article_write_cocon' ) {
            return $this->dispatch_cocon_write( $data );
        }

        if ( $type === 'article_write_standalone' ) {
            return $this->dispatch_standalone_write( $data );
        }

        return $result;
    }

    /**
     * Exécute l'écriture d'un article cocon (via Commander → API HTS).
     */
    private function dispatch_cocon_write( $data ) {
        $cocon_id    = $data['cocon_id'] ?? '';
        $topic_id    = $data['topic_id'] ?? 0;
        $article_key = $data['article_key'] ?? '';
        $keyword     = $data['keyword'] ?? '';

        if ( empty( $cocon_id ) || empty( $keyword ) ) {
            self::log( 'dispatch_cocon_write : données incomplètes', 'error' );
            return false;
        }

        // Re-check budget
        if ( ! self::check_budget_guard() ) {
            self::log( 'dispatch_cocon_write : budget épuisé — annulé', 'warn' );
            return false;
        }

        // Re-check cannibalisation (car du temps a pu passer depuis la proposition)
        if ( self::pre_check_topic( $data ) !== 'ok' ) {
            self::log( 'dispatch_cocon_write : cannibalisation détectée au moment de l\'exécution', 'warn' );
            return false;
        }

        // Appeler le Commander pour lancer la génération via l'API
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) return false;

        $commander = new HTS_Cocon_Commander();
        $plan = $commander->get_plan( $cocon_id );
        if ( ! $plan ) {
            self::log( 'dispatch_cocon_write : plan cocon introuvable — ' . $cocon_id, 'error' );
            return false;
        }

        // Simuler un appel API comme ajax_generate_article
        $siblings      = $commander->get_existing_siblings( $cocon_id );
        $pillar_post_id = hts_url_to_postid( $plan['pillar_url'] ?? '' );
        $pillar_title   = $pillar_post_id ? get_the_title( $pillar_post_id ) : '';

        $api_result = $commander->cocon_api_call_public( 'POST', 'generate-article', array(
            'cocon_id'          => $cocon_id,
            'topic_id'          => $topic_id,
            'site_url'          => site_url(),
            'pillar_url'        => $plan['pillar_url'] ?? '',
            'pillar_title'      => $pillar_title,
            'siblings'          => $siblings,
            'recommended_links' => $commander->get_recommended_links( $cocon_id ),
            'language'          => $plan['language'] ?? 'fr-FR',
            'auto_validate'     => true,
        ) );

        if ( ! $api_result['success'] ) {
            self::log( 'dispatch_cocon_write : erreur API — ' . ( $api_result['error'] ?? 'inconnue' ), 'error' );
            return false;
        }

        // Marquer comme en queue
        if ( ! empty( $article_key ) ) {
            $commander->update_article_status( $cocon_id, $article_key, HTS_Cocon_Commander::STATUS_QUEUED, array(
                'ordered_at'  => current_time( 'Y-m-d H:i:s' ),
                'job_id'      => $api_result['data']['job_id'] ?? '',
                'auto_write'  => true,
            ) );
        }

        self::log( sprintf(
            'Auto-Write : article cocon lancé — « %s » (cocon %s)',
            $keyword, $cocon_id
        ), 'success' );

        return true;
    }

    /**
     * Exécute l'écriture d'un article standalone (via API HTS, sans cocon_id).
     */
    private function dispatch_standalone_write( $data ) {
        $keyword = $data['keyword'] ?? '';
        $title   = $data['title'] ?? $keyword;
        $intent  = $data['intent'] ?? 'info';

        if ( empty( $keyword ) ) {
            self::log( 'dispatch_standalone_write : keyword manquant', 'error' );
            return false;
        }

        // Re-check budget
        if ( ! self::check_budget_guard() ) {
            self::log( 'dispatch_standalone_write : budget épuisé — annulé', 'warn' );
            return false;
        }

        // Re-check cannibalisation
        if ( self::pre_check_topic( $data ) !== 'ok' ) {
            self::log( 'dispatch_standalone_write : cannibalisation détectée', 'warn' );
            return false;
        }

        // Appel API HTS pour article standalone (sans cocon_id)
        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) {
            self::log( 'dispatch_standalone_write : Commander absent', 'error' );
            return false;
        }

        $commander = new \HTS_Cocon_Commander();
        $api_result = $commander->cocon_api_call_public( 'POST', 'generate-article', array(
            'keyword'       => $keyword,
            'title'         => $title,
            'site_url'      => site_url(),
            'language'      => get_option( 'hts_language', 'fr-FR' ),
            'intent'        => $intent,
            'standalone'    => true,
            'auto_validate' => true,
        ) );

        if ( ! $api_result['success'] ) {
            self::log( 'dispatch_standalone_write : erreur API — ' . ( $api_result['error'] ?? 'inconnue' ), 'error' );
            return false;
        }

        $body = $api_result['data'];
        $code = $api_result['status'];

        $job_id = $body['job_id'] ?? '';
        if ( empty( $job_id ) ) {
            self::log( 'dispatch_standalone_write : pas de job_id dans la réponse API', 'error' );
            return false;
        }

        // ── Store job in Commander plan so cron_poll_pending_jobs() can track it ──
        // Create a pseudo-plan for standalone articles; cron polls all plans uniformly.
        $standalone_id = 'standalone_' . substr( md5( $keyword . time() ), 0, 12 );
        $article_key   = md5( $keyword );

        // Use atomic write lock to prevent race with cron update_article_status
        if ( ! hts_acquire_lock( 'plans_write', 5, 10, 150 ) ) {
            self::log( 'Write lock timeout pour standalone dispatch — article ignoré', 'warning' );
            return array( 'dispatched' => false, 'error' => 'lock_timeout' );
        }

        $plans = $commander->get_plans();
        $plans[ $standalone_id ] = array(
            'cocon_id'      => $standalone_id,
            'pillar_url'    => '',
            'pillar_title'  => '',
            'keyword'       => $keyword,
            'language'      => get_option( 'hts_language', 'fr-FR' ),
            'status'        => 'success',
            'standalone'    => true,
            'articles'      => array(
                $article_key => array(
                    'keyword'    => $keyword,
                    'title'      => $title,
                    'intent'     => $intent,
                    'status'     => 'queued',
                    'job_id'     => $job_id,
                    'ordered_at' => current_time( 'Y-m-d H:i:s' ),
                    'auto_write' => true,
                    'post_id'    => null,
                ),
            ),
            'article_count' => 1,
            'received_at'   => current_time( 'Y-m-d H:i:s' ),
            'updated_at'    => current_time( 'Y-m-d H:i:s' ),
            'articles_gen'  => array(),
        );
        update_option( \HTS_Cocon_Commander::PLANS_OPTION, $plans, false );
        hts_release_lock( 'plans_write' );

        HTS_Cocon_Commander::cocon_log( 'standalone_dispatched', sprintf(
            '📤 Article standalone « %s » envoyé à l\u0027API (job: %s)',
            mb_substr( $keyword, 0, 50 ), $job_id
        ), array( 'plan_id' => $standalone_id, 'job_id' => $job_id ) );

        self::log( sprintf(
            'Auto-Write : article standalone lancé — « %s » (job: %s)',
            $keyword, $job_id
        ), 'success' );

        return true;
    }

    /* ═══════════════════════════════════════════════
     *  CALENDRIER — PUBLISH CONDITIONS
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifie si un article peut être publié automatiquement.
     * Conditions :
     * 1. A une featured_image
     * 2. GEO score > seuil configuré
     * 3. Mode auto activé pour l'agent (sauf si $skip_mode_check)
     *
     * @param int  $post_id
     * @param bool $skip_mode_check  true lors d'un déclenchement manuel
     * @return array { can_publish, reasons[] }
     */
    public static function check_auto_publish_conditions( $post_id, $skip_mode_check = false ) {
        $reasons = array();

        // ── Featured image ──
        if ( ! has_post_thumbnail( $post_id ) ) {
            $reasons[] = 'Pas d\'image à la une';
        }

        // ── P3: Contenu minimum (évite publication d'articles vides) ──
        $post_content = get_post_field( 'post_content', $post_id );
        $word_count   = hts_word_count( wp_strip_all_tags( $post_content ) );
        if ( $word_count < 100 ) {
            $reasons[] = sprintf( 'Contenu insuffisant (%d mots, minimum 100)', $word_count );
        }

        // ── GEO Score ──
        $min_geo = (int) get_option( 'hts_auto_publish_min_geo', 50 );
        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $geo_obj = new HTS_Geo_Score();
            $geo = $geo_obj->calculate( $post_id );
            if ( $geo && isset( $geo['geo_score'] ) && $geo['geo_score'] < $min_geo ) {
                $reasons[] = sprintf( 'Score GEO insuffisant (%d/%d minimum)', $geo['geo_score'], $min_geo );
            }
        }

        // ── Mode auto (sauté si déclenchement manuel) ──
        if ( ! $skip_mode_check && class_exists( 'HTS_Workflow_Engine' ) ) {
            $agents = HTS_Workflow_Engine::get_all_agents();
            $auto_write = $agents[ self::AGENT_ID ] ?? array();
            if ( ( $auto_write['mode'] ?? 'review' ) !== 'auto' ) {
                $reasons[] = 'Mode auto non activé (mode relecture)';
            }
        }

        return array(
            'can_publish' => empty( $reasons ),
            'reasons'     => $reasons,
        );
    }

    /**
     * Post-publication hooks : IndexNow + Freshness + GEO recalcul.
     *
     * @param int $post_id
     */
    public static function post_publish_hooks( $post_id ) {
        // ── IndexNow ──
        if ( class_exists( 'HTS_IndexNow' ) && method_exists( 'HTS_IndexNow', 'notify' ) ) {
            HTS_IndexNow::notify( get_permalink( $post_id ) );
        }

        // ── Freshness update ──
        // Le score se recalcule automatiquement (basé sur post_modified)

        // ── GEO Score recalcul ──
        if ( class_exists( 'HTS_Geo_Score' ) ) {
            $geo_obj = new HTS_Geo_Score();
            $geo_obj->calculate( $post_id, true ); // force recalcul
        }

        // ── Audit Trail ──
        if ( class_exists( 'HTS_Audit_Trail' ) ) {
            HTS_Audit_Trail::log( $post_id, 'auto_published', array(
                'source' => 'auto_write',
                'time'   => current_time( 'mysql' ),
            ) );
        }

        self::log( sprintf( 'Auto-Write : article #%d publié + IndexNow + GEO recalcul', $post_id ), 'success' );
    }

    /* ═══════════════════════════════════════════════
     *  IMAGES — SOURCE SELECTION
     * ═══════════════════════════════════════════════ */

    /**
     * Cherche une image pertinente dans la bibliothèque média WP.
     * Avant de générer via DALL-E, on vérifie si une image existe déjà.
     *
     * @param string $keyword  Keyword pour la recherche
     * @param string $title    Titre article pour fallback
     * @return int|null         Attachment ID ou null
     */
    public static function find_existing_media_image( $keyword, $title = '' ) {
        if ( empty( $keyword ) && empty( $title ) ) return null;

        $search_terms = array_filter( array( $keyword, $title ) );

        foreach ( $search_terms as $term ) {
            $query = new \WP_Query( array(
                'post_type'      => 'attachment',
                'post_mime_type' => 'image',
                'post_status'    => 'inherit',
                's'              => $term,
                'posts_per_page' => 1,
                'orderby'        => 'relevance',
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ) );

            if ( $query->have_posts() ) {
                return $query->posts[0];
            }
        }

        return null;
    }

    /**
     * Obtient la source d'image préférée pour l'agent.
     *
     * @return string 'library_first' | 'dalle' | 'pexels'
     */
    public static function get_image_source_preference() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 'library_first';
        $settings = HTS_Workflow_Engine::get_agent_settings( self::AGENT_ID );
        return $settings['image_source'] ?? 'library_first';
    }

    /* ═══════════════════════════════════════════════
     *  GUARDS & HELPERS
     * ═══════════════════════════════════════════════ */

    /**
     * Vérifie si l'agent auto_write est activé.
     */
    public static function is_enabled() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return false;
        $agents = HTS_Workflow_Engine::get_all_agents();
        return ! empty( $agents[ self::AGENT_ID ]['enabled'] );
    }

    /**
     * Budget guard avec hard limit.
     * Même si la config est corrompue, on ne dépasse jamais le hard limit.
     */
    public static function check_budget_guard() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return false;
        return HTS_Workflow_Engine::check_budget();
    }

    /**
     * Obtient le max articles/semaine (avec hard limit de sécurité).
     */
    public static function get_max_articles_per_week() {
        $configured = self::DEFAULT_MAX_ARTICLES_PER_WEEK;

        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $settings = HTS_Workflow_Engine::get_agent_settings_with_defaults( self::AGENT_ID );
            // Support both legacy key (max_articles_per_week) and schema key (max_articles_week)
            if ( isset( $settings['max_articles_week'] ) ) {
                $configured = (int) $settings['max_articles_week'];
            } elseif ( isset( $settings['max_articles_per_week'] ) ) {
                $configured = (int) $settings['max_articles_per_week'];
            }
        }

        // Hard limit : même si quelqu'un met 999 dans la config
        return min( $configured, self::HARD_LIMIT_ARTICLES_PER_WEEK );
    }

    /**
     * Récupère le mode de publication depuis les agent settings.
     *
     * @since 2.4.3
     * @return string 'draft' ou 'publish'
     */
    public static function get_publish_mode() {
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $settings = HTS_Workflow_Engine::get_agent_settings_with_defaults( self::AGENT_ID );
            if ( isset( $settings['publish_mode'] ) && in_array( $settings['publish_mode'], array( 'draft', 'publish' ), true ) ) {
                return $settings['publish_mode'];
            }
        }
        return 'draft';
    }

    /**
     * Compte les articles auto-write proposés/écrits cette semaine.
     */
    public static function count_articles_this_week() {
        if ( ! class_exists( 'HTS_Workflow_Engine' ) ) return 0;

        global $wpdb;
        $table = $wpdb->prefix . 'hts_workflow_actions';

        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( ! $exists ) return 0;

        $week_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) );

        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE agent = %s AND type IN ('article_write_cocon','article_write_standalone') AND status IN ('pending','approved','executing','done') AND created_at >= %s",
            self::AGENT_ID, $week_ago
        ) );
    }

    /**
     * Vérifie que les brouillons auto ne s'accumulent pas.
     * Si > 5 brouillons auto non validés → bloquer.
     *
     * @return bool true si OK, false si accumulation détectée
     */
    public static function check_draft_accumulation() {
        global $wpdb;

        $count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_auto_write'
             WHERE p.post_status = 'draft' AND pm.meta_value = '1'"
        );

        $max_pending_drafts = 5;
        if ( $count >= $max_pending_drafts ) {
            self::log( sprintf(
                'Auto-Write : %d brouillons non validés — écriture suspendue',
                $count
            ), 'warn' );
            return false;
        }

        return true;
    }

    /* ═══════════════════════════════════════════════
     *  AJAX HANDLERS
     * ═══════════════════════════════════════════════ */

    /**
     * Déclenche un scan manuel.
     */
    /**
     * AJAX: Emergency stop — cancel all pending_queue and mark queued as cancelled.
     * This prevents the cron from dispatching new articles and ignores already-queued results.
     */
    public function ajax_emergency_stop() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) wp_send_json_error( 'Commander absent.' );

        $commander = new \HTS_Cocon_Commander();
        $plans     = $commander->get_plans();
        $cancelled_pending = 0;
        $cancelled_queued  = 0;

        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) ) continue;
            foreach ( $plan['articles'] as $akey => $art ) {
                $st = $art['status'] ?? '';

                // pending_queue → back to to_generate (never sent to API)
                if ( $st === 'pending_queue' ) {
                    $commander->update_article_status( $cocon_id, $akey, 'to_generate', array(
                        'cancelled_at'  => current_time( 'Y-m-d H:i:s' ),
                        'cancel_reason' => 'Arrêt d\'urgence',
                    ) );
                    $cancelled_pending++;
                }

                // queued (already sent to API) → mark as error so cron ignores the result
                if ( $st === 'queued' && ! empty( $art['job_id'] ) ) {
                    $commander->update_article_status( $cocon_id, $akey, 'error', array(
                        'error_reason'  => 'Annulé par arrêt d\'urgence',
                        'cancelled_at'  => current_time( 'Y-m-d H:i:s' ),
                    ) );
                    // Delete the transient so cron won't create a draft
                    delete_transient( 'hts_article_' . $art['job_id'] );
                    $cancelled_queued++;
                }
            }
        }

        // Set emergency stop flag for next cron cycle (safety net)
        set_transient( 'hts_generation_emergency_stop', true, 5 * MINUTE_IN_SECONDS );

        // Also disable auto mode
        $config = self::get_auto_schedule_config();
        $config['enabled'] = false;
        update_option( self::OPTION_AUTO_SCHEDULE, $config, false );

        // Clear dispatch lock
        delete_transient( 'hts_dispatch_lock' );

        $total = $cancelled_pending + $cancelled_queued;

        HTS_Cocon_Commander::cocon_log( 'emergency_stop', sprintf(
            '🛑 ARRÊT D\'URGENCE : %d en file annulés, %d en cours annulés, mode auto désactivé',
            $cancelled_pending, $cancelled_queued
        ), array() );

        self::log( sprintf( 'Emergency stop: %d pending + %d queued cancelled', $cancelled_pending, $cancelled_queued ), 'warn' );

        wp_send_json_success( array(
            'cancelled_pending' => $cancelled_pending,
            'cancelled_queued'  => $cancelled_queued,
            'total'             => $total,
            'message'           => sprintf( '🛑 %d article(s) annulé(s). Mode auto désactivé.', $total ),
        ) );
    }

    public function ajax_trigger_scan() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $result = $this->cron_weekly_scan();
        wp_send_json_success( $result );
    }

    /**
     * Met à jour la config de l'agent.
     */
    public function ajax_update_config() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $max_articles = isset( $_POST['max_articles_per_week'] )
            ? min( (int) $_POST['max_articles_per_week'], self::HARD_LIMIT_ARTICLES_PER_WEEK )
            : self::DEFAULT_MAX_ARTICLES_PER_WEEK;

        $image_source = sanitize_text_field( $_POST['image_source'] ?? 'library_first' );
        if ( ! in_array( $image_source, array( 'library_first', 'dalle', 'pexels' ), true ) ) {
            $image_source = 'library_first';
        }

        $enabled = isset( $_POST['enabled'] ) ? (int) $_POST['enabled'] : null;
        $mode    = isset( $_POST['mode'] ) ? sanitize_text_field( $_POST['mode'] ) : null;

        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            HTS_Workflow_Engine::update_agent_config( self::AGENT_ID, $enabled, $mode, array(
                'max_articles_per_week' => $max_articles,
                'image_source'          => $image_source,
            ) );
        }

        wp_send_json_success( array(
            'max_articles_per_week' => $max_articles,
            'image_source'          => $image_source,
        ) );
    }

    /**
     * Récupère la queue actuelle + historique.
     */
    public function ajax_get_queue() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $last_run = get_option( self::OPTION_LAST_RUN, null );
        $pending  = array();

        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $pending = HTS_Workflow_Engine::get_pending( self::AGENT_ID, 20 );
        }

        wp_send_json_success( array(
            'last_run' => $last_run,
            'pending'  => $pending,
            'config'   => array(
                'enabled'               => self::is_enabled(),
                'max_articles_per_week' => self::get_max_articles_per_week(),
                'articles_this_week'    => self::count_articles_this_week(),
                'image_source'          => self::get_image_source_preference(),
                'draft_accumulation'    => self::check_draft_accumulation(),
            ),
        ) );
    }

    /* ═══════════════════════════════════════════════
     *  AUTO-SCHEDULE : CRON + SLOT CALCULATION (BLOC B)
     * ═══════════════════════════════════════════════ */

    /**
     * Valeurs par défaut de la config auto-schedule.
     */
    public static function get_auto_schedule_defaults() {
        return array(
            'enabled'       => false,
            'days'          => array( 1, 2, 3, 4, 5 ), // 1=Lundi...7=Dimanche
            'time'          => '09:00',
            'max_per_day'   => 1,
            'min_gap_hours' => 2,
        );
    }

    /**
     * Récupère la config auto-schedule.
     *
     * @return array
     */
    public static function get_auto_schedule_config() {
        return wp_parse_args(
            get_option( self::OPTION_AUTO_SCHEDULE, array() ),
            self::get_auto_schedule_defaults()
        );
    }

    /**
     * Cron auto-schedule : planifie automatiquement les articles prêts.
     *
     * @return array Résumé { scheduled, skipped, errors }
     */
    public function cron_auto_schedule( $manual_trigger = false, $force = false ) {
        $start  = microtime( true );
        $config = self::get_auto_schedule_config();

        // ── 0. Mutex lock atomique (P1: empêche 2 exécutions parallèles) ──
        $lock_key = 'hts_auto_schedule_lock';
        $lock_acquired = false;
        if ( wp_using_ext_object_cache() ) {
            // Atomique avec Redis/Memcached
            $lock_acquired = wp_cache_add( $lock_key, time(), '', 5 * MINUTE_IN_SECONDS );
        } else {
            // Fallback transient (OK sans object cache)
            if ( ! get_transient( $lock_key ) ) {
                set_transient( $lock_key, time(), 5 * MINUTE_IN_SECONDS );
                $lock_acquired = true;
            }
        }
        if ( ! $lock_acquired ) {
            self::log( 'Auto-Schedule : déjà en cours — ignoré (lock actif)', 'info' );
            return array( 'skipped' => 'locked' );
        }

        // ── P2: try/finally pour garantir la libération du lock ──
        try {

        self::cocon_log( 'auto_sched_cron', '🔄 Cron auto-schedule démarré', array() );

        // ── 1. Config activée ? ──
        if ( empty( $config['enabled'] ) ) {
            self::log( 'Auto-Schedule désactivé — ignoré', 'info' );
            self::cocon_log( 'auto_sched_skipped', '⏭️ Cron ignoré : publication automatique désactivée', array() );
            return array( 'skipped' => 'disabled' );
        }

        // ── 2. Mode agent = 'auto' ? (sauté si déclenchement manuel) ──
        // Note: articles explicitly approved via _hts_schedule_approved bypass this check
        // because the user already validated them manually from the Planning page.
        if ( ! $manual_trigger && class_exists( 'HTS_Workflow_Engine' ) ) {
            $agents     = HTS_Workflow_Engine::get_all_agents();
            $auto_write = $agents[ self::AGENT_ID ] ?? array();
            if ( ( $auto_write['mode'] ?? 'review' ) !== 'auto' ) {
                // In review mode, only process explicitly approved articles
                // (skip Phase A auto-generation entirely)
                $has_approved = self::get_auto_schedulable_posts();
                if ( empty( $has_approved ) ) {
                    self::log( 'Auto-Schedule : mode relecture + aucun article approuvé — ignoré', 'info' );
                    self::cocon_log( 'auto_sched_skipped', '⏭️ Cron ignoré : mode relecture, aucun article validé', array() );
                    return array( 'skipped' => 'review_mode_no_approved' );
                }
                // Has approved articles → continue, but skip Phase A (auto-generation)
                self::log( 'Auto-Schedule : mode relecture mais ' . count( $has_approved ) . ' article(s) approuvé(s) — planification en cours', 'info' );
            }
        }

        // ── 3. Anti-accumulation (sauté en mode forcé) ──
        if ( ! $force && ! self::check_draft_accumulation() ) {
            self::log( 'Auto-Schedule : trop de brouillons non validés — suspendu', 'warn' );
            self::cocon_log( 'auto_sched_skipped', '⏭️ Cron suspendu : trop de brouillons non validés', array() );
            return array( 'skipped' => 'draft_accumulation' );
        }

        // ── Phase A : Auto-génération des articles cocon to_generate ──
        // Only in auto mode — review mode only schedules explicitly approved articles
        $gen_result = array( 'generated' => 0 );
        $img_result = array( 'processed' => 0 );
        $is_auto_mode = true;
        if ( class_exists( 'HTS_Workflow_Engine' ) ) {
            $agents     = HTS_Workflow_Engine::get_all_agents();
            $auto_write = $agents[ self::AGENT_ID ] ?? array();
            $is_auto_mode = ( ( $auto_write['mode'] ?? 'review' ) === 'auto' );
        }
        if ( $is_auto_mode ) {
            $gen_result = self::phase_auto_generate( $config );
            // ── Phase B : Génération images DALL-E sur brouillons sans image ──
            $img_result = self::phase_auto_images();
        }

        // ── 4. Collecter les articles prêts ──
        $ready_posts = self::get_auto_schedulable_posts();
        if ( empty( $ready_posts ) ) {
            self::log( 'Auto-Schedule : aucun article prêt à planifier', 'info' );
            self::cocon_log( 'auto_sched_cron', '🔄 Cron terminé : aucun article éligible', array() );
            return array( 'scheduled' => 0 );
        }

        // ── 5. Vérifier le hard limit semaine ──
        $max_per_week    = self::get_max_articles_per_week();
        $already_week    = self::count_scheduled_this_week();
        $remaining_week  = max( 0, min( $max_per_week, self::HARD_LIMIT_ARTICLES_PER_WEEK ) - $already_week );

        if ( $remaining_week <= 0 && ! $force ) {
            self::log( sprintf(
                'Auto-Schedule : limite hebdo atteinte (%d/%d) — pas de nouvelle planification',
                $already_week, $max_per_week
            ), 'info' );
            self::cocon_log( 'auto_sched_skipped', sprintf( '⏭️ Limite hebdomadaire atteinte (%d/%d)', $already_week, $max_per_week ), array() );
            return array( 'skipped' => 'week_limit', 'already' => $already_week, 'max' => $max_per_week );
        }

        // En mode force, permettre jusqu'à 10 articles supplémentaires
        if ( $force && $remaining_week <= 0 ) {
            $remaining_week = self::HARD_LIMIT_ARTICLES_PER_WEEK;
            self::cocon_log( 'auto_sched_cron', 'Mode forcé : limite hebdo ignorée', array() );
        }

        // ── 6. Planifier chaque article ──
        $scheduled = 0;
        $skipped   = 0;
        $errors    = 0;

        foreach ( $ready_posts as $post_id ) {
            if ( $scheduled >= $remaining_week ) break;

            try {
                // Re-check auto publish conditions
                $conditions = self::check_auto_publish_conditions( $post_id, $manual_trigger );
                if ( ! $conditions['can_publish'] ) {
                    self::log( sprintf(
                        'Auto-Schedule : #%d non éligible — %s',
                        $post_id, implode( ', ', $conditions['reasons'] )
                    ), 'info' );
                    self::cocon_log( 'auto_sched_skipped', sprintf(
                        '⏭️ « %s » non éligible', get_the_title( $post_id )
                    ), array( 'title' => get_the_title( $post_id ), 'reasons' => $conditions['reasons'] ) );
                    $skipped++;
                    continue;
                }

                // Pre-check cannibalisation
                $keyword = get_post_meta( $post_id, '_hts_focus_keyword', true ) ?: get_the_title( $post_id );
                $topic_check = self::pre_check_topic( array( 'keyword' => $keyword, 'title' => get_the_title( $post_id ) ) );
                if ( $topic_check !== 'ok' ) {
                    self::log( sprintf( 'Auto-Schedule : #%d bloqué — cannibalisation', $post_id ), 'warn' );
                    self::cocon_log( 'auto_sched_skipped', sprintf(
                        '⏭️ « %s » bloqué : cannibalisation détectée', get_the_title( $post_id )
                    ), array( 'title' => get_the_title( $post_id ), 'keyword' => $keyword ) );
                    $skipped++;
                    continue;
                }

                // Trouver le prochain slot
                $slot = self::get_next_publish_slot( $config );
                if ( ! $slot ) {
                    self::log( 'Auto-Schedule : aucun slot disponible sur 2 semaines', 'warn' );
                    self::cocon_log( 'auto_sched_skipped', '⏭️ Plus aucun créneau disponible sur 2 semaines', array() );
                    break;
                }

                // Planifier
                $slot_ts = strtotime( $slot );
                $sched_upd = wp_update_post( array(
                    'ID'            => $post_id,
                    'post_status'   => 'future',
                    'post_date'     => $slot,
                    'post_date_gmt' => get_gmt_from_date( $slot ),
                ) );

                if ( is_wp_error( $sched_upd ) || 0 === $sched_upd ) {
                    self::log( 'auto_schedule: échec planification post #' . $post_id, 'error' );
                    continue;
                }

                // Meta traçabilité
                update_post_meta( $post_id, '_hts_auto_scheduled', '1' );
                update_post_meta( $post_id, '_hts_auto_scheduled_at', current_time( 'mysql' ) );

                // Mettre à jour status Commander si article cocon
                $cocon_id    = get_post_meta( $post_id, '_hts_cocon_id', true );
                $article_key = get_post_meta( $post_id, '_hts_article_key', true );
                if ( $cocon_id && $article_key && class_exists( 'HTS_Cocon_Commander' ) ) {
                    $commander = new HTS_Cocon_Commander();
                    $commander->update_article_status( $cocon_id, $article_key, 'scheduled', array(
                        'scheduled_date' => $slot,
                        'auto_scheduled' => true,
                    ) );
                }

                // Audit Trail
                if ( class_exists( 'HTS_Audit_Trail' ) ) {
                    HTS_Audit_Trail::log( $post_id, 'auto_scheduled', array(
                        'source'         => 'auto_schedule_cron',
                        'scheduled_date' => $slot,
                        'time'           => current_time( 'mysql' ),
                    ) );
                }

                self::log( sprintf(
                    'Auto-Schedule : #%d « %s » → planifié le %s',
                    $post_id, get_the_title( $post_id ), $slot
                ), 'success' );

                self::cocon_log( 'auto_sched_article', sprintf(
                    '📅 « %s » planifié le %s',
                    get_the_title( $post_id ),
                    date_i18n( 'l j F à H:i', $slot_ts )
                ), array( 'title' => get_the_title( $post_id ), 'scheduled_date' => $slot ) );

                $scheduled++;

            } catch ( \Exception $e ) {
                self::log( 'Auto-Schedule erreur #' . $post_id . ' : ' . $e->getMessage(), 'error' );
                self::cocon_log( 'auto_sched_skipped', sprintf(
                    'Erreur planification #%d : %s', $post_id, $e->getMessage()
                ), array() );
                $errors++;
            }
        }

        $result = array(
            'scheduled'      => $scheduled,
            'skipped'        => $skipped,
            'errors'         => $errors,
            'remaining'      => $remaining_week - $scheduled,
            'generated'      => $gen_result['generated'] ?? 0,
            'images'         => $img_result['processed'] ?? 0,
            'duration_ms'    => round( ( microtime( true ) - $start ) * 1000 ),
        );

        self::log( sprintf(
            'Auto-Schedule terminé : %d généré(s), %d image(s), %d planifié(s), %d ignoré(s), %d erreur(s) (%dms)',
            $result['generated'], $result['images'], $scheduled, $skipped, $errors, $result['duration_ms']
        ), $scheduled > 0 ? 'success' : 'info' );

        self::cocon_log( 'auto_sched_cron', sprintf(
            '🔄 Cron terminé : %d généré(s), %d image(s), %d planifié(s), %d ignoré(s) — %dms',
            $result['generated'], $result['images'], $scheduled, $skipped, $result['duration_ms']
        ), $result );

        return $result;

        } finally {
            // ── P2: Libération garantie du lock (même en cas d'exception) ──
            if ( wp_using_ext_object_cache() ) {
                wp_cache_delete( $lock_key, '' );
            }
            delete_transient( $lock_key );
        }
    }

    /* ═══════════════════════════════════════════════
     *  PHASE A — AUTO-GÉNÉRATION D'ARTICLES COCON
     * ═══════════════════════════════════════════════ */

    /**
     * Phase A : Déclenche la génération des articles cocon en status to_generate.
     * Asynchrone : lance l'appel API mais ne poll pas — le prochain cron récupérera le résultat.
     *
     * Limites : 1 article par exécution de cron (pour ne pas surcharger l'API).
     *
     * @param array $config  Config auto-schedule
     * @return array { generated, skipped }
     */
    public static function phase_auto_generate( $config ) {
        $result = array( 'generated' => 0, 'skipped' => 0 );

        if ( ! class_exists( 'HTS_Cocon_Commander' ) ) return $result;

        // Vérifier le budget API
        if ( ! self::check_budget_guard() ) {
            self::cocon_log( 'auto_sched_skipped', '⏭️ Phase A ignorée : budget API épuisé', array() );
            return $result;
        }

        $commander = new \HTS_Cocon_Commander();
        $plans     = $commander->get_plans();
        if ( empty( $plans ) ) return $result;

        // ── Step 1: Poll ALL queued articles across ALL plans ──
        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) ) continue;

            foreach ( $plan['articles'] as $article_key => $art ) {
                if ( ( $art['status'] ?? '' ) !== 'queued' || empty( $art['job_id'] ) ) continue;

                $poll_result = self::poll_and_create_draft( $commander, $cocon_id, $article_key, $art['job_id'], $plan );
                if ( $poll_result === 'completed' ) {
                    $result['generated']++;
                    self::cocon_log( 'auto_sched_article', sprintf(
                        '📄 Article cocon auto-généré : « %s »',
                        $art['title'] ?? $art['topic'] ?? $article_key
                    ), array( 'cocon_id' => $cocon_id, 'article_key' => $article_key ) );
                } elseif ( $poll_result === 'pending' ) {
                    self::cocon_log( 'auto_sched_cron', sprintf(
                        '⏳ Génération en cours pour « %s » — on attend',
                        $art['title'] ?? $article_key
                    ), array() );
                }
            }
        }

        // ── G1: Re-vérifier s'il reste des jobs RÉELLEMENT en cours APRÈS le polling ──
        // (un job completed/failed n'est plus queued → on peut dispatcher)
        $plans = $commander->get_plans(); // Refresh APRÈS status changes du Step 1
        $still_queued = false;
        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) ) continue;
            foreach ( $plan['articles'] as $art ) {
                if ( ( $art['status'] ?? '' ) === 'queued' && ! empty( $art['job_id'] ) ) {
                    $still_queued = true;
                    break 2;
                }
            }
        }

        // ── Step 2: If no active queued jobs, dispatch ONE to_generate ──
        // Don't dispatch if there's still an active job (sequential processing)
        if ( $still_queued ) return $result;

        // $plans déjà rafraîchis dans le G1 check ci-dessus

        foreach ( $plans as $cocon_id => $plan ) {
            if ( empty( $plan['articles'] ) ) continue;

            foreach ( $plan['articles'] as $article_key => $art ) {
                if ( ( $art['status'] ?? '' ) !== 'to_generate' ) continue;

                // Pas de job en cours — lancer la génération
                $title   = $art['title'] ?? $art['topic'] ?? '';
                $keyword = $art['keyword'] ?? $art['focus_keyword'] ?? '';

                // G4: Re-check atomique du statut (évite double dispatch si 2 crons simultanés)
                $fresh_plans = $commander->get_plans();
                $fresh_art   = $fresh_plans[ $cocon_id ]['articles'][ $article_key ] ?? array();
                if ( ( $fresh_art['status'] ?? '' ) !== 'to_generate' ) {
                    self::log( 'Auto-Generate : statut déjà changé pour ' . $article_key . ', skip', 'info' );
                    continue;
                }

                // Pre-check cannibalisation
                $topic_check = self::pre_check_topic( array( 'keyword' => $keyword ?: $title, 'title' => $title ) );
                if ( $topic_check !== 'ok' ) {
                    self::cocon_log( 'auto_sched_skipped', sprintf(
                        '⏭️ « %s » non généré : cannibalisation détectée', $title
                    ), array( 'keyword' => $keyword ) );
                    $result['skipped']++;
                    continue;
                }

                // Lancer la génération via Commander
                $gen_result = self::trigger_article_generation( $commander, $cocon_id, $article_key, $plan );
                if ( $gen_result ) {
                    self::cocon_log( 'auto_sched_article', sprintf(
                        '✍️ Génération lancée automatiquement : « %s » (cocon %s)',
                        $title, $plan['name'] ?? $plan['keyword'] ?? $cocon_id
                    ), array( 'cocon_id' => $cocon_id, 'title' => $title ) );
                    $result['generated']++;
                } else {
                    $result['skipped']++;
                }

                return $result; // 1 dispatch par cron max
            }
        }

        return $result;
    }

    /**
     * Déclenche la génération d'un article cocon via l'API SaaS.
     *
     * @param HTS_Cocon_Commander $commander
     * @param string              $cocon_id
     * @param string              $article_key
     * @param array               $plan
     * @return bool Success
     */
    private static function trigger_article_generation( $commander, $cocon_id, $article_key, $plan ) {
        $siblings      = $commander->get_existing_siblings( $cocon_id );
        $pillar_post_id = hts_url_to_postid( $plan['pillar_url'] ?? '' );
        $pillar_title   = $pillar_post_id ? get_the_title( $pillar_post_id ) : '';

        $topic_id = (int) ( $plan['articles'][ $article_key ]['topic_id'] ?? 0 );

        $api_body = array(
            'cocon_id'          => $cocon_id,
            'topic_id'          => $topic_id,
            'site_url'          => site_url(),
            'pillar_url'        => $plan['pillar_url'] ?? '',
            'pillar_title'      => $pillar_title,
            'siblings'          => $siblings,
            'recommended_links' => $commander->get_recommended_links( $cocon_id ),
            'language'          => $plan['language'] ?? 'fr-FR',
            'auto_validate'     => true,
        );

        $result = $commander->cocon_api_call_public( 'POST', 'generate-article', $api_body );

        if ( ! $result['success'] ) {
            self::log( 'Auto-Generate : erreur API — ' . ( $result['error'] ?? 'inconnue' ), 'error' );
            return false;
        }

        $job_id = $result['data']['job_id'] ?? '';
        if ( empty( $job_id ) ) return false;

        // Stocker le job_id dans le plan pour le prochain cron
        $commander->update_article_status( $cocon_id, $article_key, 'queued', array(
            'ordered_at' => current_time( 'Y-m-d H:i:s' ),
            'job_id'     => $job_id,
            'topic_id'   => $topic_id,
            'auto_generated' => true,
        ) );

        self::log( sprintf( 'Auto-Generate : article lancé (cocon #%s, job %s)', $cocon_id, $job_id ), 'success' );
        return true;
    }

    /**
     * Poll un job en cours et crée le brouillon si terminé.
     * Gère les retries : après 5 tentatives ou 2h de timeout, marque l'article en erreur.
     *
     * @param HTS_Cocon_Commander $commander
     * @param string              $cocon_id
     * @param string              $article_key
     * @param string              $job_id
     * @param array               $plan
     * @return string 'completed' | 'pending' | 'failed'
     */
    private static function poll_and_create_draft( $commander, $cocon_id, $article_key, $job_id, $plan ) {
        $art = $plan['articles'][ $article_key ] ?? array();

        // ── Retry / timeout guard ──
        $poll_retries = (int) ( $art['poll_retries'] ?? 0 );
        $queued_at    = $art['ordered_at'] ?? '';
        $max_retries  = 10;
        $max_age_sec  = 7200; // 2 heures

        $is_expired = ( ! empty( $queued_at ) && ( time() - strtotime( $queued_at ) ) > $max_age_sec );

        if ( $poll_retries >= $max_retries || $is_expired ) {
            $reason = $is_expired ? 'timeout (>2h)' : "max retries ($poll_retries/$max_retries)";
            $commander->update_article_status( $cocon_id, $article_key, 'error', array(
                'error_reason'  => $reason,
                'error_at'      => current_time( 'Y-m-d H:i:s' ),
                'poll_retries'  => $poll_retries,
            ) );
            self::log( sprintf( 'Auto-Generate : article %s abandonné — %s', $article_key, $reason ), 'error' );
            self::cocon_log( 'auto_sched_skipped', sprintf(
                '« %s » abandonné : %s',
                $art['title'] ?? $article_key, $reason
            ), array( 'cocon_id' => $cocon_id, 'article_key' => $article_key, 'reason' => $reason ) );
            return 'failed';
        }

        // ── Poll API ──
        $result = $commander->cocon_api_call_public( 'GET', 'article-status/' . $job_id );

        if ( ! $result['success'] ) {
            // G2: Incrémenter le compteur SEULEMENT sur échec poll (pas avant)
            $commander->update_article_status( $cocon_id, $article_key, 'queued', array(
                'poll_retries' => $poll_retries + 1,
            ) );
            self::log( 'Auto-Generate poll error: ' . ( $result['error'] ?? '' ), 'error' );
            self::cocon_log( 'auto_sched_skipped', sprintf(
                'Erreur poll API pour « %s » (tentative %d/%d)',
                $art['title'] ?? $article_key, $poll_retries + 1, $max_retries
            ), array() );
            return 'pending'; // On retente au prochain cron
        }

        $status = $result['data']['status'] ?? 'unknown';

        if ( $status === 'failed' || $status === 'error' ) {
            $commander->update_article_status( $cocon_id, $article_key, 'error', array(
                'error_reason' => 'API returned: ' . $status,
                'error_at'     => current_time( 'Y-m-d H:i:s' ),
            ) );
            self::cocon_log( 'auto_sched_skipped', sprintf(
                'Génération échouée côté API pour « %s »',
                $art['title'] ?? $article_key
            ), array( 'api_status' => $status ) );
            return 'failed';
        }

        if ( $status !== 'completed' || empty( $result['data']['article'] ) ) {
            return 'pending';
        }

        // ── Article prêt — stocker dans transient et créer le brouillon ──
        $transient_key = 'hts_article_' . $job_id;
        set_transient( $transient_key, $result['data']['article'], 7200 ); // G3: 2h au lieu d'1h

        // Appeler la méthode programmatique du Commander (plus de fallback)
        $draft_result = $commander->create_draft_from_article( $cocon_id, $article_key, $job_id, array(
            'auto_generated' => true,
        ) );

        if ( $draft_result && ! empty( $draft_result['post_id'] ) ) {
            self::cocon_log( 'draft_created', sprintf(
                'Brouillon auto-créé #%d « %s »',
                $draft_result['post_id'], $draft_result['title'] ?? ''
            ), array(
                'post_id' => $draft_result['post_id'],
                'title'   => $draft_result['title'] ?? '',
            ) );
            return 'completed';
        }

        self::log( 'Auto-Generate : create_draft_from_article a échoué pour job ' . $job_id, 'error' );
        return 'failed';
    }

    /* ═══════════════════════════════════════════════
     *  PHASE B — AUTO-IMAGES DALL-E
     * ═══════════════════════════════════════════════ */

    /**
     * Phase B : Génère les images DALL-E manquantes sur les brouillons éligibles.
     * Limite : 2 articles par exécution de cron (DALL-E est lent, ~30-60s/image).
     *
     * @return array { processed, skipped }
     */
    public static function phase_auto_images() {
        $result = array( 'processed' => 0, 'skipped' => 0 );

        // Vérifier que la génération d'images est activée
        if ( ! class_exists( 'Hts_Synchronise_Articles_Admin' ) ) return $result;

        $img_cfg = \Hts_Synchronise_Articles_Admin::get_image_settings();
        if ( empty( $img_cfg['featured_enabled'] ) && empty( $img_cfg['incontent_enabled'] ) ) return $result;

        // Vérifier qu'on a une clé API pour le provider choisi
        $provider = $img_cfg['image_provider'] ?? 'openai';
        if ( $provider === 'flux' ) {
            if ( empty( $img_cfg['flux_api_key'] ) ) return $result;
        } else {
            if ( ! function_exists( 'hts_get_openai_key' ) || empty( hts_get_openai_key() ) ) {
                return $result;
            }
        }

        // Trouver les brouillons auto-write sans image à la une (max 2)
        global $wpdb;

        // G5+IMG1: Cleanup des flags images stale (>30 min = génération crashée)
        // Format timestamp: meta_value est une date MySQL
        $wpdb->query(
            "DELETE FROM {$wpdb->postmeta}
             WHERE meta_key = '_hts_images_pending'
             AND meta_value != '1'
             AND meta_value != ''
             AND meta_value != '0'
             AND meta_value < '" . esc_sql( gmdate( 'Y-m-d H:i:s', time() - 1800 ) ) . "'"
        );
        // Format legacy '1': checker _hts_images_pending_since
        $stale_legacy = $wpdb->get_col( $wpdb->prepare(
            "SELECT pm.post_id FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->postmeta} ps ON pm.post_id = ps.post_id
                AND ps.meta_key = '_hts_images_pending_since'
                AND ps.meta_value < %d
             WHERE pm.meta_key = '_hts_images_pending' AND pm.meta_value = '1'",
            time() - 1800
        ) );
        foreach ( $stale_legacy as $stale_pid ) {
            delete_post_meta( (int) $stale_pid, '_hts_images_pending' );
            delete_post_meta( (int) $stale_pid, '_hts_images_pending_since' );
        }

        $drafts_no_image = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} aw ON p.ID = aw.post_id AND aw.meta_key = '_hts_auto_write' AND aw.meta_value = '1'
             LEFT JOIN {$wpdb->postmeta} th ON p.ID = th.post_id AND th.meta_key = '_thumbnail_id'
             WHERE p.post_status = 'draft'
             AND p.post_type IN ('post','page')
             AND ( th.meta_value IS NULL OR th.meta_value = '' OR th.meta_value = '0' )
             AND NOT EXISTS (
                 SELECT 1 FROM {$wpdb->postmeta} pend
                 WHERE pend.post_id = p.ID
                 AND pend.meta_key = '_hts_images_pending'
             )
             ORDER BY p.post_date ASC
             LIMIT 2"
        );

        if ( empty( $drafts_no_image ) ) return $result;

        foreach ( $drafts_no_image as $post_id ) {
            $post_id = (int) $post_id;
            $p       = get_post( $post_id );
            if ( ! $p ) continue;

            // Skip if deferred images cron is already pending for this post
            if ( get_post_meta( $post_id, '_hts_images_pending', true ) ) {
                $result['skipped']++;
                continue;
            }

            // G6: Re-vérifier le budget API avant chaque article
            if ( ! self::check_budget_guard() ) {
                self::cocon_log( 'auto_sched_skipped', '⏭️ Budget API atteint — arrêt images', array() );
                break;
            }

            $title   = $p->post_title;
            $keyword = get_post_meta( $post_id, '_hts_api_keyword', true )
                    ?: get_post_meta( $post_id, '_hts_focus_keyword', true )
                    ?: $title;
            $content = $p->post_content;

            // AM-G1: Chercher une image existante en bibliothèque média avant de générer
            $existing_media = self::find_existing_media_image( $keyword, $title );
            if ( $existing_media ) {
                set_post_thumbnail( $post_id, $existing_media );
                self::cocon_log( 'auto_sched_article', sprintf(
                    '🎨 Image existante réutilisée (#%d) pour « %s »', $existing_media, mb_substr( $title, 0, 40 )
                ), array( 'post_id' => $post_id, 'attachment_id' => $existing_media ) );
                $result['processed']++;
                continue;
            }

            self::cocon_log( 'auto_sched_cron', sprintf(
                '🎨 Génération image %s pour « %s »...', $provider, mb_substr( $title, 0, 40 )
            ), array( 'post_id' => $post_id ) );

            // G5: Poser le flag AVANT la génération (empêche double exécution)
            update_post_meta( $post_id, '_hts_images_pending', current_time( 'mysql' ) );

            try {
                $img_result = \Hts_Synchronise_Articles_Admin::cocon_generate_article_images(
                    $post_id, $title, $keyword, $content
                );

                // G5: Nettoyer le flag après succès
                delete_post_meta( $post_id, '_hts_images_pending' );

                $count = $img_result['count'] ?? 0;
                if ( $count > 0 ) {
                    // Note: cocon_generate_article_images() handles wp_update_post internally

                    self::cocon_log( 'auto_sched_article', sprintf(
                        '🎨 %d image(s) générée(s) pour « %s »', $count, mb_substr( $title, 0, 40 )
                    ), array( 'post_id' => $post_id, 'images' => $count ) );

                    $result['processed']++;
                } else {
                    self::cocon_log( 'auto_sched_skipped', sprintf(
                        '⏭️ Pas d\'image générée pour « %s » (clé OpenAI ou config manquante ?)', mb_substr( $title, 0, 40 )
                    ), array( 'post_id' => $post_id ) );
                    $result['skipped']++;
                }
            } catch ( \Exception $e ) {
                // G5: Nettoyer le flag même en cas d'erreur
                delete_post_meta( $post_id, '_hts_images_pending' );

                self::log( 'Phase B image error #' . $post_id . ': ' . $e->getMessage(), 'error' );
                self::cocon_log( 'auto_sched_skipped', sprintf(
                    'Erreur image pour « %s » : %s', mb_substr( $title, 0, 40 ), $e->getMessage()
                ), array( 'post_id' => $post_id ) );
                $result['skipped']++;
            }
        }

        return $result;
    }

    /* ═══════════════════════════════════════════════
     *  COLLECTE ARTICLES PLANIFIABLES
     * ═══════════════════════════════════════════════ */

    /**
     * Récupère les posts éligibles à la planification automatique.
     *
     * Articles draft avec meta _hts_auto_write = 1
     * OU articles cocon status received/ready dont le post est en draft.
     *
     * @return int[] Post IDs
     */
    public static function get_auto_schedulable_posts() {
        global $wpdb;

        // Only return articles explicitly approved for scheduling via _hts_schedule_approved meta.
        // This prevents test drafts from being auto-published.
        $approved_ids = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_schedule_approved' AND pm.meta_value = '1'
             WHERE p.post_status = 'draft' AND p.post_type IN ('post','page')
             ORDER BY p.post_date ASC
             LIMIT 20"
        );

        return array_map( 'intval', $approved_ids );
    }

    /**
     * Get all draft candidates for the scheduling queue (approved or not).
     * Used by the preview UI to show all candidates with checkboxes.
     */
    public static function get_all_schedulable_candidates() {
        global $wpdb;

        $post_ids = array();

        // Source 1: posts with _hts_auto_write = 1
        $auto_write_ids = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_auto_write' AND pm.meta_value = '1'
             WHERE p.post_status = 'draft' AND p.post_type IN ('post','page')
             ORDER BY p.post_date ASC
             LIMIT 30"
        );
        $post_ids = array_merge( $post_ids, array_map( 'intval', $auto_write_ids ) );

        // Source 2: cocon articles received/ready in draft
        if ( class_exists( 'HTS_Cocon_Commander' ) ) {
            $commander = new HTS_Cocon_Commander();
            $plans     = $commander->get_plans();

            foreach ( $plans as $cocon_id => $plan ) {
                if ( empty( $plan['articles'] ) ) continue;
                foreach ( $plan['articles'] as $art ) {
                    if ( ! in_array( $art['status'] ?? '', array( 'received', 'ready' ), true ) ) continue;
                    $pid = (int) ( $art['post_id'] ?? 0 );
                    if ( $pid <= 0 ) continue;
                    $p = get_post( $pid );
                    if ( ! $p || $p->post_status !== 'draft' ) continue;
                    if ( ! in_array( $pid, $post_ids, true ) ) {
                        $post_ids[] = $pid;
                    }
                }
            }
        }

        // Source 3: any HTS-generated draft
        $hts_drafts = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_api_generated' AND pm.meta_value = '1'
             WHERE p.post_status = 'draft' AND p.post_type IN ('post','page')
             ORDER BY p.post_date ASC
             LIMIT 30"
        );
        foreach ( array_map( 'intval', $hts_drafts ) as $pid ) {
            if ( ! in_array( $pid, $post_ids, true ) ) {
                $post_ids[] = $pid;
            }
        }

        return array_slice( array_unique( $post_ids ), 0, 30 );
    }

    /**
     * Calcule le prochain slot de publication disponible.
     *
     * @param array|null $config  Config auto-schedule (null = lire depuis option)
     * @return string|null        DateTime string 'Y-m-d H:i:s' ou null
     */
    public static function get_next_publish_slot( $config = null ) {
        if ( ! $config ) {
            $config = self::get_auto_schedule_config();
        }

        $tz  = wp_timezone();
        $now = ( new \DateTimeImmutable( 'now', $tz ) )->getTimestamp();

        for ( $d = 0; $d < 14; $d++ ) { // chercher sur 2 semaines max
            $date        = wp_date( 'Y-m-d', strtotime( "+{$d} days" ) );
            $day_of_week = (int) wp_date( 'N', strtotime( $date ) ); // 1=Lun...7=Dim

            if ( ! in_array( $day_of_week, $config['days'], false ) ) continue;

            // Compter les articles déjà planifiés/publiés ce jour
            $count_that_day = self::count_posts_for_date( $date );
            $max_per_day    = (int) ( $config['max_per_day'] ?? 1 );
            if ( $count_that_day >= $max_per_day ) continue;

            // Calculer l'heure
            $base_time = $config['time'] ?? '09:00';
            $time      = $base_time;

            if ( $count_that_day > 0 ) {
                $last_time = self::get_last_scheduled_time_for_date( $date );
                if ( $last_time ) {
                    $gap_hours = (int) ( $config['min_gap_hours'] ?? 2 );
                    $next_time = wp_date( 'H:i', strtotime( $last_time ) + $gap_hours * 3600 );
                    // Vérifier qu'on ne dépasse pas 22h
                    if ( (int) str_replace( ':', '', $next_time ) <= 2200 ) {
                        $time = $next_time;
                    } else {
                        continue; // Ce jour est complet
                    }
                }
            }

            $slot = $date . ' ' . $time . ':00';

            // Si le slot est dans le passé (aujourd'hui, heure déjà passée),
            // essayer "maintenant + 5 min" pour publier le jour même
            $slot_ts = ( new \DateTimeImmutable( $slot, $tz ) )->getTimestamp();
            if ( $slot_ts <= $now && $d === 0 ) {
                $fallback_time = wp_date( 'H:i', $now + 5 * MINUTE_IN_SECONDS );
                if ( (int) str_replace( ':', '', $fallback_time ) <= 2200 ) {
                    $slot    = $date . ' ' . $fallback_time . ':00';
                    $slot_ts = ( new \DateTimeImmutable( $slot, $tz ) )->getTimestamp();
                }
            }

            if ( $slot_ts > $now ) {
                return $slot;
            }
        }

        return null; // Pas de slot trouvé
    }

    /**
     * Calcule les N prochains slots de publication (pour la preview).
     * Simule l'occupation progressive des créneaux.
     *
     * @param int        $count   Nombre de slots à calculer
     * @param array|null $config  Config auto-schedule
     * @return string[]           Liste de DateTime strings 'Y-m-d H:i:s'
     */
    public static function get_next_publish_slots( $count = 10, $config = null ) {
        if ( ! $config ) {
            $config = self::get_auto_schedule_config();
        }

        $slots          = array();
        $tz             = wp_timezone();
        $now            = ( new \DateTimeImmutable( 'now', $tz ) )->getTimestamp();
        $simulated_days = array(); // date => count of simulated slots for that day

        for ( $d = 0; $d < 14 && count( $slots ) < $count; $d++ ) {
            $date        = wp_date( 'Y-m-d', strtotime( "+{$d} days" ) );
            $day_of_week = (int) wp_date( 'N', strtotime( $date ) );

            if ( ! in_array( $day_of_week, $config['days'], false ) ) continue;

            $real_count  = self::count_posts_for_date( $date );
            $sim_count   = $simulated_days[ $date ] ?? 0;
            $total_count = $real_count + $sim_count;
            $max_per_day = (int) ( $config['max_per_day'] ?? 1 );

            while ( $total_count < $max_per_day && count( $slots ) < $count ) {
                $base_time = $config['time'] ?? '09:00';
                $time      = $base_time;

                if ( $total_count > 0 ) {
                    // Calculer le gap depuis le dernier slot (réel ou simulé)
                    $gap_hours = (int) ( $config['min_gap_hours'] ?? 2 );
                    $last_real = ( $total_count > $sim_count ) ? self::get_last_scheduled_time_for_date( $date ) : null;

                    // Prendre le plus tardif entre le réel et les simulés
                    $last_simulated = null;
                    foreach ( $slots as $s ) {
                        if ( substr( $s, 0, 10 ) === $date ) {
                            $last_simulated = substr( $s, 11 );
                        }
                    }
                    $ref_time = $last_simulated ?: $last_real;
                    if ( $ref_time ) {
                        $next_time = wp_date( 'H:i', strtotime( $ref_time ) + $gap_hours * 3600 );
                        if ( (int) str_replace( ':', '', $next_time ) > 2200 ) break; // jour complet
                        $time = $next_time;
                    }
                }

                $slot    = $date . ' ' . $time . ':00';
                $slot_ts = ( new \DateTimeImmutable( $slot, $tz ) )->getTimestamp();

                // Si le slot est dans le passé (aujourd'hui), essayer maintenant + 5 min
                if ( $slot_ts <= $now && $d === 0 ) {
                    $fallback_time = wp_date( 'H:i', $now + 5 * MINUTE_IN_SECONDS );
                    if ( (int) str_replace( ':', '', $fallback_time ) <= 2200 ) {
                        $slot    = $date . ' ' . $fallback_time . ':00';
                        $slot_ts = ( new \DateTimeImmutable( $slot, $tz ) )->getTimestamp();
                    }
                }

                if ( $slot_ts > $now ) {
                    $slots[] = $slot;
                    $sim_count++;
                    $simulated_days[ $date ] = $sim_count;
                    $total_count++;
                } else {
                    break;
                }
            }
        }

        return $slots;
    }

    /**
     * Compte les posts HTS auto-planifiés pour une date donnée.
     *
     * @param string $date  Format Y-m-d
     * @return int
     */
    public static function count_posts_for_date( $date ) {
        global $wpdb;

        // P4: Compter TOUS les posts HTS planifiés (auto + manuels + cocon)
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             WHERE p.post_status IN ('future','publish')
             AND p.post_type IN ('post','page')
             AND DATE(p.post_date) = %s
             AND EXISTS (
                 SELECT 1 FROM {$wpdb->postmeta} pm
                 WHERE pm.post_id = p.ID
                 AND pm.meta_key IN ('_hts_auto_scheduled','_hts_calendar_scheduled','_hts_cocon_id')
             )",
            $date
        ) );
    }

    /**
     * Récupère l'heure du dernier post HTS auto-planifié pour une date.
     *
     * @param string $date  Format Y-m-d
     * @return string|null  Format H:i:s ou null
     */
    public static function get_last_scheduled_time_for_date( $date ) {
        global $wpdb;

        // P4: Chercher le dernier post HTS planifié (auto + manuels + cocon)
        return $wpdb->get_var( $wpdb->prepare(
            "SELECT TIME(p.post_date) FROM {$wpdb->posts} p
             WHERE p.post_status IN ('future','publish')
             AND p.post_type IN ('post','page')
             AND DATE(p.post_date) = %s
             AND EXISTS (
                 SELECT 1 FROM {$wpdb->postmeta} pm
                 WHERE pm.post_id = p.ID
                 AND pm.meta_key IN ('_hts_auto_scheduled','_hts_calendar_scheduled','_hts_cocon_id')
             )
             ORDER BY p.post_date DESC
             LIMIT 1",
            $date
        ) );
    }

    /**
     * Compte les articles planifiés (future) + publiés cette semaine.
     *
     * @return int
     */
    public static function count_scheduled_this_week() {
        global $wpdb;

        $week_start = wp_date( 'Y-m-d', strtotime( 'monday this week' ) );
        $week_end   = wp_date( 'Y-m-d', strtotime( 'sunday this week' ) );

        // Ne compter que les articles HTS (auto-scheduled OU créés par cocon commander)
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_status IN ('future','publish')
             AND p.post_type = 'post'
             AND DATE(p.post_date) BETWEEN %s AND %s
             AND (
                 (pm.meta_key = '_hts_auto_scheduled' AND pm.meta_value = '1')
                 OR pm.meta_key = '_hts_cocon_id'
             )",
            $week_start, $week_end
        ) );
    }

    /**
     * Récupère les infos de la prochaine publication auto-planifiée.
     *
     * @return array|null { post_id, title, date }
     */
    public static function get_next_auto_scheduled() {
        global $wpdb;

        $now = current_time( 'mysql' );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_date
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_hts_auto_scheduled' AND pm.meta_value = '1'
             WHERE p.post_status = 'future'
             AND p.post_date > %s
             ORDER BY p.post_date ASC
             LIMIT 1",
            $now
        ), ARRAY_A );

        if ( ! $row ) return null;

        return array(
            'post_id' => (int) $row['ID'],
            'title'   => $row['post_title'],
            'date'    => $row['post_date'],
        );
    }

    /**
     * Compte les articles en attente de planification auto.
     *
     * @return int
     */
    public static function count_pending_auto_schedule() {
        $posts = self::get_auto_schedulable_posts();
        return count( $posts );
    }

    /* ═══════════════════════════════════════════════
     *  BLOC C — HOOKS POST-PUBLICATION (future → publish)
     * ═══════════════════════════════════════════════ */

    /**
     * Hook transition_post_status pour les articles auto-planifiés.
     * Quand future → publish : lance les hooks post-publication.
     *
     * @param string   $new_status
     * @param string   $old_status
     * @param \WP_Post $post
     */
    public function on_auto_scheduled_publish( $new_status, $old_status, $post ) {
        // Uniquement future → publish
        if ( $new_status !== 'publish' || $old_status !== 'future' ) return;
        if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) return;

        // Vérifier que c'est un article auto-planifié
        $is_auto = get_post_meta( $post->ID, '_hts_auto_scheduled', true );
        if ( $is_auto !== '1' ) return;

        // 1. Post-publish hooks (IndexNow + GEO + Audit)
        self::post_publish_hooks( $post->ID );

        // 2. Mettre à jour status Commander
        $cocon_id    = get_post_meta( $post->ID, '_hts_cocon_id', true );
        $article_key = get_post_meta( $post->ID, '_hts_article_key', true );
        if ( $cocon_id && $article_key && class_exists( 'HTS_Cocon_Commander' ) ) {
            $commander = new HTS_Cocon_Commander();
            $commander->update_article_status( $cocon_id, $article_key, 'published', array(
                'published_at'   => current_time( 'mysql' ),
                'auto_published' => true,
            ) );
        }

        // 3. Invalider le cache embeddings pour ré-indexer
        if ( class_exists( 'HTS_Embeddings' ) ) {
            delete_post_meta( $post->ID, '_hts_embedding_hash' );
        }

        self::log( sprintf(
            'Auto-Schedule : article #%d « %s » publié automatiquement',
            $post->ID, $post->post_title
        ), 'success' );

        self::cocon_log( 'auto_sched_published', sprintf(
            '« %s » publié automatiquement',
            $post->post_title
        ), array(
            'title'   => $post->post_title,
            'post_id' => $post->ID,
        ) );
    }

    /* ═══════════════════════════════════════════════
     *  AJAX — AUTO-SCHEDULE (BLOC A)
     * ═══════════════════════════════════════════════ */

    /**
     * AJAX : Sauvegarder la config auto-schedule.
     */
    public function ajax_save_auto_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $enabled = ! empty( $_POST['enabled'] );

        // Parser les jours — JS sends comma-separated string "1,2,3,4,5"
        $days_raw = $_POST['days'] ?? '';
        if ( is_string( $days_raw ) ) {
            $days_raw = array_filter( explode( ',', $days_raw ) );
        }
        $days_raw = (array) $days_raw;
        $days     = array_values( array_filter( array_map( 'intval', $days_raw ), function( $d ) {
            return $d >= 1 && $d <= 7;
        } ) );
        if ( empty( $days ) ) $days = array( 1, 2, 3, 4, 5 ); // Défaut Lun-Ven

        // Heure
        $time = sanitize_text_field( $_POST['time'] ?? '09:00' );
        if ( ! preg_match( '/^\d{2}:\d{2}$/', $time ) ) $time = '09:00';

        // Articles par jour
        $max_per_day = max( 1, min( 3, (int) ( $_POST['max_per_day'] ?? 1 ) ) );

        // Délai entre articles
        $min_gap_hours = max( 1, min( 6, (int) ( $_POST['min_gap_hours'] ?? 2 ) ) );

        $config = array(
            'enabled'       => $enabled,
            'days'          => $days,
            'time'          => $time,
            'max_per_day'   => $max_per_day,
            'min_gap_hours' => $min_gap_hours,
        );

        update_option( self::OPTION_AUTO_SCHEDULE, $config, false );

        $day_names = array( 1 => 'Lun', 2 => 'Mar', 3 => 'Mer', 4 => 'Jeu', 5 => 'Ven', 6 => 'Sam', 7 => 'Dim' );
        $day_labels = array_map( function( $d ) use ( $day_names ) { return $day_names[ $d ] ?? $d; }, $days );

        self::log(
            $enabled
                ? sprintf( 'Auto-Schedule activé : %s, %s, max %d/jour', implode( ',', $days ), $time, $max_per_day )
                : 'Auto-Schedule désactivé',
            'info'
        );

        self::cocon_log(
            'auto_sched_config',
            $enabled
                ? sprintf( '⚙️ Publication auto configurée : %s à %s, %d/jour max', implode( ', ', $day_labels ), $time, $max_per_day )
                : '⏸ Publication automatique désactivée',
            array(
                'enabled'       => $enabled,
                'days'          => $day_labels,
                'time'          => $time,
                'max_per_day'   => $max_per_day,
                'min_gap_hours' => $min_gap_hours,
            )
        );

        wp_send_json_success( $config );
    }

    /**
     * AJAX : Récupérer la config auto-schedule + status.
     */
    public function ajax_get_auto_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $config = self::get_auto_schedule_config();
        $next   = self::get_next_auto_scheduled();

        wp_send_json_success( array(
            'config'              => $config,
            'next_scheduled'      => $next,
            'pending_count'       => self::count_pending_auto_schedule(),
            'scheduled_this_week' => self::count_scheduled_this_week(),
            'max_per_week'        => self::get_max_articles_per_week(),
            'next_slot'           => self::get_next_publish_slot( $config ),
        ) );
    }

    /**
     * AJAX : Déclencher manuellement l'auto-schedule.
     */
    public function ajax_trigger_auto_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        self::cocon_log( 'auto_sched_trigger', '▶️ Planification manuelle déclenchée', array() );

        $result = $this->cron_auto_schedule( true ); // true = manual trigger, skip review mode check
        wp_send_json_success( $result );
    }

    /**
     * AJAX : Forcer l'auto-schedule (bypass limite hebdo + mode review).
     * Utile pour tester le pipeline complet.
     */
    public function ajax_force_auto_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        self::cocon_log( 'auto_sched_trigger', 'Planification FORCÉE déclenchée', array() );

        $result = $this->cron_auto_schedule( true, true ); // manual=true, force=true (bypass week limit)
        wp_send_json_success( $result );
    }

    /**
     * AJAX : Toggle schedule approval for one or multiple posts.
     * Accepts: post_ids (array or single int), approved (1 or 0)
     */
    public function ajax_toggle_schedule_approval() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $raw_ids  = $_POST['post_ids'] ?? array();
        $approved = (int) ( $_POST['approved'] ?? 0 );

        if ( ! is_array( $raw_ids ) ) {
            $raw_ids = array( $raw_ids );
        }
        $post_ids = array_filter( array_map( 'intval', $raw_ids ) );

        if ( empty( $post_ids ) ) {
            wp_send_json_error( 'Aucun article spécifié.' );
        }

        $updated   = 0;
        $scheduled = array(); // Track which posts got immediately scheduled

        foreach ( $post_ids as $pid ) {
            if ( $approved ) {
                update_post_meta( $pid, '_hts_schedule_approved', '1' );

                // ── Planification immédiate : si le post est un brouillon, le programmer maintenant ──
                $post = get_post( $pid );
                if ( $post && $post->post_status === 'draft' ) {
                    $slot = self::get_next_publish_slot( self::get_auto_schedule_config() );
                    if ( $slot ) {
                        // Vérifier les conditions de publication
                        $conditions = self::check_auto_publish_conditions( $pid, true ); // true = skip mode check
                        if ( $conditions['can_publish'] ) {
                            $slot_ts  = strtotime( $slot );
                            $gmt_date = get_gmt_from_date( $slot );

                            $result = wp_update_post( array(
                                'ID'            => $pid,
                                'post_status'   => 'future',
                                'post_date'     => $slot,
                                'post_date_gmt' => $gmt_date,
                            ), true );

                            if ( ! is_wp_error( $result ) && $result > 0 ) {
                                // Vérifier que WP n'a pas auto-publié
                                $status_after = get_post_status( $pid );
                                if ( $status_after !== 'future' ) {
                                    global $wpdb;
                                    $wpdb->update( $wpdb->posts,
                                        array( 'post_status' => 'future', 'post_date' => $slot, 'post_date_gmt' => $gmt_date ),
                                        array( 'ID' => $pid ), array( '%s', '%s', '%s' ), array( '%d' )
                                    );
                                    clean_post_cache( $pid );
                                    $gmt_ts = strtotime( $gmt_date . ' +0000' );
                                    wp_clear_scheduled_hook( 'publish_future_post', array( $pid ) );
                                    if ( $gmt_ts > time() ) {
                                        wp_schedule_single_event( $gmt_ts, 'publish_future_post', array( $pid ) );
                                    }
                                }

                                update_post_meta( $pid, '_hts_auto_scheduled', '1' );
                                update_post_meta( $pid, '_hts_auto_scheduled_at', current_time( 'mysql' ) );
                                update_post_meta( $pid, '_hts_calendar_scheduled', current_time( 'mysql' ) );
                                update_post_meta( $pid, '_hts_calendar_date', $slot );

                                $scheduled[] = array(
                                    'post_id' => $pid,
                                    'title'   => get_the_title( $pid ),
                                    'date'    => $slot,
                                    'date_fr' => date_i18n( 'l j F à H:i', $slot_ts ),
                                );

                                if ( function_exists( 'hts_add_log' ) ) {
                                    hts_add_log( sprintf(
                                        'Planning : #%d « %s » validé + planifié immédiatement → %s',
                                        $pid, get_the_title( $pid ), $slot
                                    ), 'success', 'auto-write' );
                                }
                            }
                        } else {
                            // Post pas éligible — on le garde approved, le cron re-vérifiera
                            if ( function_exists( 'hts_add_log' ) ) {
                                hts_add_log( sprintf(
                                    'Planning : #%d validé mais pas éligible (%s) — sera retenté par le cron',
                                    $pid, implode( ', ', $conditions['reasons'] )
                                ), 'info', 'auto-write' );
                            }
                        }
                    }
                }
            } else {
                delete_post_meta( $pid, '_hts_schedule_approved' );
            }
            $updated++;
        }

        self::cocon_log( 'auto_sched_config', sprintf(
            '%s %d article(s) %s pour la publication%s',
            $approved ? '✅' : '⛔',
            $updated,
            $approved ? 'approuvé(s)' : 'retiré(s)',
            ! empty( $scheduled ) ? ' — ' . count( $scheduled ) . ' planifié(s) immédiatement' : ''
        ), array() );

        wp_send_json_success( array(
            'updated'   => $updated,
            'scheduled' => $scheduled,
        ) );
    }

    /**
     * AJAX : Preview de la file d'attente auto-schedule.
     * Montre les articles éligibles avec leur ordre, cocon, créneau prévu et conditions.
     */
    public function ajax_preview_auto_schedule() {
        check_ajax_referer( 'hts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions insuffisantes.' );
        HTS_Subscription::require_tier(2);

        $config    = self::get_auto_schedule_config();
        // Show ALL candidates (not just approved) so user can check/uncheck
        $post_ids  = self::get_all_schedulable_candidates();
        $posts_out = array();
        $slot_idx  = 0;

        // Count approved for slot calculation
        $approved_ids = self::get_auto_schedulable_posts();

        // Pré-calculer les slots disponibles
        $slots = array();
        if ( ! empty( $config['enabled'] ) ) {
            $slots = self::get_next_publish_slots( min( count( $approved_ids ), 10 ), $config );
        }

        // Charger les infos cocon
        $cocon_map = array();
        if ( class_exists( 'HTS_Cocon_Commander' ) ) {
            $commander = new HTS_Cocon_Commander();
            $plans     = $commander->get_plans();
            foreach ( $plans as $cocon_id => $plan ) {
                $name = $plan['name'] ?? $plan['keyword'] ?? $cocon_id;
                if ( ! empty( $plan['articles'] ) ) {
                    foreach ( $plan['articles'] as $art ) {
                        $pid = (int) ( $art['post_id'] ?? 0 );
                        if ( $pid > 0 ) {
                            $cocon_map[ $pid ] = $name;
                        }
                    }
                }
            }
        }

        $eligible_count = 0;
        $blocked_count  = 0;
        $approved_count = 0;

        foreach ( $post_ids as $post_id ) {
            $p = get_post( $post_id );
            if ( ! $p ) continue;

            $conditions  = self::check_auto_publish_conditions( $post_id );
            $is_eligible = $conditions['can_publish'];
            $is_approved = in_array( $post_id, $approved_ids, true );

            if ( $is_eligible ) {
                $eligible_count++;
            } else {
                $blocked_count++;
            }
            if ( $is_approved ) $approved_count++;

            $slot_label = null;
            if ( $is_approved && $is_eligible && isset( $slots[ $slot_idx ] ) ) {
                $slot_ts    = strtotime( $slots[ $slot_idx ] );
                $slot_label = date_i18n( 'D j M \u00e0 H:i', $slot_ts );
                $slot_idx++;
            }

            $posts_out[] = array(
                'post_id'    => $post_id,
                'title'      => $p->post_title ?: '(sans titre)',
                'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
                'cocon_name' => $cocon_map[ $post_id ] ?? null,
                'eligible'   => $is_eligible,
                'approved'   => $is_approved,
                'reasons'    => $conditions['reasons'],
                'slot'       => $slot_label,
            );
        }

        // Résumé textuel
        $summary_parts = array();
        if ( $approved_count > 0 ) {
            $summary_parts[] = sprintf( '%d article(s) sélectionné(s) pour publication', $approved_count );
        }
        if ( $blocked_count > 0 ) {
            $summary_parts[] = sprintf( '%d article(s) bloqué(s) — corrigez les problèmes pour qu\'ils passent', $blocked_count );
        }
        if ( empty( $config['enabled'] ) ) {
            $summary_parts[] = '⏸ La publication automatique est désactivée — les créneaux ne sont pas calculés';
        }

        self::cocon_log( 'auto_sched_preview', sprintf(
            '👁️ File d\'attente consultée : %d éligible(s), %d bloqué(s)',
            $eligible_count, $blocked_count
        ), array( 'eligible' => $eligible_count, 'blocked' => $blocked_count ) );

        wp_send_json_success( array(
            'posts'   => $posts_out,
            'summary' => implode( ' · ', $summary_parts ),
        ) );
    }

    /* ═══════════════════════════════════════════════
     *  LOGGING
     * ═══════════════════════════════════════════════ */

    private static function log( $message, $type = 'info' ) {
        if ( function_exists( 'hts_add_log' ) ) {
            hts_add_log( $message, $type, 'auto-write' );
        }
    }

    /**
     * Log dans le panel Activité du Cocon Commander.
     * Permet aux événements auto-schedule d'apparaître dans les logs cocon.
     *
     * @param string $log_type  Type de log (auto_sched_config, auto_sched_article, etc.)
     * @param string $message   Message lisible
     * @param array  $data      Données complémentaires (title, keyword, etc.)
     */
    private static function cocon_log( $log_type, $message, $data = array() ) {
        if ( class_exists( 'HTS_Cocon_Commander' ) && method_exists( 'HTS_Cocon_Commander', 'cocon_log' ) ) {
            HTS_Cocon_Commander::cocon_log( $log_type, $message, $data );
        }
    }

    /* ═══════════════════════════════════════════════
     *  COACH INTEGRATION STUB — Sprint 5.1
     * ═══════════════════════════════════════════════ */

    /**
     * Generate an SEO article from Coach request.
     * Called from Coach Agent via dispatch_catalog_action().
     *
     * @since 5.1
     * @param array $params { keyword: string, cluster_id?: int, tone?: string, word_count?: int }
     * @return bool
     */
    public static function generate_from_coach( $params ) {
        $keyword = isset( $params['keyword'] ) ? sanitize_text_field( $params['keyword'] ) : '';
        if ( empty( $keyword ) ) return false;

        // Use the standalone article pipeline if available
        if ( class_exists( 'HTS_Standalone_Article' ) && method_exists( 'HTS_Standalone_Article', 'create_from_keyword' ) ) {
            $options = array(
                'keyword'    => $keyword,
                'tone'       => $params['tone'] ?? 'professional',
                'word_count' => (int) ( $params['word_count'] ?? 1500 ),
            );
            if ( ! empty( $params['cluster_id'] ) ) {
                $options['cluster_id'] = (int) $params['cluster_id'];
            }
            $result = \HTS_Standalone_Article::create_from_keyword( $options );
            return ! empty( $result ) && ! is_wp_error( $result );
        }

        // Fallback: create a draft with the keyword as title
        $post_id = wp_insert_post( array(
            'post_title'   => $keyword,
            'post_content' => '<!-- Article à rédiger : ' . esc_html( $keyword ) . ' -->',
            'post_status'  => 'draft',
            'post_type'    => 'post',
        ) );

        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_hts_coach_generated', 1 );
            update_post_meta( $post_id, '_hts_focus_keyword', $keyword );
            // Assign Polylang language (fix: articles created in EN instead of FR)
            if ( function_exists( 'pll_set_post_language' ) ) {
                $post_lang = function_exists( 'pll_current_language' ) ? pll_current_language( 'slug' ) : '';
                if ( ! $post_lang ) $post_lang = substr( get_locale(), 0, 2 );
                pll_set_post_language( $post_id, $post_lang );
            }
            // S18 FIX: Use HTS_Language for accurate lang detection, fallback to locale
            $post_lang_meta = '';
            if ( class_exists( 'HTS_Language' ) && HTS_Language::is_multilingual() ) {
                $post_lang_meta = HTS_Language::get_current_lang();
            }
            if ( ! $post_lang_meta ) {
                $post_lang_meta = substr( get_locale(), 0, 2 );
            }
            update_post_meta( $post_id, '_hts_content_lang', $post_lang_meta );
            if ( function_exists( 'hts_add_log' ) ) {
                hts_add_log( "Coach: generate_from_coach brouillon #{$post_id} pour '{$keyword}'", 'info', 'coach' );
            }
            return true;
        }

        return false;
    }
}
